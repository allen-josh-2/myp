import {
    a as ue,
    b as gt,
    c as ft,
    d as ht
} from "./chunk-K7E57KVZ.js";
import "./chunk-2B6TWJ62.js";
import "./chunk-ZE4JIEWS.js";
import {
    a as mt
} from "./chunk-ZG5YLBXN.js";
import "./chunk-2E5FSGQH.js";
import {
    b as ut
} from "./chunk-FJFEFX5C.js";
import "./chunk-PZDHMQ7I.js";
import "./chunk-XHP3KBJE.js";
import "./chunk-J36DGFIN.js";
import {
    g as pt
} from "./chunk-WDS5LHZR.js";
import "./chunk-36T2HUF3.js";
import "./chunk-OG4EABPU.js";
import "./chunk-HUDETQT5.js";
import "./chunk-PGAHHPJ5.js";
import "./chunk-MBAKXBI4.js";
import "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import "./chunk-FAP35UT3.js";
import "./chunk-2KS5UOZO.js";
import "./chunk-KJCCJCIN.js";
import "./chunk-RW3SLQZQ.js";
import {
    Bc as ce,
    Cc as Xe,
    Dc as Ze,
    Oc as et,
    Q as w,
    T as B,
    Ta as Qe,
    Va as se,
    X as je,
    Y as $e,
    Zd as de,
    _ as oe,
    ab as Ye,
    bb as Ge,
    ca as D,
    g as Ee,
    h as Ie,
    ha as re,
    ia as Ue,
    la as We,
    lb as ae,
    n as Be,
    pb as He,
    ph as lt,
    q as De,
    qb as Je,
    r as Ve,
    rd as tt,
    sb as Ke,
    t as Fe,
    te as ot,
    u as Ne,
    ue as rt,
    ve as st,
    we as at,
    xd as nt,
    xe as ct,
    yd as it,
    ye as dt,
    z as ze
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    Ab as ee,
    Eb as te,
    Ec as we,
    Fa as o,
    Fb as U,
    H,
    Hb as ye,
    Ib as c,
    Jb as u,
    Kb as k,
    Kg as Ae,
    Lb as O,
    Mb as ne,
    Na as S,
    Oa as K,
    Pb as Pe,
    Qb as Oe,
    Ra as R,
    Rb as Se,
    Sa as $,
    Tc as Te,
    _a as h,
    _b as L,
    aa as Ce,
    ac as ie,
    ba as J,
    bc as ke,
    cb as N,
    da as be,
    db as z,
    ea as C,
    eb as p,
    fb as i,
    ff as me,
    gb as r,
    ha as x,
    hb as d,
    ia as v,
    lb as ve,
    mb as Me,
    n as T,
    na as I,
    oa as F,
    q as _e,
    qb as P,
    sa as xe,
    sb as M,
    sd as Le,
    t as G,
    ta as A,
    ti as Re,
    ub as m,
    ui as qe,
    vd as pe,
    xk as y,
    yb as X,
    zb as Z
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as Q,
    b as Y,
    i as he
} from "./chunk-FBFWB55K.js";
var V = class {};
var Tt = (n, l) => l.businessType.id;

function Et(n, l) {
    if (n & 1 && (i(0, "div", 10), d(1, "dx-load-indicator", 11), i(2, "p", 12), c(3), r()()), n & 2) {
        let e = m();
        o(), p("visible", !0), o(2), k("", e.formatMessage("loading"), "...")
    }
}

function It(n, l) {
    if (n & 1 && (i(0, "div", 26)(1, "div", 49)(2, "div", 50), d(3, "i", 51), r(), i(4, "div", 52)(5, "span", 53), c(6), r(), i(7, "span", 54), c(8), r()()()()), n & 2) {
        let e = m(2);
        o(6), u(e.formatMessage("register_business_name")), o(2), u(e.businessName)
    }
}

function Bt(n, l) {
    if (n & 1 && (i(0, "div", 26)(1, "div", 49)(2, "div", 50), d(3, "i", 55), r(), i(4, "div", 52)(5, "span", 53), c(6), r(), i(7, "span", 54), c(8), r()()()()), n & 2) {
        let e = m(2);
        o(6), u(e.formatMessage("email")), o(2), u(e.businessEmail)
    }
}

function Dt(n, l) {
    if (n & 1 && (i(0, "div", 26)(1, "div", 49)(2, "div", 50), d(3, "i", 56), r(), i(4, "div", 52)(5, "span", 53), c(6), r(), i(7, "span", 54), c(8), r()()()()), n & 2) {
        let e = m(2);
        o(6), u(e.formatMessage("common_phone")), o(2), u(e.businessPhone)
    }
}

function Vt(n, l) {
    if (n & 1 && (i(0, "div", 26)(1, "div", 49)(2, "div", 50), d(3, "i", 57), r(), i(4, "div", 52)(5, "span", 53), c(6), r(), i(7, "span", 54), c(8), r()()()()), n & 2) {
        let e = m(2);
        o(6), u(e.formatMessage("common_website")), o(2), u(e.businessWebsite)
    }
}

function Ft(n, l) {
    if (n & 1 && (i(0, "div", 59)(1, "div", 60), d(2, "i", 61), r(), i(3, "div", 62)(4, "span", 63), c(5), r(), i(6, "div", 64)(7, "div", 65), d(8, "i", 66), c(9), r(), i(10, "div", 65), d(11, "i", 67), c(12), r(), i(13, "div", 65), d(14, "i", 68), c(15), r()()(), i(16, "div", 69), d(17, "i", 70), r()()), n & 2) {
        let e = l.$implicit,
            t = m(3);
        o(5), u(e.businessType.name), o(4), O(" ", e.deviceTypeCount, " ", t.formatMessage("types"), " "), o(3), O(" ", e.brandCount, " ", t.formatMessage("brands"), " "), o(3), O(" ", e.modelCount, " ", t.formatMessage("models"), " ")
    }
}

function Nt(n, l) {
    if (n & 1 && (i(0, "div", 21)(1, "div", 22), d(2, "i", 58), i(3, "span", 24), c(4), r()(), N(5, Ft, 18, 7, "div", 59, Tt), r()), n & 2) {
        let e = m(2);
        o(4), u(e.formatMessage("BUSINESS_TYPE")), o(), z(e.businessTypeSummaries)
    }
}

function zt(n, l) {
    if (n & 1 && (i(0, "div", 27)(1, "div", 22), d(2, "i", 71), i(3, "span", 24), c(4), r()(), i(5, "div", 25)(6, "div", 72)(7, "div", 73)(8, "div", 74), c(9), r(), i(10, "div", 75), c(11), r()()(), i(12, "div", 72)(13, "div", 76)(14, "div", 74), c(15), r(), i(16, "div", 75), c(17), r()()(), i(18, "div", 72)(19, "div", 77)(20, "div", 74), c(21), r(), i(22, "div", 75), c(23), r()()(), i(24, "div", 72)(25, "div", 78)(26, "div", 79), d(27, "i", 80), r(), i(28, "div", 75), c(29), r()()()()()), n & 2) {
        let e = m(2);
        o(4), u(e.formatMessage("device_configuration")), o(5), u(e.totalDeviceTypes), o(2), u(e.formatMessage("types")), o(4), u(e.totalBrands), o(2), u(e.formatMessage("brands")), o(4), u(e.selectedDeviceCount), o(2), u(e.formatMessage("models")), o(6), u(e.formatMessage("launch"))
    }
}

function Lt(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "div", 13)(1, "div", 14)(2, "div", 15)(3, "div", 16), d(4, "i", 17), r(), i(5, "div")(6, "h5", 18), c(7), r(), i(8, "small", 19), c(9), r()()()(), i(10, "div", 20)(11, "div", 21)(12, "div", 22), d(13, "i", 23), i(14, "span", 24), c(15), r()(), i(16, "div", 25), h(17, It, 9, 2, "div", 26), h(18, Bt, 9, 2, "div", 26), h(19, Dt, 9, 2, "div", 26), h(20, Vt, 9, 2, "div", 26), r()(), h(21, Nt, 7, 1, "div", 21), h(22, zt, 30, 8, "div", 27), r()(), i(23, "div", 28)(24, "div", 29)(25, "div", 30)(26, "div", 31)(27, "div", 32), d(28, "i", 33), r(), i(29, "h6", 34), c(30), r()(), i(31, "p", 35), c(32, "Follow us on social media for updates and tips"), r(), i(33, "div", 36)(34, "a", 37), d(35, "i", 38), r(), i(36, "a", 39), d(37, "i", 40), r(), i(38, "a", 41), d(39, "i", 42), r(), i(40, "a", 43), d(41, "i", 44), r()()()()(), i(42, "div", 45)(43, "button", 46), M("click", function() {
            x(e);
            let s = m();
            return v(s.getStarted())
        }), c(44), d(45, "i", 47), r(), i(46, "p", 48), c(47), r()()
    }
    if (n & 2) {
        let e = m();
        o(7), u(e.formatMessage("setup_summary")), o(2), u(e.formatMessage("setup_complete_description")), o(6), u(e.formatMessage("business_information")), o(2), _(e.businessName ? 17 : -1), o(), _(e.businessEmail ? 18 : -1), o(), _(e.businessPhone ? 19 : -1), o(), _(e.businessWebsite ? 20 : -1), o(), _(e.businessTypeSummaries.length > 0 ? 21 : -1), o(), _(e.setupSummary ? 22 : -1), o(8), u(e.formatMessage("stay_connected_heading")), o(14), k(" ", e.formatMessage("get_started"), " "), o(3), k(" ", e.formatMessage("customize_settings_hint"), " ")
    }
}
var _t = (() => {
    class n extends V {
        constructor() {
            super(...arguments), this.formatMessage = y, this.destroyRef = C(I), this.router = C(Le), this.toastNotificationService = C(D), this.accountService = C(oe), this.configService = C($e), this.isMobileDevice = C(B).isMobileDevice(), this.account = null, this.setupSummary = null, this.isLoading = !0
        }
        ngOnInit() {
            this.loadSummaryData()
        }
        loadSummaryData() {
            this.isLoading = !0, this.loadSetupSummary(), this.loadAccountData()
        }
        loadSetupSummary() {
            let e = localStorage.getItem("setupSummary");
            if (e) try {
                this.setupSummary = JSON.parse(e)
            } catch (t) {
                this.setupSummary = null
            }
        }
        loadAccountData() {
            this.accountService.getTenant().pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.account = e, this.isLoading = !1
                },
                error: () => {
                    this.toastNotificationService.error("notification_account_fetch_error"), this.isLoading = !1
                }
            })
        }
        submit() {
            return T(!0)
        }
        getStarted() {
            this.accountService.completeSetupWizard().pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.configService.updateAppConfig({
                        is_completed_wizard_setup: !0
                    }), this.cleanupLocalStorage(), this.toastNotificationService.success("notification_business_setup_success"), localStorage.setItem("pendingWelcomeTour", "1"), this.router.navigate(["/jobs"]).then(() => {
                        window.location.reload()
                    })
                },
                error: () => {
                    this.toastNotificationService.error("notification_business_setup_failed")
                }
            })
        }
        cleanupLocalStorage() {
            localStorage.removeItem("setupSummary"), localStorage.removeItem("selectedBusinessTypeId"), localStorage.removeItem("selectedBusinessType")
        }
        get businessName() {
            return this.account ? .name || ""
        }
        get businessEmail() {
            return this.account ? .email || ""
        }
        get businessPhone() {
            return this.account ? .support_number || ""
        }
        get businessWebsite() {
            return this.account ? .website || ""
        }
        get selectedDeviceCount() {
            return this.setupSummary ? .totalModels || 0
        }
        get totalDeviceTypes() {
            return this.setupSummary ? .totalDeviceTypes || 0
        }
        get totalBrands() {
            return this.setupSummary ? .totalBrands || 0
        }
        get totalBusinessTypesCount() {
            return this.setupSummary ? .totalBusinessTypes || 0
        }
        get businessTypeNames() {
            return this.setupSummary ? .businessTypes ? .map(e => e.businessType.name).join(", ") || ""
        }
        get businessTypeSummaries() {
            return this.setupSummary ? .businessTypes || []
        }
        static {
            this.\u0275fac = (() => {
                let e;
                return function(s) {
                    return (e || (e = A(n)))(s || n)
                }
            })()
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-step-final"]
                ],
                standalone: !1,
                features: [R],
                decls: 14,
                vars: 4,
                consts: [
                    [1, "container-fluid", "py-4"],
                    [1, "row", "justify-content-center"],
                    [1, "col-12", "col-lg-10", "col-xl-8"],
                    [1, "text-center", "mb-4"],
                    [1, "success-icon-container", "mb-3"],
                    [1, "success-icon-ring"],
                    [1, "success-icon-inner"],
                    [1, "fa-solid", "fa-check"],
                    [1, "fw-bold", "mb-2"],
                    [1, "text-muted", "mb-0"],
                    [1, "text-center", "py-5"],
                    [3, "visible"],
                    [1, "mt-3", "text-muted"],
                    [1, "card", "summary-card", "mb-4"],
                    [1, "card-header"],
                    [1, "d-flex", "align-items-center"],
                    [1, "header-icon-wrapper", "me-3"],
                    [1, "fa-solid", "fa-clipboard-check"],
                    [1, "mb-0", "fw-semibold"],
                    [1, "text-muted"],
                    [1, "card-body"],
                    [1, "info-section", "mb-4"],
                    [1, "section-header", "mb-3"],
                    [1, "fa-solid", "fa-building", "section-icon"],
                    [1, "section-title"],
                    [1, "row", "g-3"],
                    [1, "col-12", "col-md-6"],
                    [1, "info-section"],
                    [1, "row", "g-4", "mb-4"],
                    [1, "col-12"],
                    [1, "quick-link-card", "h-100"],
                    [1, "quick-link-header"],
                    [1, "quick-link-icon", "social-icon"],
                    [1, "fa-solid", "fa-share-nodes"],
                    [1, "quick-link-title"],
                    [1, "quick-link-description"],
                    [1, "social-links"],
                    ["href", "https://www.youtube.com/c/bytephase", "target", "_blank", 1, "social-link", "youtube"],
                    [1, "fa-brands", "fa-youtube"],
                    ["href", "https://www.instagram.com/bytephase/", "target", "_blank", 1, "social-link", "instagram"],
                    [1, "fa-brands", "fa-instagram"],
                    ["href", "https://www.facebook.com/bytephase", "target", "_blank", 1, "social-link", "facebook"],
                    [1, "fa-brands", "fa-facebook"],
                    ["href", "https://twitter.com/bytephase", "target", "_blank", 1, "social-link", "twitter"],
                    [1, "fa-brands", "fa-twitter"],
                    [1, "text-center", "get-started-section"],
                    ["type", "button", 1, "btn", "btn-primary", "btn-lg", "get-started-btn", 3, "click"],
                    [1, "fa-solid", "fa-arrow-right", "ms-2"],
                    [1, "text-muted", "small", "mt-3"],
                    [1, "info-card"],
                    [1, "info-card-icon"],
                    [1, "fa-solid", "fa-building"],
                    [1, "info-card-content"],
                    [1, "info-label"],
                    [1, "info-value"],
                    [1, "fa-solid", "fa-envelope"],
                    [1, "fa-solid", "fa-phone"],
                    [1, "fa-solid", "fa-globe"],
                    [1, "fa-solid", "fa-briefcase", "section-icon"],
                    [1, "business-type-card", "mb-2"],
                    [1, "business-type-icon"],
                    [1, "fa-solid", "fa-briefcase"],
                    [1, "business-type-content"],
                    [1, "business-type-name"],
                    [1, "d-flex", "flex-wrap", "gap-2"],
                    [1, "business-type-badge"],
                    [1, "fa-solid", "fa-microchip", "me-1"],
                    [1, "fa-solid", "fa-copyright", "me-1"],
                    [1, "fa-solid", "fa-laptop", "me-1"],
                    [1, "business-type-check"],
                    [1, "fa-solid", "fa-circle-check"],
                    [1, "fa-solid", "fa-chart-bar", "section-icon"],
                    [1, "col-6", "col-md-3"],
                    [1, "stat-card", "stat-primary"],
                    [1, "stat-value"],
                    [1, "stat-label"],
                    [1, "stat-card", "stat-secondary"],
                    [1, "stat-card", "stat-success"],
                    [1, "stat-card", "stat-info"],
                    [1, "stat-icon"],
                    [1, "fa-solid", "fa-rocket"]
                ],
                template: function(t, s) {
                    t & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4), d(5, "div", 5), i(6, "div", 6), d(7, "i", 7), r()(), i(8, "h3", 8), c(9), r(), i(10, "p", 9), c(11), r()(), h(12, Et, 4, 2, "div", 10), h(13, Lt, 48, 12), r()()()), t & 2 && (o(9), u(s.formatMessage("setup_complete_title")), o(2), k(" ", s.formatMessage("setup_complete_description"), " "), o(), _(s.isLoading ? 12 : -1), o(), _(s.isLoading ? -1 : 13))
                },
                dependencies: [ce],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   i[_ngcontent-%COMP%]{-webkit-text-stroke:unset!important}.success-icon-container[_ngcontent-%COMP%]{position:relative;width:90px;height:90px;margin:0 auto}.success-icon-ring[_ngcontent-%COMP%]{position:absolute;inset:0;border-radius:50%;border:3px solid rgba(34,197,94,.3);animation:_ngcontent-%COMP%_pulse-ring 2s ease-out infinite}.success-icon-inner[_ngcontent-%COMP%]{position:absolute;inset:8px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#22c55e,#16a34a);border-radius:50%;box-shadow:0 8px 24px #22c55e59}.success-icon-inner[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:2.25rem;color:#fff}@keyframes _ngcontent-%COMP%_pulse-ring{0%{transform:scale(1);opacity:1}to{transform:scale(1.3);opacity:0}}.summary-card[_ngcontent-%COMP%]{border:none;border-radius:16px;box-shadow:0 4px 24px #00000014;overflow:hidden}.summary-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]{background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-bottom:1px solid var(--theme-border-color);padding:1.25rem 1.5rem}.summary-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]{padding:1.5rem}.header-icon-wrapper[_ngcontent-%COMP%]{width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#3b82f6,#2563eb);border-radius:12px;box-shadow:0 4px 12px #3b82f64d}.header-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem;color:#fff}.info-section[_ngcontent-%COMP%]{padding-bottom:1.5rem;border-bottom:1px solid var(--theme-border-color)}.info-section[_ngcontent-%COMP%]:last-child{padding-bottom:0;border-bottom:none}.section-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem}.section-icon[_ngcontent-%COMP%]{width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;background:#3b82f61a;border-radius:8px;color:#3b82f6;font-size:.875rem}.section-title[_ngcontent-%COMP%]{font-size:1rem;font-weight:600;color:#3b82f6}.info-card[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.875rem;padding:1rem;background:#f8fafc;border:1px solid var(--theme-border-color);border-radius:12px;transition:all .2s ease}.info-card[_ngcontent-%COMP%]:hover{background:#f1f5f9;border-color:#cbd5e1}.info-card-icon[_ngcontent-%COMP%]{width:40px;height:40px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid var(--theme-border-color);border-radius:10px;color:#64748b;font-size:1rem;flex-shrink:0}.info-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0}.info-label[_ngcontent-%COMP%]{font-size:.75rem;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.125rem}.info-value[_ngcontent-%COMP%]{font-size:.9375rem;font-weight:500;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.business-type-card[_ngcontent-%COMP%]{display:flex;align-items:center;gap:1rem;padding:1.25rem;background:linear-gradient(135deg,#3b82f614,#3b82f60a);border:1px solid rgba(59,130,246,.2);border-radius:14px}.business-type-icon[_ngcontent-%COMP%]{width:52px;height:52px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#3b82f6,#2563eb);border-radius:12px;box-shadow:0 4px 12px #3b82f640;flex-shrink:0}.business-type-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem;color:#fff}.business-type-content[_ngcontent-%COMP%]{flex:1;min-width:0}.business-type-name[_ngcontent-%COMP%]{display:block;font-size:1.0625rem;font-weight:600;color:#1e293b;margin-bottom:.375rem}.business-type-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;padding:.375rem .75rem;background:#3b82f61f;border-radius:20px;font-size:.8125rem;font-weight:500;color:#3b82f6}.business-type-check[_ngcontent-%COMP%]{width:36px;height:36px;display:flex;align-items:center;justify-content:center;flex-shrink:0}.business-type-check[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.5rem;color:#22c55e}.stat-card[_ngcontent-%COMP%]{text-align:center;padding:1.25rem 1rem;border-radius:12px;border:1px solid var(--theme-border-color);background:#fff;transition:all .2s ease}.stat-card[_ngcontent-%COMP%]:hover{transform:translateY(-2px);box-shadow:0 4px 12px #00000014}.stat-value[_ngcontent-%COMP%]{font-size:1.75rem;font-weight:700;line-height:1.2;margin-bottom:.375rem}.stat-icon[_ngcontent-%COMP%]{font-size:1.5rem;margin-bottom:.375rem}.stat-label[_ngcontent-%COMP%]{font-size:.8125rem;color:#64748b;text-transform:uppercase;letter-spacing:.5px}.stat-primary[_ngcontent-%COMP%]{border-color:#3b82f633;background:#3b82f60a}.stat-primary[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#3b82f6}.stat-secondary[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#64748b}.stat-success[_ngcontent-%COMP%]{border-color:#22c55e33;background:#22c55e0a}.stat-success[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%]{color:#22c55e}.stat-info[_ngcontent-%COMP%]{border-color:#0ea5e933;background:#0ea5e90a}.stat-info[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%]{color:#0ea5e9}.quick-link-card[_ngcontent-%COMP%]{padding:1.5rem;background:#fff;border:1px solid var(--theme-border-color);border-radius:16px;box-shadow:0 2px 8px #0000000a;transition:all .2s ease}.quick-link-card[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #00000014}.quick-link-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.875rem;margin-bottom:.75rem}.quick-link-icon[_ngcontent-%COMP%]{width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:12px;font-size:1.125rem}.quick-link-icon.social-icon[_ngcontent-%COMP%]{background:linear-gradient(135deg,#8b5cf6,#7c3aed);color:#fff;box-shadow:0 4px 12px #8b5cf64d}.quick-link-icon.support-icon[_ngcontent-%COMP%]{background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;box-shadow:0 4px 12px #f973164d}.quick-link-title[_ngcontent-%COMP%]{font-size:1rem;font-weight:600;color:#1e293b;margin:0}.quick-link-description[_ngcontent-%COMP%]{font-size:.875rem;color:#64748b;margin-bottom:1rem;line-height:1.5}.social-links[_ngcontent-%COMP%]{display:flex;gap:.75rem}.social-link[_ngcontent-%COMP%]{width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:12px;font-size:1.25rem;text-decoration:none;transition:all .2s ease}.social-link.youtube[_ngcontent-%COMP%]{background:#ff00001a;color:red}.social-link.youtube[_ngcontent-%COMP%]:hover{background:red;color:#fff;transform:translateY(-3px);box-shadow:0 6px 16px #ff00004d}.social-link.instagram[_ngcontent-%COMP%]{background:#e4405f1a;color:#e4405f}.social-link.instagram[_ngcontent-%COMP%]:hover{background:linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);color:#fff;transform:translateY(-3px);box-shadow:0 6px 16px #e4405f4d}.social-link.facebook[_ngcontent-%COMP%]{background:#1877f21a;color:#1877f2}.social-link.facebook[_ngcontent-%COMP%]:hover{background:#1877f2;color:#fff;transform:translateY(-3px);box-shadow:0 6px 16px #1877f24d}.social-link.twitter[_ngcontent-%COMP%]{background:#1da1f21a;color:#1da1f2}.social-link.twitter[_ngcontent-%COMP%]:hover{background:#1da1f2;color:#fff;transform:translateY(-3px);box-shadow:0 6px 16px #1da1f24d}.get-started-section[_ngcontent-%COMP%]{padding-top:.5rem}.get-started-btn[_ngcontent-%COMP%]{padding:1rem 3rem;border-radius:12px;font-size:1.0625rem;font-weight:600;background:linear-gradient(135deg,#3b82f6,#2563eb);border:none;box-shadow:0 8px 24px #3b82f659;transition:all .3s ease}.get-started-btn[_ngcontent-%COMP%]:hover{transform:translateY(-3px);box-shadow:0 12px 32px #3b82f673;background:linear-gradient(135deg,#2563eb,#1d4ed8)}.get-started-btn[_ngcontent-%COMP%]:active{transform:translateY(-1px)}.dark-theme[_nghost-%COMP%]   h3[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   h3[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   h5[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   h5[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .success-icon-ring[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-icon-ring[_ngcontent-%COMP%]{border-color:#22c55e66}.dark-theme[_nghost-%COMP%]   .success-icon-inner[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-icon-inner[_ngcontent-%COMP%]{box-shadow:0 8px 24px #22c55e40}.dark-theme[_nghost-%COMP%]   .summary-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .summary-card[_ngcontent-%COMP%]{background-color:#10172a;border:1px solid #2d3748;box-shadow:0 4px 24px #0000004d}.dark-theme[_nghost-%COMP%]   .summary-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .summary-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]{background:linear-gradient(135deg,#1e293b,#10172a);border-bottom-color:#2d3748}.dark-theme[_nghost-%COMP%]   .summary-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   small[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .summary-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#94a3b8!important}.dark-theme[_nghost-%COMP%]   .header-icon-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .header-icon-wrapper[_ngcontent-%COMP%]{box-shadow:0 4px 12px #3b82f633}.dark-theme[_nghost-%COMP%]   .section-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-icon[_ngcontent-%COMP%]{background:#60a5fa26;color:#60a5fa}.dark-theme[_nghost-%COMP%]   .section-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .info-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-card[_ngcontent-%COMP%]{background:#1e293b}.dark-theme[_nghost-%COMP%]   .info-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .info-card[_ngcontent-%COMP%]:hover{background:#1e293bcc;border-color:#3d4f66}.dark-theme[_nghost-%COMP%]   .info-card-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-card-icon[_ngcontent-%COMP%]{background:#10172a;color:#94a3b8}.dark-theme[_nghost-%COMP%]   .info-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-label[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .info-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-value[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .business-type-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-card[_ngcontent-%COMP%]{background:linear-gradient(135deg,#60a5fa1a,#60a5fa0d);border-color:#60a5fa40}.dark-theme[_nghost-%COMP%]   .business-type-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-icon[_ngcontent-%COMP%]{box-shadow:0 4px 12px #3b82f633}.dark-theme[_nghost-%COMP%]   .business-type-name[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-name[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .business-type-badge[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-badge[_ngcontent-%COMP%]{background:#60a5fa26;color:#60a5fa}.dark-theme[_nghost-%COMP%]   .business-type-check[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-check[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#4ade80}.dark-theme[_nghost-%COMP%]   .stat-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card[_ngcontent-%COMP%]{background:#1e293b}.dark-theme[_nghost-%COMP%]   .stat-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .stat-card[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #0000004d}.dark-theme[_nghost-%COMP%]   .stat-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .stat-primary[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-primary[_ngcontent-%COMP%]{background:#60a5fa14;border-color:#60a5fa33}.dark-theme[_nghost-%COMP%]   .stat-primary[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-primary[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .stat-secondary[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-secondary[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .stat-success[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-success[_ngcontent-%COMP%]{background:#4ade8014;border-color:#4ade8033}.dark-theme[_nghost-%COMP%]   .stat-success[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-success[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%]{color:#4ade80}.dark-theme[_nghost-%COMP%]   .stat-info[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-info[_ngcontent-%COMP%]{background:#38bdf814;border-color:#38bdf833}.dark-theme[_nghost-%COMP%]   .stat-info[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-info[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%]{color:#38bdf8}.dark-theme[_nghost-%COMP%]   .quick-link-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-link-card[_ngcontent-%COMP%]{background:#1e293b;box-shadow:0 2px 8px #0003}.dark-theme[_nghost-%COMP%]   .quick-link-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .quick-link-card[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #0000004d}.dark-theme[_nghost-%COMP%]   .quick-link-icon.social-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-link-icon.social-icon[_ngcontent-%COMP%]{box-shadow:0 4px 12px #8b5cf633}.dark-theme[_nghost-%COMP%]   .quick-link-icon.support-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-link-icon.support-icon[_ngcontent-%COMP%]{box-shadow:0 4px 12px #f9731633}.dark-theme[_nghost-%COMP%]   .quick-link-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-link-title[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .quick-link-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-link-description[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .social-link.youtube[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .social-link.youtube[_ngcontent-%COMP%]{background:#ff000026}.dark-theme[_nghost-%COMP%]   .social-link.instagram[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .social-link.instagram[_ngcontent-%COMP%]{background:#e4405f26}.dark-theme[_nghost-%COMP%]   .social-link.facebook[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .social-link.facebook[_ngcontent-%COMP%]{background:#1877f226}.dark-theme[_nghost-%COMP%]   .social-link.twitter[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .social-link.twitter[_ngcontent-%COMP%]{background:#1da1f226}.dark-theme[_nghost-%COMP%]   .btn-outline-primary[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .btn-outline-primary[_ngcontent-%COMP%]{color:#60a5fa;border-color:#3b82f6;background-color:transparent}.dark-theme[_nghost-%COMP%]   .btn-outline-primary[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .btn-outline-primary[_ngcontent-%COMP%]:hover{background-color:#3b82f626;color:#93c5fd;border-color:#60a5fa}.dark-theme[_nghost-%COMP%]   .get-started-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .get-started-btn[_ngcontent-%COMP%]{box-shadow:0 8px 24px #3b82f640}.dark-theme[_nghost-%COMP%]   .get-started-btn[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .get-started-btn[_ngcontent-%COMP%]:hover{box-shadow:0 12px 32px #3b82f659}.dark-theme[_nghost-%COMP%]   .dx-loadindicator[_ngcontent-%COMP%]   .dx-loadindicator-segment[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .dx-loadindicator[_ngcontent-%COMP%]   .dx-loadindicator-segment[_ngcontent-%COMP%]{background-color:#60a5fa}"]
            })
        }
    }
    return n
})();
var $t = () => ({
        autocomplete: "new-country"
    }),
    Ut = () => ({
        autocomplete: "new-currency"
    }),
    Wt = () => ({
        autocomplete: "new-state"
    }),
    Qt = () => ({
        autocomplete: "new-city"
    });

function Yt(n, l) {
    n & 1 && d(0, "app-skeleton-loader", 4), n & 2 && p("rows", 6)("columns", 3)
}

function Gt(n, l) {
    if (n & 1 && (i(0, "div", 70)(1, "div", 71)(2, "span", 72), c(3), r(), i(4, "span", 73), c(5), r()(), i(6, "div", 74), c(7), r()()), n & 2) {
        let e = l.$implicit;
        o(3), u(e.format), o(2), u(e.countryName), o(2), u(e.example)
    }
}

function Ht(n, l) {
    if (n & 1 && d(0, "dxi-button", 64), n & 2) {
        let e = m(2);
        p("options", e.addStateButton)
    }
}

function Jt(n, l) {
    if (n & 1 && d(0, "dxi-button", 68), n & 2) {
        let e = m(2);
        p("options", e.addCityButton)
    }
}

function Kt(n, l) {
    if (n & 1 && d(0, "app-server-error", 69), n & 2) {
        let e = m(2);
        p("errorResponse", e.errorResponse)
    }
}

function Xt(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "form", 5)(1, "div", 8)(2, "div", 9)(3, "div", 10)(4, "div", 11), d(5, "i", 12), r(), i(6, "h4", 13), c(7), r()(), i(8, "div", 14)(9, "div", 15)(10, "div", 16)(11, "div", 17), d(12, "i", 18), r(), i(13, "h6", 19), c(14), r()(), d(15, "hr", 20), r(), i(16, "div", 21)(17, "app-control-container", 22)(18, "div", 23), d(19, "i", 24)(20, "dx-text-box", 25), r()(), i(21, "app-control-container", 26)(22, "div", 23), d(23, "i", 27)(24, "app-email", 28), r()(), i(25, "app-control-container", 29)(26, "div", 23), d(27, "i", 30)(28, "app-email", 31), r()(), i(29, "app-control-container", 32)(30, "div", 23), d(31, "i", 33)(32, "app-phone-number", 31), r()(), i(33, "app-control-container", 34), d(34, "app-mobile-number", 35), r(), i(35, "app-control-container", 36)(36, "div", 23), d(37, "i", 37)(38, "dx-text-box", 38), r(), d(39, "app-error", 39), r(), i(40, "app-control-container", 40)(41, "div", 23), d(42, "i", 41)(43, "dx-text-box", 42), r()()()()()(), i(44, "div", 8)(45, "div", 9)(46, "div", 14)(47, "div", 15)(48, "div", 16)(49, "div", 17), d(50, "i", 43), r(), i(51, "h6", 19), c(52), r()(), d(53, "hr", 20), r(), i(54, "div", 21)(55, "app-control-container", 44)(56, "div", 23), d(57, "i", 45), i(58, "dx-select-box", 46), M("onSelectionChanged", function(s) {
            x(e);
            let a = m();
            return v(a.getStateListFromCountryList(s))
        }), r()()(), i(59, "app-control-container", 47)(60, "div", 23), d(61, "i", 48)(62, "dx-select-box", 49), r()(), i(63, "app-control-container", 50)(64, "div", 23), d(65, "i", 51), i(66, "dx-select-box", 52), $(67, Gt, 8, 3, "div", 53), r()()(), i(68, "app-control-container", 54)(69, "div", 23), d(70, "i", 55)(71, "dx-select-box", 56), r()(), i(72, "app-control-container", 57)(73, "div", 23), d(74, "i", 58), i(75, "dx-select-box", 59), M("onValueChanged", function(s) {
            x(e);
            let a = m();
            return v(a.changeLocale(s))
        }), r()()(), ve(76, 60), i(77, "app-control-container", 61)(78, "div", 23), d(79, "i", 62), i(80, "dx-select-box", 63), M("onSelectionChanged", function(s) {
            x(e);
            let a = m();
            return v(a.getCityListFromStateList(s))
        }), h(81, Ht, 1, 1, "dxi-button", 64), r()()(), i(82, "app-control-container", 65)(83, "div", 23), d(84, "i", 66), i(85, "dx-select-box", 67), h(86, Jt, 1, 1, "dxi-button", 68), r()()(), Me(), r()()()(), h(87, Kt, 1, 1, "app-server-error", 69), r()
    }
    if (n & 2) {
        let e, t = m();
        p("formGroup", t.form), o(7), u(t.formatMessage("business_information")), o(7), u(t.formatMessage("basic_business_information")), o(3), p("errorMsg", t.formatMessage("register_business_name_required"))("label", t.formatMessage("register_business_name")), o(3), p("placeholder", t.formatMessage("register_business_name"))("stylingMode", "outlined"), o(), p("errorMsg", t.formatMessage("account_email_required"))("label", t.formatMessage("account_email_label"))("tooltipText", "account_email"), o(3), p("formControl", t.form.controls.email)("isEditMode", !0), o(), p("errorMsg", t.formatMessage("accounts_support_email_required"))("label", t.formatMessage("accounts_support_email"))("tooltipText", "account_support_email"), o(3), p("formControl", t.form.controls.support_email), o(), p("errorMsg", t.formatMessage("accounts_support_number_required"))("label", t.formatMessage("accounts_support_number"))("tooltipText", "account_support_number"), o(3), p("formControl", t.form.controls.support_number), o(), p("errorMsg", t.formatMessage("accounts_whats_app_number_required"))("label", t.formatMessage("accounts_whats_app_number"))("tooltipText", "account_whats_app_number"), o(), p("formControl", t.form.controls.whats_app_number)("countryId", t.selectedCountryId), o(), p("errorMsg", t.formatMessage("accounts_website_required"))("label", t.formatMessage("accounts_website"))("tooltipText", "account_website"), o(3), p("stylingMode", "outlined"), o(), p("displayError", t.form.get("website").invalid && t.form.get("website").touched && ((e = t.form.get("website").errors) == null ? null : e.invalidUrl))("errorMsg", t.formatMessage("accounts_invalid_website")), o(), p("errorMsg", t.formatMessage("accounts_gst_number_required"))("label", t.formatMessage("common_tax_number")), o(3), p("placeholder", t.formatMessage("user_customer_tax_number_type"))("stylingMode", "outlined"), o(9), u(t.formatMessage("account_region_currency")), o(3), p("errorMsg", t.formatMessage("register_country_required"))("label", t.formatMessage("register_country")), o(3), p("inputAttr", L(95, $t))("items", t.countryList)("placeholder", t.formatMessage("register_select_country"))("searchEnabled", !0)("showClearButton", t.isEditMode)("stylingMode", "outlined"), o(), p("errorMsg", t.formatMessage("accounts_currency_required"))("label", t.formatMessage("accounts_currency_code")), o(3), p("inputAttr", L(96, Ut))("items", t.countryList)("placeholder", t.formatMessage("select_currency"))("searchEnabled", !0)("showClearButton", t.isEditMode)("stylingMode", "outlined"), o(), p("errorMsg", t.formatMessage("accounts_date_time_format_required"))("label", t.formatMessage("accounts_date_time_format")), o(3), p("items", t.dateTimeFormatList)("placeholder", t.formatMessage("select_date_time_format"))("searchEnabled", !0)("showClearButton", t.isEditMode)("stylingMode", "outlined"), o(), p("dxTemplateOf", "item"), o(), p("errorMsg", t.formatMessage("accounts_timezone_required"))("label", t.formatMessage("accounts_timezone")), o(3), p("items", t.timezoneList)("placeholder", t.formatMessage("select_timezone"))("searchEnabled", !0)("showClearButton", t.isEditMode)("stylingMode", "outlined"), o(), p("errorMsg", t.formatMessage("accounts_locale_required"))("label", t.formatMessage("accounts_locale")), o(3), p("items", t.locales)("placeholder", t.formatMessage("select_language"))("searchEnabled", !0)("showClearButton", t.isEditMode)("stylingMode", "outlined"), o(2), p("errorMsg", t.formatMessage("state_required_field"))("label", t.formatMessage("state")), o(3), p("inputAttr", L(97, Wt))("items", t.stateList)("placeholder", t.formatMessage("common_select_state"))("searchEnabled", !0)("showClearButton", t.isEditMode)("showDropDownButton", !0)("stylingMode", "outlined"), o(), _(!t.form.disabled && !t.isIndiaSelected ? 81 : -1), o(), p("errorMsg", t.formatMessage("city_required_field"))("label", t.formatMessage("common_city")), o(3), p("inputAttr", L(98, Qt))("items", t.cityList)("placeholder", t.formatMessage("common_select_city"))("searchEnabled", !0)("showClearButton", t.isEditMode)("showDropDownButton", !0)("stylingMode", "outlined"), o(), _(!t.form.disabled && !t.isIndiaSelected ? 86 : -1), o(), _(t.errorResponse ? 87 : -1)
    }
}

function Zt(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "app-add-state-popup", 75), M("stateCancelClick", function() {
            x(e);
            let s = m();
            return v(s.isVisibleAddStatePopup = !1)
        })("stateSaveClick", function(s) {
            x(e);
            let a = m();
            return v(a.onAddState(s))
        }), r()
    }
    if (n & 2) {
        let e = m();
        p("isVisiblePopup", e.isVisibleAddStatePopup)
    }
}

function en(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "app-add-city-popup", 76), M("cityCancelClick", function() {
            x(e);
            let s = m();
            return v(s.isVisibleAddCityPopup = !1)
        })("citySaveClick", function(s) {
            x(e);
            let a = m();
            return v(a.onAddCity(s))
        }), r()
    }
    if (n & 2) {
        let e = m();
        p("isVisiblePopup", e.isVisibleAddCityPopup)("stateId", e.currentSelectedState == null ? null : e.currentSelectedState.id)
    }
}
var Ct = (() => {
    class n extends V {
        constructor() {
            super(...arguments), this.formatMessage = y, this.destroyRef = C(I), this.formService = C(He), this.localizationService = C(je), this.tenantService = C(ae), this.toastNotificationService = C(D), this.service = C(oe), this.cityService = C(nt), this.stateService = C(it), this.countryService = C(st), this.timezoneService = C(gt), this.isMobileDevice = C(B).isMobileDevice(), this.errorResponse = null, this.countryList = [], this.stateList = [], this.cityList = [], this.timezoneList = [], this.locales = [], this.dateTimeFormatList = Ae, this.isEditMode = !0, this.isVisibleAddStatePopup = !1, this.isVisibleAddCityPopup = !1, this.isIndiaSelected = !1, this.selectedCountryId = null
        }
        ngOnInit() {
            this.locales = this.localizationService.locales, this.getTimezones(), this.getCountries(), this.loadTenant(), this.initButtonConfigs()
        }
        loadTenant() {
            this.service.getTenant().pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.account = e, this.form = ue.getForm(new ue(this.account)), this.form.enable(), this.selectedCountryId = this.account.country_id, this.isIndiaSelected = this.account.country_id === 101, this.validateTimezoneValue()
                },
                error: () => {
                    this.toastNotificationService.error("notification_tenant_fetch_error")
                }
            })
        }
        initButtonConfigs() {
            this.addStateButton = {
                icon: "add",
                type: "default",
                hint: y("add_new_state"),
                onClick: () => {
                    this.isVisibleAddStatePopup = !0
                }
            }, this.addCityButton = {
                icon: "add",
                type: "default",
                hint: y("add_new_city"),
                onClick: () => {
                    this.isVisibleAddCityPopup = !0
                }
            }
        }
        submit() {
            if (!this.form.valid) return this.formService.validateFormFields(this.form), this.toastNotificationService.warning("please_fill_all_required_fields"), T(!1);
            this.errorResponse = null;
            let e = this.form.getRawValue();
            return e.id = this.account.id, this.service.update(e).pipe(G(t => (this.toastNotificationService.success("notification_business_info_update_success"), this.account = t, !0)), H(t => (this.errorResponse = t, T(!1))))
        }
        getStateListFromCountryList(e) {
            this.stateList = [], this.isIndiaSelected = e.selectedItem ? .id === 101, e.selectedItem ? .id && (this.selectedCountryId = e.selectedItem.id, this.form.patchValue({
                currency_code: e.selectedItem ? .currency_code
            }), this.stateService.getListByQuery({
                country_id: e.selectedItem ? .id ? ? this.tenantService ? .config() ? .country_id
            }).pipe(w(this.destroyRef)).subscribe({
                next: t => {
                    this.stateList = t
                },
                error: () => {
                    this.toastNotificationService.error("notification_state_fetch_error")
                }
            }))
        }
        getCityListFromStateList(e) {
            this.cityList = [], e.selectedItem && this.cityService.getListByQuery({
                state_id: e.selectedItem.id
            }).pipe(w(this.destroyRef)).subscribe({
                next: t => {
                    this.cityList = t
                },
                error: () => {
                    this.toastNotificationService.error("notification_city_fetch_error")
                }
            })
        }
        onAddState(e) {
            this.currentSelectedState = e, this.isVisibleAddStatePopup = !1, this.stateList.push(e), this.form.get("address").patchValue({
                state: e.name
            })
        }
        onAddCity(e) {
            this.isVisibleAddCityPopup = !1, this.cityList.push(e), this.form.get("address").patchValue({
                city: e.name,
                state_id: this.currentSelectedState.id
            })
        }
        changeLocale(e) {
            this.localizationService.switchLanguage(e ? .value)
        }
        getCountries() {
            this.countryService.loadCountries().pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.countryList = e
                },
                error: () => {
                    this.toastNotificationService.error("notification_country_fetch_error")
                }
            })
        }
        getTimezones() {
            this.timezoneService.getListByQuery().pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.timezoneList = e, this.validateTimezoneValue()
                },
                error: () => {
                    this.toastNotificationService.error("notification_timezone_fetch_error")
                }
            })
        }
        validateTimezoneValue() {
            if (!this.form || !this.timezoneList.length) return;
            let e = this.form.get("timezone") ? .value;
            e && !this.timezoneList.includes(e) && (this.form.patchValue({
                timezone: null
            }), this.form.get("timezone") ? .markAsTouched())
        }
        static {
            this.\u0275fac = (() => {
                let e;
                return function(s) {
                    return (e || (e = A(n)))(s || n)
                }
            })()
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-step-one"]
                ],
                standalone: !1,
                features: [R],
                decls: 8,
                vars: 4,
                consts: [
                    [1, "setup-step-one"],
                    [1, "container-fluid", "px-3", "px-md-4", "px-lg-5", "py-4"],
                    [1, "row", "justify-content-center"],
                    [1, "col-12"],
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    [3, "isVisiblePopup"],
                    [3, "isVisiblePopup", "stateId"],
                    [1, "card", "setup-card", "mb-4"],
                    [1, "card-body", "p-4"],
                    [1, "setup-card-header", "text-center", "mb-4"],
                    [1, "setup-icon-wrapper", "mx-auto", "mb-3"],
                    [1, "fa-thin", "fa-building-columns", "fa-2x"],
                    [1, "fw-bold", "mb-2"],
                    [1, "setup-section"],
                    [1, "setup-section-header", "mb-3"],
                    [1, "d-flex", "align-items-center"],
                    [1, "setup-section-icon", "me-2"],
                    [1, "fa-thin", "fa-circle-info"],
                    [1, "mb-0", "fw-semibold"],
                    [1, "mt-2", "mb-0"],
                    [1, "row", "g-3"],
                    ["name", "name", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "input-with-icon"],
                    [1, "fa-thin", "fa-building", "field-icon"],
                    ["formControlName", "name", 3, "placeholder", "stylingMode"],
                    ["name", "email", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    [1, "fa-thin", "fa-envelope", "field-icon"],
                    [3, "formControl", "isEditMode"],
                    ["name", "support_email", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    [1, "fa-thin", "fa-headset", "field-icon"],
                    [3, "formControl"],
                    ["name", "support_number", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    [1, "fa-thin", "fa-phone", "field-icon"],
                    ["name", "whats_app_number", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    [3, "formControl", "countryId"],
                    ["name", "website", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    [1, "fa-thin", "fa-globe", "field-icon"],
                    ["formControlName", "website", "placeholder", "Eg: https://www.bytephase.com", 3, "stylingMode"],
                    [3, "displayError", "errorMsg"],
                    ["name", "gst_number", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-file-invoice", "field-icon"],
                    ["formControlName", "gst_number", 3, "placeholder", "stylingMode"],
                    [1, "fa-thin", "fa-earth-americas"],
                    ["name", "country_id", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-flag", "field-icon"],
                    ["displayExpr", "name", "formControlName", "country_id", "searchMode", "contains", "valueExpr", "id", 3, "onSelectionChanged", "inputAttr", "items", "placeholder", "searchEnabled", "showClearButton", "stylingMode"],
                    ["name", "currency_code", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-coins", "field-icon"],
                    ["displayExpr", "currency_code", "formControlName", "currency_code", "searchMode", "contains", "valueExpr", "currency_code", 3, "inputAttr", "items", "placeholder", "searchEnabled", "showClearButton", "stylingMode"],
                    ["name", "date_time_format", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-calendar-days", "field-icon"],
                    ["displayExpr", "format", "formControlName", "date_time_format", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled", "showClearButton", "stylingMode"],
                    ["class", "p-2", 4, "dxTemplate", "dxTemplateOf"],
                    ["name", "timezone", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-clock", "field-icon"],
                    ["formControlName", "timezone", "searchMode", "contains", 3, "items", "placeholder", "searchEnabled", "showClearButton", "stylingMode"],
                    ["name", "locale", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-language", "field-icon"],
                    ["displayExpr", "Name", "formControlName", "locale", "searchMode", "contains", "valueExpr", "Value", 3, "onValueChanged", "items", "placeholder", "searchEnabled", "showClearButton", "stylingMode"],
                    ["formGroupName", "address"],
                    ["name", "state", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-map-location-dot", "field-icon"],
                    ["displayExpr", "name", "formControlName", "state", "searchMode", "contains", "valueExpr", "name", 3, "onSelectionChanged", "inputAttr", "items", "placeholder", "searchEnabled", "showClearButton", "showDropDownButton", "stylingMode"],
                    ["location", "after", "name", "addState", 3, "options"],
                    ["name", "city", 1, "col-12", "col-sm-6", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "fa-thin", "fa-city", "field-icon"],
                    ["displayExpr", "name", "formControlName", "city", "searchMode", "contains", "valueExpr", "name", 3, "inputAttr", "items", "placeholder", "searchEnabled", "showClearButton", "showDropDownButton", "stylingMode"],
                    ["location", "after", "name", "addCity", 3, "options"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "p-2"],
                    [1, "d-flex", "justify-content-between", "small"],
                    [1, "fw-medium"],
                    [1, "text-muted"],
                    [1, "text-muted", "small"],
                    [3, "stateCancelClick", "stateSaveClick", "isVisiblePopup"],
                    [3, "cityCancelClick", "citySaveClick", "isVisiblePopup", "stateId"]
                ],
                template: function(t, s) {
                    t & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), h(4, Yt, 1, 2, "app-skeleton-loader", 4), h(5, Xt, 88, 99, "form", 5), r()()()(), h(6, Zt, 1, 1, "app-add-state-popup", 6), h(7, en, 1, 2, "app-add-city-popup", 7)), t & 2 && (o(4), _(s.form ? -1 : 4), o(), _(s.form ? 5 : -1), o(), _(s.isVisibleAddStatePopup ? 6 : -1), o(), _(s.isVisibleAddCityPopup ? 7 : -1))
                },
                dependencies: [Be, Ee, Ie, Je, tt, Ke, ct, dt, de, ot, rt, at, re, We, Qe, se, De, Ne, Fe, Ve],
                styles: [".setup-step-one[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{-webkit-text-stroke:unset!important}.setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]{border:1px solid var(--theme-border-color);border-radius:16px;box-shadow:0 4px 24px #0000000f;transition:box-shadow .2s ease}.setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]:hover{box-shadow:0 8px 32px #0000001a}.setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]{padding:2rem!important}@media(min-width:768px){.setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]{padding:2.5rem 3rem!important}}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   .setup-icon-wrapper[_ngcontent-%COMP%]{width:80px;height:80px;border-radius:20px;background:linear-gradient(135deg,#e8f4fd,#f0f7ff);display:flex;align-items:center;justify-content:center;color:var(--bs-primary, #0d6efd);box-shadow:0 4px 16px #0d6efd26}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   .setup-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:2rem}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%]{color:#1f2937;font-size:1.5rem}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.9rem;max-width:600px;margin-left:auto;margin-right:auto}.setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   .setup-section-icon[_ngcontent-%COMP%]{width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg,#f0f4f8,#e2e8f0);display:flex;align-items:center;justify-content:center;color:var(--bs-primary, #0d6efd);font-size:.9rem}.setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{color:#374151;font-size:1rem}.setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   hr[_ngcontent-%COMP%]{border-color:var(--theme-border-color)}.setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]{position:relative;display:flex;align-items:stretch}.setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   .field-icon[_ngcontent-%COMP%]{position:absolute;left:12px;top:50%;transform:translateY(-50%);z-index:10;color:#6b7280;font-size:1rem;pointer-events:none}.setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-text-box[_ngcontent-%COMP%], .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-select-box[_ngcontent-%COMP%], .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-email[_ngcontent-%COMP%], .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-phone-number[_ngcontent-%COMP%], .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-mobile-number[_ngcontent-%COMP%]{flex:1}.setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-text-box[_ngcontent-%COMP%]     .dx-texteditor-input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-text-box[_ngcontent-%COMP%]     .dx-texteditor-input-container input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-select-box[_ngcontent-%COMP%]     .dx-texteditor-input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-select-box[_ngcontent-%COMP%]     .dx-texteditor-input-container input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-email[_ngcontent-%COMP%]     .dx-texteditor-input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-email[_ngcontent-%COMP%]     .dx-texteditor-input-container input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-phone-number[_ngcontent-%COMP%]     .dx-texteditor-input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-phone-number[_ngcontent-%COMP%]     .dx-texteditor-input-container input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-mobile-number[_ngcontent-%COMP%]     .dx-texteditor-input, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-mobile-number[_ngcontent-%COMP%]     .dx-texteditor-input-container input{padding-left:40px!important}.setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-text-box[_ngcontent-%COMP%]     .dx-placeholder:before, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   dx-select-box[_ngcontent-%COMP%]     .dx-placeholder:before, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-email[_ngcontent-%COMP%]     .dx-placeholder:before, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-phone-number[_ngcontent-%COMP%]     .dx-placeholder:before, .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   app-mobile-number[_ngcontent-%COMP%]     .dx-placeholder:before{padding-left:40px!important}.setup-step-one[_ngcontent-%COMP%]   .row.g-3[_ngcontent-%COMP%]{--bs-gutter-y: 1.5rem;--bs-gutter-x: 1.5rem}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]{box-shadow:0 4px 24px #0000004d}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]:hover{box-shadow:0 8px 32px #0006}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   .setup-icon-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   .setup-icon-wrapper[_ngcontent-%COMP%]{background:linear-gradient(135deg,#3b82f626,#3b82f61a);color:#60a5fa;box-shadow:0 4px 16px #3b82f633}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%]{color:#f1f5f9!important}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#94a3b8!important}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   .setup-section-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   .setup-section-icon[_ngcontent-%COMP%]{background:linear-gradient(135deg,#3b82f626,#3b82f61a);color:#60a5fa}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{color:#e2e8f0!important}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   .field-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]   .input-with-icon[_ngcontent-%COMP%]   .field-icon[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined{background-color:#10172a}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-texteditor-input-container, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-texteditor-input-container{background-color:#10172a}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-texteditor-input-container:after, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-texteditor-input-container:after{border-color:#334155}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-texteditor-input, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-texteditor-input{color:#f1f5f9;background-color:transparent}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-placeholder:before, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined .dx-placeholder:before{color:#64748b}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined.dx-state-focused .dx-texteditor-input-container:after, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined.dx-state-focused .dx-texteditor-input-container:after{border-color:#3b82f6}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined.dx-state-hover:not(.dx-state-focused) .dx-texteditor-input-container:after, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined.dx-state-hover:not(.dx-state-focused) .dx-texteditor-input-container:after{border-color:#475569}.dark-theme[_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-selectbox .dx-dropdowneditor-icon, .dark-theme   [_nghost-%COMP%]   .setup-step-one[_ngcontent-%COMP%]     .dx-selectbox .dx-dropdowneditor-icon{color:#94a3b8}@media(max-width:767px){.setup-step-one[_ngcontent-%COMP%]   .setup-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]{padding:1.5rem!important}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   .setup-icon-wrapper[_ngcontent-%COMP%]{width:64px;height:64px;border-radius:16px}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   .setup-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.5rem}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%]{font-size:1.25rem}.setup-step-one[_ngcontent-%COMP%]   .setup-card-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.8125rem}.setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   .setup-section-icon[_ngcontent-%COMP%]{width:28px;height:28px}.setup-step-one[_ngcontent-%COMP%]   .setup-section[_ngcontent-%COMP%]   .setup-section-header[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{font-size:.9rem}.setup-step-one[_ngcontent-%COMP%]   .row.g-3[_ngcontent-%COMP%]{--bs-gutter-y: 1rem;--bs-gutter-x: 1rem}}"]
            })
        }
    }
    return n
})();
var le = (() => {
    class n extends Re {
        constructor(e) {
            super(e, me), this.api = e, this.endpoint = me
        }
        get(e) {
            if (e) {
                let t = {
                    business_type_id: e
                };
                return this.api.getWithParams(this.endpoint, t)
            }
            return this.api.get(this.endpoint)
        }
        completeSetup(e) {
            return this.api.post(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)(be(qe))
            }
        }
        static {
            this.\u0275prov = Ce({
                token: n,
                factory: n.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return n
})();

function nn(n, l) {
    if (n & 1 && (i(0, "div", 1)(1, "div", 9), d(2, "i", 10), r()()), n & 2) {
        let e = m();
        o(), U("configured-badge", e.configured)
    }
}

function on(n, l) {
    n & 1 && d(0, "div", 2)
}

function rn(n, l) {
    if (n & 1 && (i(0, "span", 11), d(1, "i", 12), i(2, "span"), c(3), r()(), i(4, "span", 11), d(5, "i", 13), i(6, "span"), c(7), r()(), i(8, "span", 11), d(9, "i", 14), i(10, "span"), c(11), r()()), n & 2) {
        let e = m();
        o(3), ne("", e.configuredDeviceTypeCount, "/", e.getDeviceTypesCount(), " ", e.formatMessage("types")), o(4), ne("", e.configuredBrandCount, "/", e.getBrandsCount(), " ", e.formatMessage("brands")), o(4), ne("", e.configuredCount, "/", e.getModelsCount(), " ", e.formatMessage("models"))
    }
}

function sn(n, l) {
    if (n & 1 && (i(0, "span", 15), d(1, "i", 12), i(2, "span"), c(3), r()(), i(4, "span", 15), d(5, "i", 13), i(6, "span"), c(7), r()(), i(8, "span", 15), d(9, "i", 14), i(10, "span"), c(11), r()()), n & 2) {
        let e = m();
        o(3), O("", e.getDeviceTypesCount(), " ", e.formatMessage("types")), o(4), O("", e.getBrandsCount(), " ", e.formatMessage("brands")), o(4), O("", e.getModelsCount(), " ", e.formatMessage("models"))
    }
}
var bt = (() => {
    class n {
        constructor() {
            this.selected = !1, this.configured = !1, this.configuredCount = 0, this.configuredBrandCount = 0, this.configuredDeviceTypeCount = 0, this.selectBusinessType = new F, this.formatMessage = y, this.businessTypeIcons = {
                1: {
                    icon: "fa-solid fa-laptop",
                    gradient: "linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)"
                },
                2: {
                    icon: "fa-solid fa-mobile-screen",
                    gradient: "linear-gradient(135deg, #10B981 0%, #059669 100%)"
                },
                3: {
                    icon: "fa-solid fa-snowflake",
                    gradient: "linear-gradient(135deg, #14B8A6 0%, #0D9488 100%)"
                },
                4: {
                    icon: "fa-solid fa-gem",
                    gradient: "linear-gradient(135deg, #F59E0B 0%, #D97706 100%)"
                },
                5: {
                    icon: "fa-solid fa-hard-drive",
                    gradient: "linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)"
                },
                6: {
                    icon: "fa-solid fa-clock",
                    gradient: "linear-gradient(135deg, #EC4899 0%, #DB2777 100%)"
                },
                7: {
                    icon: "fa-solid fa-camera",
                    gradient: "linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)"
                },
                8: {
                    icon: "fa-solid fa-microchip",
                    gradient: "linear-gradient(135deg, #EF4444 0%, #DC2626 100%)"
                },
                9: {
                    icon: "fa-solid fa-blender",
                    gradient: "linear-gradient(135deg, #F97316 0%, #EA580C 100%)"
                },
                10: {
                    icon: "fa-solid fa-car",
                    gradient: "linear-gradient(135deg, #06B6D4 0%, #0891B2 100%)"
                },
                11: {
                    icon: "fa-solid fa-bicycle",
                    gradient: "linear-gradient(135deg, #84CC16 0%, #65A30D 100%)"
                },
                12: {
                    icon: "fa-solid fa-guitar",
                    gradient: "linear-gradient(135deg, #A855F7 0%, #9333EA 100%)"
                },
                13: {
                    icon: "fa-solid fa-screwdriver-wrench",
                    gradient: "linear-gradient(135deg, #6B7280 0%, #4B5563 100%)"
                }
            }
        }
        onCardClick() {
            this.selectBusinessType.emit(this.businessType)
        }
        getIcon() {
            return this.businessTypeIcons[this.businessType.id] ? .icon || this.businessType.icon || "fa-solid fa-briefcase"
        }
        getGradient() {
            return this.businessTypeIcons[this.businessType.id] ? .gradient || "linear-gradient(135deg, #6B7280 0%, #4B5563 100%)"
        }
        getDeviceTypesCount() {
            return this.businessType.device_types_count || 0
        }
        getBrandsCount() {
            return this.businessType.brands_count || 0
        }
        getModelsCount() {
            return this.businessType.models_count || 0
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-business-type-card"]
                ],
                inputs: {
                    businessType: "businessType",
                    selected: "selected",
                    configured: "configured",
                    configuredCount: "configuredCount",
                    configuredBrandCount: "configuredBrandCount",
                    configuredDeviceTypeCount: "configuredDeviceTypeCount"
                },
                outputs: {
                    selectBusinessType: "selectBusinessType"
                },
                standalone: !1,
                decls: 14,
                vars: 13,
                consts: [
                    ["type", "button", 1, "selection-card", 3, "click"],
                    [1, "selection-card-indicator"],
                    [1, "selection-card-status-dot"],
                    [1, "selection-card-header"],
                    [1, "selection-card-icon-container"],
                    [1, "selection-card-title"],
                    [1, "selection-card-content"],
                    [1, "selection-card-description"],
                    [1, "d-flex", "gap-1", "mt-2", "flex-nowrap"],
                    [1, "selection-card-badge"],
                    [1, "fa-solid", "fa-check"],
                    [1, "badge", "bg-success-subtle", "text-success", "border", "border-success-subtle", "d-inline-flex", "align-items-center", "gap-1"],
                    [1, "fa-solid", "fa-layer-group"],
                    [1, "fa-solid", "fa-tags"],
                    [1, "fa-solid", "fa-cubes"],
                    [1, "device-count-badge"]
                ],
                template: function(t, s) {
                    t & 1 && (i(0, "button", 0), M("click", function() {
                        return s.onCardClick()
                    }), h(1, nn, 3, 2, "div", 1), h(2, on, 1, 0, "div", 2), i(3, "div", 3)(4, "div", 4), d(5, "i"), r(), i(6, "h6", 5), c(7), r()(), i(8, "div", 6)(9, "p", 7), c(10), r(), i(11, "div", 8), h(12, rn, 12, 9)(13, sn, 12, 6), r()()()), t & 2 && (U("selected", s.selected)("configured", s.configured), o(), _(s.selected ? 1 : -1), o(), _(s.selected ? 2 : -1), o(2), te("background", s.getGradient()), o(), ye(s.getIcon()), o(2), u(s.businessType.name), o(3), k(" ", s.businessType.description, " "), o(2), _(s.selected && s.configured && s.configuredCount > 0 ? 12 : 13))
                },
                styles: ["[_nghost-%COMP%]{display:block;height:100%}[_nghost-%COMP%]   i[_ngcontent-%COMP%]{-webkit-text-stroke:unset!important}.selection-card.selected[_ngcontent-%COMP%]:not(.configured)   .selection-card-status-dot[_ngcontent-%COMP%]{background-color:var(--bs-primary)}"]
            })
        }
    }
    return n
})();
var cn = ["treeView"],
    dn = () => ({
        class: "device-config-modal"
    });

function ln(n, l) {
    if (n & 1 && (i(0, "div", 11), d(1, "dx-load-indicator", 31), i(2, "p", 32), c(3), r()()), n & 2) {
        let e = m(2);
        o(), p("visible", !0), o(2), u(e.formatMessage("loading_device_types"))
    }
}

function pn(n, l) {
    if (n & 1 && (i(0, "div", 36)(1, "span", 37), c(2), r(), i(3, "span", 38), c(4), r()()), n & 2) {
        let e = l.$implicit;
        o(2), u(e.text), o(2), u(e.type)
    }
}

function mn(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "div", 12)(1, "div", 33)(2, "dx-tree-view", 34, 0), M("onSelectionChanged", function(s) {
            x(e);
            let a = m(2);
            return v(a.onSelectionChanged(s))
        })("onContentReady", function(s) {
            x(e);
            let a = m(2);
            return v(a.onTreeContentReady(s))
        }), $(4, pn, 5, 2, "div", 35), r()()()
    }
    if (n & 2) {
        let e = m(2);
        o(2), p("dataSource", e.filteredTreeDataSource)("showCheckBoxesMode", "normal")("selectionMode", "multiple")("selectByClick", !0)("selectNodesRecursive", !0), o(2), p("dxTemplateOf", "treeItemTemplate")
    }
}

function un(n, l) {
    if (n & 1 && (i(0, "div", 13), d(1, "i", 39), i(2, "p", 40), c(3), r()()), n & 2) {
        let e = m(2);
        o(3), u(e.formatMessage("no_device_types_found"))
    }
}

function gn(n, l) {
    if (n & 1 && (i(0, "div", 13), d(1, "i", 41), i(2, "p", 40), c(3), r()()), n & 2) {
        let e = m(2);
        o(3), u(e.formatMessage("no_search_results") || "No devices match your search")
    }
}

function fn(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "div", 3)(1, "div", 4)(2, "h5", 5), c(3), r(), i(4, "button", 6), M("click", function() {
            x(e);
            let s = m();
            return v(s.onCancel())
        }), d(5, "i", 7), r()(), i(6, "div", 8)(7, "dx-text-box", 9), M("onValueChanged", function(s) {
            x(e);
            let a = m();
            return v(a.onSearchValueChanged(s.value))
        }), r()(), i(8, "div", 10), h(9, ln, 4, 2, "div", 11), h(10, mn, 5, 6, "div", 12), h(11, un, 4, 1, "div", 13), h(12, gn, 4, 1, "div", 13), r(), i(13, "div", 14)(14, "div", 15)(15, "div", 16)(16, "div", 17)(17, "div", 18), d(18, "i", 19), i(19, "span", 20), c(20), r()(), i(21, "div", 21)(22, "div")(23, "div", 22), c(24), r(), i(25, "div", 23), c(26), r()(), i(27, "div", 24)(28, "div", 25), c(29), r(), i(30, "div", 23), c(31), r()(), i(32, "div", 24)(33, "div", 26), c(34), r(), i(35, "div", 23), c(36), r()(), i(37, "div", 24)(38, "div", 27), c(39), r(), i(40, "div", 23), c(41), r()()()()()(), i(42, "div", 28)(43, "dx-button", 29), M("onClick", function() {
            x(e);
            let s = m();
            return v(s.onCancel())
        }), r(), i(44, "dx-button", 30), M("onClick", function() {
            x(e);
            let s = m();
            return v(s.onConfirm())
        }), r()()()()
    }
    if (n & 2) {
        let e = m();
        o(3), O(" ", e.formatMessage("select_devices_for"), " ", e.businessTypeName || e.formatMessage("business_type"), " "), o(4), p("placeholder", e.formatMessage("search_devices") || "Search devices...")("value", e.searchValue)("showClearButton", !0)("height", 36), o(2), _(e.isLoading ? 9 : -1), o(), _(!e.isLoading && e.filteredTreeDataSource.length > 0 ? 10 : -1), o(), _(!e.isLoading && e.treeDataSource.length === 0 ? 11 : -1), o(), _(!e.isLoading && e.treeDataSource.length > 0 && e.filteredTreeDataSource.length === 0 ? 12 : -1), o(8), u(e.formatMessage("selection_summary")), o(4), u(e.selectionSummary.total), o(2), u(e.formatMessage("total")), o(3), u(e.selectionSummary.deviceTypes), o(2), u(e.formatMessage("types")), o(3), u(e.selectionSummary.brands), o(2), u(e.formatMessage("brands")), o(3), u(e.selectionSummary.models), o(2), u(e.formatMessage("models")), o(2), p("text", e.formatMessage("cancel"))("stylingMode", "outlined")("height", 36)("width", 110), o(), p("text", e.formatMessage("save_selection") + " (" + e.selectionSummary.total + ")")("stylingMode", "contained")("height", 36)("width", 170)
    }
}
var xt = (() => {
    class n {
        constructor() {
            this.isVisible = !1, this.businessTypeId = null, this.businessTypeName = "", this.preSelectedDevices = null, this.configComplete = new F, this.cancel = new F, this.formatMessage = y, this.destroyRef = C(I), this.setupService = C(le), this.toastNotificationService = C(D), this.isMobileDevice = C(B).isMobileDevice, this.treeDataSource = [], this.filteredTreeDataSource = [], this.isLoading = !1, this.selectionSummary = {
                total: 0,
                deviceTypes: 0,
                brands: 0,
                models: 0
            }, this.isBulkOperation = !1, this.hasInitializedSelection = !1, this.searchValue = ""
        }
        ngOnChanges(e) {
            e.isVisible && this.isVisible && this.businessTypeId && this.loadDeviceTypes()
        }
        loadDeviceTypes() {
            this.businessTypeId && (this.isLoading = !0, this.treeDataSource = [], this.filteredTreeDataSource = [], this.searchValue = "", this.selectionSummary = {
                total: 0,
                deviceTypes: 0,
                brands: 0,
                models: 0
            }, this.hasInitializedSelection = !1, this.setupService.get(this.businessTypeId).pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.buildTreeData(e), this.isLoading = !1
                },
                error: () => {
                    this.toastNotificationService.error("failed_to_load_device_types"), this.isLoading = !1
                }
            }))
        }
        buildTreeData(e) {
            let t = e.device_types || [],
                s = [],
                a = this.preSelectedDevices && (this.preSelectedDevices.deviceTypeIds.length > 0 || this.preSelectedDevices.brandIds.length > 0 || this.preSelectedDevices.modelIds.length > 0),
                g = new Set(this.preSelectedDevices ? .deviceTypeIds || []),
                f = new Set(this.preSelectedDevices ? .brandIds || []),
                b = new Set(this.preSelectedDevices ? .modelIds || []);
            t.forEach(q => {
                let Ot = !a || g.has(q.id),
                    ge = {
                        id: `dt_${q.id}`,
                        text: q.name,
                        type: "Device Type",
                        expanded: !0,
                        selected: Ot,
                        items: [],
                        originalId: q.id,
                        originalType: "device_type"
                    };
                (q.brands || []).forEach(j => {
                    let St = !a || f.has(j.id),
                        fe = {
                            id: `br_${j.id}`,
                            text: j.name,
                            type: "Brand",
                            expanded: !0,
                            selected: St,
                            items: [],
                            originalId: j.id,
                            originalType: "brand"
                        };
                    (j.models || []).forEach(W => {
                        let kt = !a || b.has(W.id);
                        fe.items.push({
                            id: `md_${W.id}`,
                            text: W.name,
                            type: "Model",
                            expanded: !1,
                            selected: kt,
                            originalId: W.id,
                            originalType: "model"
                        })
                    }), ge.items.push(fe)
                }), s.push(ge)
            }), this.treeDataSource = s, this.filteredTreeDataSource = this.deepCloneTree(s), this.calculateSelectionFromData()
        }
        deepCloneTree(e) {
            return e.map(t => Y(Q({}, t), {
                items: t.items ? this.deepCloneTree(t.items) : void 0
            }))
        }
        calculateSelectionFromData() {
            let e = 0,
                t = 0,
                s = 0,
                a = f => {
                    f.forEach(b => {
                        b.type === "Device Type" && this.hasSelectedDescendant(b) ? e++ : b.type === "Brand" && this.hasSelectedDescendant(b) ? t++ : b.type === "Model" && b.selected && s++, b.items && b.items.length > 0 && a(b.items)
                    })
                };
            a(this.treeDataSource);
            let g = e + t + s;
            this.selectionSummary = {
                total: g,
                deviceTypes: e,
                brands: t,
                models: s
            }
        }
        onTreeContentReady(e) {
            !this.hasInitializedSelection && this.treeView ? .instance && this.treeDataSource.length > 0 && (this.hasInitializedSelection = !0, setTimeout(() => {
                this.initializeTreeSelection()
            }, 50))
        }
        initializeTreeSelection() {
            if (!this.treeView ? .instance) return;
            this.preSelectedDevices && (this.preSelectedDevices.deviceTypeIds.length > 0 || this.preSelectedDevices.brandIds.length > 0 || this.preSelectedDevices.modelIds.length > 0) ? this.applyPreSelection() : this.selectAllNodes()
        }
        applyPreSelection() {
            if (!this.treeView ? .instance || !this.preSelectedDevices) return;
            this.isBulkOperation = !0, this.treeView.instance.unselectAll();
            let e = new Set(this.preSelectedDevices.deviceTypeIds),
                t = new Set(this.preSelectedDevices.brandIds),
                s = new Set(this.preSelectedDevices.modelIds),
                a = g => {
                    g.forEach(f => {
                        let b = !1;
                        f.originalType === "device_type" ? b = e.has(f.originalId) : f.originalType === "brand" ? b = t.has(f.originalId) : f.originalType === "model" && (b = s.has(f.originalId)), b && this.treeView.instance.selectItem(f.id), f.items && f.items.length > 0 && a(f.items)
                    })
                };
            a(this.treeDataSource), this.isBulkOperation = !1, this.syncVisibleNodesToDataSource(), this.updateSelectionSummary()
        }
        selectAllNodes() {
            this.treeView ? .instance && (this.isBulkOperation = !0, this.treeView.instance.unselectAll(), this.treeDataSource.forEach(e => {
                this.treeView.instance.selectItem(e.id)
            }), this.isBulkOperation = !1, this.syncVisibleNodesToDataSource(), this.updateSelectionSummary())
        }
        onSelectionChanged(e) {
            this.isBulkOperation || (this.syncVisibleNodesToDataSource(), this.updateSelectionSummary())
        }
        syncVisibleNodesToDataSource() {
            if (!this.treeView ? .instance) return;
            let e = new Map,
                t = a => {
                    a.forEach(g => {
                        e.set(g.itemData.id, g.selected === !0), g.children && g.children.length > 0 && t(g.children)
                    })
                };
            t(this.treeView.instance.getNodes());
            let s = a => {
                a.forEach(g => {
                    e.has(g.id) && (g.selected = e.get(g.id)), g.items && g.items.length > 0 && s(g.items)
                })
            };
            s(this.treeDataSource)
        }
        updateSelectionSummary() {
            let e = 0,
                t = 0,
                s = 0,
                a = f => {
                    f.forEach(b => {
                        b.type === "Device Type" && this.hasSelectedDescendant(b) ? e++ : b.type === "Brand" && this.hasSelectedDescendant(b) ? t++ : b.type === "Model" && b.selected && s++, b.items && b.items.length > 0 && a(b.items)
                    })
                };
            a(this.treeDataSource);
            let g = e + t + s;
            this.selectionSummary = {
                total: g,
                deviceTypes: e,
                brands: t,
                models: s
            }
        }
        hasSelectedDescendant(e) {
            return !e.items || e.items.length === 0 ? e.selected === !0 : e.items.some(t => this.hasSelectedDescendant(t))
        }
        get hasSelection() {
            return this.selectionSummary.models > 0
        }
        getSelectionResult() {
            this.syncVisibleNodesToDataSource();
            let e = [],
                t = [],
                s = [],
                a = g => {
                    g.forEach(f => {
                        f.originalType === "device_type" && this.hasSelectedDescendant(f) ? e.push(f.originalId) : f.originalType === "brand" && this.hasSelectedDescendant(f) ? t.push(f.originalId) : f.originalType === "model" && f.selected === !0 && s.push(f.originalId), f.items && f.items.length > 0 && a(f.items)
                    })
                };
            return a(this.treeDataSource), {
                deviceTypeIds: e,
                brandIds: t,
                modelIds: s
            }
        }
        onConfirm() {
            let e = this.getSelectionResult();
            if (e.modelIds.length === 0) {
                this.toastNotificationService.warning("please_select_at_least_one_model");
                return
            }
            this.configComplete.emit(e)
        }
        onCancel() {
            this.cancel.emit()
        }
        onHiding() {
            this.isBulkOperation = !1, this.hasInitializedSelection = !1, this.searchValue = "", this.filteredTreeDataSource = []
        }
        onSearchValueChanged(e) {
            this.searchValue = e || "", this.applyCustomFilter()
        }
        applyCustomFilter() {
            !this.searchValue || this.searchValue.trim() === "" ? this.filteredTreeDataSource = this.deepCloneTree(this.treeDataSource) : this.filteredTreeDataSource = this.filterTreeWithDescendants(this.treeDataSource, this.searchValue.toLowerCase()), setTimeout(() => {
                this.reapplySelectionFromDataSource()
            }, 100)
        }
        filterTreeWithDescendants(e, t) {
            let s = [];
            for (let a of e) {
                let g = a.text.toLowerCase().includes(t),
                    f = a.items ? this.filterTreeWithDescendants(a.items, t) : [],
                    b = f.length > 0;
                g ? s.push(Y(Q({}, a), {
                    expanded: !0,
                    items: a.items ? this.deepCloneTree(a.items) : void 0
                })) : b && s.push(Y(Q({}, a), {
                    expanded: !0,
                    items: f
                }))
            }
            return s
        }
        reapplySelectionFromDataSource() {
            if (!this.treeView ? .instance) return;
            this.isBulkOperation = !0;
            let e = new Map,
                t = a => {
                    a.forEach(g => {
                        e.set(g.id, g.selected), g.items && g.items.length > 0 && t(g.items)
                    })
                };
            t(this.treeDataSource);
            let s = a => {
                a.forEach(g => {
                    e.get(g.id) && this.treeView.instance.selectItem(g.id), g.items && g.items.length > 0 && s(g.items)
                })
            };
            s(this.filteredTreeDataSource), this.isBulkOperation = !1
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-device-config-modal"]
                ],
                viewQuery: function(t, s) {
                    if (t & 1 && X(cn, 5), t & 2) {
                        let a;
                        Z(a = ee()) && (s.treeView = a.first)
                    }
                },
                inputs: {
                    isVisible: "isVisible",
                    businessTypeId: "businessTypeId",
                    businessTypeName: "businessTypeName",
                    preSelectedDevices: "preSelectedDevices"
                },
                outputs: {
                    configComplete: "configComplete",
                    cancel: "cancel"
                },
                standalone: !1,
                features: [xe],
                decls: 2,
                vars: 11,
                consts: [
                    ["treeView", ""],
                    [3, "onHiding", "visible", "showTitle", "dragEnabled", "showCloseButton", "hideOnOutsideClick", "wrapperAttr", "width", "height", "maxHeight"],
                    ["class", "device-config-modal d-flex flex-column", "style", "height: 100%;", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "device-config-modal", "d-flex", "flex-column", 2, "height", "100%"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "p-3", "flex-shrink-0"],
                    [1, "fw-bold", "mb-0", "modal-title"],
                    ["type", "button", 1, "btn-close-custom", 3, "click"],
                    [1, "fa-solid", "fa-xmark"],
                    [1, "flex-shrink-0", "px-3", "pb-2"],
                    ["mode", "search", "valueChangeEvent", "input", "stylingMode", "outlined", 3, "onValueChanged", "placeholder", "value", "showClearButton", "height"],
                    [1, "flex-grow-1", "overflow-auto", "px-3", 2, "min-height", "200px"],
                    [1, "text-center", "py-5"],
                    [1, "tree-wrapper", "rounded-3"],
                    [1, "text-center", "py-4", "rounded-3", "empty-state"],
                    [1, "flex-shrink-0", "p-3", "border-top"],
                    [1, "row", "g-3", "mb-3"],
                    [1, "col-md-12"],
                    [1, "p-3", "rounded-3", "summary-card", "h-100"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-2"],
                    [1, "fa-solid", "fa-chart-pie", "text-success", "small"],
                    [1, "fw-semibold", "small", "card-title"],
                    [1, "d-flex", "justify-content-around", "text-center"],
                    [1, "fs-5", "fw-bold", "summary-value"],
                    [1, "small", "summary-label"],
                    [1, "summary-divider", "ps-3"],
                    [1, "fs-5", "fw-bold", "text-primary"],
                    [1, "fs-5", "fw-bold", "text-info"],
                    [1, "fs-5", "fw-bold", "text-warning"],
                    [1, "d-flex", "justify-content-end", "gap-2", "pt-3", "border-top", "action-buttons"],
                    ["type", "normal", 3, "onClick", "text", "stylingMode", "height", "width"],
                    ["type", "default", 3, "onClick", "text", "stylingMode", "height", "width"],
                    [3, "visible"],
                    [1, "mt-3", "modal-subtitle"],
                    [1, "tree-content"],
                    ["keyExpr", "id", "displayExpr", "text", "itemsExpr", "items", "itemTemplate", "treeItemTemplate", 3, "onSelectionChanged", "onContentReady", "dataSource", "showCheckBoxesMode", "selectionMode", "selectByClick", "selectNodesRecursive"],
                    ["class", "d-flex align-items-center w-100 py-1", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "align-items-center", "w-100", "py-1"],
                    [1, "flex-grow-1", "text-truncate", "tree-item-name"],
                    [1, "tree-item-type", "small"],
                    [1, "fa-thin", "fa-laptop", "fa-3x", "mb-3", "opacity-50"],
                    [1, "mb-0"],
                    [1, "fa-thin", "fa-search", "fa-3x", "mb-3", "opacity-50"]
                ],
                template: function(t, s) {
                    t & 1 && (i(0, "dx-popup", 1), M("onHiding", function() {
                        return s.onHiding()
                    }), $(1, fn, 45, 27, "div", 2), r()), t & 2 && (p("visible", s.isVisible)("showTitle", !1)("dragEnabled", !1)("showCloseButton", !1)("hideOnOutsideClick", !1)("wrapperAttr", L(10, dn))("width", s.isMobileDevice() ? "95%" : 700)("height", s.isMobileDevice() ? "95vh" : "85vh")("maxHeight", s.isMobileDevice() ? "95vh" : "85vh"), o(), p("dxTemplateOf", "content"))
                },
                dependencies: [re, Ue, ce, Ye, se, et],
                styles: [`.device-config-modal i{-webkit-text-stroke:unset!important}.device-config-modal.dx-overlay-content{background-color:var(--primary-bg)}.device-config-modal .modal-title{color:#1f2937}.device-config-modal .btn-close-custom{display:flex;align-items:center;justify-content:center;width:32px;height:32px;border:none;background:transparent;border-radius:6px;cursor:pointer;color:#6b7280;transition:all .15s ease}.device-config-modal .btn-close-custom:hover{background-color:#0000000d;color:#1f2937}.device-config-modal .btn-close-custom i{font-size:1rem}.device-config-modal .tree-wrapper{border:1px solid var(--theme-border-color);overflow:hidden}.device-config-modal .tree-header{background-color:#f3f4f6;color:#6b7280;border-bottom:1px solid var(--theme-border-color)}.device-config-modal .tree-content{background-color:var(--primary-bg)}.device-config-modal .tree-content .dx-treeview,.device-config-modal .tree-content .dx-treeview .dx-scrollable-wrapper,.device-config-modal .tree-content .dx-treeview .dx-scrollable-container,.device-config-modal .tree-content .dx-treeview .dx-scrollable-content,.device-config-modal .tree-content .dx-treeview .dx-treeview-node,.device-config-modal .tree-content .dx-treeview .dx-treeview-item{background-color:transparent!important}.device-config-modal .tree-content .dx-treeview .dx-treeview-item{padding:8px 12px}.device-config-modal .tree-content .dx-treeview .dx-treeview-item-content{width:100%}.device-config-modal .tree-content .dx-treeview .dx-checkbox{margin-right:8px}.device-config-modal .tree-content .dx-treeview .dx-treeview-toggle-item-visibility{min-width:24px}.device-config-modal .tree-item-name{color:#1f2937}.device-config-modal .tree-item-type{min-width:80px;text-align:right;color:#9ca3af}.device-config-modal .summary-card{background-color:var(--bg-secondary);border:1px solid var(--theme-border-color)}.device-config-modal .card-title{color:#1f2937}.device-config-modal .card-label{color:#6b7280}.device-config-modal .summary-value{color:#1f2937}.device-config-modal .summary-label{color:#6b7280}.device-config-modal .summary-divider{border-left:1px solid var(--theme-border-color)}.device-config-modal .empty-state{background-color:var(--bg-secondary);border:1px solid var(--theme-border-color);color:#6b7280}.device-config-modal .action-buttons{border-color:var(--theme-border-color)!important}.device-config-modal .border-top{border-top-color:var(--theme-border-color)!important}body.dark-theme .device-config-modal .modal-title{color:#f1f5f9}body.dark-theme .device-config-modal .btn-close-custom{color:#94a3b8}body.dark-theme .device-config-modal .btn-close-custom:hover{background-color:#ffffff1a;color:#f1f5f9}body.dark-theme .device-config-modal .tree-header{background-color:#1e293b;color:#94a3b8}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-scrollable-wrapper,body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-scrollable-container,body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-scrollable-content,body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-treeview-node{background-color:transparent!important}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-treeview-item{background-color:transparent!important;color:#f1f5f9}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-treeview-item:hover{background-color:#3498db26!important}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-treeview-item-content{color:#f1f5f9}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-checkbox .dx-checkbox-icon{border-color:#475569!important;background-color:#1e293b!important}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-checkbox.dx-checkbox-checked .dx-checkbox-icon,body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-checkbox.dx-checkbox-indeterminate .dx-checkbox-icon{background-color:#3b82f6!important;border-color:#3b82f6!important}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-treeview-toggle-item-visibility{color:#94a3b8}body.dark-theme .device-config-modal .tree-content .dx-treeview .dx-treeview-toggle-item-visibility:before{color:#94a3b8}body.dark-theme .device-config-modal .tree-item-name{color:#f1f5f9}body.dark-theme .device-config-modal .tree-item-type{color:#64748b}body.dark-theme .device-config-modal .card-title{color:#f1f5f9}body.dark-theme .device-config-modal .card-label{color:#94a3b8}body.dark-theme .device-config-modal .summary-value{color:#f1f5f9}body.dark-theme .device-config-modal .summary-label,body.dark-theme .device-config-modal .empty-state{color:#94a3b8}body.dark-theme .device-config-modal .dx-button.dx-button-mode-outlined{background-color:#1e293b!important;border-color:#2d3748!important}body.dark-theme .device-config-modal .dx-button.dx-button-mode-outlined .dx-button-text{color:#f1f5f9!important}body.dark-theme .device-config-modal .dx-button.dx-button-mode-outlined:hover,body.dark-theme .device-config-modal .dx-button.dx-button-mode-outlined.dx-state-hover{background-color:#2d3748!important}body.dark-theme .device-config-modal .dx-button.dx-button-mode-contained.dx-button-default{background-color:#3b82f6!important;border-color:#3b82f6!important}body.dark-theme .device-config-modal .dx-button.dx-button-mode-contained.dx-button-default .dx-button-text{color:#fff!important}body.dark-theme .device-config-modal .dx-button.dx-button-mode-contained.dx-button-default:hover,body.dark-theme .device-config-modal .dx-button.dx-button-mode-contained.dx-button-default.dx-state-hover{background-color:#2563eb!important}body.dark-theme .device-config-modal.dx-popup-wrapper .dx-overlay-content{background-color:var(--primary-bg)!important}
`],
                encapsulation: 2
            })
        }
    }
    return n
})();
var _n = (n, l) => l.businessType.id,
    Cn = (n, l) => l.id;

function bn(n, l) {
    if (n & 1 && (i(0, "div", 8)(1, "span", 14), d(2, "i", 15), c(3), r(), i(4, "span", 16), d(5, "i", 17), c(6), r()()), n & 2) {
        let e = m();
        o(3), O(" ", e.selectedBusinessTypesCount, " ", e.formatMessage("business_types_selected"), " "), o(3), O(" ", e.totalConfiguredDevices, " ", e.formatMessage("total_devices_configured"), " ")
    }
}

function xn(n, l) {
    if (n & 1 && (i(0, "div", 25)(1, "span", 32), c(2), r(), i(3, "span", 32), c(4), r(), i(5, "span", 32), c(6), r()()), n & 2) {
        let e = m().$implicit,
            t = m(2);
        o(2), O(" ", e.deviceTypeIds.length, " ", t.formatMessage("types"), " "), o(2), O(" ", e.brandIds.length, " ", t.formatMessage("brands"), " "), o(2), O(" ", e.modelIds.length, " ", t.formatMessage("models"), " ")
    }
}

function vn(n, l) {
    if (n & 1 && (i(0, "span", 26), c(1), r()), n & 2) {
        let e = m(3);
        o(), k(" ", e.formatMessage("not_configured"), " ")
    }
}

function Mn(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "div", 23)(1, "span", 24), c(2), r(), h(3, xn, 7, 6, "div", 25)(4, vn, 2, 1, "span", 26), i(5, "div", 27)(6, "button", 28), M("click", function() {
            let s = x(e).$implicit,
                a = m(2);
            return v(a.onEditBusinessType(s.businessType.id))
        }), d(7, "i", 29), r(), i(8, "button", 30), M("click", function() {
            let s = x(e).$implicit,
                a = m(2);
            return v(a.onRemoveBusinessType(s.businessType.id))
        }), d(9, "i", 31), r()()()
    }
    if (n & 2) {
        let e = l.$implicit,
            t = m(2);
        U("configured", e.modelIds.length > 0), o(2), u(e.businessType.name), o(), _(e.modelIds.length > 0 ? 3 : 4), o(3), p("title", t.formatMessage("edit")), o(2), p("title", t.formatMessage("remove"))
    }
}

function yn(n, l) {
    if (n & 1 && (i(0, "div", 9)(1, "div", 18)(2, "div", 19), d(3, "i", 20), i(4, "span"), c(5), r()()(), i(6, "div", 21), N(7, Mn, 10, 6, "div", 22, _n), r()()), n & 2) {
        let e = m();
        o(5), u(e.formatMessage("selected_business_types")), o(2), z(e.selectedBusinessTypesArray)
    }
}

function Pn(n, l) {
    n & 1 && d(0, "app-skeleton-loader", 10), n & 2 && p("rows", 4)("columns", 3)
}

function On(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "div", 33)(1, "app-business-type-card", 34), M("selectBusinessType", function(s) {
            x(e);
            let a = m(2);
            return v(a.onSelectBusinessType(s))
        })("configureDevices", function() {
            let s = x(e).$implicit,
                a = m(2);
            return v(a.onEditBusinessType(s.id))
        }), r()()
    }
    if (n & 2) {
        let e = l.$implicit,
            t = m(2);
        o(), p("businessType", e)("selected", t.isSelected(e))("configured", t.isConfigured(e))("configuredCount", t.getConfiguredCount(e))("configuredBrandCount", t.getConfiguredBrandCount(e))("configuredDeviceTypeCount", t.getConfiguredDeviceTypeCount(e))
    }
}

function Sn(n, l) {
    if (n & 1 && (i(0, "div", 11), N(1, On, 2, 6, "div", 33, Cn), r()), n & 2) {
        let e = m();
        o(), z(e.businessTypes)
    }
}

function kn(n, l) {
    if (n & 1 && (i(0, "div", 12), d(1, "i", 35), i(2, "h5"), c(3), r(), i(4, "p", 36), c(5), r()()), n & 2) {
        let e = m();
        o(3), u(e.formatMessage("no_business_types_available")), o(2), u(e.formatMessage("contact_admin_for_business_types"))
    }
}
var vt = (() => {
    class n extends V {
        constructor() {
            super(...arguments), this.formatMessage = y, this.destroyRef = C(I), this.businessTypeService = C(ft), this.setupService = C(le), this.toastNotificationService = C(D), this.isMobileDevice = C(B).isMobileDevice(), this.businessTypes = [], this.isLoading = !0, this.selectedBusinessTypes = new Map, this.isDeviceModalVisible = !1, this.currentEditingBusinessTypeId = null
        }
        ngOnInit() {
            this.loadBusinessTypes()
        }
        loadBusinessTypes() {
            this.isLoading = !0, this.businessTypeService.getAllBusinessTypes().pipe(w(this.destroyRef)).subscribe({
                next: e => {
                    this.businessTypes = e.data, this.isLoading = !1
                },
                error: () => {
                    this.toastNotificationService.error("failed_to_load_business_types"), this.isLoading = !1
                }
            })
        }
        onSelectBusinessType(e) {
            this.selectedBusinessTypes.has(e.id) ? this.openDeviceConfigModal(e.id) : (this.selectedBusinessTypes.set(e.id, {
                businessType: e,
                deviceTypeIds: [],
                brandIds: [],
                modelIds: []
            }), this.openDeviceConfigModal(e.id))
        }
        isSelected(e) {
            return this.selectedBusinessTypes.has(e.id)
        }
        isConfigured(e) {
            let t = this.selectedBusinessTypes.get(e.id);
            return t ? t.modelIds.length > 0 : !1
        }
        getConfiguredCount(e) {
            let t = this.selectedBusinessTypes.get(e.id);
            return t ? t.modelIds.length : 0
        }
        getConfiguredBrandCount(e) {
            let t = this.selectedBusinessTypes.get(e.id);
            return t ? t.brandIds.length : 0
        }
        getConfiguredDeviceTypeCount(e) {
            let t = this.selectedBusinessTypes.get(e.id);
            return t ? t.deviceTypeIds.length : 0
        }
        openDeviceConfigModal(e) {
            this.currentEditingBusinessTypeId = e, this.isDeviceModalVisible = !0
        }
        onEditBusinessType(e) {
            this.openDeviceConfigModal(e)
        }
        onRemoveBusinessType(e) {
            this.selectedBusinessTypes.delete(e)
        }
        onDeviceConfigComplete(e) {
            if (this.currentEditingBusinessTypeId !== null) {
                let t = this.selectedBusinessTypes.get(this.currentEditingBusinessTypeId);
                t && (t.deviceTypeIds = e.deviceTypeIds, t.brandIds = e.brandIds, t.modelIds = e.modelIds, e.modelIds.length === 0 && this.selectedBusinessTypes.delete(this.currentEditingBusinessTypeId))
            }
            this.isDeviceModalVisible = !1, this.currentEditingBusinessTypeId = null, this.toastNotificationService.success("devices_configured_successfully")
        }
        onDeviceConfigCancel() {
            if (this.currentEditingBusinessTypeId !== null) {
                let e = this.selectedBusinessTypes.get(this.currentEditingBusinessTypeId);
                e && e.modelIds.length === 0 && this.selectedBusinessTypes.delete(this.currentEditingBusinessTypeId)
            }
            this.isDeviceModalVisible = !1, this.currentEditingBusinessTypeId = null
        }
        get selectedBusinessTypesCount() {
            return this.selectedBusinessTypes.size
        }
        get totalConfiguredDevices() {
            let e = 0;
            return this.selectedBusinessTypes.forEach(t => {
                e += t.modelIds.length
            }), e
        }
        get selectedBusinessTypesArray() {
            return Array.from(this.selectedBusinessTypes.values())
        }
        get hasConfiguredBusinessTypes() {
            return this.selectedBusinessTypesArray.some(e => e.modelIds.length > 0)
        }
        getCurrentEditingBusinessType() {
            return this.currentEditingBusinessTypeId === null ? null : this.selectedBusinessTypes.get(this.currentEditingBusinessTypeId) ? .businessType ? ? null
        }
        getCurrentEditingPreSelectedDevices() {
            if (this.currentEditingBusinessTypeId === null) return null;
            let e = this.selectedBusinessTypes.get(this.currentEditingBusinessTypeId);
            return e ? {
                deviceTypeIds: e.deviceTypeIds,
                brandIds: e.brandIds,
                modelIds: e.modelIds
            } : null
        }
        submit() {
            if (this.selectedBusinessTypes.size === 0) return this.toastNotificationService.error("please_select_business_type"), T(!1);
            if (!this.hasConfiguredBusinessTypes) return this.toastNotificationService.warning("please_configure_devices"), T(!1);
            let e = this.selectedBusinessTypesArray.filter(t => t.modelIds.length > 0).map(t => ({
                business_type_id: t.businessType.id,
                device_type_ids: t.deviceTypeIds,
                brand_ids: t.brandIds,
                model_ids: t.modelIds
            }));
            return this.setupService.completeSetup({
                business_types: e
            }).pipe(G(t => {
                let s = {
                    businessTypes: this.selectedBusinessTypesArray.map(a => ({
                        businessType: a.businessType,
                        deviceTypeIds: a.deviceTypeIds,
                        brandIds: a.brandIds,
                        modelIds: a.modelIds,
                        deviceTypeCount: a.deviceTypeIds.length,
                        brandCount: a.brandIds.length,
                        modelCount: a.modelIds.length
                    })),
                    totalBusinessTypes: this.selectedBusinessTypesCount,
                    totalDeviceTypes: this.selectedBusinessTypesArray.reduce((a, g) => a + g.deviceTypeIds.length, 0),
                    totalBrands: this.selectedBusinessTypesArray.reduce((a, g) => a + g.brandIds.length, 0),
                    totalModels: this.totalConfiguredDevices
                };
                return localStorage.setItem("setupSummary", JSON.stringify(s)), !0
            }), H(() => (this.toastNotificationService.error("failed_to_complete_setup"), T(!1))))
        }
        static {
            this.\u0275fac = (() => {
                let e;
                return function(s) {
                    return (e || (e = A(n)))(s || n)
                }
            })()
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-business-type-selection"]
                ],
                standalone: !1,
                features: [R],
                decls: 16,
                vars: 10,
                consts: [
                    [1, "business-type-selection"],
                    [1, "main-content", "px-3", "px-md-4", "px-lg-5", "py-4"],
                    [1, "text-center", "mb-4"],
                    [1, "header-icon-wrapper"],
                    [1, "fa-thin", "fa-briefcase"],
                    [1, "fw-semibold", "mb-2", "header-title"],
                    [1, "text-muted", "small", "mb-0"],
                    [1, "fa-solid", "fa-circle-info", "me-1"],
                    [1, "summary-badges"],
                    [1, "selected-section"],
                    ["type", "card-grid", 3, "rows", "columns"],
                    [1, "row", "g-3"],
                    [1, "empty-state", "text-center", "py-5"],
                    [3, "configComplete", "cancel", "isVisible", "businessTypeId", "businessTypeName", "preSelectedDevices"],
                    [1, "summary-badge", "primary"],
                    [1, "fa-solid", "fa-briefcase"],
                    [1, "summary-badge", "success"],
                    [1, "fa-solid", "fa-laptop"],
                    [1, "selected-section-header"],
                    [1, "selected-section-title", "d-flex", "align-items-center", "gap-2", "fw-semibold"],
                    [1, "fa-solid", "fa-check-circle"],
                    [1, "selected-chips-wrapper"],
                    [1, "selected-chip", 3, "configured"],
                    [1, "selected-chip"],
                    [1, "chip-name"],
                    [1, "d-flex", "flex-wrap", "gap-1"],
                    [1, "chip-badge"],
                    [1, "d-flex", "align-items-center", "gap-1", "ms-1"],
                    ["type", "button", 1, "chip-action-btn", "edit", 3, "click", "title"],
                    [1, "fa-solid", "fa-pen"],
                    ["type", "button", 1, "chip-action-btn", "remove", 3, "click", "title"],
                    [1, "fa-solid", "fa-times"],
                    [1, "chip-badge", "success"],
                    [1, "col-12", "col-sm-6", "col-lg-3"],
                    [3, "selectBusinessType", "configureDevices", "businessType", "selected", "configured", "configuredCount", "configuredBrandCount", "configuredDeviceTypeCount"],
                    [1, "fa-thin", "fa-briefcase", "fa-4x", "mb-3"],
                    [1, "small"]
                ],
                template: function(t, s) {
                    if (t & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), d(4, "i", 4), r(), i(5, "h5", 5), c(6), r(), i(7, "p", 6), d(8, "i", 7), c(9, " Your selection will be visible in the CRM. Only select the device types you actively work with. "), r(), h(10, bn, 7, 4, "div", 8), r(), h(11, yn, 9, 1, "div", 9), h(12, Pn, 1, 2, "app-skeleton-loader", 10), h(13, Sn, 3, 0, "div", 11), h(14, kn, 6, 2, "div", 12), r()(), i(15, "app-device-config-modal", 13), M("configComplete", function(g) {
                            return s.onDeviceConfigComplete(g)
                        })("cancel", function() {
                            return s.onDeviceConfigCancel()
                        }), r()), t & 2) {
                        let a, g;
                        o(6), u(s.formatMessage("select_business_types")), o(4), _(s.selectedBusinessTypesCount > 0 ? 10 : -1), o(), _(s.selectedBusinessTypesCount > 0 && !s.isLoading ? 11 : -1), o(), _(s.isLoading ? 12 : -1), o(), _(!s.isLoading && s.businessTypes.length > 0 ? 13 : -1), o(), _(!s.isLoading && s.businessTypes.length === 0 ? 14 : -1), o(), p("isVisible", s.isDeviceModalVisible)("businessTypeId", ((a = s.getCurrentEditingBusinessType()) == null ? null : a.id) ? ? null)("businessTypeName", ((g = s.getCurrentEditingBusinessType()) == null ? null : g.name) ? ? "")("preSelectedDevices", s.getCurrentEditingPreSelectedDevices())
                    }
                },
                dependencies: [de, bt, xt],
                styles: ["[_nghost-%COMP%]{display:block;height:100%}.business-type-selection[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{-webkit-text-stroke:unset!important}.business-type-selection[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%}.main-content[_ngcontent-%COMP%]{flex:1;overflow-y:auto}.header-icon-wrapper[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:64px;height:64px;margin-bottom:1rem;background-color:rgba(var(--bs-primary-rgb),.1);border-radius:50%}.header-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.75rem;color:var(--bs-primary)}.header-title[_ngcontent-%COMP%]{color:var(--bs-body-color)}.header-description[_ngcontent-%COMP%]{font-size:.875rem;color:var(--bs-secondary-color);max-width:550px;margin:0 auto;line-height:1.5}.summary-badges[_ngcontent-%COMP%]{display:flex;justify-content:center;gap:.75rem;margin-top:1.25rem;flex-wrap:wrap}.summary-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:.5rem;padding:.5rem 1rem;font-size:.8125rem;font-weight:500;border-radius:2rem;white-space:nowrap}.summary-badge[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.75rem}.summary-badge.primary[_ngcontent-%COMP%]{background-color:rgba(var(--bs-primary-rgb),.1);color:var(--bs-primary);border:1px solid rgba(var(--bs-primary-rgb),.25)}.summary-badge.success[_ngcontent-%COMP%]{background-color:rgba(var(--bs-success-rgb),.1);color:var(--bs-success);border:1px solid rgba(var(--bs-success-rgb),.25)}.selected-section[_ngcontent-%COMP%]{margin:1.5rem 0;padding:1rem 1.25rem;background-color:var(--bg-secondary);border:1px solid var(--theme-border-color);border-radius:.75rem}.selected-section-header[_ngcontent-%COMP%]{margin-bottom:.75rem}.selected-section-title[_ngcontent-%COMP%]{font-size:.9375rem;color:var(--bs-body-color)}.selected-section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:var(--bs-success);font-size:1rem}.selected-chips-wrapper[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:.75rem}.selected-chip[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:.625rem;padding:.5rem .875rem;background-color:var(--primary-bg);border:1.5px solid var(--theme-border-color);border-radius:2rem;transition:all .2s ease}.selected-chip.configured[_ngcontent-%COMP%]{border-color:var(--bs-success)}.selected-chip[_ngcontent-%COMP%]:hover{box-shadow:0 2px 8px #0000001a}.chip-name[_ngcontent-%COMP%]{font-size:.8125rem;font-weight:500;color:var(--bs-body-color);white-space:nowrap}.chip-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;padding:.25rem .5rem;font-size:.6875rem;font-weight:600;background-color:rgba(var(--bs-warning-rgb),.15);color:var(--bs-warning);border-radius:1rem;white-space:nowrap}.chip-badge.success[_ngcontent-%COMP%]{background-color:rgba(var(--bs-success-rgb),.15);color:var(--bs-success)}.chip-action-btn[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;border:none;background:transparent;border-radius:50%;cursor:pointer;transition:all .2s ease;color:var(--bs-secondary-color)}.chip-action-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.6875rem}.chip-action-btn[_ngcontent-%COMP%]:hover{background-color:var(--bg-secondary)}.chip-action-btn.edit[_ngcontent-%COMP%]:hover{color:var(--bs-primary)}.chip-action-btn.remove[_ngcontent-%COMP%]:hover{color:var(--bs-danger)}.loading-text[_ngcontent-%COMP%], .empty-state[_ngcontent-%COMP%]{color:var(--bs-secondary-color)}.empty-state[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{opacity:.5;color:var(--bs-secondary-color)}.empty-state[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{color:var(--bs-secondary-color)}.dark-theme[_nghost-%COMP%]   .header-icon-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .header-icon-wrapper[_ngcontent-%COMP%]{background-color:#3b82f626}.dark-theme[_nghost-%COMP%]   .header-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .header-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .header-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .header-title[_ngcontent-%COMP%]{color:#fff!important}.dark-theme[_nghost-%COMP%]   .header-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .header-description[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .summary-badges[_ngcontent-%COMP%]   .summary-badge.primary[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .summary-badges[_ngcontent-%COMP%]   .summary-badge.primary[_ngcontent-%COMP%]{background-color:#3b82f626;color:#60a5fa;border-color:#3b82f64d}.dark-theme[_nghost-%COMP%]   .summary-badges[_ngcontent-%COMP%]   .summary-badge.success[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .summary-badges[_ngcontent-%COMP%]   .summary-badge.success[_ngcontent-%COMP%]{background-color:#22c55e26;color:#4ade80;border-color:#22c55e4d}.dark-theme[_nghost-%COMP%]   .selected-section-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .selected-section-title[_ngcontent-%COMP%]{color:#fff!important}.dark-theme[_nghost-%COMP%]   .selected-section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .selected-section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#4ade80}.dark-theme[_nghost-%COMP%]   .selected-chip.configured[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .selected-chip.configured[_ngcontent-%COMP%]{border-color:#4ade80}.dark-theme[_nghost-%COMP%]   .selected-chip[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .selected-chip[_ngcontent-%COMP%]:hover{box-shadow:0 2px 8px #0000004d}.dark-theme[_nghost-%COMP%]   .chip-name[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .chip-name[_ngcontent-%COMP%]{color:#fff!important}.dark-theme[_nghost-%COMP%]   .chip-badge[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .chip-badge[_ngcontent-%COMP%]{background-color:#fbbf2433;color:#fbbf24}.dark-theme[_nghost-%COMP%]   .chip-badge.success[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .chip-badge.success[_ngcontent-%COMP%]{background-color:#22c55e33;color:#4ade80}.dark-theme[_nghost-%COMP%]   .chip-action-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .chip-action-btn[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .chip-action-btn.edit[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .chip-action-btn.edit[_ngcontent-%COMP%]:hover{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .chip-action-btn.remove[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .chip-action-btn.remove[_ngcontent-%COMP%]:hover{color:#f87171}.dark-theme[_nghost-%COMP%]   .loading-text[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .loading-text[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .empty-state[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#64748b!important}@media(max-width:768px){.header-icon-wrapper[_ngcontent-%COMP%]{width:56px;height:56px}.header-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.5rem}.header-description[_ngcontent-%COMP%]{font-size:.8125rem}.summary-badges[_ngcontent-%COMP%]{gap:.5rem}.summary-badge[_ngcontent-%COMP%]{padding:.375rem .75rem;font-size:.75rem}.selected-section[_ngcontent-%COMP%]{padding:.875rem 1rem}.selected-section-title[_ngcontent-%COMP%]{font-size:.875rem}.selected-chips-wrapper[_ngcontent-%COMP%]{gap:.5rem}.selected-chip[_ngcontent-%COMP%]{padding:.375rem .75rem;gap:.5rem}.chip-name[_ngcontent-%COMP%]{font-size:.75rem}.chip-badge[_ngcontent-%COMP%]{font-size:.625rem;padding:.1875rem .375rem}.chip-action-btn[_ngcontent-%COMP%]{width:22px;height:22px}}"]
            })
        }
    }
    return n
})();
var Tn = (n, l) => ({
        "btn-primary": n,
        "btn-light border border-2": l
    }),
    En = (n, l, e) => ({
        "text-primary": n,
        "text-body": l,
        "text-muted": e
    }),
    In = (n, l) => ({
        "text-white": n,
        "text-muted": l
    }),
    Bn = (n, l) => ({
        "bg-primary": n,
        "bg-secondary bg-opacity-25": l
    }),
    Dn = (n, l) => l.label;

function Vn(n, l) {
    n & 1 && d(0, "i", 3)
}

function Fn(n, l) {
    if (n & 1 && (i(0, "span", 4), c(1), r()), n & 2) {
        let e = m().$index,
            t = m();
        p("ngClass", ie(2, In, t.isStepActive(e), t.isStepPending(e))), o(), k(" ", e + 1, " ")
    }
}

function Nn(n, l) {
    if (n & 1 && (i(0, "div", 6), d(1, "div", 7), r()), n & 2) {
        let e = m().$index,
            t = m();
        o(), p("ngClass", ie(1, Bn, t.isStepCompleted(e), !t.isStepCompleted(e)))
    }
}

function zn(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "div", 1)(1, "button", 2), M("click", function() {
            let s = x(e).$index,
                a = m();
            return v(a.onStepClick(s))
        }), h(2, Vn, 1, 0, "i", 3)(3, Fn, 2, 5, "span", 4), r(), i(4, "span", 5), c(5), r()(), h(6, Nn, 2, 4, "div", 6)
    }
    if (n & 2) {
        let e = l.$implicit,
            t = l.$index,
            s = l.$count,
            a = m();
        o(), te("width", 48, "px")("height", 48, "px"), p("ngClass", ie(10, Tn, a.isStepCompleted(t) || a.isStepActive(t), a.isStepPending(t)))("disabled", a.isStepPending(t)), o(), _(a.isStepCompleted(t) ? 2 : 3), o(2), p("ngClass", ke(13, En, a.isStepActive(t), a.isStepCompleted(t), a.isStepPending(t))), o(), k(" ", e.label, " "), o(), _(t !== s - 1 ? 6 : -1)
    }
}
var Mt = (() => {
    class n {
        constructor() {
            this.steps = [], this.currentStep = 0, this.stepClick = new F
        }
        onStepClick(e) {
            e < this.currentStep && this.stepClick.emit(e)
        }
        isStepCompleted(e) {
            return e < this.currentStep
        }
        isStepActive(e) {
            return e === this.currentStep
        }
        isStepPending(e) {
            return e > this.currentStep
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-setup-stepper"]
                ],
                inputs: {
                    steps: "steps",
                    currentStep: "currentStep"
                },
                outputs: {
                    stepClick: "stepClick"
                },
                standalone: !1,
                decls: 3,
                vars: 0,
                consts: [
                    [1, "d-flex", "justify-content-center", "align-items-start", "py-4"],
                    [1, "d-flex", "flex-column", "align-items-center", "text-center", 2, "min-width", "120px", "max-width", "160px"],
                    ["type", "button", 1, "btn", "rounded-circle", "d-flex", "align-items-center", "justify-content-center", "p-0", "border-0", 3, "click", "ngClass", "disabled"],
                    [1, "fa-solid", "fa-check", "text-white"],
                    [1, "fw-semibold", 3, "ngClass"],
                    [1, "fw-semibold", "small", "mt-2", 3, "ngClass"],
                    [1, "flex-grow-1", "d-flex", "align-items-center", "px-2", 2, "margin-top", "24px"],
                    [1, "w-100", "rounded-pill", 2, "height", "3px", 3, "ngClass"]
                ],
                template: function(t, s) {
                    t & 1 && (i(0, "div", 0), N(1, zn, 7, 17, null, null, Dn), r()), t & 2 && (o(), z(s.steps))
                },
                dependencies: [we],
                styles: ["[_nghost-%COMP%]{display:block}"]
            })
        }
    }
    return n
})();
var An = ["stepComponent"];

function Rn(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "app-save-btn", 13), M("saveBtnClick", function() {
            x(e);
            let s = m();
            return v(s.onPrevButtonClick())
        }), r()
    }
    n & 2 && p("useSubmitBehavior", !1)
}

function qn(n, l) {
    if (n & 1) {
        let e = P();
        i(0, "app-save-btn", 14), M("saveBtnClick", function() {
            x(e);
            let s = m();
            return v(s.onNextButtonClick())
        }), r()
    }
    n & 2 && p("useSubmitBehavior", !1)
}
var yt = (() => {
    class n {
        constructor() {
            this.formatMessage = y, this.tenantService = C(ae), this.plan = this.tenantService.plan(), this.isIndia = this.tenantService.isIndia(), this.selectedIndex = 0, this.steps = [{
                label: y("BUSINESS_INFORMATION"),
                subtitle: y("SETUP_STEP1_SUBTITLE")
            }, {
                label: y("BUSINESS_TYPE_DEVICES"),
                subtitle: y("SETUP_STEP2_SUBTITLE")
            }, {
                label: y("COMPLETED"),
                subtitle: y("SETUP_STEP3_SUBTITLE")
            }]
        }
        onStepClick(e) {
            e < this.selectedIndex && (this.selectedIndex = e)
        }
        moveNext() {
            this.selectedIndex++
        }
        onPrevButtonClick() {
            this.selectedIndex > 0 && this.selectedIndex--
        }
        getCurrentStepComponent() {
            return this.stepComponents.toArray()[this.selectedIndex]
        }
        onNextButtonClick() {
            return he(this, null, function*() {
                if (this.selectedIndex < this.steps.length - 1) {
                    let e = this.getCurrentStepComponent();
                    e ? .submit ? (yield _e(e.submit())) && this.moveNext() : this.moveNext()
                }
            })
        }
        isLastStep() {
            return this.selectedIndex === this.steps.length - 1
        }
        isFirstStep() {
            return this.selectedIndex === 0
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-setup"]
                ],
                viewQuery: function(t, s) {
                    if (t & 1 && X(An, 5), t & 2) {
                        let a;
                        Z(a = ee()) && (s.stepComponents = a)
                    }
                },
                standalone: !1,
                decls: 24,
                vars: 13,
                consts: [
                    ["stepComponent", ""],
                    [1, "container-fluid", "px-3", "px-md-4"],
                    [3, "stepClick", "steps", "currentStep"],
                    [1, "content"],
                    [3, "selectedIndexChange", "selectedIndex", "animationEnabled", "focusStateEnabled", "swipeEnabled", "deferRendering"],
                    [1, "nav-panel", "mt-4", "pb-4"],
                    [1, "d-flex", "justify-content-between", "align-items-center"],
                    [1, "current-step"],
                    [1, "text-muted", "small"],
                    [1, "text-body"],
                    [1, "nav-buttons", "d-flex", "gap-2"],
                    ["icon", "fa-thin fa-arrow-left me-1", "saveText", "BACK", "type", "normal", 3, "useSubmitBehavior"],
                    ["saveText", "CONTINUE", "suffixIcon", "fa-thin fa-arrow-right ms-1", 3, "useSubmitBehavior"],
                    ["icon", "fa-thin fa-arrow-left me-1", "saveText", "BACK", "type", "normal", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "CONTINUE", "suffixIcon", "fa-thin fa-arrow-right ms-1", 3, "saveBtnClick", "useSubmitBehavior"]
                ],
                template: function(t, s) {
                    if (t & 1) {
                        let a = P();
                        i(0, "div", 1)(1, "app-setup-stepper", 2), M("stepClick", function(f) {
                            return s.onStepClick(f)
                        }), r(), i(2, "div", 3)(3, "dx-multi-view", 4), Se("selectedIndexChange", function(f) {
                            return x(a), Oe(s.selectedIndex, f) || (s.selectedIndex = f), v(f)
                        }), i(4, "dxi-multi-view-item"), d(5, "app-step-one", null, 0), r(), i(7, "dxi-multi-view-item"), d(8, "app-business-type-selection", null, 0), r(), i(10, "dxi-multi-view-item"), d(11, "app-step-final", null, 0), r()(), i(13, "div", 5)(14, "div", 6)(15, "div", 7)(16, "span", 8), c(17), i(18, "strong", 9), c(19), r(), c(20), r()(), i(21, "div", 10), h(22, Rn, 1, 1, "app-save-btn", 11), h(23, qn, 1, 1, "app-save-btn", 12), r()()()()()
                    }
                    t & 2 && (o(), p("steps", s.steps)("currentStep", s.selectedIndex), o(2), Pe("selectedIndex", s.selectedIndex), p("animationEnabled", !1)("focusStateEnabled", !1)("swipeEnabled", !1)("deferRendering", !1), o(14), k(" ", s.formatMessage("STEP"), " "), o(2), u(s.selectedIndex + 1), o(), O(" ", s.formatMessage("OF"), " ", s.steps.length, " "), o(2), _(s.isFirstStep() ? -1 : 22), o(), _(s.isLastStep() ? -1 : 23))
                },
                dependencies: [Ge, Ze, Xe, Ct, _t, vt, Mt],
                encapsulation: 2
            })
        }
    }
    return n
})();
var jn = [{
        path: "",
        component: yt
    }],
    Pt = (() => {
        class n {
            static {
                this.\u0275fac = function(t) {
                    return new(t || n)
                }
            }
            static {
                this.\u0275mod = K({
                    type: n
                })
            }
            static {
                this.\u0275inj = J({
                    imports: [pe.forChild(jn), pe]
                })
            }
        }
        return n
    })();
var nr = (() => {
    class n {
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275mod = K({
                type: n
            })
        }
        static {
            this.\u0275inj = J({
                imports: [Te, ze, Pt, lt, ht, pt, mt, ut]
            })
        }
    }
    return n
})();
export {
    nr as SetupModule
};