import {
    c as a
} from "./chunk-MKYLKZGM.js";
import "./chunk-DCKGQUHB.js";
import "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
export {
    a as MobilesModule
};