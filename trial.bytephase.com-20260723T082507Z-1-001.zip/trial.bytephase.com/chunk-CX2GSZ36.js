import {
    Ae as K,
    Ec as Ve,
    Le as qe,
    Nc as Ae,
    Rc as Pe,
    T as z,
    Ta as H,
    Va as W,
    Zd as Z,
    _d as Qe,
    ab as De,
    ca as M,
    cb as $,
    cd as Re,
    e as k,
    g as B,
    h as Q,
    ha as Te,
    hb as Ie,
    ka as we,
    kd as Le,
    n as be,
    og as I,
    pb as Oe,
    ph as Ge,
    rd as Be,
    sb as Y,
    t as q,
    u as G,
    ub as D,
    y as U,
    yc as Ne
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    $g as xe,
    Ak as Ee,
    Ec as _e,
    Fa as n,
    Fc as L,
    Fh as ye,
    Ib as le,
    Ka as re,
    Kb as de,
    Kc as he,
    Na as x,
    Oa as R,
    Pb as ce,
    Qb as me,
    Rb as pe,
    Rd as Fe,
    Sa as w,
    Tc as Ce,
    Vb as ue,
    Wb as fe,
    Xa as ne,
    _a as f,
    _b as E,
    aa as N,
    ba as V,
    da as A,
    dh as y,
    ea as m,
    eb as r,
    fb as l,
    gb as s,
    ha as C,
    hb as c,
    hi as Se,
    ia as b,
    lb as ae,
    mb as se,
    oa as oe,
    pd as ge,
    qa as P,
    qb as F,
    qd as ve,
    qg as ee,
    sb as u,
    sd as j,
    ti as ke,
    ub as d,
    ui as Me,
    vd as J,
    wd as X,
    xk as h
} from "./chunk-GOPIAW4V.js";
var je = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-feedback"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                template: function(i, o) {
                    i & 1 && (l(0, "div"), c(1, "router-outlet"), s())
                },
                dependencies: [ve],
                encapsulation: 2
            })
        }
    }
    return t
})();
var g = class {
    constructor(a) {
        return Object.assign(this, a)
    }
    static getForm(a) {
        return new U().group({
            id: [a.id || null],
            title: [a.title || null, [k.required]],
            ends_at: [a.ends_at || new Date, [k.required]],
            description: [a.description || null, [k.required]],
            fields: I.getFormArray(a.fields)
        })
    }
};
var T = (() => {
    class t extends ke {
        constructor(e) {
            super(e, ee), this.api = e, this.endpoint = ee
        }
        getById(e) {
            return this.api.get(`${this.endpoint}/${e}`)
        }
        getByType() {
            return this.api.get(this.endpoint)
        }
        getListByQuery(e = {}) {
            return this.api.getListByQuery("getAllFormsByList", e)
        }
        saveFeedbackQuestionCustomField(e) {
            return this.api.post("saveFeedbackQuestionCustomField", e)
        }
        updateFeedbackQuestionCustomField(e, i) {
            return this.api.patch(`updateFeedbackQuestionCustomField/${e}`, i)
        }
        feedbackResponse(e) {
            return this.api.post("feedbackResponse", e)
        }
        isFeedbackFormShown() {
            let e = localStorage.getItem("feedbackFormShown"),
                i = new Date().toISOString().split("T")[0];
            return e === i ? (console.log("The feedback form was shown today."), !0) : (console.log("The feedback form was not shown today."), !1)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(A(Me))
            }
        }
        static {
            this.\u0275prov = N({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function at(t, a) {
    t & 1 && c(0, "app-skeleton-loader", 2), t & 2 && r("rows", 6)("columns", 3)
}

function st(t, a) {
    if (t & 1) {
        let e = F();
        l(0, "app-save-cancel-footer", 23), u("cancelClick", function() {
            C(e);
            let o = d(2);
            return b(o.cancel())
        }), s()
    }
    t & 2 && r("isVisibleHr", !1)
}

function lt(t, a) {
    if (t & 1) {
        let e = F();
        l(0, "app-edit-back-btn", 24), u("editClick", function() {
            C(e);
            let o = d(2);
            return b(o.setEditMode())
        }), s()
    }
}

function dt(t, a) {
    if (t & 1) {
        let e = F();
        l(0, "app-dx-outline-button", 41), u("click", function() {
            C(e);
            let o = d().index,
                p = d(2);
            return b(p.removeCustomFields(o))
        }), s()
    }
    t & 2 && r("isVisibleIcon", !0)
}

function ct(t, a) {
    if (t & 1) {
        let e = F();
        l(0, "app-control-container", 38)(1, "dx-tag-box", 42), u("onCustomItemCreating", function(o) {
            C(e);
            let p = d(3);
            return b(p.createTag(o))
        }), s()()
    }
    if (t & 2) {
        let e = d(3);
        r("errorMsg", e.formatMessage("error_dropdown_items_required"))("label", e.formatMessage("label_dropdown_items")), n(), r("acceptCustomValue", !0)("placeholder", e.formatMessage("placeholder_dropdown_items"))("readOnly", !e.isEditMode)
    }
}

function mt(t, a) {
    if (t & 1) {
        let e = F();
        l(0, "div", 3)(1, "div", 25)(2, "h2", 26)(3, "div", 27)(4, "button", 28)(5, "span"), le(6), s()(), f(7, dt, 1, 1, "app-dx-outline-button", 29), s()(), l(8, "div", 30)(9, "div", 31)(10, "div", 11)(11, "app-control-container", 32)(12, "dx-select-box", 33), u("onSelectionChanged", function(o) {
            let p = C(e).index,
                v = d(2);
            return b(v.addExtraFields(o, p))
        }), s()(), l(13, "app-control-container", 34), c(14, "app-switch-btn", 35), s(), l(15, "app-control-container", 36), c(16, "dx-text-box", 37), s(), f(17, ct, 2, 5, "app-control-container", 38), l(18, "app-control-container", 39), c(19, "dx-text-box", 40), s()()()()()()
    }
    if (t & 2) {
        let e = a.$implicit,
            i = a.index,
            o = d(2);
        r("formGroup", e), n(4), r("title", o.formatMessage("accordion_field_info_title")), ne("data-bs-target", "#customField" + i), n(2), de(" ", (e.controls.field_name == null ? null : e.controls.field_name.value) ? ? o.formatMessage("accordion_field_no") + (i + 1)), n(), _(o.isEditMode ? 7 : -1), n(), r("id", fe("customField", i)), n(3), r("errorMsg", o.formatMessage("error_field_type_required")), n(), r("items", o.formFieldList)("placeholder", o.formatMessage("label_field_type"))("readOnly", !o.isEditMode), n(), r("errorMsg", o.formatMessage("error_is_required_required"))("label", o.formatMessage("label_is_required")), n(), r("isEditMode", o.isEditMode), n(), r("errorMsg", o.formatMessage("error_field_name_required"))("label", o.formatMessage("label_field_name")), n(), r("placeholder", o.formatMessage("label_field_name"))("readOnly", !o.isEditMode), n(), _(o.isDropdown && o.dummyArrayToTrackFields.includes(i) ? 17 : -1), n(), r("errorMsg", o.formatMessage("error_placeholder_required"))("label", o.formatMessage("label_placeholder")), n(), r("placeholder", o.formatMessage("placeholder_placeholder"))("readOnly", !o.isEditMode)
    }
}

function pt(t, a) {
    if (t & 1 && c(0, "app-server-error", 22), t & 2) {
        let e = d(2);
        r("errorResponse", e.errorResponse)
    }
}

function ut(t, a) {
    if (t & 1) {
        let e = F();
        l(0, "form", 4), u("ngSubmit", function() {
            C(e);
            let o = d();
            return b(o.onAddCustomField())
        }), c(1, "app-section-title", 5)(2, "app-alert-panel", 6), l(3, "div", 7)(4, "div", 8), f(5, st, 1, 1, "app-save-cancel-footer", 9)(6, lt, 1, 0, "app-edit-back-btn", 10), s()(), l(7, "div", 11)(8, "app-dx-outline-button", 12), u("click", function() {
            C(e);
            let o = d();
            return b(o.addCustomFields())
        }), s(), l(9, "div", 13)(10, "div")(11, "app-control-container", 14), c(12, "dx-text-box", 15), s()(), l(13, "div")(14, "app-control-container", 16), c(15, "dx-date-box", 17), s()(), l(16, "div")(17, "app-control-container", 18), c(18, "dx-text-area", 19), s()(), l(19, "div", 20), w(20, mt, 20, 23, "div", 21), s()()(), f(21, pt, 1, 1, "app-server-error", 22), s()
    }
    if (t & 2) {
        let e = d();
        r("formGroup", e.form), n(), r("title", "add_feedback_fields"), n(), r("message", e.formatMessage("alert")), n(3), _(e.isEditMode ? 5 : 6), n(3), r("disabled", !e.isEditMode), n(3), r("errorMsg", e.formatMessage("title_required"))("label", e.formatMessage("title_name")), n(), r("readOnly", !e.isEditMode)("placeholder", e.formatMessage("type_a_title")), n(2), r("errorMsg", e.formatMessage("ends_at_required"))("label", e.formatMessage("ends_at")), n(), r("placeholder", ue(e.formatMessage("common_placeholders_ends_at")))("dateSerializationFormat", e.DATETIME_SERIALIZATION_FORMAT)("displayFormat", "dd-MMM-yyyy")("readOnly", !e.isEditMode)("pickerType", e.isMobileDevice ? "rollers" : "calendar"), n(2), r("errorMsg", e.formatMessage("description_required"))("label", e.formatMessage("description")), n(), r("autoResizeEnabled", !0)("disabled", !e.isEditMode)("placeholder", e.formatMessage("placeholder_description")), n(2), r("ngForOf", e.form.get("fields").controls), n(), _(e.errorResponse ? 21 : -1)
    }
}
var te = (() => {
    class t {
        constructor(e) {
            this.route = e, this.isCreate = !0, this.isEditMode = !1, this.today = new Date, this.isMobileDevice = m(z).isMobileDevice(), this.errorResponse = null, this.formFieldList = Object.values(y), this.toastNotificationService = m(M), this.formService = m(Oe), this.feedbackFormService = m(T), this.isSaving = P(!1), this.isDropdown = !1, this.dummyArrayToTrackFields = [], this.dropDownItems = [], this.formatMessage = h, this.DATETIME_SERIALIZATION_FORMAT = Fe
        }
        ngOnInit() {
            let e = this.route.snapshot.paramMap.get("id"),
                i = this.feedbackQuestionId || (e ? Number(e) : null);
            i ? (this.isCreate = !this.isCreate, this.feedbackFormService.getById(i).subscribe({
                next: o => {
                    this.form = g.getForm(new g(o ? ? {})), this.form.patchValue({
                        id: o.id
                    }), this.allCustomFields = o, this.form.disable()
                },
                error: o => console.error(o)
            })) : (this.form = g.getForm(new g({})), this.form.enable())
        }
        onAddCustomField() {
            if (!this.form.valid) {
                this.formService.validateFormFields(this.form);
                return
            }
            if (this.isSaving.set(!0), this.isCreate) this.feedbackFormService.saveFeedbackQuestionCustomField(this.form.value).subscribe({
                next: e => {
                    console.log("Created:", e), this.toastNotificationService.success("notification_custom_field_add_success"), this.isCreate = !1, this.allCustomFields = e, this.form = g.getForm(new g(e)), this.form.disable()
                },
                error: e => {
                    this.errorResponse = e
                },
                complete: () => {
                    this.isSaving.set(!1), this.isEditMode = !1
                }
            });
            else {
                let e = this.form.value.id;
                this.feedbackFormService.updateFeedbackQuestionCustomField(e, this.form.value).subscribe({
                    next: i => {
                        console.log("Updated:", i), this.toastNotificationService.success("notification_custom_field_update_success"), this.allCustomFields = i, this.form = g.getForm(new g(i)), this.form.disable(), this.isEditMode = !1
                    },
                    error: i => {
                        this.errorResponse = i
                    },
                    complete: () => {
                        this.isSaving.set(!1), this.isEditMode = !1
                    }
                })
            }
        }
        cancel() {
            this.form.disable(), this.isEditMode = !1
        }
        addExtraFields(e, i) {
            this.isDropdown = !1, this.dummyArrayToTrackFields = [], e.selectedItem === y.DROPDOWN && (this.isDropdown = !0, this.dummyArrayToTrackFields.push(i))
        }
        createTag(e) {
            e.customItem = e.text, this.dropDownItems.unshift(e.text)
        }
        removeCustomFields(e) {
            this.form.get("fields").removeAt(e)
        }
        addCustomFields() {
            this.isEditMode && this.form.get("fields").push(I.getForm(new I({})))
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(re(ge))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-feedback-question-detail"]
                ],
                standalone: !1,
                decls: 4,
                vars: 2,
                consts: [
                    [1, "row", "card", "px-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "card-body"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "mt-3", 3, "title"],
                    [3, "message"],
                    [1, "row", "mt-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["cancelBtnId", "settings-cancel", "saveBtnId", "settings-save", 3, "isVisibleHr"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit"],
                    [1, "row"],
                    ["buttonType", "default", "text", "button_add_new_field", 1, "m-1", 3, "click", "disabled"],
                    [1, "mt-2"],
                    ["name", "title", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "title", 3, "readOnly", "placeholder"],
                    ["name", "ends_at", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "ends_at", "type", "date", 3, "dateSerializationFormat", "displayFormat", "readOnly", "pickerType", "placeholder"],
                    ["name", "description", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["minHeight", "60", "maxHeight", "100", "formControlName", "description", 3, "autoResizeEnabled", "disabled", "placeholder"],
                    ["id", "accordionExample", 1, "accordion", "theme-secondary-bg"],
                    [3, "formGroup", 4, "ngFor", "ngForOf"],
                    [3, "errorResponse"],
                    ["cancelBtnId", "settings-cancel", "saveBtnId", "settings-save", 3, "cancelClick", "isVisibleHr"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit", 3, "editClick"],
                    [1, "accordion-item", "mb-3"],
                    [1, "accordion-header", "theme-secondary-bg"],
                    [1, "d-flex", "align-items-center", "theme-secondary-bg"],
                    ["aria-controls", "collapseOne", "aria-expanded", "true", "data-bs-toggle", "collapse", "type", "button", 1, "accordion-button", "theme-secondary-bg", 3, "title"],
                    ["buttonType", "default", "icon", "fa-thin fa-trash", "title", "delete", 3, "isVisibleIcon"],
                    ["data-bs-parent", "#accordionExample", 1, "accordion-collapse", "collapse", "show", 3, "id"],
                    [1, "accordion-body", "theme-secondary-bg"],
                    ["label", "Name", "name", "field_type", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg"],
                    ["formControlName", "field_type", "valueExpr", "", 3, "onSelectionChanged", "items", "placeholder", "readOnly"],
                    ["name", "is_field_required", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "is_field_required", 3, "isEditMode"],
                    ["name", "field_name", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "field_name", "id", "field_name_id", 3, "placeholder", "readOnly"],
                    ["name", "select_box_items", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["name", "placeholder", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "placeholder", "id", "placeholder", 3, "placeholder", "readOnly"],
                    ["buttonType", "default", "icon", "fa-thin fa-trash", "title", "delete", 3, "click", "isVisibleIcon"],
                    ["formControlName", "select_box_items", "id", "select-box-items-id", 3, "onCustomItemCreating", "acceptCustomValue", "placeholder", "readOnly"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "div", 0)(1, "div", 1), f(2, at, 1, 2, "app-skeleton-loader", 2), f(3, ut, 22, 24, "form", 3), s()()), i & 2 && (n(2), _(o.form ? -1 : 2), n(), _(o.form ? 3 : -1))
                },
                dependencies: [L, Be, Y, $, qe, Re, K, Z, we, Le, Ne, H, Ae, Ie, W, be, B, Q, G, q],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ze = (() => {
    class t {
        constructor() {
            this.formatMessage = h, this.responseData = [], this.feedbackFormService = m(T), this.toastNotificationService = m(M), this.router = m(j), this.ENTITIES = Se, this.columns = [{
                dataField: "id",
                caption: h("common_id"),
                width: 40,
                hidingPriority: 1,
                allowSorting: !0
            }, {
                dataField: "title",
                caption: h("common_title"),
                hidingPriority: 6,
                allowSorting: !0,
                alignment: "center"
            }, {
                dataField: "description",
                caption: h("description"),
                allowSorting: !1,
                visible: !0,
                hidingPriority: 0
            }, {
                dataField: "ends_at",
                caption: h("common_due_date"),
                allowSorting: !1,
                cellTemplate: "dateTimeTemplate",
                visible: !0,
                hidingPriority: 4
            }, {
                dataField: "responses_count",
                caption: h("feedback_response_count"),
                allowSorting: !1,
                visible: !0,
                hidingPriority: 5
            }, {
                dataField: "created_at",
                caption: h("common_created_on"),
                hidingPriority: 3,
                alignment: "center",
                visible: !0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                allowSorting: !1,
                cellTemplate: "actionTemplate",
                alignment: "center",
                width: 50,
                hidingPriority: 2
            }], this.CUSTOM_FORM_FIELD_LIST = y, this.PERMISSION_LIST = ye
        }
        ngOnInit() {
            this.feedbackFormService.getListByQuery().subscribe({
                next: e => {
                    this.responseData = e.data
                }
            })
        }
        onEdit(e) {
            this.router.navigate([`feedbacks/edit/${e.id}`])
        }
        create() {
            this.router.navigate(["feedbacks/create"])
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-feedback-list"]
                ],
                standalone: !1,
                decls: 1,
                vars: 8,
                consts: [
                    [3, "dataGridEditClick", "dataGridAddNewClick", "columns", "service", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "writeAccessPermissionName", "deleteAccessPermissionName", "isVisibleEditAction"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "app-data-grid", 0), u("dataGridEditClick", function(v) {
                        return o.onEdit(v)
                    })("dataGridAddNewClick", function() {
                        return o.create()
                    }), s()), i & 2 && r("columns", o.columns)("service", o.feedbackFormService)("entity", o.ENTITIES.FEEDBACKS_FORMS)("isVisibleAddAction", !0)("isVisibleDeleteAction", !0)("writeAccessPermissionName", o.PERMISSION_LIST.EMPLOYEE_WRITE)("deleteAccessPermissionName", o.PERMISSION_LIST.EMPLOYEE_WRITE)("isVisibleEditAction", !0)
                },
                dependencies: [Qe],
                encapsulation: 2
            })
        }
    }
    return t
})();

function He(t) {
    if (!t || typeof t != "string") return console.error("[SubdomainUtil] Invalid origin provided:", t), "";
    try {
        let a = t.indexOf("/") + 2,
            e = t.indexOf(".");
        if (a < 2 || e === -1 || e <= a) return "";
        let i = t.substring(a, e);
        return /^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/i.test(i) ? i : (console.warn(`[SubdomainUtil] Invalid subdomain format: "${i}" from origin: "${t}"`), "")
    } catch (a) {
        return console.error("[SubdomainUtil] Error extracting subdomain from origin:", t, a), ""
    }
}
var We = (() => {
    class t {
        constructor(e) {
            this.router = e
        }
        canActivate() {
            try {
                let e = window.location.origin,
                    i = He(e),
                    o = localStorage.getItem("currentUser");
                if (!o) return console.error("User data not found in localStorage."), this.router.navigate(["/unauthorized"]), !1;
                let p = JSON.parse(o),
                    v = p ? .email,
                    ie = p ? .roles ? .[0] ? .is_employee,
                    Ke = X.feedbackModuleAllowedUsersEmail;
                return i === "demo" && v && Ke.includes(v) && ie === 1 || X.currentEnvironment === "staging" && ie === 1 ? !0 : (this.router.navigate(["/unauthorized"]), !1)
            } catch (e) {
                return console.error("Error parsing user data in bytephase-employee guard:", e), this.router.navigate(["/unauthorized"]), !1
            }
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(A(j))
            }
        }
        static {
            this.\u0275prov = N({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var ft = [{
        path: "",
        component: je,
        canActivate: [We],
        children: [{
            path: "list",
            component: ze
        }, {
            path: "create",
            component: te
        }, {
            path: "edit/:id",
            component: te
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    $e = (() => {
        class t {
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275mod = R({
                    type: t
                })
            }
            static {
                this.\u0275inj = V({
                    imports: [J.forChild(ft), J]
                })
            }
        }
        return t
    })();
var O = class {
    constructor(a) {
        return Object.assign(this, a)
    }
    static getForm(a) {
        return new U().group({
            id: [a.id || null],
            title: [a.title || null, [k.required]],
            custom_fields: D.getFormArray(a.custom_fields)
        })
    }
};
var Ye = () => ({
        "font-size": "0.7rem"
    }),
    Ze = () => ({});

function _t(t, a) {
    t & 1 && c(0, "app-skeleton-loader", 2), t & 2 && r("rows", 4)("columns", 2)
}

function ht(t, a) {
    if (t & 1 && c(0, "app-alert-panel", 3), t & 2) {
        let e = d(3);
        r("isVisibleCancelButton", !1)("message", e.formTypeFields == null ? null : e.formTypeFields.description)("ngStyle", e.isMobileDevice ? E(3, Ye) : E(4, Ze))
    }
}

function Ct(t, a) {
    if (t & 1 && (l(0, "div"), c(1, "dx-text-box", 11), s()), t & 2) {
        let e = d().index,
            i = d(3);
        n(), r("placeholder", i.checkPlaceholder(e) ? ? i.formatMessage("enter_value"))
    }
}

function bt(t, a) {
    if (t & 1 && (l(0, "div"), c(1, "dx-number-box", 12), s()), t & 2) {
        let e = d().index,
            i = d(3);
        n(), r("placeholder", i.checkPlaceholder(e) ? ? i.formatMessage("enter_number"))
    }
}

function gt(t, a) {
    if (t & 1 && (l(0, "div"), c(1, "dx-select-box", 13), s()), t & 2) {
        let e = d().index,
            i = d(3);
        n(), r("items", i.showDropdownItems(e))("placeholder", i.checkPlaceholder(e) ? ? i.formatMessage("select_value"))
    }
}

function vt(t, a) {
    if (t & 1 && (l(0, "div"), c(1, "dx-text-box", 14), s()), t & 2) {
        let e = d(4);
        n(), r("placeholder", e.formatMessage("default_your_value"))
    }
}

function Ft(t, a) {
    if (t & 1 && (l(0, "div", 8)(1, "app-control-container", 9), ae(2, 10), f(3, Ct, 2, 1, "div")(4, bt, 2, 1, "div")(5, gt, 2, 2, "div")(6, vt, 2, 1, "div"), se(), s()()), t & 2) {
        let e, i = a.$implicit,
            o = d(3);
        r("formGroup", i)("ngClass", o.hasColumn === 3 ? "col-sm-3 col-md-3 col-lg-3" : o.hasColumn === 4 ? "col-sm-4 col-md-4 col-lg-4" : o.hasColumn === 6 ? "col-sm-6 col-md-6 col-lg-6" : "col-sm-12 col-md-12 col-lg-12"), n(), r("errorMsg", (i.controls.label.value || o.formatMessage("value_required")) + o.formatMessage("is_required_field"))("label", i.controls.label.value ? ? "Value")("ngStyle", o.isMobileDevice ? E(6, Ye) : E(7, Ze)), n(2), _((e = i.controls.field_type.value) === o.FORM_FIELD_LIST.TEXT ? 3 : e === o.FORM_FIELD_LIST.NUMBER ? 4 : e === o.FORM_FIELD_LIST.DROPDOWN ? 5 : 6)
    }
}

function xt(t, a) {
    if (t & 1) {
        let e = F();
        f(0, ht, 1, 5, "app-alert-panel", 3), l(1, "div", 4)(2, "div", 5), w(3, Ft, 7, 8, "div", 6), s()(), l(4, "app-save-cancel-footer", 7), u("cancelClick", function() {
            C(e);
            let o = d(2);
            return b(o.onClosing())
        })("saveClick", function() {
            C(e);
            let o = d(2);
            return b(o.onSaving())
        }), s()
    }
    if (t & 2) {
        let e = d(2);
        _(e.formTypeFields.description ? 0 : -1), n(3), r("ngForOf", e.form.get("custom_fields").controls), n(), r("isOnPopup", !0)
    }
}

function yt(t, a) {
    if (t & 1 && (l(0, "div"), f(1, _t, 1, 2, "app-skeleton-loader", 2), f(2, xt, 5, 3), s()), t & 2) {
        let e = d();
        n(), _(e.form ? -1 : 1), n(), _(e.form ? 2 : -1)
    }
}
var Ai = (() => {
    class t {
        constructor() {
            this.formatMessage = h, this.isVisiblePopup = !1, this.isVisibleFeedbackPopup = !1, this.onPostClose = new oe, this.isSaving = P(!1), this.isSavedAction = !1, this.loaderService = m(Ee), this.feedbackFormService = m(T), this.toastNotificationService = m(M), this.isMobileDevice = m(z).isMobileDevice(), this.themeService = m(Pe), this.isDarkTheme = this.themeService.isDarkTheme(), this.newCustomFieldArr = [], this.FORM_FIELD_LIST = y
        }
        ngOnInit() {
            let e = localStorage.getItem("feedbackFormShown");
            if (e) {
                let i = new Date(e);
                if (Math.floor((new Date().getTime() - i.getTime()) / (1e3 * 60 * 60 * 24)) < 3) {
                    this.isVisiblePopup = !1;
                    return
                }
            }
            this.form = O.getForm(new O({})), this.feedbackFormService.getByType().subscribe({
                next: i => {
                    this.form.patchValue({
                        id: i.id
                    }), i ? .id && setTimeout(() => {
                        this.isVisiblePopup = this.isVisibleFeedbackPopup
                    }, 300), this.formTypeFields = i, this.formTypeFields && this.formTypeFields.fields ? .map(o => {
                        this.customField(o), this.newCustomFieldArr.push(o)
                    })
                },
                error: i => {
                    console.error(i)
                }
            })
        }
        checkPlaceholder(e) {
            return this.newCustomFieldArr[e] ? .placeholder ? ? null
        }
        showDropdownItems(e) {
            return this.newCustomFieldArr[e] ? .select_box_items ? ? null
        }
        customField(e) {
            this.form.get("custom_fields").push(D.getForm(new D({
                label: e.field_name,
                field_type: e.field_type,
                select_box_items: e.select_box_items
            }), e.is_field_required))
        }
        onClosing() {
            if (this.onPostClose.emit(!0), !this.isSavedAction && !this.feedbackFormService.isFeedbackFormShown()) {
                let e = new Date().toISOString().split("T")[0];
                localStorage.setItem("feedbackFormShown", e)
            }
            this.isVisiblePopup = !1, this.isSavedAction = !1
        }
        onSaving() {
            this.isSaving.set(!0), this.loaderService.show(), this.isSavedAction = !0, this.feedbackFormService.feedbackResponse(this.form.value).subscribe({
                next: e => {
                    this.toastNotificationService.success("notification_feedback_submit_success"), this.isVisiblePopup = !1
                },
                error: e => {
                    console.error(e), this.isSaving.set(!1), this.loaderService.hide(), this.toastNotificationService.showRaw({
                        message: e.error.errors["custom_fields.1.field_value"][0],
                        type: xe.ERROR
                    })
                },
                complete: () => {
                    this.loaderService.hide(), this.isSaving.set(!1)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-feedback-form"]
                ],
                inputs: {
                    form: "form",
                    formType: "formType",
                    hasColumn: "hasColumn",
                    isVisiblePopup: "isVisiblePopup",
                    isVisibleFeedbackPopup: "isVisibleFeedbackPopup"
                },
                outputs: {
                    onPostClose: "onPostClose"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [1, "profile-popover", 3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "isVisibleCancelButton", "message", "ngStyle"],
                    [2, "max-height", "calc(90vh - 230px)", "overflow-y", "auto"],
                    [1, "row"],
                    ["class", "d-flex gap-2", 3, "formGroup", "ngClass", 4, "ngFor", "ngForOf"],
                    [3, "cancelClick", "saveClick", "isOnPopup"],
                    [1, "d-flex", "gap-2", 3, "formGroup", "ngClass"],
                    ["name", "field_value", 1, "w-100", 3, "errorMsg", "label", "ngStyle"],
                    [1, "w-100"],
                    ["formControlName", "field_value", "id", "string-value", 3, "placeholder"],
                    ["formControlName", "field_value", "id", "number-value", 3, "placeholder"],
                    ["formControlName", "field_value", 3, "items", "placeholder"],
                    ["formControlName", "field_value", "id", "text-input-default", 3, "placeholder"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "dx-popup", 0), u("onHidden", function() {
                        return o.onClosing()
                    }), pe("visibleChange", function(v) {
                        return me(o.isVisiblePopup, v) || (o.isVisiblePopup = v), v
                    }), w(1, yt, 3, 2, "div", 1), s()), i & 2 && (ce("visible", o.isVisiblePopup), r("maxHeight", "90vh")("width", "95vw")("maxWidth", o.isMobileDevice ? 550 : 600)("title", o.isMobileDevice ? (o.formTypeFields == null ? null : o.formTypeFields.title) + " Feedback" : (o.formTypeFields == null ? null : o.formTypeFields.title) + " Feedback Form"), n(), r("dxTemplateOf", "content"))
                },
                dependencies: [_e, L, he, Y, $, K, Z, Te, Ve, De, H, W, B, Q, G, q],
                encapsulation: 2
            })
        }
    }
    return t
})();
var $i = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275mod = R({
                type: t
            })
        }
        static {
            this.\u0275inj = V({
                imports: [Ce, Ge, $e]
            })
        }
    }
    return t
})();
export {
    Ai as a, $i as b
};