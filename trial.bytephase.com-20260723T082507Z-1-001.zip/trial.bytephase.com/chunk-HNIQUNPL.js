var O = (function(N) {
        return N.Aztec = "AZTEC", N.Codabar = "CODABAR", N.Code39 = "CODE_39", N.Code93 = "CODE_93", N.Code128 = "CODE_128", N.DataMatrix = "DATA_MATRIX", N.Ean8 = "EAN_8", N.Ean13 = "EAN_13", N.Itf = "ITF", N.Pdf417 = "PDF_417", N.QrCode = "QR_CODE", N.UpcA = "UPC_A", N.UpcE = "UPC_E", N
    })(O || {}),
    E = (function(N) {
        return N.CalendarEvent = "CALENDAR_EVENT", N.ContactInfo = "CONTACT_INFO", N.DriversLicense = "DRIVERS_LICENSE", N.Email = "EMAIL", N.Geo = "GEO", N.Isbn = "ISBN", N.Phone = "PHONE", N.Product = "PRODUCT", N.Sms = "SMS", N.Text = "TEXT", N.Url = "URL", N.Wifi = "WIFI", N.Unknown = "UNKNOWN", N
    })(E || {});
var D = (function(N) {
    return N.Front = "FRONT", N.Back = "BACK", N
})(D || {});
export {
    O as a, E as b, D as c
};