import {
    M as E,
    Ma as U,
    Wd as f,
    _d as W,
    ca as q,
    ph as K
} from "./chunk-DCKGQUHB.js";
import {
    $a as M,
    Fa as a,
    Fh as C,
    Ib as n,
    Ig as P,
    Jb as o,
    Ka as d,
    Kb as b,
    Lb as w,
    Na as s,
    Oa as u,
    Oc as N,
    Pb as F,
    Qb as y,
    Rb as k,
    Tc as O,
    _a as D,
    _b as T,
    ba as c,
    ea as h,
    eb as g,
    fb as t,
    gb as i,
    gc as L,
    hb as v,
    hc as A,
    hi as G,
    pd as B,
    qa as _,
    qd as j,
    ub as I,
    vd as S,
    xk as p
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var V = (() => {
    class l {
        constructor(e) {
            this.service = e, this.formatMessage = p, this.entity = G.MAIL_MARKETING, this.columns = [{
                dataField: "id",
                caption: p("campaign_id"),
                width: 130,
                allowSorting: !0,
                alignment: "center"
            }, {
                dataField: "title",
                caption: p("campaign_title"),
                alignment: "center",
                allowSorting: !0
            }, {
                dataField: "subject",
                caption: p("campaign_subject"),
                allowSorting: !1
            }, {
                dataField: "preview_text",
                caption: p("preview_text"),
                allowSorting: !1
            }, {
                dataField: "from_name",
                caption: p("from_name"),
                allowSorting: !1
            }, {
                dataField: "preview",
                caption: p("template"),
                allowSorting: !1,
                alignment: "center",
                cellTemplate: "campaignTemplatePreview"
            }, {
                dataField: "archive_url",
                caption: p("open_mail"),
                allowSorting: !1,
                width: 130,
                cellTemplate: "openMailInNewTabTemplate",
                alignment: "center"
            }]
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || l)(d(f))
            }
        }
        static {
            this.\u0275cmp = s({
                type: l,
                selectors: [
                    ["app-campaign-list"]
                ],
                standalone: !1,
                decls: 1,
                vars: 4,
                consts: [
                    [3, "columns", "entity", "isVisibleClearFilterButton", "service"]
                ],
                template: function(r, m) {
                    r & 1 && v(0, "app-data-grid", 0), r & 2 && g("columns", m.columns)("entity", m.entity)("isVisibleClearFilterButton", !1)("service", m.service)
                },
                dependencies: [W],
                encapsulation: 2
            })
        }
    }
    return l
})();
var X = () => ({ of: "#commentForm"
});

function Y(l, $) {
    if (l & 1 && (t(0, "h3", 1), n(1, "Campaign Report"), i(), t(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h3"), n(7), L(8, "uppercase"), i()(), t(9, "div", 6)(10, "h5", 7), n(11), i(), t(12, "p", 8), n(13), i(), t(14, "p", 8), n(15), i(), t(16, "a", 9), n(17, "Login To Mailchimp"), i()(), t(18, "div", 10), n(19), i()()()(), t(20, "div", 11)(21, "div", 12)(22, "div", 13)(23, "div", 5), n(24, "Campaign Performance"), i(), t(25, "div", 6)(26, "div", 14)(27, "h5", 7), n(28, "\u2709\uFE0F Emails Sent"), i(), t(29, "span"), n(30), i()(), t(31, "div", 14)(32, "h5", 7), n(33, "\u26A0\uFE0F\uFE0F Abuse Reports"), i(), t(34, "span"), n(35), i()(), t(36, "div", 14)(37, "h5", 7), n(38, "\u{1F6AB} Unsubscribed"), i(), t(39, "span"), n(40), i()()()()(), t(41, "div", 12)(42, "div", 13)(43, "div", 5), n(44, "Bounce Statistics (When emails are undelivered)"), i(), t(45, "div", 6)(46, "div", 14)(47, "h5", 7), n(48, "\u{1F6D1} Hard Bounces"), i(), t(49, "span"), n(50), i()(), t(51, "div", 14)(52, "h5", 7), n(53, " \u{1F504} Soft Bounces"), i(), t(54, "span"), n(55), i()(), t(56, "div", 14)(57, "h5", 7), n(58, "\u274C Syntax Errors"), i(), t(59, "span"), n(60), i()()()()(), t(61, "div", 12)(62, "div", 13)(63, "div", 5), n(64, "Forwarding Stats (When recipients forward your email):"), i(), t(65, "div", 6)(66, "div", 14)(67, "h5", 7), n(68, " \u{1F501} Forwards Count"), i(), t(69, "span"), n(70), i()(), t(71, "div", 14)(72, "h5", 7), n(73, "\u{1F441}\uFE0F Forwards Opens"), i(), t(74, "span"), n(75), i()(), t(76, "div", 14)(77, "h5", 7), n(78, "Delivery Status (Enabled)"), i(), t(79, "span"), n(80), i()()()()(), t(81, "div", 12)(82, "div", 13)(83, "div", 5), n(84, "Open Statistics"), i(), t(85, "div", 6)(86, "div", 14)(87, "h5", 7), n(88, "\u{1F4C8} Opens Total"), i(), t(89, "span"), n(90), i()(), t(91, "div", 14)(92, "h5", 7), n(93, "\u{1F464} Unique Opens"), i(), t(94, "span"), n(95), i()(), t(96, "div", 14)(97, "h5", 7), n(98, "\u{1F4CA}Open Rate"), i(), t(99, "span"), n(100), i()(), t(101, "div", 14)(102, "h5", 7), n(103, " \u23F0 Last Open"), i(), t(104, "span"), n(105), i()()()()(), t(106, "div", 12)(107, "div", 13)(108, "div", 5), n(109, " Click Statistics"), i(), t(110, "div", 6)(111, "div", 14)(112, "h5", 7), n(113, "\u{1F4CA} Clicks Total"), i(), t(114, "span"), n(115), i()(), t(116, "div", 14)(117, "h5", 7), n(118, "\u{1F5B1} Unique Clicks\uFE0F"), i(), t(119, "span"), n(120), i()(), t(121, "div", 14)(122, "h5", 7), n(123, "\u{1F4C8} Click Rate"), i(), t(124, "span"), n(125), i()(), t(126, "div", 14)(127, "h5", 7), n(128, " \u23F0 Last Click"), i(), t(129, "span"), n(130), i()()()()(), t(131, "div", 12)(132, "div", 13)(133, "div", 5), n(134, " List Statistics (Statistics related to your mailing list)"), i(), t(135, "div", 6)(136, "div", 14)(137, "h5", 7), n(138, "\u{1F4C8} Subscription Rate"), i(), t(139, "span"), n(140), i()(), t(141, "div", 14)(142, "h5", 7), n(143, " \u{1F4C9} Unsubscription Rate"), i(), t(144, "span"), n(145), i()(), t(146, "div", 14)(147, "h5", 7), n(148, "\u{1F4EC} Open Rate"), i(), t(149, "span"), n(150), i()(), t(151, "div", 14)(152, "h5", 7), n(153, "\u{1F5B1}\uFE0F Click Rate"), i(), t(154, "span"), n(155), i()()()()()()), l & 2) {
        let e = I();
        a(7), w("", e.campaignReport.campaign_title, " - ", A(8, 27, e.campaignReport.id)), a(4), o(e.campaignReport == null ? null : e.campaignReport.campaign_title), a(2), o(e.campaignReport.subject_line), a(2), o(e.campaignReport.preview_text), a(4), b(" Audience List Name ", e.campaignReport.list_name, " "), a(11), o(e.campaignReport == null ? null : e.campaignReport.emails_sent), a(5), o(e.campaignReport == null ? null : e.campaignReport.abuse_reports), a(5), o(e.campaignReport == null ? null : e.campaignReport.unsubscribed), a(10), o(e.campaignReport == null || e.campaignReport.bounces == null ? null : e.campaignReport.bounces.hard_bounces), a(5), o(e.campaignReport == null || e.campaignReport.bounces == null ? null : e.campaignReport.bounces.soft_bounces), a(5), o(e.campaignReport == null || e.campaignReport.bounces == null ? null : e.campaignReport.bounces.soft_bounces), a(10), o(e.campaignReport == null || e.campaignReport.forwards == null ? null : e.campaignReport.forwards.forwards_count), a(5), o(e.campaignReport == null || e.campaignReport.forwards == null ? null : e.campaignReport.forwards.forwards_opens), a(5), o(e.campaignReport == null || e.campaignReport.delivery_status == null ? null : e.campaignReport.delivery_status.enabled), a(10), o(e.campaignReport == null || e.campaignReport.opens == null ? null : e.campaignReport.opens.opens_total), a(5), o(e.campaignReport == null || e.campaignReport.opens == null ? null : e.campaignReport.opens.unique_opens), a(5), o(e.campaignReport == null || e.campaignReport.opens == null ? null : e.campaignReport.opens.open_rate), a(5), o(e.campaignReport == null || e.campaignReport.opens == null ? null : e.campaignReport.opens.last_open), a(10), o(e.campaignReport == null || e.campaignReport.clicks == null ? null : e.campaignReport.clicks.clicks_total), a(5), o(e.campaignReport == null || e.campaignReport.clicks == null ? null : e.campaignReport.clicks.unique_clicks), a(5), o(e.campaignReport == null || e.campaignReport.clicks == null ? null : e.campaignReport.clicks.unique_subscriber_clicks), a(5), o(e.campaignReport == null || e.campaignReport.clicks == null ? null : e.campaignReport.clicks.click_rate), a(10), o(e.campaignReport == null || e.campaignReport.list_stats == null ? null : e.campaignReport.list_stats.sub_rate), a(5), o(e.campaignReport == null || e.campaignReport.list_stats == null ? null : e.campaignReport.list_stats.unsub_rate), a(5), o(e.campaignReport == null || e.campaignReport.list_stats == null ? null : e.campaignReport.list_stats.open_rate), a(5), o(e.campaignReport == null || e.campaignReport.list_stats == null ? null : e.campaignReport.list_stats.click_rate)
    }
}
var H = (() => {
    class l {
        constructor(e) {
            this.service = e, this.formatMessage = p, this.activatedRouter = h(B), this.toastNotificationService = h(q), this.campaignId = _(this.activatedRouter.snapshot ? .params ? .campaign_id ? ? null), this.isFetchingReport = !0, this.loaderLogo = P
        }
        ngOnInit() {
            this.service.getCampaignReportById(this.campaignId()).subscribe({
                next: e => {
                    this.campaignReport = e.data, this.isFetchingReport = !1
                },
                error: e => {
                    this.toastNotificationService.error("notification_report_fetch_error")
                }
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || l)(d(f))
            }
        }
        static {
            this.\u0275cmp = s({
                type: l,
                selectors: [
                    ["app-campaign-reports"]
                ],
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    [3, "visibleChange", "visible", "indicatorSrc", "message", "position", "showPane"],
                    [1, "m-2"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "card", "text-center"],
                    [1, "card-header"],
                    [1, "card-body"],
                    [1, "card-title"],
                    [1, "card-text"],
                    ["href", "https://login.mailchimp.com/", "target", "_blank", 1, "btn", "btn-light", "btn-sm", "link-without-effect"],
                    [1, "card-footer", "text-muted"],
                    [1, "row", "mt-5"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4"],
                    [1, "card", "mb-3"],
                    [1, "d-flex", "justify-content-between", "px-2"]
                ],
                template: function(r, m) {
                    r & 1 && (D(0, Y, 156, 29), t(1, "dx-load-panel", 0), k("visibleChange", function(x) {
                        return y(m.isFetchingReport, x) || (m.isFetchingReport = x), x
                    }), i()), r & 2 && (M(m.campaignReport ? 0 : -1), a(), F("visible", m.isFetchingReport), g("indicatorSrc", m.loaderLogo)("message", "")("position", T(6, X))("showPane", !1))
                },
                dependencies: [U, N],
                encapsulation: 2
            })
        }
    }
    return l
})();
var z = (() => {
    class l {
        static {
            this.\u0275fac = function(r) {
                return new(r || l)
            }
        }
        static {
            this.\u0275cmp = s({
                type: l,
                selectors: [
                    ["app-mail-marketing"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(r, m) {
                    r & 1 && (t(0, "div", 0), v(1, "router-outlet"), i())
                },
                dependencies: [j],
                encapsulation: 2
            })
        }
    }
    return l
})();
var Z = [{
        path: "",
        component: z,
        children: [{
            path: "list",
            component: V,
            canActivate: [E],
            data: {
                permissions: {
                    only: [C.MAIL_MARKETING_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Marketing Management"
        }, {
            path: ":campaign_id",
            component: H,
            canActivate: [E],
            data: {
                permissions: {
                    only: [C.MAIL_MARKETING_LIST]
                }
            }
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    J = (() => {
        class l {
            static {
                this.\u0275fac = function(r) {
                    return new(r || l)
                }
            }
            static {
                this.\u0275mod = u({
                    type: l
                })
            }
            static {
                this.\u0275inj = c({
                    imports: [S.forChild(Z), S]
                })
            }
        }
        return l
    })();
var Te = (() => {
    class l {
        static {
            this.\u0275fac = function(r) {
                return new(r || l)
            }
        }
        static {
            this.\u0275mod = u({
                type: l
            })
        }
        static {
            this.\u0275inj = c({
                imports: [O, J, K]
            })
        }
    }
    return l
})();
export {
    Te as MailMarketingModule
};