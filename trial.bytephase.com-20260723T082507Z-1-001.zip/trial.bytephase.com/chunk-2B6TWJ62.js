import {
    e as r,
    y as c
} from "./chunk-DCKGQUHB.js";
var n = class {
    constructor(e) {
        return Object.assign(this, e)
    }
    static getForm(e, u = !0) {
        return new c().group({
            id: [e.id || null],
            account_name: [e.account_name || null, u ? [r.required] : []],
            account_number: [e.account_number || null, u ? [r.required] : []],
            ifsc_code: [e.ifsc_code || null, u ? [r.required] : []],
            branch_name: [e.branch_name || null],
            bank_name: [e.bank_name || null, u ? [r.required] : []]
        })
    }
};
export {
    n as a
};