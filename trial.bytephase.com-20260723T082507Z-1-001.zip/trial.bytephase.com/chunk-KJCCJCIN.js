import {
    V as f,
    Z as m
} from "./chunk-DCKGQUHB.js";
import {
    aa as s,
    da as i,
    ei as u,
    sd as a
} from "./chunk-GOPIAW4V.js";
var j = (() => {
    class r {
        constructor(o, t, c) {
            this.authService = o, this.storageService = t, this.router = c
        }
        canActivate(o, t) {
            let c = t.url;
            return new Promise((n, h) => {
                this.authService.currentUser.subscribe({
                    next: e => e && e.type_id === u.EMPLOYEE ? n(!0) : (this.authService.redirectUrl = c, this.router.navigate(["/jobs"]), n(!1)),
                    error: e => {
                        console.error(e)
                    }
                }).add(() => {
                    h("Error processing")
                })
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || r)(i(m), i(f), i(a))
            }
        }
        static {
            this.\u0275prov = s({
                token: r,
                factory: r.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return r
})();
export {
    j as a
};