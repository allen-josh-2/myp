import {
    a as X
} from "./chunk-KTU2GBZL.js";
import {
    a as st,
    b as lt,
    c as ct
} from "./chunk-WIGXHFCU.js";
import "./chunk-XHP3KBJE.js";
import {
    a as Ze
} from "./chunk-MYGQO4K4.js";
import "./chunk-BLJF2YPR.js";
import "./chunk-RW3SLQZQ.js";
import {
    $b as zi,
    $e as Je,
    A as yi,
    Ae as H,
    Db as Ge,
    Dc as Qi,
    Ec as Zi,
    Fe as Le,
    Hc as we,
    Ic as Ji,
    Jc as Pe,
    Kb as Hi,
    Lb as ji,
    N as Fi,
    Pd as it,
    Q as ce,
    Rc as U,
    Sa as de,
    Sc as Xi,
    T as L,
    Ta as Oi,
    Ua as Bi,
    Va as De,
    Wa as Ni,
    Yg as tt,
    _b as qi,
    _e as Ae,
    _f as Y,
    aa as Ei,
    ab as Ai,
    ba as Gi,
    bb as A,
    ca as Z,
    cb as me,
    ch as ot,
    dh as nt,
    e as V,
    ed as Oe,
    g as q,
    h as B,
    ha as Me,
    hh as rt,
    i as Ie,
    k as y,
    ka as Qe,
    la as wi,
    lb as pe,
    mb as Ui,
    n as Si,
    oc as Yi,
    od as et,
    pb as Ri,
    ph as at,
    q as oe,
    qb as ae,
    sa as Pi,
    sb as R,
    t as z,
    tb as J,
    te as Be,
    u as N,
    uc as Ki,
    we as ue,
    x as xi,
    xb as Ee,
    yc as Wi,
    zc as $i,
    ze as Ne
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    $b as D,
    Ab as le,
    Ak as Li,
    Ba as pi,
    C as si,
    Ca as P,
    Eb as ee,
    Ec as O,
    Fa as n,
    Fb as fi,
    H as li,
    Ib as m,
    Jb as T,
    Ka as qe,
    Kb as b,
    Kc as j,
    Lb as ye,
    Lg as E,
    Na as w,
    Ng as re,
    Oa as Se,
    P as ci,
    Pg as $e,
    Rc as gi,
    Rd as Fe,
    Sa as K,
    Sd as ki,
    Tc as bi,
    Uh as ke,
    Wg as Vi,
    _a as p,
    _b as vi,
    ac as G,
    ba as be,
    bb as ze,
    bc as hi,
    cb as Ye,
    db as Ke,
    ea as x,
    eb as s,
    eh as Te,
    fb as r,
    fi as Mi,
    gb as a,
    gc as ie,
    ha as _,
    hb as v,
    hi as Ve,
    ia as f,
    ic as te,
    lb as ui,
    mb as _i,
    mc as W,
    n as ni,
    na as di,
    oc as M,
    pc as I,
    qa as C,
    qb as F,
    qd as Ii,
    r as ri,
    sa as mi,
    sb as h,
    sc as Ci,
    sd as ne,
    t as ai,
    th as Q,
    ub as l,
    vd as We,
    vi as Di,
    wd as Ti,
    xk as S,
    yb as xe,
    zb as se
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as oi
} from "./chunk-FBFWB55K.js";
var dt = (() => {
    class o {
        constructor(e, i) {
            this.service = e, this.deviceTypeService = i, this.formatMessage = S, this.formService = x(Ri), this.toastNotificationService = x(Z), this.isSaving = !1, this.DATETIME_SERIALIZATION_FORMAT = Fe
        }
        ngOnInit() {
            this.deviceTypeService.getList().subscribe({
                next: e => {
                    this.deviceTypes = e
                },
                error: e => {
                    console.error(e)
                }
            }), this.form = Je.getForm(new Je({}))
        }
        save() {
            this.form.valid ? (this.isSaving = !0, this.service.signedSchedulePickup(this.form.getRawValue()).subscribe({
                next: i => {
                    this.toastNotificationService.success("notification_pickup_schedule_success")
                },
                error: () => {
                    this.toastNotificationService.error("notification_pickup_schedule_error")
                },
                complete: () => {
                    this.isSaving = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)(qe(X), qe(et))
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-signed-schedule-pickup-basic-info"]
                ],
                standalone: !1,
                decls: 0,
                vars: 0,
                template: function(i, t) {},
                encapsulation: 2
            })
        }
    }
    return o
})();
var mt = (() => {
    class o {
        constructor() {
            this.formatMessage = S
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-guest"]
                ],
                standalone: !1,
                decls: 1,
                vars: 0,
                template: function(i, t) {
                    i & 1 && v(0, "router-outlet")
                },
                dependencies: [Ii],
                encapsulation: 2
            })
        }
    }
    return o
})();
var It = (o, d, e) => ({
        "card p-2 me-4 mt-4": o,
        "m-3": d,
        "device-card-dark-color": e
    }),
    Re = (o, d) => ({
        hint: o,
        placeholder: d
    }),
    ge = o => ({
        "text-black": o
    }),
    Xe = o => ({
        fontSize: o
    }),
    Ft = () => ({});

function Tt(o, d) {
    if (o & 1 && v(0, "img", 20), o & 2) {
        let e = l().$implicit,
            i = l(2);
        s("alt", e.name)("src", i.isDeviceImagePresent(e), P)
    }
}

function kt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div")(1, "div", 17)(2, "div", 18), h("click", function() {
            let t = _(e).$implicit,
                c = l(2);
            return f(c.onSelectDevice(t))
        }), r(3, "div", 19), p(4, Tt, 1, 2, "img", 20), r(5, "p", 21), m(6), a()()()()()
    }
    if (o & 2) {
        let e = d.$implicit,
            i = l(2);
        n(3), s("title", e.name), n(), u(i.isDeviceImagePresent(e) ? 4 : -1), n(), s("ngClass", D(5, ge, !i.isDarkTheme()))("ngStyle", D(7, Xe, i.isDeviceImagePresent(e) ? "0.8rem" : "1rem")), n(), b(" ", e.name, " ")
    }
}

function Vt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11)(1, "div", 12)(2, "h6"), m(3), a()(), r(4, "div", 13)(5, "dx-list", 14, 0), K(7, kt, 7, 9, "div", 8), a()(), r(8, "div", 15)(9, "app-save-btn", 16), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.backToLogin.emit())
        }), a()()()
    }
    if (o & 2) {
        let e = l();
        ee("height", e.isMobileDevice() ? "calc(100vh - 250px)" : "600px"), n(3), T(e.formatMessage("select_device_type")), n(2), s("dataSource", e.deviceTypeDataSource())("searchEnabled", !0)("searchEditorOptions", G(8, Re, e.formatMessage("device_type_placeholder"), e.formatMessage("device_type_placeholder"))), n(2), s("dxTemplateOf", "item"), n(2), s("useSubmitBehavior", !1)
    }
}

function Mt(o, d) {
    if (o & 1 && v(0, "img", 20), o & 2) {
        let e = l().$implicit,
            i = l(3);
        s("alt", e.name)("src", i.isDeviceImagePresent(e), P)
    }
}

function Dt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div")(1, "div", 17)(2, "div", 18), h("click", function() {
            let t = _(e).$implicit,
                c = l(3);
            return f(c.onSelectBrand(t))
        }), r(3, "div", 19), p(4, Mt, 1, 2, "img", 20), r(5, "p", 21), m(6), a()()()()()
    }
    if (o & 2) {
        let e = d.$implicit,
            i = l(3);
        n(3), s("title", e.name), n(), u(i.isDeviceImagePresent(e) ? 4 : -1), n(), s("ngClass", D(5, ge, !i.isDarkTheme()))("ngStyle", D(7, Xe, i.isDeviceImagePresent(e) ? "0.8rem" : "1rem")), n(), b(" ", e.name, " ")
    }
}

function Et(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 12)(1, "h6"), m(2), a(), r(3, "div", 17)(4, "div", 23), h("click", function() {
            _(e);
            let t = l(2);
            return f(t.onSelectOtherBrand())
        }), r(5, "div", 24), v(6, "i", 25), r(7, "p", 26), m(8), a()()()(), r(9, "small", 27), m(10), a()(), r(11, "div", 13)(12, "dx-list", 14, 0), K(14, Dt, 7, 9, "div", 8), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(2), T(e.formatMessage("select_device_brand")), n(2), s("title", e.formatMessage("if_brand_not_available_use_others")), n(3), s("ngClass", D(9, ge, !e.isDarkTheme())), n(), b(" ", e.formatMessage("common_other"), " "), n(2), T(e.formatMessage("brand_not_listed_select_other")), n(2), s("dataSource", e.deviceBrandDataSource())("searchEnabled", !0)("searchEditorOptions", G(11, Re, e.formatMessage("device_brand_placeholder_3"), e.formatMessage("device_brand_placeholder_3"))), n(2), s("dxTemplateOf", "item")
    }
}

function Gt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 28)(1, "h6"), m(2), a(), v(3, "dx-text-box", 29, 1), a(), r(5, "div", 30)(6, "app-save-btn", 31), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.isOtherBrandSelected.set(!1))
        }), a(), r(7, "app-save-btn", 32), h("saveBtnClick", function() {
            let t;
            _(e);
            let c = l(2);
            return f(c.onConfirmOtherBrand((t = c.deviceInformationFormGroup.get("custom_brand_name")) == null ? null : t.value))
        }), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(2), T(e.formatMessage("enter_brand_name")), n(), s("placeholder", e.formatMessage("device_brand_placeholder_2")), n(3), s("useSubmitBehavior", !1), n(), s("useSubmitBehavior", !1)
    }
}

function wt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11), p(1, Et, 15, 14)(2, Gt, 8, 4), r(3, "div", 15)(4, "app-save-btn", 22), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.showConfirmationPopup({
                title: "",
                id: t.activeBreadcrumb().id - 1
            }))
        }), a()()()
    }
    if (o & 2) {
        let e = l();
        ee("height", e.isMobileDevice() ? "calc(100vh - 250px)" : "600px"), n(), u(e.isOtherBrandSelected() ? 2 : 1), n(3), s("useSubmitBehavior", !1)
    }
}

function Pt(o, d) {
    if (o & 1 && v(0, "img", 20), o & 2) {
        let e = l().$implicit,
            i = l(3);
        s("alt", e.name)("src", i.isDeviceImagePresent(e), P)
    }
}

function Ot(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div")(1, "div", 17)(2, "div", 18), h("click", function() {
            let t = _(e).$implicit,
                c = l(3);
            return f(c.onSelectModel(t))
        }), r(3, "div", 19), p(4, Pt, 1, 2, "img", 20), r(5, "p", 21), m(6), a()()()()()
    }
    if (o & 2) {
        let e = d.$implicit,
            i = l(3);
        n(3), s("title", e.name), n(), u(i.isDeviceImagePresent(e) ? 4 : -1), n(), s("ngClass", D(5, ge, !i.isDarkTheme()))("ngStyle", D(7, Xe, i.isDeviceImagePresent(e) ? "0.8rem" : "1rem")), n(), b(" ", e.name, " ")
    }
}

function Bt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 12)(1, "h6"), m(2), a(), r(3, "div", 17)(4, "div", 23), h("click", function() {
            _(e);
            let t = l(2);
            return f(t.onSelectOtherModel())
        }), r(5, "div", 24), v(6, "i", 25), r(7, "p", 26), m(8), a()()()(), r(9, "small", 27), m(10), a()(), r(11, "div", 13)(12, "dx-list", 33, 0), K(14, Ot, 7, 9, "div", 8), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(2), T(e.formatMessage("select_model")), n(2), s("title", e.formatMessage("if_model_not_available_use_others")), n(3), s("ngClass", D(10, ge, !e.isDarkTheme())), n(), b(" ", e.formatMessage("common_other"), " "), n(2), T(e.formatMessage("model_not_listed_select_other")), n(2), s("noDataText", e.formatMessage("model_is_not_there"))("dataSource", e.deviceModelDataSource())("searchEnabled", !0)("searchEditorOptions", G(12, Re, e.formatMessage("device_model_placeholder_2"), e.formatMessage("device_model_placeholder_2"))), n(2), s("dxTemplateOf", "item")
    }
}

function Nt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 28)(1, "h6"), m(2), a(), v(3, "dx-text-box", 34), a(), r(4, "div", 30)(5, "app-save-btn", 31), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.isOtherModelSelected.set(!1))
        }), a(), r(6, "app-save-btn", 32), h("saveBtnClick", function() {
            let t;
            _(e);
            let c = l(2);
            return f(c.onConfirmOtherModel((t = c.deviceInformationFormGroup.get("custom_model_name")) == null ? null : t.value))
        }), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(2), T(e.formatMessage("enter_model_name")), n(), s("placeholder", e.formatMessage("model_name")), n(2), s("useSubmitBehavior", !1), n(), s("useSubmitBehavior", !1)
    }
}

function Lt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11), p(1, Bt, 15, 15)(2, Nt, 7, 4), r(3, "div", 15)(4, "app-save-btn", 22), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.showConfirmationPopup({
                title: "",
                id: t.activeBreadcrumb().id - 1
            }))
        }), a()()()
    }
    if (o & 2) {
        let e = l();
        ee("height", e.isMobileDevice() ? "calc(100vh - 250px)" : "600px"), n(), u(e.isOtherModelSelected() ? 2 : 1), n(3), s("useSubmitBehavior", !1)
    }
}

function At(o, d) {
    if (o & 1 && (r(0, "div", 35)(1, "div", 46)(2, "div")(3, "h5", 47), m(4), a(), r(5, "p", 48), m(6), a()()()()), o & 2) {
        let e = l(2);
        s("ngClass", e.isDarkTheme() ? "" : "bg-light"), n(4), T(e.selectedModel == null ? null : e.selectedModel.name), n(2), ye(" ", e.formatMessage("common_brand"), " : ", e.selectedBrand == null ? null : e.selectedBrand.name, " ")
    }
}

function Ut(o, d) {
    if (o & 1 && v(0, "app-alert-panel", 37), o & 2) {
        let e = l(2);
        s("message", e.formatMessage("no_repair_services_available"))("isVisibleCancelButton", !1)
    }
}

function Rt(o, d) {
    if (o & 1 && (r(0, "span", 62), v(1, "app-currency-symbol"), m(2), ie(3, "number"), a()), o & 2) {
        let e = l().$implicit;
        n(2), b(" ", te(3, 1, e.price, "1.0-0"), " ")
    }
}

function Ht(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div")(1, "div", 49)(2, "div", 50)(3, "div", 51), h("click", function() {
            let t = _(e).$implicit,
                c = l(2);
            return f(c.toggleServiceSelection(t))
        }), r(4, "div", 52)(5, "div", 53), v(6, "i", 54), a(), r(7, "div", 55)(8, "div", 56)(9, "div", 57)(10, "h6", 58), m(11), a()(), r(12, "div", 59), v(13, "input", 60), a()(), r(14, "div", 61), p(15, Rt, 4, 4, "span", 62), a()()()()()()()
    }
    if (o & 2) {
        let e = d.$implicit,
            i = l(2);
        n(3), fi("selected", i.isServiceSelected(e)), n(8), T(e.name), n(2), s("checked", i.isServiceSelected(e)), n(2), u(i.isSelfCheckinServicePriceEnabled() && e.price > 0 ? 15 : -1)
    }
}

function jt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11)(1, "div", 12), p(2, At, 7, 4, "div", 35), r(3, "h6", 36), m(4), a(), p(5, Ut, 1, 2, "app-alert-panel", 37), a(), r(6, "div", 38)(7, "app-control-container", 39), v(8, "app-textarea", 40), a()(), r(9, "div", 41)(10, "div", 38)(11, "p", 42), m(12), a()(), r(13, "div", 43)(14, "dx-list", 33, 0), K(16, Ht, 16, 5, "div", 8), a()()(), r(17, "div", 44)(18, "app-save-btn", 22), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.showConfirmationPopup({
                title: "",
                id: t.activeBreadcrumb().id - 1
            }))
        }), a(), r(19, "app-save-btn", 45), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.goToNextStep())
        }), a()()()
    }
    if (o & 2) {
        let e, i = l();
        ee("height", i.isMobileDevice() ? "calc(100vh - 250px)" : "600px"), n(2), u(i.getValueFromForm("device_model_id") ? 2 : -1), n(2), T(i.formatMessage("pick_your_repair_service")), n(), u(((e = i.filteredDeviceServices()) == null ? null : e.length) === 0 ? 5 : -1), n(2), s("label", i.formatMessage("device_issue_service_needed_label")), n(), s("placeholder", i.formatMessage("device_issue_placeholder")), n(4), T(i.formatMessage("service_type_placeholder")), n(2), s("noDataText", i.formatMessage("no_service_for_selected_model"))("dataSource", i.deviceServiceDataSource())("searchEnabled", !0)("searchEditorOptions", G(16, Re, i.formatMessage("service_type_placeholder_2"), i.formatMessage("service_type_placeholder_2"))), n(2), s("dxTemplateOf", "item"), n(2), s("useSubmitBehavior", !1), n(), s("isDisabled", i.isServiceMandatory() && i.selectedServices.length === 0)("useSubmitBehavior", !1)
    }
}

function qt(o, d) {
    if (o & 1 && (r(0, "app-control-container", 68), v(1, "dx-text-box", 77), a()), o & 2) {
        let e = l(2);
        s("errorMsg", e.formatMessage("serial_number_is_a_required_field"))("label", e.formatMessage("pcb_number_serial_number_2")), n(), s("placeholder", e.formatMessage("pcb_number_serial_number_2"))
    }
}

function zt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-control-container", 69)(1, "app-password", 78), h("onPatternLockClick", function() {
            _(e);
            let t = l(2);
            return f(t.onPatternLockClick())
        }), a()()
    }
    if (o & 2) {
        let e = l(2);
        s("label", e.formatMessage("device_password")), n(), s("disableAutoFill", !0)("isEditMode", !0)("formControl", e.formControlForDevicePassword)("placeholder", e.formatMessage("device_password"))
    }
}

function Yt(o, d) {
    if (o & 1 && (r(0, "app-control-container", 70)(1, "div", 79), v(2, "dx-number-box", 80)(3, "dx-select-box", 81), a()()), o & 2) {
        let e = l(2);
        s("errorMsg", e.formatMessage("capacity_is_a_required_field"))("label", e.formatMessage("capacity")), n(2), s("placeholder", e.formatMessage("capacity_placeholder")), n(), s("items", e.capacityMeasures)("searchEnabled", !1)
    }
}

function Kt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11)(1, "div", 13)(2, "dx-scroll-view", 63)(3, "div", 64)(4, "app-control-container", 65)(5, "dx-text-box", 66), v(6, "dxi-button", 67), a()(), p(7, qt, 2, 3, "app-control-container", 68), p(8, zt, 2, 5, "app-control-container", 69), p(9, Yt, 4, 5, "app-control-container", 70), r(10, "app-control-container", 71), v(11, "app-tag-box-with-images", 72), a(), r(12, "div", 73)(13, "p", 74), m(14), a(), v(15, "app-attachments", 75), a()()()(), r(16, "div", 44)(17, "app-save-btn", 22), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.showConfirmationPopup({
                title: "",
                id: t.activeBreadcrumb().id - 1
            }))
        }), a(), r(18, "app-save-btn", 76), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.deviceInformationFormCompleted.emit(1))
        }), a()()()
    }
    if (o & 2) {
        let e = l();
        ee("height", e.isMobileDevice() ? "calc(100vh - 250px)" : "600px"), n(4), s("label", e.formatMessage("serial_imei_number")), n(), s("placeholder", e.formatMessage("device_serial_number_placeholder")), n(), s("options", e.addSerialBarcodeScan), n(), u(e.isServiceRecovery() ? 7 : -1), n(), u(e.isDevicePasswordHidden() ? -1 : 8), n(), u(e.isServiceRecovery() ? 9 : -1), n(), s("label", e.formatMessage("accessories")), n(), s("products", e.filteredAccessories())("placeholder", "device_accessories_placeholder")("imageCategory", "accessory"), n(3), T(e.formatMessage("upload_device_type_image")), n(), s("entity", vi(24, Ft))("isEditMode", !0)("attachableType", e.attachableType)("isVisibleLabel", !1)("isCustomStoragePath", !0)("isPubliclyAccessible", !0)("isMultipleUploads", !0)("storagePathType", e.ENTITIES.CONTACT_US.name), n(2), s("useSubmitBehavior", !1), n(), s("isDisabled", e.deviceInformationFormGroup.invalid)("useSubmitBehavior", !1)
    }
}

function Wt(o, d) {
    o & 1 && (r(0, "div")(1, "p"), m(2, "Default content"), a()())
}

function $t(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div")(1, "p"), m(2), a(), r(3, "app-save-cancel-footer", 82), h("cancelClick", function() {
            _(e);
            let t = l();
            return f(t.navigateToSelectedBreadcrumb())
        })("saveClick", function() {
            _(e);
            let t = l();
            return f(t.onConfirmationPopupClosing())
        }), a()()
    }
    if (o & 2) {
        let e = l();
        n(2), T(e.formatMessage("confirm_navigation_title_text")), n(), s("saveText", "cancel")("useSubmitBehavior", !1)("cancelLabel", "common_go_back")
    }
}

function Qt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div")(1, "app-screen-pattern-lock", 84), h("onPatternLockSaveClick", function(t) {
            _(e);
            let c = l(2);
            return f(c.onPatternLockSaveClick(t))
        }), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(), s("isEditMode", !0)("lockPattern", e.lockPattern())
    }
}

function Zt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "dx-popup", 83), h("onHiding", function() {
            _(e);
            let t = l();
            return f(t.isPatternLockPopupOpen.set(!1))
        }), K(1, Qt, 2, 2, "div", 8), a()
    }
    if (o & 2) {
        let e = l();
        s("maxHeight", e.isMobileDevice ? 470 : 460)("width", "95vw")("maxWidth", 450)("title", e.formatMessage("pattern_lock"))("visible", e.isPatternLockPopupOpen()), n(), s("dxTemplateOf", "content")
    }
}

function Jt(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-qrcode-scanner", 85), h("scannerToSave", function(t) {
            _(e);
            let c = l();
            return f(c.addBarcodeNumberForSerialNumber(t))
        }), a()
    }
    if (o & 2) {
        let e = l();
        s("type", "get_barcode_number")("isVisiblePopup", e.isVisibleBarcodeScannerPopUp())
    }
}
var He = (() => {
    class o {
        constructor() {
            this.formatMessage = S, this.generalSettingDataService = x(Ge), this.isMobileDevice = x(L).isMobileDevice, this.isDarkTheme = x(U).isDarkTheme, this.guestSelfCheckInFormGroup = I(), this.deviceInformationControlList = I(), this.allDeviceTypeList = I(), this.allDeviceBrandList = I(), this.allDeviceModelList = I(), this.allAccessoriesList = I(), this.allRepairServicesList = I(), this.selectedServices = [], this.deviceInformationFormCompleted = M(), this.allDeviceInformationValue = M(), this.backToLogin = M(), this.deviceFormControlValues = {}, this.defaultImage = "/assets/images/default-device.jpg", this.capacityMeasures = Object.values(Te), this.selectedBreadcrumb = null, this.SETTINGS = Q, this.ENTITIES = Ve, this.attachableType = this.ENTITIES.CONTACT_US.name, this.isModelWiseServicePricing = C(this.generalSettingDataService.getGeneralSettingByKey(Q.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING) ? ? !1), this.isServiceRecovery = C(!1), this.filteredDeviceBrands = C(this.allDeviceBrandList()), this.filteredDeviceModels = C(this.allDeviceModelList()), this.selectedDeviceTypeId = C(null), this.filteredAccessories = W(() => {
                let e = this.selectedDeviceTypeId(),
                    i = this.allAccessoriesList() ? ? [];
                return e ? i.filter(t => t.device_type_id === e) : []
            }), this.filteredDeviceServices = C(this.isModelWiseServicePricing() ? [] : this.allRepairServicesList()), this.breadcrumbPath = C([{
                title: S("lead_device_info"),
                id: 0,
                clickable: !1
            }]), this.isConfirmationPopupOpen = C(!1), this.isPatternLockPopupOpen = C(!1), this.lockPattern = C(null), this.isSelfCheckinServicePriceEnabled = C(!1), this.isVisibleBarcodeScannerPopUp = C(!1), this.isDevicePasswordHidden = C(!!this.generalSettingDataService.getGeneralSettingByKey(Q.SELF_CHECK_IN_SETTINGS.HIDE_DEVICE_PASSWORD)), this.isServiceMandatory = C(!!this.generalSettingDataService.getGeneralSettingByKey(Q.SELF_CHECK_IN_SETTINGS.SERVICE_MANDATORY)), this.isOtherBrandSelected = C(!1), this.isOtherModelSelected = C(!1), this.activeBreadcrumb = W(() => {
                let e = this.breadcrumbPath();
                return e[e.length - 1]
            }), this.deviceTypeDataSource = W(() => new de({
                store: this.allDeviceTypeList() || [],
                paginate: !1
            })), this.deviceBrandDataSource = W(() => new de({
                store: this.filteredDeviceBrands() || [],
                paginate: !1
            })), this.deviceModelDataSource = W(() => new de({
                store: this.filteredDeviceModels() || [],
                paginate: !1
            })), this.deviceServiceDataSource = W(() => new de({
                store: this.filteredDeviceServices() || [],
                paginate: !1
            })), this.addSerialBarcodeScan = {
                icon: "fa-thin fa-barcode-read",
                type: "default",
                hint: S("scan_serial/_IMEI_number"),
                onClick: () => {
                    this.scanJob()
                }
            }
        }
        ngOnInit() {
            this.isModelWiseServicePricing.set(this.generalSettingDataService.getGeneralSettingByKey(Q.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING)), this.subscribeToIsRecoveryFormControl(), this.subscribeToDeviceInformationFormStatus(), this.subscribeToDeviceTypeChanges();
            let e = this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.GENERAL_SETTINGS.ENABLE_SELF_CHECKIN_REPAIR_SERVICE_PRICE);
            this.isSelfCheckinServicePriceEnabled.set(!!e)
        }
        get deviceInformationFormGroup() {
            return this.guestSelfCheckInFormGroup() ? .get("deviceInformationGroup")
        }
        get formControlForDevicePassword() {
            return this.deviceInformationFormGroup.controls.device_password
        }
        get selectedModel() {
            let e = this.getValueFromForm("device_model_id");
            return this.allDeviceModelList() ? .find(i => i.id === e)
        }
        get selectedBrand() {
            let e = this.getValueFromForm("device_brand_id");
            return this.allDeviceBrandList() ? .find(i => i.id === e)
        }
        scanJob() {
            this.isVisibleBarcodeScannerPopUp() ? (this.isVisibleBarcodeScannerPopUp.set(!1), setTimeout(() => {
                this.isVisibleBarcodeScannerPopUp.set(!0)
            }, 0)) : this.isVisibleBarcodeScannerPopUp.set(!0)
        }
        subscribeToDeviceTypeChanges() {
            let e = this.deviceInformationFormGroup.controls.device_type_id;
            this.selectedDeviceTypeId.set(e.value ? ? null), e.valueChanges.subscribe(i => {
                this.selectedDeviceTypeId.set(i ? ? null)
            })
        }
        subscribeToIsRecoveryFormControl() {
            let e = this.guestSelfCheckInFormGroup().controls.serviceOptionFormGroup ? .get("is_recovery");
            this.isServiceRecovery.set(!!e ? .value), e ? .valueChanges.subscribe(i => {
                this.isServiceRecovery.set(i)
            })
        }
        subscribeToDeviceInformationFormStatus() {
            this.deviceInformationFormGroup.statusChanges.subscribe(e => {
                if (e === "VALID") {
                    this.deviceFormControlValues.deviceType = this.allDeviceTypeList().find(k => k.id === this.deviceInformationFormGroup.controls.device_type_id.value);
                    let i = this.deviceInformationFormGroup.controls.device_brand_id.value,
                        t = this.deviceInformationFormGroup.controls.custom_brand_name ? .value;
                    this.deviceFormControlValues.deviceBrand = i ? this.allDeviceBrandList().find(k => k.id === i) : t ? {
                        name: t
                    } : null;
                    let c = this.deviceInformationFormGroup.controls.device_model_id.value,
                        g = this.deviceInformationFormGroup.controls.custom_model_name ? .value;
                    this.deviceFormControlValues.deviceModel = c ? this.allDeviceModelList().find(k => k.id === c) : g ? {
                        name: g
                    } : null, this.deviceFormControlValues.serialNumber = this.deviceInformationFormGroup.controls.serial_number ? .value, this.deviceFormControlValues.serialNumber2 = this.deviceInformationFormGroup.controls.serial_number_2 ? .value, this.deviceFormControlValues.size = this.deviceInformationFormGroup.controls.size ? .value, this.deviceFormControlValues.capacityMeasure = this.deviceInformationFormGroup.controls.capacity_measure ? .value, this.deviceFormControlValues.accessories = this.allAccessoriesList().filter(k => this.deviceInformationFormGroup.controls.accessories ? .value ? .includes(k.id)).map((k, je, ti) => je === ti.length - 1 ? `${k.name}.` : k.name).join(", "), this.deviceFormControlValues.repairables = this.allRepairServicesList().filter(k => this.deviceInformationFormGroup.controls.repairables ? .value ? .includes(k.id)).map(k => k.name)
                }
                this.allDeviceInformationValue.emit(this.deviceFormControlValues)
            })
        }
        clearFormControlValues(e) {
            for (let i = e + 1; i < this.deviceInformationControlList().length; i++) {
                let t = this.deviceInformationControlList()[i].name;
                this.isServiceRecovery() && t === "capacity_measure" || i > 0 && this.deviceInformationFormGroup ? .controls[t].patchValue(null)
            }
        }
        filterDeviceData(e) {
            this.filteredDeviceBrands.set(this.allDeviceBrandList().filter(i => i.device_type_id === e)), this.isModelWiseServicePricing() || this.filteredDeviceServices.set(this.allRepairServicesList().filter(i => i.device_type_id === e))
        }
        filterDeviceModel(e) {
            this.filteredDeviceModels.set(this.allDeviceModelList().filter(i => i.device_brand_id === e && i.device_type_id === this.getValueFromForm("device_type_id")))
        }
        truncateText(e) {
            return Ee.truncateText(21, 20, e)
        }
        addPathToBreadcrumb(e) {
            this.breadcrumbPath.update(i => [...i, e])
        }
        removePathFromBreadcrumb() {
            let e = this.breadcrumbPath().findIndex(t => t.id === this.selectedBreadcrumb.id),
                i = this.breadcrumbPath().slice(0, e + 1);
            this.selectedBreadcrumb = null, this.breadcrumbPath.set(i), this.clearFormControlValues(e), e === 0 ? (this.isOtherBrandSelected.set(!1), this.isOtherModelSelected.set(!1)) : e === 1 && this.isOtherModelSelected.set(!1)
        }
        addSelectedValueInForm(e, i) {
            this.deviceInformationFormGroup.get(e) ? .patchValue(i)
        }
        getValueFromForm(e) {
            return this.deviceInformationFormGroup.get(e).value
        }
        onSelectDevice(e) {
            let i = e.id;
            this.addPathToBreadcrumb({
                title: e.name,
                id: 1
            }), this.addSelectedValueInForm("device_type_id", i), this.filterDeviceData(i)
        }
        onSelectBrand(e) {
            let i = e.id;
            this.addPathToBreadcrumb({
                title: e.name,
                id: 2
            }), this.addSelectedValueInForm("device_brand_id", i), this.filterDeviceModel(i)
        }
        onSelectModel(e) {
            let i = e.id;
            this.addPathToBreadcrumb({
                title: e.name,
                id: 3
            }), this.addSelectedValueInForm("device_model_id", i), this.isModelWiseServicePricing() && this.filteredDeviceServices.set(this.allRepairServicesList().filter(t => t.device_model_id === i))
        }
        onSelectOtherBrand() {
            this.isOtherBrandSelected.set(!0), this.addSelectedValueInForm("device_brand_id", null), this.addSelectedValueInForm("custom_brand_name", "")
        }
        onConfirmOtherBrand(e) {
            e ? .trim() && (this.addSelectedValueInForm("custom_brand_name", e.trim()), this.deviceInformationFormGroup.get("device_brand_id") ? .clearValidators(), this.deviceInformationFormGroup.get("device_brand_id") ? .updateValueAndValidity(), this.addPathToBreadcrumb({
                title: e.trim(),
                id: 2
            }), this.isOtherBrandSelected.set(!1), this.isOtherModelSelected.set(!0), this.addSelectedValueInForm("device_model_id", null), this.addSelectedValueInForm("custom_model_name", ""))
        }
        onConfirmOtherModel(e) {
            if (!e ? .trim()) return;
            this.addSelectedValueInForm("custom_model_name", e.trim()), this.deviceInformationFormGroup.get("device_model_id") ? .clearValidators(), this.deviceInformationFormGroup.get("device_model_id") ? .updateValueAndValidity(), this.addPathToBreadcrumb({
                title: e.trim(),
                id: 3
            }), this.isOtherModelSelected.set(!1);
            let i = this.getValueFromForm("device_type_id");
            this.filteredDeviceServices.set(this.allRepairServicesList().filter(t => t.device_type_id === i))
        }
        onSelectOtherModel() {
            this.isOtherModelSelected.set(!0), this.addSelectedValueInForm("device_model_id", null), this.addSelectedValueInForm("custom_model_name", "")
        }
        addBarcodeNumberForSerialNumber(e) {
            this.deviceInformationFormGroup.controls.serial_number.setValue(e)
        }
        showConfirmationPopup(e) {
            this.selectedBreadcrumb = e, this.isConfirmationPopupOpen.set(!0)
        }
        onConfirmationPopupClosing() {
            this.isConfirmationPopupOpen.set(!1)
        }
        navigateToSelectedBreadcrumb() {
            if (!this.selectedBreadcrumb) return;
            let e = this.activeBreadcrumb().id;
            this.selectedBreadcrumb.id > e && this.breadcrumbPath.update(t => [...t, this.selectedBreadcrumb]), this.removePathFromBreadcrumb(), this.onConfirmationPopupClosing()
        }
        onPatternLockSaveClick(e) {
            this.deviceInformationFormGroup.controls.device_password.patchValue(e), this.isPatternLockPopupOpen.set(!1)
        }
        onPatternLockClick() {
            this.isPatternLockPopupOpen.set(!0)
        }
        onAddService(e) {
            let i = this.deviceInformationFormGroup.get("repairables") ? .value || [];
            i.includes(e.id) || this.deviceInformationFormGroup.get("repairables") ? .setValue([...i, e.id])
        }
        goToNextStep() {
            let i = this.activeBreadcrumb().id + 1;
            this.addPathToBreadcrumb({
                title: S("device_details"),
                id: i
            })
        }
        isDeviceImagePresent(e) {
            if (e ? .attachments ? .[0] ? .link) return e.attachments[0].link;
            let i;
            return "device_type_id" in e && "device_brand_id" in e ? i = "device-model" : "device_type_id" in e && !("device_brand_id" in e) ? i = "device-brand" : "accessory_type_id" in e ? i = "accessory" : i = "device-type", `assets/images/${i}-default.png`
        }
        toggleServiceSelection(e) {
            let i = this.deviceInformationFormGroup.get("repairables"),
                t = i ? .value || [];
            t.indexOf(e.id) > -1 ? (i.setValue(t.filter(g => g !== e.id)), this.selectedServices = this.selectedServices.filter(g => g.id !== e.id)) : (i.setValue([...t, e.id]), this.selectedServices.push(e))
        }
        isServiceSelected(e) {
            return this.selectedServices.some(i => i.id === e.id)
        }
        uploadAttachments(e) {
            this.attachmentInstance.syncNotes(e)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-device-information-form"]
                ],
                viewQuery: function(i, t) {
                    if (i & 1 && xe(Oe, 5), i & 2) {
                        let c;
                        se(c = le()) && (t.attachmentInstance = c.first)
                    }
                },
                inputs: {
                    guestSelfCheckInFormGroup: [1, "guestSelfCheckInFormGroup"],
                    deviceInformationControlList: [1, "deviceInformationControlList"],
                    allDeviceTypeList: [1, "allDeviceTypeList"],
                    allDeviceBrandList: [1, "allDeviceBrandList"],
                    allDeviceModelList: [1, "allDeviceModelList"],
                    allAccessoriesList: [1, "allAccessoriesList"],
                    allRepairServicesList: [1, "allRepairServicesList"]
                },
                outputs: {
                    deviceInformationFormCompleted: "deviceInformationFormCompleted",
                    allDeviceInformationValue: "allDeviceInformationValue",
                    backToLogin: "backToLogin"
                },
                standalone: !1,
                decls: 15,
                vars: 16,
                consts: [
                    ["list", ""],
                    ["otherBrandInput", ""],
                    ["id", "deviceInformationFormGroup", 3, "formGroup"],
                    [3, "ngClass"],
                    [1, "text-center", 3, "title"],
                    [3, "clickedBreadcrumb", "breadcrumbPath"],
                    [1, "d-flex", "flex-column", 3, "height"],
                    ["id", "confirmation-popup", 3, "onHidden", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["id", "pattern-lock-popup", 3, "maxHeight", "width", "maxWidth", "title", "visible"],
                    [3, "type", "isVisiblePopup"],
                    [1, "d-flex", "flex-column"],
                    [1, "flex-shrink-0"],
                    [1, "flex-grow-1", "overflow-hidden"],
                    ["height", "100%", "searchExpr", "name", "searchMode", "contains", 3, "dataSource", "searchEnabled", "searchEditorOptions"],
                    [1, "self-checkin-actions", "d-flex", "mt-auto", "p-3", "flex-shrink-0"],
                    ["icon", "fa-solid fa-arrow-left me-1", "saveText", "back_to_login", 3, "saveBtnClick", "useSubmitBehavior"],
                    [1, "d-flex", "flex-wrap", "gap-3"],
                    [1, "card-with-selection", "p-3", "d-flex", "justify-content-center", "align-items-center", "text-center", "rounded", "shadow-sm", 2, "width", "120px", "height", "120px", 3, "click"],
                    [1, "device-card-content", "d-flex", "flex-column", "align-items-center", "justify-content-center", "gap-2", 3, "title"],
                    ["width", "40px", "height", "40px", "loading", "lazy", 1, "device-card-image", 3, "alt", "src"],
                    [1, "mb-0", "text-wrap", "device-card-text", 3, "ngClass", "ngStyle"],
                    ["icon", "fa-solid fa-arrow-left me-1", "saveText", "previous", 3, "saveBtnClick", "useSubmitBehavior"],
                    [1, "card-with-selection", "p-3", "d-flex", "justify-content-center", "align-items-center", "text-center", "rounded", "shadow-sm", 2, "width", "120px", "height", "120px", "cursor", "pointer", 3, "click", "title"],
                    [1, "device-card-content", "d-flex", "flex-column", "align-items-center", "justify-content-center", "gap-2"],
                    [1, "fa-thin", "fa-plus"],
                    [1, "mb-0", "device-card-text", 3, "ngClass"],
                    [1, "text-muted", "d-block", "mt-1", "mb-3"],
                    [1, "flex-shrink-0", "p-3"],
                    ["formControlName", "custom_brand_name", 3, "placeholder"],
                    [1, "self-checkin-actions", "d-flex", "justify-content-end", "p-3", "gap-3"],
                    ["saveText", "cancel", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "next", "suffixIcon", "fa-solid fa-arrow-right ms-1", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["height", "100%", "searchExpr", "name", "searchMode", "contains", 3, "noDataText", "dataSource", "searchEnabled", "searchEditorOptions"],
                    ["formControlName", "custom_model_name", 3, "placeholder"],
                    [1, "card", "p-3", "mb-3", "border", 3, "ngClass"],
                    [1, "fw-bold", "mb-3"],
                    [3, "message", "isVisibleCancelButton"],
                    [1, "flex-shrink-0", "px-2"],
                    ["name", "comment", 1, "mb-3", 3, "label"],
                    ["formControlName", "comment", 3, "placeholder"],
                    [1, "flex-grow-1", "overflow-hidden", "d-flex", "flex-column"],
                    [1, "mb-2"],
                    [1, "list-container", "flex-grow-1", "overflow-hidden"],
                    [1, "self-checkin-actions", "d-flex", "justify-content-between", "mt-auto", "p-3", "flex-shrink-0"],
                    ["saveText", "next", "suffixIcon", "fa-solid fa-arrow-right ms-1", 3, "saveBtnClick", "isDisabled", "useSubmitBehavior"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "mb-1", "fw-bold"],
                    [1, "mb-0", "small"],
                    [1, "row", "g-2", "mb-3"],
                    [1, ""],
                    [1, "card-with-selection", "h-100", 3, "click"],
                    [1, "d-flex", "align-items-start", "gap-2"],
                    [1, "p-2"],
                    [1, "fa-solid", "fa-screwdriver-wrench", "fw-normal", "fs-6"],
                    [1, "flex-grow-1"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-1"],
                    [1, "w-75"],
                    [1, "fw-normal", "mb-0", "text-wrap", "truncate-text"],
                    [1, "form-check"],
                    ["type", "radio", "readonly", "", 1, "form-check-input", "pe-none", 3, "checked"],
                    [1, "d-flex", "align-items-baseline", "gap-2"],
                    [1, "fw-bold", "text-success"],
                    ["height", "100%", "width", "100%"],
                    [1, "row", "m-1"],
                    ["name", "serial_number", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "serial_number", "id", "guest-self-checkin-serial-number", 3, "placeholder"],
                    ["location", "after", "name", "serialNumberBarcodeScan", 3, "options"],
                    ["name", "serial_number_2", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "device_password", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["name", "size", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "accessories", "id", "customAccessoriesTagBox", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "accessories", 3, "products", "placeholder", "imageCategory"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "mt-3"],
                    [1, "mb-2", "fw-bold"],
                    ["formControlName", "attachments", "id", "device-information-attachment", "accept", "image/*,.dsn", 3, "entity", "isEditMode", "attachableType", "isVisibleLabel", "isCustomStoragePath", "isPubliclyAccessible", "isMultipleUploads", "storagePathType"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "next", 3, "saveBtnClick", "isDisabled", "useSubmitBehavior"],
                    ["formControlName", "serial_number_2", "id", "guest-self-checkin-serial-number_2", 3, "placeholder"],
                    ["id", "guest-self-checkin-device-password", 3, "onPatternLockClick", "disableAutoFill", "isEditMode", "formControl", "placeholder"],
                    [1, "input-group"],
                    ["aria-label", "Size of Device", "formControlName", "size", 1, "w-75", 3, "placeholder"],
                    ["formControlName", "capacity_measure", "searchMode", "startswith", 1, "form-control", "w-25", 3, "items", "searchEnabled"],
                    [3, "cancelClick", "saveClick", "saveText", "useSubmitBehavior", "cancelLabel"],
                    ["id", "pattern-lock-popup", 3, "onHiding", "maxHeight", "width", "maxWidth", "title", "visible"],
                    [3, "onPatternLockSaveClick", "isEditMode", "lockPattern"],
                    [3, "scannerToSave", "type", "isVisiblePopup"]
                ],
                template: function(i, t) {
                    if (i & 1 && (r(0, "div", 2)(1, "div", 3), v(2, "app-actionable-page-subtitle", 4), r(3, "app-breadcrumbs", 5), h("clickedBreadcrumb", function(g) {
                            return t.showConfirmationPopup(g)
                        }), a(), r(4, "div"), p(5, Vt, 10, 11, "div", 6)(6, wt, 5, 4, "div", 6)(7, Lt, 5, 4, "div", 6)(8, jt, 20, 19, "div", 6)(9, Kt, 19, 25, "div", 6)(10, Wt, 3, 0, "div"), a()()(), r(11, "dx-popup", 7), h("onHidden", function() {
                            return t.onConfirmationPopupClosing()
                        }), K(12, $t, 4, 4, "div", 8), a(), p(13, Zt, 2, 6, "dx-popup", 9), p(14, Jt, 1, 2, "app-qrcode-scanner", 10)), i & 2) {
                        let c;
                        s("formGroup", t.deviceInformationFormGroup), n(), s("ngClass", hi(12, It, !t.isMobileDevice(), t.isMobileDevice(), t.isDarkTheme())), n(), s("title", "device_information"), n(), s("breadcrumbPath", t.breadcrumbPath()), n(2), u((c = t.activeBreadcrumb().id) === 0 ? 5 : c === 1 ? 6 : c === 2 ? 7 : c === 3 ? 8 : c === 4 ? 9 : 10), n(6), s("visible", t.isConfirmationPopupOpen())("width", "95vw")("maxWidth", 500)("title", t.formatMessage("confirm_navigation_title")), n(), s("dxTemplateOf", "content"), n(), u(t.isPatternLockPopupOpen() ? 13 : -1), n(), u(t.isVisibleBarcodeScannerPopUp() ? 14 : -1)
                    }
                },
                dependencies: [O, j, wi, Me, Oi, De, q, B, oe, N, z, A, R, Oe, me, it, H, tt, Y, ot, Xi, Le, qi, nt, Yi, Zi, Ai, zi, gi],
                styles: ["#repairServicesTagBox[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined{height:auto}#customAccessoriesTagBox[_ngcontent-%COMP%]     .dx-texteditor.dx-editor-outlined{height:auto}#deviceInformationFormGroup[_ngcontent-%COMP%]     .dx-list-item{width:auto}#deviceInformationFormGroup[_ngcontent-%COMP%]     .dx-list-items{display:flex;flex-wrap:wrap;flex-direction:row}#deviceInformationFormGroup[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{display:block;margin-left:auto;margin-right:auto}#deviceInformationFormGroup[_ngcontent-%COMP%]   .flex-grow-1[_ngcontent-%COMP%]{min-height:0}#deviceInformationFormGroup[_ngcontent-%COMP%]   .device-card-text[_ngcontent-%COMP%]{width:80px;white-space:normal;word-wrap:break-word;overflow:visible}  .list-container .dx-list-items{display:grid!important;grid-template-columns:repeat(3,1fr);gap:10px}@media(max-width:768px){  .list-container .dx-list-items{grid-template-columns:repeat(1,1fr)!important}#deviceInformationFormGroup[_ngcontent-%COMP%]     .dx-list-items{flex-direction:column!important;align-items:stretch!important}#deviceInformationFormGroup[_ngcontent-%COMP%]     .dx-list-item{width:100%!important}#deviceInformationFormGroup[_ngcontent-%COMP%]   .d-flex.flex-wrap[_ngcontent-%COMP%]{flex-direction:column!important}#deviceInformationFormGroup[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]{width:100%!important;max-width:100%!important;height:auto!important;text-align:left!important;justify-content:flex-start!important}#deviceInformationFormGroup[_ngcontent-%COMP%]   .device-card-content[_ngcontent-%COMP%]{flex-direction:row!important;justify-content:flex-start!important;align-items:center!important;gap:12px!important;width:100%!important}#deviceInformationFormGroup[_ngcontent-%COMP%]   .device-card-image[_ngcontent-%COMP%]{flex-shrink:0}#deviceInformationFormGroup[_ngcontent-%COMP%]   .device-card-text[_ngcontent-%COMP%]{width:100%!important;max-width:100%!important;white-space:normal!important;word-wrap:break-word!important;overflow:visible!important;text-align:left!important}}@media(max-width:1200px)and (min-width:769px){  .list-container .dx-list-items{grid-template-columns:repeat(2,1fr)!important}}"]
            })
        }
    }
    return o
})();
var to = (o, d) => ({
    background: o,
    color: d
});

function oo(o, d) {
    if (o & 1 && v(0, "app-alert-panel", 4), o & 2) {
        let e = l();
        s("message", e.formatMessage("self_checkin_basic_information_note"))("isVisibleCancelButton", !1)
    }
}

function no(o, d) {
    if (o & 1 && v(0, "app-address", 12), o & 2) {
        let e = l();
        s("parentForm", e.basicInformationGroup())("isAddressOptional", !e.isAddressMandatory())("isHrVisible", !1)("hideCity", e.hideCity())("hideState", e.hideState())("hidePostalCode", e.hidePostalCode())
    }
}

function ro(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-save-btn", 21), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.onSkipPickupAndSubmit())
        }), a()
    }
    o & 2 && s("useSubmitBehavior", !1)
}

function ao(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-save-btn", 22), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.onSkipPickup())
        }), a()
    }
    o & 2 && s("useSubmitBehavior", !1)
}

function so(o, d) {
    if (o & 1 && p(0, ro, 1, 1, "app-save-btn", 19)(1, ao, 1, 1, "app-save-btn", 20), o & 2) {
        let e = l();
        u(e.isLoggedIn() ? 0 : 1)
    }
}

function lo(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-save-btn", 26), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.onSkipPickupAndSubmit())
        }), a()
    }
    o & 2 && s("useSubmitBehavior", !1)
}

function co(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-save-btn", 27), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.onSkipPickup())
        }), a()
    }
    o & 2 && s("useSubmitBehavior", !1)
}

function mo(o, d) {
    if (o & 1) {
        let e = F();
        p(0, lo, 1, 1, "app-save-btn", 23), p(1, co, 1, 1, "app-save-btn", 24), r(2, "app-save-btn", 25), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.onNextStep())
        }), a()
    }
    if (o & 2) {
        let e = l();
        u(e.isLoggedIn() && !e.isAddressMandatory() ? 0 : -1), n(), u(!e.isLoggedIn() && !e.isAddressMandatory() ? 1 : -1), n(), s("useSubmitBehavior", !1)
    }
}
var ft = (() => {
    class o {
        constructor() {
            this.formatMessage = S, this.isMobileDevice = x(L).isMobileDevice, this.isDarkTheme = x(U).isDarkTheme, this.basicInformationGroup = I(), this.guestSelfCheckInFormGroup = I(), this.isLoggedIn = I(), this.isOTPVerified = I(), this.isAddressMandatory = I(!1), this.hideCity = I(!1), this.hideState = I(!1), this.hidePostalCode = I(!1), this.showAddressOnBasicInfo = I(!1), this.hidePickup = I(!1), this.goToVerifyUserForm = M(), this.goToAddPickupStep = M(), this.goToDeviceInformationForm = M(), this.skipPickupAndSubmit = M(), this.verifiedUserBy = C(null), this.isSubmitted = C(!1), this.VERIFY_USER_TYPE_LIST = E
        }
        get formControlForName() {
            return this.basicInformationGroup().controls.name
        }
        get formControlForEmail() {
            return this.basicInformationGroup().controls.email
        }
        get formControlForMobileNumber() {
            return this.basicInformationGroup().controls.mobile_number
        }
        get verifyUserFormGroup() {
            return this.guestSelfCheckInFormGroup() ? .get("verifyUserGroup")
        }
        ngOnChanges(e) {
            e ? .isOTPVerified ? .currentValue && (this.verifyUserFormGroup.controls.verify_type.value === E.MOBILE ? this.verifiedUserBy.set(E.MOBILE) : this.verifyUserFormGroup.controls.verify_type.value === E.EMAIL && this.verifiedUserBy.set(E.EMAIL))
        }
        onNextStep() {
            this.isSubmitted.set(!0), this.basicInformationGroup().valid && (this.goToAddPickupStep.emit(2), this.guestSelfCheckInFormGroup().controls.pickupInformationGroup.get("is_pickup_booked").patchValue(!0))
        }
        onSkipPickupAndSubmit() {
            this.isSubmitted.set(!0), this.basicInformationGroup().valid && this.skipPickupAndSubmit.emit()
        }
        onSkipPickup() {
            this.isSubmitted.set(!0), this.basicInformationGroup().valid && this.goToVerifyUserForm.emit(3)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-basic-information-form"]
                ],
                inputs: {
                    basicInformationGroup: [1, "basicInformationGroup"],
                    guestSelfCheckInFormGroup: [1, "guestSelfCheckInFormGroup"],
                    isLoggedIn: [1, "isLoggedIn"],
                    isOTPVerified: [1, "isOTPVerified"],
                    isAddressMandatory: [1, "isAddressMandatory"],
                    hideCity: [1, "hideCity"],
                    hideState: [1, "hideState"],
                    hidePostalCode: [1, "hidePostalCode"],
                    showAddressOnBasicInfo: [1, "showAddressOnBasicInfo"],
                    hidePickup: [1, "hidePickup"]
                },
                outputs: {
                    goToVerifyUserForm: "goToVerifyUserForm",
                    goToAddPickupStep: "goToAddPickupStep",
                    goToDeviceInformationForm: "goToDeviceInformationForm",
                    skipPickupAndSubmit: "skipPickupAndSubmit"
                },
                standalone: !1,
                features: [mi],
                decls: 29,
                vars: 49,
                consts: [
                    [3, "formGroup"],
                    [3, "ngClass", "ngStyle"],
                    [3, "title"],
                    [1, "row"],
                    [3, "message", "isVisibleCancelButton"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "isReadOnly"],
                    [3, "formControl", "readOnly", "placeholder"],
                    [3, "displayError", "errorMsg"],
                    ["name", "mobile_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "isReadOnly"],
                    [3, "formControl", "form", "isEditMode", "isUniqueValidation", "validateFormat"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "isReadOnly"],
                    [3, "formControl", "isEditMode", "isUniqueValidation", "validateFormat"],
                    [3, "parentForm", "isAddressOptional", "isHrVisible", "hideCity", "hideState", "hidePostalCode"],
                    [1, "row", "mt-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "flex-wrap", "overflow-auto", "border", "rounded", "p-3", 2, "max-height", "40vh", 3, "innerHTML"],
                    [3, "ngClass"],
                    ["formControlName", "agree_term_and_conditions", 1, "required", 3, "text"],
                    [1, "self-checkin-actions", "d-flex", "justify-content-end", "gap-3", "p-3"],
                    ["icon", "fa-solid fa-arrow-left", "saveText", "previous", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "common_submit", 3, "useSubmitBehavior"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "continue", 3, "useSubmitBehavior"],
                    ["saveText", "common_submit", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "continue", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "self_checkin_skip_pickup_and_submit_button", 3, "useSubmitBehavior"],
                    ["saveText", "self_checkin_skip_pickup_button", 3, "useSubmitBehavior"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "schedule_pickup", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "self_checkin_skip_pickup_and_submit_button", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "self_checkin_skip_pickup_button", 3, "saveBtnClick", "useSubmitBehavior"]
                ],
                template: function(i, t) {
                    if (i & 1 && (r(0, "div", 0)(1, "div", 1), v(2, "app-actionable-page-subtitle", 2), r(3, "div", 3), p(4, oo, 1, 2, "app-alert-panel", 4), r(5, "app-control-container", 5), v(6, "dx-text-box", 6)(7, "app-error", 7), a(), r(8, "app-control-container", 8), v(9, "app-mobile-number", 9)(10, "app-error", 7)(11, "app-error", 7), a(), r(12, "app-control-container", 10), v(13, "app-email", 11)(14, "app-error", 7), a(), p(15, no, 1, 6, "app-address", 12), r(16, "div", 13)(17, "h6"), m(18), a(), v(19, "div", 14), ie(20, "safe"), a(), r(21, "div", 3)(22, "div", 15), v(23, "dx-check-box", 16)(24, "app-error", 7), a()()(), r(25, "div", 17)(26, "app-save-btn", 18), h("saveBtnClick", function() {
                            return t.goToDeviceInformationForm.emit()
                        }), a(), p(27, so, 2, 1)(28, mo, 3, 3), a()()()), i & 2) {
                        let c;
                        s("formGroup", t.basicInformationGroup()), n(), s("ngClass", t.isMobileDevice() ? "m-3" : "card p-2 me-4 mt-4")("ngStyle", G(46, to, t.isDarkTheme() ? "#10172A" : "#FFFFFF", t.isDarkTheme() ? "#FFFFFF" : "#000000")), n(), s("title", "basic_information"), n(2), u(t.isLoggedIn() ? -1 : 4), n(), s("errorMsg", t.formatMessage("common_error_messages_name_required"))("label", t.formatMessage("your_name"))("isReadOnly", t.isLoggedIn()), n(), s("formControl", t.formControlForName)("readOnly", t.isLoggedIn())("placeholder", t.formatMessage("employee_name_placeholder")), n(), s("displayError", t.formControlForName.hasError("invalidName"))("errorMsg", t.formatMessage("special_characters_not_allowed")), n(), s("errorMsg", t.formatMessage("mobile_number_is_a_required_field"))("label", t.formatMessage("common_mobile_number"))("isReadOnly", t.isLoggedIn()), n(), s("formControl", t.formControlForMobileNumber)("form", t.basicInformationGroup())("isEditMode", !(t.isLoggedIn() || t.verifiedUserBy() === t.VERIFY_USER_TYPE_LIST.EMAIL))("isUniqueValidation", !1)("validateFormat", !0), n(), s("displayError", t.isSubmitted() && t.formControlForMobileNumber.invalid && t.formControlForMobileNumber.errors.invalidPhoneNumber)("errorMsg", t.formatMessage("common_invalid_mobile_number")), n(), s("displayError", t.isSubmitted() && t.basicInformationGroup().errors && t.basicInformationGroup().errors.atLeastOne)("errorMsg", t.formatMessage("either_mobile_number_or_email_is_required_field")), n(), s("errorMsg", t.formatMessage("email_required_error"))("label", t.formatMessage("common_email_id"))("isReadOnly", t.isLoggedIn()), n(), s("formControl", t.formControlForEmail)("isEditMode", !(t.isLoggedIn() || t.verifiedUserBy() === t.VERIFY_USER_TYPE_LIST.EMAIL))("isUniqueValidation", !1)("validateFormat", !0), n(), s("displayError", t.isSubmitted() && t.basicInformationGroup().errors && t.basicInformationGroup().errors.atLeastOne)("errorMsg", t.formatMessage("either_mobile_number_or_email_is_required_field")), n(), u(t.showAddressOnBasicInfo() ? 15 : -1), n(3), T(t.formatMessage("common_terms_and_conditions")), n(), s("innerHTML", te(20, 43, (c = t.basicInformationGroup().get("term_and_condition")) == null ? null : c.value, "html"), pi), n(3), s("ngClass", t.isMobileDevice() ? "mb-4" : "mt-2"), n(), s("text", t.formatMessage("i_agree_to_your_terms_and_conditions_mentioned_above")), n(), s("displayError", t.isSubmitted() && t.basicInformationGroup().get("agree_term_and_conditions").invalid)("errorMsg", t.formatMessage("register_must_agree_terms")), n(2), s("useSubmitBehavior", !1), n(), u(t.hidePickup() ? 27 : 28)
                    }
                },
                dependencies: [O, j, De, q, B, oe, N, z, ae, A, R, Ne, H, Y, Be, ue, Ki, ji],
                encapsulation: 2
            })
        }
    }
    return o
})();
var uo = (o, d) => ({
    background: o,
    color: d
});

function _o(o, d) {
    if (o & 1 && (r(0, "small", 10), m(1), a()), o & 2) {
        let e = l();
        n(), T(e.formatMessage("pickup_must_be_scheduled_at_least_12_hours_from_now"))
    }
}

function fo(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11)(1, "app-save-btn", 12), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.goToBasicInformationForm.emit())
        }), a(), r(2, "app-save-btn", 13), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.submitAndGoToNextPage())
        }), a()()
    }
    if (o & 2) {
        let e = l();
        n(), s("useSubmitBehavior", !1), n(), s("isDisabled", !e.pickupInformationGroup.valid)("useSubmitBehavior", !1)
    }
}

function vo(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 11)(1, "app-save-btn", 12), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.goToBasicInformationForm.emit())
        }), a(), r(2, "app-save-btn", 14), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.submitForm())
        }), a()()
    }
    if (o & 2) {
        let e = l();
        n(), s("useSubmitBehavior", !1), n(), s("isDisabled", e.isFormInvalid)("useSubmitBehavior", !1)
    }
}
var vt = (() => {
    class o {
        constructor() {
            this.formatMessage = S, this.isMobileDevice = x(L).isMobileDevice, this.isDarkTheme = x(U).isDarkTheme, this.router = x(ne), this.guestSelfCheckInFormGroup = I(), this.isLoggedIn = I(), this.hideCity = I(!1), this.hideState = I(!1), this.hidePostalCode = I(!1), this.disabledDates = I(), this.pickupMinDateTime = I(new Date), this.pickupMinLeadHoursEnabled = I(!1), this.goToVerifyUserStep = M(), this.verifyUserWithoutSchedulingPickup = M(), this.goToBasicInformationForm = M(), this.formSubmitted = M(), this.DISPLAY_DATETIME_SERIALIZATION_FORMAT = ki, this.DATETIME_SERIALIZATION_FORMAT = Fe
        }
        get pickupInformationGroup() {
            return this.guestSelfCheckInFormGroup().get("pickupInformationGroup")
        }
        get isFormInvalid() {
            return this.pickupInformationGroup.invalid && this.guestSelfCheckInFormGroup().invalid
        }
        redirect() {
            this.router.navigate(["auth/login"], {
                queryParams: {
                    redirect: "/guest/lead"
                }
            })
        }
        submitForm() {
            this.pickupInformationGroup.controls.is_pickup_booked.patchValue(!0), this.formSubmitted.emit()
        }
        submitAndGoToNextPage() {
            this.pickupInformationGroup.controls.is_pickup_booked.patchValue(!0), this.goToVerifyUserStep.emit(3)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-pickup-information-form"]
                ],
                inputs: {
                    guestSelfCheckInFormGroup: [1, "guestSelfCheckInFormGroup"],
                    isLoggedIn: [1, "isLoggedIn"],
                    hideCity: [1, "hideCity"],
                    hideState: [1, "hideState"],
                    hidePostalCode: [1, "hidePostalCode"],
                    disabledDates: [1, "disabledDates"],
                    pickupMinDateTime: [1, "pickupMinDateTime"],
                    pickupMinLeadHoursEnabled: [1, "pickupMinLeadHoursEnabled"]
                },
                outputs: {
                    goToVerifyUserStep: "goToVerifyUserStep",
                    verifyUserWithoutSchedulingPickup: "verifyUserWithoutSchedulingPickup",
                    goToBasicInformationForm: "goToBasicInformationForm",
                    formSubmitted: "formSubmitted"
                },
                standalone: !1,
                decls: 14,
                vars: 28,
                consts: [
                    [3, "formGroup"],
                    [3, "ngClass", "ngStyle"],
                    [1, "row"],
                    [1, "container"],
                    [3, "title"],
                    [3, "isVisibleCancelButton", "message"],
                    [3, "parentForm", "isAddressOptional", "isHrVisible", "hideCity", "hideState", "hidePostalCode"],
                    ["name", "scheduled_on", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "scheduled_on", "type", "datetime", 3, "dateSerializationFormat", "displayFormat", "disabledDates", "min", "pickerType", "placeholder"],
                    [3, "displayError", "errorMsg"],
                    [1, "text-muted", "d-block", "mt-1"],
                    [1, "self-checkin-actions", "d-flex", "justify-content-end", "gap-3", "p-3"],
                    ["icon", "fa-solid fa-arrow-left", "saveText", "previous", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "next", 3, "saveBtnClick", "isDisabled", "useSubmitBehavior"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "common_submit", 3, "saveBtnClick", "isDisabled", "useSubmitBehavior"]
                ],
                template: function(i, t) {
                    if (i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), v(4, "app-actionable-page-subtitle", 4)(5, "app-alert-panel", 5), r(6, "div", 2), v(7, "app-address", 6), r(8, "app-control-container", 7), v(9, "dx-date-box", 8)(10, "app-error", 9), p(11, _o, 2, 1, "small", 10), a()(), p(12, fo, 3, 3, "div", 11), p(13, vo, 3, 3, "div", 11), a()()()()), i & 2) {
                        let c;
                        s("formGroup", t.pickupInformationGroup), n(), s("ngClass", t.isMobileDevice() ? "m-3" : "card p-2 mt-4 me-4")("ngStyle", G(25, uo, t.isDarkTheme() ? "#10172A" : "#FFFFFF", t.isDarkTheme() ? "#FFFFFF" : "#000000")), n(3), s("title", "schedule_pickup"), n(), s("isVisibleCancelButton", !1)("message", t.formatMessage("device_pickup_will_be_scheduled_only_after_your_request_is_approved")), n(2), s("parentForm", t.pickupInformationGroup)("isAddressOptional", !1)("isHrVisible", !1)("hideCity", t.hideCity())("hideState", t.hideState())("hidePostalCode", t.hidePostalCode()), n(), s("errorMsg", t.formatMessage("error_date_required"))("label", t.formatMessage("preferred_pickup_date_time")), n(), s("dateSerializationFormat", t.DATETIME_SERIALIZATION_FORMAT)("displayFormat", t.DISPLAY_DATETIME_SERIALIZATION_FORMAT)("disabledDates", t.disabledDates())("min", t.pickupMinDateTime())("pickerType", t.isMobileDevice() ? "rollers" : "calendar")("placeholder", t.formatMessage("select_from_calendar")), n(), s("displayError", (t.pickupInformationGroup == null || (c = t.pickupInformationGroup.get("scheduled_on")) == null ? null : c.invalid) && (t.pickupInformationGroup == null || t.pickupInformationGroup.controls.scheduled_on == null ? null : t.pickupInformationGroup.controls.scheduled_on.getError("outsideBusinessHours")))("errorMsg", t.pickupInformationGroup == null || t.pickupInformationGroup.controls.scheduled_on == null ? null : t.pickupInformationGroup.controls.scheduled_on.getError("outsideBusinessHours")), n(), u(t.pickupMinLeadHoursEnabled() ? 11 : -1), n(), u(t.isLoggedIn() ? -1 : 12), n(), u(t.isLoggedIn() ? 13 : -1)
                    }
                },
                dependencies: [O, j, Wi, q, B, N, z, ae, A, R, Ne, H, Y],
                encapsulation: 2
            })
        }
    }
    return o
})();
var bo = (o, d) => ({
    background: o,
    color: d
});

function So(o, d) {
    if (o & 1 && (r(0, "app-control-container", 7), v(1, "app-mobile-number", 15)(2, "app-error", 12)(3, "app-error", 12), a()), o & 2) {
        let e = l(2);
        s("errorMsg", e.formatMessage("mobile_number_required_error"))("label", e.formatMessage("verify_mobile_number")), n(), s("placeholder", e.formatMessage("mobile_number_placeholder"))("form", e.verifyUserFormGroup)("isEditMode", !1), n(), s("displayError", !e.formControlForMobileNumber.untouched && e.formControlForMobileNumber.invalid && e.formControlForMobileNumber.errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), n(), s("displayError", e.formControlForMobileNumber.dirty && e.verifyUserFormGroup.errors && e.verifyUserFormGroup.errors.atLeastOne)("errorMsg", e.formatMessage("either_mobile_number_or_email_is_required_field"))
    }
}

function xo(o, d) {
    if (o & 1 && (r(0, "app-control-container", 8), v(1, "app-email", 16)(2, "app-error", 12), a()), o & 2) {
        let e = l(2);
        s("errorMsg", e.formatMessage("email_required_error"))("label", e.formatMessage("verify_email")), n(), s("formControl", e.formControlForEmail)("isUniqueValidation", !1)("isEditMode", !1), n(), s("displayError", !e.formControlForEmail.untouched && e.verifyUserFormGroup.errors && e.verifyUserFormGroup.errors.atLeastOne)("errorMsg", e.formatMessage("either_mobile_number_or_email_is_required_field"))
    }
}

function yo(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 0)(1, "div", 1), v(2, "app-actionable-page-subtitle", 2)(3, "app-alert-panel", 3), ui(4), r(5, "div", 4)(6, "dx-radio-group", 5), h("onValueChanged", function(t) {
            _(e);
            let c = l();
            return f(c.onValueChanged(t))
        }), a(), r(7, "div", 6), p(8, So, 4, 9, "app-control-container", 7)(9, xo, 3, 7, "app-control-container", 8), a(), r(10, "app-dx-outline-button", 9), h("onClickEvent", function() {
            _(e);
            let t = l();
            return f(t.sendOTP(t.verificationType()))
        }), a()(), r(11, "app-control-container", 10)(12, "app-otp-input", 11), h("otpComplete", function() {
            _(e);
            let t = l();
            return f(t.onOtpComplete())
        }), a(), v(13, "app-error", 12), a(), _i(), r(14, "div", 13)(15, "app-save-btn", 14), h("saveBtnClick", function() {
            _(e);
            let t = l();
            return f(t.goToSchedulePickupStep.emit())
        }), a()()()()
    }
    if (o & 2) {
        let e, i = l();
        s("formGroup", i.verifyUserFormGroup), n(), s("ngClass", i.isMobileDevice ? "m-3" : "card p-2 me-4 mt-4")("ngStyle", G(19, bo, i.isDarkTheme() ? "#10172A" : "#FFFFFF", i.isDarkTheme() ? "#FFFFFF" : "#000000")), n(), s("title", "verify_user"), n(), s("message", i.formatMessage("verify_user_self_check_in_note")), n(3), s("items", i.verifyUserTypeList)("value", i.verificationType()), n(), s("ngClass", i.isMobileDevice ? "w-100" : ""), n(), u(i.verificationType() === i.VERIFY_USER_TYPE_LIST.MOBILE ? 8 : 9), n(2), s("disabled", i.isOTPButtonDisabled() || i.checkFormValidity)("localeVariable", i.isOTPDelivered() && i.disableSendOtpBtnTimer !== 0 && i.isOTPButtonDisabled() ? i.disableSendOtpBtnTimer : "")("text", i.sendOtpAttempts === 0 ? "delivery_send_otp" : "delivery_resend_otp"), n(), s("errorMsg", i.formatMessage("delivery_otp_required"))("label", i.verificationType() === i.VERIFY_USER_TYPE_LIST.EMAIL ? i.formatMessage("label_verify_email_otp") : i.formatMessage("label_verify_mobile_otp")), n(), s("disabled", !i.isOTPDelivered())("hasError", ((e = i.verifyUserFormGroup.get("otp")) == null ? null : e.invalid) && ((e = i.verifyUserFormGroup.get("otp")) == null ? null : e.touched)), n(), s("displayError", !!(i.formControlForOtp != null && i.formControlForOtp.touched) && !!(!(i.formControlForOtp == null || i.formControlForOtp.errors == null) && i.formControlForOtp.errors.otpInvalid))("errorMsg", i.formControlForOtp == null || i.formControlForOtp.errors == null ? null : i.formControlForOtp.errors.otpInvalid), n(2), s("useSubmitBehavior", !1)
    }
}
var ht = (() => {
    class o {
        constructor() {
            this.isMobileDevice = x(L).isMobileDevice(), this.tenantService = x(pe), this.guestService = x(X), this.toastNotificationService = x(Z), this.router = x(ne), this.isDarkTheme = x(U).isDarkTheme, this.guestSelfCheckInFormGroup = I(), this.isLoggedIn = I(), this.customerMobileNumber = I(), this.customerEmail = I(), this.hasValueChanged = I(), this.hasPrimaryActiveSmsService = I(), this.valueChanged = I(), this.isFormSubmitted = Ci(), this.goToSchedulePickupStep = M(), this.verifyUserFormCompleted = M(), this.isUserVerified = M(), this.verificationType = C(null), this.isOTPButtonDisabled = C(!1), this.isOTPVerified = C(!1), this.isSendingOTP = C(!1), this.initialisedFormSubmission = C(!1), this.isOTPDelivered = C(!1), this.verifyUserTypeList = Object.values(E), this.disableSendOtpBtnTimer = 30, this.sendOtpAttempts = 0, this.intervalSubscription = null, this.intervalSource = null, this.isValidating = !1, this.formatMessage = S, this.VERIFY_USER_TYPE_LIST = E, this.asyncOtpValidation = this.asyncOtpValidation.bind(this)
        }
        get verifyUserFormGroup() {
            return this.guestSelfCheckInFormGroup().get("verifyUserGroup")
        }
        get basicInformationFormGroup() {
            return this.guestSelfCheckInFormGroup().get("basicInformationGroup")
        }
        get checkFormValidity() {
            return this.verifyUserFormGroup ? .errors && this.verifyUserFormGroup ? .errors.atLeastOne || this.verifyUserFormGroup ? .get("mobile_number") ? .errors || this.verifyUserFormGroup ? .get("email") ? .errors
        }
        get formControlForEmail() {
            return this.verifyUserFormGroup.controls.email
        }
        get formControlForMobileNumber() {
            return this.verifyUserFormGroup.controls.mobile_number
        }
        get formControlForOtp() {
            return this.verifyUserFormGroup.controls.otp
        }
        get isFormInvalidAndOtpVerified() {
            return this.guestSelfCheckInFormGroup().invalid || !this.isOTPVerified()
        }
        ngOnInit() {
            this.isLoggedIn() || (this.verifyUserFormGroup.get("otp") ? .disable(), this.subscribeToBasicInformationForm(), this.subscribeToVerifyUserForm())
        }
        subscribeToBasicInformationForm() {
            this.basicInformationFormGroup.get("mobile_number").valueChanges.subscribe(i => {
                this.verifyUserFormGroup.controls.mobile_number.patchValue(i, {
                    emitEvent: !1
                }), this.hasPrimaryActiveSmsService() && this.verifyUserFormGroup.controls.mobile_number.valid && (this.verificationType.set(E.MOBILE), this.verifyUserFormGroup.get("verify_type") ? .patchValue(E.MOBILE))
            }), this.basicInformationFormGroup.get("mobile_country_code") ? .valueChanges.subscribe(i => {
                this.verifyUserFormGroup.controls.mobile_country_code ? .patchValue(i)
            });
            let e = this.basicInformationFormGroup.get("mobile_country_code") ? .value;
            e && this.verifyUserFormGroup.controls.mobile_country_code ? .patchValue(e), this.basicInformationFormGroup.get("email").valueChanges.subscribe(i => {
                this.verifyUserFormGroup.controls.email.patchValue(i, {
                    emitEvent: !1
                }), (!this.hasPrimaryActiveSmsService() || this.verifyUserFormGroup.controls.mobile_number.value.length <= 0 && this.verifyUserFormGroup.controls.email.value) && (this.verificationType.set(E.EMAIL), this.verifyUserFormGroup.get("verify_type") ? .patchValue(E.EMAIL))
            })
        }
        subscribeToVerifyUserForm() {
            this.verifyUserFormGroup.controls.mobile_number.valueChanges.subscribe(e => {
                this.basicInformationFormGroup.controls.mobile_number.patchValue(e, {
                    emitEvent: !1
                })
            }), this.verifyUserFormGroup.controls.email.valueChanges.subscribe(e => {
                this.basicInformationFormGroup.controls.email.patchValue(e, {
                    emitEvent: !1
                })
            })
        }
        onValueChanged(e) {
            this.verificationType.set(e.value), this.verifyUserFormGroup.get("verify_type") ? .patchValue(this.verificationType())
        }
        disableSendOtpForDuration() {
            this.intervalSource = si(1e3), this.intervalSubscription = this.intervalSource.subscribe({
                next: () => {
                    this.disableSendOtpBtnTimer !== 0 ? this.disableSendOtpBtnTimer-- : this.unsubscribeIntervalAndEnableResendOtp()
                },
                error: e => {
                    console.error("error in internal subscription ", e)
                }
            })
        }
        unsubscribeIntervalAndEnableResendOtp() {
            this.isOTPButtonDisabled.set(!1), this.disableSendOtpBtnTimer = 30, this.sendOtpAttempts++, this.intervalSubscription && this.intervalSubscription.unsubscribe()
        }
        sendOTP(e) {
            this.isSendingOTP.set(!0), this.sendOtpOn = e === "Email" ? this.verifyUserFormGroup.value ? .email : this.verifyUserFormGroup.value ? .mobile_number;
            let i = this.verifyUserFormGroup.get("verify_type").value === E.EMAIL ? "notification_otp_sent_email_success" : "notification_otp_sent_mobile_number_success";
            this.guestService.sendVerificationOtp({
                username: this.sendOtpOn,
                type: e,
                name: this.basicInformationFormGroup ? .get("name") ? .value
            }).subscribe({
                next: () => {
                    this.isOTPDelivered.set(!0), this.verifyUserFormGroup.get("otp") ? .enable(), this.toastNotificationService.success(i), this.isOTPButtonDisabled.set(!0), this.disableSendOtpForDuration()
                },
                error: t => {
                    this.toastNotificationService.error("notification_otp_error")
                },
                complete: () => {
                    this.isSendingOTP.set(!1)
                }
            })
        }
        asyncOtpValidation(e) {
            return this.isValidating ? Promise.resolve(!1) : (this.isValidating = !0, this.sendOtpOn = this.verifyUserFormGroup.value ? .verify_type === "Email" ? this.verifyUserFormGroup.value ? .email : this.verifyUserFormGroup.value ? .mobile_number, ri(this.guestService.validateSignedOtp({
                otp: this.verifyUserFormGroup.value ? .otp,
                username: this.sendOtpOn,
                verification_type: this.verifyUserFormGroup.get("verify_type") ? .value === E.MOBILE ? ke.MOBILE_VERIFY_OTP : ke.EMAIL_VERIFY_OTP
            }).pipe(ai(i => (this.isOTPVerified.set(!1), !i ? .success || !i.success ? (this.verifyUserFormGroup.get("otp") ? .setErrors({
                otpInvalid: S("otp_verification_failed")
            }), !1) : (this.isOTPVerified.set(!0), this.submitForm(), this.isUserVerified.emit(!0), !!(i ? .success && i.success)))), li(i => {
                let t = this.verifyUserFormGroup.get("otp");
                return t ? .setErrors({
                    otpInvalid: S("error_occurred_during_otp_verification_failed")
                }), t ? .updateValueAndValidity(), this.isUserVerified.emit(!1), ni(!1)
            }), ci(() => this.isValidating = !1))))
        }
        onOtpComplete() {
            this.verifyUserFormGroup.get("otp") ? .value ? .length === 6 && this.asyncOtpValidation({
                value: this.verifyUserFormGroup.get("otp") ? .value
            })
        }
        submitForm() {
            this.isFormSubmitted.set(!1), this.initialisedFormSubmission.set(!0), this.verifyUserFormCompleted.emit()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-verify-user-form"]
                ],
                inputs: {
                    guestSelfCheckInFormGroup: [1, "guestSelfCheckInFormGroup"],
                    isLoggedIn: [1, "isLoggedIn"],
                    customerMobileNumber: [1, "customerMobileNumber"],
                    customerEmail: [1, "customerEmail"],
                    hasValueChanged: [1, "hasValueChanged"],
                    hasPrimaryActiveSmsService: [1, "hasPrimaryActiveSmsService"],
                    valueChanged: [1, "valueChanged"],
                    isFormSubmitted: [1, "isFormSubmitted"]
                },
                outputs: {
                    isFormSubmitted: "isFormSubmittedChange",
                    goToSchedulePickupStep: "goToSchedulePickupStep",
                    verifyUserFormCompleted: "verifyUserFormCompleted",
                    isUserVerified: "isUserVerified"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "formGroup"],
                    [3, "ngClass", "ngStyle"],
                    [3, "title"],
                    [3, "message"],
                    [1, "d-flex", "flex-column", "justify-content-center", "align-items-center"],
                    ["layout", "horizontal", "formControlName", "verify_type", 3, "onValueChanged", "items", "value"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "mt-3", 3, "ngClass"],
                    ["id", "mobile_number", "name", "mobile_number", 3, "errorMsg", "label"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["buttonType", "default", 1, "mt-3", "mb-3", 3, "onClickEvent", "disabled", "localeVariable", "text"],
                    ["name", "otp", 1, "col-sm-4", "col-md-4", "col-lg-4", 2, "align-self", "center", 3, "errorMsg", "label"],
                    ["formControlName", "otp", 3, "otpComplete", "disabled", "hasError"],
                    [3, "displayError", "errorMsg"],
                    [1, "self-checkin-actions", "d-flex", "justify-content-end", "gap-3", "p-3"],
                    ["icon", "fa-solid fa-arrow-left", "saveText", "previous", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["formControlName", "mobile_number", "id", "guest-self-check-in-mobile", 3, "placeholder", "form", "isEditMode"],
                    [3, "formControl", "isUniqueValidation", "isEditMode"]
                ],
                template: function(i, t) {
                    i & 1 && p(0, yo, 16, 22, "div", 0), i & 2 && u(t.isLoggedIn() ? -1 : 0)
                },
                dependencies: [O, j, q, B, oe, N, z, ae, A, R, H, Y, rt, Qe, Be, ue, we],
                encapsulation: 2
            })
        }
    }
    return o
})();
var Fo = (o, d) => [o, d],
    To = (o, d) => ({
        "border-primary bg-light-subtle shadow-sm": o,
        "border-light hover-shadow": d
    }),
    ko = o => ({
        "text-muted": o
    }),
    Vo = (o, d) => ({
        "bg-primary border-primary": o,
        "theme-secondary-bg border-secondary-subtle": d
    });

function Mo(o, d) {
    o & 1 && v(0, "i")
}

function Do(o, d) {
    if (o & 1 && (r(0, "div")(1, "div", 11)(2, "div", 12)(3, "h5", 13), m(4), a(), r(5, "p", 14), m(6), a()(), r(7, "div", 15), p(8, Mo, 1, 0, "i"), a()()()), o & 2) {
        let e, i, t, c, g = d.$implicit,
            k = l();
        n(), s("ngClass", G(6, To, ((e = k.serviceOptionFormGroup.get("is_recovery")) == null ? null : e.value) === g.isRecovery, ((e = k.serviceOptionFormGroup.get("is_recovery")) == null ? null : e.value) !== g.isRecovery)), n(2), s("ngClass", D(9, ko, ((i = k.serviceOptionFormGroup.get("is_recovery")) == null ? null : i.value) !== g.isRecovery)), n(), b(" ", g.title, " "), n(2), T(g.description), n(), s("ngClass", G(11, Vo, ((t = k.serviceOptionFormGroup.get("is_recovery")) == null ? null : t.value) === g.isRecovery, ((t = k.serviceOptionFormGroup.get("is_recovery")) == null ? null : t.value) !== g.isRecovery)), n(), u(((c = k.serviceOptionFormGroup.get("is_recovery")) == null ? null : c.value) === g.isRecovery ? 8 : -1)
    }
}

function Eo(o, d) {
    if (o & 1 && (r(0, "div", 8), m(1), a()), o & 2) {
        let e = l();
        n(), b(" ", e.formatMessage("common_error_messages_service_option_required"), " ")
    }
}
var Ct = (() => {
    class o {
        constructor() {
            this.formatMessage = S, this.isMobileDevice = x(L).isMobileDevice, this.isDarkTheme = x(U).isDarkTheme, this.guestSelfCheckInFormGroup = I.required(), this.serviceOptions = I.required(), this.serviceOptionFormCompleted = M(), this.SERVICE_OPTIONS = re
        }
        get serviceOptionFormGroup() {
            return this.guestSelfCheckInFormGroup().get("serviceOptionFormGroup")
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-service-option-form"]
                ],
                inputs: {
                    guestSelfCheckInFormGroup: [1, "guestSelfCheckInFormGroup"],
                    serviceOptions: [1, "serviceOptions"]
                },
                outputs: {
                    serviceOptionFormCompleted: "serviceOptionFormCompleted"
                },
                standalone: !1,
                decls: 11,
                vars: 15,
                consts: [
                    [3, "formGroup"],
                    ["id", "service-option-form", 3, "ngClass"],
                    [3, "title"],
                    [1, "mb-4"],
                    [3, "message", "isVisibleCancelButton"],
                    ["name", "is_recovery", 1, "col-sm-12", 3, "errorMsg"],
                    ["formControlName", "is_recovery", "layout", "horizontal", 1, "w-100", 3, "items", "valueExpr"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "mt-2", "text-danger", "small", "fw-semibold"],
                    [1, "self-checkin-actions", "d-flex", "justify-content-end", "gap-3", "p-3"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", "saveText", "next", 1, "fw-semibold", 3, "saveBtnClick", "isDisabled", "useSubmitBehavior"],
                    [1, "theme-secondary-bg", "service-option-card", "p-4", "border", "rounded-4", "position-relative", "cursor-pointer", "transition-all", 3, "ngClass"],
                    [1, "d-flex", "flex-column", "pe-2", "text-center"],
                    [1, "fw-bold", "mb-2", 3, "ngClass"],
                    [1, "text-muted", "small", "mb-0"],
                    [3, "ngClass"]
                ],
                template: function(i, t) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1), v(2, "app-actionable-page-subtitle", 2), r(3, "div", 3), v(4, "app-alert-panel", 4), a(), r(5, "app-control-container", 5)(6, "dx-radio-group", 6), K(7, Do, 9, 14, "div", 7), a(), p(8, Eo, 2, 1, "div", 8), a(), r(9, "div", 9)(10, "app-save-btn", 10), h("saveBtnClick", function() {
                        return t.serviceOptionFormCompleted.emit(0)
                    }), a()()()()), i & 2 && (s("formGroup", t.serviceOptionFormGroup), n(), s("ngClass", G(12, Fo, t.isMobileDevice() ? "m-3" : "card p-2 me-4 mt-4", t.isDarkTheme() ? "service-option-dark" : "service-option-light")), n(), s("title", "service_option"), n(2), s("message", t.formatMessage("note_service_option_guest_self_checkin"))("isVisibleCancelButton", !1), n(), s("errorMsg", t.formatMessage("common_error_messages_service_option_required")), n(), s("items", t.serviceOptions())("valueExpr", "isRecovery"), n(), s("dxTemplateOf", "item"), n(), u(t.serviceOptionFormGroup.controls.is_recovery.touched && t.serviceOptionFormGroup.controls.is_recovery.invalid ? 8 : -1), n(2), s("isDisabled", t.serviceOptionFormGroup.invalid)("useSubmitBehavior", !1))
                },
                dependencies: [O, Me, q, B, N, z, A, R, H, Y, we],
                styles: ["#service-option-form[_ngcontent-%COMP%]     .dx-radiogroup-horizontal .dx-collection{column-gap:2.5rem}.service-option-card[_ngcontent-%COMP%]{display:flex;font-size:12px;font-weight:500;border-radius:8px;cursor:pointer;box-shadow:0 2px 5px #00000026;transition:transform .2s,box-shadow .2s;width:350px;padding:30px}.service-option-dark[_ngcontent-%COMP%]{background:#10172a;color:#fff}.service-option-light[_ngcontent-%COMP%]{background:#fff}.service-option-card[_ngcontent-%COMP%]:hover{transform:translateY(-2px);box-shadow:0 4px 8px #00000040}@media(max-width:600px){.service-option-card[_ngcontent-%COMP%]{width:100%;height:100%}}.service-option-card[_ngcontent-%COMP%]{transition:all .25s ease-in-out;cursor:pointer}.service-option-card[_ngcontent-%COMP%]:hover{transform:translateY(-3px);box-shadow:0 .5rem 1rem #00000014}.service-option-card.hover-shadow[_ngcontent-%COMP%]:hover{border-color:#dee2e6;background-color:#fafafa}.disabled-button[_ngcontent-%COMP%]{cursor:not-allowed!important;opacity:.65}"]
            })
        }
    }
    return o
})();
var wo = (o, d) => ({
        "summary-dark": o,
        "summary-light": d
    }),
    Po = o => ({
        height: o
    }),
    ei = o => ({
        "text-black": o
    }),
    ii = o => ({
        fontSize: o
    }),
    Oo = (o, d) => ({
        background: o,
        color: d
    });

function Bo(o, d) {
    if (o & 1 && (r(0, "p", 6), m(1), a()), o & 2) {
        let e = l(3);
        n(), T(e.formatMessage("common_summary"))
    }
}

function No(o, d) {
    if (o & 1 && v(0, "img", 19), o & 2) {
        let e = l(5);
        s("src", e.isDeviceImagePresent(e.deviceFormControlValues.deviceType), P)
    }
}

function Lo(o, d) {
    if (o & 1 && (r(0, "div", 12)(1, "div", 18), p(2, No, 1, 1, "img", 19), r(3, "p", 20), m(4), a()()()), o & 2) {
        let e = l(4);
        n(), s("title", e.deviceFormControlValues.deviceType.name), n(), u(e.isDeviceImagePresent(e.deviceFormControlValues.deviceType) ? 2 : -1), n(), s("ngClass", D(5, ei, !e.isDarkTheme()))("ngStyle", D(7, ii, e.isDeviceImagePresent(e.deviceFormControlValues.deviceType) ? "" : "1rem")), n(), b(" ", e.truncateText(e.deviceFormControlValues.deviceType.name), " ")
    }
}

function Ao(o, d) {
    if (o & 1 && v(0, "img", 19), o & 2) {
        let e = l(5);
        s("src", e.isDeviceImagePresent(e.deviceFormControlValues.deviceBrand), P)
    }
}

function Uo(o, d) {
    if (o & 1 && (r(0, "div", 12)(1, "div", 18), p(2, Ao, 1, 1, "img", 19), r(3, "p", 20), m(4), a()()()), o & 2) {
        let e = l(4);
        n(), s("title", e.deviceFormControlValues.deviceBrand.name), n(), u(e.isDeviceImagePresent(e.deviceFormControlValues.deviceBrand) ? 2 : -1), n(), s("ngClass", D(5, ei, !e.isDarkTheme()))("ngStyle", D(7, ii, e.isDeviceImagePresent(e.deviceFormControlValues.deviceBrand) ? "" : "1rem")), n(), b(" ", e.truncateText(e.deviceFormControlValues.deviceBrand.name), " ")
    }
}

function Ro(o, d) {
    if (o & 1 && v(0, "img", 19), o & 2) {
        let e = l(5);
        s("src", e.isDeviceImagePresent(e.deviceFormControlValues.deviceModel), P)
    }
}

function Ho(o, d) {
    if (o & 1 && (r(0, "div", 12)(1, "div", 18), p(2, Ro, 1, 1, "img", 19), r(3, "p", 20), m(4), a()()()), o & 2) {
        let e = l(4);
        n(), s("title", e.deviceFormControlValues.deviceModel.name), n(), u(e.isDeviceImagePresent(e.deviceFormControlValues.deviceModel) ? 2 : -1), n(), s("ngClass", D(5, ei, !e.isDarkTheme()))("ngStyle", D(7, ii, e.isDeviceImagePresent(e.deviceFormControlValues.deviceModel) ? "" : "1rem")), n(), b(" ", e.truncateText(e.deviceFormControlValues.deviceModel.name), " ")
    }
}

function jo(o, d) {
    if (o & 1 && (r(0, "p", 14), m(1), a()), o & 2) {
        let e = l(4);
        n(), b(" ", e.formatMessage("job_service_information"), " ")
    }
}

function qo(o, d) {
    if (o & 1 && (r(0, "p", 15)(1, "span", 21), m(2), a()()), o & 2) {
        let e = l(4);
        n(2), b(" ", e.formatMessage("repair_service"), ": ")
    }
}

function zo(o, d) {
    if (o & 1 && (r(0, "li"), m(1), a()), o & 2) {
        let e = d.$implicit;
        n(), b(" ", e, " ")
    }
}

function Yo(o, d) {
    if (o & 1 && (r(0, "ul", 16), Ye(1, zo, 2, 1, "li", null, ze), a()), o & 2) {
        let e = l(4);
        n(), Ke(e.deviceFormControlValues.repairables)
    }
}

function Ko(o, d) {
    if (o & 1 && (r(0, "p", 17)(1, "span", 21), m(2), a(), m(3), a()), o & 2) {
        let e = l(4);
        n(2), b("", e.formatMessage("device_serial_number"), " "), n(), b(" : ", e.deviceFormControlValues.serialNumber, " ")
    }
}

function Wo(o, d) {
    if (o & 1 && (r(0, "p", 17)(1, "span", 21), m(2), a(), m(3), a()), o & 2) {
        let e = l(4);
        n(2), b(" ", e.formatMessage("serial_number2"), " "), n(), b(" : ", e.deviceFormControlValues.serialNumber2, " ")
    }
}

function $o(o, d) {
    if (o & 1 && (r(0, "p", 17)(1, "span", 21), m(2), a(), m(3), a()), o & 2) {
        let e = l(4);
        n(2), b(" ", e.formatMessage("capacity"), " "), n(), ye(" : ", e.deviceFormControlValues.size, " ", e.deviceFormControlValues.capacityMeasure, " ")
    }
}

function Qo(o, d) {
    if (o & 1 && (r(0, "p", 17)(1, "span", 21), m(2), a(), m(3), a()), o & 2) {
        let e = l(4);
        n(2), b(" ", e.formatMessage("accessories"), " "), n(), b(" : ", e.deviceFormControlValues.accessories, " ")
    }
}

function Zo(o, d) {
    if (o & 1 && (r(0, "div", 7)(1, "p", 10), m(2), a(), r(3, "div", 11), p(4, Lo, 5, 9, "div", 12), p(5, Uo, 5, 9, "div", 12), p(6, Ho, 5, 9, "div", 12), a(), v(7, "div", 13), p(8, jo, 2, 1, "p", 14), p(9, qo, 3, 1, "p", 15), p(10, Yo, 3, 0, "ul", 16), p(11, Ko, 4, 2, "p", 17), p(12, Wo, 4, 2, "p", 17), p(13, $o, 4, 3, "p", 17), p(14, Qo, 4, 2, "p", 17), a()), o & 2) {
        let e = l(3);
        n(2), T(e.formatMessage("lead_device_info")), n(2), u(e.deviceFormControlValues.deviceType.name ? 4 : -1), n(), u(e.deviceFormControlValues.deviceBrand.name ? 5 : -1), n(), u(e.deviceFormControlValues.deviceModel.name ? 6 : -1), n(2), u(e.deviceFormControlValues.repairables.length > 0 ? 8 : -1), n(), u(e.deviceFormControlValues.repairables.length > 0 ? 9 : -1), n(), u(e.deviceFormControlValues.repairables.length > 0 ? 10 : -1), n(), u(e.deviceFormControlValues.serialNumber ? 11 : -1), n(), u(e.deviceFormControlValues.serialNumber2 ? 12 : -1), n(), u(e.deviceFormControlValues.size ? 13 : -1), n(), u(e.deviceFormControlValues.accessories.length > 0 ? 14 : -1)
    }
}

function Jo(o, d) {
    if (o & 1 && (r(0, "p", 22)(1, "span", 21), m(2), a(), m(3), a()), o & 2) {
        let e = l(4);
        n(2), b(" ", e.formatMessage("common_email_id"), " "), n(), b(" : ", e.basicInformationGroup.get("email").value, " ")
    }
}

function Xo(o, d) {
    if (o & 1 && (r(0, "p", 22)(1, "span", 21), m(2), a(), m(3), ie(4, "mobileDisplay"), a()), o & 2) {
        let e, i = l(4);
        n(2), b(" ", i.formatMessage("common_mobile_number"), " "), n(), b(" : ", te(4, 2, i.basicInformationGroup.get("mobile_number").value, (e = i.basicInformationGroup.get("mobile_country_code")) == null ? null : e.value), " ")
    }
}

function en(o, d) {
    if (o & 1 && (r(0, "div", 8)(1, "p", 14), m(2), a(), r(3, "div")(4, "p", 22)(5, "span", 21), m(6), a(), m(7), a(), p(8, Jo, 4, 2, "p", 22), p(9, Xo, 5, 5, "p", 22), a()()), o & 2) {
        let e = l(3);
        n(2), T(e.formatMessage("basic_information")), n(4), b(" ", e.formatMessage("common_name"), " "), n(), b(" : ", e.basicInformationGroup.get("name").value, " "), n(), u(e.basicInformationGroup.get("email").value ? 8 : -1), n(), u(e.basicInformationGroup.get("mobile_number").value ? 9 : -1)
    }
}

function tn(o, d) {
    if (o & 1 && (r(0, "div", 9)(1, "p", 14), m(2), a(), r(3, "p", 22)(4, "span", 21), m(5), a(), m(6), a(), r(7, "p", 22)(8, "span", 21), m(9), a(), m(10), a(), r(11, "p", 22)(12, "span", 21), m(13), a(), m(14), a(), r(15, "p", 22)(16, "span", 21), m(17), a(), m(18), a()()), o & 2) {
        let e, i, t, c, g = l(3);
        n(2), T(g.formatMessage("save_or_book_pickup")), n(3), b(" ", g.formatMessage("user_customer_address_line"), " "), n(), b(" : ", g.pickupAddressInformationFormGroup == null || (e = g.pickupAddressInformationFormGroup.get("address_line")) == null ? null : e.value, " "), n(3), b(" ", g.formatMessage("user_region_state"), " "), n(), b(" : ", g.pickupAddressInformationFormGroup == null || (i = g.pickupAddressInformationFormGroup.get("state")) == null ? null : i.value, " "), n(3), b(" ", g.formatMessage("user_city_town"), " "), n(), b(" : ", g.pickupAddressInformationFormGroup == null || (t = g.pickupAddressInformationFormGroup.get("city")) == null ? null : t.value, " "), n(3), b(" ", g.formatMessage("user_postal_code"), " "), n(), b(" : ", g.pickupAddressInformationFormGroup == null || (c = g.pickupAddressInformationFormGroup.get("zip_code")) == null ? null : c.value, " ")
    }
}

function on(o, d) {
    if (o & 1 && (r(0, "div", 3)(1, "div")(2, "div", 5), v(3, "app-logo"), a(), p(4, Bo, 2, 1, "p", 6), p(5, Zo, 15, 11, "div", 7), p(6, en, 10, 5, "div", 8), p(7, tn, 19, 9, "div", 9), a()()), o & 2) {
        let e = l(2);
        s("ngClass", G(6, wo, e.isDarkTheme(), !e.isDarkTheme()))("ngStyle", D(9, Po, e.isLoggedIn() ? "calc(100vh - 4.5rem)" : "100vh")), n(4), u(e.deviceInformationGroup != null && e.deviceInformationGroup.valid ? 4 : -1), n(), u(e.deviceInformationGroup != null && e.deviceInformationGroup.valid ? 5 : -1), n(), u(e.basicInformationGroup != null && e.basicInformationGroup.valid ? 6 : -1), n(), u(!(e.pickupAddressInformationFormGroup == null || e.pickupAddressInformationFormGroup.controls.is_pickup_booked == null) && e.pickupAddressInformationFormGroup.controls.is_pickup_booked.value && (e.pickupAddressInformationFormGroup != null && e.pickupAddressInformationFormGroup.valid) ? 7 : -1)
    }
}

function nn(o, d) {
    if (o & 1 && v(0, "dxi-stepper-item", 25), o & 2) {
        let e = d.$implicit;
        s("label", e.label)("icon", e.icon)("hint", e.hint)("isValid", e.isValid)("disabled", e.disabled)
    }
}

function rn(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "dxi-item")(1, "div")(2, "app-service-option-form", 30), h("serviceOptionFormCompleted", function(t) {
            _(e);
            let c = l(4);
            return f(c.serviceOptionFormCompleted(t))
        }), a()()()
    }
    if (o & 2) {
        let e = l(4);
        n(2), s("guestSelfCheckInFormGroup", e.guestSelfCheckInFormGroup)("serviceOptions", e.serviceOptions)
    }
}

function an(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "app-pickup-information-form", 32), h("verifyUserWithoutSchedulingPickup", function(t) {
            _(e);
            let c = l(5);
            return f(c.goToVerifyUserStepDirectly(t))
        })("goToBasicInformationForm", function() {
            _(e);
            let t = l(5);
            return f(t.goToPreviousStep())
        })("goToVerifyUserStep", function(t) {
            _(e);
            let c = l(5);
            return f(c.goToNextStep(t))
        })("formSubmitted", function() {
            _(e);
            let t = l(5);
            return f(t.submit())
        }), a()
    }
    if (o & 2) {
        let e = l(5);
        s("isLoggedIn", e.isLoggedIn())("guestSelfCheckInFormGroup", e.guestSelfCheckInFormGroup)("disabledDates", e.disabledDates)("pickupMinDateTime", e.pickupMinDateTime())("pickupMinLeadHoursEnabled", e.pickupMinLeadHoursEnabled())("hideCity", e.hideCity())("hideState", e.hideState())("hidePostalCode", e.hidePostalCode())
    }
}

function sn(o, d) {
    if (o & 1 && (r(0, "dxi-item")(1, "div"), p(2, an, 1, 8, "app-pickup-information-form", 31), a()()), o & 2) {
        let e = l(4);
        n(2), u(e.pickupInformationGroup ? 2 : -1)
    }
}

function ln(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "dxi-item")(1, "div")(2, "app-verify-user-form", 33), h("verifyUserFormCompleted", function() {
            _(e);
            let t = l(4);
            return f(t.submit())
        })("isUserVerified", function(t) {
            _(e);
            let c = l(4);
            return f(c.hasUserVerified(t))
        })("goToSchedulePickupStep", function() {
            _(e);
            let t = l(4);
            return f(t.goToPreviousAddPickupStep())
        }), a()()()
    }
    if (o & 2) {
        let e = l(4);
        n(2), s("guestSelfCheckInFormGroup", e.guestSelfCheckInFormGroup)("isLoggedIn", e.isLoggedIn())("customerMobileNumber", e.customerMobileNumber())("customerEmail", e.customerEmail())("hasValueChanged", e.hasVerificationValueChanged())("valueChanged", e.verificationValueChanged())("hasPrimaryActiveSmsService", e.hasPrimaryActiveSmsService())("isFormSubmitted", e.isFormSubmitted())
    }
}

function cn(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "form", 26)(1, "dx-multi-view", 27), p(2, rn, 3, 2, "dxi-item"), r(3, "dxi-item")(4, "app-device-information-form", 28), h("allDeviceInformationValue", function(t) {
            _(e);
            let c = l(3);
            return f(c.displayValuesInSidebar(t))
        })("deviceInformationFormCompleted", function(t) {
            _(e);
            let c = l(3);
            return f(c.goToBasicInformationStep(t))
        })("backToLogin", function() {
            _(e);
            let t = l(3);
            return f(t.backToLogin())
        }), a()(), r(5, "dxi-item")(6, "app-basic-information-form", 29), h("goToDeviceInformationForm", function() {
            _(e);
            let t = l(3);
            return f(t.goToPreviousStep())
        })("goToAddPickupStep", function(t) {
            _(e);
            let c = l(3);
            return f(c.goToAddPickupStep(t))
        })("goToVerifyUserForm", function(t) {
            _(e);
            let c = l(3);
            return f(c.goToVerifyUserStepDirectly(t))
        })("skipPickupAndSubmit", function() {
            _(e);
            let t = l(3);
            return f(t.skipPickupAndSubmit())
        }), a()(), p(7, sn, 3, 1, "dxi-item"), p(8, ln, 3, 8, "dxi-item"), a()()
    }
    if (o & 2) {
        let e = l(3);
        s("formGroup", e.guestSelfCheckInForm), n(), s("selectedIndex", e.selectedStepId())("animationEnabled", !1)("swipeEnabled", !1), n(), u(e.jobServiceOption() === "Both" ? 2 : -1), n(2), s("guestSelfCheckInFormGroup", e.guestSelfCheckInFormGroup)("deviceInformationControlList", e.deviceInformationControlList)("allDeviceTypeList", e.allDeviceTypeList)("allDeviceBrandList", e.allDeviceBrandList)("allDeviceModelList", e.allDeviceModelList)("allAccessoriesList", e.allAccessoriesList)("allRepairServicesList", e.allRepairServicesList), n(2), s("isLoggedIn", e.isLoggedIn())("basicInformationGroup", e.basicInformationGroup)("guestSelfCheckInFormGroup", e.guestSelfCheckInFormGroup)("isOTPVerified", e.isOTPVerified())("isAddressMandatory", e.isAddressMandatory())("hideCity", e.hideCity())("hideState", e.hideState())("hidePostalCode", e.hidePostalCode())("showAddressOnBasicInfo", e.showAddressOnBasicInfo())("hidePickup", e.hidePickup()), n(), u(e.hidePickup() ? -1 : 7), n(), u(e.verifyUserGroup ? 8 : -1)
    }
}

function dn(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 23), h("keydown.enter", function(t) {
            _(e);
            let c = l(2);
            return f(c.handleEnterKey(t))
        }), r(1, "dx-stepper", 24, 0), h("onSelectionChanged", function(t) {
            _(e);
            let c = l(2);
            return f(c.onSelectionChanged(t))
        }), Ye(3, nn, 1, 5, "dxi-stepper-item", 25, ze), a(), p(5, cn, 9, 24, "form", 26), a()
    }
    if (o & 2) {
        let e = l(2);
        n(), s("selectedIndex", e.selectedStepId()), n(2), Ke(e.validationGroups), n(2), u(e.guestSelfCheckInForm ? 5 : -1)
    }
}

function mn(o, d) {
    if (o & 1 && (r(0, "div", 1), p(1, on, 8, 11, "div", 3), p(2, dn, 6, 2, "div", 4), a()), o & 2) {
        let e = l();
        n(), u(e.isMobileDevice() ? -1 : 1), n(), u(e.isLoading() ? -1 : 2)
    }
}

function pn(o, d) {
    if (o & 1 && (r(0, "div", 39), m(1), a()), o & 2) {
        let e = l(2);
        n(), b(" ", e.formatMessage("self_checkin_thankyou_note"), " ")
    }
}

function un(o, d) {
    if (o & 1 && (r(0, "div", 48)(1, "p", 44), m(2), a(), r(3, "p", 47), m(4), a()()), o & 2) {
        let e = l(2);
        n(2), T(e.formatMessage("common_issues")), n(2), T(e.deviceFormControlValues.repairables)
    }
}

function _n(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 50)(1, "app-save-btn", 52), h("saveBtnClick", function() {
            _(e);
            let t = l(2);
            return f(t.submitAnotherForm())
        }), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(), s("useSubmitBehavior", !1)("saveText", e.isMobileDevice() ? "job_self_check_in" : "submit_another_self_checkin")
    }
}

function fn(o, d) {
    if (o & 1) {
        let e = F();
        r(0, "div", 51)(1, "app-save-cancel-footer", 53), h("cancelClick", function() {
            _(e);
            let t = l(2);
            return f(t.backToLogin())
        })("saveClick", function() {
            _(e);
            let t = l(2);
            return f(t.submitAnotherForm())
        }), a()()
    }
    if (o & 2) {
        let e = l(2);
        n(), s("isOnPopup", !0)("saveText", e.isMobileDevice() ? "job_self_check_in" : "submit_another_self_checkin")
    }
}

function vn(o, d) {
    if (o & 1 && (r(0, "div", 2)(1, "div", 34)(2, "div", 5), v(3, "img", 35), a(), r(4, "div", 36)(5, "h5", 37), m(6), a(), r(7, "h6", 38), m(8), a()(), p(9, pn, 2, 1, "div", 39), r(10, "div", 40)(11, "h6", 41), m(12), a(), r(13, "div", 42)(14, "div", 43)(15, "p", 44), m(16), a(), r(17, "div", 45), v(18, "img", 46), r(19, "p", 47), m(20), a()()(), r(21, "div", 43)(22, "p", 44), m(23), a(), r(24, "div", 45), v(25, "img", 46), r(26, "p", 47), m(27), a()()(), r(28, "div", 43)(29, "p", 44), m(30), a(), r(31, "div", 45), v(32, "img", 46), r(33, "p", 47), m(34), a()()()(), p(35, un, 5, 2, "div", 48), v(36, "hr", 49), p(37, _n, 2, 2, "div", 50), p(38, fn, 2, 2, "div", 51), a()()()), o & 2) {
        let e = l();
        n(), s("ngClass", e.isMobileDevice() ? "m-3 w-70" : "card w-50")("ngStyle", G(22, Oo, e.isDarkTheme() ? "#10172A" : "#FFFFFF", e.isDarkTheme() ? "#FFFFFF" : "#000000")), n(2), s("src", e.headerImage, P), n(3), b(" ", e.formatMessage("self_checkin_thankyou_for_appointment_title"), " "), n(2), b(" ", e.formatMessage("self_checkin_thankyou_for_appointment_sub_title"), " "), n(), u(e.showThankyouNote() ? 9 : -1), n(3), T(e.formatMessage("common_information")), n(4), T(e.formatMessage("device_type_name")), n(2), s("src", e.isDeviceImagePresent(e.deviceFormControlValues.deviceType), P)("alt", e.deviceFormControlValues.deviceType == null ? null : e.deviceFormControlValues.deviceType.name), n(2), T((e.deviceFormControlValues.deviceType == null ? null : e.deviceFormControlValues.deviceType.name) || "-"), n(3), T(e.formatMessage("common_brand")), n(2), s("src", e.isDeviceImagePresent(e.deviceFormControlValues.deviceBrand), P)("alt", e.deviceFormControlValues.deviceBrand == null ? null : e.deviceFormControlValues.deviceBrand.name), n(2), T((e.deviceFormControlValues.deviceBrand == null ? null : e.deviceFormControlValues.deviceBrand.name) || "-"), n(3), T(e.formatMessage("common_model")), n(2), s("src", e.isDeviceImagePresent(e.deviceFormControlValues.deviceModel), P)("alt", e.deviceFormControlValues.deviceModel == null ? null : e.deviceFormControlValues.deviceModel.name), n(2), T((e.deviceFormControlValues.deviceModel == null ? null : e.deviceFormControlValues.deviceModel.name) || "-"), n(), u((e.deviceFormControlValues.repairables == null ? null : e.deviceFormControlValues.repairables.length) > 0 ? 35 : -1), n(2), u(e.isLoggedIn() ? 37 : -1), n(), u(e.isLoggedIn() ? -1 : 38)
    }
}
var gt = (() => {
    class o {
        constructor() {
            this.formatMessage = S, this.formBuilder = x(xi), this.userSessionService = x(Gi), this.userDeviceService = x(L), this.generalSettingDataService = x(Ge), this.tenantService = x(pe), this.termAndConditionService = x(Hi), this.customerService = x(Di), this.toastNotificationService = x(Z), this.guestService = x(X), this.loaderService = x(Li), this.reCaptchaV3Service = x(lt), this.routerHelperService = x(Ei), this.router = x(ne), this.destroyRef = x(di), this.isLoggedIn = this.userSessionService.isLoggedIn, this.currentUser = this.userSessionService.currentUser, this.tenantConfig = this.tenantService.config, this.plan = this.tenantService.plan, this.isMobileDevice = this.userDeviceService.isMobileDevice, this.isDarkTheme = x(U).isDarkTheme, this.SETTINGS = Q, this.customer = null, this.businessHours = this.tenantService ? .config() ? .business_hours, this.isAddressMandatory = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.ADDRESS_MANDATORY)), this.isCityOptional = C(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.CITY_OPTIONAL) ? ? !0), this.isStateOptional = C(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.STATE_OPTIONAL) ? ? !0), this.isPostalCodeOptional = C(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.POSTAL_CODE_OPTIONAL) ? ? !0), this.hideCity = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.HIDE_CITY)), this.hideState = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.HIDE_STATE)), this.hidePostalCode = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.HIDE_POSTAL_CODE)), this.showAddressOnBasicInfo = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.SHOW_ADDRESS_ON_BASIC_INFO)), this.pickupMinLeadHoursEnabled = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.PICKUP_MIN_LEAD_HOURS_ENABLED)), this.hidePickup = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.HIDE_PICKUP)), this.showThankyouNote = C(!!this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.SELF_CHECK_IN_SETTINGS.SHOW_THANKYOU_NOTE)), this.pickupMinDateTime = W(() => this.pickupMinLeadHoursEnabled() ? new Date(Date.now() + 720 * 60 * 1e3) : new Date), this.allDeviceTypeList = [], this.allDeviceBrandList = [], this.allDeviceModelList = [], this.allAccessoriesList = [], this.allRepairServicesList = [], this.errorResponse = null, this.deviceFormControlValues = {}, this.siteKey = Ti.siteKey, this.isSaving = !1, this.serviceOptions = [{
                name: re.REPAIR_SERVICE,
                title: S("repair_service_title"),
                description: S("service_description"),
                isRecovery: !1
            }, {
                name: re.RECOVERY_SERVICE,
                title: S("recovery_service_title"),
                description: S("recovery_description"),
                isRecovery: !0
            }], this.validationGroups = [{
                id: 1,
                icon: "fa-thin fa-ticket",
                label: this.isMobileDevice() ? S("common_device") : S("device_information"),
                hint: S("device_information"),
                visible: !0,
                disabled: !0,
                key: "deviceInformationGroup"
            }, {
                id: 2,
                icon: "fa-thin fa-user",
                label: this.isMobileDevice() ? S("common_basic") : S("basic_information"),
                hint: S("basic_information"),
                visible: !0,
                isValid: void 0,
                disabled: !0,
                key: "basicInformationGroup"
            }, {
                id: 3,
                icon: "fa-thin fa-truck-pickup",
                label: this.isMobileDevice() ? S("common_pickup") : S("save_or_book_pickup"),
                hint: S("save_or_book_pickup"),
                visible: !0,
                isValid: void 0,
                disabled: !0,
                key: "pickupInformationGroup"
            }], this.deviceInformationControlList = [{
                index: 0,
                name: "device_information"
            }, {
                index: 1,
                name: "device_type_id"
            }, {
                index: 2,
                name: "device_brand_id"
            }, {
                index: 3,
                name: "device_model_id"
            }, {
                index: 4,
                name: "serial_number"
            }, {
                index: 5,
                name: "serial_number_2"
            }, {
                index: 6,
                name: "accessories"
            }, {
                index: 7,
                name: "device_password"
            }, {
                index: 8,
                name: "size"
            }, {
                index: 9,
                name: "repairables"
            }, {
                index: 10,
                name: "capacity_measure"
            }, {
                index: 11,
                name: "comment"
            }, {
                index: 12,
                name: "attachments"
            }], this.headerImage = "/assets/images/blue-correct-tick.png", this.jobServiceOption = C(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SERVICE_OPTION)), this.isRecovery = C(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SERVICE_OPTION) === re.RECOVERY_SERVICE), this.isBusinessHourSet = C(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.GENERAL_SETTINGS.ENABLE_BUSINESS_HOURS)), this.selectedStepId = C(0), this.customerName = C(""), this.customerMobileNumber = C(""), this.customerEmail = C(""), this.hasVerificationValueChanged = C(!1), this.verificationValueChanged = C([]), this.isLoading = C(!1), this.isOTPVerified = C(!1), this.isFormSubmitted = C(!1), this.selfCheckInResponse = C(null), this.disabledDates = Ae.getDisabledDates(this.isBusinessHourSet(), this.businessHours)
        }
        ngOnInit() {
            this.isLoggedIn() && this.fetchCustomerDetails(), this.manageServiceOptionInValidationGroup(), this.manageVerifyUserValidationStep(), this.manageHidePickupValidationStep(), this.isLoading.set(!0), this.loaderService.show(), this.guestService.getLookups().subscribe({
                next: e => {
                    this.allDeviceTypeList = e.device_types.filter(i => i.is_visible_on_self_checkin !== !1), this.allDeviceBrandList = e.device_brands, this.allDeviceModelList = e.device_models, this.allAccessoriesList = e.accessories, this.allRepairServicesList = e.repair_services, this.setupForm(), this.subscribeToForm()
                },
                error: e => {
                    console.log(e)
                }
            }).add(() => {
                this.loaderService.hide(), this.isLoading.set(!1)
            })
        }
        get guestSelfCheckInFormGroup() {
            return this.guestSelfCheckInForm
        }
        get serviceOptionFormGroup() {
            return this.guestSelfCheckInForm ? .get("serviceOptionFormGroup")
        }
        get deviceInformationGroup() {
            return this.guestSelfCheckInForm ? .get("deviceInformationGroup")
        }
        get basicInformationGroup() {
            return this.guestSelfCheckInForm ? .get("basicInformationGroup")
        }
        get pickupInformationGroup() {
            return this.guestSelfCheckInForm ? .get("pickupInformationGroup")
        }
        get pickupAddressInformationFormGroup() {
            return this.guestSelfCheckInForm ? .get("pickupInformationGroup") ? .get("address")
        }
        get verifyUserGroup() {
            return this.guestSelfCheckInForm ? .get("verifyUserGroup")
        }
        manageVerifyUserValidationStep() {
            this.isLoggedIn() || this.validationGroups.push({
                id: 4,
                icon: "fa-thin fa-user",
                label: this.isMobileDevice() ? S("common_verification") : S("verify_user"),
                hint: S("verify_user"),
                visible: !0,
                isValid: void 0,
                disabled: !0,
                key: "verifyUserGroup"
            })
        }
        manageHidePickupValidationStep() {
            this.hidePickup() && (this.validationGroups = this.validationGroups.filter(e => e.key !== "pickupInformationGroup"))
        }
        checkFormGroupValidity() {
            let e = this.guestSelfCheckInFormGroup ? .controls;
            e.serviceOptionFormGroup && e.serviceOptionFormGroup.touched && e.serviceOptionFormGroup.valid && (this.validationGroups[0].isValid = !0, this.validationGroups[0].disabled = !0), this.validationGroups.forEach((t, c) => {
                if (c === 0) return;
                let g = e[t.key];
                if (g)
                    if (t.key === "pickupInformationGroup") {
                        let k = e.pickupInformationGroup;
                        (k.get("address") ? .get("address_line") ? .value || "").length > 0 && k.valid ? (t.isValid = !0, t.disabled = !1) : t.isValid = void 0
                    } else t.key === "verifyUserGroup" ? (t.isValid = this.isOTPVerified() ? !0 : void 0, t.disabled = !1) : g.valid ? (t.isValid = !0, t.disabled = !1) : g.invalid && (t.isValid = void 0)
            })
        }
        subscribeToForm() {
            this.guestSelfCheckInFormGroup.statusChanges.pipe(ce(this.destroyRef)).subscribe(() => {
                this.checkFormGroupValidity()
            })
        }
        get mobileNumberValidators() {
            let e = this.generalSettingDataService.getGeneralSettingByKey("disable_mobile_number_validation"),
                i = this.tenantService ? .config() ? .mobile_regex;
            return e || !i ? [J.phoneNumberValidator] : [J.phoneNumberValidator, V.pattern(i)]
        }
        setupForm() {
            this.guestSelfCheckInForm = this.formBuilder.group({
                serviceOptionFormGroup: this.formBuilder.group({
                    is_recovery: new y(this.isRecovery(), V.required)
                }),
                basicInformationGroup: this.formBuilder.group(oi({
                    name: new y(null, [V.required, J.nameValidator]),
                    email: new y(null, [V.email]),
                    mobile_number: new y("", this.mobileNumberValidators),
                    mobile_country_code: new y(null),
                    term_and_condition: new y(""),
                    agree_term_and_conditions: new y(!1, V.requiredTrue),
                    status: [Vi.OPEN, V.required],
                    id: null,
                    assigned_user_id: 1,
                    job_id: null
                }, this.showAddressOnBasicInfo() ? {
                    address: this.formBuilder.group({
                        address_line: new y(""),
                        state: new y(""),
                        city: new y(""),
                        zip_code: new y("")
                    })
                } : {}), {
                    validators: J.atLeastOne(V.required, ["email", "mobile_number"])
                }),
                deviceInformationGroup: this.formBuilder.group({
                    device_type_id: new y(null, V.required),
                    device_brand_id: new y(null, V.required),
                    device_model_id: new y(null, V.required),
                    custom_brand_name: new y(""),
                    custom_model_name: new y(""),
                    serial_number: new y(""),
                    serial_number_2: new y(""),
                    accessories: new y([]),
                    device_password: new y(""),
                    size: new y(""),
                    repairables: new y([]),
                    capacity_measure: new y(Te.GB),
                    comment: new y(""),
                    contact_us_type: new y([Ve.CONTACT_US.name]),
                    attachments: new y([])
                }),
                pickupInformationGroup: this.formBuilder.group({
                    is_pickup_booked: new y(!1),
                    scheduled_on: new y(this.getDefaultPickupDateTime(), V.required),
                    address: this.formBuilder.group({
                        address_line: new y(""),
                        state: new y(""),
                        city: new y(""),
                        zip_code: new y("")
                    })
                })
            }), this.setupVerifyUserForm(), this.addSizeValidations(), this.getTermsAndConditions(), this.addCustomerDetailsToForm(), this.addPickupDateTimeValidators(), this.applyAddressMandatorySetting()
        }
        applyAddressMandatorySetting() {
            if (!this.isAddressMandatory()) return;
            let e = this.pickupAddressInformationFormGroup ? .get("address_line");
            if (e && (e.addValidators(V.required), e.updateValueAndValidity()), this.showAddressOnBasicInfo()) {
                let i = this.basicInformationGroup ? .get("address") ? .get("address_line");
                i && (i.addValidators(V.required), i.updateValueAndValidity())
            }
        }
        addCustomerDetailsToForm() {
            if (this.basicInformationGroup.controls.name.patchValue(this.customerName()), this.basicInformationGroup.controls.email.patchValue(this.customerEmail()), this.basicInformationGroup.controls.mobile_number.patchValue(this.customerMobileNumber()), this.showAddressOnBasicInfo() && this.customer ? .address) {
                let {
                    address_line: e,
                    state: i,
                    city: t,
                    zip_code: c
                } = this.customer.address;
                this.basicInformationGroup.get("address") ? .patchValue({
                    address_line: e,
                    state: i,
                    city: t,
                    zip_code: c
                })
            }
        }
        setupVerifyUserForm() {
            this.isLoggedIn() ? this.guestSelfCheckInForm.addControl("verifyUserGroup", this.formBuilder.group({
                google_recaptcha: new y("")
            })) : this.guestSelfCheckInForm.addControl("verifyUserGroup", this.formBuilder.group({
                verify_type: new y(""),
                otp: new y(null, V.required),
                email: new y("", [V.email]),
                mobile_number: new y("", [J.phoneNumberValidator]),
                mobile_country_code: new y(null),
                google_recaptcha: new y("")
            }, {
                validators: J.atLeastOne(V.required, ["email", "mobile_number"])
            }))
        }
        setVerificationServiceType() {
            this.hasPrimaryActiveSmsService() ? this.verifyUserGroup.get("verify_type") ? .patchValue(E.MOBILE) : this.verifyUserGroup.get("verify_type") ? .patchValue(E.EMAIL)
        }
        addServiceOptionToValidationGroup() {
            this.validationGroups.unshift({
                id: 0,
                icon: "fa-thin fa-wrench",
                label: this.isMobileDevice() ? S("common_service") : S("service_option"),
                visible: this.jobServiceOption() === "Both",
                hint: S("service_option"),
                disabled: !1,
                key: "serviceOptionFormGroup"
            })
        }
        manageServiceOptionInValidationGroup() {
            this.jobServiceOption() === "Both" ? this.addServiceOptionToValidationGroup() : (this.validationGroups[0].isValid = void 0, this.validationGroups[0].disabled = !1, this.selectedStepId.set(0))
        }
        addCustomerAddressDetails() {
            let {
                address_line: e,
                state: i,
                city: t,
                zip_code: c
            } = this.customer.address;
            this.pickupInformationGroup.controls.address.patchValue({
                address_line: e,
                state: i,
                city: t,
                zip_code: c
            })
        }
        getTermsAndConditions() {
            this.termAndConditionService.getByTypeId({
                type_id: Mi.SELF_CHECKIN
            }).subscribe({
                next: e => {
                    this.basicInformationGroup.get("term_and_condition").patchValue(e ? .text)
                }
            })
        }
        fetchCustomerDetails() {
            this.customerService.getById(this.currentUser().id).subscribe({
                next: e => {
                    this.customer = e, this.customerName.set(this.customer.name || null), this.customerMobileNumber.set(this.customer ? .mobile_number || null), this.customerEmail.set(this.customer ? .email || null), this.basicInformationGroup && this.addCustomerDetailsToForm()
                },
                error: () => {
                    this.toastNotificationService.error("notification_user_fetch_error")
                }
            })
        }
        subscribeToEmailValueChanges() {
            this.basicInformationGroup.controls.email.valueChanges.pipe(ce(this.destroyRef)).subscribe(e => {
                if (this.customerEmail() !== e) {
                    if (this.hasVerificationValueChanged.set(!0), this.verificationValueChanged().find(i => i === "Email")) return;
                    this.verificationValueChanged.update(i => [...i, "Email"])
                } else {
                    this.hasVerificationValueChanged.set(!1);
                    let i = this.verificationValueChanged().filter(t => t !== "Email");
                    this.verificationValueChanged.set(i)
                }
            })
        }
        subscribeToMobileNumberValueChanges() {
            this.basicInformationGroup.controls.mobile_number.valueChanges.pipe(ce(this.destroyRef)).subscribe(e => {
                if (this.customerMobileNumber() !== e) {
                    if (this.hasVerificationValueChanged.set(!0), this.verificationValueChanged().find(i => i === "MobileNumber")) return;
                    this.verificationValueChanged.update(i => [...i, "MobileNumber"])
                } else {
                    this.hasVerificationValueChanged.set(!1);
                    let i = this.verificationValueChanged().filter(t => t !== "MobileNumber");
                    this.verificationValueChanged.set(i)
                }
            })
        }
        addSizeValidations() {
            let e = this.serviceOptionFormGroup.controls.is_recovery;
            this.applySizeValidator(!!e ? .value), e ? .valueChanges.pipe(ce(this.destroyRef)).subscribe(i => {
                this.applySizeValidator(i)
            })
        }
        applySizeValidator(e) {
            let i = this.deviceInformationGroup.get("size");
            e ? i ? .addValidators(V.required) : i ? .removeValidators(V.required), i ? .updateValueAndValidity()
        }
        getDefaultPickupDateTime() {
            let e = this.pickupMinDateTime();
            return this.isBusinessHourSet() ? Ae.getFirstAvailableDateTime(this.businessHours, e) : e
        }
        addPickupDateTimeValidators() {
            let e = this.pickupInformationGroup.get("scheduled_on"),
                i = [];
            e && (e.clearValidators(), i.push(V.required), this.isBusinessHourSet() && i.push(Ae.businessHoursValidator(this.businessHours)), e.addValidators(i), e.updateValueAndValidity())
        }
        addValidatorsRecursively(e) {
            Object.keys(e.controls).forEach(i => {
                let t = e.get(i);
                t instanceof Ie ? this.addValidatorsRecursively(t) : (t.addValidators(V.required), t.updateValueAndValidity())
            })
        }
        removeValidatorsRecursively(e) {
            Object.keys(e.controls).forEach(i => {
                let t = e.get(i);
                t instanceof Ie ? this.removeValidatorsRecursively(t) : (t.clearValidators(), t.updateValueAndValidity())
            })
        }
        removeFormControlsRecursively(e, i) {
            Object.keys(e.controls).forEach(t => {
                let c = e.get(t);
                i.includes(t) ? e.removeControl(t) : c instanceof Ie && this.removeFormControlsRecursively(c, i)
            })
        }
        onSelectionChanged(e) {
            let {
                addedItems: i
            } = e, t = i[0].label, c = this.validationGroups.findIndex(g => g.label === t);
            this.selectedStepId.set(c)
        }
        goToNextStep(e) {
            let i = this.validationGroups.findIndex(t => t.id === e);
            this.validationGroups[i].isValid = !0, this.validationGroups[i + 1].disabled = !1, this.validationGroups[i + 1].isValid = void 0, this.selectedStepId.set(i + 1), this.checkFormGroupValidity()
        }
        goToPreviousStep() {
            this.selectedStepId.update(e => e - 1)
        }
        flattenFormValue(e) {
            let i = {};
            for (let t in e) {
                if (!e.hasOwnProperty(t)) continue;
                let c = e[t];
                if (t === "address") {
                    i[t] = c;
                    continue
                }
                if (c && typeof c == "object" && !Array.isArray(c) && Object.prototype.toString.call(c) === "[object Object]") {
                    let k = this.flattenFormValue(c);
                    Object.assign(i, k)
                } else i[t] = c
            }
            return i
        }
        submit() {
            this.isSaving || (this.isSaving = !0, this.reCaptchaV3Service.execute(this.siteKey, "attempt", e => {
                if (this.verifyUserGroup.controls.google_recaptcha.patchValue(e), this.errorResponse = null, this.basicInformationGroup.controls.assigned_user_id.patchValue(1), this.guestSelfCheckInFormGroup.valid) {
                    this.loaderService.show();
                    let i = this.guestSelfCheckInForm.getRawValue(),
                        t = this.flattenFormValue(i);
                    this.guestService.create(t).subscribe({
                        next: c => {
                            this.selfCheckInResponse.set(c), this.deviceInformationFormComponent.uploadAttachments(c), this.isFormSubmitted.set(!0), this.toastNotificationService.success("notification_response_save_success"), this.guestSelfCheckInForm.reset()
                        },
                        error: c => {
                            this.errorResponse = c
                        }
                    }).add(() => {
                        this.isSaving = !1, this.loaderService.hide()
                    })
                } else this.isSaving = !1
            }, {
                useGlobalDomain: !0
            }))
        }
        goToAddPickupStep(e) {
            this.addValidatorsToAddress(), this.addPickupDateTimeValidators(), this.isLoggedIn() && this.addCustomerAddressDetails(), this.copyBasicInfoAddressToPickup(), this.goToNextStep(e)
        }
        copyBasicInfoAddressToPickup() {
            if (!this.showAddressOnBasicInfo()) return;
            let e = this.basicInformationGroup.get("address") ? .value;
            e && this.pickupAddressInformationFormGroup ? .patchValue({
                address_line: e.address_line,
                state: e.state,
                city: e.city,
                zip_code: e.zip_code
            })
        }
        removePickupValidators() {
            this.removeValidatorsRecursively(this.pickupInformationGroup)
        }
        goToVerifyUserStepDirectly(e) {
            this.pickupInformationGroup && (this.pickupInformationGroup.reset(), this.pickupInformationGroup.controls.is_pickup_booked.patchValue(!1), this.removePickupValidators());
            let i = this.validationGroups.findIndex(g => g.key === "basicInformationGroup"),
                t = this.validationGroups.findIndex(g => g.key === "pickupInformationGroup"),
                c = this.validationGroups.findIndex(g => g.key === "verifyUserGroup");
            i !== -1 && (this.validationGroups[i].isValid = !0), t !== -1 && (this.validationGroups[t].disabled = !0), this.validationGroups[c].isValid = void 0, this.validationGroups[c].disabled = !1, this.selectedStepId.set(c)
        }
        serviceOptionFormCompleted(e) {
            this.validationGroups[0].disabled = !0, this.goToNextStep(e)
        }
        setSidebarLogo() {
            return this.tenantConfig() ? .logo && [$e.STANDARD, $e.ENTERPRISE].includes(this.plan()) ? this.tenantConfig().logo : "/assets/images/bytephase.png"
        }
        goToBasicInformationStep(e) {
            this.goToNextStep(e), this.subscribeToEmailValueChanges(), this.subscribeToMobileNumberValueChanges()
        }
        goToPreviousAddPickupStep() {
            this.addValidatorsToAddress(), this.addPickupDateTimeValidators(), this.isLoggedIn() && this.addCustomerAddressDetails(), this.goToPreviousStep(), this.validationGroups[this.selectedStepId()].disabled = !1, !this.validationGroups[this.selectedStepId()].isValid && (this.validationGroups[this.selectedStepId()].isValid = void 0)
        }
        hasPrimaryActiveSmsService() {
            return this.tenantService ? .config() ? .active_integrations.some(e => e.group === "sms" && e.is_primary === !0 && e.status === "Active")
        }
        addValidatorsToAddress() {
            let e = this.pickupInformationGroup.controls;
            Object.keys(e).forEach(i => {
                let t = e[i];
                if (i === "address") {
                    let c = t;
                    c.controls && Object.keys(c.controls).forEach(g => {
                        let k = c.controls[g];
                        g === "city" && (this.hideCity() || this.isCityOptional()) || g === "state" && (this.hideState() || this.isStateOptional()) || g === "zip_code" && (this.hidePostalCode() || this.isPostalCodeOptional()) ? k.clearValidators() : k.addValidators(V.required), k.updateValueAndValidity()
                    })
                } else t.addValidators(V.required), t.updateValueAndValidity()
            })
        }
        displayValuesInSidebar(e) {
            this.deviceFormControlValues = e
        }
        handleEnterKey(e) {
            e.target.id !== "submit-button" && e.preventDefault()
        }
        truncateText(e) {
            return Ee.truncateText(10, 11, e)
        }
        skipPickupAndSubmit() {
            this.removePickupValidators(), this.removeFormControlsRecursively(this.pickupInformationGroup, ["scheduled_on", "address"]), this.submit()
        }
        isDeviceImagePresent(e) {
            return e ? .attachments ? .[0] ? .link ? e.attachments[0].link : e ? .hasOwnProperty("device_brand_id") ? "/assets/images/device-model-default.png" : e ? .hasOwnProperty("device_type_id") ? "/assets/images/device-brand-default.png" : e ? .hasOwnProperty("name") && e ? .hasOwnProperty("id") ? "/assets/images/device-type-default.png" : "/assets/images/accessory-default.png"
        }
        hasUserVerified(e) {
            this.isOTPVerified.set(e)
        }
        submitAnotherForm() {
            this.router.navigate(["guest", "lead"]), window.location.reload()
        }
        backToLogin() {
            this.router.navigate(["auth", "login"])
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275cmp = w({
                type: o,
                selectors: [
                    ["app-self-check-in-form"]
                ],
                viewQuery: function(i, t) {
                    if (i & 1 && xe(Pe, 5)(He, 5), i & 2) {
                        let c;
                        se(c = le()) && (t.stepper = c.first), se(c = le()) && (t.deviceInformationFormComponent = c.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 1,
                consts: [
                    ["stepper", ""],
                    [1, "wizard-container"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "flex-column", 2, "height", "100vh"],
                    [1, "summary-panel", 3, "ngClass", "ngStyle"],
                    [1, "d-flex", "flex-column", "w-100", "mt-4"],
                    [1, "text-center"],
                    [1, "text-start", "m-0", "m-1", "fs-5", "fw-medium"],
                    [1, "mt-2"],
                    [1, "m-0", "mt-4"],
                    [1, "mt-4"],
                    [1, "text-start", "fs-6", "m-1"],
                    [1, "d-flex", "flex-row", "gap-2", "justify-content-center", "mb-2"],
                    [1, "summary-card", "theme-secondary-bg"],
                    [1, "separator", "my-3"],
                    [1, "text-start", "m-0", "m-1", "fs-6", "fw-medium"],
                    [1, "m-0", "mb-1", "mt-3"],
                    [1, "m-0", "ps-3"],
                    [1, "m-0", "mb-1"],
                    [1, "d-flex", "flex-column", "align-items-center", "justify-content-center", "gap-2", 3, "title"],
                    ["alt", "Brand name", "width", "30px", "height", "30px", "loading", "lazy", 3, "src"],
                    [1, "mb-0", "summary-card-title", 3, "ngClass", "ngStyle"],
                    [1, "fw-bold"],
                    [1, "m-1", "mb-2"],
                    [1, "d-flex", "flex-column", "w-100", "mt-4", 3, "keydown.enter"],
                    [3, "onSelectionChanged", "selectedIndex"],
                    [3, "label", "icon", "hint", "isValid", "disabled"],
                    ["autocomplete", "off", 3, "formGroup"],
                    [3, "selectedIndex", "animationEnabled", "swipeEnabled"],
                    [3, "allDeviceInformationValue", "deviceInformationFormCompleted", "backToLogin", "guestSelfCheckInFormGroup", "deviceInformationControlList", "allDeviceTypeList", "allDeviceBrandList", "allDeviceModelList", "allAccessoriesList", "allRepairServicesList"],
                    [3, "goToDeviceInformationForm", "goToAddPickupStep", "goToVerifyUserForm", "skipPickupAndSubmit", "isLoggedIn", "basicInformationGroup", "guestSelfCheckInFormGroup", "isOTPVerified", "isAddressMandatory", "hideCity", "hideState", "hidePostalCode", "showAddressOnBasicInfo", "hidePickup"],
                    [3, "serviceOptionFormCompleted", "guestSelfCheckInFormGroup", "serviceOptions"],
                    [3, "isLoggedIn", "guestSelfCheckInFormGroup", "disabledDates", "pickupMinDateTime", "pickupMinLeadHoursEnabled", "hideCity", "hideState", "hidePostalCode"],
                    [3, "verifyUserWithoutSchedulingPickup", "goToBasicInformationForm", "goToVerifyUserStep", "formSubmitted", "isLoggedIn", "guestSelfCheckInFormGroup", "disabledDates", "pickupMinDateTime", "pickupMinLeadHoursEnabled", "hideCity", "hideState", "hidePostalCode"],
                    [3, "verifyUserFormCompleted", "isUserVerified", "goToSchedulePickupStep", "guestSelfCheckInFormGroup", "isLoggedIn", "customerMobileNumber", "customerEmail", "hasValueChanged", "valueChanged", "hasPrimaryActiveSmsService", "isFormSubmitted"],
                    [1, "p-3", 3, "ngClass", "ngStyle"],
                    ["alt", "Brand name", "width", "150px", "height", "150px", 3, "src"],
                    [1, "text-center", "mt-3"],
                    [1, "fw-normal"],
                    [1, "fw-normal", "mt-3"],
                    [1, "border", "rounded", "p-3", "mt-3", "mx-1", "text-start", "small", "lh-base"],
                    [1, "mt-4", "px-3"],
                    [1, "fw-bold", "mb-3"],
                    [1, "row", "g-3"],
                    [1, "col-4"],
                    [1, "text-muted", "mb-1", "small"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    ["width", "28", "height", "28", "loading", "lazy", 1, "rounded", 3, "src", "alt"],
                    [1, "fw-semibold", "mb-0"],
                    [1, "mt-3"],
                    [1, "mt-4", "mb-3"],
                    [1, "d-flex", "align-items-center", "justify-content-center", "mb-3"],
                    [1, "d-flex", "justify-content-center", "mb-3"],
                    ["suffixIcon", "fa-solid fa-arrow-right ms-1", 3, "saveBtnClick", "useSubmitBehavior", "saveText"],
                    ["cancelBtnId", "self-check-in-basic-info-cancel", "cancelLabel", "common_back", "saveBtnId", "self-check-in-social-info-save", 1, "w-100", 3, "cancelClick", "saveClick", "isOnPopup", "saveText"]
                ],
                template: function(i, t) {
                    i & 1 && p(0, mn, 3, 2, "div", 1)(1, vn, 39, 25, "div", 2), i & 2 && u(t.selfCheckInResponse() ? 1 : 0)
                },
                dependencies: [O, j, Pi, Si, B, N, A, me, Qi, Pe, Ji, st, ft, He, vt, ht, Ct, Ui],
                styles: [".wizard-container[_ngcontent-%COMP%]     .dx-step.dx-state-disabled .dx-step-caption{color:var(--theme-font-color)}.wizard-container[_ngcontent-%COMP%]{display:flex;gap:20px}.summary-dark[_ngcontent-%COMP%]{background:#10172a;color:#fff}.summary-light[_ngcontent-%COMP%]{background:#fff}.summary-panel[_ngcontent-%COMP%]{width:400px;padding:20px;position:sticky;top:0;overflow-y:auto}.logged-in-sidebar-height[_ngcontent-%COMP%]{height:calc(100vh - 4.5rem)}.guest-side-bar-panel-height[_ngcontent-%COMP%]{height:100vh}.stepper-panel[_ngcontent-%COMP%]{flex:1;padding:20px}.sidebar-tenant-logo[_ngcontent-%COMP%]{max-width:100%;max-height:100%;object-fit:contain;object-position:center}.summary-card[_ngcontent-%COMP%]{padding:20px;background:#fff;display:flex;justify-content:center;align-items:center;font-size:.8rem;font-weight:500;text-align:center;border-radius:8px;cursor:pointer;box-shadow:0 2px 5px #00000026;transition:transform .2s,box-shadow .2s;width:80px;height:80px;color:#000}.summary-card-title[_ngcontent-%COMP%]{word-break:break-word;width:70px;font-size:.7rem}"]
            })
        }
    }
    return o
})();
var hn = [{
        path: "",
        component: mt,
        children: [{
            path: "lead",
            component: gt,
            title: "BytePhase | Lead form",
            canActivate: [Ze]
        }, {
            path: "pickup",
            component: dt,
            title: "BytePhase | Schedule Pickup form",
            canActivate: [Ze]
        }]
    }],
    bt = (() => {
        class o {
            static {
                this.\u0275fac = function(i) {
                    return new(i || o)
                }
            }
            static {
                this.\u0275mod = Se({
                    type: o
                })
            }
            static {
                this.\u0275inj = be({
                    imports: [We.forChild(hn), We]
                })
            }
        }
        return o
    })();
var is = (() => {
    class o {
        static {
            this.\u0275fac = function(i) {
                return new(i || o)
            }
        }
        static {
            this.\u0275mod = Se({
                type: o
            })
        }
        static {
            this.\u0275inj = be({
                imports: [bi, bt, $i, Bi, Ni, Fi, yi, at, Le, ct]
            })
        }
    }
    return o
})();
export {
    is as GuestModule
};