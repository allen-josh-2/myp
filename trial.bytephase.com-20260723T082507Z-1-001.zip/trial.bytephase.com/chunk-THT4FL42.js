import {
    a as _s
} from "./chunk-FVAZ73PS.js";
import {
    a as gs
} from "./chunk-73S5G3JB.js";
import {
    Bc as wn,
    Cd as ms,
    Dc as Oo,
    Gc as Sn,
    Hb as vn,
    Jc as Do,
    Kc as Ro,
    Na as To,
    O as pn,
    T as ho,
    Ta as _n,
    W as Ci,
    Wa as yo,
    ba as go,
    da as _o,
    ea as gn,
    fa as ps,
    ha as vo,
    ia as la,
    id as Ti,
    ke as yi,
    lb as Or,
    na as wo,
    oc as ko,
    oe as xs,
    pc as Fo,
    ph as Po,
    qc as Ao,
    rc as bo,
    sa as So,
    sc as Io,
    xc as Mo,
    ya as Eo,
    za as Co
} from "./chunk-DCKGQUHB.js";
import {
    $a as we,
    $b as ja,
    Aa as Y0,
    Ab as io,
    Ba as K0,
    Ci as xo,
    Db as cs,
    Ea as J0,
    Eb as ls,
    Ec as dn,
    Ei as hs,
    Fa as k,
    Fb as tr,
    Fh as ca,
    H as X0,
    Hb as oa,
    Ib as q,
    Jb as ge,
    Ka as Z0,
    Kb as Fe,
    Lb as rt,
    Mi as mn,
    Na as nt,
    Nb as no,
    Oa as un,
    Pb as rr,
    Qa as Q0,
    Qb as ar,
    Qi as xn,
    R as q0,
    Ra as _r,
    Rb as ir,
    Sa as os,
    Tc as hn,
    X as j0,
    Xa as eo,
    Za as to,
    _a as ve,
    _b as qa,
    aa as er,
    b as ss,
    ba as fn,
    bc as fs,
    cb as vr,
    da as $0,
    db as wr,
    ea as De,
    eb as Ce,
    fb as I,
    gb as D,
    gc as so,
    ha as qe,
    hb as ae,
    hc as oo,
    hd as co,
    ia as je,
    m as G0,
    mc as us,
    me as Si,
    n as fr,
    oa as Ta,
    oe as po,
    pd as lo,
    q as ln,
    qa as Xa,
    qb as st,
    qd as fo,
    sb as it,
    sd as uo,
    t as z0,
    ta as gr,
    ub as te,
    ui as mo,
    vd as ds,
    xk as pe,
    yb as ro,
    z as za,
    zb as ao,
    zi as Ei
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as Ca,
    b as Ga,
    i as Qt
} from "./chunk-FBFWB55K.js";
var No = _o(),
    Lo = null,
    Uo = {},
    Bo = {
        "top left": {
            top: 10,
            left: 10
        },
        "top right": {
            top: 10,
            right: 10
        },
        "bottom left": {
            bottom: 10,
            left: 10
        },
        "bottom right": {
            bottom: 10,
            right: 10
        },
        "top center": e => ({
            top: 10,
            left: Math.round(e.windowWidth / 2 - e.toastWidth / 2)
        }),
        "left center": e => ({
            top: Math.round(e.windowHeight / 2 - e.toastHeight / 2),
            left: 10
        }),
        "right center": e => ({
            top: Math.round(e.windowHeight / 2 - e.toastHeight / 2),
            right: 10
        }),
        center: e => ({
            top: Math.round(e.windowHeight / 2 - e.toastHeight / 2),
            left: Math.round(e.windowWidth / 2 - e.toastWidth / 2)
        }),
        "bottom center": e => ({
            bottom: 10,
            left: Math.round(e.windowWidth / 2 - e.toastWidth / 2)
        })
    },
    Ou = {
        up: (e, r) => ({
            bottom: e.bottom ? ? r.windowHeight - r.toastHeight - (e.top ? ? 0),
            top: "",
            left: e.left ? ? "",
            right: e.right ? ? ""
        }),
        down: (e, r) => ({
            top: e.top ? ? r.windowHeight - r.toastHeight - (e.bottom ? ? 0),
            bottom: "",
            left: e.left ? ? "",
            right: e.right ? ? ""
        }),
        left: (e, r) => ({
            right: e.right ? ? r.windowWidth - r.toastWidth - (e.left ? ? 0),
            left: "",
            top: e.top ? ? "",
            bottom: e.bottom ? ? ""
        }),
        right: (e, r) => ({
            left: e.left ? ? r.windowWidth - r.toastWidth - (e.right ? ? 0),
            right: "",
            top: e.top ? ? "",
            bottom: e.bottom ? ? ""
        })
    },
    Du = e => mn(e) && e.includes("top") ? "down-push" : "up-push",
    Ru = e => {
        let r = gn("<div>").appendTo(ps());
        return Uo[e] = r, r
    },
    Pu = e => Uo[e] || Ru(e),
    Nu = (e, r) => {
        let t = `dx-toast-stack dx-toast-stack-${r}-direction`;
        e.removeAttr("class").addClass(t)
    },
    Lu = (e, r) => {
        let t = e ? Bo[e] : Bo["bottom center"];
        return typeof t == "function" ? t(r) : t
    },
    Bu = (e, r, t) => {
        let a = e.replace(/-push|-stack/g, ""),
            i = Ou[a];
        return i ? i(r, t) : {
            top: "",
            bottom: "",
            left: "",
            right: ""
        }
    },
    Uu = (e, r, t) => {
        let {
            offsetWidth: a,
            offsetHeight: i
        } = e.children().first().get(0), n = {
            toastWidth: a,
            toastHeight: i,
            windowHeight: No.innerHeight,
            windowWidth: No.innerWidth
        }, s = mn(t) ? Lu(t, n) : t, o = Bu(r, s, n);
        e.css(o)
    },
    Vu = (e, r, t) => {
        let a = xn(e) ? e : {
                message: e
            },
            i = xn(r) ? r : void 0,
            n = xn(r) ? void 0 : r,
            {
                onHidden: s,
                onShowing: o
            } = a,
            c = {
                onHidden: f => {
                    gn(f.element).remove(), s ? .(f)
                }
            };
        if (n !== void 0 && (c.type = n), t !== void 0 && (c.displayTime = t), i != null && i.position) {
            let {
                position: f
            } = i, u = i.direction || Du(f), h = mn(f) ? f : `${f.top}-${f.left}-${f.bottom}-${f.right}`, p = Pu(h);
            return Nu(p, u), Object.assign({}, a, c, {
                container: p,
                _skipContentPositioning: !0,
                onShowing: d => {
                    Uu(p, u, f), o ? .(d)
                }
            })
        }
        return Object.assign({}, a, c)
    },
    Wu = (e, r, t) => {
        let a = Vu(e, r, t);
        Lo = gn("<div>").appendTo(ps()), new Io(Lo, a).show()
    },
    Vo = Wu;
var Wo = (() => {
    class e {
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-import"]
                ],
                standalone: !1,
                decls: 1,
                vars: 0,
                template: function(a, i) {
                    a & 1 && ae(0, "router-outlet")
                },
                dependencies: [fo],
                styles: ["[_nghost-%COMP%]{display:block;width:100%;height:100%}"]
            })
        }
    }
    return e
})();

function dt(e, r) {
    let t = pe(e);
    return r && Object.keys(r).forEach(a => {
        let i = new RegExp(`\\{${a}\\}`, "g");
        t = t.replace(i, String(r[a]))
    }), t
}
var $a = {
        MIN_PROGRESS_DISPLAY: 500,
        STEP_TRANSITION: 300,
        TOAST_DURATION: 1500,
        IMPORT_COMPLETE_RESET: 1500
    },
    zC = {
        FILE_TYPE_DETECTION_BYTES: 4,
        MAX_FILE_SIZE: 10 * 1024 * 1024,
        PROCESSING_CHUNK_SIZE: 1e3
    };
var En = (() => {
    class e {
        constructor() {
            this.progressSignal = Xa(0), this.statusSignal = Xa(""), this.isImportingSignal = Xa(!1), this.currentRowSignal = Xa(0), this.totalRowsSignal = Xa(0), this.progress = this.progressSignal.asReadonly(), this.status = this.statusSignal.asReadonly(), this.isImporting = this.isImportingSignal.asReadonly(), this.currentRow = this.currentRowSignal.asReadonly(), this.totalRows = this.totalRowsSignal.asReadonly(), this.percentageText = us(() => `${this.progress()}%`), this.rowProgressText = us(() => `${this.currentRow()} / ${this.totalRows()}`)
        }
        reset() {
            this.progressSignal.set(0), this.statusSignal.set(""), this.isImportingSignal.set(!1), this.currentRowSignal.set(0), this.totalRowsSignal.set(0)
        }
        startImport(t) {
            this.reset(), this.totalRowsSignal.set(t), this.isImportingSignal.set(!0), this.updateStatus("preparing_import"), this.updateProgress(0)
        }
        updateUploadProgress(t) {
            this.updateStatus("uploading_file"), this.updateProgress(0)
        }
        updateValidationProgress(t) {
            this.updateStatus("validating_data"), this.updateProgress(0)
        }
        updateImportProgress(t, a) {
            this.currentRowSignal.set(t), this.updateStatus("importing_row", {
                current: t,
                total: a
            });
            let i = t / a * 90;
            this.updateProgress(i), console.log(`Import progress: ${t}/${a} -> ${Math.round(i)}%`)
        }
        completeImport(t) {
            this.updateProgress(100), this.updateStatus(t ? "import_complete" : "import_failed"), setTimeout(() => {
                this.isImportingSignal.set(!1)
            }, $a.IMPORT_COMPLETE_RESET)
        }
        updateProgress(t) {
            let a = Math.min(100, Math.max(0, Math.round(t)));
            console.log(`Setting progress signal to: ${a}%`), this.progressSignal.set(a)
        }
        updateStatus(t, a) {
            let i = a ? dt(t, a) : pe(t);
            this.statusSignal.set(i)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var fa = {
        EMAIL: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
        PHONE: {
            DIGITS_ONLY: /\D/g,
            MIN_DIGITS: 10,
            MAX_DIGITS: 15
        },
        BOOLEAN_VALUES: ["true", "false", "1", "0", "yes", "no", "y", "n"],
        CSV_FORMULA: /^[=+\-@]/,
        SCRIPT_TAG: /<script[^>]*>[\s\S]*?<\/script>/gi,
        HTML_TAG: /<[^>]+>/g
    },
    ct = {
        MAX_SIZE_MB: 10,
        MAX_PREVIEW_ROWS: 100,
        MAX_ROWS_BY_TYPE: po,
        SUPPORTED_FORMATS: ["csv", "xlsx", "xls"],
        FILE_READ_TIMEOUT_MS: 3e4,
        MIME_TYPES: {
            csv: ["text/csv", "application/csv", "text/plain"],
            xlsx: ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
            xls: ["application/vnd.ms-excel"]
        },
        MAGIC_NUMBERS: {
            xlsx: [80, 75, 3, 4],
            xls: [208, 207, 17, 224]
        }
    };
var ye = (function(e) {
        return e.STRING = "string", e.NUMBER = "number", e.BOOLEAN = "boolean", e.DATE = "date", e
    })(ye || {}),
    Ze = (function(e) {
        return e.REQUIRED = "required", e.EMAIL = "email", e.PHONE = "phone", e.MIN_LENGTH = "minLength", e.MAX_LENGTH = "maxLength", e.PATTERN = "pattern", e.NUMBER = "number", e.DATE = "date", e.UNIQUE = "unique", e
    })(Ze || {}),
    Sr = (function(e) {
        return e.ERROR = "error", e.WARNING = "warning", e
    })(Sr || {});
var be = (function(e) {
        return e.CUSTOMER = "customer", e.LEAD = "lead", e.PART = "part", e.EMPLOYEE = "employee", e.DEVICE_TYPE = "device_type", e.DEVICE_BRAND = "device_brand", e.DEVICE_MODEL = "device_model", e
    })(be || {}),
    Et = {
        [be.CUSTOMER]: {
            key: be.CUSTOMER,
            name: "Customers",
            icon: Ei.CUSTOMER.light,
            iconColor: "#3498db",
            apiPath: "customers/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.CUSTOMER,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_customer_help",
            fields: [{
                key: "name",
                label: "name",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 60,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "customer_name_required"
                }],
                sampleValue: "John Doe",
                aliases: ["Customer Name", "customer_name"]
            }, {
                key: "email",
                label: "email",
                required: !0,
                unique: !0,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.EMAIL,
                    message: "invalid_email"
                }],
                sampleValue: "john.doe@example.com"
            }, {
                key: "mobile_number",
                label: "mobile_number",
                required: !1,
                unique: !0,
                dataType: ye.STRING,
                maxLength: 20,
                validations: [{
                    type: Ze.PHONE,
                    message: "invalid_phone"
                }],
                sampleValue: "9876543210"
            }, {
                key: "phone_number",
                label: "phone_number",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 20,
                sampleValue: "1234567890"
            }, {
                key: "gst_number",
                label: "gst_number",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 20,
                sampleValue: "22AAAAA0000A1Z5"
            }, {
                key: "source_id",
                label: "source_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "Walk-in",
                aliases: ["Source", "source"]
            }, {
                key: "role_id",
                label: "role_id",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                defaultValue: "End User",
                sampleValue: "End User",
                aliases: ["Role", "role"]
            }, {
                key: "address_line",
                label: "address_line",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 200,
                sampleValue: "123 Main Street",
                aliases: ["Address", "Address Line"]
            }, {
                key: "city",
                label: "city",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "New York"
            }, {
                key: "state",
                label: "state",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "NY"
            }, {
                key: "zip_code",
                label: "zip_code",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 20,
                sampleValue: "10001"
            }]
        },
        [be.EMPLOYEE]: {
            key: be.EMPLOYEE,
            name: "Employees",
            icon: Ei.EMPLOYEE.light,
            iconColor: "#10B981",
            apiPath: "employees/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.EMPLOYEE,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_employee_help",
            fields: [{
                key: "name",
                label: "name",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 60,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "employee_name_required"
                }, {
                    type: Ze.MAX_LENGTH,
                    value: 60
                }],
                sampleValue: "Jane Smith",
                aliases: ["Employee Name", "employee_name"]
            }, {
                key: "email",
                label: "email",
                required: !0,
                unique: !0,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "email_required"
                }, {
                    type: Ze.EMAIL,
                    message: "invalid_email"
                }],
                sampleValue: "jane.smith@company.com",
                aliases: ["Email"]
            }, {
                key: "mobile_number",
                label: "mobile_number",
                required: !0,
                unique: !0,
                dataType: ye.STRING,
                maxLength: 20,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "mobile_number_required"
                }, {
                    type: Ze.PHONE,
                    message: "invalid_phone"
                }],
                sampleValue: "9876543210",
                aliases: ["Mobile Number", "Mobile"]
            }, {
                key: "display_name",
                label: "display_name",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 60,
                sampleValue: "Jane",
                aliases: ["Display Name"]
            }, {
                key: "phone_number",
                label: "phone_number",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 20,
                sampleValue: "1234567890",
                aliases: ["Phone Number", "Phone"]
            }, {
                key: "role",
                label: "role",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                defaultValue: "Technician",
                validations: [{
                    type: Ze.REQUIRED,
                    message: "role_required"
                }],
                sampleValue: "Technician",
                aliases: ["Role"]
            }, {
                key: "address_line",
                label: "address_line",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 200,
                sampleValue: "456 Office Street",
                aliases: ["Address", "Address Line"]
            }, {
                key: "city",
                label: "city",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "Mumbai",
                aliases: ["City"]
            }, {
                key: "state",
                label: "state",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "Maharashtra",
                aliases: ["State"]
            }, {
                key: "zip_code",
                label: "zip_code",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 20,
                sampleValue: "400001",
                aliases: ["Zip Code", "ZIP", "Postal Code"]
            }]
        },
        [be.LEAD]: {
            key: be.LEAD,
            name: "Leads",
            icon: Ei.LEAD.light,
            iconColor: "#F59E0B",
            apiPath: "leads/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.LEAD,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_lead_help",
            fields: [{
                key: "name",
                label: "name",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 60,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "lead_name_required"
                }, {
                    type: Ze.MAX_LENGTH,
                    value: 60
                }],
                sampleValue: "Potential Customer Inc",
                aliases: ["Lead Name"]
            }, {
                key: "email",
                label: "email",
                required: !1,
                unique: !0,
                dataType: ye.STRING,
                maxLength: 191,
                validations: [{
                    type: Ze.EMAIL,
                    message: "invalid_email"
                }],
                sampleValue: "contact@company.com",
                aliases: ["Email"]
            }, {
                key: "mobile_number",
                label: "mobile_number",
                required: !1,
                unique: !0,
                dataType: ye.STRING,
                maxLength: 20,
                validations: [{
                    type: Ze.PHONE,
                    message: "invalid_phone"
                }],
                sampleValue: "9876543210",
                aliases: ["Mobile Number", "Mobile"]
            }, {
                key: "phone_number",
                label: "phone_number",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 10,
                sampleValue: "1234567890",
                aliases: ["Phone Number", "Phone"]
            }, {
                key: "role_id",
                label: "role_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "End User",
                aliases: ["Role"]
            }, {
                key: "lead_source_id",
                label: "lead_source_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "Website",
                aliases: ["Lead Source", "Source"]
            }, {
                key: "status_id",
                label: "status_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "New",
                aliases: ["Status"]
            }, {
                key: "comment",
                label: "comment",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 500,
                sampleValue: "Interested in repair services",
                aliases: ["Comment"]
            }, {
                key: "address_line",
                label: "address_line",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 200,
                sampleValue: "123 Business Street",
                aliases: ["Address", "Address Line"]
            }, {
                key: "city",
                label: "city",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "New York",
                aliases: ["City"]
            }, {
                key: "state",
                label: "state",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "NY",
                aliases: ["State"]
            }, {
                key: "zip_code",
                label: "zip_code",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 20,
                sampleValue: "10001",
                aliases: ["Zip Code", "ZIP", "Postal Code"]
            }]
        },
        [be.PART]: {
            key: be.PART,
            name: "Parts",
            icon: Ei.PART.light,
            iconColor: "#8B5CF6",
            apiPath: "parts/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.PART,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_part_help",
            fields: [{
                key: "name",
                label: "name",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "part_name_required"
                }],
                sampleValue: "LCD Display",
                aliases: ["Part Name", "part_name"]
            }, {
                key: "quantity",
                label: "quantity",
                required: !0,
                unique: !1,
                dataType: ye.NUMBER,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "quantity_required"
                }, {
                    type: Ze.NUMBER,
                    message: "must_be_number"
                }],
                sampleValue: 50,
                aliases: ["Quantity"]
            }, {
                key: "sku",
                label: "sku",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                sampleValue: "LCD-001",
                aliases: ["SKU"]
            }, {
                key: "barcode_no",
                label: "barcode_no",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: 123456789012,
                aliases: ["Barcode", "Barcode No"]
            }, {
                key: "purchase_price",
                label: "purchase_price",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                validations: [{
                    type: Ze.NUMBER,
                    message: "must_be_number"
                }],
                sampleValue: 1500.5,
                aliases: ["Purchase Price", "Cost"]
            }, {
                key: "selling_price",
                label: "selling_price",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                validations: [{
                    type: Ze.NUMBER,
                    message: "must_be_number"
                }],
                sampleValue: 2e3,
                aliases: ["Selling Price", "Price"]
            }, {
                key: "low_stock_unit",
                label: "low_stock_unit",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: 10,
                aliases: ["Low Stock Threshold", "Min Stock"]
            }, {
                key: "unit",
                label: "unit",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                sampleValue: "pc",
                aliases: ["Unit"]
            }, {
                key: "tax_id",
                label: "tax_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "GST 18%",
                aliases: ["Tax"]
            }, {
                key: "tax_code",
                label: "tax_code",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                sampleValue: "GST18",
                aliases: ["Tax Code", "HSN Code", "HSN"]
            }, {
                key: "warranty",
                label: "warranty",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                sampleValue: "6 months",
                aliases: ["Warranty"]
            }, {
                key: "category_id",
                label: "category_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "Electronics",
                aliases: ["Category"]
            }, {
                key: "sub_category_id",
                label: "sub_category_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "Mobile Parts",
                aliases: ["Sub Category", "Subcategory"]
            }, {
                key: "storage_location_id",
                label: "storage_location_id",
                required: !1,
                unique: !1,
                dataType: ye.NUMBER,
                sampleValue: "Warehouse A",
                aliases: ["Storage Location", "Location"]
            }, {
                key: "description",
                label: "description",
                required: !1,
                unique: !1,
                dataType: ye.STRING,
                sampleValue: "High quality LCD display for mobile phones",
                aliases: ["Description"]
            }, {
                key: "is_manage_stock",
                label: "is_manage_stock",
                required: !1,
                unique: !1,
                dataType: ye.BOOLEAN,
                sampleValue: "Yes",
                aliases: ["Manage Stock", "Track Stock"]
            }, {
                key: "is_rate_including_tax",
                label: "is_rate_including_tax",
                required: !1,
                unique: !1,
                dataType: ye.BOOLEAN,
                sampleValue: "No",
                aliases: ["Rate Including Tax", "Tax Inclusive"]
            }, {
                key: "is_low_stock_alert",
                label: "is_low_stock_alert",
                required: !1,
                unique: !1,
                dataType: ye.BOOLEAN,
                sampleValue: "Yes",
                aliases: ["Low Stock Alert"]
            }]
        },
        [be.DEVICE_TYPE]: {
            key: be.DEVICE_TYPE,
            name: "Device Types",
            icon: hs.DEVICE.light,
            iconColor: "#14B8A6",
            apiPath: "device-types/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.DEVICE_TYPE,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_device_type_help",
            fields: [{
                key: "name",
                label: "name",
                required: !0,
                unique: !0,
                dataType: ye.STRING,
                maxLength: 100,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "device_type_name_required"
                }, {
                    type: Ze.MAX_LENGTH,
                    value: 100
                }],
                sampleValue: "Mobile Phone",
                aliases: ["Device Type", "device_type"]
            }]
        },
        [be.DEVICE_BRAND]: {
            key: be.DEVICE_BRAND,
            name: "Device Brands",
            icon: hs.BRAND.light,
            iconColor: "#EC4899",
            apiPath: "device-brands/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.DEVICE_BRAND,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_device_brand_help",
            fields: [{
                key: "device_type",
                label: "device_type",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "device_type_required"
                }],
                sampleValue: "Mobile Phone",
                aliases: ["Device Type"]
            }, {
                key: "name",
                label: "name",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "brand_name_required"
                }],
                sampleValue: "Apple",
                aliases: ["Brand Name", "brand_name", "device_brand", "Brand"]
            }]
        },
        [be.DEVICE_MODEL]: {
            key: be.DEVICE_MODEL,
            name: "Device Models",
            icon: xo.MOBILE.light,
            iconColor: "#6366F1",
            apiPath: "device-models/import",
            maxFileSize: ct.MAX_SIZE_MB,
            maxRows: ct.MAX_ROWS_BY_TYPE.DEVICE_MODEL,
            supportedFormats: ct.SUPPORTED_FORMATS,
            helpText: "import_device_model_help",
            fields: [{
                key: "device_type",
                label: "device_type",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "device_type_required"
                }],
                sampleValue: "Mobile Phone",
                aliases: ["Device Type", "Type", "device type"]
            }, {
                key: "device_brand",
                label: "device_brand",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "device_brand_required"
                }],
                sampleValue: "Apple",
                aliases: ["Device Brand", "Brand", "Brand Name", "Manufacturer"]
            }, {
                key: "name",
                label: "name",
                required: !0,
                unique: !1,
                dataType: ye.STRING,
                maxLength: 100,
                validations: [{
                    type: Ze.REQUIRED,
                    message: "model_name_required"
                }, {
                    type: Ze.MAX_LENGTH,
                    value: 100
                }],
                sampleValue: "iPhone 15 Pro",
                aliases: ["Device Model", "Model", "model_name", "Model Name", "device_model"]
            }]
        }
    };
var Er = (() => {
    class e {
        constructor() {
            this.toastr = De(pn), this.formatMessage = pe
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["ng-component"]
                ],
                inputs: {
                    importData: "importData"
                },
                standalone: !1,
                decls: 0,
                vars: 0,
                template: function(a, i) {},
                encapsulation: 2
            })
        }
    }
    return e
})();

function Hu(e, r) {
    e & 1 && (I(0, "div", 1)(1, "div", 11), ae(2, "i", 12), D()())
}

function Gu(e, r) {
    if (e & 1 && (I(0, "span", 10), q(1), D()), e & 2) {
        let t = te();
        k(), rt(" ", t.getRequiredFieldsCount(), " ", t.formatMessage("required"), " ")
    }
}
var Ho = (() => {
    class e {
        constructor() {
            this.selected = !1, this.selectImportType = new Ta, this.formatMessage = pe
        }
        onCardClick() {
            this.selectImportType.emit(this.importType)
        }
        getImportTypeName() {
            let a = {
                customer: "customers",
                employee: "employees",
                lead: "leads",
                part: "common_parts"
            }[this.importType.key] || this.importType.key;
            return pe(a)
        }
        getTotalFieldsCount() {
            return this.importType.fields ? .length || 0
        }
        getRequiredFieldsCount() {
            return this.importType.fields ? .filter(t => t.required).length || 0
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-import-type-card"]
                ],
                inputs: {
                    importType: "importType",
                    selected: "selected"
                },
                outputs: {
                    selectImportType: "selectImportType"
                },
                standalone: !1,
                decls: 15,
                vars: 11,
                consts: [
                    ["type", "button", 1, "selection-card", 3, "click"],
                    [1, "selection-card-indicator"],
                    [1, "selection-card-header"],
                    [1, "selection-card-icon-container"],
                    [1, "selection-card-title"],
                    [1, "fa-solid", "fa-chevron-right", "selection-card-arrow"],
                    [1, "selection-card-content"],
                    [1, "selection-card-description"],
                    [1, "selection-card-badges"],
                    [1, "selection-card-badge-item", "muted"],
                    [1, "selection-card-badge-item", "primary"],
                    [1, "selection-card-badge"],
                    [1, "fa-solid", "fa-circle-check"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "button", 0), it("click", function() {
                        return i.onCardClick()
                    }), ve(1, Hu, 3, 0, "div", 1), I(2, "div", 2)(3, "div", 3), ae(4, "i"), D(), I(5, "h5", 4), q(6), ae(7, "i", 5), D()(), I(8, "div", 6)(9, "p", 7), q(10), D(), I(11, "div", 8)(12, "span", 9), q(13), D(), ve(14, Gu, 2, 2, "span", 10), D()()()), a & 2 && (tr("selected", i.selected), k(), we(i.selected ? 1 : -1), k(2), eo("data-gradient", i.importType.key), k(), oa(i.importType.icon + " fa-2x"), k(2), Fe(" ", i.getImportTypeName(), " "), k(4), Fe(" ", i.formatMessage(i.importType.helpText), " "), k(3), rt(" ", i.getTotalFieldsCount(), " ", i.formatMessage("fields"), " "), k(), we(i.getRequiredFieldsCount() > 0 ? 14 : -1))
                },
                styles: ["[_nghost-%COMP%]{display:block;height:100%}"]
            })
        }
    }
    return e
})();
var Xu = (e, r) => r.key;

function qu(e, r) {
    if (e & 1 && (I(0, "div", 4)(1, "div", 7), ae(2, "i", 8), I(3, "span", 9), q(4), D()()()), e & 2) {
        let t = te();
        k(4), ge(t.formatMessage("ready_to_continue"))
    }
}

function ju(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 10)(1, "app-import-type-card", 11), it("selectImportType", function(i) {
            qe(t);
            let n = te(2);
            return je(n.onSelectImportType(i))
        }), D()()
    }
    if (e & 2) {
        let t = r.$implicit,
            a = te(2);
        k(), Ce("importType", t)("selected", a.isSelected(t))
    }
}

function $u(e, r) {
    if (e & 1 && (I(0, "div", 5), vr(1, ju, 2, 2, "div", 10, Xu), D()), e & 2) {
        let t = te();
        k(), wr(t.availableImportTypes)
    }
}

function Yu(e, r) {
    if (e & 1 && (I(0, "div", 6), ae(1, "i", 12), I(2, "div")(3, "h6", 13), q(4), D(), I(5, "p", 3), q(6), D()()()), e & 2) {
        let t = te();
        k(4), ge(t.formatMessage("no_permissions")), k(2), ge(t.formatMessage("no_import_permissions"))
    }
}
var Go = (() => {
    class e extends Er {
        constructor() {
            super(...arguments), this.userSessionService = De(go), this.tenantService = De(Or), this.IMPORT_TYPE_CONFIGS = Et, this.availableImportTypes = [], this.selectedType = null, this.typeSelected = new Ta
        }
        ngOnInit() {
            this.availableImportTypes = this.getAvailableImportTypes(), this.importData.type && (this.selectedType = this.importData.type)
        }
        getAvailableImportTypes() {
            let t = this.userSessionService.userPermissionList(),
                a = Object.values(Et),
                i = {
                    [be.CUSTOMER]: ca.IMPORT_CUSTOMER,
                    [be.EMPLOYEE]: ca.IMPORT_EMPLOYEE,
                    [be.LEAD]: ca.IMPORT_LEAD,
                    [be.PART]: ca.IMPORT_PART,
                    [be.DEVICE_TYPE]: ca.IMPORT_DEVICE_TYPE,
                    [be.DEVICE_BRAND]: ca.IMPORT_DEVICE_BRAND,
                    [be.DEVICE_MODEL]: ca.IMPORT_DEVICE_MODEL
                };
            return a.filter(n => {
                let s = i[n.key],
                    o = t.includes(s) || this.userSessionService.isAdmin();
                if (n.key === be.LEAD) {
                    let c = this.tenantService.isLitePlan() || this.tenantService.isBasicPlan();
                    return o && !c
                }
                return o
            })
        }
        onSelectImportType(t) {
            let a = this.importData.type && this.importData.type !== t.key;
            this.selectedType = t.key, this.importData.type = t.key, a && (this.importData.file = null, this.importData.data = [], this.importData.totalRows = void 0, this.importData.mappings = [], this.importData.validationResult = null, this.importData.importResult = null), setTimeout(() => {
                this.typeSelected.emit()
            }, $a.STEP_TRANSITION)
        }
        isSelected(t) {
            return this.selectedType === t.key
        }
        submit() {
            return this.importData.type ? fr(!0) : (this.toastr.error(this.formatMessage("select_import_type_error")), fr(!1))
        }
        static {
            this.\u0275fac = (() => {
                let t;
                return function(i) {
                    return (t || (t = gr(e)))(i || e)
                }
            })()
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-step-select-type"]
                ],
                outputs: {
                    typeSelected: "typeSelected"
                },
                standalone: !1,
                features: [_r],
                decls: 10,
                vars: 5,
                consts: [
                    [1, "step-select-type"],
                    [1, "d-flex", "align-items-start", "justify-content-between", "mb-4"],
                    [1, "mb-2"],
                    [1, "mb-0"],
                    [1, "ready-indicator"],
                    [1, "row", "g-3", "g-md-4"],
                    ["role", "alert", 1, "alert", "alert-warning", "d-flex", "align-items-center", "gap-3"],
                    [1, "d-flex", "align-items-center", "gap-2", "px-3", "py-2", "bg-success", "bg-opacity-10", "border", "border-success", "border-opacity-25", "rounded-3"],
                    [1, "fa-solid", "fa-circle-check", "text-success"],
                    [1, "text-success", "fw-medium"],
                    [1, "col-12", "col-sm-6", "col-lg-4", "col-xl-3"],
                    [3, "selectImportType", "importType", "selected"],
                    [1, "fa-thin", "fa-exclamation-triangle", "fa-2x"],
                    [1, "mb-1"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1)(2, "div")(3, "h5", 2), q(4), D(), I(5, "p", 3), q(6), D()(), ve(7, qu, 5, 1, "div", 4), D(), ve(8, $u, 3, 0, "div", 5), ve(9, Yu, 7, 2, "div", 6), D()), a & 2 && (k(4), ge(i.formatMessage("select_import_type")), k(2), ge(i.formatMessage("select_import_type_description")), k(), we(i.selectedType ? 7 : -1), k(), we(i.availableImportTypes.length > 0 ? 8 : -1), k(), we(i.availableImportTypes.length === 0 ? 9 : -1))
                },
                dependencies: [Ho],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   .step-select-type[_ngcontent-%COMP%]{min-height:400px;padding:0 1rem}[_nghost-%COMP%]   .step-select-type[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{color:var(--primary-text);font-weight:600;font-size:1.25rem}[_nghost-%COMP%]   .step-select-type[_ngcontent-%COMP%]   .ready-indicator[_ngcontent-%COMP%]{white-space:nowrap}[_nghost-%COMP%]   .step-select-type[_ngcontent-%COMP%]   .ready-indicator[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1rem}[_nghost-%COMP%]   .step-select-type[_ngcontent-%COMP%]   .ready-indicator[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.875rem}@media(min-width:992px){.step-select-type[_ngcontent-%COMP%]{padding:0 1.5rem!important}}@media(max-width:768px){.step-select-type[_ngcontent-%COMP%]   .ready-indicator[_ngcontent-%COMP%]{position:absolute;top:0;right:0}.step-select-type[_ngcontent-%COMP%]   .ready-indicator[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:none}.step-select-type[_ngcontent-%COMP%]   .ready-indicator[_ngcontent-%COMP%]   .d-flex[_ngcontent-%COMP%]{padding:.5rem!important}}"]
            })
        }
    }
    return e
})();
var Ui = {};
Ui.version = "0.18.5";
var zr = 1200,
    ni = 1252,
    Ju = [874, 932, 936, 949, 950, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1e4],
    Xs = {
        0: 1252,
        1: 65001,
        2: 65001,
        77: 1e4,
        128: 932,
        129: 949,
        130: 1361,
        134: 936,
        136: 950,
        161: 1253,
        162: 1254,
        163: 1258,
        177: 1255,
        178: 1256,
        186: 1257,
        204: 1251,
        222: 874,
        238: 1250,
        255: 1252,
        69: 6969
    },
    qs = function(e) {
        Ju.indexOf(e) != -1 && (ni = Xs[0] = e)
    };

function Zu() {
    qs(1252)
}
var Rr = function(e) {
    zr = e, qs(e)
};

function js() {
    Rr(1200), Zu()
}

function Ds(e) {
    for (var r = [], t = 0, a = e.length; t < a; ++t) r[t] = e.charCodeAt(t);
    return r
}

function Qu(e) {
    for (var r = [], t = 0; t < e.length >> 1; ++t) r[t] = String.fromCharCode(e.charCodeAt(2 * t) + (e.charCodeAt(2 * t + 1) << 8));
    return r.join("")
}

function Zc(e) {
    for (var r = [], t = 0; t < e.length >> 1; ++t) r[t] = String.fromCharCode(e.charCodeAt(2 * t + 1) + (e.charCodeAt(2 * t) << 8));
    return r.join("")
}
var Ai = function(e) {
        var r = e.charCodeAt(0),
            t = e.charCodeAt(1);
        return r == 255 && t == 254 ? Qu(e.slice(2)) : r == 254 && t == 255 ? Zc(e.slice(2)) : r == 65279 ? e.slice(1) : e
    },
    Cn = function(r) {
        return String.fromCharCode(r)
    },
    zo = function(r) {
        return String.fromCharCode(r)
    },
    Ye;
var _t = null,
    ki = !0,
    da = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function Vi(e) {
    for (var r = "", t = 0, a = 0, i = 0, n = 0, s = 0, o = 0, c = 0, l = 0; l < e.length;) t = e.charCodeAt(l++), n = t >> 2, a = e.charCodeAt(l++), s = (t & 3) << 4 | a >> 4, i = e.charCodeAt(l++), o = (a & 15) << 2 | i >> 6, c = i & 63, isNaN(a) ? o = c = 64 : isNaN(i) && (c = 64), r += da.charAt(n) + da.charAt(s) + da.charAt(o) + da.charAt(c);
    return r
}

function pr(e) {
    var r = "",
        t = 0,
        a = 0,
        i = 0,
        n = 0,
        s = 0,
        o = 0,
        c = 0;
    e = e.replace(/[^\w\+\/\=]/g, "");
    for (var l = 0; l < e.length;) n = da.indexOf(e.charAt(l++)), s = da.indexOf(e.charAt(l++)), t = n << 2 | s >> 4, r += String.fromCharCode(t), o = da.indexOf(e.charAt(l++)), a = (s & 15) << 4 | o >> 2, o !== 64 && (r += String.fromCharCode(a)), c = da.indexOf(e.charAt(l++)), i = (o & 3) << 6 | c, c !== 64 && (r += String.fromCharCode(i));
    return r
}
var Ue = (function() {
        return typeof Buffer < "u" && typeof process < "u" && typeof process.versions < "u" && !!process.versions.node
    })(),
    ra = (function() {
        if (typeof Buffer < "u") {
            var e = !Buffer.from;
            if (!e) try {
                Buffer.from("foo", "utf8")
            } catch (r) {
                e = !0
            }
            return e ? function(r, t) {
                return t ? new Buffer(r, t) : new Buffer(r)
            } : Buffer.from.bind(Buffer)
        }
        return function() {}
    })();

function pa(e) {
    return Ue ? Buffer.alloc ? Buffer.alloc(e) : new Buffer(e) : typeof Uint8Array < "u" ? new Uint8Array(e) : new Array(e)
}

function Xo(e) {
    return Ue ? Buffer.allocUnsafe ? Buffer.allocUnsafe(e) : new Buffer(e) : typeof Uint8Array < "u" ? new Uint8Array(e) : new Array(e)
}
var dr = function(r) {
    return Ue ? ra(r, "binary") : r.split("").map(function(t) {
        return t.charCodeAt(0) & 255
    })
};

function jn(e) {
    if (typeof ArrayBuffer > "u") return dr(e);
    for (var r = new ArrayBuffer(e.length), t = new Uint8Array(r), a = 0; a != e.length; ++a) t[a] = e.charCodeAt(a) & 255;
    return r
}

function _a(e) {
    if (Array.isArray(e)) return e.map(function(a) {
        return String.fromCharCode(a)
    }).join("");
    for (var r = [], t = 0; t < e.length; ++t) r[t] = String.fromCharCode(e[t]);
    return r.join("")
}

function ed(e) {
    if (typeof Uint8Array > "u") throw new Error("Unsupported");
    return new Uint8Array(e)
}

function $s(e) {
    if (typeof ArrayBuffer > "u") throw new Error("Unsupported");
    if (e instanceof ArrayBuffer) return $s(new Uint8Array(e));
    for (var r = new Array(e.length), t = 0; t < e.length; ++t) r[t] = e[t];
    return r
}
var Pt = Ue ? function(e) {
    return Buffer.concat(e.map(function(r) {
        return Buffer.isBuffer(r) ? r : ra(r)
    }))
} : function(e) {
    if (typeof Uint8Array < "u") {
        var r = 0,
            t = 0;
        for (r = 0; r < e.length; ++r) t += e[r].length;
        var a = new Uint8Array(t),
            i = 0;
        for (r = 0, t = 0; r < e.length; t += i, ++r)
            if (i = e[r].length, e[r] instanceof Uint8Array) a.set(e[r], t);
            else {
                if (typeof e[r] == "string") throw "wtf";
                a.set(new Uint8Array(e[r]), t)
            }
        return a
    }
    return [].concat.apply([], e.map(function(n) {
        return Array.isArray(n) ? n : [].slice.call(n)
    }))
};

function td(e) {
    for (var r = [], t = 0, a = e.length + 250, i = pa(e.length + 255), n = 0; n < e.length; ++n) {
        var s = e.charCodeAt(n);
        if (s < 128) i[t++] = s;
        else if (s < 2048) i[t++] = 192 | s >> 6 & 31, i[t++] = 128 | s & 63;
        else if (s >= 55296 && s < 57344) {
            s = (s & 1023) + 64;
            var o = e.charCodeAt(++n) & 1023;
            i[t++] = 240 | s >> 8 & 7, i[t++] = 128 | s >> 2 & 63, i[t++] = 128 | o >> 6 & 15 | (s & 3) << 4, i[t++] = 128 | o & 63
        } else i[t++] = 224 | s >> 12 & 15, i[t++] = 128 | s >> 6 & 63, i[t++] = 128 | s & 63;
        t > a && (r.push(i.slice(0, t)), t = 0, i = pa(65535), a = 65530)
    }
    return r.push(i.slice(0, t)), Pt(r)
}
var Xt = /\u0000/g,
    bi = /[\u0001-\u0006]/g;

function ti(e) {
    for (var r = "", t = e.length - 1; t >= 0;) r += e.charAt(t--);
    return r
}

function Pr(e, r) {
    var t = "" + e;
    return t.length >= r ? t : xt("0", r - t.length) + t
}

function Ys(e, r) {
    var t = "" + e;
    return t.length >= r ? t : xt(" ", r - t.length) + t
}

function Rn(e, r) {
    var t = "" + e;
    return t.length >= r ? t : t + xt(" ", r - t.length)
}

function rd(e, r) {
    var t = "" + Math.round(e);
    return t.length >= r ? t : xt("0", r - t.length) + t
}

function ad(e, r) {
    var t = "" + e;
    return t.length >= r ? t : xt("0", r - t.length) + t
}
var qo = Math.pow(2, 32);

function Ya(e, r) {
    if (e > qo || e < -qo) return rd(e, r);
    var t = Math.round(e);
    return ad(t, r)
}

function Pn(e, r) {
    return r = r || 0, e.length >= 7 + r && (e.charCodeAt(r) | 32) === 103 && (e.charCodeAt(r + 1) | 32) === 101 && (e.charCodeAt(r + 2) | 32) === 110 && (e.charCodeAt(r + 3) | 32) === 101 && (e.charCodeAt(r + 4) | 32) === 114 && (e.charCodeAt(r + 5) | 32) === 97 && (e.charCodeAt(r + 6) | 32) === 108
}
var jo = [
        ["Sun", "Sunday"],
        ["Mon", "Monday"],
        ["Tue", "Tuesday"],
        ["Wed", "Wednesday"],
        ["Thu", "Thursday"],
        ["Fri", "Friday"],
        ["Sat", "Saturday"]
    ],
    vs = [
        ["J", "Jan", "January"],
        ["F", "Feb", "February"],
        ["M", "Mar", "March"],
        ["A", "Apr", "April"],
        ["M", "May", "May"],
        ["J", "Jun", "June"],
        ["J", "Jul", "July"],
        ["A", "Aug", "August"],
        ["S", "Sep", "September"],
        ["O", "Oct", "October"],
        ["N", "Nov", "November"],
        ["D", "Dec", "December"]
    ];

function id(e) {
    return e || (e = {}), e[0] = "General", e[1] = "0", e[2] = "0.00", e[3] = "#,##0", e[4] = "#,##0.00", e[9] = "0%", e[10] = "0.00%", e[11] = "0.00E+00", e[12] = "# ?/?", e[13] = "# ??/??", e[14] = "m/d/yy", e[15] = "d-mmm-yy", e[16] = "d-mmm", e[17] = "mmm-yy", e[18] = "h:mm AM/PM", e[19] = "h:mm:ss AM/PM", e[20] = "h:mm", e[21] = "h:mm:ss", e[22] = "m/d/yy h:mm", e[37] = "#,##0 ;(#,##0)", e[38] = "#,##0 ;[Red](#,##0)", e[39] = "#,##0.00;(#,##0.00)", e[40] = "#,##0.00;[Red](#,##0.00)", e[45] = "mm:ss", e[46] = "[h]:mm:ss", e[47] = "mmss.0", e[48] = "##0.0E+0", e[49] = "@", e[56] = '"\u4E0A\u5348/\u4E0B\u5348 "hh"\u6642"mm"\u5206"ss"\u79D2 "', e
}
var Ie = {
        0: "General",
        1: "0",
        2: "0.00",
        3: "#,##0",
        4: "#,##0.00",
        9: "0%",
        10: "0.00%",
        11: "0.00E+00",
        12: "# ?/?",
        13: "# ??/??",
        14: "m/d/yy",
        15: "d-mmm-yy",
        16: "d-mmm",
        17: "mmm-yy",
        18: "h:mm AM/PM",
        19: "h:mm:ss AM/PM",
        20: "h:mm",
        21: "h:mm:ss",
        22: "m/d/yy h:mm",
        37: "#,##0 ;(#,##0)",
        38: "#,##0 ;[Red](#,##0)",
        39: "#,##0.00;(#,##0.00)",
        40: "#,##0.00;[Red](#,##0.00)",
        45: "mm:ss",
        46: "[h]:mm:ss",
        47: "mmss.0",
        48: "##0.0E+0",
        49: "@",
        56: '"\u4E0A\u5348/\u4E0B\u5348 "hh"\u6642"mm"\u5206"ss"\u79D2 "'
    },
    $o = {
        5: 37,
        6: 38,
        7: 39,
        8: 40,
        23: 0,
        24: 0,
        25: 0,
        26: 0,
        27: 14,
        28: 14,
        29: 14,
        30: 14,
        31: 14,
        50: 14,
        51: 14,
        52: 14,
        53: 14,
        54: 14,
        55: 14,
        56: 14,
        57: 14,
        58: 14,
        59: 1,
        60: 2,
        61: 3,
        62: 4,
        67: 9,
        68: 10,
        69: 12,
        70: 13,
        71: 14,
        72: 14,
        73: 15,
        74: 16,
        75: 17,
        76: 20,
        77: 21,
        78: 22,
        79: 45,
        80: 46,
        81: 47,
        82: 0
    },
    nd = {
        5: '"$"#,##0_);\\("$"#,##0\\)',
        63: '"$"#,##0_);\\("$"#,##0\\)',
        6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
        64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
        7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
        65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
        8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
        66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
        41: '_(* #,##0_);_(* \\(#,##0\\);_(* "-"_);_(@_)',
        42: '_("$"* #,##0_);_("$"* \\(#,##0\\);_("$"* "-"_);_(@_)',
        43: '_(* #,##0.00_);_(* \\(#,##0.00\\);_(* "-"??_);_(@_)',
        44: '_("$"* #,##0.00_);_("$"* \\(#,##0.00\\);_("$"* "-"??_);_(@_)'
    };

function Nn(e, r, t) {
    for (var a = e < 0 ? -1 : 1, i = e * a, n = 0, s = 1, o = 0, c = 1, l = 0, f = 0, u = Math.floor(i); l < r && (u = Math.floor(i), o = u * s + n, f = u * l + c, !(i - u < 5e-8));) i = 1 / (i - u), n = s, s = o, c = l, l = f;
    if (f > r && (l > r ? (f = c, o = n) : (f = l, o = s)), !t) return [0, a * o, f];
    var h = Math.floor(a * o / f);
    return [h, a * o - h * f, f]
}

function ka(e, r, t) {
    if (e > 2958465 || e < 0) return null;
    var a = e | 0,
        i = Math.floor(86400 * (e - a)),
        n = 0,
        s = [],
        o = {
            D: a,
            T: i,
            u: 86400 * (e - a) - i,
            y: 0,
            m: 0,
            d: 0,
            H: 0,
            M: 0,
            S: 0,
            q: 0
        };
    if (Math.abs(o.u) < 1e-6 && (o.u = 0), r && r.date1904 && (a += 1462), o.u > .9999 && (o.u = 0, ++i == 86400 && (o.T = i = 0, ++a, ++o.D)), a === 60) s = t ? [1317, 10, 29] : [1900, 2, 29], n = 3;
    else if (a === 0) s = t ? [1317, 8, 29] : [1900, 1, 0], n = 6;
    else {
        a > 60 && --a;
        var c = new Date(1900, 0, 1);
        c.setDate(c.getDate() + a - 1), s = [c.getFullYear(), c.getMonth() + 1, c.getDate()], n = c.getDay(), a < 60 && (n = (n + 6) % 7), t && (n = ud(c, s))
    }
    return o.y = s[0], o.m = s[1], o.d = s[2], o.S = i % 60, i = Math.floor(i / 60), o.M = i % 60, i = Math.floor(i / 60), o.H = i, o.q = n, o
}
var Qc = new Date(1899, 11, 31, 0, 0, 0),
    sd = Qc.getTime(),
    od = new Date(1900, 2, 1, 0, 0, 0);

function el(e, r) {
    var t = e.getTime();
    return r ? t -= 1461 * 24 * 60 * 60 * 1e3 : e >= od && (t += 1440 * 60 * 1e3), (t - (sd + (e.getTimezoneOffset() - Qc.getTimezoneOffset()) * 6e4)) / (1440 * 60 * 1e3)
}

function Ks(e) {
    return e.indexOf(".") == -1 ? e : e.replace(/(?:\.0*|(\.\d*[1-9])0+)$/, "$1")
}

function cd(e) {
    return e.indexOf("E") == -1 ? e : e.replace(/(?:\.0*|(\.\d*[1-9])0+)[Ee]/, "$1E").replace(/(E[+-])(\d)$/, "$10$2")
}

function ld(e) {
    var r = e < 0 ? 12 : 11,
        t = Ks(e.toFixed(12));
    return t.length <= r || (t = e.toPrecision(10), t.length <= r) ? t : e.toExponential(5)
}

function fd(e) {
    var r = Ks(e.toFixed(11));
    return r.length > (e < 0 ? 12 : 11) || r === "0" || r === "-0" ? e.toPrecision(6) : r
}

function Wi(e) {
    var r = Math.floor(Math.log(Math.abs(e)) * Math.LOG10E),
        t;
    return r >= -4 && r <= -1 ? t = e.toPrecision(10 + r) : Math.abs(r) <= 9 ? t = ld(e) : r === 10 ? t = e.toFixed(10).substr(0, 12) : t = fd(e), Ks(cd(t.toUpperCase()))
}

function Ma(e, r) {
    switch (typeof e) {
        case "string":
            return e;
        case "boolean":
            return e ? "TRUE" : "FALSE";
        case "number":
            return (e | 0) === e ? e.toString(10) : Wi(e);
        case "undefined":
            return "";
        case "object":
            if (e == null) return "";
            if (e instanceof Date) return Ir(14, el(e, r && r.date1904), r)
    }
    throw new Error("unsupported value in General format: " + e)
}

function ud(e, r) {
    r[0] -= 581;
    var t = e.getDay();
    return e < 60 && (t = (t + 6) % 7), t
}

function dd(e, r, t, a) {
    var i = "",
        n = 0,
        s = 0,
        o = t.y,
        c, l = 0;
    switch (e) {
        case 98:
            o = t.y + 543;
        case 121:
            switch (r.length) {
                case 1:
                case 2:
                    c = o % 100, l = 2;
                    break;
                default:
                    c = o % 1e4, l = 4;
                    break
            }
            break;
        case 109:
            switch (r.length) {
                case 1:
                case 2:
                    c = t.m, l = r.length;
                    break;
                case 3:
                    return vs[t.m - 1][1];
                case 5:
                    return vs[t.m - 1][0];
                default:
                    return vs[t.m - 1][2]
            }
            break;
        case 100:
            switch (r.length) {
                case 1:
                case 2:
                    c = t.d, l = r.length;
                    break;
                case 3:
                    return jo[t.q][0];
                default:
                    return jo[t.q][1]
            }
            break;
        case 104:
            switch (r.length) {
                case 1:
                case 2:
                    c = 1 + (t.H + 11) % 12, l = r.length;
                    break;
                default:
                    throw "bad hour format: " + r
            }
            break;
        case 72:
            switch (r.length) {
                case 1:
                case 2:
                    c = t.H, l = r.length;
                    break;
                default:
                    throw "bad hour format: " + r
            }
            break;
        case 77:
            switch (r.length) {
                case 1:
                case 2:
                    c = t.M, l = r.length;
                    break;
                default:
                    throw "bad minute format: " + r
            }
            break;
        case 115:
            if (r != "s" && r != "ss" && r != ".0" && r != ".00" && r != ".000") throw "bad second format: " + r;
            return t.u === 0 && (r == "s" || r == "ss") ? Pr(t.S, r.length) : (a >= 2 ? s = a === 3 ? 1e3 : 100 : s = a === 1 ? 10 : 1, n = Math.round(s * (t.S + t.u)), n >= 60 * s && (n = 0), r === "s" ? n === 0 ? "0" : "" + n / s : (i = Pr(n, 2 + a), r === "ss" ? i.substr(0, 2) : "." + i.substr(2, r.length - 1)));
        case 90:
            switch (r) {
                case "[h]":
                case "[hh]":
                    c = t.D * 24 + t.H;
                    break;
                case "[m]":
                case "[mm]":
                    c = (t.D * 24 + t.H) * 60 + t.M;
                    break;
                case "[s]":
                case "[ss]":
                    c = ((t.D * 24 + t.H) * 60 + t.M) * 60 + Math.round(t.S + t.u);
                    break;
                default:
                    throw "bad abstime format: " + r
            }
            l = r.length === 3 ? 1 : 2;
            break;
        case 101:
            c = o, l = 1;
            break
    }
    var f = l > 0 ? Pr(c, l) : "";
    return f
}

function ha(e) {
    var r = 3;
    if (e.length <= r) return e;
    for (var t = e.length % r, a = e.substr(0, t); t != e.length; t += r) a += (a.length > 0 ? "," : "") + e.substr(t, r);
    return a
}
var tl = /%/g;

function hd(e, r, t) {
    var a = r.replace(tl, ""),
        i = r.length - a.length;
    return Zr(e, a, t * Math.pow(10, 2 * i)) + xt("%", i)
}

function pd(e, r, t) {
    for (var a = r.length - 1; r.charCodeAt(a - 1) === 44;) --a;
    return Zr(e, r.substr(0, a), t / Math.pow(10, 3 * (r.length - a)))
}

function rl(e, r) {
    var t, a = e.indexOf("E") - e.indexOf(".") - 1;
    if (e.match(/^#+0.0E\+0$/)) {
        if (r == 0) return "0.0E+0";
        if (r < 0) return "-" + rl(e, -r);
        var i = e.indexOf(".");
        i === -1 && (i = e.indexOf("E"));
        var n = Math.floor(Math.log(r) * Math.LOG10E) % i;
        if (n < 0 && (n += i), t = (r / Math.pow(10, n)).toPrecision(a + 1 + (i + n) % i), t.indexOf("e") === -1) {
            var s = Math.floor(Math.log(r) * Math.LOG10E);
            for (t.indexOf(".") === -1 ? t = t.charAt(0) + "." + t.substr(1) + "E+" + (s - t.length + n) : t += "E+" + (s - n); t.substr(0, 2) === "0.";) t = t.charAt(0) + t.substr(2, i) + "." + t.substr(2 + i), t = t.replace(/^0+([1-9])/, "$1").replace(/^0+\./, "0.");
            t = t.replace(/\+-/, "-")
        }
        t = t.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(o, c, l, f) {
            return c + l + f.substr(0, (i + n) % i) + "." + f.substr(n) + "E"
        })
    } else t = r.toExponential(a);
    return e.match(/E\+00$/) && t.match(/e[+-]\d$/) && (t = t.substr(0, t.length - 1) + "0" + t.charAt(t.length - 1)), e.match(/E\-/) && t.match(/e\+/) && (t = t.replace(/e\+/, "e")), t.replace("e", "E")
}
var al = /# (\?+)( ?)\/( ?)(\d+)/;

function md(e, r, t) {
    var a = parseInt(e[4], 10),
        i = Math.round(r * a),
        n = Math.floor(i / a),
        s = i - n * a,
        o = a;
    return t + (n === 0 ? "" : "" + n) + " " + (s === 0 ? xt(" ", e[1].length + 1 + e[4].length) : Ys(s, e[1].length) + e[2] + "/" + e[3] + Pr(o, e[4].length))
}

function xd(e, r, t) {
    return t + (r === 0 ? "" : "" + r) + xt(" ", e[1].length + 2 + e[4].length)
}
var il = /^#*0*\.([0#]+)/,
    nl = /\).*[0#]/,
    sl = /\(###\) ###\\?-####/;

function Kt(e) {
    for (var r = "", t, a = 0; a != e.length; ++a) switch (t = e.charCodeAt(a)) {
        case 35:
            break;
        case 63:
            r += " ";
            break;
        case 48:
            r += "0";
            break;
        default:
            r += String.fromCharCode(t)
    }
    return r
}

function Yo(e, r) {
    var t = Math.pow(10, r);
    return "" + Math.round(e * t) / t
}

function Ko(e, r) {
    var t = e - Math.floor(e),
        a = Math.pow(10, r);
    return r < ("" + Math.round(t * a)).length ? 0 : Math.round(t * a)
}

function gd(e, r) {
    return r < ("" + Math.round((e - Math.floor(e)) * Math.pow(10, r))).length ? 1 : 0
}

function _d(e) {
    return e < 2147483647 && e > -2147483648 ? "" + (e >= 0 ? e | 0 : e - 1 | 0) : "" + Math.floor(e)
}

function Tr(e, r, t) {
    if (e.charCodeAt(0) === 40 && !r.match(nl)) {
        var a = r.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
        return t >= 0 ? Tr("n", a, t) : "(" + Tr("n", a, -t) + ")"
    }
    if (r.charCodeAt(r.length - 1) === 44) return pd(e, r, t);
    if (r.indexOf("%") !== -1) return hd(e, r, t);
    if (r.indexOf("E") !== -1) return rl(r, t);
    if (r.charCodeAt(0) === 36) return "$" + Tr(e, r.substr(r.charAt(1) == " " ? 2 : 1), t);
    var i, n, s, o, c = Math.abs(t),
        l = t < 0 ? "-" : "";
    if (r.match(/^00+$/)) return l + Ya(c, r.length);
    if (r.match(/^[#?]+$/)) return i = Ya(t, 0), i === "0" && (i = ""), i.length > r.length ? i : Kt(r.substr(0, r.length - i.length)) + i;
    if (n = r.match(al)) return md(n, c, l);
    if (r.match(/^#+0+$/)) return l + Ya(c, r.length - r.indexOf("0"));
    if (n = r.match(il)) return i = Yo(t, n[1].length).replace(/^([^\.]+)$/, "$1." + Kt(n[1])).replace(/\.$/, "." + Kt(n[1])).replace(/\.(\d*)$/, function(m, d) {
        return "." + d + xt("0", Kt(n[1]).length - d.length)
    }), r.indexOf("0.") !== -1 ? i : i.replace(/^0\./, ".");
    if (r = r.replace(/^#+([0.])/, "$1"), n = r.match(/^(0*)\.(#*)$/)) return l + Yo(c, n[2].length).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, n[1].length ? "0." : ".");
    if (n = r.match(/^#{1,3},##0(\.?)$/)) return l + ha(Ya(c, 0));
    if (n = r.match(/^#,##0\.([#0]*0)$/)) return t < 0 ? "-" + Tr(e, r, -t) : ha("" + (Math.floor(t) + gd(t, n[1].length))) + "." + Pr(Ko(t, n[1].length), n[1].length);
    if (n = r.match(/^#,#*,#0/)) return Tr(e, r.replace(/^#,#*,/, ""), t);
    if (n = r.match(/^([0#]+)(\\?-([0#]+))+$/)) return i = ti(Tr(e, r.replace(/[\\-]/g, ""), t)), s = 0, ti(ti(r.replace(/\\/g, "")).replace(/[0#]/g, function(m) {
        return s < i.length ? i.charAt(s++) : m === "0" ? "0" : ""
    }));
    if (r.match(sl)) return i = Tr(e, "##########", t), "(" + i.substr(0, 3) + ") " + i.substr(3, 3) + "-" + i.substr(6);
    var f = "";
    if (n = r.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/)) return s = Math.min(n[4].length, 7), o = Nn(c, Math.pow(10, s) - 1, !1), i = "" + l, f = Zr("n", n[1], o[1]), f.charAt(f.length - 1) == " " && (f = f.substr(0, f.length - 1) + "0"), i += f + n[2] + "/" + n[3], f = Rn(o[2], s), f.length < n[4].length && (f = Kt(n[4].substr(n[4].length - f.length)) + f), i += f, i;
    if (n = r.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/)) return s = Math.min(Math.max(n[1].length, n[4].length), 7), o = Nn(c, Math.pow(10, s) - 1, !0), l + (o[0] || (o[1] ? "" : "0")) + " " + (o[1] ? Ys(o[1], s) + n[2] + "/" + n[3] + Rn(o[2], s) : xt(" ", 2 * s + 1 + n[2].length + n[3].length));
    if (n = r.match(/^[#0?]+$/)) return i = Ya(t, 0), r.length <= i.length ? i : Kt(r.substr(0, r.length - i.length)) + i;
    if (n = r.match(/^([#0?]+)\.([#0]+)$/)) {
        i = "" + t.toFixed(Math.min(n[2].length, 10)).replace(/([^0])0+$/, "$1"), s = i.indexOf(".");
        var u = r.indexOf(".") - s,
            h = r.length - i.length - u;
        return Kt(r.substr(0, u) + i + r.substr(r.length - h))
    }
    if (n = r.match(/^00,000\.([#0]*0)$/)) return s = Ko(t, n[1].length), t < 0 ? "-" + Tr(e, r, -t) : ha(_d(t)).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(m) {
        return "00," + (m.length < 3 ? Pr(0, 3 - m.length) : "") + m
    }) + "." + Pr(s, n[1].length);
    switch (r) {
        case "###,##0.00":
            return Tr(e, "#,##0.00", t);
        case "###,###":
        case "##,###":
        case "#,###":
            var p = ha(Ya(c, 0));
            return p !== "0" ? l + p : "";
        case "###,###.00":
            return Tr(e, "###,##0.00", t).replace(/^0\./, ".");
        case "#,###.00":
            return Tr(e, "#,##0.00", t).replace(/^0\./, ".");
        default:
    }
    throw new Error("unsupported format |" + r + "|")
}

function vd(e, r, t) {
    for (var a = r.length - 1; r.charCodeAt(a - 1) === 44;) --a;
    return Zr(e, r.substr(0, a), t / Math.pow(10, 3 * (r.length - a)))
}

function wd(e, r, t) {
    var a = r.replace(tl, ""),
        i = r.length - a.length;
    return Zr(e, a, t * Math.pow(10, 2 * i)) + xt("%", i)
}

function ol(e, r) {
    var t, a = e.indexOf("E") - e.indexOf(".") - 1;
    if (e.match(/^#+0.0E\+0$/)) {
        if (r == 0) return "0.0E+0";
        if (r < 0) return "-" + ol(e, -r);
        var i = e.indexOf(".");
        i === -1 && (i = e.indexOf("E"));
        var n = Math.floor(Math.log(r) * Math.LOG10E) % i;
        if (n < 0 && (n += i), t = (r / Math.pow(10, n)).toPrecision(a + 1 + (i + n) % i), !t.match(/[Ee]/)) {
            var s = Math.floor(Math.log(r) * Math.LOG10E);
            t.indexOf(".") === -1 ? t = t.charAt(0) + "." + t.substr(1) + "E+" + (s - t.length + n) : t += "E+" + (s - n), t = t.replace(/\+-/, "-")
        }
        t = t.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(o, c, l, f) {
            return c + l + f.substr(0, (i + n) % i) + "." + f.substr(n) + "E"
        })
    } else t = r.toExponential(a);
    return e.match(/E\+00$/) && t.match(/e[+-]\d$/) && (t = t.substr(0, t.length - 1) + "0" + t.charAt(t.length - 1)), e.match(/E\-/) && t.match(/e\+/) && (t = t.replace(/e\+/, "e")), t.replace("e", "E")
}

function Wr(e, r, t) {
    if (e.charCodeAt(0) === 40 && !r.match(nl)) {
        var a = r.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
        return t >= 0 ? Wr("n", a, t) : "(" + Wr("n", a, -t) + ")"
    }
    if (r.charCodeAt(r.length - 1) === 44) return vd(e, r, t);
    if (r.indexOf("%") !== -1) return wd(e, r, t);
    if (r.indexOf("E") !== -1) return ol(r, t);
    if (r.charCodeAt(0) === 36) return "$" + Wr(e, r.substr(r.charAt(1) == " " ? 2 : 1), t);
    var i, n, s, o, c = Math.abs(t),
        l = t < 0 ? "-" : "";
    if (r.match(/^00+$/)) return l + Pr(c, r.length);
    if (r.match(/^[#?]+$/)) return i = "" + t, t === 0 && (i = ""), i.length > r.length ? i : Kt(r.substr(0, r.length - i.length)) + i;
    if (n = r.match(al)) return xd(n, c, l);
    if (r.match(/^#+0+$/)) return l + Pr(c, r.length - r.indexOf("0"));
    if (n = r.match(il)) return i = ("" + t).replace(/^([^\.]+)$/, "$1." + Kt(n[1])).replace(/\.$/, "." + Kt(n[1])), i = i.replace(/\.(\d*)$/, function(m, d) {
        return "." + d + xt("0", Kt(n[1]).length - d.length)
    }), r.indexOf("0.") !== -1 ? i : i.replace(/^0\./, ".");
    if (r = r.replace(/^#+([0.])/, "$1"), n = r.match(/^(0*)\.(#*)$/)) return l + ("" + c).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, n[1].length ? "0." : ".");
    if (n = r.match(/^#{1,3},##0(\.?)$/)) return l + ha("" + c);
    if (n = r.match(/^#,##0\.([#0]*0)$/)) return t < 0 ? "-" + Wr(e, r, -t) : ha("" + t) + "." + xt("0", n[1].length);
    if (n = r.match(/^#,#*,#0/)) return Wr(e, r.replace(/^#,#*,/, ""), t);
    if (n = r.match(/^([0#]+)(\\?-([0#]+))+$/)) return i = ti(Wr(e, r.replace(/[\\-]/g, ""), t)), s = 0, ti(ti(r.replace(/\\/g, "")).replace(/[0#]/g, function(m) {
        return s < i.length ? i.charAt(s++) : m === "0" ? "0" : ""
    }));
    if (r.match(sl)) return i = Wr(e, "##########", t), "(" + i.substr(0, 3) + ") " + i.substr(3, 3) + "-" + i.substr(6);
    var f = "";
    if (n = r.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/)) return s = Math.min(n[4].length, 7), o = Nn(c, Math.pow(10, s) - 1, !1), i = "" + l, f = Zr("n", n[1], o[1]), f.charAt(f.length - 1) == " " && (f = f.substr(0, f.length - 1) + "0"), i += f + n[2] + "/" + n[3], f = Rn(o[2], s), f.length < n[4].length && (f = Kt(n[4].substr(n[4].length - f.length)) + f), i += f, i;
    if (n = r.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/)) return s = Math.min(Math.max(n[1].length, n[4].length), 7), o = Nn(c, Math.pow(10, s) - 1, !0), l + (o[0] || (o[1] ? "" : "0")) + " " + (o[1] ? Ys(o[1], s) + n[2] + "/" + n[3] + Rn(o[2], s) : xt(" ", 2 * s + 1 + n[2].length + n[3].length));
    if (n = r.match(/^[#0?]+$/)) return i = "" + t, r.length <= i.length ? i : Kt(r.substr(0, r.length - i.length)) + i;
    if (n = r.match(/^([#0]+)\.([#0]+)$/)) {
        i = "" + t.toFixed(Math.min(n[2].length, 10)).replace(/([^0])0+$/, "$1"), s = i.indexOf(".");
        var u = r.indexOf(".") - s,
            h = r.length - i.length - u;
        return Kt(r.substr(0, u) + i + r.substr(r.length - h))
    }
    if (n = r.match(/^00,000\.([#0]*0)$/)) return t < 0 ? "-" + Wr(e, r, -t) : ha("" + t).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(m) {
        return "00," + (m.length < 3 ? Pr(0, 3 - m.length) : "") + m
    }) + "." + Pr(0, n[1].length);
    switch (r) {
        case "###,###":
        case "##,###":
        case "#,###":
            var p = ha("" + c);
            return p !== "0" ? l + p : "";
        default:
            if (r.match(/\.[0#?]*$/)) return Wr(e, r.slice(0, r.lastIndexOf(".")), t) + Kt(r.slice(r.lastIndexOf(".")))
    }
    throw new Error("unsupported format |" + r + "|")
}

function Zr(e, r, t) {
    return (t | 0) === t ? Wr(e, r, t) : Tr(e, r, t)
}

function Sd(e) {
    for (var r = [], t = !1, a = 0, i = 0; a < e.length; ++a) switch (e.charCodeAt(a)) {
        case 34:
            t = !t;
            break;
        case 95:
        case 42:
        case 92:
            ++a;
            break;
        case 59:
            r[r.length] = e.substr(i, a - i), i = a + 1
    }
    if (r[r.length] = e.substr(i), t === !0) throw new Error("Format |" + e + "| unterminated string ");
    return r
}
var cl = /\[[HhMmSs\u0E0A\u0E19\u0E17]*\]/;

function li(e) {
    for (var r = 0, t = "", a = ""; r < e.length;) switch (t = e.charAt(r)) {
        case "G":
            Pn(e, r) && (r += 6), r++;
            break;
        case '"':
            for (; e.charCodeAt(++r) !== 34 && r < e.length;);
            ++r;
            break;
        case "\\":
            r += 2;
            break;
        case "_":
            r += 2;
            break;
        case "@":
            ++r;
            break;
        case "B":
        case "b":
            if (e.charAt(r + 1) === "1" || e.charAt(r + 1) === "2") return !0;
        case "M":
        case "D":
        case "Y":
        case "H":
        case "S":
        case "E":
        case "m":
        case "d":
        case "y":
        case "h":
        case "s":
        case "e":
        case "g":
            return !0;
        case "A":
        case "a":
        case "\u4E0A":
            if (e.substr(r, 3).toUpperCase() === "A/P" || e.substr(r, 5).toUpperCase() === "AM/PM" || e.substr(r, 5).toUpperCase() === "\u4E0A\u5348/\u4E0B\u5348") return !0;
            ++r;
            break;
        case "[":
            for (a = t; e.charAt(r++) !== "]" && r < e.length;) a += e.charAt(r);
            if (a.match(cl)) return !0;
            break;
        case ".":
        case "0":
        case "#":
            for (; r < e.length && ("0#?.,E+-%".indexOf(t = e.charAt(++r)) > -1 || t == "\\" && e.charAt(r + 1) == "-" && "0#".indexOf(e.charAt(r + 2)) > -1););
            break;
        case "?":
            for (; e.charAt(++r) === t;);
            break;
        case "*":
            ++r, (e.charAt(r) == " " || e.charAt(r) == "*") && ++r;
            break;
        case "(":
        case ")":
            ++r;
            break;
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
            for (; r < e.length && "0123456789".indexOf(e.charAt(++r)) > -1;);
            break;
        case " ":
            ++r;
            break;
        default:
            ++r;
            break
    }
    return !1
}

function Ed(e, r, t, a) {
    for (var i = [], n = "", s = 0, o = "", c = "t", l, f, u, h = "H"; s < e.length;) switch (o = e.charAt(s)) {
        case "G":
            if (!Pn(e, s)) throw new Error("unrecognized character " + o + " in " + e);
            i[i.length] = {
                t: "G",
                v: "General"
            }, s += 7;
            break;
        case '"':
            for (n = "";
                (u = e.charCodeAt(++s)) !== 34 && s < e.length;) n += String.fromCharCode(u);
            i[i.length] = {
                t: "t",
                v: n
            }, ++s;
            break;
        case "\\":
            var p = e.charAt(++s),
                m = p === "(" || p === ")" ? p : "t";
            i[i.length] = {
                t: m,
                v: p
            }, ++s;
            break;
        case "_":
            i[i.length] = {
                t: "t",
                v: " "
            }, s += 2;
            break;
        case "@":
            i[i.length] = {
                t: "T",
                v: r
            }, ++s;
            break;
        case "B":
        case "b":
            if (e.charAt(s + 1) === "1" || e.charAt(s + 1) === "2") {
                if (l == null && (l = ka(r, t, e.charAt(s + 1) === "2"), l == null)) return "";
                i[i.length] = {
                    t: "X",
                    v: e.substr(s, 2)
                }, c = o, s += 2;
                break
            }
        case "M":
        case "D":
        case "Y":
        case "H":
        case "S":
        case "E":
            o = o.toLowerCase();
        case "m":
        case "d":
        case "y":
        case "h":
        case "s":
        case "e":
        case "g":
            if (r < 0 || l == null && (l = ka(r, t), l == null)) return "";
            for (n = o; ++s < e.length && e.charAt(s).toLowerCase() === o;) n += o;
            o === "m" && c.toLowerCase() === "h" && (o = "M"), o === "h" && (o = h), i[i.length] = {
                t: o,
                v: n
            }, c = o;
            break;
        case "A":
        case "a":
        case "\u4E0A":
            var d = {
                t: o,
                v: o
            };
            if (l == null && (l = ka(r, t)), e.substr(s, 3).toUpperCase() === "A/P" ? (l != null && (d.v = l.H >= 12 ? "P" : "A"), d.t = "T", h = "h", s += 3) : e.substr(s, 5).toUpperCase() === "AM/PM" ? (l != null && (d.v = l.H >= 12 ? "PM" : "AM"), d.t = "T", s += 5, h = "h") : e.substr(s, 5).toUpperCase() === "\u4E0A\u5348/\u4E0B\u5348" ? (l != null && (d.v = l.H >= 12 ? "\u4E0B\u5348" : "\u4E0A\u5348"), d.t = "T", s += 5, h = "h") : (d.t = "t", ++s), l == null && d.t === "T") return "";
            i[i.length] = d, c = o;
            break;
        case "[":
            for (n = o; e.charAt(s++) !== "]" && s < e.length;) n += e.charAt(s);
            if (n.slice(-1) !== "]") throw 'unterminated "[" block: |' + n + "|";
            if (n.match(cl)) {
                if (l == null && (l = ka(r, t), l == null)) return "";
                i[i.length] = {
                    t: "Z",
                    v: n.toLowerCase()
                }, c = n.charAt(1)
            } else n.indexOf("$") > -1 && (n = (n.match(/\$([^-\[\]]*)/) || [])[1] || "$", li(e) || (i[i.length] = {
                t: "t",
                v: n
            }));
            break;
        case ".":
            if (l != null) {
                for (n = o; ++s < e.length && (o = e.charAt(s)) === "0";) n += o;
                i[i.length] = {
                    t: "s",
                    v: n
                };
                break
            }
        case "0":
        case "#":
            for (n = o; ++s < e.length && "0#?.,E+-%".indexOf(o = e.charAt(s)) > -1;) n += o;
            i[i.length] = {
                t: "n",
                v: n
            };
            break;
        case "?":
            for (n = o; e.charAt(++s) === o;) n += o;
            i[i.length] = {
                t: o,
                v: n
            }, c = o;
            break;
        case "*":
            ++s, (e.charAt(s) == " " || e.charAt(s) == "*") && ++s;
            break;
        case "(":
        case ")":
            i[i.length] = {
                t: a === 1 ? "t" : o,
                v: o
            }, ++s;
            break;
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
            for (n = o; s < e.length && "0123456789".indexOf(e.charAt(++s)) > -1;) n += e.charAt(s);
            i[i.length] = {
                t: "D",
                v: n
            };
            break;
        case " ":
            i[i.length] = {
                t: o,
                v: o
            }, ++s;
            break;
        case "$":
            i[i.length] = {
                t: "t",
                v: "$"
            }, ++s;
            break;
        default:
            if (",$-+/():!^&'~{}<>=\u20ACacfijklopqrtuvwxzP".indexOf(o) === -1) throw new Error("unrecognized character " + o + " in " + e);
            i[i.length] = {
                t: "t",
                v: o
            }, ++s;
            break
    }
    var x = 0,
        E = 0,
        S;
    for (s = i.length - 1, c = "t"; s >= 0; --s) switch (i[s].t) {
        case "h":
        case "H":
            i[s].t = h, c = "h", x < 1 && (x = 1);
            break;
        case "s":
            (S = i[s].v.match(/\.0+$/)) && (E = Math.max(E, S[0].length - 1)), x < 3 && (x = 3);
        case "d":
        case "y":
        case "M":
        case "e":
            c = i[s].t;
            break;
        case "m":
            c === "s" && (i[s].t = "M", x < 2 && (x = 2));
            break;
        case "X":
            break;
        case "Z":
            x < 1 && i[s].v.match(/[Hh]/) && (x = 1), x < 2 && i[s].v.match(/[Mm]/) && (x = 2), x < 3 && i[s].v.match(/[Ss]/) && (x = 3)
    }
    switch (x) {
        case 0:
            break;
        case 1:
            l.u >= .5 && (l.u = 0, ++l.S), l.S >= 60 && (l.S = 0, ++l.M), l.M >= 60 && (l.M = 0, ++l.H);
            break;
        case 2:
            l.u >= .5 && (l.u = 0, ++l.S), l.S >= 60 && (l.S = 0, ++l.M);
            break
    }
    var _ = "",
        L;
    for (s = 0; s < i.length; ++s) switch (i[s].t) {
        case "t":
        case "T":
        case " ":
        case "D":
            break;
        case "X":
            i[s].v = "", i[s].t = ";";
            break;
        case "d":
        case "m":
        case "y":
        case "h":
        case "H":
        case "M":
        case "s":
        case "e":
        case "b":
        case "Z":
            i[s].v = dd(i[s].t.charCodeAt(0), i[s].v, l, E), i[s].t = "t";
            break;
        case "n":
        case "?":
            for (L = s + 1; i[L] != null && ((o = i[L].t) === "?" || o === "D" || (o === " " || o === "t") && i[L + 1] != null && (i[L + 1].t === "?" || i[L + 1].t === "t" && i[L + 1].v === "/") || i[s].t === "(" && (o === " " || o === "n" || o === ")") || o === "t" && (i[L].v === "/" || i[L].v === " " && i[L + 1] != null && i[L + 1].t == "?"));) i[s].v += i[L].v, i[L] = {
                v: "",
                t: ";"
            }, ++L;
            _ += i[s].v, s = L - 1;
            break;
        case "G":
            i[s].t = "t", i[s].v = Ma(r, t);
            break
    }
    var U = "",
        R, T;
    if (_.length > 0) {
        _.charCodeAt(0) == 40 ? (R = r < 0 && _.charCodeAt(0) === 45 ? -r : r, T = Zr("n", _, R)) : (R = r < 0 && a > 1 ? -r : r, T = Zr("n", _, R), R < 0 && i[0] && i[0].t == "t" && (T = T.substr(1), i[0].v = "-" + i[0].v)), L = T.length - 1;
        var N = i.length;
        for (s = 0; s < i.length; ++s)
            if (i[s] != null && i[s].t != "t" && i[s].v.indexOf(".") > -1) {
                N = s;
                break
            }
        var P = i.length;
        if (N === i.length && T.indexOf("E") === -1) {
            for (s = i.length - 1; s >= 0; --s) i[s] == null || "n?".indexOf(i[s].t) === -1 || (L >= i[s].v.length - 1 ? (L -= i[s].v.length, i[s].v = T.substr(L + 1, i[s].v.length)) : L < 0 ? i[s].v = "" : (i[s].v = T.substr(0, L + 1), L = -1), i[s].t = "t", P = s);
            L >= 0 && P < i.length && (i[P].v = T.substr(0, L + 1) + i[P].v)
        } else if (N !== i.length && T.indexOf("E") === -1) {
            for (L = T.indexOf(".") - 1, s = N; s >= 0; --s)
                if (!(i[s] == null || "n?".indexOf(i[s].t) === -1)) {
                    for (f = i[s].v.indexOf(".") > -1 && s === N ? i[s].v.indexOf(".") - 1 : i[s].v.length - 1, U = i[s].v.substr(f + 1); f >= 0; --f) L >= 0 && (i[s].v.charAt(f) === "0" || i[s].v.charAt(f) === "#") && (U = T.charAt(L--) + U);
                    i[s].v = U, i[s].t = "t", P = s
                }
            for (L >= 0 && P < i.length && (i[P].v = T.substr(0, L + 1) + i[P].v), L = T.indexOf(".") + 1, s = N; s < i.length; ++s)
                if (!(i[s] == null || "n?(".indexOf(i[s].t) === -1 && s !== N)) {
                    for (f = i[s].v.indexOf(".") > -1 && s === N ? i[s].v.indexOf(".") + 1 : 0, U = i[s].v.substr(0, f); f < i[s].v.length; ++f) L < T.length && (U += T.charAt(L++));
                    i[s].v = U, i[s].t = "t", P = s
                }
        }
    }
    for (s = 0; s < i.length; ++s) i[s] != null && "n?".indexOf(i[s].t) > -1 && (R = a > 1 && r < 0 && s > 0 && i[s - 1].v === "-" ? -r : r, i[s].v = Zr(i[s].t, i[s].v, R), i[s].t = "t");
    var X = "";
    for (s = 0; s !== i.length; ++s) i[s] != null && (X += i[s].v);
    return X
}
var Jo = /\[(=|>[=]?|<[>=]?)(-?\d+(?:\.\d*)?)\]/;

function Zo(e, r) {
    if (r == null) return !1;
    var t = parseFloat(r[2]);
    switch (r[1]) {
        case "=":
            if (e == t) return !0;
            break;
        case ">":
            if (e > t) return !0;
            break;
        case "<":
            if (e < t) return !0;
            break;
        case "<>":
            if (e != t) return !0;
            break;
        case ">=":
            if (e >= t) return !0;
            break;
        case "<=":
            if (e <= t) return !0;
            break
    }
    return !1
}

function Cd(e, r) {
    var t = Sd(e),
        a = t.length,
        i = t[a - 1].indexOf("@");
    if (a < 4 && i > -1 && --a, t.length > 4) throw new Error("cannot find right format for |" + t.join("|") + "|");
    if (typeof r != "number") return [4, t.length === 4 || i > -1 ? t[t.length - 1] : "@"];
    switch (t.length) {
        case 1:
            t = i > -1 ? ["General", "General", "General", t[0]] : [t[0], t[0], t[0], "@"];
            break;
        case 2:
            t = i > -1 ? [t[0], t[0], t[0], t[1]] : [t[0], t[1], t[0], "@"];
            break;
        case 3:
            t = i > -1 ? [t[0], t[1], t[0], t[2]] : [t[0], t[1], t[2], "@"];
            break;
        case 4:
            break
    }
    var n = r > 0 ? t[0] : r < 0 ? t[1] : t[2];
    if (t[0].indexOf("[") === -1 && t[1].indexOf("[") === -1) return [a, n];
    if (t[0].match(/\[[=<>]/) != null || t[1].match(/\[[=<>]/) != null) {
        var s = t[0].match(Jo),
            o = t[1].match(Jo);
        return Zo(r, s) ? [a, t[0]] : Zo(r, o) ? [a, t[1]] : [a, t[s != null && o != null ? 2 : 1]]
    }
    return [a, n]
}

function Ir(e, r, t) {
    t == null && (t = {});
    var a = "";
    switch (typeof e) {
        case "string":
            e == "m/d/yy" && t.dateNF ? a = t.dateNF : a = e;
            break;
        case "number":
            e == 14 && t.dateNF ? a = t.dateNF : a = (t.table != null ? t.table : Ie)[e], a == null && (a = t.table && t.table[$o[e]] || Ie[$o[e]]), a == null && (a = nd[e] || "General");
            break
    }
    if (Pn(a, 0)) return Ma(r, t);
    r instanceof Date && (r = el(r, t.date1904));
    var i = Cd(a, r);
    if (Pn(i[1])) return Ma(r, t);
    if (r === !0) r = "TRUE";
    else if (r === !1) r = "FALSE";
    else if (r === "" || r == null) return "";
    return Ed(i[1], r, t, i[0])
}

function Qr(e, r) {
    if (typeof r != "number") {
        r = +r || -1;
        for (var t = 0; t < 392; ++t) {
            if (Ie[t] == null) {
                r < 0 && (r = t);
                continue
            }
            if (Ie[t] == e) {
                r = t;
                break
            }
        }
        r < 0 && (r = 391)
    }
    return Ie[r] = e, r
}

function $n(e) {
    for (var r = 0; r != 392; ++r) e[r] !== void 0 && Qr(e[r], r)
}

function fi() {
    Ie = id()
}
var Td = {
        5: '"$"#,##0_);\\("$"#,##0\\)',
        6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
        7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
        8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
        23: "General",
        24: "General",
        25: "General",
        26: "General",
        27: "m/d/yy",
        28: "m/d/yy",
        29: "m/d/yy",
        30: "m/d/yy",
        31: "m/d/yy",
        32: "h:mm:ss",
        33: "h:mm:ss",
        34: "h:mm:ss",
        35: "h:mm:ss",
        36: "m/d/yy",
        41: '_(* #,##0_);_(* (#,##0);_(* "-"_);_(@_)',
        42: '_("$"* #,##0_);_("$"* (#,##0);_("$"* "-"_);_(@_)',
        43: '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)',
        44: '_("$"* #,##0.00_);_("$"* (#,##0.00);_("$"* "-"??_);_(@_)',
        50: "m/d/yy",
        51: "m/d/yy",
        52: "m/d/yy",
        53: "m/d/yy",
        54: "m/d/yy",
        55: "m/d/yy",
        56: "m/d/yy",
        57: "m/d/yy",
        58: "m/d/yy",
        59: "0",
        60: "0.00",
        61: "#,##0",
        62: "#,##0.00",
        63: '"$"#,##0_);\\("$"#,##0\\)',
        64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
        65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
        66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
        67: "0%",
        68: "0.00%",
        69: "# ?/?",
        70: "# ??/??",
        71: "m/d/yy",
        72: "m/d/yy",
        73: "d-mmm-yy",
        74: "d-mmm",
        75: "mmm-yy",
        76: "h:mm",
        77: "h:mm:ss",
        78: "m/d/yy h:mm",
        79: "mm:ss",
        80: "[h]:mm:ss",
        81: "mmss.0"
    },
    ll = /[dD]+|[mM]+|[yYeE]+|[Hh]+|[Ss]+/g;

function yd(e) {
    var r = typeof e == "number" ? Ie[e] : e;
    return r = r.replace(ll, "(\\d+)"), new RegExp("^" + r + "$")
}

function kd(e, r, t) {
    var a = -1,
        i = -1,
        n = -1,
        s = -1,
        o = -1,
        c = -1;
    (r.match(ll) || []).forEach(function(u, h) {
        var p = parseInt(t[h + 1], 10);
        switch (u.toLowerCase().charAt(0)) {
            case "y":
                a = p;
                break;
            case "d":
                n = p;
                break;
            case "h":
                s = p;
                break;
            case "s":
                c = p;
                break;
            case "m":
                s >= 0 ? o = p : i = p;
                break
        }
    }), c >= 0 && o == -1 && i >= 0 && (o = i, i = -1);
    var l = ("" + (a >= 0 ? a : new Date().getFullYear())).slice(-4) + "-" + ("00" + (i >= 1 ? i : 1)).slice(-2) + "-" + ("00" + (n >= 1 ? n : 1)).slice(-2);
    l.length == 7 && (l = "0" + l), l.length == 8 && (l = "20" + l);
    var f = ("00" + (s >= 0 ? s : 0)).slice(-2) + ":" + ("00" + (o >= 0 ? o : 0)).slice(-2) + ":" + ("00" + (c >= 0 ? c : 0)).slice(-2);
    return s == -1 && o == -1 && c == -1 ? l : a == -1 && i == -1 && n == -1 ? f : l + "T" + f
}
var Fd = (function() {
        var e = {};
        e.version = "1.2.0";

        function r() {
            for (var T = 0, N = new Array(256), P = 0; P != 256; ++P) T = P, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, T = T & 1 ? -306674912 ^ T >>> 1 : T >>> 1, N[P] = T;
            return typeof Int32Array < "u" ? new Int32Array(N) : N
        }
        var t = r();

        function a(T) {
            var N = 0,
                P = 0,
                X = 0,
                j = typeof Int32Array < "u" ? new Int32Array(4096) : new Array(4096);
            for (X = 0; X != 256; ++X) j[X] = T[X];
            for (X = 0; X != 256; ++X)
                for (P = T[X], N = 256 + X; N < 4096; N += 256) P = j[N] = P >>> 8 ^ T[P & 255];
            var B = [];
            for (X = 1; X != 16; ++X) B[X - 1] = typeof Int32Array < "u" ? j.subarray(X * 256, X * 256 + 256) : j.slice(X * 256, X * 256 + 256);
            return B
        }
        var i = a(t),
            n = i[0],
            s = i[1],
            o = i[2],
            c = i[3],
            l = i[4],
            f = i[5],
            u = i[6],
            h = i[7],
            p = i[8],
            m = i[9],
            d = i[10],
            x = i[11],
            E = i[12],
            S = i[13],
            _ = i[14];

        function L(T, N) {
            for (var P = N ^ -1, X = 0, j = T.length; X < j;) P = P >>> 8 ^ t[(P ^ T.charCodeAt(X++)) & 255];
            return ~P
        }

        function U(T, N) {
            for (var P = N ^ -1, X = T.length - 15, j = 0; j < X;) P = _[T[j++] ^ P & 255] ^ S[T[j++] ^ P >> 8 & 255] ^ E[T[j++] ^ P >> 16 & 255] ^ x[T[j++] ^ P >>> 24] ^ d[T[j++]] ^ m[T[j++]] ^ p[T[j++]] ^ h[T[j++]] ^ u[T[j++]] ^ f[T[j++]] ^ l[T[j++]] ^ c[T[j++]] ^ o[T[j++]] ^ s[T[j++]] ^ n[T[j++]] ^ t[T[j++]];
            for (X += 15; j < X;) P = P >>> 8 ^ t[(P ^ T[j++]) & 255];
            return ~P
        }

        function R(T, N) {
            for (var P = N ^ -1, X = 0, j = T.length, B = 0, se = 0; X < j;) B = T.charCodeAt(X++), B < 128 ? P = P >>> 8 ^ t[(P ^ B) & 255] : B < 2048 ? (P = P >>> 8 ^ t[(P ^ (192 | B >> 6 & 31)) & 255], P = P >>> 8 ^ t[(P ^ (128 | B & 63)) & 255]) : B >= 55296 && B < 57344 ? (B = (B & 1023) + 64, se = T.charCodeAt(X++) & 1023, P = P >>> 8 ^ t[(P ^ (240 | B >> 8 & 7)) & 255], P = P >>> 8 ^ t[(P ^ (128 | B >> 2 & 63)) & 255], P = P >>> 8 ^ t[(P ^ (128 | se >> 6 & 15 | (B & 3) << 4)) & 255], P = P >>> 8 ^ t[(P ^ (128 | se & 63)) & 255]) : (P = P >>> 8 ^ t[(P ^ (224 | B >> 12 & 15)) & 255], P = P >>> 8 ^ t[(P ^ (128 | B >> 6 & 63)) & 255], P = P >>> 8 ^ t[(P ^ (128 | B & 63)) & 255]);
            return ~P
        }
        return e.table = t, e.bstr = L, e.buf = U, e.str = R, e
    })(),
    Ae = (function() {
        var r = {};
        r.version = "1.2.1";

        function t(g, C) {
            for (var v = g.split("/"), w = C.split("/"), y = 0, F = 0, V = Math.min(v.length, w.length); y < V; ++y) {
                if (F = v[y].length - w[y].length) return F;
                if (v[y] != w[y]) return v[y] < w[y] ? -1 : 1
            }
            return v.length - w.length
        }

        function a(g) {
            if (g.charAt(g.length - 1) == "/") return g.slice(0, -1).indexOf("/") === -1 ? g : a(g.slice(0, -1));
            var C = g.lastIndexOf("/");
            return C === -1 ? g : g.slice(0, C + 1)
        }

        function i(g) {
            if (g.charAt(g.length - 1) == "/") return i(g.slice(0, -1));
            var C = g.lastIndexOf("/");
            return C === -1 ? g : g.slice(C + 1)
        }

        function n(g, C) {
            typeof C == "string" && (C = new Date(C));
            var v = C.getHours();
            v = v << 6 | C.getMinutes(), v = v << 5 | C.getSeconds() >>> 1, g.write_shift(2, v);
            var w = C.getFullYear() - 1980;
            w = w << 4 | C.getMonth() + 1, w = w << 5 | C.getDate(), g.write_shift(2, w)
        }

        function s(g) {
            var C = g.read_shift(2) & 65535,
                v = g.read_shift(2) & 65535,
                w = new Date,
                y = v & 31;
            v >>>= 5;
            var F = v & 15;
            v >>>= 4, w.setMilliseconds(0), w.setFullYear(v + 1980), w.setMonth(F - 1), w.setDate(y);
            var V = C & 31;
            C >>>= 5;
            var K = C & 63;
            return C >>>= 6, w.setHours(C), w.setMinutes(K), w.setSeconds(V << 1), w
        }

        function o(g) {
            Bt(g, 0);
            for (var C = {}, v = 0; g.l <= g.length - 4;) {
                var w = g.read_shift(2),
                    y = g.read_shift(2),
                    F = g.l + y,
                    V = {};
                w === 21589 && (v = g.read_shift(1), v & 1 && (V.mtime = g.read_shift(4)), y > 5 && (v & 2 && (V.atime = g.read_shift(4)), v & 4 && (V.ctime = g.read_shift(4))), V.mtime && (V.mt = new Date(V.mtime * 1e3))), g.l = F, C[w] = V
            }
            return C
        }
        var c;

        function l() {
            return c || (c = {})
        }

        function f(g, C) {
            if (g[0] == 80 && g[1] == 75) return H0(g, C);
            if ((g[0] | 32) == 109 && (g[1] | 32) == 105) return ku(g, C);
            if (g.length < 512) throw new Error("CFB file size " + g.length + " < 512");
            var v = 3,
                w = 512,
                y = 0,
                F = 0,
                V = 0,
                K = 0,
                G = 0,
                W = [],
                z = g.slice(0, 512);
            Bt(z, 0);
            var re = u(z);
            switch (v = re[0], v) {
                case 3:
                    w = 512;
                    break;
                case 4:
                    w = 4096;
                    break;
                case 0:
                    if (re[1] == 0) return H0(g, C);
                default:
                    throw new Error("Major Version: Expected 3 or 4 saw " + v)
            }
            w !== 512 && (z = g.slice(0, w), Bt(z, 28));
            var fe = g.slice(0, w);
            h(z, v);
            var Ee = z.read_shift(4, "i");
            if (v === 3 && Ee !== 0) throw new Error("# Directory Sectors: Expected 0 saw " + Ee);
            z.l += 4, V = z.read_shift(4, "i"), z.l += 4, z.chk("00100000", "Mini Stream Cutoff Size: "), K = z.read_shift(4, "i"), y = z.read_shift(4, "i"), G = z.read_shift(4, "i"), F = z.read_shift(4, "i");
            for (var ue = -1, he = 0; he < 109 && (ue = z.read_shift(4, "i"), !(ue < 0)); ++he) W[he] = ue;
            var Re = p(g, w);
            x(G, F, Re, w, W);
            var ot = S(Re, V, W, w);
            ot[V].name = "!Directory", y > 0 && K !== se && (ot[K].name = "!MiniFAT"), ot[W[0]].name = "!FAT", ot.fat_addrs = W, ot.ssz = w;
            var Zt = {},
                kt = [],
                lr = [],
                vi = [];
            _(V, ot, Re, kt, y, Zt, lr, K), m(lr, vi, kt), kt.shift();
            var wi = {
                FileIndex: lr,
                FullPaths: vi
            };
            return C && C.raw && (wi.raw = {
                header: fe,
                sectors: Re
            }), wi
        }

        function u(g) {
            if (g[g.l] == 80 && g[g.l + 1] == 75) return [0, 0];
            g.chk(_e, "Header Signature: "), g.l += 16;
            var C = g.read_shift(2, "u");
            return [g.read_shift(2, "u"), C]
        }

        function h(g, C) {
            var v = 9;
            switch (g.l += 2, v = g.read_shift(2)) {
                case 9:
                    if (C != 3) throw new Error("Sector Shift: Expected 9 saw " + v);
                    break;
                case 12:
                    if (C != 4) throw new Error("Sector Shift: Expected 12 saw " + v);
                    break;
                default:
                    throw new Error("Sector Shift: Expected 9 or 12 saw " + v)
            }
            g.chk("0600", "Mini Sector Shift: "), g.chk("000000000000", "Reserved: ")
        }

        function p(g, C) {
            for (var v = Math.ceil(g.length / C) - 1, w = [], y = 1; y < v; ++y) w[y - 1] = g.slice(y * C, (y + 1) * C);
            return w[v - 1] = g.slice(v * C), w
        }

        function m(g, C, v) {
            for (var w = 0, y = 0, F = 0, V = 0, K = 0, G = v.length, W = [], z = []; w < G; ++w) W[w] = z[w] = w, C[w] = v[w];
            for (; K < z.length; ++K) w = z[K], y = g[w].L, F = g[w].R, V = g[w].C, W[w] === w && (y !== -1 && W[y] !== y && (W[w] = W[y]), F !== -1 && W[F] !== F && (W[w] = W[F])), V !== -1 && (W[V] = w), y !== -1 && w != W[w] && (W[y] = W[w], z.lastIndexOf(y) < K && z.push(y)), F !== -1 && w != W[w] && (W[F] = W[w], z.lastIndexOf(F) < K && z.push(F));
            for (w = 1; w < G; ++w) W[w] === w && (F !== -1 && W[F] !== F ? W[w] = W[F] : y !== -1 && W[y] !== y && (W[w] = W[y]));
            for (w = 1; w < G; ++w)
                if (g[w].type !== 0) {
                    if (K = w, K != W[K])
                        do K = W[K], C[w] = C[K] + "/" + C[w]; while (K !== 0 && W[K] !== -1 && K != W[K]);
                    W[w] = -1
                }
            for (C[0] += "/", w = 1; w < G; ++w) g[w].type !== 2 && (C[w] += "/")
        }

        function d(g, C, v) {
            for (var w = g.start, y = g.size, F = [], V = w; v && y > 0 && V >= 0;) F.push(C.slice(V * B, V * B + B)), y -= B, V = ya(v, V * 4);
            return F.length === 0 ? Y(0) : Pt(F).slice(0, g.size)
        }

        function x(g, C, v, w, y) {
            var F = se;
            if (g === se) {
                if (C !== 0) throw new Error("DIFAT chain shorter than expected")
            } else if (g !== -1) {
                var V = v[g],
                    K = (w >>> 2) - 1;
                if (!V) return;
                for (var G = 0; G < K && (F = ya(V, G * 4)) !== se; ++G) y.push(F);
                x(ya(V, w - 4), C - 1, v, w, y)
            }
        }

        function E(g, C, v, w, y) {
            var F = [],
                V = [];
            y || (y = []);
            var K = w - 1,
                G = 0,
                W = 0;
            for (G = C; G >= 0;) {
                y[G] = !0, F[F.length] = G, V.push(g[G]);
                var z = v[Math.floor(G * 4 / w)];
                if (W = G * 4 & K, w < 4 + W) throw new Error("FAT boundary crossed: " + G + " 4 " + w);
                if (!g[z]) break;
                G = ya(g[z], W)
            }
            return {
                nodes: F,
                data: fc([V])
            }
        }

        function S(g, C, v, w) {
            var y = g.length,
                F = [],
                V = [],
                K = [],
                G = [],
                W = w - 1,
                z = 0,
                re = 0,
                fe = 0,
                Ee = 0;
            for (z = 0; z < y; ++z)
                if (K = [], fe = z + C, fe >= y && (fe -= y), !V[fe]) {
                    G = [];
                    var ue = [];
                    for (re = fe; re >= 0;) {
                        ue[re] = !0, V[re] = !0, K[K.length] = re, G.push(g[re]);
                        var he = v[Math.floor(re * 4 / w)];
                        if (Ee = re * 4 & W, w < 4 + Ee) throw new Error("FAT boundary crossed: " + re + " 4 " + w);
                        if (!g[he] || (re = ya(g[he], Ee), ue[re])) break
                    }
                    F[fe] = {
                        nodes: K,
                        data: fc([G])
                    }
                }
            return F
        }

        function _(g, C, v, w, y, F, V, K) {
            for (var G = 0, W = w.length ? 2 : 0, z = C[g].data, re = 0, fe = 0, Ee; re < z.length; re += 128) {
                var ue = z.slice(re, re + 128);
                Bt(ue, 64), fe = ue.read_shift(2), Ee = Zn(ue, 0, fe - W), w.push(Ee);
                var he = {
                        name: Ee,
                        type: ue.read_shift(1),
                        color: ue.read_shift(1),
                        L: ue.read_shift(4, "i"),
                        R: ue.read_shift(4, "i"),
                        C: ue.read_shift(4, "i"),
                        clsid: ue.read_shift(16),
                        state: ue.read_shift(4, "i"),
                        start: 0,
                        size: 0
                    },
                    Re = ue.read_shift(2) + ue.read_shift(2) + ue.read_shift(2) + ue.read_shift(2);
                Re !== 0 && (he.ct = L(ue, ue.l - 8));
                var ot = ue.read_shift(2) + ue.read_shift(2) + ue.read_shift(2) + ue.read_shift(2);
                ot !== 0 && (he.mt = L(ue, ue.l - 8)), he.start = ue.read_shift(4, "i"), he.size = ue.read_shift(4, "i"), he.size < 0 && he.start < 0 && (he.size = he.type = 0, he.start = se, he.name = ""), he.type === 5 ? (G = he.start, y > 0 && G !== se && (C[G].name = "!StreamData")) : he.size >= 4096 ? (he.storage = "fat", C[he.start] === void 0 && (C[he.start] = E(v, he.start, C.fat_addrs, C.ssz)), C[he.start].name = he.name, he.content = C[he.start].data.slice(0, he.size)) : (he.storage = "minifat", he.size < 0 ? he.size = 0 : G !== se && he.start !== se && C[G] && (he.content = d(he, C[G].data, (C[K] || {}).data))), he.content && Bt(he.content, 0), F[Ee] = he, V.push(he)
            }
        }

        function L(g, C) {
            return new Date((Rt(g, C + 4) / 1e7 * Math.pow(2, 32) + Rt(g, C) / 1e7 - 11644473600) * 1e3)
        }

        function U(g, C) {
            return l(), f(c.readFileSync(g), C)
        }

        function R(g, C) {
            var v = C && C.type;
            switch (v || Ue && Buffer.isBuffer(g) && (v = "buffer"), v || "base64") {
                case "file":
                    return U(g, C);
                case "base64":
                    return f(dr(pr(g)), C);
                case "binary":
                    return f(dr(g), C)
            }
            return f(g, C)
        }

        function T(g, C) {
            var v = C || {},
                w = v.root || "Root Entry";
            if (g.FullPaths || (g.FullPaths = []), g.FileIndex || (g.FileIndex = []), g.FullPaths.length !== g.FileIndex.length) throw new Error("inconsistent CFB structure");
            g.FullPaths.length === 0 && (g.FullPaths[0] = w + "/", g.FileIndex[0] = {
                name: w,
                type: 5
            }), v.CLSID && (g.FileIndex[0].clsid = v.CLSID), N(g)
        }

        function N(g) {
            var C = "Sh33tJ5";
            if (!Ae.find(g, "/" + C)) {
                var v = Y(4);
                v[0] = 55, v[1] = v[3] = 50, v[2] = 54, g.FileIndex.push({
                    name: C,
                    type: 2,
                    content: v,
                    size: 4,
                    L: 69,
                    R: 69,
                    C: 69
                }), g.FullPaths.push(g.FullPaths[0] + C), P(g)
            }
        }

        function P(g, C) {
            T(g);
            for (var v = !1, w = !1, y = g.FullPaths.length - 1; y >= 0; --y) {
                var F = g.FileIndex[y];
                switch (F.type) {
                    case 0:
                        w ? v = !0 : (g.FileIndex.pop(), g.FullPaths.pop());
                        break;
                    case 1:
                    case 2:
                    case 5:
                        w = !0, isNaN(F.R * F.L * F.C) && (v = !0), F.R > -1 && F.L > -1 && F.R == F.L && (v = !0);
                        break;
                    default:
                        v = !0;
                        break
                }
            }
            if (!(!v && !C)) {
                var V = new Date(1987, 1, 19),
                    K = 0,
                    G = Object.create ? Object.create(null) : {},
                    W = [];
                for (y = 0; y < g.FullPaths.length; ++y) G[g.FullPaths[y]] = !0, g.FileIndex[y].type !== 0 && W.push([g.FullPaths[y], g.FileIndex[y]]);
                for (y = 0; y < W.length; ++y) {
                    var z = a(W[y][0]);
                    w = G[z], w || (W.push([z, {
                        name: i(z).replace("/", ""),
                        type: 1,
                        clsid: ke,
                        ct: V,
                        mt: V,
                        content: null
                    }]), G[z] = !0)
                }
                for (W.sort(function(Ee, ue) {
                        return t(Ee[0], ue[0])
                    }), g.FullPaths = [], g.FileIndex = [], y = 0; y < W.length; ++y) g.FullPaths[y] = W[y][0], g.FileIndex[y] = W[y][1];
                for (y = 0; y < W.length; ++y) {
                    var re = g.FileIndex[y],
                        fe = g.FullPaths[y];
                    if (re.name = i(fe).replace("/", ""), re.L = re.R = re.C = -(re.color = 1), re.size = re.content ? re.content.length : 0, re.start = 0, re.clsid = re.clsid || ke, y === 0) re.C = W.length > 1 ? 1 : -1, re.size = 0, re.type = 5;
                    else if (fe.slice(-1) == "/") {
                        for (K = y + 1; K < W.length && a(g.FullPaths[K]) != fe; ++K);
                        for (re.C = K >= W.length ? -1 : K, K = y + 1; K < W.length && a(g.FullPaths[K]) != a(fe); ++K);
                        re.R = K >= W.length ? -1 : K, re.type = 1
                    } else a(g.FullPaths[y + 1] || "") == a(fe) && (re.R = y + 1), re.type = 2
                }
            }
        }

        function X(g, C) {
            var v = C || {};
            if (v.fileType == "mad") return Fu(g, v);
            if (P(g), v.fileType === "zip") return wu(g, v);
            var w = (function(Ee) {
                    for (var ue = 0, he = 0, Re = 0; Re < Ee.FileIndex.length; ++Re) {
                        var ot = Ee.FileIndex[Re];
                        if (ot.content) {
                            var Zt = ot.content.length;
                            Zt > 0 && (Zt < 4096 ? ue += Zt + 63 >> 6 : he += Zt + 511 >> 9)
                        }
                    }
                    for (var kt = Ee.FullPaths.length + 3 >> 2, lr = ue + 7 >> 3, vi = ue + 127 >> 7, wi = lr + he + kt + vi, Ea = wi + 127 >> 7, ns = Ea <= 109 ? 0 : Math.ceil((Ea - 109) / 127); wi + Ea + ns + 127 >> 7 > Ea;) ns = ++Ea <= 109 ? 0 : Math.ceil((Ea - 109) / 127);
                    var Kr = [1, ns, Ea, vi, kt, he, ue, 0];
                    return Ee.FileIndex[0].size = ue << 6, Kr[7] = (Ee.FileIndex[0].start = Kr[0] + Kr[1] + Kr[2] + Kr[3] + Kr[4] + Kr[5]) + (Kr[6] + 7 >> 3), Kr
                })(g),
                y = Y(w[7] << 9),
                F = 0,
                V = 0; {
                for (F = 0; F < 8; ++F) y.write_shift(1, oe[F]);
                for (F = 0; F < 8; ++F) y.write_shift(2, 0);
                for (y.write_shift(2, 62), y.write_shift(2, 3), y.write_shift(2, 65534), y.write_shift(2, 9), y.write_shift(2, 6), F = 0; F < 3; ++F) y.write_shift(2, 0);
                for (y.write_shift(4, 0), y.write_shift(4, w[2]), y.write_shift(4, w[0] + w[1] + w[2] + w[3] - 1), y.write_shift(4, 0), y.write_shift(4, 4096), y.write_shift(4, w[3] ? w[0] + w[1] + w[2] - 1 : se), y.write_shift(4, w[3]), y.write_shift(-4, w[1] ? w[0] - 1 : se), y.write_shift(4, w[1]), F = 0; F < 109; ++F) y.write_shift(-4, F < w[2] ? w[1] + F : -1)
            }
            if (w[1])
                for (V = 0; V < w[1]; ++V) {
                    for (; F < 236 + V * 127; ++F) y.write_shift(-4, F < w[2] ? w[1] + F : -1);
                    y.write_shift(-4, V === w[1] - 1 ? se : V + 1)
                }
            var K = function(Ee) {
                for (V += Ee; F < V - 1; ++F) y.write_shift(-4, F + 1);
                Ee && (++F, y.write_shift(-4, se))
            };
            for (V = F = 0, V += w[1]; F < V; ++F) y.write_shift(-4, Se.DIFSECT);
            for (V += w[2]; F < V; ++F) y.write_shift(-4, Se.FATSECT);
            K(w[3]), K(w[4]);
            for (var G = 0, W = 0, z = g.FileIndex[0]; G < g.FileIndex.length; ++G) z = g.FileIndex[G], z.content && (W = z.content.length, !(W < 4096) && (z.start = V, K(W + 511 >> 9)));
            for (K(w[6] + 7 >> 3); y.l & 511;) y.write_shift(-4, Se.ENDOFCHAIN);
            for (V = F = 0, G = 0; G < g.FileIndex.length; ++G) z = g.FileIndex[G], z.content && (W = z.content.length, !(!W || W >= 4096) && (z.start = V, K(W + 63 >> 6)));
            for (; y.l & 511;) y.write_shift(-4, Se.ENDOFCHAIN);
            for (F = 0; F < w[4] << 2; ++F) {
                var re = g.FullPaths[F];
                if (!re || re.length === 0) {
                    for (G = 0; G < 17; ++G) y.write_shift(4, 0);
                    for (G = 0; G < 3; ++G) y.write_shift(4, -1);
                    for (G = 0; G < 12; ++G) y.write_shift(4, 0);
                    continue
                }
                z = g.FileIndex[F], F === 0 && (z.start = z.size ? z.start - 1 : se);
                var fe = F === 0 && v.root || z.name;
                if (W = 2 * (fe.length + 1), y.write_shift(64, fe, "utf16le"), y.write_shift(2, W), y.write_shift(1, z.type), y.write_shift(1, z.color), y.write_shift(-4, z.L), y.write_shift(-4, z.R), y.write_shift(-4, z.C), z.clsid) y.write_shift(16, z.clsid, "hex");
                else
                    for (G = 0; G < 4; ++G) y.write_shift(4, 0);
                y.write_shift(4, z.state || 0), y.write_shift(4, 0), y.write_shift(4, 0), y.write_shift(4, 0), y.write_shift(4, 0), y.write_shift(4, z.start), y.write_shift(4, z.size), y.write_shift(4, 0)
            }
            for (F = 1; F < g.FileIndex.length; ++F)
                if (z = g.FileIndex[F], z.size >= 4096)
                    if (y.l = z.start + 1 << 9, Ue && Buffer.isBuffer(z.content)) z.content.copy(y, y.l, 0, z.size), y.l += z.size + 511 & -512;
                    else {
                        for (G = 0; G < z.size; ++G) y.write_shift(1, z.content[G]);
                        for (; G & 511; ++G) y.write_shift(1, 0)
                    }
            for (F = 1; F < g.FileIndex.length; ++F)
                if (z = g.FileIndex[F], z.size > 0 && z.size < 4096)
                    if (Ue && Buffer.isBuffer(z.content)) z.content.copy(y, y.l, 0, z.size), y.l += z.size + 63 & -64;
                    else {
                        for (G = 0; G < z.size; ++G) y.write_shift(1, z.content[G]);
                        for (; G & 63; ++G) y.write_shift(1, 0)
                    }
            if (Ue) y.l = y.length;
            else
                for (; y.l < y.length;) y.write_shift(1, 0);
            return y
        }

        function j(g, C) {
            var v = g.FullPaths.map(function(G) {
                    return G.toUpperCase()
                }),
                w = v.map(function(G) {
                    var W = G.split("/");
                    return W[W.length - (G.slice(-1) == "/" ? 2 : 1)]
                }),
                y = !1;
            C.charCodeAt(0) === 47 ? (y = !0, C = v[0].slice(0, -1) + C) : y = C.indexOf("/") !== -1;
            var F = C.toUpperCase(),
                V = y === !0 ? v.indexOf(F) : w.indexOf(F);
            if (V !== -1) return g.FileIndex[V];
            var K = !F.match(bi);
            for (F = F.replace(Xt, ""), K && (F = F.replace(bi, "!")), V = 0; V < v.length; ++V)
                if ((K ? v[V].replace(bi, "!") : v[V]).replace(Xt, "") == F || (K ? w[V].replace(bi, "!") : w[V]).replace(Xt, "") == F) return g.FileIndex[V];
            return null
        }
        var B = 64,
            se = -2,
            _e = "d0cf11e0a1b11ae1",
            oe = [208, 207, 17, 224, 161, 177, 26, 225],
            ke = "00000000000000000000000000000000",
            Se = {
                MAXREGSECT: -6,
                DIFSECT: -4,
                FATSECT: -3,
                ENDOFCHAIN: se,
                FREESECT: -1,
                HEADER_SIGNATURE: _e,
                HEADER_MINOR_VERSION: "3e00",
                MAXREGSID: -6,
                NOSTREAM: -1,
                HEADER_CLSID: ke,
                EntryTypes: ["unknown", "storage", "stream", "lockbytes", "property", "root"]
            };

        function Ve(g, C, v) {
            l();
            var w = X(g, v);
            c.writeFileSync(C, w)
        }

        function me(g) {
            for (var C = new Array(g.length), v = 0; v < g.length; ++v) C[v] = String.fromCharCode(g[v]);
            return C.join("")
        }

        function Te(g, C) {
            var v = X(g, C);
            switch (C && C.type || "buffer") {
                case "file":
                    return l(), c.writeFileSync(C.filename, v), v;
                case "binary":
                    return typeof v == "string" ? v : me(v);
                case "base64":
                    return Vi(typeof v == "string" ? v : me(v));
                case "buffer":
                    if (Ue) return Buffer.isBuffer(v) ? v : ra(v);
                case "array":
                    return typeof v == "string" ? dr(v) : v
            }
            return v
        }
        var Z;

        function b(g) {
            try {
                var C = g.InflateRaw,
                    v = new C;
                if (v._processChunk(new Uint8Array([3, 0]), v._finishFlushFlag), v.bytesRead) Z = g;
                else throw new Error("zlib does not expose bytesRead")
            } catch (w) {
                console.error("cannot use native zlib: " + (w.message || w))
            }
        }

        function H(g, C) {
            if (!Z) return V0(g, C);
            var v = Z.InflateRaw,
                w = new v,
                y = w._processChunk(g.slice(g.l), w._finishFlushFlag);
            return g.l += w.bytesRead, y
        }

        function O(g) {
            return Z ? Z.deflateRawSync(g) : We(g)
        }
        var M = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15],
            J = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258],
            de = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];

        function ie(g) {
            var C = (g << 1 | g << 11) & 139536 | (g << 5 | g << 15) & 558144;
            return (C >> 16 | C >> 8 | C) & 255
        }
        for (var ne = typeof Uint8Array < "u", Q = ne ? new Uint8Array(256) : [], Pe = 0; Pe < 256; ++Pe) Q[Pe] = ie(Pe);

        function A(g, C) {
            var v = Q[g & 255];
            return C <= 8 ? v >>> 8 - C : (v = v << 8 | Q[g >> 8 & 255], C <= 16 ? v >>> 16 - C : (v = v << 8 | Q[g >> 16 & 255], v >>> 24 - C))
        }

        function Ke(g, C) {
            var v = C & 7,
                w = C >>> 3;
            return (g[w] | (v <= 6 ? 0 : g[w + 1] << 8)) >>> v & 3
        }

        function He(g, C) {
            var v = C & 7,
                w = C >>> 3;
            return (g[w] | (v <= 5 ? 0 : g[w + 1] << 8)) >>> v & 7
        }

        function Je(g, C) {
            var v = C & 7,
                w = C >>> 3;
            return (g[w] | (v <= 4 ? 0 : g[w + 1] << 8)) >>> v & 15
        }

        function Ge(g, C) {
            var v = C & 7,
                w = C >>> 3;
            return (g[w] | (v <= 3 ? 0 : g[w + 1] << 8)) >>> v & 31
        }

        function xe(g, C) {
            var v = C & 7,
                w = C >>> 3;
            return (g[w] | (v <= 1 ? 0 : g[w + 1] << 8)) >>> v & 127
        }

        function wt(g, C, v) {
            var w = C & 7,
                y = C >>> 3,
                F = (1 << v) - 1,
                V = g[y] >>> w;
            return v < 8 - w || (V |= g[y + 1] << 8 - w, v < 16 - w) || (V |= g[y + 2] << 16 - w, v < 24 - w) || (V |= g[y + 3] << 24 - w), V & F
        }

        function mr(g, C, v) {
            var w = C & 7,
                y = C >>> 3;
            return w <= 5 ? g[y] |= (v & 7) << w : (g[y] |= v << w & 255, g[y + 1] = (v & 7) >> 8 - w), C + 3
        }

        function Br(g, C, v) {
            var w = C & 7,
                y = C >>> 3;
            return v = (v & 1) << w, g[y] |= v, C + 1
        }

        function $r(g, C, v) {
            var w = C & 7,
                y = C >>> 3;
            return v <<= w, g[y] |= v & 255, v >>>= 8, g[y + 1] = v, C + 8
        }

        function gi(g, C, v) {
            var w = C & 7,
                y = C >>> 3;
            return v <<= w, g[y] |= v & 255, v >>>= 8, g[y + 1] = v & 255, g[y + 2] = v >>> 8, C + 16
        }

        function na(g, C) {
            var v = g.length,
                w = 2 * v > C ? 2 * v : C + 5,
                y = 0;
            if (v >= C) return g;
            if (Ue) {
                var F = Xo(w);
                if (g.copy) g.copy(F);
                else
                    for (; y < g.length; ++y) F[y] = g[y];
                return F
            } else if (ne) {
                var V = new Uint8Array(w);
                if (V.set) V.set(g);
                else
                    for (; y < v; ++y) V[y] = g[y];
                return V
            }
            return g.length = w, g
        }

        function cr(g) {
            for (var C = new Array(g), v = 0; v < g; ++v) C[v] = 0;
            return C
        }

        function Yr(g, C, v) {
            var w = 1,
                y = 0,
                F = 0,
                V = 0,
                K = 0,
                G = g.length,
                W = ne ? new Uint16Array(32) : cr(32);
            for (F = 0; F < 32; ++F) W[F] = 0;
            for (F = G; F < v; ++F) g[F] = 0;
            G = g.length;
            var z = ne ? new Uint16Array(G) : cr(G);
            for (F = 0; F < G; ++F) W[y = g[F]]++, w < y && (w = y), z[F] = 0;
            for (W[0] = 0, F = 1; F <= w; ++F) W[F + 16] = K = K + W[F - 1] << 1;
            for (F = 0; F < G; ++F) K = g[F], K != 0 && (z[F] = W[K + 16]++);
            var re = 0;
            for (F = 0; F < G; ++F)
                if (re = g[F], re != 0)
                    for (K = A(z[F], w) >> w - re, V = (1 << w + 4 - re) - 1; V >= 0; --V) C[K | V << re] = re & 15 | F << 4;
            return w
        }
        var sa = ne ? new Uint16Array(512) : cr(512),
            _i = ne ? new Uint16Array(32) : cr(32);
        if (!ne) {
            for (var Yt = 0; Yt < 512; ++Yt) sa[Yt] = 0;
            for (Yt = 0; Yt < 32; ++Yt) _i[Yt] = 0
        }(function() {
            for (var g = [], C = 0; C < 32; C++) g.push(5);
            Yr(g, _i, 32);
            var v = [];
            for (C = 0; C <= 143; C++) v.push(8);
            for (; C <= 255; C++) v.push(9);
            for (; C <= 279; C++) v.push(7);
            for (; C <= 287; C++) v.push(8);
            Yr(v, sa, 288)
        })();
        var Ur = (function() {
            for (var C = ne ? new Uint8Array(32768) : [], v = 0, w = 0; v < de.length - 1; ++v)
                for (; w < de[v + 1]; ++w) C[w] = v;
            for (; w < 32768; ++w) C[w] = 29;
            var y = ne ? new Uint8Array(259) : [];
            for (v = 0, w = 0; v < J.length - 1; ++v)
                for (; w < J[v + 1]; ++w) y[w] = v;

            function F(K, G) {
                for (var W = 0; W < K.length;) {
                    var z = Math.min(65535, K.length - W),
                        re = W + z == K.length;
                    for (G.write_shift(1, +re), G.write_shift(2, z), G.write_shift(2, ~z & 65535); z-- > 0;) G[G.l++] = K[W++]
                }
                return G.l
            }

            function V(K, G) {
                for (var W = 0, z = 0, re = ne ? new Uint16Array(32768) : []; z < K.length;) {
                    var fe = Math.min(65535, K.length - z);
                    if (fe < 10) {
                        for (W = mr(G, W, +(z + fe == K.length)), W & 7 && (W += 8 - (W & 7)), G.l = W / 8 | 0, G.write_shift(2, fe), G.write_shift(2, ~fe & 65535); fe-- > 0;) G[G.l++] = K[z++];
                        W = G.l * 8;
                        continue
                    }
                    W = mr(G, W, +(z + fe == K.length) + 2);
                    for (var Ee = 0; fe-- > 0;) {
                        var ue = K[z];
                        Ee = (Ee << 5 ^ ue) & 32767;
                        var he = -1,
                            Re = 0;
                        if ((he = re[Ee]) && (he |= z & -32768, he > z && (he -= 32768), he < z))
                            for (; K[he + Re] == K[z + Re] && Re < 250;) ++Re;
                        if (Re > 2) {
                            ue = y[Re], ue <= 22 ? W = $r(G, W, Q[ue + 1] >> 1) - 1 : ($r(G, W, 3), W += 5, $r(G, W, Q[ue - 23] >> 5), W += 3);
                            var ot = ue < 8 ? 0 : ue - 4 >> 2;
                            ot > 0 && (gi(G, W, Re - J[ue]), W += ot), ue = C[z - he], W = $r(G, W, Q[ue] >> 3), W -= 3;
                            var Zt = ue < 4 ? 0 : ue - 2 >> 1;
                            Zt > 0 && (gi(G, W, z - he - de[ue]), W += Zt);
                            for (var kt = 0; kt < Re; ++kt) re[Ee] = z & 32767, Ee = (Ee << 5 ^ K[z]) & 32767, ++z;
                            fe -= Re - 1
                        } else ue <= 143 ? ue = ue + 48 : W = Br(G, W, 1), W = $r(G, W, Q[ue]), re[Ee] = z & 32767, ++z
                    }
                    W = $r(G, W, 0) - 1
                }
                return G.l = (W + 7) / 8 | 0, G.l
            }
            return function(G, W) {
                return G.length < 8 ? F(G, W) : V(G, W)
            }
        })();

        function We(g) {
            var C = Y(50 + Math.floor(g.length * 1.1)),
                v = Ur(g, C);
            return C.slice(0, v)
        }
        var St = ne ? new Uint16Array(32768) : cr(32768),
            xr = ne ? new Uint16Array(32768) : cr(32768),
            It = ne ? new Uint16Array(128) : cr(128),
            Sa = 1,
            U0 = 1;

        function gu(g, C) {
            var v = Ge(g, C) + 257;
            C += 5;
            var w = Ge(g, C) + 1;
            C += 5;
            var y = Je(g, C) + 4;
            C += 4;
            for (var F = 0, V = ne ? new Uint8Array(19) : cr(19), K = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], G = 1, W = ne ? new Uint8Array(8) : cr(8), z = ne ? new Uint8Array(8) : cr(8), re = V.length, fe = 0; fe < y; ++fe) V[M[fe]] = F = He(g, C), G < F && (G = F), W[F]++, C += 3;
            var Ee = 0;
            for (W[0] = 0, fe = 1; fe <= G; ++fe) z[fe] = Ee = Ee + W[fe - 1] << 1;
            for (fe = 0; fe < re; ++fe)(Ee = V[fe]) != 0 && (K[fe] = z[Ee]++);
            var ue = 0;
            for (fe = 0; fe < re; ++fe)
                if (ue = V[fe], ue != 0) {
                    Ee = Q[K[fe]] >> 8 - ue;
                    for (var he = (1 << 7 - ue) - 1; he >= 0; --he) It[Ee | he << ue] = ue & 7 | fe << 3
                }
            var Re = [];
            for (G = 1; Re.length < v + w;) switch (Ee = It[xe(g, C)], C += Ee & 7, Ee >>>= 3) {
                case 16:
                    for (F = 3 + Ke(g, C), C += 2, Ee = Re[Re.length - 1]; F-- > 0;) Re.push(Ee);
                    break;
                case 17:
                    for (F = 3 + He(g, C), C += 3; F-- > 0;) Re.push(0);
                    break;
                case 18:
                    for (F = 11 + xe(g, C), C += 7; F-- > 0;) Re.push(0);
                    break;
                default:
                    Re.push(Ee), G < Ee && (G = Ee);
                    break
            }
            var ot = Re.slice(0, v),
                Zt = Re.slice(v);
            for (fe = v; fe < 286; ++fe) ot[fe] = 0;
            for (fe = w; fe < 30; ++fe) Zt[fe] = 0;
            return Sa = Yr(ot, St, 286), U0 = Yr(Zt, xr, 30), C
        }

        function _u(g, C) {
            if (g[0] == 3 && !(g[1] & 3)) return [pa(C), 2];
            for (var v = 0, w = 0, y = Xo(C || 1 << 18), F = 0, V = y.length >>> 0, K = 0, G = 0;
                (w & 1) == 0;) {
                if (w = He(g, v), v += 3, w >>> 1) w >> 1 == 1 ? (K = 9, G = 5) : (v = gu(g, v), K = Sa, G = U0);
                else {
                    v & 7 && (v += 8 - (v & 7));
                    var W = g[v >>> 3] | g[(v >>> 3) + 1] << 8;
                    if (v += 32, W > 0)
                        for (!C && V < F + W && (y = na(y, F + W), V = y.length); W-- > 0;) y[F++] = g[v >>> 3], v += 8;
                    continue
                }
                for (;;) {
                    !C && V < F + 32767 && (y = na(y, F + 32767), V = y.length);
                    var z = wt(g, v, K),
                        re = w >>> 1 == 1 ? sa[z] : St[z];
                    if (v += re & 15, re >>>= 4, (re >>> 8 & 255) === 0) y[F++] = re;
                    else {
                        if (re == 256) break;
                        re -= 257;
                        var fe = re < 8 ? 0 : re - 4 >> 2;
                        fe > 5 && (fe = 0);
                        var Ee = F + J[re];
                        fe > 0 && (Ee += wt(g, v, fe), v += fe), z = wt(g, v, G), re = w >>> 1 == 1 ? _i[z] : xr[z], v += re & 15, re >>>= 4;
                        var ue = re < 4 ? 0 : re - 2 >> 1,
                            he = de[re];
                        for (ue > 0 && (he += wt(g, v, ue), v += ue), !C && V < Ee && (y = na(y, Ee + 100), V = y.length); F < Ee;) y[F] = y[F - he], ++F
                    }
                }
            }
            return C ? [y, v + 7 >>> 3] : [y.slice(0, F), v + 7 >>> 3]
        }

        function V0(g, C) {
            var v = g.slice(g.l || 0),
                w = _u(v, C);
            return g.l += w[1], w[0]
        }

        function W0(g, C) {
            if (g) typeof console < "u" && console.error(C);
            else throw new Error(C)
        }

        function H0(g, C) {
            var v = g;
            Bt(v, 0);
            var w = [],
                y = [],
                F = {
                    FileIndex: w,
                    FullPaths: y
                };
            T(F, {
                root: C.root
            });
            for (var V = v.length - 4;
                (v[V] != 80 || v[V + 1] != 75 || v[V + 2] != 5 || v[V + 3] != 6) && V >= 0;) --V;
            v.l = V + 4, v.l += 4;
            var K = v.read_shift(2);
            v.l += 6;
            var G = v.read_shift(4);
            for (v.l = G, V = 0; V < K; ++V) {
                v.l += 20;
                var W = v.read_shift(4),
                    z = v.read_shift(4),
                    re = v.read_shift(2),
                    fe = v.read_shift(2),
                    Ee = v.read_shift(2);
                v.l += 8;
                var ue = v.read_shift(4),
                    he = o(v.slice(v.l + re, v.l + re + fe));
                v.l += re + fe + Ee;
                var Re = v.l;
                v.l = ue + 4, vu(v, W, z, F, he), v.l = Re
            }
            return F
        }

        function vu(g, C, v, w, y) {
            g.l += 2;
            var F = g.read_shift(2),
                V = g.read_shift(2),
                K = s(g);
            if (F & 8257) throw new Error("Unsupported ZIP encryption");
            for (var G = g.read_shift(4), W = g.read_shift(4), z = g.read_shift(4), re = g.read_shift(2), fe = g.read_shift(2), Ee = "", ue = 0; ue < re; ++ue) Ee += String.fromCharCode(g[g.l++]);
            if (fe) {
                var he = o(g.slice(g.l, g.l + fe));
                (he[21589] || {}).mt && (K = he[21589].mt), ((y || {})[21589] || {}).mt && (K = y[21589].mt)
            }
            g.l += fe;
            var Re = g.slice(g.l, g.l + W);
            switch (V) {
                case 8:
                    Re = H(g, z);
                    break;
                case 0:
                    break;
                default:
                    throw new Error("Unsupported ZIP Compression method " + V)
            }
            var ot = !1;
            F & 8 && (G = g.read_shift(4), G == 134695760 && (G = g.read_shift(4), ot = !0), W = g.read_shift(4), z = g.read_shift(4)), W != C && W0(ot, "Bad compressed size: " + C + " != " + W), z != v && W0(ot, "Bad uncompressed size: " + v + " != " + z), is(w, Ee, Re, {
                unsafe: !0,
                mt: K
            })
        }

        function wu(g, C) {
            var v = C || {},
                w = [],
                y = [],
                F = Y(1),
                V = v.compression ? 8 : 0,
                K = 0,
                G = !1;
            G && (K |= 8);
            var W = 0,
                z = 0,
                re = 0,
                fe = 0,
                Ee = g.FullPaths[0],
                ue = Ee,
                he = g.FileIndex[0],
                Re = [],
                ot = 0;
            for (W = 1; W < g.FullPaths.length; ++W)
                if (ue = g.FullPaths[W].slice(Ee.length), he = g.FileIndex[W], !(!he.size || !he.content || ue == "Sh33tJ5")) {
                    var Zt = re,
                        kt = Y(ue.length);
                    for (z = 0; z < ue.length; ++z) kt.write_shift(1, ue.charCodeAt(z) & 127);
                    kt = kt.slice(0, kt.l), Re[fe] = Fd.buf(he.content, 0);
                    var lr = he.content;
                    V == 8 && (lr = O(lr)), F = Y(30), F.write_shift(4, 67324752), F.write_shift(2, 20), F.write_shift(2, K), F.write_shift(2, V), he.mt ? n(F, he.mt) : F.write_shift(4, 0), F.write_shift(-4, K & 8 ? 0 : Re[fe]), F.write_shift(4, K & 8 ? 0 : lr.length), F.write_shift(4, K & 8 ? 0 : he.content.length), F.write_shift(2, kt.length), F.write_shift(2, 0), re += F.length, w.push(F), re += kt.length, w.push(kt), re += lr.length, w.push(lr), K & 8 && (F = Y(12), F.write_shift(-4, Re[fe]), F.write_shift(4, lr.length), F.write_shift(4, he.content.length), re += F.l, w.push(F)), F = Y(46), F.write_shift(4, 33639248), F.write_shift(2, 0), F.write_shift(2, 20), F.write_shift(2, K), F.write_shift(2, V), F.write_shift(4, 0), F.write_shift(-4, Re[fe]), F.write_shift(4, lr.length), F.write_shift(4, he.content.length), F.write_shift(2, kt.length), F.write_shift(2, 0), F.write_shift(2, 0), F.write_shift(2, 0), F.write_shift(2, 0), F.write_shift(4, 0), F.write_shift(4, Zt), ot += F.l, y.push(F), ot += kt.length, y.push(kt), ++fe
                }
            return F = Y(22), F.write_shift(4, 101010256), F.write_shift(2, 0), F.write_shift(2, 0), F.write_shift(2, fe), F.write_shift(2, fe), F.write_shift(4, ot), F.write_shift(4, re), F.write_shift(2, 0), Pt([Pt(w), Pt(y), F])
        }
        var cn = {
            htm: "text/html",
            xml: "text/xml",
            gif: "image/gif",
            jpg: "image/jpeg",
            png: "image/png",
            mso: "application/x-mso",
            thmx: "application/vnd.ms-officetheme",
            sh33tj5: "application/octet-stream"
        };

        function Su(g, C) {
            if (g.ctype) return g.ctype;
            var v = g.name || "",
                w = v.match(/\.([^\.]+)$/);
            return w && cn[w[1]] || C && (w = (v = C).match(/[\.\\]([^\.\\])+$/), w && cn[w[1]]) ? cn[w[1]] : "application/octet-stream"
        }

        function Eu(g) {
            for (var C = Vi(g), v = [], w = 0; w < C.length; w += 76) v.push(C.slice(w, w + 76));
            return v.join(`\r
`) + `\r
`
        }

        function Cu(g) {
            var C = g.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF=]/g, function(W) {
                var z = W.charCodeAt(0).toString(16).toUpperCase();
                return "=" + (z.length == 1 ? "0" + z : z)
            });
            C = C.replace(/ $/mg, "=20").replace(/\t$/mg, "=09"), C.charAt(0) == `
` && (C = "=0D" + C.slice(1)), C = C.replace(/\r(?!\n)/mg, "=0D").replace(/\n\n/mg, `
=0A`).replace(/([^\r\n])\n/mg, "$1=0A");
            for (var v = [], w = C.split(`\r
`), y = 0; y < w.length; ++y) {
                var F = w[y];
                if (F.length == 0) {
                    v.push("");
                    continue
                }
                for (var V = 0; V < F.length;) {
                    var K = 76,
                        G = F.slice(V, V + K);
                    G.charAt(K - 1) == "=" ? K-- : G.charAt(K - 2) == "=" ? K -= 2 : G.charAt(K - 3) == "=" && (K -= 3), G = F.slice(V, V + K), V += K, V < F.length && (G += "="), v.push(G)
                }
            }
            return v.join(`\r
`)
        }

        function Tu(g) {
            for (var C = [], v = 0; v < g.length; ++v) {
                for (var w = g[v]; v <= g.length && w.charAt(w.length - 1) == "=";) w = w.slice(0, w.length - 1) + g[++v];
                C.push(w)
            }
            for (var y = 0; y < C.length; ++y) C[y] = C[y].replace(/[=][0-9A-Fa-f]{2}/g, function(F) {
                return String.fromCharCode(parseInt(F.slice(1), 16))
            });
            return dr(C.join(`\r
`))
        }

        function yu(g, C, v) {
            for (var w = "", y = "", F = "", V, K = 0; K < 10; ++K) {
                var G = C[K];
                if (!G || G.match(/^\s*$/)) break;
                var W = G.match(/^(.*?):\s*([^\s].*)$/);
                if (W) switch (W[1].toLowerCase()) {
                    case "content-location":
                        w = W[2].trim();
                        break;
                    case "content-type":
                        F = W[2].trim();
                        break;
                    case "content-transfer-encoding":
                        y = W[2].trim();
                        break
                }
            }
            switch (++K, y.toLowerCase()) {
                case "base64":
                    V = dr(pr(C.slice(K).join("")));
                    break;
                case "quoted-printable":
                    V = Tu(C.slice(K));
                    break;
                default:
                    throw new Error("Unsupported Content-Transfer-Encoding " + y)
            }
            var z = is(g, w.slice(v.length), V, {
                unsafe: !0
            });
            F && (z.ctype = F)
        }

        function ku(g, C) {
            if (me(g.slice(0, 13)).toLowerCase() != "mime-version:") throw new Error("Unsupported MAD header");
            var v = C && C.root || "",
                w = (Ue && Buffer.isBuffer(g) ? g.toString("binary") : me(g)).split(`\r
`),
                y = 0,
                F = "";
            for (y = 0; y < w.length; ++y)
                if (F = w[y], !!/^Content-Location:/i.test(F) && (F = F.slice(F.indexOf("file")), v || (v = F.slice(0, F.lastIndexOf("/") + 1)), F.slice(0, v.length) != v))
                    for (; v.length > 0 && (v = v.slice(0, v.length - 1), v = v.slice(0, v.lastIndexOf("/") + 1), F.slice(0, v.length) != v););
            var V = (w[1] || "").match(/boundary="(.*?)"/);
            if (!V) throw new Error("MAD cannot find boundary");
            var K = "--" + (V[1] || ""),
                G = [],
                W = [],
                z = {
                    FileIndex: G,
                    FullPaths: W
                };
            T(z);
            var re, fe = 0;
            for (y = 0; y < w.length; ++y) {
                var Ee = w[y];
                Ee !== K && Ee !== K + "--" || (fe++ && yu(z, w.slice(re, y), v), re = y)
            }
            return z
        }

        function Fu(g, C) {
            var v = C || {},
                w = v.boundary || "SheetJS";
            w = "------=" + w;
            for (var y = ["MIME-Version: 1.0", 'Content-Type: multipart/related; boundary="' + w.slice(2) + '"', "", "", ""], F = g.FullPaths[0], V = F, K = g.FileIndex[0], G = 1; G < g.FullPaths.length; ++G)
                if (V = g.FullPaths[G].slice(F.length), K = g.FileIndex[G], !(!K.size || !K.content || V == "Sh33tJ5")) {
                    V = V.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF]/g, function(Re) {
                        return "_x" + Re.charCodeAt(0).toString(16) + "_"
                    }).replace(/[\u0080-\uFFFF]/g, function(Re) {
                        return "_u" + Re.charCodeAt(0).toString(16) + "_"
                    });
                    for (var W = K.content, z = Ue && Buffer.isBuffer(W) ? W.toString("binary") : me(W), re = 0, fe = Math.min(1024, z.length), Ee = 0, ue = 0; ue <= fe; ++ue)(Ee = z.charCodeAt(ue)) >= 32 && Ee < 128 && ++re;
                    var he = re >= fe * 4 / 5;
                    y.push(w), y.push("Content-Location: " + (v.root || "file:///C:/SheetJS/") + V), y.push("Content-Transfer-Encoding: " + (he ? "quoted-printable" : "base64")), y.push("Content-Type: " + Su(K, V)), y.push(""), y.push(he ? Cu(z) : Eu(z))
                }
            return y.push(w + `--\r
`), y.join(`\r
`)
        }

        function Au(g) {
            var C = {};
            return T(C, g), C
        }

        function is(g, C, v, w) {
            var y = w && w.unsafe;
            y || T(g);
            var F = !y && Ae.find(g, C);
            if (!F) {
                var V = g.FullPaths[0];
                C.slice(0, V.length) == V ? V = C : (V.slice(-1) != "/" && (V += "/"), V = (V + C).replace("//", "/")), F = {
                    name: i(C),
                    type: 2
                }, g.FileIndex.push(F), g.FullPaths.push(V), y || Ae.utils.cfb_gc(g)
            }
            return F.content = v, F.size = v ? v.length : 0, w && (w.CLSID && (F.clsid = w.CLSID), w.mt && (F.mt = w.mt), w.ct && (F.ct = w.ct)), F
        }

        function bu(g, C) {
            T(g);
            var v = Ae.find(g, C);
            if (v) {
                for (var w = 0; w < g.FileIndex.length; ++w)
                    if (g.FileIndex[w] == v) return g.FileIndex.splice(w, 1), g.FullPaths.splice(w, 1), !0
            }
            return !1
        }

        function Iu(g, C, v) {
            T(g);
            var w = Ae.find(g, C);
            if (w) {
                for (var y = 0; y < g.FileIndex.length; ++y)
                    if (g.FileIndex[y] == w) return g.FileIndex[y].name = i(v), g.FullPaths[y] = v, !0
            }
            return !1
        }

        function Mu(g) {
            P(g, !0)
        }
        return r.find = j, r.read = R, r.parse = f, r.write = Te, r.writeFile = Ve, r.utils = {
            cfb_new: Au,
            cfb_add: is,
            cfb_del: bu,
            cfb_mov: Iu,
            cfb_gc: Mu,
            ReadShift: Mi,
            CheckField: Fl,
            prep_blob: Bt,
            bconcat: Pt,
            use_zlib: b,
            _deflateRaw: We,
            _inflateRaw: V0,
            consts: Se
        }, r
    })(),
    Qa;

function Ad(e) {
    return typeof e == "string" ? jn(e) : Array.isArray(e) ? ed(e) : e
}

function Qi(e, r, t) {
    if (typeof Qa < "u" && Qa.writeFileSync) return t ? Qa.writeFileSync(e, r, t) : Qa.writeFileSync(e, r);
    if (typeof Deno < "u") {
        if (t && typeof r == "string") switch (t) {
            case "utf8":
                r = new TextEncoder(t).encode(r);
                break;
            case "binary":
                r = jn(r);
                break;
            default:
                throw new Error("Unsupported encoding " + t)
        }
        return Deno.writeFileSync(e, r)
    }
    var a = t == "utf8" ? Gr(r) : r;
    if (typeof IE_SaveFile < "u") return IE_SaveFile(a, e);
    if (typeof Blob < "u") {
        var i = new Blob([Ad(a)], {
            type: "application/octet-stream"
        });
        if (typeof navigator < "u" && navigator.msSaveBlob) return navigator.msSaveBlob(i, e);
        if (typeof saveAs < "u") return saveAs(i, e);
        if (typeof URL < "u" && typeof document < "u" && document.createElement && URL.createObjectURL) {
            var n = URL.createObjectURL(i);
            if (typeof chrome == "object" && typeof(chrome.downloads || {}).download == "function") return URL.revokeObjectURL && typeof setTimeout < "u" && setTimeout(function() {
                URL.revokeObjectURL(n)
            }, 6e4), chrome.downloads.download({
                url: n,
                filename: e,
                saveAs: !0
            });
            var s = document.createElement("a");
            if (s.download != null) return s.download = e, s.href = n, document.body.appendChild(s), s.click(), document.body.removeChild(s), URL.revokeObjectURL && typeof setTimeout < "u" && setTimeout(function() {
                URL.revokeObjectURL(n)
            }, 6e4), n
        }
    }
    if (typeof $ < "u" && typeof File < "u" && typeof Folder < "u") try {
        var o = File(e);
        return o.open("w"), o.encoding = "binary", Array.isArray(r) && (r = _a(r)), o.write(r), o.close(), r
    } catch (c) {
        if (!c.message || !c.message.match(/onstruct/)) throw c
    }
    throw new Error("cannot save file " + e)
}

function bd(e) {
    if (typeof Qa < "u") return Qa.readFileSync(e);
    if (typeof Deno < "u") return Deno.readFileSync(e);
    if (typeof $ < "u" && typeof File < "u" && typeof Folder < "u") try {
        var r = File(e);
        r.open("r"), r.encoding = "binary";
        var t = r.read();
        return r.close(), t
    } catch (a) {
        if (!a.message || !a.message.match(/onstruct/)) throw a
    }
    throw new Error("Cannot access file " + e)
}

function vt(e) {
    for (var r = Object.keys(e), t = [], a = 0; a < r.length; ++a) Object.prototype.hasOwnProperty.call(e, r[a]) && t.push(r[a]);
    return t
}

function Qo(e, r) {
    for (var t = [], a = vt(e), i = 0; i !== a.length; ++i) t[e[a[i]][r]] == null && (t[e[a[i]][r]] = a[i]);
    return t
}

function Yn(e) {
    for (var r = [], t = vt(e), a = 0; a !== t.length; ++a) r[e[t[a]]] = t[a];
    return r
}

function Kn(e) {
    for (var r = [], t = vt(e), a = 0; a !== t.length; ++a) r[e[t[a]]] = parseInt(t[a], 10);
    return r
}

function Id(e) {
    for (var r = [], t = vt(e), a = 0; a !== t.length; ++a) r[e[t[a]]] == null && (r[e[t[a]]] = []), r[e[t[a]]].push(t[a]);
    return r
}
var Ln = new Date(1899, 11, 30, 0, 0, 0);

function Ot(e, r) {
    var t = e.getTime();
    r && (t -= 1462 * 24 * 60 * 60 * 1e3);
    var a = Ln.getTime() + (e.getTimezoneOffset() - Ln.getTimezoneOffset()) * 6e4;
    return (t - a) / (1440 * 60 * 1e3)
}
var fl = new Date,
    Md = Ln.getTime() + (fl.getTimezoneOffset() - Ln.getTimezoneOffset()) * 6e4,
    ec = fl.getTimezoneOffset();

function Jn(e) {
    var r = new Date;
    return r.setTime(e * 24 * 60 * 60 * 1e3 + Md), r.getTimezoneOffset() !== ec && r.setTime(r.getTime() + (r.getTimezoneOffset() - ec) * 6e4), r
}

function Od(e) {
    var r = 0,
        t = 0,
        a = !1,
        i = e.match(/P([0-9\.]+Y)?([0-9\.]+M)?([0-9\.]+D)?T([0-9\.]+H)?([0-9\.]+M)?([0-9\.]+S)?/);
    if (!i) throw new Error("|" + e + "| is not an ISO8601 Duration");
    for (var n = 1; n != i.length; ++n)
        if (i[n]) {
            switch (t = 1, n > 3 && (a = !0), i[n].slice(i[n].length - 1)) {
                case "Y":
                    throw new Error("Unsupported ISO Duration Field: " + i[n].slice(i[n].length - 1));
                case "D":
                    t *= 24;
                case "H":
                    t *= 60;
                case "M":
                    if (a) t *= 60;
                    else throw new Error("Unsupported ISO Duration Field: M");
                case "S":
                    break
            }
            r += t * parseInt(i[n], 10)
        }
    return r
}
var tc = new Date("2017-02-19T19:06:09.000Z"),
    ul = isNaN(tc.getFullYear()) ? new Date("2/19/17") : tc,
    Dd = ul.getFullYear() == 2017;

function ft(e, r) {
    var t = new Date(e);
    if (Dd) return r > 0 ? t.setTime(t.getTime() + t.getTimezoneOffset() * 60 * 1e3) : r < 0 && t.setTime(t.getTime() - t.getTimezoneOffset() * 60 * 1e3), t;
    if (e instanceof Date) return e;
    if (ul.getFullYear() == 1917 && !isNaN(t.getFullYear())) {
        var a = t.getFullYear();
        return e.indexOf("" + a) > -1 || t.setFullYear(t.getFullYear() + 100), t
    }
    var i = e.match(/\d+/g) || ["2017", "2", "19", "0", "0", "0"],
        n = new Date(+i[0], +i[1] - 1, +i[2], +i[3] || 0, +i[4] || 0, +i[5] || 0);
    return e.indexOf("Z") > -1 && (n = new Date(n.getTime() - n.getTimezoneOffset() * 60 * 1e3)), n
}

function Oa(e, r) {
    if (Ue && Buffer.isBuffer(e)) {
        if (r) {
            if (e[0] == 255 && e[1] == 254) return Gr(e.slice(2).toString("utf16le"));
            if (e[1] == 254 && e[2] == 255) return Gr(Zc(e.slice(2).toString("binary")))
        }
        return e.toString("binary")
    }
    if (typeof TextDecoder < "u") try {
        if (r) {
            if (e[0] == 255 && e[1] == 254) return Gr(new TextDecoder("utf-16le").decode(e.slice(2)));
            if (e[0] == 254 && e[1] == 255) return Gr(new TextDecoder("utf-16be").decode(e.slice(2)))
        }
        var t = {
            "\u20AC": "\x80",
            "\u201A": "\x82",
            \u0192: "\x83",
            "\u201E": "\x84",
            "\u2026": "\x85",
            "\u2020": "\x86",
            "\u2021": "\x87",
            "\u02C6": "\x88",
            "\u2030": "\x89",
            \u0160: "\x8A",
            "\u2039": "\x8B",
            \u0152: "\x8C",
            \u017D: "\x8E",
            "\u2018": "\x91",
            "\u2019": "\x92",
            "\u201C": "\x93",
            "\u201D": "\x94",
            "\u2022": "\x95",
            "\u2013": "\x96",
            "\u2014": "\x97",
            "\u02DC": "\x98",
            "\u2122": "\x99",
            \u0161: "\x9A",
            "\u203A": "\x9B",
            \u0153: "\x9C",
            \u017E: "\x9E",
            \u0178: "\x9F"
        };
        return Array.isArray(e) && (e = new Uint8Array(e)), new TextDecoder("latin1").decode(e).replace(/[€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ]/g, function(n) {
            return t[n] || n
        })
    } catch (n) {}
    for (var a = [], i = 0; i != e.length; ++i) a.push(String.fromCharCode(e[i]));
    return a.join("")
}

function ut(e) {
    if (typeof JSON < "u" && !Array.isArray(e)) return JSON.parse(JSON.stringify(e));
    if (typeof e != "object" || e == null) return e;
    if (e instanceof Date) return new Date(e.getTime());
    var r = {};
    for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (r[t] = ut(e[t]));
    return r
}

function xt(e, r) {
    for (var t = ""; t.length < r;) t += e;
    return t
}

function Nr(e) {
    var r = Number(e);
    if (!isNaN(r)) return isFinite(r) ? r : NaN;
    if (!/\d/.test(e)) return r;
    var t = 1,
        a = e.replace(/([\d]),([\d])/g, "$1$2").replace(/[$]/g, "").replace(/[%]/g, function() {
            return t *= 100, ""
        });
    return !isNaN(r = Number(a)) || (a = a.replace(/[(](.*)[)]/, function(i, n) {
        return t = -t, n
    }), !isNaN(r = Number(a))) ? r / t : r
}
var Rd = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

function si(e) {
    var r = new Date(e),
        t = new Date(NaN),
        a = r.getYear(),
        i = r.getMonth(),
        n = r.getDate();
    if (isNaN(n)) return t;
    var s = e.toLowerCase();
    if (s.match(/jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/)) {
        if (s = s.replace(/[^a-z]/g, "").replace(/([^a-z]|^)[ap]m?([^a-z]|$)/, ""), s.length > 3 && Rd.indexOf(s) == -1) return t
    } else if (s.match(/[a-z]/)) return t;
    return a < 0 || a > 8099 ? t : (i > 0 || n > 1) && a != 101 ? r : e.match(/[^-0-9:,\/\\]/) ? t : r
}
var Pd = (function() {
    var e = "abacaba".split(/(:?b)/i).length == 5;
    return function(t, a, i) {
        if (e || typeof a == "string") return t.split(a);
        for (var n = t.split(a), s = [n[0]], o = 1; o < n.length; ++o) s.push(i), s.push(n[o]);
        return s
    }
})();

function dl(e) {
    return e ? e.content && e.type ? Oa(e.content, !0) : e.data ? Ai(e.data) : e.asNodeBuffer && Ue ? Ai(e.asNodeBuffer().toString("binary")) : e.asBinary ? Ai(e.asBinary()) : e._data && e._data.getContent ? Ai(Oa(Array.prototype.slice.call(e._data.getContent(), 0))) : null : null
}

function hl(e) {
    if (!e) return null;
    if (e.data) return Ds(e.data);
    if (e.asNodeBuffer && Ue) return e.asNodeBuffer();
    if (e._data && e._data.getContent) {
        var r = e._data.getContent();
        return typeof r == "string" ? Ds(r) : Array.prototype.slice.call(r)
    }
    return e.content && e.type ? e.content : null
}

function Nd(e) {
    return e && e.name.slice(-4) === ".bin" ? hl(e) : dl(e)
}

function Fr(e, r) {
    for (var t = e.FullPaths || vt(e.files), a = r.toLowerCase().replace(/[\/]/g, "\\"), i = a.replace(/\\/g, "/"), n = 0; n < t.length; ++n) {
        var s = t[n].replace(/^Root Entry[\/]/, "").toLowerCase();
        if (a == s || i == s) return e.files ? e.files[t[n]] : e.FileIndex[n]
    }
    return null
}

function Js(e, r) {
    var t = Fr(e, r);
    if (t == null) throw new Error("Cannot find file " + r + " in zip");
    return t
}

function At(e, r, t) {
    if (!t) return Nd(Js(e, r));
    if (!r) return null;
    try {
        return At(e, r)
    } catch (a) {
        return null
    }
}

function hr(e, r, t) {
    if (!t) return dl(Js(e, r));
    if (!r) return null;
    try {
        return hr(e, r)
    } catch (a) {
        return null
    }
}

function pl(e, r, t) {
    if (!t) return hl(Js(e, r));
    if (!r) return null;
    try {
        return pl(e, r)
    } catch (a) {
        return null
    }
}

function rc(e) {
    for (var r = e.FullPaths || vt(e.files), t = [], a = 0; a < r.length; ++a) r[a].slice(-1) != "/" && t.push(r[a].replace(/^Root Entry[\/]/, ""));
    return t.sort()
}

function Le(e, r, t) {
    if (e.FullPaths) {
        if (typeof t == "string") {
            var a;
            return Ue ? a = ra(t) : a = td(t), Ae.utils.cfb_add(e, r, a)
        }
        Ae.utils.cfb_add(e, r, t)
    } else e.file(r, t)
}

function Zs() {
    return Ae.utils.cfb_new()
}

function ml(e, r) {
    switch (r.type) {
        case "base64":
            return Ae.read(e, {
                type: "base64"
            });
        case "binary":
            return Ae.read(e, {
                type: "binary"
            });
        case "buffer":
        case "array":
            return Ae.read(e, {
                type: "buffer"
            })
    }
    throw new Error("Unrecognized type " + r.type)
}

function Ii(e, r) {
    if (e.charAt(0) == "/") return e.slice(1);
    var t = r.split("/");
    r.slice(-1) != "/" && t.pop();
    for (var a = e.split("/"); a.length !== 0;) {
        var i = a.shift();
        i === ".." ? t.pop() : i !== "." && t.push(i)
    }
    return t.join("/")
}
var yt = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r
`,
    Ld = /([^"\s?>\/]+)\s*=\s*((?:")([^"]*)(?:")|(?:')([^']*)(?:')|([^'">\s]+))/g,
    ac = /<[\/\?]?[a-zA-Z0-9:_-]+(?:\s+[^"\s?>\/]+\s*=\s*(?:"[^"]*"|'[^']*'|[^'">\s=]+))*\s*[\/\?]?>/mg,
    Bd = /<[^>]*>/g,
    $t = yt.match(ac) ? ac : Bd,
    Ud = /<\w*:/,
    Vd = /<(\/?)\w+:/;

function Oe(e, r, t) {
    for (var a = {}, i = 0, n = 0; i !== e.length && !((n = e.charCodeAt(i)) === 32 || n === 10 || n === 13); ++i);
    if (r || (a[0] = e.slice(0, i)), i === e.length) return a;
    var s = e.match(Ld),
        o = 0,
        c = "",
        l = 0,
        f = "",
        u = "",
        h = 1;
    if (s)
        for (l = 0; l != s.length; ++l) {
            for (u = s[l], n = 0; n != u.length && u.charCodeAt(n) !== 61; ++n);
            for (f = u.slice(0, n).trim(); u.charCodeAt(n + 1) == 32;) ++n;
            for (h = (i = u.charCodeAt(n + 1)) == 34 || i == 39 ? 1 : 0, c = u.slice(n + 1 + h, u.length - h), o = 0; o != f.length && f.charCodeAt(o) !== 58; ++o);
            if (o === f.length) f.indexOf("_") > 0 && (f = f.slice(0, f.indexOf("_"))), a[f] = c, t || (a[f.toLowerCase()] = c);
            else {
                var p = (o === 5 && f.slice(0, 5) === "xmlns" ? "xmlns" : "") + f.slice(o + 1);
                if (a[p] && f.slice(o - 3, o) == "ext") continue;
                a[p] = c, t || (a[p.toLowerCase()] = c)
            }
        }
    return a
}

function Xr(e) {
    return e.replace(Vd, "<$1")
}
var xl = {
        "&quot;": '"',
        "&apos;": "'",
        "&gt;": ">",
        "&lt;": "<",
        "&amp;": "&"
    },
    Qs = Yn(xl),
    ze = (function() {
        var e = /&(?:quot|apos|gt|lt|amp|#x?([\da-fA-F]+));/ig,
            r = /_x([\da-fA-F]{4})_/ig;
        return function t(a) {
            var i = a + "",
                n = i.indexOf("<![CDATA[");
            if (n == -1) return i.replace(e, function(o, c) {
                return xl[o] || String.fromCharCode(parseInt(c, o.indexOf("x") > -1 ? 16 : 10)) || o
            }).replace(r, function(o, c) {
                return String.fromCharCode(parseInt(c, 16))
            });
            var s = i.indexOf("]]>");
            return t(i.slice(0, n)) + i.slice(n + 9, s) + t(i.slice(s + 3))
        }
    })(),
    e0 = /[&<>'"]/g,
    Wd = /[\u0000-\u0008\u000b-\u001f]/g;

function tt(e) {
    var r = e + "";
    return r.replace(e0, function(t) {
        return Qs[t]
    }).replace(Wd, function(t) {
        return "_x" + ("000" + t.charCodeAt(0).toString(16)).slice(-4) + "_"
    })
}

function ic(e) {
    return tt(e).replace(/ /g, "_x0020_")
}
var gl = /[\u0000-\u001f]/g;

function t0(e) {
    var r = e + "";
    return r.replace(e0, function(t) {
        return Qs[t]
    }).replace(/\n/g, "<br/>").replace(gl, function(t) {
        return "&#x" + ("000" + t.charCodeAt(0).toString(16)).slice(-4) + ";"
    })
}

function Hd(e) {
    var r = e + "";
    return r.replace(e0, function(t) {
        return Qs[t]
    }).replace(gl, function(t) {
        return "&#x" + t.charCodeAt(0).toString(16).toUpperCase() + ";"
    })
}
var nc = (function() {
    var e = /&#(\d+);/g;

    function r(t, a) {
        return String.fromCharCode(parseInt(a, 10))
    }
    return function(a) {
        return a.replace(e, r)
    }
})();

function Gd(e) {
    return e.replace(/(\r\n|[\r\n])/g, "&#10;")
}

function lt(e) {
    switch (e) {
        case 1:
        case !0:
        case "1":
        case "true":
        case "TRUE":
            return !0;
        default:
            return !1
    }
}

function ws(e) {
    for (var r = "", t = 0, a = 0, i = 0, n = 0, s = 0, o = 0; t < e.length;) {
        if (a = e.charCodeAt(t++), a < 128) {
            r += String.fromCharCode(a);
            continue
        }
        if (i = e.charCodeAt(t++), a > 191 && a < 224) {
            s = (a & 31) << 6, s |= i & 63, r += String.fromCharCode(s);
            continue
        }
        if (n = e.charCodeAt(t++), a < 240) {
            r += String.fromCharCode((a & 15) << 12 | (i & 63) << 6 | n & 63);
            continue
        }
        s = e.charCodeAt(t++), o = ((a & 7) << 18 | (i & 63) << 12 | (n & 63) << 6 | s & 63) - 65536, r += String.fromCharCode(55296 + (o >>> 10 & 1023)), r += String.fromCharCode(56320 + (o & 1023))
    }
    return r
}

function sc(e) {
    var r = pa(2 * e.length),
        t, a, i = 1,
        n = 0,
        s = 0,
        o;
    for (a = 0; a < e.length; a += i) i = 1, (o = e.charCodeAt(a)) < 128 ? t = o : o < 224 ? (t = (o & 31) * 64 + (e.charCodeAt(a + 1) & 63), i = 2) : o < 240 ? (t = (o & 15) * 4096 + (e.charCodeAt(a + 1) & 63) * 64 + (e.charCodeAt(a + 2) & 63), i = 3) : (i = 4, t = (o & 7) * 262144 + (e.charCodeAt(a + 1) & 63) * 4096 + (e.charCodeAt(a + 2) & 63) * 64 + (e.charCodeAt(a + 3) & 63), t -= 65536, s = 55296 + (t >>> 10 & 1023), t = 56320 + (t & 1023)), s !== 0 && (r[n++] = s & 255, r[n++] = s >>> 8, s = 0), r[n++] = t % 256, r[n++] = t >>> 8;
    return r.slice(0, n).toString("ucs2")
}

function oc(e) {
    return ra(e, "binary").toString("utf8")
}
var Tn = "foo bar baz\xE2\x98\x83\xF0\x9F\x8D\xA3",
    at = Ue && (oc(Tn) == ws(Tn) && oc || sc(Tn) == ws(Tn) && sc) || ws,
    Gr = Ue ? function(e) {
        return ra(e, "utf8").toString("binary")
    } : function(e) {
        for (var r = [], t = 0, a = 0, i = 0; t < e.length;) switch (a = e.charCodeAt(t++), !0) {
            case a < 128:
                r.push(String.fromCharCode(a));
                break;
            case a < 2048:
                r.push(String.fromCharCode(192 + (a >> 6))), r.push(String.fromCharCode(128 + (a & 63)));
                break;
            case (a >= 55296 && a < 57344):
                a -= 55296, i = e.charCodeAt(t++) - 56320 + (a << 10), r.push(String.fromCharCode(240 + (i >> 18 & 7))), r.push(String.fromCharCode(144 + (i >> 12 & 63))), r.push(String.fromCharCode(128 + (i >> 6 & 63))), r.push(String.fromCharCode(128 + (i & 63)));
                break;
            default:
                r.push(String.fromCharCode(224 + (a >> 12))), r.push(String.fromCharCode(128 + (a >> 6 & 63))), r.push(String.fromCharCode(128 + (a & 63)))
        }
        return r.join("")
    },
    Hi = (function() {
        var e = {};
        return function(t, a) {
            var i = t + "|" + (a || "");
            return e[i] ? e[i] : e[i] = new RegExp("<(?:\\w+:)?" + t + '(?: xml:space="preserve")?(?:[^>]*)>([\\s\\S]*?)</(?:\\w+:)?' + t + ">", a || "")
        }
    })(),
    _l = (function() {
        var e = [
            ["nbsp", " "],
            ["middot", "\xB7"],
            ["quot", '"'],
            ["apos", "'"],
            ["gt", ">"],
            ["lt", "<"],
            ["amp", "&"]
        ].map(function(r) {
            return [new RegExp("&" + r[0] + ";", "ig"), r[1]]
        });
        return function(t) {
            for (var a = t.replace(/^[\t\n\r ]+/, "").replace(/[\t\n\r ]+$/, "").replace(/>\s+/g, ">").replace(/\s+</g, "<").replace(/[\t\n\r ]+/g, " ").replace(/<\s*[bB][rR]\s*\/?>/g, `
`).replace(/<[^>]*>/g, ""), i = 0; i < e.length; ++i) a = a.replace(e[i][0], e[i][1]);
            return a
        }
    })(),
    zd = (function() {
        var e = {};
        return function(t) {
            return e[t] !== void 0 ? e[t] : e[t] = new RegExp("<(?:vt:)?" + t + ">([\\s\\S]*?)</(?:vt:)?" + t + ">", "g")
        }
    })(),
    Xd = /<\/?(?:vt:)?variant>/g,
    qd = /<(?:vt:)([^>]*)>([\s\S]*)</;

function cc(e, r) {
    var t = Oe(e),
        a = e.match(zd(t.baseType)) || [],
        i = [];
    if (a.length != t.size) {
        if (r.WTF) throw new Error("unexpected vector length " + a.length + " != " + t.size);
        return i
    }
    return a.forEach(function(n) {
        var s = n.replace(Xd, "").match(qd);
        s && i.push({
            v: at(s[2]),
            t: s[1]
        })
    }), i
}
var vl = /(^\s|\s$|\n)/;

function Ut(e, r) {
    return "<" + e + (r.match(vl) ? ' xml:space="preserve"' : "") + ">" + r + "</" + e + ">"
}

function Gi(e) {
    return vt(e).map(function(r) {
        return " " + r + '="' + e[r] + '"'
    }).join("")
}

function ce(e, r, t) {
    return "<" + e + (t != null ? Gi(t) : "") + (r != null ? (r.match(vl) ? ' xml:space="preserve"' : "") + ">" + r + "</" + e : "/") + ">"
}

function Rs(e, r) {
    try {
        return e.toISOString().replace(/\.\d*/, "")
    } catch (t) {
        if (r) throw t
    }
    return ""
}

function jd(e, r) {
    switch (typeof e) {
        case "string":
            var t = ce("vt:lpwstr", tt(e));
            return r && (t = t.replace(/&quot;/g, "_x0022_")), t;
        case "number":
            return ce((e | 0) == e ? "vt:i4" : "vt:r8", tt(String(e)));
        case "boolean":
            return ce("vt:bool", e ? "true" : "false")
    }
    if (e instanceof Date) return ce("vt:filetime", Rs(e));
    throw new Error("Unable to serialize " + e)
}

function r0(e) {
    if (Ue && Buffer.isBuffer(e)) return e.toString("utf8");
    if (typeof e == "string") return e;
    if (typeof Uint8Array < "u" && e instanceof Uint8Array) return at(_a($s(e)));
    throw new Error("Bad input format: expected Buffer or string")
}
var zi = /<(\/?)([^\s?><!\/:]*:|)([^\s?<>:\/]+)(?:[\s?:\/][^>]*)?>/mg,
    Mt = {
        CORE_PROPS: "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
        CUST_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties",
        EXT_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
        CT: "http://schemas.openxmlformats.org/package/2006/content-types",
        RELS: "http://schemas.openxmlformats.org/package/2006/relationships",
        TCMNT: "http://schemas.microsoft.com/office/spreadsheetml/2018/threadedcomments",
        dc: "http://purl.org/dc/elements/1.1/",
        dcterms: "http://purl.org/dc/terms/",
        dcmitype: "http://purl.org/dc/dcmitype/",
        mx: "http://schemas.microsoft.com/office/mac/excel/2008/main",
        r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        sjs: "http://schemas.openxmlformats.org/package/2006/sheetjs/core-properties",
        vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes",
        xsi: "http://www.w3.org/2001/XMLSchema-instance",
        xsd: "http://www.w3.org/2001/XMLSchema"
    },
    La = ["http://schemas.openxmlformats.org/spreadsheetml/2006/main", "http://purl.oclc.org/ooxml/spreadsheetml/main", "http://schemas.microsoft.com/office/excel/2006/main", "http://schemas.microsoft.com/office/excel/2006/2"],
    ur = {
        o: "urn:schemas-microsoft-com:office:office",
        x: "urn:schemas-microsoft-com:office:excel",
        ss: "urn:schemas-microsoft-com:office:spreadsheet",
        dt: "uuid:C2F41010-65B3-11d1-A29F-00AA00C14882",
        mv: "http://macVmlSchemaUri",
        v: "urn:schemas-microsoft-com:vml",
        html: "http://www.w3.org/TR/REC-html40"
    };

function $d(e, r) {
    for (var t = 1 - 2 * (e[r + 7] >>> 7), a = ((e[r + 7] & 127) << 4) + (e[r + 6] >>> 4 & 15), i = e[r + 6] & 15, n = 5; n >= 0; --n) i = i * 256 + e[r + n];
    return a == 2047 ? i == 0 ? t * (1 / 0) : NaN : (a == 0 ? a = -1022 : (a -= 1023, i += Math.pow(2, 52)), t * Math.pow(2, a - 52) * i)
}

function Yd(e, r, t) {
    var a = (r < 0 || 1 / r == -1 / 0 ? 1 : 0) << 7,
        i = 0,
        n = 0,
        s = a ? -r : r;
    isFinite(s) ? s == 0 ? i = n = 0 : (i = Math.floor(Math.log(s) / Math.LN2), n = s * Math.pow(2, 52 - i), i <= -1023 && (!isFinite(n) || n < Math.pow(2, 52)) ? i = -1022 : (n -= Math.pow(2, 52), i += 1023)) : (i = 2047, n = isNaN(r) ? 26985 : 0);
    for (var o = 0; o <= 5; ++o, n /= 256) e[t + o] = n & 255;
    e[t + 6] = (i & 15) << 4 | n & 15, e[t + 7] = i >> 4 | a
}
var lc = function(e) {
        for (var r = [], t = 10240, a = 0; a < e[0].length; ++a)
            if (e[0][a])
                for (var i = 0, n = e[0][a].length; i < n; i += t) r.push.apply(r, e[0][a].slice(i, i + t));
        return r
    },
    fc = Ue ? function(e) {
        return e[0].length > 0 && Buffer.isBuffer(e[0][0]) ? Buffer.concat(e[0].map(function(r) {
            return Buffer.isBuffer(r) ? r : ra(r)
        })) : lc(e)
    } : lc,
    uc = function(e, r, t) {
        for (var a = [], i = r; i < t; i += 2) a.push(String.fromCharCode(Jr(e, i)));
        return a.join("").replace(Xt, "")
    },
    Zn = Ue ? function(e, r, t) {
        return Buffer.isBuffer(e) ? e.toString("utf16le", r, t).replace(Xt, "") : uc(e, r, t)
    } : uc,
    dc = function(e, r, t) {
        for (var a = [], i = r; i < r + t; ++i) a.push(("0" + e[i].toString(16)).slice(-2));
        return a.join("")
    },
    wl = Ue ? function(e, r, t) {
        return Buffer.isBuffer(e) ? e.toString("hex", r, r + t) : dc(e, r, t)
    } : dc,
    hc = function(e, r, t) {
        for (var a = [], i = r; i < t; i++) a.push(String.fromCharCode(Za(e, i)));
        return a.join("")
    },
    ui = Ue ? function(r, t, a) {
        return Buffer.isBuffer(r) ? r.toString("utf8", t, a) : hc(r, t, a)
    } : hc,
    Sl = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? ui(e, r + 4, r + 4 + t - 1) : ""
    },
    a0 = Sl,
    El = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? ui(e, r + 4, r + 4 + t - 1) : ""
    },
    i0 = El,
    Cl = function(e, r) {
        var t = 2 * Rt(e, r);
        return t > 0 ? ui(e, r + 4, r + 4 + t - 1) : ""
    },
    n0 = Cl,
    Tl = function(r, t) {
        var a = Rt(r, t);
        return a > 0 ? Zn(r, t + 4, t + 4 + a) : ""
    },
    s0 = Tl,
    yl = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? ui(e, r + 4, r + 4 + t) : ""
    },
    o0 = yl,
    kl = function(e, r) {
        return $d(e, r)
    },
    Bn = kl,
    c0 = function(r) {
        return Array.isArray(r) || typeof Uint8Array < "u" && r instanceof Uint8Array
    };
Ue && (a0 = function(r, t) {
    if (!Buffer.isBuffer(r)) return Sl(r, t);
    var a = r.readUInt32LE(t);
    return a > 0 ? r.toString("utf8", t + 4, t + 4 + a - 1) : ""
}, i0 = function(r, t) {
    if (!Buffer.isBuffer(r)) return El(r, t);
    var a = r.readUInt32LE(t);
    return a > 0 ? r.toString("utf8", t + 4, t + 4 + a - 1) : ""
}, n0 = function(r, t) {
    if (!Buffer.isBuffer(r)) return Cl(r, t);
    var a = 2 * r.readUInt32LE(t);
    return r.toString("utf16le", t + 4, t + 4 + a - 1)
}, s0 = function(r, t) {
    if (!Buffer.isBuffer(r)) return Tl(r, t);
    var a = r.readUInt32LE(t);
    return r.toString("utf16le", t + 4, t + 4 + a)
}, o0 = function(r, t) {
    if (!Buffer.isBuffer(r)) return yl(r, t);
    var a = r.readUInt32LE(t);
    return r.toString("utf8", t + 4, t + 4 + a)
}, Bn = function(r, t) {
    return Buffer.isBuffer(r) ? r.readDoubleLE(t) : kl(r, t)
}, c0 = function(r) {
    return Buffer.isBuffer(r) || Array.isArray(r) || typeof Uint8Array < "u" && r instanceof Uint8Array
});

function Kd() {
    Zn = function(e, r, t) {
        return Ye.utils.decode(1200, e.slice(r, t)).replace(Xt, "")
    }, ui = function(e, r, t) {
        return Ye.utils.decode(65001, e.slice(r, t))
    }, a0 = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? Ye.utils.decode(ni, e.slice(r + 4, r + 4 + t - 1)) : ""
    }, i0 = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? Ye.utils.decode(zr, e.slice(r + 4, r + 4 + t - 1)) : ""
    }, n0 = function(e, r) {
        var t = 2 * Rt(e, r);
        return t > 0 ? Ye.utils.decode(1200, e.slice(r + 4, r + 4 + t - 1)) : ""
    }, s0 = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? Ye.utils.decode(1200, e.slice(r + 4, r + 4 + t)) : ""
    }, o0 = function(e, r) {
        var t = Rt(e, r);
        return t > 0 ? Ye.utils.decode(65001, e.slice(r + 4, r + 4 + t)) : ""
    }
}
typeof Ye < "u" && Kd();
var Za = function(e, r) {
        return e[r]
    },
    Jr = function(e, r) {
        return e[r + 1] * 256 + e[r]
    },
    Jd = function(e, r) {
        var t = e[r + 1] * 256 + e[r];
        return t < 32768 ? t : (65535 - t + 1) * -1
    },
    Rt = function(e, r) {
        return e[r + 3] * (1 << 24) + (e[r + 2] << 16) + (e[r + 1] << 8) + e[r]
    },
    ya = function(e, r) {
        return e[r + 3] << 24 | e[r + 2] << 16 | e[r + 1] << 8 | e[r]
    },
    Zd = function(e, r) {
        return e[r] << 24 | e[r + 1] << 16 | e[r + 2] << 8 | e[r + 3]
    };

function Mi(e, r) {
    var t = "",
        a, i, n = [],
        s, o, c, l;
    switch (r) {
        case "dbcs":
            if (l = this.l, Ue && Buffer.isBuffer(this)) t = this.slice(this.l, this.l + 2 * e).toString("utf16le");
            else
                for (c = 0; c < e; ++c) t += String.fromCharCode(Jr(this, l)), l += 2;
            e *= 2;
            break;
        case "utf8":
            t = ui(this, this.l, this.l + e);
            break;
        case "utf16le":
            e *= 2, t = Zn(this, this.l, this.l + e);
            break;
        case "wstr":
            if (typeof Ye < "u") t = Ye.utils.decode(zr, this.slice(this.l, this.l + 2 * e));
            else return Mi.call(this, e, "dbcs");
            e = 2 * e;
            break;
        case "lpstr-ansi":
            t = a0(this, this.l), e = 4 + Rt(this, this.l);
            break;
        case "lpstr-cp":
            t = i0(this, this.l), e = 4 + Rt(this, this.l);
            break;
        case "lpwstr":
            t = n0(this, this.l), e = 4 + 2 * Rt(this, this.l);
            break;
        case "lpp4":
            e = 4 + Rt(this, this.l), t = s0(this, this.l), e & 2 && (e += 2);
            break;
        case "8lpp4":
            e = 4 + Rt(this, this.l), t = o0(this, this.l), e & 3 && (e += 4 - (e & 3));
            break;
        case "cstr":
            for (e = 0, t = "";
                (s = Za(this, this.l + e++)) !== 0;) n.push(Cn(s));
            t = n.join("");
            break;
        case "_wstr":
            for (e = 0, t = "";
                (s = Jr(this, this.l + e)) !== 0;) n.push(Cn(s)), e += 2;
            e += 2, t = n.join("");
            break;
        case "dbcs-cont":
            for (t = "", l = this.l, c = 0; c < e; ++c) {
                if (this.lens && this.lens.indexOf(l) !== -1) return s = Za(this, l), this.l = l + 1, o = Mi.call(this, e - c, s ? "dbcs-cont" : "sbcs-cont"), n.join("") + o;
                n.push(Cn(Jr(this, l))), l += 2
            }
            t = n.join(""), e *= 2;
            break;
        case "cpstr":
            if (typeof Ye < "u") {
                t = Ye.utils.decode(zr, this.slice(this.l, this.l + e));
                break
            }
        case "sbcs-cont":
            for (t = "", l = this.l, c = 0; c != e; ++c) {
                if (this.lens && this.lens.indexOf(l) !== -1) return s = Za(this, l), this.l = l + 1, o = Mi.call(this, e - c, s ? "dbcs-cont" : "sbcs-cont"), n.join("") + o;
                n.push(Cn(Za(this, l))), l += 1
            }
            t = n.join("");
            break;
        default:
            switch (e) {
                case 1:
                    return a = Za(this, this.l), this.l++, a;
                case 2:
                    return a = (r === "i" ? Jd : Jr)(this, this.l), this.l += 2, a;
                case 4:
                case -4:
                    return r === "i" || (this[this.l + 3] & 128) === 0 ? (a = (e > 0 ? ya : Zd)(this, this.l), this.l += 4, a) : (i = Rt(this, this.l), this.l += 4, i);
                case 8:
                case -8:
                    if (r === "f") return e == 8 ? i = Bn(this, this.l) : i = Bn([this[this.l + 7], this[this.l + 6], this[this.l + 5], this[this.l + 4], this[this.l + 3], this[this.l + 2], this[this.l + 1], this[this.l + 0]], 0), this.l += 8, i;
                    e = 8;
                case 16:
                    t = wl(this, this.l, e);
                    break
            }
    }
    return this.l += e, t
}
var Qd = function(e, r, t) {
        e[t] = r & 255, e[t + 1] = r >>> 8 & 255, e[t + 2] = r >>> 16 & 255, e[t + 3] = r >>> 24 & 255
    },
    eh = function(e, r, t) {
        e[t] = r & 255, e[t + 1] = r >> 8 & 255, e[t + 2] = r >> 16 & 255, e[t + 3] = r >> 24 & 255
    },
    th = function(e, r, t) {
        e[t] = r & 255, e[t + 1] = r >>> 8 & 255
    };

function rh(e, r, t) {
    var a = 0,
        i = 0;
    if (t === "dbcs") {
        for (i = 0; i != r.length; ++i) th(this, r.charCodeAt(i), this.l + 2 * i);
        a = 2 * r.length
    } else if (t === "sbcs") {
        if (typeof Ye < "u" && ni == 874)
            for (i = 0; i != r.length; ++i) {
                var n = Ye.utils.encode(ni, r.charAt(i));
                this[this.l + i] = n[0]
            } else
                for (r = r.replace(/[^\x00-\x7F]/g, "_"), i = 0; i != r.length; ++i) this[this.l + i] = r.charCodeAt(i) & 255;
        a = r.length
    } else if (t === "hex") {
        for (; i < e; ++i) this[this.l++] = parseInt(r.slice(2 * i, 2 * i + 2), 16) || 0;
        return this
    } else if (t === "utf16le") {
        var s = Math.min(this.l + e, this.length);
        for (i = 0; i < Math.min(r.length, e); ++i) {
            var o = r.charCodeAt(i);
            this[this.l++] = o & 255, this[this.l++] = o >> 8
        }
        for (; this.l < s;) this[this.l++] = 0;
        return this
    } else switch (e) {
        case 1:
            a = 1, this[this.l] = r & 255;
            break;
        case 2:
            a = 2, this[this.l] = r & 255, r >>>= 8, this[this.l + 1] = r & 255;
            break;
        case 3:
            a = 3, this[this.l] = r & 255, r >>>= 8, this[this.l + 1] = r & 255, r >>>= 8, this[this.l + 2] = r & 255;
            break;
        case 4:
            a = 4, Qd(this, r, this.l);
            break;
        case 8:
            if (a = 8, t === "f") {
                Yd(this, r, this.l);
                break
            }
        case 16:
            break;
        case -4:
            a = 4, eh(this, r, this.l);
            break
    }
    return this.l += a, this
}

function Fl(e, r) {
    var t = wl(this, this.l, e.length >> 1);
    if (t !== e) throw new Error(r + "Expected " + e + " saw " + t);
    this.l += e.length >> 1
}

function Bt(e, r) {
    e.l = r, e.read_shift = Mi, e.chk = Fl, e.write_shift = rh
}

function jt(e, r) {
    e.l += r
}

function Y(e) {
    var r = pa(e);
    return Bt(r, 0), r
}

function aa(e, r, t) {
    if (e) {
        var a, i, n;
        Bt(e, e.l || 0);
        for (var s = e.length, o = 0, c = 0; e.l < s;) {
            o = e.read_shift(1), o & 128 && (o = (o & 127) + ((e.read_shift(1) & 127) << 7));
            var l = Ki[o] || Ki[65535];
            for (a = e.read_shift(1), n = a & 127, i = 1; i < 4 && a & 128; ++i) n += ((a = e.read_shift(1)) & 127) << 7 * i;
            c = e.l + n;
            var f = l.f && l.f(e, n, t);
            if (e.l = c, r(f, l, o)) return
        }
    }
}

function sr() {
    var e = [],
        r = Ue ? 256 : 2048,
        t = function(l) {
            var f = Y(l);
            return Bt(f, 0), f
        },
        a = t(r),
        i = function() {
            a && (a.length > a.l && (a = a.slice(0, a.l), a.l = a.length), a.length > 0 && e.push(a), a = null)
        },
        n = function(l) {
            return a && l < a.length - a.l ? a : (i(), a = t(Math.max(l + 1, r)))
        },
        s = function() {
            return i(), Pt(e)
        },
        o = function(l) {
            i(), a = l, a.l == null && (a.l = a.length), n(r)
        };
    return {
        next: n,
        push: o,
        end: s,
        _bufs: e
    }
}

function ee(e, r, t, a) {
    var i = +r,
        n;
    if (!isNaN(i)) {
        a || (a = Ki[i].p || (t || []).length || 0), n = 1 + (i >= 128 ? 1 : 0) + 1, a >= 128 && ++n, a >= 16384 && ++n, a >= 2097152 && ++n;
        var s = e.next(n);
        i <= 127 ? s.write_shift(1, i) : (s.write_shift(1, (i & 127) + 128), s.write_shift(1, i >> 7));
        for (var o = 0; o != 4; ++o)
            if (a >= 128) s.write_shift(1, (a & 127) + 128), a >>= 7;
            else {
                s.write_shift(1, a);
                break
            }
        a > 0 && c0(t) && e.push(t)
    }
}

function Oi(e, r, t) {
    var a = ut(e);
    if (r.s ? (a.cRel && (a.c += r.s.c), a.rRel && (a.r += r.s.r)) : (a.cRel && (a.c += r.c), a.rRel && (a.r += r.r)), !t || t.biff < 12) {
        for (; a.c >= 256;) a.c -= 256;
        for (; a.r >= 65536;) a.r -= 65536
    }
    return a
}

function pc(e, r, t) {
    var a = ut(e);
    return a.s = Oi(a.s, r.s, t), a.e = Oi(a.e, r.s, t), a
}

function Di(e, r) {
    if (e.cRel && e.c < 0)
        for (e = ut(e); e.c < 0;) e.c += r > 8 ? 16384 : 256;
    if (e.rRel && e.r < 0)
        for (e = ut(e); e.r < 0;) e.r += r > 8 ? 1048576 : r > 5 ? 65536 : 16384;
    var t = Me(e);
    return !e.cRel && e.cRel != null && (t = nh(t)), !e.rRel && e.rRel != null && (t = ah(t)), t
}

function Ss(e, r) {
    return e.s.r == 0 && !e.s.rRel && e.e.r == (r.biff >= 12 ? 1048575 : r.biff >= 8 ? 65536 : 16384) && !e.e.rRel ? (e.s.cRel ? "" : "$") + ht(e.s.c) + ":" + (e.e.cRel ? "" : "$") + ht(e.e.c) : e.s.c == 0 && !e.s.cRel && e.e.c == (r.biff >= 12 ? 16383 : 255) && !e.e.cRel ? (e.s.rRel ? "" : "$") + Tt(e.s.r) + ":" + (e.e.rRel ? "" : "$") + Tt(e.e.r) : Di(e.s, r.biff) + ":" + Di(e.e, r.biff)
}

function l0(e) {
    return parseInt(ih(e), 10) - 1
}

function Tt(e) {
    return "" + (e + 1)
}

function ah(e) {
    return e.replace(/([A-Z]|^)(\d+)$/, "$1$$$2")
}

function ih(e) {
    return e.replace(/\$(\d+)$/, "$1")
}

function f0(e) {
    for (var r = sh(e), t = 0, a = 0; a !== r.length; ++a) t = 26 * t + r.charCodeAt(a) - 64;
    return t - 1
}

function ht(e) {
    if (e < 0) throw new Error("invalid column " + e);
    var r = "";
    for (++e; e; e = Math.floor((e - 1) / 26)) r = String.fromCharCode((e - 1) % 26 + 65) + r;
    return r
}

function nh(e) {
    return e.replace(/^([A-Z])/, "$$$1")
}

function sh(e) {
    return e.replace(/^\$([A-Z])/, "$1")
}

function oh(e) {
    return e.replace(/(\$?[A-Z]*)(\$?\d*)/, "$1,$2").split(",")
}

function pt(e) {
    for (var r = 0, t = 0, a = 0; a < e.length; ++a) {
        var i = e.charCodeAt(a);
        i >= 48 && i <= 57 ? r = 10 * r + (i - 48) : i >= 65 && i <= 90 && (t = 26 * t + (i - 64))
    }
    return {
        c: t - 1,
        r: r - 1
    }
}

function Me(e) {
    for (var r = e.c + 1, t = ""; r; r = (r - 1) / 26 | 0) t = String.fromCharCode((r - 1) % 26 + 65) + t;
    return t + (e.r + 1)
}

function or(e) {
    var r = e.indexOf(":");
    return r == -1 ? {
        s: pt(e),
        e: pt(e)
    } : {
        s: pt(e.slice(0, r)),
        e: pt(e.slice(r + 1))
    }
}

function Ne(e, r) {
    return typeof r > "u" || typeof r == "number" ? Ne(e.s, e.e) : (typeof e != "string" && (e = Me(e)), typeof r != "string" && (r = Me(r)), e == r ? e : e + ":" + r)
}

function Xe(e) {
    var r = {
            s: {
                c: 0,
                r: 0
            },
            e: {
                c: 0,
                r: 0
            }
        },
        t = 0,
        a = 0,
        i = 0,
        n = e.length;
    for (t = 0; a < n && !((i = e.charCodeAt(a) - 64) < 1 || i > 26); ++a) t = 26 * t + i;
    for (r.s.c = --t, t = 0; a < n && !((i = e.charCodeAt(a) - 48) < 0 || i > 9); ++a) t = 10 * t + i;
    if (r.s.r = --t, a === n || i != 10) return r.e.c = r.s.c, r.e.r = r.s.r, r;
    for (++a, t = 0; a != n && !((i = e.charCodeAt(a) - 64) < 1 || i > 26); ++a) t = 26 * t + i;
    for (r.e.c = --t, t = 0; a != n && !((i = e.charCodeAt(a) - 48) < 0 || i > 9); ++a) t = 10 * t + i;
    return r.e.r = --t, r
}

function mc(e, r) {
    var t = e.t == "d" && r instanceof Date;
    if (e.z != null) try {
        return e.w = Ir(e.z, t ? Ot(r) : r)
    } catch (a) {}
    try {
        return e.w = Ir((e.XF || {}).numFmtId || (t ? 14 : 0), t ? Ot(r) : r)
    } catch (a) {
        return "" + r
    }
}

function ta(e, r, t) {
    return e == null || e.t == null || e.t == "z" ? "" : e.w !== void 0 ? e.w : (e.t == "d" && !e.z && t && t.dateNF && (e.z = t.dateNF), e.t == "e" ? ia[e.v] || e.v : r == null ? mc(e, e.v) : mc(e, r))
}

function va(e, r) {
    var t = r && r.sheet ? r.sheet : "Sheet1",
        a = {};
    return a[t] = e, {
        SheetNames: [t],
        Sheets: a
    }
}

function Al(e, r, t) {
    var a = t || {},
        i = e ? Array.isArray(e) : a.dense;
    _t != null && i == null && (i = _t);
    var n = e || (i ? [] : {}),
        s = 0,
        o = 0;
    if (n && a.origin != null) {
        if (typeof a.origin == "number") s = a.origin;
        else {
            var c = typeof a.origin == "string" ? pt(a.origin) : a.origin;
            s = c.r, o = c.c
        }
        n["!ref"] || (n["!ref"] = "A1:A1")
    }
    var l = {
        s: {
            c: 1e7,
            r: 1e7
        },
        e: {
            c: 0,
            r: 0
        }
    };
    if (n["!ref"]) {
        var f = Xe(n["!ref"]);
        l.s.c = f.s.c, l.s.r = f.s.r, l.e.c = Math.max(l.e.c, f.e.c), l.e.r = Math.max(l.e.r, f.e.r), s == -1 && (l.e.r = s = f.e.r + 1)
    }
    for (var u = 0; u != r.length; ++u)
        if (r[u]) {
            if (!Array.isArray(r[u])) throw new Error("aoa_to_sheet expects an array of arrays");
            for (var h = 0; h != r[u].length; ++h)
                if (!(typeof r[u][h] > "u")) {
                    var p = {
                            v: r[u][h]
                        },
                        m = s + u,
                        d = o + h;
                    if (l.s.r > m && (l.s.r = m), l.s.c > d && (l.s.c = d), l.e.r < m && (l.e.r = m), l.e.c < d && (l.e.c = d), r[u][h] && typeof r[u][h] == "object" && !Array.isArray(r[u][h]) && !(r[u][h] instanceof Date)) p = r[u][h];
                    else if (Array.isArray(p.v) && (p.f = r[u][h][1], p.v = p.v[0]), p.v === null)
                        if (p.f) p.t = "n";
                        else if (a.nullError) p.t = "e", p.v = 0;
                    else if (a.sheetStubs) p.t = "z";
                    else continue;
                    else typeof p.v == "number" ? p.t = "n" : typeof p.v == "boolean" ? p.t = "b" : p.v instanceof Date ? (p.z = a.dateNF || Ie[14], a.cellDates ? (p.t = "d", p.w = Ir(p.z, Ot(p.v))) : (p.t = "n", p.v = Ot(p.v), p.w = Ir(p.z, p.v))) : p.t = "s";
                    if (i) n[m] || (n[m] = []), n[m][d] && n[m][d].z && (p.z = n[m][d].z), n[m][d] = p;
                    else {
                        var x = Me({
                            c: d,
                            r: m
                        });
                        n[x] && n[x].z && (p.z = n[x].z), n[x] = p
                    }
                }
        }
    return l.s.c < 1e7 && (n["!ref"] = Ne(l)), n
}

function di(e, r) {
    return Al(null, e, r)
}

function ch(e) {
    return e.read_shift(4, "i")
}

function Lr(e, r) {
    return r || (r = Y(4)), r.write_shift(4, e), r
}

function qt(e) {
    var r = e.read_shift(4);
    return r === 0 ? "" : e.read_shift(r, "dbcs")
}

function Nt(e, r) {
    var t = !1;
    return r == null && (t = !0, r = Y(4 + 2 * e.length)), r.write_shift(4, e.length), e.length > 0 && r.write_shift(0, e, "dbcs"), t ? r.slice(0, r.l) : r
}

function lh(e) {
    return {
        ich: e.read_shift(2),
        ifnt: e.read_shift(2)
    }
}

function fh(e, r) {
    return r || (r = Y(4)), r.write_shift(2, e.ich || 0), r.write_shift(2, e.ifnt || 0), r
}

function u0(e, r) {
    var t = e.l,
        a = e.read_shift(1),
        i = qt(e),
        n = [],
        s = {
            t: i,
            h: i
        };
    if ((a & 1) !== 0) {
        for (var o = e.read_shift(4), c = 0; c != o; ++c) n.push(lh(e));
        s.r = n
    } else s.r = [{
        ich: 0,
        ifnt: 0
    }];
    return e.l = t + r, s
}

function uh(e, r) {
    var t = !1;
    return r == null && (t = !0, r = Y(15 + 4 * e.t.length)), r.write_shift(1, 0), Nt(e.t, r), t ? r.slice(0, r.l) : r
}
var dh = u0;

function hh(e, r) {
    var t = !1;
    return r == null && (t = !0, r = Y(23 + 4 * e.t.length)), r.write_shift(1, 1), Nt(e.t, r), r.write_shift(4, 1), fh({
        ich: 0,
        ifnt: 0
    }, r), t ? r.slice(0, r.l) : r
}

function Mr(e) {
    var r = e.read_shift(4),
        t = e.read_shift(2);
    return t += e.read_shift(1) << 16, e.l++, {
        c: r,
        iStyleRef: t
    }
}

function Ba(e, r) {
    return r == null && (r = Y(8)), r.write_shift(-4, e.c), r.write_shift(3, e.iStyleRef || e.s), r.write_shift(1, 0), r
}

function Ua(e) {
    var r = e.read_shift(2);
    return r += e.read_shift(1) << 16, e.l++, {
        c: -1,
        iStyleRef: r
    }
}

function Va(e, r) {
    return r == null && (r = Y(4)), r.write_shift(3, e.iStyleRef || e.s), r.write_shift(1, 0), r
}
var ph = qt,
    bl = Nt;

function d0(e) {
    var r = e.read_shift(4);
    return r === 0 || r === 4294967295 ? "" : e.read_shift(r, "dbcs")
}

function Un(e, r) {
    var t = !1;
    return r == null && (t = !0, r = Y(127)), r.write_shift(4, e.length > 0 ? e.length : 4294967295), e.length > 0 && r.write_shift(0, e, "dbcs"), t ? r.slice(0, r.l) : r
}
var mh = qt,
    Ps = d0,
    h0 = Un;

function p0(e) {
    var r = e.slice(e.l, e.l + 4),
        t = r[0] & 1,
        a = r[0] & 2;
    e.l += 4;
    var i = a === 0 ? Bn([0, 0, 0, 0, r[0] & 252, r[1], r[2], r[3]], 0) : ya(r, 0) >> 2;
    return t ? i / 100 : i
}

function Il(e, r) {
    r == null && (r = Y(4));
    var t = 0,
        a = 0,
        i = e * 100;
    if (e == (e | 0) && e >= -(1 << 29) && e < 1 << 29 ? a = 1 : i == (i | 0) && i >= -(1 << 29) && i < 1 << 29 && (a = 1, t = 1), a) r.write_shift(-4, ((t ? i : e) << 2) + (t + 2));
    else throw new Error("unsupported RkNumber " + e)
}

function Ml(e) {
    var r = {
        s: {},
        e: {}
    };
    return r.s.r = e.read_shift(4), r.e.r = e.read_shift(4), r.s.c = e.read_shift(4), r.e.c = e.read_shift(4), r
}

function xh(e, r) {
    return r || (r = Y(16)), r.write_shift(4, e.s.r), r.write_shift(4, e.e.r), r.write_shift(4, e.s.c), r.write_shift(4, e.e.c), r
}
var Wa = Ml,
    hi = xh;

function zt(e) {
    if (e.length - e.l < 8) throw "XLS Xnum Buffer underflow";
    return e.read_shift(8, "f")
}

function Da(e, r) {
    return (r || Y(8)).write_shift(8, e, "f")
}

function gh(e) {
    var r = {},
        t = e.read_shift(1),
        a = t >>> 1,
        i = e.read_shift(1),
        n = e.read_shift(2, "i"),
        s = e.read_shift(1),
        o = e.read_shift(1),
        c = e.read_shift(1);
    switch (e.l++, a) {
        case 0:
            r.auto = 1;
            break;
        case 1:
            r.index = i;
            var l = Fa[i];
            l && (r.rgb = qi(l));
            break;
        case 2:
            r.rgb = qi([s, o, c]);
            break;
        case 3:
            r.theme = i;
            break
    }
    return n != 0 && (r.tint = n > 0 ? n / 32767 : n / 32768), r
}

function Vn(e, r) {
    if (r || (r = Y(8)), !e || e.auto) return r.write_shift(4, 0), r.write_shift(4, 0), r;
    e.index != null ? (r.write_shift(1, 2), r.write_shift(1, e.index)) : e.theme != null ? (r.write_shift(1, 6), r.write_shift(1, e.theme)) : (r.write_shift(1, 5), r.write_shift(1, 0));
    var t = e.tint || 0;
    if (t > 0 ? t *= 32767 : t < 0 && (t *= 32768), r.write_shift(2, t), !e.rgb || e.theme != null) r.write_shift(2, 0), r.write_shift(1, 0), r.write_shift(1, 0);
    else {
        var a = e.rgb || "FFFFFF";
        typeof a == "number" && (a = ("000000" + a.toString(16)).slice(-6)), r.write_shift(1, parseInt(a.slice(0, 2), 16)), r.write_shift(1, parseInt(a.slice(2, 4), 16)), r.write_shift(1, parseInt(a.slice(4, 6), 16)), r.write_shift(1, 255)
    }
    return r
}

function _h(e) {
    var r = e.read_shift(1);
    e.l++;
    var t = {
        fBold: r & 1,
        fItalic: r & 2,
        fUnderline: r & 4,
        fStrikeout: r & 8,
        fOutline: r & 16,
        fShadow: r & 32,
        fCondense: r & 64,
        fExtend: r & 128
    };
    return t
}

function vh(e, r) {
    r || (r = Y(2));
    var t = (e.italic ? 2 : 0) | (e.strike ? 8 : 0) | (e.outline ? 16 : 0) | (e.shadow ? 32 : 0) | (e.condense ? 64 : 0) | (e.extend ? 128 : 0);
    return r.write_shift(1, t), r.write_shift(1, 0), r
}

function Ol(e, r) {
    var t = {
            2: "BITMAP",
            3: "METAFILEPICT",
            8: "DIB",
            14: "ENHMETAFILE"
        },
        a = e.read_shift(4);
    switch (a) {
        case 0:
            return "";
        case 4294967295:
        case 4294967294:
            return t[e.read_shift(4)] || ""
    }
    if (a > 400) throw new Error("Unsupported Clipboard: " + a.toString(16));
    return e.l -= 4, e.read_shift(0, r == 1 ? "lpstr" : "lpwstr")
}

function wh(e) {
    return Ol(e, 1)
}

function Sh(e) {
    return Ol(e, 2)
}
var m0 = 2,
    nr = 3,
    yn = 11,
    xc = 12,
    Wn = 19;
var kn = 64,
    Eh = 65,
    Ch = 71;
var Th = 4108,
    yh = 4126,
    Dt = 80,
    Dl = 81,
    kh = [Dt, Dl],
    Ns = {
        1: {
            n: "CodePage",
            t: m0
        },
        2: {
            n: "Category",
            t: Dt
        },
        3: {
            n: "PresentationFormat",
            t: Dt
        },
        4: {
            n: "ByteCount",
            t: nr
        },
        5: {
            n: "LineCount",
            t: nr
        },
        6: {
            n: "ParagraphCount",
            t: nr
        },
        7: {
            n: "SlideCount",
            t: nr
        },
        8: {
            n: "NoteCount",
            t: nr
        },
        9: {
            n: "HiddenCount",
            t: nr
        },
        10: {
            n: "MultimediaClipCount",
            t: nr
        },
        11: {
            n: "ScaleCrop",
            t: yn
        },
        12: {
            n: "HeadingPairs",
            t: Th
        },
        13: {
            n: "TitlesOfParts",
            t: yh
        },
        14: {
            n: "Manager",
            t: Dt
        },
        15: {
            n: "Company",
            t: Dt
        },
        16: {
            n: "LinksUpToDate",
            t: yn
        },
        17: {
            n: "CharacterCount",
            t: nr
        },
        19: {
            n: "SharedDoc",
            t: yn
        },
        22: {
            n: "HyperlinksChanged",
            t: yn
        },
        23: {
            n: "AppVersion",
            t: nr,
            p: "version"
        },
        24: {
            n: "DigSig",
            t: Eh
        },
        26: {
            n: "ContentType",
            t: Dt
        },
        27: {
            n: "ContentStatus",
            t: Dt
        },
        28: {
            n: "Language",
            t: Dt
        },
        29: {
            n: "Version",
            t: Dt
        },
        255: {},
        2147483648: {
            n: "Locale",
            t: Wn
        },
        2147483651: {
            n: "Behavior",
            t: Wn
        },
        1919054434: {}
    },
    Ls = {
        1: {
            n: "CodePage",
            t: m0
        },
        2: {
            n: "Title",
            t: Dt
        },
        3: {
            n: "Subject",
            t: Dt
        },
        4: {
            n: "Author",
            t: Dt
        },
        5: {
            n: "Keywords",
            t: Dt
        },
        6: {
            n: "Comments",
            t: Dt
        },
        7: {
            n: "Template",
            t: Dt
        },
        8: {
            n: "LastAuthor",
            t: Dt
        },
        9: {
            n: "RevNumber",
            t: Dt
        },
        10: {
            n: "EditTime",
            t: kn
        },
        11: {
            n: "LastPrinted",
            t: kn
        },
        12: {
            n: "CreatedDate",
            t: kn
        },
        13: {
            n: "ModifiedDate",
            t: kn
        },
        14: {
            n: "PageCount",
            t: nr
        },
        15: {
            n: "WordCount",
            t: nr
        },
        16: {
            n: "CharCount",
            t: nr
        },
        17: {
            n: "Thumbnail",
            t: Ch
        },
        18: {
            n: "Application",
            t: Dt
        },
        19: {
            n: "DocSecurity",
            t: nr
        },
        255: {},
        2147483648: {
            n: "Locale",
            t: Wn
        },
        2147483651: {
            n: "Behavior",
            t: Wn
        },
        1919054434: {}
    },
    gc = {
        1: "US",
        2: "CA",
        3: "",
        7: "RU",
        20: "EG",
        30: "GR",
        31: "NL",
        32: "BE",
        33: "FR",
        34: "ES",
        36: "HU",
        39: "IT",
        41: "CH",
        43: "AT",
        44: "GB",
        45: "DK",
        46: "SE",
        47: "NO",
        48: "PL",
        49: "DE",
        52: "MX",
        55: "BR",
        61: "AU",
        64: "NZ",
        66: "TH",
        81: "JP",
        82: "KR",
        84: "VN",
        86: "CN",
        90: "TR",
        105: "JS",
        213: "DZ",
        216: "MA",
        218: "LY",
        351: "PT",
        354: "IS",
        358: "FI",
        420: "CZ",
        886: "TW",
        961: "LB",
        962: "JO",
        963: "SY",
        964: "IQ",
        965: "KW",
        966: "SA",
        971: "AE",
        972: "IL",
        974: "QA",
        981: "IR",
        65535: "US"
    },
    Fh = [null, "solid", "mediumGray", "darkGray", "lightGray", "darkHorizontal", "darkVertical", "darkDown", "darkUp", "darkGrid", "darkTrellis", "lightHorizontal", "lightVertical", "lightDown", "lightUp", "lightGrid", "lightTrellis", "gray125", "gray0625"];

function Ah(e) {
    return e.map(function(r) {
        return [r >> 16 & 255, r >> 8 & 255, r & 255]
    })
}
var bh = Ah([0, 16777215, 16711680, 65280, 255, 16776960, 16711935, 65535, 0, 16777215, 16711680, 65280, 255, 16776960, 16711935, 65535, 8388608, 32768, 128, 8421376, 8388736, 32896, 12632256, 8421504, 10066431, 10040166, 16777164, 13434879, 6684774, 16744576, 26316, 13421823, 128, 16711935, 16776960, 65535, 8388736, 8388608, 32896, 255, 52479, 13434879, 13434828, 16777113, 10079487, 16751052, 13408767, 16764057, 3368703, 3394764, 10079232, 16763904, 16750848, 16737792, 6710937, 9868950, 13158, 3381606, 13056, 3355392, 10040064, 10040166, 3355545, 3355443, 16777215, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
    Fa = ut(bh),
    ia = {
        0: "#NULL!",
        7: "#DIV/0!",
        15: "#VALUE!",
        23: "#REF!",
        29: "#NAME?",
        36: "#NUM!",
        42: "#N/A",
        43: "#GETTING_DATA",
        255: "#WTF?"
    },
    Rl = {
        "#NULL!": 0,
        "#DIV/0!": 7,
        "#VALUE!": 15,
        "#REF!": 23,
        "#NAME?": 29,
        "#NUM!": 36,
        "#N/A": 42,
        "#GETTING_DATA": 43,
        "#WTF?": 255
    },
    Bs = {
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": "workbooks",
        "application/vnd.ms-excel.sheet.macroEnabled.main+xml": "workbooks",
        "application/vnd.ms-excel.sheet.binary.macroEnabled.main": "workbooks",
        "application/vnd.ms-excel.addin.macroEnabled.main+xml": "workbooks",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": "workbooks",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": "sheets",
        "application/vnd.ms-excel.worksheet": "sheets",
        "application/vnd.ms-excel.binIndexWs": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": "charts",
        "application/vnd.ms-excel.chartsheet": "charts",
        "application/vnd.ms-excel.macrosheet+xml": "macros",
        "application/vnd.ms-excel.macrosheet": "macros",
        "application/vnd.ms-excel.intlmacrosheet": "TODO",
        "application/vnd.ms-excel.binIndexMs": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": "dialogs",
        "application/vnd.ms-excel.dialogsheet": "dialogs",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml": "strs",
        "application/vnd.ms-excel.sharedStrings": "strs",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": "styles",
        "application/vnd.ms-excel.styles": "styles",
        "application/vnd.openxmlformats-package.core-properties+xml": "coreprops",
        "application/vnd.openxmlformats-officedocument.custom-properties+xml": "custprops",
        "application/vnd.openxmlformats-officedocument.extended-properties+xml": "extprops",
        "application/vnd.openxmlformats-officedocument.customXmlProperties+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.customProperty": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": "comments",
        "application/vnd.ms-excel.comments": "comments",
        "application/vnd.ms-excel.threadedcomments+xml": "threadedcomments",
        "application/vnd.ms-excel.person+xml": "people",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml": "metadata",
        "application/vnd.ms-excel.sheetMetadata": "metadata",
        "application/vnd.ms-excel.pivotTable": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotTable+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": "TODO",
        "application/vnd.ms-office.chartcolorstyle+xml": "TODO",
        "application/vnd.ms-office.chartstyle+xml": "TODO",
        "application/vnd.ms-office.chartex+xml": "TODO",
        "application/vnd.ms-excel.calcChain": "calcchains",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml": "calcchains",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings": "TODO",
        "application/vnd.ms-office.activeX": "TODO",
        "application/vnd.ms-office.activeX+xml": "TODO",
        "application/vnd.ms-excel.attachedToolbars": "TODO",
        "application/vnd.ms-excel.connections": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": "TODO",
        "application/vnd.ms-excel.externalLink": "links",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.externalLink+xml": "links",
        "application/vnd.ms-excel.pivotCacheDefinition": "TODO",
        "application/vnd.ms-excel.pivotCacheRecords": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheDefinition+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheRecords+xml": "TODO",
        "application/vnd.ms-excel.queryTable": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.queryTable+xml": "TODO",
        "application/vnd.ms-excel.userNames": "TODO",
        "application/vnd.ms-excel.revisionHeaders": "TODO",
        "application/vnd.ms-excel.revisionLog": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionHeaders+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionLog+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.userNames+xml": "TODO",
        "application/vnd.ms-excel.tableSingleCells": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.tableSingleCells+xml": "TODO",
        "application/vnd.ms-excel.slicer": "TODO",
        "application/vnd.ms-excel.slicerCache": "TODO",
        "application/vnd.ms-excel.slicer+xml": "TODO",
        "application/vnd.ms-excel.slicerCache+xml": "TODO",
        "application/vnd.ms-excel.wsSortMap": "TODO",
        "application/vnd.ms-excel.table": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.theme+xml": "themes",
        "application/vnd.openxmlformats-officedocument.themeOverride+xml": "TODO",
        "application/vnd.ms-excel.Timeline+xml": "TODO",
        "application/vnd.ms-excel.TimelineCache+xml": "TODO",
        "application/vnd.ms-office.vbaProject": "vba",
        "application/vnd.ms-office.vbaProjectSignature": "TODO",
        "application/vnd.ms-office.volatileDependencies": "TODO",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.volatileDependencies+xml": "TODO",
        "application/vnd.ms-excel.controlproperties+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.model+data": "TODO",
        "application/vnd.ms-excel.Survey+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.drawing+xml": "drawings",
        "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.drawingml.diagramColors+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.drawingml.diagramLayout+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.drawingml.diagramStyle+xml": "TODO",
        "application/vnd.openxmlformats-officedocument.vmlDrawing": "TODO",
        "application/vnd.openxmlformats-package.relationships+xml": "rels",
        "application/vnd.openxmlformats-officedocument.oleObject": "TODO",
        "image/png": "TODO",
        sheet: "js"
    },
    Fn = {
        workbooks: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
            xlsm: "application/vnd.ms-excel.sheet.macroEnabled.main+xml",
            xlsb: "application/vnd.ms-excel.sheet.binary.macroEnabled.main",
            xlam: "application/vnd.ms-excel.addin.macroEnabled.main+xml",
            xltx: "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml"
        },
        strs: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml",
            xlsb: "application/vnd.ms-excel.sharedStrings"
        },
        comments: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml",
            xlsb: "application/vnd.ms-excel.comments"
        },
        sheets: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml",
            xlsb: "application/vnd.ms-excel.worksheet"
        },
        charts: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml",
            xlsb: "application/vnd.ms-excel.chartsheet"
        },
        dialogs: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml",
            xlsb: "application/vnd.ms-excel.dialogsheet"
        },
        macros: {
            xlsx: "application/vnd.ms-excel.macrosheet+xml",
            xlsb: "application/vnd.ms-excel.macrosheet"
        },
        metadata: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml",
            xlsb: "application/vnd.ms-excel.sheetMetadata"
        },
        styles: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml",
            xlsb: "application/vnd.ms-excel.styles"
        }
    };

function x0() {
    return {
        workbooks: [],
        sheets: [],
        charts: [],
        dialogs: [],
        macros: [],
        rels: [],
        strs: [],
        comments: [],
        threadedcomments: [],
        links: [],
        coreprops: [],
        extprops: [],
        custprops: [],
        themes: [],
        styles: [],
        calcchains: [],
        vba: [],
        drawings: [],
        metadata: [],
        people: [],
        TODO: [],
        xmlns: ""
    }
}

function Ih(e) {
    var r = x0();
    if (!e || !e.match) return r;
    var t = {};
    if ((e.match($t) || []).forEach(function(a) {
            var i = Oe(a);
            switch (i[0].replace(Ud, "<")) {
                case "<?xml":
                    break;
                case "<Types":
                    r.xmlns = i["xmlns" + (i[0].match(/<(\w+):/) || ["", ""])[1]];
                    break;
                case "<Default":
                    t[i.Extension] = i.ContentType;
                    break;
                case "<Override":
                    r[Bs[i.ContentType]] !== void 0 && r[Bs[i.ContentType]].push(i.PartName);
                    break
            }
        }), r.xmlns !== Mt.CT) throw new Error("Unknown Namespace: " + r.xmlns);
    return r.calcchain = r.calcchains.length > 0 ? r.calcchains[0] : "", r.sst = r.strs.length > 0 ? r.strs[0] : "", r.style = r.styles.length > 0 ? r.styles[0] : "", r.defaults = t, delete r.calcchains, r
}

function Pl(e, r) {
    var t = Id(Bs),
        a = [],
        i;
    a[a.length] = yt, a[a.length] = ce("Types", null, {
        xmlns: Mt.CT,
        "xmlns:xsd": Mt.xsd,
        "xmlns:xsi": Mt.xsi
    }), a = a.concat([
        ["xml", "application/xml"],
        ["bin", "application/vnd.ms-excel.sheet.binary.macroEnabled.main"],
        ["vml", "application/vnd.openxmlformats-officedocument.vmlDrawing"],
        ["data", "application/vnd.openxmlformats-officedocument.model+data"],
        ["bmp", "image/bmp"],
        ["png", "image/png"],
        ["gif", "image/gif"],
        ["emf", "image/x-emf"],
        ["wmf", "image/x-wmf"],
        ["jpg", "image/jpeg"],
        ["jpeg", "image/jpeg"],
        ["tif", "image/tiff"],
        ["tiff", "image/tiff"],
        ["pdf", "application/pdf"],
        ["rels", "application/vnd.openxmlformats-package.relationships+xml"]
    ].map(function(c) {
        return ce("Default", null, {
            Extension: c[0],
            ContentType: c[1]
        })
    }));
    var n = function(c) {
            e[c] && e[c].length > 0 && (i = e[c][0], a[a.length] = ce("Override", null, {
                PartName: (i[0] == "/" ? "" : "/") + i,
                ContentType: Fn[c][r.bookType] || Fn[c].xlsx
            }))
        },
        s = function(c) {
            (e[c] || []).forEach(function(l) {
                a[a.length] = ce("Override", null, {
                    PartName: (l[0] == "/" ? "" : "/") + l,
                    ContentType: Fn[c][r.bookType] || Fn[c].xlsx
                })
            })
        },
        o = function(c) {
            (e[c] || []).forEach(function(l) {
                a[a.length] = ce("Override", null, {
                    PartName: (l[0] == "/" ? "" : "/") + l,
                    ContentType: t[c][0]
                })
            })
        };
    return n("workbooks"), s("sheets"), s("charts"), o("themes"), ["strs", "styles"].forEach(n), ["coreprops", "extprops", "custprops"].forEach(o), o("vba"), o("comments"), o("threadedcomments"), o("drawings"), s("metadata"), o("people"), a.length > 2 && (a[a.length] = "</Types>", a[1] = a[1].replace("/>", ">")), a.join("")
}
var Be = {
    WB: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
    SHEET: "http://sheetjs.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
    HLINK: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
    VML: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing",
    XPATH: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLinkPath",
    XMISS: "http://schemas.microsoft.com/office/2006/relationships/xlExternalLinkPath/xlPathMissing",
    XLINK: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLink",
    CXML: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml",
    CXMLP: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps",
    CMNT: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments",
    CORE_PROPS: "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
    EXT_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties",
    CUST_PROPS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties",
    SST: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings",
    STY: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles",
    THEME: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
    CHART: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart",
    CHARTEX: "http://schemas.microsoft.com/office/2014/relationships/chartEx",
    CS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chartsheet",
    WS: ["http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "http://purl.oclc.org/ooxml/officeDocument/relationships/worksheet"],
    DS: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/dialogsheet",
    MS: "http://schemas.microsoft.com/office/2006/relationships/xlMacrosheet",
    IMG: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
    DRAW: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing",
    XLMETA: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sheetMetadata",
    TCMNT: "http://schemas.microsoft.com/office/2017/10/relationships/threadedComment",
    PEOPLE: "http://schemas.microsoft.com/office/2017/10/relationships/person",
    VBA: "http://schemas.microsoft.com/office/2006/relationships/vbaProject"
};

function Xi(e) {
    var r = e.lastIndexOf("/");
    return e.slice(0, r + 1) + "_rels/" + e.slice(r + 1) + ".rels"
}

function Ri(e, r) {
    var t = {
        "!id": {}
    };
    if (!e) return t;
    r.charAt(0) !== "/" && (r = "/" + r);
    var a = {};
    return (e.match($t) || []).forEach(function(i) {
        var n = Oe(i);
        if (n[0] === "<Relationship") {
            var s = {};
            s.Type = n.Type, s.Target = n.Target, s.Id = n.Id, n.TargetMode && (s.TargetMode = n.TargetMode);
            var o = n.TargetMode === "External" ? n.Target : Ii(n.Target, r);
            t[o] = s, a[n.Id] = s
        }
    }), t["!id"] = a, t
}

function ri(e) {
    var r = [yt, ce("Relationships", null, {
        xmlns: Mt.RELS
    })];
    return vt(e["!id"]).forEach(function(t) {
        r[r.length] = ce("Relationship", null, e["!id"][t])
    }), r.length > 2 && (r[r.length] = "</Relationships>", r[1] = r[1].replace("/>", ">")), r.join("")
}

function et(e, r, t, a, i, n) {
    if (i || (i = {}), e["!id"] || (e["!id"] = {}), e["!idx"] || (e["!idx"] = 1), r < 0)
        for (r = e["!idx"]; e["!id"]["rId" + r]; ++r);
    if (e["!idx"] = r + 1, i.Id = "rId" + r, i.Type = a, i.Target = t, n ? i.TargetMode = n : [Be.HLINK, Be.XPATH, Be.XMISS].indexOf(i.Type) > -1 && (i.TargetMode = "External"), e["!id"][i.Id]) throw new Error("Cannot rewrite rId " + r);
    return e["!id"][i.Id] = i, e[("/" + i.Target).replace("//", "/")] = i, r
}
var Mh = "application/vnd.oasis.opendocument.spreadsheet";

function Oh(e, r) {
    for (var t = r0(e), a, i; a = zi.exec(t);) switch (a[3]) {
        case "manifest":
            break;
        case "file-entry":
            if (i = Oe(a[0], !1), i.path == "/" && i.type !== Mh) throw new Error("This OpenDocument is not a spreadsheet");
            break;
        case "encryption-data":
        case "algorithm":
        case "start-key-generation":
        case "key-derivation":
            throw new Error("Unsupported ODS Encryption");
        default:
            if (r && r.WTF) throw a
    }
}

function Dh(e) {
    var r = [yt];
    r.push(`<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
`), r.push(`  <manifest:file-entry manifest:full-path="/" manifest:version="1.2" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>
`);
    for (var t = 0; t < e.length; ++t) r.push('  <manifest:file-entry manifest:full-path="' + e[t][0] + '" manifest:media-type="' + e[t][1] + `"/>
`);
    return r.push("</manifest:manifest>"), r.join("")
}

function _c(e, r, t) {
    return ['  <rdf:Description rdf:about="' + e + `">
`, '    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/' + (t || "odf") + "#" + r + `"/>
`, `  </rdf:Description>
`].join("")
}

function Rh(e, r) {
    return ['  <rdf:Description rdf:about="' + e + `">
`, '    <ns0:hasPart xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" rdf:resource="' + r + `"/>
`, `  </rdf:Description>
`].join("")
}

function Ph(e) {
    var r = [yt];
    r.push(`<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
`);
    for (var t = 0; t != e.length; ++t) r.push(_c(e[t][0], e[t][1])), r.push(Rh("", e[t][0]));
    return r.push(_c("", "Document", "pkg")), r.push("</rdf:RDF>"), r.join("")
}

function Nl() {
    return '<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:xlink="http://www.w3.org/1999/xlink" office:version="1.2"><office:meta><meta:generator>SheetJS ' + Ui.version + "</meta:generator></office:meta></office:document-meta>"
}
var br = [
        ["cp:category", "Category"],
        ["cp:contentStatus", "ContentStatus"],
        ["cp:keywords", "Keywords"],
        ["cp:lastModifiedBy", "LastAuthor"],
        ["cp:lastPrinted", "LastPrinted"],
        ["cp:revision", "RevNumber"],
        ["cp:version", "Version"],
        ["dc:creator", "Author"],
        ["dc:description", "Comments"],
        ["dc:identifier", "Identifier"],
        ["dc:language", "Language"],
        ["dc:subject", "Subject"],
        ["dc:title", "Title"],
        ["dcterms:created", "CreatedDate", "date"],
        ["dcterms:modified", "ModifiedDate", "date"]
    ],
    Nh = (function() {
        for (var e = new Array(br.length), r = 0; r < br.length; ++r) {
            var t = br[r],
                a = "(?:" + t[0].slice(0, t[0].indexOf(":")) + ":)" + t[0].slice(t[0].indexOf(":") + 1);
            e[r] = new RegExp("<" + a + "[^>]*>([\\s\\S]*?)</" + a + ">")
        }
        return e
    })();

function Ll(e) {
    var r = {};
    e = at(e);
    for (var t = 0; t < br.length; ++t) {
        var a = br[t],
            i = e.match(Nh[t]);
        i != null && i.length > 0 && (r[a[1]] = ze(i[1])), a[2] === "date" && r[a[1]] && (r[a[1]] = ft(r[a[1]]))
    }
    return r
}

function Es(e, r, t, a, i) {
    i[e] != null || r == null || r === "" || (i[e] = r, r = tt(r), a[a.length] = t ? ce(e, r, t) : Ut(e, r))
}

function Bl(e, r) {
    var t = r || {},
        a = [yt, ce("cp:coreProperties", null, {
            "xmlns:cp": Mt.CORE_PROPS,
            "xmlns:dc": Mt.dc,
            "xmlns:dcterms": Mt.dcterms,
            "xmlns:dcmitype": Mt.dcmitype,
            "xmlns:xsi": Mt.xsi
        })],
        i = {};
    if (!e && !t.Props) return a.join("");
    e && (e.CreatedDate != null && Es("dcterms:created", typeof e.CreatedDate == "string" ? e.CreatedDate : Rs(e.CreatedDate, t.WTF), {
        "xsi:type": "dcterms:W3CDTF"
    }, a, i), e.ModifiedDate != null && Es("dcterms:modified", typeof e.ModifiedDate == "string" ? e.ModifiedDate : Rs(e.ModifiedDate, t.WTF), {
        "xsi:type": "dcterms:W3CDTF"
    }, a, i));
    for (var n = 0; n != br.length; ++n) {
        var s = br[n],
            o = t.Props && t.Props[s[1]] != null ? t.Props[s[1]] : e ? e[s[1]] : null;
        o === !0 ? o = "1" : o === !1 ? o = "0" : typeof o == "number" && (o = String(o)), o != null && Es(s[0], o, null, a, i)
    }
    return a.length > 2 && (a[a.length] = "</cp:coreProperties>", a[1] = a[1].replace("/>", ">")), a.join("")
}
var Aa = [
        ["Application", "Application", "string"],
        ["AppVersion", "AppVersion", "string"],
        ["Company", "Company", "string"],
        ["DocSecurity", "DocSecurity", "string"],
        ["Manager", "Manager", "string"],
        ["HyperlinksChanged", "HyperlinksChanged", "bool"],
        ["SharedDoc", "SharedDoc", "bool"],
        ["LinksUpToDate", "LinksUpToDate", "bool"],
        ["ScaleCrop", "ScaleCrop", "bool"],
        ["HeadingPairs", "HeadingPairs", "raw"],
        ["TitlesOfParts", "TitlesOfParts", "raw"]
    ],
    Ul = ["Worksheets", "SheetNames", "NamedRanges", "DefinedNames", "Chartsheets", "ChartNames"];

function Vl(e, r, t, a) {
    var i = [];
    if (typeof e == "string") i = cc(e, a);
    else
        for (var n = 0; n < e.length; ++n) i = i.concat(e[n].map(function(f) {
            return {
                v: f
            }
        }));
    var s = typeof r == "string" ? cc(r, a).map(function(f) {
            return f.v
        }) : r,
        o = 0,
        c = 0;
    if (s.length > 0)
        for (var l = 0; l !== i.length; l += 2) {
            switch (c = +i[l + 1].v, i[l].v) {
                case "Worksheets":
                case "\u5DE5\u4F5C\u8868":
                case "\u041B\u0438\u0441\u0442\u044B":
                case "\u0623\u0648\u0631\u0627\u0642 \u0627\u0644\u0639\u0645\u0644":
                case "\u30EF\u30FC\u30AF\u30B7\u30FC\u30C8":
                case "\u05D2\u05DC\u05D9\u05D5\u05E0\u05D5\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4":
                case "Arbeitsbl\xE4tter":
                case "\xC7al\u0131\u015Fma Sayfalar\u0131":
                case "Feuilles de calcul":
                case "Fogli di lavoro":
                case "Folhas de c\xE1lculo":
                case "Planilhas":
                case "Regneark":
                case "Hojas de c\xE1lculo":
                case "Werkbladen":
                    t.Worksheets = c, t.SheetNames = s.slice(o, o + c);
                    break;
                case "Named Ranges":
                case "Rangos con nombre":
                case "\u540D\u524D\u4ED8\u304D\u4E00\u89A7":
                case "Benannte Bereiche":
                case "Navngivne omr\xE5der":
                    t.NamedRanges = c, t.DefinedNames = s.slice(o, o + c);
                    break;
                case "Charts":
                case "Diagramme":
                    t.Chartsheets = c, t.ChartNames = s.slice(o, o + c);
                    break
            }
            o += c
        }
}

function Lh(e, r, t) {
    var a = {};
    return r || (r = {}), e = at(e), Aa.forEach(function(i) {
        var n = (e.match(Hi(i[0])) || [])[1];
        switch (i[2]) {
            case "string":
                n && (r[i[1]] = ze(n));
                break;
            case "bool":
                r[i[1]] = n === "true";
                break;
            case "raw":
                var s = e.match(new RegExp("<" + i[0] + "[^>]*>([\\s\\S]*?)</" + i[0] + ">"));
                s && s.length > 0 && (a[i[1]] = s[1]);
                break
        }
    }), a.HeadingPairs && a.TitlesOfParts && Vl(a.HeadingPairs, a.TitlesOfParts, r, t), r
}

function Wl(e) {
    var r = [],
        t = ce;
    return e || (e = {}), e.Application = "SheetJS", r[r.length] = yt, r[r.length] = ce("Properties", null, {
        xmlns: Mt.EXT_PROPS,
        "xmlns:vt": Mt.vt
    }), Aa.forEach(function(a) {
        if (e[a[1]] !== void 0) {
            var i;
            switch (a[2]) {
                case "string":
                    i = tt(String(e[a[1]]));
                    break;
                case "bool":
                    i = e[a[1]] ? "true" : "false";
                    break
            }
            i !== void 0 && (r[r.length] = t(a[0], i))
        }
    }), r[r.length] = t("HeadingPairs", t("vt:vector", t("vt:variant", "<vt:lpstr>Worksheets</vt:lpstr>") + t("vt:variant", t("vt:i4", String(e.Worksheets))), {
        size: 2,
        baseType: "variant"
    })), r[r.length] = t("TitlesOfParts", t("vt:vector", e.SheetNames.map(function(a) {
        return "<vt:lpstr>" + tt(a) + "</vt:lpstr>"
    }).join(""), {
        size: e.Worksheets,
        baseType: "lpstr"
    })), r.length > 2 && (r[r.length] = "</Properties>", r[1] = r[1].replace("/>", ">")), r.join("")
}
var Bh = /<[^>]+>[^<]*/g;

function Uh(e, r) {
    var t = {},
        a = "",
        i = e.match(Bh);
    if (i)
        for (var n = 0; n != i.length; ++n) {
            var s = i[n],
                o = Oe(s);
            switch (o[0]) {
                case "<?xml":
                    break;
                case "<Properties":
                    break;
                case "<property":
                    a = ze(o.name);
                    break;
                case "</property>":
                    a = null;
                    break;
                default:
                    if (s.indexOf("<vt:") === 0) {
                        var c = s.split(">"),
                            l = c[0].slice(4),
                            f = c[1];
                        switch (l) {
                            case "lpstr":
                            case "bstr":
                            case "lpwstr":
                                t[a] = ze(f);
                                break;
                            case "bool":
                                t[a] = lt(f);
                                break;
                            case "i1":
                            case "i2":
                            case "i4":
                            case "i8":
                            case "int":
                            case "uint":
                                t[a] = parseInt(f, 10);
                                break;
                            case "r4":
                            case "r8":
                            case "decimal":
                                t[a] = parseFloat(f);
                                break;
                            case "filetime":
                            case "date":
                                t[a] = ft(f);
                                break;
                            case "cy":
                            case "error":
                                t[a] = ze(f);
                                break;
                            default:
                                if (l.slice(-1) == "/") break;
                                r.WTF && typeof console < "u" && console.warn("Unexpected", s, l, c)
                        }
                    } else if (s.slice(0, 2) !== "</") {
                        if (r.WTF) throw new Error(s)
                    }
            }
        }
    return t
}

function Hl(e) {
    var r = [yt, ce("Properties", null, {
        xmlns: Mt.CUST_PROPS,
        "xmlns:vt": Mt.vt
    })];
    if (!e) return r.join("");
    var t = 1;
    return vt(e).forEach(function(i) {
        ++t, r[r.length] = ce("property", jd(e[i], !0), {
            fmtid: "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}",
            pid: t,
            name: tt(i)
        })
    }), r.length > 2 && (r[r.length] = "</Properties>", r[1] = r[1].replace("/>", ">")), r.join("")
}
var Us = {
        Title: "Title",
        Subject: "Subject",
        Author: "Author",
        Keywords: "Keywords",
        Comments: "Description",
        LastAuthor: "LastAuthor",
        RevNumber: "Revision",
        Application: "AppName",
        LastPrinted: "LastPrinted",
        CreatedDate: "Created",
        ModifiedDate: "LastSaved",
        Category: "Category",
        Manager: "Manager",
        Company: "Company",
        AppVersion: "Version",
        ContentStatus: "ContentStatus",
        Identifier: "Identifier",
        Language: "Language"
    },
    Cs;

function Vh(e, r, t) {
    Cs || (Cs = Yn(Us)), r = Cs[r] || r, e[r] = t
}

function Wh(e, r) {
    var t = [];
    return vt(Us).map(function(a) {
        for (var i = 0; i < br.length; ++i)
            if (br[i][1] == a) return br[i];
        for (i = 0; i < Aa.length; ++i)
            if (Aa[i][1] == a) return Aa[i];
        throw a
    }).forEach(function(a) {
        if (e[a[1]] != null) {
            var i = r && r.Props && r.Props[a[1]] != null ? r.Props[a[1]] : e[a[1]];
            a[2] === "date" && (i = new Date(i).toISOString().replace(/\.\d*Z/, "Z")), typeof i == "number" ? i = String(i) : i === !0 || i === !1 ? i = i ? "1" : "0" : i instanceof Date && (i = new Date(i).toISOString().replace(/\.\d*Z/, "")), t.push(Ut(Us[a[1]] || a[1], i))
        }
    }), ce("DocumentProperties", t.join(""), {
        xmlns: ur.o
    })
}

function Hh(e, r) {
    var t = ["Worksheets", "SheetNames"],
        a = "CustomDocumentProperties",
        i = [];
    return e && vt(e).forEach(function(n) {
        if (Object.prototype.hasOwnProperty.call(e, n)) {
            for (var s = 0; s < br.length; ++s)
                if (n == br[s][1]) return;
            for (s = 0; s < Aa.length; ++s)
                if (n == Aa[s][1]) return;
            for (s = 0; s < t.length; ++s)
                if (n == t[s]) return;
            var o = e[n],
                c = "string";
            typeof o == "number" ? (c = "float", o = String(o)) : o === !0 || o === !1 ? (c = "boolean", o = o ? "1" : "0") : o = String(o), i.push(ce(ic(n), o, {
                "dt:dt": c
            }))
        }
    }), r && vt(r).forEach(function(n) {
        if (Object.prototype.hasOwnProperty.call(r, n) && !(e && Object.prototype.hasOwnProperty.call(e, n))) {
            var s = r[n],
                o = "string";
            typeof s == "number" ? (o = "float", s = String(s)) : s === !0 || s === !1 ? (o = "boolean", s = s ? "1" : "0") : s instanceof Date ? (o = "dateTime.tz", s = s.toISOString()) : s = String(s), i.push(ce(ic(n), s, {
                "dt:dt": o
            }))
        }
    }), "<" + a + ' xmlns="' + ur.o + '">' + i.join("") + "</" + a + ">"
}

function g0(e) {
    var r = e.read_shift(4),
        t = e.read_shift(4);
    return new Date((t / 1e7 * Math.pow(2, 32) + r / 1e7 - 11644473600) * 1e3).toISOString().replace(/\.000/, "")
}

function Gh(e) {
    var r = typeof e == "string" ? new Date(Date.parse(e)) : e,
        t = r.getTime() / 1e3 + 11644473600,
        a = t % Math.pow(2, 32),
        i = (t - a) / Math.pow(2, 32);
    a *= 1e7, i *= 1e7;
    var n = a / Math.pow(2, 32) | 0;
    n > 0 && (a = a % Math.pow(2, 32), i += n);
    var s = Y(8);
    return s.write_shift(4, a), s.write_shift(4, i), s
}

function Gl(e, r, t) {
    var a = e.l,
        i = e.read_shift(0, "lpstr-cp");
    if (t)
        for (; e.l - a & 3;) ++e.l;
    return i
}

function zl(e, r, t) {
    var a = e.read_shift(0, "lpwstr");
    return t && (e.l += 4 - (a.length + 1 & 3) & 3), a
}

function Xl(e, r, t) {
    return r === 31 ? zl(e) : Gl(e, r, t)
}

function Vs(e, r, t) {
    return Xl(e, r, t === !1 ? 0 : 4)
}

function zh(e, r) {
    if (!r) throw new Error("VtUnalignedString must have positive length");
    return Xl(e, r, 0)
}

function Xh(e) {
    for (var r = e.read_shift(4), t = [], a = 0; a != r; ++a) {
        var i = e.l;
        t[a] = e.read_shift(0, "lpwstr").replace(Xt, ""), e.l - i & 2 && (e.l += 2)
    }
    return t
}

function qh(e) {
    for (var r = e.read_shift(4), t = [], a = 0; a != r; ++a) t[a] = e.read_shift(0, "lpstr-cp").replace(Xt, "");
    return t
}

function jh(e) {
    var r = e.l,
        t = Hn(e, Dl);
    e[e.l] == 0 && e[e.l + 1] == 0 && e.l - r & 2 && (e.l += 2);
    var a = Hn(e, nr);
    return [t, a]
}

function $h(e) {
    for (var r = e.read_shift(4), t = [], a = 0; a < r / 2; ++a) t.push(jh(e));
    return t
}

function vc(e, r) {
    for (var t = e.read_shift(4), a = {}, i = 0; i != t; ++i) {
        var n = e.read_shift(4),
            s = e.read_shift(4);
        a[n] = e.read_shift(s, r === 1200 ? "utf16le" : "utf8").replace(Xt, "").replace(bi, "!"), r === 1200 && s % 2 && (e.l += 2)
    }
    return e.l & 3 && (e.l = e.l >> 3 << 2), a
}

function ql(e) {
    var r = e.read_shift(4),
        t = e.slice(e.l, e.l + r);
    return e.l += r, (r & 3) > 0 && (e.l += 4 - (r & 3) & 3), t
}

function Yh(e) {
    var r = {};
    return r.Size = e.read_shift(4), e.l += r.Size + 3 - (r.Size - 1) % 4, r
}

function Hn(e, r, t) {
    var a = e.read_shift(2),
        i, n = t || {};
    if (e.l += 2, r !== xc && a !== r && kh.indexOf(r) === -1 && !((r & 65534) == 4126 && (a & 65534) == 4126)) throw new Error("Expected type " + r + " saw " + a);
    switch (r === xc ? a : r) {
        case 2:
            return i = e.read_shift(2, "i"), n.raw || (e.l += 2), i;
        case 3:
            return i = e.read_shift(4, "i"), i;
        case 11:
            return e.read_shift(4) !== 0;
        case 19:
            return i = e.read_shift(4), i;
        case 30:
            return Gl(e, a, 4).replace(Xt, "");
        case 31:
            return zl(e);
        case 64:
            return g0(e);
        case 65:
            return ql(e);
        case 71:
            return Yh(e);
        case 80:
            return Vs(e, a, !n.raw).replace(Xt, "");
        case 81:
            return zh(e, a).replace(Xt, "");
        case 4108:
            return $h(e);
        case 4126:
        case 4127:
            return a == 4127 ? Xh(e) : qh(e);
        default:
            throw new Error("TypedPropertyValue unrecognized type " + r + " " + a)
    }
}

function wc(e, r) {
    var t = Y(4),
        a = Y(4);
    switch (t.write_shift(4, e == 80 ? 31 : e), e) {
        case 3:
            a.write_shift(-4, r);
            break;
        case 5:
            a = Y(8), a.write_shift(8, r, "f");
            break;
        case 11:
            a.write_shift(4, r ? 1 : 0);
            break;
        case 64:
            a = Gh(r);
            break;
        case 31:
        case 80:
            for (a = Y(4 + 2 * (r.length + 1) + (r.length % 2 ? 0 : 2)), a.write_shift(4, r.length + 1), a.write_shift(0, r, "dbcs"); a.l != a.length;) a.write_shift(1, 0);
            break;
        default:
            throw new Error("TypedPropertyValue unrecognized type " + e + " " + r)
    }
    return Pt([t, a])
}

function Sc(e, r) {
    var t = e.l,
        a = e.read_shift(4),
        i = e.read_shift(4),
        n = [],
        s = 0,
        o = 0,
        c = -1,
        l = {};
    for (s = 0; s != i; ++s) {
        var f = e.read_shift(4),
            u = e.read_shift(4);
        n[s] = [f, u + t]
    }
    n.sort(function(S, _) {
        return S[1] - _[1]
    });
    var h = {};
    for (s = 0; s != i; ++s) {
        if (e.l !== n[s][1]) {
            var p = !0;
            if (s > 0 && r) switch (r[n[s - 1][0]].t) {
                case 2:
                    e.l + 2 === n[s][1] && (e.l += 2, p = !1);
                    break;
                case 80:
                    e.l <= n[s][1] && (e.l = n[s][1], p = !1);
                    break;
                case 4108:
                    e.l <= n[s][1] && (e.l = n[s][1], p = !1);
                    break
            }
            if ((!r || s == 0) && e.l <= n[s][1] && (p = !1, e.l = n[s][1]), p) throw new Error("Read Error: Expected address " + n[s][1] + " at " + e.l + " :" + s)
        }
        if (r) {
            var m = r[n[s][0]];
            if (h[m.n] = Hn(e, m.t, {
                    raw: !0
                }), m.p === "version" && (h[m.n] = String(h[m.n] >> 16) + "." + ("0000" + String(h[m.n] & 65535)).slice(-4)), m.n == "CodePage") switch (h[m.n]) {
                case 0:
                    h[m.n] = 1252;
                case 874:
                case 932:
                case 936:
                case 949:
                case 950:
                case 1250:
                case 1251:
                case 1253:
                case 1254:
                case 1255:
                case 1256:
                case 1257:
                case 1258:
                case 1e4:
                case 1200:
                case 1201:
                case 1252:
                case 65e3:
                case -536:
                case 65001:
                case -535:
                    Rr(o = h[m.n] >>> 0 & 65535);
                    break;
                default:
                    throw new Error("Unsupported CodePage: " + h[m.n])
            }
        } else if (n[s][0] === 1) {
            if (o = h.CodePage = Hn(e, m0), Rr(o), c !== -1) {
                var d = e.l;
                e.l = n[c][1], l = vc(e, o), e.l = d
            }
        } else if (n[s][0] === 0) {
            if (o === 0) {
                c = s, e.l = n[s + 1][1];
                continue
            }
            l = vc(e, o)
        } else {
            var x = l[n[s][0]],
                E;
            switch (e[e.l]) {
                case 65:
                    e.l += 4, E = ql(e);
                    break;
                case 30:
                    e.l += 4, E = Vs(e, e[e.l - 4]).replace(/\u0000+$/, "");
                    break;
                case 31:
                    e.l += 4, E = Vs(e, e[e.l - 4]).replace(/\u0000+$/, "");
                    break;
                case 3:
                    e.l += 4, E = e.read_shift(4, "i");
                    break;
                case 19:
                    e.l += 4, E = e.read_shift(4);
                    break;
                case 5:
                    e.l += 4, E = e.read_shift(8, "f");
                    break;
                case 11:
                    e.l += 4, E = Ct(e, 4);
                    break;
                case 64:
                    e.l += 4, E = ft(g0(e));
                    break;
                default:
                    throw new Error("unparsed value: " + e[e.l])
            }
            h[x] = E
        }
    }
    return e.l = t + a, h
}
var jl = ["CodePage", "Thumbnail", "_PID_LINKBASE", "_PID_HLINKS", "SystemIdentifier", "FMTID"];

function Kh(e) {
    switch (typeof e) {
        case "boolean":
            return 11;
        case "number":
            return (e | 0) == e ? 3 : 5;
        case "string":
            return 31;
        case "object":
            if (e instanceof Date) return 64;
            break
    }
    return -1
}

function Ec(e, r, t) {
    var a = Y(8),
        i = [],
        n = [],
        s = 8,
        o = 0,
        c = Y(8),
        l = Y(8);
    if (c.write_shift(4, 2), c.write_shift(4, 1200), l.write_shift(4, 1), n.push(c), i.push(l), s += 8 + c.length, !r) {
        l = Y(8), l.write_shift(4, 0), i.unshift(l);
        var f = [Y(4)];
        for (f[0].write_shift(4, e.length), o = 0; o < e.length; ++o) {
            var u = e[o][0];
            for (c = Y(8 + 2 * (u.length + 1) + (u.length % 2 ? 0 : 2)), c.write_shift(4, o + 2), c.write_shift(4, u.length + 1), c.write_shift(0, u, "dbcs"); c.l != c.length;) c.write_shift(1, 0);
            f.push(c)
        }
        c = Pt(f), n.unshift(c), s += 8 + c.length
    }
    for (o = 0; o < e.length; ++o)
        if (!(r && !r[e[o][0]]) && !(jl.indexOf(e[o][0]) > -1 || Ul.indexOf(e[o][0]) > -1) && e[o][1] != null) {
            var h = e[o][1],
                p = 0;
            if (r) {
                p = +r[e[o][0]];
                var m = t[p];
                if (m.p == "version" && typeof h == "string") {
                    var d = h.split(".");
                    h = (+d[0] << 16) + (+d[1] || 0)
                }
                c = wc(m.t, h)
            } else {
                var x = Kh(h);
                x == -1 && (x = 31, h = String(h)), c = wc(x, h)
            }
            n.push(c), l = Y(8), l.write_shift(4, r ? p : 2 + o), i.push(l), s += 8 + c.length
        }
    var E = 8 * (n.length + 1);
    for (o = 0; o < n.length; ++o) i[o].write_shift(4, E), E += n[o].length;
    return a.write_shift(4, s), a.write_shift(4, n.length), Pt([a].concat(i).concat(n))
}

function Cc(e, r, t) {
    var a = e.content;
    if (!a) return {};
    Bt(a, 0);
    var i, n, s, o, c = 0;
    a.chk("feff", "Byte Order: "), a.read_shift(2);
    var l = a.read_shift(4),
        f = a.read_shift(16);
    if (f !== Ae.utils.consts.HEADER_CLSID && f !== t) throw new Error("Bad PropertySet CLSID " + f);
    if (i = a.read_shift(4), i !== 1 && i !== 2) throw new Error("Unrecognized #Sets: " + i);
    if (n = a.read_shift(16), o = a.read_shift(4), i === 1 && o !== a.l) throw new Error("Length mismatch: " + o + " !== " + a.l);
    i === 2 && (s = a.read_shift(16), c = a.read_shift(4));
    var u = Sc(a, r),
        h = {
            SystemIdentifier: l
        };
    for (var p in u) h[p] = u[p];
    if (h.FMTID = n, i === 1) return h;
    if (c - a.l == 2 && (a.l += 2), a.l !== c) throw new Error("Length mismatch 2: " + a.l + " !== " + c);
    var m;
    try {
        m = Sc(a, null)
    } catch (d) {}
    for (p in m) h[p] = m[p];
    return h.FMTID = [n, s], h
}

function Tc(e, r, t, a, i, n) {
    var s = Y(i ? 68 : 48),
        o = [s];
    s.write_shift(2, 65534), s.write_shift(2, 0), s.write_shift(4, 842412599), s.write_shift(16, Ae.utils.consts.HEADER_CLSID, "hex"), s.write_shift(4, i ? 2 : 1), s.write_shift(16, r, "hex"), s.write_shift(4, i ? 68 : 48);
    var c = Ec(e, t, a);
    if (o.push(c), i) {
        var l = Ec(i, null, null);
        s.write_shift(16, n, "hex"), s.write_shift(4, 68 + c.length), o.push(l)
    }
    return Pt(o)
}

function ua(e, r) {
    return e.read_shift(r), null
}

function Jh(e, r) {
    r || (r = Y(e));
    for (var t = 0; t < e; ++t) r.write_shift(1, 0);
    return r
}

function Zh(e, r, t) {
    for (var a = [], i = e.l + r; e.l < i;) a.push(t(e, i - e.l));
    if (i !== e.l) throw new Error("Slurp error");
    return a
}

function Ct(e, r) {
    return e.read_shift(r) === 1
}

function Jt(e, r) {
    return r || (r = Y(2)), r.write_shift(2, +!!e), r
}

function bt(e) {
    return e.read_shift(2, "u")
}

function Ar(e, r) {
    return r || (r = Y(2)), r.write_shift(2, e), r
}

function $l(e, r) {
    return Zh(e, r, bt)
}

function Qh(e) {
    var r = e.read_shift(1),
        t = e.read_shift(1);
    return t === 1 ? r : r === 1
}

function Yl(e, r, t) {
    return t || (t = Y(2)), t.write_shift(1, r == "e" ? +e : +!!e), t.write_shift(1, r == "e" ? 1 : 0), t
}

function en(e, r, t) {
    var a = e.read_shift(t && t.biff >= 12 ? 2 : 1),
        i = "sbcs-cont",
        n = zr;
    if (t && t.biff >= 8 && (zr = 1200), !t || t.biff == 8) {
        var s = e.read_shift(1);
        s && (i = "dbcs-cont")
    } else t.biff == 12 && (i = "wstr");
    t.biff >= 2 && t.biff <= 5 && (i = "cpstr");
    var o = a ? e.read_shift(a, i) : "";
    return zr = n, o
}

function e1(e) {
    var r = zr;
    zr = 1200;
    var t = e.read_shift(2),
        a = e.read_shift(1),
        i = a & 4,
        n = a & 8,
        s = 1 + (a & 1),
        o = 0,
        c, l = {};
    n && (o = e.read_shift(2)), i && (c = e.read_shift(4));
    var f = s == 2 ? "dbcs-cont" : "sbcs-cont",
        u = t === 0 ? "" : e.read_shift(t, f);
    return n && (e.l += 4 * o), i && (e.l += c), l.t = u, n || (l.raw = "<t>" + l.t + "</t>", l.r = l.t), zr = r, l
}

function t1(e) {
    var r = e.t || "",
        t = 1,
        a = Y(3 + (t > 1 ? 2 : 0));
    a.write_shift(2, r.length), a.write_shift(1, (t > 1 ? 8 : 0) | 1), t > 1 && a.write_shift(2, t);
    var i = Y(2 * r.length);
    i.write_shift(2 * r.length, r, "utf16le");
    var n = [a, i];
    return Pt(n)
}

function Ra(e, r, t) {
    var a;
    if (t) {
        if (t.biff >= 2 && t.biff <= 5) return e.read_shift(r, "cpstr");
        if (t.biff >= 12) return e.read_shift(r, "dbcs-cont")
    }
    var i = e.read_shift(1);
    return i === 0 ? a = e.read_shift(r, "sbcs-cont") : a = e.read_shift(r, "dbcs-cont"), a
}

function tn(e, r, t) {
    var a = e.read_shift(t && t.biff == 2 ? 1 : 2);
    return a === 0 ? (e.l++, "") : Ra(e, a, t)
}

function Ha(e, r, t) {
    if (t.biff > 5) return tn(e, r, t);
    var a = e.read_shift(1);
    return a === 0 ? (e.l++, "") : e.read_shift(a, t.biff <= 4 || !e.lens ? "cpstr" : "sbcs-cont")
}

function Kl(e, r, t) {
    return t || (t = Y(3 + 2 * e.length)), t.write_shift(2, e.length), t.write_shift(1, 1), t.write_shift(31, e, "utf16le"), t
}

function r1(e) {
    var r = e.read_shift(1);
    e.l++;
    var t = e.read_shift(2);
    return e.l += 2, [r, t]
}

function a1(e) {
    var r = e.read_shift(4),
        t = e.l,
        a = !1;
    r > 24 && (e.l += r - 24, e.read_shift(16) === "795881f43b1d7f48af2c825dc4852763" && (a = !0), e.l = t);
    var i = e.read_shift((a ? r - 24 : r) >> 1, "utf16le").replace(Xt, "");
    return a && (e.l += 24), i
}

function i1(e) {
    for (var r = e.read_shift(2), t = ""; r-- > 0;) t += "../";
    var a = e.read_shift(0, "lpstr-ansi");
    if (e.l += 2, e.read_shift(2) != 57005) throw new Error("Bad FileMoniker");
    var i = e.read_shift(4);
    if (i === 0) return t + a.replace(/\\/g, "/");
    var n = e.read_shift(4);
    if (e.read_shift(2) != 3) throw new Error("Bad FileMoniker");
    var s = e.read_shift(n >> 1, "utf16le").replace(Xt, "");
    return t + s
}

function n1(e, r) {
    var t = e.read_shift(16);
    switch (r -= 16, t) {
        case "e0c9ea79f9bace118c8200aa004ba90b":
            return a1(e, r);
        case "0303000000000000c000000000000046":
            return i1(e, r);
        default:
            throw new Error("Unsupported Moniker " + t)
    }
}

function An(e) {
    var r = e.read_shift(4),
        t = r > 0 ? e.read_shift(r, "utf16le").replace(Xt, "") : "";
    return t
}

function yc(e, r) {
    r || (r = Y(6 + e.length * 2)), r.write_shift(4, 1 + e.length);
    for (var t = 0; t < e.length; ++t) r.write_shift(2, e.charCodeAt(t));
    return r.write_shift(2, 0), r
}

function s1(e, r) {
    var t = e.l + r,
        a = e.read_shift(4);
    if (a !== 2) throw new Error("Unrecognized streamVersion: " + a);
    var i = e.read_shift(2);
    e.l += 2;
    var n, s, o, c, l = "",
        f, u;
    i & 16 && (n = An(e, t - e.l)), i & 128 && (s = An(e, t - e.l)), (i & 257) === 257 && (o = An(e, t - e.l)), (i & 257) === 1 && (c = n1(e, t - e.l)), i & 8 && (l = An(e, t - e.l)), i & 32 && (f = e.read_shift(16)), i & 64 && (u = g0(e)), e.l = t;
    var h = s || o || c || "";
    h && l && (h += "#" + l), h || (h = "#" + l), i & 2 && h.charAt(0) == "/" && h.charAt(1) != "/" && (h = "file://" + h);
    var p = {
        Target: h
    };
    return f && (p.guid = f), u && (p.time = u), n && (p.Tooltip = n), p
}

function o1(e) {
    var r = Y(512),
        t = 0,
        a = e.Target;
    a.slice(0, 7) == "file://" && (a = a.slice(7));
    var i = a.indexOf("#"),
        n = i > -1 ? 31 : 23;
    switch (a.charAt(0)) {
        case "#":
            n = 28;
            break;
        case ".":
            n &= -3;
            break
    }
    r.write_shift(4, 2), r.write_shift(4, n);
    var s = [8, 6815827, 6619237, 4849780, 83];
    for (t = 0; t < s.length; ++t) r.write_shift(4, s[t]);
    if (n == 28) a = a.slice(1), yc(a, r);
    else if (n & 2) {
        for (s = "e0 c9 ea 79 f9 ba ce 11 8c 82 00 aa 00 4b a9 0b".split(" "), t = 0; t < s.length; ++t) r.write_shift(1, parseInt(s[t], 16));
        var o = i > -1 ? a.slice(0, i) : a;
        for (r.write_shift(4, 2 * (o.length + 1)), t = 0; t < o.length; ++t) r.write_shift(2, o.charCodeAt(t));
        r.write_shift(2, 0), n & 8 && yc(i > -1 ? a.slice(i + 1) : "", r)
    } else {
        for (s = "03 03 00 00 00 00 00 00 c0 00 00 00 00 00 00 46".split(" "), t = 0; t < s.length; ++t) r.write_shift(1, parseInt(s[t], 16));
        for (var c = 0; a.slice(c * 3, c * 3 + 3) == "../" || a.slice(c * 3, c * 3 + 3) == "..\\";) ++c;
        for (r.write_shift(2, c), r.write_shift(4, a.length - 3 * c + 1), t = 0; t < a.length - 3 * c; ++t) r.write_shift(1, a.charCodeAt(t + 3 * c) & 255);
        for (r.write_shift(1, 0), r.write_shift(2, 65535), r.write_shift(2, 57005), t = 0; t < 6; ++t) r.write_shift(4, 0)
    }
    return r.slice(0, r.l)
}

function Jl(e) {
    var r = e.read_shift(1),
        t = e.read_shift(1),
        a = e.read_shift(1),
        i = e.read_shift(1);
    return [r, t, a, i]
}

function Zl(e, r) {
    var t = Jl(e, r);
    return t[3] = 0, t
}

function qr(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(2);
    return {
        r,
        c: t,
        ixfe: a
    }
}

function Pa(e, r, t, a) {
    return a || (a = Y(6)), a.write_shift(2, e), a.write_shift(2, r), a.write_shift(2, t || 0), a
}

function c1(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2);
    return e.l += 8, {
        type: r,
        flags: t
    }
}

function l1(e, r, t) {
    return r === 0 ? "" : Ha(e, r, t)
}

function f1(e, r, t) {
    var a = t.biff > 8 ? 4 : 2,
        i = e.read_shift(a),
        n = e.read_shift(a, "i"),
        s = e.read_shift(a, "i");
    return [i, n, s]
}

function Ql(e) {
    var r = e.read_shift(2),
        t = p0(e);
    return [r, t]
}

function u1(e, r, t) {
    e.l += 4, r -= 4;
    var a = e.l + r,
        i = en(e, r, t),
        n = e.read_shift(2);
    if (a -= e.l, n !== a) throw new Error("Malformed AddinUdf: padding = " + a + " != " + n);
    return e.l += n, i
}

function Qn(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(2),
        i = e.read_shift(2);
    return {
        s: {
            c: a,
            r
        },
        e: {
            c: i,
            r: t
        }
    }
}

function ef(e, r) {
    return r || (r = Y(8)), r.write_shift(2, e.s.r), r.write_shift(2, e.e.r), r.write_shift(2, e.s.c), r.write_shift(2, e.e.c), r
}

function tf(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(1),
        i = e.read_shift(1);
    return {
        s: {
            c: a,
            r
        },
        e: {
            c: i,
            r: t
        }
    }
}
var d1 = tf;

function rf(e) {
    e.l += 4;
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(2);
    return e.l += 12, [t, r, a]
}

function h1(e) {
    var r = {};
    return e.l += 4, e.l += 16, r.fSharedNote = e.read_shift(2), e.l += 4, r
}

function p1(e) {
    var r = {};
    return e.l += 4, e.cf = e.read_shift(2), r
}

function Vt(e) {
    e.l += 2, e.l += e.read_shift(2)
}
var m1 = {
    0: Vt,
    4: Vt,
    5: Vt,
    6: Vt,
    7: p1,
    8: Vt,
    9: Vt,
    10: Vt,
    11: Vt,
    12: Vt,
    13: h1,
    14: Vt,
    15: Vt,
    16: Vt,
    17: Vt,
    18: Vt,
    19: Vt,
    20: Vt,
    21: rf
};

function x1(e, r) {
    for (var t = e.l + r, a = []; e.l < t;) {
        var i = e.read_shift(2);
        e.l -= 2;
        try {
            a.push(m1[i](e, t - e.l))
        } catch (n) {
            return e.l = t, a
        }
    }
    return e.l != t && (e.l = t), a
}

function bn(e, r) {
    var t = {
        BIFFVer: 0,
        dt: 0
    };
    switch (t.BIFFVer = e.read_shift(2), r -= 2, r >= 2 && (t.dt = e.read_shift(2), e.l -= 2), t.BIFFVer) {
        case 1536:
        case 1280:
        case 1024:
        case 768:
        case 512:
        case 2:
        case 7:
            break;
        default:
            if (r > 6) throw new Error("Unexpected BIFF Ver " + t.BIFFVer)
    }
    return e.read_shift(r), t
}

function _0(e, r, t) {
    var a = 1536,
        i = 16;
    switch (t.bookType) {
        case "biff8":
            break;
        case "biff5":
            a = 1280, i = 8;
            break;
        case "biff4":
            a = 4, i = 6;
            break;
        case "biff3":
            a = 3, i = 6;
            break;
        case "biff2":
            a = 2, i = 4;
            break;
        case "xla":
            break;
        default:
            throw new Error("unsupported BIFF version")
    }
    var n = Y(i);
    return n.write_shift(2, a), n.write_shift(2, r), i > 4 && n.write_shift(2, 29282), i > 6 && n.write_shift(2, 1997), i > 8 && (n.write_shift(2, 49161), n.write_shift(2, 1), n.write_shift(2, 1798), n.write_shift(2, 0)), n
}

function g1(e, r) {
    return r === 0 || e.read_shift(2), 1200
}

function _1(e, r, t) {
    if (t.enc) return e.l += r, "";
    var a = e.l,
        i = Ha(e, 0, t);
    return e.read_shift(r + a - e.l), i
}

function v1(e, r) {
    var t = !r || r.biff == 8,
        a = Y(t ? 112 : 54);
    for (a.write_shift(r.biff == 8 ? 2 : 1, 7), t && a.write_shift(1, 0), a.write_shift(4, 859007059), a.write_shift(4, 5458548 | (t ? 0 : 536870912)); a.l < a.length;) a.write_shift(1, t ? 0 : 32);
    return a
}

function w1(e, r, t) {
    var a = t && t.biff == 8 || r == 2 ? e.read_shift(2) : (e.l += r, 0);
    return {
        fDialog: a & 16,
        fBelow: a & 64,
        fRight: a & 128
    }
}

function S1(e, r, t) {
    var a = e.read_shift(4),
        i = e.read_shift(1) & 3,
        n = e.read_shift(1);
    switch (n) {
        case 0:
            n = "Worksheet";
            break;
        case 1:
            n = "Macrosheet";
            break;
        case 2:
            n = "Chartsheet";
            break;
        case 6:
            n = "VBAModule";
            break
    }
    var s = en(e, 0, t);
    return s.length === 0 && (s = "Sheet1"), {
        pos: a,
        hs: i,
        dt: n,
        name: s
    }
}

function E1(e, r) {
    var t = !r || r.biff >= 8 ? 2 : 1,
        a = Y(8 + t * e.name.length);
    a.write_shift(4, e.pos), a.write_shift(1, e.hs || 0), a.write_shift(1, e.dt), a.write_shift(1, e.name.length), r.biff >= 8 && a.write_shift(1, 1), a.write_shift(t * e.name.length, e.name, r.biff < 8 ? "sbcs" : "utf16le");
    var i = a.slice(0, a.l);
    return i.l = a.l, i
}

function C1(e, r) {
    for (var t = e.l + r, a = e.read_shift(4), i = e.read_shift(4), n = [], s = 0; s != i && e.l < t; ++s) n.push(e1(e));
    return n.Count = a, n.Unique = i, n
}

function T1(e, r) {
    var t = Y(8);
    t.write_shift(4, e.Count), t.write_shift(4, e.Unique);
    for (var a = [], i = 0; i < e.length; ++i) a[i] = t1(e[i], r);
    var n = Pt([t].concat(a));
    return n.parts = [t.length].concat(a.map(function(s) {
        return s.length
    })), n
}

function y1(e, r) {
    var t = {};
    return t.dsst = e.read_shift(2), e.l += r - 2, t
}

function k1(e) {
    var r = {};
    r.r = e.read_shift(2), r.c = e.read_shift(2), r.cnt = e.read_shift(2) - r.c;
    var t = e.read_shift(2);
    e.l += 4;
    var a = e.read_shift(1);
    return e.l += 3, a & 7 && (r.level = a & 7), a & 32 && (r.hidden = !0), a & 64 && (r.hpt = t / 20), r
}

function F1(e) {
    var r = c1(e);
    if (r.type != 2211) throw new Error("Invalid Future Record " + r.type);
    var t = e.read_shift(4);
    return t !== 0
}

function A1(e) {
    return e.read_shift(2), e.read_shift(4)
}

function kc(e, r, t) {
    var a = 0;
    t && t.biff == 2 || (a = e.read_shift(2));
    var i = e.read_shift(2);
    t && t.biff == 2 && (a = 1 - (i >> 15), i &= 32767);
    var n = {
        Unsynced: a & 1,
        DyZero: (a & 2) >> 1,
        ExAsc: (a & 4) >> 2,
        ExDsc: (a & 8) >> 3
    };
    return [n, i]
}

function b1(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(2),
        i = e.read_shift(2),
        n = e.read_shift(2),
        s = e.read_shift(2),
        o = e.read_shift(2),
        c = e.read_shift(2),
        l = e.read_shift(2);
    return {
        Pos: [r, t],
        Dim: [a, i],
        Flags: n,
        CurTab: s,
        FirstTab: o,
        Selected: c,
        TabRatio: l
    }
}

function I1() {
    var e = Y(18);
    return e.write_shift(2, 0), e.write_shift(2, 0), e.write_shift(2, 29280), e.write_shift(2, 17600), e.write_shift(2, 56), e.write_shift(2, 0), e.write_shift(2, 0), e.write_shift(2, 1), e.write_shift(2, 500), e
}

function M1(e, r, t) {
    if (t && t.biff >= 2 && t.biff < 5) return {};
    var a = e.read_shift(2);
    return {
        RTL: a & 64
    }
}

function O1(e) {
    var r = Y(18),
        t = 1718;
    return e && e.RTL && (t |= 64), r.write_shift(2, t), r.write_shift(4, 0), r.write_shift(4, 64), r.write_shift(4, 0), r.write_shift(4, 0), r
}

function D1() {}

function R1(e, r, t) {
    var a = {
        dyHeight: e.read_shift(2),
        fl: e.read_shift(2)
    };
    switch (t && t.biff || 8) {
        case 2:
            break;
        case 3:
        case 4:
            e.l += 2;
            break;
        default:
            e.l += 10;
            break
    }
    return a.name = en(e, 0, t), a
}

function P1(e, r) {
    var t = e.name || "Arial",
        a = r && r.biff == 5,
        i = a ? 15 + t.length : 16 + 2 * t.length,
        n = Y(i);
    return n.write_shift(2, (e.sz || 12) * 20), n.write_shift(4, 0), n.write_shift(2, 400), n.write_shift(4, 0), n.write_shift(2, 0), n.write_shift(1, t.length), a || n.write_shift(1, 1), n.write_shift((a ? 1 : 2) * t.length, t, a ? "sbcs" : "utf16le"), n
}

function N1(e) {
    var r = qr(e);
    return r.isst = e.read_shift(4), r
}

function L1(e, r, t, a) {
    var i = Y(10);
    return Pa(e, r, a, i), i.write_shift(4, t), i
}

function B1(e, r, t) {
    t.biffguess && t.biff == 2 && (t.biff = 5);
    var a = e.l + r,
        i = qr(e, 6);
    t.biff == 2 && e.l++;
    var n = tn(e, a - e.l, t);
    return i.val = n, i
}

function U1(e, r, t, a, i) {
    var n = !i || i.biff == 8,
        s = Y(8 + +n + (1 + n) * t.length);
    return Pa(e, r, a, s), s.write_shift(2, t.length), n && s.write_shift(1, 1), s.write_shift((1 + n) * t.length, t, n ? "utf16le" : "sbcs"), s
}

function V1(e, r, t) {
    var a = e.read_shift(2),
        i = Ha(e, 0, t);
    return [a, i]
}

function W1(e, r, t, a) {
    var i = t && t.biff == 5;
    a || (a = Y(i ? 3 + r.length : 5 + 2 * r.length)), a.write_shift(2, e), a.write_shift(i ? 1 : 2, r.length), i || a.write_shift(1, 1), a.write_shift((i ? 1 : 2) * r.length, r, i ? "sbcs" : "utf16le");
    var n = a.length > a.l ? a.slice(0, a.l) : a;
    return n.l == null && (n.l = n.length), n
}
var H1 = Ha;

function Fc(e, r, t) {
    var a = e.l + r,
        i = t.biff == 8 || !t.biff ? 4 : 2,
        n = e.read_shift(i),
        s = e.read_shift(i),
        o = e.read_shift(2),
        c = e.read_shift(2);
    return e.l = a, {
        s: {
            r: n,
            c: o
        },
        e: {
            r: s,
            c
        }
    }
}

function G1(e, r) {
    var t = r.biff == 8 || !r.biff ? 4 : 2,
        a = Y(2 * t + 6);
    return a.write_shift(t, e.s.r), a.write_shift(t, e.e.r + 1), a.write_shift(2, e.s.c), a.write_shift(2, e.e.c + 1), a.write_shift(2, 0), a
}

function z1(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = Ql(e);
    return {
        r,
        c: t,
        ixfe: a[0],
        rknum: a[1]
    }
}

function X1(e, r) {
    for (var t = e.l + r - 2, a = e.read_shift(2), i = e.read_shift(2), n = []; e.l < t;) n.push(Ql(e));
    if (e.l !== t) throw new Error("MulRK read error");
    var s = e.read_shift(2);
    if (n.length != s - i + 1) throw new Error("MulRK length mismatch");
    return {
        r: a,
        c: i,
        C: s,
        rkrec: n
    }
}

function q1(e, r) {
    for (var t = e.l + r - 2, a = e.read_shift(2), i = e.read_shift(2), n = []; e.l < t;) n.push(e.read_shift(2));
    if (e.l !== t) throw new Error("MulBlank read error");
    var s = e.read_shift(2);
    if (n.length != s - i + 1) throw new Error("MulBlank length mismatch");
    return {
        r: a,
        c: i,
        C: s,
        ixfe: n
    }
}

function j1(e, r, t, a) {
    var i = {},
        n = e.read_shift(4),
        s = e.read_shift(4),
        o = e.read_shift(4),
        c = e.read_shift(2);
    return i.patternType = Fh[o >> 26], a.cellStyles && (i.alc = n & 7, i.fWrap = n >> 3 & 1, i.alcV = n >> 4 & 7, i.fJustLast = n >> 7 & 1, i.trot = n >> 8 & 255, i.cIndent = n >> 16 & 15, i.fShrinkToFit = n >> 20 & 1, i.iReadOrder = n >> 22 & 2, i.fAtrNum = n >> 26 & 1, i.fAtrFnt = n >> 27 & 1, i.fAtrAlc = n >> 28 & 1, i.fAtrBdr = n >> 29 & 1, i.fAtrPat = n >> 30 & 1, i.fAtrProt = n >> 31 & 1, i.dgLeft = s & 15, i.dgRight = s >> 4 & 15, i.dgTop = s >> 8 & 15, i.dgBottom = s >> 12 & 15, i.icvLeft = s >> 16 & 127, i.icvRight = s >> 23 & 127, i.grbitDiag = s >> 30 & 3, i.icvTop = o & 127, i.icvBottom = o >> 7 & 127, i.icvDiag = o >> 14 & 127, i.dgDiag = o >> 21 & 15, i.icvFore = c & 127, i.icvBack = c >> 7 & 127, i.fsxButton = c >> 14 & 1), i
}

function $1(e, r, t) {
    var a = {};
    return a.ifnt = e.read_shift(2), a.numFmtId = e.read_shift(2), a.flags = e.read_shift(2), a.fStyle = a.flags >> 2 & 1, r -= 6, a.data = j1(e, r, a.fStyle, t), a
}

function Ac(e, r, t, a) {
    var i = t && t.biff == 5;
    a || (a = Y(i ? 16 : 20)), a.write_shift(2, 0), e.style ? (a.write_shift(2, e.numFmtId || 0), a.write_shift(2, 65524)) : (a.write_shift(2, e.numFmtId || 0), a.write_shift(2, r << 4));
    var n = 0;
    return e.numFmtId > 0 && i && (n |= 1024), a.write_shift(4, n), a.write_shift(4, 0), i || a.write_shift(4, 0), a.write_shift(2, 0), a
}

function Y1(e) {
    e.l += 4;
    var r = [e.read_shift(2), e.read_shift(2)];
    if (r[0] !== 0 && r[0]--, r[1] !== 0 && r[1]--, r[0] > 7 || r[1] > 7) throw new Error("Bad Gutters: " + r.join("|"));
    return r
}

function K1(e) {
    var r = Y(8);
    return r.write_shift(4, 0), r.write_shift(2, e[0] ? e[0] + 1 : 0), r.write_shift(2, e[1] ? e[1] + 1 : 0), r
}

function bc(e, r, t) {
    var a = qr(e, 6);
    (t.biff == 2 || r == 9) && ++e.l;
    var i = Qh(e, 2);
    return a.val = i, a.t = i === !0 || i === !1 ? "b" : "e", a
}

function J1(e, r, t, a, i, n) {
    var s = Y(8);
    return Pa(e, r, a, s), Yl(t, n, s), s
}

function Z1(e, r, t) {
    t.biffguess && t.biff == 2 && (t.biff = 5);
    var a = qr(e, 6),
        i = zt(e, 8);
    return a.val = i, a
}

function Q1(e, r, t, a) {
    var i = Y(14);
    return Pa(e, r, a, i), Da(t, i), i
}
var Ic = l1;

function ep(e, r, t) {
    var a = e.l + r,
        i = e.read_shift(2),
        n = e.read_shift(2);
    if (t.sbcch = n, n == 1025 || n == 14849) return [n, i];
    if (n < 1 || n > 255) throw new Error("Unexpected SupBook type: " + n);
    for (var s = Ra(e, n), o = []; a > e.l;) o.push(tn(e));
    return [n, i, s, o]
}

function Mc(e, r, t) {
    var a = e.read_shift(2),
        i, n = {
            fBuiltIn: a & 1,
            fWantAdvise: a >>> 1 & 1,
            fWantPict: a >>> 2 & 1,
            fOle: a >>> 3 & 1,
            fOleLink: a >>> 4 & 1,
            cf: a >>> 5 & 1023,
            fIcon: a >>> 15 & 1
        };
    return t.sbcch === 14849 && (i = u1(e, r - 2, t)), n.body = i || e.read_shift(r - 2), typeof i == "string" && (n.Name = i), n
}
var tp = ["_xlnm.Consolidate_Area", "_xlnm.Auto_Open", "_xlnm.Auto_Close", "_xlnm.Extract", "_xlnm.Database", "_xlnm.Criteria", "_xlnm.Print_Area", "_xlnm.Print_Titles", "_xlnm.Recorder", "_xlnm.Data_Form", "_xlnm.Auto_Activate", "_xlnm.Auto_Deactivate", "_xlnm.Sheet_Title", "_xlnm._FilterDatabase"];

function Oc(e, r, t) {
    var a = e.l + r,
        i = e.read_shift(2),
        n = e.read_shift(1),
        s = e.read_shift(1),
        o = e.read_shift(t && t.biff == 2 ? 1 : 2),
        c = 0;
    (!t || t.biff >= 5) && (t.biff != 5 && (e.l += 2), c = e.read_shift(2), t.biff == 5 && (e.l += 2), e.l += 4);
    var l = Ra(e, s, t);
    i & 32 && (l = tp[l.charCodeAt(0)]);
    var f = a - e.l;
    t && t.biff == 2 && --f;
    var u = a == e.l || o === 0 || !(f > 0) ? [] : x_(e, f, t, o);
    return {
        chKey: n,
        Name: l,
        itab: c,
        rgce: u
    }
}

function af(e, r, t) {
    if (t.biff < 8) return rp(e, r, t);
    for (var a = [], i = e.l + r, n = e.read_shift(t.biff > 8 ? 4 : 2); n-- !== 0;) a.push(f1(e, t.biff > 8 ? 12 : 6, t));
    if (e.l != i) throw new Error("Bad ExternSheet: " + e.l + " != " + i);
    return a
}

function rp(e, r, t) {
    e[e.l + 1] == 3 && e[e.l]++;
    var a = en(e, r, t);
    return a.charCodeAt(0) == 3 ? a.slice(1) : a
}

function ap(e, r, t) {
    if (t.biff < 8) {
        e.l += r;
        return
    }
    var a = e.read_shift(2),
        i = e.read_shift(2),
        n = Ra(e, a, t),
        s = Ra(e, i, t);
    return [n, s]
}

function ip(e, r, t) {
    var a = tf(e, 6);
    e.l++;
    var i = e.read_shift(1);
    return r -= 8, [g_(e, r, t), i, a]
}

function Dc(e, r, t) {
    var a = d1(e, 6);
    switch (t.biff) {
        case 2:
            e.l++, r -= 7;
            break;
        case 3:
        case 4:
            e.l += 2, r -= 8;
            break;
        default:
            e.l += 6, r -= 12
    }
    return [a, p_(e, r, t, a)]
}

function np(e) {
    var r = e.read_shift(4) !== 0,
        t = e.read_shift(4) !== 0,
        a = e.read_shift(4);
    return [r, t, a]
}

function sp(e, r, t) {
    if (!(t.biff < 8)) {
        var a = e.read_shift(2),
            i = e.read_shift(2),
            n = e.read_shift(2),
            s = e.read_shift(2),
            o = Ha(e, 0, t);
        return t.biff < 8 && e.read_shift(1), [{
            r: a,
            c: i
        }, o, s, n]
    }
}

function op(e, r, t) {
    return sp(e, r, t)
}

function cp(e, r) {
    for (var t = [], a = e.read_shift(2); a--;) t.push(Qn(e, r));
    return t
}

function lp(e) {
    var r = Y(2 + e.length * 8);
    r.write_shift(2, e.length);
    for (var t = 0; t < e.length; ++t) ef(e[t], r);
    return r
}

function fp(e, r, t) {
    if (t && t.biff < 8) return dp(e, r, t);
    var a = rf(e, 22),
        i = x1(e, r - 22, a[1]);
    return {
        cmo: a,
        ft: i
    }
}
var up = {
    8: function(e, r) {
        var t = e.l + r;
        e.l += 10;
        var a = e.read_shift(2);
        e.l += 4, e.l += 2, e.l += 2, e.l += 2, e.l += 4;
        var i = e.read_shift(1);
        return e.l += i, e.l = t, {
            fmt: a
        }
    }
};

function dp(e, r, t) {
    e.l += 4;
    var a = e.read_shift(2),
        i = e.read_shift(2),
        n = e.read_shift(2);
    e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 2, e.l += 6, r -= 36;
    var s = [];
    return s.push((up[a] || jt)(e, r, t)), {
        cmo: [i, a, n],
        ft: s
    }
}

function hp(e, r, t) {
    var a = e.l,
        i = "";
    try {
        e.l += 4;
        var n = (t.lastobj || {
                cmo: [0, 0]
            }).cmo[1],
            s;
        [0, 5, 7, 11, 12, 14].indexOf(n) == -1 ? e.l += 6 : s = r1(e, 6, t);
        var o = e.read_shift(2);
        e.read_shift(2), bt(e, 2);
        var c = e.read_shift(2);
        e.l += c;
        for (var l = 1; l < e.lens.length - 1; ++l) {
            if (e.l - a != e.lens[l]) throw new Error("TxO: bad continue record");
            var f = e[e.l],
                u = Ra(e, e.lens[l + 1] - e.lens[l] - 1);
            if (i += u, i.length >= (f ? o : 2 * o)) break
        }
        if (i.length !== o && i.length !== o * 2) throw new Error("cchText: " + o + " != " + i.length);
        return e.l = a + r, {
            t: i
        }
    } catch (h) {
        return e.l = a + r, {
            t: i
        }
    }
}

function pp(e, r) {
    var t = Qn(e, 8);
    e.l += 16;
    var a = s1(e, r - 24);
    return [t, a]
}

function mp(e) {
    var r = Y(24),
        t = pt(e[0]);
    r.write_shift(2, t.r), r.write_shift(2, t.r), r.write_shift(2, t.c), r.write_shift(2, t.c);
    for (var a = "d0 c9 ea 79 f9 ba ce 11 8c 82 00 aa 00 4b a9 0b".split(" "), i = 0; i < 16; ++i) r.write_shift(1, parseInt(a[i], 16));
    return Pt([r, o1(e[1])])
}

function xp(e, r) {
    e.read_shift(2);
    var t = Qn(e, 8),
        a = e.read_shift((r - 10) / 2, "dbcs-cont");
    return a = a.replace(Xt, ""), [t, a]
}

function gp(e) {
    var r = e[1].Tooltip,
        t = Y(10 + 2 * (r.length + 1));
    t.write_shift(2, 2048);
    var a = pt(e[0]);
    t.write_shift(2, a.r), t.write_shift(2, a.r), t.write_shift(2, a.c), t.write_shift(2, a.c);
    for (var i = 0; i < r.length; ++i) t.write_shift(2, r.charCodeAt(i));
    return t.write_shift(2, 0), t
}

function _p(e) {
    var r = [0, 0],
        t;
    return t = e.read_shift(2), r[0] = gc[t] || t, t = e.read_shift(2), r[1] = gc[t] || t, r
}

function vp(e) {
    return e || (e = Y(4)), e.write_shift(2, 1), e.write_shift(2, 1), e
}

function wp(e) {
    for (var r = e.read_shift(2), t = []; r-- > 0;) t.push(Zl(e, 8));
    return t
}

function Sp(e) {
    for (var r = e.read_shift(2), t = []; r-- > 0;) t.push(Zl(e, 8));
    return t
}

function Ep(e) {
    e.l += 2;
    var r = {
        cxfs: 0,
        crc: 0
    };
    return r.cxfs = e.read_shift(2), r.crc = e.read_shift(4), r
}

function nf(e, r, t) {
    if (!t.cellStyles) return jt(e, r);
    var a = t && t.biff >= 12 ? 4 : 2,
        i = e.read_shift(a),
        n = e.read_shift(a),
        s = e.read_shift(a),
        o = e.read_shift(a),
        c = e.read_shift(2);
    a == 2 && (e.l += 2);
    var l = {
        s: i,
        e: n,
        w: s,
        ixfe: o,
        flags: c
    };
    return (t.biff >= 5 || !t.biff) && (l.level = c >> 8 & 7), l
}

function Cp(e, r) {
    var t = Y(12);
    t.write_shift(2, r), t.write_shift(2, r), t.write_shift(2, e.width * 256), t.write_shift(2, 0);
    var a = 0;
    return e.hidden && (a |= 1), t.write_shift(1, a), a = e.level || 0, t.write_shift(1, a), t.write_shift(2, 0), t
}

function Tp(e, r) {
    var t = {};
    return r < 32 || (e.l += 16, t.header = zt(e, 8), t.footer = zt(e, 8), e.l += 2), t
}

function yp(e, r, t) {
    var a = {
        area: !1
    };
    if (t.biff != 5) return e.l += r, a;
    var i = e.read_shift(1);
    return e.l += 3, i & 16 && (a.area = !0), a
}

function kp(e) {
    for (var r = Y(2 * e), t = 0; t < e; ++t) r.write_shift(2, t + 1);
    return r
}
var Fp = qr,
    Ap = $l,
    bp = tn;

function Ip(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(4),
        i = {
            fmt: r,
            env: t,
            len: a,
            data: e.slice(e.l, e.l + a)
        };
    return e.l += a, i
}

function Mp(e, r, t) {
    t.biffguess && t.biff == 5 && (t.biff = 2);
    var a = qr(e, 6);
    ++e.l;
    var i = Ha(e, r - 7, t);
    return a.t = "str", a.val = i, a
}

function Op(e) {
    var r = qr(e, 6);
    ++e.l;
    var t = zt(e, 8);
    return r.t = "n", r.val = t, r
}

function Dp(e, r, t) {
    var a = Y(15);
    return sn(a, e, r), a.write_shift(8, t, "f"), a
}

function Rp(e) {
    var r = qr(e, 6);
    ++e.l;
    var t = e.read_shift(2);
    return r.t = "n", r.val = t, r
}

function Pp(e, r, t) {
    var a = Y(9);
    return sn(a, e, r), a.write_shift(2, t), a
}

function Np(e) {
    var r = e.read_shift(1);
    return r === 0 ? (e.l++, "") : e.read_shift(r, "sbcs-cont")
}

function Lp(e, r) {
    e.l += 6, e.l += 2, e.l += 1, e.l += 3, e.l += 1, e.l += r - 13
}

function Bp(e, r, t) {
    var a = e.l + r,
        i = qr(e, 6),
        n = e.read_shift(2),
        s = Ra(e, n, t);
    return e.l = a, i.t = "str", i.val = s, i
}
var Up = [2, 3, 48, 49, 131, 139, 140, 245],
    Ws = (function() {
        var e = {
                1: 437,
                2: 850,
                3: 1252,
                4: 1e4,
                100: 852,
                101: 866,
                102: 865,
                103: 861,
                104: 895,
                105: 620,
                106: 737,
                107: 857,
                120: 950,
                121: 949,
                122: 936,
                123: 932,
                124: 874,
                125: 1255,
                126: 1256,
                150: 10007,
                151: 10029,
                152: 10006,
                200: 1250,
                201: 1251,
                202: 1254,
                203: 1253,
                0: 20127,
                8: 865,
                9: 437,
                10: 850,
                11: 437,
                13: 437,
                14: 850,
                15: 437,
                16: 850,
                17: 437,
                18: 850,
                19: 932,
                20: 850,
                21: 437,
                22: 850,
                23: 865,
                24: 437,
                25: 437,
                26: 850,
                27: 437,
                28: 863,
                29: 850,
                31: 852,
                34: 852,
                35: 852,
                36: 860,
                37: 850,
                38: 866,
                55: 850,
                64: 852,
                77: 936,
                78: 949,
                79: 950,
                80: 874,
                87: 1252,
                88: 1252,
                89: 1252,
                108: 863,
                134: 737,
                135: 852,
                136: 857,
                204: 1257,
                255: 16969
            },
            r = Yn({
                1: 437,
                2: 850,
                3: 1252,
                4: 1e4,
                100: 852,
                101: 866,
                102: 865,
                103: 861,
                104: 895,
                105: 620,
                106: 737,
                107: 857,
                120: 950,
                121: 949,
                122: 936,
                123: 932,
                124: 874,
                125: 1255,
                126: 1256,
                150: 10007,
                151: 10029,
                152: 10006,
                200: 1250,
                201: 1251,
                202: 1254,
                203: 1253,
                0: 20127
            });

        function t(o, c) {
            var l = [],
                f = pa(1);
            switch (c.type) {
                case "base64":
                    f = dr(pr(o));
                    break;
                case "binary":
                    f = dr(o);
                    break;
                case "buffer":
                case "array":
                    f = o;
                    break
            }
            Bt(f, 0);
            var u = f.read_shift(1),
                h = !!(u & 136),
                p = !1,
                m = !1;
            switch (u) {
                case 2:
                    break;
                case 3:
                    break;
                case 48:
                    p = !0, h = !0;
                    break;
                case 49:
                    p = !0, h = !0;
                    break;
                case 131:
                    break;
                case 139:
                    break;
                case 140:
                    m = !0;
                    break;
                case 245:
                    break;
                default:
                    throw new Error("DBF Unsupported Version: " + u.toString(16))
            }
            var d = 0,
                x = 521;
            u == 2 && (d = f.read_shift(2)), f.l += 3, u != 2 && (d = f.read_shift(4)), d > 1048576 && (d = 1e6), u != 2 && (x = f.read_shift(2));
            var E = f.read_shift(2),
                S = c.codepage || 1252;
            u != 2 && (f.l += 16, f.read_shift(1), f[f.l] !== 0 && (S = e[f[f.l]]), f.l += 1, f.l += 2), m && (f.l += 36);
            for (var _ = [], L = {}, U = Math.min(f.length, u == 2 ? 521 : x - 10 - (p ? 264 : 0)), R = m ? 32 : 11; f.l < U && f[f.l] != 13;) switch (L = {}, L.name = Ye.utils.decode(S, f.slice(f.l, f.l + R)).replace(/[\u0000\r\n].*$/g, ""), f.l += R, L.type = String.fromCharCode(f.read_shift(1)), u != 2 && !m && (L.offset = f.read_shift(4)), L.len = f.read_shift(1), u == 2 && (L.offset = f.read_shift(2)), L.dec = f.read_shift(1), L.name.length && _.push(L), u != 2 && (f.l += m ? 13 : 14), L.type) {
                case "B":
                    (!p || L.len != 8) && c.WTF && console.log("Skipping " + L.name + ":" + L.type);
                    break;
                case "G":
                case "P":
                    c.WTF && console.log("Skipping " + L.name + ":" + L.type);
                    break;
                case "+":
                case "0":
                case "@":
                case "C":
                case "D":
                case "F":
                case "I":
                case "L":
                case "M":
                case "N":
                case "O":
                case "T":
                case "Y":
                    break;
                default:
                    throw new Error("Unknown Field Type: " + L.type)
            }
            if (f[f.l] !== 13 && (f.l = x - 1), f.read_shift(1) !== 13) throw new Error("DBF Terminator not found " + f.l + " " + f[f.l]);
            f.l = x;
            var T = 0,
                N = 0;
            for (l[0] = [], N = 0; N != _.length; ++N) l[0][N] = _[N].name;
            for (; d-- > 0;) {
                if (f[f.l] === 42) {
                    f.l += E;
                    continue
                }
                for (++f.l, l[++T] = [], N = 0, N = 0; N != _.length; ++N) {
                    var P = f.slice(f.l, f.l + _[N].len);
                    f.l += _[N].len, Bt(P, 0);
                    var X = Ye.utils.decode(S, P);
                    switch (_[N].type) {
                        case "C":
                            X.trim().length && (l[T][N] = X.replace(/\s+$/, ""));
                            break;
                        case "D":
                            X.length === 8 ? l[T][N] = new Date(+X.slice(0, 4), +X.slice(4, 6) - 1, +X.slice(6, 8)) : l[T][N] = X;
                            break;
                        case "F":
                            l[T][N] = parseFloat(X.trim());
                            break;
                        case "+":
                        case "I":
                            l[T][N] = m ? P.read_shift(-4, "i") ^ 2147483648 : P.read_shift(4, "i");
                            break;
                        case "L":
                            switch (X.trim().toUpperCase()) {
                                case "Y":
                                case "T":
                                    l[T][N] = !0;
                                    break;
                                case "N":
                                case "F":
                                    l[T][N] = !1;
                                    break;
                                case "":
                                case "?":
                                    break;
                                default:
                                    throw new Error("DBF Unrecognized L:|" + X + "|")
                            }
                            break;
                        case "M":
                            if (!h) throw new Error("DBF Unexpected MEMO for type " + u.toString(16));
                            l[T][N] = "##MEMO##" + (m ? parseInt(X.trim(), 10) : P.read_shift(4));
                            break;
                        case "N":
                            X = X.replace(/\u0000/g, "").trim(), X && X != "." && (l[T][N] = +X || 0);
                            break;
                        case "@":
                            l[T][N] = new Date(P.read_shift(-8, "f") - 621356832e5);
                            break;
                        case "T":
                            l[T][N] = new Date((P.read_shift(4) - 2440588) * 864e5 + P.read_shift(4));
                            break;
                        case "Y":
                            l[T][N] = P.read_shift(4, "i") / 1e4 + P.read_shift(4, "i") / 1e4 * Math.pow(2, 32);
                            break;
                        case "O":
                            l[T][N] = -P.read_shift(-8, "f");
                            break;
                        case "B":
                            if (p && _[N].len == 8) {
                                l[T][N] = P.read_shift(8, "f");
                                break
                            }
                        case "G":
                        case "P":
                            P.l += _[N].len;
                            break;
                        case "0":
                            if (_[N].name === "_NullFlags") break;
                        default:
                            throw new Error("DBF Unsupported data type " + _[N].type)
                    }
                }
            }
            if (u != 2 && f.l < f.length && f[f.l++] != 26) throw new Error("DBF EOF Marker missing " + (f.l - 1) + " of " + f.length + " " + f[f.l - 1].toString(16));
            return c && c.sheetRows && (l = l.slice(0, c.sheetRows)), c.DBF = _, l
        }

        function a(o, c) {
            var l = c || {};
            l.dateNF || (l.dateNF = "yyyymmdd");
            var f = di(t(o, l), l);
            return f["!cols"] = l.DBF.map(function(u) {
                return {
                    wch: u.len,
                    DBF: u
                }
            }), delete l.DBF, f
        }

        function i(o, c) {
            try {
                return va(a(o, c), c)
            } catch (l) {
                if (c && c.WTF) throw l
            }
            return {
                SheetNames: [],
                Sheets: {}
            }
        }
        var n = {
            B: 8,
            C: 250,
            L: 1,
            D: 8,
            "?": 0,
            "": 0
        };

        function s(o, c) {
            var l = c || {};
            if (+l.codepage >= 0 && Rr(+l.codepage), l.type == "string") throw new Error("Cannot write DBF to JS string");
            var f = sr(),
                u = qn(o, {
                    header: 1,
                    raw: !0,
                    cellDates: !0
                }),
                h = u[0],
                p = u.slice(1),
                m = o["!cols"] || [],
                d = 0,
                x = 0,
                E = 0,
                S = 1;
            for (d = 0; d < h.length; ++d) {
                if (((m[d] || {}).DBF || {}).name) {
                    h[d] = m[d].DBF.name, ++E;
                    continue
                }
                if (h[d] != null) {
                    if (++E, typeof h[d] == "number" && (h[d] = h[d].toString(10)), typeof h[d] != "string") throw new Error("DBF Invalid column name " + h[d] + " |" + typeof h[d] + "|");
                    if (h.indexOf(h[d]) !== d) {
                        for (x = 0; x < 1024; ++x)
                            if (h.indexOf(h[d] + "_" + x) == -1) {
                                h[d] += "_" + x;
                                break
                            }
                    }
                }
            }
            var _ = Xe(o["!ref"]),
                L = [],
                U = [],
                R = [];
            for (d = 0; d <= _.e.c - _.s.c; ++d) {
                var T = "",
                    N = "",
                    P = 0,
                    X = [];
                for (x = 0; x < p.length; ++x) p[x][d] != null && X.push(p[x][d]);
                if (X.length == 0 || h[d] == null) {
                    L[d] = "?";
                    continue
                }
                for (x = 0; x < X.length; ++x) {
                    switch (typeof X[x]) {
                        case "number":
                            N = "B";
                            break;
                        case "string":
                            N = "C";
                            break;
                        case "boolean":
                            N = "L";
                            break;
                        case "object":
                            N = X[x] instanceof Date ? "D" : "C";
                            break;
                        default:
                            N = "C"
                    }
                    P = Math.max(P, String(X[x]).length), T = T && T != N ? "C" : N
                }
                P > 250 && (P = 250), N = ((m[d] || {}).DBF || {}).type, N == "C" && m[d].DBF.len > P && (P = m[d].DBF.len), T == "B" && N == "N" && (T = "N", R[d] = m[d].DBF.dec, P = m[d].DBF.len), U[d] = T == "C" || N == "N" ? P : n[T] || 0, S += U[d], L[d] = T
            }
            var j = f.next(32);
            for (j.write_shift(4, 318902576), j.write_shift(4, p.length), j.write_shift(2, 296 + 32 * E), j.write_shift(2, S), d = 0; d < 4; ++d) j.write_shift(4, 0);
            for (j.write_shift(4, 0 | (+r[ni] || 3) << 8), d = 0, x = 0; d < h.length; ++d)
                if (h[d] != null) {
                    var B = f.next(32),
                        se = (h[d].slice(-10) + "\0\0\0\0\0\0\0\0\0\0\0").slice(0, 11);
                    B.write_shift(1, se, "sbcs"), B.write_shift(1, L[d] == "?" ? "C" : L[d], "sbcs"), B.write_shift(4, x), B.write_shift(1, U[d] || n[L[d]] || 0), B.write_shift(1, R[d] || 0), B.write_shift(1, 2), B.write_shift(4, 0), B.write_shift(1, 0), B.write_shift(4, 0), B.write_shift(4, 0), x += U[d] || n[L[d]] || 0
                }
            var _e = f.next(264);
            for (_e.write_shift(4, 13), d = 0; d < 65; ++d) _e.write_shift(4, 0);
            for (d = 0; d < p.length; ++d) {
                var oe = f.next(S);
                for (oe.write_shift(1, 0), x = 0; x < h.length; ++x)
                    if (h[x] != null) switch (L[x]) {
                        case "L":
                            oe.write_shift(1, p[d][x] == null ? 63 : p[d][x] ? 84 : 70);
                            break;
                        case "B":
                            oe.write_shift(8, p[d][x] || 0, "f");
                            break;
                        case "N":
                            var ke = "0";
                            for (typeof p[d][x] == "number" && (ke = p[d][x].toFixed(R[x] || 0)), E = 0; E < U[x] - ke.length; ++E) oe.write_shift(1, 32);
                            oe.write_shift(1, ke, "sbcs");
                            break;
                        case "D":
                            p[d][x] ? (oe.write_shift(4, ("0000" + p[d][x].getFullYear()).slice(-4), "sbcs"), oe.write_shift(2, ("00" + (p[d][x].getMonth() + 1)).slice(-2), "sbcs"), oe.write_shift(2, ("00" + p[d][x].getDate()).slice(-2), "sbcs")) : oe.write_shift(8, "00000000", "sbcs");
                            break;
                        case "C":
                            var Se = String(p[d][x] != null ? p[d][x] : "").slice(0, U[x]);
                            for (oe.write_shift(1, Se, "sbcs"), E = 0; E < U[x] - Se.length; ++E) oe.write_shift(1, 32);
                            break
                    }
            }
            return f.next(1).write_shift(1, 26), f.end()
        }
        return {
            to_workbook: i,
            to_sheet: a,
            from_sheet: s
        }
    })(),
    sf = (function() {
        var e = {
                AA: "\xC0",
                BA: "\xC1",
                CA: "\xC2",
                DA: 195,
                HA: "\xC4",
                JA: 197,
                AE: "\xC8",
                BE: "\xC9",
                CE: "\xCA",
                HE: "\xCB",
                AI: "\xCC",
                BI: "\xCD",
                CI: "\xCE",
                HI: "\xCF",
                AO: "\xD2",
                BO: "\xD3",
                CO: "\xD4",
                DO: 213,
                HO: "\xD6",
                AU: "\xD9",
                BU: "\xDA",
                CU: "\xDB",
                HU: "\xDC",
                Aa: "\xE0",
                Ba: "\xE1",
                Ca: "\xE2",
                Da: 227,
                Ha: "\xE4",
                Ja: 229,
                Ae: "\xE8",
                Be: "\xE9",
                Ce: "\xEA",
                He: "\xEB",
                Ai: "\xEC",
                Bi: "\xED",
                Ci: "\xEE",
                Hi: "\xEF",
                Ao: "\xF2",
                Bo: "\xF3",
                Co: "\xF4",
                Do: 245,
                Ho: "\xF6",
                Au: "\xF9",
                Bu: "\xFA",
                Cu: "\xFB",
                Hu: "\xFC",
                KC: "\xC7",
                Kc: "\xE7",
                q: "\xE6",
                z: "\u0153",
                a: "\xC6",
                j: "\u0152",
                DN: 209,
                Dn: 241,
                Hy: 255,
                S: 169,
                c: 170,
                R: 174,
                "B ": 180,
                0: 176,
                1: 177,
                2: 178,
                3: 179,
                5: 181,
                6: 182,
                7: 183,
                Q: 185,
                k: 186,
                b: 208,
                i: 216,
                l: 222,
                s: 240,
                y: 248,
                "!": 161,
                '"': 162,
                "#": 163,
                "(": 164,
                "%": 165,
                "'": 167,
                "H ": 168,
                "+": 171,
                ";": 187,
                "<": 188,
                "=": 189,
                ">": 190,
                "?": 191,
                "{": 223
            },
            r = new RegExp("\x1BN(" + vt(e).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1") + "|\\|)", "gm"),
            t = function(h, p) {
                var m = e[p];
                return typeof m == "number" ? zo(m) : m
            },
            a = function(h, p, m) {
                var d = p.charCodeAt(0) - 32 << 4 | m.charCodeAt(0) - 48;
                return d == 59 ? h : zo(d)
            };
        e["|"] = 254;

        function i(h, p) {
            switch (p.type) {
                case "base64":
                    return n(pr(h), p);
                case "binary":
                    return n(h, p);
                case "buffer":
                    return n(Ue && Buffer.isBuffer(h) ? h.toString("binary") : _a(h), p);
                case "array":
                    return n(Oa(h), p)
            }
            throw new Error("Unrecognized type " + p.type)
        }

        function n(h, p) {
            var m = h.split(/[\n\r]+/),
                d = -1,
                x = -1,
                E = 0,
                S = 0,
                _ = [],
                L = [],
                U = null,
                R = {},
                T = [],
                N = [],
                P = [],
                X = 0,
                j;
            for (+p.codepage >= 0 && Rr(+p.codepage); E !== m.length; ++E) {
                X = 0;
                var B = m[E].trim().replace(/\x1B([\x20-\x2F])([\x30-\x3F])/g, a).replace(r, t),
                    se = B.replace(/;;/g, "\0").split(";").map(function(M) {
                        return M.replace(/\u0000/g, ";")
                    }),
                    _e = se[0],
                    oe;
                if (B.length > 0) switch (_e) {
                    case "ID":
                        break;
                    case "E":
                        break;
                    case "B":
                        break;
                    case "O":
                        break;
                    case "W":
                        break;
                    case "P":
                        se[1].charAt(0) == "P" && L.push(B.slice(3).replace(/;;/g, ";"));
                        break;
                    case "C":
                        var ke = !1,
                            Se = !1,
                            Ve = !1,
                            me = !1,
                            Te = -1,
                            Z = -1;
                        for (S = 1; S < se.length; ++S) switch (se[S].charAt(0)) {
                            case "A":
                                break;
                            case "X":
                                x = parseInt(se[S].slice(1)) - 1, Se = !0;
                                break;
                            case "Y":
                                for (d = parseInt(se[S].slice(1)) - 1, Se || (x = 0), j = _.length; j <= d; ++j) _[j] = [];
                                break;
                            case "K":
                                oe = se[S].slice(1), oe.charAt(0) === '"' ? oe = oe.slice(1, oe.length - 1) : oe === "TRUE" ? oe = !0 : oe === "FALSE" ? oe = !1 : isNaN(Nr(oe)) ? isNaN(si(oe).getDate()) || (oe = ft(oe)) : (oe = Nr(oe), U !== null && li(U) && (oe = Jn(oe))), typeof Ye < "u" && typeof oe == "string" && (p || {}).type != "string" && (p || {}).codepage && (oe = Ye.utils.decode(p.codepage, oe)), ke = !0;
                                break;
                            case "E":
                                me = !0;
                                var b = ai(se[S].slice(1), {
                                    r: d,
                                    c: x
                                });
                                _[d][x] = [_[d][x], b];
                                break;
                            case "S":
                                Ve = !0, _[d][x] = [_[d][x], "S5S"];
                                break;
                            case "G":
                                break;
                            case "R":
                                Te = parseInt(se[S].slice(1)) - 1;
                                break;
                            case "C":
                                Z = parseInt(se[S].slice(1)) - 1;
                                break;
                            default:
                                if (p && p.WTF) throw new Error("SYLK bad record " + B)
                        }
                        if (ke && (_[d][x] && _[d][x].length == 2 ? _[d][x][0] = oe : _[d][x] = oe, U = null), Ve) {
                            if (me) throw new Error("SYLK shared formula cannot have own formula");
                            var H = Te > -1 && _[Te][Z];
                            if (!H || !H[1]) throw new Error("SYLK shared formula cannot find base");
                            _[d][x][1] = Tf(H[1], {
                                r: d - Te,
                                c: x - Z
                            })
                        }
                        break;
                    case "F":
                        var O = 0;
                        for (S = 1; S < se.length; ++S) switch (se[S].charAt(0)) {
                            case "X":
                                x = parseInt(se[S].slice(1)) - 1, ++O;
                                break;
                            case "Y":
                                for (d = parseInt(se[S].slice(1)) - 1, j = _.length; j <= d; ++j) _[j] = [];
                                break;
                            case "M":
                                X = parseInt(se[S].slice(1)) / 20;
                                break;
                            case "F":
                                break;
                            case "G":
                                break;
                            case "P":
                                U = L[parseInt(se[S].slice(1))];
                                break;
                            case "S":
                                break;
                            case "D":
                                break;
                            case "N":
                                break;
                            case "W":
                                for (P = se[S].slice(1).split(" "), j = parseInt(P[0], 10); j <= parseInt(P[1], 10); ++j) X = parseInt(P[2], 10), N[j - 1] = X === 0 ? {
                                    hidden: !0
                                } : {
                                    wch: X
                                }, ma(N[j - 1]);
                                break;
                            case "C":
                                x = parseInt(se[S].slice(1)) - 1, N[x] || (N[x] = {});
                                break;
                            case "R":
                                d = parseInt(se[S].slice(1)) - 1, T[d] || (T[d] = {}), X > 0 ? (T[d].hpt = X, T[d].hpx = ci(X)) : X === 0 && (T[d].hidden = !0);
                                break;
                            default:
                                if (p && p.WTF) throw new Error("SYLK bad record " + B)
                        }
                        O < 1 && (U = null);
                        break;
                    default:
                        if (p && p.WTF) throw new Error("SYLK bad record " + B)
                }
            }
            return T.length > 0 && (R["!rows"] = T), N.length > 0 && (R["!cols"] = N), p && p.sheetRows && (_ = _.slice(0, p.sheetRows)), [_, R]
        }

        function s(h, p) {
            var m = i(h, p),
                d = m[0],
                x = m[1],
                E = di(d, p);
            return vt(x).forEach(function(S) {
                E[S] = x[S]
            }), E
        }

        function o(h, p) {
            return va(s(h, p), p)
        }

        function c(h, p, m, d) {
            var x = "C;Y" + (m + 1) + ";X" + (d + 1) + ";K";
            switch (h.t) {
                case "n":
                    x += h.v || 0, h.f && !h.F && (x += ";E" + T0(h.f, {
                        r: m,
                        c: d
                    }));
                    break;
                case "b":
                    x += h.v ? "TRUE" : "FALSE";
                    break;
                case "e":
                    x += h.w || h.v;
                    break;
                case "d":
                    x += '"' + (h.w || h.v) + '"';
                    break;
                case "s":
                    x += '"' + h.v.replace(/"/g, "").replace(/;/g, ";;") + '"';
                    break
            }
            return x
        }

        function l(h, p) {
            p.forEach(function(m, d) {
                var x = "F;W" + (d + 1) + " " + (d + 1) + " ";
                m.hidden ? x += "0" : (typeof m.width == "number" && !m.wpx && (m.wpx = ji(m.width)), typeof m.wpx == "number" && !m.wch && (m.wch = $i(m.wpx)), typeof m.wch == "number" && (x += Math.round(m.wch))), x.charAt(x.length - 1) != " " && h.push(x)
            })
        }

        function f(h, p) {
            p.forEach(function(m, d) {
                var x = "F;";
                m.hidden ? x += "M0;" : m.hpt ? x += "M" + 20 * m.hpt + ";" : m.hpx && (x += "M" + 20 * Yi(m.hpx) + ";"), x.length > 2 && h.push(x + "R" + (d + 1))
            })
        }

        function u(h, p) {
            var m = ["ID;PWXL;N;E"],
                d = [],
                x = Xe(h["!ref"]),
                E, S = Array.isArray(h),
                _ = `\r
`;
            m.push("P;PGeneral"), m.push("F;P0;DG0G8;M255"), h["!cols"] && l(m, h["!cols"]), h["!rows"] && f(m, h["!rows"]), m.push("B;Y" + (x.e.r - x.s.r + 1) + ";X" + (x.e.c - x.s.c + 1) + ";D" + [x.s.c, x.s.r, x.e.c, x.e.r].join(" "));
            for (var L = x.s.r; L <= x.e.r; ++L)
                for (var U = x.s.c; U <= x.e.c; ++U) {
                    var R = Me({
                        r: L,
                        c: U
                    });
                    E = S ? (h[L] || [])[U] : h[R], !(!E || E.v == null && (!E.f || E.F)) && d.push(c(E, h, L, U, p))
                }
            return m.join(_) + _ + d.join(_) + _ + "E" + _
        }
        return {
            to_workbook: o,
            to_sheet: s,
            from_sheet: u
        }
    })(),
    of = (function() {
        function e(n, s) {
            switch (s.type) {
                case "base64":
                    return r(pr(n), s);
                case "binary":
                    return r(n, s);
                case "buffer":
                    return r(Ue && Buffer.isBuffer(n) ? n.toString("binary") : _a(n), s);
                case "array":
                    return r(Oa(n), s)
            }
            throw new Error("Unrecognized type " + s.type)
        }

        function r(n, s) {
            for (var o = n.split(`
`), c = -1, l = -1, f = 0, u = []; f !== o.length; ++f) {
                if (o[f].trim() === "BOT") {
                    u[++c] = [], l = 0;
                    continue
                }
                if (!(c < 0)) {
                    var h = o[f].trim().split(","),
                        p = h[0],
                        m = h[1];
                    ++f;
                    for (var d = o[f] || "";
                        (d.match(/["]/g) || []).length & 1 && f < o.length - 1;) d += `
` + o[++f];
                    switch (d = d.trim(), +p) {
                        case -1:
                            if (d === "BOT") {
                                u[++c] = [], l = 0;
                                continue
                            } else if (d !== "EOD") throw new Error("Unrecognized DIF special command " + d);
                            break;
                        case 0:
                            d === "TRUE" ? u[c][l] = !0 : d === "FALSE" ? u[c][l] = !1 : isNaN(Nr(m)) ? isNaN(si(m).getDate()) ? u[c][l] = m : u[c][l] = ft(m) : u[c][l] = Nr(m), ++l;
                            break;
                        case 1:
                            d = d.slice(1, d.length - 1), d = d.replace(/""/g, '"'), ki && d && d.match(/^=".*"$/) && (d = d.slice(2, -1)), u[c][l++] = d !== "" ? d : null;
                            break
                    }
                    if (d === "EOD") break
                }
            }
            return s && s.sheetRows && (u = u.slice(0, s.sheetRows)), u
        }

        function t(n, s) {
            return di(e(n, s), s)
        }

        function a(n, s) {
            return va(t(n, s), s)
        }
        var i = (function() {
            var n = function(c, l, f, u, h) {
                    c.push(l), c.push(f + "," + u), c.push('"' + h.replace(/"/g, '""') + '"')
                },
                s = function(c, l, f, u) {
                    c.push(l + "," + f), c.push(l == 1 ? '"' + u.replace(/"/g, '""') + '"' : u)
                };
            return function(c) {
                var l = [],
                    f = Xe(c["!ref"]),
                    u, h = Array.isArray(c);
                n(l, "TABLE", 0, 1, "sheetjs"), n(l, "VECTORS", 0, f.e.r - f.s.r + 1, ""), n(l, "TUPLES", 0, f.e.c - f.s.c + 1, ""), n(l, "DATA", 0, 0, "");
                for (var p = f.s.r; p <= f.e.r; ++p) {
                    s(l, -1, 0, "BOT");
                    for (var m = f.s.c; m <= f.e.c; ++m) {
                        var d = Me({
                            r: p,
                            c: m
                        });
                        if (u = h ? (c[p] || [])[m] : c[d], !u) {
                            s(l, 1, 0, "");
                            continue
                        }
                        switch (u.t) {
                            case "n":
                                var x = ki ? u.w : u.v;
                                !x && u.v != null && (x = u.v), x == null ? ki && u.f && !u.F ? s(l, 1, 0, "=" + u.f) : s(l, 1, 0, "") : s(l, 0, x, "V");
                                break;
                            case "b":
                                s(l, 0, u.v ? 1 : 0, u.v ? "TRUE" : "FALSE");
                                break;
                            case "s":
                                s(l, 1, 0, !ki || isNaN(u.v) ? u.v : '="' + u.v + '"');
                                break;
                            case "d":
                                u.w || (u.w = Ir(u.z || Ie[14], Ot(ft(u.v)))), ki ? s(l, 0, u.w, "V") : s(l, 1, 0, u.w);
                                break;
                            default:
                                s(l, 1, 0, "")
                        }
                    }
                }
                s(l, -1, 0, "EOD");
                var E = `\r
`,
                    S = l.join(E);
                return S
            }
        })();
        return {
            to_workbook: a,
            to_sheet: t,
            from_sheet: i
        }
    })(),
    cf = (function() {
        function e(u) {
            return u.replace(/\\b/g, "\\").replace(/\\c/g, ":").replace(/\\n/g, `
`)
        }

        function r(u) {
            return u.replace(/\\/g, "\\b").replace(/:/g, "\\c").replace(/\n/g, "\\n")
        }

        function t(u, h) {
            for (var p = u.split(`
`), m = -1, d = -1, x = 0, E = []; x !== p.length; ++x) {
                var S = p[x].trim().split(":");
                if (S[0] === "cell") {
                    var _ = pt(S[1]);
                    if (E.length <= _.r)
                        for (m = E.length; m <= _.r; ++m) E[m] || (E[m] = []);
                    switch (m = _.r, d = _.c, S[2]) {
                        case "t":
                            E[m][d] = e(S[3]);
                            break;
                        case "v":
                            E[m][d] = +S[3];
                            break;
                        case "vtf":
                            var L = S[S.length - 1];
                        case "vtc":
                            S[3] === "nl" ? E[m][d] = !!+S[4] : E[m][d] = +S[4], S[2] == "vtf" && (E[m][d] = [E[m][d], L])
                    }
                }
            }
            return h && h.sheetRows && (E = E.slice(0, h.sheetRows)), E
        }

        function a(u, h) {
            return di(t(u, h), h)
        }

        function i(u, h) {
            return va(a(u, h), h)
        }
        var n = ["socialcalc:version:1.5", "MIME-Version: 1.0", "Content-Type: multipart/mixed; boundary=SocialCalcSpreadsheetControlSave"].join(`
`),
            s = ["--SocialCalcSpreadsheetControlSave", "Content-type: text/plain; charset=UTF-8"].join(`
`) + `
`,
            o = ["# SocialCalc Spreadsheet Control Save", "part:sheet"].join(`
`),
            c = "--SocialCalcSpreadsheetControlSave--";

        function l(u) {
            if (!u || !u["!ref"]) return "";
            for (var h = [], p = [], m, d = "", x = or(u["!ref"]), E = Array.isArray(u), S = x.s.r; S <= x.e.r; ++S)
                for (var _ = x.s.c; _ <= x.e.c; ++_)
                    if (d = Me({
                            r: S,
                            c: _
                        }), m = E ? (u[S] || [])[_] : u[d], !(!m || m.v == null || m.t === "z")) {
                        switch (p = ["cell", d, "t"], m.t) {
                            case "s":
                            case "str":
                                p.push(r(m.v));
                                break;
                            case "n":
                                m.f ? (p[2] = "vtf", p[3] = "n", p[4] = m.v, p[5] = r(m.f)) : (p[2] = "v", p[3] = m.v);
                                break;
                            case "b":
                                p[2] = "vt" + (m.f ? "f" : "c"), p[3] = "nl", p[4] = m.v ? "1" : "0", p[5] = r(m.f || (m.v ? "TRUE" : "FALSE"));
                                break;
                            case "d":
                                var L = Ot(ft(m.v));
                                p[2] = "vtc", p[3] = "nd", p[4] = "" + L, p[5] = m.w || Ir(m.z || Ie[14], L);
                                break;
                            case "e":
                                continue
                        }
                        h.push(p.join(":"))
                    }
            return h.push("sheet:c:" + (x.e.c - x.s.c + 1) + ":r:" + (x.e.r - x.s.r + 1) + ":tvf:1"), h.push("valueformat:1:text-wiki"), h.join(`
`)
        }

        function f(u) {
            return [n, s, o, s, l(u), c].join(`
`)
        }
        return {
            to_workbook: i,
            to_sheet: a,
            from_sheet: f
        }
    })(),
    oi = (function() {
        function e(f, u, h, p, m) {
            m.raw ? u[h][p] = f : f === "" || (f === "TRUE" ? u[h][p] = !0 : f === "FALSE" ? u[h][p] = !1 : isNaN(Nr(f)) ? isNaN(si(f).getDate()) ? u[h][p] = f : u[h][p] = ft(f) : u[h][p] = Nr(f))
        }

        function r(f, u) {
            var h = u || {},
                p = [];
            if (!f || f.length === 0) return p;
            for (var m = f.split(/[\r\n]/), d = m.length - 1; d >= 0 && m[d].length === 0;) --d;
            for (var x = 10, E = 0, S = 0; S <= d; ++S) E = m[S].indexOf(" "), E == -1 ? E = m[S].length : E++, x = Math.max(x, E);
            for (S = 0; S <= d; ++S) {
                p[S] = [];
                var _ = 0;
                for (e(m[S].slice(0, x).trim(), p, S, _, h), _ = 1; _ <= (m[S].length - x) / 10 + 1; ++_) e(m[S].slice(x + (_ - 1) * 10, x + _ * 10).trim(), p, S, _, h)
            }
            return h.sheetRows && (p = p.slice(0, h.sheetRows)), p
        }
        var t = {
                44: ",",
                9: "	",
                59: ";",
                124: "|"
            },
            a = {
                44: 3,
                9: 2,
                59: 1,
                124: 0
            };

        function i(f) {
            for (var u = {}, h = !1, p = 0, m = 0; p < f.length; ++p)(m = f.charCodeAt(p)) == 34 ? h = !h : !h && m in t && (u[m] = (u[m] || 0) + 1);
            m = [];
            for (p in u) Object.prototype.hasOwnProperty.call(u, p) && m.push([u[p], p]);
            if (!m.length) {
                u = a;
                for (p in u) Object.prototype.hasOwnProperty.call(u, p) && m.push([u[p], p])
            }
            return m.sort(function(d, x) {
                return d[0] - x[0] || a[d[1]] - a[x[1]]
            }), t[m.pop()[1]] || 44
        }

        function n(f, u) {
            var h = u || {},
                p = "";
            _t != null && h.dense == null && (h.dense = _t);
            var m = h.dense ? [] : {},
                d = {
                    s: {
                        c: 0,
                        r: 0
                    },
                    e: {
                        c: 0,
                        r: 0
                    }
                };
            f.slice(0, 4) == "sep=" ? f.charCodeAt(5) == 13 && f.charCodeAt(6) == 10 ? (p = f.charAt(4), f = f.slice(7)) : f.charCodeAt(5) == 13 || f.charCodeAt(5) == 10 ? (p = f.charAt(4), f = f.slice(6)) : p = i(f.slice(0, 1024)) : h && h.FS ? p = h.FS : p = i(f.slice(0, 1024));
            var x = 0,
                E = 0,
                S = 0,
                _ = 0,
                L = 0,
                U = p.charCodeAt(0),
                R = !1,
                T = 0,
                N = f.charCodeAt(0);
            f = f.replace(/\r\n/mg, `
`);
            var P = h.dateNF != null ? yd(h.dateNF) : null;

            function X() {
                var j = f.slice(_, L),
                    B = {};
                if (j.charAt(0) == '"' && j.charAt(j.length - 1) == '"' && (j = j.slice(1, -1).replace(/""/g, '"')), j.length === 0) B.t = "z";
                else if (h.raw) B.t = "s", B.v = j;
                else if (j.trim().length === 0) B.t = "s", B.v = j;
                else if (j.charCodeAt(0) == 61) j.charCodeAt(1) == 34 && j.charCodeAt(j.length - 1) == 34 ? (B.t = "s", B.v = j.slice(2, -1).replace(/""/g, '"')) : eg(j) ? (B.t = "n", B.f = j.slice(1)) : (B.t = "s", B.v = j);
                else if (j == "TRUE") B.t = "b", B.v = !0;
                else if (j == "FALSE") B.t = "b", B.v = !1;
                else if (!isNaN(S = Nr(j))) B.t = "n", h.cellText !== !1 && (B.w = j), B.v = S;
                else if (!isNaN(si(j).getDate()) || P && j.match(P)) {
                    B.z = h.dateNF || Ie[14];
                    var se = 0;
                    P && j.match(P) && (j = kd(j, h.dateNF, j.match(P) || []), se = 1), h.cellDates ? (B.t = "d", B.v = ft(j, se)) : (B.t = "n", B.v = Ot(ft(j, se))), h.cellText !== !1 && (B.w = Ir(B.z, B.v instanceof Date ? Ot(B.v) : B.v)), h.cellNF || delete B.z
                } else B.t = "s", B.v = j;
                if (B.t == "z" || (h.dense ? (m[x] || (m[x] = []), m[x][E] = B) : m[Me({
                        c: E,
                        r: x
                    })] = B), _ = L + 1, N = f.charCodeAt(_), d.e.c < E && (d.e.c = E), d.e.r < x && (d.e.r = x), T == U) ++E;
                else if (E = 0, ++x, h.sheetRows && h.sheetRows <= x) return !0
            }
            e: for (; L < f.length; ++L) switch (T = f.charCodeAt(L)) {
                case 34:
                    N === 34 && (R = !R);
                    break;
                case U:
                case 10:
                case 13:
                    if (!R && X()) break e;
                    break;
                default:
                    break
            }
            return L - _ > 0 && X(), m["!ref"] = Ne(d), m
        }

        function s(f, u) {
            return !(u && u.PRN) || u.FS || f.slice(0, 4) == "sep=" || f.indexOf("	") >= 0 || f.indexOf(",") >= 0 || f.indexOf(";") >= 0 ? n(f, u) : di(r(f, u), u)
        }

        function o(f, u) {
            var h = "",
                p = u.type == "string" ? [0, 0, 0, 0] : O0(f, u);
            switch (u.type) {
                case "base64":
                    h = pr(f);
                    break;
                case "binary":
                    h = f;
                    break;
                case "buffer":
                    u.codepage == 65001 ? h = f.toString("utf8") : u.codepage && typeof Ye < "u" ? h = Ye.utils.decode(u.codepage, f) : h = Ue && Buffer.isBuffer(f) ? f.toString("binary") : _a(f);
                    break;
                case "array":
                    h = Oa(f);
                    break;
                case "string":
                    h = f;
                    break;
                default:
                    throw new Error("Unrecognized type " + u.type)
            }
            return p[0] == 239 && p[1] == 187 && p[2] == 191 ? h = at(h.slice(3)) : u.type != "string" && u.type != "buffer" && u.codepage == 65001 ? h = at(h) : u.type == "binary" && typeof Ye < "u" && u.codepage && (h = Ye.utils.decode(u.codepage, Ye.utils.encode(28591, h))), h.slice(0, 19) == "socialcalc:version:" ? cf.to_sheet(u.type == "string" ? h : at(h), u) : s(h, u)
        }

        function c(f, u) {
            return va(o(f, u), u)
        }

        function l(f) {
            for (var u = [], h = Xe(f["!ref"]), p, m = Array.isArray(f), d = h.s.r; d <= h.e.r; ++d) {
                for (var x = [], E = h.s.c; E <= h.e.c; ++E) {
                    var S = Me({
                        r: d,
                        c: E
                    });
                    if (p = m ? (f[d] || [])[E] : f[S], !p || p.v == null) {
                        x.push("          ");
                        continue
                    }
                    for (var _ = (p.w || (ta(p), p.w) || "").slice(0, 10); _.length < 10;) _ += " ";
                    x.push(_ + (E === 0 ? " " : ""))
                }
                u.push(x.join(""))
            }
            return u.join(`
`)
        }
        return {
            to_workbook: c,
            to_sheet: o,
            from_sheet: l
        }
    })();

function Vp(e, r) {
    var t = r || {},
        a = !!t.WTF;
    t.WTF = !0;
    try {
        var i = sf.to_workbook(e, t);
        return t.WTF = a, i
    } catch (n) {
        if (t.WTF = a, !n.message.match(/SYLK bad record ID/) && a) throw n;
        return oi.to_workbook(e, r)
    }
}
var ba = (function() {
    function e(b, H, O) {
        if (b) {
            Bt(b, b.l || 0);
            for (var M = O.Enum || Te; b.l < b.length;) {
                var J = b.read_shift(2),
                    de = M[J] || M[65535],
                    ie = b.read_shift(2),
                    ne = b.l + ie,
                    Q = de.f && de.f(b, ie, O);
                if (b.l = ne, H(Q, de, J)) return
            }
        }
    }

    function r(b, H) {
        switch (H.type) {
            case "base64":
                return t(dr(pr(b)), H);
            case "binary":
                return t(dr(b), H);
            case "buffer":
            case "array":
                return t(b, H)
        }
        throw "Unsupported type " + H.type
    }

    function t(b, H) {
        if (!b) return b;
        var O = H || {};
        _t != null && O.dense == null && (O.dense = _t);
        var M = O.dense ? [] : {},
            J = "Sheet1",
            de = "",
            ie = 0,
            ne = {},
            Q = [],
            Pe = [],
            A = {
                s: {
                    r: 0,
                    c: 0
                },
                e: {
                    r: 0,
                    c: 0
                }
            },
            Ke = O.sheetRows || 0;
        if (b[2] == 0 && (b[3] == 8 || b[3] == 9) && b.length >= 16 && b[14] == 5 && b[15] === 108) throw new Error("Unsupported Works 3 for Mac file");
        if (b[2] == 2) O.Enum = Te, e(b, function(xe, wt, mr) {
            switch (mr) {
                case 0:
                    O.vers = xe, xe >= 4096 && (O.qpro = !0);
                    break;
                case 6:
                    A = xe;
                    break;
                case 204:
                    xe && (de = xe);
                    break;
                case 222:
                    de = xe;
                    break;
                case 15:
                case 51:
                    O.qpro || (xe[1].v = xe[1].v.slice(1));
                case 13:
                case 14:
                case 16:
                    mr == 14 && (xe[2] & 112) == 112 && (xe[2] & 15) > 1 && (xe[2] & 15) < 15 && (xe[1].z = O.dateNF || Ie[14], O.cellDates && (xe[1].t = "d", xe[1].v = Jn(xe[1].v))), O.qpro && xe[3] > ie && (M["!ref"] = Ne(A), ne[J] = M, Q.push(J), M = O.dense ? [] : {}, A = {
                        s: {
                            r: 0,
                            c: 0
                        },
                        e: {
                            r: 0,
                            c: 0
                        }
                    }, ie = xe[3], J = de || "Sheet" + (ie + 1), de = "");
                    var Br = O.dense ? (M[xe[0].r] || [])[xe[0].c] : M[Me(xe[0])];
                    if (Br) {
                        Br.t = xe[1].t, Br.v = xe[1].v, xe[1].z != null && (Br.z = xe[1].z), xe[1].f != null && (Br.f = xe[1].f);
                        break
                    }
                    O.dense ? (M[xe[0].r] || (M[xe[0].r] = []), M[xe[0].r][xe[0].c] = xe[1]) : M[Me(xe[0])] = xe[1];
                    break;
                default:
            }
        }, O);
        else if (b[2] == 26 || b[2] == 14) O.Enum = Z, b[2] == 14 && (O.qpro = !0, b.l = 0), e(b, function(xe, wt, mr) {
            switch (mr) {
                case 204:
                    J = xe;
                    break;
                case 22:
                    xe[1].v = xe[1].v.slice(1);
                case 23:
                case 24:
                case 25:
                case 37:
                case 39:
                case 40:
                    if (xe[3] > ie && (M["!ref"] = Ne(A), ne[J] = M, Q.push(J), M = O.dense ? [] : {}, A = {
                            s: {
                                r: 0,
                                c: 0
                            },
                            e: {
                                r: 0,
                                c: 0
                            }
                        }, ie = xe[3], J = "Sheet" + (ie + 1)), Ke > 0 && xe[0].r >= Ke) break;
                    O.dense ? (M[xe[0].r] || (M[xe[0].r] = []), M[xe[0].r][xe[0].c] = xe[1]) : M[Me(xe[0])] = xe[1], A.e.c < xe[0].c && (A.e.c = xe[0].c), A.e.r < xe[0].r && (A.e.r = xe[0].r);
                    break;
                case 27:
                    xe[14e3] && (Pe[xe[14e3][0]] = xe[14e3][1]);
                    break;
                case 1537:
                    Pe[xe[0]] = xe[1], xe[0] == ie && (J = xe[1]);
                    break;
                default:
                    break
            }
        }, O);
        else throw new Error("Unrecognized LOTUS BOF " + b[2]);
        if (M["!ref"] = Ne(A), ne[de || J] = M, Q.push(de || J), !Pe.length) return {
            SheetNames: Q,
            Sheets: ne
        };
        for (var He = {}, Je = [], Ge = 0; Ge < Pe.length; ++Ge) ne[Q[Ge]] ? (Je.push(Pe[Ge] || Q[Ge]), He[Pe[Ge]] = ne[Pe[Ge]] || ne[Q[Ge]]) : (Je.push(Pe[Ge]), He[Pe[Ge]] = {
            "!ref": "A1"
        });
        return {
            SheetNames: Je,
            Sheets: He
        }
    }

    function a(b, H) {
        var O = H || {};
        if (+O.codepage >= 0 && Rr(+O.codepage), O.type == "string") throw new Error("Cannot write WK1 to JS string");
        var M = sr(),
            J = Xe(b["!ref"]),
            de = Array.isArray(b),
            ie = [];
        le(M, 0, n(1030)), le(M, 6, c(J));
        for (var ne = Math.min(J.e.r, 8191), Q = J.s.r; Q <= ne; ++Q)
            for (var Pe = Tt(Q), A = J.s.c; A <= J.e.c; ++A) {
                Q === J.s.r && (ie[A] = ht(A));
                var Ke = ie[A] + Pe,
                    He = de ? (b[Q] || [])[A] : b[Ke];
                if (!(!He || He.t == "z"))
                    if (He.t == "n")(He.v | 0) == He.v && He.v >= -32768 && He.v <= 32767 ? le(M, 13, p(Q, A, He.v)) : le(M, 14, d(Q, A, He.v));
                    else {
                        var Je = ta(He);
                        le(M, 15, u(Q, A, Je.slice(0, 239)))
                    }
            }
        return le(M, 1), M.end()
    }

    function i(b, H) {
        var O = H || {};
        if (+O.codepage >= 0 && Rr(+O.codepage), O.type == "string") throw new Error("Cannot write WK3 to JS string");
        var M = sr();
        le(M, 0, s(b));
        for (var J = 0, de = 0; J < b.SheetNames.length; ++J)(b.Sheets[b.SheetNames[J]] || {})["!ref"] && le(M, 27, me(b.SheetNames[J], de++));
        var ie = 0;
        for (J = 0; J < b.SheetNames.length; ++J) {
            var ne = b.Sheets[b.SheetNames[J]];
            if (!(!ne || !ne["!ref"])) {
                for (var Q = Xe(ne["!ref"]), Pe = Array.isArray(ne), A = [], Ke = Math.min(Q.e.r, 8191), He = Q.s.r; He <= Ke; ++He)
                    for (var Je = Tt(He), Ge = Q.s.c; Ge <= Q.e.c; ++Ge) {
                        He === Q.s.r && (A[Ge] = ht(Ge));
                        var xe = A[Ge] + Je,
                            wt = Pe ? (ne[He] || [])[Ge] : ne[xe];
                        if (!(!wt || wt.t == "z"))
                            if (wt.t == "n") le(M, 23, X(He, Ge, ie, wt.v));
                            else {
                                var mr = ta(wt);
                                le(M, 22, T(He, Ge, ie, mr.slice(0, 239)))
                            }
                    }++ie
            }
        }
        return le(M, 1), M.end()
    }

    function n(b) {
        var H = Y(2);
        return H.write_shift(2, b), H
    }

    function s(b) {
        var H = Y(26);
        H.write_shift(2, 4096), H.write_shift(2, 4), H.write_shift(4, 0);
        for (var O = 0, M = 0, J = 0, de = 0; de < b.SheetNames.length; ++de) {
            var ie = b.SheetNames[de],
                ne = b.Sheets[ie];
            if (!(!ne || !ne["!ref"])) {
                ++J;
                var Q = or(ne["!ref"]);
                O < Q.e.r && (O = Q.e.r), M < Q.e.c && (M = Q.e.c)
            }
        }
        return O > 8191 && (O = 8191), H.write_shift(2, O), H.write_shift(1, J), H.write_shift(1, M), H.write_shift(2, 0), H.write_shift(2, 0), H.write_shift(1, 1), H.write_shift(1, 2), H.write_shift(4, 0), H.write_shift(4, 0), H
    }

    function o(b, H, O) {
        var M = {
            s: {
                c: 0,
                r: 0
            },
            e: {
                c: 0,
                r: 0
            }
        };
        return H == 8 && O.qpro ? (M.s.c = b.read_shift(1), b.l++, M.s.r = b.read_shift(2), M.e.c = b.read_shift(1), b.l++, M.e.r = b.read_shift(2), M) : (M.s.c = b.read_shift(2), M.s.r = b.read_shift(2), H == 12 && O.qpro && (b.l += 2), M.e.c = b.read_shift(2), M.e.r = b.read_shift(2), H == 12 && O.qpro && (b.l += 2), M.s.c == 65535 && (M.s.c = M.e.c = M.s.r = M.e.r = 0), M)
    }

    function c(b) {
        var H = Y(8);
        return H.write_shift(2, b.s.c), H.write_shift(2, b.s.r), H.write_shift(2, b.e.c), H.write_shift(2, b.e.r), H
    }

    function l(b, H, O) {
        var M = [{
            c: 0,
            r: 0
        }, {
            t: "n",
            v: 0
        }, 0, 0];
        return O.qpro && O.vers != 20768 ? (M[0].c = b.read_shift(1), M[3] = b.read_shift(1), M[0].r = b.read_shift(2), b.l += 2) : (M[2] = b.read_shift(1), M[0].c = b.read_shift(2), M[0].r = b.read_shift(2)), M
    }

    function f(b, H, O) {
        var M = b.l + H,
            J = l(b, H, O);
        if (J[1].t = "s", O.vers == 20768) {
            b.l++;
            var de = b.read_shift(1);
            return J[1].v = b.read_shift(de, "utf8"), J
        }
        return O.qpro && b.l++, J[1].v = b.read_shift(M - b.l, "cstr"), J
    }

    function u(b, H, O) {
        var M = Y(7 + O.length);
        M.write_shift(1, 255), M.write_shift(2, H), M.write_shift(2, b), M.write_shift(1, 39);
        for (var J = 0; J < M.length; ++J) {
            var de = O.charCodeAt(J);
            M.write_shift(1, de >= 128 ? 95 : de)
        }
        return M.write_shift(1, 0), M
    }

    function h(b, H, O) {
        var M = l(b, H, O);
        return M[1].v = b.read_shift(2, "i"), M
    }

    function p(b, H, O) {
        var M = Y(7);
        return M.write_shift(1, 255), M.write_shift(2, H), M.write_shift(2, b), M.write_shift(2, O, "i"), M
    }

    function m(b, H, O) {
        var M = l(b, H, O);
        return M[1].v = b.read_shift(8, "f"), M
    }

    function d(b, H, O) {
        var M = Y(13);
        return M.write_shift(1, 255), M.write_shift(2, H), M.write_shift(2, b), M.write_shift(8, O, "f"), M
    }

    function x(b, H, O) {
        var M = b.l + H,
            J = l(b, H, O);
        if (J[1].v = b.read_shift(8, "f"), O.qpro) b.l = M;
        else {
            var de = b.read_shift(2);
            L(b.slice(b.l, b.l + de), J), b.l += de
        }
        return J
    }

    function E(b, H, O) {
        var M = H & 32768;
        return H &= -32769, H = (M ? b : 0) + (H >= 8192 ? H - 16384 : H), (M ? "" : "$") + (O ? ht(H) : Tt(H))
    }
    var S = {
            51: ["FALSE", 0],
            52: ["TRUE", 0],
            70: ["LEN", 1],
            80: ["SUM", 69],
            81: ["AVERAGEA", 69],
            82: ["COUNTA", 69],
            83: ["MINA", 69],
            84: ["MAXA", 69],
            111: ["T", 1]
        },
        _ = ["", "", "", "", "", "", "", "", "", "+", "-", "*", "/", "^", "=", "<>", "<=", ">=", "<", ">", "", "", "", "", "&", "", "", "", "", "", "", ""];

    function L(b, H) {
        Bt(b, 0);
        for (var O = [], M = 0, J = "", de = "", ie = "", ne = ""; b.l < b.length;) {
            var Q = b[b.l++];
            switch (Q) {
                case 0:
                    O.push(b.read_shift(8, "f"));
                    break;
                case 1:
                    de = E(H[0].c, b.read_shift(2), !0), J = E(H[0].r, b.read_shift(2), !1), O.push(de + J);
                    break;
                case 2:
                    {
                        var Pe = E(H[0].c, b.read_shift(2), !0),
                            A = E(H[0].r, b.read_shift(2), !1);de = E(H[0].c, b.read_shift(2), !0),
                        J = E(H[0].r, b.read_shift(2), !1),
                        O.push(Pe + A + ":" + de + J)
                    }
                    break;
                case 3:
                    if (b.l < b.length) {
                        console.error("WK1 premature formula end");
                        return
                    }
                    break;
                case 4:
                    O.push("(" + O.pop() + ")");
                    break;
                case 5:
                    O.push(b.read_shift(2));
                    break;
                case 6:
                    {
                        for (var Ke = ""; Q = b[b.l++];) Ke += String.fromCharCode(Q);O.push('"' + Ke.replace(/"/g, '""') + '"')
                    }
                    break;
                case 8:
                    O.push("-" + O.pop());
                    break;
                case 23:
                    O.push("+" + O.pop());
                    break;
                case 22:
                    O.push("NOT(" + O.pop() + ")");
                    break;
                case 20:
                case 21:
                    ne = O.pop(), ie = O.pop(), O.push(["AND", "OR"][Q - 20] + "(" + ie + "," + ne + ")");
                    break;
                default:
                    if (Q < 32 && _[Q]) ne = O.pop(), ie = O.pop(), O.push(ie + _[Q] + ne);
                    else if (S[Q]) {
                        if (M = S[Q][1], M == 69 && (M = b[b.l++]), M > O.length) {
                            console.error("WK1 bad formula parse 0x" + Q.toString(16) + ":|" + O.join("|") + "|");
                            return
                        }
                        var He = O.slice(-M);
                        O.length -= M, O.push(S[Q][0] + "(" + He.join(",") + ")")
                    } else return Q <= 7 ? console.error("WK1 invalid opcode " + Q.toString(16)) : Q <= 24 ? console.error("WK1 unsupported op " + Q.toString(16)) : Q <= 30 ? console.error("WK1 invalid opcode " + Q.toString(16)) : Q <= 115 ? console.error("WK1 unsupported function opcode " + Q.toString(16)) : console.error("WK1 unrecognized opcode " + Q.toString(16))
            }
        }
        O.length == 1 ? H[1].f = "" + O[0] : console.error("WK1 bad formula parse |" + O.join("|") + "|")
    }

    function U(b) {
        var H = [{
            c: 0,
            r: 0
        }, {
            t: "n",
            v: 0
        }, 0];
        return H[0].r = b.read_shift(2), H[3] = b[b.l++], H[0].c = b[b.l++], H
    }

    function R(b, H) {
        var O = U(b, H);
        return O[1].t = "s", O[1].v = b.read_shift(H - 4, "cstr"), O
    }

    function T(b, H, O, M) {
        var J = Y(6 + M.length);
        J.write_shift(2, b), J.write_shift(1, O), J.write_shift(1, H), J.write_shift(1, 39);
        for (var de = 0; de < M.length; ++de) {
            var ie = M.charCodeAt(de);
            J.write_shift(1, ie >= 128 ? 95 : ie)
        }
        return J.write_shift(1, 0), J
    }

    function N(b, H) {
        var O = U(b, H);
        O[1].v = b.read_shift(2);
        var M = O[1].v >> 1;
        if (O[1].v & 1) switch (M & 7) {
            case 0:
                M = (M >> 3) * 5e3;
                break;
            case 1:
                M = (M >> 3) * 500;
                break;
            case 2:
                M = (M >> 3) / 20;
                break;
            case 3:
                M = (M >> 3) / 200;
                break;
            case 4:
                M = (M >> 3) / 2e3;
                break;
            case 5:
                M = (M >> 3) / 2e4;
                break;
            case 6:
                M = (M >> 3) / 16;
                break;
            case 7:
                M = (M >> 3) / 64;
                break
        }
        return O[1].v = M, O
    }

    function P(b, H) {
        var O = U(b, H),
            M = b.read_shift(4),
            J = b.read_shift(4),
            de = b.read_shift(2);
        if (de == 65535) return M === 0 && J === 3221225472 ? (O[1].t = "e", O[1].v = 15) : M === 0 && J === 3489660928 ? (O[1].t = "e", O[1].v = 42) : O[1].v = 0, O;
        var ie = de & 32768;
        return de = (de & 32767) - 16446, O[1].v = (1 - ie * 2) * (J * Math.pow(2, de + 32) + M * Math.pow(2, de)), O
    }

    function X(b, H, O, M) {
        var J = Y(14);
        if (J.write_shift(2, b), J.write_shift(1, O), J.write_shift(1, H), M == 0) return J.write_shift(4, 0), J.write_shift(4, 0), J.write_shift(2, 65535), J;
        var de = 0,
            ie = 0,
            ne = 0,
            Q = 0;
        return M < 0 && (de = 1, M = -M), ie = Math.log2(M) | 0, M /= Math.pow(2, ie - 31), Q = M >>> 0, (Q & 2147483648) == 0 && (M /= 2, ++ie, Q = M >>> 0), M -= Q, Q |= 2147483648, Q >>>= 0, M *= Math.pow(2, 32), ne = M >>> 0, J.write_shift(4, ne), J.write_shift(4, Q), ie += 16383 + (de ? 32768 : 0), J.write_shift(2, ie), J
    }

    function j(b, H) {
        var O = P(b, 14);
        return b.l += H - 14, O
    }

    function B(b, H) {
        var O = U(b, H),
            M = b.read_shift(4);
        return O[1].v = M >> 6, O
    }

    function se(b, H) {
        var O = U(b, H),
            M = b.read_shift(8, "f");
        return O[1].v = M, O
    }

    function _e(b, H) {
        var O = se(b, 14);
        return b.l += H - 10, O
    }

    function oe(b, H) {
        return b[b.l + H - 1] == 0 ? b.read_shift(H, "cstr") : ""
    }

    function ke(b, H) {
        var O = b[b.l++];
        O > H - 1 && (O = H - 1);
        for (var M = ""; M.length < O;) M += String.fromCharCode(b[b.l++]);
        return M
    }

    function Se(b, H, O) {
        if (!(!O.qpro || H < 21)) {
            var M = b.read_shift(1);
            b.l += 17, b.l += 1, b.l += 2;
            var J = b.read_shift(H - 21, "cstr");
            return [M, J]
        }
    }

    function Ve(b, H) {
        for (var O = {}, M = b.l + H; b.l < M;) {
            var J = b.read_shift(2);
            if (J == 14e3) {
                for (O[J] = [0, ""], O[J][0] = b.read_shift(2); b[b.l];) O[J][1] += String.fromCharCode(b[b.l]), b.l++;
                b.l++
            }
        }
        return O
    }

    function me(b, H) {
        var O = Y(5 + b.length);
        O.write_shift(2, 14e3), O.write_shift(2, H);
        for (var M = 0; M < b.length; ++M) {
            var J = b.charCodeAt(M);
            O[O.l++] = J > 127 ? 95 : J
        }
        return O[O.l++] = 0, O
    }
    var Te = {
            0: {
                n: "BOF",
                f: bt
            },
            1: {
                n: "EOF"
            },
            2: {
                n: "CALCMODE"
            },
            3: {
                n: "CALCORDER"
            },
            4: {
                n: "SPLIT"
            },
            5: {
                n: "SYNC"
            },
            6: {
                n: "RANGE",
                f: o
            },
            7: {
                n: "WINDOW1"
            },
            8: {
                n: "COLW1"
            },
            9: {
                n: "WINTWO"
            },
            10: {
                n: "COLW2"
            },
            11: {
                n: "NAME"
            },
            12: {
                n: "BLANK"
            },
            13: {
                n: "INTEGER",
                f: h
            },
            14: {
                n: "NUMBER",
                f: m
            },
            15: {
                n: "LABEL",
                f
            },
            16: {
                n: "FORMULA",
                f: x
            },
            24: {
                n: "TABLE"
            },
            25: {
                n: "ORANGE"
            },
            26: {
                n: "PRANGE"
            },
            27: {
                n: "SRANGE"
            },
            28: {
                n: "FRANGE"
            },
            29: {
                n: "KRANGE1"
            },
            32: {
                n: "HRANGE"
            },
            35: {
                n: "KRANGE2"
            },
            36: {
                n: "PROTEC"
            },
            37: {
                n: "FOOTER"
            },
            38: {
                n: "HEADER"
            },
            39: {
                n: "SETUP"
            },
            40: {
                n: "MARGINS"
            },
            41: {
                n: "LABELFMT"
            },
            42: {
                n: "TITLES"
            },
            43: {
                n: "SHEETJS"
            },
            45: {
                n: "GRAPH"
            },
            46: {
                n: "NGRAPH"
            },
            47: {
                n: "CALCCOUNT"
            },
            48: {
                n: "UNFORMATTED"
            },
            49: {
                n: "CURSORW12"
            },
            50: {
                n: "WINDOW"
            },
            51: {
                n: "STRING",
                f
            },
            55: {
                n: "PASSWORD"
            },
            56: {
                n: "LOCKED"
            },
            60: {
                n: "QUERY"
            },
            61: {
                n: "QUERYNAME"
            },
            62: {
                n: "PRINT"
            },
            63: {
                n: "PRINTNAME"
            },
            64: {
                n: "GRAPH2"
            },
            65: {
                n: "GRAPHNAME"
            },
            66: {
                n: "ZOOM"
            },
            67: {
                n: "SYMSPLIT"
            },
            68: {
                n: "NSROWS"
            },
            69: {
                n: "NSCOLS"
            },
            70: {
                n: "RULER"
            },
            71: {
                n: "NNAME"
            },
            72: {
                n: "ACOMM"
            },
            73: {
                n: "AMACRO"
            },
            74: {
                n: "PARSE"
            },
            102: {
                n: "PRANGES??"
            },
            103: {
                n: "RRANGES??"
            },
            104: {
                n: "FNAME??"
            },
            105: {
                n: "MRANGES??"
            },
            204: {
                n: "SHEETNAMECS",
                f: oe
            },
            222: {
                n: "SHEETNAMELP",
                f: ke
            },
            65535: {
                n: ""
            }
        },
        Z = {
            0: {
                n: "BOF"
            },
            1: {
                n: "EOF"
            },
            2: {
                n: "PASSWORD"
            },
            3: {
                n: "CALCSET"
            },
            4: {
                n: "WINDOWSET"
            },
            5: {
                n: "SHEETCELLPTR"
            },
            6: {
                n: "SHEETLAYOUT"
            },
            7: {
                n: "COLUMNWIDTH"
            },
            8: {
                n: "HIDDENCOLUMN"
            },
            9: {
                n: "USERRANGE"
            },
            10: {
                n: "SYSTEMRANGE"
            },
            11: {
                n: "ZEROFORCE"
            },
            12: {
                n: "SORTKEYDIR"
            },
            13: {
                n: "FILESEAL"
            },
            14: {
                n: "DATAFILLNUMS"
            },
            15: {
                n: "PRINTMAIN"
            },
            16: {
                n: "PRINTSTRING"
            },
            17: {
                n: "GRAPHMAIN"
            },
            18: {
                n: "GRAPHSTRING"
            },
            19: {
                n: "??"
            },
            20: {
                n: "ERRCELL"
            },
            21: {
                n: "NACELL"
            },
            22: {
                n: "LABEL16",
                f: R
            },
            23: {
                n: "NUMBER17",
                f: P
            },
            24: {
                n: "NUMBER18",
                f: N
            },
            25: {
                n: "FORMULA19",
                f: j
            },
            26: {
                n: "FORMULA1A"
            },
            27: {
                n: "XFORMAT",
                f: Ve
            },
            28: {
                n: "DTLABELMISC"
            },
            29: {
                n: "DTLABELCELL"
            },
            30: {
                n: "GRAPHWINDOW"
            },
            31: {
                n: "CPA"
            },
            32: {
                n: "LPLAUTO"
            },
            33: {
                n: "QUERY"
            },
            34: {
                n: "HIDDENSHEET"
            },
            35: {
                n: "??"
            },
            37: {
                n: "NUMBER25",
                f: B
            },
            38: {
                n: "??"
            },
            39: {
                n: "NUMBER27",
                f: se
            },
            40: {
                n: "FORMULA28",
                f: _e
            },
            142: {
                n: "??"
            },
            147: {
                n: "??"
            },
            150: {
                n: "??"
            },
            151: {
                n: "??"
            },
            152: {
                n: "??"
            },
            153: {
                n: "??"
            },
            154: {
                n: "??"
            },
            155: {
                n: "??"
            },
            156: {
                n: "??"
            },
            163: {
                n: "??"
            },
            174: {
                n: "??"
            },
            175: {
                n: "??"
            },
            176: {
                n: "??"
            },
            177: {
                n: "??"
            },
            184: {
                n: "??"
            },
            185: {
                n: "??"
            },
            186: {
                n: "??"
            },
            187: {
                n: "??"
            },
            188: {
                n: "??"
            },
            195: {
                n: "??"
            },
            201: {
                n: "??"
            },
            204: {
                n: "SHEETNAMECS",
                f: oe
            },
            205: {
                n: "??"
            },
            206: {
                n: "??"
            },
            207: {
                n: "??"
            },
            208: {
                n: "??"
            },
            256: {
                n: "??"
            },
            259: {
                n: "??"
            },
            260: {
                n: "??"
            },
            261: {
                n: "??"
            },
            262: {
                n: "??"
            },
            263: {
                n: "??"
            },
            265: {
                n: "??"
            },
            266: {
                n: "??"
            },
            267: {
                n: "??"
            },
            268: {
                n: "??"
            },
            270: {
                n: "??"
            },
            271: {
                n: "??"
            },
            384: {
                n: "??"
            },
            389: {
                n: "??"
            },
            390: {
                n: "??"
            },
            393: {
                n: "??"
            },
            396: {
                n: "??"
            },
            512: {
                n: "??"
            },
            514: {
                n: "??"
            },
            513: {
                n: "??"
            },
            516: {
                n: "??"
            },
            517: {
                n: "??"
            },
            640: {
                n: "??"
            },
            641: {
                n: "??"
            },
            642: {
                n: "??"
            },
            643: {
                n: "??"
            },
            644: {
                n: "??"
            },
            645: {
                n: "??"
            },
            646: {
                n: "??"
            },
            647: {
                n: "??"
            },
            648: {
                n: "??"
            },
            658: {
                n: "??"
            },
            659: {
                n: "??"
            },
            660: {
                n: "??"
            },
            661: {
                n: "??"
            },
            662: {
                n: "??"
            },
            665: {
                n: "??"
            },
            666: {
                n: "??"
            },
            768: {
                n: "??"
            },
            772: {
                n: "??"
            },
            1537: {
                n: "SHEETINFOQP",
                f: Se
            },
            1600: {
                n: "??"
            },
            1602: {
                n: "??"
            },
            1793: {
                n: "??"
            },
            1794: {
                n: "??"
            },
            1795: {
                n: "??"
            },
            1796: {
                n: "??"
            },
            1920: {
                n: "??"
            },
            2048: {
                n: "??"
            },
            2049: {
                n: "??"
            },
            2052: {
                n: "??"
            },
            2688: {
                n: "??"
            },
            10998: {
                n: "??"
            },
            12849: {
                n: "??"
            },
            28233: {
                n: "??"
            },
            28484: {
                n: "??"
            },
            65535: {
                n: ""
            }
        };
    return {
        sheet_to_wk1: a,
        book_to_wk3: i,
        to_workbook: r
    }
})();

function Wp(e) {
    var r = {},
        t = e.match($t),
        a = 0,
        i = !1;
    if (t)
        for (; a != t.length; ++a) {
            var n = Oe(t[a]);
            switch (n[0].replace(/\w*:/g, "")) {
                case "<condense":
                    break;
                case "<extend":
                    break;
                case "<shadow":
                    if (!n.val) break;
                case "<shadow>":
                case "<shadow/>":
                    r.shadow = 1;
                    break;
                case "</shadow>":
                    break;
                case "<charset":
                    if (n.val == "1") break;
                    r.cp = Xs[parseInt(n.val, 10)];
                    break;
                case "<outline":
                    if (!n.val) break;
                case "<outline>":
                case "<outline/>":
                    r.outline = 1;
                    break;
                case "</outline>":
                    break;
                case "<rFont":
                    r.name = n.val;
                    break;
                case "<sz":
                    r.sz = n.val;
                    break;
                case "<strike":
                    if (!n.val) break;
                case "<strike>":
                case "<strike/>":
                    r.strike = 1;
                    break;
                case "</strike>":
                    break;
                case "<u":
                    if (!n.val) break;
                    switch (n.val) {
                        case "double":
                            r.uval = "double";
                            break;
                        case "singleAccounting":
                            r.uval = "single-accounting";
                            break;
                        case "doubleAccounting":
                            r.uval = "double-accounting";
                            break
                    }
                case "<u>":
                case "<u/>":
                    r.u = 1;
                    break;
                case "</u>":
                    break;
                case "<b":
                    if (n.val == "0") break;
                case "<b>":
                case "<b/>":
                    r.b = 1;
                    break;
                case "</b>":
                    break;
                case "<i":
                    if (n.val == "0") break;
                case "<i>":
                case "<i/>":
                    r.i = 1;
                    break;
                case "</i>":
                    break;
                case "<color":
                    n.rgb && (r.color = n.rgb.slice(2, 8));
                    break;
                case "<color>":
                case "<color/>":
                case "</color>":
                    break;
                case "<family":
                    r.family = n.val;
                    break;
                case "<family>":
                case "<family/>":
                case "</family>":
                    break;
                case "<vertAlign":
                    r.valign = n.val;
                    break;
                case "<vertAlign>":
                case "<vertAlign/>":
                case "</vertAlign>":
                    break;
                case "<scheme":
                    break;
                case "<scheme>":
                case "<scheme/>":
                case "</scheme>":
                    break;
                case "<extLst":
                case "<extLst>":
                case "</extLst>":
                    break;
                case "<ext":
                    i = !0;
                    break;
                case "</ext>":
                    i = !1;
                    break;
                default:
                    if (n[0].charCodeAt(1) !== 47 && !i) throw new Error("Unrecognized rich format " + n[0])
            }
        }
    return r
}
var Hp = (function() {
        var e = Hi("t"),
            r = Hi("rPr");

        function t(n) {
            var s = n.match(e);
            if (!s) return {
                t: "s",
                v: ""
            };
            var o = {
                    t: "s",
                    v: ze(s[1])
                },
                c = n.match(r);
            return c && (o.s = Wp(c[1])), o
        }
        var a = /<(?:\w+:)?r>/g,
            i = /<\/(?:\w+:)?r>/;
        return function(s) {
            return s.replace(a, "").split(i).map(t).filter(function(o) {
                return o.v
            })
        }
    })(),
    Gp = (function() {
        var r = /(\r\n|\n)/g;

        function t(i, n, s) {
            var o = [];
            i.u && o.push("text-decoration: underline;"), i.uval && o.push("text-underline-style:" + i.uval + ";"), i.sz && o.push("font-size:" + i.sz + "pt;"), i.outline && o.push("text-effect: outline;"), i.shadow && o.push("text-shadow: auto;"), n.push('<span style="' + o.join("") + '">'), i.b && (n.push("<b>"), s.push("</b>")), i.i && (n.push("<i>"), s.push("</i>")), i.strike && (n.push("<s>"), s.push("</s>"));
            var c = i.valign || "";
            return c == "superscript" || c == "super" ? c = "sup" : c == "subscript" && (c = "sub"), c != "" && (n.push("<" + c + ">"), s.push("</" + c + ">")), s.push("</span>"), i
        }

        function a(i) {
            var n = [
                [], i.v, []
            ];
            return i.v ? (i.s && t(i.s, n[0], n[2]), n[0].join("") + n[1].replace(r, "<br/>") + n[2].join("")) : ""
        }
        return function(n) {
            return n.map(a).join("")
        }
    })(),
    zp = /<(?:\w+:)?t[^>]*>([^<]*)<\/(?:\w+:)?t>/g,
    Xp = /<(?:\w+:)?r>/,
    qp = /<(?:\w+:)?rPh.*?>([\s\S]*?)<\/(?:\w+:)?rPh>/g;

function v0(e, r) {
    var t = r ? r.cellHTML : !0,
        a = {};
    return e ? (e.match(/^\s*<(?:\w+:)?t[^>]*>/) ? (a.t = ze(at(e.slice(e.indexOf(">") + 1).split(/<\/(?:\w+:)?t>/)[0] || "")), a.r = at(e), t && (a.h = t0(a.t))) : e.match(Xp) && (a.r = at(e), a.t = ze(at((e.replace(qp, "").match(zp) || []).join("").replace($t, ""))), t && (a.h = Gp(Hp(a.r)))), a) : {
        t: ""
    }
}
var jp = /<(?:\w+:)?sst([^>]*)>([\s\S]*)<\/(?:\w+:)?sst>/,
    $p = /<(?:\w+:)?(?:si|sstItem)>/g,
    Yp = /<\/(?:\w+:)?(?:si|sstItem)>/;

function Kp(e, r) {
    var t = [],
        a = "";
    if (!e) return t;
    var i = e.match(jp);
    if (i) {
        a = i[2].replace($p, "").split(Yp);
        for (var n = 0; n != a.length; ++n) {
            var s = v0(a[n].trim(), r);
            s != null && (t[t.length] = s)
        }
        i = Oe(i[1]), t.Count = i.count, t.Unique = i.uniqueCount
    }
    return t
}
var Jp = /^\s|\s$|[\t\n\r]/;

function lf(e, r) {
    if (!r.bookSST) return "";
    var t = [yt];
    t[t.length] = ce("sst", null, {
        xmlns: La[0],
        count: e.Count,
        uniqueCount: e.Unique
    });
    for (var a = 0; a != e.length; ++a)
        if (e[a] != null) {
            var i = e[a],
                n = "<si>";
            i.r ? n += i.r : (n += "<t", i.t || (i.t = ""), i.t.match(Jp) && (n += ' xml:space="preserve"'), n += ">" + tt(i.t) + "</t>"), n += "</si>", t[t.length] = n
        }
    return t.length > 2 && (t[t.length] = "</sst>", t[1] = t[1].replace("/>", ">")), t.join("")
}

function Zp(e) {
    return [e.read_shift(4), e.read_shift(4)]
}

function Qp(e, r) {
    var t = [],
        a = !1;
    return aa(e, function(n, s, o) {
        switch (o) {
            case 159:
                t.Count = n[0], t.Unique = n[1];
                break;
            case 19:
                t.push(n);
                break;
            case 160:
                return !0;
            case 35:
                a = !0;
                break;
            case 36:
                a = !1;
                break;
            default:
                if (s.T, !a || r.WTF) throw new Error("Unexpected record 0x" + o.toString(16))
        }
    }), t
}

function em(e, r) {
    return r || (r = Y(8)), r.write_shift(4, e.Count), r.write_shift(4, e.Unique), r
}
var tm = uh;

function rm(e) {
    var r = sr();
    ee(r, 159, em(e));
    for (var t = 0; t < e.length; ++t) ee(r, 19, tm(e[t]));
    return ee(r, 160), r.end()
}

function ff(e) {
    if (typeof Ye < "u") return Ye.utils.encode(ni, e);
    for (var r = [], t = e.split(""), a = 0; a < t.length; ++a) r[a] = t[a].charCodeAt(0);
    return r
}

function ea(e, r) {
    var t = {};
    return t.Major = e.read_shift(2), t.Minor = e.read_shift(2), r >= 4 && (e.l += r - 4), t
}

function am(e) {
    var r = {};
    return r.id = e.read_shift(0, "lpp4"), r.R = ea(e, 4), r.U = ea(e, 4), r.W = ea(e, 4), r
}

function im(e) {
    for (var r = e.read_shift(4), t = e.l + r - 4, a = {}, i = e.read_shift(4), n = []; i-- > 0;) n.push({
        t: e.read_shift(4),
        v: e.read_shift(0, "lpp4")
    });
    if (a.name = e.read_shift(0, "lpp4"), a.comps = n, e.l != t) throw new Error("Bad DataSpaceMapEntry: " + e.l + " != " + t);
    return a
}

function nm(e) {
    var r = [];
    e.l += 4;
    for (var t = e.read_shift(4); t-- > 0;) r.push(im(e));
    return r
}

function sm(e) {
    var r = [];
    e.l += 4;
    for (var t = e.read_shift(4); t-- > 0;) r.push(e.read_shift(0, "lpp4"));
    return r
}

function om(e) {
    var r = {};
    return e.read_shift(4), e.l += 4, r.id = e.read_shift(0, "lpp4"), r.name = e.read_shift(0, "lpp4"), r.R = ea(e, 4), r.U = ea(e, 4), r.W = ea(e, 4), r
}

function cm(e) {
    var r = om(e);
    if (r.ename = e.read_shift(0, "8lpp4"), r.blksz = e.read_shift(4), r.cmode = e.read_shift(4), e.read_shift(4) != 4) throw new Error("Bad !Primary record");
    return r
}

function uf(e, r) {
    var t = e.l + r,
        a = {};
    a.Flags = e.read_shift(4) & 63, e.l += 4, a.AlgID = e.read_shift(4);
    var i = !1;
    switch (a.AlgID) {
        case 26126:
        case 26127:
        case 26128:
            i = a.Flags == 36;
            break;
        case 26625:
            i = a.Flags == 4;
            break;
        case 0:
            i = a.Flags == 16 || a.Flags == 4 || a.Flags == 36;
            break;
        default:
            throw "Unrecognized encryption algorithm: " + a.AlgID
    }
    if (!i) throw new Error("Encryption Flags/AlgID mismatch");
    return a.AlgIDHash = e.read_shift(4), a.KeySize = e.read_shift(4), a.ProviderType = e.read_shift(4), e.l += 8, a.CSPName = e.read_shift(t - e.l >> 1, "utf16le"), e.l = t, a
}

function df(e, r) {
    var t = {},
        a = e.l + r;
    return e.l += 4, t.Salt = e.slice(e.l, e.l + 16), e.l += 16, t.Verifier = e.slice(e.l, e.l + 16), e.l += 16, e.read_shift(4), t.VerifierHash = e.slice(e.l, a), e.l = a, t
}

function lm(e) {
    var r = ea(e);
    switch (r.Minor) {
        case 2:
            return [r.Minor, fm(e, r)];
        case 3:
            return [r.Minor, um(e, r)];
        case 4:
            return [r.Minor, dm(e, r)]
    }
    throw new Error("ECMA-376 Encrypted file unrecognized Version: " + r.Minor)
}

function fm(e) {
    var r = e.read_shift(4);
    if ((r & 63) != 36) throw new Error("EncryptionInfo mismatch");
    var t = e.read_shift(4),
        a = uf(e, t),
        i = df(e, e.length - e.l);
    return {
        t: "Std",
        h: a,
        v: i
    }
}

function um() {
    throw new Error("File is password-protected: ECMA-376 Extensible")
}

function dm(e) {
    var r = ["saltSize", "blockSize", "keyBits", "hashSize", "cipherAlgorithm", "cipherChaining", "hashAlgorithm", "saltValue"];
    e.l += 4;
    var t = e.read_shift(e.length - e.l, "utf8"),
        a = {};
    return t.replace($t, function(n) {
        var s = Oe(n);
        switch (Xr(s[0])) {
            case "<?xml":
                break;
            case "<encryption":
            case "</encryption>":
                break;
            case "<keyData":
                r.forEach(function(o) {
                    a[o] = s[o]
                });
                break;
            case "<dataIntegrity":
                a.encryptedHmacKey = s.encryptedHmacKey, a.encryptedHmacValue = s.encryptedHmacValue;
                break;
            case "<keyEncryptors>":
            case "<keyEncryptors":
                a.encs = [];
                break;
            case "</keyEncryptors>":
                break;
            case "<keyEncryptor":
                a.uri = s.uri;
                break;
            case "</keyEncryptor>":
                break;
            case "<encryptedKey":
                a.encs.push(s);
                break;
            default:
                throw s[0]
        }
    }), a
}

function hm(e, r) {
    var t = {},
        a = t.EncryptionVersionInfo = ea(e, 4);
    if (r -= 4, a.Minor != 2) throw new Error("unrecognized minor version code: " + a.Minor);
    if (a.Major > 4 || a.Major < 2) throw new Error("unrecognized major version code: " + a.Major);
    t.Flags = e.read_shift(4), r -= 4;
    var i = e.read_shift(4);
    return r -= 4, t.EncryptionHeader = uf(e, i), r -= i, t.EncryptionVerifier = df(e, r), t
}

function pm(e) {
    var r = {},
        t = r.EncryptionVersionInfo = ea(e, 4);
    if (t.Major != 1 || t.Minor != 1) throw "unrecognized version code " + t.Major + " : " + t.Minor;
    return r.Salt = e.read_shift(16), r.EncryptedVerifier = e.read_shift(16), r.EncryptedVerifierHash = e.read_shift(16), r
}

function w0(e) {
    var r = 0,
        t, a = ff(e),
        i = a.length + 1,
        n, s, o, c, l;
    for (t = pa(i), t[0] = a.length, n = 1; n != i; ++n) t[n] = a[n - 1];
    for (n = i - 1; n >= 0; --n) s = t[n], o = (r & 16384) === 0 ? 0 : 1, c = r << 1 & 32767, l = o | c, r = l ^ s;
    return r ^ 52811
}
var hf = (function() {
        var e = [187, 255, 255, 186, 255, 255, 185, 128, 0, 190, 15, 0, 191, 15, 0],
            r = [57840, 7439, 52380, 33984, 4364, 3600, 61902, 12606, 6258, 57657, 54287, 34041, 10252, 43370, 20163],
            t = [44796, 19929, 39858, 10053, 20106, 40212, 10761, 31585, 63170, 64933, 60267, 50935, 40399, 11199, 17763, 35526, 1453, 2906, 5812, 11624, 23248, 885, 1770, 3540, 7080, 14160, 28320, 56640, 55369, 41139, 20807, 41614, 21821, 43642, 17621, 28485, 56970, 44341, 19019, 38038, 14605, 29210, 60195, 50791, 40175, 10751, 21502, 43004, 24537, 18387, 36774, 3949, 7898, 15796, 31592, 63184, 47201, 24803, 49606, 37805, 14203, 28406, 56812, 17824, 35648, 1697, 3394, 6788, 13576, 27152, 43601, 17539, 35078, 557, 1114, 2228, 4456, 30388, 60776, 51953, 34243, 7079, 14158, 28316, 14128, 28256, 56512, 43425, 17251, 34502, 7597, 13105, 26210, 52420, 35241, 883, 1766, 3532, 4129, 8258, 16516, 33032, 4657, 9314, 18628],
            a = function(s) {
                return (s / 2 | s * 128) & 255
            },
            i = function(s, o) {
                return a(s ^ o)
            },
            n = function(s) {
                for (var o = r[s.length - 1], c = 104, l = s.length - 1; l >= 0; --l)
                    for (var f = s[l], u = 0; u != 7; ++u) f & 64 && (o ^= t[c]), f *= 2, --c;
                return o
            };
        return function(s) {
            for (var o = ff(s), c = n(o), l = o.length, f = pa(16), u = 0; u != 16; ++u) f[u] = 0;
            var h, p, m;
            for ((l & 1) === 1 && (h = c >> 8, f[l] = i(e[0], h), --l, h = c & 255, p = o[o.length - 1], f[l] = i(p, h)); l > 0;) --l, h = c >> 8, f[l] = i(o[l], h), --l, h = c & 255, f[l] = i(o[l], h);
            for (l = 15, m = 15 - o.length; m > 0;) h = c >> 8, f[l] = i(e[m], h), --l, --m, h = c & 255, f[l] = i(o[l], h), --l, --m;
            return f
        }
    })(),
    mm = function(e, r, t, a, i) {
        i || (i = r), a || (a = hf(e));
        var n, s;
        for (n = 0; n != r.length; ++n) s = r[n], s ^= a[t], s = (s >> 5 | s << 3) & 255, i[n] = s, ++t;
        return [i, t, a]
    },
    xm = function(e) {
        var r = 0,
            t = hf(e);
        return function(a) {
            var i = mm("", a, r, t);
            return r = i[1], i[0]
        }
    };

function gm(e, r, t, a) {
    var i = {
        key: bt(e),
        verificationBytes: bt(e)
    };
    return t.password && (i.verifier = w0(t.password)), a.valid = i.verificationBytes === i.verifier, a.valid && (a.insitu = xm(t.password)), i
}

function _m(e, r, t) {
    var a = t || {};
    return a.Info = e.read_shift(2), e.l -= 2, a.Info === 1 ? a.Data = pm(e, r) : a.Data = hm(e, r), a
}

function vm(e, r, t) {
    var a = {
        Type: t.biff >= 8 ? e.read_shift(2) : 0
    };
    return a.Type ? _m(e, r - 2, a) : gm(e, t.biff >= 8 ? r : r - 2, t, a), a
}
var pf = (function() {
    function e(i, n) {
        switch (n.type) {
            case "base64":
                return r(pr(i), n);
            case "binary":
                return r(i, n);
            case "buffer":
                return r(Ue && Buffer.isBuffer(i) ? i.toString("binary") : _a(i), n);
            case "array":
                return r(Oa(i), n)
        }
        throw new Error("Unrecognized type " + n.type)
    }

    function r(i, n) {
        var s = n || {},
            o = s.dense ? [] : {},
            c = i.match(/\\trowd.*?\\row\b/g);
        if (!c.length) throw new Error("RTF missing table");
        var l = {
            s: {
                c: 0,
                r: 0
            },
            e: {
                c: 0,
                r: c.length - 1
            }
        };
        return c.forEach(function(f, u) {
            Array.isArray(o) && (o[u] = []);
            for (var h = /\\\w+\b/g, p = 0, m, d = -1; m = h.exec(f);) {
                switch (m[0]) {
                    case "\\cell":
                        var x = f.slice(p, h.lastIndex - m[0].length);
                        if (x[0] == " " && (x = x.slice(1)), ++d, x.length) {
                            var E = {
                                v: x,
                                t: "s"
                            };
                            Array.isArray(o) ? o[u][d] = E : o[Me({
                                r: u,
                                c: d
                            })] = E
                        }
                        break
                }
                p = h.lastIndex
            }
            d > l.e.c && (l.e.c = d)
        }), o["!ref"] = Ne(l), o
    }

    function t(i, n) {
        return va(e(i, n), n)
    }

    function a(i) {
        for (var n = ["{\\rtf1\\ansi"], s = Xe(i["!ref"]), o, c = Array.isArray(i), l = s.s.r; l <= s.e.r; ++l) {
            n.push("\\trowd\\trautofit1");
            for (var f = s.s.c; f <= s.e.c; ++f) n.push("\\cellx" + (f + 1));
            for (n.push("\\pard\\intbl"), f = s.s.c; f <= s.e.c; ++f) {
                var u = Me({
                    r: l,
                    c: f
                });
                o = c ? (i[l] || [])[f] : i[u], !(!o || o.v == null && (!o.f || o.F)) && (n.push(" " + (o.w || (ta(o), o.w))), n.push("\\cell"))
            }
            n.push("\\pard\\intbl\\row")
        }
        return n.join("") + "}"
    }
    return {
        to_workbook: t,
        to_sheet: e,
        from_sheet: a
    }
})();

function wm(e) {
    var r = e.slice(e[0] === "#" ? 1 : 0).slice(0, 6);
    return [parseInt(r.slice(0, 2), 16), parseInt(r.slice(2, 4), 16), parseInt(r.slice(4, 6), 16)]
}

function qi(e) {
    for (var r = 0, t = 1; r != 3; ++r) t = t * 256 + (e[r] > 255 ? 255 : e[r] < 0 ? 0 : e[r]);
    return t.toString(16).toUpperCase().slice(1)
}

function Sm(e) {
    var r = e[0] / 255,
        t = e[1] / 255,
        a = e[2] / 255,
        i = Math.max(r, t, a),
        n = Math.min(r, t, a),
        s = i - n;
    if (s === 0) return [0, 0, r];
    var o = 0,
        c = 0,
        l = i + n;
    switch (c = s / (l > 1 ? 2 - l : l), i) {
        case r:
            o = ((t - a) / s + 6) % 6;
            break;
        case t:
            o = (a - r) / s + 2;
            break;
        case a:
            o = (r - t) / s + 4;
            break
    }
    return [o / 6, c, l / 2]
}

function Em(e) {
    var r = e[0],
        t = e[1],
        a = e[2],
        i = t * 2 * (a < .5 ? a : 1 - a),
        n = a - i / 2,
        s = [n, n, n],
        o = 6 * r,
        c;
    if (t !== 0) switch (o | 0) {
        case 0:
        case 6:
            c = i * o, s[0] += i, s[1] += c;
            break;
        case 1:
            c = i * (2 - o), s[0] += c, s[1] += i;
            break;
        case 2:
            c = i * (o - 2), s[1] += i, s[2] += c;
            break;
        case 3:
            c = i * (4 - o), s[1] += c, s[2] += i;
            break;
        case 4:
            c = i * (o - 4), s[2] += i, s[0] += c;
            break;
        case 5:
            c = i * (6 - o), s[2] += c, s[0] += i;
            break
    }
    for (var l = 0; l != 3; ++l) s[l] = Math.round(s[l] * 255);
    return s
}

function Gn(e, r) {
    if (r === 0) return e;
    var t = Sm(wm(e));
    return r < 0 ? t[2] = t[2] * (1 + r) : t[2] = 1 - (1 - t[2]) * (1 - r), qi(Em(t))
}
var mf = 6,
    Cm = 15,
    Tm = 1,
    Gt = mf;

function ji(e) {
    return Math.floor((e + Math.round(128 / Gt) / 256) * Gt)
}

function $i(e) {
    return Math.floor((e - 5) / Gt * 100 + .5) / 100
}

function zn(e) {
    return Math.round((e * Gt + 5) / Gt * 256) / 256
}

function Ts(e) {
    return zn($i(ji(e)))
}

function S0(e) {
    var r = Math.abs(e - Ts(e)),
        t = Gt;
    if (r > .005)
        for (Gt = Tm; Gt < Cm; ++Gt) Math.abs(e - Ts(e)) <= r && (r = Math.abs(e - Ts(e)), t = Gt);
    Gt = t
}

function ma(e) {
    e.width ? (e.wpx = ji(e.width), e.wch = $i(e.wpx), e.MDW = Gt) : e.wpx ? (e.wch = $i(e.wpx), e.width = zn(e.wch), e.MDW = Gt) : typeof e.wch == "number" && (e.width = zn(e.wch), e.wpx = ji(e.width), e.MDW = Gt), e.customWidth && delete e.customWidth
}
var ym = 96,
    xf = ym;

function Yi(e) {
    return e * 96 / xf
}

function ci(e) {
    return e * xf / 96
}
var km = {
    None: "none",
    Solid: "solid",
    Gray50: "mediumGray",
    Gray75: "darkGray",
    Gray25: "lightGray",
    HorzStripe: "darkHorizontal",
    VertStripe: "darkVertical",
    ReverseDiagStripe: "darkDown",
    DiagStripe: "darkUp",
    DiagCross: "darkGrid",
    ThickDiagCross: "darkTrellis",
    ThinHorzStripe: "lightHorizontal",
    ThinVertStripe: "lightVertical",
    ThinReverseDiagStripe: "lightDown",
    ThinHorzCross: "lightGrid"
};

function Fm(e, r, t, a) {
    r.Borders = [];
    var i = {},
        n = !1;
    (e[0].match($t) || []).forEach(function(s) {
        var o = Oe(s);
        switch (Xr(o[0])) {
            case "<borders":
            case "<borders>":
            case "</borders>":
                break;
            case "<border":
            case "<border>":
            case "<border/>":
                i = {}, o.diagonalUp && (i.diagonalUp = lt(o.diagonalUp)), o.diagonalDown && (i.diagonalDown = lt(o.diagonalDown)), r.Borders.push(i);
                break;
            case "</border>":
                break;
            case "<left/>":
                break;
            case "<left":
            case "<left>":
                break;
            case "</left>":
                break;
            case "<right/>":
                break;
            case "<right":
            case "<right>":
                break;
            case "</right>":
                break;
            case "<top/>":
                break;
            case "<top":
            case "<top>":
                break;
            case "</top>":
                break;
            case "<bottom/>":
                break;
            case "<bottom":
            case "<bottom>":
                break;
            case "</bottom>":
                break;
            case "<diagonal":
            case "<diagonal>":
            case "<diagonal/>":
                break;
            case "</diagonal>":
                break;
            case "<horizontal":
            case "<horizontal>":
            case "<horizontal/>":
                break;
            case "</horizontal>":
                break;
            case "<vertical":
            case "<vertical>":
            case "<vertical/>":
                break;
            case "</vertical>":
                break;
            case "<start":
            case "<start>":
            case "<start/>":
                break;
            case "</start>":
                break;
            case "<end":
            case "<end>":
            case "<end/>":
                break;
            case "</end>":
                break;
            case "<color":
            case "<color>":
                break;
            case "<color/>":
            case "</color>":
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
                break;
            case "<ext":
                n = !0;
                break;
            case "</ext>":
                n = !1;
                break;
            default:
                if (a && a.WTF && !n) throw new Error("unrecognized " + o[0] + " in borders")
        }
    })
}

function Am(e, r, t, a) {
    r.Fills = [];
    var i = {},
        n = !1;
    (e[0].match($t) || []).forEach(function(s) {
        var o = Oe(s);
        switch (Xr(o[0])) {
            case "<fills":
            case "<fills>":
            case "</fills>":
                break;
            case "<fill>":
            case "<fill":
            case "<fill/>":
                i = {}, r.Fills.push(i);
                break;
            case "</fill>":
                break;
            case "<gradientFill>":
                break;
            case "<gradientFill":
            case "</gradientFill>":
                r.Fills.push(i), i = {};
                break;
            case "<patternFill":
            case "<patternFill>":
                o.patternType && (i.patternType = o.patternType);
                break;
            case "<patternFill/>":
            case "</patternFill>":
                break;
            case "<bgColor":
                i.bgColor || (i.bgColor = {}), o.indexed && (i.bgColor.indexed = parseInt(o.indexed, 10)), o.theme && (i.bgColor.theme = parseInt(o.theme, 10)), o.tint && (i.bgColor.tint = parseFloat(o.tint)), o.rgb && (i.bgColor.rgb = o.rgb.slice(-6));
                break;
            case "<bgColor/>":
            case "</bgColor>":
                break;
            case "<fgColor":
                i.fgColor || (i.fgColor = {}), o.theme && (i.fgColor.theme = parseInt(o.theme, 10)), o.tint && (i.fgColor.tint = parseFloat(o.tint)), o.rgb != null && (i.fgColor.rgb = o.rgb.slice(-6));
                break;
            case "<fgColor/>":
            case "</fgColor>":
                break;
            case "<stop":
            case "<stop/>":
                break;
            case "</stop>":
                break;
            case "<color":
            case "<color/>":
                break;
            case "</color>":
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
                break;
            case "<ext":
                n = !0;
                break;
            case "</ext>":
                n = !1;
                break;
            default:
                if (a && a.WTF && !n) throw new Error("unrecognized " + o[0] + " in fills")
        }
    })
}

function bm(e, r, t, a) {
    r.Fonts = [];
    var i = {},
        n = !1;
    (e[0].match($t) || []).forEach(function(s) {
        var o = Oe(s);
        switch (Xr(o[0])) {
            case "<fonts":
            case "<fonts>":
            case "</fonts>":
                break;
            case "<font":
            case "<font>":
                break;
            case "</font>":
            case "<font/>":
                r.Fonts.push(i), i = {};
                break;
            case "<name":
                o.val && (i.name = at(o.val));
                break;
            case "<name/>":
            case "</name>":
                break;
            case "<b":
                i.bold = o.val ? lt(o.val) : 1;
                break;
            case "<b/>":
                i.bold = 1;
                break;
            case "<i":
                i.italic = o.val ? lt(o.val) : 1;
                break;
            case "<i/>":
                i.italic = 1;
                break;
            case "<u":
                switch (o.val) {
                    case "none":
                        i.underline = 0;
                        break;
                    case "single":
                        i.underline = 1;
                        break;
                    case "double":
                        i.underline = 2;
                        break;
                    case "singleAccounting":
                        i.underline = 33;
                        break;
                    case "doubleAccounting":
                        i.underline = 34;
                        break
                }
                break;
            case "<u/>":
                i.underline = 1;
                break;
            case "<strike":
                i.strike = o.val ? lt(o.val) : 1;
                break;
            case "<strike/>":
                i.strike = 1;
                break;
            case "<outline":
                i.outline = o.val ? lt(o.val) : 1;
                break;
            case "<outline/>":
                i.outline = 1;
                break;
            case "<shadow":
                i.shadow = o.val ? lt(o.val) : 1;
                break;
            case "<shadow/>":
                i.shadow = 1;
                break;
            case "<condense":
                i.condense = o.val ? lt(o.val) : 1;
                break;
            case "<condense/>":
                i.condense = 1;
                break;
            case "<extend":
                i.extend = o.val ? lt(o.val) : 1;
                break;
            case "<extend/>":
                i.extend = 1;
                break;
            case "<sz":
                o.val && (i.sz = +o.val);
                break;
            case "<sz/>":
            case "</sz>":
                break;
            case "<vertAlign":
                o.val && (i.vertAlign = o.val);
                break;
            case "<vertAlign/>":
            case "</vertAlign>":
                break;
            case "<family":
                o.val && (i.family = parseInt(o.val, 10));
                break;
            case "<family/>":
            case "</family>":
                break;
            case "<scheme":
                o.val && (i.scheme = o.val);
                break;
            case "<scheme/>":
            case "</scheme>":
                break;
            case "<charset":
                if (o.val == "1") break;
                o.codepage = Xs[parseInt(o.val, 10)];
                break;
            case "<color":
                if (i.color || (i.color = {}), o.auto && (i.color.auto = lt(o.auto)), o.rgb) i.color.rgb = o.rgb.slice(-6);
                else if (o.indexed) {
                    i.color.index = parseInt(o.indexed, 10);
                    var c = Fa[i.color.index];
                    i.color.index == 81 && (c = Fa[1]), c || (c = Fa[1]), i.color.rgb = c[0].toString(16) + c[1].toString(16) + c[2].toString(16)
                } else o.theme && (i.color.theme = parseInt(o.theme, 10), o.tint && (i.color.tint = parseFloat(o.tint)), o.theme && t.themeElements && t.themeElements.clrScheme && (i.color.rgb = Gn(t.themeElements.clrScheme[i.color.theme].rgb, i.color.tint || 0)));
                break;
            case "<color/>":
            case "</color>":
                break;
            case "<AlternateContent":
                n = !0;
                break;
            case "</AlternateContent>":
                n = !1;
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
                break;
            case "<ext":
                n = !0;
                break;
            case "</ext>":
                n = !1;
                break;
            default:
                if (a && a.WTF && !n) throw new Error("unrecognized " + o[0] + " in fonts")
        }
    })
}

function Im(e, r, t) {
    r.NumberFmt = [];
    for (var a = vt(Ie), i = 0; i < a.length; ++i) r.NumberFmt[a[i]] = Ie[a[i]];
    var n = e[0].match($t);
    if (n)
        for (i = 0; i < n.length; ++i) {
            var s = Oe(n[i]);
            switch (Xr(s[0])) {
                case "<numFmts":
                case "</numFmts>":
                case "<numFmts/>":
                case "<numFmts>":
                    break;
                case "<numFmt":
                    {
                        var o = ze(at(s.formatCode)),
                            c = parseInt(s.numFmtId, 10);
                        if (r.NumberFmt[c] = o, c > 0) {
                            if (c > 392) {
                                for (c = 392; c > 60 && r.NumberFmt[c] != null; --c);
                                r.NumberFmt[c] = o
                            }
                            Qr(o, c)
                        }
                    }
                    break;
                case "</numFmt>":
                    break;
                default:
                    if (t.WTF) throw new Error("unrecognized " + s[0] + " in numFmts")
            }
        }
}

function Mm(e) {
    var r = ["<numFmts>"];
    return [
        [5, 8],
        [23, 26],
        [41, 44],
        [50, 392]
    ].forEach(function(t) {
        for (var a = t[0]; a <= t[1]; ++a) e[a] != null && (r[r.length] = ce("numFmt", null, {
            numFmtId: a,
            formatCode: tt(e[a])
        }))
    }), r.length === 1 ? "" : (r[r.length] = "</numFmts>", r[0] = ce("numFmts", null, {
        count: r.length - 2
    }).replace("/>", ">"), r.join(""))
}
var In = ["numFmtId", "fillId", "fontId", "borderId", "xfId"],
    Mn = ["applyAlignment", "applyBorder", "applyFill", "applyFont", "applyNumberFormat", "applyProtection", "pivotButton", "quotePrefix"];

function Om(e, r, t) {
    r.CellXf = [];
    var a, i = !1;
    (e[0].match($t) || []).forEach(function(n) {
        var s = Oe(n),
            o = 0;
        switch (Xr(s[0])) {
            case "<cellXfs":
            case "<cellXfs>":
            case "<cellXfs/>":
            case "</cellXfs>":
                break;
            case "<xf":
            case "<xf/>":
                for (a = s, delete a[0], o = 0; o < In.length; ++o) a[In[o]] && (a[In[o]] = parseInt(a[In[o]], 10));
                for (o = 0; o < Mn.length; ++o) a[Mn[o]] && (a[Mn[o]] = lt(a[Mn[o]]));
                if (r.NumberFmt && a.numFmtId > 392) {
                    for (o = 392; o > 60; --o)
                        if (r.NumberFmt[a.numFmtId] == r.NumberFmt[o]) {
                            a.numFmtId = o;
                            break
                        }
                }
                r.CellXf.push(a);
                break;
            case "</xf>":
                break;
            case "<alignment":
            case "<alignment/>":
                var c = {};
                s.vertical && (c.vertical = s.vertical), s.horizontal && (c.horizontal = s.horizontal), s.textRotation != null && (c.textRotation = s.textRotation), s.indent && (c.indent = s.indent), s.wrapText && (c.wrapText = lt(s.wrapText)), a.alignment = c;
                break;
            case "</alignment>":
                break;
            case "<protection":
                break;
            case "</protection>":
            case "<protection/>":
                break;
            case "<AlternateContent":
                i = !0;
                break;
            case "</AlternateContent>":
                i = !1;
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
                break;
            case "<ext":
                i = !0;
                break;
            case "</ext>":
                i = !1;
                break;
            default:
                if (t && t.WTF && !i) throw new Error("unrecognized " + s[0] + " in cellXfs")
        }
    })
}

function Dm(e) {
    var r = [];
    return r[r.length] = ce("cellXfs", null), e.forEach(function(t) {
        r[r.length] = ce("xf", null, t)
    }), r[r.length] = "</cellXfs>", r.length === 2 ? "" : (r[0] = ce("cellXfs", null, {
        count: r.length - 2
    }).replace("/>", ">"), r.join(""))
}
var Rm = (function() {
    var r = /<(?:\w+:)?numFmts([^>]*)>[\S\s]*?<\/(?:\w+:)?numFmts>/,
        t = /<(?:\w+:)?cellXfs([^>]*)>[\S\s]*?<\/(?:\w+:)?cellXfs>/,
        a = /<(?:\w+:)?fills([^>]*)>[\S\s]*?<\/(?:\w+:)?fills>/,
        i = /<(?:\w+:)?fonts([^>]*)>[\S\s]*?<\/(?:\w+:)?fonts>/,
        n = /<(?:\w+:)?borders([^>]*)>[\S\s]*?<\/(?:\w+:)?borders>/;
    return function(o, c, l) {
        var f = {};
        if (!o) return f;
        o = o.replace(/<!--([\s\S]*?)-->/mg, "").replace(/<!DOCTYPE[^\[]*\[[^\]]*\]>/gm, "");
        var u;
        return (u = o.match(r)) && Im(u, f, l), (u = o.match(i)) && bm(u, f, c, l), (u = o.match(a)) && Am(u, f, c, l), (u = o.match(n)) && Fm(u, f, c, l), (u = o.match(t)) && Om(u, f, l), f
    }
})();

function gf(e, r) {
    var t = [yt, ce("styleSheet", null, {
            xmlns: La[0],
            "xmlns:vt": Mt.vt
        })],
        a;
    return e.SSF && (a = Mm(e.SSF)) != null && (t[t.length] = a), t[t.length] = '<fonts count="1"><font><sz val="12"/><color theme="1"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font></fonts>', t[t.length] = '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>', t[t.length] = '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>', t[t.length] = '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>', (a = Dm(r.cellXfs)) && (t[t.length] = a), t[t.length] = '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>', t[t.length] = '<dxfs count="0"/>', t[t.length] = '<tableStyles count="0" defaultTableStyle="TableStyleMedium9" defaultPivotStyle="PivotStyleMedium4"/>', t.length > 2 && (t[t.length] = "</styleSheet>", t[1] = t[1].replace("/>", ">")), t.join("")
}

function Pm(e, r) {
    var t = e.read_shift(2),
        a = qt(e, r - 2);
    return [t, a]
}

function Nm(e, r, t) {
    t || (t = Y(6 + 4 * r.length)), t.write_shift(2, e), Nt(r, t);
    var a = t.length > t.l ? t.slice(0, t.l) : t;
    return t.l == null && (t.l = t.length), a
}

function Lm(e, r, t) {
    var a = {};
    a.sz = e.read_shift(2) / 20;
    var i = _h(e, 2, t);
    i.fItalic && (a.italic = 1), i.fCondense && (a.condense = 1), i.fExtend && (a.extend = 1), i.fShadow && (a.shadow = 1), i.fOutline && (a.outline = 1), i.fStrikeout && (a.strike = 1);
    var n = e.read_shift(2);
    switch (n === 700 && (a.bold = 1), e.read_shift(2)) {
        case 1:
            a.vertAlign = "superscript";
            break;
        case 2:
            a.vertAlign = "subscript";
            break
    }
    var s = e.read_shift(1);
    s != 0 && (a.underline = s);
    var o = e.read_shift(1);
    o > 0 && (a.family = o);
    var c = e.read_shift(1);
    switch (c > 0 && (a.charset = c), e.l++, a.color = gh(e, 8), e.read_shift(1)) {
        case 1:
            a.scheme = "major";
            break;
        case 2:
            a.scheme = "minor";
            break
    }
    return a.name = qt(e, r - 21), a
}

function Bm(e, r) {
    r || (r = Y(153)), r.write_shift(2, e.sz * 20), vh(e, r), r.write_shift(2, e.bold ? 700 : 400);
    var t = 0;
    e.vertAlign == "superscript" ? t = 1 : e.vertAlign == "subscript" && (t = 2), r.write_shift(2, t), r.write_shift(1, e.underline || 0), r.write_shift(1, e.family || 0), r.write_shift(1, e.charset || 0), r.write_shift(1, 0), Vn(e.color, r);
    var a = 0;
    return e.scheme == "major" && (a = 1), e.scheme == "minor" && (a = 2), r.write_shift(1, a), Nt(e.name, r), r.length > r.l ? r.slice(0, r.l) : r
}
var Um = ["none", "solid", "mediumGray", "darkGray", "lightGray", "darkHorizontal", "darkVertical", "darkDown", "darkUp", "darkGrid", "darkTrellis", "lightHorizontal", "lightVertical", "lightDown", "lightUp", "lightGrid", "lightTrellis", "gray125", "gray0625"],
    ys, Vm = jt;

function Rc(e, r) {
    r || (r = Y(84)), ys || (ys = Yn(Um));
    var t = ys[e.patternType];
    t == null && (t = 40), r.write_shift(4, t);
    var a = 0;
    if (t != 40)
        for (Vn({
                auto: 1
            }, r), Vn({
                auto: 1
            }, r); a < 12; ++a) r.write_shift(4, 0);
    else {
        for (; a < 4; ++a) r.write_shift(4, 0);
        for (; a < 12; ++a) r.write_shift(4, 0)
    }
    return r.length > r.l ? r.slice(0, r.l) : r
}

function Wm(e, r) {
    var t = e.l + r,
        a = e.read_shift(2),
        i = e.read_shift(2);
    return e.l = t, {
        ixfe: a,
        numFmtId: i
    }
}

function _f(e, r, t) {
    t || (t = Y(16)), t.write_shift(2, r || 0), t.write_shift(2, e.numFmtId || 0), t.write_shift(2, 0), t.write_shift(2, 0), t.write_shift(2, 0), t.write_shift(1, 0), t.write_shift(1, 0);
    var a = 0;
    return t.write_shift(1, a), t.write_shift(1, 0), t.write_shift(1, 0), t.write_shift(1, 0), t
}

function Fi(e, r) {
    return r || (r = Y(10)), r.write_shift(1, 0), r.write_shift(1, 0), r.write_shift(4, 0), r.write_shift(4, 0), r
}
var Hm = jt;

function Gm(e, r) {
    return r || (r = Y(51)), r.write_shift(1, 0), Fi(null, r), Fi(null, r), Fi(null, r), Fi(null, r), Fi(null, r), r.length > r.l ? r.slice(0, r.l) : r
}

function zm(e, r) {
    return r || (r = Y(52)), r.write_shift(4, e.xfId), r.write_shift(2, 1), r.write_shift(1, +e.builtinId), r.write_shift(1, 0), Un(e.name || "", r), r.length > r.l ? r.slice(0, r.l) : r
}

function Xm(e, r, t) {
    var a = Y(2052);
    return a.write_shift(4, e), Un(r, a), Un(t, a), a.length > a.l ? a.slice(0, a.l) : a
}

function qm(e, r, t) {
    var a = {};
    a.NumberFmt = [];
    for (var i in Ie) a.NumberFmt[i] = Ie[i];
    a.CellXf = [], a.Fonts = [];
    var n = [],
        s = !1;
    return aa(e, function(c, l, f) {
        switch (f) {
            case 44:
                a.NumberFmt[c[0]] = c[1], Qr(c[1], c[0]);
                break;
            case 43:
                a.Fonts.push(c), c.color.theme != null && r && r.themeElements && r.themeElements.clrScheme && (c.color.rgb = Gn(r.themeElements.clrScheme[c.color.theme].rgb, c.color.tint || 0));
                break;
            case 1025:
                break;
            case 45:
                break;
            case 46:
                break;
            case 47:
                n[n.length - 1] == 617 && a.CellXf.push(c);
                break;
            case 48:
            case 507:
            case 572:
            case 475:
                break;
            case 1171:
            case 2102:
            case 1130:
            case 512:
            case 2095:
            case 3072:
                break;
            case 35:
                s = !0;
                break;
            case 36:
                s = !1;
                break;
            case 37:
                n.push(f), s = !0;
                break;
            case 38:
                n.pop(), s = !1;
                break;
            default:
                if (l.T > 0) n.push(f);
                else if (l.T < 0) n.pop();
                else if (!s || t.WTF && n[n.length - 1] != 37) throw new Error("Unexpected record 0x" + f.toString(16))
        }
    }), a
}

function jm(e, r) {
    if (r) {
        var t = 0;
        [
            [5, 8],
            [23, 26],
            [41, 44],
            [50, 392]
        ].forEach(function(a) {
            for (var i = a[0]; i <= a[1]; ++i) r[i] != null && ++t
        }), t != 0 && (ee(e, 615, Lr(t)), [
            [5, 8],
            [23, 26],
            [41, 44],
            [50, 392]
        ].forEach(function(a) {
            for (var i = a[0]; i <= a[1]; ++i) r[i] != null && ee(e, 44, Nm(i, r[i]))
        }), ee(e, 616))
    }
}

function $m(e) {
    var r = 1;
    r != 0 && (ee(e, 611, Lr(r)), ee(e, 43, Bm({
        sz: 12,
        color: {
            theme: 1
        },
        name: "Calibri",
        family: 2,
        scheme: "minor"
    })), ee(e, 612))
}

function Ym(e) {
    var r = 2;
    r != 0 && (ee(e, 603, Lr(r)), ee(e, 45, Rc({
        patternType: "none"
    })), ee(e, 45, Rc({
        patternType: "gray125"
    })), ee(e, 604))
}

function Km(e) {
    var r = 1;
    r != 0 && (ee(e, 613, Lr(r)), ee(e, 46, Gm({})), ee(e, 614))
}

function Jm(e) {
    var r = 1;
    ee(e, 626, Lr(r)), ee(e, 47, _f({
        numFmtId: 0,
        fontId: 0,
        fillId: 0,
        borderId: 0
    }, 65535)), ee(e, 627)
}

function Zm(e, r) {
    ee(e, 617, Lr(r.length)), r.forEach(function(t) {
        ee(e, 47, _f(t, 0))
    }), ee(e, 618)
}

function Qm(e) {
    var r = 1;
    ee(e, 619, Lr(r)), ee(e, 48, zm({
        xfId: 0,
        builtinId: 0,
        name: "Normal"
    })), ee(e, 620)
}

function ex(e) {
    var r = 0;
    ee(e, 505, Lr(r)), ee(e, 506)
}

function tx(e) {
    var r = 0;
    ee(e, 508, Xm(r, "TableStyleMedium9", "PivotStyleMedium4")), ee(e, 509)
}

function rx(e, r) {
    var t = sr();
    return ee(t, 278), jm(t, e.SSF), $m(t, e), Ym(t, e), Km(t, e), Jm(t, e), Zm(t, r.cellXfs), Qm(t, e), ex(t, e), tx(t, e), ee(t, 279), t.end()
}
var ax = ["</a:lt1>", "</a:dk1>", "</a:lt2>", "</a:dk2>", "</a:accent1>", "</a:accent2>", "</a:accent3>", "</a:accent4>", "</a:accent5>", "</a:accent6>", "</a:hlink>", "</a:folHlink>"];

function ix(e, r, t) {
    r.themeElements.clrScheme = [];
    var a = {};
    (e[0].match($t) || []).forEach(function(i) {
        var n = Oe(i);
        switch (n[0]) {
            case "<a:clrScheme":
            case "</a:clrScheme>":
                break;
            case "<a:srgbClr":
                a.rgb = n.val;
                break;
            case "<a:sysClr":
                a.rgb = n.lastClr;
                break;
            case "<a:dk1>":
            case "</a:dk1>":
            case "<a:lt1>":
            case "</a:lt1>":
            case "<a:dk2>":
            case "</a:dk2>":
            case "<a:lt2>":
            case "</a:lt2>":
            case "<a:accent1>":
            case "</a:accent1>":
            case "<a:accent2>":
            case "</a:accent2>":
            case "<a:accent3>":
            case "</a:accent3>":
            case "<a:accent4>":
            case "</a:accent4>":
            case "<a:accent5>":
            case "</a:accent5>":
            case "<a:accent6>":
            case "</a:accent6>":
            case "<a:hlink>":
            case "</a:hlink>":
            case "<a:folHlink>":
            case "</a:folHlink>":
                n[0].charAt(1) === "/" ? (r.themeElements.clrScheme[ax.indexOf(n[0])] = a, a = {}) : a.name = n[0].slice(3, n[0].length - 1);
                break;
            default:
                if (t && t.WTF) throw new Error("Unrecognized " + n[0] + " in clrScheme")
        }
    })
}

function nx() {}

function sx() {}
var ox = /<a:clrScheme([^>]*)>[\s\S]*<\/a:clrScheme>/,
    cx = /<a:fontScheme([^>]*)>[\s\S]*<\/a:fontScheme>/,
    lx = /<a:fmtScheme([^>]*)>[\s\S]*<\/a:fmtScheme>/;

function fx(e, r, t) {
    r.themeElements = {};
    var a;
    [
        ["clrScheme", ox, ix],
        ["fontScheme", cx, nx],
        ["fmtScheme", lx, sx]
    ].forEach(function(i) {
        if (!(a = e.match(i[1]))) throw new Error(i[0] + " not found in themeElements");
        i[2](a, r, t)
    })
}
var ux = /<a:themeElements([^>]*)>[\s\S]*<\/a:themeElements>/;

function vf(e, r) {
    (!e || e.length === 0) && (e = E0());
    var t, a = {};
    if (!(t = e.match(ux))) throw new Error("themeElements not found in theme");
    return fx(t[0], a, r), a.raw = e, a
}

function E0(e, r) {
    if (r && r.themeXLSX) return r.themeXLSX;
    if (e && typeof e.raw == "string") return e.raw;
    var t = [yt];
    return t[t.length] = '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">', t[t.length] = "<a:themeElements>", t[t.length] = '<a:clrScheme name="Office">', t[t.length] = '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>', t[t.length] = '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>', t[t.length] = '<a:dk2><a:srgbClr val="1F497D"/></a:dk2>', t[t.length] = '<a:lt2><a:srgbClr val="EEECE1"/></a:lt2>', t[t.length] = '<a:accent1><a:srgbClr val="4F81BD"/></a:accent1>', t[t.length] = '<a:accent2><a:srgbClr val="C0504D"/></a:accent2>', t[t.length] = '<a:accent3><a:srgbClr val="9BBB59"/></a:accent3>', t[t.length] = '<a:accent4><a:srgbClr val="8064A2"/></a:accent4>', t[t.length] = '<a:accent5><a:srgbClr val="4BACC6"/></a:accent5>', t[t.length] = '<a:accent6><a:srgbClr val="F79646"/></a:accent6>', t[t.length] = '<a:hlink><a:srgbClr val="0000FF"/></a:hlink>', t[t.length] = '<a:folHlink><a:srgbClr val="800080"/></a:folHlink>', t[t.length] = "</a:clrScheme>", t[t.length] = '<a:fontScheme name="Office">', t[t.length] = "<a:majorFont>", t[t.length] = '<a:latin typeface="Cambria"/>', t[t.length] = '<a:ea typeface=""/>', t[t.length] = '<a:cs typeface=""/>', t[t.length] = '<a:font script="Jpan" typeface="\uFF2D\uFF33 \uFF30\u30B4\u30B7\u30C3\u30AF"/>', t[t.length] = '<a:font script="Hang" typeface="\uB9D1\uC740 \uACE0\uB515"/>', t[t.length] = '<a:font script="Hans" typeface="\u5B8B\u4F53"/>', t[t.length] = '<a:font script="Hant" typeface="\u65B0\u7D30\u660E\u9AD4"/>', t[t.length] = '<a:font script="Arab" typeface="Times New Roman"/>', t[t.length] = '<a:font script="Hebr" typeface="Times New Roman"/>', t[t.length] = '<a:font script="Thai" typeface="Tahoma"/>', t[t.length] = '<a:font script="Ethi" typeface="Nyala"/>', t[t.length] = '<a:font script="Beng" typeface="Vrinda"/>', t[t.length] = '<a:font script="Gujr" typeface="Shruti"/>', t[t.length] = '<a:font script="Khmr" typeface="MoolBoran"/>', t[t.length] = '<a:font script="Knda" typeface="Tunga"/>', t[t.length] = '<a:font script="Guru" typeface="Raavi"/>', t[t.length] = '<a:font script="Cans" typeface="Euphemia"/>', t[t.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', t[t.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', t[t.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', t[t.length] = '<a:font script="Thaa" typeface="MV Boli"/>', t[t.length] = '<a:font script="Deva" typeface="Mangal"/>', t[t.length] = '<a:font script="Telu" typeface="Gautami"/>', t[t.length] = '<a:font script="Taml" typeface="Latha"/>', t[t.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', t[t.length] = '<a:font script="Orya" typeface="Kalinga"/>', t[t.length] = '<a:font script="Mlym" typeface="Kartika"/>', t[t.length] = '<a:font script="Laoo" typeface="DokChampa"/>', t[t.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', t[t.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', t[t.length] = '<a:font script="Viet" typeface="Times New Roman"/>', t[t.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', t[t.length] = '<a:font script="Geor" typeface="Sylfaen"/>', t[t.length] = "</a:majorFont>", t[t.length] = "<a:minorFont>", t[t.length] = '<a:latin typeface="Calibri"/>', t[t.length] = '<a:ea typeface=""/>', t[t.length] = '<a:cs typeface=""/>', t[t.length] = '<a:font script="Jpan" typeface="\uFF2D\uFF33 \uFF30\u30B4\u30B7\u30C3\u30AF"/>', t[t.length] = '<a:font script="Hang" typeface="\uB9D1\uC740 \uACE0\uB515"/>', t[t.length] = '<a:font script="Hans" typeface="\u5B8B\u4F53"/>', t[t.length] = '<a:font script="Hant" typeface="\u65B0\u7D30\u660E\u9AD4"/>', t[t.length] = '<a:font script="Arab" typeface="Arial"/>', t[t.length] = '<a:font script="Hebr" typeface="Arial"/>', t[t.length] = '<a:font script="Thai" typeface="Tahoma"/>', t[t.length] = '<a:font script="Ethi" typeface="Nyala"/>', t[t.length] = '<a:font script="Beng" typeface="Vrinda"/>', t[t.length] = '<a:font script="Gujr" typeface="Shruti"/>', t[t.length] = '<a:font script="Khmr" typeface="DaunPenh"/>', t[t.length] = '<a:font script="Knda" typeface="Tunga"/>', t[t.length] = '<a:font script="Guru" typeface="Raavi"/>', t[t.length] = '<a:font script="Cans" typeface="Euphemia"/>', t[t.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', t[t.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', t[t.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', t[t.length] = '<a:font script="Thaa" typeface="MV Boli"/>', t[t.length] = '<a:font script="Deva" typeface="Mangal"/>', t[t.length] = '<a:font script="Telu" typeface="Gautami"/>', t[t.length] = '<a:font script="Taml" typeface="Latha"/>', t[t.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', t[t.length] = '<a:font script="Orya" typeface="Kalinga"/>', t[t.length] = '<a:font script="Mlym" typeface="Kartika"/>', t[t.length] = '<a:font script="Laoo" typeface="DokChampa"/>', t[t.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', t[t.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', t[t.length] = '<a:font script="Viet" typeface="Arial"/>', t[t.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', t[t.length] = '<a:font script="Geor" typeface="Sylfaen"/>', t[t.length] = "</a:minorFont>", t[t.length] = "</a:fontScheme>", t[t.length] = '<a:fmtScheme name="Office">', t[t.length] = "<a:fillStyleLst>", t[t.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', t[t.length] = '<a:gradFill rotWithShape="1">', t[t.length] = "<a:gsLst>", t[t.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', t[t.length] = '<a:gs pos="35000"><a:schemeClr val="phClr"><a:tint val="37000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', t[t.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', t[t.length] = "</a:gsLst>", t[t.length] = '<a:lin ang="16200000" scaled="1"/>', t[t.length] = "</a:gradFill>", t[t.length] = '<a:gradFill rotWithShape="1">', t[t.length] = "<a:gsLst>", t[t.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="100000"/><a:shade val="100000"/><a:satMod val="130000"/></a:schemeClr></a:gs>', t[t.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="50000"/><a:shade val="100000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', t[t.length] = "</a:gsLst>", t[t.length] = '<a:lin ang="16200000" scaled="0"/>', t[t.length] = "</a:gradFill>", t[t.length] = "</a:fillStyleLst>", t[t.length] = "<a:lnStyleLst>", t[t.length] = '<a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"><a:shade val="95000"/><a:satMod val="105000"/></a:schemeClr></a:solidFill><a:prstDash val="solid"/></a:ln>', t[t.length] = '<a:ln w="25400" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', t[t.length] = '<a:ln w="38100" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', t[t.length] = "</a:lnStyleLst>", t[t.length] = "<a:effectStyleLst>", t[t.length] = "<a:effectStyle>", t[t.length] = "<a:effectLst>", t[t.length] = '<a:outerShdw blurRad="40000" dist="20000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="38000"/></a:srgbClr></a:outerShdw>', t[t.length] = "</a:effectLst>", t[t.length] = "</a:effectStyle>", t[t.length] = "<a:effectStyle>", t[t.length] = "<a:effectLst>", t[t.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', t[t.length] = "</a:effectLst>", t[t.length] = "</a:effectStyle>", t[t.length] = "<a:effectStyle>", t[t.length] = "<a:effectLst>", t[t.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', t[t.length] = "</a:effectLst>", t[t.length] = '<a:scene3d><a:camera prst="orthographicFront"><a:rot lat="0" lon="0" rev="0"/></a:camera><a:lightRig rig="threePt" dir="t"><a:rot lat="0" lon="0" rev="1200000"/></a:lightRig></a:scene3d>', t[t.length] = '<a:sp3d><a:bevelT w="63500" h="25400"/></a:sp3d>', t[t.length] = "</a:effectStyle>", t[t.length] = "</a:effectStyleLst>", t[t.length] = "<a:bgFillStyleLst>", t[t.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', t[t.length] = '<a:gradFill rotWithShape="1">', t[t.length] = "<a:gsLst>", t[t.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="40000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', t[t.length] = '<a:gs pos="40000"><a:schemeClr val="phClr"><a:tint val="45000"/><a:shade val="99000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', t[t.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="20000"/><a:satMod val="255000"/></a:schemeClr></a:gs>', t[t.length] = "</a:gsLst>", t[t.length] = '<a:path path="circle"><a:fillToRect l="50000" t="-80000" r="50000" b="180000"/></a:path>', t[t.length] = "</a:gradFill>", t[t.length] = '<a:gradFill rotWithShape="1">', t[t.length] = "<a:gsLst>", t[t.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="80000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', t[t.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="30000"/><a:satMod val="200000"/></a:schemeClr></a:gs>', t[t.length] = "</a:gsLst>", t[t.length] = '<a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path>', t[t.length] = "</a:gradFill>", t[t.length] = "</a:bgFillStyleLst>", t[t.length] = "</a:fmtScheme>", t[t.length] = "</a:themeElements>", t[t.length] = "<a:objectDefaults>", t[t.length] = "<a:spDef>", t[t.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="1"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="3"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="2"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="lt1"/></a:fontRef></a:style>', t[t.length] = "</a:spDef>", t[t.length] = "<a:lnDef>", t[t.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="2"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="1"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="tx1"/></a:fontRef></a:style>', t[t.length] = "</a:lnDef>", t[t.length] = "</a:objectDefaults>", t[t.length] = "<a:extraClrSchemeLst/>", t[t.length] = "</a:theme>", t.join("")
}

function dx(e, r, t) {
    var a = e.l + r,
        i = e.read_shift(4);
    if (i !== 124226) {
        if (!t.cellStyles) {
            e.l = a;
            return
        }
        var n = e.slice(e.l);
        e.l = a;
        var s;
        try {
            s = ml(n, {
                type: "array"
            })
        } catch (c) {
            return
        }
        var o = hr(s, "theme/theme/theme1.xml", !0);
        if (o) return vf(o, t)
    }
}

function hx(e) {
    return e.read_shift(4)
}

function px(e) {
    var r = {};
    switch (r.xclrType = e.read_shift(2), r.nTintShade = e.read_shift(2), r.xclrType) {
        case 0:
            e.l += 4;
            break;
        case 1:
            r.xclrValue = mx(e, 4);
            break;
        case 2:
            r.xclrValue = Jl(e, 4);
            break;
        case 3:
            r.xclrValue = hx(e, 4);
            break;
        case 4:
            e.l += 4;
            break
    }
    return e.l += 8, r
}

function mx(e, r) {
    return jt(e, r)
}

function xx(e, r) {
    return jt(e, r)
}

function gx(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2) - 4,
        a = [r];
    switch (r) {
        case 4:
        case 5:
        case 7:
        case 8:
        case 9:
        case 10:
        case 11:
        case 13:
            a[1] = px(e, t);
            break;
        case 6:
            a[1] = xx(e, t);
            break;
        case 14:
        case 15:
            a[1] = e.read_shift(t === 1 ? 1 : 2);
            break;
        default:
            throw new Error("Unrecognized ExtProp type: " + r + " " + t)
    }
    return a
}

function _x(e, r) {
    var t = e.l + r;
    e.l += 2;
    var a = e.read_shift(2);
    e.l += 2;
    for (var i = e.read_shift(2), n = []; i-- > 0;) n.push(gx(e, t - e.l));
    return {
        ixfe: a,
        ext: n
    }
}

function vx(e, r) {
    r.forEach(function(t) {
        switch (t[0]) {
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            case 10:
                break;
            case 11:
                break;
            case 13:
                break;
            case 14:
                break;
            case 15:
                break
        }
    })
}

function wx(e, r) {
    return {
        flags: e.read_shift(4),
        version: e.read_shift(4),
        name: qt(e, r - 8)
    }
}

function Sx(e) {
    var r = Y(12 + 2 * e.name.length);
    return r.write_shift(4, e.flags), r.write_shift(4, e.version), Nt(e.name, r), r.slice(0, r.l)
}

function Ex(e) {
    for (var r = [], t = e.read_shift(4); t-- > 0;) r.push([e.read_shift(4), e.read_shift(4)]);
    return r
}

function Cx(e) {
    var r = Y(4 + 8 * e.length);
    r.write_shift(4, e.length);
    for (var t = 0; t < e.length; ++t) r.write_shift(4, e[t][0]), r.write_shift(4, e[t][1]);
    return r
}

function Tx(e, r) {
    var t = Y(8 + 2 * r.length);
    return t.write_shift(4, e), Nt(r, t), t.slice(0, t.l)
}

function yx(e) {
    return e.l += 4, e.read_shift(4) != 0
}

function kx(e, r) {
    var t = Y(8);
    return t.write_shift(4, e), t.write_shift(4, r ? 1 : 0), t
}

function Fx(e, r, t) {
    var a = {
            Types: [],
            Cell: [],
            Value: []
        },
        i = t || {},
        n = [],
        s = !1,
        o = 2;
    return aa(e, function(c, l, f) {
        switch (f) {
            case 335:
                a.Types.push({
                    name: c.name
                });
                break;
            case 51:
                c.forEach(function(u) {
                    o == 1 ? a.Cell.push({
                        type: a.Types[u[0] - 1].name,
                        index: u[1]
                    }) : o == 0 && a.Value.push({
                        type: a.Types[u[0] - 1].name,
                        index: u[1]
                    })
                });
                break;
            case 337:
                o = c ? 1 : 0;
                break;
            case 338:
                o = 2;
                break;
            case 35:
                n.push(f), s = !0;
                break;
            case 36:
                n.pop(), s = !1;
                break;
            default:
                if (!l.T) {
                    if (!s || i.WTF && n[n.length - 1] != 35) throw new Error("Unexpected record 0x" + f.toString(16))
                }
        }
    }), a
}

function Ax() {
    var e = sr();
    return ee(e, 332), ee(e, 334, Lr(1)), ee(e, 335, Sx({
        name: "XLDAPR",
        version: 12e4,
        flags: 3496657072
    })), ee(e, 336), ee(e, 339, Tx(1, "XLDAPR")), ee(e, 52), ee(e, 35, Lr(514)), ee(e, 4096, Lr(0)), ee(e, 4097, Ar(1)), ee(e, 36), ee(e, 53), ee(e, 340), ee(e, 337, kx(1, !0)), ee(e, 51, Cx([
        [1, 0]
    ])), ee(e, 338), ee(e, 333), e.end()
}

function bx(e, r, t) {
    var a = {
        Types: [],
        Cell: [],
        Value: []
    };
    if (!e) return a;
    var i = !1,
        n = 2,
        s;
    return e.replace($t, function(o) {
        var c = Oe(o);
        switch (Xr(c[0])) {
            case "<?xml":
                break;
            case "<metadata":
            case "</metadata>":
                break;
            case "<metadataTypes":
            case "</metadataTypes>":
                break;
            case "<metadataType":
                a.Types.push({
                    name: c.name
                });
                break;
            case "</metadataType>":
                break;
            case "<futureMetadata":
                for (var l = 0; l < a.Types.length; ++l) a.Types[l].name == c.name && (s = a.Types[l]);
                break;
            case "</futureMetadata>":
                break;
            case "<bk>":
                break;
            case "</bk>":
                break;
            case "<rc":
                n == 1 ? a.Cell.push({
                    type: a.Types[c.t - 1].name,
                    index: +c.v
                }) : n == 0 && a.Value.push({
                    type: a.Types[c.t - 1].name,
                    index: +c.v
                });
                break;
            case "</rc>":
                break;
            case "<cellMetadata":
                n = 1;
                break;
            case "</cellMetadata>":
                n = 2;
                break;
            case "<valueMetadata":
                n = 0;
                break;
            case "</valueMetadata>":
                n = 2;
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
            case "<extLst/>":
                break;
            case "<ext":
                i = !0;
                break;
            case "</ext>":
                i = !1;
                break;
            case "<rvb":
                if (!s) break;
                s.offsets || (s.offsets = []), s.offsets.push(+c.i);
                break;
            default:
                if (!i && t.WTF) throw new Error("unrecognized " + c[0] + " in metadata")
        }
        return o
    }), a
}

function wf() {
    var e = [yt];
    return e.push(`<metadata xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:xlrd="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata" xmlns:xda="http://schemas.microsoft.com/office/spreadsheetml/2017/dynamicarray">
  <metadataTypes count="1">
    <metadataType name="XLDAPR" minSupportedVersion="120000" copy="1" pasteAll="1" pasteValues="1" merge="1" splitFirst="1" rowColShift="1" clearFormats="1" clearComments="1" assign="1" coerce="1" cellMeta="1"/>
  </metadataTypes>
  <futureMetadata name="XLDAPR" count="1">
    <bk>
      <extLst>
        <ext uri="{bdbb8cdc-fa1e-496e-a857-3c3f30c029c3}">
          <xda:dynamicArrayProperties fDynamic="1" fCollapsed="0"/>
        </ext>
      </extLst>
    </bk>
  </futureMetadata>
  <cellMetadata count="1">
    <bk>
      <rc t="1" v="0"/>
    </bk>
  </cellMetadata>
</metadata>`), e.join("")
}

function Ix(e) {
    var r = [];
    if (!e) return r;
    var t = 1;
    return (e.match($t) || []).forEach(function(a) {
        var i = Oe(a);
        switch (i[0]) {
            case "<?xml":
                break;
            case "<calcChain":
            case "<calcChain>":
            case "</calcChain>":
                break;
            case "<c":
                delete i[0], i.i ? t = i.i : i.i = t, r.push(i);
                break
        }
    }), r
}

function Mx(e) {
    var r = {};
    r.i = e.read_shift(4);
    var t = {};
    t.r = e.read_shift(4), t.c = e.read_shift(4), r.r = Me(t);
    var a = e.read_shift(1);
    return a & 2 && (r.l = "1"), a & 8 && (r.a = "1"), r
}

function Ox(e, r, t) {
    var a = [],
        i = !1;
    return aa(e, function(s, o, c) {
        switch (c) {
            case 63:
                a.push(s);
                break;
            default:
                if (!o.T) {
                    if (!i || t.WTF) throw new Error("Unexpected record 0x" + c.toString(16))
                }
        }
    }), a
}

function Dx(e, r, t, a) {
    if (!e) return e;
    var i = a || {},
        n = !1,
        s = !1;
    aa(e, function(c, l, f) {
        if (!s) switch (f) {
            case 359:
            case 363:
            case 364:
            case 366:
            case 367:
            case 368:
            case 369:
            case 370:
            case 371:
            case 472:
            case 577:
            case 578:
            case 579:
            case 580:
            case 581:
            case 582:
            case 583:
            case 584:
            case 585:
            case 586:
            case 587:
                break;
            case 35:
                n = !0;
                break;
            case 36:
                n = !1;
                break;
            default:
                if (!l.T) {
                    if (!n || i.WTF) throw new Error("Unexpected record 0x" + f.toString(16))
                }
        }
    }, i)
}

function Rx(e, r) {
    if (!e) return "??";
    var t = (e.match(/<c:chart [^>]*r:id="([^"]*)"/) || ["", ""])[1];
    return r["!id"][t].Target
}
var ei = 1024;

function Sf(e, r) {
    for (var t = [21600, 21600], a = ["m0,0l0", t[1], t[0], t[1], t[0], "0xe"].join(","), i = [ce("xml", null, {
            "xmlns:v": ur.v,
            "xmlns:o": ur.o,
            "xmlns:x": ur.x,
            "xmlns:mv": ur.mv
        }).replace(/\/>/, ">"), ce("o:shapelayout", ce("o:idmap", null, {
            "v:ext": "edit",
            data: e
        }), {
            "v:ext": "edit"
        }), ce("v:shapetype", [ce("v:stroke", null, {
            joinstyle: "miter"
        }), ce("v:path", null, {
            gradientshapeok: "t",
            "o:connecttype": "rect"
        })].join(""), {
            id: "_x0000_t202",
            "o:spt": 202,
            coordsize: t.join(","),
            path: a
        })]; ei < e * 1e3;) ei += 1e3;
    return r.forEach(function(n) {
        var s = pt(n[0]),
            o = {
                color2: "#BEFF82",
                type: "gradient"
            };
        o.type == "gradient" && (o.angle = "-180");
        var c = o.type == "gradient" ? ce("o:fill", null, {
                type: "gradientUnscaled",
                "v:ext": "view"
            }) : null,
            l = ce("v:fill", c, o),
            f = {
                on: "t",
                obscured: "t"
            };
        ++ei, i = i.concat(["<v:shape" + Gi({
            id: "_x0000_s" + ei,
            type: "#_x0000_t202",
            style: "position:absolute; margin-left:80pt;margin-top:5pt;width:104pt;height:64pt;z-index:10" + (n[1].hidden ? ";visibility:hidden" : ""),
            fillcolor: "#ECFAD4",
            strokecolor: "#edeaa1"
        }) + ">", l, ce("v:shadow", null, f), ce("v:path", null, {
            "o:connecttype": "none"
        }), '<v:textbox><div style="text-align:left"></div></v:textbox>', '<x:ClientData ObjectType="Note">', "<x:MoveWithCells/>", "<x:SizeWithCells/>", Ut("x:Anchor", [s.c + 1, 0, s.r + 1, 0, s.c + 3, 20, s.r + 5, 20].join(",")), Ut("x:AutoFill", "False"), Ut("x:Row", String(s.r)), Ut("x:Column", String(s.c)), n[1].hidden ? "" : "<x:Visible/>", "</x:ClientData>", "</v:shape>"])
    }), i.push("</xml>"), i.join("")
}

function Pc(e, r, t, a) {
    var i = Array.isArray(e),
        n;
    r.forEach(function(s) {
        var o = pt(s.ref);
        if (i ? (e[o.r] || (e[o.r] = []), n = e[o.r][o.c]) : n = e[s.ref], !n) {
            n = {
                t: "z"
            }, i ? e[o.r][o.c] = n : e[s.ref] = n;
            var c = Xe(e["!ref"] || "BDWGO1000001:A1");
            c.s.r > o.r && (c.s.r = o.r), c.e.r < o.r && (c.e.r = o.r), c.s.c > o.c && (c.s.c = o.c), c.e.c < o.c && (c.e.c = o.c);
            var l = Ne(c);
            l !== e["!ref"] && (e["!ref"] = l)
        }
        n.c || (n.c = []);
        var f = {
            a: s.author,
            t: s.t,
            r: s.r,
            T: t
        };
        s.h && (f.h = s.h);
        for (var u = n.c.length - 1; u >= 0; --u) {
            if (!t && n.c[u].T) return;
            t && !n.c[u].T && n.c.splice(u, 1)
        }
        if (t && a) {
            for (u = 0; u < a.length; ++u)
                if (f.a == a[u].id) {
                    f.a = a[u].name || f.a;
                    break
                }
        }
        n.c.push(f)
    })
}

function Px(e, r) {
    if (e.match(/<(?:\w+:)?comments *\/>/)) return [];
    var t = [],
        a = [],
        i = e.match(/<(?:\w+:)?authors>([\s\S]*)<\/(?:\w+:)?authors>/);
    i && i[1] && i[1].split(/<\/\w*:?author>/).forEach(function(s) {
        if (!(s === "" || s.trim() === "")) {
            var o = s.match(/<(?:\w+:)?author[^>]*>(.*)/);
            o && t.push(o[1])
        }
    });
    var n = e.match(/<(?:\w+:)?commentList>([\s\S]*)<\/(?:\w+:)?commentList>/);
    return n && n[1] && n[1].split(/<\/\w*:?comment>/).forEach(function(s) {
        if (!(s === "" || s.trim() === "")) {
            var o = s.match(/<(?:\w+:)?comment[^>]*>/);
            if (o) {
                var c = Oe(o[0]),
                    l = {
                        author: c.authorId && t[c.authorId] || "sheetjsghost",
                        ref: c.ref,
                        guid: c.guid
                    },
                    f = pt(c.ref);
                if (!(r.sheetRows && r.sheetRows <= f.r)) {
                    var u = s.match(/<(?:\w+:)?text>([\s\S]*)<\/(?:\w+:)?text>/),
                        h = !!u && !!u[1] && v0(u[1]) || {
                            r: "",
                            t: "",
                            h: ""
                        };
                    l.r = h.r, h.r == "<t></t>" && (h.t = h.h = ""), l.t = (h.t || "").replace(/\r\n/g, `
`).replace(/\r/g, `
`), r.cellHTML && (l.h = h.h), a.push(l)
                }
            }
        }
    }), a
}

function Ef(e) {
    var r = [yt, ce("comments", null, {
            xmlns: La[0]
        })],
        t = [];
    return r.push("<authors>"), e.forEach(function(a) {
        a[1].forEach(function(i) {
            var n = tt(i.a);
            t.indexOf(n) == -1 && (t.push(n), r.push("<author>" + n + "</author>")), i.T && i.ID && t.indexOf("tc=" + i.ID) == -1 && (t.push("tc=" + i.ID), r.push("<author>tc=" + i.ID + "</author>"))
        })
    }), t.length == 0 && (t.push("SheetJ5"), r.push("<author>SheetJ5</author>")), r.push("</authors>"), r.push("<commentList>"), e.forEach(function(a) {
        var i = 0,
            n = [];
        if (a[1][0] && a[1][0].T && a[1][0].ID ? i = t.indexOf("tc=" + a[1][0].ID) : a[1].forEach(function(c) {
                c.a && (i = t.indexOf(tt(c.a))), n.push(c.t || "")
            }), r.push('<comment ref="' + a[0] + '" authorId="' + i + '"><text>'), n.length <= 1) r.push(Ut("t", tt(n[0] || "")));
        else {
            for (var s = `Comment:
    ` + n[0] + `
`, o = 1; o < n.length; ++o) s += `Reply:
    ` + n[o] + `
`;
            r.push(Ut("t", tt(s)))
        }
        r.push("</text></comment>")
    }), r.push("</commentList>"), r.length > 2 && (r[r.length] = "</comments>", r[1] = r[1].replace("/>", ">")), r.join("")
}

function Nx(e, r) {
    var t = [],
        a = !1,
        i = {},
        n = 0;
    return e.replace($t, function(o, c) {
        var l = Oe(o);
        switch (Xr(l[0])) {
            case "<?xml":
                break;
            case "<ThreadedComments":
                break;
            case "</ThreadedComments>":
                break;
            case "<threadedComment":
                i = {
                    author: l.personId,
                    guid: l.id,
                    ref: l.ref,
                    T: 1
                };
                break;
            case "</threadedComment>":
                i.t != null && t.push(i);
                break;
            case "<text>":
            case "<text":
                n = c + o.length;
                break;
            case "</text>":
                i.t = e.slice(n, c).replace(/\r\n/g, `
`).replace(/\r/g, `
`);
                break;
            case "<mentions":
            case "<mentions>":
                a = !0;
                break;
            case "</mentions>":
                a = !1;
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
            case "<extLst/>":
                break;
            case "<ext":
                a = !0;
                break;
            case "</ext>":
                a = !1;
                break;
            default:
                if (!a && r.WTF) throw new Error("unrecognized " + l[0] + " in threaded comments")
        }
        return o
    }), t
}

function Lx(e, r, t) {
    var a = [yt, ce("ThreadedComments", null, {
        xmlns: Mt.TCMNT
    }).replace(/[\/]>/, ">")];
    return e.forEach(function(i) {
        var n = "";
        (i[1] || []).forEach(function(s, o) {
            if (!s.T) {
                delete s.ID;
                return
            }
            s.a && r.indexOf(s.a) == -1 && r.push(s.a);
            var c = {
                ref: i[0],
                id: "{54EE7951-7262-4200-6969-" + ("000000000000" + t.tcid++).slice(-12) + "}"
            };
            o == 0 ? n = c.id : c.parentId = n, s.ID = c.id, s.a && (c.personId = "{54EE7950-7262-4200-6969-" + ("000000000000" + r.indexOf(s.a)).slice(-12) + "}"), a.push(ce("threadedComment", Ut("text", s.t || ""), c))
        })
    }), a.push("</ThreadedComments>"), a.join("")
}

function Bx(e, r) {
    var t = [],
        a = !1;
    return e.replace($t, function(n) {
        var s = Oe(n);
        switch (Xr(s[0])) {
            case "<?xml":
                break;
            case "<personList":
                break;
            case "</personList>":
                break;
            case "<person":
                t.push({
                    name: s.displayname,
                    id: s.id
                });
                break;
            case "</person>":
                break;
            case "<extLst":
            case "<extLst>":
            case "</extLst>":
            case "<extLst/>":
                break;
            case "<ext":
                a = !0;
                break;
            case "</ext>":
                a = !1;
                break;
            default:
                if (!a && r.WTF) throw new Error("unrecognized " + s[0] + " in threaded comments")
        }
        return n
    }), t
}

function Ux(e) {
    var r = [yt, ce("personList", null, {
        xmlns: Mt.TCMNT,
        "xmlns:x": La[0]
    }).replace(/[\/]>/, ">")];
    return e.forEach(function(t, a) {
        r.push(ce("person", null, {
            displayName: t,
            id: "{54EE7950-7262-4200-6969-" + ("000000000000" + a).slice(-12) + "}",
            userId: t,
            providerId: "None"
        }))
    }), r.push("</personList>"), r.join("")
}

function Vx(e) {
    var r = {};
    r.iauthor = e.read_shift(4);
    var t = Wa(e, 16);
    return r.rfx = t.s, r.ref = Me(t.s), e.l += 16, r
}

function Wx(e, r) {
    return r == null && (r = Y(36)), r.write_shift(4, e[1].iauthor), hi(e[0], r), r.write_shift(4, 0), r.write_shift(4, 0), r.write_shift(4, 0), r.write_shift(4, 0), r
}
var Hx = qt;

function Gx(e) {
    return Nt(e.slice(0, 54))
}

function zx(e, r) {
    var t = [],
        a = [],
        i = {},
        n = !1;
    return aa(e, function(o, c, l) {
        switch (l) {
            case 632:
                a.push(o);
                break;
            case 635:
                i = o;
                break;
            case 637:
                i.t = o.t, i.h = o.h, i.r = o.r;
                break;
            case 636:
                if (i.author = a[i.iauthor], delete i.iauthor, r.sheetRows && i.rfx && r.sheetRows <= i.rfx.r) break;
                i.t || (i.t = ""), delete i.rfx, t.push(i);
                break;
            case 3072:
                break;
            case 35:
                n = !0;
                break;
            case 36:
                n = !1;
                break;
            case 37:
                break;
            case 38:
                break;
            default:
                if (!c.T) {
                    if (!n || r.WTF) throw new Error("Unexpected record 0x" + l.toString(16))
                }
        }
    }), t
}

function Xx(e) {
    var r = sr(),
        t = [];
    return ee(r, 628), ee(r, 630), e.forEach(function(a) {
        a[1].forEach(function(i) {
            t.indexOf(i.a) > -1 || (t.push(i.a.slice(0, 54)), ee(r, 632, Gx(i.a)))
        })
    }), ee(r, 631), ee(r, 633), e.forEach(function(a) {
        a[1].forEach(function(i) {
            i.iauthor = t.indexOf(i.a);
            var n = {
                s: pt(a[0]),
                e: pt(a[0])
            };
            ee(r, 635, Wx([n, i])), i.t && i.t.length > 0 && ee(r, 637, hh(i)), ee(r, 636), delete i.iauthor
        })
    }), ee(r, 634), ee(r, 629), r.end()
}
var qx = "application/vnd.ms-office.vbaProject";

function jx(e) {
    var r = Ae.utils.cfb_new({
        root: "R"
    });
    return e.FullPaths.forEach(function(t, a) {
        if (!(t.slice(-1) === "/" || !t.match(/_VBA_PROJECT_CUR/))) {
            var i = t.replace(/^[^\/]*/, "R").replace(/\/_VBA_PROJECT_CUR\u0000*/, "");
            Ae.utils.cfb_add(r, i, e.FileIndex[a].content)
        }
    }), Ae.write(r)
}

function $x(e, r) {
    r.FullPaths.forEach(function(t, a) {
        if (a != 0) {
            var i = t.replace(/[^\/]*[\/]/, "/_VBA_PROJECT_CUR/");
            i.slice(-1) !== "/" && Ae.utils.cfb_add(e, i, r.FileIndex[a].content)
        }
    })
}
var Cf = ["xlsb", "xlsm", "xlam", "biff8", "xla"];

function Yx() {
    return {
        "!type": "dialog"
    }
}

function Kx() {
    return {
        "!type": "dialog"
    }
}

function Jx() {
    return {
        "!type": "macro"
    }
}

function Zx() {
    return {
        "!type": "macro"
    }
}
var ai = (function() {
        var e = /(^|[^A-Za-z_])R(\[?-?\d+\]|[1-9]\d*|)C(\[?-?\d+\]|[1-9]\d*|)(?![A-Za-z0-9_])/g,
            r = {
                r: 0,
                c: 0
            };

        function t(a, i, n, s) {
            var o = !1,
                c = !1;
            n.length == 0 ? c = !0 : n.charAt(0) == "[" && (c = !0, n = n.slice(1, -1)), s.length == 0 ? o = !0 : s.charAt(0) == "[" && (o = !0, s = s.slice(1, -1));
            var l = n.length > 0 ? parseInt(n, 10) | 0 : 0,
                f = s.length > 0 ? parseInt(s, 10) | 0 : 0;
            return o ? f += r.c : --f, c ? l += r.r : --l, i + (o ? "" : "$") + ht(f) + (c ? "" : "$") + Tt(l)
        }
        return function(i, n) {
            return r = n, i.replace(e, t)
        }
    })(),
    C0 = /(^|[^._A-Z0-9])([$]?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])([$]?)(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})(?![_.\(A-Za-z0-9])/g,
    T0 = (function() {
        return function(r, t) {
            return r.replace(C0, function(a, i, n, s, o, c) {
                var l = f0(s) - (n ? 0 : t.c),
                    f = l0(c) - (o ? 0 : t.r),
                    u = f == 0 ? "" : o ? f + 1 : "[" + f + "]",
                    h = l == 0 ? "" : n ? l + 1 : "[" + l + "]";
                return i + "R" + u + "C" + h
            })
        }
    })();

function Tf(e, r) {
    return e.replace(C0, function(t, a, i, n, s, o) {
        return a + (i == "$" ? i + n : ht(f0(n) + r.c)) + (s == "$" ? s + o : Tt(l0(o) + r.r))
    })
}

function Qx(e, r, t) {
    var a = or(r),
        i = a.s,
        n = pt(t),
        s = {
            r: n.r - i.r,
            c: n.c - i.c
        };
    return Tf(e, s)
}

function eg(e) {
    return e.length != 1
}

function Nc(e) {
    return e.replace(/_xlfn\./g, "")
}

function Ft(e) {
    e.l += 1
}

function xa(e, r) {
    var t = e.read_shift(r == 1 ? 1 : 2);
    return [t & 16383, t >> 14 & 1, t >> 15 & 1]
}

function yf(e, r, t) {
    var a = 2;
    if (t) {
        if (t.biff >= 2 && t.biff <= 5) return kf(e, r, t);
        t.biff == 12 && (a = 4)
    }
    var i = e.read_shift(a),
        n = e.read_shift(a),
        s = xa(e, 2),
        o = xa(e, 2);
    return {
        s: {
            r: i,
            c: s[0],
            cRel: s[1],
            rRel: s[2]
        },
        e: {
            r: n,
            c: o[0],
            cRel: o[1],
            rRel: o[2]
        }
    }
}

function kf(e) {
    var r = xa(e, 2),
        t = xa(e, 2),
        a = e.read_shift(1),
        i = e.read_shift(1);
    return {
        s: {
            r: r[0],
            c: a,
            cRel: r[1],
            rRel: r[2]
        },
        e: {
            r: t[0],
            c: i,
            cRel: t[1],
            rRel: t[2]
        }
    }
}

function tg(e, r, t) {
    if (t.biff < 8) return kf(e, r, t);
    var a = e.read_shift(t.biff == 12 ? 4 : 2),
        i = e.read_shift(t.biff == 12 ? 4 : 2),
        n = xa(e, 2),
        s = xa(e, 2);
    return {
        s: {
            r: a,
            c: n[0],
            cRel: n[1],
            rRel: n[2]
        },
        e: {
            r: i,
            c: s[0],
            cRel: s[1],
            rRel: s[2]
        }
    }
}

function Ff(e, r, t) {
    if (t && t.biff >= 2 && t.biff <= 5) return rg(e, r, t);
    var a = e.read_shift(t && t.biff == 12 ? 4 : 2),
        i = xa(e, 2);
    return {
        r: a,
        c: i[0],
        cRel: i[1],
        rRel: i[2]
    }
}

function rg(e) {
    var r = xa(e, 2),
        t = e.read_shift(1);
    return {
        r: r[0],
        c: t,
        cRel: r[1],
        rRel: r[2]
    }
}

function ag(e) {
    var r = e.read_shift(2),
        t = e.read_shift(2);
    return {
        r,
        c: t & 255,
        fQuoted: !!(t & 16384),
        cRel: t >> 15,
        rRel: t >> 15
    }
}

function ig(e, r, t) {
    var a = t && t.biff ? t.biff : 8;
    if (a >= 2 && a <= 5) return ng(e, r, t);
    var i = e.read_shift(a >= 12 ? 4 : 2),
        n = e.read_shift(2),
        s = (n & 16384) >> 14,
        o = (n & 32768) >> 15;
    if (n &= 16383, o == 1)
        for (; i > 524287;) i -= 1048576;
    if (s == 1)
        for (; n > 8191;) n = n - 16384;
    return {
        r: i,
        c: n,
        cRel: s,
        rRel: o
    }
}

function ng(e) {
    var r = e.read_shift(2),
        t = e.read_shift(1),
        a = (r & 32768) >> 15,
        i = (r & 16384) >> 14;
    return r &= 16383, a == 1 && r >= 8192 && (r = r - 16384), i == 1 && t >= 128 && (t = t - 256), {
        r,
        c: t,
        cRel: i,
        rRel: a
    }
}

function sg(e, r, t) {
    var a = (e[e.l++] & 96) >> 5,
        i = yf(e, t.biff >= 2 && t.biff <= 5 ? 6 : 8, t);
    return [a, i]
}

function og(e, r, t) {
    var a = (e[e.l++] & 96) >> 5,
        i = e.read_shift(2, "i"),
        n = 8;
    if (t) switch (t.biff) {
        case 5:
            e.l += 12, n = 6;
            break;
        case 12:
            n = 12;
            break
    }
    var s = yf(e, n, t);
    return [a, i, s]
}

function cg(e, r, t) {
    var a = (e[e.l++] & 96) >> 5;
    return e.l += t && t.biff > 8 ? 12 : t.biff < 8 ? 6 : 8, [a]
}

function lg(e, r, t) {
    var a = (e[e.l++] & 96) >> 5,
        i = e.read_shift(2),
        n = 8;
    if (t) switch (t.biff) {
        case 5:
            e.l += 12, n = 6;
            break;
        case 12:
            n = 12;
            break
    }
    return e.l += n, [a, i]
}

function fg(e, r, t) {
    var a = (e[e.l++] & 96) >> 5,
        i = tg(e, r - 1, t);
    return [a, i]
}

function ug(e, r, t) {
    var a = (e[e.l++] & 96) >> 5;
    return e.l += t.biff == 2 ? 6 : t.biff == 12 ? 14 : 7, [a]
}

function Lc(e) {
    var r = e[e.l + 1] & 1,
        t = 1;
    return e.l += 4, [r, t]
}

function dg(e, r, t) {
    e.l += 2;
    for (var a = e.read_shift(t && t.biff == 2 ? 1 : 2), i = [], n = 0; n <= a; ++n) i.push(e.read_shift(t && t.biff == 2 ? 1 : 2));
    return i
}

function hg(e, r, t) {
    var a = e[e.l + 1] & 255 ? 1 : 0;
    return e.l += 2, [a, e.read_shift(t && t.biff == 2 ? 1 : 2)]
}

function pg(e, r, t) {
    var a = e[e.l + 1] & 255 ? 1 : 0;
    return e.l += 2, [a, e.read_shift(t && t.biff == 2 ? 1 : 2)]
}

function mg(e) {
    var r = e[e.l + 1] & 255 ? 1 : 0;
    return e.l += 2, [r, e.read_shift(2)]
}

function xg(e, r, t) {
    var a = e[e.l + 1] & 255 ? 1 : 0;
    return e.l += t && t.biff == 2 ? 3 : 4, [a]
}

function Af(e) {
    var r = e.read_shift(1),
        t = e.read_shift(1);
    return [r, t]
}

function gg(e) {
    return e.read_shift(2), Af(e, 2)
}

function _g(e) {
    return e.read_shift(2), Af(e, 2)
}

function vg(e, r, t) {
    var a = (e[e.l] & 96) >> 5;
    e.l += 1;
    var i = Ff(e, 0, t);
    return [a, i]
}

function wg(e, r, t) {
    var a = (e[e.l] & 96) >> 5;
    e.l += 1;
    var i = ig(e, 0, t);
    return [a, i]
}

function Sg(e, r, t) {
    var a = (e[e.l] & 96) >> 5;
    e.l += 1;
    var i = e.read_shift(2);
    t && t.biff == 5 && (e.l += 12);
    var n = Ff(e, 0, t);
    return [a, i, n]
}

function Eg(e, r, t) {
    var a = (e[e.l] & 96) >> 5;
    e.l += 1;
    var i = e.read_shift(t && t.biff <= 3 ? 1 : 2);
    return [y_[i], Mf[i], a]
}

function Cg(e, r, t) {
    var a = e[e.l++],
        i = e.read_shift(1),
        n = t && t.biff <= 3 ? [a == 88 ? -1 : 0, e.read_shift(1)] : Tg(e);
    return [i, (n[0] === 0 ? Mf : T_)[n[1]]]
}

function Tg(e) {
    return [e[e.l + 1] >> 7, e.read_shift(2) & 32767]
}

function yg(e, r, t) {
    e.l += t && t.biff == 2 ? 3 : 4
}

function kg(e, r, t) {
    if (e.l++, t && t.biff == 12) return [e.read_shift(4, "i"), 0];
    var a = e.read_shift(2),
        i = e.read_shift(t && t.biff == 2 ? 1 : 2);
    return [a, i]
}

function Fg(e) {
    return e.l++, ia[e.read_shift(1)]
}

function Ag(e) {
    return e.l++, e.read_shift(2)
}

function bg(e) {
    return e.l++, e.read_shift(1) !== 0
}

function Ig(e) {
    return e.l++, zt(e, 8)
}

function Mg(e, r, t) {
    return e.l++, en(e, r - 1, t)
}

function Og(e, r) {
    var t = [e.read_shift(1)];
    if (r == 12) switch (t[0]) {
        case 2:
            t[0] = 4;
            break;
        case 4:
            t[0] = 16;
            break;
        case 0:
            t[0] = 1;
            break;
        case 1:
            t[0] = 2;
            break
    }
    switch (t[0]) {
        case 4:
            t[1] = Ct(e, 1) ? "TRUE" : "FALSE", r != 12 && (e.l += 7);
            break;
        case 37:
        case 16:
            t[1] = ia[e[e.l]], e.l += r == 12 ? 4 : 8;
            break;
        case 0:
            e.l += 8;
            break;
        case 1:
            t[1] = zt(e, 8);
            break;
        case 2:
            t[1] = Ha(e, 0, {
                biff: r > 0 && r < 8 ? 2 : r
            });
            break;
        default:
            throw new Error("Bad SerAr: " + t[0])
    }
    return t
}

function Dg(e, r, t) {
    for (var a = e.read_shift(t.biff == 12 ? 4 : 2), i = [], n = 0; n != a; ++n) i.push((t.biff == 12 ? Wa : Qn)(e, 8));
    return i
}

function Rg(e, r, t) {
    var a = 0,
        i = 0;
    t.biff == 12 ? (a = e.read_shift(4), i = e.read_shift(4)) : (i = 1 + e.read_shift(1), a = 1 + e.read_shift(2)), t.biff >= 2 && t.biff < 8 && (--a, --i == 0 && (i = 256));
    for (var n = 0, s = []; n != a && (s[n] = []); ++n)
        for (var o = 0; o != i; ++o) s[n][o] = Og(e, t.biff);
    return s
}

function Pg(e, r, t) {
    var a = e.read_shift(1) >>> 5 & 3,
        i = !t || t.biff >= 8 ? 4 : 2,
        n = e.read_shift(i);
    switch (t.biff) {
        case 2:
            e.l += 5;
            break;
        case 3:
        case 4:
            e.l += 8;
            break;
        case 5:
            e.l += 12;
            break
    }
    return [a, 0, n]
}

function Ng(e, r, t) {
    if (t.biff == 5) return Lg(e, r, t);
    var a = e.read_shift(1) >>> 5 & 3,
        i = e.read_shift(2),
        n = e.read_shift(4);
    return [a, i, n]
}

function Lg(e) {
    var r = e.read_shift(1) >>> 5 & 3,
        t = e.read_shift(2, "i");
    e.l += 8;
    var a = e.read_shift(2);
    return e.l += 12, [r, t, a]
}

function Bg(e, r, t) {
    var a = e.read_shift(1) >>> 5 & 3;
    e.l += t && t.biff == 2 ? 3 : 4;
    var i = e.read_shift(t && t.biff == 2 ? 1 : 2);
    return [a, i]
}

function Ug(e, r, t) {
    var a = e.read_shift(1) >>> 5 & 3,
        i = e.read_shift(t && t.biff == 2 ? 1 : 2);
    return [a, i]
}

function Vg(e, r, t) {
    var a = e.read_shift(1) >>> 5 & 3;
    return e.l += 4, t.biff < 8 && e.l--, t.biff == 12 && (e.l += 2), [a]
}

function Wg(e, r, t) {
    var a = (e[e.l++] & 96) >> 5,
        i = e.read_shift(2),
        n = 4;
    if (t) switch (t.biff) {
        case 5:
            n = 15;
            break;
        case 12:
            n = 6;
            break
    }
    return e.l += n, [a, i]
}
var Hg = jt,
    Gg = jt,
    zg = jt;

function rn(e, r, t) {
    return e.l += 2, [ag(e, 4, t)]
}

function y0(e) {
    return e.l += 6, []
}
var Xg = rn,
    qg = y0,
    jg = y0,
    $g = rn;

function bf(e) {
    return e.l += 2, [bt(e), e.read_shift(2) & 1]
}
var Yg = rn,
    Kg = bf,
    Jg = y0,
    Zg = rn,
    Qg = rn,
    e_ = ["Data", "All", "Headers", "??", "?Data2", "??", "?DataHeaders", "??", "Totals", "??", "??", "??", "?DataTotals", "??", "??", "??", "?Current"];

function t_(e) {
    e.l += 2;
    var r = e.read_shift(2),
        t = e.read_shift(2),
        a = e.read_shift(4),
        i = e.read_shift(2),
        n = e.read_shift(2),
        s = e_[t >> 2 & 31];
    return {
        ixti: r,
        coltype: t & 3,
        rt: s,
        idx: a,
        c: i,
        C: n
    }
}

function r_(e) {
    return e.l += 2, [e.read_shift(4)]
}

function a_(e, r, t) {
    return e.l += 5, e.l += 2, e.l += t.biff == 2 ? 1 : 4, ["PTGSHEET"]
}

function i_(e, r, t) {
    return e.l += t.biff == 2 ? 4 : 5, ["PTGENDSHEET"]
}

function n_(e) {
    var r = e.read_shift(1) >>> 5 & 3,
        t = e.read_shift(2);
    return [r, t]
}

function s_(e) {
    var r = e.read_shift(1) >>> 5 & 3,
        t = e.read_shift(2);
    return [r, t]
}

function o_(e) {
    return e.l += 4, [0, 0]
}
var Bc = {
        1: {
            n: "PtgExp",
            f: kg
        },
        2: {
            n: "PtgTbl",
            f: zg
        },
        3: {
            n: "PtgAdd",
            f: Ft
        },
        4: {
            n: "PtgSub",
            f: Ft
        },
        5: {
            n: "PtgMul",
            f: Ft
        },
        6: {
            n: "PtgDiv",
            f: Ft
        },
        7: {
            n: "PtgPower",
            f: Ft
        },
        8: {
            n: "PtgConcat",
            f: Ft
        },
        9: {
            n: "PtgLt",
            f: Ft
        },
        10: {
            n: "PtgLe",
            f: Ft
        },
        11: {
            n: "PtgEq",
            f: Ft
        },
        12: {
            n: "PtgGe",
            f: Ft
        },
        13: {
            n: "PtgGt",
            f: Ft
        },
        14: {
            n: "PtgNe",
            f: Ft
        },
        15: {
            n: "PtgIsect",
            f: Ft
        },
        16: {
            n: "PtgUnion",
            f: Ft
        },
        17: {
            n: "PtgRange",
            f: Ft
        },
        18: {
            n: "PtgUplus",
            f: Ft
        },
        19: {
            n: "PtgUminus",
            f: Ft
        },
        20: {
            n: "PtgPercent",
            f: Ft
        },
        21: {
            n: "PtgParen",
            f: Ft
        },
        22: {
            n: "PtgMissArg",
            f: Ft
        },
        23: {
            n: "PtgStr",
            f: Mg
        },
        26: {
            n: "PtgSheet",
            f: a_
        },
        27: {
            n: "PtgEndSheet",
            f: i_
        },
        28: {
            n: "PtgErr",
            f: Fg
        },
        29: {
            n: "PtgBool",
            f: bg
        },
        30: {
            n: "PtgInt",
            f: Ag
        },
        31: {
            n: "PtgNum",
            f: Ig
        },
        32: {
            n: "PtgArray",
            f: ug
        },
        33: {
            n: "PtgFunc",
            f: Eg
        },
        34: {
            n: "PtgFuncVar",
            f: Cg
        },
        35: {
            n: "PtgName",
            f: Pg
        },
        36: {
            n: "PtgRef",
            f: vg
        },
        37: {
            n: "PtgArea",
            f: sg
        },
        38: {
            n: "PtgMemArea",
            f: Bg
        },
        39: {
            n: "PtgMemErr",
            f: Hg
        },
        40: {
            n: "PtgMemNoMem",
            f: Gg
        },
        41: {
            n: "PtgMemFunc",
            f: Ug
        },
        42: {
            n: "PtgRefErr",
            f: Vg
        },
        43: {
            n: "PtgAreaErr",
            f: cg
        },
        44: {
            n: "PtgRefN",
            f: wg
        },
        45: {
            n: "PtgAreaN",
            f: fg
        },
        46: {
            n: "PtgMemAreaN",
            f: n_
        },
        47: {
            n: "PtgMemNoMemN",
            f: s_
        },
        57: {
            n: "PtgNameX",
            f: Ng
        },
        58: {
            n: "PtgRef3d",
            f: Sg
        },
        59: {
            n: "PtgArea3d",
            f: og
        },
        60: {
            n: "PtgRefErr3d",
            f: Wg
        },
        61: {
            n: "PtgAreaErr3d",
            f: lg
        },
        255: {}
    },
    c_ = {
        64: 32,
        96: 32,
        65: 33,
        97: 33,
        66: 34,
        98: 34,
        67: 35,
        99: 35,
        68: 36,
        100: 36,
        69: 37,
        101: 37,
        70: 38,
        102: 38,
        71: 39,
        103: 39,
        72: 40,
        104: 40,
        73: 41,
        105: 41,
        74: 42,
        106: 42,
        75: 43,
        107: 43,
        76: 44,
        108: 44,
        77: 45,
        109: 45,
        78: 46,
        110: 46,
        79: 47,
        111: 47,
        88: 34,
        120: 34,
        89: 57,
        121: 57,
        90: 58,
        122: 58,
        91: 59,
        123: 59,
        92: 60,
        124: 60,
        93: 61,
        125: 61
    },
    l_ = {
        1: {
            n: "PtgElfLel",
            f: bf
        },
        2: {
            n: "PtgElfRw",
            f: Zg
        },
        3: {
            n: "PtgElfCol",
            f: Xg
        },
        6: {
            n: "PtgElfRwV",
            f: Qg
        },
        7: {
            n: "PtgElfColV",
            f: $g
        },
        10: {
            n: "PtgElfRadical",
            f: Yg
        },
        11: {
            n: "PtgElfRadicalS",
            f: Jg
        },
        13: {
            n: "PtgElfColS",
            f: qg
        },
        15: {
            n: "PtgElfColSV",
            f: jg
        },
        16: {
            n: "PtgElfRadicalLel",
            f: Kg
        },
        25: {
            n: "PtgList",
            f: t_
        },
        29: {
            n: "PtgSxName",
            f: r_
        },
        255: {}
    },
    f_ = {
        0: {
            n: "PtgAttrNoop",
            f: o_
        },
        1: {
            n: "PtgAttrSemi",
            f: xg
        },
        2: {
            n: "PtgAttrIf",
            f: pg
        },
        4: {
            n: "PtgAttrChoose",
            f: dg
        },
        8: {
            n: "PtgAttrGoto",
            f: hg
        },
        16: {
            n: "PtgAttrSum",
            f: yg
        },
        32: {
            n: "PtgAttrBaxcel",
            f: Lc
        },
        33: {
            n: "PtgAttrBaxcel",
            f: Lc
        },
        64: {
            n: "PtgAttrSpace",
            f: gg
        },
        65: {
            n: "PtgAttrSpaceSemi",
            f: _g
        },
        128: {
            n: "PtgAttrIfError",
            f: mg
        },
        255: {}
    };

function an(e, r, t, a) {
    if (a.biff < 8) return jt(e, r);
    for (var i = e.l + r, n = [], s = 0; s !== t.length; ++s) switch (t[s][0]) {
        case "PtgArray":
            t[s][1] = Rg(e, 0, a), n.push(t[s][1]);
            break;
        case "PtgMemArea":
            t[s][2] = Dg(e, t[s][1], a), n.push(t[s][2]);
            break;
        case "PtgExp":
            a && a.biff == 12 && (t[s][1][1] = e.read_shift(4), n.push(t[s][1]));
            break;
        case "PtgList":
        case "PtgElfRadicalS":
        case "PtgElfColS":
        case "PtgElfColSV":
            throw "Unsupported " + t[s][0];
        default:
            break
    }
    return r = i - e.l, r !== 0 && n.push(jt(e, r)), n
}

function nn(e, r, t) {
    for (var a = e.l + r, i, n, s = []; a != e.l;) r = a - e.l, n = e[e.l], i = Bc[n] || Bc[c_[n]], (n === 24 || n === 25) && (i = (n === 24 ? l_ : f_)[e[e.l + 1]]), !i || !i.f ? jt(e, r) : s.push([i.n, i.f(e, r, t)]);
    return s
}

function u_(e) {
    for (var r = [], t = 0; t < e.length; ++t) {
        for (var a = e[t], i = [], n = 0; n < a.length; ++n) {
            var s = a[n];
            s ? s[0] === 2 ? i.push('"' + s[1].replace(/"/g, '""') + '"') : i.push(s[1]) : i.push("")
        }
        r.push(i.join(","))
    }
    return r.join(";")
}
var d_ = {
    PtgAdd: "+",
    PtgConcat: "&",
    PtgDiv: "/",
    PtgEq: "=",
    PtgGe: ">=",
    PtgGt: ">",
    PtgLe: "<=",
    PtgLt: "<",
    PtgMul: "*",
    PtgNe: "<>",
    PtgPower: "^",
    PtgSub: "-"
};

function h_(e, r) {
    if (!e && !(r && r.biff <= 5 && r.biff >= 2)) throw new Error("empty sheet name");
    return /[^\w\u4E00-\u9FFF\u3040-\u30FF]/.test(e) ? "'" + e + "'" : e
}

function If(e, r, t) {
    if (!e) return "SH33TJSERR0";
    if (t.biff > 8 && (!e.XTI || !e.XTI[r])) return e.SheetNames[r];
    if (!e.XTI) return "SH33TJSERR6";
    var a = e.XTI[r];
    if (t.biff < 8) return r > 1e4 && (r -= 65536), r < 0 && (r = -r), r == 0 ? "" : e.XTI[r - 1];
    if (!a) return "SH33TJSERR1";
    var i = "";
    if (t.biff > 8) switch (e[a[0]][0]) {
        case 357:
            return i = a[1] == -1 ? "#REF" : e.SheetNames[a[1]], a[1] == a[2] ? i : i + ":" + e.SheetNames[a[2]];
        case 358:
            return t.SID != null ? e.SheetNames[t.SID] : "SH33TJSSAME" + e[a[0]][0];
        default:
            return "SH33TJSSRC" + e[a[0]][0]
    }
    switch (e[a[0]][0][0]) {
        case 1025:
            return i = a[1] == -1 ? "#REF" : e.SheetNames[a[1]] || "SH33TJSERR3", a[1] == a[2] ? i : i + ":" + e.SheetNames[a[2]];
        case 14849:
            return e[a[0]].slice(1).map(function(n) {
                return n.Name
            }).join(";;");
        default:
            return e[a[0]][0][3] ? (i = a[1] == -1 ? "#REF" : e[a[0]][0][3][a[1]] || "SH33TJSERR4", a[1] == a[2] ? i : i + ":" + e[a[0]][0][3][a[2]]) : "SH33TJSERR2"
    }
}

function Uc(e, r, t) {
    var a = If(e, r, t);
    return a == "#REF" ? a : h_(a, t)
}

function Ht(e, r, t, a, i) {
    var n = i && i.biff || 8,
        s = {
            s: {
                c: 0,
                r: 0
            },
            e: {
                c: 0,
                r: 0
            }
        },
        o = [],
        c, l, f, u = 0,
        h = 0,
        p, m = "";
    if (!e[0] || !e[0][0]) return "";
    for (var d = -1, x = "", E = 0, S = e[0].length; E < S; ++E) {
        var _ = e[0][E];
        switch (_[0]) {
            case "PtgUminus":
                o.push("-" + o.pop());
                break;
            case "PtgUplus":
                o.push("+" + o.pop());
                break;
            case "PtgPercent":
                o.push(o.pop() + "%");
                break;
            case "PtgAdd":
            case "PtgConcat":
            case "PtgDiv":
            case "PtgEq":
            case "PtgGe":
            case "PtgGt":
            case "PtgLe":
            case "PtgLt":
            case "PtgMul":
            case "PtgNe":
            case "PtgPower":
            case "PtgSub":
                if (c = o.pop(), l = o.pop(), d >= 0) {
                    switch (e[0][d][1][0]) {
                        case 0:
                            x = xt(" ", e[0][d][1][1]);
                            break;
                        case 1:
                            x = xt("\r", e[0][d][1][1]);
                            break;
                        default:
                            if (x = "", i.WTF) throw new Error("Unexpected PtgAttrSpaceType " + e[0][d][1][0])
                    }
                    l = l + x, d = -1
                }
                o.push(l + d_[_[0]] + c);
                break;
            case "PtgIsect":
                c = o.pop(), l = o.pop(), o.push(l + " " + c);
                break;
            case "PtgUnion":
                c = o.pop(), l = o.pop(), o.push(l + "," + c);
                break;
            case "PtgRange":
                c = o.pop(), l = o.pop(), o.push(l + ":" + c);
                break;
            case "PtgAttrChoose":
                break;
            case "PtgAttrGoto":
                break;
            case "PtgAttrIf":
                break;
            case "PtgAttrIfError":
                break;
            case "PtgRef":
                f = Oi(_[1][1], s, i), o.push(Di(f, n));
                break;
            case "PtgRefN":
                f = t ? Oi(_[1][1], t, i) : _[1][1], o.push(Di(f, n));
                break;
            case "PtgRef3d":
                u = _[1][1], f = Oi(_[1][2], s, i), m = Uc(a, u, i);
                var L = m;
                o.push(m + "!" + Di(f, n));
                break;
            case "PtgFunc":
            case "PtgFuncVar":
                var U = _[1][0],
                    R = _[1][1];
                U || (U = 0), U &= 127;
                var T = U == 0 ? [] : o.slice(-U);
                o.length -= U, R === "User" && (R = T.shift()), o.push(R + "(" + T.join(",") + ")");
                break;
            case "PtgBool":
                o.push(_[1] ? "TRUE" : "FALSE");
                break;
            case "PtgInt":
                o.push(_[1]);
                break;
            case "PtgNum":
                o.push(String(_[1]));
                break;
            case "PtgStr":
                o.push('"' + _[1].replace(/"/g, '""') + '"');
                break;
            case "PtgErr":
                o.push(_[1]);
                break;
            case "PtgAreaN":
                p = pc(_[1][1], t ? {
                    s: t
                } : s, i), o.push(Ss(p, i));
                break;
            case "PtgArea":
                p = pc(_[1][1], s, i), o.push(Ss(p, i));
                break;
            case "PtgArea3d":
                u = _[1][1], p = _[1][2], m = Uc(a, u, i), o.push(m + "!" + Ss(p, i));
                break;
            case "PtgAttrSum":
                o.push("SUM(" + o.pop() + ")");
                break;
            case "PtgAttrBaxcel":
            case "PtgAttrSemi":
                break;
            case "PtgName":
                h = _[1][2];
                var N = (a.names || [])[h - 1] || (a[0] || [])[h],
                    P = N ? N.Name : "SH33TJSNAME" + String(h);
                P && P.slice(0, 6) == "_xlfn." && !i.xlfn && (P = P.slice(6)), o.push(P);
                break;
            case "PtgNameX":
                var X = _[1][1];
                h = _[1][2];
                var j;
                if (i.biff <= 5) X < 0 && (X = -X), a[X] && (j = a[X][h]);
                else {
                    var B = "";
                    if (((a[X] || [])[0] || [])[0] == 14849 || (((a[X] || [])[0] || [])[0] == 1025 ? a[X][h] && a[X][h].itab > 0 && (B = a.SheetNames[a[X][h].itab - 1] + "!") : B = a.SheetNames[h - 1] + "!"), a[X] && a[X][h]) B += a[X][h].Name;
                    else if (a[0] && a[0][h]) B += a[0][h].Name;
                    else {
                        var se = (If(a, X, i) || "").split(";;");
                        se[h - 1] ? B = se[h - 1] : B += "SH33TJSERRX"
                    }
                    o.push(B);
                    break
                }
                j || (j = {
                    Name: "SH33TJSERRY"
                }), o.push(j.Name);
                break;
            case "PtgParen":
                var _e = "(",
                    oe = ")";
                if (d >= 0) {
                    switch (x = "", e[0][d][1][0]) {
                        case 2:
                            _e = xt(" ", e[0][d][1][1]) + _e;
                            break;
                        case 3:
                            _e = xt("\r", e[0][d][1][1]) + _e;
                            break;
                        case 4:
                            oe = xt(" ", e[0][d][1][1]) + oe;
                            break;
                        case 5:
                            oe = xt("\r", e[0][d][1][1]) + oe;
                            break;
                        default:
                            if (i.WTF) throw new Error("Unexpected PtgAttrSpaceType " + e[0][d][1][0])
                    }
                    d = -1
                }
                o.push(_e + o.pop() + oe);
                break;
            case "PtgRefErr":
                o.push("#REF!");
                break;
            case "PtgRefErr3d":
                o.push("#REF!");
                break;
            case "PtgExp":
                f = {
                    c: _[1][1],
                    r: _[1][0]
                };
                var ke = {
                    c: t.c,
                    r: t.r
                };
                if (a.sharedf[Me(f)]) {
                    var Se = a.sharedf[Me(f)];
                    o.push(Ht(Se, s, ke, a, i))
                } else {
                    var Ve = !1;
                    for (c = 0; c != a.arrayf.length; ++c)
                        if (l = a.arrayf[c], !(f.c < l[0].s.c || f.c > l[0].e.c) && !(f.r < l[0].s.r || f.r > l[0].e.r)) {
                            o.push(Ht(l[1], s, ke, a, i)), Ve = !0;
                            break
                        }
                    Ve || o.push(_[1])
                }
                break;
            case "PtgArray":
                o.push("{" + u_(_[1]) + "}");
                break;
            case "PtgMemArea":
                break;
            case "PtgAttrSpace":
            case "PtgAttrSpaceSemi":
                d = E;
                break;
            case "PtgTbl":
                break;
            case "PtgMemErr":
                break;
            case "PtgMissArg":
                o.push("");
                break;
            case "PtgAreaErr":
                o.push("#REF!");
                break;
            case "PtgAreaErr3d":
                o.push("#REF!");
                break;
            case "PtgList":
                o.push("Table" + _[1].idx + "[#" + _[1].rt + "]");
                break;
            case "PtgMemAreaN":
            case "PtgMemNoMemN":
            case "PtgAttrNoop":
            case "PtgSheet":
            case "PtgEndSheet":
                break;
            case "PtgMemFunc":
                break;
            case "PtgMemNoMem":
                break;
            case "PtgElfCol":
            case "PtgElfColS":
            case "PtgElfColSV":
            case "PtgElfColV":
            case "PtgElfLel":
            case "PtgElfRadical":
            case "PtgElfRadicalLel":
            case "PtgElfRadicalS":
            case "PtgElfRw":
            case "PtgElfRwV":
                throw new Error("Unsupported ELFs");
            case "PtgSxName":
                throw new Error("Unrecognized Formula Token: " + String(_));
            default:
                throw new Error("Unrecognized Formula Token: " + String(_))
        }
        var me = ["PtgAttrSpace", "PtgAttrSpaceSemi", "PtgAttrGoto"];
        if (i.biff != 3 && d >= 0 && me.indexOf(e[0][E][0]) == -1) {
            _ = e[0][d];
            var Te = !0;
            switch (_[1][0]) {
                case 4:
                    Te = !1;
                case 0:
                    x = xt(" ", _[1][1]);
                    break;
                case 5:
                    Te = !1;
                case 1:
                    x = xt("\r", _[1][1]);
                    break;
                default:
                    if (x = "", i.WTF) throw new Error("Unexpected PtgAttrSpaceType " + _[1][0])
            }
            o.push((Te ? x : "") + o.pop() + (Te ? "" : x)), d = -1
        }
    }
    if (o.length > 1 && i.WTF) throw new Error("bad formula stack");
    return o[0]
}

function p_(e, r, t) {
    var a = e.l + r,
        i = t.biff == 2 ? 1 : 2,
        n, s = e.read_shift(i);
    if (s == 65535) return [
        [], jt(e, r - 2)
    ];
    var o = nn(e, s, t);
    return r !== s + i && (n = an(e, r - s - i, o, t)), e.l = a, [o, n]
}

function m_(e, r, t) {
    var a = e.l + r,
        i = t.biff == 2 ? 1 : 2,
        n, s = e.read_shift(i);
    if (s == 65535) return [
        [], jt(e, r - 2)
    ];
    var o = nn(e, s, t);
    return r !== s + i && (n = an(e, r - s - i, o, t)), e.l = a, [o, n]
}

function x_(e, r, t, a) {
    var i = e.l + r,
        n = nn(e, a, t),
        s;
    return i !== e.l && (s = an(e, i - e.l, n, t)), [n, s]
}

function g_(e, r, t) {
    var a = e.l + r,
        i, n = e.read_shift(2),
        s = nn(e, n, t);
    return n == 65535 ? [
        [], jt(e, r - 2)
    ] : (r !== n + 2 && (i = an(e, a - n - 2, s, t)), [s, i])
}

function __(e) {
    var r;
    if (Jr(e, e.l + 6) !== 65535) return [zt(e), "n"];
    switch (e[e.l]) {
        case 0:
            return e.l += 8, ["String", "s"];
        case 1:
            return r = e[e.l + 2] === 1, e.l += 8, [r, "b"];
        case 2:
            return r = e[e.l + 2], e.l += 8, [r, "e"];
        case 3:
            return e.l += 8, ["", "s"]
    }
    return []
}

function v_(e) {
    if (e == null) {
        var r = Y(8);
        return r.write_shift(1, 3), r.write_shift(1, 0), r.write_shift(2, 0), r.write_shift(2, 0), r.write_shift(2, 65535), r
    } else if (typeof e == "number") return Da(e);
    return Da(0)
}

function ks(e, r, t) {
    var a = e.l + r,
        i = qr(e, 6);
    t.biff == 2 && ++e.l;
    var n = __(e, 8),
        s = e.read_shift(1);
    t.biff != 2 && (e.read_shift(1), t.biff >= 5 && e.read_shift(4));
    var o = m_(e, a - e.l, t);
    return {
        cell: i,
        val: n[0],
        formula: o,
        shared: s >> 3 & 1,
        tt: n[1]
    }
}

function w_(e, r, t, a, i) {
    var n = Pa(r, t, i),
        s = v_(e.v),
        o = Y(6),
        c = 33;
    o.write_shift(2, c), o.write_shift(4, 0);
    for (var l = Y(e.bf.length), f = 0; f < e.bf.length; ++f) l[f] = e.bf[f];
    var u = Pt([n, s, o, l]);
    return u
}

function es(e, r, t) {
    var a = e.read_shift(4),
        i = nn(e, a, t),
        n = e.read_shift(4),
        s = n > 0 ? an(e, n, i, t) : null;
    return [i, s]
}
var S_ = es,
    ts = es,
    E_ = es,
    C_ = es,
    T_ = {
        0: "BEEP",
        1: "OPEN",
        2: "OPEN.LINKS",
        3: "CLOSE.ALL",
        4: "SAVE",
        5: "SAVE.AS",
        6: "FILE.DELETE",
        7: "PAGE.SETUP",
        8: "PRINT",
        9: "PRINTER.SETUP",
        10: "QUIT",
        11: "NEW.WINDOW",
        12: "ARRANGE.ALL",
        13: "WINDOW.SIZE",
        14: "WINDOW.MOVE",
        15: "FULL",
        16: "CLOSE",
        17: "RUN",
        22: "SET.PRINT.AREA",
        23: "SET.PRINT.TITLES",
        24: "SET.PAGE.BREAK",
        25: "REMOVE.PAGE.BREAK",
        26: "FONT",
        27: "DISPLAY",
        28: "PROTECT.DOCUMENT",
        29: "PRECISION",
        30: "A1.R1C1",
        31: "CALCULATE.NOW",
        32: "CALCULATION",
        34: "DATA.FIND",
        35: "EXTRACT",
        36: "DATA.DELETE",
        37: "SET.DATABASE",
        38: "SET.CRITERIA",
        39: "SORT",
        40: "DATA.SERIES",
        41: "TABLE",
        42: "FORMAT.NUMBER",
        43: "ALIGNMENT",
        44: "STYLE",
        45: "BORDER",
        46: "CELL.PROTECTION",
        47: "COLUMN.WIDTH",
        48: "UNDO",
        49: "CUT",
        50: "COPY",
        51: "PASTE",
        52: "CLEAR",
        53: "PASTE.SPECIAL",
        54: "EDIT.DELETE",
        55: "INSERT",
        56: "FILL.RIGHT",
        57: "FILL.DOWN",
        61: "DEFINE.NAME",
        62: "CREATE.NAMES",
        63: "FORMULA.GOTO",
        64: "FORMULA.FIND",
        65: "SELECT.LAST.CELL",
        66: "SHOW.ACTIVE.CELL",
        67: "GALLERY.AREA",
        68: "GALLERY.BAR",
        69: "GALLERY.COLUMN",
        70: "GALLERY.LINE",
        71: "GALLERY.PIE",
        72: "GALLERY.SCATTER",
        73: "COMBINATION",
        74: "PREFERRED",
        75: "ADD.OVERLAY",
        76: "GRIDLINES",
        77: "SET.PREFERRED",
        78: "AXES",
        79: "LEGEND",
        80: "ATTACH.TEXT",
        81: "ADD.ARROW",
        82: "SELECT.CHART",
        83: "SELECT.PLOT.AREA",
        84: "PATTERNS",
        85: "MAIN.CHART",
        86: "OVERLAY",
        87: "SCALE",
        88: "FORMAT.LEGEND",
        89: "FORMAT.TEXT",
        90: "EDIT.REPEAT",
        91: "PARSE",
        92: "JUSTIFY",
        93: "HIDE",
        94: "UNHIDE",
        95: "WORKSPACE",
        96: "FORMULA",
        97: "FORMULA.FILL",
        98: "FORMULA.ARRAY",
        99: "DATA.FIND.NEXT",
        100: "DATA.FIND.PREV",
        101: "FORMULA.FIND.NEXT",
        102: "FORMULA.FIND.PREV",
        103: "ACTIVATE",
        104: "ACTIVATE.NEXT",
        105: "ACTIVATE.PREV",
        106: "UNLOCKED.NEXT",
        107: "UNLOCKED.PREV",
        108: "COPY.PICTURE",
        109: "SELECT",
        110: "DELETE.NAME",
        111: "DELETE.FORMAT",
        112: "VLINE",
        113: "HLINE",
        114: "VPAGE",
        115: "HPAGE",
        116: "VSCROLL",
        117: "HSCROLL",
        118: "ALERT",
        119: "NEW",
        120: "CANCEL.COPY",
        121: "SHOW.CLIPBOARD",
        122: "MESSAGE",
        124: "PASTE.LINK",
        125: "APP.ACTIVATE",
        126: "DELETE.ARROW",
        127: "ROW.HEIGHT",
        128: "FORMAT.MOVE",
        129: "FORMAT.SIZE",
        130: "FORMULA.REPLACE",
        131: "SEND.KEYS",
        132: "SELECT.SPECIAL",
        133: "APPLY.NAMES",
        134: "REPLACE.FONT",
        135: "FREEZE.PANES",
        136: "SHOW.INFO",
        137: "SPLIT",
        138: "ON.WINDOW",
        139: "ON.DATA",
        140: "DISABLE.INPUT",
        142: "OUTLINE",
        143: "LIST.NAMES",
        144: "FILE.CLOSE",
        145: "SAVE.WORKBOOK",
        146: "DATA.FORM",
        147: "COPY.CHART",
        148: "ON.TIME",
        149: "WAIT",
        150: "FORMAT.FONT",
        151: "FILL.UP",
        152: "FILL.LEFT",
        153: "DELETE.OVERLAY",
        155: "SHORT.MENUS",
        159: "SET.UPDATE.STATUS",
        161: "COLOR.PALETTE",
        162: "DELETE.STYLE",
        163: "WINDOW.RESTORE",
        164: "WINDOW.MAXIMIZE",
        166: "CHANGE.LINK",
        167: "CALCULATE.DOCUMENT",
        168: "ON.KEY",
        169: "APP.RESTORE",
        170: "APP.MOVE",
        171: "APP.SIZE",
        172: "APP.MINIMIZE",
        173: "APP.MAXIMIZE",
        174: "BRING.TO.FRONT",
        175: "SEND.TO.BACK",
        185: "MAIN.CHART.TYPE",
        186: "OVERLAY.CHART.TYPE",
        187: "SELECT.END",
        188: "OPEN.MAIL",
        189: "SEND.MAIL",
        190: "STANDARD.FONT",
        191: "CONSOLIDATE",
        192: "SORT.SPECIAL",
        193: "GALLERY.3D.AREA",
        194: "GALLERY.3D.COLUMN",
        195: "GALLERY.3D.LINE",
        196: "GALLERY.3D.PIE",
        197: "VIEW.3D",
        198: "GOAL.SEEK",
        199: "WORKGROUP",
        200: "FILL.GROUP",
        201: "UPDATE.LINK",
        202: "PROMOTE",
        203: "DEMOTE",
        204: "SHOW.DETAIL",
        206: "UNGROUP",
        207: "OBJECT.PROPERTIES",
        208: "SAVE.NEW.OBJECT",
        209: "SHARE",
        210: "SHARE.NAME",
        211: "DUPLICATE",
        212: "APPLY.STYLE",
        213: "ASSIGN.TO.OBJECT",
        214: "OBJECT.PROTECTION",
        215: "HIDE.OBJECT",
        216: "SET.EXTRACT",
        217: "CREATE.PUBLISHER",
        218: "SUBSCRIBE.TO",
        219: "ATTRIBUTES",
        220: "SHOW.TOOLBAR",
        222: "PRINT.PREVIEW",
        223: "EDIT.COLOR",
        224: "SHOW.LEVELS",
        225: "FORMAT.MAIN",
        226: "FORMAT.OVERLAY",
        227: "ON.RECALC",
        228: "EDIT.SERIES",
        229: "DEFINE.STYLE",
        240: "LINE.PRINT",
        243: "ENTER.DATA",
        249: "GALLERY.RADAR",
        250: "MERGE.STYLES",
        251: "EDITION.OPTIONS",
        252: "PASTE.PICTURE",
        253: "PASTE.PICTURE.LINK",
        254: "SPELLING",
        256: "ZOOM",
        259: "INSERT.OBJECT",
        260: "WINDOW.MINIMIZE",
        265: "SOUND.NOTE",
        266: "SOUND.PLAY",
        267: "FORMAT.SHAPE",
        268: "EXTEND.POLYGON",
        269: "FORMAT.AUTO",
        272: "GALLERY.3D.BAR",
        273: "GALLERY.3D.SURFACE",
        274: "FILL.AUTO",
        276: "CUSTOMIZE.TOOLBAR",
        277: "ADD.TOOL",
        278: "EDIT.OBJECT",
        279: "ON.DOUBLECLICK",
        280: "ON.ENTRY",
        281: "WORKBOOK.ADD",
        282: "WORKBOOK.MOVE",
        283: "WORKBOOK.COPY",
        284: "WORKBOOK.OPTIONS",
        285: "SAVE.WORKSPACE",
        288: "CHART.WIZARD",
        289: "DELETE.TOOL",
        290: "MOVE.TOOL",
        291: "WORKBOOK.SELECT",
        292: "WORKBOOK.ACTIVATE",
        293: "ASSIGN.TO.TOOL",
        295: "COPY.TOOL",
        296: "RESET.TOOL",
        297: "CONSTRAIN.NUMERIC",
        298: "PASTE.TOOL",
        302: "WORKBOOK.NEW",
        305: "SCENARIO.CELLS",
        306: "SCENARIO.DELETE",
        307: "SCENARIO.ADD",
        308: "SCENARIO.EDIT",
        309: "SCENARIO.SHOW",
        310: "SCENARIO.SHOW.NEXT",
        311: "SCENARIO.SUMMARY",
        312: "PIVOT.TABLE.WIZARD",
        313: "PIVOT.FIELD.PROPERTIES",
        314: "PIVOT.FIELD",
        315: "PIVOT.ITEM",
        316: "PIVOT.ADD.FIELDS",
        318: "OPTIONS.CALCULATION",
        319: "OPTIONS.EDIT",
        320: "OPTIONS.VIEW",
        321: "ADDIN.MANAGER",
        322: "MENU.EDITOR",
        323: "ATTACH.TOOLBARS",
        324: "VBAActivate",
        325: "OPTIONS.CHART",
        328: "VBA.INSERT.FILE",
        330: "VBA.PROCEDURE.DEFINITION",
        336: "ROUTING.SLIP",
        338: "ROUTE.DOCUMENT",
        339: "MAIL.LOGON",
        342: "INSERT.PICTURE",
        343: "EDIT.TOOL",
        344: "GALLERY.DOUGHNUT",
        350: "CHART.TREND",
        352: "PIVOT.ITEM.PROPERTIES",
        354: "WORKBOOK.INSERT",
        355: "OPTIONS.TRANSITION",
        356: "OPTIONS.GENERAL",
        370: "FILTER.ADVANCED",
        373: "MAIL.ADD.MAILER",
        374: "MAIL.DELETE.MAILER",
        375: "MAIL.REPLY",
        376: "MAIL.REPLY.ALL",
        377: "MAIL.FORWARD",
        378: "MAIL.NEXT.LETTER",
        379: "DATA.LABEL",
        380: "INSERT.TITLE",
        381: "FONT.PROPERTIES",
        382: "MACRO.OPTIONS",
        383: "WORKBOOK.HIDE",
        384: "WORKBOOK.UNHIDE",
        385: "WORKBOOK.DELETE",
        386: "WORKBOOK.NAME",
        388: "GALLERY.CUSTOM",
        390: "ADD.CHART.AUTOFORMAT",
        391: "DELETE.CHART.AUTOFORMAT",
        392: "CHART.ADD.DATA",
        393: "AUTO.OUTLINE",
        394: "TAB.ORDER",
        395: "SHOW.DIALOG",
        396: "SELECT.ALL",
        397: "UNGROUP.SHEETS",
        398: "SUBTOTAL.CREATE",
        399: "SUBTOTAL.REMOVE",
        400: "RENAME.OBJECT",
        412: "WORKBOOK.SCROLL",
        413: "WORKBOOK.NEXT",
        414: "WORKBOOK.PREV",
        415: "WORKBOOK.TAB.SPLIT",
        416: "FULL.SCREEN",
        417: "WORKBOOK.PROTECT",
        420: "SCROLLBAR.PROPERTIES",
        421: "PIVOT.SHOW.PAGES",
        422: "TEXT.TO.COLUMNS",
        423: "FORMAT.CHARTTYPE",
        424: "LINK.FORMAT",
        425: "TRACER.DISPLAY",
        430: "TRACER.NAVIGATE",
        431: "TRACER.CLEAR",
        432: "TRACER.ERROR",
        433: "PIVOT.FIELD.GROUP",
        434: "PIVOT.FIELD.UNGROUP",
        435: "CHECKBOX.PROPERTIES",
        436: "LABEL.PROPERTIES",
        437: "LISTBOX.PROPERTIES",
        438: "EDITBOX.PROPERTIES",
        439: "PIVOT.REFRESH",
        440: "LINK.COMBO",
        441: "OPEN.TEXT",
        442: "HIDE.DIALOG",
        443: "SET.DIALOG.FOCUS",
        444: "ENABLE.OBJECT",
        445: "PUSHBUTTON.PROPERTIES",
        446: "SET.DIALOG.DEFAULT",
        447: "FILTER",
        448: "FILTER.SHOW.ALL",
        449: "CLEAR.OUTLINE",
        450: "FUNCTION.WIZARD",
        451: "ADD.LIST.ITEM",
        452: "SET.LIST.ITEM",
        453: "REMOVE.LIST.ITEM",
        454: "SELECT.LIST.ITEM",
        455: "SET.CONTROL.VALUE",
        456: "SAVE.COPY.AS",
        458: "OPTIONS.LISTS.ADD",
        459: "OPTIONS.LISTS.DELETE",
        460: "SERIES.AXES",
        461: "SERIES.X",
        462: "SERIES.Y",
        463: "ERRORBAR.X",
        464: "ERRORBAR.Y",
        465: "FORMAT.CHART",
        466: "SERIES.ORDER",
        467: "MAIL.LOGOFF",
        468: "CLEAR.ROUTING.SLIP",
        469: "APP.ACTIVATE.MICROSOFT",
        470: "MAIL.EDIT.MAILER",
        471: "ON.SHEET",
        472: "STANDARD.WIDTH",
        473: "SCENARIO.MERGE",
        474: "SUMMARY.INFO",
        475: "FIND.FILE",
        476: "ACTIVE.CELL.FONT",
        477: "ENABLE.TIPWIZARD",
        478: "VBA.MAKE.ADDIN",
        480: "INSERTDATATABLE",
        481: "WORKGROUP.OPTIONS",
        482: "MAIL.SEND.MAILER",
        485: "AUTOCORRECT",
        489: "POST.DOCUMENT",
        491: "PICKLIST",
        493: "VIEW.SHOW",
        494: "VIEW.DEFINE",
        495: "VIEW.DELETE",
        509: "SHEET.BACKGROUND",
        510: "INSERT.MAP.OBJECT",
        511: "OPTIONS.MENONO",
        517: "MSOCHECKS",
        518: "NORMAL",
        519: "LAYOUT",
        520: "RM.PRINT.AREA",
        521: "CLEAR.PRINT.AREA",
        522: "ADD.PRINT.AREA",
        523: "MOVE.BRK",
        545: "HIDECURR.NOTE",
        546: "HIDEALL.NOTES",
        547: "DELETE.NOTE",
        548: "TRAVERSE.NOTES",
        549: "ACTIVATE.NOTES",
        620: "PROTECT.REVISIONS",
        621: "UNPROTECT.REVISIONS",
        647: "OPTIONS.ME",
        653: "WEB.PUBLISH",
        667: "NEWWEBQUERY",
        673: "PIVOT.TABLE.CHART",
        753: "OPTIONS.SAVE",
        755: "OPTIONS.SPELL",
        808: "HIDEALL.INKANNOTS"
    },
    Mf = {
        0: "COUNT",
        1: "IF",
        2: "ISNA",
        3: "ISERROR",
        4: "SUM",
        5: "AVERAGE",
        6: "MIN",
        7: "MAX",
        8: "ROW",
        9: "COLUMN",
        10: "NA",
        11: "NPV",
        12: "STDEV",
        13: "DOLLAR",
        14: "FIXED",
        15: "SIN",
        16: "COS",
        17: "TAN",
        18: "ATAN",
        19: "PI",
        20: "SQRT",
        21: "EXP",
        22: "LN",
        23: "LOG10",
        24: "ABS",
        25: "INT",
        26: "SIGN",
        27: "ROUND",
        28: "LOOKUP",
        29: "INDEX",
        30: "REPT",
        31: "MID",
        32: "LEN",
        33: "VALUE",
        34: "TRUE",
        35: "FALSE",
        36: "AND",
        37: "OR",
        38: "NOT",
        39: "MOD",
        40: "DCOUNT",
        41: "DSUM",
        42: "DAVERAGE",
        43: "DMIN",
        44: "DMAX",
        45: "DSTDEV",
        46: "VAR",
        47: "DVAR",
        48: "TEXT",
        49: "LINEST",
        50: "TREND",
        51: "LOGEST",
        52: "GROWTH",
        53: "GOTO",
        54: "HALT",
        55: "RETURN",
        56: "PV",
        57: "FV",
        58: "NPER",
        59: "PMT",
        60: "RATE",
        61: "MIRR",
        62: "IRR",
        63: "RAND",
        64: "MATCH",
        65: "DATE",
        66: "TIME",
        67: "DAY",
        68: "MONTH",
        69: "YEAR",
        70: "WEEKDAY",
        71: "HOUR",
        72: "MINUTE",
        73: "SECOND",
        74: "NOW",
        75: "AREAS",
        76: "ROWS",
        77: "COLUMNS",
        78: "OFFSET",
        79: "ABSREF",
        80: "RELREF",
        81: "ARGUMENT",
        82: "SEARCH",
        83: "TRANSPOSE",
        84: "ERROR",
        85: "STEP",
        86: "TYPE",
        87: "ECHO",
        88: "SET.NAME",
        89: "CALLER",
        90: "DEREF",
        91: "WINDOWS",
        92: "SERIES",
        93: "DOCUMENTS",
        94: "ACTIVE.CELL",
        95: "SELECTION",
        96: "RESULT",
        97: "ATAN2",
        98: "ASIN",
        99: "ACOS",
        100: "CHOOSE",
        101: "HLOOKUP",
        102: "VLOOKUP",
        103: "LINKS",
        104: "INPUT",
        105: "ISREF",
        106: "GET.FORMULA",
        107: "GET.NAME",
        108: "SET.VALUE",
        109: "LOG",
        110: "EXEC",
        111: "CHAR",
        112: "LOWER",
        113: "UPPER",
        114: "PROPER",
        115: "LEFT",
        116: "RIGHT",
        117: "EXACT",
        118: "TRIM",
        119: "REPLACE",
        120: "SUBSTITUTE",
        121: "CODE",
        122: "NAMES",
        123: "DIRECTORY",
        124: "FIND",
        125: "CELL",
        126: "ISERR",
        127: "ISTEXT",
        128: "ISNUMBER",
        129: "ISBLANK",
        130: "T",
        131: "N",
        132: "FOPEN",
        133: "FCLOSE",
        134: "FSIZE",
        135: "FREADLN",
        136: "FREAD",
        137: "FWRITELN",
        138: "FWRITE",
        139: "FPOS",
        140: "DATEVALUE",
        141: "TIMEVALUE",
        142: "SLN",
        143: "SYD",
        144: "DDB",
        145: "GET.DEF",
        146: "REFTEXT",
        147: "TEXTREF",
        148: "INDIRECT",
        149: "REGISTER",
        150: "CALL",
        151: "ADD.BAR",
        152: "ADD.MENU",
        153: "ADD.COMMAND",
        154: "ENABLE.COMMAND",
        155: "CHECK.COMMAND",
        156: "RENAME.COMMAND",
        157: "SHOW.BAR",
        158: "DELETE.MENU",
        159: "DELETE.COMMAND",
        160: "GET.CHART.ITEM",
        161: "DIALOG.BOX",
        162: "CLEAN",
        163: "MDETERM",
        164: "MINVERSE",
        165: "MMULT",
        166: "FILES",
        167: "IPMT",
        168: "PPMT",
        169: "COUNTA",
        170: "CANCEL.KEY",
        171: "FOR",
        172: "WHILE",
        173: "BREAK",
        174: "NEXT",
        175: "INITIATE",
        176: "REQUEST",
        177: "POKE",
        178: "EXECUTE",
        179: "TERMINATE",
        180: "RESTART",
        181: "HELP",
        182: "GET.BAR",
        183: "PRODUCT",
        184: "FACT",
        185: "GET.CELL",
        186: "GET.WORKSPACE",
        187: "GET.WINDOW",
        188: "GET.DOCUMENT",
        189: "DPRODUCT",
        190: "ISNONTEXT",
        191: "GET.NOTE",
        192: "NOTE",
        193: "STDEVP",
        194: "VARP",
        195: "DSTDEVP",
        196: "DVARP",
        197: "TRUNC",
        198: "ISLOGICAL",
        199: "DCOUNTA",
        200: "DELETE.BAR",
        201: "UNREGISTER",
        204: "USDOLLAR",
        205: "FINDB",
        206: "SEARCHB",
        207: "REPLACEB",
        208: "LEFTB",
        209: "RIGHTB",
        210: "MIDB",
        211: "LENB",
        212: "ROUNDUP",
        213: "ROUNDDOWN",
        214: "ASC",
        215: "DBCS",
        216: "RANK",
        219: "ADDRESS",
        220: "DAYS360",
        221: "TODAY",
        222: "VDB",
        223: "ELSE",
        224: "ELSE.IF",
        225: "END.IF",
        226: "FOR.CELL",
        227: "MEDIAN",
        228: "SUMPRODUCT",
        229: "SINH",
        230: "COSH",
        231: "TANH",
        232: "ASINH",
        233: "ACOSH",
        234: "ATANH",
        235: "DGET",
        236: "CREATE.OBJECT",
        237: "VOLATILE",
        238: "LAST.ERROR",
        239: "CUSTOM.UNDO",
        240: "CUSTOM.REPEAT",
        241: "FORMULA.CONVERT",
        242: "GET.LINK.INFO",
        243: "TEXT.BOX",
        244: "INFO",
        245: "GROUP",
        246: "GET.OBJECT",
        247: "DB",
        248: "PAUSE",
        251: "RESUME",
        252: "FREQUENCY",
        253: "ADD.TOOLBAR",
        254: "DELETE.TOOLBAR",
        255: "User",
        256: "RESET.TOOLBAR",
        257: "EVALUATE",
        258: "GET.TOOLBAR",
        259: "GET.TOOL",
        260: "SPELLING.CHECK",
        261: "ERROR.TYPE",
        262: "APP.TITLE",
        263: "WINDOW.TITLE",
        264: "SAVE.TOOLBAR",
        265: "ENABLE.TOOL",
        266: "PRESS.TOOL",
        267: "REGISTER.ID",
        268: "GET.WORKBOOK",
        269: "AVEDEV",
        270: "BETADIST",
        271: "GAMMALN",
        272: "BETAINV",
        273: "BINOMDIST",
        274: "CHIDIST",
        275: "CHIINV",
        276: "COMBIN",
        277: "CONFIDENCE",
        278: "CRITBINOM",
        279: "EVEN",
        280: "EXPONDIST",
        281: "FDIST",
        282: "FINV",
        283: "FISHER",
        284: "FISHERINV",
        285: "FLOOR",
        286: "GAMMADIST",
        287: "GAMMAINV",
        288: "CEILING",
        289: "HYPGEOMDIST",
        290: "LOGNORMDIST",
        291: "LOGINV",
        292: "NEGBINOMDIST",
        293: "NORMDIST",
        294: "NORMSDIST",
        295: "NORMINV",
        296: "NORMSINV",
        297: "STANDARDIZE",
        298: "ODD",
        299: "PERMUT",
        300: "POISSON",
        301: "TDIST",
        302: "WEIBULL",
        303: "SUMXMY2",
        304: "SUMX2MY2",
        305: "SUMX2PY2",
        306: "CHITEST",
        307: "CORREL",
        308: "COVAR",
        309: "FORECAST",
        310: "FTEST",
        311: "INTERCEPT",
        312: "PEARSON",
        313: "RSQ",
        314: "STEYX",
        315: "SLOPE",
        316: "TTEST",
        317: "PROB",
        318: "DEVSQ",
        319: "GEOMEAN",
        320: "HARMEAN",
        321: "SUMSQ",
        322: "KURT",
        323: "SKEW",
        324: "ZTEST",
        325: "LARGE",
        326: "SMALL",
        327: "QUARTILE",
        328: "PERCENTILE",
        329: "PERCENTRANK",
        330: "MODE",
        331: "TRIMMEAN",
        332: "TINV",
        334: "MOVIE.COMMAND",
        335: "GET.MOVIE",
        336: "CONCATENATE",
        337: "POWER",
        338: "PIVOT.ADD.DATA",
        339: "GET.PIVOT.TABLE",
        340: "GET.PIVOT.FIELD",
        341: "GET.PIVOT.ITEM",
        342: "RADIANS",
        343: "DEGREES",
        344: "SUBTOTAL",
        345: "SUMIF",
        346: "COUNTIF",
        347: "COUNTBLANK",
        348: "SCENARIO.GET",
        349: "OPTIONS.LISTS.GET",
        350: "ISPMT",
        351: "DATEDIF",
        352: "DATESTRING",
        353: "NUMBERSTRING",
        354: "ROMAN",
        355: "OPEN.DIALOG",
        356: "SAVE.DIALOG",
        357: "VIEW.GET",
        358: "GETPIVOTDATA",
        359: "HYPERLINK",
        360: "PHONETIC",
        361: "AVERAGEA",
        362: "MAXA",
        363: "MINA",
        364: "STDEVPA",
        365: "VARPA",
        366: "STDEVA",
        367: "VARA",
        368: "BAHTTEXT",
        369: "THAIDAYOFWEEK",
        370: "THAIDIGIT",
        371: "THAIMONTHOFYEAR",
        372: "THAINUMSOUND",
        373: "THAINUMSTRING",
        374: "THAISTRINGLENGTH",
        375: "ISTHAIDIGIT",
        376: "ROUNDBAHTDOWN",
        377: "ROUNDBAHTUP",
        378: "THAIYEAR",
        379: "RTD",
        380: "CUBEVALUE",
        381: "CUBEMEMBER",
        382: "CUBEMEMBERPROPERTY",
        383: "CUBERANKEDMEMBER",
        384: "HEX2BIN",
        385: "HEX2DEC",
        386: "HEX2OCT",
        387: "DEC2BIN",
        388: "DEC2HEX",
        389: "DEC2OCT",
        390: "OCT2BIN",
        391: "OCT2HEX",
        392: "OCT2DEC",
        393: "BIN2DEC",
        394: "BIN2OCT",
        395: "BIN2HEX",
        396: "IMSUB",
        397: "IMDIV",
        398: "IMPOWER",
        399: "IMABS",
        400: "IMSQRT",
        401: "IMLN",
        402: "IMLOG2",
        403: "IMLOG10",
        404: "IMSIN",
        405: "IMCOS",
        406: "IMEXP",
        407: "IMARGUMENT",
        408: "IMCONJUGATE",
        409: "IMAGINARY",
        410: "IMREAL",
        411: "COMPLEX",
        412: "IMSUM",
        413: "IMPRODUCT",
        414: "SERIESSUM",
        415: "FACTDOUBLE",
        416: "SQRTPI",
        417: "QUOTIENT",
        418: "DELTA",
        419: "GESTEP",
        420: "ISEVEN",
        421: "ISODD",
        422: "MROUND",
        423: "ERF",
        424: "ERFC",
        425: "BESSELJ",
        426: "BESSELK",
        427: "BESSELY",
        428: "BESSELI",
        429: "XIRR",
        430: "XNPV",
        431: "PRICEMAT",
        432: "YIELDMAT",
        433: "INTRATE",
        434: "RECEIVED",
        435: "DISC",
        436: "PRICEDISC",
        437: "YIELDDISC",
        438: "TBILLEQ",
        439: "TBILLPRICE",
        440: "TBILLYIELD",
        441: "PRICE",
        442: "YIELD",
        443: "DOLLARDE",
        444: "DOLLARFR",
        445: "NOMINAL",
        446: "EFFECT",
        447: "CUMPRINC",
        448: "CUMIPMT",
        449: "EDATE",
        450: "EOMONTH",
        451: "YEARFRAC",
        452: "COUPDAYBS",
        453: "COUPDAYS",
        454: "COUPDAYSNC",
        455: "COUPNCD",
        456: "COUPNUM",
        457: "COUPPCD",
        458: "DURATION",
        459: "MDURATION",
        460: "ODDLPRICE",
        461: "ODDLYIELD",
        462: "ODDFPRICE",
        463: "ODDFYIELD",
        464: "RANDBETWEEN",
        465: "WEEKNUM",
        466: "AMORDEGRC",
        467: "AMORLINC",
        468: "CONVERT",
        724: "SHEETJS",
        469: "ACCRINT",
        470: "ACCRINTM",
        471: "WORKDAY",
        472: "NETWORKDAYS",
        473: "GCD",
        474: "MULTINOMIAL",
        475: "LCM",
        476: "FVSCHEDULE",
        477: "CUBEKPIMEMBER",
        478: "CUBESET",
        479: "CUBESETCOUNT",
        480: "IFERROR",
        481: "COUNTIFS",
        482: "SUMIFS",
        483: "AVERAGEIF",
        484: "AVERAGEIFS"
    },
    y_ = {
        2: 1,
        3: 1,
        10: 0,
        15: 1,
        16: 1,
        17: 1,
        18: 1,
        19: 0,
        20: 1,
        21: 1,
        22: 1,
        23: 1,
        24: 1,
        25: 1,
        26: 1,
        27: 2,
        30: 2,
        31: 3,
        32: 1,
        33: 1,
        34: 0,
        35: 0,
        38: 1,
        39: 2,
        40: 3,
        41: 3,
        42: 3,
        43: 3,
        44: 3,
        45: 3,
        47: 3,
        48: 2,
        53: 1,
        61: 3,
        63: 0,
        65: 3,
        66: 3,
        67: 1,
        68: 1,
        69: 1,
        70: 1,
        71: 1,
        72: 1,
        73: 1,
        74: 0,
        75: 1,
        76: 1,
        77: 1,
        79: 2,
        80: 2,
        83: 1,
        85: 0,
        86: 1,
        89: 0,
        90: 1,
        94: 0,
        95: 0,
        97: 2,
        98: 1,
        99: 1,
        101: 3,
        102: 3,
        105: 1,
        106: 1,
        108: 2,
        111: 1,
        112: 1,
        113: 1,
        114: 1,
        117: 2,
        118: 1,
        119: 4,
        121: 1,
        126: 1,
        127: 1,
        128: 1,
        129: 1,
        130: 1,
        131: 1,
        133: 1,
        134: 1,
        135: 1,
        136: 2,
        137: 2,
        138: 2,
        140: 1,
        141: 1,
        142: 3,
        143: 4,
        144: 4,
        161: 1,
        162: 1,
        163: 1,
        164: 1,
        165: 2,
        172: 1,
        175: 2,
        176: 2,
        177: 3,
        178: 2,
        179: 1,
        184: 1,
        186: 1,
        189: 3,
        190: 1,
        195: 3,
        196: 3,
        197: 1,
        198: 1,
        199: 3,
        201: 1,
        207: 4,
        210: 3,
        211: 1,
        212: 2,
        213: 2,
        214: 1,
        215: 1,
        225: 0,
        229: 1,
        230: 1,
        231: 1,
        232: 1,
        233: 1,
        234: 1,
        235: 3,
        244: 1,
        247: 4,
        252: 2,
        257: 1,
        261: 1,
        271: 1,
        273: 4,
        274: 2,
        275: 2,
        276: 2,
        277: 3,
        278: 3,
        279: 1,
        280: 3,
        281: 3,
        282: 3,
        283: 1,
        284: 1,
        285: 2,
        286: 4,
        287: 3,
        288: 2,
        289: 4,
        290: 3,
        291: 3,
        292: 3,
        293: 4,
        294: 1,
        295: 3,
        296: 1,
        297: 3,
        298: 1,
        299: 2,
        300: 3,
        301: 3,
        302: 4,
        303: 2,
        304: 2,
        305: 2,
        306: 2,
        307: 2,
        308: 2,
        309: 3,
        310: 2,
        311: 2,
        312: 2,
        313: 2,
        314: 2,
        315: 2,
        316: 4,
        325: 2,
        326: 2,
        327: 2,
        328: 2,
        331: 2,
        332: 2,
        337: 2,
        342: 1,
        343: 1,
        346: 2,
        347: 1,
        350: 4,
        351: 3,
        352: 1,
        353: 2,
        360: 1,
        368: 1,
        369: 1,
        370: 1,
        371: 1,
        372: 1,
        373: 1,
        374: 1,
        375: 1,
        376: 1,
        377: 1,
        378: 1,
        382: 3,
        385: 1,
        392: 1,
        393: 1,
        396: 2,
        397: 2,
        398: 2,
        399: 1,
        400: 1,
        401: 1,
        402: 1,
        403: 1,
        404: 1,
        405: 1,
        406: 1,
        407: 1,
        408: 1,
        409: 1,
        410: 1,
        414: 4,
        415: 1,
        416: 1,
        417: 2,
        420: 1,
        421: 1,
        422: 2,
        424: 1,
        425: 2,
        426: 2,
        427: 2,
        428: 2,
        430: 3,
        438: 3,
        439: 3,
        440: 3,
        443: 2,
        444: 2,
        445: 2,
        446: 2,
        447: 6,
        448: 6,
        449: 2,
        450: 2,
        464: 2,
        468: 3,
        476: 2,
        479: 1,
        480: 2,
        65535: 0
    };

function Vc(e) {
    return e.slice(0, 3) == "of:" && (e = e.slice(3)), e.charCodeAt(0) == 61 && (e = e.slice(1), e.charCodeAt(0) == 61 && (e = e.slice(1))), e = e.replace(/COM\.MICROSOFT\./g, ""), e = e.replace(/\[((?:\.[A-Z]+[0-9]+)(?::\.[A-Z]+[0-9]+)?)\]/g, function(r, t) {
        return t.replace(/\./g, "")
    }), e = e.replace(/\[.(#[A-Z]*[?!])\]/g, "$1"), e.replace(/[;~]/g, ",").replace(/\|/g, ";")
}

function k_(e) {
    var r = "of:=" + e.replace(C0, "$1[.$2$3$4$5]").replace(/\]:\[/g, ":");
    return r.replace(/;/g, "|").replace(/,/g, ";")
}

function Fs(e) {
    var r = e.split(":"),
        t = r[0].split(".")[0];
    return [t, r[0].split(".")[1] + (r.length > 1 ? ":" + (r[1].split(".")[1] || r[1].split(".")[0]) : "")]
}

function F_(e) {
    return e.replace(/\./, "!")
}
var Pi = {},
    ii = {},
    Ni = typeof Map < "u";

function k0(e, r, t) {
    var a = 0,
        i = e.length;
    if (t) {
        if (Ni ? t.has(r) : Object.prototype.hasOwnProperty.call(t, r)) {
            for (var n = Ni ? t.get(r) : t[r]; a < n.length; ++a)
                if (e[n[a]].t === r) return e.Count++, n[a]
        }
    } else
        for (; a < i; ++a)
            if (e[a].t === r) return e.Count++, a;
    return e[i] = {
        t: r
    }, e.Count++, e.Unique++, t && (Ni ? (t.has(r) || t.set(r, []), t.get(r).push(i)) : (Object.prototype.hasOwnProperty.call(t, r) || (t[r] = []), t[r].push(i))), i
}

function rs(e, r) {
    var t = {
            min: e + 1,
            max: e + 1
        },
        a = -1;
    return r.MDW && (Gt = r.MDW), r.width != null ? t.customWidth = 1 : r.wpx != null ? a = $i(r.wpx) : r.wch != null && (a = r.wch), a > -1 ? (t.width = zn(a), t.customWidth = 1) : r.width != null && (t.width = r.width), r.hidden && (t.hidden = !0), r.level != null && (t.outlineLevel = t.level = r.level), t
}

function Ia(e, r) {
    if (e) {
        var t = [.7, .7, .75, .75, .3, .3];
        r == "xlml" && (t = [1, 1, 1, 1, .5, .5]), e.left == null && (e.left = t[0]), e.right == null && (e.right = t[1]), e.top == null && (e.top = t[2]), e.bottom == null && (e.bottom = t[3]), e.header == null && (e.header = t[4]), e.footer == null && (e.footer = t[5])
    }
}

function wa(e, r, t) {
    var a = t.revssf[r.z != null ? r.z : "General"],
        i = 60,
        n = e.length;
    if (a == null && t.ssf) {
        for (; i < 392; ++i)
            if (t.ssf[i] == null) {
                Qr(r.z, i), t.ssf[i] = r.z, t.revssf[r.z] = a = i;
                break
            }
    }
    for (i = 0; i != n; ++i)
        if (e[i].numFmtId === a) return i;
    return e[n] = {
        numFmtId: a,
        fontId: 0,
        fillId: 0,
        borderId: 0,
        xfId: 0,
        applyNumberFormat: 1
    }, n
}

function Of(e, r, t, a, i, n) {
    try {
        a.cellNF && (e.z = Ie[r])
    } catch (o) {
        if (a.WTF) throw o
    }
    if (!(e.t === "z" && !a.cellStyles)) {
        if (e.t === "d" && typeof e.v == "string" && (e.v = ft(e.v)), (!a || a.cellText !== !1) && e.t !== "z") try {
            if (Ie[r] == null && Qr(Td[r] || "General", r), e.t === "e") e.w = e.w || ia[e.v];
            else if (r === 0)
                if (e.t === "n")(e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = Wi(e.v);
                else if (e.t === "d") {
                var s = Ot(e.v);
                (s | 0) === s ? e.w = s.toString(10) : e.w = Wi(s)
            } else {
                if (e.v === void 0) return "";
                e.w = Ma(e.v, ii)
            } else e.t === "d" ? e.w = Ir(r, Ot(e.v), ii) : e.w = Ir(r, e.v, ii)
        } catch (o) {
            if (a.WTF) throw o
        }
        if (a.cellStyles && t != null) try {
            e.s = n.Fills[t], e.s.fgColor && e.s.fgColor.theme && !e.s.fgColor.rgb && (e.s.fgColor.rgb = Gn(i.themeElements.clrScheme[e.s.fgColor.theme].rgb, e.s.fgColor.tint || 0), a.WTF && (e.s.fgColor.raw_rgb = i.themeElements.clrScheme[e.s.fgColor.theme].rgb)), e.s.bgColor && e.s.bgColor.theme && (e.s.bgColor.rgb = Gn(i.themeElements.clrScheme[e.s.bgColor.theme].rgb, e.s.bgColor.tint || 0), a.WTF && (e.s.bgColor.raw_rgb = i.themeElements.clrScheme[e.s.bgColor.theme].rgb))
        } catch (o) {
            if (a.WTF && n.Fills) throw o
        }
    }
}

function A_(e, r, t) {
    if (e && e["!ref"]) {
        var a = Xe(e["!ref"]);
        if (a.e.c < a.s.c || a.e.r < a.s.r) throw new Error("Bad range (" + t + "): " + e["!ref"])
    }
}

function b_(e, r) {
    var t = Xe(r);
    t.s.r <= t.e.r && t.s.c <= t.e.c && t.s.r >= 0 && t.s.c >= 0 && (e["!ref"] = Ne(t))
}
var I_ = /<(?:\w:)?mergeCell ref="[A-Z0-9:]+"\s*[\/]?>/g,
    M_ = /<(?:\w+:)?sheetData[^>]*>([\s\S]*)<\/(?:\w+:)?sheetData>/,
    O_ = /<(?:\w:)?hyperlink [^>]*>/mg,
    D_ = /"(\w*:\w*)"/,
    R_ = /<(?:\w:)?col\b[^>]*[\/]?>/g,
    P_ = /<(?:\w:)?autoFilter[^>]*([\/]|>([\s\S]*)<\/(?:\w:)?autoFilter)>/g,
    N_ = /<(?:\w:)?pageMargins[^>]*\/>/g,
    Df = /<(?:\w:)?sheetPr\b(?:[^>a-z][^>]*)?\/>/,
    L_ = /<(?:\w:)?sheetPr[^>]*(?:[\/]|>([\s\S]*)<\/(?:\w:)?sheetPr)>/,
    B_ = /<(?:\w:)?sheetViews[^>]*(?:[\/]|>([\s\S]*)<\/(?:\w:)?sheetViews)>/;

function U_(e, r, t, a, i, n, s) {
    if (!e) return e;
    a || (a = {
        "!id": {}
    }), _t != null && r.dense == null && (r.dense = _t);
    var o = r.dense ? [] : {},
        c = {
            s: {
                r: 2e6,
                c: 2e6
            },
            e: {
                r: 0,
                c: 0
            }
        },
        l = "",
        f = "",
        u = e.match(M_);
    u ? (l = e.slice(0, u.index), f = e.slice(u.index + u[0].length)) : l = f = e;
    var h = l.match(Df);
    h ? F0(h[0], o, i, t) : (h = l.match(L_)) && W_(h[0], h[1] || "", o, i, t, s, n);
    var p = (l.match(/<(?:\w*:)?dimension/) || {
        index: -1
    }).index;
    if (p > 0) {
        var m = l.slice(p, p + 50).match(D_);
        m && b_(o, m[1])
    }
    var d = l.match(B_);
    d && d[1] && ev(d[1], i);
    var x = [];
    if (r.cellStyles) {
        var E = l.match(R_);
        E && Y_(x, E)
    }
    u && av(u[1], o, r, c, n, s);
    var S = f.match(P_);
    S && (o["!autofilter"] = J_(S[0]));
    var _ = [],
        L = f.match(I_);
    if (L)
        for (p = 0; p != L.length; ++p) _[p] = Xe(L[p].slice(L[p].indexOf('"') + 1));
    var U = f.match(O_);
    U && q_(o, U, a);
    var R = f.match(N_);
    if (R && (o["!margins"] = j_(Oe(R[0]))), !o["!ref"] && c.e.c >= c.s.c && c.e.r >= c.s.r && (o["!ref"] = Ne(c)), r.sheetRows > 0 && o["!ref"]) {
        var T = Xe(o["!ref"]);
        r.sheetRows <= +T.e.r && (T.e.r = r.sheetRows - 1, T.e.r > c.e.r && (T.e.r = c.e.r), T.e.r < T.s.r && (T.s.r = T.e.r), T.e.c > c.e.c && (T.e.c = c.e.c), T.e.c < T.s.c && (T.s.c = T.e.c), o["!fullref"] = o["!ref"], o["!ref"] = Ne(T))
    }
    return x.length > 0 && (o["!cols"] = x), _.length > 0 && (o["!merges"] = _), o
}

function V_(e) {
    if (e.length === 0) return "";
    for (var r = '<mergeCells count="' + e.length + '">', t = 0; t != e.length; ++t) r += '<mergeCell ref="' + Ne(e[t]) + '"/>';
    return r + "</mergeCells>"
}

function F0(e, r, t, a) {
    var i = Oe(e);
    t.Sheets[a] || (t.Sheets[a] = {}), i.codeName && (t.Sheets[a].CodeName = ze(at(i.codeName)))
}

function W_(e, r, t, a, i) {
    F0(e.slice(0, e.indexOf(">")), t, a, i)
}

function H_(e, r, t, a, i) {
    var n = !1,
        s = {},
        o = null;
    if (a.bookType !== "xlsx" && r.vbaraw) {
        var c = r.SheetNames[t];
        try {
            r.Workbook && (c = r.Workbook.Sheets[t].CodeName || c)
        } catch (f) {}
        n = !0, s.codeName = Gr(tt(c))
    }
    if (e && e["!outline"]) {
        var l = {
            summaryBelow: 1,
            summaryRight: 1
        };
        e["!outline"].above && (l.summaryBelow = 0), e["!outline"].left && (l.summaryRight = 0), o = (o || "") + ce("outlinePr", null, l)
    }!n && !o || (i[i.length] = ce("sheetPr", o, s))
}
var G_ = ["objects", "scenarios", "selectLockedCells", "selectUnlockedCells"],
    z_ = ["formatColumns", "formatRows", "formatCells", "insertColumns", "insertRows", "insertHyperlinks", "deleteColumns", "deleteRows", "sort", "autoFilter", "pivotTables"];

function X_(e) {
    var r = {
        sheet: 1
    };
    return G_.forEach(function(t) {
        e[t] != null && e[t] && (r[t] = "1")
    }), z_.forEach(function(t) {
        e[t] != null && !e[t] && (r[t] = "0")
    }), e.password && (r.password = w0(e.password).toString(16).toUpperCase()), ce("sheetProtection", null, r)
}

function q_(e, r, t) {
    for (var a = Array.isArray(e), i = 0; i != r.length; ++i) {
        var n = Oe(at(r[i]), !0);
        if (!n.ref) return;
        var s = ((t || {})["!id"] || [])[n.id];
        s ? (n.Target = s.Target, n.location && (n.Target += "#" + ze(n.location))) : (n.Target = "#" + ze(n.location), s = {
            Target: n.Target,
            TargetMode: "Internal"
        }), n.Rel = s, n.tooltip && (n.Tooltip = n.tooltip, delete n.tooltip);
        for (var o = Xe(n.ref), c = o.s.r; c <= o.e.r; ++c)
            for (var l = o.s.c; l <= o.e.c; ++l) {
                var f = Me({
                    c: l,
                    r: c
                });
                a ? (e[c] || (e[c] = []), e[c][l] || (e[c][l] = {
                    t: "z",
                    v: void 0
                }), e[c][l].l = n) : (e[f] || (e[f] = {
                    t: "z",
                    v: void 0
                }), e[f].l = n)
            }
    }
}

function j_(e) {
    var r = {};
    return ["left", "right", "top", "bottom", "header", "footer"].forEach(function(t) {
        e[t] && (r[t] = parseFloat(e[t]))
    }), r
}

function $_(e) {
    return Ia(e), ce("pageMargins", null, e)
}

function Y_(e, r) {
    for (var t = !1, a = 0; a != r.length; ++a) {
        var i = Oe(r[a], !0);
        i.hidden && (i.hidden = lt(i.hidden));
        var n = parseInt(i.min, 10) - 1,
            s = parseInt(i.max, 10) - 1;
        for (i.outlineLevel && (i.level = +i.outlineLevel || 0), delete i.min, delete i.max, i.width = +i.width, !t && i.width && (t = !0, S0(i.width)), ma(i); n <= s;) e[n++] = ut(i)
    }
}

function K_(e, r) {
    for (var t = ["<cols>"], a, i = 0; i != r.length; ++i)(a = r[i]) && (t[t.length] = ce("col", null, rs(i, a)));
    return t[t.length] = "</cols>", t.join("")
}

function J_(e) {
    var r = {
        ref: (e.match(/ref="([^"]*)"/) || [])[1]
    };
    return r
}

function Z_(e, r, t, a) {
    var i = typeof e.ref == "string" ? e.ref : Ne(e.ref);
    t.Workbook || (t.Workbook = {
        Sheets: []
    }), t.Workbook.Names || (t.Workbook.Names = []);
    var n = t.Workbook.Names,
        s = or(i);
    s.s.r == s.e.r && (s.e.r = or(r["!ref"]).e.r, i = Ne(s));
    for (var o = 0; o < n.length; ++o) {
        var c = n[o];
        if (c.Name == "_xlnm._FilterDatabase" && c.Sheet == a) {
            c.Ref = "'" + t.SheetNames[a] + "'!" + i;
            break
        }
    }
    return o == n.length && n.push({
        Name: "_xlnm._FilterDatabase",
        Sheet: a,
        Ref: "'" + t.SheetNames[a] + "'!" + i
    }), ce("autoFilter", null, {
        ref: i
    })
}
var Q_ = /<(?:\w:)?sheetView(?:[^>a-z][^>]*)?\/?>/;

function ev(e, r) {
    r.Views || (r.Views = [{}]), (e.match(Q_) || []).forEach(function(t, a) {
        var i = Oe(t);
        r.Views[a] || (r.Views[a] = {}), +i.zoomScale && (r.Views[a].zoom = +i.zoomScale), lt(i.rightToLeft) && (r.Views[a].RTL = !0)
    })
}

function tv(e, r, t, a) {
    var i = {
        workbookViewId: "0"
    };
    return (((a || {}).Workbook || {}).Views || [])[0] && (i.rightToLeft = a.Workbook.Views[0].RTL ? "1" : "0"), ce("sheetViews", ce("sheetView", null, i), {})
}

function rv(e, r, t, a) {
    if (e.c && t["!comments"].push([r, e.c]), e.v === void 0 && typeof e.f != "string" || e.t === "z" && !e.f) return "";
    var i = "",
        n = e.t,
        s = e.v;
    if (e.t !== "z") switch (e.t) {
        case "b":
            i = e.v ? "1" : "0";
            break;
        case "n":
            i = "" + e.v;
            break;
        case "e":
            i = ia[e.v];
            break;
        case "d":
            a && a.cellDates ? i = ft(e.v, -1).toISOString() : (e = ut(e), e.t = "n", i = "" + (e.v = Ot(ft(e.v)))), typeof e.z > "u" && (e.z = Ie[14]);
            break;
        default:
            i = e.v;
            break
    }
    var o = Ut("v", tt(i)),
        c = {
            r
        },
        l = wa(a.cellXfs, e, a);
    switch (l !== 0 && (c.s = l), e.t) {
        case "n":
            break;
        case "d":
            c.t = "d";
            break;
        case "b":
            c.t = "b";
            break;
        case "e":
            c.t = "e";
            break;
        case "z":
            break;
        default:
            if (e.v == null) {
                delete e.t;
                break
            }
            if (e.v.length > 32767) throw new Error("Text length must not exceed 32767 characters");
            if (a && a.bookSST) {
                o = Ut("v", "" + k0(a.Strings, e.v, a.revStrings)), c.t = "s";
                break
            }
            c.t = "str";
            break
    }
    if (e.t != n && (e.t = n, e.v = s), typeof e.f == "string" && e.f) {
        var f = e.F && e.F.slice(0, r.length) == r ? {
            t: "array",
            ref: e.F
        } : null;
        o = ce("f", tt(e.f), f) + (e.v != null ? o : "")
    }
    return e.l && t["!links"].push([r, e.l]), e.D && (c.cm = 1), ce("c", o, c)
}
var av = (function() {
    var e = /<(?:\w+:)?c[ \/>]/,
        r = /<\/(?:\w+:)?row>/,
        t = /r=["']([^"']*)["']/,
        a = /<(?:\w+:)?is>([\S\s]*?)<\/(?:\w+:)?is>/,
        i = /ref=["']([^"']*)["']/,
        n = Hi("v"),
        s = Hi("f");
    return function(c, l, f, u, h, p) {
        for (var m = 0, d = "", x = [], E = [], S = 0, _ = 0, L = 0, U = "", R, T, N = 0, P = 0, X, j, B = 0, se = 0, _e = Array.isArray(p.CellXf), oe, ke = [], Se = [], Ve = Array.isArray(l), me = [], Te = {}, Z = !1, b = !!f.sheetStubs, H = c.split(r), O = 0, M = H.length; O != M; ++O) {
            d = H[O].trim();
            var J = d.length;
            if (J !== 0) {
                var de = 0;
                e: for (m = 0; m < J; ++m) switch (d[m]) {
                    case ">":
                        if (d[m - 1] != "/") {
                            ++m;
                            break e
                        }
                        if (f && f.cellStyles) {
                            if (T = Oe(d.slice(de, m), !0), N = T.r != null ? parseInt(T.r, 10) : N + 1, P = -1, f.sheetRows && f.sheetRows < N) continue;
                            Te = {}, Z = !1, T.ht && (Z = !0, Te.hpt = parseFloat(T.ht), Te.hpx = ci(Te.hpt)), T.hidden == "1" && (Z = !0, Te.hidden = !0), T.outlineLevel != null && (Z = !0, Te.level = +T.outlineLevel), Z && (me[N - 1] = Te)
                        }
                        break;
                    case "<":
                        de = m;
                        break
                }
                if (de >= m) break;
                if (T = Oe(d.slice(de, m), !0), N = T.r != null ? parseInt(T.r, 10) : N + 1, P = -1, !(f.sheetRows && f.sheetRows < N)) {
                    u.s.r > N - 1 && (u.s.r = N - 1), u.e.r < N - 1 && (u.e.r = N - 1), f && f.cellStyles && (Te = {}, Z = !1, T.ht && (Z = !0, Te.hpt = parseFloat(T.ht), Te.hpx = ci(Te.hpt)), T.hidden == "1" && (Z = !0, Te.hidden = !0), T.outlineLevel != null && (Z = !0, Te.level = +T.outlineLevel), Z && (me[N - 1] = Te)), x = d.slice(m).split(e);
                    for (var ie = 0; ie != x.length && x[ie].trim().charAt(0) == "<"; ++ie);
                    for (x = x.slice(ie), m = 0; m != x.length; ++m)
                        if (d = x[m].trim(), d.length !== 0) {
                            if (E = d.match(t), S = m, _ = 0, L = 0, d = "<c " + (d.slice(0, 1) == "<" ? ">" : "") + d, E != null && E.length === 2) {
                                for (S = 0, U = E[1], _ = 0; _ != U.length && !((L = U.charCodeAt(_) - 64) < 1 || L > 26); ++_) S = 26 * S + L;
                                --S, P = S
                            } else ++P;
                            for (_ = 0; _ != d.length && d.charCodeAt(_) !== 62; ++_);
                            if (++_, T = Oe(d.slice(0, _), !0), T.r || (T.r = Me({
                                    r: N - 1,
                                    c: P
                                })), U = d.slice(_), R = {
                                    t: ""
                                }, (E = U.match(n)) != null && E[1] !== "" && (R.v = ze(E[1])), f.cellFormula) {
                                if ((E = U.match(s)) != null && E[1] !== "") {
                                    if (R.f = ze(at(E[1])).replace(/\r\n/g, `
`), f.xlfn || (R.f = Nc(R.f)), E[0].indexOf('t="array"') > -1) R.F = (U.match(i) || [])[1], R.F.indexOf(":") > -1 && ke.push([Xe(R.F), R.F]);
                                    else if (E[0].indexOf('t="shared"') > -1) {
                                        j = Oe(E[0]);
                                        var ne = ze(at(E[1]));
                                        f.xlfn || (ne = Nc(ne)), Se[parseInt(j.si, 10)] = [j, ne, T.r]
                                    }
                                } else(E = U.match(/<f[^>]*\/>/)) && (j = Oe(E[0]), Se[j.si] && (R.f = Qx(Se[j.si][1], Se[j.si][2], T.r)));
                                var Q = pt(T.r);
                                for (_ = 0; _ < ke.length; ++_) Q.r >= ke[_][0].s.r && Q.r <= ke[_][0].e.r && Q.c >= ke[_][0].s.c && Q.c <= ke[_][0].e.c && (R.F = ke[_][1])
                            }
                            if (T.t == null && R.v === void 0)
                                if (R.f || R.F) R.v = 0, R.t = "n";
                                else if (b) R.t = "z";
                            else continue;
                            else R.t = T.t || "n";
                            switch (u.s.c > P && (u.s.c = P), u.e.c < P && (u.e.c = P), R.t) {
                                case "n":
                                    if (R.v == "" || R.v == null) {
                                        if (!b) continue;
                                        R.t = "z"
                                    } else R.v = parseFloat(R.v);
                                    break;
                                case "s":
                                    if (typeof R.v > "u") {
                                        if (!b) continue;
                                        R.t = "z"
                                    } else X = Pi[parseInt(R.v, 10)], R.v = X.t, R.r = X.r, f.cellHTML && (R.h = X.h);
                                    break;
                                case "str":
                                    R.t = "s", R.v = R.v != null ? at(R.v) : "", f.cellHTML && (R.h = t0(R.v));
                                    break;
                                case "inlineStr":
                                    E = U.match(a), R.t = "s", E != null && (X = v0(E[1])) ? (R.v = X.t, f.cellHTML && (R.h = X.h)) : R.v = "";
                                    break;
                                case "b":
                                    R.v = lt(R.v);
                                    break;
                                case "d":
                                    f.cellDates ? R.v = ft(R.v, 1) : (R.v = Ot(ft(R.v, 1)), R.t = "n");
                                    break;
                                case "e":
                                    (!f || f.cellText !== !1) && (R.w = R.v), R.v = Rl[R.v];
                                    break
                            }
                            if (B = se = 0, oe = null, _e && T.s !== void 0 && (oe = p.CellXf[T.s], oe != null && (oe.numFmtId != null && (B = oe.numFmtId), f.cellStyles && oe.fillId != null && (se = oe.fillId))), Of(R, B, se, f, h, p), f.cellDates && _e && R.t == "n" && li(Ie[B]) && (R.t = "d", R.v = Jn(R.v)), T.cm && f.xlmeta) {
                                var Pe = (f.xlmeta.Cell || [])[+T.cm - 1];
                                Pe && Pe.type == "XLDAPR" && (R.D = !0)
                            }
                            if (Ve) {
                                var A = pt(T.r);
                                l[A.r] || (l[A.r] = []), l[A.r][A.c] = R
                            } else l[T.r] = R
                        }
                }
            }
        }
        me.length > 0 && (l["!rows"] = me)
    }
})();

function iv(e, r, t, a) {
    var i = [],
        n = [],
        s = Xe(e["!ref"]),
        o = "",
        c, l = "",
        f = [],
        u = 0,
        h = 0,
        p = e["!rows"],
        m = Array.isArray(e),
        d = {
            r: l
        },
        x, E = -1;
    for (h = s.s.c; h <= s.e.c; ++h) f[h] = ht(h);
    for (u = s.s.r; u <= s.e.r; ++u) {
        for (n = [], l = Tt(u), h = s.s.c; h <= s.e.c; ++h) {
            c = f[h] + l;
            var S = m ? (e[u] || [])[h] : e[c];
            S !== void 0 && (o = rv(S, c, e, r, t, a)) != null && n.push(o)
        }(n.length > 0 || p && p[u]) && (d = {
            r: l
        }, p && p[u] && (x = p[u], x.hidden && (d.hidden = 1), E = -1, x.hpx ? E = Yi(x.hpx) : x.hpt && (E = x.hpt), E > -1 && (d.ht = E, d.customHeight = 1), x.level && (d.outlineLevel = x.level)), i[i.length] = ce("row", n.join(""), d))
    }
    if (p)
        for (; u < p.length; ++u) p && p[u] && (d = {
            r: u + 1
        }, x = p[u], x.hidden && (d.hidden = 1), E = -1, x.hpx ? E = Yi(x.hpx) : x.hpt && (E = x.hpt), E > -1 && (d.ht = E, d.customHeight = 1), x.level && (d.outlineLevel = x.level), i[i.length] = ce("row", "", d));
    return i.join("")
}

function Rf(e, r, t, a) {
    var i = [yt, ce("worksheet", null, {
            xmlns: La[0],
            "xmlns:r": Mt.r
        })],
        n = t.SheetNames[e],
        s = 0,
        o = "",
        c = t.Sheets[n];
    c == null && (c = {});
    var l = c["!ref"] || "A1",
        f = Xe(l);
    if (f.e.c > 16383 || f.e.r > 1048575) {
        if (r.WTF) throw new Error("Range " + l + " exceeds format limit A1:XFD1048576");
        f.e.c = Math.min(f.e.c, 16383), f.e.r = Math.min(f.e.c, 1048575), l = Ne(f)
    }
    a || (a = {}), c["!comments"] = [];
    var u = [];
    H_(c, t, e, r, i), i[i.length] = ce("dimension", null, {
        ref: l
    }), i[i.length] = tv(c, r, e, t), r.sheetFormat && (i[i.length] = ce("sheetFormatPr", null, {
        defaultRowHeight: r.sheetFormat.defaultRowHeight || "16",
        baseColWidth: r.sheetFormat.baseColWidth || "10",
        outlineLevelRow: r.sheetFormat.outlineLevelRow || "7"
    })), c["!cols"] != null && c["!cols"].length > 0 && (i[i.length] = K_(c, c["!cols"])), i[s = i.length] = "<sheetData/>", c["!links"] = [], c["!ref"] != null && (o = iv(c, r, e, t, a), o.length > 0 && (i[i.length] = o)), i.length > s + 1 && (i[i.length] = "</sheetData>", i[s] = i[s].replace("/>", ">")), c["!protect"] && (i[i.length] = X_(c["!protect"])), c["!autofilter"] != null && (i[i.length] = Z_(c["!autofilter"], c, t, e)), c["!merges"] != null && c["!merges"].length > 0 && (i[i.length] = V_(c["!merges"]));
    var h = -1,
        p, m = -1;
    return c["!links"].length > 0 && (i[i.length] = "<hyperlinks>", c["!links"].forEach(function(d) {
        d[1].Target && (p = {
            ref: d[0]
        }, d[1].Target.charAt(0) != "#" && (m = et(a, -1, tt(d[1].Target).replace(/#.*$/, ""), Be.HLINK), p["r:id"] = "rId" + m), (h = d[1].Target.indexOf("#")) > -1 && (p.location = tt(d[1].Target.slice(h + 1))), d[1].Tooltip && (p.tooltip = tt(d[1].Tooltip)), i[i.length] = ce("hyperlink", null, p))
    }), i[i.length] = "</hyperlinks>"), delete c["!links"], c["!margins"] != null && (i[i.length] = $_(c["!margins"])), (!r || r.ignoreEC || r.ignoreEC == null) && (i[i.length] = Ut("ignoredErrors", ce("ignoredError", null, {
        numberStoredAsText: 1,
        sqref: l
    }))), u.length > 0 && (m = et(a, -1, "../drawings/drawing" + (e + 1) + ".xml", Be.DRAW), i[i.length] = ce("drawing", null, {
        "r:id": "rId" + m
    }), c["!drawing"] = u), c["!comments"].length > 0 && (m = et(a, -1, "../drawings/vmlDrawing" + (e + 1) + ".vml", Be.VML), i[i.length] = ce("legacyDrawing", null, {
        "r:id": "rId" + m
    }), c["!legacy"] = m), i.length > 1 && (i[i.length] = "</worksheet>", i[1] = i[1].replace("/>", ">")), i.join("")
}

function nv(e, r) {
    var t = {},
        a = e.l + r;
    t.r = e.read_shift(4), e.l += 4;
    var i = e.read_shift(2);
    e.l += 1;
    var n = e.read_shift(1);
    return e.l = a, n & 7 && (t.level = n & 7), n & 16 && (t.hidden = !0), n & 32 && (t.hpt = i / 20), t
}

function sv(e, r, t) {
    var a = Y(145),
        i = (t["!rows"] || [])[e] || {};
    a.write_shift(4, e), a.write_shift(4, 0);
    var n = 320;
    i.hpx ? n = Yi(i.hpx) * 20 : i.hpt && (n = i.hpt * 20), a.write_shift(2, n), a.write_shift(1, 0);
    var s = 0;
    i.level && (s |= i.level), i.hidden && (s |= 16), (i.hpx || i.hpt) && (s |= 32), a.write_shift(1, s), a.write_shift(1, 0);
    var o = 0,
        c = a.l;
    a.l += 4;
    for (var l = {
            r: e,
            c: 0
        }, f = 0; f < 16; ++f)
        if (!(r.s.c > f + 1 << 10 || r.e.c < f << 10)) {
            for (var u = -1, h = -1, p = f << 10; p < f + 1 << 10; ++p) {
                l.c = p;
                var m = Array.isArray(t) ? (t[l.r] || [])[l.c] : t[Me(l)];
                m && (u < 0 && (u = p), h = p)
            }
            u < 0 || (++o, a.write_shift(4, u), a.write_shift(4, h))
        }
    var d = a.l;
    return a.l = c, a.write_shift(4, o), a.l = d, a.length > a.l ? a.slice(0, a.l) : a
}

function ov(e, r, t, a) {
    var i = sv(a, t, r);
    (i.length > 17 || (r["!rows"] || [])[a]) && ee(e, 0, i)
}
var cv = Wa,
    lv = hi;

function fv() {}

function uv(e, r) {
    var t = {},
        a = e[e.l];
    return ++e.l, t.above = !(a & 64), t.left = !(a & 128), e.l += 18, t.name = ph(e, r - 19), t
}

function dv(e, r, t) {
    t == null && (t = Y(84 + 4 * e.length));
    var a = 192;
    r && (r.above && (a &= -65), r.left && (a &= -129)), t.write_shift(1, a);
    for (var i = 1; i < 3; ++i) t.write_shift(1, 0);
    return Vn({
        auto: 1
    }, t), t.write_shift(-4, -1), t.write_shift(-4, -1), bl(e, t), t.slice(0, t.l)
}

function hv(e) {
    var r = Mr(e);
    return [r]
}

function pv(e, r, t) {
    return t == null && (t = Y(8)), Ba(r, t)
}

function mv(e) {
    var r = Ua(e);
    return [r]
}

function xv(e, r, t) {
    return t == null && (t = Y(4)), Va(r, t)
}

function gv(e) {
    var r = Mr(e),
        t = e.read_shift(1);
    return [r, t, "b"]
}

function _v(e, r, t) {
    return t == null && (t = Y(9)), Ba(r, t), t.write_shift(1, e.v ? 1 : 0), t
}

function vv(e) {
    var r = Ua(e),
        t = e.read_shift(1);
    return [r, t, "b"]
}

function wv(e, r, t) {
    return t == null && (t = Y(5)), Va(r, t), t.write_shift(1, e.v ? 1 : 0), t
}

function Sv(e) {
    var r = Mr(e),
        t = e.read_shift(1);
    return [r, t, "e"]
}

function Ev(e, r, t) {
    return t == null && (t = Y(9)), Ba(r, t), t.write_shift(1, e.v), t
}

function Cv(e) {
    var r = Ua(e),
        t = e.read_shift(1);
    return [r, t, "e"]
}

function Tv(e, r, t) {
    return t == null && (t = Y(8)), Va(r, t), t.write_shift(1, e.v), t.write_shift(2, 0), t.write_shift(1, 0), t
}

function yv(e) {
    var r = Mr(e),
        t = e.read_shift(4);
    return [r, t, "s"]
}

function kv(e, r, t) {
    return t == null && (t = Y(12)), Ba(r, t), t.write_shift(4, r.v), t
}

function Fv(e) {
    var r = Ua(e),
        t = e.read_shift(4);
    return [r, t, "s"]
}

function Av(e, r, t) {
    return t == null && (t = Y(8)), Va(r, t), t.write_shift(4, r.v), t
}

function bv(e) {
    var r = Mr(e),
        t = zt(e);
    return [r, t, "n"]
}

function Iv(e, r, t) {
    return t == null && (t = Y(16)), Ba(r, t), Da(e.v, t), t
}

function Pf(e) {
    var r = Ua(e),
        t = zt(e);
    return [r, t, "n"]
}

function Mv(e, r, t) {
    return t == null && (t = Y(12)), Va(r, t), Da(e.v, t), t
}

function Ov(e) {
    var r = Mr(e),
        t = p0(e);
    return [r, t, "n"]
}

function Dv(e, r, t) {
    return t == null && (t = Y(12)), Ba(r, t), Il(e.v, t), t
}

function Rv(e) {
    var r = Ua(e),
        t = p0(e);
    return [r, t, "n"]
}

function Pv(e, r, t) {
    return t == null && (t = Y(8)), Va(r, t), Il(e.v, t), t
}

function Nv(e) {
    var r = Mr(e),
        t = u0(e);
    return [r, t, "is"]
}

function Lv(e) {
    var r = Mr(e),
        t = qt(e);
    return [r, t, "str"]
}

function Bv(e, r, t) {
    return t == null && (t = Y(12 + 4 * e.v.length)), Ba(r, t), Nt(e.v, t), t.length > t.l ? t.slice(0, t.l) : t
}

function Uv(e) {
    var r = Ua(e),
        t = qt(e);
    return [r, t, "str"]
}

function Vv(e, r, t) {
    return t == null && (t = Y(8 + 4 * e.v.length)), Va(r, t), Nt(e.v, t), t.length > t.l ? t.slice(0, t.l) : t
}

function Wv(e, r, t) {
    var a = e.l + r,
        i = Mr(e);
    i.r = t["!row"];
    var n = e.read_shift(1),
        s = [i, n, "b"];
    if (t.cellFormula) {
        e.l += 2;
        var o = ts(e, a - e.l, t);
        s[3] = Ht(o, null, i, t.supbooks, t)
    } else e.l = a;
    return s
}

function Hv(e, r, t) {
    var a = e.l + r,
        i = Mr(e);
    i.r = t["!row"];
    var n = e.read_shift(1),
        s = [i, n, "e"];
    if (t.cellFormula) {
        e.l += 2;
        var o = ts(e, a - e.l, t);
        s[3] = Ht(o, null, i, t.supbooks, t)
    } else e.l = a;
    return s
}

function Gv(e, r, t) {
    var a = e.l + r,
        i = Mr(e);
    i.r = t["!row"];
    var n = zt(e),
        s = [i, n, "n"];
    if (t.cellFormula) {
        e.l += 2;
        var o = ts(e, a - e.l, t);
        s[3] = Ht(o, null, i, t.supbooks, t)
    } else e.l = a;
    return s
}

function zv(e, r, t) {
    var a = e.l + r,
        i = Mr(e);
    i.r = t["!row"];
    var n = qt(e),
        s = [i, n, "str"];
    if (t.cellFormula) {
        e.l += 2;
        var o = ts(e, a - e.l, t);
        s[3] = Ht(o, null, i, t.supbooks, t)
    } else e.l = a;
    return s
}
var Xv = Wa,
    qv = hi;

function jv(e, r) {
    return r == null && (r = Y(4)), r.write_shift(4, e), r
}

function $v(e, r) {
    var t = e.l + r,
        a = Wa(e, 16),
        i = d0(e),
        n = qt(e),
        s = qt(e),
        o = qt(e);
    e.l = t;
    var c = {
        rfx: a,
        relId: i,
        loc: n,
        display: o
    };
    return s && (c.Tooltip = s), c
}

function Yv(e, r) {
    var t = Y(50 + 4 * (e[1].Target.length + (e[1].Tooltip || "").length));
    hi({
        s: pt(e[0]),
        e: pt(e[0])
    }, t), h0("rId" + r, t);
    var a = e[1].Target.indexOf("#"),
        i = a == -1 ? "" : e[1].Target.slice(a + 1);
    return Nt(i || "", t), Nt(e[1].Tooltip || "", t), Nt("", t), t.slice(0, t.l)
}

function Kv() {}

function Jv(e, r, t) {
    var a = e.l + r,
        i = Ml(e, 16),
        n = e.read_shift(1),
        s = [i];
    if (s[2] = n, t.cellFormula) {
        var o = S_(e, a - e.l, t);
        s[1] = o
    } else e.l = a;
    return s
}

function Zv(e, r, t) {
    var a = e.l + r,
        i = Wa(e, 16),
        n = [i];
    if (t.cellFormula) {
        var s = C_(e, a - e.l, t);
        n[1] = s, e.l = a
    } else e.l = a;
    return n
}

function Qv(e, r, t) {
    t == null && (t = Y(18));
    var a = rs(e, r);
    t.write_shift(-4, e), t.write_shift(-4, e), t.write_shift(4, (a.width || 10) * 256), t.write_shift(4, 0);
    var i = 0;
    return r.hidden && (i |= 1), typeof a.width == "number" && (i |= 2), r.level && (i |= r.level << 8), t.write_shift(2, i), t
}
var Nf = ["left", "right", "top", "bottom", "header", "footer"];

function e2(e) {
    var r = {};
    return Nf.forEach(function(t) {
        r[t] = zt(e, 8)
    }), r
}

function t2(e, r) {
    return r == null && (r = Y(48)), Ia(e), Nf.forEach(function(t) {
        Da(e[t], r)
    }), r
}

function r2(e) {
    var r = e.read_shift(2);
    return e.l += 28, {
        RTL: r & 32
    }
}

function a2(e, r, t) {
    t == null && (t = Y(30));
    var a = 924;
    return (((r || {}).Views || [])[0] || {}).RTL && (a |= 32), t.write_shift(2, a), t.write_shift(4, 0), t.write_shift(4, 0), t.write_shift(4, 0), t.write_shift(1, 0), t.write_shift(1, 0), t.write_shift(2, 0), t.write_shift(2, 100), t.write_shift(2, 0), t.write_shift(2, 0), t.write_shift(2, 0), t.write_shift(4, 0), t
}

function i2(e) {
    var r = Y(24);
    return r.write_shift(4, 4), r.write_shift(4, 1), hi(e, r), r
}

function n2(e, r) {
    return r == null && (r = Y(66)), r.write_shift(2, e.password ? w0(e.password) : 0), r.write_shift(4, 1), [
        ["objects", !1],
        ["scenarios", !1],
        ["formatCells", !0],
        ["formatColumns", !0],
        ["formatRows", !0],
        ["insertColumns", !0],
        ["insertRows", !0],
        ["insertHyperlinks", !0],
        ["deleteColumns", !0],
        ["deleteRows", !0],
        ["selectLockedCells", !1],
        ["sort", !0],
        ["autoFilter", !0],
        ["pivotTables", !0],
        ["selectUnlockedCells", !1]
    ].forEach(function(t) {
        t[1] ? r.write_shift(4, e[t[0]] != null && !e[t[0]] ? 1 : 0) : r.write_shift(4, e[t[0]] != null && e[t[0]] ? 0 : 1)
    }), r
}

function s2() {}

function o2() {}

function c2(e, r, t, a, i, n, s) {
    if (!e) return e;
    var o = r || {};
    a || (a = {
        "!id": {}
    }), _t != null && o.dense == null && (o.dense = _t);
    var c = o.dense ? [] : {},
        l, f = {
            s: {
                r: 2e6,
                c: 2e6
            },
            e: {
                r: 0,
                c: 0
            }
        },
        u = [],
        h = !1,
        p = !1,
        m, d, x, E, S, _, L, U, R, T = [];
    o.biff = 12, o["!row"] = 0;
    var N = 0,
        P = !1,
        X = [],
        j = {},
        B = o.supbooks || i.supbooks || [
            []
        ];
    if (B.sharedf = j, B.arrayf = X, B.SheetNames = i.SheetNames || i.Sheets.map(function(Te) {
            return Te.name
        }), !o.supbooks && (o.supbooks = B, i.Names))
        for (var se = 0; se < i.Names.length; ++se) B[0][se + 1] = i.Names[se];
    var _e = [],
        oe = [],
        ke = !1;
    Ki[16] = {
        n: "BrtShortReal",
        f: Pf
    };
    var Se, Ve;
    if (aa(e, function(Z, b, H) {
            if (!p) switch (H) {
                case 148:
                    l = Z;
                    break;
                case 0:
                    m = Z, o.sheetRows && o.sheetRows <= m.r && (p = !0), U = Tt(E = m.r), o["!row"] = m.r, (Z.hidden || Z.hpt || Z.level != null) && (Z.hpt && (Z.hpx = ci(Z.hpt)), oe[Z.r] = Z);
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 62:
                    switch (d = {
                        t: Z[2]
                    }, Z[2]) {
                        case "n":
                            d.v = Z[1];
                            break;
                        case "s":
                            L = Pi[Z[1]], d.v = L.t, d.r = L.r;
                            break;
                        case "b":
                            d.v = !!Z[1];
                            break;
                        case "e":
                            d.v = Z[1], o.cellText !== !1 && (d.w = ia[d.v]);
                            break;
                        case "str":
                            d.t = "s", d.v = Z[1];
                            break;
                        case "is":
                            d.t = "s", d.v = Z[1].t;
                            break
                    }
                    if ((x = s.CellXf[Z[0].iStyleRef]) && Of(d, x.numFmtId, null, o, n, s), S = Z[0].c == -1 ? S + 1 : Z[0].c, o.dense ? (c[E] || (c[E] = []), c[E][S] = d) : c[ht(S) + U] = d, o.cellFormula) {
                        for (P = !1, N = 0; N < X.length; ++N) {
                            var O = X[N];
                            m.r >= O[0].s.r && m.r <= O[0].e.r && S >= O[0].s.c && S <= O[0].e.c && (d.F = Ne(O[0]), P = !0)
                        }!P && Z.length > 3 && (d.f = Z[3])
                    }
                    if (f.s.r > m.r && (f.s.r = m.r), f.s.c > S && (f.s.c = S), f.e.r < m.r && (f.e.r = m.r), f.e.c < S && (f.e.c = S), o.cellDates && x && d.t == "n" && li(Ie[x.numFmtId])) {
                        var M = ka(d.v);
                        M && (d.t = "d", d.v = new Date(M.y, M.m - 1, M.d, M.H, M.M, M.S, M.u))
                    }
                    Se && (Se.type == "XLDAPR" && (d.D = !0), Se = void 0), Ve && (Ve = void 0);
                    break;
                case 1:
                case 12:
                    if (!o.sheetStubs || h) break;
                    d = {
                        t: "z",
                        v: void 0
                    }, S = Z[0].c == -1 ? S + 1 : Z[0].c, o.dense ? (c[E] || (c[E] = []), c[E][S] = d) : c[ht(S) + U] = d, f.s.r > m.r && (f.s.r = m.r), f.s.c > S && (f.s.c = S), f.e.r < m.r && (f.e.r = m.r), f.e.c < S && (f.e.c = S), Se && (Se.type == "XLDAPR" && (d.D = !0), Se = void 0), Ve && (Ve = void 0);
                    break;
                case 176:
                    T.push(Z);
                    break;
                case 49:
                    Se = ((o.xlmeta || {}).Cell || [])[Z - 1];
                    break;
                case 494:
                    var J = a["!id"][Z.relId];
                    for (J ? (Z.Target = J.Target, Z.loc && (Z.Target += "#" + Z.loc), Z.Rel = J) : Z.relId == "" && (Z.Target = "#" + Z.loc), E = Z.rfx.s.r; E <= Z.rfx.e.r; ++E)
                        for (S = Z.rfx.s.c; S <= Z.rfx.e.c; ++S) o.dense ? (c[E] || (c[E] = []), c[E][S] || (c[E][S] = {
                            t: "z",
                            v: void 0
                        }), c[E][S].l = Z) : (_ = Me({
                            c: S,
                            r: E
                        }), c[_] || (c[_] = {
                            t: "z",
                            v: void 0
                        }), c[_].l = Z);
                    break;
                case 426:
                    if (!o.cellFormula) break;
                    X.push(Z), R = o.dense ? c[E][S] : c[ht(S) + U], R.f = Ht(Z[1], f, {
                        r: m.r,
                        c: S
                    }, B, o), R.F = Ne(Z[0]);
                    break;
                case 427:
                    if (!o.cellFormula) break;
                    j[Me(Z[0].s)] = Z[1], R = o.dense ? c[E][S] : c[ht(S) + U], R.f = Ht(Z[1], f, {
                        r: m.r,
                        c: S
                    }, B, o);
                    break;
                case 60:
                    if (!o.cellStyles) break;
                    for (; Z.e >= Z.s;) _e[Z.e--] = {
                        width: Z.w / 256,
                        hidden: !!(Z.flags & 1),
                        level: Z.level
                    }, ke || (ke = !0, S0(Z.w / 256)), ma(_e[Z.e + 1]);
                    break;
                case 161:
                    c["!autofilter"] = {
                        ref: Ne(Z)
                    };
                    break;
                case 476:
                    c["!margins"] = Z;
                    break;
                case 147:
                    i.Sheets[t] || (i.Sheets[t] = {}), Z.name && (i.Sheets[t].CodeName = Z.name), (Z.above || Z.left) && (c["!outline"] = {
                        above: Z.above,
                        left: Z.left
                    });
                    break;
                case 137:
                    i.Views || (i.Views = [{}]), i.Views[0] || (i.Views[0] = {}), Z.RTL && (i.Views[0].RTL = !0);
                    break;
                case 485:
                    break;
                case 64:
                case 1053:
                    break;
                case 151:
                    break;
                case 152:
                case 175:
                case 644:
                case 625:
                case 562:
                case 396:
                case 1112:
                case 1146:
                case 471:
                case 1050:
                case 649:
                case 1105:
                case 589:
                case 607:
                case 564:
                case 1055:
                case 168:
                case 174:
                case 1180:
                case 499:
                case 507:
                case 550:
                case 171:
                case 167:
                case 1177:
                case 169:
                case 1181:
                case 551:
                case 552:
                case 661:
                case 639:
                case 478:
                case 537:
                case 477:
                case 536:
                case 1103:
                case 680:
                case 1104:
                case 1024:
                case 663:
                case 535:
                case 678:
                case 504:
                case 1043:
                case 428:
                case 170:
                case 3072:
                case 50:
                case 2070:
                case 1045:
                    break;
                case 35:
                    h = !0;
                    break;
                case 36:
                    h = !1;
                    break;
                case 37:
                    u.push(H), h = !0;
                    break;
                case 38:
                    u.pop(), h = !1;
                    break;
                default:
                    if (!b.T) {
                        if (!h || o.WTF) throw new Error("Unexpected record 0x" + H.toString(16))
                    }
            }
        }, o), delete o.supbooks, delete o["!row"], !c["!ref"] && (f.s.r < 2e6 || l && (l.e.r > 0 || l.e.c > 0 || l.s.r > 0 || l.s.c > 0)) && (c["!ref"] = Ne(l || f)), o.sheetRows && c["!ref"]) {
        var me = Xe(c["!ref"]);
        o.sheetRows <= +me.e.r && (me.e.r = o.sheetRows - 1, me.e.r > f.e.r && (me.e.r = f.e.r), me.e.r < me.s.r && (me.s.r = me.e.r), me.e.c > f.e.c && (me.e.c = f.e.c), me.e.c < me.s.c && (me.s.c = me.e.c), c["!fullref"] = c["!ref"], c["!ref"] = Ne(me))
    }
    return T.length > 0 && (c["!merges"] = T), _e.length > 0 && (c["!cols"] = _e), oe.length > 0 && (c["!rows"] = oe), c
}

function l2(e, r, t, a, i, n, s) {
    if (r.v === void 0) return !1;
    var o = "";
    switch (r.t) {
        case "b":
            o = r.v ? "1" : "0";
            break;
        case "d":
            r = ut(r), r.z = r.z || Ie[14], r.v = Ot(ft(r.v)), r.t = "n";
            break;
        case "n":
        case "e":
            o = "" + r.v;
            break;
        default:
            o = r.v;
            break
    }
    var c = {
        r: t,
        c: a
    };
    switch (c.s = wa(i.cellXfs, r, i), r.l && n["!links"].push([Me(c), r.l]), r.c && n["!comments"].push([Me(c), r.c]), r.t) {
        case "s":
        case "str":
            return i.bookSST ? (o = k0(i.Strings, r.v, i.revStrings), c.t = "s", c.v = o, s ? ee(e, 18, Av(r, c)) : ee(e, 7, kv(r, c))) : (c.t = "str", s ? ee(e, 17, Vv(r, c)) : ee(e, 6, Bv(r, c))), !0;
        case "n":
            return r.v == (r.v | 0) && r.v > -1e3 && r.v < 1e3 ? s ? ee(e, 13, Pv(r, c)) : ee(e, 2, Dv(r, c)) : s ? ee(e, 16, Mv(r, c)) : ee(e, 5, Iv(r, c)), !0;
        case "b":
            return c.t = "b", s ? ee(e, 15, wv(r, c)) : ee(e, 4, _v(r, c)), !0;
        case "e":
            return c.t = "e", s ? ee(e, 14, Tv(r, c)) : ee(e, 3, Ev(r, c)), !0
    }
    return s ? ee(e, 12, xv(r, c)) : ee(e, 1, pv(r, c)), !0
}

function f2(e, r, t, a) {
    var i = Xe(r["!ref"] || "A1"),
        n, s = "",
        o = [];
    ee(e, 145);
    var c = Array.isArray(r),
        l = i.e.r;
    r["!rows"] && (l = Math.max(i.e.r, r["!rows"].length - 1));
    for (var f = i.s.r; f <= l; ++f) {
        s = Tt(f), ov(e, r, i, f);
        var u = !1;
        if (f <= i.e.r)
            for (var h = i.s.c; h <= i.e.c; ++h) {
                f === i.s.r && (o[h] = ht(h)), n = o[h] + s;
                var p = c ? (r[f] || [])[h] : r[n];
                if (!p) {
                    u = !1;
                    continue
                }
                u = l2(e, p, f, h, a, r, u)
            }
    }
    ee(e, 146)
}

function u2(e, r) {
    !r || !r["!merges"] || (ee(e, 177, jv(r["!merges"].length)), r["!merges"].forEach(function(t) {
        ee(e, 176, qv(t))
    }), ee(e, 178))
}

function d2(e, r) {
    !r || !r["!cols"] || (ee(e, 390), r["!cols"].forEach(function(t, a) {
        t && ee(e, 60, Qv(a, t))
    }), ee(e, 391))
}

function h2(e, r) {
    !r || !r["!ref"] || (ee(e, 648), ee(e, 649, i2(Xe(r["!ref"]))), ee(e, 650))
}

function p2(e, r, t) {
    r["!links"].forEach(function(a) {
        if (a[1].Target) {
            var i = et(t, -1, a[1].Target.replace(/#.*$/, ""), Be.HLINK);
            ee(e, 494, Yv(a, i))
        }
    }), delete r["!links"]
}

function m2(e, r, t, a) {
    if (r["!comments"].length > 0) {
        var i = et(a, -1, "../drawings/vmlDrawing" + (t + 1) + ".vml", Be.VML);
        ee(e, 551, h0("rId" + i)), r["!legacy"] = i
    }
}

function x2(e, r, t, a) {
    if (r["!autofilter"]) {
        var i = r["!autofilter"],
            n = typeof i.ref == "string" ? i.ref : Ne(i.ref);
        t.Workbook || (t.Workbook = {
            Sheets: []
        }), t.Workbook.Names || (t.Workbook.Names = []);
        var s = t.Workbook.Names,
            o = or(n);
        o.s.r == o.e.r && (o.e.r = or(r["!ref"]).e.r, n = Ne(o));
        for (var c = 0; c < s.length; ++c) {
            var l = s[c];
            if (l.Name == "_xlnm._FilterDatabase" && l.Sheet == a) {
                l.Ref = "'" + t.SheetNames[a] + "'!" + n;
                break
            }
        }
        c == s.length && s.push({
            Name: "_xlnm._FilterDatabase",
            Sheet: a,
            Ref: "'" + t.SheetNames[a] + "'!" + n
        }), ee(e, 161, hi(Xe(n))), ee(e, 162)
    }
}

function g2(e, r, t) {
    ee(e, 133), ee(e, 137, a2(r, t)), ee(e, 138), ee(e, 134)
}

function _2(e, r) {
    r["!protect"] && ee(e, 535, n2(r["!protect"]))
}

function v2(e, r, t, a) {
    var i = sr(),
        n = t.SheetNames[e],
        s = t.Sheets[n] || {},
        o = n;
    try {
        t && t.Workbook && (o = t.Workbook.Sheets[e].CodeName || o)
    } catch (l) {}
    var c = Xe(s["!ref"] || "A1");
    if (c.e.c > 16383 || c.e.r > 1048575) {
        if (r.WTF) throw new Error("Range " + (s["!ref"] || "A1") + " exceeds format limit A1:XFD1048576");
        c.e.c = Math.min(c.e.c, 16383), c.e.r = Math.min(c.e.c, 1048575)
    }
    return s["!links"] = [], s["!comments"] = [], ee(i, 129), (t.vbaraw || s["!outline"]) && ee(i, 147, dv(o, s["!outline"])), ee(i, 148, lv(c)), g2(i, s, t.Workbook), d2(i, s, e, r, t), f2(i, s, e, r, t), _2(i, s), x2(i, s, t, e), u2(i, s), p2(i, s, a), s["!margins"] && ee(i, 476, t2(s["!margins"])), (!r || r.ignoreEC || r.ignoreEC == null) && h2(i, s), m2(i, s, e, a), ee(i, 130), i.end()
}

function w2(e) {
    var r = [],
        t = e.match(/^<c:numCache>/),
        a;
    (e.match(/<c:pt idx="(\d*)">(.*?)<\/c:pt>/mg) || []).forEach(function(n) {
        var s = n.match(/<c:pt idx="(\d*?)"><c:v>(.*)<\/c:v><\/c:pt>/);
        s && (r[+s[1]] = t ? +s[2] : s[2])
    });
    var i = ze((e.match(/<c:formatCode>([\s\S]*?)<\/c:formatCode>/) || ["", "General"])[1]);
    return (e.match(/<c:f>(.*?)<\/c:f>/mg) || []).forEach(function(n) {
        a = n.replace(/<.*?>/g, "")
    }), [r, i, a]
}

function S2(e, r, t, a, i, n) {
    var s = n || {
        "!type": "chart"
    };
    if (!e) return n;
    var o = 0,
        c = 0,
        l = "A",
        f = {
            s: {
                r: 2e6,
                c: 2e6
            },
            e: {
                r: 0,
                c: 0
            }
        };
    return (e.match(/<c:numCache>[\s\S]*?<\/c:numCache>/gm) || []).forEach(function(u) {
        var h = w2(u);
        f.s.r = f.s.c = 0, f.e.c = o, l = ht(o), h[0].forEach(function(p, m) {
            s[l + Tt(m)] = {
                t: "n",
                v: p,
                z: h[1]
            }, c = m
        }), f.e.r < c && (f.e.r = c), ++o
    }), o > 0 && (s["!ref"] = Ne(f)), s
}

function E2(e, r, t, a, i) {
    if (!e) return e;
    a || (a = {
        "!id": {}
    });
    var n = {
            "!type": "chart",
            "!drawel": null,
            "!rel": ""
        },
        s, o = e.match(Df);
    return o && F0(o[0], n, i, t), (s = e.match(/drawing r:id="(.*?)"/)) && (n["!rel"] = s[1]), a["!id"][n["!rel"]] && (n["!drawel"] = a["!id"][n["!rel"]]), n
}

function C2(e, r) {
    e.l += 10;
    var t = qt(e, r - 10);
    return {
        name: t
    }
}

function T2(e, r, t, a, i) {
    if (!e) return e;
    a || (a = {
        "!id": {}
    });
    var n = {
            "!type": "chart",
            "!drawel": null,
            "!rel": ""
        },
        s = [],
        o = !1;
    return aa(e, function(l, f, u) {
        switch (u) {
            case 550:
                n["!rel"] = l;
                break;
            case 651:
                i.Sheets[t] || (i.Sheets[t] = {}), l.name && (i.Sheets[t].CodeName = l.name);
                break;
            case 562:
            case 652:
            case 669:
            case 679:
            case 551:
            case 552:
            case 476:
            case 3072:
                break;
            case 35:
                o = !0;
                break;
            case 36:
                o = !1;
                break;
            case 37:
                s.push(u);
                break;
            case 38:
                s.pop();
                break;
            default:
                if (f.T > 0) s.push(u);
                else if (f.T < 0) s.pop();
                else if (!o || r.WTF) throw new Error("Unexpected record 0x" + u.toString(16))
        }
    }, r), a["!id"][n["!rel"]] && (n["!drawel"] = a["!id"][n["!rel"]]), n
}
var A0 = [
        ["allowRefreshQuery", !1, "bool"],
        ["autoCompressPictures", !0, "bool"],
        ["backupFile", !1, "bool"],
        ["checkCompatibility", !1, "bool"],
        ["CodeName", ""],
        ["date1904", !1, "bool"],
        ["defaultThemeVersion", 0, "int"],
        ["filterPrivacy", !1, "bool"],
        ["hidePivotFieldList", !1, "bool"],
        ["promptedSolutions", !1, "bool"],
        ["publishItems", !1, "bool"],
        ["refreshAllConnections", !1, "bool"],
        ["saveExternalLinkValues", !0, "bool"],
        ["showBorderUnselectedTables", !0, "bool"],
        ["showInkAnnotation", !0, "bool"],
        ["showObjects", "all"],
        ["showPivotChartFilter", !1, "bool"],
        ["updateLinks", "userSet"]
    ],
    y2 = [
        ["activeTab", 0, "int"],
        ["autoFilterDateGrouping", !0, "bool"],
        ["firstSheet", 0, "int"],
        ["minimized", !1, "bool"],
        ["showHorizontalScroll", !0, "bool"],
        ["showSheetTabs", !0, "bool"],
        ["showVerticalScroll", !0, "bool"],
        ["tabRatio", 600, "int"],
        ["visibility", "visible"]
    ],
    k2 = [],
    F2 = [
        ["calcCompleted", "true"],
        ["calcMode", "auto"],
        ["calcOnSave", "true"],
        ["concurrentCalc", "true"],
        ["fullCalcOnLoad", "false"],
        ["fullPrecision", "true"],
        ["iterate", "false"],
        ["iterateCount", "100"],
        ["iterateDelta", "0.001"],
        ["refMode", "A1"]
    ];

function Wc(e, r) {
    for (var t = 0; t != e.length; ++t)
        for (var a = e[t], i = 0; i != r.length; ++i) {
            var n = r[i];
            if (a[n[0]] == null) a[n[0]] = n[1];
            else switch (n[2]) {
                case "bool":
                    typeof a[n[0]] == "string" && (a[n[0]] = lt(a[n[0]]));
                    break;
                case "int":
                    typeof a[n[0]] == "string" && (a[n[0]] = parseInt(a[n[0]], 10));
                    break
            }
        }
}

function Hc(e, r) {
    for (var t = 0; t != r.length; ++t) {
        var a = r[t];
        if (e[a[0]] == null) e[a[0]] = a[1];
        else switch (a[2]) {
            case "bool":
                typeof e[a[0]] == "string" && (e[a[0]] = lt(e[a[0]]));
                break;
            case "int":
                typeof e[a[0]] == "string" && (e[a[0]] = parseInt(e[a[0]], 10));
                break
        }
    }
}

function Lf(e) {
    Hc(e.WBProps, A0), Hc(e.CalcPr, F2), Wc(e.WBView, y2), Wc(e.Sheets, k2), ii.date1904 = lt(e.WBProps.date1904)
}

function A2(e) {
    return !e.Workbook || !e.Workbook.WBProps ? "false" : lt(e.Workbook.WBProps.date1904) ? "true" : "false"
}
var b2 = "][*?/\\".split("");

function Bf(e, r) {
    if (e.length > 31) {
        if (r) return !1;
        throw new Error("Sheet names cannot exceed 31 chars")
    }
    var t = !0;
    return b2.forEach(function(a) {
        if (e.indexOf(a) != -1) {
            if (!r) throw new Error("Sheet name cannot contain : \\ / ? * [ ]");
            t = !1
        }
    }), t
}

function I2(e, r, t) {
    e.forEach(function(a, i) {
        Bf(a);
        for (var n = 0; n < i; ++n)
            if (a == e[n]) throw new Error("Duplicate Sheet Name: " + a);
        if (t) {
            var s = r && r[i] && r[i].CodeName || a;
            if (s.charCodeAt(0) == 95 && s.length > 22) throw new Error("Bad Code Name: Worksheet" + s)
        }
    })
}

function M2(e) {
    if (!e || !e.SheetNames || !e.Sheets) throw new Error("Invalid Workbook");
    if (!e.SheetNames.length) throw new Error("Workbook is empty");
    var r = e.Workbook && e.Workbook.Sheets || [];
    I2(e.SheetNames, r, !!e.vbaraw);
    for (var t = 0; t < e.SheetNames.length; ++t) A_(e.Sheets[e.SheetNames[t]], e.SheetNames[t], t)
}
var O2 = /<\w+:workbook/;

function D2(e, r) {
    if (!e) throw new Error("Could not find file");
    var t = {
            AppVersion: {},
            WBProps: {},
            WBView: [],
            Sheets: [],
            CalcPr: {},
            Names: [],
            xmlns: ""
        },
        a = !1,
        i = "xmlns",
        n = {},
        s = 0;
    if (e.replace($t, function(c, l) {
            var f = Oe(c);
            switch (Xr(f[0])) {
                case "<?xml":
                    break;
                case "<workbook":
                    c.match(O2) && (i = "xmlns" + c.match(/<(\w+):/)[1]), t.xmlns = f[i];
                    break;
                case "</workbook>":
                    break;
                case "<fileVersion":
                    delete f[0], t.AppVersion = f;
                    break;
                case "<fileVersion/>":
                case "</fileVersion>":
                    break;
                case "<fileSharing":
                    break;
                case "<fileSharing/>":
                    break;
                case "<workbookPr":
                case "<workbookPr/>":
                    A0.forEach(function(u) {
                        if (f[u[0]] != null) switch (u[2]) {
                            case "bool":
                                t.WBProps[u[0]] = lt(f[u[0]]);
                                break;
                            case "int":
                                t.WBProps[u[0]] = parseInt(f[u[0]], 10);
                                break;
                            default:
                                t.WBProps[u[0]] = f[u[0]]
                        }
                    }), f.codeName && (t.WBProps.CodeName = at(f.codeName));
                    break;
                case "</workbookPr>":
                    break;
                case "<workbookProtection":
                    break;
                case "<workbookProtection/>":
                    break;
                case "<bookViews":
                case "<bookViews>":
                case "</bookViews>":
                    break;
                case "<workbookView":
                case "<workbookView/>":
                    delete f[0], t.WBView.push(f);
                    break;
                case "</workbookView>":
                    break;
                case "<sheets":
                case "<sheets>":
                case "</sheets>":
                    break;
                case "<sheet":
                    switch (f.state) {
                        case "hidden":
                            f.Hidden = 1;
                            break;
                        case "veryHidden":
                            f.Hidden = 2;
                            break;
                        default:
                            f.Hidden = 0
                    }
                    delete f.state, f.name = ze(at(f.name)), delete f[0], t.Sheets.push(f);
                    break;
                case "</sheet>":
                    break;
                case "<functionGroups":
                case "<functionGroups/>":
                    break;
                case "<functionGroup":
                    break;
                case "<externalReferences":
                case "</externalReferences>":
                case "<externalReferences>":
                    break;
                case "<externalReference":
                    break;
                case "<definedNames/>":
                    break;
                case "<definedNames>":
                case "<definedNames":
                    a = !0;
                    break;
                case "</definedNames>":
                    a = !1;
                    break;
                case "<definedName":
                    n = {}, n.Name = at(f.name), f.comment && (n.Comment = f.comment), f.localSheetId && (n.Sheet = +f.localSheetId), lt(f.hidden || "0") && (n.Hidden = !0), s = l + c.length;
                    break;
                case "</definedName>":
                    n.Ref = ze(at(e.slice(s, l))), t.Names.push(n);
                    break;
                case "<definedName/>":
                    break;
                case "<calcPr":
                    delete f[0], t.CalcPr = f;
                    break;
                case "<calcPr/>":
                    delete f[0], t.CalcPr = f;
                    break;
                case "</calcPr>":
                    break;
                case "<oleSize":
                    break;
                case "<customWorkbookViews>":
                case "</customWorkbookViews>":
                case "<customWorkbookViews":
                    break;
                case "<customWorkbookView":
                case "</customWorkbookView>":
                    break;
                case "<pivotCaches>":
                case "</pivotCaches>":
                case "<pivotCaches":
                    break;
                case "<pivotCache":
                    break;
                case "<smartTagPr":
                case "<smartTagPr/>":
                    break;
                case "<smartTagTypes":
                case "<smartTagTypes>":
                case "</smartTagTypes>":
                    break;
                case "<smartTagType":
                    break;
                case "<webPublishing":
                case "<webPublishing/>":
                    break;
                case "<fileRecoveryPr":
                case "<fileRecoveryPr/>":
                    break;
                case "<webPublishObjects>":
                case "<webPublishObjects":
                case "</webPublishObjects>":
                    break;
                case "<webPublishObject":
                    break;
                case "<extLst":
                case "<extLst>":
                case "</extLst>":
                case "<extLst/>":
                    break;
                case "<ext":
                    a = !0;
                    break;
                case "</ext>":
                    a = !1;
                    break;
                case "<ArchID":
                    break;
                case "<AlternateContent":
                case "<AlternateContent>":
                    a = !0;
                    break;
                case "</AlternateContent>":
                    a = !1;
                    break;
                case "<revisionPtr":
                    break;
                default:
                    if (!a && r.WTF) throw new Error("unrecognized " + f[0] + " in workbook")
            }
            return c
        }), La.indexOf(t.xmlns) === -1) throw new Error("Unknown Namespace: " + t.xmlns);
    return Lf(t), t
}

function Uf(e) {
    var r = [yt];
    r[r.length] = ce("workbook", null, {
        xmlns: La[0],
        "xmlns:r": Mt.r
    });
    var t = e.Workbook && (e.Workbook.Names || []).length > 0,
        a = {
            codeName: "ThisWorkbook"
        };
    e.Workbook && e.Workbook.WBProps && (A0.forEach(function(o) {
        e.Workbook.WBProps[o[0]] != null && e.Workbook.WBProps[o[0]] != o[1] && (a[o[0]] = e.Workbook.WBProps[o[0]])
    }), e.Workbook.WBProps.CodeName && (a.codeName = e.Workbook.WBProps.CodeName, delete a.CodeName)), r[r.length] = ce("workbookPr", null, a);
    var i = e.Workbook && e.Workbook.Sheets || [],
        n = 0;
    if (i && i[0] && i[0].Hidden) {
        for (r[r.length] = "<bookViews>", n = 0; n != e.SheetNames.length && !(!i[n] || !i[n].Hidden); ++n);
        n == e.SheetNames.length && (n = 0), r[r.length] = '<workbookView firstSheet="' + n + '" activeTab="' + n + '"/>', r[r.length] = "</bookViews>"
    }
    for (r[r.length] = "<sheets>", n = 0; n != e.SheetNames.length; ++n) {
        var s = {
            name: tt(e.SheetNames[n].slice(0, 31))
        };
        if (s.sheetId = "" + (n + 1), s["r:id"] = "rId" + (n + 1), i[n]) switch (i[n].Hidden) {
            case 1:
                s.state = "hidden";
                break;
            case 2:
                s.state = "veryHidden";
                break
        }
        r[r.length] = ce("sheet", null, s)
    }
    return r[r.length] = "</sheets>", t && (r[r.length] = "<definedNames>", e.Workbook && e.Workbook.Names && e.Workbook.Names.forEach(function(o) {
        var c = {
            name: o.Name
        };
        o.Comment && (c.comment = o.Comment), o.Sheet != null && (c.localSheetId = "" + o.Sheet), o.Hidden && (c.hidden = "1"), o.Ref && (r[r.length] = ce("definedName", tt(o.Ref), c))
    }), r[r.length] = "</definedNames>"), r.length > 2 && (r[r.length] = "</workbook>", r[1] = r[1].replace("/>", ">")), r.join("")
}

function R2(e, r) {
    var t = {};
    return t.Hidden = e.read_shift(4), t.iTabID = e.read_shift(4), t.strRelID = Ps(e, r - 8), t.name = qt(e), t
}

function P2(e, r) {
    return r || (r = Y(127)), r.write_shift(4, e.Hidden), r.write_shift(4, e.iTabID), h0(e.strRelID, r), Nt(e.name.slice(0, 31), r), r.length > r.l ? r.slice(0, r.l) : r
}

function N2(e, r) {
    var t = {},
        a = e.read_shift(4);
    t.defaultThemeVersion = e.read_shift(4);
    var i = r > 8 ? qt(e) : "";
    return i.length > 0 && (t.CodeName = i), t.autoCompressPictures = !!(a & 65536), t.backupFile = !!(a & 64), t.checkCompatibility = !!(a & 4096), t.date1904 = !!(a & 1), t.filterPrivacy = !!(a & 8), t.hidePivotFieldList = !!(a & 1024), t.promptedSolutions = !!(a & 16), t.publishItems = !!(a & 2048), t.refreshAllConnections = !!(a & 262144), t.saveExternalLinkValues = !!(a & 128), t.showBorderUnselectedTables = !!(a & 4), t.showInkAnnotation = !!(a & 32), t.showObjects = ["all", "placeholders", "none"][a >> 13 & 3], t.showPivotChartFilter = !!(a & 32768), t.updateLinks = ["userSet", "never", "always"][a >> 8 & 3], t
}

function L2(e, r) {
    r || (r = Y(72));
    var t = 0;
    return e && e.filterPrivacy && (t |= 8), r.write_shift(4, t), r.write_shift(4, 0), bl(e && e.CodeName || "ThisWorkbook", r), r.slice(0, r.l)
}

function B2(e, r) {
    var t = {};
    return e.read_shift(4), t.ArchID = e.read_shift(4), e.l += r - 8, t
}

function U2(e, r, t) {
    var a = e.l + r;
    e.l += 4, e.l += 1;
    var i = e.read_shift(4),
        n = mh(e),
        s = E_(e, 0, t),
        o = d0(e);
    e.l = a;
    var c = {
        Name: n,
        Ptg: s
    };
    return i < 268435455 && (c.Sheet = i), o && (c.Comment = o), c
}

function V2(e, r) {
    var t = {
            AppVersion: {},
            WBProps: {},
            WBView: [],
            Sheets: [],
            CalcPr: {},
            xmlns: ""
        },
        a = [],
        i = !1;
    r || (r = {}), r.biff = 12;
    var n = [],
        s = [
            []
        ];
    return s.SheetNames = [], s.XTI = [], Ki[16] = {
        n: "BrtFRTArchID$",
        f: B2
    }, aa(e, function(c, l, f) {
        switch (f) {
            case 156:
                s.SheetNames.push(c.name), t.Sheets.push(c);
                break;
            case 153:
                t.WBProps = c;
                break;
            case 39:
                c.Sheet != null && (r.SID = c.Sheet), c.Ref = Ht(c.Ptg, null, null, s, r), delete r.SID, delete c.Ptg, n.push(c);
                break;
            case 1036:
                break;
            case 357:
            case 358:
            case 355:
            case 667:
                s[0].length ? s.push([f, c]) : s[0] = [f, c], s[s.length - 1].XTI = [];
                break;
            case 362:
                s.length === 0 && (s[0] = [], s[0].XTI = []), s[s.length - 1].XTI = s[s.length - 1].XTI.concat(c), s.XTI = s.XTI.concat(c);
                break;
            case 361:
                break;
            case 2071:
            case 158:
            case 143:
            case 664:
            case 353:
                break;
            case 3072:
            case 3073:
            case 534:
            case 677:
            case 157:
            case 610:
            case 2050:
            case 155:
            case 548:
            case 676:
            case 128:
            case 665:
            case 2128:
            case 2125:
            case 549:
            case 2053:
            case 596:
            case 2076:
            case 2075:
            case 2082:
            case 397:
            case 154:
            case 1117:
            case 553:
            case 2091:
                break;
            case 35:
                a.push(f), i = !0;
                break;
            case 36:
                a.pop(), i = !1;
                break;
            case 37:
                a.push(f), i = !0;
                break;
            case 38:
                a.pop(), i = !1;
                break;
            case 16:
                break;
            default:
                if (!l.T) {
                    if (!i || r.WTF && a[a.length - 1] != 37 && a[a.length - 1] != 35) throw new Error("Unexpected record 0x" + f.toString(16))
                }
        }
    }, r), Lf(t), t.Names = n, t.supbooks = s, t
}

function W2(e, r) {
    ee(e, 143);
    for (var t = 0; t != r.SheetNames.length; ++t) {
        var a = r.Workbook && r.Workbook.Sheets && r.Workbook.Sheets[t] && r.Workbook.Sheets[t].Hidden || 0,
            i = {
                Hidden: a,
                iTabID: t + 1,
                strRelID: "rId" + (t + 1),
                name: r.SheetNames[t]
            };
        ee(e, 156, P2(i))
    }
    ee(e, 144)
}

function H2(e, r) {
    r || (r = Y(127));
    for (var t = 0; t != 4; ++t) r.write_shift(4, 0);
    return Nt("SheetJS", r), Nt(Ui.version, r), Nt(Ui.version, r), Nt("7262", r), r.length > r.l ? r.slice(0, r.l) : r
}

function G2(e, r) {
    r || (r = Y(29)), r.write_shift(-4, 0), r.write_shift(-4, 460), r.write_shift(4, 28800), r.write_shift(4, 17600), r.write_shift(4, 500), r.write_shift(4, e), r.write_shift(4, e);
    var t = 120;
    return r.write_shift(1, t), r.length > r.l ? r.slice(0, r.l) : r
}

function z2(e, r) {
    if (!(!r.Workbook || !r.Workbook.Sheets)) {
        for (var t = r.Workbook.Sheets, a = 0, i = -1, n = -1; a < t.length; ++a) !t[a] || !t[a].Hidden && i == -1 ? i = a : t[a].Hidden == 1 && n == -1 && (n = a);
        n > i || (ee(e, 135), ee(e, 158, G2(i)), ee(e, 136))
    }
}

function X2(e, r) {
    var t = sr();
    return ee(t, 131), ee(t, 128, H2()), ee(t, 153, L2(e.Workbook && e.Workbook.WBProps || null)), z2(t, e, r), W2(t, e, r), ee(t, 132), t.end()
}

function q2(e, r, t) {
    return r.slice(-4) === ".bin" ? V2(e, t) : D2(e, t)
}

function j2(e, r, t, a, i, n, s, o) {
    return r.slice(-4) === ".bin" ? c2(e, a, t, i, n, s, o) : U_(e, a, t, i, n, s, o)
}

function $2(e, r, t, a, i, n, s, o) {
    return r.slice(-4) === ".bin" ? T2(e, a, t, i, n, s, o) : E2(e, a, t, i, n, s, o)
}

function Y2(e, r, t, a, i, n, s, o) {
    return r.slice(-4) === ".bin" ? Jx(e, a, t, i, n, s, o) : Zx(e, a, t, i, n, s, o)
}

function K2(e, r, t, a, i, n, s, o) {
    return r.slice(-4) === ".bin" ? Yx(e, a, t, i, n, s, o) : Kx(e, a, t, i, n, s, o)
}

function J2(e, r, t, a) {
    return r.slice(-4) === ".bin" ? qm(e, t, a) : Rm(e, t, a)
}

function Z2(e, r, t) {
    return vf(e, t)
}

function Q2(e, r, t) {
    return r.slice(-4) === ".bin" ? Qp(e, t) : Kp(e, t)
}

function ew(e, r, t) {
    return r.slice(-4) === ".bin" ? zx(e, t) : Px(e, t)
}

function tw(e, r, t) {
    return r.slice(-4) === ".bin" ? Ox(e, r, t) : Ix(e, r, t)
}

function rw(e, r, t, a) {
    return t.slice(-4) === ".bin" ? Dx(e, r, t, a) : void 0
}

function aw(e, r, t) {
    return r.slice(-4) === ".bin" ? Fx(e, r, t) : bx(e, r, t)
}

function iw(e, r, t) {
    return (r.slice(-4) === ".bin" ? X2 : Uf)(e, t)
}

function nw(e, r, t, a, i) {
    return (r.slice(-4) === ".bin" ? v2 : Rf)(e, t, a, i)
}

function sw(e, r, t) {
    return (r.slice(-4) === ".bin" ? rx : gf)(e, t)
}

function ow(e, r, t) {
    return (r.slice(-4) === ".bin" ? rm : lf)(e, t)
}

function cw(e, r, t) {
    return (r.slice(-4) === ".bin" ? Xx : Ef)(e, t)
}

function lw(e) {
    return (e.slice(-4) === ".bin" ? Ax : wf)()
}
var Vf = /([\w:]+)=((?:")([^"]*)(?:")|(?:')([^']*)(?:'))/g,
    Wf = /([\w:]+)=((?:")(?:[^"]*)(?:")|(?:')(?:[^']*)(?:'))/;

function Dr(e, r) {
    var t = e.split(/\s+/),
        a = [];
    if (r || (a[0] = t[0]), t.length === 1) return a;
    var i = e.match(Vf),
        n, s, o, c;
    if (i)
        for (c = 0; c != i.length; ++c) n = i[c].match(Wf), (s = n[1].indexOf(":")) === -1 ? a[n[1]] = n[2].slice(1, n[2].length - 1) : (n[1].slice(0, 6) === "xmlns:" ? o = "xmlns" + n[1].slice(6) : o = n[1].slice(s + 1), a[o] = n[2].slice(1, n[2].length - 1));
    return a
}

function fw(e) {
    var r = e.split(/\s+/),
        t = {};
    if (r.length === 1) return t;
    var a = e.match(Vf),
        i, n, s, o;
    if (a)
        for (o = 0; o != a.length; ++o) i = a[o].match(Wf), (n = i[1].indexOf(":")) === -1 ? t[i[1]] = i[2].slice(1, i[2].length - 1) : (i[1].slice(0, 6) === "xmlns:" ? s = "xmlns" + i[1].slice(6) : s = i[1].slice(n + 1), t[s] = i[2].slice(1, i[2].length - 1));
    return t
}
var Li;

function uw(e, r) {
    var t = Li[e] || ze(e);
    return t === "General" ? Ma(r) : Ir(t, r)
}

function dw(e, r, t, a) {
    var i = a;
    switch ((t[0].match(/dt:dt="([\w.]+)"/) || ["", ""])[1]) {
        case "boolean":
            i = lt(a);
            break;
        case "i2":
        case "int":
            i = parseInt(a, 10);
            break;
        case "r4":
        case "float":
            i = parseFloat(a);
            break;
        case "date":
        case "dateTime.tz":
            i = ft(a);
            break;
        case "i8":
        case "string":
        case "fixed":
        case "uuid":
        case "bin.base64":
            break;
        default:
            throw new Error("bad custprop:" + t[0])
    }
    e[ze(r)] = i
}

function hw(e, r, t) {
    if (e.t !== "z") {
        if (!t || t.cellText !== !1) try {
            e.t === "e" ? e.w = e.w || ia[e.v] : r === "General" ? e.t === "n" ? (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = Wi(e.v) : e.w = Ma(e.v) : e.w = uw(r || "General", e.v)
        } catch (n) {
            if (t.WTF) throw n
        }
        try {
            var a = Li[r] || r || "General";
            if (t.cellNF && (e.z = a), t.cellDates && e.t == "n" && li(a)) {
                var i = ka(e.v);
                i && (e.t = "d", e.v = new Date(i.y, i.m - 1, i.d, i.H, i.M, i.S, i.u))
            }
        } catch (n) {
            if (t.WTF) throw n
        }
    }
}

function pw(e, r, t) {
    if (t.cellStyles && r.Interior) {
        var a = r.Interior;
        a.Pattern && (a.patternType = km[a.Pattern] || a.Pattern)
    }
    e[r.ID] = r
}

function mw(e, r, t, a, i, n, s, o, c, l) {
    var f = "General",
        u = a.StyleID,
        h = {};
    l = l || {};
    var p = [],
        m = 0;
    for (u === void 0 && o && (u = o.StyleID), u === void 0 && s && (u = s.StyleID); n[u] !== void 0 && (n[u].nf && (f = n[u].nf), n[u].Interior && p.push(n[u].Interior), !!n[u].Parent);) u = n[u].Parent;
    switch (t.Type) {
        case "Boolean":
            a.t = "b", a.v = lt(e);
            break;
        case "String":
            a.t = "s", a.r = nc(ze(e)), a.v = e.indexOf("<") > -1 ? ze(r || e).replace(/<.*?>/g, "") : a.r;
            break;
        case "DateTime":
            e.slice(-1) != "Z" && (e += "Z"), a.v = (ft(e) - new Date(Date.UTC(1899, 11, 30))) / (1440 * 60 * 1e3), a.v !== a.v ? a.v = ze(e) : a.v < 60 && (a.v = a.v - 1), (!f || f == "General") && (f = "yyyy-mm-dd");
        case "Number":
            a.v === void 0 && (a.v = +e), a.t || (a.t = "n");
            break;
        case "Error":
            a.t = "e", a.v = Rl[e], l.cellText !== !1 && (a.w = e);
            break;
        default:
            e == "" && r == "" ? a.t = "z" : (a.t = "s", a.v = nc(r || e));
            break
    }
    if (hw(a, f, l), l.cellFormula !== !1)
        if (a.Formula) {
            var d = ze(a.Formula);
            d.charCodeAt(0) == 61 && (d = d.slice(1)), a.f = ai(d, i), delete a.Formula, a.ArrayRange == "RC" ? a.F = ai("RC:RC", i) : a.ArrayRange && (a.F = ai(a.ArrayRange, i), c.push([Xe(a.F), a.F]))
        } else
            for (m = 0; m < c.length; ++m) i.r >= c[m][0].s.r && i.r <= c[m][0].e.r && i.c >= c[m][0].s.c && i.c <= c[m][0].e.c && (a.F = c[m][1]);
    l.cellStyles && (p.forEach(function(x) {
        !h.patternType && x.patternType && (h.patternType = x.patternType)
    }), a.s = h), a.StyleID !== void 0 && (a.ixfe = a.StyleID)
}

function xw(e) {
    e.t = e.v || "", e.t = e.t.replace(/\r\n/g, `
`).replace(/\r/g, `
`), e.v = e.w = e.ixfe = void 0
}

function As(e, r) {
    var t = r || {};
    fi();
    var a = Ai(r0(e));
    (t.type == "binary" || t.type == "array" || t.type == "base64") && (typeof Ye < "u" ? a = Ye.utils.decode(65001, Ds(a)) : a = at(a));
    var i = a.slice(0, 1024).toLowerCase(),
        n = !1;
    if (i = i.replace(/".*?"/g, ""), (i.indexOf(">") & 1023) > Math.min(i.indexOf(",") & 1023, i.indexOf(";") & 1023)) {
        var s = ut(t);
        return s.type = "string", oi.to_workbook(a, s)
    }
    if (i.indexOf("<?xml") == -1 && ["html", "table", "head", "meta", "script", "style", "div"].forEach(function(wt) {
            i.indexOf("<" + wt) >= 0 && (n = !0)
        }), n) return tS(a, t);
    Li = {
        "General Number": "General",
        "General Date": Ie[22],
        "Long Date": "dddd, mmmm dd, yyyy",
        "Medium Date": Ie[15],
        "Short Date": Ie[14],
        "Long Time": Ie[19],
        "Medium Time": Ie[18],
        "Short Time": Ie[20],
        Currency: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
        Fixed: Ie[2],
        Standard: Ie[4],
        Percent: Ie[10],
        Scientific: Ie[11],
        "Yes/No": '"Yes";"Yes";"No";@',
        "True/False": '"True";"True";"False";@',
        "On/Off": '"Yes";"Yes";"No";@'
    };
    var o, c = [],
        l;
    _t != null && t.dense == null && (t.dense = _t);
    var f = {},
        u = [],
        h = t.dense ? [] : {},
        p = "",
        m = {},
        d = {},
        x = Dr('<Data ss:Type="String">'),
        E = 0,
        S = 0,
        _ = 0,
        L = {
            s: {
                r: 2e6,
                c: 2e6
            },
            e: {
                r: 0,
                c: 0
            }
        },
        U = {},
        R = {},
        T = "",
        N = 0,
        P = [],
        X = {},
        j = {},
        B = 0,
        se = [],
        _e = [],
        oe = {},
        ke = [],
        Se, Ve = !1,
        me = [],
        Te = [],
        Z = {},
        b = 0,
        H = 0,
        O = {
            Sheets: [],
            WBProps: {
                date1904: !1
            }
        },
        M = {};
    zi.lastIndex = 0, a = a.replace(/<!--([\s\S]*?)-->/mg, "");
    for (var J = ""; o = zi.exec(a);) switch (o[3] = (J = o[3]).toLowerCase()) {
        case "data":
            if (J == "data") {
                if (o[1] === "/") {
                    if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"))
                } else o[0].charAt(o[0].length - 2) !== "/" && c.push([o[3], !0]);
                break
            }
            if (c[c.length - 1][1]) break;
            o[1] === "/" ? mw(a.slice(E, o.index), T, x, c[c.length - 1][0] == "comment" ? oe : m, {
                c: S,
                r: _
            }, U, ke[S], d, me, t) : (T = "", x = Dr(o[0]), E = o.index + o[0].length);
            break;
        case "cell":
            if (o[1] === "/")
                if (_e.length > 0 && (m.c = _e), (!t.sheetRows || t.sheetRows > _) && m.v !== void 0 && (t.dense ? (h[_] || (h[_] = []), h[_][S] = m) : h[ht(S) + Tt(_)] = m), m.HRef && (m.l = {
                        Target: ze(m.HRef)
                    }, m.HRefScreenTip && (m.l.Tooltip = m.HRefScreenTip), delete m.HRef, delete m.HRefScreenTip), (m.MergeAcross || m.MergeDown) && (b = S + (parseInt(m.MergeAcross, 10) | 0), H = _ + (parseInt(m.MergeDown, 10) | 0), P.push({
                        s: {
                            c: S,
                            r: _
                        },
                        e: {
                            c: b,
                            r: H
                        }
                    })), !t.sheetStubs) m.MergeAcross ? S = b + 1 : ++S;
                else if (m.MergeAcross || m.MergeDown) {
                for (var de = S; de <= b; ++de)
                    for (var ie = _; ie <= H; ++ie)(de > S || ie > _) && (t.dense ? (h[ie] || (h[ie] = []), h[ie][de] = {
                        t: "z"
                    }) : h[ht(de) + Tt(ie)] = {
                        t: "z"
                    });
                S = b + 1
            } else ++S;
            else m = fw(o[0]), m.Index && (S = +m.Index - 1), S < L.s.c && (L.s.c = S), S > L.e.c && (L.e.c = S), o[0].slice(-2) === "/>" && ++S, _e = [];
            break;
        case "row":
            o[1] === "/" || o[0].slice(-2) === "/>" ? (_ < L.s.r && (L.s.r = _), _ > L.e.r && (L.e.r = _), o[0].slice(-2) === "/>" && (d = Dr(o[0]), d.Index && (_ = +d.Index - 1)), S = 0, ++_) : (d = Dr(o[0]), d.Index && (_ = +d.Index - 1), Z = {}, (d.AutoFitHeight == "0" || d.Height) && (Z.hpx = parseInt(d.Height, 10), Z.hpt = Yi(Z.hpx), Te[_] = Z), d.Hidden == "1" && (Z.hidden = !0, Te[_] = Z));
            break;
        case "worksheet":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"));
                u.push(p), L.s.r <= L.e.r && L.s.c <= L.e.c && (h["!ref"] = Ne(L), t.sheetRows && t.sheetRows <= L.e.r && (h["!fullref"] = h["!ref"], L.e.r = t.sheetRows - 1, h["!ref"] = Ne(L))), P.length && (h["!merges"] = P), ke.length > 0 && (h["!cols"] = ke), Te.length > 0 && (h["!rows"] = Te), f[p] = h
            } else L = {
                s: {
                    r: 2e6,
                    c: 2e6
                },
                e: {
                    r: 0,
                    c: 0
                }
            }, _ = S = 0, c.push([o[3], !1]), l = Dr(o[0]), p = ze(l.Name), h = t.dense ? [] : {}, P = [], me = [], Te = [], M = {
                name: p,
                Hidden: 0
            }, O.Sheets.push(M);
            break;
        case "table":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"))
            } else {
                if (o[0].slice(-2) == "/>") break;
                c.push([o[3], !1]), ke = [], Ve = !1
            }
            break;
        case "style":
            o[1] === "/" ? pw(U, R, t) : R = Dr(o[0]);
            break;
        case "numberformat":
            R.nf = ze(Dr(o[0]).Format || "General"), Li[R.nf] && (R.nf = Li[R.nf]);
            for (var ne = 0; ne != 392 && Ie[ne] != R.nf; ++ne);
            if (ne == 392) {
                for (ne = 57; ne != 392; ++ne)
                    if (Ie[ne] == null) {
                        Qr(R.nf, ne);
                        break
                    }
            }
            break;
        case "column":
            if (c[c.length - 1][0] !== "table") break;
            if (Se = Dr(o[0]), Se.Hidden && (Se.hidden = !0, delete Se.Hidden), Se.Width && (Se.wpx = parseInt(Se.Width, 10)), !Ve && Se.wpx > 10) {
                Ve = !0, Gt = mf;
                for (var Q = 0; Q < ke.length; ++Q) ke[Q] && ma(ke[Q])
            }
            Ve && ma(Se), ke[Se.Index - 1 || ke.length] = Se;
            for (var Pe = 0; Pe < +Se.Span; ++Pe) ke[ke.length] = ut(Se);
            break;
        case "namedrange":
            if (o[1] === "/") break;
            O.Names || (O.Names = []);
            var A = Oe(o[0]),
                Ke = {
                    Name: A.Name,
                    Ref: ai(A.RefersTo.slice(1), {
                        r: 0,
                        c: 0
                    })
                };
            O.Sheets.length > 0 && (Ke.Sheet = O.Sheets.length - 1), O.Names.push(Ke);
            break;
        case "namedcell":
            break;
        case "b":
            break;
        case "i":
            break;
        case "u":
            break;
        case "s":
            break;
        case "em":
            break;
        case "h2":
            break;
        case "h3":
            break;
        case "sub":
            break;
        case "sup":
            break;
        case "span":
            break;
        case "alignment":
            break;
        case "borders":
            break;
        case "border":
            break;
        case "font":
            if (o[0].slice(-2) === "/>") break;
            o[1] === "/" ? T += a.slice(N, o.index) : N = o.index + o[0].length;
            break;
        case "interior":
            if (!t.cellStyles) break;
            R.Interior = Dr(o[0]);
            break;
        case "protection":
            break;
        case "author":
        case "title":
        case "description":
        case "created":
        case "keywords":
        case "subject":
        case "category":
        case "company":
        case "lastauthor":
        case "lastsaved":
        case "lastprinted":
        case "version":
        case "revision":
        case "totaltime":
        case "hyperlinkbase":
        case "manager":
        case "contentstatus":
        case "identifier":
        case "language":
        case "appname":
            if (o[0].slice(-2) === "/>") break;
            o[1] === "/" ? Vh(X, J, a.slice(B, o.index)) : B = o.index + o[0].length;
            break;
        case "paragraphs":
            break;
        case "styles":
        case "workbook":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"))
            } else c.push([o[3], !1]);
            break;
        case "comment":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"));
                xw(oe), _e.push(oe)
            } else c.push([o[3], !1]), l = Dr(o[0]), oe = {
                a: l.Author
            };
            break;
        case "autofilter":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"))
            } else if (o[0].charAt(o[0].length - 2) !== "/") {
                var He = Dr(o[0]);
                h["!autofilter"] = {
                    ref: ai(He.Range).replace(/\$/g, "")
                }, c.push([o[3], !0])
            }
            break;
        case "name":
            break;
        case "datavalidation":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"))
            } else o[0].charAt(o[0].length - 2) !== "/" && c.push([o[3], !0]);
            break;
        case "pixelsperinch":
            break;
        case "componentoptions":
        case "documentproperties":
        case "customdocumentproperties":
        case "officedocumentsettings":
        case "pivottable":
        case "pivotcache":
        case "names":
        case "mapinfo":
        case "pagebreaks":
        case "querytable":
        case "sorting":
        case "schema":
        case "conditionalformatting":
        case "smarttagtype":
        case "smarttags":
        case "excelworkbook":
        case "workbookoptions":
        case "worksheetoptions":
            if (o[1] === "/") {
                if ((l = c.pop())[0] !== o[3]) throw new Error("Bad state: " + l.join("|"))
            } else o[0].charAt(o[0].length - 2) !== "/" && c.push([o[3], !0]);
            break;
        case "null":
            break;
        default:
            if (c.length == 0 && o[3] == "document" || c.length == 0 && o[3] == "uof") return jc(a, t);
            var Je = !0;
            switch (c[c.length - 1][0]) {
                case "officedocumentsettings":
                    switch (o[3]) {
                        case "allowpng":
                            break;
                        case "removepersonalinformation":
                            break;
                        case "downloadcomponents":
                            break;
                        case "locationofcomponents":
                            break;
                        case "colors":
                            break;
                        case "color":
                            break;
                        case "index":
                            break;
                        case "rgb":
                            break;
                        case "targetscreensize":
                            break;
                        case "readonlyrecommended":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "componentoptions":
                    switch (o[3]) {
                        case "toolbar":
                            break;
                        case "hideofficelogo":
                            break;
                        case "spreadsheetautofit":
                            break;
                        case "label":
                            break;
                        case "caption":
                            break;
                        case "maxheight":
                            break;
                        case "maxwidth":
                            break;
                        case "nextsheetnumber":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "excelworkbook":
                    switch (o[3]) {
                        case "date1904":
                            O.WBProps.date1904 = !0;
                            break;
                        case "windowheight":
                            break;
                        case "windowwidth":
                            break;
                        case "windowtopx":
                            break;
                        case "windowtopy":
                            break;
                        case "tabratio":
                            break;
                        case "protectstructure":
                            break;
                        case "protectwindow":
                            break;
                        case "protectwindows":
                            break;
                        case "activesheet":
                            break;
                        case "displayinknotes":
                            break;
                        case "firstvisiblesheet":
                            break;
                        case "supbook":
                            break;
                        case "sheetname":
                            break;
                        case "sheetindex":
                            break;
                        case "sheetindexfirst":
                            break;
                        case "sheetindexlast":
                            break;
                        case "dll":
                            break;
                        case "acceptlabelsinformulas":
                            break;
                        case "donotsavelinkvalues":
                            break;
                        case "iteration":
                            break;
                        case "maxiterations":
                            break;
                        case "maxchange":
                            break;
                        case "path":
                            break;
                        case "xct":
                            break;
                        case "count":
                            break;
                        case "selectedsheets":
                            break;
                        case "calculation":
                            break;
                        case "uncalced":
                            break;
                        case "startupprompt":
                            break;
                        case "crn":
                            break;
                        case "externname":
                            break;
                        case "formula":
                            break;
                        case "colfirst":
                            break;
                        case "collast":
                            break;
                        case "wantadvise":
                            break;
                        case "boolean":
                            break;
                        case "error":
                            break;
                        case "text":
                            break;
                        case "ole":
                            break;
                        case "noautorecover":
                            break;
                        case "publishobjects":
                            break;
                        case "donotcalculatebeforesave":
                            break;
                        case "number":
                            break;
                        case "refmoder1c1":
                            break;
                        case "embedsavesmarttags":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "workbookoptions":
                    switch (o[3]) {
                        case "owcversion":
                            break;
                        case "height":
                            break;
                        case "width":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "worksheetoptions":
                    switch (o[3]) {
                        case "visible":
                            if (o[0].slice(-2) !== "/>")
                                if (o[1] === "/") switch (a.slice(B, o.index)) {
                                    case "SheetHidden":
                                        M.Hidden = 1;
                                        break;
                                    case "SheetVeryHidden":
                                        M.Hidden = 2;
                                        break
                                } else B = o.index + o[0].length;
                            break;
                        case "header":
                            h["!margins"] || Ia(h["!margins"] = {}, "xlml"), isNaN(+Oe(o[0]).Margin) || (h["!margins"].header = +Oe(o[0]).Margin);
                            break;
                        case "footer":
                            h["!margins"] || Ia(h["!margins"] = {}, "xlml"), isNaN(+Oe(o[0]).Margin) || (h["!margins"].footer = +Oe(o[0]).Margin);
                            break;
                        case "pagemargins":
                            var Ge = Oe(o[0]);
                            h["!margins"] || Ia(h["!margins"] = {}, "xlml"), isNaN(+Ge.Top) || (h["!margins"].top = +Ge.Top), isNaN(+Ge.Left) || (h["!margins"].left = +Ge.Left), isNaN(+Ge.Right) || (h["!margins"].right = +Ge.Right), isNaN(+Ge.Bottom) || (h["!margins"].bottom = +Ge.Bottom);
                            break;
                        case "displayrighttoleft":
                            O.Views || (O.Views = []), O.Views[0] || (O.Views[0] = {}), O.Views[0].RTL = !0;
                            break;
                        case "freezepanes":
                            break;
                        case "frozennosplit":
                            break;
                        case "splithorizontal":
                        case "splitvertical":
                            break;
                        case "donotdisplaygridlines":
                            break;
                        case "activerow":
                            break;
                        case "activecol":
                            break;
                        case "toprowbottompane":
                            break;
                        case "leftcolumnrightpane":
                            break;
                        case "unsynced":
                            break;
                        case "print":
                            break;
                        case "printerrors":
                            break;
                        case "panes":
                            break;
                        case "scale":
                            break;
                        case "pane":
                            break;
                        case "number":
                            break;
                        case "layout":
                            break;
                        case "pagesetup":
                            break;
                        case "selected":
                            break;
                        case "protectobjects":
                            break;
                        case "enableselection":
                            break;
                        case "protectscenarios":
                            break;
                        case "validprinterinfo":
                            break;
                        case "horizontalresolution":
                            break;
                        case "verticalresolution":
                            break;
                        case "numberofcopies":
                            break;
                        case "activepane":
                            break;
                        case "toprowvisible":
                            break;
                        case "leftcolumnvisible":
                            break;
                        case "fittopage":
                            break;
                        case "rangeselection":
                            break;
                        case "papersizeindex":
                            break;
                        case "pagelayoutzoom":
                            break;
                        case "pagebreakzoom":
                            break;
                        case "filteron":
                            break;
                        case "fitwidth":
                            break;
                        case "fitheight":
                            break;
                        case "commentslayout":
                            break;
                        case "zoom":
                            break;
                        case "lefttoright":
                            break;
                        case "gridlines":
                            break;
                        case "allowsort":
                            break;
                        case "allowfilter":
                            break;
                        case "allowinsertrows":
                            break;
                        case "allowdeleterows":
                            break;
                        case "allowinsertcols":
                            break;
                        case "allowdeletecols":
                            break;
                        case "allowinserthyperlinks":
                            break;
                        case "allowformatcells":
                            break;
                        case "allowsizecols":
                            break;
                        case "allowsizerows":
                            break;
                        case "nosummaryrowsbelowdetail":
                            h["!outline"] || (h["!outline"] = {}), h["!outline"].above = !0;
                            break;
                        case "tabcolorindex":
                            break;
                        case "donotdisplayheadings":
                            break;
                        case "showpagelayoutzoom":
                            break;
                        case "nosummarycolumnsrightdetail":
                            h["!outline"] || (h["!outline"] = {}), h["!outline"].left = !0;
                            break;
                        case "blackandwhite":
                            break;
                        case "donotdisplayzeros":
                            break;
                        case "displaypagebreak":
                            break;
                        case "rowcolheadings":
                            break;
                        case "donotdisplayoutline":
                            break;
                        case "noorientation":
                            break;
                        case "allowusepivottables":
                            break;
                        case "zeroheight":
                            break;
                        case "viewablerange":
                            break;
                        case "selection":
                            break;
                        case "protectcontents":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "pivottable":
                case "pivotcache":
                    switch (o[3]) {
                        case "immediateitemsondrop":
                            break;
                        case "showpagemultipleitemlabel":
                            break;
                        case "compactrowindent":
                            break;
                        case "location":
                            break;
                        case "pivotfield":
                            break;
                        case "orientation":
                            break;
                        case "layoutform":
                            break;
                        case "layoutsubtotallocation":
                            break;
                        case "layoutcompactrow":
                            break;
                        case "position":
                            break;
                        case "pivotitem":
                            break;
                        case "datatype":
                            break;
                        case "datafield":
                            break;
                        case "sourcename":
                            break;
                        case "parentfield":
                            break;
                        case "ptlineitems":
                            break;
                        case "ptlineitem":
                            break;
                        case "countofsameitems":
                            break;
                        case "item":
                            break;
                        case "itemtype":
                            break;
                        case "ptsource":
                            break;
                        case "cacheindex":
                            break;
                        case "consolidationreference":
                            break;
                        case "filename":
                            break;
                        case "reference":
                            break;
                        case "nocolumngrand":
                            break;
                        case "norowgrand":
                            break;
                        case "blanklineafteritems":
                            break;
                        case "hidden":
                            break;
                        case "subtotal":
                            break;
                        case "basefield":
                            break;
                        case "mapchilditems":
                            break;
                        case "function":
                            break;
                        case "refreshonfileopen":
                            break;
                        case "printsettitles":
                            break;
                        case "mergelabels":
                            break;
                        case "defaultversion":
                            break;
                        case "refreshname":
                            break;
                        case "refreshdate":
                            break;
                        case "refreshdatecopy":
                            break;
                        case "versionlastrefresh":
                            break;
                        case "versionlastupdate":
                            break;
                        case "versionupdateablemin":
                            break;
                        case "versionrefreshablemin":
                            break;
                        case "calculation":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "pagebreaks":
                    switch (o[3]) {
                        case "colbreaks":
                            break;
                        case "colbreak":
                            break;
                        case "rowbreaks":
                            break;
                        case "rowbreak":
                            break;
                        case "colstart":
                            break;
                        case "colend":
                            break;
                        case "rowend":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "autofilter":
                    switch (o[3]) {
                        case "autofiltercolumn":
                            break;
                        case "autofiltercondition":
                            break;
                        case "autofilterand":
                            break;
                        case "autofilteror":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "querytable":
                    switch (o[3]) {
                        case "id":
                            break;
                        case "autoformatfont":
                            break;
                        case "autoformatpattern":
                            break;
                        case "querysource":
                            break;
                        case "querytype":
                            break;
                        case "enableredirections":
                            break;
                        case "refreshedinxl9":
                            break;
                        case "urlstring":
                            break;
                        case "htmltables":
                            break;
                        case "connection":
                            break;
                        case "commandtext":
                            break;
                        case "refreshinfo":
                            break;
                        case "notitles":
                            break;
                        case "nextid":
                            break;
                        case "columninfo":
                            break;
                        case "overwritecells":
                            break;
                        case "donotpromptforfile":
                            break;
                        case "textwizardsettings":
                            break;
                        case "source":
                            break;
                        case "number":
                            break;
                        case "decimal":
                            break;
                        case "thousandseparator":
                            break;
                        case "trailingminusnumbers":
                            break;
                        case "formatsettings":
                            break;
                        case "fieldtype":
                            break;
                        case "delimiters":
                            break;
                        case "tab":
                            break;
                        case "comma":
                            break;
                        case "autoformatname":
                            break;
                        case "versionlastedit":
                            break;
                        case "versionlastrefresh":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "datavalidation":
                    switch (o[3]) {
                        case "range":
                            break;
                        case "type":
                            break;
                        case "min":
                            break;
                        case "max":
                            break;
                        case "sort":
                            break;
                        case "descending":
                            break;
                        case "order":
                            break;
                        case "casesensitive":
                            break;
                        case "value":
                            break;
                        case "errorstyle":
                            break;
                        case "errormessage":
                            break;
                        case "errortitle":
                            break;
                        case "inputmessage":
                            break;
                        case "inputtitle":
                            break;
                        case "combohide":
                            break;
                        case "inputhide":
                            break;
                        case "condition":
                            break;
                        case "qualifier":
                            break;
                        case "useblank":
                            break;
                        case "value1":
                            break;
                        case "value2":
                            break;
                        case "format":
                            break;
                        case "cellrangelist":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "sorting":
                case "conditionalformatting":
                    switch (o[3]) {
                        case "range":
                            break;
                        case "type":
                            break;
                        case "min":
                            break;
                        case "max":
                            break;
                        case "sort":
                            break;
                        case "descending":
                            break;
                        case "order":
                            break;
                        case "casesensitive":
                            break;
                        case "value":
                            break;
                        case "errorstyle":
                            break;
                        case "errormessage":
                            break;
                        case "errortitle":
                            break;
                        case "cellrangelist":
                            break;
                        case "inputmessage":
                            break;
                        case "inputtitle":
                            break;
                        case "combohide":
                            break;
                        case "inputhide":
                            break;
                        case "condition":
                            break;
                        case "qualifier":
                            break;
                        case "useblank":
                            break;
                        case "value1":
                            break;
                        case "value2":
                            break;
                        case "format":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "mapinfo":
                case "schema":
                case "data":
                    switch (o[3]) {
                        case "map":
                            break;
                        case "entry":
                            break;
                        case "range":
                            break;
                        case "xpath":
                            break;
                        case "field":
                            break;
                        case "xsdtype":
                            break;
                        case "filteron":
                            break;
                        case "aggregate":
                            break;
                        case "elementtype":
                            break;
                        case "attributetype":
                            break;
                        case "schema":
                        case "element":
                        case "complextype":
                        case "datatype":
                        case "all":
                        case "attribute":
                        case "extends":
                            break;
                        case "row":
                            break;
                        default:
                            Je = !1
                    }
                    break;
                case "smarttags":
                    break;
                default:
                    Je = !1;
                    break
            }
            if (Je || o[3].match(/!\[CDATA/)) break;
            if (!c[c.length - 1][1]) throw "Unrecognized tag: " + o[3] + "|" + c.join("|");
            if (c[c.length - 1][0] === "customdocumentproperties") {
                if (o[0].slice(-2) === "/>") break;
                o[1] === "/" ? dw(j, J, se, a.slice(B, o.index)) : (se = o, B = o.index + o[0].length);
                break
            }
            if (t.WTF) throw "Unrecognized tag: " + o[3] + "|" + c.join("|")
    }
    var xe = {};
    return !t.bookSheets && !t.bookProps && (xe.Sheets = f), xe.SheetNames = u, xe.Workbook = O, xe.SSF = ut(Ie), xe.Props = X, xe.Custprops = j, xe
}

function Hs(e, r) {
    switch (I0(r = r || {}), r.type || "base64") {
        case "base64":
            return As(pr(e), r);
        case "binary":
        case "buffer":
        case "file":
            return As(e, r);
        case "array":
            return As(_a(e), r)
    }
}

function gw(e, r) {
    var t = [];
    return e.Props && t.push(Wh(e.Props, r)), e.Custprops && t.push(Hh(e.Props, e.Custprops, r)), t.join("")
}

function _w() {
    return ""
}

function vw(e, r) {
    var t = ['<Style ss:ID="Default" ss:Name="Normal"><NumberFormat/></Style>'];
    return r.cellXfs.forEach(function(a, i) {
        var n = [];
        n.push(ce("NumberFormat", null, {
            "ss:Format": tt(Ie[a.numFmtId])
        }));
        var s = {
            "ss:ID": "s" + (21 + i)
        };
        t.push(ce("Style", n.join(""), s))
    }), ce("Styles", t.join(""))
}

function Hf(e) {
    return ce("NamedRange", null, {
        "ss:Name": e.Name,
        "ss:RefersTo": "=" + T0(e.Ref, {
            r: 0,
            c: 0
        })
    })
}

function ww(e) {
    if (!((e || {}).Workbook || {}).Names) return "";
    for (var r = e.Workbook.Names, t = [], a = 0; a < r.length; ++a) {
        var i = r[a];
        i.Sheet == null && (i.Name.match(/^_xlfn\./) || t.push(Hf(i)))
    }
    return ce("Names", t.join(""))
}

function Sw(e, r, t, a) {
    if (!e || !((a || {}).Workbook || {}).Names) return "";
    for (var i = a.Workbook.Names, n = [], s = 0; s < i.length; ++s) {
        var o = i[s];
        o.Sheet == t && (o.Name.match(/^_xlfn\./) || n.push(Hf(o)))
    }
    return n.join("")
}

function Ew(e, r, t, a) {
    if (!e) return "";
    var i = [];
    if (e["!margins"] && (i.push("<PageSetup>"), e["!margins"].header && i.push(ce("Header", null, {
            "x:Margin": e["!margins"].header
        })), e["!margins"].footer && i.push(ce("Footer", null, {
            "x:Margin": e["!margins"].footer
        })), i.push(ce("PageMargins", null, {
            "x:Bottom": e["!margins"].bottom || "0.75",
            "x:Left": e["!margins"].left || "0.7",
            "x:Right": e["!margins"].right || "0.7",
            "x:Top": e["!margins"].top || "0.75"
        })), i.push("</PageSetup>")), a && a.Workbook && a.Workbook.Sheets && a.Workbook.Sheets[t])
        if (a.Workbook.Sheets[t].Hidden) i.push(ce("Visible", a.Workbook.Sheets[t].Hidden == 1 ? "SheetHidden" : "SheetVeryHidden", {}));
        else {
            for (var n = 0; n < t && !(a.Workbook.Sheets[n] && !a.Workbook.Sheets[n].Hidden); ++n);
            n == t && i.push("<Selected/>")
        }
    return ((((a || {}).Workbook || {}).Views || [])[0] || {}).RTL && i.push("<DisplayRightToLeft/>"), e["!protect"] && (i.push(Ut("ProtectContents", "True")), e["!protect"].objects && i.push(Ut("ProtectObjects", "True")), e["!protect"].scenarios && i.push(Ut("ProtectScenarios", "True")), e["!protect"].selectLockedCells != null && !e["!protect"].selectLockedCells ? i.push(Ut("EnableSelection", "NoSelection")) : e["!protect"].selectUnlockedCells != null && !e["!protect"].selectUnlockedCells && i.push(Ut("EnableSelection", "UnlockedCells")), [
        ["formatCells", "AllowFormatCells"],
        ["formatColumns", "AllowSizeCols"],
        ["formatRows", "AllowSizeRows"],
        ["insertColumns", "AllowInsertCols"],
        ["insertRows", "AllowInsertRows"],
        ["insertHyperlinks", "AllowInsertHyperlinks"],
        ["deleteColumns", "AllowDeleteCols"],
        ["deleteRows", "AllowDeleteRows"],
        ["sort", "AllowSort"],
        ["autoFilter", "AllowFilter"],
        ["pivotTables", "AllowUsePivotTables"]
    ].forEach(function(s) {
        e["!protect"][s[0]] && i.push("<" + s[1] + "/>")
    })), i.length == 0 ? "" : ce("WorksheetOptions", i.join(""), {
        xmlns: ur.x
    })
}

function Cw(e) {
    return e.map(function(r) {
        var t = Gd(r.t || ""),
            a = ce("ss:Data", t, {
                xmlns: "http://www.w3.org/TR/REC-html40"
            });
        return ce("Comment", a, {
            "ss:Author": r.a
        })
    }).join("")
}

function Tw(e, r, t, a, i, n, s) {
    if (!e || e.v == null && e.f == null) return "";
    var o = {};
    if (e.f && (o["ss:Formula"] = "=" + tt(T0(e.f, s))), e.F && e.F.slice(0, r.length) == r) {
        var c = pt(e.F.slice(r.length + 1));
        o["ss:ArrayRange"] = "RC:R" + (c.r == s.r ? "" : "[" + (c.r - s.r) + "]") + "C" + (c.c == s.c ? "" : "[" + (c.c - s.c) + "]")
    }
    if (e.l && e.l.Target && (o["ss:HRef"] = tt(e.l.Target), e.l.Tooltip && (o["x:HRefScreenTip"] = tt(e.l.Tooltip))), t["!merges"])
        for (var l = t["!merges"], f = 0; f != l.length; ++f) l[f].s.c != s.c || l[f].s.r != s.r || (l[f].e.c > l[f].s.c && (o["ss:MergeAcross"] = l[f].e.c - l[f].s.c), l[f].e.r > l[f].s.r && (o["ss:MergeDown"] = l[f].e.r - l[f].s.r));
    var u = "",
        h = "";
    switch (e.t) {
        case "z":
            if (!a.sheetStubs) return "";
            break;
        case "n":
            u = "Number", h = String(e.v);
            break;
        case "b":
            u = "Boolean", h = e.v ? "1" : "0";
            break;
        case "e":
            u = "Error", h = ia[e.v];
            break;
        case "d":
            u = "DateTime", h = new Date(e.v).toISOString(), e.z == null && (e.z = e.z || Ie[14]);
            break;
        case "s":
            u = "String", h = Hd(e.v || "");
            break
    }
    var p = wa(a.cellXfs, e, a);
    o["ss:StyleID"] = "s" + (21 + p), o["ss:Index"] = s.c + 1;
    var m = e.v != null ? h : "",
        d = e.t == "z" ? "" : '<Data ss:Type="' + u + '">' + m + "</Data>";
    return (e.c || []).length > 0 && (d += Cw(e.c)), ce("Cell", d, o)
}

function yw(e, r) {
    var t = '<Row ss:Index="' + (e + 1) + '"';
    return r && (r.hpt && !r.hpx && (r.hpx = ci(r.hpt)), r.hpx && (t += ' ss:AutoFitHeight="0" ss:Height="' + r.hpx + '"'), r.hidden && (t += ' ss:Hidden="1"')), t + ">"
}

function kw(e, r, t, a) {
    if (!e["!ref"]) return "";
    var i = Xe(e["!ref"]),
        n = e["!merges"] || [],
        s = 0,
        o = [];
    e["!cols"] && e["!cols"].forEach(function(x, E) {
        ma(x);
        var S = !!x.width,
            _ = rs(E, x),
            L = {
                "ss:Index": E + 1
            };
        S && (L["ss:Width"] = ji(_.width)), x.hidden && (L["ss:Hidden"] = "1"), o.push(ce("Column", null, L))
    });
    for (var c = Array.isArray(e), l = i.s.r; l <= i.e.r; ++l) {
        for (var f = [yw(l, (e["!rows"] || [])[l])], u = i.s.c; u <= i.e.c; ++u) {
            var h = !1;
            for (s = 0; s != n.length; ++s)
                if (!(n[s].s.c > u) && !(n[s].s.r > l) && !(n[s].e.c < u) && !(n[s].e.r < l)) {
                    (n[s].s.c != u || n[s].s.r != l) && (h = !0);
                    break
                }
            if (!h) {
                var p = {
                        r: l,
                        c: u
                    },
                    m = Me(p),
                    d = c ? (e[l] || [])[u] : e[m];
                f.push(Tw(d, m, e, r, t, a, p))
            }
        }
        f.push("</Row>"), f.length > 2 && o.push(f.join(""))
    }
    return o.join("")
}

function Fw(e, r, t) {
    var a = [],
        i = t.SheetNames[e],
        n = t.Sheets[i],
        s = n ? Sw(n, r, e, t) : "";
    return s.length > 0 && a.push("<Names>" + s + "</Names>"), s = n ? kw(n, r, e, t) : "", s.length > 0 && a.push("<Table>" + s + "</Table>"), a.push(Ew(n, r, e, t)), a.join("")
}

function Aw(e, r) {
    r || (r = {}), e.SSF || (e.SSF = ut(Ie)), e.SSF && (fi(), $n(e.SSF), r.revssf = Kn(e.SSF), r.revssf[e.SSF[65535]] = 0, r.ssf = e.SSF, r.cellXfs = [], wa(r.cellXfs, {}, {
        revssf: {
            General: 0
        }
    }));
    var t = [];
    t.push(gw(e, r)), t.push(_w(e, r)), t.push(""), t.push("");
    for (var a = 0; a < e.SheetNames.length; ++a) t.push(ce("Worksheet", Fw(a, r, e), {
        "ss:Name": tt(e.SheetNames[a])
    }));
    return t[2] = vw(e, r), t[3] = ww(e, r), yt + ce("Workbook", t.join(""), {
        xmlns: ur.ss,
        "xmlns:o": ur.o,
        "xmlns:x": ur.x,
        "xmlns:ss": ur.ss,
        "xmlns:dt": ur.dt,
        "xmlns:html": ur.html
    })
}

function bw(e) {
    var r = {},
        t = e.content;
    if (t.l = 28, r.AnsiUserType = t.read_shift(0, "lpstr-ansi"), r.AnsiClipboardFormat = wh(t), t.length - t.l <= 4) return r;
    var a = t.read_shift(4);
    if (a == 0 || a > 40 || (t.l -= 4, r.Reserved1 = t.read_shift(0, "lpstr-ansi"), t.length - t.l <= 4) || (a = t.read_shift(4), a !== 1907505652) || (r.UnicodeClipboardFormat = Sh(t), a = t.read_shift(4), a == 0 || a > 40)) return r;
    t.l -= 4, r.Reserved2 = t.read_shift(0, "lpwstr")
}
var Iw = [60, 1084, 2066, 2165, 2175];

function Mw(e, r, t, a, i) {
    var n = a,
        s = [],
        o = t.slice(t.l, t.l + n);
    if (i && i.enc && i.enc.insitu && o.length > 0) switch (e) {
        case 9:
        case 521:
        case 1033:
        case 2057:
        case 47:
        case 405:
        case 225:
        case 406:
        case 312:
        case 404:
        case 10:
            break;
        case 133:
            break;
        default:
            i.enc.insitu(o)
    }
    s.push(o), t.l += n;
    for (var c = Jr(t, t.l), l = Gs[c], f = 0; l != null && Iw.indexOf(c) > -1;) n = Jr(t, t.l + 2), f = t.l + 4, c == 2066 ? f += 4 : (c == 2165 || c == 2175) && (f += 12), o = t.slice(f, t.l + 4 + n), s.push(o), t.l += 4 + n, l = Gs[c = Jr(t, t.l)];
    var u = Pt(s);
    Bt(u, 0);
    var h = 0;
    u.lens = [];
    for (var p = 0; p < s.length; ++p) u.lens.push(h), h += s[p].length;
    if (u.length < a) throw "XLS Record 0x" + e.toString(16) + " Truncated: " + u.length + " < " + a;
    return r.f(u, u.length, i)
}

function Vr(e, r, t) {
    if (e.t !== "z" && e.XF) {
        var a = 0;
        try {
            a = e.z || e.XF.numFmtId || 0, r.cellNF && (e.z = Ie[a])
        } catch (n) {
            if (r.WTF) throw n
        }
        if (!r || r.cellText !== !1) try {
            e.t === "e" ? e.w = e.w || ia[e.v] : a === 0 || a == "General" ? e.t === "n" ? (e.v | 0) === e.v ? e.w = e.v.toString(10) : e.w = Wi(e.v) : e.w = Ma(e.v) : e.w = Ir(a, e.v, {
                date1904: !!t,
                dateNF: r && r.dateNF
            })
        } catch (n) {
            if (r.WTF) throw n
        }
        if (r.cellDates && a && e.t == "n" && li(Ie[a] || String(a))) {
            var i = ka(e.v);
            i && (e.t = "d", e.v = new Date(i.y, i.m - 1, i.d, i.H, i.M, i.S, i.u))
        }
    }
}

function On(e, r, t) {
    return {
        v: e,
        ixfe: r,
        t
    }
}

function Ow(e, r) {
    var t = {
            opts: {}
        },
        a = {};
    _t != null && r.dense == null && (r.dense = _t);
    var i = r.dense ? [] : {},
        n = {},
        s = {},
        o = null,
        c = [],
        l = "",
        f = {},
        u, h = "",
        p, m, d, x, E = {},
        S = [],
        _, L, U = [],
        R = [],
        T = {
            Sheets: [],
            WBProps: {
                date1904: !1
            },
            Views: [{}]
        },
        N = {},
        P = function(We) {
            return We < 8 ? Fa[We] : We < 64 && R[We - 8] || Fa[We]
        },
        X = function(We, St, xr) {
            var It = St.XF.data;
            if (!(!It || !It.patternType || !xr || !xr.cellStyles)) {
                St.s = {}, St.s.patternType = It.patternType;
                var Sa;
                (Sa = qi(P(It.icvFore))) && (St.s.fgColor = {
                    rgb: Sa
                }), (Sa = qi(P(It.icvBack))) && (St.s.bgColor = {
                    rgb: Sa
                })
            }
        },
        j = function(We, St, xr) {
            if (!(Z > 1) && !(xr.sheetRows && We.r >= xr.sheetRows)) {
                if (xr.cellStyles && St.XF && St.XF.data && X(We, St, xr), delete St.ixfe, delete St.XF, u = We, h = Me(We), (!s || !s.s || !s.e) && (s = {
                        s: {
                            r: 0,
                            c: 0
                        },
                        e: {
                            r: 0,
                            c: 0
                        }
                    }), We.r < s.s.r && (s.s.r = We.r), We.c < s.s.c && (s.s.c = We.c), We.r + 1 > s.e.r && (s.e.r = We.r + 1), We.c + 1 > s.e.c && (s.e.c = We.c + 1), xr.cellFormula && St.f) {
                    for (var It = 0; It < S.length; ++It)
                        if (!(S[It][0].s.c > We.c || S[It][0].s.r > We.r) && !(S[It][0].e.c < We.c || S[It][0].e.r < We.r)) {
                            St.F = Ne(S[It][0]), (S[It][0].s.c != We.c || S[It][0].s.r != We.r) && delete St.f, St.f && (St.f = "" + Ht(S[It][1], s, We, me, B));
                            break
                        }
                }
                xr.dense ? (i[We.r] || (i[We.r] = []), i[We.r][We.c] = St) : i[h] = St
            }
        },
        B = {
            enc: !1,
            sbcch: 0,
            snames: [],
            sharedf: E,
            arrayf: S,
            rrtabid: [],
            lastuser: "",
            biff: 8,
            codepage: 0,
            winlocked: 0,
            cellStyles: !!r && !!r.cellStyles,
            WTF: !!r && !!r.wtf
        };
    r.password && (B.password = r.password);
    var se, _e = [],
        oe = [],
        ke = [],
        Se = [],
        Ve = !1,
        me = [];
    me.SheetNames = B.snames, me.sharedf = B.sharedf, me.arrayf = B.arrayf, me.names = [], me.XTI = [];
    var Te = 0,
        Z = 0,
        b = 0,
        H = [],
        O = [],
        M;
    B.codepage = 1200, Rr(1200);
    for (var J = !1; e.l < e.length - 1;) {
        var de = e.l,
            ie = e.read_shift(2);
        if (ie === 0 && Te === 10) break;
        var ne = e.l === e.length ? 0 : e.read_shift(2),
            Q = Gs[ie];
        if (Q && Q.f) {
            if (r.bookSheets && Te === 133 && ie !== 133) break;
            if (Te = ie, Q.r === 2 || Q.r == 12) {
                var Pe = e.read_shift(2);
                if (ne -= 2, !B.enc && Pe !== ie && ((Pe & 255) << 8 | Pe >> 8) !== ie) throw new Error("rt mismatch: " + Pe + "!=" + ie);
                Q.r == 12 && (e.l += 10, ne -= 10)
            }
            var A = {};
            if (ie === 10 ? A = Q.f(e, ne, B) : A = Mw(ie, Q, e, ne, B), Z == 0 && [9, 521, 1033, 2057].indexOf(Te) === -1) continue;
            switch (ie) {
                case 34:
                    t.opts.Date1904 = T.WBProps.date1904 = A;
                    break;
                case 134:
                    t.opts.WriteProtect = !0;
                    break;
                case 47:
                    if (B.enc || (e.l = 0), B.enc = A, !r.password) throw new Error("File is password-protected");
                    if (A.valid == null) throw new Error("Encryption scheme unsupported");
                    if (!A.valid) throw new Error("Password is incorrect");
                    break;
                case 92:
                    B.lastuser = A;
                    break;
                case 66:
                    var Ke = Number(A);
                    switch (Ke) {
                        case 21010:
                            Ke = 1200;
                            break;
                        case 32768:
                            Ke = 1e4;
                            break;
                        case 32769:
                            Ke = 1252;
                            break
                    }
                    Rr(B.codepage = Ke), J = !0;
                    break;
                case 317:
                    B.rrtabid = A;
                    break;
                case 25:
                    B.winlocked = A;
                    break;
                case 439:
                    t.opts.RefreshAll = A;
                    break;
                case 12:
                    t.opts.CalcCount = A;
                    break;
                case 16:
                    t.opts.CalcDelta = A;
                    break;
                case 17:
                    t.opts.CalcIter = A;
                    break;
                case 13:
                    t.opts.CalcMode = A;
                    break;
                case 14:
                    t.opts.CalcPrecision = A;
                    break;
                case 95:
                    t.opts.CalcSaveRecalc = A;
                    break;
                case 15:
                    B.CalcRefMode = A;
                    break;
                case 2211:
                    t.opts.FullCalc = A;
                    break;
                case 129:
                    A.fDialog && (i["!type"] = "dialog"), A.fBelow || ((i["!outline"] || (i["!outline"] = {})).above = !0), A.fRight || ((i["!outline"] || (i["!outline"] = {})).left = !0);
                    break;
                case 224:
                    U.push(A);
                    break;
                case 430:
                    me.push([A]), me[me.length - 1].XTI = [];
                    break;
                case 35:
                case 547:
                    me[me.length - 1].push(A);
                    break;
                case 24:
                case 536:
                    M = {
                        Name: A.Name,
                        Ref: Ht(A.rgce, s, null, me, B)
                    }, A.itab > 0 && (M.Sheet = A.itab - 1), me.names.push(M), me[0] || (me[0] = [], me[0].XTI = []), me[me.length - 1].push(A), A.Name == "_xlnm._FilterDatabase" && A.itab > 0 && A.rgce && A.rgce[0] && A.rgce[0][0] && A.rgce[0][0][0] == "PtgArea3d" && (O[A.itab - 1] = {
                        ref: Ne(A.rgce[0][0][1][2])
                    });
                    break;
                case 22:
                    B.ExternCount = A;
                    break;
                case 23:
                    me.length == 0 && (me[0] = [], me[0].XTI = []), me[me.length - 1].XTI = me[me.length - 1].XTI.concat(A), me.XTI = me.XTI.concat(A);
                    break;
                case 2196:
                    if (B.biff < 8) break;
                    M != null && (M.Comment = A[1]);
                    break;
                case 18:
                    i["!protect"] = A;
                    break;
                case 19:
                    A !== 0 && B.WTF && console.error("Password verifier: " + A);
                    break;
                case 133:
                    n[A.pos] = A, B.snames.push(A.name);
                    break;
                case 10:
                    {
                        if (--Z) break;
                        if (s.e) {
                            if (s.e.r > 0 && s.e.c > 0) {
                                if (s.e.r--, s.e.c--, i["!ref"] = Ne(s), r.sheetRows && r.sheetRows <= s.e.r) {
                                    var He = s.e.r;
                                    s.e.r = r.sheetRows - 1, i["!fullref"] = i["!ref"], i["!ref"] = Ne(s), s.e.r = He
                                }
                                s.e.r++, s.e.c++
                            }
                            _e.length > 0 && (i["!merges"] = _e), oe.length > 0 && (i["!objects"] = oe), ke.length > 0 && (i["!cols"] = ke), Se.length > 0 && (i["!rows"] = Se), T.Sheets.push(N)
                        }
                        l === "" ? f = i : a[l] = i,
                        i = r.dense ? [] : {}
                    }
                    break;
                case 9:
                case 521:
                case 1033:
                case 2057:
                    {
                        if (B.biff === 8 && (B.biff = {
                                9: 2,
                                521: 3,
                                1033: 4
                            }[ie] || {
                                512: 2,
                                768: 3,
                                1024: 4,
                                1280: 5,
                                1536: 8,
                                2: 2,
                                7: 2
                            }[A.BIFFVer] || 8), B.biffguess = A.BIFFVer == 0, A.BIFFVer == 0 && A.dt == 4096 && (B.biff = 5, J = !0, Rr(B.codepage = 28591)), B.biff == 8 && A.BIFFVer == 0 && A.dt == 16 && (B.biff = 2), Z++) break;
                        if (i = r.dense ? [] : {}, B.biff < 8 && !J && (J = !0, Rr(B.codepage = r.codepage || 1252)), B.biff < 5 || A.BIFFVer == 0 && A.dt == 4096) {
                            l === "" && (l = "Sheet1"), s = {
                                s: {
                                    r: 0,
                                    c: 0
                                },
                                e: {
                                    r: 0,
                                    c: 0
                                }
                            };
                            var Je = {
                                pos: e.l - ne,
                                name: l
                            };
                            n[Je.pos] = Je, B.snames.push(l)
                        } else l = (n[de] || {
                            name: ""
                        }).name;A.dt == 32 && (i["!type"] = "chart"),
                        A.dt == 64 && (i["!type"] = "macro"),
                        _e = [],
                        oe = [],
                        B.arrayf = S = [],
                        ke = [],
                        Se = [],
                        Ve = !1,
                        N = {
                            Hidden: (n[de] || {
                                hs: 0
                            }).hs,
                            name: l
                        }
                    }
                    break;
                case 515:
                case 3:
                case 2:
                    i["!type"] == "chart" && (r.dense ? (i[A.r] || [])[A.c] : i[Me({
                        c: A.c,
                        r: A.r
                    })]) && ++A.c, _ = {
                        ixfe: A.ixfe,
                        XF: U[A.ixfe] || {},
                        v: A.val,
                        t: "n"
                    }, b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                        c: A.c,
                        r: A.r
                    }, _, r);
                    break;
                case 5:
                case 517:
                    _ = {
                        ixfe: A.ixfe,
                        XF: U[A.ixfe],
                        v: A.val,
                        t: A.t
                    }, b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                        c: A.c,
                        r: A.r
                    }, _, r);
                    break;
                case 638:
                    _ = {
                        ixfe: A.ixfe,
                        XF: U[A.ixfe],
                        v: A.rknum,
                        t: "n"
                    }, b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                        c: A.c,
                        r: A.r
                    }, _, r);
                    break;
                case 189:
                    for (var Ge = A.c; Ge <= A.C; ++Ge) {
                        var xe = A.rkrec[Ge - A.c][0];
                        _ = {
                            ixfe: xe,
                            XF: U[xe],
                            v: A.rkrec[Ge - A.c][1],
                            t: "n"
                        }, b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                            c: Ge,
                            r: A.r
                        }, _, r)
                    }
                    break;
                case 6:
                case 518:
                case 1030:
                    {
                        if (A.val == "String") {
                            o = A;
                            break
                        }
                        if (_ = On(A.val, A.cell.ixfe, A.tt), _.XF = U[_.ixfe], r.cellFormula) {
                            var wt = A.formula;
                            if (wt && wt[0] && wt[0][0] && wt[0][0][0] == "PtgExp") {
                                var mr = wt[0][0][1][0],
                                    Br = wt[0][0][1][1],
                                    $r = Me({
                                        r: mr,
                                        c: Br
                                    });
                                E[$r] ? _.f = "" + Ht(A.formula, s, A.cell, me, B) : _.F = ((r.dense ? (i[mr] || [])[Br] : i[$r]) || {}).F
                            } else _.f = "" + Ht(A.formula, s, A.cell, me, B)
                        }
                        b > 0 && (_.z = H[_.ixfe >> 8 & 63]),
                        Vr(_, r, t.opts.Date1904),
                        j(A.cell, _, r),
                        o = A
                    }
                    break;
                case 7:
                case 519:
                    if (o) o.val = A, _ = On(A, o.cell.ixfe, "s"), _.XF = U[_.ixfe], r.cellFormula && (_.f = "" + Ht(o.formula, s, o.cell, me, B)), b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j(o.cell, _, r), o = null;
                    else throw new Error("String record expects Formula");
                    break;
                case 33:
                case 545:
                    {
                        S.push(A);
                        var gi = Me(A[0].s);
                        if (p = r.dense ? (i[A[0].s.r] || [])[A[0].s.c] : i[gi], r.cellFormula && p) {
                            if (!o || !gi || !p) break;
                            p.f = "" + Ht(A[1], s, A[0], me, B), p.F = Ne(A[0])
                        }
                    }
                    break;
                case 1212:
                    {
                        if (!r.cellFormula) break;
                        if (h) {
                            if (!o) break;
                            E[Me(o.cell)] = A[0], p = r.dense ? (i[o.cell.r] || [])[o.cell.c] : i[Me(o.cell)], (p || {}).f = "" + Ht(A[0], s, u, me, B)
                        }
                    }
                    break;
                case 253:
                    _ = On(c[A.isst].t, A.ixfe, "s"), c[A.isst].h && (_.h = c[A.isst].h), _.XF = U[_.ixfe], b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                        c: A.c,
                        r: A.r
                    }, _, r);
                    break;
                case 513:
                    r.sheetStubs && (_ = {
                        ixfe: A.ixfe,
                        XF: U[A.ixfe],
                        t: "z"
                    }, b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                        c: A.c,
                        r: A.r
                    }, _, r));
                    break;
                case 190:
                    if (r.sheetStubs)
                        for (var na = A.c; na <= A.C; ++na) {
                            var cr = A.ixfe[na - A.c];
                            _ = {
                                ixfe: cr,
                                XF: U[cr],
                                t: "z"
                            }, b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                                c: na,
                                r: A.r
                            }, _, r)
                        }
                    break;
                case 214:
                case 516:
                case 4:
                    _ = On(A.val, A.ixfe, "s"), _.XF = U[_.ixfe], b > 0 && (_.z = H[_.ixfe >> 8 & 63]), Vr(_, r, t.opts.Date1904), j({
                        c: A.c,
                        r: A.r
                    }, _, r);
                    break;
                case 0:
                case 512:
                    Z === 1 && (s = A);
                    break;
                case 252:
                    c = A;
                    break;
                case 1054:
                    if (B.biff == 4) {
                        H[b++] = A[1];
                        for (var Yr = 0; Yr < b + 163 && Ie[Yr] != A[1]; ++Yr);
                        Yr >= 163 && Qr(A[1], b + 163)
                    } else Qr(A[1], A[0]);
                    break;
                case 30:
                    {
                        H[b++] = A;
                        for (var sa = 0; sa < b + 163 && Ie[sa] != A; ++sa);sa >= 163 && Qr(A, b + 163)
                    }
                    break;
                case 229:
                    _e = _e.concat(A);
                    break;
                case 93:
                    oe[A.cmo[0]] = B.lastobj = A;
                    break;
                case 438:
                    B.lastobj.TxO = A;
                    break;
                case 127:
                    B.lastobj.ImData = A;
                    break;
                case 440:
                    for (x = A[0].s.r; x <= A[0].e.r; ++x)
                        for (d = A[0].s.c; d <= A[0].e.c; ++d) p = r.dense ? (i[x] || [])[d] : i[Me({
                            c: d,
                            r: x
                        })], p && (p.l = A[1]);
                    break;
                case 2048:
                    for (x = A[0].s.r; x <= A[0].e.r; ++x)
                        for (d = A[0].s.c; d <= A[0].e.c; ++d) p = r.dense ? (i[x] || [])[d] : i[Me({
                            c: d,
                            r: x
                        })], p && p.l && (p.l.Tooltip = A[1]);
                    break;
                case 28:
                    {
                        if (B.biff <= 5 && B.biff >= 2) break;p = r.dense ? (i[A[0].r] || [])[A[0].c] : i[Me(A[0])];
                        var _i = oe[A[2]];p || (r.dense ? (i[A[0].r] || (i[A[0].r] = []), p = i[A[0].r][A[0].c] = {
                            t: "z"
                        }) : p = i[Me(A[0])] = {
                            t: "z"
                        }, s.e.r = Math.max(s.e.r, A[0].r), s.s.r = Math.min(s.s.r, A[0].r), s.e.c = Math.max(s.e.c, A[0].c), s.s.c = Math.min(s.s.c, A[0].c)),
                        p.c || (p.c = []),
                        m = {
                            a: A[1],
                            t: _i.TxO.t
                        },
                        p.c.push(m)
                    }
                    break;
                case 2173:
                    vx(U[A.ixfe], A.ext);
                    break;
                case 125:
                    {
                        if (!B.cellStyles) break;
                        for (; A.e >= A.s;) ke[A.e--] = {
                            width: A.w / 256,
                            level: A.level || 0,
                            hidden: !!(A.flags & 1)
                        },
                        Ve || (Ve = !0, S0(A.w / 256)),
                        ma(ke[A.e + 1])
                    }
                    break;
                case 520:
                    {
                        var Yt = {};A.level != null && (Se[A.r] = Yt, Yt.level = A.level),
                        A.hidden && (Se[A.r] = Yt, Yt.hidden = !0),
                        A.hpt && (Se[A.r] = Yt, Yt.hpt = A.hpt, Yt.hpx = ci(A.hpt))
                    }
                    break;
                case 38:
                case 39:
                case 40:
                case 41:
                    i["!margins"] || Ia(i["!margins"] = {}), i["!margins"][{
                        38: "left",
                        39: "right",
                        40: "top",
                        41: "bottom"
                    }[ie]] = A;
                    break;
                case 161:
                    i["!margins"] || Ia(i["!margins"] = {}), i["!margins"].header = A.header, i["!margins"].footer = A.footer;
                    break;
                case 574:
                    A.RTL && (T.Views[0].RTL = !0);
                    break;
                case 146:
                    R = A;
                    break;
                case 2198:
                    se = A;
                    break;
                case 140:
                    L = A;
                    break;
                case 442:
                    l ? N.CodeName = A || N.name : T.WBProps.CodeName = A || "ThisWorkbook";
                    break
            }
        } else Q || console.error("Missing Info for XLS Record 0x" + ie.toString(16)), e.l += ne
    }
    return t.SheetNames = vt(n).sort(function(Ur, We) {
        return Number(Ur) - Number(We)
    }).map(function(Ur) {
        return n[Ur].name
    }), r.bookSheets || (t.Sheets = a), !t.SheetNames.length && f["!ref"] ? (t.SheetNames.push("Sheet1"), t.Sheets && (t.Sheets.Sheet1 = f)) : t.Preamble = f, t.Sheets && O.forEach(function(Ur, We) {
        t.Sheets[t.SheetNames[We]]["!autofilter"] = Ur
    }), t.Strings = c, t.SSF = ut(Ie), B.enc && (t.Encryption = B.enc), se && (t.Themes = se), t.Metadata = {}, L !== void 0 && (t.Metadata.Country = L), me.names.length > 0 && (T.Names = me.names), t.Workbook = T, t
}
var Bi = {
    SI: "e0859ff2f94f6810ab9108002b27b3d9",
    DSI: "02d5cdd59c2e1b10939708002b2cf9ae",
    UDI: "05d5cdd59c2e1b10939708002b2cf9ae"
};

function Dw(e, r, t) {
    var a = Ae.find(e, "/!DocumentSummaryInformation");
    if (a && a.size > 0) try {
        var i = Cc(a, Ns, Bi.DSI);
        for (var n in i) r[n] = i[n]
    } catch (l) {
        if (t.WTF) throw l
    }
    var s = Ae.find(e, "/!SummaryInformation");
    if (s && s.size > 0) try {
        var o = Cc(s, Ls, Bi.SI);
        for (var c in o) r[c] == null && (r[c] = o[c])
    } catch (l) {
        if (t.WTF) throw l
    }
    r.HeadingPairs && r.TitlesOfParts && (Vl(r.HeadingPairs, r.TitlesOfParts, r, t), delete r.HeadingPairs, delete r.TitlesOfParts)
}

function Rw(e, r) {
    var t = [],
        a = [],
        i = [],
        n = 0,
        s, o = Qo(Ns, "n"),
        c = Qo(Ls, "n");
    if (e.Props)
        for (s = vt(e.Props), n = 0; n < s.length; ++n)(Object.prototype.hasOwnProperty.call(o, s[n]) ? t : Object.prototype.hasOwnProperty.call(c, s[n]) ? a : i).push([s[n], e.Props[s[n]]]);
    if (e.Custprops)
        for (s = vt(e.Custprops), n = 0; n < s.length; ++n) Object.prototype.hasOwnProperty.call(e.Props || {}, s[n]) || (Object.prototype.hasOwnProperty.call(o, s[n]) ? t : Object.prototype.hasOwnProperty.call(c, s[n]) ? a : i).push([s[n], e.Custprops[s[n]]]);
    var l = [];
    for (n = 0; n < i.length; ++n) jl.indexOf(i[n][0]) > -1 || Ul.indexOf(i[n][0]) > -1 || i[n][1] != null && l.push(i[n]);
    a.length && Ae.utils.cfb_add(r, "/SummaryInformation", Tc(a, Bi.SI, c, Ls)), (t.length || l.length) && Ae.utils.cfb_add(r, "/DocumentSummaryInformation", Tc(t, Bi.DSI, o, Ns, l.length ? l : null, Bi.UDI))
}

function Gf(e, r) {
    r || (r = {}), I0(r), js(), r.codepage && qs(r.codepage);
    var t, a;
    if (e.FullPaths) {
        if (Ae.find(e, "/encryption")) throw new Error("File is password-protected");
        t = Ae.find(e, "!CompObj"), a = Ae.find(e, "/Workbook") || Ae.find(e, "/Book")
    } else {
        switch (r.type) {
            case "base64":
                e = dr(pr(e));
                break;
            case "binary":
                e = dr(e);
                break;
            case "buffer":
                break;
            case "array":
                Array.isArray(e) || (e = Array.prototype.slice.call(e));
                break
        }
        Bt(e, 0), a = {
            content: e
        }
    }
    var i, n;
    if (t && bw(t), r.bookProps && !r.bookSheets) i = {};
    else {
        var s = Ue ? "buffer" : "array";
        if (a && a.content) i = Ow(a.content, r);
        else if ((n = Ae.find(e, "PerfectOffice_MAIN")) && n.content) i = ba.to_workbook(n.content, (r.type = s, r));
        else if ((n = Ae.find(e, "NativeContent_MAIN")) && n.content) i = ba.to_workbook(n.content, (r.type = s, r));
        else throw (n = Ae.find(e, "MN0")) && n.content ? new Error("Unsupported Works 4 for Mac file") : new Error("Cannot find Workbook stream");
        r.bookVBA && e.FullPaths && Ae.find(e, "/_VBA_PROJECT_CUR/VBA/dir") && (i.vbaraw = jx(e))
    }
    var o = {};
    return e.FullPaths && Dw(e, o, r), i.Props = i.Custprops = o, r.bookFiles && (i.cfb = e), i
}

function Pw(e, r) {
    var t = r || {},
        a = Ae.utils.cfb_new({
            root: "R"
        }),
        i = "/Workbook";
    switch (t.bookType || "xls") {
        case "xls":
            t.bookType = "biff8";
        case "xla":
            t.bookType || (t.bookType = "xla");
        case "biff8":
            i = "/Workbook", t.biff = 8;
            break;
        case "biff5":
            i = "/Book", t.biff = 5;
            break;
        default:
            throw new Error("invalid type " + t.bookType + " for XLS CFB")
    }
    return Ae.utils.cfb_add(a, i, zf(e, t)), t.biff == 8 && (e.Props || e.Custprops) && Rw(e, a), t.biff == 8 && e.vbaraw && $x(a, Ae.read(e.vbaraw, {
        type: typeof e.vbaraw == "string" ? "binary" : "buffer"
    })), a
}
var Ki = {
        0: {
            f: nv
        },
        1: {
            f: hv
        },
        2: {
            f: Ov
        },
        3: {
            f: Sv
        },
        4: {
            f: gv
        },
        5: {
            f: bv
        },
        6: {
            f: Lv
        },
        7: {
            f: yv
        },
        8: {
            f: zv
        },
        9: {
            f: Gv
        },
        10: {
            f: Wv
        },
        11: {
            f: Hv
        },
        12: {
            f: mv
        },
        13: {
            f: Rv
        },
        14: {
            f: Cv
        },
        15: {
            f: vv
        },
        16: {
            f: Pf
        },
        17: {
            f: Uv
        },
        18: {
            f: Fv
        },
        19: {
            f: u0
        },
        20: {},
        21: {},
        22: {},
        23: {},
        24: {},
        25: {},
        26: {},
        27: {},
        28: {},
        29: {},
        30: {},
        31: {},
        32: {},
        33: {},
        34: {},
        35: {
            T: 1
        },
        36: {
            T: -1
        },
        37: {
            T: 1
        },
        38: {
            T: -1
        },
        39: {
            f: U2
        },
        40: {},
        42: {},
        43: {
            f: Lm
        },
        44: {
            f: Pm
        },
        45: {
            f: Vm
        },
        46: {
            f: Hm
        },
        47: {
            f: Wm
        },
        48: {},
        49: {
            f: ch
        },
        50: {},
        51: {
            f: Ex
        },
        52: {
            T: 1
        },
        53: {
            T: -1
        },
        54: {
            T: 1
        },
        55: {
            T: -1
        },
        56: {
            T: 1
        },
        57: {
            T: -1
        },
        58: {},
        59: {},
        60: {
            f: nf
        },
        62: {
            f: Nv
        },
        63: {
            f: Mx
        },
        64: {
            f: s2
        },
        65: {},
        66: {},
        67: {},
        68: {},
        69: {},
        70: {},
        128: {},
        129: {
            T: 1
        },
        130: {
            T: -1
        },
        131: {
            T: 1,
            f: jt,
            p: 0
        },
        132: {
            T: -1
        },
        133: {
            T: 1
        },
        134: {
            T: -1
        },
        135: {
            T: 1
        },
        136: {
            T: -1
        },
        137: {
            T: 1,
            f: r2
        },
        138: {
            T: -1
        },
        139: {
            T: 1
        },
        140: {
            T: -1
        },
        141: {
            T: 1
        },
        142: {
            T: -1
        },
        143: {
            T: 1
        },
        144: {
            T: -1
        },
        145: {
            T: 1
        },
        146: {
            T: -1
        },
        147: {
            f: uv
        },
        148: {
            f: cv,
            p: 16
        },
        151: {
            f: Kv
        },
        152: {},
        153: {
            f: N2
        },
        154: {},
        155: {},
        156: {
            f: R2
        },
        157: {},
        158: {},
        159: {
            T: 1,
            f: Zp
        },
        160: {
            T: -1
        },
        161: {
            T: 1,
            f: Wa
        },
        162: {
            T: -1
        },
        163: {
            T: 1
        },
        164: {
            T: -1
        },
        165: {
            T: 1
        },
        166: {
            T: -1
        },
        167: {},
        168: {},
        169: {},
        170: {},
        171: {},
        172: {
            T: 1
        },
        173: {
            T: -1
        },
        174: {},
        175: {},
        176: {
            f: Xv
        },
        177: {
            T: 1
        },
        178: {
            T: -1
        },
        179: {
            T: 1
        },
        180: {
            T: -1
        },
        181: {
            T: 1
        },
        182: {
            T: -1
        },
        183: {
            T: 1
        },
        184: {
            T: -1
        },
        185: {
            T: 1
        },
        186: {
            T: -1
        },
        187: {
            T: 1
        },
        188: {
            T: -1
        },
        189: {
            T: 1
        },
        190: {
            T: -1
        },
        191: {
            T: 1
        },
        192: {
            T: -1
        },
        193: {
            T: 1
        },
        194: {
            T: -1
        },
        195: {
            T: 1
        },
        196: {
            T: -1
        },
        197: {
            T: 1
        },
        198: {
            T: -1
        },
        199: {
            T: 1
        },
        200: {
            T: -1
        },
        201: {
            T: 1
        },
        202: {
            T: -1
        },
        203: {
            T: 1
        },
        204: {
            T: -1
        },
        205: {
            T: 1
        },
        206: {
            T: -1
        },
        207: {
            T: 1
        },
        208: {
            T: -1
        },
        209: {
            T: 1
        },
        210: {
            T: -1
        },
        211: {
            T: 1
        },
        212: {
            T: -1
        },
        213: {
            T: 1
        },
        214: {
            T: -1
        },
        215: {
            T: 1
        },
        216: {
            T: -1
        },
        217: {
            T: 1
        },
        218: {
            T: -1
        },
        219: {
            T: 1
        },
        220: {
            T: -1
        },
        221: {
            T: 1
        },
        222: {
            T: -1
        },
        223: {
            T: 1
        },
        224: {
            T: -1
        },
        225: {
            T: 1
        },
        226: {
            T: -1
        },
        227: {
            T: 1
        },
        228: {
            T: -1
        },
        229: {
            T: 1
        },
        230: {
            T: -1
        },
        231: {
            T: 1
        },
        232: {
            T: -1
        },
        233: {
            T: 1
        },
        234: {
            T: -1
        },
        235: {
            T: 1
        },
        236: {
            T: -1
        },
        237: {
            T: 1
        },
        238: {
            T: -1
        },
        239: {
            T: 1
        },
        240: {
            T: -1
        },
        241: {
            T: 1
        },
        242: {
            T: -1
        },
        243: {
            T: 1
        },
        244: {
            T: -1
        },
        245: {
            T: 1
        },
        246: {
            T: -1
        },
        247: {
            T: 1
        },
        248: {
            T: -1
        },
        249: {
            T: 1
        },
        250: {
            T: -1
        },
        251: {
            T: 1
        },
        252: {
            T: -1
        },
        253: {
            T: 1
        },
        254: {
            T: -1
        },
        255: {
            T: 1
        },
        256: {
            T: -1
        },
        257: {
            T: 1
        },
        258: {
            T: -1
        },
        259: {
            T: 1
        },
        260: {
            T: -1
        },
        261: {
            T: 1
        },
        262: {
            T: -1
        },
        263: {
            T: 1
        },
        264: {
            T: -1
        },
        265: {
            T: 1
        },
        266: {
            T: -1
        },
        267: {
            T: 1
        },
        268: {
            T: -1
        },
        269: {
            T: 1
        },
        270: {
            T: -1
        },
        271: {
            T: 1
        },
        272: {
            T: -1
        },
        273: {
            T: 1
        },
        274: {
            T: -1
        },
        275: {
            T: 1
        },
        276: {
            T: -1
        },
        277: {},
        278: {
            T: 1
        },
        279: {
            T: -1
        },
        280: {
            T: 1
        },
        281: {
            T: -1
        },
        282: {
            T: 1
        },
        283: {
            T: 1
        },
        284: {
            T: -1
        },
        285: {
            T: 1
        },
        286: {
            T: -1
        },
        287: {
            T: 1
        },
        288: {
            T: -1
        },
        289: {
            T: 1
        },
        290: {
            T: -1
        },
        291: {
            T: 1
        },
        292: {
            T: -1
        },
        293: {
            T: 1
        },
        294: {
            T: -1
        },
        295: {
            T: 1
        },
        296: {
            T: -1
        },
        297: {
            T: 1
        },
        298: {
            T: -1
        },
        299: {
            T: 1
        },
        300: {
            T: -1
        },
        301: {
            T: 1
        },
        302: {
            T: -1
        },
        303: {
            T: 1
        },
        304: {
            T: -1
        },
        305: {
            T: 1
        },
        306: {
            T: -1
        },
        307: {
            T: 1
        },
        308: {
            T: -1
        },
        309: {
            T: 1
        },
        310: {
            T: -1
        },
        311: {
            T: 1
        },
        312: {
            T: -1
        },
        313: {
            T: -1
        },
        314: {
            T: 1
        },
        315: {
            T: -1
        },
        316: {
            T: 1
        },
        317: {
            T: -1
        },
        318: {
            T: 1
        },
        319: {
            T: -1
        },
        320: {
            T: 1
        },
        321: {
            T: -1
        },
        322: {
            T: 1
        },
        323: {
            T: -1
        },
        324: {
            T: 1
        },
        325: {
            T: -1
        },
        326: {
            T: 1
        },
        327: {
            T: -1
        },
        328: {
            T: 1
        },
        329: {
            T: -1
        },
        330: {
            T: 1
        },
        331: {
            T: -1
        },
        332: {
            T: 1
        },
        333: {
            T: -1
        },
        334: {
            T: 1
        },
        335: {
            f: wx
        },
        336: {
            T: -1
        },
        337: {
            f: yx,
            T: 1
        },
        338: {
            T: -1
        },
        339: {
            T: 1
        },
        340: {
            T: -1
        },
        341: {
            T: 1
        },
        342: {
            T: -1
        },
        343: {
            T: 1
        },
        344: {
            T: -1
        },
        345: {
            T: 1
        },
        346: {
            T: -1
        },
        347: {
            T: 1
        },
        348: {
            T: -1
        },
        349: {
            T: 1
        },
        350: {
            T: -1
        },
        351: {},
        352: {},
        353: {
            T: 1
        },
        354: {
            T: -1
        },
        355: {
            f: Ps
        },
        357: {},
        358: {},
        359: {},
        360: {
            T: 1
        },
        361: {},
        362: {
            f: af
        },
        363: {},
        364: {},
        366: {},
        367: {},
        368: {},
        369: {},
        370: {},
        371: {},
        372: {
            T: 1
        },
        373: {
            T: -1
        },
        374: {
            T: 1
        },
        375: {
            T: -1
        },
        376: {
            T: 1
        },
        377: {
            T: -1
        },
        378: {
            T: 1
        },
        379: {
            T: -1
        },
        380: {
            T: 1
        },
        381: {
            T: -1
        },
        382: {
            T: 1
        },
        383: {
            T: -1
        },
        384: {
            T: 1
        },
        385: {
            T: -1
        },
        386: {
            T: 1
        },
        387: {
            T: -1
        },
        388: {
            T: 1
        },
        389: {
            T: -1
        },
        390: {
            T: 1
        },
        391: {
            T: -1
        },
        392: {
            T: 1
        },
        393: {
            T: -1
        },
        394: {
            T: 1
        },
        395: {
            T: -1
        },
        396: {},
        397: {},
        398: {},
        399: {},
        400: {},
        401: {
            T: 1
        },
        403: {},
        404: {},
        405: {},
        406: {},
        407: {},
        408: {},
        409: {},
        410: {},
        411: {},
        412: {},
        413: {},
        414: {},
        415: {},
        416: {},
        417: {},
        418: {},
        419: {},
        420: {},
        421: {},
        422: {
            T: 1
        },
        423: {
            T: 1
        },
        424: {
            T: -1
        },
        425: {
            T: -1
        },
        426: {
            f: Jv
        },
        427: {
            f: Zv
        },
        428: {},
        429: {
            T: 1
        },
        430: {
            T: -1
        },
        431: {
            T: 1
        },
        432: {
            T: -1
        },
        433: {
            T: 1
        },
        434: {
            T: -1
        },
        435: {
            T: 1
        },
        436: {
            T: -1
        },
        437: {
            T: 1
        },
        438: {
            T: -1
        },
        439: {
            T: 1
        },
        440: {
            T: -1
        },
        441: {
            T: 1
        },
        442: {
            T: -1
        },
        443: {
            T: 1
        },
        444: {
            T: -1
        },
        445: {
            T: 1
        },
        446: {
            T: -1
        },
        447: {
            T: 1
        },
        448: {
            T: -1
        },
        449: {
            T: 1
        },
        450: {
            T: -1
        },
        451: {
            T: 1
        },
        452: {
            T: -1
        },
        453: {
            T: 1
        },
        454: {
            T: -1
        },
        455: {
            T: 1
        },
        456: {
            T: -1
        },
        457: {
            T: 1
        },
        458: {
            T: -1
        },
        459: {
            T: 1
        },
        460: {
            T: -1
        },
        461: {
            T: 1
        },
        462: {
            T: -1
        },
        463: {
            T: 1
        },
        464: {
            T: -1
        },
        465: {
            T: 1
        },
        466: {
            T: -1
        },
        467: {
            T: 1
        },
        468: {
            T: -1
        },
        469: {
            T: 1
        },
        470: {
            T: -1
        },
        471: {},
        472: {},
        473: {
            T: 1
        },
        474: {
            T: -1
        },
        475: {},
        476: {
            f: e2
        },
        477: {},
        478: {},
        479: {
            T: 1
        },
        480: {
            T: -1
        },
        481: {
            T: 1
        },
        482: {
            T: -1
        },
        483: {
            T: 1
        },
        484: {
            T: -1
        },
        485: {
            f: fv
        },
        486: {
            T: 1
        },
        487: {
            T: -1
        },
        488: {
            T: 1
        },
        489: {
            T: -1
        },
        490: {
            T: 1
        },
        491: {
            T: -1
        },
        492: {
            T: 1
        },
        493: {
            T: -1
        },
        494: {
            f: $v
        },
        495: {
            T: 1
        },
        496: {
            T: -1
        },
        497: {
            T: 1
        },
        498: {
            T: -1
        },
        499: {},
        500: {
            T: 1
        },
        501: {
            T: -1
        },
        502: {
            T: 1
        },
        503: {
            T: -1
        },
        504: {},
        505: {
            T: 1
        },
        506: {
            T: -1
        },
        507: {},
        508: {
            T: 1
        },
        509: {
            T: -1
        },
        510: {
            T: 1
        },
        511: {
            T: -1
        },
        512: {},
        513: {},
        514: {
            T: 1
        },
        515: {
            T: -1
        },
        516: {
            T: 1
        },
        517: {
            T: -1
        },
        518: {
            T: 1
        },
        519: {
            T: -1
        },
        520: {
            T: 1
        },
        521: {
            T: -1
        },
        522: {},
        523: {},
        524: {},
        525: {},
        526: {},
        527: {},
        528: {
            T: 1
        },
        529: {
            T: -1
        },
        530: {
            T: 1
        },
        531: {
            T: -1
        },
        532: {
            T: 1
        },
        533: {
            T: -1
        },
        534: {},
        535: {},
        536: {},
        537: {},
        538: {
            T: 1
        },
        539: {
            T: -1
        },
        540: {
            T: 1
        },
        541: {
            T: -1
        },
        542: {
            T: 1
        },
        548: {},
        549: {},
        550: {
            f: Ps
        },
        551: {},
        552: {},
        553: {},
        554: {
            T: 1
        },
        555: {
            T: -1
        },
        556: {
            T: 1
        },
        557: {
            T: -1
        },
        558: {
            T: 1
        },
        559: {
            T: -1
        },
        560: {
            T: 1
        },
        561: {
            T: -1
        },
        562: {},
        564: {},
        565: {
            T: 1
        },
        566: {
            T: -1
        },
        569: {
            T: 1
        },
        570: {
            T: -1
        },
        572: {},
        573: {
            T: 1
        },
        574: {
            T: -1
        },
        577: {},
        578: {},
        579: {},
        580: {},
        581: {},
        582: {},
        583: {},
        584: {},
        585: {},
        586: {},
        587: {},
        588: {
            T: -1
        },
        589: {},
        590: {
            T: 1
        },
        591: {
            T: -1
        },
        592: {
            T: 1
        },
        593: {
            T: -1
        },
        594: {
            T: 1
        },
        595: {
            T: -1
        },
        596: {},
        597: {
            T: 1
        },
        598: {
            T: -1
        },
        599: {
            T: 1
        },
        600: {
            T: -1
        },
        601: {
            T: 1
        },
        602: {
            T: -1
        },
        603: {
            T: 1
        },
        604: {
            T: -1
        },
        605: {
            T: 1
        },
        606: {
            T: -1
        },
        607: {},
        608: {
            T: 1
        },
        609: {
            T: -1
        },
        610: {},
        611: {
            T: 1
        },
        612: {
            T: -1
        },
        613: {
            T: 1
        },
        614: {
            T: -1
        },
        615: {
            T: 1
        },
        616: {
            T: -1
        },
        617: {
            T: 1
        },
        618: {
            T: -1
        },
        619: {
            T: 1
        },
        620: {
            T: -1
        },
        625: {},
        626: {
            T: 1
        },
        627: {
            T: -1
        },
        628: {
            T: 1
        },
        629: {
            T: -1
        },
        630: {
            T: 1
        },
        631: {
            T: -1
        },
        632: {
            f: Hx
        },
        633: {
            T: 1
        },
        634: {
            T: -1
        },
        635: {
            T: 1,
            f: Vx
        },
        636: {
            T: -1
        },
        637: {
            f: dh
        },
        638: {
            T: 1
        },
        639: {},
        640: {
            T: -1
        },
        641: {
            T: 1
        },
        642: {
            T: -1
        },
        643: {
            T: 1
        },
        644: {},
        645: {
            T: -1
        },
        646: {
            T: 1
        },
        648: {
            T: 1
        },
        649: {},
        650: {
            T: -1
        },
        651: {
            f: C2
        },
        652: {},
        653: {
            T: 1
        },
        654: {
            T: -1
        },
        655: {
            T: 1
        },
        656: {
            T: -1
        },
        657: {
            T: 1
        },
        658: {
            T: -1
        },
        659: {},
        660: {
            T: 1
        },
        661: {},
        662: {
            T: -1
        },
        663: {},
        664: {
            T: 1
        },
        665: {},
        666: {
            T: -1
        },
        667: {},
        668: {},
        669: {},
        671: {
            T: 1
        },
        672: {
            T: -1
        },
        673: {
            T: 1
        },
        674: {
            T: -1
        },
        675: {},
        676: {},
        677: {},
        678: {},
        679: {},
        680: {},
        681: {},
        1024: {},
        1025: {},
        1026: {
            T: 1
        },
        1027: {
            T: -1
        },
        1028: {
            T: 1
        },
        1029: {
            T: -1
        },
        1030: {},
        1031: {
            T: 1
        },
        1032: {
            T: -1
        },
        1033: {
            T: 1
        },
        1034: {
            T: -1
        },
        1035: {},
        1036: {},
        1037: {},
        1038: {
            T: 1
        },
        1039: {
            T: -1
        },
        1040: {},
        1041: {
            T: 1
        },
        1042: {
            T: -1
        },
        1043: {},
        1044: {},
        1045: {},
        1046: {
            T: 1
        },
        1047: {
            T: -1
        },
        1048: {
            T: 1
        },
        1049: {
            T: -1
        },
        1050: {},
        1051: {
            T: 1
        },
        1052: {
            T: 1
        },
        1053: {
            f: o2
        },
        1054: {
            T: 1
        },
        1055: {},
        1056: {
            T: 1
        },
        1057: {
            T: -1
        },
        1058: {
            T: 1
        },
        1059: {
            T: -1
        },
        1061: {},
        1062: {
            T: 1
        },
        1063: {
            T: -1
        },
        1064: {
            T: 1
        },
        1065: {
            T: -1
        },
        1066: {
            T: 1
        },
        1067: {
            T: -1
        },
        1068: {
            T: 1
        },
        1069: {
            T: -1
        },
        1070: {
            T: 1
        },
        1071: {
            T: -1
        },
        1072: {
            T: 1
        },
        1073: {
            T: -1
        },
        1075: {
            T: 1
        },
        1076: {
            T: -1
        },
        1077: {
            T: 1
        },
        1078: {
            T: -1
        },
        1079: {
            T: 1
        },
        1080: {
            T: -1
        },
        1081: {
            T: 1
        },
        1082: {
            T: -1
        },
        1083: {
            T: 1
        },
        1084: {
            T: -1
        },
        1085: {},
        1086: {
            T: 1
        },
        1087: {
            T: -1
        },
        1088: {
            T: 1
        },
        1089: {
            T: -1
        },
        1090: {
            T: 1
        },
        1091: {
            T: -1
        },
        1092: {
            T: 1
        },
        1093: {
            T: -1
        },
        1094: {
            T: 1
        },
        1095: {
            T: -1
        },
        1096: {},
        1097: {
            T: 1
        },
        1098: {},
        1099: {
            T: -1
        },
        1100: {
            T: 1
        },
        1101: {
            T: -1
        },
        1102: {},
        1103: {},
        1104: {},
        1105: {},
        1111: {},
        1112: {},
        1113: {
            T: 1
        },
        1114: {
            T: -1
        },
        1115: {
            T: 1
        },
        1116: {
            T: -1
        },
        1117: {},
        1118: {
            T: 1
        },
        1119: {
            T: -1
        },
        1120: {
            T: 1
        },
        1121: {
            T: -1
        },
        1122: {
            T: 1
        },
        1123: {
            T: -1
        },
        1124: {
            T: 1
        },
        1125: {
            T: -1
        },
        1126: {},
        1128: {
            T: 1
        },
        1129: {
            T: -1
        },
        1130: {},
        1131: {
            T: 1
        },
        1132: {
            T: -1
        },
        1133: {
            T: 1
        },
        1134: {
            T: -1
        },
        1135: {
            T: 1
        },
        1136: {
            T: -1
        },
        1137: {
            T: 1
        },
        1138: {
            T: -1
        },
        1139: {
            T: 1
        },
        1140: {
            T: -1
        },
        1141: {},
        1142: {
            T: 1
        },
        1143: {
            T: -1
        },
        1144: {
            T: 1
        },
        1145: {
            T: -1
        },
        1146: {},
        1147: {
            T: 1
        },
        1148: {
            T: -1
        },
        1149: {
            T: 1
        },
        1150: {
            T: -1
        },
        1152: {
            T: 1
        },
        1153: {
            T: -1
        },
        1154: {
            T: -1
        },
        1155: {
            T: -1
        },
        1156: {
            T: -1
        },
        1157: {
            T: 1
        },
        1158: {
            T: -1
        },
        1159: {
            T: 1
        },
        1160: {
            T: -1
        },
        1161: {
            T: 1
        },
        1162: {
            T: -1
        },
        1163: {
            T: 1
        },
        1164: {
            T: -1
        },
        1165: {
            T: 1
        },
        1166: {
            T: -1
        },
        1167: {
            T: 1
        },
        1168: {
            T: -1
        },
        1169: {
            T: 1
        },
        1170: {
            T: -1
        },
        1171: {},
        1172: {
            T: 1
        },
        1173: {
            T: -1
        },
        1177: {},
        1178: {
            T: 1
        },
        1180: {},
        1181: {},
        1182: {},
        2048: {
            T: 1
        },
        2049: {
            T: -1
        },
        2050: {},
        2051: {
            T: 1
        },
        2052: {
            T: -1
        },
        2053: {},
        2054: {},
        2055: {
            T: 1
        },
        2056: {
            T: -1
        },
        2057: {
            T: 1
        },
        2058: {
            T: -1
        },
        2060: {},
        2067: {},
        2068: {
            T: 1
        },
        2069: {
            T: -1
        },
        2070: {},
        2071: {},
        2072: {
            T: 1
        },
        2073: {
            T: -1
        },
        2075: {},
        2076: {},
        2077: {
            T: 1
        },
        2078: {
            T: -1
        },
        2079: {},
        2080: {
            T: 1
        },
        2081: {
            T: -1
        },
        2082: {},
        2083: {
            T: 1
        },
        2084: {
            T: -1
        },
        2085: {
            T: 1
        },
        2086: {
            T: -1
        },
        2087: {
            T: 1
        },
        2088: {
            T: -1
        },
        2089: {
            T: 1
        },
        2090: {
            T: -1
        },
        2091: {},
        2092: {},
        2093: {
            T: 1
        },
        2094: {
            T: -1
        },
        2095: {},
        2096: {
            T: 1
        },
        2097: {
            T: -1
        },
        2098: {
            T: 1
        },
        2099: {
            T: -1
        },
        2100: {
            T: 1
        },
        2101: {
            T: -1
        },
        2102: {},
        2103: {
            T: 1
        },
        2104: {
            T: -1
        },
        2105: {},
        2106: {
            T: 1
        },
        2107: {
            T: -1
        },
        2108: {},
        2109: {
            T: 1
        },
        2110: {
            T: -1
        },
        2111: {
            T: 1
        },
        2112: {
            T: -1
        },
        2113: {
            T: 1
        },
        2114: {
            T: -1
        },
        2115: {},
        2116: {},
        2117: {},
        2118: {
            T: 1
        },
        2119: {
            T: -1
        },
        2120: {},
        2121: {
            T: 1
        },
        2122: {
            T: -1
        },
        2123: {
            T: 1
        },
        2124: {
            T: -1
        },
        2125: {},
        2126: {
            T: 1
        },
        2127: {
            T: -1
        },
        2128: {},
        2129: {
            T: 1
        },
        2130: {
            T: -1
        },
        2131: {
            T: 1
        },
        2132: {
            T: -1
        },
        2133: {
            T: 1
        },
        2134: {},
        2135: {},
        2136: {},
        2137: {
            T: 1
        },
        2138: {
            T: -1
        },
        2139: {
            T: 1
        },
        2140: {
            T: -1
        },
        2141: {},
        3072: {},
        3073: {},
        4096: {
            T: 1
        },
        4097: {
            T: -1
        },
        5002: {
            T: 1
        },
        5003: {
            T: -1
        },
        5081: {
            T: 1
        },
        5082: {
            T: -1
        },
        5083: {},
        5084: {
            T: 1
        },
        5085: {
            T: -1
        },
        5086: {
            T: 1
        },
        5087: {
            T: -1
        },
        5088: {},
        5089: {},
        5090: {},
        5092: {
            T: 1
        },
        5093: {
            T: -1
        },
        5094: {},
        5095: {
            T: 1
        },
        5096: {
            T: -1
        },
        5097: {},
        5099: {},
        65535: {
            n: ""
        }
    },
    Gs = {
        6: {
            f: ks
        },
        10: {
            f: ua
        },
        12: {
            f: bt
        },
        13: {
            f: bt
        },
        14: {
            f: Ct
        },
        15: {
            f: Ct
        },
        16: {
            f: zt
        },
        17: {
            f: Ct
        },
        18: {
            f: Ct
        },
        19: {
            f: bt
        },
        20: {
            f: Ic
        },
        21: {
            f: Ic
        },
        23: {
            f: af
        },
        24: {
            f: Oc
        },
        25: {
            f: Ct
        },
        26: {},
        27: {},
        28: {
            f: op
        },
        29: {},
        34: {
            f: Ct
        },
        35: {
            f: Mc
        },
        38: {
            f: zt
        },
        39: {
            f: zt
        },
        40: {
            f: zt
        },
        41: {
            f: zt
        },
        42: {
            f: Ct
        },
        43: {
            f: Ct
        },
        47: {
            f: vm
        },
        49: {
            f: R1
        },
        51: {
            f: bt
        },
        60: {},
        61: {
            f: b1
        },
        64: {
            f: Ct
        },
        65: {
            f: D1
        },
        66: {
            f: bt
        },
        77: {},
        80: {},
        81: {},
        82: {},
        85: {
            f: bt
        },
        89: {},
        90: {},
        91: {},
        92: {
            f: _1
        },
        93: {
            f: fp
        },
        94: {},
        95: {
            f: Ct
        },
        96: {},
        97: {},
        99: {
            f: Ct
        },
        125: {
            f: nf
        },
        128: {
            f: Y1
        },
        129: {
            f: w1
        },
        130: {
            f: bt
        },
        131: {
            f: Ct
        },
        132: {
            f: Ct
        },
        133: {
            f: S1
        },
        134: {},
        140: {
            f: _p
        },
        141: {
            f: bt
        },
        144: {},
        146: {
            f: Sp
        },
        151: {},
        152: {},
        153: {},
        154: {},
        155: {},
        156: {
            f: bt
        },
        157: {},
        158: {},
        160: {
            f: Ap
        },
        161: {
            f: Tp
        },
        174: {},
        175: {},
        176: {},
        177: {},
        178: {},
        180: {},
        181: {},
        182: {},
        184: {},
        185: {},
        189: {
            f: X1
        },
        190: {
            f: q1
        },
        193: {
            f: ua
        },
        197: {},
        198: {},
        199: {},
        200: {},
        201: {},
        202: {
            f: Ct
        },
        203: {},
        204: {},
        205: {},
        206: {},
        207: {},
        208: {},
        209: {},
        210: {},
        211: {},
        213: {},
        215: {},
        216: {},
        217: {},
        218: {
            f: bt
        },
        220: {},
        221: {
            f: Ct
        },
        222: {},
        224: {
            f: $1
        },
        225: {
            f: g1
        },
        226: {
            f: ua
        },
        227: {},
        229: {
            f: cp
        },
        233: {},
        235: {},
        236: {},
        237: {},
        239: {},
        240: {},
        241: {},
        242: {},
        244: {},
        245: {},
        246: {},
        247: {},
        248: {},
        249: {},
        251: {},
        252: {
            f: C1
        },
        253: {
            f: N1
        },
        255: {
            f: y1
        },
        256: {},
        259: {},
        290: {},
        311: {},
        312: {},
        315: {},
        317: {
            f: $l
        },
        318: {},
        319: {},
        320: {},
        330: {},
        331: {},
        333: {},
        334: {},
        335: {},
        336: {},
        337: {},
        338: {},
        339: {},
        340: {},
        351: {},
        352: {
            f: Ct
        },
        353: {
            f: ua
        },
        401: {},
        402: {},
        403: {},
        404: {},
        405: {},
        406: {},
        407: {},
        408: {},
        425: {},
        426: {},
        427: {},
        428: {},
        429: {},
        430: {
            f: ep
        },
        431: {
            f: Ct
        },
        432: {},
        433: {},
        434: {},
        437: {},
        438: {
            f: hp
        },
        439: {
            f: Ct
        },
        440: {
            f: pp
        },
        441: {},
        442: {
            f: tn
        },
        443: {},
        444: {
            f: bt
        },
        445: {},
        446: {},
        448: {
            f: ua
        },
        449: {
            f: A1,
            r: 2
        },
        450: {
            f: ua
        },
        512: {
            f: Fc
        },
        513: {
            f: Fp
        },
        515: {
            f: Z1
        },
        516: {
            f: B1
        },
        517: {
            f: bc
        },
        519: {
            f: bp
        },
        520: {
            f: k1
        },
        523: {},
        545: {
            f: Dc
        },
        549: {
            f: kc
        },
        566: {},
        574: {
            f: M1
        },
        638: {
            f: z1
        },
        659: {},
        1048: {},
        1054: {
            f: V1
        },
        1084: {},
        1212: {
            f: ip
        },
        2048: {
            f: xp
        },
        2049: {},
        2050: {},
        2051: {},
        2052: {},
        2053: {},
        2054: {},
        2055: {},
        2056: {},
        2057: {
            f: bn
        },
        2058: {},
        2059: {},
        2060: {},
        2061: {},
        2062: {},
        2063: {},
        2064: {},
        2066: {},
        2067: {},
        2128: {},
        2129: {},
        2130: {},
        2131: {},
        2132: {},
        2133: {},
        2134: {},
        2135: {},
        2136: {},
        2137: {},
        2138: {},
        2146: {},
        2147: {
            r: 12
        },
        2148: {},
        2149: {},
        2150: {},
        2151: {
            f: ua
        },
        2152: {},
        2154: {},
        2155: {},
        2156: {},
        2161: {},
        2162: {},
        2164: {},
        2165: {},
        2166: {},
        2167: {},
        2168: {},
        2169: {},
        2170: {},
        2171: {},
        2172: {
            f: Ep,
            r: 12
        },
        2173: {
            f: _x,
            r: 12
        },
        2174: {},
        2175: {},
        2180: {},
        2181: {},
        2182: {},
        2183: {},
        2184: {},
        2185: {},
        2186: {},
        2187: {},
        2188: {
            f: Ct,
            r: 12
        },
        2189: {},
        2190: {
            r: 12
        },
        2191: {},
        2192: {},
        2194: {},
        2195: {},
        2196: {
            f: ap,
            r: 12
        },
        2197: {},
        2198: {
            f: dx,
            r: 12
        },
        2199: {},
        2200: {},
        2201: {},
        2202: {
            f: np,
            r: 12
        },
        2203: {
            f: ua
        },
        2204: {},
        2205: {},
        2206: {},
        2207: {},
        2211: {
            f: F1
        },
        2212: {},
        2213: {},
        2214: {},
        2215: {},
        4097: {},
        4098: {},
        4099: {},
        4102: {},
        4103: {},
        4105: {},
        4106: {},
        4107: {},
        4108: {},
        4109: {},
        4116: {},
        4117: {},
        4118: {},
        4119: {},
        4120: {},
        4121: {},
        4122: {},
        4123: {},
        4124: {},
        4125: {},
        4126: {},
        4127: {},
        4128: {},
        4129: {},
        4130: {},
        4132: {},
        4133: {},
        4134: {
            f: bt
        },
        4135: {},
        4146: {},
        4147: {},
        4148: {},
        4149: {},
        4154: {},
        4156: {},
        4157: {},
        4158: {},
        4159: {},
        4160: {},
        4161: {},
        4163: {},
        4164: {
            f: yp
        },
        4165: {},
        4166: {},
        4168: {},
        4170: {},
        4171: {},
        4174: {},
        4175: {},
        4176: {},
        4177: {},
        4187: {},
        4188: {
            f: wp
        },
        4189: {},
        4191: {},
        4192: {},
        4193: {},
        4194: {},
        4195: {},
        4196: {},
        4197: {},
        4198: {},
        4199: {},
        4200: {},
        0: {
            f: Fc
        },
        1: {},
        2: {
            f: Rp
        },
        3: {
            f: Op
        },
        4: {
            f: Mp
        },
        5: {
            f: bc
        },
        7: {
            f: Np
        },
        8: {},
        9: {
            f: bn
        },
        11: {},
        22: {
            f: bt
        },
        30: {
            f: H1
        },
        31: {},
        32: {},
        33: {
            f: Dc
        },
        36: {},
        37: {
            f: kc
        },
        50: {
            f: Lp
        },
        62: {},
        52: {},
        67: {},
        68: {
            f: bt
        },
        69: {},
        86: {},
        126: {},
        127: {
            f: Ip
        },
        135: {},
        136: {},
        137: {},
        145: {},
        148: {},
        149: {},
        150: {},
        169: {},
        171: {},
        188: {},
        191: {},
        192: {},
        194: {},
        195: {},
        214: {
            f: Bp
        },
        223: {},
        234: {},
        354: {},
        421: {},
        518: {
            f: ks
        },
        521: {
            f: bn
        },
        536: {
            f: Oc
        },
        547: {
            f: Mc
        },
        561: {},
        579: {},
        1030: {
            f: ks
        },
        1033: {
            f: bn
        },
        1091: {},
        2157: {},
        2163: {},
        2177: {},
        2240: {},
        2241: {},
        2242: {},
        2243: {},
        2244: {},
        2245: {},
        2246: {},
        2247: {},
        2248: {},
        2249: {},
        2250: {},
        2251: {},
        2262: {
            r: 12
        },
        29282: {}
    };

function le(e, r, t, a) {
    var i = r;
    if (!isNaN(i)) {
        var n = a || (t || []).length || 0,
            s = e.next(4);
        s.write_shift(2, i), s.write_shift(2, n), n > 0 && c0(t) && e.push(t)
    }
}

function Nw(e, r, t, a) {
    var i = a || (t || []).length || 0;
    if (i <= 8224) return le(e, r, t, i);
    var n = r;
    if (!isNaN(n)) {
        for (var s = t.parts || [], o = 0, c = 0, l = 0; l + (s[o] || 8224) <= 8224;) l += s[o] || 8224, o++;
        var f = e.next(4);
        for (f.write_shift(2, n), f.write_shift(2, l), e.push(t.slice(c, c + l)), c += l; c < i;) {
            for (f = e.next(4), f.write_shift(2, 60), l = 0; l + (s[o] || 8224) <= 8224;) l += s[o] || 8224, o++;
            f.write_shift(2, l), e.push(t.slice(c, c + l)), c += l
        }
    }
}

function sn(e, r, t) {
    return e || (e = Y(7)), e.write_shift(2, r), e.write_shift(2, t), e.write_shift(2, 0), e.write_shift(1, 0), e
}

function Lw(e, r, t, a) {
    var i = Y(9);
    return sn(i, e, r), Yl(t, a || "b", i), i
}

function Bw(e, r, t) {
    var a = Y(8 + 2 * t.length);
    return sn(a, e, r), a.write_shift(1, t.length), a.write_shift(t.length, t, "sbcs"), a.l < a.length ? a.slice(0, a.l) : a
}

function Uw(e, r, t, a) {
    if (r.v != null) switch (r.t) {
        case "d":
        case "n":
            var i = r.t == "d" ? Ot(ft(r.v)) : r.v;
            i == (i | 0) && i >= 0 && i < 65536 ? le(e, 2, Pp(t, a, i)) : le(e, 3, Dp(t, a, i));
            return;
        case "b":
        case "e":
            le(e, 5, Lw(t, a, r.v, r.t));
            return;
        case "s":
        case "str":
            le(e, 4, Bw(t, a, (r.v || "").slice(0, 255)));
            return
    }
    le(e, 1, sn(null, t, a))
}

function Vw(e, r, t, a) {
    var i = Array.isArray(r),
        n = Xe(r["!ref"] || "A1"),
        s, o = "",
        c = [];
    if (n.e.c > 255 || n.e.r > 16383) {
        if (a.WTF) throw new Error("Range " + (r["!ref"] || "A1") + " exceeds format limit A1:IV16384");
        n.e.c = Math.min(n.e.c, 255), n.e.r = Math.min(n.e.c, 16383), s = Ne(n)
    }
    for (var l = n.s.r; l <= n.e.r; ++l) {
        o = Tt(l);
        for (var f = n.s.c; f <= n.e.c; ++f) {
            l === n.s.r && (c[f] = ht(f)), s = c[f] + o;
            var u = i ? (r[l] || [])[f] : r[s];
            u && Uw(e, u, l, f, a)
        }
    }
}

function Ww(e, r) {
    var t = r || {};
    _t != null && t.dense == null && (t.dense = _t);
    for (var a = sr(), i = 0, n = 0; n < e.SheetNames.length; ++n) e.SheetNames[n] == t.sheet && (i = n);
    if (i == 0 && t.sheet && e.SheetNames[0] != t.sheet) throw new Error("Sheet not found: " + t.sheet);
    return le(a, t.biff == 4 ? 1033 : t.biff == 3 ? 521 : 9, _0(e, 16, t)), Vw(a, e.Sheets[e.SheetNames[i]], i, t, e), le(a, 10), a.end()
}

function Hw(e, r, t) {
    le(e, 49, P1({
        sz: 12,
        color: {
            theme: 1
        },
        name: "Arial",
        family: 2,
        scheme: "minor"
    }, t))
}

function Gw(e, r, t) {
    r && [
        [5, 8],
        [23, 26],
        [41, 44],
        [50, 392]
    ].forEach(function(a) {
        for (var i = a[0]; i <= a[1]; ++i) r[i] != null && le(e, 1054, W1(i, r[i], t))
    })
}

function zw(e, r) {
    var t = Y(19);
    t.write_shift(4, 2151), t.write_shift(4, 0), t.write_shift(4, 0), t.write_shift(2, 3), t.write_shift(1, 1), t.write_shift(4, 0), le(e, 2151, t), t = Y(39), t.write_shift(4, 2152), t.write_shift(4, 0), t.write_shift(4, 0), t.write_shift(2, 3), t.write_shift(1, 0), t.write_shift(4, 0), t.write_shift(2, 1), t.write_shift(4, 4), t.write_shift(2, 0), ef(Xe(r["!ref"] || "A1"), t), t.write_shift(4, 4), le(e, 2152, t)
}

function Xw(e, r) {
    for (var t = 0; t < 16; ++t) le(e, 224, Ac({
        numFmtId: 0,
        style: !0
    }, 0, r));
    r.cellXfs.forEach(function(a) {
        le(e, 224, Ac(a, 0, r))
    })
}

function qw(e, r) {
    for (var t = 0; t < r["!links"].length; ++t) {
        var a = r["!links"][t];
        le(e, 440, mp(a)), a[1].Tooltip && le(e, 2048, gp(a))
    }
    delete r["!links"]
}

function jw(e, r) {
    if (r) {
        var t = 0;
        r.forEach(function(a, i) {
            ++t <= 256 && a && le(e, 125, Cp(rs(i, a), i))
        })
    }
}

function $w(e, r, t, a, i) {
    var n = 16 + wa(i.cellXfs, r, i);
    if (r.v == null && !r.bf) {
        le(e, 513, Pa(t, a, n));
        return
    }
    if (r.bf) le(e, 6, w_(r, t, a, i, n));
    else switch (r.t) {
        case "d":
        case "n":
            var s = r.t == "d" ? Ot(ft(r.v)) : r.v;
            le(e, 515, Q1(t, a, s, n, i));
            break;
        case "b":
        case "e":
            le(e, 517, J1(t, a, r.v, n, i, r.t));
            break;
        case "s":
        case "str":
            if (i.bookSST) {
                var o = k0(i.Strings, r.v, i.revStrings);
                le(e, 253, L1(t, a, o, n, i))
            } else le(e, 516, U1(t, a, (r.v || "").slice(0, 255), n, i));
            break;
        default:
            le(e, 513, Pa(t, a, n))
    }
}

function Yw(e, r, t) {
    var a = sr(),
        i = t.SheetNames[e],
        n = t.Sheets[i] || {},
        s = (t || {}).Workbook || {},
        o = (s.Sheets || [])[e] || {},
        c = Array.isArray(n),
        l = r.biff == 8,
        f, u = "",
        h = [],
        p = Xe(n["!ref"] || "A1"),
        m = l ? 65536 : 16384;
    if (p.e.c > 255 || p.e.r >= m) {
        if (r.WTF) throw new Error("Range " + (n["!ref"] || "A1") + " exceeds format limit A1:IV16384");
        p.e.c = Math.min(p.e.c, 255), p.e.r = Math.min(p.e.c, m - 1)
    }
    le(a, 2057, _0(t, 16, r)), le(a, 13, Ar(1)), le(a, 12, Ar(100)), le(a, 15, Jt(!0)), le(a, 17, Jt(!1)), le(a, 16, Da(.001)), le(a, 95, Jt(!0)), le(a, 42, Jt(!1)), le(a, 43, Jt(!1)), le(a, 130, Ar(1)), le(a, 128, K1([0, 0])), le(a, 131, Jt(!1)), le(a, 132, Jt(!1)), l && jw(a, n["!cols"]), le(a, 512, G1(p, r)), l && (n["!links"] = []);
    for (var d = p.s.r; d <= p.e.r; ++d) {
        u = Tt(d);
        for (var x = p.s.c; x <= p.e.c; ++x) {
            d === p.s.r && (h[x] = ht(x)), f = h[x] + u;
            var E = c ? (n[d] || [])[x] : n[f];
            E && ($w(a, E, d, x, r), l && E.l && n["!links"].push([f, E.l]))
        }
    }
    var S = o.CodeName || o.name || i;
    return l && le(a, 574, O1((s.Views || [])[0])), l && (n["!merges"] || []).length && le(a, 229, lp(n["!merges"])), l && qw(a, n), le(a, 442, Kl(S, r)), l && zw(a, n), le(a, 10), a.end()
}

function Kw(e, r, t) {
    var a = sr(),
        i = (e || {}).Workbook || {},
        n = i.Sheets || [],
        s = i.WBProps || {},
        o = t.biff == 8,
        c = t.biff == 5;
    if (le(a, 2057, _0(e, 5, t)), t.bookType == "xla" && le(a, 135), le(a, 225, o ? Ar(1200) : null), le(a, 193, Jh(2)), c && le(a, 191), c && le(a, 192), le(a, 226), le(a, 92, v1("SheetJS", t)), le(a, 66, Ar(o ? 1200 : 1252)), o && le(a, 353, Ar(0)), o && le(a, 448), le(a, 317, kp(e.SheetNames.length)), o && e.vbaraw && le(a, 211), o && e.vbaraw) {
        var l = s.CodeName || "ThisWorkbook";
        le(a, 442, Kl(l, t))
    }
    le(a, 156, Ar(17)), le(a, 25, Jt(!1)), le(a, 18, Jt(!1)), le(a, 19, Ar(0)), o && le(a, 431, Jt(!1)), o && le(a, 444, Ar(0)), le(a, 61, I1(t)), le(a, 64, Jt(!1)), le(a, 141, Ar(0)), le(a, 34, Jt(A2(e) == "true")), le(a, 14, Jt(!0)), o && le(a, 439, Jt(!1)), le(a, 218, Ar(0)), Hw(a, e, t), Gw(a, e.SSF, t), Xw(a, t), o && le(a, 352, Jt(!1));
    var f = a.end(),
        u = sr();
    o && le(u, 140, vp()), o && t.Strings && Nw(u, 252, T1(t.Strings, t)), le(u, 10);
    var h = u.end(),
        p = sr(),
        m = 0,
        d = 0;
    for (d = 0; d < e.SheetNames.length; ++d) m += (o ? 12 : 11) + (o ? 2 : 1) * e.SheetNames[d].length;
    var x = f.length + m + h.length;
    for (d = 0; d < e.SheetNames.length; ++d) {
        var E = n[d] || {};
        le(p, 133, E1({
            pos: x,
            hs: E.Hidden || 0,
            dt: 0,
            name: e.SheetNames[d]
        }, t)), x += r[d].length
    }
    var S = p.end();
    if (m != S.length) throw new Error("BS8 " + m + " != " + S.length);
    var _ = [];
    return f.length && _.push(f), S.length && _.push(S), h.length && _.push(h), Pt(_)
}

function Jw(e, r) {
    var t = r || {},
        a = [];
    e && !e.SSF && (e.SSF = ut(Ie)), e && e.SSF && (fi(), $n(e.SSF), t.revssf = Kn(e.SSF), t.revssf[e.SSF[65535]] = 0, t.ssf = e.SSF), t.Strings = [], t.Strings.Count = 0, t.Strings.Unique = 0, M0(t), t.cellXfs = [], wa(t.cellXfs, {}, {
        revssf: {
            General: 0
        }
    }), e.Props || (e.Props = {});
    for (var i = 0; i < e.SheetNames.length; ++i) a[a.length] = Yw(i, t, e);
    return a.unshift(Kw(e, a, t)), Pt(a)
}

function zf(e, r) {
    for (var t = 0; t <= e.SheetNames.length; ++t) {
        var a = e.Sheets[e.SheetNames[t]];
        if (!(!a || !a["!ref"])) {
            var i = or(a["!ref"]);
            i.e.c > 255 && typeof console < "u" && console.error && console.error("Worksheet '" + e.SheetNames[t] + "' extends beyond column IV (255).  Data may be lost.")
        }
    }
    var n = r || {};
    switch (n.biff || 2) {
        case 8:
        case 5:
            return Jw(e, r);
        case 4:
        case 3:
        case 2:
            return Ww(e, r)
    }
    throw new Error("invalid type " + n.bookType + " for BIFF")
}

function Gc(e, r) {
    var t = r || {};
    _t != null && t.dense == null && (t.dense = _t);
    var a = t.dense ? [] : {};
    e = e.replace(/<!--.*?-->/g, "");
    var i = e.match(/<table/i);
    if (!i) throw new Error("Invalid HTML: could not find <table>");
    var n = e.match(/<\/table/i),
        s = i.index,
        o = n && n.index || e.length,
        c = Pd(e.slice(s, o), /(:?<tr[^>]*>)/i, "<tr>"),
        l = -1,
        f = 0,
        u = 0,
        h = 0,
        p = {
            s: {
                r: 1e7,
                c: 1e7
            },
            e: {
                r: 0,
                c: 0
            }
        },
        m = [];
    for (s = 0; s < c.length; ++s) {
        var d = c[s].trim(),
            x = d.slice(0, 3).toLowerCase();
        if (x == "<tr") {
            if (++l, t.sheetRows && t.sheetRows <= l) {
                --l;
                break
            }
            f = 0;
            continue
        }
        if (!(x != "<td" && x != "<th")) {
            var E = d.split(/<\/t[dh]>/i);
            for (o = 0; o < E.length; ++o) {
                var S = E[o].trim();
                if (S.match(/<t[dh]/i)) {
                    for (var _ = S, L = 0; _.charAt(0) == "<" && (L = _.indexOf(">")) > -1;) _ = _.slice(L + 1);
                    for (var U = 0; U < m.length; ++U) {
                        var R = m[U];
                        R.s.c == f && R.s.r < l && l <= R.e.r && (f = R.e.c + 1, U = -1)
                    }
                    var T = Oe(S.slice(0, S.indexOf(">")));
                    h = T.colspan ? +T.colspan : 1, ((u = +T.rowspan) > 1 || h > 1) && m.push({
                        s: {
                            r: l,
                            c: f
                        },
                        e: {
                            r: l + (u || 1) - 1,
                            c: f + h - 1
                        }
                    });
                    var N = T.t || T["data-t"] || "";
                    if (!_.length) {
                        f += h;
                        continue
                    }
                    if (_ = _l(_), p.s.r > l && (p.s.r = l), p.e.r < l && (p.e.r = l), p.s.c > f && (p.s.c = f), p.e.c < f && (p.e.c = f), !_.length) {
                        f += h;
                        continue
                    }
                    var P = {
                        t: "s",
                        v: _
                    };
                    t.raw || !_.trim().length || N == "s" || (_ === "TRUE" ? P = {
                        t: "b",
                        v: !0
                    } : _ === "FALSE" ? P = {
                        t: "b",
                        v: !1
                    } : isNaN(Nr(_)) ? isNaN(si(_).getDate()) || (P = {
                        t: "d",
                        v: ft(_)
                    }, t.cellDates || (P = {
                        t: "n",
                        v: Ot(P.v)
                    }), P.z = t.dateNF || Ie[14]) : P = {
                        t: "n",
                        v: Nr(_)
                    }), t.dense ? (a[l] || (a[l] = []), a[l][f] = P) : a[Me({
                        r: l,
                        c: f
                    })] = P, f += h
                }
            }
        }
    }
    return a["!ref"] = Ne(p), m.length && (a["!merges"] = m), a
}

function Zw(e, r, t, a) {
    for (var i = e["!merges"] || [], n = [], s = r.s.c; s <= r.e.c; ++s) {
        for (var o = 0, c = 0, l = 0; l < i.length; ++l)
            if (!(i[l].s.r > t || i[l].s.c > s) && !(i[l].e.r < t || i[l].e.c < s)) {
                if (i[l].s.r < t || i[l].s.c < s) {
                    o = -1;
                    break
                }
                o = i[l].e.r - i[l].s.r + 1, c = i[l].e.c - i[l].s.c + 1;
                break
            }
        if (!(o < 0)) {
            var f = Me({
                    r: t,
                    c: s
                }),
                u = a.dense ? (e[t] || [])[s] : e[f],
                h = u && u.v != null && (u.h || t0(u.w || (ta(u), u.w) || "")) || "",
                p = {};
            o > 1 && (p.rowspan = o), c > 1 && (p.colspan = c), a.editable ? h = '<span contenteditable="true">' + h + "</span>" : u && (p["data-t"] = u && u.t || "z", u.v != null && (p["data-v"] = u.v), u.z != null && (p["data-z"] = u.z), u.l && (u.l.Target || "#").charAt(0) != "#" && (h = '<a href="' + u.l.Target + '">' + h + "</a>")), p.id = (a.id || "sjs") + "-" + f, n.push(ce("td", h, p))
        }
    }
    var m = "<tr>";
    return m + n.join("") + "</tr>"
}
var Qw = '<html><head><meta charset="utf-8"/><title>SheetJS Table Export</title></head><body>',
    eS = "</body></html>";

function tS(e, r) {
    var t = e.match(/<table[\s\S]*?>[\s\S]*?<\/table>/gi);
    if (!t || t.length == 0) throw new Error("Invalid HTML: could not find <table>");
    if (t.length == 1) return va(Gc(t[0], r), r);
    var a = R0();
    return t.forEach(function(i, n) {
        P0(a, Gc(i, r), "Sheet" + (n + 1))
    }), a
}

function rS(e, r, t) {
    var a = [];
    return a.join("") + "<table" + (t && t.id ? ' id="' + t.id + '"' : "") + ">"
}

function Xf(e, r) {
    var t = r || {},
        a = t.header != null ? t.header : Qw,
        i = t.footer != null ? t.footer : eS,
        n = [a],
        s = or(e["!ref"]);
    t.dense = Array.isArray(e), n.push(rS(e, s, t));
    for (var o = s.s.r; o <= s.e.r; ++o) n.push(Zw(e, s, o, t));
    return n.push("</table>" + i), n.join("")
}

function qf(e, r, t) {
    var a = t || {};
    _t != null && (a.dense = _t);
    var i = 0,
        n = 0;
    if (a.origin != null)
        if (typeof a.origin == "number") i = a.origin;
        else {
            var s = typeof a.origin == "string" ? pt(a.origin) : a.origin;
            i = s.r, n = s.c
        }
    var o = r.getElementsByTagName("tr"),
        c = Math.min(a.sheetRows || 1e7, o.length),
        l = {
            s: {
                r: 0,
                c: 0
            },
            e: {
                r: i,
                c: n
            }
        };
    if (e["!ref"]) {
        var f = or(e["!ref"]);
        l.s.r = Math.min(l.s.r, f.s.r), l.s.c = Math.min(l.s.c, f.s.c), l.e.r = Math.max(l.e.r, f.e.r), l.e.c = Math.max(l.e.c, f.e.c), i == -1 && (l.e.r = i = f.e.r + 1)
    }
    var u = [],
        h = 0,
        p = e["!rows"] || (e["!rows"] = []),
        m = 0,
        d = 0,
        x = 0,
        E = 0,
        S = 0,
        _ = 0;
    for (e["!cols"] || (e["!cols"] = []); m < o.length && d < c; ++m) {
        var L = o[m];
        if (zc(L)) {
            if (a.display) continue;
            p[d] = {
                hidden: !0
            }
        }
        var U = L.children;
        for (x = E = 0; x < U.length; ++x) {
            var R = U[x];
            if (!(a.display && zc(R))) {
                var T = R.hasAttribute("data-v") ? R.getAttribute("data-v") : R.hasAttribute("v") ? R.getAttribute("v") : _l(R.innerHTML),
                    N = R.getAttribute("data-z") || R.getAttribute("z");
                for (h = 0; h < u.length; ++h) {
                    var P = u[h];
                    P.s.c == E + n && P.s.r < d + i && d + i <= P.e.r && (E = P.e.c + 1 - n, h = -1)
                }
                _ = +R.getAttribute("colspan") || 1, ((S = +R.getAttribute("rowspan") || 1) > 1 || _ > 1) && u.push({
                    s: {
                        r: d + i,
                        c: E + n
                    },
                    e: {
                        r: d + i + (S || 1) - 1,
                        c: E + n + (_ || 1) - 1
                    }
                });
                var X = {
                        t: "s",
                        v: T
                    },
                    j = R.getAttribute("data-t") || R.getAttribute("t") || "";
                T != null && (T.length == 0 ? X.t = j || "z" : a.raw || T.trim().length == 0 || j == "s" || (T === "TRUE" ? X = {
                    t: "b",
                    v: !0
                } : T === "FALSE" ? X = {
                    t: "b",
                    v: !1
                } : isNaN(Nr(T)) ? isNaN(si(T).getDate()) || (X = {
                    t: "d",
                    v: ft(T)
                }, a.cellDates || (X = {
                    t: "n",
                    v: Ot(X.v)
                }), X.z = a.dateNF || Ie[14]) : X = {
                    t: "n",
                    v: Nr(T)
                })), X.z === void 0 && N != null && (X.z = N);
                var B = "",
                    se = R.getElementsByTagName("A");
                if (se && se.length)
                    for (var _e = 0; _e < se.length && !(se[_e].hasAttribute("href") && (B = se[_e].getAttribute("href"), B.charAt(0) != "#")); ++_e);
                B && B.charAt(0) != "#" && (X.l = {
                    Target: B
                }), a.dense ? (e[d + i] || (e[d + i] = []), e[d + i][E + n] = X) : e[Me({
                    c: E + n,
                    r: d + i
                })] = X, l.e.c < E + n && (l.e.c = E + n), E += _
            }
        }++d
    }
    return u.length && (e["!merges"] = (e["!merges"] || []).concat(u)), l.e.r = Math.max(l.e.r, d - 1 + i), e["!ref"] = Ne(l), d >= c && (e["!fullref"] = Ne((l.e.r = o.length - m + d - 1 + i, l))), e
}

function jf(e, r) {
    var t = r || {},
        a = t.dense ? [] : {};
    return qf(a, e, r)
}

function aS(e, r) {
    return va(jf(e, r), r)
}

function zc(e) {
    var r = "",
        t = iS(e);
    return t && (r = t(e).getPropertyValue("display")), r || (r = e.style && e.style.display), r === "none"
}

function iS(e) {
    return e.ownerDocument.defaultView && typeof e.ownerDocument.defaultView.getComputedStyle == "function" ? e.ownerDocument.defaultView.getComputedStyle : typeof getComputedStyle == "function" ? getComputedStyle : null
}

function nS(e) {
    var r = e.replace(/[\t\r\n]/g, " ").trim().replace(/ +/g, " ").replace(/<text:s\/>/g, " ").replace(/<text:s text:c="(\d+)"\/>/g, function(a, i) {
            return Array(parseInt(i, 10) + 1).join(" ")
        }).replace(/<text:tab[^>]*\/>/g, "	").replace(/<text:line-break\/>/g, `
`),
        t = ze(r.replace(/<[^>]*>/g, ""));
    return [t]
}
var Xc = {
    day: ["d", "dd"],
    month: ["m", "mm"],
    year: ["y", "yy"],
    hours: ["h", "hh"],
    minutes: ["m", "mm"],
    seconds: ["s", "ss"],
    "am-pm": ["A/P", "AM/PM"],
    "day-of-week": ["ddd", "dddd"],
    era: ["e", "ee"],
    quarter: ["\\Qm", 'm\\"th quarter"']
};

function $f(e, r) {
    var t = r || {};
    _t != null && t.dense == null && (t.dense = _t);
    var a = r0(e),
        i = [],
        n, s, o = {
            name: ""
        },
        c = "",
        l = 0,
        f, u, h = {},
        p = [],
        m = t.dense ? [] : {},
        d, x, E = {
            value: ""
        },
        S = "",
        _ = 0,
        L, U = [],
        R = -1,
        T = -1,
        N = {
            s: {
                r: 1e6,
                c: 1e7
            },
            e: {
                r: 0,
                c: 0
            }
        },
        P = 0,
        X = {},
        j = [],
        B = {},
        se = 0,
        _e = 0,
        oe = [],
        ke = 1,
        Se = 1,
        Ve = [],
        me = {
            Names: []
        },
        Te = {},
        Z = ["", ""],
        b = [],
        H = {},
        O = "",
        M = 0,
        J = !1,
        de = !1,
        ie = 0;
    for (zi.lastIndex = 0, a = a.replace(/<!--([\s\S]*?)-->/mg, "").replace(/<!DOCTYPE[^\[]*\[[^\]]*\]>/gm, ""); d = zi.exec(a);) switch (d[3] = d[3].replace(/_.*$/, "")) {
        case "table":
        case "\u5DE5\u4F5C\u8868":
            d[1] === "/" ? (N.e.c >= N.s.c && N.e.r >= N.s.r ? m["!ref"] = Ne(N) : m["!ref"] = "A1:A1", t.sheetRows > 0 && t.sheetRows <= N.e.r && (m["!fullref"] = m["!ref"], N.e.r = t.sheetRows - 1, m["!ref"] = Ne(N)), j.length && (m["!merges"] = j), oe.length && (m["!rows"] = oe), f.name = f.\u540D\ u79F0 || f.name, typeof JSON < "u" && JSON.stringify(f), p.push(f.name), h[f.name] = m, de = !1) : d[0].charAt(d[0].length - 2) !== "/" && (f = Oe(d[0], !1), R = T = -1, N.s.r = N.s.c = 1e7, N.e.r = N.e.c = 0, m = t.dense ? [] : {}, j = [], oe = [], de = !0);
            break;
        case "table-row-group":
            d[1] === "/" ? --P : ++P;
            break;
        case "table-row":
        case "\u884C":
            if (d[1] === "/") {
                R += ke, ke = 1;
                break
            }
            if (u = Oe(d[0], !1), u.\u884C\ u53F7 ? R = u.\u884C\ u53F7 - 1 : R == -1 && (R = 0), ke = +u["number-rows-repeated"] || 1, ke < 10)
                for (ie = 0; ie < ke; ++ie) P > 0 && (oe[R + ie] = {
                    level: P
                });
            T = -1;
            break;
        case "covered-table-cell":
            d[1] !== "/" && ++T, t.sheetStubs && (t.dense ? (m[R] || (m[R] = []), m[R][T] = {
                t: "z"
            }) : m[Me({
                r: R,
                c: T
            })] = {
                t: "z"
            }), S = "", U = [];
            break;
        case "table-cell":
        case "\u6570\u636E":
            if (d[0].charAt(d[0].length - 2) === "/") ++T, E = Oe(d[0], !1), Se = parseInt(E["number-columns-repeated"] || "1", 10), x = {
                t: "z",
                v: null
            }, E.formula && t.cellFormula != !1 && (x.f = Vc(ze(E.formula))), (E.\u6570\ u636E\ u7C7B\ u578B || E["value-type"]) == "string" && (x.t = "s", x.v = ze(E["string-value"] || ""), t.dense ? (m[R] || (m[R] = []), m[R][T] = x) : m[Me({
                r: R,
                c: T
            })] = x), T += Se - 1;
            else if (d[1] !== "/") {
                ++T, S = "", _ = 0, U = [], Se = 1;
                var ne = ke ? R + ke - 1 : R;
                if (T > N.e.c && (N.e.c = T), T < N.s.c && (N.s.c = T), R < N.s.r && (N.s.r = R), ne > N.e.r && (N.e.r = ne), E = Oe(d[0], !1), b = [], H = {}, x = {
                        t: E.\u6570\ u636E\ u7C7B\ u578B || E["value-type"],
                        v: null
                    }, t.cellFormula)
                    if (E.formula && (E.formula = ze(E.formula)), E["number-matrix-columns-spanned"] && E["number-matrix-rows-spanned"] && (se = parseInt(E["number-matrix-rows-spanned"], 10) || 0, _e = parseInt(E["number-matrix-columns-spanned"], 10) || 0, B = {
                            s: {
                                r: R,
                                c: T
                            },
                            e: {
                                r: R + se - 1,
                                c: T + _e - 1
                            }
                        }, x.F = Ne(B), Ve.push([B, x.F])), E.formula) x.f = Vc(E.formula);
                    else
                        for (ie = 0; ie < Ve.length; ++ie) R >= Ve[ie][0].s.r && R <= Ve[ie][0].e.r && T >= Ve[ie][0].s.c && T <= Ve[ie][0].e.c && (x.F = Ve[ie][1]);
                switch ((E["number-columns-spanned"] || E["number-rows-spanned"]) && (se = parseInt(E["number-rows-spanned"], 10) || 0, _e = parseInt(E["number-columns-spanned"], 10) || 0, B = {
                    s: {
                        r: R,
                        c: T
                    },
                    e: {
                        r: R + se - 1,
                        c: T + _e - 1
                    }
                }, j.push(B)), E["number-columns-repeated"] && (Se = parseInt(E["number-columns-repeated"], 10)), x.t) {
                    case "boolean":
                        x.t = "b", x.v = lt(E["boolean-value"]);
                        break;
                    case "float":
                        x.t = "n", x.v = parseFloat(E.value);
                        break;
                    case "percentage":
                        x.t = "n", x.v = parseFloat(E.value);
                        break;
                    case "currency":
                        x.t = "n", x.v = parseFloat(E.value);
                        break;
                    case "date":
                        x.t = "d", x.v = ft(E["date-value"]), t.cellDates || (x.t = "n", x.v = Ot(x.v)), x.z = "m/d/yy";
                        break;
                    case "time":
                        x.t = "n", x.v = Od(E["time-value"]) / 86400, t.cellDates && (x.t = "d", x.v = Jn(x.v)), x.z = "HH:MM:SS";
                        break;
                    case "number":
                        x.t = "n", x.v = parseFloat(E.\u6570\ u636E\ u6570\ u503C);
                        break;
                    default:
                        if (x.t === "string" || x.t === "text" || !x.t) x.t = "s", E["string-value"] != null && (S = ze(E["string-value"]), U = []);
                        else throw new Error("Unsupported value type " + x.t)
                }
            } else {
                if (J = !1, x.t === "s" && (x.v = S || "", U.length && (x.R = U), J = _ == 0), Te.Target && (x.l = Te), b.length > 0 && (x.c = b, b = []), S && t.cellText !== !1 && (x.w = S), J && (x.t = "z", delete x.v), (!J || t.sheetStubs) && !(t.sheetRows && t.sheetRows <= R))
                    for (var Q = 0; Q < ke; ++Q) {
                        if (Se = parseInt(E["number-columns-repeated"] || "1", 10), t.dense)
                            for (m[R + Q] || (m[R + Q] = []), m[R + Q][T] = Q == 0 ? x : ut(x); --Se > 0;) m[R + Q][T + Se] = ut(x);
                        else
                            for (m[Me({
                                    r: R + Q,
                                    c: T
                                })] = x; --Se > 0;) m[Me({
                                r: R + Q,
                                c: T + Se
                            })] = ut(x);
                        N.e.c <= T && (N.e.c = T)
                    }
                Se = parseInt(E["number-columns-repeated"] || "1", 10), T += Se - 1, Se = 0, x = {}, S = "", U = []
            }
            Te = {};
            break;
        case "document":
        case "document-content":
        case "\u7535\u5B50\u8868\u683C\u6587\u6863":
        case "spreadsheet":
        case "\u4E3B\u4F53":
        case "scripts":
        case "styles":
        case "font-face-decls":
        case "master-styles":
            if (d[1] === "/") {
                if ((n = i.pop())[0] !== d[3]) throw "Bad state: " + n
            } else d[0].charAt(d[0].length - 2) !== "/" && i.push([d[3], !0]);
            break;
        case "annotation":
            if (d[1] === "/") {
                if ((n = i.pop())[0] !== d[3]) throw "Bad state: " + n;
                H.t = S, U.length && (H.R = U), H.a = O, b.push(H)
            } else d[0].charAt(d[0].length - 2) !== "/" && i.push([d[3], !1]);
            O = "", M = 0, S = "", _ = 0, U = [];
            break;
        case "creator":
            d[1] === "/" ? O = a.slice(M, d.index) : M = d.index + d[0].length;
            break;
        case "meta":
        case "\u5143\u6570\u636E":
        case "settings":
        case "config-item-set":
        case "config-item-map-indexed":
        case "config-item-map-entry":
        case "config-item-map-named":
        case "shapes":
        case "frame":
        case "text-box":
        case "image":
        case "data-pilot-tables":
        case "list-style":
        case "form":
        case "dde-links":
        case "event-listeners":
        case "chart":
            if (d[1] === "/") {
                if ((n = i.pop())[0] !== d[3]) throw "Bad state: " + n
            } else d[0].charAt(d[0].length - 2) !== "/" && i.push([d[3], !1]);
            S = "", _ = 0, U = [];
            break;
        case "scientific-number":
            break;
        case "currency-symbol":
            break;
        case "currency-style":
            break;
        case "number-style":
        case "percentage-style":
        case "date-style":
        case "time-style":
            if (d[1] === "/") {
                if (X[o.name] = c, (n = i.pop())[0] !== d[3]) throw "Bad state: " + n
            } else d[0].charAt(d[0].length - 2) !== "/" && (c = "", o = Oe(d[0], !1), i.push([d[3], !0]));
            break;
        case "script":
            break;
        case "libraries":
            break;
        case "automatic-styles":
            break;
        case "default-style":
        case "page-layout":
            break;
        case "style":
            break;
        case "map":
            break;
        case "font-face":
            break;
        case "paragraph-properties":
            break;
        case "table-properties":
            break;
        case "table-column-properties":
            break;
        case "table-row-properties":
            break;
        case "table-cell-properties":
            break;
        case "number":
            switch (i[i.length - 1][0]) {
                case "time-style":
                case "date-style":
                    s = Oe(d[0], !1), c += Xc[d[3]][s.style === "long" ? 1 : 0];
                    break
            }
            break;
        case "fraction":
            break;
        case "day":
        case "month":
        case "year":
        case "era":
        case "day-of-week":
        case "week-of-year":
        case "quarter":
        case "hours":
        case "minutes":
        case "seconds":
        case "am-pm":
            switch (i[i.length - 1][0]) {
                case "time-style":
                case "date-style":
                    s = Oe(d[0], !1), c += Xc[d[3]][s.style === "long" ? 1 : 0];
                    break
            }
            break;
        case "boolean-style":
            break;
        case "boolean":
            break;
        case "text-style":
            break;
        case "text":
            if (d[0].slice(-2) === "/>") break;
            if (d[1] === "/") switch (i[i.length - 1][0]) {
                case "number-style":
                case "date-style":
                case "time-style":
                    c += a.slice(l, d.index);
                    break
            } else l = d.index + d[0].length;
            break;
        case "named-range":
            s = Oe(d[0], !1), Z = Fs(s["cell-range-address"]);
            var Pe = {
                Name: s.name,
                Ref: Z[0] + "!" + Z[1]
            };
            de && (Pe.Sheet = p.length), me.Names.push(Pe);
            break;
        case "text-content":
            break;
        case "text-properties":
            break;
        case "embedded-text":
            break;
        case "body":
        case "\u7535\u5B50\u8868\u683C":
            break;
        case "forms":
            break;
        case "table-column":
            break;
        case "table-header-rows":
            break;
        case "table-rows":
            break;
        case "table-column-group":
            break;
        case "table-header-columns":
            break;
        case "table-columns":
            break;
        case "null-date":
            break;
        case "graphic-properties":
            break;
        case "calculation-settings":
            break;
        case "named-expressions":
            break;
        case "label-range":
            break;
        case "label-ranges":
            break;
        case "named-expression":
            break;
        case "sort":
            break;
        case "sort-by":
            break;
        case "sort-groups":
            break;
        case "tab":
            break;
        case "line-break":
            break;
        case "span":
            break;
        case "p":
        case "\u6587\u672C\u4E32":
            if (["master-styles"].indexOf(i[i.length - 1][0]) > -1) break;
            if (d[1] === "/" && (!E || !E["string-value"])) {
                var A = nS(a.slice(_, d.index), L);
                S = (S.length > 0 ? S + `
` : "") + A[0]
            } else L = Oe(d[0], !1), _ = d.index + d[0].length;
            break;
        case "s":
            break;
        case "database-range":
            if (d[1] === "/") break;
            try {
                Z = Fs(Oe(d[0])["target-range-address"]), h[Z[0]]["!autofilter"] = {
                    ref: Z[1]
                }
            } catch (He) {}
            break;
        case "date":
            break;
        case "object":
            break;
        case "title":
        case "\u6807\u9898":
            break;
        case "desc":
            break;
        case "binary-data":
            break;
        case "table-source":
            break;
        case "scenario":
            break;
        case "iteration":
            break;
        case "content-validations":
            break;
        case "content-validation":
            break;
        case "help-message":
            break;
        case "error-message":
            break;
        case "database-ranges":
            break;
        case "filter":
            break;
        case "filter-and":
            break;
        case "filter-or":
            break;
        case "filter-condition":
            break;
        case "list-level-style-bullet":
            break;
        case "list-level-style-number":
            break;
        case "list-level-properties":
            break;
        case "sender-firstname":
        case "sender-lastname":
        case "sender-initials":
        case "sender-title":
        case "sender-position":
        case "sender-email":
        case "sender-phone-private":
        case "sender-fax":
        case "sender-company":
        case "sender-phone-work":
        case "sender-street":
        case "sender-city":
        case "sender-postal-code":
        case "sender-country":
        case "sender-state-or-province":
        case "author-name":
        case "author-initials":
        case "chapter":
        case "file-name":
        case "template-name":
        case "sheet-name":
            break;
        case "event-listener":
            break;
        case "initial-creator":
        case "creation-date":
        case "print-date":
        case "generator":
        case "document-statistic":
        case "user-defined":
        case "editing-duration":
        case "editing-cycles":
            break;
        case "config-item":
            break;
        case "page-number":
            break;
        case "page-count":
            break;
        case "time":
            break;
        case "cell-range-source":
            break;
        case "detective":
            break;
        case "operation":
            break;
        case "highlighted-range":
            break;
        case "data-pilot-table":
        case "source-cell-range":
        case "source-service":
        case "data-pilot-field":
        case "data-pilot-level":
        case "data-pilot-subtotals":
        case "data-pilot-subtotal":
        case "data-pilot-members":
        case "data-pilot-member":
        case "data-pilot-display-info":
        case "data-pilot-sort-info":
        case "data-pilot-layout-info":
        case "data-pilot-field-reference":
        case "data-pilot-groups":
        case "data-pilot-group":
        case "data-pilot-group-member":
            break;
        case "rect":
            break;
        case "dde-connection-decls":
        case "dde-connection-decl":
        case "dde-link":
        case "dde-source":
            break;
        case "properties":
            break;
        case "property":
            break;
        case "a":
            if (d[1] !== "/") {
                if (Te = Oe(d[0], !1), !Te.href) break;
                Te.Target = ze(Te.href), delete Te.href, Te.Target.charAt(0) == "#" && Te.Target.indexOf(".") > -1 ? (Z = Fs(Te.Target.slice(1)), Te.Target = "#" + Z[0] + "!" + Z[1]) : Te.Target.match(/^\.\.[\\\/]/) && (Te.Target = Te.Target.slice(3))
            }
            break;
        case "table-protection":
            break;
        case "data-pilot-grand-total":
            break;
        case "office-document-common-attrs":
            break;
        default:
            switch (d[2]) {
                case "dc:":
                case "calcext:":
                case "loext:":
                case "ooo:":
                case "chartooo:":
                case "draw:":
                case "style:":
                case "chart:":
                case "form:":
                case "uof:":
                case "\u8868:":
                case "\u5B57:":
                    break;
                default:
                    if (t.WTF) throw new Error(d)
            }
    }
    var Ke = {
        Sheets: h,
        SheetNames: p,
        Workbook: me
    };
    return t.bookSheets && delete Ke.Sheets, Ke
}

function qc(e, r) {
    r = r || {}, Fr(e, "META-INF/manifest.xml") && Oh(At(e, "META-INF/manifest.xml"), r);
    var t = hr(e, "content.xml");
    if (!t) throw new Error("Missing content.xml in ODS / UOF file");
    var a = $f(at(t), r);
    return Fr(e, "meta.xml") && (a.Props = Ll(At(e, "meta.xml"))), a
}

function jc(e, r) {
    return $f(e, r)
}
var sS = (function() {
        var e = ["<office:master-styles>", '<style:master-page style:name="mp1" style:page-layout-name="mp1">', "<style:header/>", '<style:header-left style:display="false"/>', "<style:footer/>", '<style:footer-left style:display="false"/>', "</style:master-page>", "</office:master-styles>"].join(""),
            r = "<office:document-styles " + Gi({
                "xmlns:office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
                "xmlns:table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
                "xmlns:style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
                "xmlns:text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
                "xmlns:draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
                "xmlns:fo": "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0",
                "xmlns:xlink": "http://www.w3.org/1999/xlink",
                "xmlns:dc": "http://purl.org/dc/elements/1.1/",
                "xmlns:number": "urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0",
                "xmlns:svg": "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0",
                "xmlns:of": "urn:oasis:names:tc:opendocument:xmlns:of:1.2",
                "office:version": "1.2"
            }) + ">" + e + "</office:document-styles>";
        return function() {
            return yt + r
        }
    })(),
    $c = (function() {
        var e = function(n) {
                return tt(n).replace(/  +/g, function(s) {
                    return '<text:s text:c="' + s.length + '"/>'
                }).replace(/\t/g, "<text:tab/>").replace(/\n/g, "</text:p><text:p>").replace(/^ /, "<text:s/>").replace(/ $/, "<text:s/>")
            },
            r = `          <table:table-cell />
`,
            t = `          <table:covered-table-cell/>
`,
            a = function(n, s, o) {
                var c = [];
                c.push('      <table:table table:name="' + tt(s.SheetNames[o]) + `" table:style-name="ta1">
`);
                var l = 0,
                    f = 0,
                    u = or(n["!ref"] || "A1"),
                    h = n["!merges"] || [],
                    p = 0,
                    m = Array.isArray(n);
                if (n["!cols"])
                    for (f = 0; f <= u.e.c; ++f) c.push("        <table:table-column" + (n["!cols"][f] ? ' table:style-name="co' + n["!cols"][f].ods + '"' : "") + `></table:table-column>
`);
                var d = "",
                    x = n["!rows"] || [];
                for (l = 0; l < u.s.r; ++l) d = x[l] ? ' table:style-name="ro' + x[l].ods + '"' : "", c.push("        <table:table-row" + d + `></table:table-row>
`);
                for (; l <= u.e.r; ++l) {
                    for (d = x[l] ? ' table:style-name="ro' + x[l].ods + '"' : "", c.push("        <table:table-row" + d + `>
`), f = 0; f < u.s.c; ++f) c.push(r);
                    for (; f <= u.e.c; ++f) {
                        var E = !1,
                            S = {},
                            _ = "";
                        for (p = 0; p != h.length; ++p)
                            if (!(h[p].s.c > f) && !(h[p].s.r > l) && !(h[p].e.c < f) && !(h[p].e.r < l)) {
                                (h[p].s.c != f || h[p].s.r != l) && (E = !0), S["table:number-columns-spanned"] = h[p].e.c - h[p].s.c + 1, S["table:number-rows-spanned"] = h[p].e.r - h[p].s.r + 1;
                                break
                            }
                        if (E) {
                            c.push(t);
                            continue
                        }
                        var L = Me({
                                r: l,
                                c: f
                            }),
                            U = m ? (n[l] || [])[f] : n[L];
                        if (U && U.f && (S["table:formula"] = tt(k_(U.f)), U.F && U.F.slice(0, L.length) == L)) {
                            var R = or(U.F);
                            S["table:number-matrix-columns-spanned"] = R.e.c - R.s.c + 1, S["table:number-matrix-rows-spanned"] = R.e.r - R.s.r + 1
                        }
                        if (!U) {
                            c.push(r);
                            continue
                        }
                        switch (U.t) {
                            case "b":
                                _ = U.v ? "TRUE" : "FALSE", S["office:value-type"] = "boolean", S["office:boolean-value"] = U.v ? "true" : "false";
                                break;
                            case "n":
                                _ = U.w || String(U.v || 0), S["office:value-type"] = "float", S["office:value"] = U.v || 0;
                                break;
                            case "s":
                            case "str":
                                _ = U.v == null ? "" : U.v, S["office:value-type"] = "string";
                                break;
                            case "d":
                                _ = U.w || ft(U.v).toISOString(), S["office:value-type"] = "date", S["office:date-value"] = ft(U.v).toISOString(), S["table:style-name"] = "ce1";
                                break;
                            default:
                                c.push(r);
                                continue
                        }
                        var T = e(_);
                        if (U.l && U.l.Target) {
                            var N = U.l.Target;
                            N = N.charAt(0) == "#" ? "#" + F_(N.slice(1)) : N, N.charAt(0) != "#" && !N.match(/^\w+:/) && (N = "../" + N), T = ce("text:a", T, {
                                "xlink:href": N.replace(/&/g, "&amp;")
                            })
                        }
                        c.push("          " + ce("table:table-cell", ce("text:p", T, {}), S) + `
`)
                    }
                    c.push(`        </table:table-row>
`)
                }
                return c.push(`      </table:table>
`), c.join("")
            },
            i = function(n, s) {
                n.push(` <office:automatic-styles>
`), n.push(`  <number:date-style style:name="N37" number:automatic-order="true">
`), n.push(`   <number:month number:style="long"/>
`), n.push(`   <number:text>/</number:text>
`), n.push(`   <number:day number:style="long"/>
`), n.push(`   <number:text>/</number:text>
`), n.push(`   <number:year/>
`), n.push(`  </number:date-style>
`);
                var o = 0;
                s.SheetNames.map(function(l) {
                    return s.Sheets[l]
                }).forEach(function(l) {
                    if (l && l["!cols"]) {
                        for (var f = 0; f < l["!cols"].length; ++f)
                            if (l["!cols"][f]) {
                                var u = l["!cols"][f];
                                if (u.width == null && u.wpx == null && u.wch == null) continue;
                                ma(u), u.ods = o;
                                var h = l["!cols"][f].wpx + "px";
                                n.push('  <style:style style:name="co' + o + `" style:family="table-column">
`), n.push('   <style:table-column-properties fo:break-before="auto" style:column-width="' + h + `"/>
`), n.push(`  </style:style>
`), ++o
                            }
                    }
                });
                var c = 0;
                s.SheetNames.map(function(l) {
                    return s.Sheets[l]
                }).forEach(function(l) {
                    if (l && l["!rows"]) {
                        for (var f = 0; f < l["!rows"].length; ++f)
                            if (l["!rows"][f]) {
                                l["!rows"][f].ods = c;
                                var u = l["!rows"][f].hpx + "px";
                                n.push('  <style:style style:name="ro' + c + `" style:family="table-row">
`), n.push('   <style:table-row-properties fo:break-before="auto" style:row-height="' + u + `"/>
`), n.push(`  </style:style>
`), ++c
                            }
                    }
                }), n.push(`  <style:style style:name="ta1" style:family="table" style:master-page-name="mp1">
`), n.push(`   <style:table-properties table:display="true" style:writing-mode="lr-tb"/>
`), n.push(`  </style:style>
`), n.push(`  <style:style style:name="ce1" style:family="table-cell" style:parent-style-name="Default" style:data-style-name="N37"/>
`), n.push(` </office:automatic-styles>
`)
            };
        return function(s, o) {
            var c = [yt],
                l = Gi({
                    "xmlns:office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
                    "xmlns:table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
                    "xmlns:style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
                    "xmlns:text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
                    "xmlns:draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
                    "xmlns:fo": "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0",
                    "xmlns:xlink": "http://www.w3.org/1999/xlink",
                    "xmlns:dc": "http://purl.org/dc/elements/1.1/",
                    "xmlns:meta": "urn:oasis:names:tc:opendocument:xmlns:meta:1.0",
                    "xmlns:number": "urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0",
                    "xmlns:presentation": "urn:oasis:names:tc:opendocument:xmlns:presentation:1.0",
                    "xmlns:svg": "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0",
                    "xmlns:chart": "urn:oasis:names:tc:opendocument:xmlns:chart:1.0",
                    "xmlns:dr3d": "urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0",
                    "xmlns:math": "http://www.w3.org/1998/Math/MathML",
                    "xmlns:form": "urn:oasis:names:tc:opendocument:xmlns:form:1.0",
                    "xmlns:script": "urn:oasis:names:tc:opendocument:xmlns:script:1.0",
                    "xmlns:ooo": "http://openoffice.org/2004/office",
                    "xmlns:ooow": "http://openoffice.org/2004/writer",
                    "xmlns:oooc": "http://openoffice.org/2004/calc",
                    "xmlns:dom": "http://www.w3.org/2001/xml-events",
                    "xmlns:xforms": "http://www.w3.org/2002/xforms",
                    "xmlns:xsd": "http://www.w3.org/2001/XMLSchema",
                    "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
                    "xmlns:sheet": "urn:oasis:names:tc:opendocument:sh33tjs:1.0",
                    "xmlns:rpt": "http://openoffice.org/2005/report",
                    "xmlns:of": "urn:oasis:names:tc:opendocument:xmlns:of:1.2",
                    "xmlns:xhtml": "http://www.w3.org/1999/xhtml",
                    "xmlns:grddl": "http://www.w3.org/2003/g/data-view#",
                    "xmlns:tableooo": "http://openoffice.org/2009/table",
                    "xmlns:drawooo": "http://openoffice.org/2010/draw",
                    "xmlns:calcext": "urn:org:documentfoundation:names:experimental:calc:xmlns:calcext:1.0",
                    "xmlns:loext": "urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0",
                    "xmlns:field": "urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0",
                    "xmlns:formx": "urn:openoffice:names:experimental:ooxml-odf-interop:xmlns:form:1.0",
                    "xmlns:css3t": "http://www.w3.org/TR/css3-text/",
                    "office:version": "1.2"
                }),
                f = Gi({
                    "xmlns:config": "urn:oasis:names:tc:opendocument:xmlns:config:1.0",
                    "office:mimetype": "application/vnd.oasis.opendocument.spreadsheet"
                });
            o.bookType == "fods" ? (c.push("<office:document" + l + f + `>
`), c.push(Nl().replace(/office:document-meta/g, "office:meta"))) : c.push("<office:document-content" + l + `>
`), i(c, s), c.push(`  <office:body>
`), c.push(`    <office:spreadsheet>
`);
            for (var u = 0; u != s.SheetNames.length; ++u) c.push(a(s.Sheets[s.SheetNames[u]], s, u, o));
            return c.push(`    </office:spreadsheet>
`), c.push(`  </office:body>
`), o.bookType == "fods" ? c.push("</office:document>") : c.push("</office:document-content>"), c.join("")
        }
    })();

function Yf(e, r) {
    if (r.bookType == "fods") return $c(e, r);
    var t = Zs(),
        a = "",
        i = [],
        n = [];
    return a = "mimetype", Le(t, a, "application/vnd.oasis.opendocument.spreadsheet"), a = "content.xml", Le(t, a, $c(e, r)), i.push([a, "text/xml"]), n.push([a, "ContentFile"]), a = "styles.xml", Le(t, a, sS(e, r)), i.push([a, "text/xml"]), n.push([a, "StylesFile"]), a = "meta.xml", Le(t, a, yt + Nl()), i.push([a, "text/xml"]), n.push([a, "MetadataFile"]), a = "manifest.rdf", Le(t, a, Ph(n)), i.push([a, "application/rdf+xml"]), a = "META-INF/manifest.xml", Le(t, a, Dh(i)), t
}

function Na(e) {
    return new DataView(e.buffer, e.byteOffset, e.byteLength)
}

function zs(e) {
    return typeof TextDecoder < "u" ? new TextDecoder().decode(e) : at(_a(e))
}

function oS(e) {
    return typeof TextEncoder < "u" ? new TextEncoder().encode(e) : dr(Gr(e))
}

function cS(e, r) {
    e: for (var t = 0; t <= e.length - r.length; ++t) {
        for (var a = 0; a < r.length; ++a)
            if (e[t + a] != r[a]) continue e;
        return !0
    }
    return !1
}

function ga(e) {
    var r = e.reduce(function(i, n) {
            return i + n.length
        }, 0),
        t = new Uint8Array(r),
        a = 0;
    return e.forEach(function(i) {
        t.set(i, a), a += i.length
    }), t
}

function Yc(e) {
    return e -= e >> 1 & 1431655765, e = (e & 858993459) + (e >> 2 & 858993459), (e + (e >> 4) & 252645135) * 16843009 >>> 24
}

function lS(e, r) {
    for (var t = (e[r + 15] & 127) << 7 | e[r + 14] >> 1, a = e[r + 14] & 1, i = r + 13; i >= r; --i) a = a * 256 + e[i];
    return (e[r + 15] & 128 ? -a : a) * Math.pow(10, t - 6176)
}

function fS(e, r, t) {
    var a = Math.floor(t == 0 ? 0 : Math.LOG10E * Math.log(Math.abs(t))) + 6176 - 20,
        i = t / Math.pow(10, a - 6176);
    e[r + 15] |= a >> 7, e[r + 14] |= (a & 127) << 1;
    for (var n = 0; i >= 1; ++n, i /= 256) e[r + n] = i & 255;
    e[r + 15] |= t >= 0 ? 0 : 128
}

function Ji(e, r) {
    var t = r ? r[0] : 0,
        a = e[t] & 127;
    e: if (e[t++] >= 128 && (a |= (e[t] & 127) << 7, e[t++] < 128 || (a |= (e[t] & 127) << 14, e[t++] < 128) || (a |= (e[t] & 127) << 21, e[t++] < 128) || (a += (e[t] & 127) * Math.pow(2, 28), ++t, e[t++] < 128) || (a += (e[t] & 127) * Math.pow(2, 35), ++t, e[t++] < 128) || (a += (e[t] & 127) * Math.pow(2, 42), ++t, e[t++] < 128))) break e;
    return r && (r[0] = t), a
}

function Qe(e) {
    var r = new Uint8Array(7);
    r[0] = e & 127;
    var t = 1;
    e: if (e > 127) {
        if (r[t - 1] |= 128, r[t] = e >> 7 & 127, ++t, e <= 16383 || (r[t - 1] |= 128, r[t] = e >> 14 & 127, ++t, e <= 2097151) || (r[t - 1] |= 128, r[t] = e >> 21 & 127, ++t, e <= 268435455) || (r[t - 1] |= 128, r[t] = e / 256 >>> 21 & 127, ++t, e <= 34359738367) || (r[t - 1] |= 128, r[t] = e / 65536 >>> 21 & 127, ++t, e <= 4398046511103)) break e;
        r[t - 1] |= 128, r[t] = e / 16777216 >>> 21 & 127, ++t
    }
    return r.slice(0, t)
}

function gt(e) {
    var r = 0,
        t = e[r] & 127;
    e: if (e[r++] >= 128) {
        if (t |= (e[r] & 127) << 7, e[r++] < 128 || (t |= (e[r] & 127) << 14, e[r++] < 128) || (t |= (e[r] & 127) << 21, e[r++] < 128)) break e;
        t |= (e[r] & 127) << 28
    }
    return t
}

function $e(e) {
    for (var r = [], t = [0]; t[0] < e.length;) {
        var a = t[0],
            i = Ji(e, t),
            n = i & 7;
        i = Math.floor(i / 8);
        var s = 0,
            o;
        if (i == 0) break;
        switch (n) {
            case 0:
                {
                    for (var c = t[0]; e[t[0]++] >= 128;);o = e.slice(c, t[0])
                }
                break;
            case 5:
                s = 4, o = e.slice(t[0], t[0] + s), t[0] += s;
                break;
            case 1:
                s = 8, o = e.slice(t[0], t[0] + s), t[0] += s;
                break;
            case 2:
                s = Ji(e, t), o = e.slice(t[0], t[0] + s), t[0] += s;
                break;
            default:
                throw new Error("PB Type ".concat(n, " for Field ").concat(i, " at offset ").concat(a))
        }
        var l = {
            data: o,
            type: n
        };
        r[i] == null ? r[i] = [l] : r[i].push(l)
    }
    return r
}

function Lt(e) {
    var r = [];
    return e.forEach(function(t, a) {
        t.forEach(function(i) {
            i.data && (r.push(Qe(a * 8 + i.type)), i.type == 2 && r.push(Qe(i.data.length)), r.push(i.data))
        })
    }), ga(r)
}

function b0(e, r) {
    return e ? .map(function(t) {
        return r(t.data)
    }) || []
}

function yr(e) {
    for (var r, t = [], a = [0]; a[0] < e.length;) {
        var i = Ji(e, a),
            n = $e(e.slice(a[0], a[0] + i));
        a[0] += i;
        var s = {
            id: gt(n[1][0].data),
            messages: []
        };
        n[2].forEach(function(o) {
            var c = $e(o.data),
                l = gt(c[3][0].data);
            s.messages.push({
                meta: c,
                data: e.slice(a[0], a[0] + l)
            }), a[0] += l
        }), (r = n[3]) != null && r[0] && (s.merge = gt(n[3][0].data) >>> 0 > 0), t.push(s)
    }
    return t
}

function Ka(e) {
    var r = [];
    return e.forEach(function(t) {
        var a = [];
        a[1] = [{
            data: Qe(t.id),
            type: 0
        }], a[2] = [], t.merge != null && (a[3] = [{
            data: Qe(+!!t.merge),
            type: 0
        }]);
        var i = [];
        t.messages.forEach(function(s) {
            i.push(s.data), s.meta[3] = [{
                type: 0,
                data: Qe(s.data.length)
            }], a[2].push({
                data: Lt(s.meta),
                type: 2
            })
        });
        var n = Lt(a);
        r.push(Qe(n.length)), r.push(n), i.forEach(function(s) {
            return r.push(s)
        })
    }), ga(r)
}

function uS(e, r) {
    if (e != 0) throw new Error("Unexpected Snappy chunk type ".concat(e));
    for (var t = [0], a = Ji(r, t), i = []; t[0] < r.length;) {
        var n = r[t[0]] & 3;
        if (n == 0) {
            var s = r[t[0]++] >> 2;
            if (s < 60) ++s;
            else {
                var o = s - 59;
                s = r[t[0]], o > 1 && (s |= r[t[0] + 1] << 8), o > 2 && (s |= r[t[0] + 2] << 16), o > 3 && (s |= r[t[0] + 3] << 24), s >>>= 0, s++, t[0] += o
            }
            i.push(r.slice(t[0], t[0] + s)), t[0] += s;
            continue
        } else {
            var c = 0,
                l = 0;
            if (n == 1 ? (l = (r[t[0]] >> 2 & 7) + 4, c = (r[t[0]++] & 224) << 3, c |= r[t[0]++]) : (l = (r[t[0]++] >> 2) + 1, n == 2 ? (c = r[t[0]] | r[t[0] + 1] << 8, t[0] += 2) : (c = (r[t[0]] | r[t[0] + 1] << 8 | r[t[0] + 2] << 16 | r[t[0] + 3] << 24) >>> 0, t[0] += 4)), i = [ga(i)], c == 0) throw new Error("Invalid offset 0");
            if (c > i[0].length) throw new Error("Invalid offset beyond length");
            if (l >= c)
                for (i.push(i[0].slice(-c)), l -= c; l >= i[i.length - 1].length;) i.push(i[i.length - 1]), l -= i[i.length - 1].length;
            i.push(i[0].slice(-c, -c + l))
        }
    }
    var f = ga(i);
    if (f.length != a) throw new Error("Unexpected length: ".concat(f.length, " != ").concat(a));
    return f
}

function kr(e) {
    for (var r = [], t = 0; t < e.length;) {
        var a = e[t++],
            i = e[t] | e[t + 1] << 8 | e[t + 2] << 16;
        t += 3, r.push(uS(a, e.slice(t, t + i))), t += i
    }
    if (t !== e.length) throw new Error("data is not a valid framed stream!");
    return ga(r)
}

function Ja(e) {
    for (var r = [], t = 0; t < e.length;) {
        var a = Math.min(e.length - t, 268435455),
            i = new Uint8Array(4);
        r.push(i);
        var n = Qe(a),
            s = n.length;
        r.push(n), a <= 60 ? (s++, r.push(new Uint8Array([a - 1 << 2]))) : a <= 256 ? (s += 2, r.push(new Uint8Array([240, a - 1 & 255]))) : a <= 65536 ? (s += 3, r.push(new Uint8Array([244, a - 1 & 255, a - 1 >> 8 & 255]))) : a <= 16777216 ? (s += 4, r.push(new Uint8Array([248, a - 1 & 255, a - 1 >> 8 & 255, a - 1 >> 16 & 255]))) : a <= 4294967296 && (s += 5, r.push(new Uint8Array([252, a - 1 & 255, a - 1 >> 8 & 255, a - 1 >> 16 & 255, a - 1 >>> 24 & 255]))), r.push(e.slice(t, t + a)), s += a, i[0] = 0, i[1] = s & 255, i[2] = s >> 8 & 255, i[3] = s >> 16 & 255, t += a
    }
    return ga(r)
}

function dS(e, r, t, a) {
    var i = Na(e),
        n = i.getUint32(4, !0),
        s = (a > 1 ? 12 : 8) + Yc(n & (a > 1 ? 3470 : 398)) * 4,
        o = -1,
        c = -1,
        l = NaN,
        f = new Date(2001, 0, 1);
    n & 512 && (o = i.getUint32(s, !0), s += 4), s += Yc(n & (a > 1 ? 12288 : 4096)) * 4, n & 16 && (c = i.getUint32(s, !0), s += 4), n & 32 && (l = i.getFloat64(s, !0), s += 8), n & 64 && (f.setTime(f.getTime() + i.getFloat64(s, !0) * 1e3), s += 8);
    var u;
    switch (e[2]) {
        case 0:
            break;
        case 2:
            u = {
                t: "n",
                v: l
            };
            break;
        case 3:
            u = {
                t: "s",
                v: r[c]
            };
            break;
        case 5:
            u = {
                t: "d",
                v: f
            };
            break;
        case 6:
            u = {
                t: "b",
                v: l > 0
            };
            break;
        case 7:
            u = {
                t: "n",
                v: l / 86400
            };
            break;
        case 8:
            u = {
                t: "e",
                v: 0
            };
            break;
        case 9:
            if (o > -1) u = {
                t: "s",
                v: t[o]
            };
            else if (c > -1) u = {
                t: "s",
                v: r[c]
            };
            else if (!isNaN(l)) u = {
                t: "n",
                v: l
            };
            else throw new Error("Unsupported cell type ".concat(e.slice(0, 4)));
            break;
        default:
            throw new Error("Unsupported cell type ".concat(e.slice(0, 4)))
    }
    return u
}

function hS(e, r, t) {
    var a = Na(e),
        i = a.getUint32(8, !0),
        n = 12,
        s = -1,
        o = -1,
        c = NaN,
        l = NaN,
        f = new Date(2001, 0, 1);
    i & 1 && (c = lS(e, n), n += 16), i & 2 && (l = a.getFloat64(n, !0), n += 8), i & 4 && (f.setTime(f.getTime() + a.getFloat64(n, !0) * 1e3), n += 8), i & 8 && (o = a.getUint32(n, !0), n += 4), i & 16 && (s = a.getUint32(n, !0), n += 4);
    var u;
    switch (e[1]) {
        case 0:
            break;
        case 2:
            u = {
                t: "n",
                v: c
            };
            break;
        case 3:
            u = {
                t: "s",
                v: r[o]
            };
            break;
        case 5:
            u = {
                t: "d",
                v: f
            };
            break;
        case 6:
            u = {
                t: "b",
                v: l > 0
            };
            break;
        case 7:
            u = {
                t: "n",
                v: l / 86400
            };
            break;
        case 8:
            u = {
                t: "e",
                v: 0
            };
            break;
        case 9:
            if (s > -1) u = {
                t: "s",
                v: t[s]
            };
            else throw new Error("Unsupported cell type ".concat(e[1], " : ").concat(i & 31, " : ").concat(e.slice(0, 4)));
            break;
        case 10:
            u = {
                t: "n",
                v: c
            };
            break;
        default:
            throw new Error("Unsupported cell type ".concat(e[1], " : ").concat(i & 31, " : ").concat(e.slice(0, 4)))
    }
    return u
}

function bs(e, r) {
    var t = new Uint8Array(32),
        a = Na(t),
        i = 12,
        n = 0;
    switch (t[0] = 5, e.t) {
        case "n":
            t[1] = 2, fS(t, i, e.v), n |= 1, i += 16;
            break;
        case "b":
            t[1] = 6, a.setFloat64(i, e.v ? 1 : 0, !0), n |= 2, i += 8;
            break;
        case "s":
            if (r.indexOf(e.v) == -1) throw new Error("Value ".concat(e.v, " missing from SST!"));
            t[1] = 3, a.setUint32(i, r.indexOf(e.v), !0), n |= 8, i += 4;
            break;
        default:
            throw "unsupported cell type " + e.t
    }
    return a.setUint32(8, n, !0), t.slice(0, i)
}

function Is(e, r) {
    var t = new Uint8Array(32),
        a = Na(t),
        i = 12,
        n = 0;
    switch (t[0] = 3, e.t) {
        case "n":
            t[2] = 2, a.setFloat64(i, e.v, !0), n |= 32, i += 8;
            break;
        case "b":
            t[2] = 6, a.setFloat64(i, e.v ? 1 : 0, !0), n |= 32, i += 8;
            break;
        case "s":
            if (r.indexOf(e.v) == -1) throw new Error("Value ".concat(e.v, " missing from SST!"));
            t[2] = 3, a.setUint32(i, r.indexOf(e.v), !0), n |= 16, i += 4;
            break;
        default:
            throw "unsupported cell type " + e.t
    }
    return a.setUint32(4, n, !0), t.slice(0, i)
}

function pS(e, r, t) {
    switch (e[0]) {
        case 0:
        case 1:
        case 2:
        case 3:
            return dS(e, r, t, e[0]);
        case 5:
            return hS(e, r, t);
        default:
            throw new Error("Unsupported payload version ".concat(e[0]))
    }
}

function Wt(e) {
    var r = $e(e);
    return Ji(r[1][0].data)
}

function Kc(e, r) {
    var t = $e(r.data),
        a = gt(t[1][0].data),
        i = t[3],
        n = [];
    return (i || []).forEach(function(s) {
        var o = $e(s.data),
            c = gt(o[1][0].data) >>> 0;
        switch (a) {
            case 1:
                n[c] = zs(o[3][0].data);
                break;
            case 8:
                {
                    var l = e[Wt(o[9][0].data)][0],
                        f = $e(l.data),
                        u = e[Wt(f[1][0].data)][0],
                        h = gt(u.meta[1][0].data);
                    if (h != 2001) throw new Error("2000 unexpected reference to ".concat(h));
                    var p = $e(u.data);n[c] = p[3].map(function(m) {
                        return zs(m.data)
                    }).join("")
                }
                break
        }
    }), n
}

function mS(e, r) {
    var t, a, i, n, s, o, c, l, f, u, h, p, m, d, x = $e(e),
        E = gt(x[1][0].data) >>> 0,
        S = gt(x[2][0].data) >>> 0,
        _ = ((a = (t = x[8]) == null ? void 0 : t[0]) == null ? void 0 : a.data) && gt(x[8][0].data) > 0 || !1,
        L, U;
    if ((n = (i = x[7]) == null ? void 0 : i[0]) != null && n.data && r != 0) L = (o = (s = x[7]) == null ? void 0 : s[0]) == null ? void 0 : o.data, U = (l = (c = x[6]) == null ? void 0 : c[0]) == null ? void 0 : l.data;
    else if ((u = (f = x[4]) == null ? void 0 : f[0]) != null && u.data && r != 1) L = (p = (h = x[4]) == null ? void 0 : h[0]) == null ? void 0 : p.data, U = (d = (m = x[3]) == null ? void 0 : m[0]) == null ? void 0 : d.data;
    else throw "NUMBERS Tile missing ".concat(r, " cell storage");
    for (var R = _ ? 4 : 1, T = Na(L), N = [], P = 0; P < L.length / 2; ++P) {
        var X = T.getUint16(P * 2, !0);
        X < 65535 && N.push([P, X])
    }
    if (N.length != S) throw "Expected ".concat(S, " cells, found ").concat(N.length);
    var j = [];
    for (P = 0; P < N.length - 1; ++P) j[N[P][0]] = U.subarray(N[P][1] * R, N[P + 1][1] * R);
    return N.length >= 1 && (j[N[N.length - 1][0]] = U.subarray(N[N.length - 1][1] * R)), {
        R: E,
        cells: j
    }
}

function xS(e, r) {
    var t, a = $e(r.data),
        i = (t = a ? .[7]) != null && t[0] ? gt(a[7][0].data) >>> 0 > 0 ? 1 : 0 : -1,
        n = b0(a[5], function(s) {
            return mS(s, i)
        });
    return {
        nrows: gt(a[4][0].data) >>> 0,
        data: n.reduce(function(s, o) {
            return s[o.R] || (s[o.R] = []), o.cells.forEach(function(c, l) {
                if (s[o.R][l]) throw new Error("Duplicate cell r=".concat(o.R, " c=").concat(l));
                s[o.R][l] = c
            }), s
        }, [])
    }
}

function gS(e, r, t) {
    var a, i = $e(r.data),
        n = {
            s: {
                r: 0,
                c: 0
            },
            e: {
                r: 0,
                c: 0
            }
        };
    if (n.e.r = (gt(i[6][0].data) >>> 0) - 1, n.e.r < 0) throw new Error("Invalid row varint ".concat(i[6][0].data));
    if (n.e.c = (gt(i[7][0].data) >>> 0) - 1, n.e.c < 0) throw new Error("Invalid col varint ".concat(i[7][0].data));
    t["!ref"] = Ne(n);
    var s = $e(i[4][0].data),
        o = Kc(e, e[Wt(s[4][0].data)][0]),
        c = (a = s[17]) != null && a[0] ? Kc(e, e[Wt(s[17][0].data)][0]) : [],
        l = $e(s[3][0].data),
        f = 0;
    l[1].forEach(function(u) {
        var h = $e(u.data),
            p = e[Wt(h[2][0].data)][0],
            m = gt(p.meta[1][0].data);
        if (m != 6002) throw new Error("6001 unexpected reference to ".concat(m));
        var d = xS(e, p);
        d.data.forEach(function(x, E) {
            x.forEach(function(S, _) {
                var L = Me({
                        r: f + E,
                        c: _
                    }),
                    U = pS(S, o, c);
                U && (t[L] = U)
            })
        }), f += d.nrows
    })
}

function _S(e, r) {
    var t = $e(r.data),
        a = {
            "!ref": "A1"
        },
        i = e[Wt(t[2][0].data)],
        n = gt(i[0].meta[1][0].data);
    if (n != 6001) throw new Error("6000 unexpected reference to ".concat(n));
    return gS(e, i[0], a), a
}

function vS(e, r) {
    var t, a = $e(r.data),
        i = {
            name: (t = a[1]) != null && t[0] ? zs(a[1][0].data) : "",
            sheets: []
        },
        n = b0(a[2], Wt);
    return n.forEach(function(s) {
        e[s].forEach(function(o) {
            var c = gt(o.meta[1][0].data);
            c == 6e3 && i.sheets.push(_S(e, o))
        })
    }), i
}

function wS(e, r) {
    var t = R0(),
        a = $e(r.data),
        i = b0(a[1], Wt);
    if (i.forEach(function(n) {
            e[n].forEach(function(s) {
                var o = gt(s.meta[1][0].data);
                if (o == 2) {
                    var c = vS(e, s);
                    c.sheets.forEach(function(l, f) {
                        P0(t, l, f == 0 ? c.name : c.name + "_" + f, !0)
                    })
                }
            })
        }), t.SheetNames.length == 0) throw new Error("Empty NUMBERS file");
    return t
}

function Ms(e) {
    var r, t, a, i, n = {},
        s = [];
    if (e.FullPaths.forEach(function(c) {
            if (c.match(/\.iwpv2/)) throw new Error("Unsupported password protection")
        }), e.FileIndex.forEach(function(c) {
            if (c.name.match(/\.iwa$/)) {
                var l;
                try {
                    l = kr(c.content)
                } catch (u) {
                    return console.log("?? " + c.content.length + " " + (u.message || u))
                }
                var f;
                try {
                    f = yr(l)
                } catch (u) {
                    return console.log("## " + (u.message || u))
                }
                f.forEach(function(u) {
                    n[u.id] = u.messages, s.push(u.id)
                })
            }
        }), !s.length) throw new Error("File has no messages");
    var o = ((i = (a = (t = (r = n ? .[1]) == null ? void 0 : r[0]) == null ? void 0 : t.meta) == null ? void 0 : a[1]) == null ? void 0 : i[0].data) && gt(n[1][0].meta[1][0].data) == 1 && n[1][0];
    if (o || s.forEach(function(c) {
            n[c].forEach(function(l) {
                var f = gt(l.meta[1][0].data) >>> 0;
                if (f == 1)
                    if (!o) o = l;
                    else throw new Error("Document has multiple roots")
            })
        }), !o) throw new Error("Cannot find Document root");
    return wS(n, o)
}

function SS(e, r, t) {
    var a, i, n, s;
    if (!((a = e[6]) != null && a[0]) || !((i = e[7]) != null && i[0])) throw "Mutation only works on post-BNC storages!";
    var o = ((s = (n = e[8]) == null ? void 0 : n[0]) == null ? void 0 : s.data) && gt(e[8][0].data) > 0 || !1;
    if (o) throw "Math only works with normal offsets";
    for (var c = 0, l = Na(e[7][0].data), f = 0, u = [], h = Na(e[4][0].data), p = 0, m = [], d = 0; d < r.length; ++d) {
        if (r[d] == null) {
            l.setUint16(d * 2, 65535, !0), h.setUint16(d * 2, 65535);
            continue
        }
        l.setUint16(d * 2, f, !0), h.setUint16(d * 2, p, !0);
        var x, E;
        switch (typeof r[d]) {
            case "string":
                x = bs({
                    t: "s",
                    v: r[d]
                }, t), E = Is({
                    t: "s",
                    v: r[d]
                }, t);
                break;
            case "number":
                x = bs({
                    t: "n",
                    v: r[d]
                }, t), E = Is({
                    t: "n",
                    v: r[d]
                }, t);
                break;
            case "boolean":
                x = bs({
                    t: "b",
                    v: r[d]
                }, t), E = Is({
                    t: "b",
                    v: r[d]
                }, t);
                break;
            default:
                throw new Error("Unsupported value " + r[d])
        }
        u.push(x), f += x.length, m.push(E), p += E.length, ++c
    }
    for (e[2][0].data = Qe(c); d < e[7][0].data.length / 2; ++d) l.setUint16(d * 2, 65535, !0), h.setUint16(d * 2, 65535, !0);
    return e[6][0].data = ga(u), e[3][0].data = ga(m), c
}

function ES(e, r) {
    if (!r || !r.numbers) throw new Error("Must pass a `numbers` option -- check the README");
    var t = e.Sheets[e.SheetNames[0]];
    e.SheetNames.length > 1 && console.error("The Numbers writer currently writes only the first table");
    var a = or(t["!ref"]);
    a.s.r = a.s.c = 0;
    var i = !1;
    a.e.c > 9 && (i = !0, a.e.c = 9), a.e.r > 49 && (i = !0, a.e.r = 49), i && console.error("The Numbers writer is currently limited to ".concat(Ne(a)));
    var n = qn(t, {
            range: a,
            header: 1
        }),
        s = ["~Sh33tJ5~"];
    n.forEach(function(O) {
        return O.forEach(function(M) {
            typeof M == "string" && s.push(M)
        })
    });
    var o = {},
        c = [],
        l = Ae.read(r.numbers, {
            type: "base64"
        });
    l.FileIndex.map(function(O, M) {
        return [O, l.FullPaths[M]]
    }).forEach(function(O) {
        var M = O[0],
            J = O[1];
        if (M.type == 2 && M.name.match(/\.iwa/)) {
            var de = M.content,
                ie = kr(de),
                ne = yr(ie);
            ne.forEach(function(Q) {
                c.push(Q.id), o[Q.id] = {
                    deps: [],
                    location: J,
                    type: gt(Q.messages[0].meta[1][0].data)
                }
            })
        }
    }), c.sort(function(O, M) {
        return O - M
    });
    var f = c.filter(function(O) {
        return O > 1
    }).map(function(O) {
        return [O, Qe(O)]
    });
    l.FileIndex.map(function(O, M) {
        return [O, l.FullPaths[M]]
    }).forEach(function(O) {
        var M = O[0],
            J = O[1];
        if (M.name.match(/\.iwa/)) {
            var de = yr(kr(M.content));
            de.forEach(function(ie) {
                ie.messages.forEach(function(ne) {
                    f.forEach(function(Q) {
                        ie.messages.some(function(Pe) {
                            return gt(Pe.meta[1][0].data) != 11006 && cS(Pe.data, Q[1])
                        }) && o[Q[0]].deps.push(ie.id)
                    })
                })
            })
        }
    });

    function u() {
        for (var O = 927262; O < 2e6; ++O)
            if (!o[O]) return O;
        throw new Error("Too many messages")
    }
    for (var h = Ae.find(l, o[1].location), p = yr(kr(h.content)), m, d = 0; d < p.length; ++d) {
        var x = p[d];
        x.id == 1 && (m = x)
    }
    var E = Wt($e(m.messages[0].data)[1][0].data);
    for (h = Ae.find(l, o[E].location), p = yr(kr(h.content)), d = 0; d < p.length; ++d) x = p[d], x.id == E && (m = x);
    for (E = Wt($e(m.messages[0].data)[2][0].data), h = Ae.find(l, o[E].location), p = yr(kr(h.content)), d = 0; d < p.length; ++d) x = p[d], x.id == E && (m = x);
    for (E = Wt($e(m.messages[0].data)[2][0].data), h = Ae.find(l, o[E].location), p = yr(kr(h.content)), d = 0; d < p.length; ++d) x = p[d], x.id == E && (m = x);
    var S = $e(m.messages[0].data); {
        S[6][0].data = Qe(a.e.r + 1), S[7][0].data = Qe(a.e.c + 1);
        var _ = Wt(S[46][0].data),
            L = Ae.find(l, o[_].location),
            U = yr(kr(L.content)); {
            for (var R = 0; R < U.length && U[R].id != _; ++R);
            if (U[R].id != _) throw "Bad ColumnRowUIDMapArchive";
            var T = $e(U[R].messages[0].data);
            T[1] = [], T[2] = [], T[3] = [];
            for (var N = 0; N <= a.e.c; ++N) {
                var P = [];
                P[1] = P[2] = [{
                    type: 0,
                    data: Qe(N + 420690)
                }], T[1].push({
                    type: 2,
                    data: Lt(P)
                }), T[2].push({
                    type: 0,
                    data: Qe(N)
                }), T[3].push({
                    type: 0,
                    data: Qe(N)
                })
            }
            T[4] = [], T[5] = [], T[6] = [];
            for (var X = 0; X <= a.e.r; ++X) P = [], P[1] = P[2] = [{
                type: 0,
                data: Qe(X + 726270)
            }], T[4].push({
                type: 2,
                data: Lt(P)
            }), T[5].push({
                type: 0,
                data: Qe(X)
            }), T[6].push({
                type: 0,
                data: Qe(X)
            });
            U[R].messages[0].data = Lt(T)
        }
        L.content = Ja(Ka(U)), L.size = L.content.length, delete S[46];
        var j = $e(S[4][0].data); {
            j[7][0].data = Qe(a.e.r + 1);
            var B = $e(j[1][0].data),
                se = Wt(B[2][0].data);
            L = Ae.find(l, o[se].location), U = yr(kr(L.content)); {
                if (U[0].id != se) throw "Bad HeaderStorageBucket";
                var _e = $e(U[0].messages[0].data);
                for (X = 0; X < n.length; ++X) {
                    var oe = $e(_e[2][0].data);
                    oe[1][0].data = Qe(X), oe[4][0].data = Qe(n[X].length), _e[2][X] = {
                        type: _e[2][0].type,
                        data: Lt(oe)
                    }
                }
                U[0].messages[0].data = Lt(_e)
            }
            L.content = Ja(Ka(U)), L.size = L.content.length;
            var ke = Wt(j[2][0].data);
            L = Ae.find(l, o[ke].location), U = yr(kr(L.content)); {
                if (U[0].id != ke) throw "Bad HeaderStorageBucket";
                for (_e = $e(U[0].messages[0].data), N = 0; N <= a.e.c; ++N) oe = $e(_e[2][0].data), oe[1][0].data = Qe(N), oe[4][0].data = Qe(a.e.r + 1), _e[2][N] = {
                    type: _e[2][0].type,
                    data: Lt(oe)
                };
                U[0].messages[0].data = Lt(_e)
            }
            L.content = Ja(Ka(U)), L.size = L.content.length;
            var Se = Wt(j[4][0].data);
            (function() {
                for (var O = Ae.find(l, o[Se].location), M = yr(kr(O.content)), J, de = 0; de < M.length; ++de) {
                    var ie = M[de];
                    ie.id == Se && (J = ie)
                }
                var ne = $e(J.messages[0].data); {
                    ne[3] = [];
                    var Q = [];
                    s.forEach(function(Ke, He) {
                        Q[1] = [{
                            type: 0,
                            data: Qe(He)
                        }], Q[2] = [{
                            type: 0,
                            data: Qe(1)
                        }], Q[3] = [{
                            type: 2,
                            data: oS(Ke)
                        }], ne[3].push({
                            type: 2,
                            data: Lt(Q)
                        })
                    })
                }
                J.messages[0].data = Lt(ne);
                var Pe = Ka(M),
                    A = Ja(Pe);
                O.content = A, O.size = O.content.length
            })();
            var Ve = $e(j[3][0].data); {
                var me = Ve[1][0];
                delete Ve[2];
                var Te = $e(me.data); {
                    var Z = Wt(Te[2][0].data);
                    (function() {
                        for (var O = Ae.find(l, o[Z].location), M = yr(kr(O.content)), J, de = 0; de < M.length; ++de) {
                            var ie = M[de];
                            ie.id == Z && (J = ie)
                        }
                        var ne = $e(J.messages[0].data); {
                            delete ne[6], delete Ve[7];
                            var Q = new Uint8Array(ne[5][0].data);
                            ne[5] = [];
                            for (var Pe = 0, A = 0; A <= a.e.r; ++A) {
                                var Ke = $e(Q);
                                Pe += SS(Ke, n[A], s), Ke[1][0].data = Qe(A), ne[5].push({
                                    data: Lt(Ke),
                                    type: 2
                                })
                            }
                            ne[1] = [{
                                type: 0,
                                data: Qe(a.e.c + 1)
                            }], ne[2] = [{
                                type: 0,
                                data: Qe(a.e.r + 1)
                            }], ne[3] = [{
                                type: 0,
                                data: Qe(Pe)
                            }], ne[4] = [{
                                type: 0,
                                data: Qe(a.e.r + 1)
                            }]
                        }
                        J.messages[0].data = Lt(ne);
                        var He = Ka(M),
                            Je = Ja(He);
                        O.content = Je, O.size = O.content.length
                    })()
                }
                me.data = Lt(Te)
            }
            j[3][0].data = Lt(Ve)
        }
        S[4][0].data = Lt(j)
    }
    m.messages[0].data = Lt(S);
    var b = Ka(p),
        H = Ja(b);
    return h.content = H, h.size = h.content.length, l
}

function Kf(e) {
    return function(t) {
        for (var a = 0; a != e.length; ++a) {
            var i = e[a];
            t[i[0]] === void 0 && (t[i[0]] = i[1]), i[2] === "n" && (t[i[0]] = Number(t[i[0]]))
        }
    }
}

function I0(e) {
    Kf([
        ["cellNF", !1],
        ["cellHTML", !0],
        ["cellFormula", !0],
        ["cellStyles", !1],
        ["cellText", !0],
        ["cellDates", !1],
        ["sheetStubs", !1],
        ["sheetRows", 0, "n"],
        ["bookDeps", !1],
        ["bookSheets", !1],
        ["bookProps", !1],
        ["bookFiles", !1],
        ["bookVBA", !1],
        ["password", ""],
        ["WTF", !1]
    ])(e)
}

function M0(e) {
    Kf([
        ["cellDates", !1],
        ["bookSST", !1],
        ["bookType", "xlsx"],
        ["compression", !1],
        ["WTF", !1]
    ])(e)
}

function CS(e) {
    return Be.WS.indexOf(e) > -1 ? "sheet" : Be.CS && e == Be.CS ? "chart" : Be.DS && e == Be.DS ? "dialog" : Be.MS && e == Be.MS ? "macro" : e && e.length ? e : "sheet"
}

function TS(e, r) {
    if (!e) return 0;
    try {
        e = r.map(function(a) {
            return a.id || (a.id = a.strRelID), [a.name, e["!id"][a.id].Target, CS(e["!id"][a.id].Type)]
        })
    } catch (t) {
        return null
    }
    return !e || e.length === 0 ? null : e
}

function yS(e, r, t, a, i, n, s, o, c, l, f, u) {
    try {
        n[a] = Ri(hr(e, t, !0), r);
        var h = At(e, r),
            p;
        switch (o) {
            case "sheet":
                p = j2(h, r, i, c, n[a], l, f, u);
                break;
            case "chart":
                if (p = $2(h, r, i, c, n[a], l, f, u), !p || !p["!drawel"]) break;
                var m = Ii(p["!drawel"].Target, r),
                    d = Xi(m),
                    x = Rx(hr(e, m, !0), Ri(hr(e, d, !0), m)),
                    E = Ii(x, m),
                    S = Xi(E);
                p = S2(hr(e, E, !0), E, c, Ri(hr(e, S, !0), E), l, p);
                break;
            case "macro":
                p = Y2(h, r, i, c, n[a], l, f, u);
                break;
            case "dialog":
                p = K2(h, r, i, c, n[a], l, f, u);
                break;
            default:
                throw new Error("Unrecognized sheet type " + o)
        }
        s[a] = p;
        var _ = [];
        n && n[a] && vt(n[a]).forEach(function(L) {
            var U = "";
            if (n[a][L].Type == Be.CMNT) {
                U = Ii(n[a][L].Target, r);
                var R = ew(At(e, U, !0), U, c);
                if (!R || !R.length) return;
                Pc(p, R, !1)
            }
            n[a][L].Type == Be.TCMNT && (U = Ii(n[a][L].Target, r), _ = _.concat(Nx(At(e, U, !0), c)))
        }), _ && _.length && Pc(p, _, !0, c.people || [])
    } catch (L) {
        if (c.WTF) throw L
    }
}

function Cr(e) {
    return e.charAt(0) == "/" ? e.slice(1) : e
}

function kS(e, r) {
    if (fi(), r = r || {}, I0(r), Fr(e, "META-INF/manifest.xml") || Fr(e, "objectdata.xml")) return qc(e, r);
    if (Fr(e, "Index/Document.iwa")) {
        if (typeof Uint8Array > "u") throw new Error("NUMBERS file parsing requires Uint8Array support");
        if (typeof Ms < "u") {
            if (e.FileIndex) return Ms(e);
            var t = Ae.utils.cfb_new();
            return rc(e).forEach(function(_e) {
                Le(t, _e, pl(e, _e))
            }), Ms(t)
        }
        throw new Error("Unsupported NUMBERS file")
    }
    if (!Fr(e, "[Content_Types].xml")) throw Fr(e, "index.xml.gz") ? new Error("Unsupported NUMBERS 08 file") : Fr(e, "index.xml") ? new Error("Unsupported NUMBERS 09 file") : new Error("Unsupported ZIP file");
    var a = rc(e),
        i = Ih(hr(e, "[Content_Types].xml")),
        n = !1,
        s, o;
    if (i.workbooks.length === 0 && (o = "xl/workbook.xml", At(e, o, !0) && i.workbooks.push(o)), i.workbooks.length === 0) {
        if (o = "xl/workbook.bin", !At(e, o, !0)) throw new Error("Could not find workbook");
        i.workbooks.push(o), n = !0
    }
    i.workbooks[0].slice(-3) == "bin" && (n = !0);
    var c = {},
        l = {};
    if (!r.bookSheets && !r.bookProps) {
        if (Pi = [], i.sst) try {
            Pi = Q2(At(e, Cr(i.sst)), i.sst, r)
        } catch (_e) {
            if (r.WTF) throw _e
        }
        r.cellStyles && i.themes.length && (c = Z2(hr(e, i.themes[0].replace(/^\//, ""), !0) || "", i.themes[0], r)), i.style && (l = J2(At(e, Cr(i.style)), i.style, c, r))
    }
    i.links.map(function(_e) {
        try {
            var oe = Ri(hr(e, Xi(Cr(_e))), _e);
            return rw(At(e, Cr(_e)), oe, _e, r)
        } catch (ke) {}
    });
    var f = q2(At(e, Cr(i.workbooks[0])), i.workbooks[0], r),
        u = {},
        h = "";
    i.coreprops.length && (h = At(e, Cr(i.coreprops[0]), !0), h && (u = Ll(h)), i.extprops.length !== 0 && (h = At(e, Cr(i.extprops[0]), !0), h && Lh(h, u, r)));
    var p = {};
    (!r.bookSheets || r.bookProps) && i.custprops.length !== 0 && (h = hr(e, Cr(i.custprops[0]), !0), h && (p = Uh(h, r)));
    var m = {};
    if ((r.bookSheets || r.bookProps) && (f.Sheets ? s = f.Sheets.map(function(oe) {
            return oe.name
        }) : u.Worksheets && u.SheetNames.length > 0 && (s = u.SheetNames), r.bookProps && (m.Props = u, m.Custprops = p), r.bookSheets && typeof s < "u" && (m.SheetNames = s), r.bookSheets ? m.SheetNames : r.bookProps)) return m;
    s = {};
    var d = {};
    r.bookDeps && i.calcchain && (d = tw(At(e, Cr(i.calcchain)), i.calcchain, r));
    var x = 0,
        E = {},
        S, _; {
        var L = f.Sheets;
        u.Worksheets = L.length, u.SheetNames = [];
        for (var U = 0; U != L.length; ++U) u.SheetNames[U] = L[U].name
    }
    var R = n ? "bin" : "xml",
        T = i.workbooks[0].lastIndexOf("/"),
        N = (i.workbooks[0].slice(0, T + 1) + "_rels/" + i.workbooks[0].slice(T + 1) + ".rels").replace(/^\//, "");
    Fr(e, N) || (N = "xl/_rels/workbook." + R + ".rels");
    var P = Ri(hr(e, N, !0), N.replace(/_rels.*/, "s5s"));
    (i.metadata || []).length >= 1 && (r.xlmeta = aw(At(e, Cr(i.metadata[0])), i.metadata[0], r)), (i.people || []).length >= 1 && (r.people = Bx(At(e, Cr(i.people[0])), r)), P && (P = TS(P, f.Sheets));
    var X = At(e, "xl/worksheets/sheet.xml", !0) ? 1 : 0;
    e: for (x = 0; x != u.Worksheets; ++x) {
        var j = "sheet";
        if (P && P[x] ? (S = "xl/" + P[x][1].replace(/[\/]?xl\//, ""), Fr(e, S) || (S = P[x][1]), Fr(e, S) || (S = N.replace(/_rels\/.*$/, "") + P[x][1]), j = P[x][2]) : (S = "xl/worksheets/sheet" + (x + 1 - X) + "." + R, S = S.replace(/sheet0\./, "sheet.")), _ = S.replace(/^(.*)(\/)([^\/]*)$/, "$1/_rels/$3.rels"), r && r.sheets != null) switch (typeof r.sheets) {
            case "number":
                if (x != r.sheets) continue e;
                break;
            case "string":
                if (u.SheetNames[x].toLowerCase() != r.sheets.toLowerCase()) continue e;
                break;
            default:
                if (Array.isArray && Array.isArray(r.sheets)) {
                    for (var B = !1, se = 0; se != r.sheets.length; ++se) typeof r.sheets[se] == "number" && r.sheets[se] == x && (B = 1), typeof r.sheets[se] == "string" && r.sheets[se].toLowerCase() == u.SheetNames[x].toLowerCase() && (B = 1);
                    if (!B) continue e
                }
        }
        yS(e, S, _, u.SheetNames[x], x, E, s, j, r, f, c, l)
    }
    return m = {
        Directory: i,
        Workbook: f,
        Props: u,
        Custprops: p,
        Deps: d,
        Sheets: s,
        SheetNames: u.SheetNames,
        Strings: Pi,
        Styles: l,
        Themes: c,
        SSF: ut(Ie)
    }, r && r.bookFiles && (e.files ? (m.keys = a, m.files = e.files) : (m.keys = [], m.files = {}, e.FullPaths.forEach(function(_e, oe) {
        _e = _e.replace(/^Root Entry[\/]/, ""), m.keys.push(_e), m.files[_e] = e.FileIndex[oe]
    }))), r && r.bookVBA && (i.vba.length > 0 ? m.vbaraw = At(e, Cr(i.vba[0]), !0) : i.defaults && i.defaults.bin === qx && (m.vbaraw = At(e, "xl/vbaProject.bin", !0))), m
}

function FS(e, r) {
    var t = r || {},
        a = "Workbook",
        i = Ae.find(e, a);
    try {
        if (a = "/!DataSpaces/Version", i = Ae.find(e, a), !i || !i.content) throw new Error("ECMA-376 Encrypted file missing " + a);
        if (am(i.content), a = "/!DataSpaces/DataSpaceMap", i = Ae.find(e, a), !i || !i.content) throw new Error("ECMA-376 Encrypted file missing " + a);
        var n = nm(i.content);
        if (n.length !== 1 || n[0].comps.length !== 1 || n[0].comps[0].t !== 0 || n[0].name !== "StrongEncryptionDataSpace" || n[0].comps[0].v !== "EncryptedPackage") throw new Error("ECMA-376 Encrypted file bad " + a);
        if (a = "/!DataSpaces/DataSpaceInfo/StrongEncryptionDataSpace", i = Ae.find(e, a), !i || !i.content) throw new Error("ECMA-376 Encrypted file missing " + a);
        var s = sm(i.content);
        if (s.length != 1 || s[0] != "StrongEncryptionTransform") throw new Error("ECMA-376 Encrypted file bad " + a);
        if (a = "/!DataSpaces/TransformInfo/StrongEncryptionTransform/!Primary", i = Ae.find(e, a), !i || !i.content) throw new Error("ECMA-376 Encrypted file missing " + a);
        cm(i.content)
    } catch (c) {}
    if (a = "/EncryptionInfo", i = Ae.find(e, a), !i || !i.content) throw new Error("ECMA-376 Encrypted file missing " + a);
    var o = lm(i.content);
    if (a = "/EncryptedPackage", i = Ae.find(e, a), !i || !i.content) throw new Error("ECMA-376 Encrypted file missing " + a);
    if (o[0] == 4 && typeof decrypt_agile < "u") return decrypt_agile(o[1], i.content, t.password || "", t);
    if (o[0] == 2 && typeof decrypt_std76 < "u") return decrypt_std76(o[1], i.content, t.password || "", t);
    throw new Error("File is password-protected")
}

function AS(e, r) {
    return r.bookType == "ods" ? Yf(e, r) : r.bookType == "numbers" ? ES(e, r) : r.bookType == "xlsb" ? bS(e, r) : IS(e, r)
}

function bS(e, r) {
    ei = 1024, e && !e.SSF && (e.SSF = ut(Ie)), e && e.SSF && (fi(), $n(e.SSF), r.revssf = Kn(e.SSF), r.revssf[e.SSF[65535]] = 0, r.ssf = e.SSF), r.rels = {}, r.wbrels = {}, r.Strings = [], r.Strings.Count = 0, r.Strings.Unique = 0, Ni ? r.revStrings = new Map : (r.revStrings = {}, r.revStrings.foo = [], delete r.revStrings.foo);
    var t = r.bookType == "xlsb" ? "bin" : "xml",
        a = Cf.indexOf(r.bookType) > -1,
        i = x0();
    M0(r = r || {});
    var n = Zs(),
        s = "",
        o = 0;
    if (r.cellXfs = [], wa(r.cellXfs, {}, {
            revssf: {
                General: 0
            }
        }), e.Props || (e.Props = {}), s = "docProps/core.xml", Le(n, s, Bl(e.Props, r)), i.coreprops.push(s), et(r.rels, 2, s, Be.CORE_PROPS), s = "docProps/app.xml", !(e.Props && e.Props.SheetNames))
        if (!e.Workbook || !e.Workbook.Sheets) e.Props.SheetNames = e.SheetNames;
        else {
            for (var c = [], l = 0; l < e.SheetNames.length; ++l)(e.Workbook.Sheets[l] || {}).Hidden != 2 && c.push(e.SheetNames[l]);
            e.Props.SheetNames = c
        }
    for (e.Props.Worksheets = e.Props.SheetNames.length, Le(n, s, Wl(e.Props, r)), i.extprops.push(s), et(r.rels, 3, s, Be.EXT_PROPS), e.Custprops !== e.Props && vt(e.Custprops || {}).length > 0 && (s = "docProps/custom.xml", Le(n, s, Hl(e.Custprops, r)), i.custprops.push(s), et(r.rels, 4, s, Be.CUST_PROPS)), o = 1; o <= e.SheetNames.length; ++o) {
        var f = {
                "!id": {}
            },
            u = e.Sheets[e.SheetNames[o - 1]],
            h = (u || {})["!type"] || "sheet";
        if (s = "xl/worksheets/sheet" + o + "." + t, Le(n, s, nw(o - 1, s, r, e, f)), i.sheets.push(s), et(r.wbrels, -1, "worksheets/sheet" + o + "." + t, Be.WS[0]), u) {
            var p = u["!comments"],
                m = !1,
                d = "";
            p && p.length > 0 && (d = "xl/comments" + o + "." + t, Le(n, d, cw(p, d, r)), i.comments.push(d), et(f, -1, "../comments" + o + "." + t, Be.CMNT), m = !0), u["!legacy"] && m && Le(n, "xl/drawings/vmlDrawing" + o + ".vml", Sf(o, u["!comments"])), delete u["!comments"], delete u["!legacy"]
        }
        f["!id"].rId1 && Le(n, Xi(s), ri(f))
    }
    return r.Strings != null && r.Strings.length > 0 && (s = "xl/sharedStrings." + t, Le(n, s, ow(r.Strings, s, r)), i.strs.push(s), et(r.wbrels, -1, "sharedStrings." + t, Be.SST)), s = "xl/workbook." + t, Le(n, s, iw(e, s, r)), i.workbooks.push(s), et(r.rels, 1, s, Be.WB), s = "xl/theme/theme1.xml", Le(n, s, E0(e.Themes, r)), i.themes.push(s), et(r.wbrels, -1, "theme/theme1.xml", Be.THEME), s = "xl/styles." + t, Le(n, s, sw(e, s, r)), i.styles.push(s), et(r.wbrels, -1, "styles." + t, Be.STY), e.vbaraw && a && (s = "xl/vbaProject.bin", Le(n, s, e.vbaraw), i.vba.push(s), et(r.wbrels, -1, "vbaProject.bin", Be.VBA)), s = "xl/metadata." + t, Le(n, s, lw(s)), i.metadata.push(s), et(r.wbrels, -1, "metadata." + t, Be.XLMETA), Le(n, "[Content_Types].xml", Pl(i, r)), Le(n, "_rels/.rels", ri(r.rels)), Le(n, "xl/_rels/workbook." + t + ".rels", ri(r.wbrels)), delete r.revssf, delete r.ssf, n
}

function IS(e, r) {
    ei = 1024, e && !e.SSF && (e.SSF = ut(Ie)), e && e.SSF && (fi(), $n(e.SSF), r.revssf = Kn(e.SSF), r.revssf[e.SSF[65535]] = 0, r.ssf = e.SSF), r.rels = {}, r.wbrels = {}, r.Strings = [], r.Strings.Count = 0, r.Strings.Unique = 0, Ni ? r.revStrings = new Map : (r.revStrings = {}, r.revStrings.foo = [], delete r.revStrings.foo);
    var t = "xml",
        a = Cf.indexOf(r.bookType) > -1,
        i = x0();
    M0(r = r || {});
    var n = Zs(),
        s = "",
        o = 0;
    if (r.cellXfs = [], wa(r.cellXfs, {}, {
            revssf: {
                General: 0
            }
        }), e.Props || (e.Props = {}), s = "docProps/core.xml", Le(n, s, Bl(e.Props, r)), i.coreprops.push(s), et(r.rels, 2, s, Be.CORE_PROPS), s = "docProps/app.xml", !(e.Props && e.Props.SheetNames))
        if (!e.Workbook || !e.Workbook.Sheets) e.Props.SheetNames = e.SheetNames;
        else {
            for (var c = [], l = 0; l < e.SheetNames.length; ++l)(e.Workbook.Sheets[l] || {}).Hidden != 2 && c.push(e.SheetNames[l]);
            e.Props.SheetNames = c
        }
    e.Props.Worksheets = e.Props.SheetNames.length, Le(n, s, Wl(e.Props, r)), i.extprops.push(s), et(r.rels, 3, s, Be.EXT_PROPS), e.Custprops !== e.Props && vt(e.Custprops || {}).length > 0 && (s = "docProps/custom.xml", Le(n, s, Hl(e.Custprops, r)), i.custprops.push(s), et(r.rels, 4, s, Be.CUST_PROPS));
    var f = ["SheetJ5"];
    for (r.tcid = 0, o = 1; o <= e.SheetNames.length; ++o) {
        var u = {
                "!id": {}
            },
            h = e.Sheets[e.SheetNames[o - 1]],
            p = (h || {})["!type"] || "sheet";
        if (s = "xl/worksheets/sheet" + o + "." + t, Le(n, s, Rf(o - 1, r, e, u)), i.sheets.push(s), et(r.wbrels, -1, "worksheets/sheet" + o + "." + t, Be.WS[0]), h) {
            var m = h["!comments"],
                d = !1,
                x = "";
            if (m && m.length > 0) {
                var E = !1;
                m.forEach(function(S) {
                    S[1].forEach(function(_) {
                        _.T == !0 && (E = !0)
                    })
                }), E && (x = "xl/threadedComments/threadedComment" + o + "." + t, Le(n, x, Lx(m, f, r)), i.threadedcomments.push(x), et(u, -1, "../threadedComments/threadedComment" + o + "." + t, Be.TCMNT)), x = "xl/comments" + o + "." + t, Le(n, x, Ef(m, r)), i.comments.push(x), et(u, -1, "../comments" + o + "." + t, Be.CMNT), d = !0
            }
            h["!legacy"] && d && Le(n, "xl/drawings/vmlDrawing" + o + ".vml", Sf(o, h["!comments"])), delete h["!comments"], delete h["!legacy"]
        }
        u["!id"].rId1 && Le(n, Xi(s), ri(u))
    }
    return r.Strings != null && r.Strings.length > 0 && (s = "xl/sharedStrings." + t, Le(n, s, lf(r.Strings, r)), i.strs.push(s), et(r.wbrels, -1, "sharedStrings." + t, Be.SST)), s = "xl/workbook." + t, Le(n, s, Uf(e, r)), i.workbooks.push(s), et(r.rels, 1, s, Be.WB), s = "xl/theme/theme1.xml", Le(n, s, E0(e.Themes, r)), i.themes.push(s), et(r.wbrels, -1, "theme/theme1.xml", Be.THEME), s = "xl/styles." + t, Le(n, s, gf(e, r)), i.styles.push(s), et(r.wbrels, -1, "styles." + t, Be.STY), e.vbaraw && a && (s = "xl/vbaProject.bin", Le(n, s, e.vbaraw), i.vba.push(s), et(r.wbrels, -1, "vbaProject.bin", Be.VBA)), s = "xl/metadata." + t, Le(n, s, wf()), i.metadata.push(s), et(r.wbrels, -1, "metadata." + t, Be.XLMETA), f.length > 1 && (s = "xl/persons/person.xml", Le(n, s, Ux(f, r)), i.people.push(s), et(r.wbrels, -1, "persons/person.xml", Be.PEOPLE)), Le(n, "[Content_Types].xml", Pl(i, r)), Le(n, "_rels/.rels", ri(r.rels)), Le(n, "xl/_rels/workbook." + t + ".rels", ri(r.wbrels)), delete r.revssf, delete r.ssf, n
}

function O0(e, r) {
    var t = "";
    switch ((r || {}).type || "base64") {
        case "buffer":
            return [e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]];
        case "base64":
            t = pr(e.slice(0, 12));
            break;
        case "binary":
            t = e;
            break;
        case "array":
            return [e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]];
        default:
            throw new Error("Unrecognized type " + (r && r.type || "undefined"))
    }
    return [t.charCodeAt(0), t.charCodeAt(1), t.charCodeAt(2), t.charCodeAt(3), t.charCodeAt(4), t.charCodeAt(5), t.charCodeAt(6), t.charCodeAt(7)]
}

function MS(e, r) {
    return Ae.find(e, "EncryptedPackage") ? FS(e, r) : Gf(e, r)
}

function OS(e, r) {
    var t, a = e,
        i = r || {};
    return i.type || (i.type = Ue && Buffer.isBuffer(e) ? "buffer" : "base64"), t = ml(a, i), kS(t, i)
}

function Jf(e, r) {
    var t = 0;
    e: for (; t < e.length;) switch (e.charCodeAt(t)) {
        case 10:
        case 13:
        case 32:
            ++t;
            break;
        case 60:
            return Hs(e.slice(t), r);
        default:
            break e
    }
    return oi.to_workbook(e, r)
}

function DS(e, r) {
    var t = "",
        a = O0(e, r);
    switch (r.type) {
        case "base64":
            t = pr(e);
            break;
        case "binary":
            t = e;
            break;
        case "buffer":
            t = e.toString("binary");
            break;
        case "array":
            t = Oa(e);
            break;
        default:
            throw new Error("Unrecognized type " + r.type)
    }
    return a[0] == 239 && a[1] == 187 && a[2] == 191 && (t = at(t)), r.type = "binary", Jf(t, r)
}

function RS(e, r) {
    var t = e;
    return r.type == "base64" && (t = pr(t)), t = Ye.utils.decode(1200, t.slice(2), "str"), r.type = "binary", Jf(t, r)
}

function PS(e) {
    return e.match(/[^\x00-\x7F]/) ? Gr(e) : e
}

function Os(e, r, t, a) {
    return a ? (t.type = "string", oi.to_workbook(e, t)) : oi.to_workbook(r, t)
}

function Xn(e, r) {
    js();
    var t = r || {};
    if (typeof ArrayBuffer < "u" && e instanceof ArrayBuffer) return Xn(new Uint8Array(e), (t = ut(t), t.type = "array", t));
    typeof Uint8Array < "u" && e instanceof Uint8Array && !t.type && (t.type = typeof Deno < "u" ? "buffer" : "array");
    var a = e,
        i = [0, 0, 0, 0],
        n = !1;
    if (t.cellStyles && (t.cellNF = !0, t.sheetStubs = !0), ii = {}, t.dateNF && (ii.dateNF = t.dateNF), t.type || (t.type = Ue && Buffer.isBuffer(e) ? "buffer" : "base64"), t.type == "file" && (t.type = Ue ? "buffer" : "binary", a = bd(e), typeof Uint8Array < "u" && !Ue && (t.type = "array")), t.type == "string" && (n = !0, t.type = "binary", t.codepage = 65001, a = PS(e)), t.type == "array" && typeof Uint8Array < "u" && e instanceof Uint8Array && typeof ArrayBuffer < "u") {
        var s = new ArrayBuffer(3),
            o = new Uint8Array(s);
        if (o.foo = "bar", !o.foo) return t = ut(t), t.type = "array", Xn($s(a), t)
    }
    switch ((i = O0(a, t))[0]) {
        case 208:
            if (i[1] === 207 && i[2] === 17 && i[3] === 224 && i[4] === 161 && i[5] === 177 && i[6] === 26 && i[7] === 225) return MS(Ae.read(a, t), t);
            break;
        case 9:
            if (i[1] <= 8) return Gf(a, t);
            break;
        case 60:
            return Hs(a, t);
        case 73:
            if (i[1] === 73 && i[2] === 42 && i[3] === 0) throw new Error("TIFF Image File is not a spreadsheet");
            if (i[1] === 68) return Vp(a, t);
            break;
        case 84:
            if (i[1] === 65 && i[2] === 66 && i[3] === 76) return of.to_workbook(a, t);
            break;
        case 80:
            return i[1] === 75 && i[2] < 9 && i[3] < 9 ? OS(a, t) : Os(e, a, t, n);
        case 239:
            return i[3] === 60 ? Hs(a, t) : Os(e, a, t, n);
        case 255:
            if (i[1] === 254) return RS(a, t);
            if (i[1] === 0 && i[2] === 2 && i[3] === 0) return ba.to_workbook(a, t);
            break;
        case 0:
            if (i[1] === 0 && (i[2] >= 2 && i[3] === 0 || i[2] === 0 && (i[3] === 8 || i[3] === 9))) return ba.to_workbook(a, t);
            break;
        case 3:
        case 131:
        case 139:
        case 140:
            return Ws.to_workbook(a, t);
        case 123:
            if (i[1] === 92 && i[2] === 114 && i[3] === 116) return pf.to_workbook(a, t);
            break;
        case 10:
        case 13:
        case 32:
            return DS(a, t);
        case 137:
            if (i[1] === 80 && i[2] === 78 && i[3] === 71) throw new Error("PNG Image File is not a spreadsheet");
            break
    }
    return Up.indexOf(i[0]) > -1 && i[2] <= 12 && i[3] <= 31 ? Ws.to_workbook(a, t) : Os(e, a, t, n)
}

function Zf(e, r) {
    switch (r.type) {
        case "base64":
        case "binary":
            break;
        case "buffer":
        case "array":
            r.type = "";
            break;
        case "file":
            return Qi(r.file, Ae.write(e, {
                type: Ue ? "buffer" : ""
            }));
        case "string":
            throw new Error("'string' output type invalid for '" + r.bookType + "' files");
        default:
            throw new Error("Unrecognized type " + r.type)
    }
    return Ae.write(e, r)
}

function NS(e, r) {
    var t = ut(r || {}),
        a = AS(e, t);
    return LS(a, t)
}

function LS(e, r) {
    var t = {},
        a = Ue ? "nodebuffer" : typeof Uint8Array < "u" ? "array" : "string";
    if (r.compression && (t.compression = "DEFLATE"), r.password) t.type = a;
    else switch (r.type) {
        case "base64":
            t.type = "base64";
            break;
        case "binary":
            t.type = "string";
            break;
        case "string":
            throw new Error("'string' output type invalid for '" + r.bookType + "' files");
        case "buffer":
        case "file":
            t.type = a;
            break;
        default:
            throw new Error("Unrecognized type " + r.type)
    }
    var i = e.FullPaths ? Ae.write(e, {
        fileType: "zip",
        type: {
            nodebuffer: "buffer",
            string: "binary"
        }[t.type] || t.type,
        compression: !!r.compression
    }) : e.generate(t);
    if (typeof Deno < "u" && typeof i == "string") {
        if (r.type == "binary" || r.type == "base64") return i;
        i = new Uint8Array(jn(i))
    }
    return r.password && typeof encrypt_agile < "u" ? Zf(encrypt_agile(i, r.password), r) : r.type === "file" ? Qi(r.file, i) : r.type == "string" ? at(i) : i
}

function BS(e, r) {
    var t = r || {},
        a = Pw(e, t);
    return Zf(a, t)
}

function Hr(e, r, t) {
    t || (t = "");
    var a = t + e;
    switch (r.type) {
        case "base64":
            return Vi(Gr(a));
        case "binary":
            return Gr(a);
        case "string":
            return e;
        case "file":
            return Qi(r.file, a, "utf8");
        case "buffer":
            return Ue ? ra(a, "utf8") : typeof TextEncoder < "u" ? new TextEncoder().encode(a) : Hr(a, {
                type: "binary"
            }).split("").map(function(i) {
                return i.charCodeAt(0)
            })
    }
    throw new Error("Unrecognized type " + r.type)
}

function US(e, r) {
    switch (r.type) {
        case "base64":
            return Vi(e);
        case "binary":
            return e;
        case "string":
            return e;
        case "file":
            return Qi(r.file, e, "binary");
        case "buffer":
            return Ue ? ra(e, "binary") : e.split("").map(function(t) {
                return t.charCodeAt(0)
            })
    }
    throw new Error("Unrecognized type " + r.type)
}

function Dn(e, r) {
    switch (r.type) {
        case "string":
        case "base64":
        case "binary":
            for (var t = "", a = 0; a < e.length; ++a) t += String.fromCharCode(e[a]);
            return r.type == "base64" ? Vi(t) : r.type == "string" ? at(t) : t;
        case "file":
            return Qi(r.file, e);
        case "buffer":
            return e;
        default:
            throw new Error("Unrecognized type " + r.type)
    }
}

function on(e, r) {
    js(), M2(e);
    var t = ut(r || {});
    if (t.cellStyles && (t.cellNF = !0, t.sheetStubs = !0), t.type == "array") {
        t.type = "binary";
        var a = on(e, t);
        return t.type = "array", jn(a)
    }
    var i = 0;
    if (t.sheet && (typeof t.sheet == "number" ? i = t.sheet : i = e.SheetNames.indexOf(t.sheet), !e.SheetNames[i])) throw new Error("Sheet not found: " + t.sheet + " : " + typeof t.sheet);
    switch (t.bookType || "xlsb") {
        case "xml":
        case "xlml":
            return Hr(Aw(e, t), t);
        case "slk":
        case "sylk":
            return Hr(sf.from_sheet(e.Sheets[e.SheetNames[i]], t), t);
        case "htm":
        case "html":
            return Hr(Xf(e.Sheets[e.SheetNames[i]], t), t);
        case "txt":
            return US(Qf(e.Sheets[e.SheetNames[i]], t), t);
        case "csv":
            return Hr(D0(e.Sheets[e.SheetNames[i]], t), t, "\uFEFF");
        case "dif":
            return Hr( of .from_sheet(e.Sheets[e.SheetNames[i]], t), t);
        case "dbf":
            return Dn(Ws.from_sheet(e.Sheets[e.SheetNames[i]], t), t);
        case "prn":
            return Hr(oi.from_sheet(e.Sheets[e.SheetNames[i]], t), t);
        case "rtf":
            return Hr(pf.from_sheet(e.Sheets[e.SheetNames[i]], t), t);
        case "eth":
            return Hr(cf.from_sheet(e.Sheets[e.SheetNames[i]], t), t);
        case "fods":
            return Hr(Yf(e, t), t);
        case "wk1":
            return Dn(ba.sheet_to_wk1(e.Sheets[e.SheetNames[i]], t), t);
        case "wk3":
            return Dn(ba.book_to_wk3(e, t), t);
        case "biff2":
            t.biff || (t.biff = 2);
        case "biff3":
            t.biff || (t.biff = 3);
        case "biff4":
            return t.biff || (t.biff = 4), Dn(zf(e, t), t);
        case "biff5":
            t.biff || (t.biff = 5);
        case "biff8":
        case "xla":
        case "xls":
            return t.biff || (t.biff = 8), BS(e, t);
        case "xlsx":
        case "xlsm":
        case "xlam":
        case "xlsb":
        case "numbers":
        case "ods":
            return NS(e, t);
        default:
            throw new Error("Unrecognized bookType |" + t.bookType + "|")
    }
}

function VS(e, r, t, a, i, n, s, o) {
    var c = Tt(t),
        l = o.defval,
        f = o.raw || !Object.prototype.hasOwnProperty.call(o, "raw"),
        u = !0,
        h = i === 1 ? [] : {};
    if (i !== 1)
        if (Object.defineProperty) try {
            Object.defineProperty(h, "__rowNum__", {
                value: t,
                enumerable: !1
            })
        } catch (x) {
            h.__rowNum__ = t
        } else h.__rowNum__ = t;
    if (!s || e[t])
        for (var p = r.s.c; p <= r.e.c; ++p) {
            var m = s ? e[t][p] : e[a[p] + c];
            if (m === void 0 || m.t === void 0) {
                if (l === void 0) continue;
                n[p] != null && (h[n[p]] = l);
                continue
            }
            var d = m.v;
            switch (m.t) {
                case "z":
                    if (d == null) break;
                    continue;
                case "e":
                    d = d == 0 ? null : void 0;
                    break;
                case "s":
                case "d":
                case "b":
                case "n":
                    break;
                default:
                    throw new Error("unrecognized type " + m.t)
            }
            if (n[p] != null) {
                if (d == null)
                    if (m.t == "e" && d === null) h[n[p]] = null;
                    else if (l !== void 0) h[n[p]] = l;
                else if (f && d === null) h[n[p]] = null;
                else continue;
                else h[n[p]] = f && (m.t !== "n" || m.t === "n" && o.rawNumbers !== !1) ? d : ta(m, d, o);
                d != null && (u = !1)
            }
        }
    return {
        row: h,
        isempty: u
    }
}

function qn(e, r) {
    if (e == null || e["!ref"] == null) return [];
    var t = {
            t: "n",
            v: 0
        },
        a = 0,
        i = 1,
        n = [],
        s = 0,
        o = "",
        c = {
            s: {
                r: 0,
                c: 0
            },
            e: {
                r: 0,
                c: 0
            }
        },
        l = r || {},
        f = l.range != null ? l.range : e["!ref"];
    switch (l.header === 1 ? a = 1 : l.header === "A" ? a = 2 : Array.isArray(l.header) ? a = 3 : l.header == null && (a = 0), typeof f) {
        case "string":
            c = Xe(f);
            break;
        case "number":
            c = Xe(e["!ref"]), c.s.r = f;
            break;
        default:
            c = f
    }
    a > 0 && (i = 0);
    var u = Tt(c.s.r),
        h = [],
        p = [],
        m = 0,
        d = 0,
        x = Array.isArray(e),
        E = c.s.r,
        S = 0,
        _ = {};
    x && !e[E] && (e[E] = []);
    var L = l.skipHidden && e["!cols"] || [],
        U = l.skipHidden && e["!rows"] || [];
    for (S = c.s.c; S <= c.e.c; ++S)
        if (!(L[S] || {}).hidden) switch (h[S] = ht(S), t = x ? e[E][S] : e[h[S] + u], a) {
            case 1:
                n[S] = S - c.s.c;
                break;
            case 2:
                n[S] = h[S];
                break;
            case 3:
                n[S] = l.header[S - c.s.c];
                break;
            default:
                if (t == null && (t = {
                        w: "__EMPTY",
                        t: "s"
                    }), o = s = ta(t, null, l), d = _[s] || 0, !d) _[s] = 1;
                else {
                    do o = s + "_" + d++; while (_[o]);
                    _[s] = d, _[o] = 1
                }
                n[S] = o
        }
    for (E = c.s.r + i; E <= c.e.r; ++E)
        if (!(U[E] || {}).hidden) {
            var R = VS(e, c, E, h, a, n, x, l);
            (R.isempty === !1 || (a === 1 ? l.blankrows !== !1 : l.blankrows)) && (p[m++] = R.row)
        }
    return p.length = m, p
}
var Jc = /"/g;

function WS(e, r, t, a, i, n, s, o) {
    for (var c = !0, l = [], f = "", u = Tt(t), h = r.s.c; h <= r.e.c; ++h)
        if (a[h]) {
            var p = o.dense ? (e[t] || [])[h] : e[a[h] + u];
            if (p == null) f = "";
            else if (p.v != null) {
                c = !1, f = "" + (o.rawNumbers && p.t == "n" ? p.v : ta(p, null, o));
                for (var m = 0, d = 0; m !== f.length; ++m)
                    if ((d = f.charCodeAt(m)) === i || d === n || d === 34 || o.forceQuotes) {
                        f = '"' + f.replace(Jc, '""') + '"';
                        break
                    }
                f == "ID" && (f = '"ID"')
            } else p.f != null && !p.F ? (c = !1, f = "=" + p.f, f.indexOf(",") >= 0 && (f = '"' + f.replace(Jc, '""') + '"')) : f = "";
            l.push(f)
        }
    return o.blankrows === !1 && c ? null : l.join(s)
}

function D0(e, r) {
    var t = [],
        a = r ? ? {};
    if (e == null || e["!ref"] == null) return "";
    var i = Xe(e["!ref"]),
        n = a.FS !== void 0 ? a.FS : ",",
        s = n.charCodeAt(0),
        o = a.RS !== void 0 ? a.RS : `
`,
        c = o.charCodeAt(0),
        l = new RegExp((n == "|" ? "\\|" : n) + "+$"),
        f = "",
        u = [];
    a.dense = Array.isArray(e);
    for (var h = a.skipHidden && e["!cols"] || [], p = a.skipHidden && e["!rows"] || [], m = i.s.c; m <= i.e.c; ++m)(h[m] || {}).hidden || (u[m] = ht(m));
    for (var d = 0, x = i.s.r; x <= i.e.r; ++x)(p[x] || {}).hidden || (f = WS(e, i, x, u, s, c, n, a), f != null && (a.strip && (f = f.replace(l, "")), (f || a.blankrows !== !1) && t.push((d++ ? o : "") + f)));
    return delete a.dense, t.join("")
}

function Qf(e, r) {
    r || (r = {}), r.FS = "	", r.RS = `
`;
    var t = D0(e, r);
    if (typeof Ye > "u" || r.type == "string") return t;
    var a = Ye.utils.encode(1200, t, "str");
    return "\xFF\xFE" + a
}

function HS(e) {
    var r = "",
        t, a = "";
    if (e == null || e["!ref"] == null) return [];
    var i = Xe(e["!ref"]),
        n = "",
        s = [],
        o, c = [],
        l = Array.isArray(e);
    for (o = i.s.c; o <= i.e.c; ++o) s[o] = ht(o);
    for (var f = i.s.r; f <= i.e.r; ++f)
        for (n = Tt(f), o = i.s.c; o <= i.e.c; ++o)
            if (r = s[o] + n, t = l ? (e[f] || [])[o] : e[r], a = "", t !== void 0) {
                if (t.F != null) {
                    if (r = t.F, !t.f) continue;
                    a = t.f, r.indexOf(":") == -1 && (r = r + ":" + r)
                }
                if (t.f != null) a = t.f;
                else {
                    if (t.t == "z") continue;
                    if (t.t == "n" && t.v != null) a = "" + t.v;
                    else if (t.t == "b") a = t.v ? "TRUE" : "FALSE";
                    else if (t.w !== void 0) a = "'" + t.w;
                    else {
                        if (t.v === void 0) continue;
                        t.t == "s" ? a = "'" + t.v : a = "" + t.v
                    }
                }
                c[c.length] = r + "=" + a
            }
    return c
}

function eu(e, r, t) {
    var a = t || {},
        i = +!a.skipHeader,
        n = e || {},
        s = 0,
        o = 0;
    if (n && a.origin != null)
        if (typeof a.origin == "number") s = a.origin;
        else {
            var c = typeof a.origin == "string" ? pt(a.origin) : a.origin;
            s = c.r, o = c.c
        }
    var l, f = {
        s: {
            c: 0,
            r: 0
        },
        e: {
            c: o,
            r: s + r.length - 1 + i
        }
    };
    if (n["!ref"]) {
        var u = Xe(n["!ref"]);
        f.e.c = Math.max(f.e.c, u.e.c), f.e.r = Math.max(f.e.r, u.e.r), s == -1 && (s = u.e.r + 1, f.e.r = s + r.length - 1 + i)
    } else s == -1 && (s = 0, f.e.r = r.length - 1 + i);
    var h = a.header || [],
        p = 0;
    r.forEach(function(d, x) {
        vt(d).forEach(function(E) {
            (p = h.indexOf(E)) == -1 && (h[p = h.length] = E);
            var S = d[E],
                _ = "z",
                L = "",
                U = Me({
                    c: o + p,
                    r: s + x + i
                });
            l = Zi(n, U), S && typeof S == "object" && !(S instanceof Date) ? n[U] = S : (typeof S == "number" ? _ = "n" : typeof S == "boolean" ? _ = "b" : typeof S == "string" ? _ = "s" : S instanceof Date ? (_ = "d", a.cellDates || (_ = "n", S = Ot(S)), L = a.dateNF || Ie[14]) : S === null && a.nullError && (_ = "e", S = 0), l ? (l.t = _, l.v = S, delete l.w, delete l.R, L && (l.z = L)) : n[U] = l = {
                t: _,
                v: S
            }, L && (l.z = L))
        })
    }), f.e.c = Math.max(f.e.c, o + h.length - 1);
    var m = Tt(s);
    if (i)
        for (p = 0; p < h.length; ++p) n[ht(p + o) + m] = {
            t: "s",
            v: h[p]
        };
    return n["!ref"] = Ne(f), n
}

function GS(e, r) {
    return eu(null, e, r)
}

function Zi(e, r, t) {
    if (typeof r == "string") {
        if (Array.isArray(e)) {
            var a = pt(r);
            return e[a.r] || (e[a.r] = []), e[a.r][a.c] || (e[a.r][a.c] = {
                t: "z"
            })
        }
        return e[r] || (e[r] = {
            t: "z"
        })
    }
    return typeof r != "number" ? Zi(e, Me(r)) : Zi(e, Me({
        r,
        c: t || 0
    }))
}

function zS(e, r) {
    if (typeof r == "number") {
        if (r >= 0 && e.SheetNames.length > r) return r;
        throw new Error("Cannot find sheet # " + r)
    } else if (typeof r == "string") {
        var t = e.SheetNames.indexOf(r);
        if (t > -1) return t;
        throw new Error("Cannot find sheet name |" + r + "|")
    } else throw new Error("Cannot find sheet |" + r + "|")
}

function R0() {
    return {
        SheetNames: [],
        Sheets: {}
    }
}

function P0(e, r, t, a) {
    var i = 1;
    if (!t)
        for (; i <= 65535 && e.SheetNames.indexOf(t = "Sheet" + i) != -1; ++i, t = void 0);
    if (!t || e.SheetNames.length >= 65535) throw new Error("Too many worksheets");
    if (a && e.SheetNames.indexOf(t) >= 0) {
        var n = t.match(/(^.*?)(\d+)$/);
        i = n && +n[2] || 0;
        var s = n && n[1] || t;
        for (++i; i <= 65535 && e.SheetNames.indexOf(t = s + i) != -1; ++i);
    }
    if (Bf(t), e.SheetNames.indexOf(t) >= 0) throw new Error("Worksheet with name |" + t + "| already exists!");
    return e.SheetNames.push(t), e.Sheets[t] = r, t
}

function XS(e, r, t) {
    e.Workbook || (e.Workbook = {}), e.Workbook.Sheets || (e.Workbook.Sheets = []);
    var a = zS(e, r);
    switch (e.Workbook.Sheets[a] || (e.Workbook.Sheets[a] = {}), t) {
        case 0:
        case 1:
        case 2:
            break;
        default:
            throw new Error("Bad sheet visibility setting " + t)
    }
    e.Workbook.Sheets[a].Hidden = t
}

function qS(e, r) {
    return e.z = r, e
}

function tu(e, r, t) {
    return r ? (e.l = {
        Target: r
    }, t && (e.l.Tooltip = t)) : delete e.l, e
}

function jS(e, r, t) {
    return tu(e, "#" + r, t)
}

function $S(e, r, t) {
    e.c || (e.c = []), e.c.push({
        t: r,
        a: t || "SheetJS"
    })
}

function YS(e, r, t, a) {
    for (var i = typeof r != "string" ? r : Xe(r), n = typeof r == "string" ? r : Ne(r), s = i.s.r; s <= i.e.r; ++s)
        for (var o = i.s.c; o <= i.e.c; ++o) {
            var c = Zi(e, s, o);
            c.t = "n", c.F = n, delete c.v, s == i.s.r && o == i.s.c && (c.f = t, a && (c.D = !0))
        }
    return e
}
var jr = {
    encode_col: ht,
    encode_row: Tt,
    encode_cell: Me,
    encode_range: Ne,
    decode_col: f0,
    decode_row: l0,
    split_cell: oh,
    decode_cell: pt,
    decode_range: or,
    format_cell: ta,
    sheet_add_aoa: Al,
    sheet_add_json: eu,
    sheet_add_dom: qf,
    aoa_to_sheet: di,
    json_to_sheet: GS,
    table_to_sheet: jf,
    table_to_book: aS,
    sheet_to_csv: D0,
    sheet_to_txt: Qf,
    sheet_to_json: qn,
    sheet_to_html: Xf,
    sheet_to_formulae: HS,
    sheet_to_row_object_array: qn,
    sheet_get_cell: Zi,
    book_new: R0,
    book_append_sheet: P0,
    book_set_sheet_visibility: XS,
    cell_set_number_format: qS,
    cell_set_hyperlink: tu,
    cell_set_internal_link: jS,
    cell_add_comment: $S,
    sheet_set_array_formula: YS,
    consts: {
        SHEET_VISIBLE: 0,
        SHEET_HIDDEN: 1,
        SHEET_VERY_HIDDEN: 2
    }
};
var bT = Ui.version;
var pi = (() => {
    class e {
        constructor() {
            this.apiService = De(mo), this.tenantService = De(Or), this.nativeFileService = De(vn)
        }
        getFieldDisplayLabel(t) {
            return t === "gst_number" && !this.tenantService.isIndia() ? pe("vat_number") : pe(t)
        }
        downloadSampleCSV(t) {
            return Qt(this, null, function*() {
                let a = Et[t],
                    i = a.fields.map(c => c.label),
                    n = a.fields.map(c => c.sampleValue),
                    s = [i.join(","), n.map(c => typeof c == "string" && c.includes(",") ? `"${c}"` : c).join(",")].join(`
`),
                    o = new Blob([s], {
                        type: "text/csv;charset=utf-8;"
                    });
                yield this.nativeFileService.downloadFile(o, `${t}_import_sample.csv`)
            })
        }
        downloadSampleExcel(t) {
            return Qt(this, null, function*() {
                let a = Et[t],
                    i = jr.book_new(),
                    n = a.fields.map(u => u.label),
                    s = a.fields.map(u => u.sampleValue),
                    o = [n, s],
                    c = jr.aoa_to_sheet(o);
                c["!cols"] = a.fields.map(() => ({
                    wch: 20
                })), jr.book_append_sheet(i, c, "Sample");
                let l = on(i, {
                        bookType: "xlsx",
                        type: "array"
                    }),
                    f = new Blob([l], {
                        type: "application/octet-stream"
                    });
                yield this.nativeFileService.downloadFile(f, `${t}_import_sample.xlsx`)
            })
        }
        validateImportData(t, a) {
            return this.apiService.post(`${Si}/validate`, {
                type: a,
                data: t
            })
        }
        executeImport(t) {
            if (!t.type) throw new Error("Import type is required");
            if (!t.file) throw new Error("File is required");
            if (!t.mappings || t.mappings.length === 0) throw new Error("Field mappings are required");
            let a = Et[t.type],
                i = new FormData;
            return i.append("file", t.file, t.file.name), i.append("mappings", JSON.stringify(t.mappings)), t.defaults && Object.keys(t.defaults).length > 0 && i.append("defaults", JSON.stringify(t.defaults)), this.apiService.uploadFormData(a.apiPath, i)
        }
        getImportHistory(t) {
            return this.apiService.getWithParams(Si, t)
        }
        getImportDetails(t) {
            return this.apiService.get(`${Si}/${t}`)
        }
        deleteImport(t) {
            return this.apiService.delete(`${Si}/${t}`)
        }
        getFieldConfigurations(t) {
            return this.apiService.get(`import/fields/${t}`)
        }
        getAllFieldConfigurations() {
            return this.apiService.get("import/fields")
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var L0 = Vo;
var KS = () => ["name", "display_name", "id"],
    JS = e => ({
        placeholder: e,
        showClearButton: !0
    });

function ZS(e, r) {
    if (e & 1 && (I(0, "div", 7)(1, "div", 8)(2, "span", 9), q(3), D()(), I(4, "p", 10), q(5), D()()), e & 2) {
        let t = te();
        k(3), ge(t.formatMessage("loading")), k(2), ge(t.formatMessage("loading_reference_data"))
    }
}

function QS(e, r) {
    if (e & 1 && (I(0, "div")(1, "div", 17)(2, "div", 18), ae(3, "i"), D(), I(4, "div", 19)(5, "div", 20), q(6), D(), I(7, "div", 21), q(8), D()()()()), e & 2) {
        let t = r.$implicit,
            a = te(2);
        k(2), ls("background-color", t.iconColor + "20"), k(), oa(t.icon), ls("color", t.iconColor), k(3), ge(t.title), k(2), rt("", t.count, " ", a.formatMessage("values_available"))
    }
}

function eE(e, r) {
    if (e & 1 && (I(0, "span", 29), q(1), D()), e & 2) {
        let t = te().$implicit;
        k(), Fe(" ", t.value, "%")
    }
}

function tE(e, r) {
    if (e & 1 && (I(0, "div", 31), q(1), D()), e & 2) {
        let t = te().$implicit;
        k(), ge(t.description)
    }
}

function rE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div")(1, "div", 24), it("click", function() {
            let i = qe(t).$implicit,
                n = te(4);
            return je(n.copyToClipboard(i, "name"))
        }), I(2, "div", 25)(3, "div", 26)(4, "span", 27), q(5), D(), I(6, "span", 28), q(7), ve(8, eE, 2, 1, "span", 29), D()(), ae(9, "i", 30), D(), ve(10, tE, 2, 1, "div", 31), D()()
    }
    if (e & 2) {
        let t = r.$implicit,
            a = te(4);
        k(5), ge(t.id), k(2), Fe(" ", a.getItemName(t), " "), k(), we(a.hasTaxValue(t) ? 8 : -1), k(2), we(t.description ? 10 : -1)
    }
}

function aE(e, r) {
    if (e & 1 && (I(0, "div", 22)(1, "dx-list", 23), os(2, rE, 11, 4, "div", 13), D()()), e & 2) {
        let t = te().$implicit,
            a = te(2);
        k(), Ce("dataSource", t.items)("searchEnabled", !0)("searchExpr", qa(7, KS))("searchMode", "contains")("searchEditorOptions", ja(8, JS, a.formatMessage("search_reference_values")))("showScrollbar", "onScroll"), k(), Ce("dxTemplateOf", "itemTemplate")
    }
}

function iE(e, r) {
    if (e & 1 && (I(0, "div"), ve(1, aE, 3, 10, "div", 22), D()), e & 2) {
        let t = r.$implicit;
        k(), we(t.items.length > 0 ? 1 : -1)
    }
}

function nE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 11)(1, "dx-accordion", 12), ir("selectedItemsChange", function(i) {
            qe(t);
            let n = te();
            return ar(n.selectedItems, i) || (n.selectedItems = i), je(i)
        }), os(2, QS, 9, 9, "div", 13)(3, iE, 2, 1, "div", 13), D()(), I(4, "div", 14), ae(5, "i", 15), I(6, "strong"), q(7), D(), I(8, "span", 16), q(9), D()()
    }
    if (e & 2) {
        let t = te();
        k(), Ce("dataSource", t.accordionItems)("collapsible", !0)("multiple", !0)("animationDuration", 300), rr("selectedItems", t.selectedItems), k(), Ce("dxTemplateOf", "titleTemplate"), k(), Ce("dxTemplateOf", "contentTemplate"), k(4), Fe("", t.formatMessage("tip"), ":"), k(2), ge(t.formatMessage("click_value_to_copy_tip"))
    }
}
var as = (() => {
    class e {
        constructor() {
            this.importType = null, this.partCategoryService = De(ms), this.partSubCategoryService = De(_s), this.taxService = De(xs), this.storageLocationService = De(gs), this.roleService = De(Ci), this.dataService = De(Ti), this.leadStatusService = De(yi), this.tenantService = De(Or), this.isLoading = !0, this.accordionItems = [], this.selectedItems = [], this.formatMessage = pe, this.ImportType = be
        }
        ngOnInit() {
            this.loadReferenceData()
        }
        loadReferenceData() {
            switch (this.isLoading = !0, this.importType) {
                case be.CUSTOMER:
                    this.loadCustomerData();
                    break;
                case be.EMPLOYEE:
                    this.loadEmployeeData();
                    break;
                case be.LEAD:
                    this.loadLeadData();
                    break;
                case be.PART:
                    this.loadPartData();
                    break;
                default:
                    this.isLoading = !1
            }
        }
        loadCustomerData() {
            za({
                lookups: this.dataService.getLookups(),
                roles: this.roleService.getCustomerRoles()
            }).subscribe({
                next: t => {
                    this.accordionItems = [{
                        id: "sources",
                        title: pe("source"),
                        icon: "fa-light fa-tags",
                        iconColor: "#3b82f6",
                        count: t.lookups.job_sources ? .length || 0,
                        items: t.lookups.job_sources || []
                    }, {
                        id: "roles",
                        title: pe("user_type"),
                        icon: "fa-light fa-user-shield",
                        iconColor: "#10b981",
                        count: t.roles ? .length || 0,
                        items: t.roles || []
                    }], this.selectedItems = [], this.isLoading = !1
                },
                error: t => {
                    console.error("Error loading customer data:", t), this.isLoading = !1
                }
            })
        }
        loadEmployeeData() {
            this.roleService.getEmployeeRoles().subscribe({
                next: t => {
                    this.accordionItems = [{
                        id: "roles",
                        title: pe("available_roles"),
                        icon: "fa-light fa-user-shield",
                        iconColor: "#3b82f6",
                        count: t ? .length || 0,
                        items: t || []
                    }], this.selectedItems = [], this.isLoading = !1
                },
                error: t => {
                    console.error("Error loading employee data:", t), this.isLoading = !1
                }
            })
        }
        loadLeadData() {
            za({
                lookups: this.dataService.getLookups(),
                roles: this.roleService.getCustomerRoles(),
                statuses: this.leadStatusService.getListByQuery()
            }).subscribe({
                next: t => {
                    let a = t.lookups.lead_sources || t.lookups.job_sources || [];
                    this.accordionItems = [{
                        id: "sources",
                        title: pe("lead_source"),
                        icon: "fa-light fa-tags",
                        iconColor: "#f59e0b",
                        count: a.length,
                        items: a
                    }, {
                        id: "roles",
                        title: pe("role"),
                        icon: "fa-light fa-user-shield",
                        iconColor: "#10b981",
                        count: t.roles ? .length || 0,
                        items: t.roles || []
                    }, {
                        id: "statuses",
                        title: pe("status"),
                        icon: "fa-light fa-circle-check",
                        iconColor: "#3b82f6",
                        count: t.statuses ? .length || 0,
                        items: t.statuses || []
                    }], this.selectedItems = [], this.isLoading = !1
                },
                error: t => {
                    console.error("Error loading lead data:", t), this.isLoading = !1
                }
            })
        }
        loadPartData() {
            za({
                categories: this.partCategoryService.getAll(),
                subCategories: this.partSubCategoryService.getAll(),
                taxes: this.taxService.getAll(),
                storageLocations: this.storageLocationService.getListByQuery({})
            }).subscribe({
                next: t => {
                    let a = t.storageLocations ? .data || t.storageLocations || [];
                    this.accordionItems = [{
                        id: "categories",
                        title: pe("part_categories"),
                        icon: "fa-light fa-layer-group",
                        iconColor: "#a855f7",
                        count: t.categories ? .length || 0,
                        items: t.categories || []
                    }, {
                        id: "subCategories",
                        title: pe("part_sub_categories"),
                        icon: "fa-light fa-sitemap",
                        iconColor: "#ec4899",
                        count: t.subCategories ? .length || 0,
                        items: t.subCategories || []
                    }, {
                        id: "taxes",
                        title: this.tenantService.isIndia() ? `${pe("taxes")} (${pe("gst")})` : pe("taxes"),
                        icon: "fa-light fa-percent",
                        iconColor: "#3b82f6",
                        count: t.taxes ? .length || 0,
                        items: t.taxes || []
                    }, {
                        id: "storageLocations",
                        title: pe("storage_locations"),
                        icon: "fa-light fa-warehouse",
                        iconColor: "#10b981",
                        count: a.length,
                        items: a
                    }], this.selectedItems = [], this.isLoading = !1
                },
                error: t => {
                    console.error("Error loading part data:", t), this.isLoading = !1
                }
            })
        }
        copyToClipboard(t, a) {
            let i = a === "id" ? String(t.id) : this.getItemName(t);
            if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(i).then(() => {
                L0(pe("copied_to_clipboard"), "success", 1500)
            });
            else {
                let n = document.createElement("textarea");
                n.value = i, n.style.position = "fixed", n.style.left = "-999999px", document.body.appendChild(n), n.select();
                try {
                    document.execCommand("copy"), L0(pe("copied_to_clipboard"), "success", 1500)
                } catch (s) {
                    console.error("Failed to copy:", s)
                }
                document.body.removeChild(n)
            }
        }
        getItemName(t) {
            return "display_name" in t ? t.display_name || t.name || "" : t.name || ""
        }
        hasTaxValue(t) {
            return "rate" in t
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-quick-reference-guide"]
                ],
                inputs: {
                    importType: "importType"
                },
                decls: 11,
                vars: 4,
                consts: [
                    [1, "quick-reference-guide"],
                    [1, "gradient-header"],
                    [1, "header-icon"],
                    [1, "fa-light", "fa-circle-info"],
                    [1, "header-content"],
                    [1, "mb-1"],
                    [1, "mb-0"],
                    [1, "text-center", "py-5"],
                    ["role", "status", 1, "spinner-border", "text-primary"],
                    [1, "visually-hidden"],
                    [1, "small", "text-muted", "mt-3", "mb-0"],
                    [1, "accordion-container"],
                    ["itemTitleTemplate", "titleTemplate", "itemTemplate", "contentTemplate", 3, "selectedItemsChange", "dataSource", "collapsible", "multiple", "animationDuration", "selectedItems"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "tip-footer"],
                    [1, "fa-light", "fa-lightbulb", "me-2"],
                    [1, "ms-1"],
                    [1, "accordion-title"],
                    [1, "icon-container"],
                    [1, "title-content"],
                    [1, "title-text"],
                    [1, "title-count"],
                    [1, "accordion-content"],
                    ["itemTemplate", "itemTemplate", 3, "dataSource", "searchEnabled", "searchExpr", "searchMode", "searchEditorOptions", "showScrollbar"],
                    [1, "card-with-selection", 3, "click"],
                    [1, "item-header"],
                    [1, "item-main"],
                    [1, "item-id"],
                    [1, "item-name"],
                    [1, "tax-value"],
                    [1, "fa-light", "fa-copy", "copy-icon"],
                    [1, "item-description"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1)(2, "div", 2), ae(3, "i", 3), D(), I(4, "div", 4)(5, "h5", 5), q(6), D(), I(7, "p", 6), q(8), D()()(), ve(9, ZS, 6, 2, "div", 7), ve(10, nE, 10, 9), D()), a & 2 && (k(6), ge(i.formatMessage("quick_reference_guide")), k(2), ge(i.formatMessage("available_values_for_import")), k(), we(i.isLoading ? 9 : -1), k(), we(i.isLoading ? -1 : 10))
                },
                dependencies: [bo, Ao, vo, yo, Fo, ko],
                styles: [".quick-reference-guide[_ngcontent-%COMP%]{display:flex;flex-direction:column;max-height:450px;background:var(--primary-bg);border-radius:8px;overflow:hidden;border:1px solid var(--bs-border-color, #dee2e6)}.quick-reference-guide[_ngcontent-%COMP%]   .gradient-header[_ngcontent-%COMP%]{background:linear-gradient(135deg,#3b82f6,#8b5cf6);padding:1rem;display:flex;align-items:flex-start;gap:.75rem}.quick-reference-guide[_ngcontent-%COMP%]   .gradient-header[_ngcontent-%COMP%]   .header-icon[_ngcontent-%COMP%]{width:2.5rem;height:2.5rem;background:#fff3;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}.quick-reference-guide[_ngcontent-%COMP%]   .gradient-header[_ngcontent-%COMP%]   .header-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem;color:#fff}.quick-reference-guide[_ngcontent-%COMP%]   .gradient-header[_ngcontent-%COMP%]   .header-content[_ngcontent-%COMP%]{flex:1;color:#fff}.quick-reference-guide[_ngcontent-%COMP%]   .gradient-header[_ngcontent-%COMP%]   .header-content[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{font-size:.9rem;font-weight:700;margin:0;color:#fff}.quick-reference-guide[_ngcontent-%COMP%]   .gradient-header[_ngcontent-%COMP%]   .header-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.75rem;opacity:.95;margin:0}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-container[_ngcontent-%COMP%]{flex:1;overflow-y:auto;padding:.75rem;background:var(--bg-secondary)}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-title[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.5rem;padding:.25rem .75rem .25rem 0}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-title[_ngcontent-%COMP%]   .icon-container[_ngcontent-%COMP%]{width:1.75rem;height:1.75rem;border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-title[_ngcontent-%COMP%]   .icon-container[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.8rem}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-title[_ngcontent-%COMP%]   .title-content[_ngcontent-%COMP%]{flex:1;display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-title[_ngcontent-%COMP%]   .title-content[_ngcontent-%COMP%]   .title-text[_ngcontent-%COMP%]{font-size:.8rem;font-weight:600;color:var(--primary-text);line-height:1.2;margin:0;padding:0}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-title[_ngcontent-%COMP%]   .title-content[_ngcontent-%COMP%]   .title-count[_ngcontent-%COMP%]{font-size:.7rem;color:var(--primary-text);opacity:.7;margin:.05rem 0 0;padding:0;line-height:1.2}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-content[_ngcontent-%COMP%]{padding:.5rem .75rem}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-content[_ngcontent-%COMP%]     .dx-list{border:none;background:transparent;max-height:250px;overflow-y:auto}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-content[_ngcontent-%COMP%]     .dx-list .dx-list-item{border:none;padding:0;margin-bottom:.5rem;background:transparent}.quick-reference-guide[_ngcontent-%COMP%]   .accordion-content[_ngcontent-%COMP%]     .dx-list .dx-list-item:last-child{margin-bottom:0}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:.75rem}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-header[_ngcontent-%COMP%]   .item-main[_ngcontent-%COMP%]{flex:1;display:flex;align-items:center;gap:.4rem;flex-wrap:wrap}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-header[_ngcontent-%COMP%]   .item-main[_ngcontent-%COMP%]   .item-id[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600;color:#3b82f6;text-transform:uppercase}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-header[_ngcontent-%COMP%]   .item-main[_ngcontent-%COMP%]   .item-name[_ngcontent-%COMP%]{font-size:.875rem;font-weight:500;color:var(--primary-text)}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-header[_ngcontent-%COMP%]   .item-main[_ngcontent-%COMP%]   .item-name[_ngcontent-%COMP%]   .tax-value[_ngcontent-%COMP%]{color:var(--primary-text)}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-header[_ngcontent-%COMP%]   .copy-icon[_ngcontent-%COMP%]{font-size:.875rem;color:#6b7280;flex-shrink:0;transition:color .2s ease}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]:hover   .copy-icon[_ngcontent-%COMP%]{color:#3b82f6}.quick-reference-guide[_ngcontent-%COMP%]   .card-with-selection[_ngcontent-%COMP%]   .item-description[_ngcontent-%COMP%]{font-size:.8rem;color:var(--primary-text);opacity:.6;margin-top:.4rem;line-height:1.4}.quick-reference-guide[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]{text-align:center;padding:2rem 1rem}.quick-reference-guide[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{display:block;margin-bottom:.5rem;color:var(--primary-text);opacity:.5}.quick-reference-guide[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.875rem;color:var(--primary-text);opacity:.7}.quick-reference-guide[_ngcontent-%COMP%]   .tip-footer[_ngcontent-%COMP%]{background:#fef3c7;border-top:1px solid #fde68a;padding:.65rem 1rem;font-size:.8rem;color:#92400e;display:flex;align-items:center}.quick-reference-guide[_ngcontent-%COMP%]   .tip-footer[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.9rem;color:#d97706}.quick-reference-guide[_ngcontent-%COMP%]   .tip-footer[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:#78350f}"]
            })
        }
    }
    return e
})();
var ru = (e, r) => r.key;

function oE(e, r) {
    if (e & 1 && (I(0, "div", 1)(1, "h6", 4), ae(2, "i", 5), q(3), D()()), e & 2) {
        let t = te(2);
        k(3), Fe(" ", t.formatMessage("field_requirements"), " ")
    }
}

function cE(e, r) {
    if (e & 1 && (I(0, "div", 9), ae(1, "i", 12), I(2, "small"), q(3), D()()), e & 2) {
        let t = te(3);
        k(3), ge(t.formatMessage("email_or_mobile_required"))
    }
}

function lE(e, r) {
    e & 1 && (I(0, "span"), q(1, ", "), D())
}

function fE(e, r) {
    if (e & 1 && (I(0, "span", 11), q(1), ve(2, lE, 2, 0, "span"), D()), e & 2) {
        let t = r.$implicit,
            a = r.$index,
            i = r.$count,
            n = te(3);
        k(), ge(n.getFieldLabel(t.label)), k(), we(a !== i - 1 ? 2 : -1)
    }
}

function uE(e, r) {
    if (e & 1 && (I(0, "div", 2)(1, "h6", 6), ae(2, "i", 7), q(3), I(4, "span", 8), q(5), D()(), ve(6, cE, 4, 1, "div", 9), I(7, "div", 10), vr(8, fE, 3, 2, "span", 11, ru), D()()), e & 2) {
        let t = te(2);
        k(3), Fe(" ", t.formatMessage("required_fields"), " "), k(2), Fe("(", t.displayRequiredFields.length, ")"), k(), we(t.hasEitherOrRequirement ? 6 : -1), k(2), wr(t.displayRequiredFields)
    }
}

function dE(e, r) {
    e & 1 && (I(0, "span"), q(1, ", "), D())
}

function hE(e, r) {
    if (e & 1 && (I(0, "span", 11), q(1), ve(2, dE, 2, 0, "span"), D()), e & 2) {
        let t = r.$implicit,
            a = r.$index,
            i = r.$count,
            n = te(3);
        k(), ge(n.getFieldLabel(t.label)), k(), we(a !== i - 1 ? 2 : -1)
    }
}

function pE(e, r) {
    if (e & 1 && (I(0, "div", 3)(1, "h6", 6), ae(2, "i", 13), q(3), I(4, "span", 8), q(5), D()(), I(6, "div", 10), vr(7, hE, 3, 2, "span", 11, ru), D()()), e & 2) {
        let t = te(2);
        k(3), Fe(" ", t.formatMessage("optional_fields"), " "), k(2), Fe("(", t.optionalFields.length, ")"), k(2), wr(t.optionalFields)
    }
}

function mE(e, r) {
    if (e & 1 && (I(0, "div", 0), ve(1, oE, 4, 1, "div", 1), ve(2, uE, 10, 3, "div", 2), ve(3, pE, 9, 2, "div", 3), D()), e & 2) {
        let t = te();
        k(), we(t.showHeader ? 1 : -1), k(), we(t.displayRequiredFields.length > 0 ? 2 : -1), k(), we(t.optionalFields.length > 0 ? 3 : -1)
    }
}
var au = (() => {
    class e {
        constructor() {
            this.config = null, this.showHeader = !0, this.compact = !1, this.tenantService = De(Or), this.formatMessage = pe
        }
        getFieldLabel(t) {
            return t === "gst_number" && !this.tenantService.isIndia() ? pe("vat_number") : t === "tax_code" && this.tenantService.isIndia() ? pe("hsn_code") : pe(t)
        }
        get requiredFields() {
            return this.config ? this.config.fields.filter(t => t.required) : []
        }
        get displayRequiredFields() {
            if (!this.config) return [];
            let t = this.config.fields.filter(a => a.required);
            return this.hasEitherOrRequirement ? [...t.filter(i => i.key !== "email" && i.key !== "mobile_number").map(i => ({
                key: i.key,
                label: i.label,
                unique: i.unique
            })), {
                key: "email_or_mobile",
                label: "email_or_mobile_number",
                unique: !1
            }] : t.map(a => ({
                key: a.key,
                label: a.label,
                unique: a.unique
            }))
        }
        get optionalFields() {
            if (!this.config) return [];
            let t = this.config.fields.filter(a => !a.required);
            return this.hasEitherOrRequirement && (t = t.filter(a => a.key !== "email" && a.key !== "mobile_number")), t
        }
        get uniqueFields() {
            return this.config ? this.config.fields.filter(t => t.unique) : []
        }
        get hasEitherOrRequirement() {
            return this.config ? this.config.key === "customer" || this.config.key === "lead" : !1
        }
        getValidationHint(t) {
            if (!t.validations || t.validations.length === 0) return null;
            let a = [];
            return t.validations.forEach(i => {
                switch (i.type) {
                    case "maxLength":
                        a.push(`${pe("max_length")}: ${i.value}`);
                        break;
                    case "minLength":
                        a.push(`${pe("min_length")}: ${i.value}`);
                        break;
                    case "email":
                        a.push(pe("must_be_valid_email"));
                        break;
                    case "phone":
                        a.push(pe("must_be_valid_phone"));
                        break;
                    case "number":
                        a.push(pe("must_be_number"));
                        break;
                    case "date":
                        a.push(pe("must_be_valid_date"));
                        break
                }
            }), a.length > 0 ? a.join(", ") : null
        }
        getDataTypeBadgeClass(t) {
            return {
                string: "badge-info",
                number: "badge-success",
                boolean: "badge-warning",
                date: "badge-primary"
            }[t] || "badge-secondary"
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-field-requirements-info"]
                ],
                inputs: {
                    config: "config",
                    showHeader: "showHeader",
                    compact: "compact"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [1, "field-requirements-container"],
                    [1, "requirements-header", "mb-3"],
                    [1, "requirements-section", "mb-3"],
                    [1, "requirements-section"],
                    [1, "mb-0"],
                    [1, "fa-thin", "fa-clipboard-list-check", "me-2"],
                    [1, "mb-3"],
                    [1, "fa-solid", "fa-asterisk", "text-danger", "me-2", 2, "font-size", "0.75rem"],
                    [1, "ms-2"],
                    [1, "alert", "alert-warning", "py-1", "px-2", "mb-2"],
                    [1, "field-list-inline"],
                    [1, "field-inline"],
                    [1, "fa-thin", "fa-circle-info", "me-1"],
                    [1, "fa-solid", "fa-circle", "text-secondary", "me-2", 2, "font-size", "0.5rem"]
                ],
                template: function(a, i) {
                    a & 1 && ve(0, mE, 4, 3, "div", 0), a & 2 && we(i.config ? 0 : -1)
                },
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   h6[_ngcontent-%COMP%]{display:flex;align-items:center;font-size:1rem;font-weight:600}[_nghost-%COMP%]   .field-list-inline[_ngcontent-%COMP%]{display:block;font-size:.875rem;line-height:1.6;text-align:left;padding-left:0}[_nghost-%COMP%]   .field-list-inline[_ngcontent-%COMP%]   .field-inline[_ngcontent-%COMP%]{display:inline;font-weight:400}[_nghost-%COMP%]   .field-list-inline[_ngcontent-%COMP%]   .field-inline[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%]{font-size:.65rem;padding:2px 5px;vertical-align:middle}"]
            })
        }
    }
    return e
})();
var _E = e => ({
    rows: e
});

function vE(e, r) {
    if (e & 1 && (I(0, "p", 4), q(1), D()), e & 2) {
        let t = te();
        k(), Fe(" ", t.formatMessage("upload_file_description").replace("{size}", t.currentConfig.maxFileSize + "MB"), " ")
    }
}

function wE(e, r) {
    if (e & 1 && (I(0, "div", 21), ae(1, "app-quick-reference-guide", 22), D()), e & 2) {
        let t = te(2);
        k(), Ce("importType", t.importData.type)
    }
}

function SE(e, r) {
    if (e & 1 && (I(0, "div", 6)(1, "div", 10)(2, "div", 11)(3, "div", 12)(4, "div", 13)(5, "div", 14)(6, "h6", 15), ae(7, "i", 16), q(8), D(), I(9, "ul", 17)(10, "li", 3)(11, "strong"), q(12), D(), I(13, "span", 18), q(14), D()(), I(15, "li", 3)(16, "strong"), q(17), D(), I(18, "span", 18), q(19), D()(), I(20, "li")(21, "strong"), q(22), D(), I(23, "span", 18), q(24), D()()()()(), I(25, "div", 19), ae(26, "app-field-requirements-info", 20), D(), ve(27, wE, 2, 1, "div", 21), D()()()()), e & 2) {
        let t = te();
        k(8), Fe(" ", t.formatMessage("file_requirements"), " "), k(4), Fe("", t.formatMessage("formats"), ":"), k(2), ge(t.currentConfig.supportedFormats.join(", ").toUpperCase()), k(3), Fe("", t.formatMessage("max_file_size"), ":"), k(2), Fe("", t.currentConfig.maxFileSize, "MB"), k(3), Fe("", t.formatMessage("max_rows"), ":"), k(2), rt("", t.currentConfig.maxRows.toLocaleString(), " ", t.formatMessage("records")), k(), tr("border-end-column", t.importData.type === t.ImportType.CUSTOMER || t.importData.type === t.ImportType.EMPLOYEE || t.importData.type === t.ImportType.LEAD || t.importData.type === t.ImportType.PART), k(), Ce("config", t.currentConfig)("showHeader", !1)("compact", !0), k(), we(t.importData.type === t.ImportType.CUSTOMER || t.importData.type === t.ImportType.EMPLOYEE || t.importData.type === t.ImportType.LEAD || t.importData.type === t.ImportType.PART ? 27 : -1)
    }
}

function EE(e, r) {
    if (e & 1 && (I(0, "div", 28)(1, "small", 29), q(2), ae(3, "br"), q(4), D()()), e & 2) {
        let t = te(2);
        k(2), rt(" ", t.formatMessage("supported_formats"), ": ", t.currentConfig.supportedFormats.join(", ").toUpperCase(), " "), k(2), rt(" ", t.formatMessage("max_file_size"), ": ", t.currentConfig.maxFileSize, "MB ")
    }
}

function CE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 23), it("click", function() {
            qe(t);
            let i = cs(9);
            return je(i.click())
        })("drop", function(i) {
            qe(t);
            let n = te();
            return je(n.onDrop(i))
        })("dragover", function(i) {
            qe(t);
            let n = te();
            return je(n.onDragOver(i))
        })("dragleave", function(i) {
            qe(t);
            let n = te();
            return je(n.onDragLeave(i))
        }), I(1, "div", 24), ae(2, "i", 25), I(3, "h6", 3), q(4), D(), I(5, "p", 15), q(6), D(), I(7, "dx-button", 26), it("onClick", function(i) {
            qe(t);
            let n = cs(9),
                s = te();
            return je(s.onBrowseClick(i, n))
        }), D(), I(8, "input", 27, 0), it("change", function(i) {
            qe(t);
            let n = te();
            return je(n.onFileSelected(i))
        }), D(), ve(10, EE, 5, 4, "div", 28), D()()
    }
    if (e & 2) {
        let t = te();
        tr("drag-over", t.isDragOver), k(4), ge(t.formatMessage("drag_drop_file")), k(2), ge(t.formatMessage("or")), k(), Ce("text", t.formatMessage("browse_files")), k(), Ce("accept", t.fileAcceptAttribute), k(2), we(t.currentConfig ? 10 : -1)
    }
}

function TE(e, r) {
    if (e & 1 && (I(0, "span"), q(1), D()), e & 2) {
        let t = te(2);
        k(), rt(" \xB7 ", t.importData.totalRows || t.importData.data.length, " ", t.formatMessage("rows"), " ")
    }
}

function yE(e, r) {
    if (e & 1 && (I(0, "div", 35), ae(1, "dx-load-indicator", 37), I(2, "span", 18), q(3), D()()), e & 2) {
        let t = te(2);
        k(), Ce("visible", !0)("height", 30)("width", 30), k(2), ge(t.formatMessage("processing_file"))
    }
}

function kE(e, r) {
    if (e & 1 && (I(0, "div", 36), ae(1, "i", 38), q(2), D()), e & 2) {
        let t = te(2);
        k(2), Fe(" ", t.formatMessageWithParams("file_processed_success", ja(1, _E, t.importData.totalRows || t.importData.data.length)), " ")
    }
}

function FE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 9)(1, "div", 11)(2, "div", 30)(3, "div", 31), ae(4, "i", 32), I(5, "div")(6, "h6", 33), q(7), D(), I(8, "small", 29), q(9), ve(10, TE, 2, 2, "span"), D()()(), I(11, "dx-button", 34), it("onClick", function() {
            qe(t);
            let i = te();
            return je(i.removeFile())
        }), D()(), ve(12, yE, 4, 4, "div", 35), ve(13, kE, 3, 3, "div", 36), D()()
    }
    if (e & 2) {
        let t = te();
        k(7), ge(t.selectedFile.name), k(2), Fe(" ", (t.selectedFile.size / 1024).toFixed(2), " KB "), k(), we(t.importData.totalRows || t.importData.data && t.importData.data.length > 0 ? 10 : -1), k(), Ce("text", t.formatMessage("remove"))("disabled", t.isProcessing), k(), we(t.isProcessing ? 12 : -1), k(), we(!t.isProcessing && t.importData.data && t.importData.data.length > 0 ? 13 : -1)
    }
}
var iu = (() => {
    class e extends Er {
        constructor() {
            super(...arguments), this.importService = De(pi), this.userDeviceService = De(ho), this.isMobileDevice = this.userDeviceService.isMobileDevice(), this.selectedFile = null, this.isDragOver = !1, this.isProcessing = !1, this.rejectionReason = null, this.formatMessageWithParams = dt, this.ImportType = be
        }
        validateFileMimeType(t, a) {
            let n = ct.MIME_TYPES[a];
            return n ? n.includes(t.type) ? !0 : (this.toastr.error(dt("invalid_mime_type", {
                expected: n.join(", "),
                actual: t.type || "unknown"
            })), !1) : (this.toastr.error(this.formatMessage("invalid_file_format")), !1)
        }
        validateMagicNumber(t, a) {
            return Qt(this, null, function*() {
                let n = ct.MAGIC_NUMBERS[a];
                return n ? new Promise(s => {
                    let o = new FileReader,
                        c = t.slice(0, 4);
                    o.onload = l => {
                        let f = new Uint8Array(l.target.result),
                            u = n.every((h, p) => f[p] === h);
                        u || this.toastr.error(this.formatMessage("invalid_file_format_magic_number")), s(u)
                    }, o.onerror = () => {
                        this.toastr.error(this.formatMessage("file_read_error")), s(!1)
                    }, o.readAsArrayBuffer(c)
                }) : !0
            })
        }
        onFileSelected(t) {
            let a = t.target.files[0];
            a && this.processFile(a)
        }
        onDrop(t) {
            t.preventDefault(), t.stopPropagation(), this.isDragOver = !1;
            let a = t.dataTransfer ? .files;
            a && a.length > 0 && this.processFile(a[0])
        }
        onDragOver(t) {
            t.preventDefault(), t.stopPropagation(), this.isDragOver = !0
        }
        onDragLeave(t) {
            t.preventDefault(), t.stopPropagation(), this.isDragOver = !1
        }
        processFile(t) {
            return Qt(this, null, function*() {
                if (this.rejectionReason = null, !this.importData.type) {
                    this.toastr.error(this.formatMessage("select_import_type_first"));
                    return
                }
                let a = Et[this.importData.type],
                    i = t.name.split(".").pop() ? .toLowerCase();
                if (!i || !a.supportedFormats.includes(i)) {
                    this.toastr.error(dt("invalid_file_format", {
                        formats: a.supportedFormats.join(", ").toUpperCase()
                    }));
                    return
                }
                if (!this.validateFileMimeType(t, i) || !(yield this.validateMagicNumber(t, i))) return;
                let s = a.maxFileSize * 1024 * 1024;
                if (t.size > s) {
                    this.toastr.error(dt("file_too_large", {
                        size: a.maxFileSize
                    }));
                    return
                }
                this.isProcessing = !0, this.selectedFile = t;
                let o = new FileReader;
                o.onload = c => {
                    try {
                        let l = new Uint8Array(c.target.result),
                            f = Xn(l, {
                                type: "array"
                            }),
                            u = f.SheetNames[0],
                            h = f.Sheets[u],
                            p = jr.sheet_to_json(h, {
                                header: 1,
                                raw: !1,
                                defval: ""
                            });
                        if (p.length === 0) {
                            this.toastr.error(this.formatMessage("empty_file")), this.isProcessing = !1;
                            return
                        }
                        let m = p[0],
                            d = p.slice(1).filter(T => T.some(N => N != null && N !== ""));
                        if (d.length === 0) {
                            this.toastr.error(this.formatMessage("no_data_rows")), this.isProcessing = !1;
                            return
                        }
                        let x = 100,
                            E = d.slice(0, x),
                            S = d.length,
                            L = Et[this.importData.type] ? .maxRows || 2e3;
                        if (S > L) {
                            this.rejectionReason = {
                                message: "import_max_rows_exceeded",
                                params: {
                                    total: S,
                                    max: L
                                }
                            }, this.toastr.error(dt("import_max_rows_exceeded", {
                                total: S,
                                max: L
                            }), this.formatMessage("import_failed"), {
                                disableTimeOut: !0
                            }), this.isProcessing = !1;
                            return
                        }
                        this.rejectionReason = null;
                        let U = E.map(T => {
                            let N = {};
                            return m.forEach((P, X) => {
                                let j = T[X];
                                N[P] = j != null ? String(j) : ""
                            }), N
                        });
                        this.importData.file = t, this.importData.data = U, this.importData.totalRows = S;
                        let R = S > x ? dt("file_uploaded_preview", {
                            preview: U.length,
                            total: S
                        }) : dt("file_uploaded_success", {
                            rows: U.length
                        });
                        this.toastr.success(R), this.isProcessing = !1
                    } catch (l) {
                        console.error("File parsing error:", l), this.toastr.error(this.formatMessage("file_parse_error")), this.isProcessing = !1
                    }
                }, o.onerror = () => {
                    this.toastr.error(this.formatMessage("file_read_error")), this.isProcessing = !1
                }, o.readAsArrayBuffer(t)
            })
        }
        removeFile() {
            this.selectedFile = null, this.importData.file = null, this.importData.data = [], this.importData.totalRows = void 0, this.rejectionReason = null
        }
        onBrowseClick(t, a) {
            t.event ? .stopPropagation(), a.click()
        }
        downloadSample() {
            if (!this.importData.type) {
                this.toastr.error(this.formatMessage("select_import_type_first"));
                return
            }
            this.importService.downloadSampleCSV(this.importData.type), this.toastr.success(this.formatMessage("sample_file_downloaded"))
        }
        get currentConfig() {
            return this.importData.type ? Et[this.importData.type] : null
        }
        get fileAcceptAttribute() {
            return this.currentConfig ? .supportedFormats.map(t => "." + t).join(",") || ""
        }
        submit() {
            if (this.rejectionReason) return this.toastr.error(dt(this.rejectionReason.message, this.rejectionReason.params), this.formatMessage("import_failed"), {
                disableTimeOut: !0
            }), fr(!1);
            if (!this.importData.file || !this.importData.data || this.importData.data.length === 0) return this.toastr.error(this.formatMessage("upload_file_error")), fr(!1);
            let a = Et[this.importData.type] ? .maxRows || 2e3;
            return this.importData.data.length > a ? (this.toastr.error(dt("import_max_rows_exceeded", {
                total: this.importData.data.length,
                max: a
            }), this.formatMessage("import_failed"), {
                disableTimeOut: !0
            }), fr(!1)) : fr(!0)
        }
        static {
            this.\u0275fac = (() => {
                let t;
                return function(i) {
                    return (t || (t = gr(e)))(i || e)
                }
            })()
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-step-upload-file"]
                ],
                standalone: !1,
                features: [_r],
                decls: 11,
                vars: 8,
                consts: [
                    ["fileInput", ""],
                    [1, "step-upload-file"],
                    [1, "step-header", "d-flex", "align-items-center", "justify-content-between", "mb-3"],
                    [1, "mb-2"],
                    [1, "mb-0"],
                    ["type", "default", "stylingMode", "contained", 3, "onClick", "icon", "text", "disabled"],
                    [1, "field-requirements-section", "mb-4"],
                    [1, "upload-area-container"],
                    [1, "upload-area", 2, "cursor", "pointer", 3, "drag-over"],
                    [1, "file-info-card", "card"],
                    [1, "card"],
                    [1, "card-body"],
                    [1, "row", "g-4"],
                    [1, "col-md-3", "border-end-column"],
                    [1, "file-format-info"],
                    [1, "mb-3"],
                    [1, "fa-thin", "fa-file-circle-info", "me-2"],
                    [1, "mb-0", "ps-3"],
                    [1, "ms-2"],
                    [1, "col-md-4"],
                    [3, "config", "showHeader", "compact"],
                    [1, "col-md-5"],
                    [3, "importType"],
                    [1, "upload-area", 2, "cursor", "pointer", 3, "click", "drop", "dragover", "dragleave"],
                    [1, "upload-content", "text-center"],
                    [1, "fa-thin", "fa-cloud-arrow-up", "fa-4x", "mb-3", "text-info"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-folder-open", 3, "onClick", "text"],
                    ["type", "file", 1, "d-none", 3, "change", "accept"],
                    [1, "mt-4"],
                    [1, ""],
                    [1, "d-flex", "align-items-center", "justify-content-between"],
                    [1, "d-flex", "align-items-center"],
                    [1, "fa-thin", "fa-file-excel", "fa-3x", "text-success", "me-3"],
                    [1, "mb-1"],
                    ["type", "danger", "stylingMode", "outlined", "icon", "fa-thin fa-trash", 3, "onClick", "text", "disabled"],
                    [1, "mt-3"],
                    ["role", "alert", 1, "alert", "alert-success", "mt-3", "mb-0"],
                    [3, "visible", "height", "width"],
                    [1, "fa-thin", "fa-circle-check", "me-2"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 1)(1, "div", 2)(2, "div")(3, "h5", 3), q(4), D(), ve(5, vE, 2, 1, "p", 4), D(), I(6, "dx-button", 5), it("onClick", function() {
                        return i.downloadSample()
                    }), D()(), ve(7, SE, 28, 14, "div", 6), I(8, "div", 7), ve(9, CE, 11, 7, "div", 8), ve(10, FE, 14, 7, "div", 9), D()()), a & 2 && (k(4), ge(i.formatMessage("upload_file")), k(), we(i.currentConfig ? 5 : -1), k(), Ce("icon", i.isMobileDevice ? "" : "fa-thin fa-download")("text", i.formatMessage("download_sample_file"))("disabled", !i.importData.type), k(), we(i.currentConfig ? 7 : -1), k(2), we(i.selectedFile ? -1 : 9), k(), we(i.selectedFile ? 10 : -1))
                },
                dependencies: [la, wn, as, au],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   .step-header[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{background:linear-gradient(135deg,var(--bs-primary) 0%,var(--bs-info) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}[_nghost-%COMP%]   .file-format-info[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]{font-size:.875rem;line-height:1.6}[_nghost-%COMP%]   .field-requirements-section[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%]{min-height:auto}[_nghost-%COMP%]   .field-requirements-section[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%]   .col-md-4[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .field-requirements-section[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%]   .col-md-4[_ngcontent-%COMP%]   app-quick-reference-guide[_ngcontent-%COMP%]{flex:1;display:flex}[_nghost-%COMP%]   .border-end-column[_ngcontent-%COMP%]{border-right:1px solid var(--bs-border-color)}[_nghost-%COMP%]   .upload-area.drag-over[_ngcontent-%COMP%]{border-color:var(--bs-primary)!important;background:rgba(var(--bs-primary-rgb),.05)!important;transform:scale(1.02)}[_nghost-%COMP%]   .upload-area[_ngcontent-%COMP%]{border:2px dashed var(--bs-border-color);border-radius:8px;padding:3rem 2rem;transition:all .3s ease}[_nghost-%COMP%]   .upload-area[_ngcontent-%COMP%]:hover{border-color:var(--bs-primary);background:rgba(var(--bs-primary-rgb),.02)}"]
            })
        }
    }
    return e
})();
var nu = (() => {
    class e {
        normalizeFieldName(t) {
            return t.toLowerCase().replace(/[^a-z0-9]/g, "").trim()
        }
        getColumnLetter(t) {
            let a = "",
                i = t;
            for (; i >= 0;) a = String.fromCharCode(i % 26 + 65) + a, i = Math.floor(i / 26) - 1;
            return a
        }
        autoDetectMappings(t, a) {
            return t.map(i => {
                let n = {
                        source_column: i,
                        target_field: "",
                        is_mapped: !1,
                        is_auto_detected: !1
                    },
                    s = this.normalizeFieldName(i);
                for (let o of a) {
                    let c = this.normalizeFieldName(o.label);
                    if (s === c) return n.target_field = o.label, n.is_mapped = !0, n.is_auto_detected = !0, n;
                    if (o.aliases && o.aliases.length > 0)
                        for (let l of o.aliases) {
                            let f = this.normalizeFieldName(l);
                            if (s === f) return n.target_field = o.label, n.is_mapped = !0, n.is_auto_detected = !0, n
                        }
                }
                for (let o of a) {
                    let c = this.normalizeFieldName(o.label);
                    if (s.length > c.length && s.includes(c)) return n.target_field = o.label, n.is_mapped = !0, n.is_auto_detected = !0, n
                }
                return n
            })
        }
        getUnmappedRequiredFields(t, a) {
            let i = t.filter(s => s.required),
                n = a.filter(s => s.is_mapped).map(s => s.target_field);
            return i.filter(s => !n.includes(s.label))
        }
        validateMappings(t, a) {
            let i = this.getUnmappedRequiredFields(t, a);
            return {
                isValid: i.length === 0,
                unmappedRequiredFields: i
            }
        }
        getMappedSourceColumnsCount(t) {
            return t.filter(a => a.is_mapped && a.target_field).length
        }
        getMappedFieldsCount(t) {
            return t.filter(a => a.is_mapped).length
        }
        updateMapping(t, a, i) {
            return t.map(n => n.source_column === a ? i === "skip" ? Ga(Ca({}, n), {
                target_field: "",
                is_mapped: !1,
                is_auto_detected: !1
            }) : Ga(Ca({}, n), {
                target_field: i,
                is_mapped: !0,
                is_auto_detected: !1
            }) : n.target_field === i && n.is_mapped && i !== "skip" ? Ga(Ca({}, n), {
                target_field: "",
                is_mapped: !1,
                is_auto_detected: !1
            }) : Ca({}, n))
        }
        getActiveMappings(t) {
            return t.filter(a => a.is_mapped && a.target_field)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var su = (() => {
    class e {
        constructor() {
            this.importService = De(pi), this.fieldConfigCache = new Map
        }
        loadFieldConfigurations(t) {
            if (this.fieldConfigCache.has(t)) return this.fieldConfigCache.get(t);
            let a = this.importService.getFieldConfigurations(t).pipe(z0(i => {
                let n = i.data.fields || [],
                    s = Et[t];
                return this.mergeFieldConfigs(s.fields, n)
            }), q0(1));
            return this.fieldConfigCache.set(t, a), a
        }
        mergeFieldConfigs(t, a) {
            return t.map(i => {
                let n = a.find(s => s.key === i.key);
                return n ? Ga(Ca({}, i), {
                    displayLabel: n.label,
                    required: n.required ? ? i.required,
                    dataType: n.dataType ? ? i.dataType,
                    maxLength: n.maxLength ? ? i.maxLength,
                    unique: n.unique ? ? i.unique,
                    validations: n.validations ? ? i.validations
                }) : i
            })
        }
        updateGlobalConfig(t, a) {
            Et[t].fields = a
        }
        clearCache(t) {
            t ? this.fieldConfigCache.delete(t) : this.fieldConfigCache.clear()
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();

function IE(e, r) {
    if (e & 1 && (I(0, "div", 3)(1, "small"), q(2), D()()), e & 2) {
        let t = te();
        k(2), ge(t.subtitle)
    }
}
var mi = (() => {
    class e {
        constructor() {
            this.icon = "fa-thin fa-circle", this.iconColor = "text-primary", this.iconSize = "fa-2x", this.value = 0, this.label = "", this.cardClass = "", this.iconClass = "", this.formatMessage = pe
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-stat-card"]
                ],
                inputs: {
                    icon: "icon",
                    iconColor: "iconColor",
                    iconSize: "iconSize",
                    value: "value",
                    label: "label",
                    subtitle: "subtitle",
                    cardClass: "cardClass",
                    iconClass: "iconClass"
                },
                decls: 8,
                vars: 6,
                consts: [
                    [1, "stat-card", "card", "h-100", "card-with-selection", 3, "ngClass"],
                    [1, "card-body", "text-center"],
                    [1, "mb-1"],
                    [1, "mt-1"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1), ae(2, "i"), I(3, "h6", 2), q(4), D(), I(5, "small"), q(6), D(), ve(7, IE, 3, 1, "div", 3), D()()), a & 2 && (Ce("ngClass", i.cardClass), k(2), oa(i.icon + " " + i.iconSize + " " + i.iconColor + " mb-2 " + i.iconClass), k(2), ge(i.value), k(2), ge(i.formatMessage(i.label)), k(), we(i.subtitle ? 7 : -1))
                },
                dependencies: [hn, dn],
                styles: ["[_nghost-%COMP%]   .stat-card.card.bg-success[_ngcontent-%COMP%]{background:linear-gradient(135deg,rgba(var(--bs-success-rgb),.08),rgba(var(--bs-success-rgb),.15))}[_nghost-%COMP%]   .stat-card.card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{filter:drop-shadow(0 2px 4px rgba(0,0,0,.1))}[_nghost-%COMP%]   .stat-card.card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_counterPop .6s cubic-bezier(.34,1.56,.64,1)}@keyframes _ngcontent-%COMP%_counterPop{0%{transform:scale(0);opacity:0}50%{transform:scale(1.1);opacity:.7}to{transform:scale(1);opacity:1}}"]
            })
        }
    }
    return e
})();
var OE = () => ({
        maxHeight: 300
    }),
    DE = (e, r) => r.key;

function RE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 20)(1, "div", 14)(2, "div", 21)(3, "div", 22)(4, "div", 23), q(5), D()(), I(6, "div", 24)(7, "div", 25), q(8), D(), I(9, "small", 26), q(10), D()()()(), I(11, "div", 27), ae(12, "i", 28), D(), I(13, "div", 14)(14, "dx-select-box", 29), it("onValueChanged", function(i) {
            let n = qe(t).$implicit,
                s = te(2);
            return je(s.onColumnMappingChange(n, i.value))
        }), D()()()
    }
    if (e & 2) {
        let t = r.$implicit,
            a = r.$index,
            i = te(2);
        k(5), ge(a + 1), k(3), ge(t), k(2), rt("", i.formatMessage("column"), " ", i.getColumnLetter(a)), k(4), Ce("items", i.targetFieldOptions)("value", i.columnValues[t])("stylingMode", "outlined")("height", 42)("dropDownOptions", qa(9, OE))
    }
}

function PE(e, r) {
    if (e & 1 && (I(0, "div", 10)(1, "div", 13)(2, "div", 14)(3, "div", 15), ae(4, "i", 16), I(5, "strong", 17), q(6), D()()(), ae(7, "div", 18), I(8, "div", 14)(9, "div", 15), ae(10, "i", 19), I(11, "strong", 17), q(12), D()()()(), vr(13, RE, 15, 10, "div", 20, to().trackByColumn, !0), D()), e & 2) {
        let t = te();
        k(6), ge(t.formatMessage("file_column_header")), k(6), ge(t.formatMessage("system_field_header")), k(), wr(t.sourceColumns)
    }
}

function NE(e, r) {
    if (e & 1 && (I(0, "li")(1, "strong"), q(2), D(), I(3, "span", 34), q(4, "*"), D()()), e & 2) {
        let t = r.$implicit,
            a = te(2);
        k(2), ge(a.formatMessage(t.label))
    }
}

function LE(e, r) {
    if (e & 1 && (I(0, "div", 11)(1, "div", 30), ae(2, "i", 31), I(3, "div", 24)(4, "strong"), q(5), D(), I(6, "p", 32), q(7), D(), I(8, "ul", 33), vr(9, NE, 5, 1, "li", null, DE), D()()()()), e & 2) {
        let t = te();
        k(5), ge(t.formatMessage("unmapped_required_fields_warning")), k(2), ge(t.formatMessage("map_all_required_fields")), k(2), wr(t.unmappedRequiredFields)
    }
}

function BE(e, r) {
    if (e & 1 && (I(0, "div", 12), ae(1, "i", 35), q(2), D()), e & 2) {
        let t = te();
        k(2), Fe(" ", t.formatMessage("all_required_fields_mapped"), " ")
    }
}
var cu = (() => {
    class e extends Er {
        constructor() {
            super(...arguments), this.mappingService = De(nu), this.fieldConfigService = De(su), this.tenantService = De(Or), this.sourceColumns = [], this.targetFields = [], this.mappings = [], this.columnValues = {}, this.targetFieldOptions = [], this.isLoadingFieldConfigs = !1
        }
        ngOnInit() {
            this.loadFieldConfigsAndInitialize()
        }
        loadFieldConfigsAndInitialize() {
            this.importData ? .type && (this.initializeMappings(), this.isLoadingFieldConfigs = !0, this.fieldConfigService.loadFieldConfigurations(this.importData.type).subscribe({
                next: t => {
                    this.fieldConfigService.updateGlobalConfig(this.importData.type, t), this.initializeMappings(), this.isLoadingFieldConfigs = !1
                },
                error: t => {
                    console.warn("Could not load field configurations from API, using default config:", t), this.isLoadingFieldConfigs = !1
                }
            }))
        }
        initializeMappings() {
            if (!this.importData ? .type || !this.importData ? .data || this.importData.data.length === 0) return;
            let t = Et[this.importData.type];
            this.targetFields = t.fields, this.sourceColumns = Object.keys(this.importData.data[0]), this.importData.mappings && this.importData.mappings.length > 0 ? this.mappings = [...this.importData.mappings] : (this.mappings = this.mappingService.autoDetectMappings(this.sourceColumns, this.targetFields), this.importData.mappings = this.mappings), this.buildTargetFieldOptions(), this.updateColumnValuesMap()
        }
        updateColumnValuesMap() {
            let t = {};
            this.mappings.forEach(a => {
                t[a.source_column] = a.is_mapped && a.target_field ? a.target_field : "skip"
            }), this.columnValues = t
        }
        getColumnLetter(t) {
            return this.mappingService.getColumnLetter(t)
        }
        buildTargetFieldOptions() {
            let t = [{
                label: this.formatMessage("skip_this_column"),
                value: "skip"
            }];
            this.targetFields.forEach(a => {
                let i;
                a.displayLabel ? i = a.displayLabel : (i = this.formatMessage(a.label), a.label === "gst_number" && !this.tenantService.isIndia() && (i = this.formatMessage("vat_number")));
                let n = a.required ? " *" : "";
                t.push({
                    label: i + n,
                    value: a.label
                })
            }), this.targetFieldOptions = t
        }
        get isMappingsReady() {
            return this.mappings && this.mappings.length > 0
        }
        trackByColumn(t, a) {
            return a
        }
        onColumnMappingChange(t, a) {
            a != null && (this.mappings = this.mappingService.updateMapping(this.mappings, t, a), this.updateColumnValuesMap(), this.importData.mappings = this.mappings)
        }
        isRequiredField(t) {
            return this.getFieldConfig(t) ? .required || !1
        }
        getFieldConfig(t) {
            return this.targetFields.find(a => a.label === t)
        }
        get unmappedRequiredFields() {
            return this.mappingService.getUnmappedRequiredFields(this.targetFields, this.mappings)
        }
        get mappedFieldsCount() {
            return this.mappingService.getMappedFieldsCount(this.mappings)
        }
        get mappedSourceColumnsCount() {
            return this.mappingService.getMappedSourceColumnsCount(this.mappings)
        }
        submit() {
            let t = this.unmappedRequiredFields;
            if (t.length > 0) {
                let a = t.map(i => this.formatMessage(i.label)).join(", ");
                return this.toastr.error(dt("unmapped_required_fields", {
                    fields: a
                })), fr(!1)
            }
            return this.importData.mappings = this.mappingService.getActiveMappings(this.mappings), fr(!0)
        }
        static {
            this.\u0275fac = (() => {
                let t;
                return function(i) {
                    return (t || (t = gr(e)))(i || e)
                }
            })()
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-step-map-fields"]
                ],
                standalone: !1,
                features: [_r],
                decls: 17,
                vars: 9,
                consts: [
                    [1, "step-map-fields"],
                    [1, "step-header", "text-center"],
                    [1, "mb-1"],
                    [1, ""],
                    [1, "mapping-summary", "mb-3"],
                    [1, "row", "g-2"],
                    [1, "col-md-4"],
                    ["icon", "fa-thin fa-table-columns", "iconColor", "text-primary", "iconSize", "fa-lg", "label", "source_columns", 3, "value"],
                    ["icon", "fa-thin fa-arrow-right-arrow-left", "iconColor", "text-success", "iconSize", "fa-lg", "label", "mapped_fields", 3, "value"],
                    ["icon", "fa-thin fa-circle-exclamation", "iconSize", "fa-lg", "label", "unmapped_required", 3, "iconColor", "value"],
                    [1, "mapping-container"],
                    ["role", "alert", 1, "alert", "alert-danger", "mt-4"],
                    ["role", "alert", 1, "alert", "alert-success", "mt-4"],
                    [1, "mapping-header", "row", "g-3", "mb-3"],
                    [1, "col-md-5"],
                    [1, "d-flex", "align-items-center"],
                    [1, "fa-solid", "fa-file-csv", "text-primary", "me-2"],
                    [1, "fs-5"],
                    [1, "col-md-2"],
                    [1, "fa-solid", "fa-database", "text-success", "me-2"],
                    [1, "mapping-row", "row", "g-3", "align-items-center", "mb-3"],
                    [1, "source-column-card", "card-with-selection", "d-flex", "align-items-center", "p-2", "rounded"],
                    [1, "column-number", "me-2"],
                    [1, "number-badge", "badge", "bg-primary-subtle", "text-primary"],
                    [1, "flex-grow-1"],
                    [1, "fw-semibold"],
                    [1, "text-muted"],
                    [1, "col-md-2", "text-center"],
                    [1, "fa-solid", "fa-arrow-right"],
                    ["displayExpr", "label", "valueExpr", "value", 3, "onValueChanged", "items", "value", "stylingMode", "height", "dropDownOptions"],
                    [1, "d-flex", "align-items-start"],
                    [1, "fa-solid", "fa-triangle-exclamation", "me-3", "mt-1"],
                    [1, "mb-2", "mt-2"],
                    [1, "mb-0"],
                    [1, "text-danger", "ms-1"],
                    [1, "fa-solid", "fa-circle-check", "me-2"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1)(2, "h5", 2), q(3), D(), I(4, "p", 3), q(5), D()(), I(6, "div", 4)(7, "div", 5)(8, "div", 6), ae(9, "app-stat-card", 7), D(), I(10, "div", 6), ae(11, "app-stat-card", 8), D(), I(12, "div", 6), ae(13, "app-stat-card", 9), D()()(), ve(14, PE, 15, 2, "div", 10), ve(15, LE, 11, 2, "div", 11), ve(16, BE, 3, 1, "div", 12), D()), a & 2 && (k(3), ge(i.formatMessage("map_columns_to_fields")), k(2), ge(i.formatMessage("map_fields_description")), k(4), Ce("value", i.sourceColumns.length), k(2), Ce("value", i.mappedSourceColumnsCount + " / " + i.sourceColumns.length), k(2), Ce("iconColor", i.unmappedRequiredFields.length > 0 ? "text-danger" : "text-success")("value", i.unmappedRequiredFields.length), k(), we(i.isMappingsReady ? 14 : -1), k(), we(i.unmappedRequiredFields.length > 0 ? 15 : -1), k(), we(i.unmappedRequiredFields.length === 0 && i.mappedFieldsCount > 0 ? 16 : -1))
                },
                dependencies: [_n, mi],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   .step-header[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{background:linear-gradient(135deg,var(--bs-primary) 0%,var(--bs-success) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}[_nghost-%COMP%]   .source-column-card.card-with-selection[_ngcontent-%COMP%]{padding:.5rem .75rem;height:auto;flex-direction:row;justify-content:flex-start;align-items:center}[_nghost-%COMP%]   .source-column-card.card-with-selection[_ngcontent-%COMP%]   .number-badge[_ngcontent-%COMP%]{font-size:.75rem;padding:.25rem .5rem;min-width:24px}[_nghost-%COMP%]   .form-select[_ngcontent-%COMP%]{font-size:.875rem}[_nghost-%COMP%]   .form-select[_ngcontent-%COMP%]   option[_ngcontent-%COMP%]{font-size:.875rem}"]
            })
        }
    }
    return e
})();

function VE(e, r) {
    if (e & 1 && (I(0, "div", 8), ae(1, "dx-load-indicator", 10), I(2, "p", 11), q(3), D()()), e & 2) {
        let t = te();
        k(), Ce("visible", !0), k(2), Fe("", t.formatMessage("loading"), "...")
    }
}

function WE(e, r) {
    if (e & 1 && (I(0, "div", 9)(1, "div", 12), ae(2, "i", 13), I(3, "div")(4, "h6", 3), q(5), D(), I(6, "p", 4), q(7), D()()()()), e & 2) {
        let t = te();
        k(5), ge(t.formatMessage("no_default_configuration_required")), k(2), Fe(" ", t.formatMessage("no_default_configuration_required_description"), " ")
    }
}

function HE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 15)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 25), q(5), I(6, "span", 26), q(7), D()(), I(8, "p", 27), q(9), D(), I(10, "dx-select-box", 28), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedRole, i) || (n.selectedRole = i), je(i)
        }), D(), I(11, "div", 29)(12, "small", 30), ae(13, "i", 31), q(14), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedRole), k(4), Fe(" ", t.formatMessage("role"), " "), k(2), ge(t.formatMessage("required")), k(2), Fe(" ", t.formatMessage("default_role_description"), " "), k(), rr("value", t.selectedRole), Ce("dataSource", t.employeeRoles)("searchEnabled", !0)("showClearButton", !1)("placeholder", t.formatMessage("select_default_role"))("noDataText", t.formatMessage("no_options_available")), k(4), rt(" ", t.formatMessage("available_count"), ": ", t.employeeRoles.length, " ")
    }
}

function GE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div")(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 32), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-select-box", 33), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedRole, i) || (n.selectedRole = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        oa(t.importData.type === t.ImportType.LEAD ? "col-md-4" : "col-md-6"), k(), tr("selected", t.selectedRole), k(4), Fe(" ", t.formatMessage("role"), " "), k(2), Fe(" ", t.formatMessage("default_role_description"), " "), k(), rr("value", t.selectedRole), Ce("dataSource", t.customerRoles)("searchEnabled", !0)("showClearButton", !0)("placeholder", t.formatMessage("select_default_role"))("noDataText", t.formatMessage("no_options_available")), k(4), rt(" ", t.formatMessage("available_count"), ": ", t.customerRoles.length, " ")
    }
}

function zE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 15)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 34), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-select-box", 35), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedSource, i) || (n.selectedSource = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedSource), k(4), Fe(" ", t.formatMessage("source"), " "), k(2), Fe(" ", t.formatMessage("default_source_description"), " "), k(), rr("value", t.selectedSource), Ce("dataSource", t.jobSources)("searchEnabled", !0)("showClearButton", !0)("placeholder", t.formatMessage("select_default_source"))("noDataText", t.formatMessage("no_options_available")), k(4), rt(" ", t.formatMessage("available_count"), ": ", t.jobSources.length, " ")
    }
}

function XE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 17)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 34), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-select-box", 35), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedLeadSource, i) || (n.selectedLeadSource = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedLeadSource), k(4), Fe(" ", t.formatMessage("lead_source"), " "), k(2), Fe(" ", t.formatMessage("default_lead_source_description"), " "), k(), rr("value", t.selectedLeadSource), Ce("dataSource", t.leadSources)("searchEnabled", !0)("showClearButton", !0)("placeholder", t.formatMessage("select_default_lead_source"))("noDataText", t.formatMessage("no_options_available")), k(4), rt(" ", t.formatMessage("available_count"), ": ", t.leadSources.length, " ")
    }
}

function qE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 17)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 36), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-select-box", 35), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedStatus, i) || (n.selectedStatus = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedStatus), k(4), Fe(" ", t.formatMessage("status"), " "), k(2), Fe(" ", t.formatMessage("default_status_description"), " "), k(), rr("value", t.selectedStatus), Ce("dataSource", t.leadStatuses)("searchEnabled", !0)("showClearButton", !0)("placeholder", t.formatMessage("select_default_status"))("noDataText", t.formatMessage("no_options_available")), k(4), rt(" ", t.formatMessage("available_count"), ": ", t.leadStatuses.length, " ")
    }
}

function jE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 17)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 37), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-switch", 38), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedManageStock, i) || (n.selectedManageStock = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedManageStock), k(4), Fe(" ", t.formatMessage("manage_stock"), " "), k(2), Fe(" ", t.formatMessage("default_manage_stock_description"), " "), k(), rr("value", t.selectedManageStock), Ce("switchedOnText", t.formatMessage("common_yes"))("switchedOffText", t.formatMessage("common_no")), k(4), rt(" ", t.formatMessage("default_value"), ": ", t.selectedManageStock ? t.formatMessage("common_yes") : t.formatMessage("common_no"), " ")
    }
}

function $E(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 17)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 39), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-switch", 38), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedRateIncludingTax, i) || (n.selectedRateIncludingTax = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedRateIncludingTax), k(4), Fe(" ", t.formatMessage("rate_including_tax"), " "), k(2), Fe(" ", t.formatMessage("default_rate_including_tax_description"), " "), k(), rr("value", t.selectedRateIncludingTax), Ce("switchedOnText", t.formatMessage("common_yes"))("switchedOffText", t.formatMessage("common_no")), k(4), rt(" ", t.formatMessage("default_value"), ": ", t.selectedRateIncludingTax ? t.formatMessage("common_yes") : t.formatMessage("common_no"), " ")
    }
}

function YE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 17)(1, "div", 22)(2, "div", 23)(3, "h6", 24), ae(4, "i", 40), q(5), D(), I(6, "p", 27), q(7), D(), I(8, "dx-switch", 38), ir("valueChange", function(i) {
            qe(t);
            let n = te(2);
            return ar(n.selectedLowStockAlert, i) || (n.selectedLowStockAlert = i), je(i)
        }), D(), I(9, "div", 29)(10, "small", 30), ae(11, "i", 31), q(12), D()()()()()
    }
    if (e & 2) {
        let t = te(2);
        k(), tr("selected", t.selectedLowStockAlert), k(4), Fe(" ", t.formatMessage("low_stock_alert"), " "), k(2), Fe(" ", t.formatMessage("default_low_stock_alert_description"), " "), k(), rr("value", t.selectedLowStockAlert), Ce("switchedOnText", t.formatMessage("common_yes"))("switchedOffText", t.formatMessage("common_no")), k(4), rt(" ", t.formatMessage("default_value"), ": ", t.selectedLowStockAlert ? t.formatMessage("common_yes") : t.formatMessage("common_no"), " ")
    }
}

function KE(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "dx-button", 41), it("onClick", function() {
            qe(t);
            let i = te(2);
            return je(i.clearAllSelections())
        }), D()
    }
    if (e & 2) {
        let t = te(2);
        Ce("text", t.formatMessage("clear_all"))
    }
}

function JE(e, r) {
    if (e & 1 && (I(0, "div", 14), ve(1, HE, 15, 13, "div", 15), ve(2, GE, 13, 14, "div", 16), ve(3, zE, 13, 12, "div", 15), ve(4, XE, 13, 12, "div", 17), ve(5, qE, 13, 12, "div", 17), ve(6, jE, 13, 9, "div", 17), ve(7, $E, 13, 9, "div", 17), ve(8, YE, 13, 9, "div", 17), D(), I(9, "div", 18)(10, "div", 19)(11, "div")(12, "strong"), q(13), D(), ae(14, "br"), I(15, "small", 20), q(16), D()(), ve(17, KE, 1, 1, "dx-button", 21), D()()), e & 2) {
        let t = te();
        k(), we(t.importData.type === t.ImportType.EMPLOYEE ? 1 : -1), k(), we(t.importData.type === t.ImportType.CUSTOMER || t.importData.type === t.ImportType.LEAD ? 2 : -1), k(), we(t.importData.type === t.ImportType.CUSTOMER ? 3 : -1), k(), we(t.importData.type === t.ImportType.LEAD ? 4 : -1), k(), we(t.importData.type === t.ImportType.LEAD ? 5 : -1), k(), we(t.importData.type === t.ImportType.PART ? 6 : -1), k(), we(t.importData.type === t.ImportType.PART ? 7 : -1), k(), we(t.importData.type === t.ImportType.PART ? 8 : -1), k(5), no("", t.configuredFieldsCount, " ", t.formatMessage("of"), " ", t.totalFieldsCount, " ", t.formatMessage("fields_configured")), k(3), rt("", t.requiredFieldsCount, " ", t.formatMessage("required_fields")), k(), we(t.hasAnySelection ? 17 : -1)
    }
}
var lu = (() => {
    class e extends Er {
        constructor() {
            super(...arguments), this.roleService = De(Ci), this.dataService = De(Ti), this.leadStatusService = De(yi), this.ImportType = be, this.employeeRoles = [], this.customerRoles = [], this.jobSources = [], this.leadSources = [], this.leadStatuses = [], this.selectedRole = null, this.selectedSource = null, this.selectedLeadSource = null, this.selectedStatus = null, this.selectedManageStock = !1, this.selectedRateIncludingTax = !1, this.selectedLowStockAlert = !1, this.isLoading = !1
        }
        isFieldMapped(t) {
            return this.importData.mappings ? .some(a => a.is_mapped && a.target_field === t) || !1
        }
        get isRoleMapped() {
            return this.isFieldMapped("role_id")
        }
        get isSourceMapped() {
            return this.isFieldMapped("source_id")
        }
        get isLeadSourceMapped() {
            return this.isFieldMapped("lead_source_id")
        }
        get isStatusMapped() {
            return this.isFieldMapped("status_id")
        }
        ngOnInit() {
            this.loadData(), this.importData.defaults && (this.selectedRole = this.importData.defaults.role_id || null, this.selectedSource = this.importData.defaults.source_id || null, this.selectedLeadSource = this.importData.defaults.lead_source_id || null, this.selectedStatus = this.importData.defaults.status_id || null, this.selectedManageStock = this.importData.defaults.is_manage_stock ? ? !1, this.selectedRateIncludingTax = this.importData.defaults.is_rate_including_tax ? ? !1, this.selectedLowStockAlert = this.importData.defaults.is_low_stock_alert ? ? !1)
        }
        loadData() {
            this.isLoading = !0, za({
                employeeRoles: this.roleService.getEmployeeRoles(),
                customerRoles: this.roleService.getCustomerRoles(),
                lookups: this.dataService.getLookups(),
                statuses: this.leadStatusService.getListByQuery()
            }).subscribe({
                next: t => {
                    this.employeeRoles = t.employeeRoles || [], this.customerRoles = t.customerRoles || [], this.jobSources = t.lookups ? .job_sources || [], this.leadSources = t.lookups ? .lead_sources || t.lookups ? .job_sources || [], this.leadStatuses = t.statuses || [], this.autoSelectDefaults(), this.isLoading = !1
                },
                error: t => {
                    console.error("Error loading default options:", t), this.toastr.error(this.formatMessage("error_loading_data")), this.isLoading = !1
                }
            })
        }
        autoSelectDefaults() {
            if (this.importData.defaults && (this.selectedRole = this.importData.defaults.role_id || null, this.selectedSource = this.importData.defaults.source_id || null, this.selectedLeadSource = this.importData.defaults.lead_source_id || null, this.selectedStatus = this.importData.defaults.status_id || null, this.selectedManageStock = this.importData.defaults.is_manage_stock ? ? !1, this.selectedRateIncludingTax = this.importData.defaults.is_rate_including_tax ? ? !1, this.selectedLowStockAlert = this.importData.defaults.is_low_stock_alert ? ? !1), !this.selectedRole) {
                if (this.importData.type === be.EMPLOYEE && this.employeeRoles.length > 0) {
                    let t = this.employeeRoles.find(a => a.display_name ? .toLowerCase() === "end user" || a.name ? .toLowerCase() === "end user");
                    this.selectedRole = t ? .display_name || this.employeeRoles[0] ? .display_name
                } else if ((this.importData.type === be.CUSTOMER || this.importData.type === be.LEAD) && this.customerRoles.length > 0) {
                    let t = this.customerRoles.find(a => a.display_name ? .toLowerCase() === "end user" || a.name ? .toLowerCase() === "end user");
                    this.selectedRole = t ? .id || this.customerRoles[0] ? .id
                }
            }
            if (!this.selectedSource && this.importData.type === be.CUSTOMER && this.jobSources.length > 0) {
                let t = this.jobSources.find(a => a.name ? .toLowerCase() === "walk in");
                this.selectedSource = t ? .id || this.jobSources[0] ? .id
            }
            if (!this.selectedLeadSource && this.importData.type === be.LEAD && this.leadSources.length > 0) {
                let t = this.leadSources.find(a => a.name ? .toLowerCase() === "walk in");
                this.selectedLeadSource = t ? .id || this.leadSources[0] ? .id
            }!this.selectedStatus && this.importData.type === be.LEAD && this.leadStatuses.length > 0 && (this.selectedStatus = this.leadStatuses[0] ? .id)
        }
        submit() {
            if (this.requiredFieldsCount === 0) return this.importData.defaults = {}, !0;
            let t = [];
            this.importData.type === be.EMPLOYEE ? this.isRoleMapped || t.push({
                field: this.selectedRole,
                message: "please_select_default_role"
            }) : this.importData.type === be.CUSTOMER ? (this.isRoleMapped || t.push({
                field: this.selectedRole,
                message: "please_select_default_role"
            }), this.isSourceMapped || t.push({
                field: this.selectedSource,
                message: "please_select_default_source"
            })) : this.importData.type === be.LEAD && (this.isRoleMapped || t.push({
                field: this.selectedRole,
                message: "please_select_default_role"
            }), this.isLeadSourceMapped || t.push({
                field: this.selectedLeadSource,
                message: "please_select_default_lead_source"
            }), this.isStatusMapped || t.push({
                field: this.selectedStatus,
                message: "please_select_default_status"
            }));
            for (let {
                    field: a,
                    message: i
                } of t)
                if (!a) return this.toastr.error(this.formatMessage(i)), !1;
            return this.importData.defaults = {
                role_id: this.selectedRole,
                source_id: this.selectedSource,
                lead_source_id: this.selectedLeadSource,
                status_id: this.selectedStatus,
                is_manage_stock: this.selectedManageStock,
                is_rate_including_tax: this.selectedRateIncludingTax,
                is_low_stock_alert: this.selectedLowStockAlert
            }, !0
        }
        clearAllSelections() {
            this.selectedRole = null, this.selectedSource = null, this.selectedLeadSource = null, this.selectedStatus = null, this.selectedManageStock = !1, this.selectedRateIncludingTax = !1, this.selectedLowStockAlert = !1
        }
        get hasAnySelection() {
            return !!(this.selectedRole || this.selectedSource || this.selectedLeadSource || this.selectedStatus || this.selectedManageStock || this.selectedRateIncludingTax || this.selectedLowStockAlert)
        }
        get configuredFieldsCount() {
            let t = 0;
            return this.selectedRole && t++, this.selectedSource && t++, this.selectedLeadSource && t++, this.selectedStatus && t++, this.selectedManageStock && t++, this.selectedRateIncludingTax && t++, this.selectedLowStockAlert && t++, t
        }
        get totalFieldsCount() {
            return this.importData.type === be.EMPLOYEE ? 1 : this.importData.type === be.CUSTOMER ? 2 : this.importData.type === be.LEAD || this.importData.type === be.PART ? 3 : 0
        }
        get requiredFieldsCount() {
            return this.importData.type === be.EMPLOYEE ? 1 : this.importData.type === be.CUSTOMER ? 2 : this.importData.type === be.LEAD ? 3 : (this.importData.type === be.PART, 0)
        }
        static {
            this.\u0275fac = (() => {
                let t;
                return function(i) {
                    return (t || (t = gr(e)))(i || e)
                }
            })()
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-step-select-defaults"]
                ],
                standalone: !1,
                features: [_r],
                decls: 16,
                vars: 5,
                consts: [
                    [1, "step-select-defaults"],
                    ["role", "alert", 1, "alert", "alert-info", "d-flex", "align-items-center", "mb-4"],
                    [1, "fa-thin", "fa-info-circle", "fa-lg", "me-3"],
                    [1, "alert-heading", "mb-1"],
                    [1, "mb-0", "small"],
                    [1, "mb-3"],
                    [1, "mb-2"],
                    [1, "text-muted", "mb-0", "small"],
                    [1, "text-center", "py-5"],
                    ["role", "alert", 1, "alert", "alert-success", "mt-4"],
                    [3, "visible"],
                    [1, "mt-3", "text-muted"],
                    [1, "d-flex", "align-items-center"],
                    [1, "fa-thin", "fa-circle-check", "fa-2x", "me-3"],
                    [1, "row", "g-4"],
                    [1, "col-md-6"],
                    [3, "class"],
                    [1, "col-md-4"],
                    ["role", "alert", 1, "alert", "alert-primary", "mt-4", "mb-3"],
                    [1, "d-flex", "align-items-center", "justify-content-between"],
                    [1, "text-primary"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-times", 3, "text"],
                    [1, "card-with-selection", "h-100"],
                    [1, "card-body"],
                    [1, "card-title", "mb-3"],
                    [1, "fa-thin", "fa-user-shield", "me-2", "text-success"],
                    [1, "badge", "bg-danger", "ms-2", "small"],
                    [1, "small", "text-muted", "mb-3"],
                    ["displayExpr", "display_name", "valueExpr", "display_name", 3, "valueChange", "value", "dataSource", "searchEnabled", "showClearButton", "placeholder", "noDataText"],
                    [1, "mt-3"],
                    [1, "text-muted"],
                    [1, "fa-thin", "fa-info-circle", "me-1"],
                    [1, "fa-thin", "fa-user-tag", "me-2", "text-success"],
                    ["displayExpr", "display_name", "valueExpr", "id", 3, "valueChange", "value", "dataSource", "searchEnabled", "showClearButton", "placeholder", "noDataText"],
                    [1, "fa-thin", "fa-bullseye", "me-2", "text-warning"],
                    ["displayExpr", "name", "valueExpr", "id", 3, "valueChange", "value", "dataSource", "searchEnabled", "showClearButton", "placeholder", "noDataText"],
                    [1, "fa-thin", "fa-flag", "me-2", "text-primary"],
                    [1, "fa-thin", "fa-boxes-stacked", "me-2", "text-primary"],
                    [3, "valueChange", "value", "switchedOnText", "switchedOffText"],
                    [1, "fa-thin", "fa-receipt", "me-2", "text-success"],
                    [1, "fa-thin", "fa-bell", "me-2", "text-warning"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-times", 3, "onClick", "text"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1), ae(2, "i", 2), I(3, "div")(4, "h6", 3), q(5), D(), I(6, "p", 4), q(7), D()()(), I(8, "div", 5)(9, "h5", 6), q(10), D(), I(11, "p", 7), q(12), D()(), ve(13, VE, 4, 2, "div", 8)(14, WE, 8, 2, "div", 9)(15, JE, 18, 15), D()), a & 2 && (k(5), ge(i.formatMessage("set_default_values")), k(2), Fe(" ", i.formatMessage("configure_default_values_description"), " "), k(3), ge(i.formatMessage("configure_default_values")), k(2), Fe(" ", i.formatMessage("set_default_values_for_dropdowns"), " "), k(), we(i.isLoading ? 13 : i.totalFieldsCount === 0 ? 14 : 15))
                },
                dependencies: [la, wn, _n, Ro],
                styles: ["[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]{padding:1rem 0}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]{border:1px solid var(--theme-border-color);transition:all .3s ease}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #0000001a;transform:translateY(-2px)}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-title[_ngcontent-%COMP%]{font-weight:600;font-size:1rem}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.1rem}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .alert-info[_ngcontent-%COMP%]{background-color:#0d6efd0d;border-color:#0d6efd33;color:var(--primary-text)}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .alert-info[_ngcontent-%COMP%]   .alert-heading[_ngcontent-%COMP%]{font-size:.9rem;font-weight:600}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .alert-info[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]{padding-left:1.25rem;margin-bottom:0}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .alert-info[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{margin-bottom:.25rem}[_nghost-%COMP%]   .step-select-defaults[_ngcontent-%COMP%]   .alert-info[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child{margin-bottom:0}"]
            })
        }
    }
    return e
})();
var fu = (() => {
    class e {
        validateData(t, a, i) {
            let n = [],
                s = Et[a];
            t.forEach((f, u) => {
                let h = f._rowNumber || u + 2;
                s.fields.filter(p => p.required).forEach(p => {
                    let m = f[p.key];
                    (m == null || String(m).trim() === "") && n.push({
                        row: h,
                        field: p.key,
                        message: dt("field_required", {
                            field: pe(p.label)
                        }),
                        severity: Sr.ERROR,
                        value: m
                    })
                }), s.fields.filter(p => p.dataType === "string" && p.key.includes("email")).forEach(p => {
                    let m = f[p.key];
                    m && !this.isValidEmail(String(m)) && n.push({
                        row: h,
                        field: p.key,
                        message: pe("invalid_email"),
                        severity: Sr.ERROR,
                        value: m
                    })
                }), s.fields.filter(p => p.dataType === "string" && (p.key.includes("phone") || p.key.includes("mobile"))).forEach(p => {
                    let m = f[p.key];
                    m && !this.isValidPhone(String(m)) && n.push({
                        row: h,
                        field: p.key,
                        message: pe("invalid_phone"),
                        severity: Sr.ERROR,
                        value: m
                    })
                }), s.fields.forEach(p => {
                    let m = f[p.key];
                    m != null && m !== "" && (p.dataType === "number" && isNaN(Number(m)) && n.push({
                        row: h,
                        field: p.key,
                        message: pe("must_be_number"),
                        severity: Sr.ERROR,
                        value: m
                    }), p.dataType === "date" && !this.isValidDate(m) && n.push({
                        row: h,
                        field: p.key,
                        message: pe("invalid_date"),
                        severity: Sr.ERROR,
                        value: m
                    }), p.dataType === "boolean" && !this.isValidBoolean(m) && n.push({
                        row: h,
                        field: p.key,
                        message: pe("must_be_boolean"),
                        severity: Sr.ERROR,
                        value: m
                    }))
                }), s.fields.forEach(p => {
                    let m = f[p.key];
                    if (m && p.validations) {
                        let d = String(m);
                        p.validations.forEach(x => {
                            x.type === "minLength" && d.length < x.value && n.push({
                                row: h,
                                field: p.key,
                                message: dt("min_length", {
                                    min: x.value
                                }),
                                severity: Sr.ERROR,
                                value: m
                            }), x.type === "maxLength" && d.length > x.value && n.push({
                                row: h,
                                field: p.key,
                                message: dt("max_length", {
                                    max: x.value
                                }),
                                severity: Sr.ERROR,
                                value: m
                            })
                        })
                    }
                    m && p.maxLength && String(m).length > p.maxLength && n.push({
                        row: h,
                        field: p.key,
                        message: dt("max_length", {
                            max: p.maxLength
                        }),
                        severity: Sr.ERROR,
                        value: m
                    })
                })
            }), s.fields.filter(f => f.unique).forEach(f => {
                let u = new Map;
                t.forEach((h, p) => {
                    let m = h[f.key],
                        d = h._rowNumber || p + 2;
                    if (m != null && m !== "") {
                        let x = String(m).toLowerCase().trim();
                        u.has(x) || u.set(x, []), u.get(x).push(d)
                    }
                }), u.forEach((h, p) => {
                    h.length > 1 && h.forEach(m => {
                        n.push({
                            row: m,
                            field: f.key,
                            message: dt("duplicate_value", {
                                value: p,
                                rows: h.join(", ")
                            }),
                            severity: Sr.ERROR,
                            value: p
                        })
                    })
                })
            });
            let c = new Set(n.map(f => f.row)),
                l = t.length - c.size;
            return {
                isValid: n.length === 0,
                errors: n,
                totalRows: t.length,
                validRows: l
            }
        }
        isValidEmail(t) {
            return fa.EMAIL.test(t)
        }
        isValidPhone(t) {
            let a = String(t).replace(fa.PHONE.DIGITS_ONLY, "");
            return a.length >= fa.PHONE.MIN_DIGITS && a.length <= fa.PHONE.MAX_DIGITS
        }
        isValidDate(t) {
            if (t instanceof Date) return !isNaN(t.getTime());
            let a = Date.parse(String(t));
            return !isNaN(a)
        }
        isValidBoolean(t) {
            if (typeof t == "boolean") return !0;
            let a = String(t).toLowerCase();
            return fa.BOOLEAN_VALUES.includes(a)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var xi = (() => {
    class e {
        constructor(t) {
            this.sanitizer = t
        }
        sanitizeHtml(t) {
            let a = String(t || "");
            return this.sanitizer.sanitize(Y0.HTML, a) || ""
        }
        sanitizeForCSV(t) {
            let a = String(t || "");
            return fa.CSV_FORMULA.test(a) ? `'${a.replace(/"/g,'""')}` : a.replace(/"/g, '""')
        }
        sanitizeErrorMessage(t) {
            return t ? t.replace(/\/[\w\-\/]+\.(ts|js|php|py)/gi, "[file]").replace(/table|column|constraint|foreign key/gi, "[database]") : ""
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)($0(co))
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var rC = e => ({
        count: e
    }),
    aC = () => ({
        count: 100
    }),
    iC = (e, r) => r.dataField;

function nC(e, r) {
    if (e & 1 && (I(0, "div", 9)(1, "div", 13)(2, "div", 14)(3, "h6", 15), ae(4, "i", 16), q(5), D(), ae(6, "dx-progress-bar", 17), I(7, "p", 18), q(8), D()()()()), e & 2) {
        let t = te();
        k(5), Fe(" ", t.progressService.status() || t.formatMessage("uploading_file"), " "), k(), Ce("value", t.progressService.progress())("showStatus", !0), k(2), Fe(" ", t.progressService.rowProgressText(), " ")
    }
}

function sC(e, r) {
    if (e & 1 && ae(0, "dxi-column", 23), e & 2) {
        let t = r.$implicit;
        Ce("dataField", t.dataField)("caption", t.caption)("dataType", t.dataType)
    }
}

function oC(e, r) {
    if (e & 1 && (I(0, "div", 10)(1, "h6", 15), q(2), D(), I(3, "dx-data-grid", 19), ae(4, "dxo-scrolling", 20)(5, "dxo-paging", 21)(6, "dxi-column", 22), vr(7, sC, 1, 3, "dxi-column", 23, iC), D()()), e & 2) {
        let t = te();
        k(2), rt("", t.formatMessage("data_preview"), " (", t.formatMessageWithParams("first_rows", qa(14, aC)), ")"), k(), Ce("dataSource", t.previewData)("showBorders", !0)("showRowLines", !0)("rowAlternationEnabled", !0)("columnAutoWidth", !0)("allowColumnReordering", !0)("allowColumnResizing", !0), k(2), Ce("enabled", !1), k(), Ce("caption", t.formatMessage("row"))("width", 80)("allowEditing", !1)("fixed", !0), k(), wr(t.previewColumns)
    }
}

function cC(e, r) {
    if (e & 1 && (I(0, "div", 11), ae(1, "i", 24), I(2, "strong"), q(3), D(), q(4), D()), e & 2) {
        let t = te();
        k(3), ge(t.formatMessage("no_data_to_preview")), k(), Fe(" ", t.formatMessage("please_upload_and_map_fields"), " ")
    }
}

function lC(e, r) {
    if (e & 1 && (I(0, "div", 12), ae(1, "i", 25), I(2, "strong"), q(3), D(), q(4), D()), e & 2) {
        let t = te();
        k(3), ge(t.formatMessage("ready_to_import")), k(), Fe(" ", t.formatMessage("backend_will_validate_data"), " ")
    }
}
var uu = (() => {
    class e extends Er {
        constructor() {
            super(...arguments), this.validationService = De(fu), this.importService = De(pi), this.progressService = De(En), this.sanitizationService = De(xi), this.previewData = [], this.previewColumns = [], this.validationErrors = [], this.isValidating = !1, this.isImporting = !1, this.showAllErrors = !1, this.uploadProgress = 0, this.formatMessageWithParams = dt
        }
        ngOnInit() {
            this.preparePreview(), this.prepareColumns()
        }
        preparePreview() {
            if (!this.importData.type || !this.importData.data || !this.importData.mappings) {
                this.previewData = [];
                return
            }
            this.previewData = this.importData.data.map((t, a) => {
                let i = {
                    _rowNumber: a + 1
                };
                return this.importData.mappings.forEach(n => {
                    n.is_mapped && n.source_column && (i[n.target_field] = t[n.source_column])
                }), i
            })
        }
        validate() {
            if (!this.importData.type || this.previewData.length === 0) return;
            this.isValidating = !0;
            let t = this.validationService.validateData(this.previewData, this.importData.type, this.importData.mappings);
            this.importData.validationResult = t, this.validationErrors = t.errors, this.isValidating = !1, t.isValid ? this.toastr.success(this.formatMessage("validation_passed")) : this.toastr.warning(dt("validation_errors_found", {
                count: t.errors.length
            }))
        }
        prepareColumns() {
            if (!this.importData.type) {
                this.previewColumns = [];
                return
            }
            let t = Et[this.importData.type],
                a = this.importData.mappings ? .filter(i => i.is_mapped) || [];
            this.previewColumns = a.map(i => {
                let n = t.fields.find(s => s.key === i.target_field);
                return {
                    dataField: i.target_field,
                    caption: this.formatMessage(n ? .label || i.target_field),
                    dataType: n ? .dataType || "string"
                }
            }), console.log("Generated columns for DataGrid:", this.previewColumns)
        }
        getRowErrors(t) {
            return this.validationErrors.filter(a => a.row === t)
        }
        toggleShowAllErrors() {
            this.showAllErrors = !this.showAllErrors
        }
        downloadErrorReport() {
            if (this.validationErrors.length === 0) return;
            let t = this.generateErrorReportCSV(),
                a = new Blob([t], {
                    type: "text/csv;charset=utf-8;"
                }),
                i = URL.createObjectURL(a),
                n = document.createElement("a");
            n.href = i, n.download = `import_errors_${Date.now()}.csv`, n.click(), URL.revokeObjectURL(i), this.toastr.success(this.formatMessage("error_report_downloaded"))
        }
        generateErrorReportCSV() {
            let t = ["Row", "Field", "Error", "Value"],
                a = this.validationErrors.map(n => [String(n.row), this.sanitizationService.sanitizeForCSV(n.field), this.sanitizationService.sanitizeForCSV(n.message), this.sanitizationService.sanitizeForCSV(n.value || "")]);
            return [t, ...a].map(n => n.map(s => `"${s}"`).join(",")).join(`
`)
        }
        executeImport() {
            return Qt(this, null, function*() {
                console.log("=== executeImport() START ==="), console.log("Preview data length:", this.previewData.length), console.log("Import type:", this.importData.type), console.log("File:", this.importData.file ? .name), console.log("Mappings count:", this.importData.mappings ? .length);
                try {
                    let t = this.initializeImportProcess(),
                        a = yield this.performImport(t);
                    return yield this.finalizeImportSuccess(a), !0
                } catch (t) {
                    return this.setImportErrorResult(t), !0
                }
            })
        }
        initializeImportProcess() {
            this.isImporting = !0, this.uploadProgress = 0;
            let t = this.importData.totalRows || this.importData.data ? .length || this.previewData.length;
            return this.progressService.startImport(t), console.log("Progress service started with total rows:", t), t
        }
        performImport(t) {
            return Qt(this, null, function*() {
                let a = this.simulateProcessingProgress(t);
                return console.log("Starting import with simulated progress..."), ln(this.importService.executeImport(this.importData).pipe(j0(i => {
                    a && (clearInterval(a), console.log("Backend response received, stopped simulation")), console.log("Response received:", i)
                }), X0(i => this.handleImportError(i, a))))
            })
        }
        handleImportError(t, a) {
            throw console.error("Import error:", t), a && clearInterval(a), this.progressService.completeImport(!1), this.isImporting = !1, this.uploadProgress = 0, this.toastr.error(t.error ? .message || this.formatMessage("import_failed")), t
        }
        finalizeImportSuccess(t) {
            return Qt(this, null, function*() {
                console.log("Import result:", t), this.importData.importResult = t;
                let a = t ? .data ? .success ? ? t ? .success ? ? !0,
                    i = t ? .data ? .errors_count > 0 || t ? .data ? .errors ? .length > 0;
                this.progressService.completeImport(a), yield new Promise(n => setTimeout(n, $a.MIN_PROGRESS_DISPLAY)), this.isImporting = !1, this.uploadProgress = 0, this.showImportNotification(a, i, t)
            })
        }
        showImportNotification(t, a, i) {
            if (t && !a) this.toastr.success(this.formatMessage("import_complete"));
            else if (a) {
                let n = i ? .data ? .imported_count || 0,
                    s = i ? .data ? .errors_count || 0;
                if (n > 0) this.toastr.warning(dt("import_partial_success", {
                    imported: n,
                    failed: s
                }));
                else {
                    let o = i ? .data ? .message || i ? .message || this.formatMessage("import_failed_with_errors");
                    this.toastr.error(o)
                }
            }
        }
        setImportErrorResult(t) {
            this.uploadProgress = 0;
            let a = t ? .error ? .errors || [],
                i = t ? .error ? .message || this.formatMessage("import_failed");
            this.importData.importResult = {
                success: !1,
                totalRows: 0,
                importedRows: 0,
                failedRows: a.length || 1,
                message: i,
                data: {
                    imported_count: 0,
                    errors_count: a.length || 1,
                    errors: a.length > 0 ? a : [{
                        row: 0,
                        message: i,
                        values: {}
                    }],
                    time_taken: 0
                }
            }
        }
        simulateProcessingProgress(t) {
            let a = 0,
                i = 7,
                n = 500,
                s = i / 2,
                o = Math.ceil(t / i);
            console.log(`Simulating progress: ${t} rows at ${i} records/second`), console.log(`Estimated completion time: ${o} seconds (~${Math.ceil(o/60)} minutes)`);
            let c = setInterval(() => {
                a = Math.min(a + s, t), this.progressService.updateImportProgress(Math.floor(a), t), a >= t * .9 && (clearInterval(c), console.log(`Simulation stopped at 90% (${Math.floor(a)} / ${t}) - waiting for backend response`))
            }, n);
            return c
        }
        submit() {
            return G0(this.executeImport())
        }
        static {
            this.\u0275fac = (() => {
                let t;
                return function(i) {
                    return (t || (t = gr(e)))(i || e)
                }
            })()
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-step-preview-validate"]
                ],
                standalone: !1,
                features: [_r],
                decls: 18,
                vars: 12,
                consts: [
                    [1, "step-preview-validate"],
                    [1, "step-header"],
                    [1, "mb-2"],
                    [1, "import-summary", "mb-4"],
                    [1, "row", "g-3"],
                    [1, "col-md-4"],
                    ["icon", "fa-thin fa-table-rows", "iconColor", "text-primary", "label", "total_rows", 3, "value", "subtitle"],
                    ["icon", "fa-thin fa-columns", "iconColor", "text-info", "label", "mapped_fields", 3, "value"],
                    ["icon", "fa-thin fa-file", "iconColor", "text-success", "label", "selected_file", 3, "value"],
                    [1, "upload-progress", "mb-4"],
                    [1, "preview-datagrid", "mb-4"],
                    [1, "alert", "alert-warning", "mb-4"],
                    ["role", "alert", 1, "alert", "alert-info"],
                    [1, "card"],
                    [1, "card-body"],
                    [1, "mb-3"],
                    [1, "fa-thin", "fa-cloud-arrow-up", "me-2"],
                    ["statusFormat", "{0}%", 3, "value", "showStatus"],
                    [1, "small", "mt-2", "mb-0"],
                    ["height", "400", 3, "dataSource", "showBorders", "showRowLines", "rowAlternationEnabled", "columnAutoWidth", "allowColumnReordering", "allowColumnResizing"],
                    ["mode", "virtual"],
                    [3, "enabled"],
                    ["dataField", "_rowNumber", 3, "caption", "width", "allowEditing", "fixed"],
                    [3, "dataField", "caption", "dataType"],
                    [1, "fa-thin", "fa-triangle-exclamation", "me-2"],
                    [1, "fa-thin", "fa-info-circle", "me-2"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1)(2, "h5", 2), q(3), D(), I(4, "p"), q(5), D()(), I(6, "div", 3)(7, "div", 4)(8, "div", 5), ae(9, "app-stat-card", 6), D(), I(10, "div", 5), ae(11, "app-stat-card", 7), D(), I(12, "div", 5), ae(13, "app-stat-card", 8), D()()(), ve(14, nC, 9, 4, "div", 9), ve(15, oC, 9, 15, "div", 10), ve(16, cC, 5, 2, "div", 11), ve(17, lC, 5, 2, "div", 12), D()), a & 2 && (k(3), ge(i.formatMessage("preview_data")), k(2), ge(i.formatMessage("preview_data_description")), k(4), Ce("value", i.importData.totalRows || (i.importData.data == null ? null : i.importData.data.length) || 0)("subtitle", i.formatMessageWithParams("preview_showing_rows", ja(10, rC, i.previewData.length))), k(2), Ce("value", i.previewColumns.length), k(2), Ce("value", (i.importData.file == null ? null : i.importData.file.name) || "No file"), k(), we(i.isImporting ? 14 : -1), k(), we(i.previewData != null && i.previewData.length && (i.previewColumns != null && i.previewColumns.length) ? 15 : -1), k(), we(!(i.previewData != null && i.previewData.length) || !(i.previewColumns != null && i.previewColumns.length) ? 16 : -1), k(), we((i.previewData == null ? null : i.previewData.length) > 0 ? 17 : -1))
                },
                dependencies: [Mo, wo, Eo, Co, Sn, mi],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   .step-header[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{background:linear-gradient(135deg,var(--bs-primary) 0%,var(--bs-warning) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}[_nghost-%COMP%]   .preview-container[_ngcontent-%COMP%]::-webkit-scrollbar{width:8px;height:8px}[_nghost-%COMP%]   .preview-container[_ngcontent-%COMP%]::-webkit-scrollbar-track{background:rgba(var(--bs-secondary-rgb),.05);border-radius:4px}[_nghost-%COMP%]   .preview-container[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{background:rgba(var(--bs-primary-rgb),.3);border-radius:4px}[_nghost-%COMP%]   .preview-container[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover{background:rgba(var(--bs-primary-rgb),.5)}"]
            })
        }
    }
    return e
})();
var du = (() => {
    class e {
        constructor(t) {
            this.sanitizationService = t
        }
        transform(t) {
            return this.sanitizationService.sanitizeHtml(t)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)(Z0(xi, 16))
            }
        }
        static {
            this.\u0275pipe = Q0({
                name: "sanitizeImport",
                type: e,
                pure: !0
            })
        }
    }
    return e
})();
var dC = (e, r, t) => ({
        "text-success": e,
        "text-warning": r,
        "text-danger": t
    }),
    hC = (e, r, t) => ({
        "border-success": e,
        "border-warning": r,
        "border-danger": t
    }),
    pC = (e, r) => r.row;

function mC(e, r) {
    e & 1 && (I(0, "div", 2), ae(1, "i", 17), D())
}

function xC(e, r) {
    e & 1 && (I(0, "div", 3), ae(1, "i", 18), D())
}

function gC(e, r) {
    e & 1 && (I(0, "div", 4), ae(1, "i", 19), D())
}

function _C(e, r) {
    if (e & 1 && (I(0, "div", 25)(1, "div", 26), ae(2, "i", 32), I(3, "h6", 28), q(4), D(), I(5, "small", 29), q(6), D()()()), e & 2) {
        let t = te(2);
        k(4), ge(t.failedRowsCount), k(2), ge(t.formatMessage("failed_rows"))
    }
}

function vC(e, r) {
    if (e & 1 && (I(0, "div", 7)(1, "div", 20)(2, "div", 21)(3, "div", 22)(4, "h6", 23), q(5), D(), I(6, "div", 24)(7, "div", 25)(8, "div", 26), ae(9, "i", 27), I(10, "h6", 28), q(11), D(), I(12, "small", 29), q(13), D()()(), I(14, "div", 25)(15, "div", 26), ae(16, "i", 30), I(17, "h6", 28), q(18), D(), I(19, "small", 29), q(20), D()()(), ve(21, _C, 7, 2, "div", 25), I(22, "div", 25)(23, "div", 26), ae(24, "i", 31), I(25, "h6", 28), q(26), D(), I(27, "small", 29), q(28), D()()()()()()()()), e & 2) {
        let t = te();
        k(2), Ce("ngClass", fs(9, hC, t.hasErrors === !1, t.hasErrors && t.importedCount > 0, t.hasErrors && t.importedCount === 0)), k(3), ge(t.formatMessage("import_summary")), k(6), ge(t.totalRows), k(2), ge(t.formatMessage("total_rows")), k(5), ge(t.importedCount), k(2), ge(t.formatMessage("imported_successfully")), k(), we(t.hasErrors ? 21 : -1), k(5), Fe("", t.timeTaken, "s"), k(2), ge(t.formatMessage("time_taken"))
    }
}

function wC(e, r) {
    if (e & 1 && (I(0, "tr", 43)(1, "td")(2, "strong"), q(3), D()(), ae(4, "td", 44), so(5, "sanitizeImport"), D()), e & 2) {
        let t = r.$implicit;
        k(3), ge(t.row), k(), Ce("innerHTML", oo(5, 2, t.message), K0)
    }
}

function SC(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "div", 8)(1, "div", 33)(2, "div", 34)(3, "div", 35)(4, "span"), ae(5, "i", 36), q(6), D(), I(7, "dx-button", 37), it("onClick", function() {
            qe(t);
            let i = te();
            return je(i.downloadErrorReport())
        }), D()(), I(8, "div", 38)(9, "div", 39)(10, "table", 40)(11, "thead")(12, "tr")(13, "th", 41), q(14), D(), I(15, "th", 42), q(16), D()()(), I(17, "tbody"), vr(18, wC, 6, 4, "tr", 43, pC), D()()()()()()()
    }
    if (e & 2) {
        let t = te();
        k(6), rt(" ", t.formatMessage("import_errors"), " (", t.errors.length, ") "), k(), Ce("text", t.formatMessage("download_error_report")), k(7), ge(t.formatMessage("row")), k(2), ge(t.formatMessage("error")), k(2), wr(t.errors)
    }
}
var hu = (() => {
    class e extends Er {
        constructor() {
            super(...arguments), this.sanitizationService = De(xi), this.nativeFileService = De(vn), this.startNewImport = new Ta, this.viewImportedData = new Ta
        }
        get errors() {
            return this.importData.importResult ? .data ? .errors || []
        }
        get hasErrors() {
            return this.errors.length > 0
        }
        get errorsCount() {
            return this.importData.importResult ? .data ? .errors_count || 0
        }
        get failedRowsCount() {
            return this.importData.importResult ? .data ? .failed_rows_count || 0
        }
        get importedCount() {
            return this.importData.importResult ? .data ? .imported_count || 0
        }
        get totalRows() {
            return this.importedCount + this.failedRowsCount
        }
        get timeTaken() {
            return this.importData.importResult ? .data ? .time_taken || 0
        }
        getHeaderMessage() {
            return this.hasErrors ? this.importedCount > 0 ? this.formatMessage("import_completed_with_errors") : this.formatMessage("import_failed") : this.formatMessage("import_completed_successfully")
        }
        onStartNewImport() {
            this.startNewImport.emit()
        }
        onViewImportedData() {
            this.viewImportedData.emit()
        }
        formatErrorValues(t) {
            return !t || typeof t != "object" ? [] : Object.keys(t).map(a => ({
                key: a,
                value: t[a] || "N/A"
            }))
        }
        downloadErrorReport() {
            return Qt(this, null, function*() {
                if (!this.errors || this.errors.length === 0) {
                    this.toastr.warning(this.formatMessage("no_errors_to_download"));
                    return
                }
                let t = new Set;
                this.errors.forEach(u => {
                    u.values && typeof u.values == "object" && Object.keys(u.values).forEach(h => t.add(h))
                });
                let a = Array.from(t),
                    n = [
                        ["Row", "Error Message", ...a], ...this.errors.map(u => [String(u.row), this.sanitizationService.sanitizeForCSV(u.message), ...a.map(h => this.sanitizationService.sanitizeForCSV(u.values ? .[h] || "N/A"))])
                    ],
                    s = jr.aoa_to_sheet(n),
                    o = jr.book_new();
                jr.book_append_sheet(o, s, "Import Errors"), s["!cols"] = [{
                    wch: 8
                }, {
                    wch: 50
                }, ...a.map(() => ({
                    wch: 20
                }))];
                let c = on(o, {
                        bookType: "xlsx",
                        type: "array"
                    }),
                    l = new Blob([c], {
                        type: "application/octet-stream"
                    }),
                    f = `${this.importData.type}_import_errors_${new Date().getTime()}.xlsx`;
                yield this.nativeFileService.downloadFile(l, f), this.toastr.success(this.formatMessage("error_report_downloaded"))
            })
        }
        get successMessage() {
            let t = this.importData.importResult;
            return t ? t.message || "" : this.formatMessage("import_completed")
        }
        submit() {
            return fr(!0)
        }
        static {
            this.\u0275fac = (() => {
                let t;
                return function(i) {
                    return (t || (t = gr(e)))(i || e)
                }
            })()
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-step-complete"]
                ],
                outputs: {
                    startNewImport: "startNewImport",
                    viewImportedData: "viewImportedData"
                },
                standalone: !1,
                features: [_r],
                decls: 26,
                vars: 18,
                consts: [
                    [1, "step-complete"],
                    [1, "text-center", "py-5"],
                    [1, "success-icon", "mb-4"],
                    [1, "warning-icon", "mb-4"],
                    [1, "error-icon", "mb-4"],
                    [1, "mb-3", 3, "ngClass"],
                    [1, "mb-4"],
                    [1, "row", "justify-content-center", "mb-5"],
                    [1, "row", "justify-content-center", "mb-4"],
                    [1, "action-buttons"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-eye", 1, "me-3", 3, "onClick", "text"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-plus", 3, "onClick", "text"],
                    [1, "tips", "mt-5"],
                    ["role", "alert", 1, "alert", "alert-info", "d-inline-block", "text-start"],
                    [1, "alert-heading"],
                    [1, "fa-thin", "fa-lightbulb", "me-2"],
                    [1, "mb-0"],
                    [1, "fa-thin", "fa-circle-check", "fa-6x", "text-success"],
                    [1, "fa-thin", "fa-triangle-exclamation", "fa-6x", "text-warning"],
                    [1, "fa-thin", "fa-circle-xmark", "fa-6x", "text-danger"],
                    [1, "col-md-8"],
                    [1, "card", 3, "ngClass"],
                    [1, "card-body"],
                    [1, "card-title", "mb-3"],
                    [1, "row", "g-3"],
                    [1, "col-md-3"],
                    [1, "summary-stat"],
                    [1, "fa-thin", "fa-table-rows", "fa-2x", "text-primary", "mb-2"],
                    [1, "mb-1"],
                    [1, ""],
                    [1, "fa-thin", "fa-circle-check", "fa-2x", "text-success", "mb-2"],
                    [1, "fa-thin", "fa-clock", "fa-2x", "text-info", "mb-2"],
                    [1, "fa-thin", "fa-circle-xmark", "fa-2x", "text-danger", "mb-2"],
                    [1, "col-md-10"],
                    [1, "card", "border-danger"],
                    [1, "card-header", "bg-danger", "text-white", "d-flex", "justify-content-between", "align-items-center"],
                    [1, "fa-thin", "fa-triangle-exclamation", "me-2"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-download", 3, "onClick", "text"],
                    [1, "card-body", 2, "max-height", "400px", "overflow-y", "auto"],
                    [1, "table-responsive"],
                    [1, "table", "table-sm", "table-hover", "mb-0"],
                    ["width", "15%"],
                    ["width", "85%"],
                    [1, "table-danger"],
                    [3, "innerHTML"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 0)(1, "div", 1), ve(2, mC, 2, 0, "div", 2), ve(3, xC, 2, 0, "div", 3), ve(4, gC, 2, 0, "div", 4), I(5, "h4", 5), q(6), D(), I(7, "p", 6), q(8), D(), ve(9, vC, 29, 13, "div", 7), ve(10, SC, 20, 5, "div", 8), I(11, "div", 9)(12, "dx-button", 10), it("onClick", function() {
                        return i.onViewImportedData()
                    }), D(), I(13, "dx-button", 11), it("onClick", function() {
                        return i.onStartNewImport()
                    }), D()(), I(14, "div", 12)(15, "div", 13)(16, "h6", 14), ae(17, "i", 15), q(18), D(), I(19, "ul", 16)(20, "li"), q(21), D(), I(22, "li"), q(23), D(), I(24, "li"), q(25), D()()()()()()), a & 2 && (k(2), we(i.hasErrors === !1 ? 2 : -1), k(), we(i.hasErrors && i.importedCount > 0 ? 3 : -1), k(), we(i.hasErrors && i.importedCount === 0 ? 4 : -1), k(), Ce("ngClass", fs(14, dC, i.hasErrors === !1, i.hasErrors && i.importedCount > 0, i.hasErrors && i.importedCount === 0)), k(), ge(i.getHeaderMessage()), k(2), ge(i.successMessage), k(), we(i.importData.importResult ? 9 : -1), k(), we(i.hasErrors && i.errors.length > 0 ? 10 : -1), k(2), Ce("text", i.formatMessage("view_imported_data")), k(), Ce("text", i.formatMessage("start_new_import")), k(5), Fe(" ", i.formatMessage("tips"), " "), k(3), ge(i.formatMessage("import_tip_1")), k(2), ge(i.formatMessage("import_tip_2")), k(2), ge(i.formatMessage("import_tip_3")))
                },
                dependencies: [dn, la, du],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]   .success-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_successPulse 2s ease-in-out infinite}[_nghost-%COMP%]   .warning-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_warningShake 2s ease-in-out infinite}[_nghost-%COMP%]   h4.text-success[_ngcontent-%COMP%]{background:linear-gradient(135deg,var(--bs-success) 0%,#059669 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}[_nghost-%COMP%]   h4.text-warning[_ngcontent-%COMP%]{background:linear-gradient(135deg,var(--bs-warning) 0%,#d97706 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}[_nghost-%COMP%]   h4.text-danger[_ngcontent-%COMP%]{background:linear-gradient(135deg,var(--bs-danger) 0%,#c81e1e 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}[_nghost-%COMP%]   .card-body[_ngcontent-%COMP%]::-webkit-scrollbar{width:8px}[_nghost-%COMP%]   .card-body[_ngcontent-%COMP%]::-webkit-scrollbar-track{background:rgba(var(--bs-danger-rgb),.05);border-radius:4px}[_nghost-%COMP%]   .card-body[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{background:rgba(var(--bs-danger-rgb),.3);border-radius:4px}[_nghost-%COMP%]   .card-body[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover{background:rgba(var(--bs-danger-rgb),.5)}@keyframes _ngcontent-%COMP%_successPulse{0%,to{transform:scale(1)}50%{transform:scale(1.05)}}@keyframes _ngcontent-%COMP%_warningShake{0%,to{transform:translate(0)}25%{transform:translate(-4px) rotate(-2deg)}75%{transform:translate(4px) rotate(2deg)}}"]
            })
        }
    }
    return e
})();
var CC = ["stepComponent"];

function TC(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "app-step-select-type", 15, 0), it("typeSelected", function() {
            qe(t);
            let i = te();
            return je(i.onNextButtonClick())
        }), D()
    }
    if (e & 2) {
        let t = te();
        Ce("importData", t.importData)
    }
}

function yC(e, r) {
    if (e & 1 && ae(0, "app-step-upload-file", 10, 0), e & 2) {
        let t = te();
        Ce("importData", t.importData)
    }
}

function kC(e, r) {
    if (e & 1 && ae(0, "app-step-map-fields", 10, 0), e & 2) {
        let t = te();
        Ce("importData", t.importData)
    }
}

function FC(e, r) {
    if (e & 1 && ae(0, "app-step-select-defaults", 10, 0), e & 2) {
        let t = te();
        Ce("importData", t.importData)
    }
}

function AC(e, r) {
    if (e & 1 && ae(0, "app-step-preview-validate", 10, 0), e & 2) {
        let t = te();
        Ce("importData", t.importData)
    }
}

function bC(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "app-step-complete", 16, 0), it("startNewImport", function() {
            qe(t);
            let i = te();
            return je(i.startNewImport())
        })("viewImportedData", function() {
            qe(t);
            let i = te();
            return je(i.viewImportedData())
        }), D()
    }
    if (e & 2) {
        let t = te();
        Ce("importData", t.importData)
    }
}

function IC(e, r) {
    if (e & 1) {
        let t = st();
        I(0, "dx-button", 17), it("onClick", function() {
            qe(t);
            let i = te();
            return je(i.onNextButtonClick())
        }), D()
    }
    if (e & 2) {
        let t = te();
        Ce("text", t.selectedIndex === t.steps.length - 2 ? t.getImportButtonText() : t.getNextButtonText())("disabled", !t.canNavigateNext || t.isImporting())
    }
}

function MC(e, r) {
    if (e & 1 && (I(0, "p", 23), q(1), D()), e & 2) {
        let t = te(2);
        k(), rt(" ", t.formatMessage("processing_rows"), ": ", t.progressService.rowProgressText(), " ")
    }
}

function OC(e, r) {
    if (e & 1 && (I(0, "div", 14)(1, "div", 18)(2, "h6", 19), q(3), D(), ae(4, "dx-progress-bar", 20), I(5, "p", 21), ae(6, "i", 22), q(7), D(), ve(8, MC, 2, 2, "p", 23), I(9, "div", 24), ae(10, "i", 25), I(11, "small"), q(12), D()()()()), e & 2) {
        let t = te();
        k(3), ge(t.formatMessage("import_in_progress")), k(), Ce("min", 0)("max", 100)("value", t.progressService.progress())("showStatus", !0), k(3), Fe(" ", t.progressService.status(), " "), k(), we(t.progressService.totalRows() > 0 ? 8 : -1), k(4), ge(t.formatMessage("do_not_close_window"))
    }
}
var pu = (() => {
    class e {
        constructor() {
            this.router = De(uo), this.route = De(lo), this.toastr = De(pn), this.progressService = De(En), this.formatMessage = pe, this.selectedIndex = 0, this.isStepperReadonly = !1, this.maxReachedStep = 0, this.importData = {
                type: null,
                file: null,
                mappings: [],
                data: [],
                validationResult: null,
                importResult: null
            }, this.steps = [{
                text: pe("select_import_type"),
                label: pe("select_import_type"),
                icon: "fa-thin fa-list",
                validationStatus: "pending"
            }, {
                text: pe("upload_file"),
                label: pe("upload_file"),
                icon: "fa-thin fa-upload",
                validationStatus: "pending"
            }, {
                text: pe("map_fields"),
                label: pe("map_fields"),
                icon: "fa-thin fa-diagram-project",
                validationStatus: "pending"
            }, {
                text: pe("select_defaults"),
                label: pe("select_defaults"),
                icon: "fa-thin fa-sliders",
                validationStatus: "pending"
            }, {
                text: pe("preview_validate"),
                label: pe("preview_validate"),
                icon: "fa-thin fa-magnifying-glass-chart",
                validationStatus: "pending"
            }, {
                text: pe("complete"),
                label: pe("complete"),
                icon: "fa-thin fa-circle-check",
                validationStatus: "pending"
            }], this.isImporting = this.progressService.isImporting
        }
        get canNavigateBack() {
            return !this.isImporting() && this.selectedIndex > 0
        }
        get canNavigateNext() {
            return !this.isImporting() && this.selectedIndex < this.steps.length - 1
        }
        get canClickStepper() {
            return !this.isImporting()
        }
        ngOnInit() {
            this.progressService.reset(), this.route.queryParams.subscribe(t => {
                let a = t.type;
                a && Object.values(be).includes(a) && (this.importData.type = a, this.steps[0].validationStatus = "valid", this.selectedIndex = 1, this.maxReachedStep = 1)
            })
        }
        onSelectionChanging(t) {
            let {
                component: a,
                addedItems: i,
                removedItems: n
            } = t, s = a.option("items") || [], o = s.findIndex(u => u === i[0]), c = s.findIndex(u => u === n[0]), l = c > -1 && o > c;
            if (c > -1 && o < c) {
                if (o <= this.maxReachedStep) return;
                t.cancel = !0, this.toastr.warning(pe("complete_current_step_first"));
                return
            }
            if (l) {
                if (o > c + 1 && o > this.maxReachedStep) {
                    t.cancel = !0, this.toastr.warning(pe("complete_current_step_first"));
                    return
                }
                let u = this.getValidationResult(c);
                this.setStepValidationResult(c, u), u || (t.cancel = !0, this.toastr.error(pe("fix_errors_before_continue")))
            }
        }
        getValidationResult(t) {
            if (t !== this.selectedIndex) return console.warn("Cannot validate step", t, "- component not rendered (current step:", this.selectedIndex, ")"), !0;
            let a = this.stepComponents.first;
            if (a && typeof a.submit == "function") try {
                let i = a.submit();
                return i instanceof ss ? !0 : !!i
            } catch (i) {
                return console.error("Step validation error:", i), !1
            }
            return !0
        }
        setStepValidationResult(t, a) {
            this.steps[t].validationStatus = a ? "valid" : "invalid"
        }
        onPrevButtonClick() {
            this.canNavigateBack && this.selectedIndex--
        }
        onNextButtonClick() {
            return Qt(this, null, function*() {
                if (!this.canNavigateNext) return;
                let t = this.stepComponents.first;
                if (t && typeof t.submit == "function") try {
                    let a = t.submit();
                    a instanceof ss ? (yield ln(a)) ? (this.setStepValidationResult(this.selectedIndex, !0), this.selectedIndex++, this.selectedIndex > this.maxReachedStep && (this.maxReachedStep = this.selectedIndex)) : (this.setStepValidationResult(this.selectedIndex, !1), this.toastr.error(pe("fix_errors_before_continue"))) : typeof a == "boolean" && (a ? (this.setStepValidationResult(this.selectedIndex, !0), this.selectedIndex++, this.selectedIndex > this.maxReachedStep && (this.maxReachedStep = this.selectedIndex)) : (this.setStepValidationResult(this.selectedIndex, !1), this.toastr.error(pe("fix_errors_before_continue"))))
                } catch (a) {
                    console.error("Step validation error:", a), this.setStepValidationResult(this.selectedIndex, !1), this.toastr.error(pe("validation_failed"))
                } else console.log("No validation method, moving to next step"), this.selectedIndex++, this.selectedIndex > this.maxReachedStep && (this.maxReachedStep = this.selectedIndex), console.log("New step index:", this.selectedIndex);
                console.log("=== End onNextButtonClick() ===")
            })
        }
        getNextButtonText() {
            return this.selectedIndex === this.steps.length - 1 ? pe("finish") : this.selectedIndex === this.steps.length - 2 ? pe("import") : pe("next")
        }
        getImportButtonText() {
            let t = this.importData.totalRows || this.importData.data ? .length || 0,
                a = t === 1 ? pe("row") : pe("rows");
            return `${pe("import_all")} ${t} ${a}`
        }
        canDeactivate() {
            return this.isImporting() ? To(pe("import_in_progress_warning"), pe("confirm_leave")).then(t => t) : !0
        }
        unloadNotification(t) {
            this.isImporting() && (t.returnValue = pe("import_in_progress_warning"))
        }
        startNewImport() {
            this.importData = {
                type: null,
                file: null,
                mappings: [],
                data: [],
                totalRows: void 0,
                validationResult: null,
                importResult: null
            }, this.selectedIndex = 0, this.maxReachedStep = 0, this.steps.forEach(t => t.validationStatus = "pending"), this.progressService.reset()
        }
        viewImportedData() {
            if (this.importData.type) {
                let a = {
                    customer: "/customers",
                    employee: "/employees",
                    lead: "/leads",
                    part: "/parts",
                    device_type: "/administrations/device-types",
                    device_brand: "/administrations/device-brands",
                    device_model: "/administrations/device-models"
                }[this.importData.type];
                a && this.router.navigate([a])
            }
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = nt({
                type: e,
                selectors: [
                    ["app-import-wizard"]
                ],
                viewQuery: function(a, i) {
                    if (a & 1 && ro(CC, 5), a & 2) {
                        let n;
                        ao(n = io()) && (i.stepComponents = n)
                    }
                },
                hostBindings: function(a, i) {
                    a & 1 && it("beforeunload", function(s) {
                        return i.unloadNotification(s)
                    }, J0)
                },
                standalone: !1,
                decls: 32,
                vars: 18,
                consts: [
                    ["stepComponent", ""],
                    [1, "container-fluid", "py-4"],
                    [1, "row"],
                    [1, "col-12"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-4"],
                    [1, "mb-0"],
                    [1, "card", "shadow-sm"],
                    [1, "card-body", "p-4"],
                    [3, "selectedIndexChange", "onSelectionChanging", "dataSource", "selectedIndex", "disabled"],
                    [1, "mt-4", 3, "selectedIndexChange", "selectedIndex", "animationEnabled", "loop", "swipeEnabled"],
                    [3, "importData"],
                    [1, "d-flex", "justify-content-between", "mt-4", "pt-3", "border-top"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-arrow-left", 3, "onClick", "text", "disabled"],
                    ["type", "success", "stylingMode", "contained", "iconPosition", "right", "icon", "fa-thin fa-arrow-right", 3, "text", "disabled"],
                    [1, "import-overlay", "position-fixed", "top-0", "start-0", "w-100", "h-100", 2, "background", "rgba(0,0,0,0.5)", "z-index", "1050"],
                    [3, "typeSelected", "importData"],
                    [3, "startNewImport", "viewImportedData", "importData"],
                    ["type", "success", "stylingMode", "contained", "iconPosition", "right", "icon", "fa-thin fa-arrow-right", 3, "onClick", "text", "disabled"],
                    [1, "position-absolute", "top-50", "start-50", "translate-middle", "rounded", "p-4", "shadow", "theme-secondary-bg", 2, "min-width", "400px", "max-width", "500px", "z-index", "1060"],
                    [1, "mb-3", "text-center"],
                    ["statusFormat", "{0}%", 3, "min", "max", "value", "showStatus"],
                    [1, "mt-3", "mb-2", "text-center"],
                    [1, "fa-thin", "fa-spinner", "fa-spin", "me-2"],
                    [1, "small", "text-center", "mb-2"],
                    ["role", "alert", 1, "alert", "alert-warning", "mb-0", "mt-3"],
                    [1, "fa-thin", "fa-exclamation-triangle", "me-2"]
                ],
                template: function(a, i) {
                    a & 1 && (I(0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "h3", 5), q(5), D()(), I(6, "div", 6)(7, "div", 7)(8, "dx-stepper", 8), ir("selectedIndexChange", function(s) {
                        return ar(i.selectedIndex, s) || (i.selectedIndex = s), s
                    }), it("onSelectionChanging", function(s) {
                        return i.onSelectionChanging(s)
                    }), D(), I(9, "dx-multi-view", 9), ir("selectedIndexChange", function(s) {
                        return ar(i.selectedIndex, s) || (i.selectedIndex = s), s
                    }), I(10, "dxi-item")(11, "div"), ve(12, TC, 2, 1, "app-step-select-type", 10), D()(), I(13, "dxi-item")(14, "div"), ve(15, yC, 2, 1, "app-step-upload-file", 10), D()(), I(16, "dxi-item")(17, "div"), ve(18, kC, 2, 1, "app-step-map-fields", 10), D()(), I(19, "dxi-item")(20, "div"), ve(21, FC, 2, 1, "app-step-select-defaults", 10), D()(), I(22, "dxi-item")(23, "div"), ve(24, AC, 2, 1, "app-step-preview-validate", 10), D()(), I(25, "dxi-item")(26, "div"), ve(27, bC, 2, 1, "app-step-complete", 10), D()()(), I(28, "div", 11)(29, "dx-button", 12), it("onClick", function() {
                        return i.onPrevButtonClick()
                    }), D(), ve(30, IC, 1, 2, "dx-button", 13), D()()()()()(), ve(31, OC, 13, 8, "div", 14)), a & 2 && (k(5), ge(i.formatMessage("import_data")), k(3), Ce("dataSource", i.steps), rr("selectedIndex", i.selectedIndex), Ce("disabled", i.isImporting()), k(), rr("selectedIndex", i.selectedIndex), Ce("animationEnabled", !0)("loop", !1)("swipeEnabled", !1), k(3), we(i.selectedIndex === 0 ? 12 : -1), k(3), we(i.selectedIndex === 1 ? 15 : -1), k(3), we(i.selectedIndex === 2 ? 18 : -1), k(3), we(i.selectedIndex === 3 ? 21 : -1), k(3), we(i.selectedIndex === 4 ? 24 : -1), k(3), we(i.selectedIndex === 5 ? 27 : -1), k(2), Ce("text", i.formatMessage("previous"))("disabled", !i.canNavigateBack || i.isImporting()), k(), we(i.selectedIndex < i.steps.length - 1 ? 30 : -1), k(), we(i.isImporting() ? 31 : -1))
                },
                dependencies: [So, la, Oo, Sn, Do, Go, iu, cu, lu, uu, hu],
                styles: ["[_nghost-%COMP%]{display:block}[_nghost-%COMP%]     .dx-item-selected .dx-stepper-item-content{transform:scale(1.05)}[_nghost-%COMP%]     .dx-item-selected .dx-stepper-item-icon{background:linear-gradient(135deg,var(--bs-primary) 0%,rgba(var(--bs-primary-rgb),.8) 100%)}[_nghost-%COMP%]     .dx-stepper-item-completed .dx-stepper-item-icon{color:#fff!important}[_nghost-%COMP%]     .dx-stepper-item-completed .dx-stepper-item-icon .dx-icon{color:#fff!important}[_nghost-%COMP%]     .dx-stepper-item-completed .dx-stepper-item-icon i{color:#fff!important}[_nghost-%COMP%]     .dx-stepper-item-indicator:before{top:24px!important}[_nghost-%COMP%]     .dx-multiview-wrapper{overflow:visible!important}[_nghost-%COMP%]     .dx-multiview-item-container{overflow:visible!important}[_nghost-%COMP%]   .import-overlay[_ngcontent-%COMP%]{backdrop-filter:blur(8px);animation:_ngcontent-%COMP%_fadeIn .4s cubic-bezier(.4,0,.2,1)}[_nghost-%COMP%]   .import-overlay[_ngcontent-%COMP%]   .theme-secondary-bg[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_slideDown .4s cubic-bezier(.34,1.56,.64,1)}[_nghost-%COMP%]   .import-overlay[_ngcontent-%COMP%]     .dx-progressbar-range{background:linear-gradient(90deg,var(--bs-primary) 0%,rgba(var(--bs-primary-rgb),.85) 100%);animation:_ngcontent-%COMP%_progressShine 2s infinite}@keyframes _ngcontent-%COMP%_fadeIn{0%{opacity:0}to{opacity:1}}@keyframes _ngcontent-%COMP%_slideDown{0%{transform:translate(-50%,-55%) scale(.95);opacity:0}to{transform:translate(-50%,-50%) scale(1);opacity:1}}@keyframes _ngcontent-%COMP%_progressShine{0%{background-position:-200px 0}to{background-position:200px 0}}"]
            })
        }
    }
    return e
})();
var mu = (() => {
    class e {
        canDeactivate(t) {
            return t && t.canDeactivate ? t.canDeactivate() : !0
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275prov = er({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var DC = [{
        path: "",
        component: Wo,
        children: [{
            path: "",
            component: pu,
            canDeactivate: [mu]
        }]
    }],
    xu = (() => {
        class e {
            static {
                this.\u0275fac = function(a) {
                    return new(a || e)
                }
            }
            static {
                this.\u0275mod = un({
                    type: e
                })
            }
            static {
                this.\u0275inj = fn({
                    imports: [ds.forChild(DC), ds]
                })
            }
        }
        return e
    })();
var R4 = (() => {
    class e {
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275mod = un({
                type: e
            })
        }
        static {
            this.\u0275inj = fn({
                imports: [hn, Po, xu, mi, as]
            })
        }
    }
    return e
})();
export {
    R4 as ImportModule
};