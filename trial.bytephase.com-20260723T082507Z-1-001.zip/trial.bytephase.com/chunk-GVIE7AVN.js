import {
    i as l
} from "./chunk-X4EY4JYZ.js";
import {
    a as o
} from "./chunk-L2KSLXYG.js";
var A = (f, i) => {
    var t, a, r;
    let s = "40px",
        c = i.direction === "back",
        E = i.enteringEl,
        m = i.leavingEl,
        d = l(E),
        g = d.querySelector("ion-toolbar"),
        n = o();
    if (n.addElement(d).fill("both").beforeRemoveClass("ion-page-invisible"), c ? n.duration(((t = i.duration) !== null && t !== void 0 ? t : 0) || 200).easing("cubic-bezier(0.47,0,0.745,0.715)") : n.duration(((a = i.duration) !== null && a !== void 0 ? a : 0) || 280).easing("cubic-bezier(0.36,0.66,0.04,1)").fromTo("transform", `translateY(${s})`, "translateY(0px)").fromTo("opacity", .01, 1), g) {
        let e = o();
        e.addElement(g), n.addAnimation(e)
    }
    if (m && c) {
        n.duration(((r = i.duration) !== null && r !== void 0 ? r : 0) || 200).easing("cubic-bezier(0.47,0,0.745,0.715)");
        let e = o();
        e.addElement(l(m)).onFinish(b => {
            b === 1 && e.elements.length > 0 && e.elements[0].style.setProperty("display", "none")
        }).fromTo("transform", "translateY(0px)", `translateY(${s})`).fromTo("opacity", 1, 0), n.addAnimation(e)
    }
    return n
};
export {
    A as a
};