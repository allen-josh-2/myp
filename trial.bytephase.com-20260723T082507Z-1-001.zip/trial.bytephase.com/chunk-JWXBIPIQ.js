import {
    a as xe
} from "./chunk-73S5G3JB.js";
import {
    Af as Ze,
    Cg as ii,
    Db as Qe,
    Dg as ti,
    Ja as ee,
    Pc as ie,
    T as Ie,
    Ta as Be,
    Uc as We,
    Va as U,
    Zd as Z,
    _d as y,
    _g as Pe,
    ab as H,
    ca as q,
    cb as Y,
    dc as qe,
    e as G,
    eb as ge,
    ed as Te,
    g as F,
    h as I,
    ha as W,
    kd as Ue,
    lb as Oe,
    le as we,
    md as He,
    n as J,
    nd as Ye,
    od as De,
    pb as K,
    qd as M,
    rd as X,
    sb as z,
    sd as Ke,
    t as B,
    td as ze,
    u as O,
    vc as Ve,
    y as Q,
    yg as $e,
    zf as Xe,
    zg as ei
} from "./chunk-DCKGQUHB.js";
import {
    $a as f,
    Ab as k,
    Fa as c,
    Ib as je,
    Jb as Fe,
    Ka as b,
    Na as g,
    Pb as V,
    Pg as Le,
    Qb as T,
    Rb as D,
    Sa as j,
    Te as Ne,
    Wa as Re,
    _a as v,
    aa as he,
    ae as Ae,
    da as ye,
    ea as w,
    eb as s,
    fb as l,
    gb as p,
    ha as d,
    hb as E,
    hi as S,
    ia as m,
    oa as N,
    qa as L,
    qb as h,
    sb as _,
    t as R,
    th as ce,
    ti as Se,
    ub as n,
    ui as be,
    xk as a,
    yb as P,
    zb as x,
    zh as Je
} from "./chunk-GOPIAW4V.js";

function di(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-accessory", 3), _("accessoryCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleAccessoryPopup = !1)
        })("accessorySaveClick", function() {
            d(e);
            let i = n();
            return m(i.onAccessorySave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("deviceAccessory", e.deviceAccessory)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAccessoryPopup)
    }
}

function mi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentAccessory)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var gt = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleAccessoryPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.entity = S.DEVICE_ACCESSORY, this.currentAccessory = null, this.archiveDeleteMode = L("delete"), this.isCreate = !1, this.columns = [{
                dataField: "attachments",
                caption: a("image"),
                alignment: "center",
                cellTemplate: "attachmentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "name",
                caption: a("device_accessory"),
                width: 180,
                hidingPriority: 5,
                allowSorting: !0
            }, {
                dataField: "device_type.name",
                caption: a("common_type"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isCreate = !0, this.isVisibleAccessoryPopup = !0
        }
        onAccessorySave() {
            this.isCreate = !1, this.isVisibleAccessoryPopup = !1, this.deviceAccessory = null, this.dataGrid.getData()
        }
        edit(e) {
            this.isCreate = !1, this.deviceAccessory = e, this.isVisibleAccessoryPopup = !0
        }
        onDeleteClick(e) {
            this.currentAccessory = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentAccessory = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentAccessory = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(ii))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-accessory-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "deviceAccessory", "isCreate", "isVisiblePopup"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "accessoryCancelClick", "accessorySaveClick", "deviceAccessory", "isCreate", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, di, 1, 3, "app-accessory", 1), v(2, mi, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleAccessoryPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, ti],
                encapsulation: 2
            })
        }
    }
    return t
})();

function ui(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-add-quick_reply", 3), _("quickReplyClose", function() {
            d(e);
            let i = n();
            return m(i.isVisibleQuickReplyPopup = !1)
        })("quickReplySave", function() {
            d(e);
            let i = n();
            return m(i.onSaveQuickReply())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleQuickReplyPopup)("quickReply", e.quickReply)
    }
}

function _i(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentQuickReply)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var Nt = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleQuickReplyPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.isCreate = !1, this.currentQuickReply = null, this.archiveDeleteMode = L("delete"), this.entity = S.QUICK_REPLY, this.columns = [{
                dataField: "title",
                caption: a("common_title"),
                allowSorting: !0
            }, {
                dataField: "comment",
                caption: a("description_label"),
                cellTemplate: "commentTemplate",
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                hidingPriority: 0,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 1,
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isVisibleQuickReplyPopup = !0, this.quickReply = null, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.quickReply = e, this.isVisibleQuickReplyPopup = !0
        }
        onSaveQuickReply() {
            this.isCreate = !1, this.dataGrid.getData(), this.isVisibleQuickReplyPopup = !1
        }
        onDeleteClick(e) {
            this.currentQuickReply = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentQuickReply = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentQuickReply = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(qe))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-quick-reply-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "quickReply"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "quickReplyClose", "quickReplySave", "isCreate", "isVisiblePopup", "quickReply"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, ui, 1, 3, "app-add-quick_reply", 1), v(2, _i, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleQuickReplyPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, We],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ci(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-device-brand", 3), _("deviceBrandCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleDeviceBrandPopup = !1)
        })("deviceBrandSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onSaveDeviceBrand())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("deviceBrand", e.deviceBrand)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleDeviceBrandPopup)
    }
}

function vi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentDeviceBrand)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var Ot = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.entity = S.DEVICE_BRAND, this.isVisibleDeviceBrandPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.currentDeviceBrand = null, this.archiveDeleteMode = L("delete"), this.isCreate = !1, this.columns = [{
                dataField: "attachments",
                caption: a("image"),
                alignment: "center",
                cellTemplate: "attachmentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "name",
                caption: a("brand_title"),
                width: 180,
                hidingPriority: 5,
                allowSorting: !0
            }, {
                dataField: "device_type.name",
                caption: a("common_type"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isVisibleDeviceBrandPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.deviceBrand = e, this.isVisibleDeviceBrandPopup = !0
        }
        onSaveDeviceBrand() {
            this.isCreate = !1, this.dataGrid.getData(), this.deviceBrand = null, this.isVisibleDeviceBrandPopup = !1
        }
        onDeleteClick(e) {
            this.currentDeviceBrand = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentDeviceBrand = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentDeviceBrand = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(He))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-device-brand-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "deviceBrandCancelClick", "deviceBrandSaveClick", "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, Ci, 1, 3, "app-device-brand", 1), v(2, vi, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleDeviceBrandPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, ze],
                encapsulation: 2
            })
        }
    }
    return t
})();
var oe = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Q().group({
            id: [u.id || null],
            name: [u.name || null, [G.required]],
            hex_color: [u.hex_color || null, [G.required]],
            is_mandatory: [u.is_mandatory || !1]
        })
    }
};

function yi(t, u) {
    t & 1 && E(0, "app-skeleton-loader", 4), t & 2 && s("rows", 3)("columns", 1)
}

function Si(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-server-error", 13), _("onConflictResolved", function(i) {
            d(e);
            let r = n(3);
            return m(r.onConflictResolved(i))
        }), p()
    }
    if (t & 2) {
        let e = n(3);
        s("errorResponse", e.errorResponse)("service", e.service)("entityName", e.ENTITIES.DEVICE_COLOR.name)("entityDisplayName", "Device Color")
    }
}

function bi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "form", 6), _("ngSubmit", function() {
            d(e);
            let i = n(2);
            return m(i.save())
        }), l(1, "div", 2)(2, "app-control-container", 7), E(3, "dx-text-box", 8), p(), l(4, "app-control-container", 9), E(5, "dx-color-box", 10), p()(), v(6, Si, 1, 4, "app-server-error", 11), l(7, "app-save-cancel-footer", 12), _("cancelClick", function() {
            d(e);
            let i = n(2);
            return m(i.onClosing())
        }), p()()
    }
    if (t & 2) {
        let e = n(2);
        s("formGroup", e.form), c(6), f(e.errorResponse ? 6 : -1), c(), s("isOnPopup", !0)
    }
}

function gi(t, u) {
    if (t & 1 && (l(0, "div")(1, "div", 2)(2, "div", 3), v(3, yi, 1, 2, "app-skeleton-loader", 4), v(4, bi, 8, 3, "form", 5), p()()()), t & 2) {
        let e = n();
        c(3), f(e.form ? -1 : 3), c(), f(e.form ? 4 : -1)
    }
}
var oi = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.ENTITIES = S, this.isCreate = !0, this.isVisiblePopup = !1, this.deviceColorSaveClick = new N, this.deviceColorCancelClick = new N, this.formService = w(K), this.toastNotificationService = w(q), this.errorResponse = null, this.isSaving = !1
        }
        ngOnInit() {
            this.form = oe.getForm(new oe(this.isCreate ? {} : this.deviceColor))
        }
        asyncUniqueNameValidation(e) {
            return this.service.checkUniqueName(e.value).pipe(R(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        save() {
            this.errorResponse = null, this.isSaving = !0, this.form.valid ? (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.deviceColor = new oe(o), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "notification_device_color_add_success" : "notification_device_color_update_success"), this.deviceColorSaveClick.emit(this.deviceColor), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => {
                this.isSaving = !1
            }) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form = null, this.isCreate = !1, this.deviceColorCancelClick.emit()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.save()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(Pe))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-device-color"]
                ],
                inputs: {
                    isCreate: "isCreate",
                    deviceColor: "deviceColor",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    deviceColorSaveClick: "deviceColorSaveClick",
                    deviceColorCancelClick: "deviceColorCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["errorMsg", "Device color is a required field", "label", "Device Color Name", "name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["formControlName", "name", "placeholder", "eg:Black, Silver"],
                    ["errorMsg", "Color is a required field", "label", "Select Color", "name", "hex_color", 1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["applyValueMode", "instantly", "formControlName", "hex_color", "stylingMode", "outlined"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [3, "cancelClick", "isOnPopup"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "dx-popup", 0), _("onHidden", function() {
                        return i.onClosing()
                    }), D("visibleChange", function(C) {
                        return T(i.isVisiblePopup, C) || (i.isVisiblePopup = C), C
                    }), j(1, gi, 5, 2, "div", 1), p()), o & 2 && (V("visible", i.isVisiblePopup), s("width", "95vw")("maxWidth", 400)("title", i.isCreate ? "Add New Device Color" : "Update Device Color"), c(), s("dxTemplateOf", "content"))
                },
                dependencies: [X, z, Y, Z, W, Ve, H, U, J, F, I, O, B],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ti(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-device-color", 3), _("deviceColorCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleAddDeviceColorPopup = !1)
        })("deviceColorSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onDeviceColorSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("deviceColor", e.deviceColor)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAddDeviceColorPopup)
    }
}

function Di(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentDeviceColor)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var lo = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleAddDeviceColorPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.isCreate = !1, this.entity = S.DEVICE_COLOR, this.currentDeviceColor = null, this.archiveDeleteMode = L("delete"), this.columns = [{
                dataField: "name",
                caption: a("device_color"),
                width: 180,
                allowSorting: !0
            }, {
                dataField: "hex_color",
                caption: a("color"),
                hidingPriority: 4,
                cellTemplate: "colorTemplate",
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.deviceColor = null
        }
        create() {
            this.isVisibleAddDeviceColorPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.deviceColor = e, this.isVisibleAddDeviceColorPopup = !0
        }
        onDeviceColorSave() {
            this.isCreate = !1, this.isVisibleAddDeviceColorPopup = !1, this.deviceColor = null, this.dataGrid.getData()
        }
        onDeleteClick(e) {
            this.currentDeviceColor = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentDeviceColor = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentDeviceColor = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(Pe))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-device-color-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "deviceColor", "isCreate", "isVisiblePopup"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "deviceColorCancelClick", "deviceColorSaveClick", "deviceColor", "isCreate", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, Ti, 1, 3, "app-device-color", 1), v(2, Di, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleAddDeviceColorPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, oi],
                encapsulation: 2
            })
        }
    }
    return t
})();

function wi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-device-model-popup", 3), _("deviceModelCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleDeviceModelPopup = !1)
        })("deviceModelSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onSaveDeviceModel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("deviceModel", e.deviceModel)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleDeviceModelPopup)
    }
}

function Pi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentDeviceModel)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var yo = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleDeviceModelPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.currentDeviceModel = null, this.archiveDeleteMode = L("delete"), this.isCreate = !1, this.entity = S.DEVICE_MODEL, this.columns = [{
                dataField: "attachments",
                caption: a("image"),
                alignment: "center",
                cellTemplate: "attachmentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "name",
                caption: a("model_title"),
                hidingPriority: 6,
                width: 180,
                allowSorting: !0
            }, {
                dataField: "device_type.name",
                caption: a("common_type"),
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "device_brand.name",
                caption: a("brand_title"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isVisibleDeviceModelPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.deviceModel = e, this.isVisibleDeviceModelPopup = !0
        }
        onSaveDeviceModel() {
            this.isCreate = !1, this.dataGrid.getData(), this.deviceModel = null, this.isVisibleDeviceModelPopup = !1
        }
        onDeleteClick(e) {
            this.currentDeviceModel = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentDeviceModel = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentDeviceModel = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(Ye))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-device-model-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "deviceModel", "isCreate", "isVisiblePopup"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "deviceModelCancelClick", "deviceModelSaveClick", "deviceModel", "isCreate", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, wi, 1, 3, "app-device-model-popup", 1), v(2, Pi, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleDeviceModelPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, Ke],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ne = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Q().group({
            id: [u.id || null],
            name: [u.name || null, [G.required]],
            is_visible_on_self_checkin: [u.is_visible_on_self_checkin ? ? !0],
            attachments: [u.attachments || null]
        })
    }
};

function ki(t, u) {
    t & 1 && E(0, "app-skeleton-loader", 4), t & 2 && s("rows", 3)("columns", 1)
}

function Ei(t, u) {
    t & 1 && (l(0, "app-control-container", 10), E(1, "app-switch-btn", 15), p()), t & 2 && (s("isLabelOnSameLine", !0), c(), s("isEditMode", !0)("label", "Visible on Self Check-in"))
}

function Ai(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-server-error", 16), _("onConflictResolved", function(i) {
            d(e);
            let r = n(3);
            return m(r.onConflictResolved(i))
        }), p()
    }
    if (t & 2) {
        let e = n(3);
        s("errorResponse", e.errorResponse)("service", e.service)("entityName", e.ENTITIES.DEVICE_TYPE.name)("entityDisplayName", e.formatMessage("device_type_name"))
    }
}

function Ni(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "form", 6), _("ngSubmit", function() {
            d(e);
            let i = n(2);
            return m(i.add())
        }), l(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), E(5, "dxi-validation-rule", 9), p()()(), v(6, Ei, 2, 3, "app-control-container", 10), l(7, "div")(8, "p", 11), je(9), p(), l(10, "app-attachments", 12), _("afterSaving", function(i) {
            d(e);
            let r = n(2);
            return m(r.afterFileUpload(i))
        }), p()()(), v(11, Ai, 1, 4, "app-server-error", 13), l(12, "app-save-cancel-footer", 14), _("cancelClick", function() {
            d(e);
            let i = n(2);
            return m(i.onClosing())
        }), p()()
    }
    if (t & 2) {
        let e = n(2);
        s("formGroup", e.form), c(2), s("errorMsg", e.formatMessage("device_type_name_required_error"))("label", e.formatMessage("device_type_name_label")), c(3), s("ignoreEmptyValue", !0)("message", e.formatMessage("validation_device_type_exists"))("validationCallback", e.asyncUniqueNameValidation), c(), f(e.isStandardOrEnterprise ? 6 : -1), c(3), Fe(e.formatMessage("upload_device_type_image")), c(), s("entity", e.deviceType)("isEditMode", !1)("attachableType", e.attachableType)("isVisibleLabel", !1)("isCustomStoragePath", !0)("isPubliclyAccessible", !0)("storagePathType", e.ENTITIES.DEVICE_TYPE.name), c(), f(e.errorResponse ? 11 : -1), c(), s("isOnPopup", !0)
    }
}

function Li(t, u) {
    if (t & 1 && (l(0, "div")(1, "div", 2)(2, "div", 3), v(3, ki, 1, 2, "app-skeleton-loader", 4), v(4, Ni, 13, 17, "form", 5), p()()()), t & 2) {
        let e = n();
        c(3), f(e.form ? -1 : 3), c(), f(e.form ? 4 : -1)
    }
}
var ni = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.ENTITIES = S, this.formService = w(K), this.applicationRef = w(Re), this.toastNotificationService = w(q), this.isStandardOrEnterprise = [Le.STANDARD, Le.ENTERPRISE].includes(w(Oe).plan()), this.isVisiblePopup = !1, this.isCreate = !0, this.deviceType = null, this.deviceTypeSaveClick = new N, this.deviceTypeCancelClick = new N, this.errorResponse = null, this.attachableType = this.ENTITIES.DEVICE_TYPE.name, this.isSaving = !1, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.deviceType = new ne(this.isCreate ? {} : this.deviceType), this.form = ne.getForm(this.deviceType)
        }
        asyncUniqueNameValidation(e) {
            return this.service.checkUniqueName({
                name: e.value,
                id: this.form ? .get("id") ? .value
            }).pipe(R(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        add() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.deviceType = new ne(o), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.deviceType), this.deviceTypeSaveClick.emit(this.deviceType), this.form = null, this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "notification_device_type_add_success" : "notification_device_type_update_success")
                },
                error: o => {
                    this.isSaving = !1, this.errorResponse = o
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.deviceType = null, this.deviceTypeCancelClick.emit()
        }
        afterFileUpload(e) {
            e || (this.isSaving = !1, this.deviceTypeSaveClick.emit(this.deviceType)), this.isSaving = !1
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.add()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(De))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-device-type"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(Te, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.attachmentInstance = r.first)
                    }
                },
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate",
                    deviceType: "deviceType"
                },
                outputs: {
                    deviceTypeSaveClick: "deviceTypeSaveClick",
                    deviceTypeCancelClick: "deviceTypeCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", "placeholder", "eg.desktop, laptop, etc"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    ["name", "is_visible_on_self_checkin", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "isLabelOnSameLine"],
                    [1, "mb-0"],
                    ["formControlName", "attachments", "id", "device-type-attachment", "accept", "image/*", 3, "afterSaving", "entity", "isEditMode", "attachableType", "isVisibleLabel", "isCustomStoragePath", "isPubliclyAccessible", "storagePathType"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [3, "cancelClick", "isOnPopup"],
                    ["formControlName", "is_visible_on_self_checkin", 3, "isEditMode", "label"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "dx-popup", 0), _("onHidden", function() {
                        return i.onClosing()
                    }), D("visibleChange", function(C) {
                        return T(i.isVisiblePopup, C) || (i.isVisiblePopup = C), C
                    }), j(1, Li, 5, 2, "div", 1), p()), o & 2 && (V("visible", i.isVisiblePopup), s("width", "95vw")("maxWidth", 400)("title", i.isCreate ? i.formatMessage("device_type_add_new") : i.formatMessage("device_type_update")), c(), s("dxTemplateOf", "content"))
                },
                dependencies: [X, z, Te, Y, Z, Ue, W, ee, H, U, ie, J, F, I, O, B],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Gi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-device-type", 2), _("deviceTypeCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleAddDeviceTypePopup = !1)
        })("deviceTypeSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onDeviceTypeSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("deviceType", e.deviceType)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAddDeviceTypePopup)
    }
}
var Bo = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleAddDeviceTypePopup = !1, this.isCreate = !1, this.entity = S.DEVICE_TYPE, this.columns = [{
                dataField: "attachments",
                caption: a("image"),
                alignment: "center",
                cellTemplate: "attachmentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "name",
                caption: a("device_type_name"),
                width: 240,
                hidingPriority: 6,
                allowSorting: !0
            }, {
                dataField: "is_visible_on_self_checkin",
                caption: a("self_checkin_visible"),
                hidingPriority: 5,
                allowSorting: !1,
                cellTemplate: "booleanTemplate"
            }, {
                dataField: "device_brands_count",
                caption: a("brands"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "accessories_count",
                caption: a("accessory"),
                hidingPriority: 2,
                allowSorting: !1
            }, {
                dataField: "repair_services_count",
                caption: a("repair_services"),
                hidingPriority: 1,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.deviceType = null
        }
        create() {
            this.isVisibleAddDeviceTypePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.deviceType = e, this.isVisibleAddDeviceTypePopup = !0
        }
        onDeviceTypeSave() {
            this.isCreate = !1, this.isVisibleAddDeviceTypePopup = !1, this.deviceType = null, this.dataGrid.getData()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(De))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-device-type-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "deviceType", "isCreate", "isVisiblePopup"],
                    [3, "deviceTypeCancelClick", "deviceTypeSaveClick", "deviceType", "isCreate", "isVisiblePopup"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    }), p(), v(1, Gi, 1, 3, "app-device-type", 1)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleAddDeviceTypePopup ? 1 : -1))
                },
                dependencies: [y, ni],
                encapsulation: 2
            })
        }
    }
    return t
})();
var re = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Q().group({
            id: [u.id || null],
            name: [u.name || null, [G.required]]
        })
    }
};
var ke = (() => {
    class t extends Se {
        constructor(e) {
            super(e, Ne), this.api = e, this.endpoint = Ne
        }
        checkUniqueName(e) {
            return this.api.post(this.endpoint + "/checkUniqueName", e)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(ye(be))
            }
        }
        static {
            this.\u0275prov = he({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function ji(t, u) {
    t & 1 && E(0, "app-skeleton-loader", 4), t & 2 && s("rows", 3)("columns", 1)
}

function Fi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-server-error", 12), _("onConflictResolved", function(i) {
            d(e);
            let r = n(3);
            return m(r.onConflictResolved(i))
        }), p()
    }
    if (t & 2) {
        let e = n(3);
        s("errorResponse", e.errorResponse)("service", e.service)("entityName", e.entity.name)("entityDisplayName", "Source")
    }
}

function Ii(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "form", 6), _("ngSubmit", function() {
            d(e);
            let i = n(2);
            return m(i.saveSource())
        }), l(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), E(5, "dxi-validation-rule", 9), p()()()(), v(6, Fi, 1, 4, "app-server-error", 10), l(7, "app-save-cancel-footer", 11), _("cancelClick", function() {
            d(e);
            let i = n(2);
            return m(i.onClosing())
        }), p()()
    }
    if (t & 2) {
        let e = n(2);
        s("formGroup", e.form), c(5), s("ignoreEmptyValue", !0)("validationCallback", e.asyncUniqueNameValidation)("message", e.formatMessage("source_name_already_exists")), c(), f(e.errorResponse ? 6 : -1), c(), s("isOnPopup", !0)
    }
}

function Ji(t, u) {
    if (t & 1 && (l(0, "div")(1, "div", 2)(2, "div", 3), v(3, ji, 1, 2, "app-skeleton-loader", 4), v(4, Ii, 8, 6, "form", 5), p()()()), t & 2) {
        let e = n();
        c(3), f(e.form ? -1 : 3), c(), f(e.form ? 4 : -1)
    }
}
var ai = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isCreate = !0, this.isVisiblePopup = !1, this.jobSourceSaveClick = new N, this.jobSourceCancelClick = new N, this.formService = w(K), this.commonService = w(ge), this.toastNotificationService = w(q), this.entity = S.JOB_SOURCE, this.errorResponse = null, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.isVisiblePopup = !0, this.form = re.getForm(new re(this.isCreate ? {} : this.jobSource))
        }
        saveSource() {
            this.errorResponse = null, this.form.valid ? (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.jobSource = new re(o), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "source_added_successfully" : "source_updated_successfully"), this.jobSourceSaveClick.emit(this.jobSource), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                }
            }) : this.formService.validateFormFields(this.form)
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.entity.table,
                name: e.value,
                entity_id: this.jobSource ? .id
            }).pipe(R(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form = null, this.isCreate = !1, this.jobSourceCancelClick.emit()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.saveSource()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(ke))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-job-source"]
                ],
                inputs: {
                    jobSource: "jobSource",
                    isCreate: "isCreate",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    jobSourceSaveClick: "jobSourceSaveClick",
                    jobSourceCancelClick: "jobSourceCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHiding", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["errorMsg", "Source is a required field", "label", "Source", "name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["formControlName", "name", "placeholder", "eg:Website, Google"],
                    ["type", "async", 3, "ignoreEmptyValue", "validationCallback", "message"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [3, "cancelClick", "isOnPopup"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "dx-popup", 0), _("onHiding", function() {
                        return i.onClosing()
                    }), D("visibleChange", function(C) {
                        return T(i.isVisiblePopup, C) || (i.isVisiblePopup = C), C
                    }), j(1, Ji, 5, 2, "div", 1), p()), o & 2 && (V("visible", i.isVisiblePopup), s("width", "95vw")("maxWidth", 400)("title", i.jobSource != null && i.jobSource.id ? "Update Source" : "Add New Source"), c(), s("dxTemplateOf", "content"))
                },
                dependencies: [X, z, Y, Z, W, ee, H, U, ie, J, F, I, O, B],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Oi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-job-source", 2), _("jobSourceCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleJobSourcePopup = !1)
        })("jobSourceSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onJobSourceSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleJobSourcePopup)("jobSource", e.jobSource)
    }
}
var ln = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleJobSourcePopup = !1, this.entity = S.JOB_SOURCE, this.isCreate = !1, this.columns = [{
                dataField: "name",
                caption: a("user_customer_source"),
                width: 180,
                allowSorting: !0
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 2,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                width: 80,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isCreate = !0, this.isVisibleJobSourcePopup = !0
        }
        onJobSourceSave() {
            this.isCreate = !1, this.isVisibleJobSourcePopup = !1, this.jobSource = null, this.dataGrid.getData()
        }
        edit(e) {
            this.isCreate = !1, this.jobSource = e, this.isVisibleJobSourcePopup = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(ke))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-job-source-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "jobSource"],
                    [3, "jobSourceCancelClick", "jobSourceSaveClick", "isCreate", "isVisiblePopup", "jobSource"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    }), p(), v(1, Oi, 1, 3, "app-job-source", 1)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleJobSourcePopup ? 1 : -1))
                },
                dependencies: [y, ai],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ae = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Q().group({
            id: [u.id || null],
            name: [u.name || null, [G.required]],
            hex_color: [u.hex_color || null, [G.required]],
            stage: [u.stage || null, [G.required]],
            is_mandatory: [u.is_mandatory || !1]
        })
    }
};

function qi(t, u) {
    t & 1 && E(0, "app-skeleton-loader", 4), t & 2 && s("rows", 3)("columns", 1)
}

function Wi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-server-error", 16), _("onConflictResolved", function(i) {
            d(e);
            let r = n(3);
            return m(r.onConflictResolved(i))
        }), p()
    }
    if (t & 2) {
        let e = n(3);
        s("errorResponse", e.errorResponse)("service", e.jobStatusService)("entityName", e.ENTITIES.JOB_STATUS.name)("entityDisplayName", e.formatMessage("job_status_name"))
    }
}

function Ui(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "form", 6), _("ngSubmit", function() {
            d(e);
            let i = n(2);
            return m(i.create())
        }), l(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), E(5, "dxi-validation-rule", 9), p()()(), l(6, "app-control-container", 10), E(7, "dx-select-box", 11), p(), l(8, "app-control-container", 12), E(9, "dx-color-box", 13), p()(), v(10, Wi, 1, 4, "app-server-error", 14), l(11, "app-save-cancel-footer", 15), _("cancelClick", function() {
            d(e);
            let i = n(2);
            return m(i.onClosing())
        }), p()()
    }
    if (t & 2) {
        let e = n(2);
        s("formGroup", e.form), c(2), s("errorMsg", e.formatMessage("job_status_name_required"))("label", e.formatMessage("job_status_name")), c(), s("placeholder", e.formatMessage("type_status_name")), c(2), s("ignoreEmptyValue", !0)("message", e.formatMessage("status_name_exists"))("validationCallback", e.asyncUniqueNameValidation), c(), s("errorMsg", e.formatMessage("status_stage_required"))("label", e.formatMessage("status_stage")), c(), s("items", e.statusStageList)("placeholder", e.formatMessage("select_status_stage")), c(), s("errorMsg", e.formatMessage("color_required"))("label", e.formatMessage("status_color")), c(2), f(e.errorResponse ? 10 : -1), c(), s("isOnPopup", !0)
    }
}

function Hi(t, u) {
    if (t & 1 && (l(0, "div")(1, "div", 2)(2, "div", 3), v(3, qi, 1, 2, "app-skeleton-loader", 4), v(4, Ui, 12, 15, "form", 5), p()()()), t & 2) {
        let e = n();
        c(3), f(e.form ? -1 : 3), c(), f(e.form ? 4 : -1)
    }
}
var si = (() => {
    class t {
        constructor(e) {
            this.jobStatusService = e, this.formatMessage = a, this.ENTITIES = S, this.jobStatus = null, this.isVisiblePopup = !1, this.isCreate = !0, this.statusCancelClick = new N, this.statusSaveClick = new N, this.formService = w(K), this.toastNotificationService = w(q), this.errorResponse = null, this.statusStageList = Object.values(Je), this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.form = ae.getForm(this.jobStatus ? this.jobStatus : new ae({}))
        }
        create() {
            this.errorResponse = null, this.form.valid ? (this.isCreate ? this.jobStatusService.create(this.form.value) : this.jobStatusService.update(this.form.value)).subscribe({
                next: o => {
                    this.jobStatus = new ae(o), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "status_added_successfully" : "status_updated_successfully"), this.statusSaveClick.emit(this.jobStatus), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                }
            }) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.statusCancelClick.emit()
        }
        asyncUniqueNameValidation(e) {
            return this.jobStatusService.checkUniqueName(e.value).pipe(R(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.create()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(we))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-job-status"]
                ],
                inputs: {
                    jobStatus: "jobStatus",
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate"
                },
                outputs: {
                    statusCancelClick: "statusCancelClick",
                    statusSaveClick: "statusSaveClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    ["name", "stage", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "stage", 3, "items", "placeholder"],
                    ["name", "hex_color", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["applyValueMode", "instantly", "formControlName", "hex_color", "stylingMode", "outlined"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    ["saveText", "save_status", 3, "cancelClick", "isOnPopup"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "dx-popup", 0), _("onHidden", function() {
                        return i.onClosing()
                    }), D("visibleChange", function(C) {
                        return T(i.isVisiblePopup, C) || (i.isVisiblePopup = C), C
                    }), j(1, Hi, 5, 2, "div", 1), p()), o & 2 && (V("visible", i.isVisiblePopup), s("width", "95vw")("maxWidth", 400)("title", i.jobStatus != null && i.jobStatus.id ? i.formatMessage("job_update_status") : i.formatMessage("add_new_job_status")), c(), s("dxTemplateOf", "content"))
                },
                dependencies: [X, z, Y, Z, W, Ve, ee, H, Be, U, ie, J, F, I, O, B],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ki(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-job-status", 3), _("statusCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleStatusPopup = !1)
        })("statusSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onStatusSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleStatusPopup)("jobStatus", e.jobStatus)
    }
}

function zi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentJobStatus)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var kn = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isCreate = !1, this.isVisibleStatusPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.entity = S.JOB_STATUS, this.currentJobStatus = null, this.archiveDeleteMode = L("delete"), this.columns = [{
                dataField: "name",
                caption: a("common_status"),
                width: 180,
                allowSorting: !0
            }, {
                dataField: "stage",
                caption: a("status_stage"),
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "hex_color",
                caption: a("color"),
                hidingPriority: 4,
                cellTemplate: "colorTemplate",
                allowSorting: !1
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isVisibleStatusPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.jobStatus = e, this.isVisibleStatusPopup = !0
        }
        onStatusSave() {
            this.isCreate = !1, this.isVisibleStatusPopup = !1, this.jobStatus = null, this.dataGrid.getData()
        }
        onDeleteClick(e) {
            this.currentJobStatus = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentJobStatus = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentJobStatus = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(we))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-job-status-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "jobStatus"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "statusCancelClick", "statusSaveClick", "isCreate", "isVisiblePopup", "jobStatus"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, Ki, 1, 3, "app-job-status", 1), v(2, zi, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleStatusPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, si],
                encapsulation: 2
            })
        }
    }
    return t
})();
var se = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Q().group({
            id: [u.id || null],
            name: [u.name || null, [G.required]]
        })
    }
};
var Ee = (() => {
    class t extends Se {
        constructor(e) {
            super(e, Ae), this.api = e, this.endpoint = Ae
        }
        getList() {
            return this.api.get(this.endpoint + "/getList")
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(ye(be))
            }
        }
        static {
            this.\u0275prov = he({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function Xi(t, u) {
    t & 1 && E(0, "app-skeleton-loader", 4), t & 2 && s("rows", 3)("columns", 1)
}

function Zi(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-server-error", 12), _("onConflictResolved", function(i) {
            d(e);
            let r = n(3);
            return m(r.onConflictResolved(i))
        }), p()
    }
    if (t & 2) {
        let e = n(3);
        s("errorResponse", e.errorResponse)("service", e.service)("entityName", e.ENTITIES.JOB_TYPE.name)("entityDisplayName", e.formatMessage("job_type_name_label"))
    }
}

function $i(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "form", 6), _("ngSubmit", function() {
            d(e);
            let i = n(2);
            return m(i.add())
        }), l(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), E(5, "dxi-validation-rule", 9), p()()()(), v(6, Zi, 1, 4, "app-server-error", 10), l(7, "app-save-cancel-footer", 11), _("cancelClick", function() {
            d(e);
            let i = n(2);
            return m(i.onClosing())
        }), p()()
    }
    if (t & 2) {
        let e = n(2);
        s("formGroup", e.form), c(2), s("errorMsg", e.formatMessage("job_type_name_required_error"))("label", e.formatMessage("job_type_name_label")), c(3), s("ignoreEmptyValue", !0)("message", e.formatMessage("validation_job_type_exists"))("validationCallback", e.asyncUniqueNameValidation), c(), f(e.errorResponse ? 6 : -1), c(), s("isOnPopup", !0)
    }
}

function et(t, u) {
    if (t & 1 && (l(0, "div")(1, "div", 2)(2, "div", 3), v(3, Xi, 1, 2, "app-skeleton-loader", 4), v(4, $i, 8, 8, "form", 5), p()()()), t & 2) {
        let e = n();
        c(3), f(e.form ? -1 : 3), c(), f(e.form ? 4 : -1)
    }
}
var ci = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.ENTITIES = S, this.formService = w(K), this.toastNotificationService = w(q), this.commonService = w(ge), this.isVisiblePopup = !1, this.isCreate = !0, this.jobType = null, this.jobTypeSaveClick = new N, this.jobTypeCancelClick = new N, this.entity = S.JOB_TYPE, this.errorResponse = null, this.isSaving = !1, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.jobType = new se(this.isCreate ? {} : this.jobType), this.form = se.getForm(this.jobType)
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.entity.table,
                name: e.value,
                entity_id: this.jobType ? .id
            }).pipe(R(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        add() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.jobType = new se(o), this.jobTypeSaveClick.emit(this.jobType), this.form = null, this.isVisiblePopup = !1, this.isSaving = !1, this.toastNotificationService.success(this.isCreate ? "notification_job_type_add_success" : "notification_job_type_update_success")
                },
                error: o => {
                    this.isSaving = !1, this.errorResponse = o
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.jobType = null, this.jobTypeCancelClick.emit()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.add()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(Ee))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-job-type"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate",
                    jobType: "jobType"
                },
                outputs: {
                    jobTypeSaveClick: "jobTypeSaveClick",
                    jobTypeCancelClick: "jobTypeCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", "placeholder", "eg. Repair, Installation, etc"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [3, "cancelClick", "isOnPopup"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "dx-popup", 0), _("onHidden", function() {
                        return i.onClosing()
                    }), D("visibleChange", function(C) {
                        return T(i.isVisiblePopup, C) || (i.isVisiblePopup = C), C
                    }), j(1, et, 5, 2, "div", 1), p()), o & 2 && (V("visible", i.isVisiblePopup), s("width", "95vw")("maxWidth", 400)("title", i.isCreate ? i.formatMessage("job_type_add_new") : i.formatMessage("job_type_update")), c(), s("dxTemplateOf", "content"))
                },
                dependencies: [X, z, Y, Z, W, ee, H, U, ie, J, F, I, O, B],
                encapsulation: 2
            })
        }
    }
    return t
})();

function tt(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-job-type", 4), _("jobTypeCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleAddJobTypePopup = !1)
        })("jobTypeSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onJobTypeSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("jobType", e.jobType)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAddJobTypePopup)
    }
}
var Kn = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isVisibleAddJobTypePopup = !1, this.isCreate = !1, this.entity = S.JOB_TYPE, this.columns = [{
                dataField: "name",
                caption: a("job_type_name"),
                width: 240,
                hidingPriority: 6,
                allowSorting: !0
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.jobType = null
        }
        ngOnInit() {}
        create() {
            this.isVisibleAddJobTypePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.jobType = e, this.isVisibleAddJobTypePopup = !0
        }
        onJobTypeSave() {
            this.isCreate = !1, this.isVisibleAddJobTypePopup = !1, this.jobType = null, this.dataGrid.getData()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(Ee))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-job-type-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 6,
                consts: [
                    [1, "row"],
                    [1, "col-12"],
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "jobType", "isCreate", "isVisiblePopup"],
                    [3, "jobTypeCancelClick", "jobTypeSaveClick", "jobType", "isCreate", "isVisiblePopup"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "div", 0)(1, "div", 1)(2, "app-data-grid", 2), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    }), p()()(), v(3, tt, 1, 3, "app-job-type", 3)), o & 2 && (c(2), s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleAddJobTypePopup ? 3 : -1))
                },
                dependencies: [y, ci],
                encapsulation: 2
            })
        }
    }
    return t
})();

function ot(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-repair-service", 3), _("repairServiceCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleRepairServicePopup = !1)
        })("repairServiceSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onReasonServiceSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleRepairServicePopup)("repairService", e.repairService)
    }
}

function nt(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentRepairService)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var ar = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.generalSettingDataService = w(Qe), this.isCreate = !1, this.isVisibleRepairServicePopup = !1, this.isVisibleArchiveDeletePopup = !1, this.entity = S.REPAIR_SERVICE, this.currentRepairService = null, this.archiveDeleteMode = L("delete"), this.columns = [{
                dataField: "name",
                caption: a("job_repair_service"),
                width: 200,
                cellTemplate: "nameTemplate",
                allowSorting: !1
            }, {
                dataField: "description",
                caption: a("repair_services_description"),
                allowSorting: !1
            }, {
                dataField: "device_type.name",
                caption: a("common_type"),
                hidingPriority: 5,
                cellTemplate: "nameTemplate",
                allowSorting: !1
            }, {
                dataField: "device_brand.name",
                caption: a("brand_title"),
                cellTemplate: "nameTemplate",
                allowSorting: !1,
                visible: this.generalSettingDataService.getGeneralSettingByKey(ce.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING),
                showInColumnChooser: this.generalSettingDataService.getGeneralSettingByKey(ce.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING)
            }, {
                dataField: "device_model.name",
                caption: a("common_model"),
                cellTemplate: "nameTemplate",
                allowSorting: !1,
                visible: this.generalSettingDataService.getGeneralSettingByKey(ce.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING),
                showInColumnChooser: this.generalSettingDataService.getGeneralSettingByKey(ce.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING)
            }, {
                dataField: "is_rate_including_tax",
                caption: a("inventory_rate_includes_tax"),
                hidingPriority: 8,
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                allowSorting: !1
            }, {
                dataField: "price",
                caption: a("common_price"),
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                width: 60,
                allowSorting: !1
            }, {
                dataField: "tax.name",
                caption: a("common_tax"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "tax_code",
                caption: a("common_tax_code"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 9,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isVisibleRepairServicePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.repairService = e, this.isVisibleRepairServicePopup = !0
        }
        onReasonServiceSave() {
            this.isCreate = !1, this.isVisibleRepairServicePopup = !1, this.repairService = null, this.dataGrid.getData()
        }
        onDeleteClick(e) {
            this.currentRepairService = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentRepairService = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentRepairService = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(Xe))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-repair-service-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "repairService"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "repairServiceCancelClick", "repairServiceSaveClick", "isCreate", "isVisiblePopup", "repairService"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, ot, 1, 3, "app-repair-service", 1), v(2, nt, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleRepairServicePopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, Ze],
                encapsulation: 2
            })
        }
    }
    return t
})();
var le = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Q().group({
            id: [u.id || null],
            name: [u.name || null, [G.required]]
        })
    }
};

function at(t, u) {
    t & 1 && E(0, "app-skeleton-loader", 4), t & 2 && s("rows", 3)("columns", 1)
}

function st(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-server-error", 11), _("onConflictResolved", function(i) {
            d(e);
            let r = n(3);
            return m(r.onConflictResolved(i))
        }), p()
    }
    if (t & 2) {
        let e = n(3);
        s("errorResponse", e.errorResponse)("service", e.service)("entityName", e.ENTITIES.STORAGE_LOCATION.name)("entityDisplayName", e.formatMessage("device_storage_location"))
    }
}

function lt(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "form", 6), _("ngSubmit", function() {
            d(e);
            let i = n(2);
            return m(i.save())
        }), l(1, "div", 2)(2, "app-control-container", 7), E(3, "dx-text-box", 8), p()(), v(4, st, 1, 4, "app-server-error", 9), l(5, "app-save-cancel-footer", 10), _("cancelClick", function() {
            d(e);
            let i = n(2);
            return m(i.onClosing())
        }), p()()
    }
    if (t & 2) {
        let e = n(2);
        s("formGroup", e.form), c(2), s("errorMsg", e.formatMessage("inventory_storage_location_error"))("label", e.formatMessage("device_storage_location")), c(), s("placeholder", e.formatMessage("storage_example")), c(), f(e.errorResponse ? 4 : -1), c(), s("isOnPopup", !0)
    }
}

function ct(t, u) {
    if (t & 1 && (l(0, "div")(1, "div", 2)(2, "div", 3), v(3, at, 1, 2, "app-skeleton-loader", 4), v(4, lt, 6, 6, "form", 5), p()()()), t & 2) {
        let e = n();
        c(3), f(e.form ? -1 : 3), c(), f(e.form ? 4 : -1)
    }
}
var pi = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.ENTITIES = S, this.isCreate = !0, this.isVisiblePopup = !1, this.storageLocationSaveClick = new N, this.storageLocationCancelClick = new N, this.formService = w(K), this.toastNotificationService = w(q), this.errorResponse = null
        }
        ngOnInit() {
            this.form = le.getForm(new le(this.isCreate ? {} : this.storageLocation))
        }
        asyncUniqueNameValidation(e) {
            return this.service.checkUniqueName(e.value).pipe(R(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.storageLocation = new le(o), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "notification_storage_location_added_success" : "notification_storage_location_updated_success"), this.storageLocationSaveClick.emit(this.storageLocation), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                }
            }) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form = null, this.isCreate = !1, this.storageLocationCancelClick.emit()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.save()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(xe))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-storage-location"]
                ],
                inputs: {
                    isCreate: "isCreate",
                    storageLocation: "storageLocation",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    storageLocationSaveClick: "storageLocationSaveClick",
                    storageLocationCancelClick: "storageLocationCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [3, "cancelClick", "isOnPopup"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "dx-popup", 0), _("onHidden", function() {
                        return i.onClosing()
                    }), D("visibleChange", function(C) {
                        return T(i.isVisiblePopup, C) || (i.isVisiblePopup = C), C
                    }), j(1, ct, 5, 2, "div", 1), p()), o & 2 && (V("visible", i.isVisiblePopup), s("width", "95vw")("maxWidth", 400)("title", i.isCreate ? i.formatMessage("storage_add_new_location") : i.formatMessage("storage_update_location")), c(), s("dxTemplateOf", "content"))
                },
                dependencies: [X, z, Y, Z, W, H, U, J, F, I, O, B],
                encapsulation: 2
            })
        }
    }
    return t
})();

function dt(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-storage-location", 2), _("storageLocationCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisibleAddStorageLocationPopup = !1)
        })("storageLocationSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onStorageLocationSave())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAddStorageLocationPopup)("storageLocation", e.storageLocation)
    }
}
var Pr = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.isMobileDevice = w(Ie).isMobileDevice(), this.isVisibleAddStorageLocationPopup = !1, this.isCreate = !1, this.entity = S.STORAGE_LOCATION, this.columns = [{
                dataField: "name",
                caption: a("device_storage_location"),
                width: this.isMobileDevice ? 260 : 400,
                allowSorting: !0
            }, {
                dataField: "jobs_count",
                caption: a("jobs"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.storageLocation = null
        }
        create() {
            this.isVisibleAddStorageLocationPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.storageLocation = e, this.isVisibleAddStorageLocationPopup = !0
        }
        onStorageLocationSave() {
            this.isCreate = !1, this.isVisibleAddStorageLocationPopup = !1, this.storageLocation = null, this.dataGrid.getData()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b(xe))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-storage-location-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "storageLocation"],
                    [3, "storageLocationCancelClick", "storageLocationSaveClick", "isCreate", "isVisiblePopup", "storageLocation"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    }), p(), v(1, dt, 1, 3, "app-storage-location", 1)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisibleAddStorageLocationPopup ? 1 : -1))
                },
                dependencies: [y, pi],
                encapsulation: 2
            })
        }
    }
    return t
})();

function mt(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-pre-post-condition-pop-up", 3), _("prePostConditionCancelClick", function() {
            d(e);
            let i = n();
            return m(i.isVisiblePrePostConditionPopup = !1)
        })("prePostConditionSaveClick", function() {
            d(e);
            let i = n();
            return m(i.onSavePrePostCondition())
        }), p()
    }
    if (t & 2) {
        let e = n();
        s("isCreate", e.isCreate)("isVisiblePopup", e.isVisiblePrePostConditionPopup)("prePostCondition", e.prePostCondition)
    }
}

function ut(t, u) {
    if (t & 1) {
        let e = h();
        l(0, "app-archive-delete-popup", 4), D("isVisibleChange", function(i) {
            d(e);
            let r = n();
            return T(r.isVisibleArchiveDeletePopup, i) || (r.isVisibleArchiveDeletePopup = i), m(i)
        }), _("onSuccess", function() {
            d(e);
            let i = n();
            return m(i.handleArchiveDeleteSuccess())
        })("onCancel", function() {
            d(e);
            let i = n();
            return m(i.onArchiveDeleteCancel())
        }), p()
    }
    if (t & 2) {
        let e = n();
        V("isVisible", e.isVisibleArchiveDeletePopup), s("service", e.service)("entity", e.currentPrePostCondition)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var jr = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = a, this.entity = S.PRE_POST_CONDITIONS, this.isVisiblePrePostConditionPopup = !1, this.isVisibleArchiveDeletePopup = !1, this.currentPrePostCondition = null, this.archiveDeleteMode = L("delete"), this.isCreate = !1, this.columns = [{
                dataField: "name",
                caption: a("pre_post_conditions"),
                width: 180,
                allowSorting: !0
            }, {
                dataField: "device_type.name",
                caption: a("common_type"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "condition_type",
                caption: a("condition_type"),
                hidingPriority: 4,
                allowSorting: !1,
                cellTemplate: "conditionTypeTemplate"
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        create() {
            this.isVisiblePrePostConditionPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.prePostCondition = e, this.isVisiblePrePostConditionPopup = !0
        }
        onSavePrePostCondition() {
            this.isCreate = !1, this.dataGrid.getData(), this.prePostCondition = null, this.isVisiblePrePostConditionPopup = !1
        }
        onDeleteClick(e) {
            this.currentPrePostCondition = e, this.archiveDeleteMode.set(e.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0
        }
        handleArchiveDeleteSuccess() {
            this.isVisibleArchiveDeletePopup = !1, this.currentPrePostCondition = null, this.dataGrid.getData()
        }
        onArchiveDeleteCancel() {
            this.isVisibleArchiveDeletePopup = !1, this.currentPrePostCondition = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(b($e))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-pre-post-conditions-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(y, 5), o & 2) {
                        let r;
                        x(r = k()) && (i.dataGrid = r.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "dataGridDeleteClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "prePostCondition"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "prePostConditionCancelClick", "prePostConditionSaveClick", "isCreate", "isVisiblePopup", "prePostCondition"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (l(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(C) {
                        return i.edit(C)
                    })("dataGridDeleteClick", function(C) {
                        return i.onDeleteClick(C)
                    }), p(), v(1, mt, 1, 3, "app-pre-post-condition-pop-up", 1), v(2, ut, 1, 6, "app-archive-delete-popup", 2)), o & 2 && (s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", i.service), c(), f(i.isVisiblePrePostConditionPopup ? 1 : -1), c(), f(i.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [M, y, ei],
                encapsulation: 2
            })
        }
    }
    return t
})();
export {
    gt as a, Nt as b, Ot as c, lo as d, yo as e, Bo as f, ln as g, kn as h, Kn as i, ar as j, Pr as k, jr as l
};