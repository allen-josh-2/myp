import {
    Ca as G,
    Fc as q,
    Ha as z,
    Ug as ee,
    Vc as Q,
    Wc as K,
    Xc as X,
    Ze as Z,
    pa as B,
    qa as H,
    ra as k,
    rb as $,
    ta as U,
    ua as V
} from "./chunk-DCKGQUHB.js";
import {
    $a as m,
    Fa as i,
    Ib as R,
    Jb as j,
    Kb as w,
    Lf as O,
    Mc as F,
    Na as L,
    _a as c,
    _h as Y,
    aa as J,
    da as I,
    ea as P,
    eb as o,
    fb as l,
    gb as r,
    gc as v,
    hb as p,
    hc as y,
    qh as W,
    sb as x,
    ti as M,
    ub as _,
    ui as N,
    wh as b,
    xk as d,
    z as A
} from "./chunk-GOPIAW4V.js";
import {
    a as S,
    b as D
} from "./chunk-FBFWB55K.js";
var te = (() => {
    class n extends M {
        constructor(e) {
            super(e, O), this.api = e, this.endpoint = O
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || n)(I(N))
            }
        }
        static {
            this.\u0275prov = J({
                token: n,
                factory: n.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return n
})();

function oe(n, u) {
    if (n & 1 && p(0, "app-trend-matrix-card", 3), n & 2) {
        let e = _();
        o("tooltipId", e.REPORT_TYPE.JOB_COUNT_TREND)("toolTip", "tooltip_total_jobs")("currentDateRangeValue", e.jobCountTrendReport == null ? null : e.jobCountTrendReport.current_period_total)("percentage", e.jobCountTrendReport == null ? null : e.jobCountTrendReport.percentage_change)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))
    }
}

function ne(n, u) {
    if (n & 1 && p(0, "app-trend-matrix-card", 4), n & 2) {
        let e = _();
        o("tooltipId", e.REPORT_TYPE.JOB_TOTAL_AMOUNT_TREND)("toolTip", "tooltip_job_total_amount")("currentDateRangeValue", e.jobTotalAmountTrendReport == null ? null : e.jobTotalAmountTrendReport.current_period_total)("percentage", e.jobTotalAmountTrendReport == null ? null : e.jobTotalAmountTrendReport.percentage_change)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))
    }
}

function re(n, u) {
    if (n & 1 && p(0, "app-charts", 14), n & 2) {
        let e = _();
        o("entityData", e.serviceWiseJobReport)("entityLabel", e.CHART_ENTITY_TYPES.SERVICE_WISE_REPORT)("graphType", e.graphType)
    }
}

function ae(n, u) {
    if (n & 1 && p(0, "app-charts", 14), n & 2) {
        let e = _();
        o("entityData", e.partWiseJobReport)("entityLabel", e.CHART_ENTITY_TYPES.PART_WISE_REPORT)("graphType", e.graphType)
    }
}

function pe(n, u) {
    if (n & 1 && p(0, "app-charts", 15), n & 2) {
        let e = _();
        o("entityData", e.statusReport)("entityLabel", e.CHART_ENTITY_TYPES.STATUS_WISE_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}

function le(n, u) {
    if (n & 1 && p(0, "app-charts", 15), n & 2) {
        let e = _();
        o("entityData", e.deviceModelRevenueReport)("entityLabel", e.CHART_ENTITY_TYPES.JOB_MODEL_WISE_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}

function de(n, u) {
    if (n & 1 && p(0, "app-charts", 15), n & 2) {
        let e = _();
        o("entityData", e.jobTypeReport)("entityLabel", e.CHART_ENTITY_TYPES.JOB_TYPE_WISE_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}

function se(n, u) {
    if (n & 1 && p(0, "app-charts", 15), n & 2) {
        let e = _();
        o("entityData", e.jobSourceReport)("entityLabel", e.CHART_ENTITY_TYPES.JOB_SOURCE_WISE_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}
var Oe = (() => {
    class n {
        constructor() {
            this.formatMessage = d, this.CHART_ENTITY_TYPES = W, this.graphType = "bar", this.isLoading = !0, this.mostPopularRepairAndPartColumns = [], this.serviceWiseColumns = [], this.statusWiseJobReport = [{
                dataField: "status_name",
                caption: d("common_status")
            }, {
                dataField: "total_jobs",
                caption: d("job_count")
            }, {
                dataField: "total_jobs_amount",
                caption: d("common_total_amount"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_payment_received",
                caption: d("total_payment_received"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "remaining_jobs_amount",
                caption: d("common_remaining_amount"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }], this.jobReportService = P(te), this.REPORT_TYPE = b, this.REPORT_DURATION_LIST = Y, this.service = P(Q), this.mostPopularRepairAndPartColumns = [{
                dataField: "name",
                caption: d("common_name")
            }, {
                dataField: "count",
                caption: d("report_columns_repair_service_count")
            }, {
                dataField: "total_revenue",
                caption: d("report_columns_total_revenue"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_quantity",
                caption: d("report_columns_total_quantity")
            }], this.serviceWiseColumns = [{
                dataField: "name",
                caption: d("common_name")
            }, {
                dataField: "device_type_name",
                caption: d("device_type")
            }, {
                dataField: "count",
                caption: d("report_columns_repair_service_count")
            }, {
                dataField: "total_revenue",
                caption: d("report_columns_total_revenue"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_quantity",
                caption: d("report_columns_total_quantity")
            }]
        }
        setGraphType(e) {
            this.graphType = e
        }
        pointClickHandler(e) {
            this.toggleVisibility(e.target)
        }
        legendClickHandler(e) {
            let a = e.target,
                t = e.component.getAllSeries()[0].getPointsByArg(a)[0];
            this.toggleVisibility(t)
        }
        toggleVisibility(e) {
            e.isVisible() ? e.hide() : e.show()
        }
        setReportForDuration(e) {
            let a = {
                from_date: e.fromDate,
                to_date: e.toDate,
                type: ""
            };
            this.dateDuration = a, A([this.service.getStatusReport(a), this.service.jobTypeReport(a), this.service.partWiseJobReport(a), this.service.serviceWiseJobReport(a), this.service.getDeviceModelRevenueReport(a), this.service.jobSourceReport(a), this.jobReportService.getReport(D(S({}, a), {
                type: b.JOB_COUNT_TREND
            })), this.jobReportService.getReport(D(S({}, a), {
                type: b.JOB_TOTAL_AMOUNT_TREND
            }))]).subscribe({
                next: ([t, T, s, h, g, C, f, E]) => {
                    this.statusReport = t, this.jobTypeReport = T, this.partWiseJobReport = s, this.serviceWiseJobReport = h, this.deviceModelRevenueReport = g, this.jobSourceReport = C, this.jobCountTrendReport = f, this.jobTotalAmountTrendReport = E
                },
                error: ([t, T, s, h, g, C, f, E]) => {
                    console.log(t, T, s, h, g, C, f, E)
                }
            }).add(() => {
                this.isLoading = !1
            }), this.deviceTypeJobReport$ = this.service.getDeviceTypeReport(a), this.deviceBrandJobReport$ = this.service.deviceBrandJobReport(a), this.getDeviceModelReport$ = this.service.getDeviceModelReport(a)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || n)
            }
        }
        static {
            this.\u0275cmp = L({
                type: n,
                selectors: [
                    ["app-job-report"]
                ],
                standalone: !1,
                decls: 65,
                vars: 58,
                consts: [
                    [3, "durationDateChanges", "selectedGraphType", "isForGraph", "selectedDuration"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["icon", "fa-thin fa-ticket", "title", "total_jobs", 3, "tooltipId", "toolTip", "currentDateRangeValue", "percentage", "dateRange"],
                    ["icon", "fa-thin fa-wallet", "title", "report_job_total_amount", 3, "tooltipId", "toolTip", "currentDateRangeValue", "percentage", "dateRange"],
                    [1, "row", "pt-2"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "mb-2"],
                    ["id", "most_popular_service_wise_jobs_report", 1, "m-0"],
                    ["target", "most_popular_service_wise_jobs_report", 3, "tooltipText"],
                    [3, "columns", "dateDuration", "reportType", "service"],
                    ["id", "most_popular_part_wise_jobs_report", 1, "m-0"],
                    ["target", "most_popular_part_wise_jobs_report", 3, "tooltipText"],
                    [1, "m-0"],
                    [3, "entityData", "entityLabel", "graphType"],
                    [3, "entityData", "entityLabel", "graphType", "isNameWise"],
                    ["id", "device_model_pie", 3, "onLegendClick", "onPointClick", "dataSource", "title"],
                    [3, "enabled"],
                    ["argumentField", "name", "name", "Device Model Wise Job Report", "valueField", "count"],
                    ["position", "columns", 3, "visible"],
                    [3, "size"],
                    [3, "visible", "width"],
                    ["id", "device_type_pie", 3, "dataSource", "title"],
                    ["horizontalAlignment", "center", "itemTextPosition", "right", "orientation", "horizontal", "verticalAlignment", "bottom", 3, "columnCount"],
                    ["argumentField", "name", "valueField", "count", 3, "name"],
                    ["id", "pie", "palette", "Bright", "type", "doughnut", 3, "dataSource", "title"],
                    ["argumentField", "name", "name", "Device Brand Wise Count", "valueField", "count"],
                    [3, "visible"],
                    ["horizontalAlignment", "center", "itemTextPosition", "right", "orientation", "horizontal", "verticalAlignment", "bottom", 3, "margin"]
                ],
                template: function(a, t) {
                    a & 1 && (l(0, "app-report-duration-dropdown", 0), x("durationDateChanges", function(s) {
                        return t.setReportForDuration(s)
                    })("selectedGraphType", function(s) {
                        return t.setGraphType(s)
                    }), r(), l(1, "div", 1)(2, "div", 2), c(3, oe, 1, 5, "app-trend-matrix-card", 3), r(), l(4, "div", 2), c(5, ne, 1, 5, "app-trend-matrix-card", 4), r()(), l(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "h5", 8), R(10), r(), p(11, "app-tooltip", 9), r(), p(12, "app-report-data-grid", 10), r(), l(13, "div", 6)(14, "div", 7)(15, "h5", 11), R(16), r(), p(17, "app-tooltip", 12), r(), p(18, "app-report-data-grid", 10), r(), l(19, "div", 6)(20, "div", 7)(21, "h5", 13), R(22), r(), p(23, "app-tooltip", 12), r(), p(24, "app-report-data-grid", 10), r(), l(25, "div", 6), c(26, re, 1, 3, "app-charts", 14), r(), l(27, "div", 6), c(28, ae, 1, 3, "app-charts", 14), r(), l(29, "div", 6), c(30, pe, 1, 4, "app-charts", 15), r(), l(31, "div", 6), c(32, le, 1, 4, "app-charts", 15), r(), l(33, "div", 6), c(34, de, 1, 4, "app-charts", 15), r(), l(35, "div", 6), c(36, se, 1, 4, "app-charts", 15), r(), l(37, "div", 6)(38, "dx-pie-chart", 16), v(39, "async"), x("onLegendClick", function(s) {
                        return t.legendClickHandler(s)
                    })("onPointClick", function(s) {
                        return t.pointClickHandler(s)
                    }), p(40, "dxo-legend")(41, "dxo-export", 17)(42, "dxo-tooltip", 17), l(43, "dxi-series", 18)(44, "dxo-label", 19), p(45, "dxo-font", 20)(46, "dxo-connector", 21), r()()()(), l(47, "div", 6)(48, "dx-pie-chart", 22), v(49, "async"), p(50, "dxo-legend", 23)(51, "dxo-export", 17)(52, "dxo-tooltip", 17), l(53, "dxi-series", 24)(54, "dxo-label", 19), p(55, "dxo-font", 20)(56, "dxo-connector", 21), r()()()(), l(57, "div", 6)(58, "dx-pie-chart", 25), v(59, "async"), l(60, "dxi-series", 26)(61, "dxo-label", 27), p(62, "dxo-connector", 27), r()(), p(63, "dxo-export", 17)(64, "dxo-legend", 28), r()()()), a & 2 && (o("isForGraph", !0)("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), m(t.jobCountTrendReport ? 3 : -1), i(2), m(t.jobTotalAmountTrendReport ? 5 : -1), i(5), w(" ", t.formatMessage("report_most_popular_service_wise_jobs_report"), " "), i(), o("tooltipText", "tooltip_service_wise_report"), i(), o("columns", t.serviceWiseColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.MOST_POPULAR_SERVICE_WISE_JOBS_REPORT)("service", t.jobReportService), i(4), j(t.formatMessage("report_most_popular_part_wise_jobs_report")), i(), o("tooltipText", "tooltip_part_wise_report"), i(), o("columns", t.mostPopularRepairAndPartColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.MOST_POPULAR_PART_WISE_JOBS_REPORT)("service", t.jobReportService), i(4), j(t.formatMessage("report_status_wise_jobs_report")), i(), o("tooltipText", "tooltip_status_wise_report"), i(), o("columns", t.statusWiseJobReport)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.STATUS_WISE_JOB_REPORT)("service", t.jobReportService), i(2), m(t.isLoading ? -1 : 26), i(2), m(t.isLoading ? -1 : 28), i(2), m(t.isLoading ? -1 : 30), i(2), m(t.isLoading ? -1 : 32), i(2), m(t.isLoading ? -1 : 34), i(2), m(t.isLoading ? -1 : 36), i(2), o("dataSource", y(39, 52, t.getDeviceModelReport$))("title", t.formatMessage("report_device_model_wise_job_report")), i(3), o("enabled", !0), i(), o("enabled", !0), i(2), o("visible", !0), i(), o("size", 16), i(), o("visible", !0)("width", .5), i(2), o("dataSource", y(49, 54, t.deviceTypeJobReport$))("title", t.formatMessage("report_device_model_wise_job_report")), i(2), o("columnCount", 4), i(), o("enabled", !0), i(), o("enabled", !0), i(), o("name", t.formatMessage("report_device_type_wise_job_report")), i(), o("visible", !0), i(), o("size", 16), i(), o("visible", !0)("width", .5), i(2), o("dataSource", y(59, 56, t.deviceBrandJobReport$))("title", t.formatMessage("report_device_brand_wise_count")), i(3), o("visible", !0), i(), o("visible", !0), i(), o("enabled", !0), i(), o("margin", 0))
                },
                dependencies: [K, Z, $, X, ee, k, U, B, H, V, G, z, q, F],
                encapsulation: 2
            })
        }
    }
    return n
})();
export {
    Oe as a
};