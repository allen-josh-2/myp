import {
    a as Pt
} from "./chunk-XHP3KBJE.js";
import {
    a as Q
} from "./chunk-MYGQO4K4.js";
import {
    a as ft
} from "./chunk-BLJF2YPR.js";
import {
    a as Ee
} from "./chunk-RW3SLQZQ.js";
import {
    $b as yt,
    Bc as wt,
    Db as bt,
    Ee as Tt,
    Fe as J,
    Ja as ke,
    Ma as _t,
    Pc as Te,
    Q as ct,
    Rc as de,
    T as B,
    Ta as Ct,
    Va as $,
    Z as j,
    Zd as Y,
    aa as we,
    af as It,
    ba as gt,
    bb as q,
    c as rt,
    ca as R,
    e as b,
    g as A,
    h as P,
    ha as vt,
    hh as Ie,
    ia as Me,
    lb as pe,
    n as V,
    pb as U,
    ph as At,
    q as ye,
    qb as K,
    sb as G,
    t as N,
    tb as xt,
    te as Mt,
    u as D,
    uc as St,
    ve as kt,
    we as Et,
    y as O
} from "./chunk-DCKGQUHB.js";
import {
    $a as f,
    $b as ce,
    Ak as Z,
    B as qe,
    Bb as Ze,
    Ca as W,
    Cb as Ye,
    Eb as ge,
    Ec as le,
    F as Ge,
    Fa as o,
    Fb as Je,
    Gb as et,
    Ib as c,
    Jb as v,
    Ka as k,
    Kb as g,
    Kc as be,
    Na as y,
    Nd as lt,
    Oa as he,
    Pd as mt,
    Pg as z,
    Sa as We,
    Tc as ot,
    Td as Fe,
    V as ze,
    Vh as ut,
    Wf as pt,
    Wh as ht,
    Xa as fe,
    _a as h,
    _b as oe,
    aa as ee,
    ac as tt,
    ad as nt,
    ba as ue,
    bb as se,
    c as Ue,
    cb as te,
    da as X,
    db as ie,
    ea as m,
    eb as s,
    fb as r,
    gb as a,
    ha as C,
    hb as d,
    ia as x,
    ja as $e,
    ka as Ke,
    lb as Qe,
    ld as at,
    mb as Xe,
    pa as Oe,
    pd as F,
    qa as He,
    qb as M,
    qd as st,
    rc as it,
    sb as _,
    sd as L,
    t as De,
    td as me,
    th as dt,
    ti as Se,
    ub as u,
    vd as Re,
    wd as I,
    xk as S,
    zf as Le
} from "./chunk-GOPIAW4V.js";
import {
    a as ae
} from "./chunk-FBFWB55K.js";

function Jt(t, l) {
    t & 1 && d(0, "app-skeleton-loader", 2), t & 2 && s("rows", 3)("columns", 1)
}

function ei(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div")(1, "form", 3), _("ngSubmit", function() {
            C(e);
            let n = u(2);
            return x(n.activateAccount())
        }), r(2, "h2", 4), c(3), a(), r(4, "div", 5)(5, "label", 6), c(6), a(), r(7, "app-control-container", 7), d(8, "app-password", 8), a()(), r(9, "div", 5)(10, "label", 9), c(11), a(), r(12, "app-control-container", 10), d(13, "app-password", 11)(14, "app-error", 12), a()(), d(15, "app-save-btn", 13), a()()
    }
    if (t & 2) {
        let e = u(2);
        o(), s("formGroup", e.form), o(2), v(e.formatMessage("activate_account")), o(3), g(" ", e.formatMessage("auth_password"), " "), o(), s("errorMsg", e.formatMessage("auth_password_required_error")), o(), s("isEditMode", !e.isActivating)("placeholder", e.formatMessage("auth_enter_password"))("disableAutoFill", !0), o(3), g(" ", e.formatMessage("auth_confirm_password"), " "), o(), s("errorMsg", e.formatMessage("auth_confirm_password_required_error")), o(), s("isEditMode", !e.isActivating)("placeholder", e.formatMessage("auth_password_confirmation"))("disableAutoFill", !0), o(), s("displayError", e.isSubmitted && e.form.value.password !== e.form.value.password_confirmation)("errorMsg", e.formatMessage("auth_password_mismatch_error")), o(), s("isOnPopup", !0)("isSaving", e.isActivating)
    }
}

function ti(t, l) {
    if (t & 1 && (h(0, Jt, 1, 2, "app-skeleton-loader", 2), h(1, ei, 16, 16, "div")), t & 2) {
        let e = u();
        f(e.form ? -1 : 0), o(), f(e.form ? 1 : -1)
    }
}

function ii(t, l) {
    if (t & 1 && (r(0, "div", 1)(1, "h3", 14), c(2), a(), r(3, "p"), c(4), a()()), t & 2) {
        let e = u();
        o(2), v(e.formatMessage("common_oops")), o(2), v(e.formatMessage("auth_account_activation_error"))
    }
}
var Dt = (() => {
    class t {
        constructor(e) {
            this.loaderService = e, this.formatMessage = S, this.formService = m(U), this.router = m(L), this.authService = m(j), this.userSessionService = m(gt), this.activatedRouter = m(F), this.toastNotificationService = m(R), this.fb = new O, this.isLoggedIn = this.userSessionService.isLoggedIn(), this.verificationCode = null, this.showPasswordReset = !1, this.isActivating = !1, this.error = null, this.isSubmitted = !1, this.role = null
        }
        ngOnInit() {
            this.activatedRouter.params.subscribe({
                next: e => {
                    e.activation_code && (this.verificationCode = e.activation_code, this.isLoggedIn || this.verifyAccountActivationCode())
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        verifyAccountActivationCode() {
            this.loaderService.show(), this.authService.verifyActivationToken({
                token: this.verificationCode
            }).subscribe({
                next: e => {
                    e && (this.showPasswordReset = !0, this.form = this.fb.group({
                        token: this.verificationCode,
                        password: [null, [b.required]],
                        password_confirmation: [null, [b.required]]
                    }))
                },
                error: () => {
                    this.toastNotificationService.error("notification_invalid_token_redirect"), this.router.navigate(["/auth/login"])
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        activateAccount() {
            this.isSubmitted = !0, this.form.valid && this.form.value.password === this.form.value.password_confirmation ? (this.isActivating = !0, this.authService.activateAccount(this.form.value).subscribe({
                next: e => {
                    this.showPasswordReset = !1, this.toastNotificationService.success("notification_account_activated_success"), this.authService.setUserSession(e.user, e.access_token, e.permissions), this.role = e.user.roles[0]
                },
                error: e => {
                    this.error = e.error.errors, this.toastNotificationService.error("notification_account_activation_error")
                }
            }).add(() => {
                this.isActivating = !1
            })) : this.formService.validateFormFields(this.form)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(Z))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-activate"]
                ],
                standalone: !1,
                decls: 3,
                vars: 2,
                consts: [
                    [1, "row", "mb-5", "mx-5", "theme-secondary-bg"],
                    ["role", "alert", 1, "alert", "alert-danger"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "text-center", "mb-4", "fs-1"],
                    [1, "mb-3"],
                    ["for", "account-activate-password", 1, "form-label", "mb-2"],
                    ["name", "password", 1, "d-block", 3, "errorMsg"],
                    ["formControlName", "password", "id", "account-activate-password", 3, "isEditMode", "placeholder", "disableAutoFill"],
                    ["for", "account-activate-password-confirmation", 1, "form-label", "mb-2"],
                    ["name", "password_confirmation", 1, "d-block", 3, "errorMsg"],
                    ["formControlName", "password_confirmation", "id", "account-activate-password-confirmation", 3, "isEditMode", "placeholder", "disableAutoFill"],
                    [3, "displayError", "errorMsg"],
                    ["id", "account-activate-save-button", "saveText", "activate", "savingText", "activating", 1, "btn-block", "d-flex", "justify-content-center", "w-100", "mt-4", 3, "isOnPopup", "isSaving"],
                    [1, "alert-heading"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0), h(1, ti, 2, 2), h(2, ii, 5, 2, "div", 1), a()), i & 2 && (o(), f(n.showPasswordReset ? 1 : -1), o(), f(n.error ? 2 : -1))
                },
                dependencies: [K, q, G, Y, J, V, A, P, D, N],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ot = (() => {
    class t {
        constructor() {
            this.formatMessage = S, this.tenantService = m(pe), this.themeService = m(de), this.tenantConfig = this.tenantService.config(), this.plan = this.tenantService.plan(), this.isDarkTheme = this.themeService.isDarkTheme(), this.TENANT_PLANS = z
        }
        ngOnInit() {}
        setAuthLogo() {
            return this.tenantConfig ? .logo && [z.STANDARD, z.ENTERPRISE].includes(this.plan) ? this.tenantConfig.logo : this.isDarkTheme ? "/assets/images/bytephase.png" : "/assets/images/bytephase-blue-logo.png"
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-logo"]
                ],
                standalone: !1,
                decls: 4,
                vars: 1,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "ml-auto", "mr-auto", "mb-3", "d-flex", "justify-content-center", "mt-3"],
                    [1, "mb-0"],
                    ["alt", "Logo", "loading", "lazy", 1, "auth-tenant-logo", "img-fluid", 3, "src"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "figure", 2), d(3, "img", 3), a()()()), i & 2 && (o(3), s("src", n.setAuthLogo(), W))
                },
                styles: [".auth-tenant-logo[_ngcontent-%COMP%]{display:block;width:auto;max-width:12.5rem;height:auto;max-height:5rem;min-height:3.3125rem}"]
            })
        }
    }
    return t
})();
var Rt = (() => {
    class t {
        constructor(e) {
            this.loaderService = e, this.formatMessage = S, this.authService = m(j), this.activatedRouter = m(F), this.state = null, this.code = null, this.activatedRouter.queryParams.subscribe({
                next: i => {
                    this.state = i.state, this.code = i.code
                },
                error: i => {
                    console.error("error ", i)
                }
            })
        }
        getRedirectBaseUrl() {
            return this.state.includes(".") ? `https://${this.state}` : `https://${this.state}.${I.domainName}`
        }
        ngOnInit() {
            this.loaderService.show(), this.state && this.code && this.authService.callback({
                state: this.state,
                code: this.code
            }).subscribe({
                next: e => {
                    console.log(e);
                    let i = this.getRedirectBaseUrl();
                    window.location.href = `${i}/auth/login?access_token=${e?.access_token}&expires_in=${e?.expires_in}&refresh_token=${e?.refresh_token}`
                },
                error: e => {
                    let i = this.getRedirectBaseUrl();
                    window.location.href = `${i}/auth/login`
                }
            }).add(() => {
                this.loaderService.show()
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(Z))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-auth-callback"]
                ],
                decls: 0,
                vars: 0,
                template: function(i, n) {},
                encapsulation: 2
            })
        }
    }
    return t
})();
var ni = t => ({
        "background-color": t
    }),
    Lt = (() => {
        class t {
            constructor() {
                this.formatMessage = S, this.userName = "", this.size = ht.DEFAULT, this.routerHelperService = m(we), this.isMobileDevice = m(B).isMobileDevice(), this.isOnAppSubdomain = window.location.hostname.startsWith("app."), this.displayIconText = "", this.colors = ["#1abc9c", "#2ecc71", "#3498db", "#9b59b6", "#34495e", "#16a085", "#27ae60", "#2980b9", "#8e44ad", "#2c3e50", "#f1c40f", "#e67e22", "#e74c3c", "#ecf0f1", "#95a5a6", "#f39c12", "#d35400", "#c0392b", "#bdc3c7", "#7f8c8d"], this.backgroundColor = ""
            }
            ngOnInit() {
                let e = this.tenant ? .name ? .match(/\b(\w)/g);
                this.displayIconText = e.join("").substr(0, 2).toUpperCase(), this.backgroundColor = this.colors[this.nameFromText(this.displayIconText) % this.colors.length]
            }
            nameFromText(e) {
                let i = e.split("").map(n => n.charCodeAt(0)).join("");
                return parseInt(i, 10)
            }
            onTenantClick() {
                this.isMobileDevice || this.isOnAppSubdomain ? this.routerHelperService.redirectToAppUrl(this.userName, this.tenant) : (localStorage.setItem("tenantUrl", this.tenant ? .domain_url), window.location.assign(this.tenant ? .domain_url + "/auth/login?username=" + this.userName))
            }
            onKeyDown(e) {
                (e.key === "Enter" || e.key === " ") && (e.preventDefault(), this.onTenantClick())
            }
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275cmp = y({
                    type: t,
                    selectors: [
                        ["app-tenant-item"]
                    ],
                    inputs: {
                        tenant: "tenant",
                        userName: "userName",
                        size: "size"
                    },
                    standalone: !1,
                    decls: 15,
                    vars: 10,
                    consts: [
                        ["role", "button", "tabindex", "0", 1, "list-group-item", "list-group-item-action", "p-0", "border-0", "bg-transparent", "cursor-pointer", 3, "click", "keydown"],
                        [1, "card", "rounded-3", "shadow", "my-2", "border-0"],
                        [1, "card-body", "d-flex", "align-items-center", "justify-content-between", "p-3"],
                        [1, "d-flex", "align-items-center", "overflow-hidden", "flex-grow-1"],
                        [1, "tenant-avatar", "rounded-3", "me-3", "flex-shrink-0", "d-flex", "align-items-center", "justify-content-center", "text-white", "fw-bold", 3, "ngClass", "ngStyle"],
                        [1, "overflow-hidden"],
                        [1, "fw-bold", "text-truncate"],
                        [1, "text-secondary", "small", "text-truncate"],
                        [1, "ms-3", "flex-shrink-0"],
                        ["aria-hidden", "true", 1, "fas", "fa-chevron-right", "text-muted"]
                    ],
                    template: function(i, n) {
                        i & 1 && (r(0, "div", 0), _("click", function() {
                            return n.onTenantClick()
                        })("keydown", function(w) {
                            return n.onKeyDown(w)
                        }), r(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4), c(5), a(), r(6, "div", 5)(7, "div", 6), c(8), a(), r(9, "div", 7), c(10), a(), r(11, "div", 7), c(12), a()()(), r(13, "div", 8), d(14, "i", 9), a()()()()), i & 2 && (fe("aria-label", "Select workspace " + (n.tenant == null ? null : n.tenant.name)), o(4), s("ngClass", n.size)("ngStyle", ce(8, ni, n.backgroundColor)), fe("aria-hidden", !0), o(), g(" ", n.displayIconText, " "), o(3), v(n.tenant == null ? null : n.tenant.name), o(2), g(" ", n.tenant.support_email, " "), o(2), g(" ", n.tenant.support_number, " "))
                    },
                    dependencies: [le, be],
                    styles: ["[_nghost-%COMP%]   .cursor-pointer[_ngcontent-%COMP%]{cursor:pointer}[_nghost-%COMP%]   .list-group-item-action[_ngcontent-%COMP%]:hover   .card[_ngcontent-%COMP%]{transform:translateY(-2px);box-shadow:0 .25rem .75rem #00000026!important}[_nghost-%COMP%]   .tenant-avatar[_ngcontent-%COMP%]{width:40px;height:40px;font-size:15px}[_nghost-%COMP%]   .default[_ngcontent-%COMP%]{font-family:sans-serif;font-size:15px;line-height:40px;color:#fff;width:40px;height:40px;border-radius:.375rem}"]
                })
            }
        }
        return t
    })();

function ai(t, l) {
    if (t & 1 && (r(0, "div", 7), d(1, "app-tenant-item", 8), a()), t & 2) {
        let e = l.$implicit,
            i = u();
        o(), s("tenant", e)("userName", i.userName)
    }
}
var Pe = (() => {
    class t {
        constructor() {
            this.formatMessage = S, this.tenants = [], this.isMobileDevice = m(B).isMobileDevice(), this.activatedRouter = m(F), this.activatedRouter.queryParams.pipe(ct()).subscribe({
                next: e => {
                    this.userName = e.username
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-auth-tenant-list"]
                ],
                inputs: {
                    tenants: "tenants"
                },
                standalone: !1,
                decls: 11,
                vars: 3,
                consts: [
                    [1, "row"],
                    [1, "text-center", "mb-2"],
                    [1, "text-secondary", "mb-1"],
                    [1, "fa-light", "fa-briefcase", "me-2"],
                    [1, "fw-light"],
                    [1, "w-100", 3, "height"],
                    [1, "p-4"],
                    [1, "mb-2"],
                    [3, "tenant", "userName"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "h6", 2), d(3, "i", 3), c(4), a(), r(5, "h5", 4), c(6), a()(), r(7, "dx-scroll-view", 5)(8, "div", 6), te(9, ai, 2, 2, "div", 7, se), a()()()), i & 2 && (o(4), g(" ", n.formatMessage("auth_your_workspaces"), " "), o(2), g(" ", n.userName, " "), o(), s("height", n.isMobileDevice ? 400 : 380), o(2), ie(n.tenants))
                },
                dependencies: [yt, Lt],
                styles: ["[_nghost-%COMP%]   .row[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%]{font-size:22px!important}"]
            })
        }
    }
    return t
})();
var ci = ["item"],
    li = (t, l) => l.id;

function mi(t, l) {
    if (t & 1 && (r(0, "div", 3, 0), d(2, "img", 6), a()), t & 2) {
        let e = l.$implicit;
        o(2), s("alt", "Slide " + e.id)("src", e.media_url, W)
    }
}

function pi(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "span", 7), _("click", function() {
            let n = C(e).$index,
                p = u();
            return x(p.moveToSlide(n))
        }), a()
    }
    if (t & 2) {
        let e = l.$index,
            i = u();
        Je("active", e === i.activeItem())
    }
}
var Bt = (() => {
    class t {
        constructor() {
            this.items = it("item"), this.activeItem = He(0), this.carousalData = [], this.authService = m(j)
        }
        ngOnInit() {
            this.authService.getCarousalItems().subscribe({
                next: e => {
                    this.carousalData = e
                },
                error: e => {
                    this.errorResponse = e
                }
            })
        }
        ngAfterViewInit() {
            this.loadShow(), this.startAutoSlide()
        }
        ngOnDestroy() {
            this.stopAutoSlide()
        }
        startAutoSlide() {
            this.autoSlideInterval = setInterval(() => {
                this.moveToNextItem()
            }, 4e3)
        }
        stopAutoSlide() {
            this.autoSlideInterval && clearInterval(this.autoSlideInterval)
        }
        getCircularIndex(e) {
            let i = this.items().length;
            return (e + i) % i
        }
        addStylesToActiveItem() {
            let e = this.items();
            e.forEach(n => {
                let p = n.nativeElement;
                p.style.transform = "translateX(0)", p.style.zIndex = "0", p.style.filter = "blur(5px)", p.style.opacity = "0.6", p.style.margin = "10px 0", p.style.width = "20vw", p.style.height = "500px"
            });
            let i = e[this.activeItem()] ? .nativeElement;
            i && (i.style.transform = "none", i.style.zIndex = `${e.length}`, i.style.filter = "none", i.style.opacity = "1", i.style.width = "45vw", i.style.height = "500px")
        }
        loadShow() {
            let e = this.items(),
                i = e.length,
                n = this.activeItem();
            this.addStylesToActiveItem();
            for (let p = 1; p <= this.items().length / 2; p++) {
                let w = this.getCircularIndex(n + p),
                    E = e[w].nativeElement;
                E.style.transform = `translateX(${400*p}px) scale(${1-.2*p}) perspective(16px) rotateY(-1deg)`, E.style.zIndex = `${i-p}`, E.style.filter = "blur(5px)", E.style.opacity = p === 3 ? "0" : "0.6", E.style.margin = "10px 0", E.style.width = "45vw", E.style.height = "500px"
            }
            for (let p = 1; p <= this.items().length / 2; p++) {
                let w = this.getCircularIndex(n - p),
                    E = e[w].nativeElement;
                E.style.transform = `translateX(${-220*p}px) scale(${1-.2*p}) perspective(16px) rotateY(1deg)`, E.style.zIndex = `${i-p}`, E.style.filter = "blur(5px)", E.style.opacity = p === 3 ? "0" : "0.6", E.style.width = "45vw", E.style.height = "500px"
            }
        }
        moveToNextItem() {
            this.activeItem.set(this.getCircularIndex(this.activeItem() + 1)), this.loadShow()
        }
        moveToSlide(e) {
            this.activeItem.set(e), this.loadShow(), this.restartAutoSlide()
        }
        restartAutoSlide() {
            this.stopAutoSlide(), this.startAutoSlide()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-auth-page-carousal"]
                ],
                viewQuery: function(i, n) {
                    i & 1 && Ze(n.items, ci, 5), i & 2 && Ye()
                },
                standalone: !1,
                decls: 7,
                vars: 0,
                consts: [
                    ["item", ""],
                    [1, "carousal-container"],
                    [1, "slider"],
                    [1, "carousal-item"],
                    [1, "dots-container"],
                    [1, "dot", 3, "active"],
                    ["loading", "lazy", 3, "alt", "src"],
                    [1, "dot", 3, "click"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 1)(1, "div", 2), te(2, mi, 3, 2, "div", 3, li), a(), r(4, "div", 4), te(5, pi, 1, 2, "span", 5, se), a()()), i & 2 && (o(2), ie(n.carousalData), o(3), ie(n.carousalData))
                },
                styles: [".carousal-container[_ngcontent-%COMP%]{background:linear-gradient(to bottom right,#dbeafe,#eff6ff,#fff);min-height:100vh;margin:0;display:flex;flex-direction:column;justify-content:center;align-items:center;font-family:monospace}.dark-theme[_nghost-%COMP%]   .carousal-container[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .carousal-container[_ngcontent-%COMP%]{background:linear-gradient(to bottom right,#1e293b,#0f172a,#1e293b)}.slider[_ngcontent-%COMP%]{position:relative;width:100%;height:430px;overflow:hidden;margin:20px 0}.carousal-item[_ngcontent-%COMP%]{position:absolute;background-color:transparent;border-radius:10px;padding:20px;transition:.5s;left:13%;top:0}.carousal-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{width:100%;height:400px;object-fit:contain;display:block}.dots-container[_ngcontent-%COMP%]{display:flex;justify-content:center;margin-top:50px}.dot[_ngcontent-%COMP%]{height:12px;width:12px;margin:0 5px;background-color:#bfdbfe;border-radius:50%;display:inline-block;transition:background-color .3s ease;cursor:pointer}.dot.active[_ngcontent-%COMP%]{background-color:#3b82f6}.dark-theme[_nghost-%COMP%]   .dot[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .dot[_ngcontent-%COMP%]{background-color:#475569}.dark-theme[_nghost-%COMP%]   .dot.active[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .dot.active[_ngcontent-%COMP%]{background-color:#94a3b8}"]
            })
        }
    }
    return t
})();
var ui = t => ({
    width: t
});

function hi(t, l) {
    t & 1 && d(0, "app-auth-page-carousal", 6)
}

function fi(t, l) {
    if (t & 1 && (Qe(0), r(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "div"), d(5, "app-logo"), a(), r(6, "div", 5), d(7, "router-outlet"), a()()(), h(8, hi, 1, 0, "app-auth-page-carousal", 6), a(), Xe()), t & 2) {
        let e = u();
        o(2), s("ngClass", e.isMobileDevice ? "vh-100" : "")("ngStyle", ce(4, ui, e.isMobileDevice ? "100%" : "40%")), o(), s("ngClass", (e.isMobileDevice, "my-auto")), o(5), f(e.isMobileDevice ? -1 : 8)
    }
}

function gi(t, l) {
    if (t & 1 && (r(0, "div", 0)(1, "div", 7), d(2, "app-logo"), r(3, "div", 8), d(4, "router-outlet"), a()()()), t & 2) {
        let e = u();
        s("ngClass", e.isMobileDevice ? "min-vh-100 overflow-y-auto justify-content-center" : "justify-content-center vh-100"), o(), s("ngClass", e.isMobileDevice ? "w-100 pt-3 border-0 shadow-none rounded-0" : "m-3 my-4")
    }
}

function vi(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "app-pickup-drop-popup", 9), _("pickupDropCancelClick", function() {
            C(e);
            let n = u();
            return x(n.isVisibleSchedulePickupPopup = !1)
        })("pickupDropSaveClick", function() {
            C(e);
            let n = u();
            return x(n.isVisibleSchedulePickupPopup = !1)
        }), a()
    }
    if (t & 2) {
        let e = u();
        s("isCreate", !0)("isVisiblePopup", e.isVisibleSchedulePickupPopup)
    }
}
var jt = (() => {
    class t {
        constructor() {
            this.formatMessage = S, this.router = m(L), this.isMobileDevice = m(B).isMobileDevice(), this.tenantService = m(pe), this.isSignupRoute = !1, this.isVisibleSchedulePickupPopup = !1, this.isUserFromCountryIndia = this.tenantService.isIndia, this.router.events.pipe(Ge(e => e instanceof at)).subscribe({
                next: () => {
                    this.isSignupRoute = this.router.url === "/signUp"
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-auth"]
                ],
                standalone: !1,
                decls: 3,
                vars: 2,
                consts: [
                    [1, "d-flex", "flex-column", "align-items-center", 3, "ngClass"],
                    [3, "isCreate", "isVisiblePopup"],
                    [1, "d-flex", "flex-row", "vh-100"],
                    [1, "align-middle", "d-flex", "flex-column", "align-items-center", "overflow-auto", 3, "ngClass", "ngStyle"],
                    [1, "w-100", "d-flex", "flex-column", "align-items-center", 3, "ngClass"],
                    [1, "forms-custom-css", "w-100"],
                    [2, "width", "60%"],
                    [1, "card", "shadow-lg", "align-middle", "d-flex", "align-content-center", "justify-content-center", 3, "ngClass"],
                    [1, "forms-custom-css"],
                    [3, "pickupDropCancelClick", "pickupDropSaveClick", "isCreate", "isVisiblePopup"]
                ],
                template: function(i, n) {
                    i & 1 && (h(0, fi, 9, 6, "ng-container")(1, gi, 5, 2, "div", 0), h(2, vi, 1, 2, "app-pickup-drop-popup", 1)), i & 2 && (f(n.isUserFromCountryIndia() ? 0 : 1), o(2), f(n.isVisibleSchedulePickupPopup ? 2 : -1))
                },
                dependencies: [le, be, It, st, Ot, Bt],
                styles: [".forms-custom-css[_ngcontent-%COMP%]{max-width:40em;margin:0 5em 3em}@media(max-width:500px){.forms-custom-css[_ngcontent-%COMP%]{max-width:40em!important;margin:0!important}}"]
            })
        }
    }
    return t
})();
var _i = (() => {
    class t {
        zone;
        scriptElemId = "ngx-catpcha-script";
        windowGrecaptcha = "grecaptcha";
        windowGrecaptchaEnterprise = "enterprise";
        windowOnLoadCallbackProperty = "ngx_captcha_onload_callback";
        windowOnLoadEnterpriseCallbackProperty = "ngx_captcha_onload_enterprise_callback";
        globalDomain = "recaptcha.net";
        defaultDomain = "google.com";
        enterpriseApi = "enterprise.js";
        defaultApi = "api.js";
        constructor(e) {
            this.zone = e
        }
        registerCaptchaScript(e, i, n, p) {
            if (this.grecaptchaScriptLoaded(e.useEnterprise)) {
                e.useEnterprise ? this.zone.run(() => {
                    n(window[this.windowGrecaptcha][this.windowGrecaptchaEnterprise])
                }) : this.zone.run(() => {
                    n(window[this.windowGrecaptcha])
                });
                return
            }
            e.useEnterprise ? window[this.getCallbackName(!0)] = () => this.zone.run(n.bind(this, window[this.windowGrecaptcha][this.windowGrecaptchaEnterprise])) : window[this.getCallbackName(!1)] = () => this.zone.run(n.bind(this, window[this.windowGrecaptcha]));
            let w = document.createElement("script");
            w.id = this.scriptElemId, w.innerHTML = "", w.src = this.getCaptchaScriptUrl(e, i, p), w.async = !0, w.defer = !0, document.getElementsByTagName("head")[0].appendChild(w)
        }
        cleanup() {
            let e = document.getElementById(this.scriptElemId);
            e && e.remove(), window[this.getCallbackName()] = void 0, window[this.windowGrecaptcha] = void 0
        }
        grecaptchaScriptLoaded(e) {
            return !window[this.getCallbackName(e)] || !window[this.windowGrecaptcha] ? !1 : e && window[this.windowGrecaptcha][this.windowGrecaptchaEnterprise] ? !0 : !!window[this.windowGrecaptcha].execute
        }
        getCallbackName(e) {
            return e ? this.windowOnLoadEnterpriseCallbackProperty : this.windowOnLoadCallbackProperty
        }
        getLanguageParam(e) {
            return e ? `&hl=${e}` : ""
        }
        getCaptchaScriptUrl(e, i, n) {
            let p = e.useGlobalDomain ? this.globalDomain : this.defaultDomain,
                w = e.useEnterprise ? this.enterpriseApi : this.defaultApi,
                E = this.getCallbackName(e.useEnterprise);
            return `https://www.${p}/recaptcha/${w}?onload=${E}&render=${i}${this.getLanguageParam(n)}`
        }
        static\ u0275fac = function(i) {
            return new(i || t)(X(Oe))
        };
        static\ u0275prov = ee({
            token: t,
            factory: t.\u0275fac,
            providedIn: "root"
        })
    }
    return t
})();
var H = (() => {
    class t {
        scriptService;
        zone;
        constructor(e, i) {
            this.scriptService = e, this.zone = i
        }
        execute(e, i, n, p, w) {
            this.executeAsPromise(e, i, p).then(n).catch(E => w ? w(E) : console.error(E))
        }
        executeAsPromise(e, i, n) {
            return new Promise((p, w) => {
                let E = n || {},
                    Zt = Yt => {
                        this.zone.runOutsideAngular(() => {
                            try {
                                Yt.execute(e, {
                                    action: i
                                }).then(Ne => this.zone.run(() => p(Ne)))
                            } catch (Ne) {
                                w(Ne)
                            }
                        })
                    };
                this.scriptService.registerCaptchaScript(E, e, Zt)
            })
        }
        static\ u0275fac = function(i) {
            return new(i || t)(X(_i), X(Oe))
        };
        static\ u0275prov = ee({
            token: t,
            factory: t.\u0275fac,
            providedIn: "root"
        })
    }
    return t
})();
var xi = () => ({
        autocomplete: "username",
        name: "username"
    }),
    bi = (t, l) => [t, l],
    yi = t => ({
        class: t
    });

function Si(t, l) {
    t & 1 && d(0, "app-skeleton-loader", 4), t & 2 && s("rows", 4)("columns", 1)
}

function wi(t, l) {
    if (t & 1 && (r(0, "div", 24), $e(), r(1, "svg", 25), d(2, "path", 26)(3, "path", 27)(4, "path", 28)(5, "path", 29), a(), Ke(), r(6, "span"), c(7), a()()), t & 2) {
        let e = u(3);
        o(7), v(e.formatMessage("auth_continue_with_google"))
    }
}

function Mi(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "dx-button", 20), _("onClick", function() {
            C(e);
            let n = u(2);
            return x(n.loginWithGoogle())
        }), We(1, wi, 8, 1, "div", 21), a(), r(2, "div", 22)(3, "span", 23), c(4), a()()
    }
    if (t & 2) {
        let e = u(2);
        s("text", e.formatMessage("auth_continue_with_google"))("width", "100%")("height", 48)("disabled", e.isLoggingIn)("elementAttr", ce(7, yi, e.isDarkTheme ? "google-btn-dark" : "google-btn-light")), o(), s("dxTemplateOf", "content"), o(3), v(e.formatMessage("auth_or"))
    }
}

function ki(t, l) {
    if (t & 1 && (r(0, "span", 13)(1, "p", 30), c(2), a()()), t & 2) {
        let e = u(2);
        o(2), v(e.message)
    }
}

function Ei(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "app-save-btn", 35), _("saveBtnClick", function() {
            C(e);
            let n = u(3);
            return x(n.navigateToTenantLogin())
        }), a()
    }
    t & 2 && (ge("height", 48, "px"), s("isOnPopup", !0)("saveText", "auth_switch_account")("useSubmitBehavior", !1))
}

function Ti(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div", 31)(1, "span", 23), c(2), a()(), r(3, "div", 32)(4, "app-save-btn", 33), _("saveBtnClick", function() {
            C(e);
            let n = u(2);
            return x(n.redirectToContactUs())
        }), a(), r(5, "app-save-btn", 33), _("saveBtnClick", function() {
            C(e);
            let n = u(2);
            return x(n.redirectToTrackRepair())
        }), a()(), h(6, Ei, 1, 5, "app-save-btn", 34)
    }
    if (t & 2) {
        let e = u(2);
        o(2), v(e.formatMessage("auth_or")), o(2), ge("height", 48, "px"), s("isOnPopup", !0)("saveText", "job_self_check_in")("useSubmitBehavior", !1), o(), ge("height", 48, "px"), s("isOnPopup", !0)("saveText", "auth_track_repair")("useSubmitBehavior", !1), o(), f(e.isMobileDevice ? 6 : -1)
    }
}

function Ii(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "form", 5), _("ngSubmit", function() {
            C(e);
            let n = u();
            return x(n.onLogin())
        }), h(1, Mi, 5, 9), r(2, "div", 6)(3, "label", 7), c(4), a(), r(5, "app-control-container", 8), d(6, "dx-text-box", 9), a()(), r(7, "div", 6)(8, "label", 10), c(9), a(), r(10, "app-control-container", 11), d(11, "app-password", 12), a(), h(12, ki, 3, 1, "span", 13), a(), r(13, "div", 14)(14, "a", 15), c(15), a()(), d(16, "app-save-btn", 16), a(), h(17, Ti, 7, 12), r(18, "p", 17), c(19), r(20, "a", 18), c(21), a(), c(22), r(23, "a", 19), c(24), a(), c(25), a()
    }
    if (t & 2) {
        let e = u();
        s("formGroup", e.form), fe("aria-busy", e.isLoggingIn), o(), f(!e.isDisabledLoginWithGoogle && !e.userDeviceService.isAndroid() && !e.userDeviceService.isIOS() ? 1 : -1), o(3), g(" ", e.formatMessage("auth_email_or_mobile_no"), " "), o(), s("errorMsg", e.formatMessage("email_required_error")), o(), s("placeholder", e.formatMessage("auth_email_example"))("disabled", e.isLoggingIn)("showClearButton", !1)("inputAttr", oe(27, xi)), o(2), s("ngClass", e.isDarkTheme ? "text-light" : "text-dark"), o(), g(" ", e.formatMessage("auth_password"), " "), o(), s("errorMsg", e.formatMessage("auth_password_required_error")), o(), s("isEditMode", !e.isLoggingIn)("placeholder", e.formatMessage("auth_password"))("enableAutocomplete", !0), o(), f(e.message ? 12 : -1), o(3), g(" ", e.formatMessage("auth_forgot"), " "), o(), ge("height", 48, "px"), s("isOnPopup", !0)("isSaving", e.isLoggingIn), o(), f(tt(28, bi, e.TENANT_PLANS.STANDARD, e.TENANT_PLANS.ENTERPRISE).includes(e.plan) ? 17 : -1), o(2), g(" ", e.formatMessage("auth_recaptcha_notice"), " "), o(2), v(e.formatMessage("auth_privacy_policy")), o(), g(" ", e.formatMessage("auth_and"), " "), o(2), v(e.formatMessage("auth_terms_of_service")), o(), g(" ", e.formatMessage("auth_apply"), ". ")
    }
}
var Ut = (() => {
    class t {
        constructor(e, i, n) {
            this.reCaptchaV3Service = e, this.loaderService = i, this.userDeviceService = n, this.formatMessage = S, this.generalSettingDataService = m(bt), this.formService = m(U), this.helperService = m(Tt), this.router = m(L), this.authService = m(j), this.themeService = m(de), this.tenantService = m(pe), this.activatedRouter = m(F), this.isMobileDevice = m(B).isMobileDevice(), this.toastNotificationService = m(R), this.fb = new O, this.plan = this.tenantService.plan(), this.isDarkTheme = this.themeService.isDarkTheme(), this.message = "", this.isLoggingIn = !1, this.siteKey = I.siteKey, this.isDisabledLoginWithGoogle = !1, this.TENANT_PLANS = z;
            let p = this.activatedRouter.snapshot.queryParams;
            this.accessToken = p.access_token, this.refreshToken = p.refresh_token ? ? "", this.expiresIn = p.expires_in, this.accessToken && this.loginUsingSocialAccount(), this.isDisabledLoginWithGoogle = this.generalSettingDataService.getGeneralSettingByKey(dt.GENERAL_SETTINGS.DISABLE_LOGIN_WITH_GOOGLE)
        }
        ngOnInit() {
            this.activatedRouter.queryParamMap.subscribe({
                next: e => {
                    this.form = this.fb.group({
                        username: [e.get("username") ? ? "", b.required],
                        password: ["", b.required],
                        google_recaptcha: [""]
                    }), this.redirectUrl = e.get("redirect")
                }
            })
        }
        loginUsingSocialAccount() {
            this.loaderService.show();
            let e = this.authService.loginUsingSocialAccount({
                access_token: this.accessToken,
                expires_in: this.expiresIn,
                refresh_token: this.refreshToken
            });
            this.handleLogin(e)
        }
        loginWithGoogle() {
            let e = mt,
                i = lt ? this.helperService.getSubdomain() : window.location.hostname,
                n = ["https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email"].join(" "),
                p = {
                    client_id: I.client_id,
                    access_type: "offline",
                    redirect_uri: I.redirect_uri,
                    response_type: "code",
                    scope: n,
                    include_granted_scopes: "true",
                    state: i
                },
                w = new URLSearchParams(p).toString();
            window.location.href = `${e}?${w}`
        }
        onLogin() {
            if (!this.isLoggingIn) {
                if (!this.form.valid) {
                    this.formService.validateFormFields(this.form);
                    return
                }
                this.message = "", this.isLoggingIn = !0, this.reCaptchaV3Service.execute(this.siteKey, "login", e => {
                    this.form.patchValue({
                        google_recaptcha: e
                    });
                    let i = this.authService.login(this.form.value);
                    this.handleLogin(i)
                }, {
                    useGlobalDomain: !0
                })
            }
        }
        handleLogin(e) {
            e.subscribe({
                next: i => {
                    if (i.requires_2fa || i.requires_2fa_setup) {
                        this.router.navigate(["/auth/two-factor-verify"], {
                            state: {
                                two_factor_token: i.two_factor_token,
                                requires_2fa_setup: i.requires_2fa_setup || !1,
                                redirectUrl: this.redirectUrl
                            }
                        });
                        return
                    }
                    this.authService.setUserSession(i.user, i.access_token, i.permissions, this.redirectUrl)
                },
                error: i => {
                    i instanceof nt && i.status === 423 && this.router.navigate(["/errors/UnauthorizedIPAccess"], {
                        queryParams: {
                            message: i.error.message,
                            isVisiblePopup: !0
                        }
                    }), this.message = i.error.message, this.toastNotificationService.error(i.error.message)
                }
            }).add(() => {
                this.isLoggingIn = !1, this.loaderService.hide()
            })
        }
        redirectToContactUs() {
            this.router.navigate(["/guest/lead"])
        }
        redirectToTrackRepair() {
            this.router.navigate(["/tracks/jobStatus"])
        }
        navigateToTenantLogin() {
            this.router.navigate(["/auth/tenantLogin"])
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(H), k(Z), k(B))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-login"]
                ],
                standalone: !1,
                decls: 8,
                vars: 5,
                consts: [
                    [1, "row", "mb-4", 3, "ngClass"],
                    [1, "text-center"],
                    [1, "mb-2", "fw-semibold"],
                    [1, "text-muted"],
                    ["type", "form", 3, "rows", "columns"],
                    ["role", "form", "aria-label", "Login form", 3, "ngSubmit", "formGroup"],
                    [1, "mb-2"],
                    ["for", "login-username", 1, "form-label", "mb-2"],
                    ["name", "username", 1, "d-block", 3, "errorMsg"],
                    ["formControlName", "username", "id", "login-username", 3, "placeholder", "disabled", "showClearButton", "inputAttr"],
                    ["for", "login-password", 1, "form-label", "mb-2", 3, "ngClass"],
                    ["name", "password", 1, "d-block", 3, "errorMsg"],
                    ["formControlName", "password", "id", "login-password", 3, "isEditMode", "placeholder", "enableAutocomplete"],
                    ["role", "alert", "aria-live", "assertive"],
                    [1, "text-end", "mb-1"],
                    ["routerLink", "/auth/requestPasswordReset", "aria-label", "Reset your password", 1, "text-primary", "text-decoration-none", "small"],
                    ["id", "login-save-button", "saveText", "auth_log_in", "savingText", "logging_in", 1, "d-block", "w-100", "mb-1", 3, "isOnPopup", "isSaving"],
                    [1, "text-center", "text-muted", "mb-0", 2, "font-size", "0.75rem", "line-height", "1.5"],
                    ["href", "https://policies.google.com/privacy", "target", "_blank", "rel", "noopener noreferrer", 1, "text-primary", "text-decoration-none"],
                    ["href", "https://policies.google.com/terms", "target", "_blank", "rel", "noopener noreferrer", 1, "text-primary", "text-decoration-none"],
                    ["type", "normal", "stylingMode", "outlined", 3, "onClick", "text", "width", "height", "disabled", "elementAttr"],
                    ["class", "d-flex align-items-center justify-content-center", 4, "dxTemplate", "dxTemplateOf"],
                    ["aria-hidden", "true", 1, "separator", "my-4"],
                    [1, "text-muted", "text-uppercase", 2, "font-size", "0.75rem"],
                    [1, "d-flex", "align-items-center", "justify-content-center"],
                    ["fill", "none", "height", "18", "role", "img", "viewBox", "0 0 18 18", "width", "18", "xmlns", "http://www.w3.org/2000/svg", 1, "me-2"],
                    ["clip-rule", "evenodd", "d", "M17.64 9.20419C17.64 8.56601 17.5827 7.95237 17.4764 7.36328H9V10.8446H13.8436C13.635 11.9696 13.0009 12.9228 12.0477 13.561V15.8192H14.9564C16.6582 14.2524 17.64 11.9451 17.64 9.20419Z", "fill", "#4285F4", "fill-rule", "evenodd"],
                    ["clip-rule", "evenodd", "d", "M8.99976 18C11.4298 18 13.467 17.1941 14.9561 15.8195L12.0475 13.5613C11.2416 14.1013 10.2107 14.4204 8.99976 14.4204C6.65567 14.4204 4.67158 12.8372 3.96385 10.71H0.957031V13.0418C2.43794 15.9831 5.48158 18 8.99976 18Z", "fill", "#34A853", "fill-rule", "evenodd"],
                    ["clip-rule", "evenodd", "d", "M3.96409 10.7098C3.78409 10.1698 3.68182 9.59301 3.68182 8.99983C3.68182 8.40664 3.78409 7.82983 3.96409 7.28983V4.95801H0.957273C0.347727 6.17301 0 7.54755 0 8.99983C0 10.4521 0.347727 11.8266 0.957273 13.0416L3.96409 10.7098Z", "fill", "#FBBC05", "fill-rule", "evenodd"],
                    ["clip-rule", "evenodd", "d", "M8.99976 3.57955C10.3211 3.57955 11.5075 4.03364 12.4402 4.92545L15.0216 2.34409C13.4629 0.891818 11.4257 0 8.99976 0C5.48158 0 2.43794 2.01682 0.957031 4.95818L3.96385 7.29C4.67158 5.16273 6.65567 3.57955 8.99976 3.57955Z", "fill", "#EA4335", "fill-rule", "evenodd"],
                    [1, "text-danger", "mt-2", "mb-0", "small"],
                    ["aria-hidden", "true", 1, "separator", "my-3"],
                    [1, "d-flex", "gap-2", "mb-3"],
                    [1, "d-block", "w-100", 3, "saveBtnClick", "isOnPopup", "saveText", "useSubmitBehavior"],
                    [1, "d-block", "w-100", "mb-3", 3, "isOnPopup", "saveText", "useSubmitBehavior", "height"],
                    [1, "d-block", "w-100", "mb-3", 3, "saveBtnClick", "isOnPopup", "saveText", "useSubmitBehavior"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "h5", 2), c(3), a(), r(4, "p", 3), c(5), a()(), h(6, Si, 1, 2, "app-skeleton-loader", 4), h(7, Ii, 26, 31), a()), i & 2 && (s("ngClass", n.isMobileDevice ? "mx-2" : "mx-5"), o(3), g(" ", n.formatMessage("auth_welcome_back"), " "), o(2), g(" ", n.formatMessage("auth_sign_in_subtitle"), " "), o(), f(n.form ? -1 : 6), o(), f(n.form ? 7 : -1))
                },
                dependencies: [le, q, G, Y, J, vt, Me, $, V, A, P, D, N, me],
                styles: ["form[aria-busy=true][_ngcontent-%COMP%]{pointer-events:none;opacity:.8;transition:opacity .2s ease-in-out}  .google-btn-light{background-color:var(--background-color)!important;border-color:#3498db!important}  .google-btn-light:hover:not(.dx-state-disabled){background-color:var(--theme-hover-color)!important}  .google-btn-dark{background-color:var(--bg-secondary)!important;border-color:#3498db!important}  .google-btn-dark:hover:not(.dx-state-disabled){background-color:var(--theme-hover-color)!important}  .google-btn-dark .dx-button-text{color:var(--primary-text)!important}body.dark-theme[_nghost-%COMP%]     .dx-texteditor.dx-editor-outlined, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor.dx-editor-outlined{background-color:#1e293b!important;border-color:#3498db!important}body.dark-theme[_nghost-%COMP%]     .dx-texteditor-container, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-container, body.dark-theme[_nghost-%COMP%]     .dx-texteditor-input-container, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-input-container{background-color:#1e293b!important}body.dark-theme[_nghost-%COMP%]     .dx-texteditor-input, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-input{color:#fff!important;background-color:#1e293b!important;-webkit-text-fill-color:#ffffff!important}body.dark-theme[_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill, body.dark-theme[_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill:hover, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill:hover, body.dark-theme[_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill:focus, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill:focus, body.dark-theme[_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill:active, body.dark-theme   [_nghost-%COMP%]     .dx-texteditor-input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px #1E293B inset!important;-webkit-text-fill-color:#ffffff!important;caret-color:#fff!important}body.dark-theme[_nghost-%COMP%]     .dx-placeholder:before, body.dark-theme   [_nghost-%COMP%]     .dx-placeholder:before{color:#94a3b8!important}"]
            })
        }
    }
    return t
})();

function Ai(t, l) {
    if (t & 1 && (r(0, "p", 7), c(1), a()), t & 2) {
        let e = u();
        o(), g(" ", e.errorMessage, " ")
    }
}
var qt = (() => {
    class t {
        constructor(e) {
            this.reCaptchaV3Service = e, this.formatMessage = S, this.formService = m(U), this.authenticationService = m(j), this.toastNotificationService = m(R), this.fb = new O, this.isLoading = !1, this.errorMessage = "", this.siteKey = I.siteKey
        }
        ngOnInit() {
            this.form = this.fb.group({
                email: [null, b.required],
                google_recaptcha: [""]
            })
        }
        onSubmit() {
            this.errorMessage = "", this.reCaptchaV3Service.execute(this.siteKey, "login", e => {
                this.form.patchValue({
                    google_recaptcha: e
                }), this.form.valid ? (this.isLoading = !0, this.authenticationService.sendPasswordResetLink(this.form.value).subscribe({
                    next: i => this.handleResponse(i),
                    error: i => {
                        this.errorMessage = i.error.error
                    }
                }).add(() => this.isLoading = !1)) : this.formService.validateFormFields(this.form)
            }, {
                useGlobalDomain: !0
            })
        }
        handleResponse(e) {
            this.toastNotificationService.success("notification_sent_password_reset_link")
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(H))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-request-reset"]
                ],
                standalone: !1,
                decls: 17,
                vars: 9,
                consts: [
                    [1, "row", "mb-5", "mx-5"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row"],
                    ["name", "email", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    [1, "form-floating"],
                    ["formControlName", "email", "id", "floatingInput", "type", "email", "autocomplete", "email", "spellcheck", "false", 1, "form-control", 3, "placeholder"],
                    ["for", "floatingInput"],
                    [1, "text-danger"],
                    [1, "col-sm12", "col-md-12", "col-lg-12"],
                    ["id", "request-reset-save-button", "saveText", "auth_send_reset_email", "savingText", "sending_email", 1, "float-end", "mt-2", "w-100", 3, "isOnPopup", "isSaving"],
                    [1, "row", "mt-3"],
                    [1, "float-end", "fs-6"],
                    ["routerLink", "/auth/login"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0)(1, "form", 1), _("ngSubmit", function() {
                        return n.onSubmit()
                    }), r(2, "div", 2)(3, "app-control-container", 3)(4, "div", 4), d(5, "input", 5), r(6, "label", 6), c(7), a()(), h(8, Ai, 2, 1, "p", 7), a()(), r(9, "div", 2)(10, "div", 8), d(11, "app-save-btn", 9), a()(), r(12, "div", 10)(13, "div", 8)(14, "label", 11)(15, "a", 12), c(16), a()()()()()()), i & 2 && (o(), s("formGroup", n.form), o(2), s("errorMsg", n.formatMessage("auth_email_required"))("label", n.formatMessage("auth_enter_email_to_reset")), o(2), s("placeholder", n.formatMessage("auth_email_example")), o(2), v(n.formatMessage("auth_email_or_mobile_no")), o(), f(n.errorMessage ? 8 : -1), o(3), s("isOnPopup", !0)("isSaving", n.isLoading), o(5), v(n.formatMessage("auth_login")))
                },
                dependencies: [q, G, V, rt, A, P, D, N, me],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ni(t, l) {
    t & 1 && d(0, "app-skeleton-loader", 1), t & 2 && s("rows", 3)("columns", 1)
}

function Di(t, l) {
    if (t & 1 && (r(0, "span")(1, "p", 15), c(2), a()()), t & 2) {
        let e = u(2);
        o(2), g(" ", e.errorMessage, " ")
    }
}

function Oi(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "form", 3), _("ngSubmit", function() {
            C(e);
            let n = u();
            return x(n.onSubmit())
        }), r(1, "div", 4)(2, "app-control-container", 5)(3, "dx-text-box", 6)(4, "dx-validator"), d(5, "dxi-validation-rule", 7)(6, "dxi-validation-rule", 8), a()()(), r(7, "app-control-container", 9), d(8, "app-password", 10), a(), r(9, "app-control-container", 11), d(10, "app-password", 12)(11, "app-error", 13), a()(), h(12, Di, 3, 1, "span"), d(13, "app-save-btn", 14), a()
    }
    if (t & 2) {
        let e = u();
        s("formGroup", e.form), o(2), s("errorMsg", e.formatMessage("common_email_required_error"))("label", e.formatMessage("common_email_id")), o(3), s("message", e.formatMessage("auth_email_required")), o(), s("message", e.formatMessage("auth_email_invalid")), o(), s("errorMsg", e.formatMessage("common_auth_password_required_error"))("label", e.formatMessage("change_password_new_password_label")), o(), s("formControl", e.form.controls.password)("isEditMode", !0)("placeholder", e.formatMessage("auth_enter_password")), o(), s("errorMsg", e.formatMessage("auth_password_confirmation_required"))("label", e.formatMessage("auth_confirm_password")), o(), s("formControl", e.form.controls.password_confirmation)("isEditMode", !0)("placeholder", e.formatMessage("auth_password_confirmation")), o(), s("displayError", e.isSubmitted && e.form.value.password !== e.form.value.password_confirmation)("errorMsg", e.formatMessage("auth_password_mismatch_error")), o(), f(e.errorMessage ? 12 : -1), o(), s("isOnPopup", !0)("isSaving", e.isLoading)
    }
}
var Gt = (() => {
    class t {
        constructor() {
            this.formatMessage = S, this.formService = m(U), this.router = m(L), this.authService = m(j), this.activatedRouter = m(F), this.toastNotificationService = m(R), this.fb = new O, this.isLoading = !1, this.errorMessage = "", this.isSubmitted = !1, this.passwordComparison = () => this.form.value.password
        }
        ngOnInit() {
            this.form = this.fb.group({
                email: [null, b.required],
                password: [null, b.required],
                password_confirmation: [null, b.required],
                reset_token: [null, b.required]
            }), this.activatedRouter.params.subscribe({
                next: e => {
                    e.token && this.form.patchValue({
                        reset_token: e.token
                    })
                },
                error: e => {
                    console.error("error ", e)
                }
            })
        }
        onSubmit() {
            this.isSubmitted = !0, this.form.valid && this.form.value.password === this.form.value.password_confirmation ? this.authService.changePassword(this.form.value).subscribe({
                next: () => {
                    this.handleResponse()
                },
                error: e => {
                    this.handleError(e)
                }
            }) : this.formService.validateFormFields(this.form)
        }
        handleResponse() {
            this.toastNotificationService.success("notification_password_change_success"), this.router.navigate(["/auth/login"])
        }
        handleError(e) {
            this.errorMessage = e.error.error
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-response-reset"]
                ],
                standalone: !1,
                decls: 3,
                vars: 2,
                consts: [
                    [1, "row", "mb-5", "mx-5"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row"],
                    ["name", "email", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "email", "id", "response-reset-email", "placeholder", "eg:example@gmail.com"],
                    ["type", "required", 3, "message"],
                    ["type", "email", 3, "message"],
                    ["name", "password", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["id", "response-reset-password", 3, "formControl", "isEditMode", "placeholder"],
                    ["name", "password_confirmation", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["id", "response-reset-password-confirmation", 3, "formControl", "isEditMode", "placeholder"],
                    [3, "displayError", "errorMsg"],
                    ["id", "response-reset-save-button", "saveText", "auth_change_password", "savingText", "auth_updating_password", 1, "float-end", "w-100", "mt-2", 3, "isOnPopup", "isSaving"],
                    [1, "text-danger"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0), h(1, Ni, 1, 2, "app-skeleton-loader", 1), h(2, Oi, 14, 20, "form", 2), a()), i & 2 && (o(), f(n.form ? -1 : 1), o(), f(n.form ? 2 : -1))
                },
                dependencies: [K, q, G, Y, J, ke, $, Te, V, A, P, ye, D, N],
                encapsulation: 2
            })
        }
    }
    return t
})();
var re = class {
    constructor(l) {
        return Object.assign(this, l)
    }
    static getForm(l) {
        return new O().group({
            name: [l.name || null, [b.required]],
            company_name: [l.company_name || null, [b.required]],
            email: [l.email || null, [b.required]],
            plan: [l.plan || "Standard", [b.required]],
            source: [l.source || null],
            country_id: [l.country_id || [b.required]],
            currency_code: [l.currency_code || null],
            mobile_number: [l.mobile_number || null, [b.required]],
            domain: [l.domain || null, [b.required, xt.domainNameValidator]],
            agree_term_and_conditions: [l.agree_term_and_conditions || !1, [b.requiredTrue]],
            google_recaptcha: [""],
            referral_code: [l.referral_code || null]
        })
    }
};
var zt = (() => {
    class t extends Se {
        constructor(e) {
            super(e, Fe), this.api = e, this.endpoint = Fe
        }
        checkUniqueEmail(e) {
            return this.api.post(this.endpoint + "/checkUniqueEmail", {
                email: e
            })
        }
        checkUniqueDomain(e) {
            return this.api.post(this.endpoint + "/checkUniqueDomain", {
                domain: e
            })
        }
        resendActivationEmail(e) {
            return this.api.post(this.endpoint + "/resendActivationEmail", {
                email: e
            })
        }
        getProspectStatus(e) {
            return this.api.get(`${pt}/${e}/status`)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(X(Ee))
            }
        }
        static {
            this.\u0275prov = ee({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Li = () => ({
        autocomplete: "new-country"
    }),
    Bi = () => ({
        style: "text-transform: lowercase"
    });

function ji(t, l) {
    t & 1 && (r(0, "div", 3), d(1, "dx-load-indicator", 5), a()), t & 2 && (o(), s("visible", !0))
}

function Ui(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "form", 6), _("ngSubmit", function() {
            C(e);
            let n = u(2);
            return x(n.onSignup())
        }), r(1, "div", 1)(2, "app-control-container", 7), d(3, "dx-text-box", 8), a(), r(4, "app-control-container", 9), d(5, "dx-text-box", 10), a(), r(6, "app-control-container", 11)(7, "dx-select-box", 12), _("onSelectionChanged", function(n) {
            C(e);
            let p = u(2);
            return x(p.getStateListFromCountryList(n))
        }), a()(), r(8, "app-control-container", 13), d(9, "app-mobile-number", 14)(10, "app-error", 15), a(), r(11, "app-control-container", 16)(12, "dx-text-box", 17)(13, "dx-validator"), d(14, "dxi-validation-rule", 18)(15, "dxi-validation-rule", 19)(16, "dxi-validation-rule", 20), a()()(), r(17, "app-control-container", 21), d(18, "dx-select-box", 22), a()(), r(19, "div", 23)(20, "div", 2)(21, "label", 24), c(22), a(), r(23, "p"), c(24), d(25, "br"), c(26), d(27, "br"), a(), r(28, "div", 25)(29, "dx-text-box", 26)(30, "dx-validator"), d(31, "dxi-validation-rule", 20), a()(), r(32, "span", 27), c(33), a()(), d(34, "app-error", 28)(35, "app-error", 15), r(36, "p"), c(37), d(38, "br"), c(39), a()()(), r(40, "div", 29)(41, "div", 2)(42, "div", 30), d(43, "dx-check-box", 31), r(44, "a", 32), c(45), a(), c(46), r(47, "a", 33), c(48), a(), d(49, "app-error", 15), a()()(), d(50, "app-save-btn", 34), r(51, "div", 35)(52, "small"), c(53), r(54, "a", 36), c(55), a(), c(56), r(57, "a", 37), c(58), a(), c(59), a()()()
    }
    if (t & 2) {
        let e = u(2);
        s("formGroup", e.form), o(2), s("errorMsg", e.formatMessage("register_business_name_required"))("label", e.formatMessage("register_business_name")), o(), s("placeholder", e.formatMessage("register_type_business_name")), o(), s("errorMsg", e.formatMessage("register_admin_name_required"))("label", e.formatMessage("register_admin_name")), o(), s("placeholder", e.formatMessage("employee_name_placeholder")), o(), s("errorMsg", e.formatMessage("register_country_required"))("label", e.formatMessage("register_country")), o(), s("inputAttr", oe(64, Li))("items", e.countryList)("placeholder", e.formatMessage("register_select_country"))("searchEnabled", !0)("showClearButton", !0), o(), s("errorMsg", e.formatMessage("mobile_number_required_error"))("label", e.formatMessage("common_mobile_number")), o(), s("countryId", e.selectedCountryId)("formControl", e.form.controls.mobile_number)("isEditMode", e.isEditMode), o(), s("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), o(), s("errorMsg", e.formatMessage("email_required_error"))("label", e.formatMessage("common_email_id")), o(), s("placeholder", e.formatMessage("auth_email_example")), o(2), s("message", e.formatMessage("common_email_required_error")), o(), s("message", e.formatMessage("email_invalid_error")), o(), s("ignoreEmptyValue", !0)("message", e.formatMessage("email_already_registered_error"))("validationCallback", e.asyncEmailValidation), o(), s("errorMsg", e.formatMessage("plan_required_error"))("label", e.formatMessage("plan_label")), o(), s("items", e.plans)("searchEnabled", !0)("disabled", !!e.prospectToken), o(4), v(e.formatMessage("register_subdomain")), o(2), v(e.formatMessage("register_site_address_info")), o(2), g(" ", e.formatMessage("register_site_address_info2"), " "), o(3), s("inputAttr", oe(65, Bi))("placeholder", e.formatMessage("register_type_subdomain")), o(2), s("ignoreEmptyValue", !0)("message", e.formatMessage("register_domain_exists"))("validationCallback", e.asyncDomainValidation), o(2), g(".", e.domainName), o(), s("displayError", e.form.get("domain").invalid && e.form.get("domain").touched && e.form.get("domain").errors.required), o(), s("displayError", e.form.get("domain").invalid && e.form.get("domain").touched && e.form.get("domain").errors.invalidDomain)("errorMsg", e.formatMessage("register_invalid_domain")), o(2), g("\u2713 ", e.formatMessage("register_domain_alphanumeric")), o(2), g(" \u2715 ", e.formatMessage("register_domain_no_special")), o(4), s("text", e.formatMessage("register_agree_terms")), o(), s("href", e.termAndConditionUrl, W), o(), v(e.formatMessage("common_terms_and_conditions")), o(), g(" ", e.formatMessage("common_and"), " "), o(), s("href", e.privacyPolicyUrl, W), o(), v(e.formatMessage("auth_privacy_policy")), o(), s("displayError", e.form.get("agree_term_and_conditions").invalid && e.form.get("agree_term_and_conditions").touched)("errorMsg", e.formatMessage("register_must_agree_terms")), o(), s("isOnPopup", !0)("isSaving", e.isSaving)("useSubmitBehavior", !0), o(3), g("", e.formatMessage("auth_recaptcha_notice"), " "), o(2), v(e.formatMessage("auth_privacy_policy")), o(), g(" ", e.formatMessage("and"), " "), o(2), v(e.formatMessage("auth_terms_of_service")), o(), g(" ", e.formatMessage("apply"), ". ")
    }
}

function qi(t, l) {
    if (t & 1 && (r(0, "div", 1)(1, "div", 2), h(2, ji, 2, 1, "div", 3), h(3, Ui, 60, 66, "form", 4), a()()), t & 2) {
        let e = u();
        o(2), f(!e.form || e.isLoadingProspect ? 2 : -1), o(), f(e.form && !e.isLoadingProspect ? 3 : -1)
    }
}

function Gi(t, l) {
    t & 1 && d(0, "span", 41)
}

function zi(t, l) {
    t & 1 && d(0, "span", 41)
}

function $i(t, l) {
    t & 1 && d(0, "span", 41)
}

function Ki(t, l) {
    if (t & 1 && (r(0, "div", 1)(1, "div", 2)(2, "div", 38)(3, "h4", 39), c(4), a(), r(5, "p"), c(6), a(), r(7, "ul", 40)(8, "li"), h(9, Gi, 1, 0, "span", 41), c(10), a(), r(11, "li"), h(12, zi, 1, 0, "span", 41), c(13), a(), r(14, "li"), h(15, $i, 1, 0, "span", 41), c(16), a()(), r(17, "p"), c(18), a(), r(19, "p"), c(20), r(21, "b"), c(22), a(), c(23, "."), d(24, "br"), c(25), a()(), r(26, "div", 42)(27, "div", 43), c(28), a()()()()), t & 2) {
        let e = u();
        o(4), g(" ", e.formatMessage("register_preparing_domain")), o(2), v(e.formatMessage("register_initializing_process")), o(3), f(e.percentageCompleted <= 30 ? 9 : -1), o(), g(" ", e.formatMessage("register_preparing_database"), " "), o(2), f(e.percentageCompleted > 30 && e.percentageCompleted <= 60 ? 12 : -1), o(), g("", e.formatMessage("register_creating_defaults"), " "), o(2), f(e.percentageCompleted > 60 && e.percentageCompleted < 99 ? 15 : -1), o(), g("", e.formatMessage("register_sending_email"), " "), o(2), v(e.formatMessage("register_do_not_refresh")), o(2), g("", e.formatMessage("register_post_process_info"), " "), o(2), v(e.form.getRawValue().email), o(3), g(" ", e.formatMessage("register_click_activate"), " "), o(2), et(e.style), o(), g("", e.percentageCompleted, "% ")
    }
}

function Hi(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div")(1, "div", 1)(2, "div", 2)(3, "div", 38)(4, "h4", 39), c(5), a(), r(6, "p"), c(7), r(8, "b"), c(9), a()(), d(10, "br"), c(11), a()()(), r(12, "div", 1)(13, "div", 2)(14, "p"), c(15), a(), r(16, "app-save-btn", 44), _("saveBtnClick", function() {
            C(e);
            let n = u();
            return x(n.resendActivationEmail())
        }), a()()()()
    }
    if (t & 2) {
        let e = u();
        o(5), v(e.formatMessage("register_completed")), o(2), g("", e.formatMessage("register_sent_email"), ":"), o(2), v(e.form.getRawValue().email), o(2), g(" ", e.formatMessage("register_click_activate"), ": "), o(4), v(e.formatMessage("register_did_not_receive_email")), o(), s("isSaving", e.isResendingEmail)
    }
}
var $t = (() => {
    class t {
        constructor(e, i, n) {
            this.service = e, this.countryService = i, this.reCaptchaV3Service = n, this.formatMessage = S, this.formService = m(U), this.toastNotificationService = m(R), this.isMobileDevice = m(B).isMobileDevice(), this.activatedRoute = m(F), this.domainName = I.domainName, this.message = "", this.isSaving = !1, this.seconds = 20, this.plans = Object.values(z).map(p => ({
                value: p,
                text: p === z.STANDARD ? `${p} (Recommended)` : p
            })), this.percentageCompleted = 0, this.isResendingEmail = !1, this.isSuccess = !1, this.countryList = [], this.selectedCountryId = null, this.termAndConditionUrl = I.websiteUrl + "/terms-conditions", this.privacyPolicyUrl = I.websiteUrl + "/privacy-policy", this.sources = ut, this.siteKey = I.siteKey, this.isEditMode = !1, this.isLoadingProspect = !1, this.prospectToken = null, this.destroy$ = new Ue, this.router = m(L), this.passwordComparison = () => this.form.value.password, this.asyncEmailValidation = this.asyncEmailValidation.bind(this), this.asyncDomainValidation = this.asyncDomainValidation.bind(this), this.getCountries()
        }
        get style() {
            return "width:" + this.percentageCompleted + "%"
        }
        ngOnInit() {
            let e = this.activatedRoute.snapshot.queryParams,
                i = {},
                n = sessionStorage.getItem("prospect_signup");
            if (n) {
                let p = JSON.parse(n);
                sessionStorage.removeItem("prospect_signup"), Object.assign(i, p), p.prospect_token && (this.prospectToken = p.prospect_token, delete i.prospect_token), p.country_id && (i.country_id = Number(p.country_id))
            }
            if (e.prospect_token && !this.prospectToken) {
                this.prospectToken = e.prospect_token, this.isLoadingProspect = !0, this.loadProspectData(e.prospect_token);
                return
            }
            e.referral_code && (i.referral_code = e.referral_code), this.form = re.getForm(new re(ae(ae({}, this.signup), i))), i.country_id && (this.selectedCountryId = i.country_id)
        }
        loadProspectData(e) {
            this.service.getProspectStatus(e).subscribe({
                next: i => {
                    let n = i.order_status ? .value || i.order_status;
                    if (n !== "paid") {
                        this.toastNotificationService.error(n === "failed" ? "payment_failed_desc" : "payment_pending_desc"), this.router.navigate(["/pricing/prospect", e, "checkout"]);
                        return
                    }
                    let p = i.prospect || {},
                        w = {
                            name: p.name,
                            email: p.email,
                            mobile_number: p.mobile_number,
                            company_name: p.company_name,
                            plan: p.plan ? .name === "Trial" ? z.STANDARD : p.plan ? .name || "",
                            country_id: p.plan ? .country_id,
                            currency_code: p.currency_code
                        };
                    this.form = re.getForm(new re(ae(ae({}, this.signup), w))), w.country_id && (this.selectedCountryId = Number(w.country_id)), this.isLoadingProspect = !1
                },
                error: () => {
                    this.isLoadingProspect = !1
                }
            })
        }
        getStateListFromCountryList(e) {
            e.selectedItem ? .id && (this.form.patchValue({
                currency_code: e.selectedItem ? .currency_code
            }), this.selectedCountryId = e.selectedItem.id, this.isEditMode = !0)
        }
        asyncEmailValidation(e) {
            return this.service.checkUniqueEmail(e.value).pipe(De(i => !!(i.hasOwnProperty("success") && i.success))).toPromise()
        }
        asyncDomainValidation(e) {
            return this.service.checkUniqueDomain(e.value).pipe(De(i => !!(i.hasOwnProperty("success") && i.success))).toPromise()
        }
        onSignup() {
            this.message = "", this.reCaptchaV3Service.execute(this.siteKey, "signUp", e => {
                if (this.form.patchValue({
                        google_recaptcha: e
                    }), this.form.valid) {
                    this.isSaving = !0, this.percentageCompleted = 0, this.seconds = 40, this.timerSubscription && this.timerSubscription.unsubscribe(), this.timer();
                    let i = ae({}, this.form.value);
                    this.prospectToken && (i.prospect_token = this.prospectToken), this.service.create(i).subscribe({
                        next: () => {
                            this.isSuccess = !0
                        },
                        error: n => {
                            this.form.patchValue({
                                password: ""
                            }), this.message = n.error.error, this.timerSubscription && this.timerSubscription.unsubscribe(), this.percentageCompleted = 0
                        }
                    }).add(() => {
                        this.isSaving = !1
                    })
                } else this.formService.validateFormFields(this.form)
            }, {
                useGlobalDomain: !0
            })
        }
        timer() {
            this.timerSubscription = qe(1e3, 1800).pipe(ze(this.destroy$)).subscribe({
                next: e => {
                    if (e)
                        if (this.percentageCompleted == 100) {
                            this.percentageCompleted = 100;
                            return
                        } else this.percentageCompleted += 1
                }
            })
        }
        resendActivationEmail() {
            this.isResendingEmail = !0, this.service.resendActivationEmail(this.form.getRawValue().email).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_account_activation_email_resent_success")
                },
                error: () => {
                    this.toastNotificationService.error("notification_account_activation_email_send_error")
                }
            }).add(() => this.isResendingEmail = !1)
        }
        getCountries() {
            this.countryService.loadCountries().subscribe({
                next: e => {
                    this.countryList = e
                },
                error: e => {
                    this.toastNotificationService.error("notification_country_fetch_error")
                }
            })
        }
        ngOnDestroy() {
            this.destroy$.next(), this.destroy$.complete(), this.timerSubscription && this.timerSubscription.unsubscribe()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(zt), k(kt), k(H))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-sign-up"]
                ],
                inputs: {
                    signup: "signup"
                },
                standalone: !1,
                decls: 4,
                vars: 3,
                consts: [
                    [1, "container-fluid", "theme-secondary-bg"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "d-flex", "justify-content-center", "align-items-center", 2, "min-height", "60vh"],
                    [3, "formGroup"],
                    ["height", "50", "width", "50", 3, "visible"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "company_name", 1, "col-12", "col-sm-6", 3, "errorMsg", "label"],
                    ["formControlName", "company_name", "id", "signup-company-name", 3, "placeholder"],
                    ["name", "name", 1, "col-12", "col-sm-6", 3, "errorMsg", "label"],
                    ["formControlName", "name", "id", "signup-admin-name", 3, "placeholder"],
                    ["name", "country_id", 1, "col-12", "col-sm-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "country_id", "id", "address-country", "searchMode", "contains", "valueExpr", "id", 3, "onSelectionChanged", "inputAttr", "items", "placeholder", "searchEnabled", "showClearButton"],
                    ["name", "mobile_number", 1, "col-12", "col-sm-6", 3, "errorMsg", "label"],
                    ["id", "signup-mobile-number", 3, "countryId", "formControl", "isEditMode"],
                    [3, "displayError", "errorMsg"],
                    ["name", "email", 1, "col-12", "col-sm-6", 3, "errorMsg", "label"],
                    ["formControlName", "email", "id", "signup-email", 3, "placeholder"],
                    ["type", "required", 3, "message"],
                    ["type", "email", 3, "message"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    ["name", "plan", 1, "col-12", "col-sm-6", 3, "errorMsg", "label"],
                    ["formControlName", "plan", "displayExpr", "text", "valueExpr", "value", "searchMode", "contains", 3, "items", "searchEnabled", "disabled"],
                    [1, "row", "domain-section", "theme-secondary-bg"],
                    [1, "required", "fw-bold"],
                    [1, "input-group", "mb-3", "domain-input-group"],
                    ["aria-describedby", "basic-addon2", "formControlName", "domain", "id", "signup-sub-domain", 1, "form-control", "p-0", "subdomain-text-box", 3, "inputAttr", "placeholder"],
                    [1, "domain-suffix"],
                    ["errorMsg", "Subdomain is a required field", 3, "displayError"],
                    [1, "row", "mt-3"],
                    [1, "d-flex", "align-items-center", "justify-content-start", "flex-wrap"],
                    ["formControlName", "agree_term_and_conditions", "id", "signup-terms-and-conditions", 3, "text"],
                    ["target", "_blank", 1, "me-2", "mb-0", "link-without-effect", 3, "href"],
                    ["target", "_blank", 1, "ms-2", "mb-0", "link-without-effect", 3, "href"],
                    ["id", "signup-save-button", "saveText", "register_button", "savingText", "registering", "width", "100%", 1, "d-flex", "justify-content-center", "my-3", "w-100", 3, "isOnPopup", "isSaving", "useSubmitBehavior"],
                    [1, "text-center", "mt-3"],
                    ["href", "https://policies.google.com/privacy", 1, "link-without-effect"],
                    ["href", "https://policies.google.com/terms", 1, "link-without-effect"],
                    ["role", "alert", 1, "alert", "alert-success"],
                    [1, "alert-heading"],
                    [1, "registration-tasks"],
                    ["role", "status", 1, "spinner-border", "spinner-border-sm", "me-2"],
                    [1, "progress"],
                    ["aria-label", "Default striped example", "aria-valuemax", "100", "aria-valuemin", "0", "aria-valuenow", "10", "role", "progressbar", 1, "progress-bar", "progress-bar-striped", "progress-bar-animated", "lh-lg", "fs-5"],
                    ["id", "signup-resend-button", "saveText", "register_resend_email", "savingText", "resending_email", 1, "mt-1", "float-end", 3, "saveBtnClick", "isSaving"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0), h(1, qi, 4, 2, "div", 1), h(2, Ki, 29, 15, "div", 1), h(3, Hi, 17, 6, "div"), a()), i & 2 && (o(), f(!n.isSaving && !n.isSuccess ? 1 : -1), o(), f(n.isSaving && !n.isSuccess ? 2 : -1), o(), f(n.isSuccess ? 3 : -1))
                },
                dependencies: [K, q, G, Et, St, ke, wt, Ct, $, Te, V, A, P, ye, D, N],
                styles: [".subdomain-text-box[_ngcontent-%COMP%]{height:37px}.registration-tasks[_ngcontent-%COMP%]{list-style-type:none;padding-inline-start:20px!important}.domain-section[_ngcontent-%COMP%]{width:auto;margin:1px;padding-top:10px;border:.5px solid #3498db!important;border-radius:4px}.auth-shadow[_ngcontent-%COMP%]{height:655px;box-shadow:0 .5rem 1rem #00000026!important}.main-bg[_ngcontent-%COMP%]{height:100%;margin-top:-20px;padding-left:.5rem!important;background:#fff}.progress[_ngcontent-%COMP%]{height:24px}.domain-input-group[_ngcontent-%COMP%]{position:relative;width:100%}.domain-input-group[_ngcontent-%COMP%]   .dx-texteditor-input[_ngcontent-%COMP%]{padding-left:7.5rem;text-transform:lowercase}.domain-suffix[_ngcontent-%COMP%]{position:absolute;right:2rem;top:50%;transform:translateY(-50%);color:var(--primary-text);font-size:.95rem;background:transparent;pointer-events:none;font-weight:400}"]
            })
        }
    }
    return t
})();
var xe = (() => {
    class t extends Se {
        constructor(e) {
            super(e, Le), this.api = e, this.endpoint = Le
        }
        attempt(e) {
            return this.api.post(this.endpoint + "/attempt", e)
        }
        getMyTenants(e) {
            return this.api.getWithParams(this.endpoint + "/getMyTenants", e)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(X(Ee))
            }
        }
        static {
            this.\u0275prov = ee({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Wi = () => ({
    autocomplete: "username",
    enterkeyhint: "go"
});

function Qi(t, l) {
    if (t & 1 && (r(0, "div", 9), c(1), a()), t & 2) {
        let e = u(2);
        o(), g("", e.formatMessage("auth_try_another_email"), " ")
    }
}

function Xi(t, l) {
    if (t & 1 && d(0, "app-save-btn", 10), t & 2) {
        let e = u(2);
        s("gaEvent", "tenant_login_save_event")("isDisabled", e.form.invalid)("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function Zi(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div", 1)(1, "h2", 2), c(2), a(), r(3, "form", 3), _("ngSubmit", function() {
            C(e);
            let n = u();
            return x(n.form.valid && !n.isSaving && n.onSignIn())
        }), d(4, "button", 4), r(5, "div", 5)(6, "app-control-container", 6), d(7, "dx-text-box", 7)(8, "app-error", 8), h(9, Qi, 2, 1, "div", 9), a(), h(10, Xi, 1, 4, "app-save-btn", 10), a()()()
    }
    if (t & 2) {
        let e = u();
        o(2), v(e.formatMessage("auth_welcome")), o(), s("formGroup", e.form), o(3), s("errorMsg", e.formatMessage("auth_mobile_or_email_required"))("label", e.formatMessage("auth_email_or_mobile_no")), o(), s("placeholder", e.formatMessage("auth_email_or_mobile"))("inputAttr", oe(10, Wi)), o(), s("displayError", !e.isEmailExist)("errorMsg", e.formatMessage("auth_email_or_mobile_not_found")), o(), f(e.isEmailExist ? -1 : 9), o(), f(e.isEmailExist ? 10 : -1)
    }
}
var Ht = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.reCaptchaV3Service = i, this.formatMessage = S, this.formService = m(U), this.routerHelperService = m(we), this.toastNotificationService = m(R), this.fb = new O, this.router = m(L), this.isMobileDevice = m(B).isMobileDevice(), this.isOnAppSubdomain = window.location.hostname.startsWith("app."), this.isEmailExist = !0, this.isVisibleLoader = !0, this.isSaving = !1, this.siteKey = I.siteKey
        }
        ngOnInit() {
            this.isVisibleLoader = !1, this.form = this.fb.group({
                username: ["", [b.required]],
                google_recaptcha: [""]
            })
        }
        onSignIn() {
            this.isSaving || (this.isSaving = !0, this.form.get("username") ? .disable({
                emitEvent: !1
            }), this.reCaptchaV3Service.execute(this.siteKey, "attempt", e => {
                this.form.patchValue({
                    google_recaptcha: e
                }), this.form.valid ? (this.isEmailExist = !0, this.service.attempt(this.form.getRawValue()).subscribe({
                    next: i => {
                        this.isSaving = !1, this.form.get("username") ? .enable({
                            emitEvent: !1
                        }), this.tenants = i, this.tenants.length === 0 ? this.isEmailExist = !1 : this.tenants.length === 1 ? this.isMobileDevice || this.isOnAppSubdomain ? this.routerHelperService.redirectToAppUrl(this.form ? .value ? .username, this.tenants[0]) : (localStorage.setItem("tenantUrl", this.tenants[0].domain_url + "/jobs/list"), window.location.assign(this.tenants[0].domain_url + "/auth/login?username=" + this.form.value.username)) : this.tenants.length > 1 && (this.toastNotificationService.success("notification_otp_sent_success"), this.router.navigate(["auth/tenantVerify"], {
                            queryParams: {
                                username: this.form.value.username
                            }
                        }))
                    },
                    error: () => {
                        this.isSaving = !1, this.form.get("username") ? .enable({
                            emitEvent: !1
                        })
                    }
                })) : (this.isSaving = !1, this.form.get("username") ? .enable({
                    emitEvent: !1
                }), this.formService.validateFormFields(this.form))
            }, {
                useGlobalDomain: !0
            }))
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(xe), k(H))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-tenant-login"]
                ],
                standalone: !1,
                decls: 2,
                vars: 3,
                consts: [
                    ["height", "100%", "width", "100%", 3, "showPane", "visible"],
                    [1, "row", "mb-5", "mx-5"],
                    [1, "mb-3", "text-center", "fs-1"],
                    [1, "form", 3, "ngSubmit", "formGroup"],
                    ["type", "submit", "hidden", "", "tabindex", "-1", "aria-hidden", "true"],
                    [1, "row", "d-flex", "justify-content-center"],
                    ["name", "username", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "username", "id", "tenant-login-email", 3, "placeholder", "inputAttr"],
                    [3, "displayError", "errorMsg"],
                    [1, "fs-3", "fw-light", "text-primary", "text-center"],
                    ["saveText", "auth_continue", "savingText", "continue", "suffixIcon", "fa-thin fa-arrow-right ms-1", 1, "d-block", "me-0", "ms-auto", "mt-3", "w-100", 3, "gaEvent", "isDisabled", "isOnPopup", "isSaving"]
                ],
                template: function(i, n) {
                    i & 1 && (d(0, "dx-load-panel", 0), h(1, Zi, 11, 11, "div", 1)), i & 2 && (s("showPane", !1)("visible", n.isVisibleLoader), o(), f(n.isVisibleLoader ? -1 : 1))
                },
                dependencies: [K, q, G, _t, $, V, A, P, D, N],
                styles: ['.hr-text[_ngcontent-%COMP%]{color:#000;text-align:center;position:relative;height:1.5em;opacity:1.5;border:0;outline:0}.hr-text[_ngcontent-%COMP%]:before{position:absolute;top:50%;left:0;width:100%;height:1px;content:"";background:linear-gradient(to right,transparent,#818078,transparent)}.hr-text[_ngcontent-%COMP%]:after{line-height:1.5em;color:#818078;position:relative;display:inline-block;padding:0 .5em;content:attr(data-content);background-color:#fcfcfa}']
            })
        }
    }
    return t
})();

function Ji(t, l) {
    t & 1 && d(0, "app-skeleton-loader", 1), t & 2 && s("rows", 3)("columns", 1)
}

function eo(t, l) {
    if (t & 1 && (r(0, "p", 10), c(1), a()), t & 2) {
        let e = u(2);
        o(), v(e.errorMessage)
    }
}

function to(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "form", 4), _("ngSubmit", function() {
            C(e);
            let n = u();
            return x(n.saveOtp())
        }), r(1, "h6", 5), c(2), r(3, "span"), c(4), a(), c(5), a(), r(6, "p", 6), c(7), r(8, "strong"), c(9), a(), c(10), a(), r(11, "div", 7)(12, "app-otp-input", 8), _("otpComplete", function() {
            C(e);
            let n = u();
            return x(n.saveOtp())
        }), a(), d(13, "app-error", 9)(14, "app-error", 9), h(15, eo, 2, 1, "p", 10), r(16, "div", 11)(17, "span"), c(18), a(), r(19, "a", 12), _("click", function() {
            C(e);
            let n = u();
            return x(n.resendOtp())
        }), c(20), a()()()()
    }
    if (t & 2) {
        let e = u();
        s("formGroup", e.form), o(2), g("", e.formatMessage("otp_check_your"), " "), o(2), v(e.form == null || e.form.value == null ? null : e.form.value.username), o(), g(" ", e.formatMessage("auth_for_otp"), " "), o(2), g("", e.formatMessage("otp_instruction"), " "), o(2), v(e.form == null || e.form.value == null ? null : e.form.value.username), o(), g(". ", e.formatMessage("otp_expires_notice"), " "), o(2), s("hasError", e.form.get("otp").invalid && e.form.get("otp").touched), o(), s("displayError", e.form.get("otp").invalid && e.form.get("otp").touched && e.form.get("otp").errors.required)("errorMsg", e.formatMessage("otp_required_error")), o(), s("displayError", e.form.get("otp").invalid && e.form.get("otp").errors.maxlength && e.form.submitted)("errorMsg", e.formatMessage("otp_must_be_6_digits")), o(), f(e.errorMessage ? 15 : -1), o(3), v(e.formatMessage("auth_didnt_get_otp")), o(2), v(e.formatMessage("otp_resend"))
    }
}

function io(t, l) {
    if (t & 1 && d(0, "app-auth-tenant-list", 3), t & 2) {
        let e = u();
        s("tenants", e.tenants)
    }
}
var Wt = (() => {
    class t {
        constructor(e, i, n) {
            this.service = e, this.serviceTenant = i, this.reCaptchaV3Service = n, this.formatMessage = S, this.formService = m(U), this.activatedRouter = m(F), this.toastNotificationService = m(R), this.fb = new O, this.tenants = [], this.userName = null, this.errorMessage = "", this.siteKey = I.siteKey
        }
        ngAfterViewInit() {
            this.setForm()
        }
        saveOtp() {
            this.form.valid ? this.service.getMyTenants({
                username: this.form.value.username,
                otp: this.form.value.otp
            }).subscribe({
                next: e => {
                    this.tenants = e, this.userName = this.form.value.userName, this.form = null
                },
                error: e => {
                    this.errorMessage = e.error.error_message
                }
            }) : this.formService.validateFormFields(this.form)
        }
        resendOtp() {
            this.reCaptchaV3Service.execute(this.siteKey, "attempt", e => {
                this.serviceTenant.attempt({
                    username: this.form.value.username,
                    google_recaptcha: e
                }).subscribe({
                    next: i => {
                        this.toastNotificationService.success("notification_otp_sent_success")
                    },
                    error: i => {
                        this.toastNotificationService.error("notification_otp_send_error"), console.log("Can't send OTP", i)
                    }
                })
            })
        }
        setForm() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.email = e, this.form = this.fb.group({
                        username: [e.username, b.required],
                        otp: [e.code ? ? "", b.compose([b.required, b.maxLength(6)])]
                    })
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(k(xe), k(xe), k(H))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-tenant-verify"]
                ],
                standalone: !1,
                decls: 4,
                vars: 3,
                consts: [
                    [1, "row", "p-3"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "tenants"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "mb-3", "text-center", "fs-3"],
                    [1, "text-center", "fs-12", "mb-1"],
                    [1, "p-2", "text-center"],
                    ["formControlName", "otp", 3, "otpComplete", "hasError"],
                    [3, "displayError", "errorMsg"],
                    [1, "text-danger"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "mt-2", "fs-12"],
                    [1, "text-decoration-none", "resent-btn", "ms-2", "link-without-effect", 3, "click"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0), h(1, Ji, 1, 2, "app-skeleton-loader", 1), h(2, to, 21, 15, "form", 2), h(3, io, 1, 1, "app-auth-tenant-list", 3), a()), i & 2 && (o(), f(!n.form && !n.tenants.length ? 1 : -1), o(), f(n.form ? 2 : -1), o(), f(n.tenants.length ? 3 : -1))
                },
                dependencies: [K, Ie, Y, V, A, P, D, N, Pe],
                styles: [".otp-input[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{height:2.5rem;border-radius:5px!important}.resent-btn[_ngcontent-%COMP%]:hover{color:#2398d4}"]
            })
        }
    }
    return t
})();

function oo(t, l) {
    t & 1 && (r(0, "h5", 3), c(1, "Set Up Two-Factor Authentication"), a(), r(2, "p", 4), c(3, "Scan the QR code below with your authenticator app, then enter the 6-digit code."), a())
}

function no(t, l) {
    t & 1 && (r(0, "h5", 3), c(1, "Save Your Backup Codes"), a(), r(2, "p", 4), c(3, "Store these codes somewhere safe. Each code can only be used once to sign in if you lose access to your authenticator app."), a())
}

function ro(t, l) {
    t & 1 && c(0, " Enter one of your backup codes to sign in. ")
}

function ao(t, l) {
    t & 1 && c(0, " Enter the 6-digit code from your authenticator app. ")
}

function so(t, l) {
    if (t & 1 && (r(0, "h5", 3), c(1, "Two-Factor Authentication"), a(), r(2, "p", 4), h(3, ro, 1, 0)(4, ao, 1, 0), a()), t & 2) {
        let e = u();
        o(3), f(e.isUsingBackupCode ? 3 : 4)
    }
}

function co(t, l) {
    if (t & 1 && (r(0, "div", 6)(1, "code", 11), c(2), a()()), t & 2) {
        let e = l.$implicit;
        o(2), v(e)
    }
}

function lo(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div", 2)(1, "div", 5), te(2, co, 3, 1, "div", 6, se), a(), r(4, "div", 7)(5, "dx-button", 8), _("onClick", function() {
            C(e);
            let n = u();
            return x(n.copyBackupCodes())
        }), a(), r(6, "dx-button", 9), _("onClick", function() {
            C(e);
            let n = u();
            return x(n.downloadBackupCodes())
        }), a()(), r(7, "dx-button", 10), _("onClick", function() {
            C(e);
            let n = u();
            return x(n.continueAfterBackup())
        }), a()()
    }
    if (t & 2) {
        let e = u();
        o(2), ie(e.backupCodes), o(5), s("width", "100%")("height", 48)
    }
}

function mo(t, l) {
    if (t & 1 && (r(0, "div", 17)(1, "p", 18), c(2, "Supported apps: "), r(3, "strong"), c(4, "Google Authenticator"), a(), c(5, ", "), r(6, "strong"), c(7, "Microsoft Authenticator"), a(), c(8, ", "), r(9, "strong"), c(10, "Authy"), a(), c(11, ", or any TOTP-compatible app."), a()(), r(12, "div", 19), d(13, "img", 20), r(14, "div", 21)(15, "small", 4), c(16, "Or enter this key manually:"), a(), r(17, "div", 22)(18, "code", 23), c(19), a()()()()), t & 2) {
        let e = u(2);
        o(13), s("src", e.qrCode, W), o(6), v(e.secret)
    }
}

function po(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div", 1)(1, "app-otp-input", 24), _("otpComplete", function() {
            C(e);
            let n = u(2);
            return x(n.onVerify())
        }), a()()
    }
    if (t & 2) {
        let e = u(2);
        o(), s("hasError", !!e.message)
    }
}

function uo(t, l) {
    if (t & 1 && (r(0, "label", 25), c(1, "Backup Code"), a(), d(2, "dx-text-box", 26)), t & 2) {
        let e = u(2);
        o(2), s("showClearButton", !0)("disabled", e.isVerifying)
    }
}

function ho(t, l) {
    if (t & 1 && (r(0, "span", 14)(1, "p", 27), c(2), a()()), t & 2) {
        let e = u(2);
        o(2), v(e.message)
    }
}

function fo(t, l) {
    t & 1 && c(0, " Use authenticator code instead ")
}

function go(t, l) {
    t & 1 && c(0, " Use a backup code ")
}

function vo(t, l) {
    if (t & 1) {
        let e = M();
        r(0, "div", 1)(1, "a", 28), _("click", function() {
            C(e);
            let n = u(2);
            return x(n.toggleBackupCode())
        }), h(2, fo, 1, 0)(3, go, 1, 0), a()()
    }
    if (t & 2) {
        let e = u(2);
        o(2), f(e.isUsingBackupCode ? 2 : 3)
    }
}

function _o(t, l) {
    if (t & 1) {
        let e = M();
        h(0, mo, 20, 2), r(1, "form", 12), _("ngSubmit", function() {
            C(e);
            let n = u();
            return x(n.onVerify())
        }), r(2, "div", 13), h(3, po, 2, 1, "div", 1)(4, uo, 3, 2), h(5, ho, 3, 1, "span", 14), a(), h(6, vo, 4, 1, "div", 1), r(7, "div", 15)(8, "a", 16), c(9, " Back to login "), a()()()
    }
    if (t & 2) {
        let e = u();
        f(e.isSetupMode && e.qrCode ? 0 : -1), o(), s("formGroup", e.form), o(2), f(e.isUsingBackupCode ? 4 : 3), o(2), f(e.message ? 5 : -1), o(), f(e.isSetupMode ? -1 : 6)
    }
}
var Qt = (() => {
    class t {
        constructor() {
            this.formatMessage = S, this.router = m(L), this.authService = m(j), this.twoFactorService = m(Pt), this.loaderService = m(Z), this.toastNotificationService = m(R), this.themeService = m(de), this.fb = new O, this.isDarkTheme = this.themeService.isDarkTheme(), this.message = "", this.isVerifying = !1, this.isUsingBackupCode = !1, this.twoFactorToken = "", this.isSetupMode = !1, this.qrCode = "", this.secret = "", this.backupCodes = [], this.showBackupCodes = !1, this.redirectUrl = ""
        }
        ngOnInit() {
            let i = this.router.getCurrentNavigation() ? .extras ? .state || history.state;
            if (this.twoFactorToken = i ? .two_factor_token || "", this.isSetupMode = i ? .requires_2fa_setup || !1, this.redirectUrl = i ? .redirectUrl || "", !this.twoFactorToken) {
                this.router.navigate(["/auth/login"]);
                return
            }
            this.form = this.fb.group({
                code: ["", [b.required]]
            }), this.isSetupMode && this.loadQrCode()
        }
        loadQrCode() {
            this.loaderService.show(), this.twoFactorService.setupQr(this.twoFactorToken).subscribe({
                next: e => {
                    this.qrCode = e.qr_code, this.secret = e.manual_entry_key, this.loaderService.hide()
                },
                error: e => {
                    this.message = e.error ? .message || "Failed to load QR code.", this.toastNotificationService.error(this.message), this.loaderService.hide()
                }
            })
        }
        onVerify() {
            this.isVerifying || this.form.valid && (this.message = "", this.isVerifying = !0, this.loaderService.show(), this.isSetupMode ? this.twoFactorService.setupAndConfirm(this.form.value.code, this.twoFactorToken).subscribe({
                next: e => {
                    e.backup_codes && (this.backupCodes = e.backup_codes, this.showBackupCodes = !0), this.authService.setUserSession(e.user, e.access_token, e.permissions, this.redirectUrl)
                },
                error: e => {
                    this.message = e.error ? .message || "Invalid verification code.", this.toastNotificationService.error(this.message), this.form.get("code").reset(), this.isVerifying = !1, this.loaderService.hide()
                },
                complete: () => {
                    this.isVerifying = !1, this.loaderService.hide()
                }
            }) : this.twoFactorService.verify({
                two_factor_token: this.twoFactorToken,
                code: this.form.value.code,
                is_backup_code: this.isUsingBackupCode
            }).subscribe({
                next: e => {
                    this.authService.setUserSession(e.user, e.access_token, e.permissions, this.redirectUrl)
                },
                error: e => {
                    this.message = e.error ? .message || "Invalid verification code.", this.toastNotificationService.error(this.message), this.form.get("code").reset(), this.isVerifying = !1, this.loaderService.hide()
                },
                complete: () => {
                    this.isVerifying = !1, this.loaderService.hide()
                }
            }))
        }
        toggleBackupCode() {
            this.isUsingBackupCode = !this.isUsingBackupCode, this.form.get("code").reset(), this.message = ""
        }
        copyBackupCodes() {
            let e = this.backupCodes.join(`
`);
            navigator.clipboard.writeText(e), this.toastNotificationService.success("Backup codes copied to clipboard.")
        }
        downloadBackupCodes() {
            let e = `BytePhase Two-Factor Authentication Backup Codes

` + this.backupCodes.join(`
`) + `

Keep these codes safe. Each code can only be used once.`,
                i = new Blob([e], {
                    type: "text/plain"
                }),
                n = window.URL.createObjectURL(i),
                p = document.createElement("a");
            p.href = n, p.download = "bytephase-2fa-backup-codes.txt", p.click(), window.URL.revokeObjectURL(n)
        }
        continueAfterBackup() {
            this.showBackupCodes = !1
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-two-factor-verify"]
                ],
                standalone: !1,
                decls: 7,
                vars: 2,
                consts: [
                    [1, "row", "mb-4", "mx-5"],
                    [1, "text-center"],
                    [1, "p-3"],
                    [1, "mb-2", "fw-semibold"],
                    [1, "text-muted"],
                    [1, "row", "row-cols-2", "g-2", "mb-3"],
                    [1, "col", "text-center"],
                    [1, "d-flex", "gap-2", "justify-content-center", "mb-3"],
                    ["text", "Copy Codes", "type", "default", "stylingMode", "outlined", 3, "onClick"],
                    ["text", "Download", "type", "default", "stylingMode", "outlined", 3, "onClick"],
                    ["text", "I've Saved My Codes", "type", "default", "stylingMode", "contained", 3, "onClick", "width", "height"],
                    [1, "fs-6", "fw-bold", "user-select-all"],
                    ["role", "form", "aria-label", "Two-factor verification form", 3, "ngSubmit", "formGroup"],
                    [1, "mb-3"],
                    ["role", "alert", "aria-live", "assertive"],
                    [1, "text-center", "mt-3"],
                    ["routerLink", "/auth/login", 1, "text-muted", "text-decoration-none", "small"],
                    [1, "text-center", "mb-2"],
                    [1, "text-muted", "small", "mb-2"],
                    [1, "text-center", "mb-3"],
                    ["alt", "QR Code for authenticator app", 1, "img-fluid", 2, "max-width", "200px", 3, "src"],
                    [1, "mt-2"],
                    [1, "mt-1"],
                    [1, "fs-6", "user-select-all"],
                    ["formControlName", "code", 3, "otpComplete", "hasError"],
                    [1, "form-label", "mb-2"],
                    ["formControlName", "code", "placeholder", "XXXX-XXXX", 3, "showClearButton", "disabled"],
                    [1, "text-danger", "mt-2", "mb-0", "small", "text-center"],
                    [1, "text-primary", "text-decoration-none", "small", 2, "cursor", "pointer", 3, "click"]
                ],
                template: function(i, n) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1), h(2, oo, 4, 0)(3, no, 4, 0)(4, so, 5, 1), a(), h(5, lo, 8, 2, "div", 2)(6, _o, 10, 5), a()), i & 2 && (o(2), f(n.isSetupMode && !n.showBackupCodes ? 2 : n.showBackupCodes ? 3 : 4), o(3), f(n.showBackupCodes ? 5 : 6))
                },
                dependencies: [Ie, Me, $, V, A, P, D, N, me],
                styles: ["code[_ngcontent-%COMP%]{padding:4px 8px;background-color:#0000000d;border-radius:4px}"]
            })
        }
    }
    return t
})();
var Co = [{
        path: "",
        component: jt,
        children: [{
            path: "callback",
            component: Rt,
            canActivate: [Q],
            title: "BytePhase Auth Callback"
        }, {
            path: "login",
            component: Ut,
            canActivate: [ft],
            title: "BytePhase Login"
        }, {
            path: "tenantLogin",
            component: Ht,
            canActivate: [Q],
            title: "BytePhase Workspace Login"
        }, {
            path: "tenantVerify",
            component: Wt,
            canActivate: [Q],
            title: "BytePhase Login Verification"
        }, {
            path: "tenants",
            component: Pe,
            canActivate: [Q],
            title: "BytePhase Accounts List"
        }, {
            path: "signUp",
            component: $t,
            canActivate: [Q],
            title: "BytePhase Signup"
        }, {
            path: "requestPasswordReset",
            component: qt,
            canActivate: [Q],
            title: "BytePhase Reset Password"
        }, {
            path: "responsePasswordReset/:token",
            component: Gt,
            canActivate: [Q],
            title: "BytePhase Update Password"
        }, {
            path: "accountActivate/:activation_code",
            component: Dt,
            canActivate: [Q],
            title: "BytePhase Activate Account"
        }, {
            path: "two-factor-verify",
            component: Qt,
            title: "BytePhase Two-Factor Authentication"
        }, {
            path: "",
            redirectTo: "/auth/login",
            pathMatch: "full"
        }]
    }],
    Xt = (() => {
        class t {
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275mod = he({
                    type: t
                })
            }
            static {
                this.\u0275inj = ue({
                    imports: [Re.forChild(Co), Re]
                })
            }
        }
        return t
    })();
var as = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275mod = he({
                type: t
            })
        }
        static {
            this.\u0275inj = ue({
                imports: [ot, At, Xt, J, Mt]
            })
        }
    }
    return t
})();
export {
    Ot as a, H as b, as as c
};