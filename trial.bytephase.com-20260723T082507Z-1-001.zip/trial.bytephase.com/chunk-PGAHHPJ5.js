import {
    Pg as oe,
    V as te
} from "./chunk-DCKGQUHB.js";
import {
    aa as O,
    da as Z,
    ea as F,
    sd as Q,
    uf as I,
    ui as ee,
    vf as q,
    xk as $
} from "./chunk-GOPIAW4V.js";
import {
    a as E,
    b as W,
    i as J
} from "./chunk-FBFWB55K.js";
var Ge = (() => {
    class e {
        constructor(t) {
            this.api = t
        }
        checkServiceability(t) {
            return this.api.getWithParams(I + "/serviceability", t)
        }
        createShipment(t) {
            return this.api.post(I, t)
        }
        trackShipment(t) {
            return this.api.get(`${I}/${t}/track`)
        }
        cancelShipment(t, r) {
            return this.api.post(`${I}/${t}/cancel`, {
                reason: r
            })
        }
        connectProvider(t) {
            return this.api.post(q + "/connect", t)
        }
        disconnectProvider() {
            return this.api.delete(q + "/disconnect")
        }
        getProviderStatus() {
            return this.api.get(q + "/status")
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)(Z(ee))
            }
        }
        static {
            this.\u0275prov = O({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var X = {},
    le;

function V(e = {}) {
    X = E({
        animate: !0,
        allowClose: !0,
        overlayClickBehavior: "close",
        overlayOpacity: .7,
        smoothScroll: !1,
        disableActiveInteraction: !1,
        showProgress: !1,
        stagePadding: 10,
        stageRadius: 5,
        popoverOffset: 10,
        showButtons: ["next", "previous", "close"],
        disableButtons: [],
        overlayColor: "#000"
    }, e)
}

function s(e) {
    return e ? X[e] : X
}

function Te(e) {
    le = e
}

function k() {
    return le
}
var G = {};

function z(e, o) {
    G[e] = o
}

function P(e) {
    var o;
    (o = G[e]) == null || o.call(G)
}

function Se() {
    G = {}
}

function U(e, o, t, r) {
    return (e /= r / 2) < 1 ? t / 2 * e * e + o : -t / 2 * (--e * (e - 2) - 1) + o
}

function de(e) {
    let o = 'a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])';
    return e.flatMap(t => {
        let r = t.matches(o),
            i = Array.from(t.querySelectorAll(o));
        return [...r ? [t] : [], ...i]
    }).filter(t => getComputedStyle(t).pointerEvents !== "none" && Ee(t))
}

function ce(e) {
    if (!e || Ke(e)) return;
    let o = s("smoothScroll"),
        t = e.offsetHeight > window.innerHeight;
    e.scrollIntoView({
        behavior: !o || ke(e) ? "auto" : "smooth",
        inline: "center",
        block: t ? "start" : "center"
    })
}

function ke(e) {
    if (!e || !e.parentElement) return;
    let o = e.parentElement;
    return o.scrollHeight > o.clientHeight
}

function Ke(e) {
    let o = e.getBoundingClientRect();
    return o.top >= 0 && o.left >= 0 && o.bottom <= (window.innerHeight || document.documentElement.clientHeight) && o.right <= (window.innerWidth || document.documentElement.clientWidth)
}

function Ee(e) {
    return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
}
var Y = {};

function T(e, o) {
    Y[e] = o
}

function d(e) {
    return e ? Y[e] : Y
}

function ie() {
    Y = {}
}

function Pe(e, o, t, r) {
    let i = d("__activeStagePosition"),
        n = i || t.getBoundingClientRect(),
        c = r.getBoundingClientRect(),
        g = U(e, n.x, c.x - n.x, o),
        l = U(e, n.y, c.y - n.y, o),
        _ = U(e, n.width, c.width - n.width, o),
        y = U(e, n.height, c.height - n.height, o);
    i = {
        x: g,
        y: l,
        width: _,
        height: y
    }, ue(i), T("__activeStagePosition", i)
}

function pe(e) {
    if (!e) return;
    let o = e.getBoundingClientRect(),
        t = {
            x: o.x,
            y: o.y,
            width: o.width,
            height: o.height
        };
    T("__activeStagePosition", t), ue(t)
}

function Ae() {
    let e = d("__activeStagePosition"),
        o = d("__overlaySvg");
    if (!e) return;
    if (!o) {
        console.warn("No stage svg found.");
        return
    }
    let t = window.innerWidth,
        r = window.innerHeight;
    o.setAttribute("viewBox", `0 0 ${t} ${r}`)
}

function $e(e) {
    let o = Le(e);
    document.body.appendChild(o), me(o, t => {
        t.target.tagName === "path" && P("overlayClick")
    }), T("__overlaySvg", o)
}

function ue(e) {
    let o = d("__overlaySvg");
    if (!o) {
        $e(e);
        return
    }
    let t = o.firstElementChild;
    if (t ? .tagName !== "path") throw new Error("no path element found in stage svg");
    t.setAttribute("d", ve(e))
}

function Le(e) {
    let o = window.innerWidth,
        t = window.innerHeight,
        r = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    r.classList.add("driver-overlay", "driver-overlay-animated"), r.setAttribute("viewBox", `0 0 ${o} ${t}`), r.setAttribute("xmlSpace", "preserve"), r.setAttribute("xmlnsXlink", "http://www.w3.org/1999/xlink"), r.setAttribute("version", "1.1"), r.setAttribute("preserveAspectRatio", "xMinYMin slice"), r.style.fillRule = "evenodd", r.style.clipRule = "evenodd", r.style.strokeLinejoin = "round", r.style.strokeMiterlimit = "2", r.style.zIndex = "10000", r.style.position = "fixed", r.style.top = "0", r.style.left = "0", r.style.width = "100%", r.style.height = "100%";
    let i = document.createElementNS("http://www.w3.org/2000/svg", "path");
    return i.setAttribute("d", ve(e)), i.style.fill = s("overlayColor") || "rgb(0,0,0)", i.style.opacity = `${s("overlayOpacity")}`, i.style.pointerEvents = "auto", i.style.cursor = "auto", r.appendChild(i), r
}

function ve(e) {
    let o = window.innerWidth,
        t = window.innerHeight,
        r = s("stagePadding") || 0,
        i = s("stageRadius") || 0,
        n = e.width + r * 2,
        c = e.height + r * 2,
        g = Math.min(i, n / 2, c / 2),
        l = Math.floor(Math.max(g, 0)),
        _ = e.x - r + l,
        y = e.y - r,
        C = n - l * 2,
        a = c - l * 2;
    return `M${o},0L0,0L0,${t}L${o},${t}L${o},0Z
    M${_},${y} h${C} a${l},${l} 0 0 1 ${l},${l} v${a} a${l},${l} 0 0 1 -${l},${l} h-${C} a${l},${l} 0 0 1 -${l},-${l} v-${a} a${l},${l} 0 0 1 ${l},-${l} z`
}

function Be() {
    let e = d("__overlaySvg");
    e && e.remove()
}

function Ie() {
    let e = document.getElementById("driver-dummy-element");
    if (e) return e;
    let o = document.createElement("div");
    return o.id = "driver-dummy-element", o.style.width = "0", o.style.height = "0", o.style.pointerEvents = "none", o.style.opacity = "0", o.style.position = "fixed", o.style.top = "50%", o.style.left = "50%", document.body.appendChild(o), o
}

function re(e) {
    let {
        element: o
    } = e, t = typeof o == "function" ? o() : typeof o == "string" ? document.querySelector(o) : o;
    t || (t = Ie()), Me(t, e)
}

function He() {
    let e = d("__activeElement"),
        o = d("__activeStep");
    e && (pe(e), Ae(), _e(e, o))
}

function Me(e, o) {
    var t;
    let r = Date.now(),
        i = d("__activeStep"),
        n = d("__activeElement") || e,
        c = !n || n === e,
        g = e.id === "driver-dummy-element",
        l = n.id === "driver-dummy-element",
        _ = s("animate"),
        y = o.onHighlightStarted || s("onHighlightStarted"),
        C = o ? .onHighlighted || s("onHighlighted"),
        a = i ? .onDeselected || s("onDeselected"),
        p = s(),
        v = d();
    !c && a && a(l ? void 0 : n, i, {
        config: p,
        state: v,
        driver: k()
    }), y && y(g ? void 0 : e, o, {
        config: p,
        state: v,
        driver: k()
    });
    let m = !c && _,
        u = !1;
    We(), T("previousStep", i), T("previousElement", n), T("activeStep", o), T("activeElement", e);
    let h = () => {
        if (d("__transitionCallback") !== h) return;
        let w = Date.now() - r,
            b = 400 - w <= 400 / 2;
        o.popover && b && !u && m && (ne(e, o), u = !0), s("animate") && w < 400 ? Pe(w, 400, n, e) : (pe(e), C && C(g ? void 0 : e, o, {
            config: s(),
            state: d(),
            driver: k()
        }), T("__transitionCallback", void 0), T("__previousStep", i), T("__previousElement", n), T("__activeStep", o), T("__activeElement", e)), window.requestAnimationFrame(h)
    };
    T("__transitionCallback", h), window.requestAnimationFrame(h), ce(e), !m && o.popover && ne(e, o), n.classList.remove("driver-active-element", "driver-no-interaction"), n.removeAttribute("aria-haspopup"), n.removeAttribute("aria-expanded"), n.removeAttribute("aria-controls"), ((t = o.disableActiveInteraction) != null ? t : s("disableActiveInteraction")) && e.classList.add("driver-no-interaction"), e.classList.add("driver-active-element"), e.setAttribute("aria-haspopup", "dialog"), e.setAttribute("aria-expanded", "true"), e.setAttribute("aria-controls", "driver-popover-content")
}

function Ne() {
    var e;
    (e = document.getElementById("driver-dummy-element")) == null || e.remove(), document.querySelectorAll(".driver-active-element").forEach(o => {
        o.classList.remove("driver-active-element", "driver-no-interaction"), o.removeAttribute("aria-haspopup"), o.removeAttribute("aria-expanded"), o.removeAttribute("aria-controls")
    })
}

function H() {
    let e = d("__resizeTimeout");
    e && window.cancelAnimationFrame(e), T("__resizeTimeout", window.requestAnimationFrame(He))
}

function Re(e) {
    var o;
    if (!d("isInitialized") || !(e.key === "Tab" || e.keyCode === 9)) return;
    let t = d("__activeElement"),
        r = (o = d("popover")) == null ? void 0 : o.wrapper,
        i = de([...r ? [r] : [], ...t ? [t] : []]),
        n = i[0],
        c = i[i.length - 1];
    if (e.preventDefault(), e.shiftKey) {
        let g = i[i.indexOf(document.activeElement) - 1] || c;
        g ? .focus()
    } else {
        let g = i[i.indexOf(document.activeElement) + 1] || n;
        g ? .focus()
    }
}

function ye(e) {
    var o;
    ((o = s("allowKeyboardControl")) == null || o) && (e.key === "Escape" ? P("escapePress") : e.key === "ArrowRight" ? P("arrowRightPress") : e.key === "ArrowLeft" && P("arrowLeftPress"))
}

function me(e, o, t) {
    let r = (i, n) => {
        let c = i.target;
        e.contains(c) && ((!t || t(c)) && (i.preventDefault(), i.stopPropagation(), i.stopImmediatePropagation()), n ? .(i))
    };
    document.addEventListener("pointerdown", r, !0), document.addEventListener("mousedown", r, !0), document.addEventListener("pointerup", r, !0), document.addEventListener("mouseup", r, !0), document.addEventListener("click", i => {
        r(i, o)
    }, !0)
}

function je() {
    window.addEventListener("keyup", ye, !1), window.addEventListener("keydown", Re, !1), window.addEventListener("resize", H), window.addEventListener("scroll", H)
}

function De() {
    window.removeEventListener("keyup", ye), window.removeEventListener("resize", H), window.removeEventListener("scroll", H)
}

function We() {
    let e = d("popover");
    e && (e.wrapper.style.display = "none")
}

function ne(e, o) {
    var t, r;
    let i = d("popover");
    i && document.body.removeChild(i.wrapper), i = Fe(), document.body.appendChild(i.wrapper);
    let {
        title: n,
        description: c,
        showButtons: g,
        disableButtons: l,
        showProgress: _,
        nextBtnText: y = s("nextBtnText") || "Next &rarr;",
        prevBtnText: C = s("prevBtnText") || "&larr; Previous",
        progressText: a = s("progressText") || "{current} of {total}"
    } = o.popover || {};
    i.nextButton.innerHTML = y, i.previousButton.innerHTML = C, i.progress.innerHTML = a, n ? (i.title.innerHTML = n, i.title.style.display = "block") : i.title.style.display = "none", c ? (i.description.innerHTML = c, i.description.style.display = "block") : i.description.style.display = "none";
    let p = g || s("showButtons"),
        v = _ || s("showProgress") || !1,
        m = p ? .includes("next") || p ? .includes("previous") || v;
    i.closeButton.style.display = p.includes("close") ? "block" : "none", m ? (i.footer.style.display = "flex", i.progress.style.display = v ? "block" : "none", i.nextButton.style.display = p.includes("next") ? "block" : "none", i.previousButton.style.display = p.includes("previous") ? "block" : "none") : i.footer.style.display = "none";
    let u = l || s("disableButtons") || [];
    u != null && u.includes("next") && (i.nextButton.disabled = !0, i.nextButton.classList.add("driver-popover-btn-disabled")), u != null && u.includes("previous") && (i.previousButton.disabled = !0, i.previousButton.classList.add("driver-popover-btn-disabled")), u != null && u.includes("close") && (i.closeButton.disabled = !0, i.closeButton.classList.add("driver-popover-btn-disabled"));
    let h = i.wrapper;
    h.style.display = "block", h.style.left = "", h.style.top = "", h.style.bottom = "", h.style.right = "", h.id = "driver-popover-content", h.setAttribute("role", "dialog"), h.setAttribute("aria-labelledby", "driver-popover-title"), h.setAttribute("aria-describedby", "driver-popover-description");
    let w = i.arrow;
    w.className = "driver-popover-arrow";
    let b = ((t = o.popover) == null ? void 0 : t.popoverClass) || s("popoverClass") || "";
    h.className = `driver-popover ${b}`.trim(), me(i.wrapper, K => {
        var M, N, R;
        let B = K.target,
            j = ((M = o.popover) == null ? void 0 : M.onNextClick) || s("onNextClick"),
            A = ((N = o.popover) == null ? void 0 : N.onPrevClick) || s("onPrevClick"),
            D = ((R = o.popover) == null ? void 0 : R.onCloseClick) || s("onCloseClick");
        if (B.closest(".driver-popover-next-btn")) return j ? j(e, o, {
            config: s(),
            state: d(),
            driver: k()
        }) : P("nextClick");
        if (B.closest(".driver-popover-prev-btn")) return A ? A(e, o, {
            config: s(),
            state: d(),
            driver: k()
        }) : P("prevClick");
        if (B.closest(".driver-popover-close-btn")) return D ? D(e, o, {
            config: s(),
            state: d(),
            driver: k()
        }) : P("closeClick")
    }, K => !(i != null && i.description.contains(K)) && !(i != null && i.title.contains(K)) && typeof K.className == "string" && K.className.includes("driver-popover")), T("popover", i);
    let S = ((r = o.popover) == null ? void 0 : r.onPopoverRender) || s("onPopoverRender");
    S && S(i, {
        config: s(),
        state: d(),
        driver: k()
    }), _e(e, o), ce(h);
    let x = e.classList.contains("driver-dummy-element"),
        f = de([h, ...x ? [] : [e]]);
    f.length > 0 && f[0].focus()
}

function ge() {
    let e = d("popover");
    if (!(e != null && e.wrapper)) return;
    let o = e.wrapper.getBoundingClientRect(),
        t = s("stagePadding") || 0,
        r = s("popoverOffset") || 0;
    return {
        width: o.width + t + r,
        height: o.height + t + r,
        realWidth: o.width,
        realHeight: o.height
    }
}

function se(e, o) {
    let {
        elementDimensions: t,
        popoverDimensions: r,
        popoverPadding: i,
        popoverArrowDimensions: n
    } = o;
    return e === "start" ? Math.max(Math.min(t.top - i, window.innerHeight - r.realHeight - n.width), n.width) : e === "end" ? Math.max(Math.min(t.top - r ? .realHeight + t.height + i, window.innerHeight - r ? .realHeight - n.width), n.width) : e === "center" ? Math.max(Math.min(t.top + t.height / 2 - r ? .realHeight / 2, window.innerHeight - r ? .realHeight - n.width), n.width) : 0
}

function ae(e, o) {
    let {
        elementDimensions: t,
        popoverDimensions: r,
        popoverPadding: i,
        popoverArrowDimensions: n
    } = o;
    return e === "start" ? Math.max(Math.min(t.left - i, window.innerWidth - r.realWidth - n.width), n.width) : e === "end" ? Math.max(Math.min(t.left - r ? .realWidth + t.width + i, window.innerWidth - r ? .realWidth - n.width), n.width) : e === "center" ? Math.max(Math.min(t.left + t.width / 2 - r ? .realWidth / 2, window.innerWidth - r ? .realWidth - n.width), n.width) : 0
}

function _e(e, o) {
    let t = d("popover");
    if (!t) return;
    let {
        align: r = "start",
        side: i = "left"
    } = o ? .popover || {}, n = r, c = e.id === "driver-dummy-element" ? "over" : i, g = s("stagePadding") || 0, l = ge(), _ = t.arrow.getBoundingClientRect(), y = e.getBoundingClientRect(), C = y.top - l.height, a = C >= 0, p = window.innerHeight - (y.bottom + l.height), v = p >= 0, m = y.left - l.width, u = m >= 0, h = window.innerWidth - (y.right + l.width), w = h >= 0, b = !a && !v && !u && !w, S = c;
    if (c === "top" && a ? w = u = v = !1 : c === "bottom" && v ? w = u = a = !1 : c === "left" && u ? w = a = v = !1 : c === "right" && w && (u = a = v = !1), c === "over") {
        let x = window.innerWidth / 2 - l.realWidth / 2,
            f = window.innerHeight / 2 - l.realHeight / 2;
        t.wrapper.style.left = `${x}px`, t.wrapper.style.right = "auto", t.wrapper.style.top = `${f}px`, t.wrapper.style.bottom = "auto"
    } else if (b) {
        let x = window.innerWidth / 2 - l ? .realWidth / 2,
            f = 10;
        t.wrapper.style.left = `${x}px`, t.wrapper.style.right = "auto", t.wrapper.style.bottom = `${f}px`, t.wrapper.style.top = "auto"
    } else if (u) {
        let x = Math.min(m, window.innerWidth - l ? .realWidth - _.width),
            f = se(n, {
                elementDimensions: y,
                popoverDimensions: l,
                popoverPadding: g,
                popoverArrowDimensions: _
            });
        t.wrapper.style.left = `${x}px`, t.wrapper.style.top = `${f}px`, t.wrapper.style.bottom = "auto", t.wrapper.style.right = "auto", S = "left"
    } else if (w) {
        let x = Math.min(h, window.innerWidth - l ? .realWidth - _.width),
            f = se(n, {
                elementDimensions: y,
                popoverDimensions: l,
                popoverPadding: g,
                popoverArrowDimensions: _
            });
        t.wrapper.style.right = `${x}px`, t.wrapper.style.top = `${f}px`, t.wrapper.style.bottom = "auto", t.wrapper.style.left = "auto", S = "right"
    } else if (a) {
        let x = Math.min(C, window.innerHeight - l.realHeight - _.width),
            f = ae(n, {
                elementDimensions: y,
                popoverDimensions: l,
                popoverPadding: g,
                popoverArrowDimensions: _
            });
        t.wrapper.style.top = `${x}px`, t.wrapper.style.left = `${f}px`, t.wrapper.style.bottom = "auto", t.wrapper.style.right = "auto", S = "top"
    } else if (v) {
        let x = Math.min(p, window.innerHeight - l ? .realHeight - _.width),
            f = ae(n, {
                elementDimensions: y,
                popoverDimensions: l,
                popoverPadding: g,
                popoverArrowDimensions: _
            });
        t.wrapper.style.left = `${f}px`, t.wrapper.style.bottom = `${x}px`, t.wrapper.style.top = "auto", t.wrapper.style.right = "auto", S = "bottom"
    }
    b ? t.arrow.classList.add("driver-popover-arrow-none") : Oe(n, S, e)
}

function Oe(e, o, t) {
    let r = d("popover");
    if (!r) return;
    let i = t.getBoundingClientRect(),
        n = ge(),
        c = r.arrow,
        g = n.width,
        l = window.innerWidth,
        _ = i.width,
        y = i.left,
        C = n.height,
        a = window.innerHeight,
        p = i.top,
        v = i.height;
    c.className = "driver-popover-arrow";
    let m = o,
        u = e;
    if (o === "top" ? (y + _ <= 0 ? (m = "right", u = "end") : y + _ - g <= 0 && (m = "top", u = "start"), y >= l ? (m = "left", u = "end") : y + g >= l && (m = "top", u = "end")) : o === "bottom" ? (y + _ <= 0 ? (m = "right", u = "start") : y + _ - g <= 0 && (m = "bottom", u = "start"), y >= l ? (m = "left", u = "start") : y + g >= l && (m = "bottom", u = "end")) : o === "left" ? (p + v <= 0 ? (m = "bottom", u = "end") : p + v - C <= 0 && (m = "left", u = "start"), p >= a ? (m = "top", u = "end") : p + C >= a && (m = "left", u = "end")) : o === "right" && (p + v <= 0 ? (m = "bottom", u = "start") : p + v - C <= 0 && (m = "right", u = "start"), p >= a ? (m = "top", u = "start") : p + C >= a && (m = "right", u = "end")), !m) c.classList.add("driver-popover-arrow-none");
    else {
        c.classList.add(`driver-popover-arrow-side-${m}`), c.classList.add(`driver-popover-arrow-align-${u}`);
        let h = t.getBoundingClientRect(),
            w = c.getBoundingClientRect(),
            b = s("stagePadding") || 0,
            S = h.left - b < window.innerWidth && h.right + b > 0 && h.top - b < window.innerHeight && h.bottom + b > 0;
        o === "bottom" && S && (w.x > h.x && w.x + w.width < h.x + h.width ? r.wrapper.style.transform = "translateY(0)" : (c.classList.remove(`driver-popover-arrow-align-${u}`), c.classList.add("driver-popover-arrow-none"), r.wrapper.style.transform = `translateY(-${b/2}px)`))
    }
}

function Fe() {
    let e = document.createElement("div");
    e.classList.add("driver-popover");
    let o = document.createElement("div");
    o.classList.add("driver-popover-arrow");
    let t = document.createElement("header");
    t.id = "driver-popover-title", t.classList.add("driver-popover-title"), t.style.display = "none", t.innerText = "Popover Title";
    let r = document.createElement("div");
    r.id = "driver-popover-description", r.classList.add("driver-popover-description"), r.style.display = "none", r.innerText = "Popover description is here";
    let i = document.createElement("button");
    i.type = "button", i.classList.add("driver-popover-close-btn"), i.setAttribute("aria-label", "Close"), i.innerHTML = "&times;";
    let n = document.createElement("footer");
    n.classList.add("driver-popover-footer");
    let c = document.createElement("span");
    c.classList.add("driver-popover-progress-text"), c.innerText = "";
    let g = document.createElement("span");
    g.classList.add("driver-popover-navigation-btns");
    let l = document.createElement("button");
    l.type = "button", l.classList.add("driver-popover-prev-btn"), l.innerHTML = "&larr; Previous";
    let _ = document.createElement("button");
    return _.type = "button", _.classList.add("driver-popover-next-btn"), _.innerHTML = "Next &rarr;", g.appendChild(l), g.appendChild(_), n.appendChild(c), n.appendChild(g), e.appendChild(i), e.appendChild(o), e.appendChild(t), e.appendChild(r), e.appendChild(n), {
        wrapper: e,
        arrow: o,
        title: t,
        description: r,
        footer: n,
        previousButton: l,
        nextButton: _,
        closeButton: i,
        footerButtons: g,
        progress: c
    }
}

function qe() {
    var e;
    let o = d("popover");
    o && ((e = o.wrapper.parentElement) == null || e.removeChild(o.wrapper))
}

function he(e = {}) {
    V(e);

    function o() {
        s("allowClose") && y()
    }

    function t() {
        let a = s("overlayClickBehavior");
        if (s("allowClose") && a === "close") {
            y();
            return
        }
        if (typeof a == "function") {
            let p = d("__activeStep"),
                v = d("__activeElement");
            a(v, p, {
                config: s(),
                state: d(),
                driver: k()
            });
            return
        }
        a === "nextStep" && r()
    }

    function r() {
        let a = d("activeIndex"),
            p = s("steps") || [];
        if (typeof a > "u") return;
        let v = a + 1;
        p[v] ? _(v) : y()
    }

    function i() {
        let a = d("activeIndex"),
            p = s("steps") || [];
        if (typeof a > "u") return;
        let v = a - 1;
        p[v] ? _(v) : y()
    }

    function n(a) {
        (s("steps") || [])[a] ? _(a): y()
    }

    function c() {
        var a;
        if (d("__transitionCallback")) return;
        let p = d("activeIndex"),
            v = d("__activeStep"),
            m = d("__activeElement");
        if (typeof p > "u" || typeof v > "u" || typeof d("activeIndex") > "u") return;
        let u = ((a = v.popover) == null ? void 0 : a.onPrevClick) || s("onPrevClick");
        if (u) return u(m, v, {
            config: s(),
            state: d(),
            driver: k()
        });
        i()
    }

    function g() {
        var a;
        if (d("__transitionCallback")) return;
        let p = d("activeIndex"),
            v = d("__activeStep"),
            m = d("__activeElement");
        if (typeof p > "u" || typeof v > "u") return;
        let u = ((a = v.popover) == null ? void 0 : a.onNextClick) || s("onNextClick");
        if (u) return u(m, v, {
            config: s(),
            state: d(),
            driver: k()
        });
        r()
    }

    function l() {
        d("isInitialized") || (T("isInitialized", !0), document.body.classList.add("driver-active", s("animate") ? "driver-fade" : "driver-simple"), je(), z("overlayClick", t), z("escapePress", o), z("arrowLeftPress", c), z("arrowRightPress", g))
    }

    function _(a = 0) {
        var p, v, m, u, h, w, b, S;
        let x = s("steps");
        if (!x) {
            console.error("No steps to drive through"), y();
            return
        }
        if (!x[a]) {
            y();
            return
        }
        T("__activeOnDestroyed", document.activeElement), T("activeIndex", a);
        let f = x[a],
            K = x[a + 1],
            M = x[a - 1],
            N = ((p = f.popover) == null ? void 0 : p.doneBtnText) || s("doneBtnText") || "Done",
            R = s("allowClose"),
            B = typeof((v = f.popover) == null ? void 0 : v.showProgress) < "u" ? (m = f.popover) == null ? void 0 : m.showProgress : s("showProgress"),
            j = (((u = f.popover) == null ? void 0 : u.progressText) || s("progressText") || "{{current}} of {{total}}").replace("{{current}}", `${a+1}`).replace("{{total}}", `${x.length}`),
            A = ((h = f.popover) == null ? void 0 : h.showButtons) || s("showButtons"),
            D = ["next", "previous", ...R ? ["close"] : []].filter(xe => !(A != null && A.length) || A.includes(xe)),
            fe = ((w = f.popover) == null ? void 0 : w.onNextClick) || s("onNextClick"),
            we = ((b = f.popover) == null ? void 0 : b.onPrevClick) || s("onPrevClick"),
            be = ((S = f.popover) == null ? void 0 : S.onCloseClick) || s("onCloseClick");
        re(W(E({}, f), {
            popover: E({
                showButtons: D,
                nextBtnText: K ? void 0 : N,
                disableButtons: [...M ? [] : ["previous"]],
                showProgress: B,
                progressText: j,
                onNextClick: fe || (() => {
                    K ? _(a + 1) : y()
                }),
                onPrevClick: we || (() => {
                    _(a - 1)
                }),
                onCloseClick: be || (() => {
                    y()
                })
            }, f ? .popover || {})
        }))
    }

    function y(a = !0) {
        let p = d("__activeElement"),
            v = d("__activeStep"),
            m = d("__activeOnDestroyed"),
            u = s("onDestroyStarted");
        if (a && u) {
            let b = !p || p ? .id === "driver-dummy-element";
            u(b ? void 0 : p, v, {
                config: s(),
                state: d(),
                driver: k()
            });
            return
        }
        let h = v ? .onDeselected || s("onDeselected"),
            w = s("onDestroyed");
        if (document.body.classList.remove("driver-active", "driver-fade", "driver-simple"), De(), qe(), Ne(), Be(), Se(), ie(), p && v) {
            let b = p.id === "driver-dummy-element";
            h && h(b ? void 0 : p, v, {
                config: s(),
                state: d(),
                driver: k()
            }), w && w(b ? void 0 : p, v, {
                config: s(),
                state: d(),
                driver: k()
            })
        }
        m && m.focus()
    }
    let C = {
        isActive: () => d("isInitialized") || !1,
        refresh: H,
        drive: (a = 0) => {
            l(), _(a)
        },
        setConfig: V,
        setSteps: a => {
            ie(), V(W(E({}, s()), {
                steps: a
            }))
        },
        getConfig: s,
        getState: d,
        getActiveIndex: () => d("activeIndex"),
        isFirstStep: () => d("activeIndex") === 0,
        isLastStep: () => {
            let a = s("steps") || [],
                p = d("activeIndex");
            return p !== void 0 && p === a.length - 1
        },
        getActiveStep: () => d("activeStep"),
        getActiveElement: () => d("activeElement"),
        getPreviousElement: () => d("previousElement"),
        getPreviousStep: () => d("previousStep"),
        moveNext: r,
        movePrevious: i,
        moveTo: n,
        hasNextStep: () => {
            let a = s("steps") || [],
                p = d("activeIndex");
            return p !== void 0 && !!a[p + 1]
        },
        hasPreviousStep: () => {
            let a = s("steps") || [],
                p = d("activeIndex");
            return p !== void 0 && !!a[p - 1]
        },
        highlight: a => {
            l(), re(W(E({}, a), {
                popover: a.popover ? E({
                    showButtons: [],
                    showProgress: !1,
                    progressText: ""
                }, a.popover) : void 0
            }))
        },
        destroy: () => {
            y(!1)
        }
    };
    return Te(C), C
}
var L = [{
    id: "OVERVIEW",
    titleKey: "tour_overview_title",
    descKey: "tour_overview_desc",
    category: "overview",
    route: "/dashboards",
    expandSidebar: !0,
    steps: [{
        titleKey: "tour_overview_s1_title",
        bodyKey: "tour_overview_s1_body",
        navigateTo: "/imports"
    }, {
        selector: "app-import-wizard",
        titleKey: "tour_overview_imports_item_title",
        bodyKey: "tour_overview_imports_item_body",
        side: "top",
        align: "center",
        navigateTo: "/settings"
    }, {
        selector: "#settings-sidebar-nav",
        titleKey: "tour_overview_settings2_title",
        bodyKey: "tour_overview_settings2_body",
        side: "right",
        align: "start",
        navigateTo: "/settings/general"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_overview_general_title",
        bodyKey: "tour_overview_general_body",
        side: "left",
        align: "start",
        navigateTo: "/settings/print"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_overview_print_title",
        bodyKey: "tour_overview_print_body",
        side: "left",
        align: "start"
    }, {
        selector: "#help-center",
        titleKey: "tour_overview_help_title",
        bodyKey: "tour_overview_help_body",
        side: "right",
        align: "end",
        navigateTo: "/supports/centers"
    }, {
        selector: "[data-item-id='0']",
        titleKey: "tour_overview_feedback_title",
        bodyKey: "tour_overview_feedback_body",
        side: "bottom",
        align: "center"
    }, {
        selector: ".chatbot-fab",
        titleKey: "tour_overview_chatbot_title",
        bodyKey: "tour_overview_chatbot_body",
        side: "left",
        align: "end",
        clickToAdvance: !0
    }, {
        selector: "#chatbot-window",
        titleKey: "tour_overview_assistant_title",
        bodyKey: "tour_overview_assistant_body",
        side: "left",
        align: "center",
        navigateTo: "/jobs/list"
    }, {
        selector: ".empty-state-primary-btn",
        titleKey: "tour_overview_create_title",
        bodyKey: "tour_overview_create_body",
        side: "bottom",
        align: "center"
    }, {
        selector: "#tours-launcher-btn",
        titleKey: "tour_overview_replay_title",
        bodyKey: "tour_overview_replay_body",
        side: "bottom",
        align: "end"
    }]
}, {
    id: "CREATE_JOB",
    titleKey: "tour_create_job_title",
    descKey: "tour_create_job_desc",
    category: "repair_workflow",
    taskCode: "CREATE_JOB",
    route: "/jobs/add",
    steps: [{
        selector: "#job-basic-info-configure-fields",
        titleKey: "tour_create_job_configure_title",
        bodyKey: "tour_create_job_configure_body",
        side: "bottom",
        align: "end"
    }, {
        selector: "#job-basic-info-title",
        titleKey: "tour_create_job_s1_title",
        bodyKey: "tour_create_job_s1_body",
        side: "bottom",
        align: "start"
    }, {
        selector: "#job-basic-device-info-title",
        titleKey: "tour_create_job_s2_title",
        bodyKey: "tour_create_job_s2_body",
        side: "bottom",
        align: "start"
    }, {
        selector: "#job-basic-info-repair-section-title",
        titleKey: "tour_create_job_s3_title",
        bodyKey: "tour_create_job_s3_body",
        side: "bottom",
        align: "start"
    }, {
        selector: "#job-basic-info-section-title",
        titleKey: "tour_create_job_s4_title",
        bodyKey: "tour_create_job_s4_body",
        side: "bottom",
        align: "start"
    }, {
        selector: "#job-basic-info-attachment",
        titleKey: "tour_create_job_s5_title",
        bodyKey: "tour_create_job_s5_body",
        side: "top",
        align: "start"
    }, {
        selector: "#job-basic-info-save",
        titleKey: "tour_create_job_s6_title",
        bodyKey: "tour_create_job_s6_body",
        side: "top",
        align: "end"
    }]
}, {
    id: "CONFIGURE_TAX",
    titleKey: "tour_tax_title",
    descKey: "tour_tax_desc",
    category: "finance_billing",
    taskCode: "CONFIGURE_TAX",
    route: "/settings/taxes",
    steps: [{
        selector: "#tax-add-btn",
        titleKey: "tour_tax_s1_title",
        bodyKey: "tour_tax_s1_body",
        side: "bottom",
        align: "end",
        clickToAdvance: !0
    }, {
        selector: "#tax-popup-tax-name",
        titleKey: "tour_tax_s2_title",
        bodyKey: "tour_tax_s2_body",
        side: "bottom",
        align: "start"
    }, {
        selector: "#tax-popup-tax-rate",
        titleKey: "tour_tax_s3_title",
        bodyKey: "tour_tax_s3_body",
        side: "bottom",
        align: "start"
    }, {
        selector: "#tax-popup-save",
        titleKey: "tour_tax_s4_title",
        bodyKey: "tour_tax_s4_body",
        side: "top",
        align: "end"
    }]
}, {
    id: "SYSTEM_CONFIG",
    titleKey: "tour_system_config_title",
    descKey: "tour_system_config_desc",
    category: "business_basics",
    route: "/settings/email",
    steps: [{
        selector: "#settings-content-area",
        titleKey: "tour_system_config_email_title",
        bodyKey: "tour_system_config_email_body",
        side: "left",
        align: "start",
        navigateTo: "/settings/workflow"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_system_config_workflow_title",
        bodyKey: "tour_system_config_workflow_body",
        side: "left",
        align: "start",
        navigateTo: "/settings/modules"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_system_config_modules_title",
        bodyKey: "tour_system_config_modules_body",
        side: "left",
        align: "start",
        navigateTo: "/settings/terms"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_system_config_terms_title",
        bodyKey: "tour_system_config_terms_body",
        side: "left",
        align: "start",
        navigateTo: "/settings/sequences"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_system_config_sequences_title",
        bodyKey: "tour_system_config_sequences_body",
        side: "left",
        align: "start"
    }]
}, {
    id: "TEAM_SECURITY",
    titleKey: "tour_team_security_title",
    descKey: "tour_team_security_desc",
    category: "run_business",
    route: "/employees/:loggedInUserId/permissions",
    expandSidebar: !0,
    steps: [{
        selector: "app-permission-detail",
        titleKey: "tour_team_security_permissions_title",
        bodyKey: "tour_team_security_permissions_body",
        side: "top",
        align: "center",
        navigateTo: "/settings/security"
    }, {
        selector: "#settings-content-area",
        titleKey: "tour_team_security_2fa_title",
        bodyKey: "tour_team_security_2fa_body",
        side: "left",
        align: "start"
    }, {
        selector: "#download-app",
        titleKey: "tour_team_security_app_title",
        bodyKey: "tour_team_security_app_body",
        side: "right",
        align: "end"
    }]
}];
var st = (() => {
    class e {
        constructor() {
            this.router = F(Q), this.storageService = F(te), this.sidebarService = F(oe)
        }
        getAvailableTours() {
            return L
        }
        hasSeenTour(t) {
            try {
                return localStorage.getItem(this.seenKey(t)) === "1"
            } catch (r) {
                return !1
            }
        }
        markTourSeen(t) {
            try {
                localStorage.setItem(this.seenKey(t), "1")
            } catch (r) {}
        }
        seenKey(t) {
            let r = this.storageService.getTenantId() || "t",
                i = this.storageService.getUser() ? .id ? ? "u";
            return `guidedTourSeen:${r}:${i}:${t}`
        }
        hasTourForTask(t) {
            return !!t && L.some(r => r.taskCode === t)
        }
        startTaskTour(t) {
            let r = L.find(i => i.taskCode === t);
            r && this.startTour(r.id)
        }
        startTour(t) {
            let r = L.find(c => c.id === t);
            if (!r) return;
            r.expandSidebar && this.sidebarService.sidebarExpanded.next(!0);
            let i = r.route.replace(":loggedInUserId", String(this.storageService.getUser() ? .id ? ? "")),
                n = this.router.url.split("?")[0];
            n === i || n.startsWith(i) ? this.runTour(r) : this.router.navigate([i]).then(c => {
                c && this.runTour(r)
            })
        }
        runTourById(t) {
            let r = L.find(i => i.id === t);
            r && this.runTour(r)
        }
        runTour(t) {
            return J(this, null, function*() {
                yield this.waitForElement(t.steps[0] ? .selector), yield new Promise(n => setTimeout(n, 300));
                let r = t.steps.map(n => ({
                        element: n.selector,
                        popover: {
                            title: $(n.titleKey),
                            description: $(n.bodyKey),
                            side: n.side ? ? "bottom",
                            align: n.align ? ? "start"
                        }
                    })),
                    i;
                i = he({
                    showProgress: !0,
                    allowClose: !0,
                    nextBtnText: $("tour_next"),
                    prevBtnText: $("tour_prev"),
                    doneBtnText: $("tour_done"),
                    steps: r,
                    onNextClick: () => {
                        let n = i.getActiveIndex() ? ? 0,
                            c = t.steps[n];
                        c ? .clickToAdvance && c.selector ? (document.querySelector(c.selector) ? .click(), setTimeout(() => {
                            this.waitForElement(t.steps[n + 1] ? .selector).then(() => i.moveNext())
                        }, 300)) : c ? .navigateTo ? this.router.navigate([c.navigateTo]).then(() => {
                            this.waitForElement(t.steps[n + 1] ? .selector).then(() => i.moveNext())
                        }) : i.moveNext()
                    },
                    onDestroyStarted: () => {
                        i.destroy()
                    }
                }), i.drive()
            })
        }
        waitForElement(t, r = 25, i = 150) {
            return new Promise(n => {
                if (!t) {
                    n(null);
                    return
                }
                let c = 0,
                    g = () => {
                        let l = document.querySelector(t);
                        if (l || c >= r) {
                            n(l);
                            return
                        }
                        c++, setTimeout(g, i)
                    };
                g()
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)
            }
        }
        static {
            this.\u0275prov = O({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
export {
    Ge as a, st as b
};