import {
    a as p,
    b as w,
    i as a
} from "./chunk-FBFWB55K.js";
var Oe = () => {};
var Re = function(e) {
        let t = [],
            n = 0;
        for (let r = 0; r < e.length; r++) {
            let i = e.charCodeAt(r);
            i < 128 ? t[n++] = i : i < 2048 ? (t[n++] = i >> 6 | 192, t[n++] = i & 63 | 128) : (i & 64512) === 55296 && r + 1 < e.length && (e.charCodeAt(r + 1) & 64512) === 56320 ? (i = 65536 + ((i & 1023) << 10) + (e.charCodeAt(++r) & 1023), t[n++] = i >> 18 | 240, t[n++] = i >> 12 & 63 | 128, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128) : (t[n++] = i >> 12 | 224, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128)
        }
        return t
    },
    kt = function(e) {
        let t = [],
            n = 0,
            r = 0;
        for (; n < e.length;) {
            let i = e[n++];
            if (i < 128) t[r++] = String.fromCharCode(i);
            else if (i > 191 && i < 224) {
                let o = e[n++];
                t[r++] = String.fromCharCode((i & 31) << 6 | o & 63)
            } else if (i > 239 && i < 365) {
                let o = e[n++],
                    s = e[n++],
                    u = e[n++],
                    f = ((i & 7) << 18 | (o & 63) << 12 | (s & 63) << 6 | u & 63) - 65536;
                t[r++] = String.fromCharCode(55296 + (f >> 10)), t[r++] = String.fromCharCode(56320 + (f & 1023))
            } else {
                let o = e[n++],
                    s = e[n++];
                t[r++] = String.fromCharCode((i & 15) << 12 | (o & 63) << 6 | s & 63)
            }
        }
        return t.join("")
    },
    xe = {
        byteToCharMap_: null,
        charToByteMap_: null,
        byteToCharMapWebSafe_: null,
        charToByteMapWebSafe_: null,
        ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        get ENCODED_VALS() {
            return this.ENCODED_VALS_BASE + "+/="
        },
        get ENCODED_VALS_WEBSAFE() {
            return this.ENCODED_VALS_BASE + "-_."
        },
        HAS_NATIVE_SUPPORT: typeof atob == "function",
        encodeByteArray(e, t) {
            if (!Array.isArray(e)) throw Error("encodeByteArray takes an array as a parameter");
            this.init_();
            let n = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_,
                r = [];
            for (let i = 0; i < e.length; i += 3) {
                let o = e[i],
                    s = i + 1 < e.length,
                    u = s ? e[i + 1] : 0,
                    f = i + 2 < e.length,
                    c = f ? e[i + 2] : 0,
                    b = o >> 2,
                    l = (o & 3) << 4 | u >> 4,
                    R = (u & 15) << 2 | c >> 6,
                    P = c & 63;
                f || (P = 64, s || (R = 64)), r.push(n[b], n[l], n[R], n[P])
            }
            return r.join("")
        },
        encodeString(e, t) {
            return this.HAS_NATIVE_SUPPORT && !t ? btoa(e) : this.encodeByteArray(Re(e), t)
        },
        decodeString(e, t) {
            return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : kt(this.decodeStringToByteArray(e, t))
        },
        decodeStringToByteArray(e, t) {
            this.init_();
            let n = t ? this.charToByteMapWebSafe_ : this.charToByteMap_,
                r = [];
            for (let i = 0; i < e.length;) {
                let o = n[e.charAt(i++)],
                    u = i < e.length ? n[e.charAt(i)] : 0;
                ++i;
                let c = i < e.length ? n[e.charAt(i)] : 64;
                ++i;
                let l = i < e.length ? n[e.charAt(i)] : 64;
                if (++i, o == null || u == null || c == null || l == null) throw new Y;
                let R = o << 2 | u >> 4;
                if (r.push(R), c !== 64) {
                    let P = u << 4 & 240 | c >> 2;
                    if (r.push(P), l !== 64) {
                        let Dt = c << 6 & 192 | l;
                        r.push(Dt)
                    }
                }
            }
            return r
        },
        init_() {
            if (!this.byteToCharMap_) {
                this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
                for (let e = 0; e < this.ENCODED_VALS.length; e++) this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e), this.charToByteMap_[this.byteToCharMap_[e]] = e, this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e, e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e)
            }
        }
    },
    Y = class extends Error {
        constructor() {
            super(...arguments), this.name = "DecodeBase64StringError"
        }
    },
    Ot = function(e) {
        let t = Re(e);
        return xe.encodeByteArray(t, !0)
    },
    X = function(e) {
        return Ot(e).replace(/\./g, "")
    },
    Me = function(e) {
        try {
            return xe.decodeString(e, !0)
        } catch (t) {
            console.error("base64Decode failed: ", t)
        }
        return null
    };

function Nt() {
    if (typeof self < "u") return self;
    if (typeof window < "u") return window;
    if (typeof global < "u") return global;
    throw new Error("Unable to locate global object.")
}
var Rt = () => Nt().__FIREBASE_DEFAULTS__,
    xt = () => {
        if (typeof process > "u" || typeof process.env > "u") return;
        let e = process.env.__FIREBASE_DEFAULTS__;
        if (e) return JSON.parse(e)
    },
    Mt = () => {
        if (typeof document > "u") return;
        let e;
        try {
            e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)
        } catch (n) {
            return
        }
        let t = e && Me(e[1]);
        return t && JSON.parse(t)
    },
    Bt = () => {
        try {
            return Oe() || Rt() || xt() || Mt()
        } catch (e) {
            console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
            return
        }
    };
var Q = () => Bt() ? .config;
var L = class {
    constructor() {
        this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise((t, n) => {
            this.resolve = t, this.reject = n
        })
    }
    wrapCallback(t) {
        return (n, r) => {
            n ? this.reject(n) : this.resolve(r), typeof t == "function" && (this.promise.catch(() => {}), t.length === 1 ? t(n) : t(n, r))
        }
    }
};

function F() {
    try {
        return typeof indexedDB == "object"
    } catch (e) {
        return !1
    }
}

function $() {
    return new Promise((e, t) => {
        try {
            let n = !0,
                r = "validate-browser-context-for-indexeddb-analytics-module",
                i = self.indexedDB.open(r);
            i.onsuccess = () => {
                i.result.close(), n || self.indexedDB.deleteDatabase(r), e(!0)
            }, i.onupgradeneeded = () => {
                n = !1
            }, i.onerror = () => {
                t(i.error ? .message || "")
            }
        } catch (n) {
            t(n)
        }
    })
}

function Be() {
    return !(typeof navigator > "u" || !navigator.cookieEnabled)
}
var Pt = "FirebaseError",
    y = class e extends Error {
        constructor(t, n, r) {
            super(n), this.code = t, this.customData = r, this.name = Pt, Object.setPrototypeOf(this, e.prototype), Error.captureStackTrace && Error.captureStackTrace(this, _.prototype.create)
        }
    },
    _ = class {
        constructor(t, n, r) {
            this.service = t, this.serviceName = n, this.errors = r
        }
        create(t, ...n) {
            let r = n[0] || {},
                i = `${this.service}/${t}`,
                o = this.errors[t],
                s = o ? Lt(o, r) : "Error",
                u = `${this.serviceName}: ${s} (${i}).`;
            return new y(i, u, r)
        }
    };

function Lt(e, t) {
    return e.replace(Ft, (n, r) => {
        let i = t[r];
        return i != null ? String(i) : `<${r}?>`
    })
}
var Ft = /\{\$([^}]+)}/g;

function H(e, t) {
    if (e === t) return !0;
    let n = Object.keys(e),
        r = Object.keys(t);
    for (let i of n) {
        if (!r.includes(i)) return !1;
        let o = e[i],
            s = t[i];
        if (Ne(o) && Ne(s)) {
            if (!H(o, s)) return !1
        } else if (o !== s) return !1
    }
    for (let i of r)
        if (!n.includes(i)) return !1;
    return !0
}

function Ne(e) {
    return e !== null && typeof e == "object"
}
var pi = 14400 * 1e3;

function x(e) {
    return e && e._delegate ? e._delegate : e
}
var g = class {
    constructor(t, n, r) {
        this.name = t, this.instanceFactory = n, this.type = r, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null
    }
    setInstantiationMode(t) {
        return this.instantiationMode = t, this
    }
    setMultipleInstances(t) {
        return this.multipleInstances = t, this
    }
    setServiceProps(t) {
        return this.serviceProps = t, this
    }
    setInstanceCreatedCallback(t) {
        return this.onInstanceCreated = t, this
    }
};
var T = "[DEFAULT]";
var Z = class {
    constructor(t, n) {
        this.name = t, this.container = n, this.component = null, this.instances = new Map, this.instancesDeferred = new Map, this.instancesOptions = new Map, this.onInitCallbacks = new Map
    }
    get(t) {
        let n = this.normalizeInstanceIdentifier(t);
        if (!this.instancesDeferred.has(n)) {
            let r = new L;
            if (this.instancesDeferred.set(n, r), this.isInitialized(n) || this.shouldAutoInitialize()) try {
                let i = this.getOrInitializeService({
                    instanceIdentifier: n
                });
                i && r.resolve(i)
            } catch (i) {}
        }
        return this.instancesDeferred.get(n).promise
    }
    getImmediate(t) {
        let n = this.normalizeInstanceIdentifier(t ? .identifier),
            r = t ? .optional ? ? !1;
        if (this.isInitialized(n) || this.shouldAutoInitialize()) try {
            return this.getOrInitializeService({
                instanceIdentifier: n
            })
        } catch (i) {
            if (r) return null;
            throw i
        } else {
            if (r) return null;
            throw Error(`Service ${this.name} is not available`)
        }
    }
    getComponent() {
        return this.component
    }
    setComponent(t) {
        if (t.name !== this.name) throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);
        if (this.component) throw Error(`Component for ${this.name} has already been provided`);
        if (this.component = t, !!this.shouldAutoInitialize()) {
            if (Ht(t)) try {
                this.getOrInitializeService({
                    instanceIdentifier: T
                })
            } catch (n) {}
            for (let [n, r] of this.instancesDeferred.entries()) {
                let i = this.normalizeInstanceIdentifier(n);
                try {
                    let o = this.getOrInitializeService({
                        instanceIdentifier: i
                    });
                    r.resolve(o)
                } catch (o) {}
            }
        }
    }
    clearInstance(t = T) {
        this.instancesDeferred.delete(t), this.instancesOptions.delete(t), this.instances.delete(t)
    }
    delete() {
        return a(this, null, function*() {
            let t = Array.from(this.instances.values());
            yield Promise.all([...t.filter(n => "INTERNAL" in n).map(n => n.INTERNAL.delete()), ...t.filter(n => "_delete" in n).map(n => n._delete())])
        })
    }
    isComponentSet() {
        return this.component != null
    }
    isInitialized(t = T) {
        return this.instances.has(t)
    }
    getOptions(t = T) {
        return this.instancesOptions.get(t) || {}
    }
    initialize(t = {}) {
        let {
            options: n = {}
        } = t, r = this.normalizeInstanceIdentifier(t.instanceIdentifier);
        if (this.isInitialized(r)) throw Error(`${this.name}(${r}) has already been initialized`);
        if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
        let i = this.getOrInitializeService({
            instanceIdentifier: r,
            options: n
        });
        for (let [o, s] of this.instancesDeferred.entries()) {
            let u = this.normalizeInstanceIdentifier(o);
            r === u && s.resolve(i)
        }
        return i
    }
    onInit(t, n) {
        let r = this.normalizeInstanceIdentifier(n),
            i = this.onInitCallbacks.get(r) ? ? new Set;
        i.add(t), this.onInitCallbacks.set(r, i);
        let o = this.instances.get(r);
        return o && t(o, r), () => {
            i.delete(t)
        }
    }
    invokeOnInitCallbacks(t, n) {
        let r = this.onInitCallbacks.get(n);
        if (r)
            for (let i of r) try {
                i(t, n)
            } catch (o) {}
    }
    getOrInitializeService({
        instanceIdentifier: t,
        options: n = {}
    }) {
        let r = this.instances.get(t);
        if (!r && this.component && (r = this.component.instanceFactory(this.container, {
                instanceIdentifier: $t(t),
                options: n
            }), this.instances.set(t, r), this.instancesOptions.set(t, n), this.invokeOnInitCallbacks(r, t), this.component.onInstanceCreated)) try {
            this.component.onInstanceCreated(this.container, t, r)
        } catch (i) {}
        return r || null
    }
    normalizeInstanceIdentifier(t = T) {
        return this.component ? this.component.multipleInstances ? t : T : t
    }
    shouldAutoInitialize() {
        return !!this.component && this.component.instantiationMode !== "EXPLICIT"
    }
};

function $t(e) {
    return e === T ? void 0 : e
}

function Ht(e) {
    return e.instantiationMode === "EAGER"
}
var j = class {
    constructor(t) {
        this.name = t, this.providers = new Map
    }
    addComponent(t) {
        let n = this.getProvider(t.name);
        if (n.isComponentSet()) throw new Error(`Component ${t.name} has already been registered with ${this.name}`);
        n.setComponent(t)
    }
    addOrOverwriteComponent(t) {
        this.getProvider(t.name).isComponentSet() && this.providers.delete(t.name), this.addComponent(t)
    }
    getProvider(t) {
        if (this.providers.has(t)) return this.providers.get(t);
        let n = new Z(t, this);
        return this.providers.set(t, n), n
    }
    getProviders() {
        return Array.from(this.providers.values())
    }
};
var jt = [],
    d = (function(e) {
        return e[e.DEBUG = 0] = "DEBUG", e[e.VERBOSE = 1] = "VERBOSE", e[e.INFO = 2] = "INFO", e[e.WARN = 3] = "WARN", e[e.ERROR = 4] = "ERROR", e[e.SILENT = 5] = "SILENT", e
    })(d || {}),
    Vt = {
        debug: d.DEBUG,
        verbose: d.VERBOSE,
        info: d.INFO,
        warn: d.WARN,
        error: d.ERROR,
        silent: d.SILENT
    },
    Ut = d.INFO,
    Wt = {
        [d.DEBUG]: "log",
        [d.VERBOSE]: "log",
        [d.INFO]: "info",
        [d.WARN]: "warn",
        [d.ERROR]: "error"
    },
    zt = (e, t, ...n) => {
        if (t < e.logLevel) return;
        let r = new Date().toISOString(),
            i = Wt[t];
        if (i) console[i](`[${r}]  ${e.name}:`, ...n);
        else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)
    },
    V = class {
        constructor(t) {
            this.name = t, this._logLevel = Ut, this._logHandler = zt, this._userLogHandler = null, jt.push(this)
        }
        get logLevel() {
            return this._logLevel
        }
        set logLevel(t) {
            if (!(t in d)) throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);
            this._logLevel = t
        }
        setLogLevel(t) {
            this._logLevel = typeof t == "string" ? Vt[t] : t
        }
        get logHandler() {
            return this._logHandler
        }
        set logHandler(t) {
            if (typeof t != "function") throw new TypeError("Value assigned to `logHandler` must be a function");
            this._logHandler = t
        }
        get userLogHandler() {
            return this._userLogHandler
        }
        set userLogHandler(t) {
            this._userLogHandler = t
        }
        debug(...t) {
            this._userLogHandler && this._userLogHandler(this, d.DEBUG, ...t), this._logHandler(this, d.DEBUG, ...t)
        }
        log(...t) {
            this._userLogHandler && this._userLogHandler(this, d.VERBOSE, ...t), this._logHandler(this, d.VERBOSE, ...t)
        }
        info(...t) {
            this._userLogHandler && this._userLogHandler(this, d.INFO, ...t), this._logHandler(this, d.INFO, ...t)
        }
        warn(...t) {
            this._userLogHandler && this._userLogHandler(this, d.WARN, ...t), this._logHandler(this, d.WARN, ...t)
        }
        error(...t) {
            this._userLogHandler && this._userLogHandler(this, d.ERROR, ...t), this._logHandler(this, d.ERROR, ...t)
        }
    };
var Kt = (e, t) => t.some(n => e instanceof n),
    Pe, Le;

function qt() {
    return Pe || (Pe = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])
}

function Gt() {
    return Le || (Le = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])
}
var Fe = new WeakMap,
    te = new WeakMap,
    $e = new WeakMap,
    ee = new WeakMap,
    re = new WeakMap;

function Jt(e) {
    let t = new Promise((n, r) => {
        let i = () => {
                e.removeEventListener("success", o), e.removeEventListener("error", s)
            },
            o = () => {
                n(m(e.result)), i()
            },
            s = () => {
                r(e.error), i()
            };
        e.addEventListener("success", o), e.addEventListener("error", s)
    });
    return t.then(n => {
        n instanceof IDBCursor && Fe.set(n, e)
    }).catch(() => {}), re.set(t, e), t
}

function Yt(e) {
    if (te.has(e)) return;
    let t = new Promise((n, r) => {
        let i = () => {
                e.removeEventListener("complete", o), e.removeEventListener("error", s), e.removeEventListener("abort", s)
            },
            o = () => {
                n(), i()
            },
            s = () => {
                r(e.error || new DOMException("AbortError", "AbortError")), i()
            };
        e.addEventListener("complete", o), e.addEventListener("error", s), e.addEventListener("abort", s)
    });
    te.set(e, t)
}
var ne = {
    get(e, t, n) {
        if (e instanceof IDBTransaction) {
            if (t === "done") return te.get(e);
            if (t === "objectStoreNames") return e.objectStoreNames || $e.get(e);
            if (t === "store") return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0])
        }
        return m(e[t])
    },
    set(e, t, n) {
        return e[t] = n, !0
    },
    has(e, t) {
        return e instanceof IDBTransaction && (t === "done" || t === "store") ? !0 : t in e
    }
};

function He(e) {
    ne = e(ne)
}

function Xt(e) {
    return e === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype) ? function(t, ...n) {
        let r = e.call(U(this), t, ...n);
        return $e.set(r, t.sort ? t.sort() : [t]), m(r)
    } : Gt().includes(e) ? function(...t) {
        return e.apply(U(this), t), m(Fe.get(this))
    } : function(...t) {
        return m(e.apply(U(this), t))
    }
}

function Qt(e) {
    return typeof e == "function" ? Xt(e) : (e instanceof IDBTransaction && Yt(e), Kt(e, qt()) ? new Proxy(e, ne) : e)
}

function m(e) {
    if (e instanceof IDBRequest) return Jt(e);
    if (ee.has(e)) return ee.get(e);
    let t = Qt(e);
    return t !== e && (ee.set(e, t), re.set(t, e)), t
}
var U = e => re.get(e);

function C(e, t, {
    blocked: n,
    upgrade: r,
    blocking: i,
    terminated: o
} = {}) {
    let s = indexedDB.open(e, t),
        u = m(s);
    return r && s.addEventListener("upgradeneeded", f => {
        r(m(s.result), f.oldVersion, f.newVersion, m(s.transaction), f)
    }), n && s.addEventListener("blocked", f => n(f.oldVersion, f.newVersion, f)), u.then(f => {
        o && f.addEventListener("close", () => o()), i && f.addEventListener("versionchange", c => i(c.oldVersion, c.newVersion, c))
    }).catch(() => {}), u
}

function W(e, {
    blocked: t
} = {}) {
    let n = indexedDB.deleteDatabase(e);
    return t && n.addEventListener("blocked", r => t(r.oldVersion, r)), m(n).then(() => {})
}
var Zt = ["get", "getKey", "getAll", "getAllKeys", "count"],
    en = ["put", "add", "delete", "clear"],
    ie = new Map;

function je(e, t) {
    if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
    if (ie.get(t)) return ie.get(t);
    let n = t.replace(/FromIndex$/, ""),
        r = t !== n,
        i = en.includes(n);
    if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(i || Zt.includes(n))) return;
    let o = function(s, ...u) {
        return a(this, null, function*() {
            let f = this.transaction(s, i ? "readwrite" : "readonly"),
                c = f.store;
            return r && (c = c.index(u.shift())), (yield Promise.all([c[n](...u), i && f.done]))[0]
        })
    };
    return ie.set(t, o), o
}
He(e => w(p({}, e), {
    get: (t, n, r) => je(t, n) || e.get(t, n, r),
    has: (t, n) => !!je(t, n) || e.has(t, n)
}));
var se = class {
    constructor(t) {
        this.container = t
    }
    getPlatformInfoString() {
        return this.container.getProviders().map(n => {
            if (tn(n)) {
                let r = n.getImmediate();
                return `${r.library}/${r.version}`
            } else return null
        }).filter(n => n).join(" ")
    }
};

function tn(e) {
    return e.getComponent() ? .type === "VERSION"
}
var ae = "@firebase/app",
    Ve = "0.14.12";
var I = new V("@firebase/app"),
    nn = "@firebase/app-compat",
    rn = "@firebase/analytics-compat",
    on = "@firebase/analytics",
    sn = "@firebase/app-check-compat",
    an = "@firebase/app-check",
    cn = "@firebase/auth",
    un = "@firebase/auth-compat",
    fn = "@firebase/database",
    dn = "@firebase/data-connect",
    ln = "@firebase/database-compat",
    hn = "@firebase/functions",
    pn = "@firebase/functions-compat",
    gn = "@firebase/installations",
    mn = "@firebase/installations-compat",
    bn = "@firebase/messaging",
    wn = "@firebase/messaging-compat",
    yn = "@firebase/performance",
    _n = "@firebase/performance-compat",
    En = "@firebase/remote-config",
    In = "@firebase/remote-config-compat",
    Sn = "@firebase/storage",
    vn = "@firebase/storage-compat",
    An = "@firebase/firestore",
    Tn = "@firebase/ai",
    Cn = "@firebase/firestore-compat",
    Dn = "firebase";
var ce = "[DEFAULT]",
    kn = {
        [ae]: "fire-core",
        [nn]: "fire-core-compat",
        [on]: "fire-analytics",
        [rn]: "fire-analytics-compat",
        [an]: "fire-app-check",
        [sn]: "fire-app-check-compat",
        [cn]: "fire-auth",
        [un]: "fire-auth-compat",
        [fn]: "fire-rtdb",
        [dn]: "fire-data-connect",
        [ln]: "fire-rtdb-compat",
        [hn]: "fire-fn",
        [pn]: "fire-fn-compat",
        [gn]: "fire-iid",
        [mn]: "fire-iid-compat",
        [bn]: "fire-fcm",
        [wn]: "fire-fcm-compat",
        [yn]: "fire-perf",
        [_n]: "fire-perf-compat",
        [En]: "fire-rc",
        [In]: "fire-rc-compat",
        [Sn]: "fire-gcs",
        [vn]: "fire-gcs-compat",
        [An]: "fire-fst",
        [Cn]: "fire-fst-compat",
        [Tn]: "fire-vertex",
        "fire-js": "fire-js",
        [Dn]: "fire-js-all"
    };
var z = new Map,
    On = new Map,
    ue = new Map;

function Ue(e, t) {
    try {
        e.container.addComponent(t)
    } catch (n) {
        I.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`, n)
    }
}

function S(e) {
    let t = e.name;
    if (ue.has(t)) return I.debug(`There were multiple attempts to register component ${t}.`), !1;
    ue.set(t, e);
    for (let n of z.values()) Ue(n, e);
    for (let n of On.values()) Ue(n, e);
    return !0
}

function B(e, t) {
    let n = e.container.getProvider("heartbeat").getImmediate({
        optional: !0
    });
    return n && n.triggerHeartbeat(), e.container.getProvider(t)
}
var Nn = {
        "no-app": "No Firebase App '{$appName}' has been created - call initializeApp() first",
        "bad-app-name": "Illegal App name: '{$appName}'",
        "duplicate-app": "Firebase App named '{$appName}' already exists with different options or config",
        "app-deleted": "Firebase App named '{$appName}' already deleted",
        "server-app-deleted": "Firebase Server App has been deleted",
        "no-options": "Need to provide options, when not being deployed to hosting via source.",
        "invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
        "invalid-log-argument": "First argument to `onLog` must be null or a function.",
        "idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
        "idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
        "idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
        "idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
        "finalization-registry-not-supported": "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
        "invalid-server-app-environment": "FirebaseServerApp is not for use in browser environments."
    },
    A = new _("app", "Firebase", Nn);
var fe = class {
    constructor(t, n, r) {
        this._isDeleted = !1, this._options = p({}, t), this._config = p({}, n), this._name = n.name, this._automaticDataCollectionEnabled = n.automaticDataCollectionEnabled, this._container = r, this.container.addComponent(new g("app", () => this, "PUBLIC"))
    }
    get automaticDataCollectionEnabled() {
        return this.checkDestroyed(), this._automaticDataCollectionEnabled
    }
    set automaticDataCollectionEnabled(t) {
        this.checkDestroyed(), this._automaticDataCollectionEnabled = t
    }
    get name() {
        return this.checkDestroyed(), this._name
    }
    get options() {
        return this.checkDestroyed(), this._options
    }
    get config() {
        return this.checkDestroyed(), this._config
    }
    get container() {
        return this._container
    }
    get isDeleted() {
        return this._isDeleted
    }
    set isDeleted(t) {
        this._isDeleted = t
    }
    checkDestroyed() {
        if (this.isDeleted) throw A.create("app-deleted", {
            appName: this._name
        })
    }
};

function Rn(e, t = {}) {
    let n = e;
    typeof t != "object" && (t = {
        name: t
    });
    let r = p({
            name: ce,
            automaticDataCollectionEnabled: !0
        }, t),
        i = r.name;
    if (typeof i != "string" || !i) throw A.create("bad-app-name", {
        appName: String(i)
    });
    if (n || (n = Q()), !n) throw A.create("no-options");
    let o = z.get(i);
    if (o) {
        if (H(n, o.options) && H(r, o.config)) return o;
        throw A.create("duplicate-app", {
            appName: i
        })
    }
    let s = new j(i);
    for (let f of ue.values()) s.addComponent(f);
    let u = new fe(n, r, s);
    return z.set(i, u), u
}

function he(e = ce) {
    let t = z.get(e);
    if (!t && e === ce && Q()) return Rn();
    if (!t) throw A.create("no-app", {
        appName: e
    });
    return t
}

function E(e, t, n) {
    let r = kn[e] ? ? e;
    n && (r += `-${n}`);
    let i = r.match(/\s|\//),
        o = t.match(/\s|\//);
    if (i || o) {
        let s = [`Unable to register library "${r}" with version "${t}":`];
        i && s.push(`library name "${r}" contains illegal characters (whitespace or "/")`), i && o && s.push("and"), o && s.push(`version name "${t}" contains illegal characters (whitespace or "/")`), I.warn(s.join(" "));
        return
    }
    S(new g(`${r}-version`, () => ({
        library: r,
        version: t
    }), "VERSION"))
}
var xn = "firebase-heartbeat-database",
    Mn = 1,
    M = "firebase-heartbeat-store",
    oe = null;

function qe() {
    return oe || (oe = C(xn, Mn, {
        upgrade: (e, t) => {
            switch (t) {
                case 0:
                    try {
                        e.createObjectStore(M)
                    } catch (n) {
                        console.warn(n)
                    }
            }
        }
    }).catch(e => {
        throw A.create("idb-open", {
            originalErrorMessage: e.message
        })
    })), oe
}

function Bn(e) {
    return a(this, null, function*() {
        try {
            let n = (yield qe()).transaction(M),
                r = yield n.objectStore(M).get(Ge(e));
            return yield n.done, r
        } catch (t) {
            if (t instanceof y) I.warn(t.message);
            else {
                let n = A.create("idb-get", {
                    originalErrorMessage: t ? .message
                });
                I.warn(n.message)
            }
        }
    })
}

function We(e, t) {
    return a(this, null, function*() {
        try {
            let r = (yield qe()).transaction(M, "readwrite");
            yield r.objectStore(M).put(t, Ge(e)), yield r.done
        } catch (n) {
            if (n instanceof y) I.warn(n.message);
            else {
                let r = A.create("idb-set", {
                    originalErrorMessage: n ? .message
                });
                I.warn(r.message)
            }
        }
    })
}

function Ge(e) {
    return `${e.name}!${e.options.appId}`
}
var Pn = 1024,
    Ln = 30,
    de = class {
        constructor(t) {
            this.container = t, this._heartbeatsCache = null;
            let n = this.container.getProvider("app").getImmediate();
            this._storage = new le(n), this._heartbeatsCachePromise = this._storage.read().then(r => (this._heartbeatsCache = r, r))
        }
        triggerHeartbeat() {
            return a(this, null, function*() {
                try {
                    let n = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),
                        r = ze();
                    if (this._heartbeatsCache ? .heartbeats == null && (this._heartbeatsCache = yield this._heartbeatsCachePromise, this._heartbeatsCache ? .heartbeats == null) || this._heartbeatsCache.lastSentHeartbeatDate === r || this._heartbeatsCache.heartbeats.some(i => i.date === r)) return;
                    if (this._heartbeatsCache.heartbeats.push({
                            date: r,
                            agent: n
                        }), this._heartbeatsCache.heartbeats.length > Ln) {
                        let i = $n(this._heartbeatsCache.heartbeats);
                        this._heartbeatsCache.heartbeats.splice(i, 1)
                    }
                    return this._storage.overwrite(this._heartbeatsCache)
                } catch (t) {
                    I.warn(t)
                }
            })
        }
        getHeartbeatsHeader() {
            return a(this, null, function*() {
                try {
                    if (this._heartbeatsCache === null && (yield this._heartbeatsCachePromise), this._heartbeatsCache ? .heartbeats == null || this._heartbeatsCache.heartbeats.length === 0) return "";
                    let t = ze(),
                        {
                            heartbeatsToSend: n,
                            unsentEntries: r
                        } = Fn(this._heartbeatsCache.heartbeats),
                        i = X(JSON.stringify({
                            version: 2,
                            heartbeats: n
                        }));
                    return this._heartbeatsCache.lastSentHeartbeatDate = t, r.length > 0 ? (this._heartbeatsCache.heartbeats = r, yield this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), i
                } catch (t) {
                    return I.warn(t), ""
                }
            })
        }
    };

function ze() {
    return new Date().toISOString().substring(0, 10)
}

function Fn(e, t = Pn) {
    let n = [],
        r = e.slice();
    for (let i of e) {
        let o = n.find(s => s.agent === i.agent);
        if (o) {
            if (o.dates.push(i.date), Ke(n) > t) {
                o.dates.pop();
                break
            }
        } else if (n.push({
                agent: i.agent,
                dates: [i.date]
            }), Ke(n) > t) {
            n.pop();
            break
        }
        r = r.slice(1)
    }
    return {
        heartbeatsToSend: n,
        unsentEntries: r
    }
}
var le = class {
    constructor(t) {
        this.app = t, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck()
    }
    runIndexedDBEnvironmentCheck() {
        return a(this, null, function*() {
            return F() ? $().then(() => !0).catch(() => !1) : !1
        })
    }
    read() {
        return a(this, null, function*() {
            if (yield this._canUseIndexedDBPromise) {
                let n = yield Bn(this.app);
                return n ? .heartbeats ? n : {
                    heartbeats: []
                }
            } else return {
                heartbeats: []
            }
        })
    }
    overwrite(t) {
        return a(this, null, function*() {
            if (yield this._canUseIndexedDBPromise) {
                let r = yield this.read();
                return We(this.app, {
                    lastSentHeartbeatDate: t.lastSentHeartbeatDate ? ? r.lastSentHeartbeatDate,
                    heartbeats: t.heartbeats
                })
            } else return
        })
    }
    add(t) {
        return a(this, null, function*() {
            if (yield this._canUseIndexedDBPromise) {
                let r = yield this.read();
                return We(this.app, {
                    lastSentHeartbeatDate: t.lastSentHeartbeatDate ? ? r.lastSentHeartbeatDate,
                    heartbeats: [...r.heartbeats, ...t.heartbeats]
                })
            } else return
        })
    }
};

function Ke(e) {
    return X(JSON.stringify({
        version: 2,
        heartbeats: e
    })).length
}

function $n(e) {
    if (e.length === 0) return -1;
    let t = 0,
        n = e[0].date;
    for (let r = 1; r < e.length; r++) e[r].date < n && (n = e[r].date, t = r);
    return t
}

function Hn(e) {
    S(new g("platform-logger", t => new se(t), "PRIVATE")), S(new g("heartbeat", t => new de(t), "PRIVATE")), E(ae, Ve, e), E(ae, Ve, "esm2020"), E("fire-js", "")
}
Hn("");
var Xe = "@firebase/installations",
    be = "0.6.22";
var Qe = 1e4,
    Ze = `w:${be}`,
    et = "FIS_v2",
    jn = "https://firebaseinstallations.googleapis.com/v1",
    Vn = 3600 * 1e3,
    Un = "installations",
    Wn = "Installations";
var zn = {
        "missing-app-config-values": 'Missing App configuration value: "{$valueName}"',
        "not-registered": "Firebase Installation is not registered.",
        "installation-not-found": "Firebase Installation not found.",
        "request-failed": '{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',
        "app-offline": "Could not process request. Application offline.",
        "delete-pending-registration": "Can't delete installation while there is a pending registration request."
    },
    k = new _(Un, Wn, zn);

function tt(e) {
    return e instanceof y && e.code.includes("request-failed")
}

function nt({
    projectId: e
}) {
    return `${jn}/projects/${e}/installations`
}

function rt(e) {
    return {
        token: e.token,
        requestStatus: 2,
        expiresIn: qn(e.expiresIn),
        creationTime: Date.now()
    }
}

function it(e, t) {
    return a(this, null, function*() {
        let r = (yield t.json()).error;
        return k.create("request-failed", {
            requestName: e,
            serverCode: r.code,
            serverMessage: r.message,
            serverStatus: r.status
        })
    })
}

function ot({
    apiKey: e
}) {
    return new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-goog-api-key": e
    })
}

function Kn(e, {
    refreshToken: t
}) {
    let n = ot(e);
    return n.append("Authorization", Gn(t)), n
}

function st(e) {
    return a(this, null, function*() {
        let t = yield e();
        return t.status >= 500 && t.status < 600 ? e() : t
    })
}

function qn(e) {
    return Number(e.replace("s", "000"))
}

function Gn(e) {
    return `${et} ${e}`
}

function Jn(r, i) {
    return a(this, arguments, function*({
        appConfig: e,
        heartbeatServiceProvider: t
    }, {
        fid: n
    }) {
        let o = nt(e),
            s = ot(e),
            u = t.getImmediate({
                optional: !0
            });
        if (u) {
            let l = yield u.getHeartbeatsHeader();
            l && s.append("x-firebase-client", l)
        }
        let f = {
                fid: n,
                authVersion: et,
                appId: e.appId,
                sdkVersion: Ze
            },
            c = {
                method: "POST",
                headers: s,
                body: JSON.stringify(f)
            },
            b = yield st(() => fetch(o, c));
        if (b.ok) {
            let l = yield b.json();
            return {
                fid: l.fid || n,
                registrationStatus: 2,
                refreshToken: l.refreshToken,
                authToken: rt(l.authToken)
            }
        } else throw yield it("Create Installation", b)
    })
}

function at(e) {
    return new Promise(t => {
        setTimeout(t, e)
    })
}

function Yn(e) {
    return btoa(String.fromCharCode(...e)).replace(/\+/g, "-").replace(/\//g, "_")
}
var Xn = /^[cdef][\w-]{21}$/,
    me = "";

function Qn() {
    try {
        let e = new Uint8Array(17);
        (self.crypto || self.msCrypto).getRandomValues(e), e[0] = 112 + e[0] % 16;
        let n = Zn(e);
        return Xn.test(n) ? n : me
    } catch (e) {
        return me
    }
}

function Zn(e) {
    return Yn(e).substr(0, 22)
}

function q(e) {
    return `${e.appName}!${e.appId}`
}
var ct = new Map;

function ut(e, t) {
    let n = q(e);
    ft(n, t), er(n, t)
}

function ft(e, t) {
    let n = ct.get(e);
    if (n)
        for (let r of n) r(t)
}

function er(e, t) {
    let n = tr();
    n && n.postMessage({
        key: e,
        fid: t
    }), nr()
}
var D = null;

function tr() {
    return !D && "BroadcastChannel" in self && (D = new BroadcastChannel("[Firebase] FID Change"), D.onmessage = e => {
        ft(e.data.key, e.data.fid)
    }), D
}

function nr() {
    ct.size === 0 && D && (D.close(), D = null)
}
var rr = "firebase-installations-database",
    ir = 1,
    O = "firebase-installations-store",
    pe = null;

function we() {
    return pe || (pe = C(rr, ir, {
        upgrade: (e, t) => {
            t === 0 && e.createObjectStore(O)
        }
    })), pe
}

function K(e, t) {
    return a(this, null, function*() {
        let n = q(e),
            i = (yield we()).transaction(O, "readwrite"),
            o = i.objectStore(O),
            s = yield o.get(n);
        return yield o.put(t, n), yield i.done, (!s || s.fid !== t.fid) && ut(e, t.fid), t
    })
}

function dt(e) {
    return a(this, null, function*() {
        let t = q(e),
            r = (yield we()).transaction(O, "readwrite");
        yield r.objectStore(O).delete(t), yield r.done
    })
}

function G(e, t) {
    return a(this, null, function*() {
        let n = q(e),
            i = (yield we()).transaction(O, "readwrite"),
            o = i.objectStore(O),
            s = yield o.get(n), u = t(s);
        return u === void 0 ? yield o.delete(n): yield o.put(u, n), yield i.done, u && (!s || s.fid !== u.fid) && ut(e, u.fid), u
    })
}

function ye(e) {
    return a(this, null, function*() {
        let t, n = yield G(e.appConfig, r => {
            let i = or(r),
                o = sr(e, i);
            return t = o.registrationPromise, o.installationEntry
        });
        return n.fid === me ? {
            installationEntry: yield t
        } : {
            installationEntry: n,
            registrationPromise: t
        }
    })
}

function or(e) {
    let t = e || {
        fid: Qn(),
        registrationStatus: 0
    };
    return lt(t)
}

function sr(e, t) {
    if (t.registrationStatus === 0) {
        if (!navigator.onLine) {
            let i = Promise.reject(k.create("app-offline"));
            return {
                installationEntry: t,
                registrationPromise: i
            }
        }
        let n = {
                fid: t.fid,
                registrationStatus: 1,
                registrationTime: Date.now()
            },
            r = ar(e, n);
        return {
            installationEntry: n,
            registrationPromise: r
        }
    } else return t.registrationStatus === 1 ? {
        installationEntry: t,
        registrationPromise: cr(e)
    } : {
        installationEntry: t
    }
}

function ar(e, t) {
    return a(this, null, function*() {
        try {
            let n = yield Jn(e, t);
            return K(e.appConfig, n)
        } catch (n) {
            throw tt(n) && n.customData.serverCode === 409 ? yield dt(e.appConfig): yield K(e.appConfig, {
                fid: t.fid,
                registrationStatus: 0
            }), n
        }
    })
}

function cr(e) {
    return a(this, null, function*() {
        let t = yield Je(e.appConfig);
        for (; t.registrationStatus === 1;) yield at(100), t = yield Je(e.appConfig);
        if (t.registrationStatus === 0) {
            let {
                installationEntry: n,
                registrationPromise: r
            } = yield ye(e);
            return r || n
        }
        return t
    })
}

function Je(e) {
    return G(e, t => {
        if (!t) throw k.create("installation-not-found");
        return lt(t)
    })
}

function lt(e) {
    return ur(e) ? {
        fid: e.fid,
        registrationStatus: 0
    } : e
}

function ur(e) {
    return e.registrationStatus === 1 && e.registrationTime + Qe < Date.now()
}

function fr(r, i) {
    return a(this, arguments, function*({
        appConfig: e,
        heartbeatServiceProvider: t
    }, n) {
        let o = dr(e, n),
            s = Kn(e, n),
            u = t.getImmediate({
                optional: !0
            });
        if (u) {
            let l = yield u.getHeartbeatsHeader();
            l && s.append("x-firebase-client", l)
        }
        let f = {
                installation: {
                    sdkVersion: Ze,
                    appId: e.appId
                }
            },
            c = {
                method: "POST",
                headers: s,
                body: JSON.stringify(f)
            },
            b = yield st(() => fetch(o, c));
        if (b.ok) {
            let l = yield b.json();
            return rt(l)
        } else throw yield it("Generate Auth Token", b)
    })
}

function dr(e, {
    fid: t
}) {
    return `${nt(e)}/${t}/authTokens:generate`
}

function _e(e, t = !1) {
    return a(this, null, function*() {
        let n, r = yield G(e.appConfig, o => {
            if (!ht(o)) throw k.create("not-registered");
            let s = o.authToken;
            if (!t && pr(s)) return o;
            if (s.requestStatus === 1) return n = lr(e, t), o; {
                if (!navigator.onLine) throw k.create("app-offline");
                let u = mr(o);
                return n = hr(e, u), u
            }
        });
        return n ? yield n: r.authToken
    })
}

function lr(e, t) {
    return a(this, null, function*() {
        let n = yield Ye(e.appConfig);
        for (; n.authToken.requestStatus === 1;) yield at(100), n = yield Ye(e.appConfig);
        let r = n.authToken;
        return r.requestStatus === 0 ? _e(e, t) : r
    })
}

function Ye(e) {
    return G(e, t => {
        if (!ht(t)) throw k.create("not-registered");
        let n = t.authToken;
        return br(n) ? w(p({}, t), {
            authToken: {
                requestStatus: 0
            }
        }) : t
    })
}

function hr(e, t) {
    return a(this, null, function*() {
        try {
            let n = yield fr(e, t), r = w(p({}, t), {
                authToken: n
            });
            return yield K(e.appConfig, r), n
        } catch (n) {
            if (tt(n) && (n.customData.serverCode === 401 || n.customData.serverCode === 404)) yield dt(e.appConfig);
            else {
                let r = w(p({}, t), {
                    authToken: {
                        requestStatus: 0
                    }
                });
                yield K(e.appConfig, r)
            }
            throw n
        }
    })
}

function ht(e) {
    return e !== void 0 && e.registrationStatus === 2
}

function pr(e) {
    return e.requestStatus === 2 && !gr(e)
}

function gr(e) {
    let t = Date.now();
    return t < e.creationTime || e.creationTime + e.expiresIn < t + Vn
}

function mr(e) {
    let t = {
        requestStatus: 1,
        requestTime: Date.now()
    };
    return w(p({}, e), {
        authToken: t
    })
}

function br(e) {
    return e.requestStatus === 1 && e.requestTime + Qe < Date.now()
}

function wr(e) {
    return a(this, null, function*() {
        let t = e,
            {
                installationEntry: n,
                registrationPromise: r
            } = yield ye(t);
        return r ? r.catch(console.error) : _e(t).catch(console.error), n.fid
    })
}

function yr(e, t = !1) {
    return a(this, null, function*() {
        let n = e;
        return yield _r(n), (yield _e(n, t)).token
    })
}

function _r(e) {
    return a(this, null, function*() {
        let {
            registrationPromise: t
        } = yield ye(e);
        t && (yield t)
    })
}

function Er(e) {
    if (!e || !e.options) throw ge("App Configuration");
    if (!e.name) throw ge("App Name");
    let t = ["projectId", "apiKey", "appId"];
    for (let n of t)
        if (!e.options[n]) throw ge(n);
    return {
        appName: e.name,
        projectId: e.options.projectId,
        apiKey: e.options.apiKey,
        appId: e.options.appId
    }
}

function ge(e) {
    return k.create("missing-app-config-values", {
        valueName: e
    })
}
var pt = "installations",
    Ir = "installations-internal",
    Sr = e => {
        let t = e.getProvider("app").getImmediate(),
            n = Er(t),
            r = B(t, "heartbeat");
        return {
            app: t,
            appConfig: n,
            heartbeatServiceProvider: r,
            _delete: () => Promise.resolve()
        }
    },
    vr = e => {
        let t = e.getProvider("app").getImmediate(),
            n = B(t, pt).getImmediate();
        return {
            getId: () => wr(n),
            getToken: i => yr(n, i)
        }
    };

function Ar() {
    S(new g(pt, Sr, "PUBLIC")), S(new g(Ir, vr, "PRIVATE"))
}
Ar();
E(Xe, be);
E(Xe, be, "esm2020");
var Tr = "/firebase-messaging-sw.js",
    Cr = "/firebase-cloud-messaging-push-scope",
    Et = "BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",
    Dr = "https://fcmregistrations.googleapis.com/v1",
    It = "google.c.a.c_id",
    kr = "google.c.a.c_l",
    Or = "google.c.a.ts",
    Nr = "google.c.a.e",
    gt = 1e4;
var J = (function(e) {
    return e.PUSH_RECEIVED = "push-received", e.NOTIFICATION_CLICKED = "notification-clicked", e
})(J || {});

function v(e) {
    let t = new Uint8Array(e);
    return btoa(String.fromCharCode(...t)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")
}

function Rr(e) {
    let t = "=".repeat((4 - e.length % 4) % 4),
        n = (e + t).replace(/\-/g, "+").replace(/_/g, "/"),
        r = atob(n),
        i = new Uint8Array(r.length);
    for (let o = 0; o < r.length; ++o) i[o] = r.charCodeAt(o);
    return i
}
var Ee = "fcm_token_details_db",
    xr = 5,
    mt = "fcm_token_object_Store";

function Mr(e) {
    return a(this, null, function*() {
        if ("databases" in indexedDB && !(yield indexedDB.databases()).map(o => o.name).includes(Ee)) return null;
        let t = null;
        return (yield C(Ee, xr, {
            upgrade: (r, i, o, s) => a(null, null, function*() {
                if (i < 2 || !r.objectStoreNames.contains(mt)) return;
                let u = s.objectStore(mt),
                    f = yield u.index("fcmSenderId").get(e);
                if (yield u.clear(), !!f) {
                    if (i === 2) {
                        let c = f;
                        if (!c.auth || !c.p256dh || !c.endpoint) return;
                        t = {
                            token: c.fcmToken,
                            createTime: c.createTime ? ? Date.now(),
                            subscriptionOptions: {
                                auth: c.auth,
                                p256dh: c.p256dh,
                                endpoint: c.endpoint,
                                swScope: c.swScope,
                                vapidKey: typeof c.vapidKey == "string" ? c.vapidKey : v(c.vapidKey)
                            }
                        }
                    } else if (i === 3) {
                        let c = f;
                        t = {
                            token: c.fcmToken,
                            createTime: c.createTime,
                            subscriptionOptions: {
                                auth: v(c.auth),
                                p256dh: v(c.p256dh),
                                endpoint: c.endpoint,
                                swScope: c.swScope,
                                vapidKey: v(c.vapidKey)
                            }
                        }
                    } else if (i === 4) {
                        let c = f;
                        t = {
                            token: c.fcmToken,
                            createTime: c.createTime,
                            subscriptionOptions: {
                                auth: v(c.auth),
                                p256dh: v(c.p256dh),
                                endpoint: c.endpoint,
                                swScope: c.swScope,
                                vapidKey: v(c.vapidKey)
                            }
                        }
                    }
                }
            })
        })).close(), yield W(Ee), yield W("fcm_vapid_details_db"), yield W("undefined"), Br(t) ? t : null
    })
}

function Br(e) {
    if (!e || !e.subscriptionOptions) return !1;
    let {
        subscriptionOptions: t
    } = e;
    return typeof e.createTime == "number" && e.createTime > 0 && typeof e.token == "string" && e.token.length > 0 && typeof t.auth == "string" && t.auth.length > 0 && typeof t.p256dh == "string" && t.p256dh.length > 0 && typeof t.endpoint == "string" && t.endpoint.length > 0 && typeof t.swScope == "string" && t.swScope.length > 0 && typeof t.vapidKey == "string" && t.vapidKey.length > 0
}
var Pr = "firebase-messaging-database",
    Lr = 1,
    N = "firebase-messaging-store",
    Ie = null;

function Ae() {
    return Ie || (Ie = C(Pr, Lr, {
        upgrade: (e, t) => {
            t === 0 && e.createObjectStore(N)
        }
    })), Ie
}

function St(e) {
    return a(this, null, function*() {
        let t = Ce(e),
            r = yield(yield Ae()).transaction(N).objectStore(N).get(t);
        if (r) return r; {
            let i = yield Mr(e.appConfig.senderId);
            if (i) return yield Te(e, i), i
        }
    })
}

function Te(e, t) {
    return a(this, null, function*() {
        let n = Ce(e),
            i = (yield Ae()).transaction(N, "readwrite");
        return yield i.objectStore(N).put(t, n), yield i.done, t
    })
}

function Fr(e) {
    return a(this, null, function*() {
        let t = Ce(e),
            r = (yield Ae()).transaction(N, "readwrite");
        yield r.objectStore(N).delete(t), yield r.done
    })
}

function Ce({
    appConfig: e
}) {
    return e.appId
}
var $r = {
        "missing-app-config-values": 'Missing App configuration value: "{$valueName}"',
        "only-available-in-window": "This method is available in a Window context.",
        "only-available-in-sw": "This method is available in a service worker context.",
        "permission-default": "The notification permission was not granted and dismissed instead.",
        "permission-blocked": "The notification permission was not granted and blocked instead.",
        "unsupported-browser": "This browser doesn't support the API's required to use the Firebase SDK.",
        "indexed-db-unsupported": "This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)",
        "failed-service-worker-registration": "We are unable to register the default service worker. {$browserErrorMessage}",
        "token-subscribe-failed": "A problem occurred while subscribing the user to FCM: {$errorInfo}",
        "token-subscribe-no-token": "FCM returned no token when subscribing the user to push.",
        "token-unsubscribe-failed": "A problem occurred while unsubscribing the user from FCM: {$errorInfo}",
        "token-update-failed": "A problem occurred while updating the user from FCM: {$errorInfo}",
        "token-update-no-token": "FCM returned no token when updating the user to push.",
        "use-sw-after-get-token": "The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.",
        "invalid-sw-registration": "The input to useServiceWorker() must be a ServiceWorkerRegistration.",
        "invalid-bg-handler": "The input to setBackgroundMessageHandler() must be a function.",
        "invalid-vapid-key": "The public VAPID key must be a string.",
        "use-vapid-key-after-get-token": "The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used."
    },
    h = new _("messaging", "Messaging", $r);

function Hr(e, t) {
    return a(this, null, function*() {
        let n = yield ke(e), r = At(t), i = {
            method: "POST",
            headers: n,
            body: JSON.stringify(r)
        }, o;
        try {
            o = yield(yield fetch(De(e.appConfig), i)).json()
        } catch (s) {
            throw h.create("token-subscribe-failed", {
                errorInfo: s ? .toString()
            })
        }
        if (o.error) {
            let s = o.error.message;
            throw h.create("token-subscribe-failed", {
                errorInfo: s
            })
        }
        if (!o.token) throw h.create("token-subscribe-no-token");
        return o.token
    })
}

function jr(e, t) {
    return a(this, null, function*() {
        let n = yield ke(e), r = At(t.subscriptionOptions), i = {
            method: "PATCH",
            headers: n,
            body: JSON.stringify(r)
        }, o;
        try {
            o = yield(yield fetch(`${De(e.appConfig)}/${t.token}`, i)).json()
        } catch (s) {
            throw h.create("token-update-failed", {
                errorInfo: s ? .toString()
            })
        }
        if (o.error) {
            let s = o.error.message;
            throw h.create("token-update-failed", {
                errorInfo: s
            })
        }
        if (!o.token) throw h.create("token-update-no-token");
        return o.token
    })
}

function vt(e, t) {
    return a(this, null, function*() {
        let r = {
            method: "DELETE",
            headers: yield ke(e)
        };
        try {
            let o = yield(yield fetch(`${De(e.appConfig)}/${t}`, r)).json();
            if (o.error) {
                let s = o.error.message;
                throw h.create("token-unsubscribe-failed", {
                    errorInfo: s
                })
            }
        } catch (i) {
            throw h.create("token-unsubscribe-failed", {
                errorInfo: i ? .toString()
            })
        }
    })
}

function De({
    projectId: e
}) {
    return `${Dr}/projects/${e}/registrations`
}

function ke(n) {
    return a(this, arguments, function*({
        appConfig: e,
        installations: t
    }) {
        let r = yield t.getToken();
        return new Headers({
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-goog-api-key": e.apiKey,
            "x-goog-firebase-installations-auth": `FIS ${r}`
        })
    })
}

function At({
    p256dh: e,
    auth: t,
    endpoint: n,
    vapidKey: r
}) {
    let i = {
        web: {
            endpoint: n,
            auth: t,
            p256dh: e
        }
    };
    return r !== Et && (i.web.applicationPubKey = r), i
}
var Vr = 10080 * 60 * 1e3;

function Ur(e) {
    return a(this, null, function*() {
        let t = yield Kr(e.swRegistration, e.vapidKey), n = {
            vapidKey: e.vapidKey,
            swScope: e.swRegistration.scope,
            endpoint: t.endpoint,
            auth: v(t.getKey("auth")),
            p256dh: v(t.getKey("p256dh"))
        }, r = yield St(e.firebaseDependencies);
        if (r) {
            if (qr(r.subscriptionOptions, n)) return Date.now() >= r.createTime + Vr ? zr(e, {
                token: r.token,
                createTime: Date.now(),
                subscriptionOptions: n
            }) : r.token;
            try {
                yield vt(e.firebaseDependencies, r.token)
            } catch (i) {
                console.warn(i)
            }
            return bt(e.firebaseDependencies, n)
        } else return bt(e.firebaseDependencies, n)
    })
}

function Wr(e) {
    return a(this, null, function*() {
        let t = yield St(e.firebaseDependencies);
        t && (yield vt(e.firebaseDependencies, t.token), yield Fr(e.firebaseDependencies));
        let n = yield e.swRegistration.pushManager.getSubscription();
        return n ? n.unsubscribe() : !0
    })
}

function zr(e, t) {
    return a(this, null, function*() {
        try {
            let n = yield jr(e.firebaseDependencies, t), r = w(p({}, t), {
                token: n,
                createTime: Date.now()
            });
            return yield Te(e.firebaseDependencies, r), n
        } catch (n) {
            throw n
        }
    })
}

function bt(e, t) {
    return a(this, null, function*() {
        let r = {
            token: yield Hr(e, t), createTime: Date.now(), subscriptionOptions: t
        };
        return yield Te(e, r), r.token
    })
}

function Kr(e, t) {
    return a(this, null, function*() {
        let n = yield e.pushManager.getSubscription();
        return n || e.pushManager.subscribe({
            userVisibleOnly: !0,
            applicationServerKey: Rr(t)
        })
    })
}

function qr(e, t) {
    let n = t.vapidKey === e.vapidKey,
        r = t.endpoint === e.endpoint,
        i = t.auth === e.auth,
        o = t.p256dh === e.p256dh;
    return n && r && i && o
}

function wt(e) {
    let t = {
        from: e.from,
        collapseKey: e.collapse_key,
        messageId: e.fcmMessageId
    };
    return Gr(t, e), Jr(t, e), Yr(t, e), t
}

function Gr(e, t) {
    if (!t.notification) return;
    e.notification = {};
    let n = t.notification.title;
    n && (e.notification.title = n);
    let r = t.notification.body;
    r && (e.notification.body = r);
    let i = t.notification.image;
    i && (e.notification.image = i);
    let o = t.notification.icon;
    o && (e.notification.icon = o)
}

function Jr(e, t) {
    t.data && (e.data = t.data)
}

function Yr(e, t) {
    if (!t.fcmOptions && !t.notification ? .click_action) return;
    e.fcmOptions = {};
    let n = t.fcmOptions ? .link ? ? t.notification ? .click_action;
    n && (e.fcmOptions.link = n);
    let r = t.fcmOptions ? .analytics_label;
    r && (e.fcmOptions.analyticsLabel = r)
}

function Xr(e) {
    return typeof e == "object" && !!e && It in e
}
Qr("AzSCbw63g1R0nCw85jG8", "Iaya3yLKwmgvh7cF0q4");

function Qr(e, t) {
    let n = [];
    for (let r = 0; r < e.length; r++) n.push(e.charAt(r)), r < t.length && n.push(t.charAt(r));
    return n.join("")
}

function Zr(e) {
    if (!e || !e.options) throw Se("App Configuration Object");
    if (!e.name) throw Se("App Name");
    let t = ["projectId", "apiKey", "appId", "messagingSenderId"],
        {
            options: n
        } = e;
    for (let r of t)
        if (!n[r]) throw Se(r);
    return {
        appName: e.name,
        projectId: n.projectId,
        apiKey: n.apiKey,
        appId: n.appId,
        senderId: n.messagingSenderId
    }
}

function Se(e) {
    return h.create("missing-app-config-values", {
        valueName: e
    })
}
var ve = class {
    constructor(t, n, r) {
        this.deliveryMetricsExportedToBigQueryEnabled = !1, this.onBackgroundMessageHandler = null, this.onMessageHandler = null, this.logEvents = [], this.isLogServiceStarted = !1;
        let i = Zr(t);
        this.firebaseDependencies = {
            app: t,
            appConfig: i,
            installations: n,
            analyticsProvider: r
        }
    }
    _delete() {
        return Promise.resolve()
    }
};

function Tt(e) {
    return a(this, null, function*() {
        try {
            e.swRegistration = yield navigator.serviceWorker.register(Tr, {
                scope: Cr
            }), e.swRegistration.update().catch(() => {}), yield ei(e.swRegistration)
        } catch (t) {
            throw h.create("failed-service-worker-registration", {
                browserErrorMessage: t ? .message
            })
        }
    })
}

function ei(e) {
    return a(this, null, function*() {
        return new Promise((t, n) => {
            let r = setTimeout(() => n(new Error(`Service worker not registered after ${gt} ms`)), gt),
                i = e.installing || e.waiting;
            e.active ? (clearTimeout(r), t()) : i ? i.onstatechange = o => {
                o.target ? .state === "activated" && (i.onstatechange = null, clearTimeout(r), t())
            } : (clearTimeout(r), n(new Error("No incoming service worker found.")))
        })
    })
}

function ti(e, t) {
    return a(this, null, function*() {
        if (!t && !e.swRegistration && (yield Tt(e)), !(!t && e.swRegistration)) {
            if (!(t instanceof ServiceWorkerRegistration)) throw h.create("invalid-sw-registration");
            e.swRegistration = t
        }
    })
}

function ni(e, t) {
    return a(this, null, function*() {
        t ? e.vapidKey = t : e.vapidKey || (e.vapidKey = Et)
    })
}

function Ct(e, t) {
    return a(this, null, function*() {
        if (!navigator) throw h.create("only-available-in-window");
        if (Notification.permission === "default" && (yield Notification.requestPermission()), Notification.permission !== "granted") throw h.create("permission-blocked");
        return yield ni(e, t ? .vapidKey), yield ti(e, t ? .serviceWorkerRegistration), Ur(e)
    })
}

function ri(e, t, n) {
    return a(this, null, function*() {
        let r = ii(t);
        (yield e.firebaseDependencies.analyticsProvider.get()).logEvent(r, {
            message_id: n[It],
            message_name: n[kr],
            message_time: n[Or],
            message_device_time: Math.floor(Date.now() / 1e3)
        })
    })
}

function ii(e) {
    switch (e) {
        case J.NOTIFICATION_CLICKED:
            return "notification_open";
        case J.PUSH_RECEIVED:
            return "notification_foreground";
        default:
            throw new Error
    }
}

function oi(e, t) {
    return a(this, null, function*() {
        let n = t.data;
        if (!n.isFirebaseMessaging) return;
        e.onMessageHandler && n.messageType === J.PUSH_RECEIVED && (typeof e.onMessageHandler == "function" ? e.onMessageHandler(wt(n)) : e.onMessageHandler.next(wt(n)));
        let r = n.data;
        Xr(r) && r[Nr] === "1" && (yield ri(e, n.messageType, r))
    })
}
var yt = "@firebase/messaging",
    _t = "0.12.26";
var si = e => {
        let t = new ve(e.getProvider("app").getImmediate(), e.getProvider("installations-internal").getImmediate(), e.getProvider("analytics-internal"));
        return navigator.serviceWorker.addEventListener("message", n => oi(t, n)), t
    },
    ai = e => {
        let t = e.getProvider("messaging").getImmediate();
        return {
            getToken: r => Ct(t, r)
        }
    };

function ci() {
    S(new g("messaging", si, "PUBLIC")), S(new g("messaging-internal", ai, "PRIVATE")), E(yt, _t), E(yt, _t, "esm2020")
}

function ui() {
    return a(this, null, function*() {
        try {
            yield $()
        } catch (e) {
            return !1
        }
        return typeof window < "u" && F() && Be() && "serviceWorker" in navigator && "PushManager" in window && "Notification" in window && "fetch" in window && ServiceWorkerRegistration.prototype.hasOwnProperty("showNotification") && PushSubscription.prototype.hasOwnProperty("getKey")
    })
}

function fi(e) {
    return a(this, null, function*() {
        if (!navigator) throw h.create("only-available-in-window");
        return e.swRegistration || (yield Tt(e)), Wr(e)
    })
}

function di(e, t) {
    if (!navigator) throw h.create("only-available-in-window");
    return e.onMessageHandler = t, () => {
        e.onMessageHandler = null
    }
}

function Gi(e = he()) {
    return ui().then(t => {
        if (!t) throw h.create("unsupported-browser")
    }, t => {
        throw h.create("indexed-db-unsupported")
    }), B(x(e), "messaging").getImmediate()
}

function Ji(e, t) {
    return a(this, null, function*() {
        return e = x(e), Ct(e, t)
    })
}

function Yi(e) {
    return e = x(e), fi(e)
}

function Xi(e, t) {
    return e = x(e), di(e, t)
}
ci();
export {
    Rn as a, E as b, ui as c, Gi as d, Ji as e, Yi as f, Xi as g
};