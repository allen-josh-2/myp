import {
    aa as r,
    da as s,
    hg as e,
    ti as o,
    ui as n
} from "./chunk-GOPIAW4V.js";
var h = (() => {
    class i extends o {
        constructor(t) {
            super(t, e), this.api = t, this.endpoint = e
        }
        guestLeadAdd(t) {
            return this.api.post(this.endpoint, t)
        }
        getLookups() {
            return this.api.getListByQuery("lookups", {})
        }
        signedSchedulePickup(t) {
            return this.api.post("signedSchedulePickup", t)
        }
        sendVerificationOtp(t) {
            return this.api.post(this.endpoint + "/sendGuestOtp", t)
        }
        validateSignedOtp(t) {
            return this.api.post(this.endpoint + "/validateSignedOtp", t)
        }
        static {
            this.\u0275fac = function(p) {
                return new(p || i)(s(n))
            }
        }
        static {
            this.\u0275prov = r({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
export {
    h as a
};