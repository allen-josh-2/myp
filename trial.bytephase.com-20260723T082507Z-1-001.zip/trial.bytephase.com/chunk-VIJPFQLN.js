import {
    a as i,
    b as u,
    c as f,
    d as g,
    e as h,
    o as p,
    p as v
} from "./chunk-R5YFTT7F.js";
var O = t => M(t),
    C = (t, e) => (typeof t == "string" && (e = t, t = void 0), O(t).includes(e)),
    M = (t = window) => {
        if (typeof t > "u") return [];
        t.Ionic = t.Ionic || {};
        let e = t.Ionic.platforms;
        return e == null && (e = t.Ionic.platforms = N(t), e.forEach(o => t.document.documentElement.classList.add(`plt-${o}`))), e
    },
    N = t => {
        let e = i.get("platform");
        return Object.keys(b).filter(o => {
            let s = e ? .[o];
            return typeof s == "function" ? s(t) : b[o](t)
        })
    },
    W = t => l(t) && !P(t),
    m = t => !!(r(t, /iPad/i) || r(t, /Macintosh/i) && l(t)),
    _ = t => r(t, /iPhone/i),
    k = t => r(t, /iPhone|iPod/i) || m(t),
    I = t => r(t, /android|sink/i),
    x = t => I(t) && !r(t, /mobile/i),
    L = t => {
        let e = t.innerWidth,
            o = t.innerHeight,
            s = Math.min(e, o),
            a = Math.max(e, o);
        return s > 390 && s < 520 && a > 620 && a < 800
    },
    F = t => {
        let e = t.innerWidth,
            o = t.innerHeight,
            s = Math.min(e, o),
            a = Math.max(e, o);
        return m(t) || x(t) || s > 460 && s < 820 && a > 780 && a < 1400
    },
    l = t => B(t, "(any-pointer:coarse)"),
    H = t => !l(t),
    P = t => A(t) || y(t),
    A = t => !!(t.cordova || t.phonegap || t.PhoneGap),
    y = t => {
        let e = t.Capacitor;
        return !!(e ? .isNative || e ? .isNativePlatform && e.isNativePlatform())
    },
    S = t => r(t, /electron/i),
    T = t => {
        var e;
        return !!(!((e = t.matchMedia) === null || e === void 0) && e.call(t, "(display-mode: standalone)").matches || t.navigator.standalone)
    },
    r = (t, e) => e.test(t.navigator.userAgent),
    B = (t, e) => {
        var o;
        return (o = t.matchMedia) === null || o === void 0 ? void 0 : o.call(t, e).matches
    },
    b = {
        ipad: m,
        iphone: _,
        ios: k,
        android: I,
        phablet: L,
        tablet: F,
        cordova: A,
        capacitor: y,
        electron: S,
        pwa: T,
        mobile: l,
        mobileweb: W,
        desktop: H,
        hybrid: P
    },
    d, U = t => t && v(t) || d,
    q = (t = {}) => {
        if (typeof window > "u") return;
        let e = window.document,
            o = window,
            s = o.Ionic = o.Ionic || {},
            a = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, u(o)), {
                persistConfig: !1
            }), s.config), g(o)), t);
        i.reset(a), i.getBoolean("persistConfig") && f(o, a), M(o), s.config = i, s.mode = d = i.get("mode", e.documentElement.getAttribute("mode") || (C(o, "ios") ? "ios" : "md")), i.set("mode", d), e.documentElement.setAttribute("mode", d), e.documentElement.classList.add(d), i.getBoolean("_testing") && i.set("animated", !1);
        let E = n => {
                var c;
                return (c = n.tagName) === null || c === void 0 ? void 0 : c.startsWith("ION-")
            },
            j = n => ["ios", "md"].includes(n);
        p(n => {
            for (; n;) {
                let c = n.mode || n.getAttribute("mode");
                if (c) {
                    if (j(c)) return c;
                    E(n) && h('Invalid ionic mode: "' + c + '", expected: "ios" or "md"')
                }
                n = n.parentElement
            }
            return d
        })
    };
export {
    C as a, U as b, q as c
};