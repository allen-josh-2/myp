import {
    a as dt
} from "./chunk-KTU2GBZL.js";
import {
    a as st,
    b as mt,
    c as ct
} from "./chunk-WIGXHFCU.js";
import "./chunk-XHP3KBJE.js";
import {
    a as et
} from "./chunk-MYGQO4K4.js";
import "./chunk-BLJF2YPR.js";
import "./chunk-RW3SLQZQ.js";
import {
    $b as ze,
    Fb as Xe,
    Hc as Qe,
    Kf as ot,
    Pd as tt,
    Rc as Ze,
    Sb as Ke,
    Sc as Z,
    T as X,
    Va as Ue,
    ab as qe,
    ba as K,
    bb as W,
    ca as A,
    e as Me,
    g as we,
    h as Ie,
    ha as z,
    hh as rt,
    jc as We,
    ka as Be,
    la as Le,
    lb as He,
    mb as Ge,
    n as De,
    ph as lt,
    q as Ve,
    qb as Ye,
    qc as Q,
    rg as at,
    sb as $e,
    t as Fe,
    te as it,
    u as je,
    we as nt,
    y as Ae,
    yb as O
} from "./chunk-DCKGQUHB.js";
import {
    $a as v,
    $b as Se,
    $c as L,
    Ak as Je,
    Ba as ve,
    C as pe,
    Ca as _e,
    Ec as Ce,
    Fa as n,
    Fb as F,
    H as ue,
    Hb as ie,
    Ib as l,
    Jb as s,
    Kb as S,
    Kc as Te,
    Lb as xe,
    Lg as E,
    Mg as j,
    Na as k,
    Oa as H,
    Od as U,
    Pc as $,
    Sa as N,
    Tc as ke,
    X as ee,
    Xa as P,
    Yh as Re,
    _a as f,
    _b as ye,
    aa as fe,
    ba as q,
    bb as be,
    cb as ge,
    da as te,
    db as he,
    dd as Ee,
    ea as _,
    eb as m,
    fb as a,
    gb as r,
    gc as M,
    ha as C,
    hb as p,
    hc as B,
    hi as Ne,
    ia as T,
    ic as D,
    mc as G,
    n as ce,
    oc as Y,
    pc as y,
    qa as g,
    qb as w,
    rh as I,
    sb as h,
    t as de,
    ub as c,
    ui as Pe,
    vd as ne,
    wd as Oe,
    xk as b
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var R = (() => {
    class t {
        constructor(e, i) {
            this.apiService = e, this.http = i, this.trackingToken = null
        }
        checkVerificationNeeded() {
            return this.apiService.get("tracking/check-verification-needed")
        }
        verifyIdentity(e) {
            return this.apiService.post("tracking/verify-identity", {
                serial_number: e
            }).pipe(ee(i => {
                i.token && (this.trackingToken = i.token)
            }))
        }
        sendOtp(e, i) {
            return this.apiService.post("tracking/send-otp", {
                job_id: e,
                verification_type: i
            })
        }
        verifyOtp(e, i) {
            return this.apiService.post("tracking/verify-otp", {
                job_id: e,
                otp: i
            }).pipe(ee(o => {
                o.token && (this.trackingToken = o.token)
            }))
        }
        getTrackingDetails(e) {
            let i = new L().set("X-Tracking-Token", this.trackingToken || "");
            return this.http.get(`${U}tracking/details/${e}`, {
                headers: i
            })
        }
        getTrackingActivities(e) {
            let i = new L().set("X-Tracking-Token", this.trackingToken || "");
            return this.http.get(`${U}tracking/activities/${e}`, {
                headers: i
            })
        }
        getTrackingComments(e) {
            let i = new L().set("X-Tracking-Token", this.trackingToken || "");
            return this.http.get(`${U}tracking/comments/${e}`, {
                headers: i
            })
        }
        addTrackingComment(e, i) {
            let o = new L().set("X-Tracking-Token", this.trackingToken || ""),
                d = {
                    comment: i
                };
            return this.http.post(`${U}tracking/comments/${e}`, d, {
                headers: o
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(te(Pe), te(Ee))
            }
        }
        static {
            this.\u0275prov = fe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var J = class {
    constructor(u) {
        return Object.assign(this, u)
    }
    static getForm(u) {
        return new Ae().group({
            tracking_number: [u.tracking_number, [Me.required]],
            google_recaptcha: [""],
            otp: [u.otp || null],
            email: [u.email || null],
            mobile_number: [u.mobile_number || null],
            verification_type: [u.verification_type || null]
        })
    }
};
var Tt = t => ({
        color: t
    }),
    kt = () => [];

function Et(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "div", 4)(1, "div", 9)(2, "div", 10), p(3, "i", 11), r(), a(4, "h5", 12), l(5), r(), a(6, "p", 13), l(7), r()(), a(8, "div", 14)(9, "p", 15), l(10), r(), a(11, "ul", 16)(12, "li"), l(13), r(), a(14, "li"), l(15), r(), a(16, "li"), l(17), r()()(), a(18, "div", 17)(19, "app-save-btn", 18), h("saveBtnClick", function() {
            C(e);
            let o = c();
            return T(o.resetForm())
        }), r(), a(20, "p", 19), l(21), a(22, "a", 20), h("click", function() {
            C(e);
            let o = c();
            return T(o.onShowAttachmentSources())
        }), l(23), r()()()()
    }
    if (t & 2) {
        let e = c();
        n(5), s(e.formatMessage("no_results_found")), n(2), S(" ", e.formatMessage("no_job_found_message"), " "), n(3), S("", e.formatMessage("please_ensure"), ":"), n(3), s(e.formatMessage("tracking_number_entered_correctly")), n(2), s(e.formatMessage("no_extra_spaces")), n(2), s(e.formatMessage("correct_format_used")), n(2), m("useSubmitBehavior", !1), n(2), S(" ", e.formatMessage("still_having_trouble"), " "), n(2), s(e.formatMessage("where_to_find_this"))
    }
}

function Mt(t, u) {
    if (t & 1 && (a(0, "div", 34), l(1), r()), t & 2) {
        let e = c(3);
        n(), s(e.otpMessage())
    }
}

function wt(t, u) {
    if (t & 1 && (a(0, "app-control-container", 37), p(1, "app-mobile-number", 41)(2, "app-error", 24), r()), t & 2) {
        let e = c(3);
        m("errorMsg", e.formatMessage("mobile_number_required_error"))("label", e.formatMessage("verify_mobile_number")), n(), m("placeholder", e.formatMessage("mobile_number_placeholder"))("isEditMode", !1)("masked", !0), n(), m("displayError", e.trackForm().get("mobile_number").touched && e.trackForm().get("mobile_number").hasError("invalidPhoneNumber"))("errorMsg", e.formatMessage("common_invalid_mobile_number"))
    }
}

function It(t, u) {
    if (t & 1 && (a(0, "app-control-container", 38), p(1, "app-email", 42), r()), t & 2) {
        let e = c(3);
        m("errorMsg", e.formatMessage("email_required_error"))("label", e.formatMessage("verify_email")), n(), m("formControl", e.formControlForEmail)("isUniqueValidation", !1)("isEditMode", !1)("masked", !0)
    }
}

function Dt(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "app-control-container", 40)(1, "app-otp-input", 43), h("otpComplete", function() {
            C(e);
            let o = c(3);
            return T(o.onOtpComplete())
        }), r()()
    }
    if (t & 2) {
        let e, i = c(3);
        m("errorMsg", i.formatMessage("delivery_otp_required"))("label", i.verificationType() === i.VERIFY_USER_TYPE_LIST.EMAIL ? i.formatMessage("label_verify_email_otp") : i.formatMessage("label_verify_mobile_otp")), n(), m("disabled", !i.isOTPDelivered())("hasError", ((e = i.trackForm().get("otp")) == null ? null : e.invalid) && ((e = i.trackForm().get("otp")) == null ? null : e.touched))
    }
}

function Vt(t, u) {
    if (t & 1) {
        let e = w();
        p(0, "hr")(1, "i", 30), a(2, "h6", 31), l(3), r(), a(4, "div", 32)(5, "div", 33), f(6, Mt, 2, 1, "div", 34), a(7, "div", 35)(8, "dx-radio-group", 36), h("onValueChanged", function(o) {
            C(e);
            let d = c(2);
            return T(d.onValueChanged(o))
        }), r()(), f(9, wt, 3, 7, "app-control-container", 37)(10, It, 2, 6, "app-control-container", 38), a(11, "div", 35)(12, "app-dx-outline-button", 39), h("onClickEvent", function() {
            C(e);
            let o = c(2);
            return T(o.sendOTP(o.verificationType()))
        }), r()(), f(13, Dt, 2, 4, "app-control-container", 40), r()()
    }
    if (t & 2) {
        let e = c(2);
        n(3), s(e.formatMessage("verify_your_identity_title")), n(3), v(e.otpMessage() ? 6 : -1), n(2), m("items", e.verifyUserTypeList)("value", e.verificationType()), n(), v(e.verificationType() === e.VERIFY_USER_TYPE_LIST.MOBILE ? 9 : 10), n(3), m("disabled", e.isOTPButtonDisabled() || !e.isVerificationFormValid())("localeVariable", e.isOTPDelivered() && e.disableSendOtpBtnTimer !== 0 && e.isOTPButtonDisabled() ? e.disableSendOtpBtnTimer : "")("text", e.sendOtpAttempts === 0 ? "delivery_send_otp" : "delivery_resend_otp"), n(), v(e.isOTPDelivered() ? 13 : -1)
    }
}

function Ft(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "form", 5)(1, "app-control-container", 21)(2, "dx-text-box", 22), p(3, "dxi-button", 23), r(), p(4, "app-error", 24), r(), a(5, "div", 25)(6, "p", 26), l(7), r(), a(8, "button", 27), h("click", function() {
            C(e);
            let o = c();
            return T(o.onShowAttachmentSources())
        }), l(9), r()(), a(10, "div", 28)(11, "app-dx-outline-button", 29), h("onClickEvent", function() {
            C(e);
            let o = c();
            return T(o.onCheckRepair())
        }), r()(), f(12, Vt, 14, 9), r()
    }
    if (t & 2) {
        let e = c();
        m("formGroup", e.trackForm()), n(), m("name", e.mainInputDetails().controlName)("errorMsg", e.formatMessage(e.mainInputDetails().errorMessageForFieldRequired))("label", e.formatMessage(e.mainInputDetails().label)), n(), m("id", e.mainInputDetails().id)("formControlName", e.mainInputDetails().controlName)("placeholder", e.formatMessage(e.mainInputDetails().placeholder)), P("aria-label", e.formatMessage(e.mainInputDetails().label))("aria-required", !0)("aria-describedby", e.mainInputDetails().id + "-error"), n(), m("options", e.qrScanButtonOptions), n(), m("displayError", e.trackForm().get(e.mainInputDetails().controlName).dirty && e.trackForm().get(e.mainInputDetails().controlName).invalid)("errorMsg", e.formatMessage(e.mainInputDetails().errorMessageForInvalidField)), n(3), s(e.formatMessage("track_your_repair_job_note")), n(), m("ngStyle", Se(22, Tt, e.isDarkTheme() && "#FFFFFF"))("disabled", e.displayOtpVerification()), P("aria-label", e.formatMessage("where_to_find_this")), n(), S(" ", e.formatMessage("where_to_find_this"), " "), n(2), m("isVisibleIcon", !0)("disabled", e.displayOtpVerification())("text", "check_now"), n(), v(e.displayOtpVerification() ? 12 : -1)
    }
}

function jt(t, u) {
    if (t & 1 && (a(0, "div")(1, "div", 48), l(2), r()()), t & 2) {
        let e = u.$implicit,
            i = c(2);
        n(2), s(i.formatMessage(e.title))
    }
}

function At(t, u) {
    if (t & 1 && (a(0, "div")(1, "p"), l(2), r(), a(3, "figure", 49), p(4, "img", 50), r()()), t & 2) {
        let e = u.$implicit,
            i = c(2);
        n(2), s(i.formatMessage(e.description)), n(), P("aria-label", i.formatMessage(e.title)), n(), m("alt", i.formatMessage(e.title))("src", e.attachmentSrc, _e)
    }
}

function Ot(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "div")(1, "dx-scroll-view", 44)(2, "p", 45), l(3), r(), a(4, "dx-accordion", 46), N(5, jt, 3, 1, "div", 7)(6, At, 5, 4, "div", 7), r(), a(7, "app-dx-outline-button", 47), h("onClickEvent", function() {
            C(e);
            let o = c();
            return T(o.onClosingAttachmentSourcesPopup())
        }), r()()()
    }
    if (t & 2) {
        let e = c();
        n(3), s(e.formatMessage("where_to_find_this_note")), n(), m("dataSource", e.items())("collapsible", !0)("multiple", !1)("selectedItem", ye(8, kt)), n(), m("dxTemplateOf", "title"), n(), m("dxTemplateOf", "item"), n(), m("text", "got_it_thanks")
    }
}

function Rt(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "app-qrcode-scanner", 51), h("scannerToSave", function(o) {
            C(e);
            let d = c();
            return T(d.getJobFromBarcode(o))
        }), r()
    }
    if (t & 2) {
        let e = c();
        m("isVisiblePopup", e.isVisibleBarcodeScannerPopUp())("type", "get_barcode_number")
    }
}
var ut = (() => {
    class t {
        constructor() {
            this.formatMessage = b, this.isMobileDevice = _(X).isMobileDevice(), this.reCaptchaV3Service = _(mt), this.loaderService = _(Je), this.tenantService = _(He), this.guestService = _(dt), this.trackingService = _(R), this.toastNotificationService = _(A), this.themeService = _(Ze), this.isDarkTheme = this.themeService.isDarkTheme, this.headerDetails = y(), this.trackForm = y(), this.mainInputDetails = y(), this.items = y(), this.isUserVerified = Y(), this.isAttachmentSourcesVisible = g(!1), this.isOTPDelivered = g(!1), this.isOTPButtonDisabled = g(!1), this.isOTPVerified = g(!1), this.isSendingOTP = g(!1), this.verificationType = g(null), this.isOtpVerificationRequired = g(!1), this.displayOtpVerification = g(!1), this.otpMessage = g(""), this.noResultsFound = g(!1), this.isVisibleBarcodeScannerPopUp = g(!1), this.disableSendOtpBtnTimer = 30, this.sendOtpAttempts = 0, this.intervalSubscription = null, this.intervalSource = null, this.verifyUserTypeList = Object.values(E), this.siteKey = Oe.siteKey, this.errorResponse = null, this.ENTITIES = Ne, this.VERIFY_USER_TYPE_LIST = E, this.ASSET_PATHS = j, this.asyncOtpValidation = this.asyncOtpValidation.bind(this), this.qrScanButtonOptions = {
                icon: "fa-thin fa-qrcode",
                type: "default",
                hint: b("scan_qr_code"),
                onClick: () => {
                    this.openBarcodeScanner()
                }
            }
        }
        ngOnInit() {
            this.trackingService.checkVerificationNeeded().subscribe(e => {
                this.isOtpVerificationRequired.set(e.verification_needed)
            }), this.selectVerificationType()
        }
        hasPrimaryActiveSmsService() {
            return this.tenantService ? .config() ? .active_integrations.some(e => e.group === "sms" && e.is_primary === !0 && e.status === "Active")
        }
        get formControlForEmail() {
            return this.trackForm().get("email")
        }
        selectVerificationType() {
            this.hasPrimaryActiveSmsService() && this.trackForm().controls.mobile_number.valid ? (this.verificationType.set(E.MOBILE), this.trackForm().controls.verification_type.setValue(this.verificationType())) : (!this.hasPrimaryActiveSmsService() || this.trackForm().controls.mobile_number.value.length <= 0 && this.trackForm().controls.email.value) && (this.verificationType.set(E.EMAIL), this.trackForm().controls.verification_type.setValue(this.verificationType())), !this.verificationType() && this.hasPrimaryActiveSmsService() ? (this.verificationType.set(E.MOBILE), this.trackForm().controls.verification_type.setValue(E.MOBILE)) : this.verificationType() || (this.verificationType.set(E.EMAIL), this.trackForm().controls.verification_type.setValue(E.EMAIL))
        }
        isVerificationFormValid() {
            let e = this.verificationType() === E.MOBILE,
                i = this.verificationType() === E.EMAIL;
            if (e) {
                let o = this.trackForm().get("mobile_number"),
                    x = (o ? .value || "").replace(/\D/g, "");
                return o ? .valid && x.length > 0
            }
            if (i) {
                let o = this.trackForm().get("email");
                return o ? .valid && o ? .value ? .length > 0
            }
            return !1
        }
        disableSendOtpForDuration() {
            this.intervalSource = pe(1e3), this.intervalSubscription = this.intervalSource.subscribe({
                next: () => {
                    this.disableSendOtpBtnTimer !== 0 ? this.disableSendOtpBtnTimer-- : this.unsubscribeIntervalAndEnableResendOtp()
                },
                error: () => {
                    this.unsubscribeIntervalAndEnableResendOtp()
                }
            })
        }
        setFormValues() {
            this.trackForm().controls.mobile_number.setValue(""), this.trackForm().controls.email.setValue("")
        }
        unsubscribeIntervalAndEnableResendOtp() {
            this.isOTPButtonDisabled.set(!1), this.disableSendOtpBtnTimer = 30, this.sendOtpAttempts++, this.intervalSubscription && this.intervalSubscription.unsubscribe()
        }
        getReceiptData() {
            this.displayOtpVerification.set(!1), this.isUserVerified.emit(this.jobId)
        }
        resetForm() {
            this.noResultsFound.set(!1), this.trackForm().reset(), this.displayOtpVerification.set(!1), this.isOTPDelivered.set(!1), this.isOTPVerified.set(!1), this.jobId = null
        }
        onCheckRepair() {
            this.reCaptchaV3Service.execute(this.siteKey, "submit", e => {
                this.trackForm().controls.google_recaptcha.patchValue(e), this.errorResponse = null;
                let i = this.trackForm().controls[this.mainInputDetails().controlName].value;
                this.trackingService.verifyIdentity(i).subscribe({
                    next: o => {
                        o.job_id && (this.jobId = o.job_id), o.mobile_number && this.trackForm().controls.mobile_number.setValue(o.mobile_number), o.email && this.trackForm().controls.email.setValue(o.email), o.verification_needed ? (this.isOtpVerificationRequired.set(!0), o.message && this.otpMessage.set(o.message), this.displayOtpVerification.set(!0)) : (this.isOtpVerificationRequired.set(!1), this.getReceiptData())
                    },
                    error: o => {
                        this.noResultsFound.set(!0)
                    }
                })
            }, {
                useGlobalDomain: !0
            })
        }
        sendOTP(e) {
            this.isSendingOTP.set(!0);
            let i = e.toLowerCase(),
                o = e === E.EMAIL ? "notification_otp_sent_email_success" : "notification_otp_sent_mobile_number_success";
            this.trackingService.sendOtp(this.jobId, i).subscribe({
                next: () => {
                    this.isOTPDelivered.set(!0), this.toastNotificationService.success(o), this.isOTPButtonDisabled.set(!0), this.disableSendOtpForDuration()
                },
                error: d => {
                    console.error("OTP Send Error:", d), this.toastNotificationService.error("notification_otp_error")
                },
                complete: () => {
                    this.isSendingOTP.set(!1)
                }
            })
        }
        asyncOtpValidation(e) {
            return this.trackingService.verifyOtp(this.jobId, parseInt(this.trackForm().controls.otp.value)).pipe(de(i => (this.isOTPVerified.set(!1), i ? .job_id ? (this.isOTPVerified.set(!0), this.getReceiptData(), !0) : (this.trackForm().get("otp") ? .setErrors({
                otpInvalid: "OTP validation failed"
            }), !1))), ue(i => {
                let o = this.trackForm().get("otp");
                return o ? .setErrors({
                    otpInvalid: "An error occurred during OTP validation"
                }), o ? .updateValueAndValidity(), this.isUserVerified.emit(!1), ce(!1)
            })).toPromise()
        }
        onShowAttachmentSources() {
            this.isAttachmentSourcesVisible.set(!0)
        }
        onClosingAttachmentSourcesPopup() {
            this.isAttachmentSourcesVisible.set(!1)
        }
        onOtpComplete() {
            this.trackForm().get("otp") ? .value ? .length === 6 && this.jobId && this.asyncOtpValidation({
                value: this.trackForm().get("otp") ? .value
            })
        }
        onValueChanged(e) {
            this.verificationType.set(e.value)
        }
        openBarcodeScanner() {
            this.isVisibleBarcodeScannerPopUp.set(!0)
        }
        getJobFromBarcode(e) {
            e && (this.trackForm().controls[this.mainInputDetails().controlName].setValue(e), this.isVisibleBarcodeScannerPopUp.set(!1), setTimeout(() => {
                this.onCheckRepair()
            }, 100))
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-track-form"]
                ],
                inputs: {
                    headerDetails: [1, "headerDetails"],
                    trackForm: [1, "trackForm"],
                    mainInputDetails: [1, "mainInputDetails"],
                    items: [1, "items"]
                },
                outputs: {
                    isUserVerified: "isUserVerified"
                },
                standalone: !1,
                decls: 14,
                vars: 15,
                consts: [
                    [1, "text-center", "m-1"],
                    [1, "fs-6"],
                    [1, "row", "justify-content-center", "m-1", "mt-3"],
                    [1, "card", 3, "ngClass"],
                    [1, "my-4", "px-4"],
                    [1, "my-4", 3, "formGroup"],
                    [3, "onHiding", "visible", "width", "maxWidth", "maxHeight", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "isVisiblePopup", "type"],
                    [1, "text-center", "mb-4"],
                    [1, "d-inline-flex", "align-items-center", "justify-content-center", "rounded-circle", "bg-danger", "bg-opacity-10", "mb-3", 2, "width", "80px", "height", "80px"],
                    [1, "fa-solid", "fa-circle-exclamation", "fa-3x", "text-danger"],
                    [1, "fw-bold", "mb-2"],
                    [1, "text-muted", "mb-4"],
                    [1, "bg-light", "rounded", "p-3", "mb-4"],
                    [1, "fw-semibold", "mb-2", "small"],
                    [1, "small", "text-muted", "mb-0", "ps-3"],
                    [1, "d-flex", "flex-column", "gap-3"],
                    ["icon", "fa-solid fa-arrow-left me-2", "saveText", "try_again", "stylingMode", "contained", 1, "w-100", 3, "saveBtnClick", "useSubmitBehavior"],
                    [1, "text-center", "small", "mb-0"],
                    ["href", "javascript:void(0)", 1, "text-decoration-none", 3, "click"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", 3, "name", "errorMsg", "label"],
                    [3, "id", "formControlName", "placeholder"],
                    ["location", "after", "name", "qrScanButton", 3, "options"],
                    [3, "displayError", "errorMsg"],
                    [1, "d-flex", "flex-column"],
                    [1, "fs-9"],
                    ["type", "button", 1, "fs-7", "align-self-end", "link-color", "border-0", "bg-transparent", 3, "click", "ngStyle", "disabled"],
                    [1, "d-flex", "justify-content-center", "mt-4"],
                    ["buttonType", "default", "buttonStyle", "contained", "icon", "fas fa-search", 1, "fs-7", 3, "onClickEvent", "isVisibleIcon", "disabled", "text"],
                    [1, "d-block", "fa-solid", "fa-circle-check", "fa-2x", "text-center", "mb-3"],
                    [1, "text-center"],
                    [1, "row", "d-flex", "justify-content-center"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "align-self-center"],
                    [1, "alert", "alert-info", "mb-3"],
                    [1, "d-flex", "justify-content-center", "mb-3"],
                    ["layout", "horizontal", "formControlName", "verification_type", 3, "onValueChanged", "items", "value"],
                    ["id", "mobile_number", "name", "mobile_number", 3, "errorMsg", "label"],
                    ["name", "email", 3, "errorMsg", "label"],
                    ["buttonType", "default", "buttonStyle", "contained", 1, "mt-3", "mb-3", 3, "onClickEvent", "disabled", "localeVariable", "text"],
                    ["name", "otp", 3, "errorMsg", "label"],
                    ["formControlName", "mobile_number", "id", "track-form-mobile", 3, "placeholder", "isEditMode", "masked"],
                    [3, "formControl", "isUniqueValidation", "isEditMode", "masked"],
                    ["formControlName", "otp", 3, "otpComplete", "disabled", "hasError"],
                    ["height", "100%", "width", "100%"],
                    [1, "fs-7"],
                    ["id", "ticket-tracking-accordion-container", 3, "dataSource", "collapsible", "multiple", "selectedItem"],
                    ["buttonType", "default", "buttonStyle", "contained", 1, "fs-7", "d-flex", "justify-content-center", 3, "onClickEvent", "text"],
                    [1, "header", "fs-7", "fw-bold"],
                    ["role", "img"],
                    ["loading", "lazy", "role", "presentation", 1, "img-fluid", "me-2", 2, "width", "100%", "height", "100%", "border", "3px solid #61616147", "border-radius", "5px", 3, "alt", "src"],
                    [3, "scannerToSave", "isVisiblePopup", "type"]
                ],
                template: function(i, o) {
                    i & 1 && (a(0, "div"), p(1, "app-logo"), a(2, "div", 0)(3, "h4"), l(4), r(), a(5, "p", 1), l(6), r()(), a(7, "div", 2)(8, "div", 3), f(9, Et, 24, 9, "div", 4), f(10, Ft, 13, 24, "form", 5), r()()(), a(11, "dx-popup", 6), h("onHiding", function() {
                        return o.onClosingAttachmentSourcesPopup()
                    }), N(12, Ot, 8, 9, "div", 7), r(), f(13, Rt, 1, 2, "app-qrcode-scanner", 8)), i & 2 && (n(4), s(o.formatMessage(o.headerDetails().headerTitle)), n(2), s(o.formatMessage(o.headerDetails().headerSubTitle)), n(2), m("ngClass", o.isMobileDevice ? "w-100" : "w-50"), n(), v(o.noResultsFound() ? 9 : -1), n(), v(o.trackForm() && !o.noResultsFound() ? 10 : -1), n(), m("visible", o.isAttachmentSourcesVisible())("width", "95vw")("maxWidth", 600)("maxHeight", 500)("title", o.isMobileDevice ? o.formatMessage("where_to_find_your_tracking_number_mobile_title") : o.formatMessage("where_to_find_your_tracking_number_title")), P("role", "dialog")("aria-modal", !0)("aria-labelledby", "tracking-help-title"), n(), m("dxTemplateOf", "content"), n(), v(o.isVisibleBarcodeScannerPopUp() ? 13 : -1))
                },
                dependencies: [Ce, Te, Ye, W, $e, tt, rt, Be, it, nt, Q, z, Le, qe, Qe, ze, Ue, De, we, Ie, Ve, je, Fe, st],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Bt(t, u) {
    if (t & 1 && (a(0, "div", 3)(1, "div"), p(2, "i"), r(), a(3, "span", 4), l(4), r()()), t & 2) {
        let e = u.$implicit;
        n(), ie(e.iconBg + " bg-opacity-10 rounded-2 p-2 d-flex align-items-center justify-content-center"), n(), ie(e.icon + " " + e.iconColor), n(2), s(e.title)
    }
}

function Lt(t, u) {
    if (t & 1 && (a(0, "div")(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "span", 8), l(5), r(), a(6, "span", 9), l(7), r()()(), a(8, "div", 6)(9, "div", 10)(10, "span", 8), l(11), r(), a(12, "span", 11), l(13), M(14, "objToString"), r()()(), a(15, "div", 6)(16, "div", 12)(17, "span", 8), l(18), r(), a(19, "span", 13), l(20), r()()()()()), t & 2) {
        let e, i, o, d = c();
        n(5), s(d.formatMessage("device_type")), n(2), s(((e = d.overviewSummary()) == null || e.device_type == null ? null : e.device_type.name) || "-"), n(4), s(d.formatMessage("job_service_information")), n(2), s(B(14, 6, (i = d.overviewSummary()) == null ? null : i.repairables)), n(5), s(d.formatMessage("payment_status")), n(2), s(((o = d.overviewSummary()) == null ? null : o.payment_status) || "-")
    }
}

function Ut(t, u) {
    if (t & 1 && (a(0, "div", 6)(1, "div", 20), p(2, "i", 21), a(3, "span", 22), l(4), r()()()), t & 2) {
        let e, i = c(2);
        n(4), s((e = i.overviewSummary()) == null || e.user == null ? null : e.user.email)
    }
}

function Jt(t, u) {
    if (t & 1 && (a(0, "div", 6)(1, "div", 20), p(2, "i", 23), a(3, "span", 22), l(4), M(5, "mobileDisplay"), r()()()), t & 2) {
        let e, i = c(2);
        n(4), s(D(5, 1, (e = i.overviewSummary()) == null || e.user == null ? null : e.user.mobile_number, (e = i.overviewSummary()) == null || e.user == null ? null : e.user.mobile_country_code))
    }
}

function qt(t, u) {
    if (t & 1 && (a(0, "div")(1, "div", 14)(2, "div", 15), p(3, "i", 16), r(), a(4, "div")(5, "p", 17), l(6), r(), a(7, "small", 18), l(8, "Customer"), r()()(), a(9, "div", 19), f(10, Ut, 5, 1, "div", 6), f(11, Jt, 6, 4, "div", 6), r()()), t & 2) {
        let e, i, o, d = c();
        n(6), s(((e = d.overviewSummary()) == null || e.user == null ? null : e.user.name) || "-"), n(4), v(!((i = d.overviewSummary()) == null || i.user == null) && i.user.email ? 10 : -1), n(), v(!((o = d.overviewSummary()) == null || o.user == null) && o.user.mobile_number ? 11 : -1)
    }
}

function Ht(t, u) {
    if (t & 1 && (a(0, "div", 6)(1, "div", 12)(2, "div", 3), p(3, "i", 26), a(4, "span", 8), l(5), r()(), a(6, "span", 27), l(7), M(8, "dateFormat"), r()()()), t & 2) {
        let e, i = c(2);
        n(5), s(i.formatMessage("completed")), n(2), s(D(8, 2, (e = i.overviewSummary()) == null ? null : e.completed_at, "datetime"))
    }
}

function Gt(t, u) {
    if (t & 1 && (a(0, "div")(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "div", 3), p(5, "i", 24), a(6, "span", 8), l(7), r()(), a(8, "span", 9), l(9), M(10, "dateFormat"), r()()(), a(11, "div", 6)(12, "div", 7)(13, "div", 3), p(14, "i", 25), a(15, "span", 8), l(16), r()(), a(17, "span", 9), l(18), M(19, "date"), r()()(), f(20, Ht, 9, 5, "div", 6), r()()), t & 2) {
        let e, i, o, d = c();
        n(7), s(d.formatMessage("job_created")), n(2), s(D(10, 5, (e = d.jobCreated()) == null ? null : e.created_at, "datetime")), n(7), s(d.formatMessage("estimated_completion")), n(2), s(B(19, 8, (i = d.overviewSummary()) == null ? null : i.estimated_delivery)), n(2), v((o = d.overviewSummary()) != null && o.completed_at ? 20 : -1)
    }
}

function Yt(t, u) {
    if (t & 1 && (a(0, "div", 6)(1, "div", 7)(2, "span", 8), l(3), r(), a(4, "span", 29), p(5, "app-currency-symbol"), l(6), r()()(), a(7, "div", 6)(8, "div", 12)(9, "span", 8), l(10), r(), a(11, "span", 30), p(12, "app-currency-symbol"), l(13), r()()()), t & 2) {
        let e, i, o = c(2);
        n(3), s(o.formatMessage("advance_paid")), n(3), S(" ", (e = o.overviewSummary()) == null ? null : e.advance_paid, " "), n(4), s(o.formatMessage("balance_due")), n(3), S(" ", (i = o.overviewSummary()) == null ? null : i.balance_due, " ")
    }
}

function $t(t, u) {
    if (t & 1 && (a(0, "div")(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "span", 8), l(5), r(), a(6, "span", 4), p(7, "app-currency-symbol"), l(8), r()()(), a(9, "div", 6)(10, "div", 12)(11, "span", 8), l(12), r(), a(13, "span", 28), p(14, "app-currency-symbol"), l(15), r()()(), f(16, Yt, 14, 4), r()()), t & 2) {
        let e, i, o, d, x = c();
        n(5), s(x.formatMessage("estimated_cost")), n(3), S(" ", ((e = x.overviewSummary()) == null ? null : e.initial_quotation) || 0, " "), n(2), F("border-bottom", ((i = x.overviewSummary()) == null ? null : i.advance_paid) > 0), n(2), s(x.formatMessage("final_cost")), n(3), S(" ", ((o = x.overviewSummary()) == null ? null : o.total_amount) || 0, " "), n(), v(((d = x.overviewSummary()) == null ? null : d.advance_paid) > 0 ? 16 : -1)
    }
}
var vt = (() => {
    class t {
        constructor() {
            this.formatMessage = b, this.overviewSummary = y(), this.jobActivities = y(), this.jobCreated = y(), this.accordionItems = [{
                id: 1,
                title: b("device_information"),
                icon: "fa-thin fa-box",
                iconColor: "text-primary",
                iconBg: "bg-primary",
                template: "deviceInfoTemplate"
            }, {
                id: 2,
                title: b("common_customer_information"),
                icon: "fa-thin fa-user",
                iconColor: "text-success",
                iconBg: "bg-success",
                template: "customerInfoTemplate"
            }, {
                id: 3,
                title: b("common_timelines"),
                icon: "fa-thin fa-clock",
                iconColor: "text-warning",
                iconBg: "bg-warning",
                template: "timelineTemplate"
            }, {
                id: 4,
                title: b("cost_information"),
                icon: "fa-thin fa-wallet",
                iconColor: "text-info",
                iconBg: "bg-info",
                template: "costInfoTemplate"
            }]
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-track-repair-job-details"]
                ],
                inputs: {
                    overviewSummary: [1, "overviewSummary"],
                    jobActivities: [1, "jobActivities"],
                    jobCreated: [1, "jobCreated"]
                },
                standalone: !1,
                decls: 6,
                vars: 10,
                consts: [
                    ["id", "job-details-accordion", 3, "dataSource", "collapsible", "multiple", "animationDuration", "selectedItems"],
                    ["class", "d-flex align-items-center gap-2", 4, "dxTemplate", "dxTemplateOf"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fw-semibold"],
                    [1, "row", "g-0"],
                    [1, "col-12"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "py-2", "border-bottom"],
                    [1, "small", "opacity-75"],
                    [1, "fw-medium", "small"],
                    [1, "d-flex", "justify-content-between", "align-items-start", "py-2", "border-bottom"],
                    [1, "fw-medium", "small", "text-end", 2, "max-width", "60%"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "py-2"],
                    [1, "badge", "bg-info", "bg-opacity-10", "text-info"],
                    [1, "d-flex", "align-items-center", "gap-3", "mb-3", "pb-3", "border-bottom"],
                    [1, "bg-success", "bg-opacity-10", "rounded-circle", "p-2", "d-flex", "align-items-center", "justify-content-center", 2, "width", "40px", "height", "40px"],
                    [1, "fa-thin", "fa-user", "text-success"],
                    [1, "mb-0", "fw-medium"],
                    [1, "opacity-75"],
                    [1, "row", "g-2"],
                    [1, "d-flex", "align-items-center", "gap-2", "py-2"],
                    [1, "fa-thin", "fa-envelope", "opacity-75"],
                    [1, "small"],
                    [1, "fa-thin", "fa-mobile", "opacity-75"],
                    [1, "fa-thin", "fa-calendar-plus", "text-info", "small"],
                    [1, "fa-thin", "fa-calendar-check", "text-warning", "small"],
                    [1, "fa-thin", "fa-circle-check", "text-success", "small"],
                    [1, "fw-medium", "small", "text-success"],
                    [1, "fw-bold", "text-info", "fs-6"],
                    [1, "fw-semibold", "text-success"],
                    [1, "fw-bold", "text-danger", "fs-6"]
                ],
                template: function(i, o) {
                    i & 1 && (a(0, "dx-accordion", 0), N(1, Bt, 5, 5, "div", 1)(2, Lt, 21, 8, "div", 2)(3, qt, 12, 3, "div", 2)(4, Gt, 21, 10, "div", 2)(5, $t, 17, 7, "div", 2), r()), i & 2 && (m("dataSource", o.accordionItems)("collapsible", !0)("multiple", !0)("animationDuration", 200)("selectedItems", o.accordionItems), n(), m("dxTemplateOf", "title"), n(), m("dxTemplateOf", "deviceInfoTemplate"), n(), m("dxTemplateOf", "customerInfoTemplate"), n(), m("dxTemplateOf", "timelineTemplate"), n(), m("dxTemplateOf", "costInfoTemplate"))
                },
                dependencies: [Z, Q, z, $, O, Ke, Ge],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Kt(t, u) {
    if (t & 1 && (a(0, "div", 1)(1, "div", 2), p(2, "i", 3), r(), a(3, "h6", 4), l(4), r(), a(5, "span", 5), l(6), r()(), p(7, "app-activity-list", 6)), t & 2) {
        let e, i = c();
        n(4), s(i.formatMessage("activity_log")), n(2), s((e = i.filteredActivities()) == null ? null : e.length), n(), m("activities", i.filteredActivities())
    }
}

function zt(t, u) {
    if (t & 1 && (a(0, "div", 0)(1, "div", 7), p(2, "i", 8), r(), a(3, "h6", 9), l(4), r(), a(5, "p", 10), l(6, "Activity history will appear here once actions are taken on this job."), r()()), t & 2) {
        let e = c();
        n(4), s(e.formatMessage("no_activity_log_found"))
    }
}
var _t = (() => {
    class t {
        constructor() {
            this.formatMessage = b, this.userSessionService = _(K), this.isEmployee = this.userSessionService.isEmployee, this.jobActivities = y([]), this.filteredActivities = G(() => {
                let e = this.jobActivities();
                if (!e) return [];
                if (this.isEmployee()) return e;
                let i = [I.OUTSOURCED_JOB_CREATED, I.OUTSOURCED_JOB_UPDATED, I.JOB_ASSIGNEE_UPDATED, I.JOB_ASSIGNEE_AND_STATUS, I.BACKUP_DRIVE_JOB_UPDATED, I.BACKUP_DRIVE_JOB_CREATED];
                return e.filter(o => !i.includes(o.event))
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-track-repair-activity-log"]
                ],
                inputs: {
                    jobActivities: [1, "jobActivities"]
                },
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    [1, "bg-body-secondary", "rounded-3", "p-5", "text-center"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-3"],
                    [1, "bg-info", "bg-opacity-10", "rounded-2", "p-2", "d-flex", "align-items-center", "justify-content-center"],
                    [1, "fa-thin", "fa-timeline", "text-info"],
                    [1, "mb-0", "fw-semibold"],
                    [1, "badge", "bg-info", "bg-opacity-10", "text-info"],
                    [3, "activities"],
                    [1, "bg-secondary", "bg-opacity-10", "rounded-circle", "mx-auto", "mb-3", "d-flex", "align-items-center", "justify-content-center", 2, "width", "80px", "height", "80px"],
                    [1, "fa-thin", "fa-timeline", "fa-2x", "text-secondary"],
                    [1, "mb-2"],
                    [1, "text-muted", "small", "mb-0"]
                ],
                template: function(i, o) {
                    if (i & 1 && (f(0, Kt, 8, 3), f(1, zt, 7, 1, "div", 0)), i & 2) {
                        let d, x;
                        v((d = o.filteredActivities()) != null && d.length ? 0 : -1), n(), v((x = o.filteredActivities()) != null && x.length ? -1 : 1)
                    }
                },
                dependencies: [ot],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Qt(t, u) {
    if (t & 1 && (a(0, "div", 9)(1, "div", 10), p(2, "i", 11), a(3, "p", 12), l(4), r()()()), t & 2) {
        let e = c();
        n(4), s(e.formatMessage("loading_comments"))
    }
}

function Zt(t, u) {
    if (t & 1 && (a(0, "div", 28), p(1, "i", 29), a(2, "span"), l(3), r()()), t & 2) {
        let e = c(3);
        n(3), s(e.formatMessage("replied_by_team"))
    }
}

function ei(t, u) {
    if (t & 1 && (a(0, "div", 17)(1, "div", 18)(2, "div", 19)(3, "div", 20), p(4, "i", 21), r(), a(5, "div")(6, "p", 22), l(7), r(), a(8, "span", 23), l(9), r()()(), a(10, "small", 24), p(11, "i", 25), l(12), M(13, "dateFormat"), r()(), a(14, "div", 26), p(15, "div", 27), f(16, Zt, 4, 1, "div", 28), r()()), t & 2) {
        let e = u.$implicit;
        n(3), F("bg-primary", (e.user == null ? null : e.user.type_id) === 1)("bg-success", (e.user == null ? null : e.user.type_id) === 2)("bg-opacity-10", !0), n(), F("text-primary", (e.user == null ? null : e.user.type_id) === 1)("text-success", (e.user == null ? null : e.user.type_id) === 2), n(3), s((e.user == null ? null : e.user.name) || "Unknown User"), n(), F("bg-primary", (e.user == null ? null : e.user.type_id) === 1)("bg-opacity-10", !0)("text-primary", (e.user == null ? null : e.user.type_id) === 1)("bg-success", (e.user == null ? null : e.user.type_id) === 2)("text-success", (e.user == null ? null : e.user.type_id) === 2), n(), S(" ", (e.user == null ? null : e.user.type_id) === 1 ? "Employee" : "Customer", " "), n(3), S(" ", D(13, 25, e.created_at, "datetime"), " "), n(3), m("innerHTML", e.comment, ve), n(), v(e.has_replied ? 16 : -1)
    }
}

function ti(t, u) {
    if (t & 1 && (a(0, "div")(1, "div", 1)(2, "div", 13), p(3, "i", 14), r(), a(4, "h6", 4), l(5), r(), a(6, "span", 15), l(7), r()(), a(8, "div", 16), ge(9, ei, 17, 28, "div", 17, be), r()()), t & 2) {
        let e = c();
        n(5), s(e.formatMessage("comment_history")), n(2), s(e.jobCommentList().length), n(2), he(e.jobCommentList())
    }
}
var bt = (() => {
    class t {
        constructor() {
            this.formatMessage = b, this.trackingService = _(R), this.toastNotificationService = _(A), this.overviewSummary = y(), this.jobCommentList = g([]), this.isLoadingComments = g(!1), this.isSubmitting = g(!1), this.newComment = g("")
        }
        ngOnInit() {
            this.loadComments()
        }
        loadComments() {
            let e = this.overviewSummary() ? .id;
            e && (this.isLoadingComments.set(!0), this.trackingService.getTrackingComments(e).subscribe({
                next: i => {
                    this.jobCommentList.set(i)
                },
                error: i => {
                    console.error("Failed to load comments:", i), this.toastNotificationService.error("Failed to load comments")
                },
                complete: () => {
                    this.isLoadingComments.set(!1)
                }
            }))
        }
        submitComment() {
            let e = this.newComment().trim();
            if (!e) {
                this.toastNotificationService.error("Comment cannot be empty");
                return
            }
            if (e.length < 2 || e.length > 1e4) {
                this.toastNotificationService.error("Comment must be between 2 and 10000 characters");
                return
            }
            let i = this.overviewSummary() ? .id;
            this.isSubmitting.set(!0), this.trackingService.addTrackingComment(i, e).subscribe({
                next: o => {
                    this.jobCommentList.update(d => [o, ...d]), this.newComment.set(""), this.toastNotificationService.success("Comment added successfully")
                },
                error: o => {
                    console.error("Failed to add comment:", o), this.toastNotificationService.error(o.error ? .message || "Failed to add comment")
                },
                complete: () => {
                    this.isSubmitting.set(!1)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-track-repair-comments"]
                ],
                inputs: {
                    overviewSummary: [1, "overviewSummary"]
                },
                standalone: !1,
                decls: 13,
                vars: 9,
                consts: [
                    [1, "mb-4"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-3"],
                    [1, "bg-primary", "bg-opacity-10", "rounded-2", "p-2", "d-flex", "align-items-center", "justify-content-center"],
                    [1, "fa-thin", "fa-comment-dots", "text-primary"],
                    [1, "mb-0", "fw-semibold", 2, "color", "var(--font-color)"],
                    [1, "border", "rounded-3", "p-3", 2, "background-color", "var(--bg-secondary)"],
                    ["rows", "3", 1, "form-control", "mb-3", 2, "background-color", "var(--background-color)", "color", "var(--font-color)", "border-color", "var(--bg-secondary)", 3, "input", "value", "disabled", "placeholder"],
                    [1, "d-flex", "justify-content-end"],
                    ["icon", "fa-thin fa-paper-plane", "saveText", "submit_comment", "savingText", "submitting", "stylingMode", "contained", 3, "saveBtnClick", "isDisabled", "isSaving", "useSubmitBehavior"],
                    [1, "text-center", "py-5"],
                    [1, "border", "rounded-3", "p-5", 2, "background-color", "var(--bg-secondary)"],
                    [1, "fa-thin", "fa-spinner", "fa-spin", "fa-2x", "text-primary", "mb-3"],
                    [1, "mb-0", 2, "color", "var(--font-color)", "opacity", "0.7"],
                    [1, "bg-secondary", "bg-opacity-10", "rounded-2", "p-2", "d-flex", "align-items-center", "justify-content-center"],
                    [1, "fa-thin", "fa-comments", "text-secondary"],
                    [1, "badge", "bg-secondary", "bg-opacity-10", "text-secondary"],
                    [1, "d-flex", "flex-column", "gap-3"],
                    [1, "border", "rounded-3", "p-3", 2, "background-color", "var(--bg-secondary)", "color", "var(--font-color)"],
                    [1, "d-flex", "justify-content-between", "align-items-start", "mb-3"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "rounded-circle", "d-flex", "align-items-center", "justify-content-center", 2, "width", "36px", "height", "36px"],
                    [1, "fa-thin", "fa-user"],
                    [1, "mb-0", "fw-medium", "small"],
                    [1, "badge", "small"],
                    [2, "color", "var(--primary-text)", "opacity", "0.7"],
                    [1, "fa-thin", "fa-clock", "me-1"],
                    [1, "ps-5", "ms-2"],
                    [1, "mb-2", 3, "innerHTML"],
                    [1, "d-flex", "align-items-center", "gap-1", "text-success", "small"],
                    [1, "fa-thin", "fa-check-circle"]
                ],
                template: function(i, o) {
                    i & 1 && (a(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "i", 3), r(), a(4, "h6", 4), l(5), r()(), a(6, "div", 5)(7, "textarea", 6), h("input", function(x) {
                        return o.newComment.set(x.target.value)
                    }), l(8, "    "), r(), a(9, "div", 7)(10, "app-save-btn", 8), h("saveBtnClick", function() {
                        return o.submitComment()
                    }), r()()()(), f(11, Qt, 5, 1, "div", 9), f(12, ti, 11, 2, "div")), i & 2 && (n(5), s(o.formatMessage("add_comment")), n(2), m("value", o.newComment())("disabled", o.isSubmitting())("placeholder", o.formatMessage("enter_your_comment_placeholder")), n(3), m("isDisabled", !o.newComment().trim())("isSaving", o.isSubmitting())("useSubmitBehavior", !1), n(), v(o.isLoadingComments() ? 11 : -1), n(), v(!o.isLoadingComments() && o.jobCommentList().length > 0 ? 12 : -1))
                },
                dependencies: [W, O],
                encapsulation: 2
            })
        }
    }
    return t
})();

function ni(t, u) {
    if (t & 1 && (a(0, "div", 15)(1, "div", 26)(2, "div", 27), p(3, "i", 28), a(4, "span", 29), l(5), r()(), a(6, "p", 30), l(7), M(8, "dateFormat"), r()()()), t & 2) {
        let e, i = c();
        n(5), s(i.formatMessage("job_created")), n(2), s(D(8, 2, (e = i.jobCreated()) == null ? null : e.created_at, "datetime"))
    }
}

function oi(t, u) {
    if (t & 1 && (a(0, "div", 15)(1, "div", 31)(2, "div", 27), p(3, "i", 32), a(4, "span", 29), l(5), r()(), a(6, "p", 30), l(7), M(8, "date"), r()()()), t & 2) {
        let e, i = c();
        n(5), s(i.formatMessage("common_due_date")), n(2), s(B(8, 2, (e = i.overviewSummary()) == null ? null : e.estimated_delivery))
    }
}

function ai(t, u) {
    if (t & 1 && (a(0, "div", 15)(1, "div", 33)(2, "div", 27), p(3, "i", 34), a(4, "span", 29), l(5), r()(), a(6, "p", 35), l(7), r()()()), t & 2) {
        let e, i = c();
        n(5), s(i.formatMessage("device_serial_imei_number")), n(2), s((e = i.overviewSummary()) == null ? null : e.serial_number)
    }
}

function ri(t, u) {
    if (t & 1 && (a(0, "div", 15)(1, "div", 36)(2, "div", 27), p(3, "i", 37), a(4, "span", 29), l(5), r()(), a(6, "p", 30), p(7, "app-currency-symbol"), l(8), r()()()), t & 2) {
        let e, i = c();
        n(5), s(i.formatMessage("estimated_cost")), n(3), S(" ", (e = i.overviewSummary()) == null ? null : e.initial_quotation, " ")
    }
}

function li(t, u) {
    t & 1 && (a(0, "div", 25), p(1, "app-print-button", 38), r()), t & 2 && (n(), m("isVisiblePrintButton", !0))
}
var gt = (() => {
    class t {
        constructor() {
            this.formatMessage = b, this.isMobileDevice = _(X).isMobileDevice(), this.isLoggedIn = _(K).isLoggedIn, this.overviewSummary = y(), this.jobActivities = y(), this.trackAnotherRepair = Y(), this.jobCreated = G(() => {
                let e = this.jobActivities();
                return e && e.length ? e.find(i => i.event === I.JOB_CREATED) : null
            }), this.trackRepairMenus = [{
                id: 0,
                text: b("job_details"),
                icon: "fa-thin fa-ticket",
                path: "",
                visible: !0
            }, {
                id: 1,
                text: b("activity_log"),
                icon: "fa-thin fa-clock",
                path: "",
                visible: !0
            }, {
                id: 2,
                text: b("comments"),
                icon: "fa-thin fa-comments",
                path: "",
                visible: !0
            }], this.statusIconTypeList = Re
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-track-repair-summary"]
                ],
                inputs: {
                    overviewSummary: [1, "overviewSummary"],
                    jobActivities: [1, "jobActivities"]
                },
                outputs: {
                    trackAnotherRepair: "trackAnotherRepair"
                },
                standalone: !1,
                decls: 34,
                vars: 18,
                consts: [
                    [1, "container-fluid", "py-4", "px-2", "px-md-4"],
                    [1, "mb-4"],
                    [1, "btn", "btn-link", "text-primary", "p-0", "d-flex", "align-items-center", "gap-2", "text-decoration-none", 3, "click"],
                    [1, "fa-solid", "fa-arrow-left"],
                    [1, "card", "border-0", "shadow-sm", "rounded-3", "mb-4", "overflow-hidden", 2, "background-color", "var(--bg-secondary)"],
                    [1, "card-body", "p-4"],
                    [1, "d-flex", "flex-column", "flex-md-row", "justify-content-between", "align-items-start", "align-items-md-center", "mb-4"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "bg-primary", "bg-opacity-10", "rounded-3", "p-3", "d-flex", "align-items-center", "justify-content-center"],
                    [1, "fa-thin", "fa-ticket", "fa-lg", "text-primary"],
                    [1, "mb-1", "fw-bold", 2, "color", "var(--font-color)"],
                    [1, "mb-0", "small", 2, "color", "var(--primary-text)", "opacity", "0.7"],
                    [1, "mt-3", "mt-md-0"],
                    [3, "iconType", "status"],
                    [1, "row", "g-3"],
                    [1, "col-6", "col-lg-3"],
                    [1, "card", "border-0", "shadow-sm", "rounded-3", "overflow-hidden", 2, "background-color", "var(--bg-secondary)"],
                    [1, "card-body", "p-0"],
                    ["mode", "template", "mobileMenuIcon", "fa-solid fa-search", 3, "tabs", "mobileMenuTitle"],
                    ["content0", "", 1, "p-4"],
                    [3, "jobActivities", "jobCreated", "overviewSummary"],
                    ["content1", "", 1, "p-4"],
                    [3, "jobActivities"],
                    ["content2", "", 1, "p-4"],
                    [3, "overviewSummary"],
                    [1, "mt-4", "text-end"],
                    [1, "rounded-3", "p-3", "h-100", "border-start", "border-4", "border-info", 2, "background-color", "var(--background-color)"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-2"],
                    [1, "fa-thin", "fa-clock", "text-info"],
                    [1, "small", 2, "color", "var(--primary-text)", "opacity", "0.7"],
                    [1, "mb-0", "fw-semibold", "small", 2, "color", "var(--font-color)"],
                    [1, "rounded-3", "p-3", "h-100", "border-start", "border-4", "border-warning", 2, "background-color", "var(--background-color)"],
                    [1, "fa-thin", "fa-calendar", "text-warning"],
                    [1, "rounded-3", "p-3", "h-100", "border-start", "border-4", "border-secondary", 2, "background-color", "var(--background-color)"],
                    [1, "fa-thin", "fa-barcode", "text-secondary"],
                    [1, "mb-0", "fw-semibold", "small", "text-truncate", 2, "color", "var(--font-color)"],
                    [1, "rounded-3", "p-3", "h-100", "border-start", "border-4", "border-success", 2, "background-color", "var(--background-color)"],
                    [1, "fa-thin", "fa-wallet", "text-success"],
                    [3, "isVisiblePrintButton"]
                ],
                template: function(i, o) {
                    if (i & 1 && (a(0, "div", 0)(1, "div", 1)(2, "button", 2), h("click", function() {
                            return o.trackAnotherRepair.emit()
                        }), p(3, "i", 3), a(4, "span"), l(5), r()()(), a(6, "div", 4)(7, "div", 5)(8, "div", 6)(9, "div", 7)(10, "div", 8), p(11, "i", 9), r(), a(12, "div")(13, "h4", 10), l(14), r(), a(15, "p", 11), l(16), r()()(), a(17, "div", 12), p(18, "app-job-status-tag", 13), r()(), a(19, "div", 14), f(20, ni, 9, 5, "div", 15), f(21, oi, 9, 4, "div", 15), f(22, ai, 8, 2, "div", 15), f(23, ri, 9, 2, "div", 15), r()()(), a(24, "div", 16)(25, "div", 17)(26, "app-responsive-tabs", 18)(27, "div", 19), p(28, "app-track-repair-job-details", 20), r(), a(29, "div", 21), p(30, "app-track-repair-activity-log", 22), r(), a(31, "div", 23), p(32, "app-track-repair-comments", 24), r()()()(), f(33, li, 2, 1, "div", 25), r()), i & 2) {
                        let d, x, oe, ae, re, le, se, me;
                        n(5), s(o.formatMessage("track_another_ticket")), n(9), xe("", o.formatMessage("job_sheet_label"), " ", (d = o.overviewSummary()) == null ? null : d.job_number), n(2), s((x = o.overviewSummary()) == null ? null : x.device_information), n(2), m("iconType", o.statusIconTypeList.BADGE_SMALL)("status", (oe = o.overviewSummary()) == null ? null : oe.status), n(2), v((ae = o.jobCreated()) != null && ae.created_at ? 20 : -1), n(), v((re = o.overviewSummary()) != null && re.estimated_delivery ? 21 : -1), n(), v((le = o.overviewSummary()) != null && le.serial_number ? 22 : -1), n(), v((se = o.overviewSummary()) != null && se.initial_quotation ? 23 : -1), n(3), m("tabs", o.trackRepairMenus)("mobileMenuTitle", (me = o.overviewSummary()) == null ? null : me.job_number), n(2), m("jobActivities", o.jobActivities())("jobCreated", o.jobCreated())("overviewSummary", o.overviewSummary()), n(2), m("jobActivities", o.jobActivities()), n(2), m("overviewSummary", o.overviewSummary()), n(), v(o.isLoggedIn() ? 33 : -1)
                    }
                },
                dependencies: [Xe, We, Z, at, vt, _t, bt, $, O],
                encapsulation: 2
            })
        }
    }
    return t
})();

function mi(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "app-track-form", 2), h("isUserVerified", function(o) {
            C(e);
            let d = c();
            return T(d.onUserVerified(o))
        }), r()
    }
    if (t & 2) {
        let e = c();
        m("headerDetails", e.headerDetails)("mainInputDetails", e.mainInputDetails)("items", e.attachmentSourcesDetails)("trackForm", e.trackRepairStatusForm)
    }
}

function ci(t, u) {
    if (t & 1) {
        let e = w();
        a(0, "app-track-repair-summary", 3), h("trackAnotherRepair", function() {
            C(e);
            let o = c();
            return T(o.trackAnotherRepair())
        }), r()
    }
    if (t & 2) {
        let e = c();
        m("overviewSummary", e.overviewSummary)("jobActivities", e.jobActivities)
    }
}
var ht = (() => {
    class t {
        constructor() {
            this.formatMessage = b, this.trackingService = _(R), this.toastNotificationService = _(A), this.isUserVerified = !1, this.headerDetails = {
                headerTitle: "track_your_repair_job_status_heading",
                headerSubTitle: "track_your_repair_job_status_sub_heading"
            }, this.mainInputDetails = {
                controlName: "tracking_number",
                errorMessageForFieldRequired: "ticket_number_is_a_required_field",
                errorMessageForInvalidField: "tracking_number_is_invalid",
                label: "track_your_repair_job_input_field_label",
                id: "track-repair-number",
                placeholder: "enter_your_ticket_number_placeholder"
            }, this.attachmentSourcesDetails = [{
                id: 1,
                title: "job_receipt",
                description: "job_receipt_description",
                icon: "fa-solid fa-receipt",
                visible: !0,
                attachmentSrc: j.IMAGES.JOBSHEET_EXAMPLE
            }, {
                id: 2,
                title: "ticket_receipt_jobsheet_email_receipt",
                description: "ticket_receipt_jobsheet_email_description",
                icon: "fa-solid fa-ticket",
                visible: !0,
                attachmentSrc: j.IMAGES.JOBSHEET_EMAIL_EXAMPLE
            }, {
                id: 3,
                title: "sms_confirmation",
                description: "sms_confirmation_description",
                icon: "fa-solid fa-comment-sms",
                visible: !0,
                attachmentSrc: j.IMAGES.JOBSHEET_EXAMPLE
            }], this.jobActivities = [], this.displayRepairTicketSummary = g(!1)
        }
        ngOnInit() {
            this.trackRepairStatusForm = J.getForm(new J({}))
        }
        onUserVerified(e) {
            this.isUserVerified = !0, this.trackingService.getTrackingDetails(e).subscribe({
                next: i => {
                    let o = i ? .data || i;
                    this.overviewSummary = o, this.trackingService.getTrackingActivities(e).subscribe({
                        next: d => {
                            this.jobActivities = d || [], this.displayRepairTicketSummary.set(!0)
                        },
                        error: d => {
                            console.error("Failed to fetch activities:", d), this.jobActivities = [], this.displayRepairTicketSummary.set(!0)
                        }
                    })
                },
                error: i => {
                    console.error("getTrackingDetails error:", i), this.toastNotificationService.error(i.error ? .message || "Failed to fetch tracking details"), this.isUserVerified = !1
                }
            })
        }
        trackAnotherRepair() {
            window.location.reload()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-track-job-status"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    [3, "headerDetails", "mainInputDetails", "items", "trackForm"],
                    [3, "overviewSummary", "jobActivities"],
                    [3, "isUserVerified", "headerDetails", "mainInputDetails", "items", "trackForm"],
                    [3, "trackAnotherRepair", "overviewSummary", "jobActivities"]
                ],
                template: function(i, o) {
                    i & 1 && (f(0, mi, 1, 4, "app-track-form", 0), f(1, ci, 1, 2, "app-track-repair-summary", 1)), i & 2 && (v(o.displayRepairTicketSummary() ? -1 : 0), n(), v(o.displayRepairTicketSummary() ? 1 : -1))
                },
                dependencies: [ut, gt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var di = [{
        path: "",
        children: [{
            path: "jobStatus",
            component: ht,
            title: "Track Repair Status",
            canActivate: [et]
        }]
    }],
    xt = (() => {
        class t {
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275mod = H({
                    type: t
                })
            }
            static {
                this.\u0275inj = q({
                    imports: [ne.forChild(di), ne]
                })
            }
        }
        return t
    })();
var zn = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275mod = H({
                type: t
            })
        }
        static {
            this.\u0275inj = q({
                imports: [ke, lt, xt, ct]
            })
        }
    }
    return t
})();
export {
    zn as TrackModule
};