import {
    T as o
} from "./chunk-DCKGQUHB.js";
import {
    aa as t,
    ea as r,
    sd as i
} from "./chunk-GOPIAW4V.js";
var m = (() => {
    class e {
        constructor() {
            this.userDeviceService = r(o), this.router = r(i)
        }
        canActivate() {
            return this.userDeviceService.isMobileDevice() ? !0 : this.router.createUrlTree(["/dashboard"])
        }
        static {
            this.\u0275fac = function(c) {
                return new(c || e)
            }
        }
        static {
            this.\u0275prov = t({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
export {
    m as a
};