import {
    b as e,
    i as l
} from "./chunk-62N2W5YM.js";
var v = (f, o) => {
    var t, a, r;
    let s = "40px",
        d = o.direction === "back",
        m = o.leavingEl,
        c = l(o.enteringEl),
        u = c.querySelector("ion-toolbar"),
        n = e();
    if (n.addElement(c).fill("both").beforeRemoveClass("ion-page-invisible"), d ? n.duration(((t = o.duration) !== null && t !== void 0 ? t : 0) || 200).easing("cubic-bezier(0.47,0,0.745,0.715)") : n.duration(((a = o.duration) !== null && a !== void 0 ? a : 0) || 280).easing("cubic-bezier(0.36,0.66,0.04,1)").fromTo("transform", `translateY(${s})`, "translateY(0px)").fromTo("opacity", .01, 1), u) {
        let i = e();
        i.addElement(u), n.addAnimation(i)
    }
    if (m && d) {
        n.duration(((r = o.duration) !== null && r !== void 0 ? r : 0) || 200).easing("cubic-bezier(0.47,0,0.745,0.715)");
        let i = e();
        i.addElement(l(m)).onFinish(b => {
            b === 1 && i.elements.length > 0 && i.elements[0].style.setProperty("display", "none")
        }).fromTo("transform", "translateY(0px)", `translateY(${s})`).fromTo("opacity", 1, 0), n.addAnimation(i)
    }
    return n
};
export {
    v as a
};