import {
    a as Ft
} from "./chunk-CNGJSDOD.js";
import {
    a as Ut,
    b as Bt
} from "./chunk-TIHYCMHH.js";
import {
    c as Lt,
    g as kt
} from "./chunk-WDS5LHZR.js";
import {
    a as Ue
} from "./chunk-HUDETQT5.js";
import {
    a as W
} from "./chunk-KJCCJCIN.js";
import {
    $c as rt,
    Ab as Qe,
    Ag as Rt,
    Be as yt,
    Db as G,
    Hg as wt,
    Ie as St,
    Jb as ze,
    L as Oe,
    Lb as Xe,
    M as j,
    Qb as Ze,
    Rb as et,
    Re as gt,
    Sc as ot,
    Sg as Vt,
    T as x,
    Ta as Fe,
    Td as pt,
    Ud as dt,
    Ue as bt,
    Va as Ge,
    Vb as tt,
    Ve as Tt,
    Y as ke,
    Zc as nt,
    Zd as ut,
    _d as O,
    ba as N,
    bf as Et,
    ca as ee,
    cb as je,
    cd as st,
    db as Ye,
    de as _t,
    g as Te,
    h as Ee,
    ic as ie,
    id as at,
    ih as At,
    jb as We,
    jc as it,
    ka as Be,
    kb as qe,
    lb as te,
    lf as It,
    mf as Mt,
    mg as xt,
    n as Ie,
    ng as Nt,
    pb as Ke,
    pf as oe,
    ph as Dt,
    q as Me,
    qb as $e,
    qd as mt,
    qf as Pt,
    rd as lt,
    rg as Ot,
    sb as Je,
    se as L,
    t as Pe,
    te as ft,
    u as xe,
    ue as Ct,
    vd as ct,
    we as ht,
    yb as He,
    ze as vt
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    $b as Se,
    Ab as Q,
    Ai as le,
    Ak as F,
    Ba as _e,
    Ci as D,
    Di as Le,
    Ec as U,
    Fa as n,
    Fh as f,
    Ib as y,
    Ih as E,
    Jb as V,
    Ka as g,
    Kb as k,
    Na as b,
    Oa as K,
    Pb as fe,
    Pg as Y,
    Qb as Ce,
    Rb as he,
    Sa as $,
    Tc as be,
    U as pe,
    Yb as ve,
    _a as d,
    _b as ye,
    aa as de,
    ba as q,
    bc as z,
    bi as we,
    cc as ge,
    ch as Re,
    da as ue,
    ea as c,
    eb as r,
    ei as Z,
    fb as m,
    gb as s,
    gc as re,
    ha as h,
    hb as _,
    hi as I,
    ia as v,
    ic as se,
    ii as Ve,
    ng as me,
    pd as M,
    qa as w,
    qb as T,
    qd as Ne,
    sb as S,
    sd as B,
    th as X,
    ti as Ae,
    ub as l,
    ui as De,
    vd as ae,
    vi as A,
    xk as a,
    yb as J,
    zb as H,
    zi as P
} from "./chunk-GOPIAW4V.js";
var ti = () => [7, 9];

function ii(t, p) {
    t & 1 && _(0, "app-skeleton-loader", 0), t & 2 && r("rows", 8)("columns", 3)
}

function oi(t, p) {
    t & 1 && (m(0, "h3", 7), y(1, "Create"), s())
}

function ni(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-save-cancel-footer", 31), S("cancelClick", function() {
            h(e);
            let i = l(3);
            return v(i.cancel())
        }), s()
    }
    if (t & 2) {
        let e = l(3);
        r("isOnPopup", !1)("isVisibleHr", !1)("saveText", e.customerId ? "common_save" : "create_button")
    }
}

function ri(t, p) {
    if (t & 1 && $(0, ni, 1, 3, "app-save-cancel-footer", 30), t & 2) {
        let e = l(2);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.CUSTOMER_WRITE)
    }
}

function si(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-dx-outline-button", 34), S("onClickEvent", function() {
            h(e);
            let i = l(4);
            return v(i.setEditMode())
        }), s()
    }
}

function ai(t, p) {
    if (t & 1 && $(0, si, 1, 0, "app-dx-outline-button", 33), t & 2) {
        let e = l(3);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.CUSTOMER_WRITE)
    }
}

function mi(t, p) {
    if (t & 1 && d(0, ai, 1, 1, "app-dx-outline-button", 32), t & 2) {
        let e = l(2);
        u(e.userPermissionList.includes(e.PERMISSION_LIST.CUSTOMER_WRITE) ? 0 : -1)
    }
}

function li(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-server-error", 35), S("onConflictResolved", function(i) {
            h(e);
            let C = l(2);
            return v(C.onConflictResolved(i))
        }), s()
    }
    if (t & 2) {
        let e = l(2);
        r("errorResponse", e.errorResponse)("service", e.customerService)("entityName", e.ENTITIES.CUSTOMER.name)("entityDisplayName", e.formatMessage("common_customer"))
    }
}

function ci(t, p) {
    if (t & 1 && (m(0, "app-control-container", 12), _(1, "app-user-type-dropdown", 36), s()), t & 2) {
        let e = l(2);
        r("errorMsg", e.formatMessage("user_customer_type_required"))("label", e.formatMessage("user_customer_customer_type")), n(), r("formControl", e.form.controls.role_id)("isEditMode", e.isEditMode)
    }
}

function pi(t, p) {
    if (t & 1 && (m(0, "app-control-container", 19)(1, "app-restricted-content", 16), _(2, "app-email", 37), s()()), t & 2) {
        let e = l(2);
        r("errorMsg", e.formatMessage("common_email_required"))("label", e.formatMessage("common_email_id")), n(), r("applyLock", !1)("permission", e.customerId ? e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION : e.PERMISSION_LIST.CUSTOMER_WRITE), n(), r("entity", e.ENTITIES.CUSTOMER)("formControl", e.form.controls.email)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("typeId", e.USER_TYPES.CUSTOMER)
    }
}

function di(t, p) {
    if (t & 1 && (m(0, "app-control-container", 22), _(1, "dx-select-box", 38), s()), t & 2) {
        let e = l(2);
        r("label", e.formatMessage("user_customer_source")), n(), r("items", e.sources)("placeholder", e.formatMessage("user_select_source"))("searchEnabled", !0)
    }
}

function ui(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-control-container", 23)(1, "app-customer-dropdown", 39), S("itemClick", function(i) {
            h(e);
            let C = l(2);
            return v(C.onReferredSelect(i))
        }), s()()
    }
    if (t & 2) {
        let e, o = l(2);
        r("errorMsg", o.formatMessage("common_error_messages_referred_by_required"))("label", o.formatMessage("user_customer_referred_by")), n(), r("customerId", o.form.getRawValue().id ? (e = o.form.getRawValue()) == null ? null : e.referred_by_id : null)("formControl", o.form.controls.referred_by_id)("isEditMode", o.isEditMode)("isVisibleAddAction", !1)("showCrateButton", !0)
    }
}

function _i(t, p) {
    if (t & 1 && (m(0, "app-control-container", 40), _(1, "app-gdpr-checkbox", 41), s()), t & 2) {
        let e = l(3);
        r("errorMsg", e.formatMessage("user_customer_gdpr_require"))
    }
}

function fi(t, p) {
    if (t & 1 && d(0, _i, 2, 1, "app-control-container", 40), t & 2) {
        let e = l(2);
        u(e.isEmployee ? 0 : -1)
    }
}

function Ci(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-save-cancel-footer", 31), S("cancelClick", function() {
            h(e);
            let i = l(3);
            return v(i.cancel())
        }), s()
    }
    if (t & 2) {
        let e = l(3);
        r("isOnPopup", !0)("isVisibleHr", !1)("saveText", e.customerId ? "common_save" : "create_button")
    }
}

function hi(t, p) {
    if (t & 1 && (m(0, "div", 29), $(1, Ci, 1, 3, "app-save-cancel-footer", 30), s()), t & 2) {
        let e = l(2);
        n(), r("ngxPermissionsOnly", e.PERMISSION_LIST.CUSTOMER_WRITE)
    }
}

function vi(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "form", 3), S("ngSubmit", function() {
            h(e);
            let i = l();
            return v(i.createCustomer())
        }), m(1, "div", 4)(2, "div", 5)(3, "div", 6), d(4, oi, 2, 0, "h3", 7), d(5, ri, 1, 1, "app-save-cancel-footer", 8), d(6, mi, 1, 1), s(), d(7, li, 1, 4, "app-server-error", 9), s()(), _(8, "app-section-title", 10), m(9, "div", 11), d(10, ci, 2, 4, "app-control-container", 12), m(11, "app-control-container", 13), _(12, "dx-text-box", 14), s(), m(13, "app-control-container", 15)(14, "app-restricted-content", 16), _(15, "app-mobile-number", 17), s(), _(16, "app-error", 18)(17, "app-error", 18), s(), d(18, pi, 3, 9, "app-control-container", 19), m(19, "app-control-container", 20)(20, "app-restricted-content", 16), _(21, "app-phone-number", 21)(22, "app-error", 18), s()(), d(23, di, 2, 4, "app-control-container", 22), d(24, ui, 2, 7, "app-control-container", 23), d(25, fi, 1, 1), m(26, "app-control-container", 24), _(27, "dx-text-box", 25), s(), _(28, "app-show-custom-fields", 26), s(), m(29, "div", 27), _(30, "app-address", 28), s(), d(31, hi, 2, 1, "div", 29), s()
    }
    if (t & 2) {
        let e = l();
        r("formGroup", e.form), n(3), r("ngClass", e.customerId || e.isMobileDevice && e.customerId ? "justify-content-end" : "justify-content-between"), n(), u(e.customerId ? -1 : 4), n(), u(!e.isMobileDevice && e.isEditMode ? 5 : -1), n(), u(e.isEditMode ? -1 : 6), n(), u(e.errorResponse ? 7 : -1), n(), r("title", "common_customer_information"), n(2), u(e.customerId ? -1 : 10), n(), r("errorMsg", e.formatMessage("common_error_messages_customer_name_required"))("label", (ye(46, ti).includes(e.form.getRawValue().role_id), e.formatMessage("user_customer_name"))), n(), r("placeholder", e.formatMessage("employee_name_placeholder")), n(), r("errorMsg", e.formatMessage("common_mobile_required"))("label", e.formatMessage("common_mobile_number")), n(), r("applyLock", !1)("permission", e.customerId ? e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION : e.PERMISSION_LIST.CUSTOMER_WRITE), n(), r("entity", e.ENTITIES.CUSTOMER)("entityId", e.customerId)("formControl", e.form.controls.mobile_number)("form", e.form)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("typeId", e.USER_TYPES.CUSTOMER), n(), r("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile")), n(), r("displayError", e.form.touched && e.form.get("mobile_number").touched && e.form.get("mobile_number").touched && e.form.errors && e.form.errors.atLeastOne)("errorMsg", e.formatMessage("common_mobile_or_email_required")), n(), u(e.form.getRawValue().id ? -1 : 18), n(), r("label", e.formatMessage("common_phone_number")), n(), r("applyLock", !1)("permission", e.customerId ? e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION : e.PERMISSION_LIST.CUSTOMER_WRITE), n(), r("formControl", e.form.controls.phone_number)("isEditMode", e.isEditMode), n(), r("displayError", e.form.get("phone_number").invalid && e.form.get("phone_number").touched && e.form.get("phone_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_mobile_invalid_chars")), n(), u(e.isEmployee ? 23 : -1), n(), u(e.isEmployee ? 24 : -1), n(), u(e.isGdprComplianceSettingEnable ? 25 : -1), n(), r("errorMsg", e.formatMessage("common_tax_number_required"))("label", e.formatMessage("common_tax_number")), n(), r("placeholder", e.formatMessage("user_customer_tax_number_type")), n(), r("formType", e.FORM_TYPE_LIST.CUSTOMER)("form", e.form)("hasColumn", 4), n(2), r("parentForm", e.form)("isReadOnly", !e.isEditMode), n(), u(e.isMobileDevice && e.isEditMode ? 31 : -1)
    }
}

function yi(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-send-notification", 42), S("sendNotificationClose", function() {
            h(e);
            let i = l();
            return v(i.sendNotificationCloseSave())
        })("sendNotificationSave", function() {
            h(e);
            let i = l();
            return v(i.sendNotificationCloseSave())
        }), s()
    }
    if (t & 2) {
        let e = l();
        r("entityObj", e.customer)("entity", e.ENTITIES.CUSTOMER)("isVisiblePopup", e.isVisibleNotificationPopup())("isVisibleSendButton", !1)
    }
}
var ce = (() => {
    class t {
        constructor(e, o) {
            this.customerService = e, this.loaderService = o, this.formatMessage = a, this.ENTITIES = I, this.SETTINGS = X, this.generalSettingDataService = c(G), this.formService = c(Ke), this.router = c(B), this.dataService = c(at), this.userSessionService = c(N), this.activatedRouter = c(M), this.isMobileDevice = c(x).isMobileDevice(), this.toastNotificationService = c(ee), this.USER_TYPES = Z, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.isGdprComplianceSettingEnable = this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.GENERAL_SETTINGS.ENABLE_GDPR_COMPLIANCE), this.errorResponse = null, this.isSaving = !1, this.isEditMode = !1, this.isVisibleNotificationPopup = w(!1), this.customerId = null, this.sources = [], this.PERMISSION_LIST = f, this.FORM_TYPE_LIST = Re
        }
        ngOnInit() {
            this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.dataService.getLookups().subscribe({
                next: e => {
                    this.sources = e.job_sources
                },
                error: e => {
                    console.log(e)
                }
            }), this.customerId ? (this.loaderService.show(), this.customerService.getById(this.customerId).subscribe({
                next: e => {
                    this.customer = new L(e), this.form = L.getForm(this.customer), this.setFormReadOnly()
                },
                error: e => {
                    console.log(e)
                }
            }).add(() => this.loaderService.hide())) : (this.customer = new L({}), this.form = L.getForm(this.customer), this.isEditMode = !0, this.form.patchValue({
                address: {
                    city: this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.CITY) ? ? null,
                    state: this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.STATE) ? ? null
                }
            }))
        }
        onReferredSelect(e) {
            this.form.patchValue({
                referred_by_id: e.id
            })
        }
        createCustomer() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, this.loaderService.show(), (this.customerId ? this.customerService.update(this.form.value) : this.customerService.create(this.form.value)).subscribe({
                next: o => {
                    this.activatedRouter.snapshot.parent.paramMap.has("customer_id") ? (this.customer = new L(o), this.toastNotificationService.success("notification_update_customer_success"), this.setFormReadOnly()) : (this.customerId = o.id, this.customer = o, this.isVisibleNotificationPopup = w(!0), this.toastNotificationService.success("notification_add_customer_success"))
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => {
                this.isSaving = !1, this.loaderService.hide()
            })) : this.formService.validateFormFields(this.form)
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable()
        }
        cancel() {
            this.customer ? .id || this.router.navigate(["/customers/list"]), this.form = L.getForm(this.customer), this.isEditMode = !1
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        sendNotificationCloseSave() {
            this.isVisibleNotificationPopup.set(!1), this.router.navigateByUrl(`/customers/${this.customerId}/profiles`)
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.createCustomer()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(A), g(F))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-customer-detail"]
                ],
                standalone: !1,
                decls: 3,
                vars: 3,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    [3, "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "d-flex", 3, "ngClass"],
                    [1, "float-start"],
                    ["cancelBtnId", "customer-detail-cancel", "saveBtnId", "customer-detail-save", 3, "isOnPopup", "isVisibleHr", "saveText"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    ["id", "customer-detail-title", 1, "mb-3", 3, "title"],
                    [1, "row"],
                    ["name", "role_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", "id", "customer-detail-user-name", 3, "placeholder"],
                    ["name", "mobile_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    [3, "applyLock", "permission"],
                    ["id", "customer-detail-mobile", 3, "entity", "entityId", "formControl", "form", "isEditMode", "isUniqueValidation", "typeId"],
                    [3, "displayError", "errorMsg"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "phone_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "label"],
                    ["id", "customer-detail-phone-number", 3, "formControl", "isEditMode"],
                    ["name", "source_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "label"],
                    ["name", "referred_by_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "gst_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "gst_number", "id", "customer-detail-gst", 3, "placeholder"],
                    [1, "row", "d-flex", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    [1, "mt-5"],
                    ["id", "customer-detail-address", 3, "parentForm", "isReadOnly"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    ["cancelBtnId", "customer-detail-cancel", "saveBtnId", "customer-detail-save", 3, "isOnPopup", "isVisibleHr", "saveText", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "customer-detail-cancel", "saveBtnId", "customer-detail-save", 3, "cancelClick", "isOnPopup", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", "id", "customer-detail-edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", "id", "customer-detail-edit", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", "id", "customer-detail-edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"],
                    ["id", "customer-detail-user-type", 3, "formControl", "isEditMode"],
                    ["id", "customer-detail-email", 3, "entity", "formControl", "isEditMode", "isUniqueValidation", "typeId"],
                    ["displayExpr", "name", "formControlName", "source_id", "id", "customer-job-sources", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "isVisibleAddAction", "showCrateButton"],
                    ["name", "is_gdpr_compliance", 1, "col-sm-4", "col-md-4", "col-lg-4", "mt-5", 3, "errorMsg"],
                    ["formControlName", "is_gdpr_compliance"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"]
                ],
                template: function(o, i) {
                    o & 1 && (d(0, ii, 1, 2, "app-skeleton-loader", 0), d(1, vi, 32, 47, "form", 1), d(2, yi, 1, 4, "app-send-notification", 2)), o & 2 && (u(!i.form && i.customerId ? 0 : -1), n(), u(i.form ? 1 : -1), n(), u(i.isVisibleNotificationPopup() ? 2 : -1))
                },
                dependencies: [U, $e, lt, Je, je, vt, st, dt, ct, ie, qe, yt, ut, Be, ft, Ct, pt, ht, Fe, Ge, Ie, Te, Ee, Me, xe, Pe, Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Si = (t, p, e, o) => [t, p, e, o],
    gi = (t, p, e) => ({
        icon: "dx-icon-group",
        title: t,
        description: p,
        primaryButtonText: "empty_state_customer_primary_button",
        secondaryButtonText: "import_title",
        quickTips: e,
        tutorialUrl: "https://www.youtube.com/watch?v=q0SWYrlETrA",
        tutorialVisible: !0,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function bi(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-forget-user-popup", 6), S("closePopup", function() {
            h(e);
            let i = l();
            return v(i.onForgetUser())
        }), s()
    }
    if (t & 2) {
        let e = l();
        r("isPopupVisible", e.currentContextMenuAction === e.CUSTOMER_CONTEXT_MENU_LIST.FORGET_USER)("userId", e.currentCustomer.id)("userName", e.currentCustomer.name)
    }
}

function Ti(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-send-notification", 7), S("sendNotificationClose", function() {
            h(e);
            let i = l();
            return v(i.sendNotificationClose())
        })("sendNotificationSave", function() {
            h(e);
            let i = l();
            return v(i.sendNotificationSave())
        }), s()
    }
    if (t & 2) {
        let e = l();
        r("entityObj", e.currentCustomer)("entity", e.ENTITIES.CUSTOMER)("isVisiblePopup", e.isVisibleNotificationPopup())("isVisibleSendButton", !1)
    }
}

function Ei(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-payment-reminder-popup", 8), S("sendNotificationClose", function() {
            h(e);
            let i = l();
            return v(i.sendPaymentReminderNotificationClose())
        })("sendNotificationSave", function() {
            h(e);
            let i = l();
            return v(i.sendPaymentNotificationSave())
        }), s()
    }
    if (t & 2) {
        let e = l();
        r("customer", e.currentCustomer)("entityObj", e.currentCustomer)("entity", e.ENTITIES.CUSTOMER)("isVisiblePopup", e.isVisiblePaymentReminderPopup())("isVisibleSendButton", !1)
    }
}

function Ii(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-confirmation-popup", 9), S("confirmActionCallback", function() {
            h(e);
            let i = l();
            return v(i.updateUserActivation())
        })("rejectActionCallback", function() {
            h(e);
            let i = l();
            return v(i.onCancelUserActivationToggle())
        }), s()
    }
    if (t & 2) {
        let e = l();
        r("confirmButtonText", e.isAccountActivated ? "deactivate" : "activate")("confirmationMessage", e.formatMessage(e.activationSwitchConfirmationMessage))("isSaving", e.isSavingActivationSetting)("rejectButtonText", "cancel")
    }
}

function Mi(t, p) {
    if (t & 1) {
        let e = T();
        m(0, "app-archive-delete-popup", 10), he("isVisibleChange", function(i) {
            h(e);
            let C = l();
            return Ce(C.isVisibleArchiveDeletePopup, i) || (C.isVisibleArchiveDeletePopup = i), v(i)
        }), S("onSuccess", function(i) {
            h(e);
            let C = l();
            return v(C.handleArchiveDeleteSuccess(i))
        })("onCancel", function() {
            h(e);
            let i = l();
            return v(i.onCloseContextMenuOption())
        }), s()
    }
    if (t & 2) {
        let e = l();
        fe("isVisible", e.isVisibleArchiveDeletePopup), r("service", e.service)("entity", e.currentCustomer)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var qt = (() => {
    class t {
        get hasTenantCustomers() {
            return (this.tenantService.config() ? .entity_counts ? .customers || 0) > 0
        }
        constructor(e) {
            this.service = e, this.formatMessage = a, this.generalSettingDataService = c(G), this.router = c(B), this.importService = c(rt), this.userSessionService = c(N), this.isMobileDevice = c(x).isMobileDevice(), this.toastNotificationService = c(ee), this.tenantService = c(te), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = I, this.entity = I.CUSTOMER, this.currentContextMenuAction = null, this.isForgetUserPopupVisible = !1, this.isVisibleUserActiveConfirmation = w(!1), this.isAccountActivated = !0, this.activationSwitchConfirmationMessage = null, this.isSavingActivationSetting = !1, this.isVisibleArchiveDeletePopup = !1, this.archiveDeleteMode = w("delete"), this.isVisibleNotificationPopup = w(!1), this.isVisiblePaymentReminderPopup = w(!1), this.customerContextMenu = [], this.columns = [{
                dataField: "name",
                caption: a("user_customer"),
                width: 160,
                cellTemplate: "userTemplate",
                allowSorting: !0,
                sortOrder: "asc"
            }, {
                dataField: "roles[0].display_name",
                caption: a("common_type"),
                hidingPriority: 13,
                allowSorting: !1,
                visible: !0
            }, {
                dataField: "mobile_number",
                caption: a("common_mobile"),
                width: 150,
                hidingPriority: 10,
                cellTemplate: "phoneTemplate",
                allowSorting: !1,
                visible: this.userPermissionList.includes(f.CUSTOMER_VIEW_CONTACT_INFORMATION),
                showInColumnChooser: this.userPermissionList.includes(f.CUSTOMER_VIEW_CONTACT_INFORMATION)
            }, {
                dataField: "payment_received",
                caption: a("payment_received"),
                width: 160,
                hidingPriority: 8,
                visible: this.isEmployee && this.userPermissionList.includes(f.CUSTOMER_VIEW_PAYMENT_INFORMATION),
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "payment_remaining",
                caption: a("payment_remaining"),
                hidingPriority: 9,
                visible: this.isEmployee && this.userPermissionList.includes(f.CUSTOMER_VIEW_PAYMENT_INFORMATION),
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "phone_number",
                caption: a("common_phone_number"),
                cellTemplate: "phoneTemplate",
                width: 150,
                hidingPriority: 7,
                visible: this.userPermissionList.includes(f.CUSTOMER_VIEW_CONTACT_INFORMATION),
                showInColumnChooser: this.userPermissionList.includes(f.CUSTOMER_VIEW_CONTACT_INFORMATION),
                allowSorting: !1
            }, {
                dataField: "email",
                caption: a("common_email"),
                hidingPriority: 3,
                cellTemplate: "emailTemplate",
                allowSorting: !0,
                showInColumnChooser: this.userPermissionList.includes(f.CUSTOMER_VIEW_CONTACT_INFORMATION),
                visible: this.userPermissionList.includes(f.CUSTOMER_VIEW_CONTACT_INFORMATION)
            }, {
                dataField: "gst_number",
                caption: a("common_tax_number"),
                hidingPriority: 6,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "email_verified_at",
                caption: a("common_verified"),
                hidingPriority: 0,
                cellTemplate: "verifiedTemplate",
                alignment: "center",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "last_login",
                caption: a("common_last_login"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                width: 150,
                visible: !0,
                allowSorting: !0
            }, {
                dataField: "updated_at",
                caption: a("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "created_at",
                caption: a("common_created_on"),
                hidingPriority: 4,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0,
                width: 130
            }, {
                dataField: "source.name",
                caption: a("customer_source_placeholder"),
                hidingPriority: 11,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "is_gdpr_compliance",
                caption: a("common_gdpr_compliance"),
                hidingPriority: 12,
                width: 90,
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                visible: !1
            }, {
                dataField: "is_active",
                caption: a("is_active"),
                cellTemplate: "booleanTemplate",
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.CUSTOMER_CONTEXT_MENU_LIST = E
        }
        ngOnInit() {
            this.customerContextMenu = [{
                name: E.FORGET_USER,
                icon: D.SHIELD_CHECK.light,
                visible: this.generalSettingDataService.getGeneralSettingByKey(X.GENERAL_SETTINGS.ENABLE_GDPR_COMPLIANCE),
                locale_key: a("customer_action_forget_user")
            }, {
                name: E.SEND_ACTIVATION_LINK,
                icon: le.SEND.light,
                visible: !0,
                locale_key: a("send_activation_link")
            }, {
                name: E.SEND_PAYMENT_OVERDUE_REMINDER,
                icon: P.NOTIFICATION.light,
                visible: !0,
                locale_key: a("customer_action_send_payment_overdue_reminder")
            }, {
                name: E.DEACTIVATE_ACTIVATE_ACCOUNT,
                icon: D.USER_TIMES.light,
                visible: !0,
                locale_key: a("customer_action_deactivate_activate_account")
            }, {
                name: E.DELETE_CUSTOMER,
                icon: le.DELETE.light,
                visible: !0,
                locale_key: a("customer_action_delete_account")
            }]
        }
        create() {
            this.router.navigate(["/customers/add"])
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentCustomer = e.entity, this.isAccountActivated = e.entity.is_active, this.currentContextMenuAction === E.DEACTIVATE_ACTIVATE_ACCOUNT && (this.currentContextMenuAction = this.isAccountActivated ? E.DEACTIVATE_ACCOUNT : E.ACTIVATE_ACCOUNT), this.currentContextMenuAction === E.FORGET_USER && (this.currentCustomer.is_gdpr_compliance ? this.isForgetUserPopupVisible = !0 : this.toastNotificationService.warning("notification_customer_gdpr_non_compliant_error")), this.currentContextMenuAction === E.SEND_ACTIVATION_LINK && this.isVisibleNotificationPopup.set(!0), this.currentContextMenuAction === E.SEND_PAYMENT_OVERDUE_REMINDER && (this.currentCustomer.payment_remaining <= 0 ? this.toastNotificationService.success("notification_customer_no_payment_left_info") : this.isVisiblePaymentReminderPopup.set(!0)), (this.currentContextMenuAction === E.DEACTIVATE_ACCOUNT || this.currentContextMenuAction === E.ACTIVATE_ACCOUNT) && (this.isVisibleUserActiveConfirmation.set(!0), this.activationSwitchConfirmationMessage = this.isAccountActivated ? "deactivate_user_and_prevent_login" : "activate_employee_and_grant_access"), this.currentContextMenuAction === E.DELETE_CUSTOMER && (this.archiveDeleteMode.set(this.currentCustomer.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0)
        }
        handleArchiveDeleteSuccess(e) {
            this.isVisibleArchiveDeletePopup = !1, this.currentContextMenuAction = null, this.currentCustomer = null, window.location.reload()
        }
        updateUserActivation() {
            this.isSavingActivationSetting = !0, this.service.toggleActivation(this.currentCustomer ? .id).subscribe({
                next: e => {
                    this.isAccountActivated = e.is_active, this.toastNotificationService.success("activation_updated_success"), this.isVisibleUserActiveConfirmation.set(!1)
                },
                error: () => {
                    this.toastNotificationService.error("activation_update_error")
                }
            }).add(() => {
                this.isSavingActivationSetting = !1, setTimeout(() => {
                    window.location.reload()
                }, 1500)
            })
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentCustomer = null
        }
        onForgetUser() {
            this.isForgetUserPopupVisible = !1, this.router.navigate([`/customers/${this.currentCustomer.id}/profiles`])
        }
        sendNotificationSave() {
            this.isVisibleNotificationPopup.set(!1)
        }
        sendNotificationClose() {
            this.isVisibleNotificationPopup.set(!1)
        }
        sendPaymentNotificationSave() {
            this.isVisiblePaymentReminderPopup.set(!1)
        }
        sendPaymentReminderNotificationClose() {
            this.isVisiblePaymentReminderPopup.set(!1)
        }
        onCancelUserActivationToggle() {
            this.isVisibleUserActiveConfirmation.set(!1)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(A))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-customer-list"]
                ],
                standalone: !1,
                decls: 6,
                vars: 24,
                consts: [
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "columns", "contextMenuItems", "entity", "isVisibleEditAction", "isVisibleDeleteAction", "isVisibleExportAction", "searchPanelPlaceholderText", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "isPopupVisible", "userId", "userName"],
                    [3, "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "customer", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "confirmButtonText", "confirmationMessage", "isSaving", "rejectButtonText"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "closePopup", "isPopupVisible", "userId", "userName"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "sendNotificationClose", "sendNotificationSave", "customer", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage", "isSaving", "rejectButtonText"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, "app-data-grid", 0), S("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(ne) {
                        return i.onContextMenuItemClick(ne)
                    })("dataGridAddNewClick", function() {
                        return i.create()
                    }), s(), d(1, bi, 1, 3, "app-forget-user-popup", 1), d(2, Ti, 1, 4, "app-send-notification", 2), d(3, Ei, 1, 5, "app-payment-reminder-popup", 3), d(4, Ii, 1, 4, "app-confirmation-popup", 4), d(5, Mi, 1, 6, "app-archive-delete-popup", 5)), o & 2 && (r("columns", i.columns)("contextMenuItems", i.customerContextMenu)("entity", i.entity)("isVisibleEditAction", !1)("isVisibleDeleteAction", !1)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("searchPanelPlaceholderText", "search_panel_customer_placeholder")("service", i.service)("hasTenantData", i.hasTenantCustomers)("emptyStateConfig", z(20, gi, i.formatMessage("empty_state_customer_title"), i.formatMessage("empty_state_customer_description"), ge(15, Si, i.formatMessage("empty_state_customer_tip_1"), i.formatMessage("empty_state_customer_tip_2"), i.formatMessage("empty_state_customer_tip_3"), i.formatMessage("empty_state_customer_import_tip")))), n(), u(i.isForgetUserPopupVisible && i.currentContextMenuAction === i.CUSTOMER_CONTEXT_MENU_LIST.FORGET_USER ? 1 : -1), n(), u(i.isVisibleNotificationPopup() ? 2 : -1), n(), u(i.isVisiblePaymentReminderPopup() ? 3 : -1), n(), u(i.isVisibleUserActiveConfirmation() ? 4 : -1), n(), u(i.isVisibleArchiveDeletePopup ? 5 : -1))
                },
                dependencies: [Ye, mt, O, ie, wt, Vt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Pi(t, p) {
    if (t & 1) {
        let e = T();
        _(0, "app-user-profile-info", 0), m(1, "div", 1)(2, "app-responsive-tabs", 2), S("tabChange", function(i) {
            h(e);
            let C = l();
            return v(C.selectTab(i))
        }), s()()
    }
    if (t & 2) {
        let e = l();
        r("entity", e.entity)("isOnProfilePage", !0)("typeId", e.USER_TYPES.CUSTOMER)("user", e.customer), n(2), r("tabs", e.tabs)("selectedIndex", e.selectedTabIndex)("mobileMenuTitle", e.customer == null ? null : e.customer.name)
    }
}
var Kt = (() => {
    class t {
        constructor(e, o, i, C) {
            this.jobService = e, this.paymentService = o, this.customerService = i, this.loaderService = C, this.formatMessage = a, this.router = c(B), this.userSessionService = c(N), this.tenantService = c(te), this.activatedRouter = c(M), this.plan = this.tenantService.plan(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.entity = I.CUSTOMER, this.USER_TYPES = Z, this.stateList = [], this.cityList = [], this.customer = null, this.customerId = null, this.selectedTabIndex = 0, this.errorResponse = null, this.isEditMode = !1, this.tabs = []
        }
        ngOnInit() {
            this.paramSubscription = this.activatedRouter.paramMap.pipe(pe(e => (this.customerId = e.get("customer_id"), this.buildTabs(), this.customer = null, this.loaderService.show(), this.customerId ? (this.selectedTabIndex = this.activatedRouter.firstChild ? .snapshot.data.tab_index, this.customerService.getById(this.customerId)) : this.customerService.me()))).subscribe({
                next: e => {
                    this.handleUserResponse(e), this.loaderService.hide()
                },
                error: e => {
                    console.log(e), this.loaderService.hide()
                }
            })
        }
        ngOnDestroy() {
            this.paramSubscription ? .unsubscribe()
        }
        buildTabs() {
            this.tabs = [{
                id: 0,
                text: a("profile"),
                path: `/customers/${this.customerId}/profiles`,
                icon: D.USER_CIRCLE.light,
                visible: !0
            }, {
                id: 1,
                text: a("contacts"),
                path: `/customers/${this.customerId}/contacts`,
                icon: D.ID_CARD.light,
                disabled: [Y.LITE].includes(this.plan),
                visible: !0
            }, {
                id: 2,
                text: a("jobs"),
                path: `/customers/${this.customerId}/jobs`,
                icon: P.JOB.light,
                visible: !0
            }, {
                id: 3,
                text: a("sale"),
                path: `/customers/${this.customerId}/sales`,
                icon: P.SALE.light,
                visible: !0
            }, {
                id: 4,
                text: a("referred_list"),
                path: `/customers/${this.customerId}/referredBy`,
                icon: P.CUSTOMER.light,
                visible: !0
            }, {
                id: 5,
                text: a("payment"),
                path: `/customers/${this.customerId}/payments`,
                icon: Le.PAYMENT_TYPE.light,
                visible: this.userPermissionList.includes(f.CUSTOMER_VIEW_PAYMENT_TAB)
            }, {
                id: 6,
                text: a("pickup_drops"),
                path: `/customers/${this.customerId}/pickUps`,
                icon: P.PICKUP_DROP.light,
                disabled: [Y.LITE].includes(this.plan),
                visible: this.userPermissionList.includes(f.PICKUP_DROP_LIST)
            }, {
                id: 7,
                text: a("private_notes"),
                path: `/customers/${this.customerId}/notes`,
                icon: D.STICKY_NOTE.light,
                visible: this.isEmployee
            }, {
                id: 8,
                text: "Bulk Payments",
                path: `/customers/${this.customerId}/bulkPayments`,
                icon: P.BILLING.light,
                disabled: [Y.LITE].includes(this.plan),
                visible: this.userPermissionList.includes(f.CUSTOMER_VIEW_PAYMENT_TAB)
            }, {
                id: 9,
                text: a("invoices"),
                path: `/customers/${this.customerId}/invoices`,
                icon: P.INVOICE.light,
                visible: !0
            }, {
                id: 10,
                text: a("notification_preferences"),
                path: `/customers/${this.customerId}/notificationPreferences`,
                icon: P.NOTIFICATION.light,
                disabled: [Y.LITE].includes(this.plan),
                visible: !0
            }, {
                id: 11,
                text: a("messages"),
                path: `/customers/${this.customerId}/messages`,
                icon: D.MESSAGES.light,
                visible: this.isEmployee
            }, {
                id: 12,
                text: a("customer_ledger"),
                path: `/customers/${this.customerId}/ledger`,
                icon: P.LEDGER.light,
                visible: this.userPermissionList.includes(f.LEDGER_LIST)
            }]
        }
        handleUserResponse(e) {
            this.customer = e, this.customerId = e.id
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(nt), g(bt), g(A), g(F))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-customer-profile"]
                ],
                standalone: !1,
                features: [ve([{
                    provide: It,
                    useExisting: A
                }])],
                decls: 1,
                vars: 1,
                consts: [
                    [3, "entity", "isOnProfilePage", "typeId", "user"],
                    [1, "my-1"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-user", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle"]
                ],
                template: function(o, i) {
                    o & 1 && d(0, Pi, 3, 7), o & 2 && u(i.customer != null && i.customer.id ? 0 : -1)
                },
                dependencies: [Mt, Ot],
                encapsulation: 2
            })
        }
    }
    return t
})();
var $t = (() => {
    class t extends Ae {
        constructor(e) {
            super(e, me), this.api = e, this.endpoint = me
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(ue(De))
            }
        }
        static {
            this.\u0275prov = de({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Ni = t => ({
        customer_id: t
    }),
    Jt = (() => {
        class t {
            constructor(e) {
                this.referredByList = e, this.formatMessage = a, this.activatedRouter = c(M), this.isCreate = !1, this.customerId = null, this.entity = I.REFERRED_BY_LIST, this.columns = [{
                    dataField: "entity",
                    caption: a("sales_jobs_list"),
                    width: 130,
                    cellTemplate: "referredByTemplate",
                    allowSorting: !1
                }, {
                    dataField: "entity_type",
                    caption: a("common_type"),
                    width: 130,
                    allowSorting: !1
                }, {
                    dataField: "updated_at",
                    caption: a("common_updated_on"),
                    alignment: "center",
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !0
                }, {
                    dataField: "created_at",
                    caption: a("common_created_on"),
                    alignment: "center",
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !0
                }]
            }
            ngOnInit() {
                this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id")
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)(g($t))
                }
            }
            static {
                this.\u0275cmp = b({
                    type: t,
                    selectors: [
                        ["app-job-sale-list-referred-by-customer"]
                    ],
                    viewQuery: function(o, i) {
                        if (o & 1 && J(O, 5), o & 2) {
                            let C;
                            H(C = Q()) && (i.dataGrid = C.first)
                        }
                    },
                    standalone: !1,
                    decls: 1,
                    vars: 7,
                    consts: [
                        [3, "additionalParams", "columns", "entity", "isVisibleReportDropdown", "service"]
                    ],
                    template: function(o, i) {
                        o & 1 && _(0, "app-data-grid", 0), o & 2 && r("additionalParams", Se(5, Ni, i.customerId))("columns", i.columns)("entity", i.entity)("isVisibleReportDropdown", !0)("service", i.referredByList)
                    },
                    dependencies: [O],
                    encapsulation: 2
                })
            }
        }
        return t
    })();

function Ri(t, p) {
    if (t & 1 && _(0, "app-send-whats-app-btn", 5), t & 2) {
        let e = l();
        r("entityId", e.bulkPayment == null ? null : e.bulkPayment.id)("entityName", e.ENTITIES.BULK_PAYMENT.name)
    }
}

function wi(t, p) {
    if (t & 1 && (m(0, "div", 15)(1, "span", 16), y(2), s(), m(3, "span", 17), y(4, ":"), s(), y(5), s()), t & 2) {
        let e = l(2);
        n(2), V(e.formatMessage("payment_mode")), n(3), k("", e.bulkPayment.payment_type.name, " ")
    }
}

function Vi(t, p) {
    if (t & 1 && (m(0, "div", 15)(1, "span", 16), y(2), s(), m(3, "span", 17), y(4, ":"), s(), y(5), s()), t & 2) {
        let e = l(2);
        n(2), V(e.bulkPayment.cheque_number ? e.formatMessage("payment_cheque_number") : e.formatMessage("common_transaction_id")), n(3), k("", e.bulkPayment.cheque_number ? e.bulkPayment.cheque_number : e.bulkPayment.transaction_id, " ")
    }
}

function Ai(t, p) {
    if (t & 1 && (m(0, "div", 15)(1, "span", 16), y(2), s(), m(3, "span", 17), y(4, ":"), s(), y(5), s()), t & 2) {
        let e = l(2);
        n(2), V(e.formatMessage("received_by")), n(3), k("", e.bulkPayment.created_by.name, " ")
    }
}

function Di(t, p) {
    if (t & 1 && (m(0, "div", 3)(1, "span", 16), y(2), s(), m(3, "span", 17), y(4, ":"), s(), _(5, "span", 21), re(6, "safe"), s()), t & 2) {
        let e = l(2);
        n(2), V(e.formatMessage("comment")), n(3), r("innerHTML", se(6, 2, e.bulkPayment.comment, "html"), _e)
    }
}

function Li(t, p) {
    if (t & 1 && (m(0, "div", 8)(1, "div", 2)(2, "div", 3)(3, "div", 2)(4, "div", 3), _(5, "app-invoice-header", 9)(6, "app-invoice-title", 10)(7, "app-invoice-customer-detail", 11), m(8, "div", 12)(9, "div", 3)(10, "h5", 13), y(11), s(), m(12, "div", 14), d(13, wi, 6, 2, "div", 15), d(14, Vi, 6, 2, "div", 15), m(15, "div", 15)(16, "span", 16), y(17), s(), m(18, "span", 17), y(19, ":"), s(), _(20, "app-currency-symbol"), y(21), s(), m(22, "div", 15)(23, "span", 16), y(24), s(), m(25, "span", 17), y(26, ":"), s(), y(27), re(28, "dateFormat"), s(), d(29, Ai, 6, 2, "div", 15), d(30, Di, 7, 5, "div", 3), s()()(), m(31, "div", 18)(32, "div", 3), _(33, "app-payment-entity-print-table", 19)(34, "app-payment-summary-table", 20), s()()()()()()()), t & 2) {
        let e = l();
        n(5), r("account", e.account)("qrCode", (e.bulkPayment == null ? null : e.bulkPayment.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.bulkPayment == null ? null : e.bulkPayment.qr_code)), n(), r("dateTime", e.bulkPayment == null ? null : e.bulkPayment.created_at)("title", e.formatMessage("bulk_payment_receipt")), n(), r("userId", e.bulkPayment.user_id), n(4), V(e.formatMessage("payment_information")), n(2), u(e.bulkPayment.payment_type.name ? 13 : -1), n(), u(e.bulkPayment.transaction_id ? 14 : -1), n(3), V(e.formatMessage("amount")), n(4), k(" ", e.bulkPayment.amount, " "), n(3), V(e.formatMessage("received_on")), n(3), k("", se(28, 17, e.bulkPayment.created_at, "datetime"), " "), n(2), u(e.bulkPayment.created_by.name ? 29 : -1), n(), u(e.bulkPayment.comment ? 30 : -1), n(3), r("bulkPayment", e.bulkPayment)("columns", e.paymentEntityTableColumns), n(), r("bulkPayment", e.bulkPayment)
    }
}
var Ht = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.loaderService = o, this.formatMessage = a, this.ENTITIES = I, this.configService = c(ke), this.userSessionService = c(N), this.activatedRouter = c(M), this.isMobileDevice = c(x).isMobileDevice(), this.generalSettingDataService = c(G), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.entityType = this.ENTITIES.BULK_PAYMENT.name, this.isEditMode = !0, this.dateTime = new Date, this.summaryRows = we, this.paymentEntityTableColumns = [{
                dataField: "paymentable.paymentable",
                caption: a("entity_number")
            }, {
                dataField: "paymentable_type",
                caption: a("entity_type")
            }, {
                dataField: "amount",
                caption: a("amount_paid"),
                dataType: "number"
            }], this.PERMISSION_LIST = f, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(Ve.PRINT_SETTINGS) ? ? Qe.getEmptyObject()
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("bulk_payment_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("bulk_payment_id");
                this.loaderService.show(), this.service.getById(e).subscribe({
                    next: o => {
                        this.configService.appConfig$.subscribe({
                            next: i => {
                                this.account = i
                            },
                            error: i => {
                                console.log("error ", i)
                            }
                        }), this.bulkPayment = o
                    },
                    error: o => {
                        console.log("error ", o)
                    }
                }).add(() => {
                    this.loaderService.hide()
                })
            }
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(oe), g(F))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-bulk-payment-receipt"]
                ],
                standalone: !1,
                decls: 9,
                vars: 8,
                consts: [
                    [1, "container-fluid", "px-1", 3, "ngClass"],
                    [1, "container-fluid", "mb-2", "px-1"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [1, "mx-1", 3, "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["id", "print-section", 1, "container-fluid", "px-1"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "row", "ps-3"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "row", "mt-2"],
                    [3, "bulkPayment", "columns"],
                    [3, "bulkPayment"],
                    [1, "d-inline-block", 3, "innerHTML"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4), d(5, Ri, 1, 2, "app-send-whats-app-btn", 5), _(6, "app-print-button", 6)(7, "app-share-btn", 7), s()()()(), d(8, Li, 35, 20, "div", 8), s()), o & 2 && (r("ngClass", i.isMobileDevice ? "vh-100" : ""), n(5), u(i.isEmployee && i.userPermissionList.includes(i.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION) ? 5 : -1), n(), r("entityId", i.bulkPayment == null ? null : i.bulkPayment.id)("entityName", i.ENTITIES.BULK_PAYMENT.name)("isVisiblePrintButton", !!(i.bulkPayment != null && i.bulkPayment.id)), n(), r("entityId", i.bulkPayment == null ? null : i.bulkPayment.id)("entityType", i.ENTITIES.BULK_PAYMENT.name), n(), u(i.bulkPayment ? 8 : -1))
                },
                dependencies: [U, ze, Ze, et, We, tt, xt, Nt, it, ot, Xe, He],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var ki = (t, p, e) => ({
        customer_id: t,
        assigned_only: p,
        employee_id: e
    }),
    Qt = (() => {
        class t {
            constructor(e) {
                this.service = e, this.formatMessage = a, this.assignedOnly = !1, this.userSessionService = c(N), this.activatedRouter = c(M), this.isMobileDevice = c(x).isMobileDevice(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.isCreate = !1, this.employeeId = null, this.customerId = null, this.isVisibleTaskPopup = !1, this.entity = I.BULK_PAYMENT, this.isVisiblePopup = !1, this.columns = [{
                    dataField: "id",
                    caption: a("common_id"),
                    allowSorting: !0
                }, {
                    dataField: "amount",
                    caption: a("payment_received"),
                    visible: this.isEmployee && this.userPermissionList.includes(f.CUSTOMER_VIEW_PAYMENT_INFORMATION),
                    allowSorting: !1,
                    format: {
                        type: "fixedPoint",
                        precision: 2
                    }
                }, {
                    dataField: "user",
                    caption: a("common_customer"),
                    cellTemplate: "userTemplate",
                    hidingPriority: 1
                }, {
                    dataField: "created_by",
                    caption: a("common_created_by"),
                    cellTemplate: "employeeTemplate"
                }, {
                    dataField: "comment",
                    caption: a("common_comment"),
                    cellTemplate: "commentTemplate"
                }, {
                    dataField: "created_at",
                    caption: a("common_created_on"),
                    cellTemplate: "dateTimeTemplate",
                    alignment: "center",
                    allowSorting: !0,
                    hidingPriority: 0
                }, {
                    dataField: "updated_at",
                    caption: a("common_updated_on"),
                    alignment: "center",
                    cellTemplate: "dateTimeTemplate",
                    visible: !1,
                    allowSorting: !0
                }]
            }
            ngOnInit() {
                this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id")
            }
            onTaskSave() {
                this.isCreate = !1, this.bulkPayment = null, this.dataGrid.getData()
            }
            create() {
                this.isVisibleTaskPopup = !0, this.isCreate = !0
            }
            edit(e) {
                this.isCreate = !1, this.bulkPayment = e, this.isVisibleTaskPopup = !0
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)(g(oe))
                }
            }
            static {
                this.\u0275cmp = b({
                    type: t,
                    selectors: [
                        ["app-bulk-payments-list"]
                    ],
                    viewQuery: function(o, i) {
                        if (o & 1 && J(O, 5), o & 2) {
                            let C;
                            H(C = Q()) && (i.dataGrid = C.first)
                        }
                    },
                    inputs: {
                        assignedOnly: "assignedOnly"
                    },
                    standalone: !1,
                    decls: 1,
                    vars: 11,
                    consts: [
                        [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleExportAction", "service"]
                    ],
                    template: function(o, i) {
                        o & 1 && (m(0, "app-data-grid", 0), S("dataGridAddNewClick", function() {
                            return i.create()
                        })("dataGridEditClick", function(ne) {
                            return i.edit(ne)
                        }), s()), o & 2 && r("additionalParams", z(7, ki, i.customerId, i.assignedOnly, i.employeeId))("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("service", i.service)
                    },
                    dependencies: [O],
                    encapsulation: 2
                })
            }
        }
        return t
    })();
var zt = (() => {
    class t {
        constructor() {
            this.formatMessage = a, this.isMobileDevice = c(x).isMobileDevice()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-customer"]
                ],
                standalone: !1,
                decls: 2,
                vars: 1,
                consts: [
                    [1, "container-fluid", 3, "ngClass"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, "div", 0), _(1, "router-outlet"), s()), o & 2 && r("ngClass", i.isMobileDevice ? "mb-5" : "")
                },
                dependencies: [U, Ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Xt = (() => {
    class t {
        constructor() {
            this.activatedRoute = c(M)
        }
        ngOnInit() {
            this.customerId = +this.activatedRoute.parent.snapshot.paramMap.get("customer_id")
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-customer-ledger-tab"]
                ],
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "customerId"]
                ],
                template: function(o, i) {
                    o & 1 && _(0, "app-customer-ledger-view", 0), o & 2 && r("customerId", i.customerId)
                },
                dependencies: [_t],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ui = [{
        path: "",
        component: zt,
        title: "Bytephase-",
        children: [{
            path: "list",
            component: qt,
            canActivate: [W, j],
            data: {
                permissions: {
                    only: [f.CUSTOMER_LIST]
                }
            },
            title: "BytePhase Dealers/Customers "
        }, {
            path: "add",
            component: ce,
            canActivate: [W, j],
            data: {
                permissions: {
                    only: [f.CUSTOMER_WRITE]
                }
            },
            title: "BytePhase Add Dealers/Customers"
        }, {
            path: "addPayment/:id",
            component: Pt,
            canActivate: [W],
            title: "BytePhase Dealers/Customers Add Payment"
        }, {
            path: "bulkPaymentReceipt/:bulk_payment_id",
            component: Ht,
            canActivate: [W],
            title: "BytePhase Bulk Payments"
        }, {
            path: ":customer_id",
            component: Kt,
            data: {
                customer_id: null
            },
            children: [{
                path: "profiles",
                component: ce,
                data: {
                    tab_index: 0
                },
                title: "BytePhase Dealers/Customers Profile"
            }, {
                path: "contacts",
                component: St,
                data: {
                    tab_index: 1
                },
                title: "BytePhase Contacts"
            }, {
                path: "jobs",
                component: Lt,
                data: {
                    tab_index: 2
                },
                title: "BytePhase Jobs/Services"
            }, {
                path: "sales",
                component: Ut,
                data: {
                    tab_index: 3
                },
                title: "BytePhase Sales"
            }, {
                path: "referredBy",
                component: Jt,
                data: {
                    tab_index: 4
                },
                title: "BytePhase Referred By"
            }, {
                path: "payments",
                component: Tt,
                data: {
                    tab_index: 5
                },
                title: "BytePhase Payments"
            }, {
                path: "pickUps",
                component: Et,
                data: {
                    tab_index: 6
                },
                title: "BytePhase Pick Ups"
            }, {
                path: "notes",
                component: gt,
                data: {
                    notable_type: I.USER.name,
                    tab_index: 7
                },
                title: "BytePhase Notes"
            }, {
                path: "bulkPayments",
                component: Qt,
                data: {
                    tab_index: 8
                },
                title: "BytePhase Bulk Payments"
            }, {
                path: "invoices",
                component: Ft,
                canActivate: [j, Ue],
                data: {
                    tab_index: 9,
                    entity: I.JOB_INVOICE,
                    permissions: {
                        only: [f.JOB_INVOICE_LIST]
                    }
                },
                pathMatch: "full",
                title: "BytePhase Invoices"
            }, {
                path: "notificationPreferences",
                component: Rt,
                data: {
                    tab_index: 10
                },
                title: "BytePhase | User Notification Preferences"
            }, {
                path: "messages",
                component: At,
                data: {
                    tab_index: 11
                },
                title: "BytePhase | Customer Messages"
            }, {
                path: "ledger",
                component: Xt,
                canActivate: [j],
                data: {
                    tab_index: 12,
                    permissions: {
                        only: [f.LEDGER_LIST]
                    }
                },
                title: "BytePhase | Customer Ledger"
            }]
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    Zt = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = K({
                    type: t
                })
            }
            static {
                this.\u0275inj = q({
                    imports: [ae.forChild(Ui), ae]
                })
            }
        }
        return t
    })();
var qr = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = K({
                type: t
            })
        }
        static {
            this.\u0275inj = q({
                imports: [be, Dt, Zt, kt, Bt]
            })
        }
    }
    return t
})();
export {
    qr as a
};