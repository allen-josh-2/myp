var ee = class {
        constructor() {
            this.m = new Map
        }
        reset(s) {
            this.m = new Map(Object.entries(s))
        }
        get(s, i) {
            let c = this.m.get(s);
            return c !== void 0 ? c : i
        }
        getBoolean(s, i = !1) {
            let c = this.m.get(s);
            return c === void 0 ? i : typeof c == "string" ? c === "true" : !!c
        }
        getNumber(s, i) {
            let c = parseFloat(this.m.get(s));
            return isNaN(c) ? i !== void 0 ? i : NaN : c
        }
        set(s, i) {
            this.m.set(s, i)
        }
    },
    xe = new ee;
var T;
(function(t) {
    t.OFF = "OFF", t.ERROR = "ERROR", t.WARN = "WARN"
})(T || (T = {}));
var Ce = (t, ...s) => {
    let i = xe.get("logLevel", T.ERROR);
    if ([T.ERROR, T.WARN].includes(i)) return console.error(`[Ionic Error]: ${t}`, ...s)
};
var Re = (t => (t.Undefined = "undefined", t.Null = "null", t.String = "string", t.Number = "number", t.SpecialNumber = "number", t.Boolean = "boolean", t.BigInt = "bigint", t))(Re || {}),
    Te = (t => (t.Array = "array", t.Date = "date", t.Map = "map", t.Object = "object", t.RegularExpression = "regexp", t.Set = "set", t.Channel = "channel", t.Symbol = "symbol", t))(Te || {});
var Le = (t, s) => (0, console.error)(t, s);
var L = typeof window < "u" ? window : {},
    Me = L.HTMLElement || class {},
    te = {
        i: 0,
        u: "",
        jmp: t => t(),
        raf: t => requestAnimationFrame(t),
        ael: (t, s, i, c) => t.addEventListener(s, i, c),
        rel: (t, s, i, c) => t.removeEventListener(s, i, c),
        ce: (t, s) => new CustomEvent(t, s)
    },
    We = (() => {
        var t;
        let s = !1;
        try {
            (t = L.document) == null || t.addEventListener("e", null, Object.defineProperty({}, "passive", {
                get() {
                    s = !0
                }
            }))
        } catch (i) {}
        return s
    })(),
    $e = (() => {
        try {
            return !!L.document.adoptedStyleSheets && (new CSSStyleSheet, typeof new CSSStyleSheet().replaceSync == "function")
        } catch (t) {}
        return !1
    })(),
    De = !!$e && !!L.document && Object.getOwnPropertyDescriptor(L.document.adoptedStyleSheets, "length").writable,
    ne = !1,
    se = [],
    Ee = [],
    _e = (t, s) => i => {
        t.push(i), ne || (ne = !0, s && 4 & te.i ? ke(oe) : te.raf(oe))
    },
    Se = t => {
        for (let s = 0; s < t.length; s++) try {
            t[s](performance.now())
        } catch (i) {
            Le(i)
        }
        t.length = 0
    },
    oe = () => {
        Se(se), Se(Ee), (ne = se.length > 0) && te.raf(oe)
    },
    ke = t => Promise.resolve(void 0).then(t),
    Ie = _e(se, !1),
    Fe = _e(Ee, !0);
var Pe = "Capture",
    qe = new RegExp(Pe + "$");
var re = typeof window < "u" ? window : void 0;
var ie, le = (t, s, i) => {
        let c = s.startsWith("animation") ? (y = t, ie === void 0 && (ie = y.style.animationName === void 0 && y.style.webkitAnimationName !== void 0 ? "-webkit-" : ""), ie) : "";
        var y;
        t.style.setProperty(c + s, i)
    },
    W = (t = [], s) => {
        if (s !== void 0) {
            let i = Array.isArray(s) ? s : [s];
            return [...t, ...i]
        }
        return t
    },
    Ze = t => {
        let s, i, c, y, D, I, d, w, A, S, o, u = [],
            F = [],
            q = [],
            b = !1,
            H = {},
            U = [],
            z = [],
            K = {},
            C = 0,
            $ = !1,
            k = !1,
            E = !0,
            j = !1,
            O = !0,
            P = !1,
            ae = t,
            J = [],
            x = [],
            V = [],
            v = [],
            h = [],
            ce = [],
            de = [],
            ue = [],
            he = [],
            fe = [],
            g = [],
            Ae = typeof AnimationEffect == "function" || re !== void 0 && typeof re.AnimationEffect == "function",
            m = typeof Element == "function" && typeof Element.prototype.animate == "function" && Ae,
            pe = () => g,
            me = (e, n) => {
                let r = n.findIndex(l => l.c === e);
                r > -1 && n.splice(r, 1)
            },
            Y = (e, n) => ((n ? .oneTimeCallback ? x : J).push({
                c: e,
                o: n
            }), o),
            ge = () => {
                m && (g.forEach(e => {
                    e.cancel()
                }), g.length = 0)
            },
            je = () => {
                ce.forEach(e => {
                    e ? .parentNode && e.parentNode.removeChild(e)
                }), ce.length = 0
            },
            Z = () => D !== void 0 ? D : d ? d.getFill() : "both",
            B = () => w !== void 0 ? w : I !== void 0 ? I : d ? d.getDirection() : "normal",
            X = () => $ ? "linear" : c !== void 0 ? c : d ? d.getEasing() : "linear",
            _ = () => k ? 0 : A !== void 0 ? A : i !== void 0 ? i : d ? d.getDuration() : 0,
            G = () => y !== void 0 ? y : d ? d.getIterations() : 1,
            Q = () => S !== void 0 ? S : s !== void 0 ? s : d ? d.getDelay() : 0,
            M = () => {
                C !== 0 && (C--, C === 0 && ((() => {
                    he.forEach(a => a()), fe.forEach(a => a());
                    let e = E ? 1 : 0,
                        n = U,
                        r = z,
                        l = K;
                    v.forEach(a => {
                        let p = a.classList;
                        n.forEach(N => p.add(N)), r.forEach(N => p.remove(N));
                        for (let N in l) l.hasOwnProperty(N) && le(a, N, l[N])
                    }), A = void 0, w = void 0, S = void 0, J.forEach(a => a.c(e, o)), x.forEach(a => a.c(e, o)), x.length = 0, O = !0, E && (j = !0), E = !0
                })(), d && d.animationFinish()))
            },
            ve = () => {
                (() => {
                    de.forEach(l => l()), ue.forEach(l => l());
                    let e = F,
                        n = q,
                        r = H;
                    v.forEach(l => {
                        let a = l.classList;
                        e.forEach(p => a.add(p)), n.forEach(p => a.remove(p));
                        for (let p in r) r.hasOwnProperty(p) && le(l, p, r[p])
                    })
                })(), u.length > 0 && m && (v.forEach(e => {
                    let n = e.animate(u, {
                        id: ae,
                        delay: Q(),
                        duration: _(),
                        easing: X(),
                        iterations: G(),
                        fill: Z(),
                        direction: B()
                    });
                    n.pause(), g.push(n)
                }), g.length > 0 && (g[0].onfinish = () => {
                    M()
                })), b = !0
            },
            R = e => {
                e = Math.min(Math.max(e, 0), .9999), m && g.forEach(n => {
                    n.currentTime = n.effect.getComputedTiming().delay + _() * e, n.pause()
                })
            },
            ye = e => {
                g.forEach(n => {
                    n.effect.updateTiming({
                        delay: Q(),
                        duration: _(),
                        easing: X(),
                        iterations: G(),
                        fill: Z(),
                        direction: B()
                    })
                }), e !== void 0 && R(e)
            },
            f = (e = !1, n = !0, r) => (e && h.forEach(l => {
                l.update(e, n, r)
            }), m && ye(r), o),
            be = () => {
                b && (m ? g.forEach(e => {
                    e.pause()
                }) : v.forEach(e => {
                    le(e, "animation-play-state", "paused")
                }), P = !0)
            },
            Ne = e => new Promise(n => {
                e ? .sync && (k = !0, Y(() => k = !1, {
                    oneTimeCallback: !0
                })), b || ve(), j && (m && (R(0), ye()), j = !1), O && (C = h.length + 1, O = !1);
                let r = () => {
                        me(l, x), n()
                    },
                    l = () => {
                        me(r, V), n()
                    };
                Y(l, {
                    oneTimeCallback: !0
                }), V.push({
                    c: r,
                    o: {
                        oneTimeCallback: !0
                    }
                }), h.forEach(a => {
                    a.play()
                }), m ? (g.forEach(a => {
                    a.play()
                }), u.length !== 0 && v.length !== 0 || M()) : M(), P = !1
            }),
            we = (e, n) => {
                let r = u[0];
                return r === void 0 || r.offset !== void 0 && r.offset !== 0 ? u = [{
                    offset: 0,
                    [e]: n
                }, ...u] : r[e] = n, o
            };
        return o = {
            parentAnimation: d,
            elements: v,
            childAnimations: h,
            id: ae,
            animationFinish: M,
            from: we,
            to: (e, n) => {
                let r = u[u.length - 1];
                return r === void 0 || r.offset !== void 0 && r.offset !== 1 ? u = [...u, {
                    offset: 1,
                    [e]: n
                }] : r[e] = n, o
            },
            fromTo: (e, n, r) => we(e, n).to(e, r),
            parent: e => (d = e, o),
            play: Ne,
            pause: () => (h.forEach(e => {
                e.pause()
            }), be(), o),
            stop: () => {
                h.forEach(e => {
                    e.stop()
                }), b && (ge(), b = !1), $ = !1, k = !1, O = !0, w = void 0, A = void 0, S = void 0, C = 0, j = !1, E = !0, P = !1, V.forEach(e => e.c(0, o)), V.length = 0
            },
            destroy: e => (h.forEach(n => {
                n.destroy(e)
            }), (n => {
                ge(), n && je()
            })(e), v.length = 0, h.length = 0, u.length = 0, J.length = 0, x.length = 0, b = !1, O = !0, o),
            keyframes: e => {
                let n = u !== e;
                return u = e, n && (r => {
                    m && pe().forEach(l => {
                        let a = l.effect;
                        if (a.setKeyframes) a.setKeyframes(r);
                        else {
                            let p = new KeyframeEffect(a.target, r, a.getTiming());
                            l.effect = p
                        }
                    })
                })(u), o
            },
            addAnimation: e => {
                if (e != null)
                    if (Array.isArray(e))
                        for (let n of e) n.parent(o), h.push(n);
                    else e.parent(o), h.push(e);
                return o
            },
            addElement: e => {
                if (e != null)
                    if (e.nodeType === 1) v.push(e);
                    else if (e.length >= 0)
                    for (let n = 0; n < e.length; n++) v.push(e[n]);
                else Ce("createAnimation - Invalid addElement value.");
                return o
            },
            update: f,
            fill: e => (D = e, f(!0), o),
            direction: e => (I = e, f(!0), o),
            iterations: e => (y = e, f(!0), o),
            duration: e => (m || e !== 0 || (e = 1), i = e, f(!0), o),
            easing: e => (c = e, f(!0), o),
            delay: e => (s = e, f(!0), o),
            getWebAnimations: pe,
            getKeyframes: () => u,
            getFill: Z,
            getDirection: B,
            getDelay: Q,
            getIterations: G,
            getEasing: X,
            getDuration: _,
            afterAddRead: e => (he.push(e), o),
            afterAddWrite: e => (fe.push(e), o),
            afterClearStyles: (e = []) => {
                for (let n of e) K[n] = "";
                return o
            },
            afterStyles: (e = {}) => (K = e, o),
            afterRemoveClass: e => (z = W(z, e), o),
            afterAddClass: e => (U = W(U, e), o),
            beforeAddRead: e => (de.push(e), o),
            beforeAddWrite: e => (ue.push(e), o),
            beforeClearStyles: (e = []) => {
                for (let n of e) H[n] = "";
                return o
            },
            beforeStyles: (e = {}) => (H = e, o),
            beforeRemoveClass: e => (q = W(q, e), o),
            beforeAddClass: e => (F = W(F, e), o),
            onFinish: Y,
            isRunning: () => C !== 0 && !P,
            progressStart: (e = !1, n) => (h.forEach(r => {
                r.progressStart(e, n)
            }), be(), $ = e, b || ve(), f(!1, !0, n), o),
            progressStep: e => (h.forEach(n => {
                n.progressStep(e)
            }), R(e), o),
            progressEnd: (e, n, r) => ($ = !1, h.forEach(l => {
                l.progressEnd(e, n, r)
            }), r !== void 0 && (A = r), j = !1, E = !0, e === 0 ? (w = B() === "reverse" ? "normal" : "reverse", w === "reverse" && (E = !1), m ? (f(), R(1 - n)) : (S = (1 - n) * _() * -1, f(!1, !1))) : e === 1 && (m ? (f(), R(n)) : (S = n * _() * -1, f(!1, !1))), e === void 0 || d || Ne(), o)
        }
    };
var Ge = (t, s) => {
    t.componentOnReady ? t.componentOnReady().then(i => s(i)) : Ve(() => s(t))
};
var Ve = t => typeof __zone_symbol__requestAnimationFrame == "function" ? __zone_symbol__requestAnimationFrame(t) : typeof requestAnimationFrame == "function" ? requestAnimationFrame(t) : setTimeout(t);
var et = "ionViewWillEnter",
    tt = "ionViewDidEnter",
    nt = "ionViewWillLeave",
    st = "ionViewDidLeave",
    ot = "ionViewWillUnload";
var rt = t => t.classList.contains("ion-page") ? t : t.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs") || t;
export {
    xe as a, Ze as b, Ge as c, et as d, tt as e, nt as f, st as g, ot as h, rt as i
};