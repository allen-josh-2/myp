import {
    a as W
} from "./chunk-CNGJSDOD.js";
import {
    a as U
} from "./chunk-HUDETQT5.js";
import {
    a as x
} from "./chunk-KJCCJCIN.js";
import {
    M as T,
    Mf as Q,
    T as v,
    Tf as H,
    Ve as J,
    _d as I,
    ba as q,
    jg as K,
    lb as S,
    ph as z,
    rg as X
} from "./chunk-DCKGQUHB.js";
import {
    $a as D,
    Ab as F,
    Fa as h,
    Fh as s,
    Ka as k,
    Na as C,
    Oa as f,
    Pg as L,
    Rh as N,
    Tc as R,
    _a as w,
    ba as _,
    bc as b,
    ea as a,
    eb as c,
    fb as m,
    gb as p,
    ha as P,
    hi as r,
    ia as M,
    pd as G,
    qb as B,
    sb as u,
    sd as Y,
    ub as y,
    vd as E,
    xk as n,
    yb as V,
    zb as O,
    zi as j
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var Z = (() => {
    class t {
        constructor() {
            this.formatMessage = n, this.ENTITIES = r, this.moduleDataService = a(K), this.router = a(Y), this.userSessionService = a(q), this.tenantService = a(S), this.activatedRouter = a(G), this.isMobileDevice = a(v).isMobileDevice(), this.plan = this.tenantService.plan(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.selectedTabIndex = this.activatedRouter.snapshot.firstChild.data.tab_index ? ? 0, this.ENTITY_ICONS = j, this.tabs = [{
                id: 0,
                text: n("invoices"),
                path: "/billings/invoices",
                attrId: "invoices",
                visible: this.userPermissionList.includes(s.JOB_INVOICE_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.JOB_INVOICE.name)
            }, {
                id: 1,
                text: n("payment"),
                path: "/billings/payments",
                attrId: "payments",
                visible: this.userPermissionList.includes(s.BILLING_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.PAYMENT.name)
            }, {
                id: 2,
                text: n("collect_payments"),
                path: "/billings/collectPayments",
                attrId: "collect-payments",
                visible: this.tenantService.isIndia() && this.userPermissionList.includes(s.BILLING_LIST) && [L.STANDARD, L.ENTERPRISE].includes(this.plan) && this.moduleDataService.isModuleActive(this.ENTITIES.COLLECT_PAYMENT.name)
            }, {
                id: 3,
                text: n("accounting"),
                path: "/billings/accounting",
                attrId: "accounting",
                visible: this.isEmployee && this.userPermissionList.includes(s.LEDGER_LIST)
            }]
        }
        selectTab(i) {
            this.selectedTabIndex = i.itemIndex
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = C({
                type: t,
                selectors: [
                    ["app-billing"]
                ],
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    [1, "container-fluid"],
                    ["mode", "route", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "contentContainerClass", "mobileMenuTitle", "mobileMenuIcon"]
                ],
                template: function(o, e) {
                    o & 1 && (m(0, "div", 0)(1, "app-responsive-tabs", 1), u("tabChange", function(g) {
                        return e.selectTab(g)
                    }), p()()), o & 2 && (h(), c("tabs", e.tabs)("selectedIndex", e.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("contentContainerClass", e.isMobileDevice ? "mb-5" : "")("mobileMenuTitle", e.formatMessage("billing"))("mobileMenuIcon", e.ENTITY_ICONS.BILLING.solid))
                },
                dependencies: [X],
                encapsulation: 2
            })
        }
    }
    return t
})();
var et = (t, d, i) => [t, d, i],
    it = (t, d, i) => ({
        icon: "dx-icon-money",
        title: t,
        description: d,
        quickTips: i,
        quickTipsVisible: !0,
        primaryButtonVisible: !1
    });

function nt(t, d) {
    if (t & 1) {
        let i = B();
        m(0, "app-check-collect-payment-status", 2), u("checkPaymentStatusPopupCloseClick", function() {
            P(i);
            let e = y();
            return M(e.onCloseContextMenuOption())
        })("checkPaymentStatusPopupSaveClick", function(e) {
            P(i);
            let l = y();
            return M(l.onPopupSaveAction(e))
        }), p()
    }
    if (t & 2) {
        let i = y();
        c("collectPayment", i.currentCollectPayment)("isVisiblePopup", i.isVisiblePopup)
    }
}
var $ = (() => {
    class t {
        get hasTenantInvoices() {
            return (this.tenantService.config() ? .entity_counts ? .invoices || 0) > 0
        }
        constructor(i) {
            this.service = i, this.formatMessage = n, this.isMobileDevice = a(v).isMobileDevice(), this.tenantService = a(S), this.entity = r.COLLECT_PAYMENT, this.currentContextMenuAction = null, this.isVisiblePopup = !1, this.collectPaymentContextMenu = [], this.columns = [{
                dataField: "entity",
                caption: n("payment_against"),
                width: this.isMobileDevice ? 110 : 130,
                cellTemplate: "collectPaymentLinkTemplate",
                allowSorting: !1
            }, {
                dataField: "amount",
                caption: n("common_amount"),
                width: this.isMobileDevice ? 100 : 130,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "user",
                caption: n("user_label"),
                cellTemplate: "employeeTemplate",
                hidingPriority: 8,
                allowSorting: !1
            }, {
                dataField: "transaction_id",
                caption: n("common_transaction_id"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "payment_status",
                caption: n("payment_status"),
                cellTemplate: "collectPaymentStatus",
                hidingPriority: 7,
                allowSorting: !1
            }, {
                dataField: "response_message",
                caption: n("response_message"),
                hidingPriority: 5,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "comment",
                caption: n("comments"),
                hidingPriority: 4,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "request_status",
                caption: n("request_status"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "cancelled_status",
                caption: n("cancelled_status"),
                hidingPriority: 2,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: n("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: n("common_created_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        ngOnInit() {
            this.collectPaymentContextMenu = [{
                name: N.CHECK_STATUS,
                icon: "fa-thin fa-money-check-alt",
                visible: !0,
                locale_key: n("common_check_status")
            }]
        }
        onPopupSaveAction(i) {
            this.onCloseContextMenuOption()
        }
        onContextMenuItemClick(i) {
            this.currentContextMenuAction = i.action, this.currentCollectPayment = i.entity, this.isVisiblePopup = !0, this.currentContextMenuAction, N.CHECK_STATUS
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentCollectPayment = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(k(Q))
            }
        }
        static {
            this.\u0275cmp = C({
                type: t,
                selectors: [
                    ["app-collect-payment-transaction-list"]
                ],
                viewQuery: function(o, e) {
                    if (o & 1 && V(I, 5), o & 2) {
                        let l;
                        O(l = F()) && (e.dataGrid = l.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 17,
                consts: [
                    ["dataGridId", "tabAndGridContainer", 3, "contextMenuItemCancelClick", "contextMenuItemClick", "columns", "contextMenuItems", "entity", "isVisibleAddAction", "isVisibleExportAction", "isVisibleReportDropdown", "service", "emptyStateConfig"],
                    [3, "collectPayment", "isVisiblePopup"],
                    [3, "checkPaymentStatusPopupCloseClick", "checkPaymentStatusPopupSaveClick", "collectPayment", "isVisiblePopup"]
                ],
                template: function(o, e) {
                    o & 1 && (m(0, "app-data-grid", 0), u("contextMenuItemCancelClick", function() {
                        return e.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(g) {
                        return e.onContextMenuItemClick(g)
                    }), p(), w(1, nt, 1, 2, "app-check-collect-payment-status", 1)), o & 2 && (c("columns", e.columns)("contextMenuItems", e.collectPaymentContextMenu)("entity", e.entity)("isVisibleAddAction", !1)("isVisibleExportAction", !1)("isVisibleReportDropdown", !0)("service", e.service)("emptyStateConfig", b(13, it, e.formatMessage("empty_state_billing_payment_title"), e.formatMessage("empty_state_billing_payment_description"), b(9, et, e.formatMessage("empty_state_billing_payment_tip_1"), e.formatMessage("empty_state_billing_payment_tip_2"), e.formatMessage("empty_state_billing_payment_tip_3")))), h(), D(e.isVisiblePopup && e.currentCollectPayment ? 1 : -1))
                },
                dependencies: [I, H],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ot = [{
        path: "",
        component: Z,
        title: "",
        children: [{
            path: "invoices",
            component: W,
            canActivate: [T, U],
            data: {
                entity: r.JOB_INVOICE,
                tab_index: 0,
                permissions: {
                    only: [s.JOB_INVOICE_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Invoices"
        }, {
            path: "payments",
            component: J,
            canActivate: [x, T],
            data: {
                entity: r.PAYMENT_LIST,
                tab_index: 1,
                permissions: {
                    only: [s.BILLING_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Payments"
        }, {
            path: "collectPayments",
            component: $,
            pathMatch: "full",
            title: "BytePhase Transaction List",
            data: {
                tab_index: 2
            }
        }, {
            path: "accounting",
            loadChildren: () =>
                import ("./chunk-BJQCKWLU.js").then(t => t.AccountingModule),
            canActivate: [x, T],
            data: {
                tab_index: 3,
                permissions: {
                    only: [s.LEDGER_LIST]
                }
            },
            title: "BytePhase Accounting"
        }, {
            path: "",
            redirectTo: "invoices",
            pathMatch: "full"
        }]
    }],
    tt = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = f({
                    type: t
                })
            }
            static {
                this.\u0275inj = _({
                    imports: [E.forChild(ot), E]
                })
            }
        }
        return t
    })();
var Ht = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = f({
                type: t
            })
        }
        static {
            this.\u0275inj = _({
                imports: [R, tt, z]
            })
        }
    }
    return t
})();
export {
    Ht as BillingModule
};