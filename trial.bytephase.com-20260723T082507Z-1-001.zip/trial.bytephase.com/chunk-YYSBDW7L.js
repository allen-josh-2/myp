import {
    $ as R,
    Lf as de,
    Me as ce,
    Ne as le,
    Rc as se,
    T as D,
    ah as me,
    c as Z,
    g as ee,
    ha as ne,
    if as pe,
    lb as ae,
    m as te,
    ph as ue,
    qc as re
} from "./chunk-DCKGQUHB.js";
import {
    $a as h,
    $b as Q,
    $h as oe,
    Eb as V,
    Ec as S,
    Fa as n,
    Hb as U,
    Ib as d,
    Jb as g,
    Kb as x,
    Kc as J,
    Na as k,
    Oa as W,
    Pb as E,
    Qb as q,
    Rb as A,
    Sa as G,
    Tc as X,
    Xa as j,
    _a as C,
    ba as H,
    bb as F,
    cb as I,
    db as B,
    ea as v,
    eb as l,
    fb as a,
    gb as r,
    ha as m,
    hb as T,
    ia as u,
    mc as P,
    pc as L,
    qa as y,
    qb as b,
    qd as ie,
    ra as M,
    sb as w,
    sc as O,
    ub as c,
    vd as $,
    xk as s
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as Y,
    b as z
} from "./chunk-FBFWB55K.js";
var fe = (() => {
    class t {
        constructor() {
            this.formatMessage = s
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-support"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(o, i) {
                    o & 1 && (a(0, "div", 0), T(1, "router-outlet"), r())
                },
                dependencies: [ie],
                encapsulation: 2
            })
        }
    }
    return t
})();

function xe(t, f) {
    if (t & 1 && (a(0, "div")(1, "p", 15), d(2), r()()), t & 2) {
        let e = c().$implicit;
        n(2), g(e.tagTitle)
    }
}

function ye(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "div", 4)(1, "div", 5)(2, "div", 6), w("click", function() {
            let i = m(e).$implicit,
                p = c(2);
            return u(p.navigateToItem(i))
        })("keydown.enter", function() {
            let i = m(e).$implicit,
                p = c(2);
            return u(p.navigateToItem(i))
        })("keydown.space", function(i) {
            let p = m(e).$implicit;
            return c(2).navigateToItem(p), u(i.preventDefault())
        }), a(3, "div", 7)(4, "div", 8)(5, "div", 9), T(6, "i", 10), r(), C(7, xe, 3, 1, "div"), r(), a(8, "div", 11)(9, "h6", 12), d(10), r(), a(11, "p", 13), d(12), r()()(), a(13, "button", 14), d(14), r()()()()
    }
    if (t & 2) {
        let e = f.$implicit,
            o = c(2);
        l("ngClass", o.isMobileDevice ? "px-2" : ""), n(), l("ngClass", o.isMobileDevice ? "w-100" : "w-75"), n(), V("--light-bg", e.cardBgColor)("--light-bg-hover", e.cardBgHoverColor), j("data-item-id", e.id), n(3), V("background-color", e.iconBgColor), n(), U(e.icon), n(), h(e.isTagPresent ? 7 : -1), n(3), g(e.title), n(2), g(e.description), n(), V("color", e.cardBgColor), n(), x(" ", e.buttonText, " ")
    }
}

function ke(t, f) {
    if (t & 1 && (a(0, "div", 0)(1, "div")(2, "div", 3), I(3, ye, 15, 17, "div", 4, F), r()()()), t & 2) {
        let e = c();
        n(2), l("ngClass", e.isMobileDevice ? "mt-2" : "mt-5"), n(), B(e.filteredContactList())
    }
}

function we(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "app-feedback-popup", 16), w("feedbackPopupCloseClick", function() {
            m(e);
            let i = c();
            return u(i.isVisibleFeedbackPopup.set(!1))
        })("feedbackPopupSaveClick", function() {
            m(e);
            let i = c();
            return u(i.isVisibleFeedbackPopup.set(!1))
        }), r()
    }
    if (t & 2) {
        let e = c();
        l("isVisiblePopup", e.isVisibleFeedbackPopup())
    }
}

function Te(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "app-request-callback-popup", 17), w("requestCallbackPopupCloseClick", function() {
            m(e);
            let i = c();
            return u(i.isVisibleCallbackPopup.set(!1))
        })("requestCallbackPopupSaveClick", function() {
            m(e);
            let i = c();
            return u(i.isVisibleCallbackPopup.set(!1))
        }), r()
    }
    if (t & 2) {
        let e = c();
        l("isVisiblePopup", e.isVisibleCallbackPopup())
    }
}
var _e = (() => {
    class t {
        constructor() {
            this.formatMessage = s, this.searchTerm = L(""), this.contactItemsCount = O(), this.isMobileDevice = v(D).isMobileDevice(), this.isVisibleFeedbackPopup = y(!1), this.isVisibleCallbackPopup = y(!1), this.isVisibleOverallFeedbackPopup = y(!1), this.contactUsList = [{
                id: "0",
                title: s("feedback_suggestions"),
                description: s("help_page_feedback_suggestions_description"),
                icon: "fa-thin fa-comment",
                cardBgColor: "#2563eb",
                iconBgColor: "#5882de75",
                cardBgHoverColor: "#2563eb",
                isTagPresent: !0,
                tagTitle: s("popular"),
                buttonText: s("share_feedback")
            }, {
                id: "1",
                title: s("request_a_callback"),
                description: s("help_page_request_a_callback_description"),
                icon: "fa-thin fa-phone",
                iconBgColor: "#9568bdc2",
                cardBgColor: "#9333ea",
                cardBgHoverColor: "#9333ea",
                isTagPresent: !1,
                buttonText: s("request_a_callback")
            }, {
                id: "3",
                title: s("email_us"),
                description: s("help_page_contact_us_email_description"),
                icon: "fa-thin fa-message",
                iconBgColor: "#e2c69f61",
                cardBgColor: "#ff990afa",
                cardBgHoverColor: "#ff990afa",
                isTagPresent: !0,
                tagTitle: s("popular"),
                buttonText: s("email_us")
            }, {
                id: "4",
                title: s("rate_us"),
                description: s("help_page_feedback_suggestions_description"),
                icon: "fa-thin fa-envelopes-bulk",
                iconBgColor: "#b3b9c37a",
                cardBgColor: "#898e95fa",
                cardBgHoverColor: "#898e95fa",
                isTagPresent: !0,
                buttonText: s("rate_us")
            }], this.filteredContactList = P(() => {
                let e = this.searchTerm() ? .toLowerCase().trim() || "";
                return e ? this.contactUsList.filter(o => o.title.toLowerCase().includes(e)) : this.contactUsList
            }), M(() => {
                this.contactItemsCount.set(this.filteredContactList().length)
            })
        }
        openEmail() {
            window.location.href = "mailto:support@bytephase.com"
        }
        openOverallFeedback() {
            this.isVisibleOverallFeedbackPopup.set(!0)
        }
        navigateToItem(e) {
            e.id === "0" ? this.isVisibleFeedbackPopup.set(!0) : e.id === "1" ? this.isVisibleCallbackPopup.set(!0) : e.id === "3" ? this.openEmail() : this.openOverallFeedback()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-contact-us-options"]
                ],
                inputs: {
                    searchTerm: [1, "searchTerm"],
                    contactItemsCount: [1, "contactItemsCount"]
                },
                outputs: {
                    contactItemsCount: "contactItemsCountChange"
                },
                standalone: !1,
                decls: 4,
                vars: 4,
                consts: [
                    [1, "help-page"],
                    [3, "isVisiblePopup"],
                    [3, "onClosePopup", "isVisiblePopup"],
                    [1, "row", "g-3", "w-100", "d-flex", "justify-content-center", 3, "ngClass"],
                    [1, "col-lg-4", "col-md-6", "col-sm-12", 2, "justify-items", "center", 3, "ngClass"],
                    [1, "card", "actionable-card", "h-100", "border-0", 3, "ngClass"],
                    ["role", "button", "tabindex", "0", 1, "card-header-section", "rounded-top", "rounded-bottom", "p-3", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "d-flex", "mb-2", "flex-column"],
                    [1, "d-flex", "justify-content-between"],
                    [1, "icon-wrapper", "me-3"],
                    [1, "text-white"],
                    [1, "flex-grow-1"],
                    [1, "fw-medium", "mb-1", "text-white", "mt-4"],
                    [1, "mb-0", "text-white", "mt-2"],
                    [1, "w-100", "bg-white", "border-0", "rounded-1", "p-2", "fs-6"],
                    [1, "text-white", "fs-6"],
                    [3, "feedbackPopupCloseClick", "feedbackPopupSaveClick", "isVisiblePopup"],
                    [3, "requestCallbackPopupCloseClick", "requestCallbackPopupSaveClick", "isVisiblePopup"]
                ],
                template: function(o, i) {
                    o & 1 && (C(0, ke, 5, 1, "div", 0), C(1, we, 1, 1, "app-feedback-popup", 1), C(2, Te, 1, 1, "app-request-callback-popup", 1), a(3, "app-overall-app-feedback", 2), w("onClosePopup", function() {
                        return i.isVisibleOverallFeedbackPopup.set(!1)
                    }), r()), o & 2 && (h(i.filteredContactList().length > 0 ? 0 : -1), n(), h(i.isVisibleFeedbackPopup() ? 1 : -1), n(), h(i.isVisibleCallbackPopup() ? 2 : -1), n(), l("isVisiblePopup", i.isVisibleOverallFeedbackPopup()))
                },
                dependencies: [S, ce, le, me],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ve(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "div", 3)(1, "div", 4)(2, "div", 5), w("click", function() {
            let i = m(e).$implicit,
                p = c(2);
            return u(p.navigateToItem(i))
        })("keydown.enter", function() {
            let i = m(e).$implicit,
                p = c(2);
            return u(p.navigateToItem(i))
        })("keydown.space", function(i) {
            let p = m(e).$implicit;
            return c(2).navigateToItem(p), u(i.preventDefault())
        }), a(3, "div", 6)(4, "div", 7)(5, "div", 8), T(6, "i"), r(), a(7, "div"), T(8, "i", 9), r()(), a(9, "div", 10)(10, "h6", 11), d(11), r(), a(12, "p", 12), d(13), r()()()()()()
    }
    if (t & 2) {
        let e = f.$implicit,
            o = c(2);
        l("ngClass", o.isMobileDevice ? "px-2" : ""), n(), l("ngClass", o.isMobileDevice ? "w-100" : "w-75"), n(), j("data-item-id", e.id), n(3), V("background-color", e.iconBgColor), n(), U(e.icon), V("color", e.iconColor), n(5), g(e.title), n(2), g(e.description)
    }
}

function Se(t, f) {
    if (t & 1 && (a(0, "div", 0)(1, "h5", 1), d(2), r(), a(3, "div")(4, "div", 2), I(5, Ve, 14, 11, "div", 3, F), r()()()), t & 2) {
        let e = c();
        l("ngClass", e.isMobileDevice ? "mt-3" : "mt-4"), n(), l("ngClass", e.isMobileDevice ? "mb-2 fs-6" : "mb-2"), n(), x(" ", e.formatMessage("quick_access"), " "), n(3), B(e.filteredQuickAccess())
    }
}
var Ce = (() => {
    class t {
        constructor() {
            this.formatMessage = s, this.isMobileDevice = v(D).isMobileDevice(), this.nativeLinkService = v(R), this.searchTerm = L(""), this.quickAccessCount = O(), this.quickAccessList = [{
                id: "0",
                title: s("whats_new"),
                description: s("help_page_quick_access_whats_new_description"),
                icon: "fa-thin fa-wand-magic-sparkles",
                iconColor: "#ff990afa",
                iconBgColor: "#f3c6716b",
                cardBgColor: "#f3c6716b",
                cardBgHoverColor: "#2563eb",
                route: "https://bytephase.com/whats-new/"
            }, {
                id: "1",
                title: s("roadmap"),
                description: s("help_page_quick_access_roadmap_description"),
                icon: "fa-thin fa-road",
                iconBgColor: "#e4b3ff6b",
                iconColor: "#9333ea",
                cardBgColor: "#9333ea",
                cardBgHoverColor: "#9333ea",
                route: "https://bytephase.com/roadmap/"
            }, {
                id: "2",
                title: s("blog"),
                description: s("help_page_quick_access_blog_description"),
                icon: "fa-thin fa-readme",
                iconColor: "#ff0303",
                iconBgColor: "#ffb3b36b",
                cardBgColor: "#ffb3b36b",
                cardBgHoverColor: "#ffb3b36b",
                route: "https://bytephase.com/blog/"
            }], this.filteredQuickAccess = P(() => {
                let e = this.searchTerm() ? .toLowerCase().trim() || "";
                return e ? this.quickAccessList.filter(o => o.title.toLowerCase().includes(e)) : this.quickAccessList
            }), M(() => {
                this.quickAccessCount.set(this.filteredQuickAccess().length)
            })
        }
        navigateToItem(e) {
            this.nativeLinkService.openExternal(e.route)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-quick-access"]
                ],
                inputs: {
                    searchTerm: [1, "searchTerm"],
                    quickAccessCount: [1, "quickAccessCount"]
                },
                outputs: {
                    quickAccessCount: "quickAccessCountChange"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "ngClass"],
                    [1, "fw-light", "ps-3", "mb-0", "text-center", 3, "ngClass"],
                    [1, "row", "g-3", "w-100", "d-flex", "justify-content-center"],
                    [1, "col-lg-4", "col-md-6", "col-sm-12", 2, "justify-items", "center", 3, "ngClass"],
                    [1, "card", "actionable-card", "h-100", 3, "ngClass"],
                    ["role", "button", "tabindex", "0", 1, "card-header-section", "rounded-top", "rounded-bottom", "p-3", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "d-flex", "mb-2", "flex-column"],
                    [1, "d-flex", "justify-content-between"],
                    [1, "icon-wrapper", "me-3"],
                    [1, "fa-thin", "fa-arrow-right", "mx-2"],
                    [1, "flex-grow-1"],
                    [1, "fw-medium", "mb-1", "mt-4"],
                    [1, "mb-0", "text-muted", "mt-2"]
                ],
                template: function(o, i) {
                    o & 1 && C(0, Se, 7, 3, "div", 0), o & 2 && h(i.filteredQuickAccess().length > 0 ? 0 : -1)
                },
                dependencies: [S],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Pe = t => ({
    "background-color": t
});

function Fe(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "div", 7)(1, "div", 8)(2, "div", 9), w("click", function() {
            let i = m(e).$implicit,
                p = c(2);
            return u(p.navigateToItem(i))
        })("keydown.enter", function() {
            let i = m(e).$implicit,
                p = c(2);
            return u(p.navigateToItem(i))
        })("keydown.space", function(i) {
            let p = m(e).$implicit;
            return c(2).navigateToItem(p), u(i.preventDefault())
        }), a(3, "div", 10)(4, "div", 11)(5, "div", 12), T(6, "i"), r(), a(7, "p", 13), d(8), r()()()()()()
    }
    if (t & 2) {
        let e = f.$implicit,
            o = c(2);
        n(), V("width", o.isMobileDevice ? "120px" : "150px"), n(), j("data-item-id", e.id), n(3), l("ngStyle", Q(9, Pe, o.isDarkTheme() ? "transparent" : "#f6eaea")), n(), U(e.icon), V("color", e.iconColor), n(2), g(e.title)
    }
}

function Ie(t, f) {
    if (t & 1 && (a(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "p", 4), d(5), r(), a(6, "p", 5), d(7), r(), a(8, "div", 6), I(9, Fe, 9, 11, "div", 7, F), r()()()()()), t & 2) {
        let e = c();
        l("ngClass", e.isMobileDevice ? "px-2 py-2" : "px-3 py-3"), n(), l("ngClass", e.isMobileDevice ? "mt-1" : "mt-2"), n(2), l("ngClass", e.isMobileDevice ? "p-2" : "p-3"), n(), l("ngClass", e.isMobileDevice ? "text-center fs-6" : "fs-6"), n(), x(" ", e.formatMessage("bytephase_features"), " "), n(), l("ngClass", e.isMobileDevice ? "text-center mb-2" : ""), n(), x(" ", e.formatMessage("help_page_bytephase_features_description"), " "), n(), l("ngClass", e.isMobileDevice ? "gap-2" : "gap-3"), n(), B(e.filteredFeatures())
    }
}
var he = (() => {
    class t {
        constructor() {
            this.formatMessage = s, this.isMobileDevice = v(D).isMobileDevice(), this.themeService = v(se), this.nativeLinkService = v(R), this.searchTerm = L(""), this.featureCount = O(), this.isDarkTheme = this.themeService.isDarkTheme, this.featureList = [{
                id: "0",
                title: s("ticketing"),
                icon: "fa-thin fa-ticket",
                iconColor: "#2563eb",
                route: "https://bytephase.com/features/repair-ticket-management-software/"
            }, {
                id: "1",
                title: s("sale"),
                icon: "fa-thin fa-cash-register",
                iconColor: "#ff990afa",
                route: "https://bytephase.com/features/point-of-sale/"
            }, {
                id: "1",
                title: s("leads"),
                icon: "fa-thin fa-user",
                iconColor: "#ff0303",
                route: "https://bytephase.com/features/lead-management/"
            }, {
                id: "2",
                title: s("expenses"),
                icon: "fa-thin fa-receipt",
                iconColor: "#9333ea",
                route: "https://bytephase.com/features/expense-management/"
            }, {
                id: "3",
                title: s("inventory"),
                icon: "fa-thin fa-briefcase",
                iconColor: "#16a34a",
                route: "https://bytephase.com/features/inventory-management/"
            }, {
                id: "3",
                title: s("employees_title"),
                icon: "fa-thin fa-person",
                iconColor: "#ff990afa",
                route: "https://bytephase.com/features/configurable-permissions/"
            }, {
                id: "4",
                title: s("client_login"),
                icon: "fa-thin fa-user-check",
                iconColor: "#d507e7fa",
                route: "https://bytephase.com/blog/what-is-client-login-in-bytephase/"
            }, {
                id: "5",
                title: s("notifications_title"),
                icon: "fa-thin fa-bell",
                iconColor: "#8a5306fa",
                route: "https://bytephase.com/features/push-notification/"
            }, {
                id: "6",
                title: s("activity_log"),
                icon: "fa-thin fa-circle-info",
                iconColor: "#07ad0bfa",
                route: "https://bytephase.com/features/activity-logs/"
            }, {
                id: "7",
                title: s("help_page_quick_quick_access_otp_for_delivery"),
                icon: "fa-thin fa-mobile",
                iconColor: "#898e95fa",
                route: "https://bytephase.com/features/otp-for-delivery/"
            }, {
                id: "8",
                title: s("contact_us"),
                icon: "fa-thin fa-address-book",
                iconColor: "#9333ea",
                route: "https://bytephase.com/features/self-check-in/"
            }, {
                id: "9",
                title: s("google_calendar"),
                icon: "fa-thin fa-calendar",
                iconColor: "#ff0303",
                route: "https://bytephase.com/blog/how-to-integrate-google-calender-in-bytephase-crm/"
            }], this.filteredFeatures = P(() => {
                let e = this.searchTerm() ? .toLowerCase().trim() || "";
                return e ? this.featureList.filter(o => o.title.toLowerCase().includes(e)) : this.featureList
            }), M(() => {
                this.featureCount.set(this.filteredFeatures().length)
            })
        }
        navigateToItem(e) {
            this.nativeLinkService.openExternal(e.route)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-bytephase-features"]
                ],
                inputs: {
                    searchTerm: [1, "searchTerm"],
                    featureCount: [1, "featureCount"]
                },
                outputs: {
                    featureCount: "featureCountChange"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "ngClass"],
                    [1, "row", "g-3", "d-flex", "justify-content-center", 3, "ngClass"],
                    [1, "col-lg-12", "col-md-12", "col-sm-12"],
                    [1, "card", "rounded-2", 2, "background-color", "#add8e64f", 3, "ngClass"],
                    [1, "mb-0", 3, "ngClass"],
                    [1, "fs-7", "text-muted", 3, "ngClass"],
                    [1, "d-flex", "flex-row", "flex-wrap", "justify-content-evenly", 3, "ngClass"],
                    [1, "", 2, "justify-items", "center"],
                    [1, "card", "actionable-card", "h-100"],
                    ["role", "button", "tabindex", "0", 1, "card-header-section", "rounded-top", "rounded-bottom", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "card", "rounded", "border-0"],
                    [1, "d-flex", "mb-2", "flex-column", "align-items-center"],
                    [1, "icon-wrapper", 3, "ngStyle"],
                    [1, "m-0", "mt-2", "text-center"]
                ],
                template: function(o, i) {
                    o & 1 && C(0, Ie, 11, 8, "div", 0), o & 2 && h(i.filteredFeatures().length > 0 ? 0 : -1)
                },
                dependencies: [S, J],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ee = t => [t];

function qe(t, f) {
    if (t & 1 && (a(0, "div", 11)(1, "div", 12)(2, "p", 13), d(3), r()()()), t & 2) {
        let e = f.$implicit,
            o = c(2);
        n(3), x(" ", o.formatMessage(e.groupTranslationKey), " ")
    }
}

function Ae(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "p", 14)(1, "a", 15), w("click", function() {
            let i = m(e).$implicit,
                p = c(3);
            return u(p.showVideo(i))
        })("keydown.enter", function() {
            let i = m(e).$implicit,
                p = c(3);
            return u(p.showVideo(i))
        })("keydown.space", function() {
            let i = m(e).$implicit,
                p = c(3);
            return u(p.showVideo(i))
        }), T(2, "i", 16), d(3), r()()
    }
    if (t & 2) {
        let e = f.$implicit,
            o = c(3);
        n(3), x(" ", o.formatMessage(e.translationKey), " ")
    }
}

function Le(t, f) {
    if (t & 1 && (a(0, "div"), I(1, Ae, 4, 1, "p", 14, F), r()), t & 2) {
        let e = f.$implicit;
        n(), B(e.items)
    }
}

function Oe(t, f) {
    if (t & 1 && (a(0, "div", 1)(1, "div", 3)(2, "p", 4), d(3), r(), a(4, "p", 5), d(5), r(), a(6, "p", 6), d(7), r(), a(8, "div", 7)(9, "dx-accordion", 8, 0), G(11, qe, 4, 1, "div", 9)(12, Le, 3, 0, "div", 10), r()()()()), t & 2) {
        let e = c();
        l("ngClass", e.isMobileDevice ? "px-2 py-2" : "px-3 py-3"), n(), l("ngClass", e.isMobileDevice ? "p-2" : "p-3"), n(), l("ngClass", e.isMobileDevice ? "text-center fs-6" : "fs-6"), n(), x(" ", e.formatMessage("help_page_bytephase_video_tutorials_title"), " "), n(), l("ngClass", e.isMobileDevice && "text-center"), n(), x(" ", e.formatMessage("help_page_bytephase_video_tutorials_description"), " "), n(), l("ngClass", e.isMobileDevice && "text-center"), n(), x(" ", e.formatMessage("help_page_bytephase_video_tutorials_disclaimer"), " "), n(2), l("dataSource", e.filteredTutorials())("collapsible", !0)("multiple", !0)("animationDuration", 300)("selectedItems", Q(15, Ee, e.filteredTutorials()[0])), n(2), l("dxTemplateOf", "title"), n(), l("dxTemplateOf", "item")
    }
}

function Ne(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "app-show-video-popup", 17), w("onPostClose", function() {
            m(e);
            let i = c();
            return u(i.isVisibleVideoPopup = !1)
        }), r()
    }
    if (t & 2) {
        let e = c();
        l("isVisiblePopup", e.isVisibleVideoPopup)("urlObj", e.currentVideoObj)
    }
}
var ge = (() => {
    class t {
        constructor() {
            this.formatMessage = s, this.isMobileDevice = v(D).isMobileDevice(), this.tenantService = v(ae), this.tutorialCount = O(), this.searchTerm = L(""), this.tutorialList = P(() => {
                let e = Object.values(oe);
                return this.tenantService.isIndia() ? e : e.map(o => z(Y({}, o), {
                    items: o.items.filter(i => !("indiaOnly" in i && i.indiaOnly))
                })).filter(o => o.items.length > 0)
            }), this.isVisibleVideoPopup = !1, this.currentVideoObj = null, this.filteredTutorials = P(() => {
                let e = this.searchTerm() ? .toLowerCase().trim() || "",
                    o = this.tutorialList();
                return e ? o.filter(i => i.groupTranslationKey.toLowerCase().includes(e) || i.items.some(p => p.translationKey.toLowerCase().includes(e))) : o
            }), M(() => {
                this.tutorialCount.set(this.filteredTutorials().length)
            })
        }
        showVideo(e) {
            this.isVisibleVideoPopup ? (this.isVisibleVideoPopup = !1, setTimeout(() => {
                this.playVideo(e)
            }, 100)) : this.playVideo(e)
        }
        playVideo(e) {
            this.currentVideoObj = e, this.isVisibleVideoPopup = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-video-tutorials"]
                ],
                inputs: {
                    tutorialCount: [1, "tutorialCount"],
                    searchTerm: [1, "searchTerm"]
                },
                outputs: {
                    tutorialCount: "tutorialCountChange"
                },
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["accordion", ""],
                    [3, "ngClass"],
                    [3, "isVisiblePopup", "urlObj"],
                    [1, "card", "rounded-3", 3, "ngClass"],
                    [1, "mb-0", 3, "ngClass"],
                    [1, "fs-7", "mb-0", 3, "ngClass"],
                    [1, "fs-7", "text-muted", "fst-italic", "mb-0", 3, "ngClass"],
                    ["id", "accordion"],
                    ["id", "accordion-container", 3, "dataSource", "collapsible", "multiple", "animationDuration", "selectedItems"],
                    ["class", "accordion-title d-flex flex-row-reverse justify-content-between align-items-center", 4, "dxTemplate", "dxTemplateOf"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "accordion-title", "d-flex", "flex-row-reverse", "justify-content-between", "align-items-center"],
                    [1, "d-flex", "flex-column"],
                    [1, "accordion-title", "fs-6", "mb-0"],
                    [1, "mb-0", "text-primary"],
                    ["role", "button", "tabindex", "0", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "fa-thin", "fa-play-circle", "p-2"],
                    [3, "onPostClose", "isVisiblePopup", "urlObj"]
                ],
                template: function(o, i) {
                    o & 1 && (C(0, Oe, 13, 17, "div", 1), C(1, Ne, 1, 2, "app-show-video-popup", 2)), o & 2 && (h(i.filteredTutorials().length > 0 ? 0 : -1), n(), h(i.isVisibleVideoPopup ? 1 : -1))
                },
                dependencies: [S, pe, re, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ue(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "div", 1)(1, "h5", 8), d(2), r(), a(3, "p", 9), d(4), r(), a(5, "input", 10), A("ngModelChange", function(i) {
            m(e);
            let p = c();
            return q(p.searchTerm, i) || (p.searchTerm = i), u(i)
        }), r()()
    }
    if (t & 2) {
        let e = c();
        n(2), g(e.formatMessage("help_page_title")), n(2), g(e.formatMessage("help_page_sub_title")), n(), l("placeholder", e.formatMessage("help_page_search_panel_placeholder")), E("ngModel", e.searchTerm)
    }
}

function He(t, f) {
    if (t & 1) {
        let e = b();
        a(0, "div", 11)(1, "input", 12), A("ngModelChange", function(i) {
            m(e);
            let p = c();
            return q(p.searchTerm, i) || (p.searchTerm = i), u(i)
        }), r()(), a(2, "div", 13)(3, "h3", 14), d(4), r(), a(5, "h5", 15), d(6), r()()
    }
    if (t & 2) {
        let e = c();
        n(), l("placeholder", e.formatMessage("help_page_search_panel_placeholder")), E("ngModel", e.searchTerm), n(3), g(e.formatMessage("help_page_title")), n(2), g(e.formatMessage("help_page_sub_title"))
    }
}

function We(t, f) {
    if (t & 1 && (a(0, "div", 2)(1, "p"), d(2), r()()), t & 2) {
        let e = c();
        n(2), g(e.formatMessage("no_results_found"))
    }
}
var ve = (() => {
    class t {
        constructor() {
            this.formatMessage = s, this.isMobileDevice = v(D).isMobileDevice(), this.searchTerm = y(""), this.contactCount = y(0), this.quickAccessCount = y(0), this.shortcutsCount = y(0), this.featuresCount = y(0), this.tutorialsCount = y(0), this.isAnyMatchFound = y(!0), M(() => {
                let e = this.contactCount() + this.quickAccessCount() + this.shortcutsCount() + this.featuresCount() + this.tutorialsCount();
                this.isAnyMatchFound.set(e === 0)
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = k({
                type: t,
                selectors: [
                    ["app-help-center"]
                ],
                standalone: !1,
                decls: 9,
                vars: 14,
                consts: [
                    [1, "help-page", "container", 3, "ngClass"],
                    [1, "d-flex", "flex-column", "align-items-center", "text-center", "mb-3"],
                    [1, "text-center", "mt-3"],
                    [3, "contactItemsCountChange", "searchTerm", "contactItemsCount"],
                    [3, "quickAccessCountChange", "searchTerm", "quickAccessCount"],
                    [3, "shortcutsCountChange", "inline", "searchTerm", "shortcutsCount"],
                    [3, "featureCountChange", "searchTerm", "featureCount"],
                    [3, "tutorialCountChange", "searchTerm", "tutorialCount"],
                    [1, "fw-bold", "mb-1"],
                    [1, "text-muted", "small", "mb-3"],
                    ["type", "text", 1, "form-control", "theme-secondary-bg", "w-100", 3, "ngModelChange", "placeholder", "ngModel"],
                    [1, "d-flex", "justify-content-end", "mb-4"],
                    ["type", "text", 1, "form-control", "theme-secondary-bg", "w-35", 3, "ngModelChange", "placeholder", "ngModel"],
                    [1, "d-flex", "justify-content-center", "flex-column", "align-items-center", "mt-3"],
                    [1, "fw-bold"],
                    [1, "fw-light", "text-muted", "text-center"]
                ],
                template: function(o, i) {
                    o & 1 && (a(0, "div", 0), C(1, Ue, 6, 4, "div", 1)(2, He, 7, 4), C(3, We, 3, 1, "div", 2), a(4, "app-contact-us-options", 3), A("contactItemsCountChange", function(_) {
                        return q(i.contactCount, _) || (i.contactCount = _), _
                    }), r(), a(5, "app-quick-access", 4), A("quickAccessCountChange", function(_) {
                        return q(i.quickAccessCount, _) || (i.quickAccessCount = _), _
                    }), r(), a(6, "app-keyboard-shortcuts", 5), A("shortcutsCountChange", function(_) {
                        return q(i.shortcutsCount, _) || (i.shortcutsCount = _), _
                    }), r(), a(7, "app-bytephase-features", 6), A("featureCountChange", function(_) {
                        return q(i.featuresCount, _) || (i.featuresCount = _), _
                    }), r(), a(8, "app-video-tutorials", 7), A("tutorialCountChange", function(_) {
                        return q(i.tutorialsCount, _) || (i.tutorialsCount = _), _
                    }), r()()), o & 2 && (l("ngClass", i.isMobileDevice ? "py-2 px-3" : "my-4"), n(), h(i.isMobileDevice ? 1 : 2), n(2), h(i.isAnyMatchFound() ? 3 : -1), n(), l("searchTerm", i.searchTerm()), E("contactItemsCount", i.contactCount), n(), l("searchTerm", i.searchTerm()), E("quickAccessCount", i.quickAccessCount), n(), l("inline", !0)("searchTerm", i.searchTerm()), E("shortcutsCount", i.shortcutsCount), n(), l("searchTerm", i.searchTerm()), E("featureCount", i.featuresCount), n(), l("searchTerm", i.searchTerm()), E("tutorialCount", i.tutorialsCount))
                },
                dependencies: [S, de, Z, ee, te, _e, Ce, he, ge],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Qe = [{
        path: "",
        component: fe,
        children: [{
            path: "centers",
            component: ve,
            title: "BytePhase | Support Center"
        }, {
            path: "",
            redirectTo: "centers",
            pathMatch: "full"
        }]
    }],
    be = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = W({
                    type: t
                })
            }
            static {
                this.\u0275inj = H({
                    imports: [$.forChild(Qe), $]
                })
            }
        }
        return t
    })();
var Yt = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = W({
                type: t
            })
        }
        static {
            this.\u0275inj = H({
                imports: [X, be, ue]
            })
        }
    }
    return t
})();
export {
    Yt as SupportModule
};