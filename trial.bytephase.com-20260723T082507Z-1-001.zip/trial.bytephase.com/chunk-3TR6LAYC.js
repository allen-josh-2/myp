import {
    i as P
} from "./chunk-X4EY4JYZ.js";
import {
    a as o
} from "./chunk-L2KSLXYG.js";
var j = 540,
    U = r => document.querySelector(`${r}.ion-cloned-element`),
    I = r => r.shadowRoot || r,
    D = r => {
        let i = r.tagName === "ION-TABS" ? r : r.querySelector("ion-tabs"),
            l = "ion-content ion-header:not(.header-collapse-condense-inactive) ion-title.title-large";
        if (i != null) {
            let e = i.querySelector("ion-tab:not(.tab-hidden), .ion-page:not(.ion-page-hidden)");
            return e != null ? e.querySelector(l) : null
        }
        return r.querySelector(l)
    },
    k = (r, i) => {
        let l = r.tagName === "ION-TABS" ? r : r.querySelector("ion-tabs"),
            e = [];
        if (l != null) {
            let t = l.querySelector("ion-tab:not(.tab-hidden), .ion-page:not(.ion-page-hidden)");
            t != null && (e = t.querySelectorAll("ion-buttons"))
        } else e = r.querySelectorAll("ion-buttons");
        for (let t of e) {
            let A = t.closest("ion-header"),
                E = A && !A.classList.contains("header-collapse-condense-inactive"),
                h = t.querySelector("ion-back-button"),
                s = t.classList.contains("buttons-collapse"),
                g = t.slot === "start" || t.slot === "";
            if (h !== null && g && (s && E && i || !s)) return h
        }
        return null
    },
    J = (r, i, l, e, t) => {
        let A = k(e, l),
            E = D(t),
            h = D(e),
            s = k(t, l),
            g = A !== null && E !== null && !l,
            u = h !== null && s !== null && l;
        if (g) {
            let p = E.getBoundingClientRect(),
                f = A.getBoundingClientRect(),
                c = I(A).querySelector(".button-text"),
                C = c ? .getBoundingClientRect(),
                y = I(E).querySelector(".toolbar-title").getBoundingClientRect();
            z(r, i, l, E, p, y, f, c, C), G(r, i, l, A, f, c, C, E, y)
        } else if (u) {
            let p = h.getBoundingClientRect(),
                f = s.getBoundingClientRect(),
                c = I(s).querySelector(".button-text"),
                C = c ? .getBoundingClientRect(),
                y = I(h).querySelector(".toolbar-title").getBoundingClientRect();
            z(r, i, l, h, p, y, f, c, C), G(r, i, l, s, f, c, C, h, y)
        }
        return {
            forward: g,
            backward: u
        }
    },
    G = (r, i, l, e, t, A, E, h, s) => {
        var g, u;
        let p = i ? `calc(100% - ${t.right+4}px)` : `${t.left-4}px`,
            f = i ? "right" : "left",
            c = i ? "left" : "right",
            C = i ? "right" : "left",
            L = 1,
            y = 1,
            m = `scale(${y})`,
            b = "scale(1)";
        if (A && E) {
            let Y = ((g = A.textContent) === null || g === void 0 ? void 0 : g.trim()) === ((u = h.textContent) === null || u === void 0 ? void 0 : u.trim());
            L = s.width / E.width, y = (s.height - Z) / E.height, m = Y ? `scale(${L}, ${y})` : `scale(${y})`
        }
        let x = I(e).querySelector("ion-icon").getBoundingClientRect(),
            W = i ? `${x.width/2-(x.right-t.right)}px` : `${t.left-x.width/2}px`,
            n = i ? `-${window.innerWidth-t.right}px` : `${t.left}px`,
            S = `${s.top}px`,
            $ = `${t.top}px`,
            v = [{
                offset: 0,
                transform: `translate3d(${W}, ${S}, 0)`
            }, {
                offset: 1,
                transform: `translate3d(${n}, ${$}, 0)`
            }],
            a = [{
                offset: 0,
                transform: `translate3d(${n}, ${$}, 0)`
            }, {
                offset: 1,
                transform: `translate3d(${W}, ${S}, 0)`
            }],
            d = l ? a : v,
            q = l ? [{
                offset: 0,
                opacity: 1,
                transform: b
            }, {
                offset: 1,
                opacity: 0,
                transform: m
            }] : [{
                offset: 0,
                opacity: 0,
                transform: m
            }, {
                offset: 1,
                opacity: 1,
                transform: b
            }],
            w = l ? [{
                offset: 0,
                opacity: 1,
                transform: "scale(1)"
            }, {
                offset: .2,
                opacity: 0,
                transform: "scale(0.6)"
            }, {
                offset: 1,
                opacity: 0,
                transform: "scale(0.6)"
            }] : [{
                offset: 0,
                opacity: 0,
                transform: "scale(0.6)"
            }, {
                offset: .6,
                opacity: 0,
                transform: "scale(0.6)"
            }, {
                offset: 1,
                opacity: 1,
                transform: "scale(1)"
            }],
            N = o(),
            F = o(),
            B = o(),
            T = U("ion-back-button"),
            M = I(T).querySelector(".button-text"),
            H = I(T).querySelector("ion-icon");
        T.text = e.text, T.mode = e.mode, T.icon = e.icon, T.color = e.color, T.disabled = e.disabled, T.style.setProperty("display", "block"), T.style.setProperty("position", "fixed"), F.addElement(H), N.addElement(M), B.addElement(T), B.beforeStyles({
            position: "absolute",
            top: "0px",
            [C]: "0px"
        }).beforeAddWrite(() => {
            e.style.setProperty("display", "none"), T.style.setProperty(f, p)
        }).afterAddWrite(() => {
            e.style.setProperty("display", ""), T.style.setProperty("display", "none"), T.style.removeProperty(f)
        }).keyframes(d), N.beforeStyles({
            "transform-origin": `${f} top`
        }).keyframes(q), F.beforeStyles({
            "transform-origin": `${c} center`
        }).keyframes(w), r.addAnimation([N, F, B])
    },
    z = (r, i, l, e, t, A, E, h, s) => {
        var g, u;
        let p = i ? "right" : "left",
            f = i ? `calc(100% - ${t.right}px)` : `${t.left}px`,
            c = "0px",
            C = `${t.top}px`,
            L = 8,
            y = i ? `-${window.innerWidth-E.right-L}px` : `${E.x+L}px`,
            m = .5,
            b = "scale(1)",
            K = `scale(${m})`;
        if (h && s) {
            y = i ? `-${window.innerWidth-s.right-L}px` : `${s.x-L}px`;
            let X = ((g = h.textContent) === null || g === void 0 ? void 0 : g.trim()) === ((u = e.textContent) === null || u === void 0 ? void 0 : u.trim()),
                _ = s.width / A.width;
            m = s.height / (A.height - Z), K = X ? `scale(${_}, ${m})` : `scale(${m})`
        }
        let x = E.top + E.height / 2,
            W = t.height * m / 2,
            n = `${x-W}px`,
            S = [{
                offset: 0,
                opacity: 0,
                transform: `translate3d(${y}, ${n}, 0) ${K}`
            }, {
                offset: .1,
                opacity: 0
            }, {
                offset: 1,
                opacity: 1,
                transform: `translate3d(${c}, ${C}, 0) ${b}`
            }],
            $ = [{
                offset: 0,
                opacity: .99,
                transform: `translate3d(${c}, ${C}, 0) ${b}`
            }, {
                offset: .6,
                opacity: 0
            }, {
                offset: 1,
                opacity: 0,
                transform: `translate3d(${y}, ${n}, 0) ${K}`
            }],
            v = l ? S : $,
            a = U("ion-title"),
            d = o();
        a.innerText = e.innerText, a.size = e.size, a.color = e.color, d.addElement(a), d.beforeStyles({
            "transform-origin": `${p} top`,
            height: `${t.height}px`,
            display: "",
            position: "relative",
            [p]: f
        }).beforeAddWrite(() => {
            e.style.setProperty("opacity", "0")
        }).afterAddWrite(() => {
            e.style.setProperty("opacity", ""), a.style.setProperty("display", "none")
        }).keyframes(v), r.addAnimation(d)
    },
    ot = (r, i) => {
        var l;
        try {
            let e = "cubic-bezier(0.32,0.72,0,1)",
                t = "opacity",
                A = "transform",
                s = r.ownerDocument.dir === "rtl",
                g = s ? "-99.5%" : "99.5%",
                u = s ? "33%" : "-33%",
                p = i.enteringEl,
                f = i.leavingEl,
                c = i.direction === "back",
                C = p.querySelector(":scope > ion-content"),
                L = p.querySelectorAll(":scope > ion-header > *:not(ion-toolbar), :scope > ion-footer > *"),
                y = p.querySelectorAll(":scope > ion-header > ion-toolbar"),
                m = o(),
                b = o();
            if (m.addElement(p).duration(((l = i.duration) !== null && l !== void 0 ? l : 0) || j).easing(i.easing || e).fill("both").beforeRemoveClass("ion-page-invisible"), f && r !== null && r !== void 0) {
                let n = o();
                n.addElement(r), m.addAnimation(n)
            }
            if (!C && y.length === 0 && L.length === 0 ? b.addElement(p.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs")) : (b.addElement(C), b.addElement(L)), m.addAnimation(b), c ? b.beforeClearStyles([t]).fromTo("transform", `translateX(${u})`, "translateX(0%)").fromTo(t, .8, 1) : b.beforeClearStyles([t]).fromTo("transform", `translateX(${g})`, "translateX(0%)"), C) {
                let n = I(C).querySelector(".transition-effect");
                if (n) {
                    let S = n.querySelector(".transition-cover"),
                        $ = n.querySelector(".transition-shadow"),
                        v = o(),
                        a = o(),
                        d = o();
                    v.addElement(n).beforeStyles({
                        opacity: "1",
                        display: "block"
                    }).afterStyles({
                        opacity: "",
                        display: ""
                    }), a.addElement(S).beforeClearStyles([t]).fromTo(t, 0, .1), d.addElement($).beforeClearStyles([t]).fromTo(t, .03, .7), v.addAnimation([a, d]), b.addAnimation([v])
                }
            }
            let K = p.querySelector("ion-header.header-collapse-condense"),
                {
                    forward: x,
                    backward: W
                } = J(m, s, c, p, f);
            if (y.forEach(n => {
                    let S = o();
                    S.addElement(n), m.addAnimation(S);
                    let $ = o();
                    $.addElement(n.querySelector("ion-title"));
                    let v = o(),
                        a = Array.from(n.querySelectorAll("ion-buttons,[menuToggle]")),
                        d = n.closest("ion-header"),
                        X = d ? .classList.contains("header-collapse-condense-inactive"),
                        _;
                    c ? _ = a.filter(N => {
                        let F = N.classList.contains("buttons-collapse");
                        return F && !X || !F
                    }) : _ = a.filter(N => !N.classList.contains("buttons-collapse")), v.addElement(_);
                    let q = o();
                    q.addElement(n.querySelectorAll(":scope > *:not(ion-title):not(ion-buttons):not([menuToggle])"));
                    let R = o();
                    R.addElement(I(n).querySelector(".toolbar-background"));
                    let O = o(),
                        w = n.querySelector("ion-back-button");
                    if (w && O.addElement(w), S.addAnimation([$, v, q, R, O]), v.fromTo(t, .01, 1), q.fromTo(t, .01, 1), c) X || $.fromTo("transform", `translateX(${u})`, "translateX(0%)").fromTo(t, .01, 1), q.fromTo("transform", `translateX(${u})`, "translateX(0%)"), O.fromTo(t, .01, 1);
                    else if (K || $.fromTo("transform", `translateX(${g})`, "translateX(0%)").fromTo(t, .01, 1), q.fromTo("transform", `translateX(${g})`, "translateX(0%)"), R.beforeClearStyles([t, "transform"]), d ? .translucent ? R.fromTo("transform", s ? "translateX(-100%)" : "translateX(100%)", "translateX(0px)") : R.fromTo(t, .01, "var(--opacity)"), x || O.fromTo(t, .01, 1), w && !x) {
                        let F = o();
                        F.addElement(I(w).querySelector(".button-text")).fromTo("transform", s ? "translateX(-100px)" : "translateX(100px)", "translateX(0px)"), S.addAnimation(F)
                    }
                }), f) {
                let n = o(),
                    S = f.querySelector(":scope > ion-content"),
                    $ = f.querySelectorAll(":scope > ion-header > ion-toolbar"),
                    v = f.querySelectorAll(":scope > ion-header > *:not(ion-toolbar), :scope > ion-footer > *");
                if (!S && $.length === 0 && v.length === 0 ? n.addElement(f.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs")) : (n.addElement(S), n.addElement(v)), m.addAnimation(n), c) {
                    n.beforeClearStyles([t]).fromTo("transform", "translateX(0%)", s ? "translateX(-100%)" : "translateX(100%)");
                    let a = P(f);
                    m.afterAddWrite(() => {
                        m.getDirection() === "normal" && a.style.setProperty("display", "none")
                    })
                } else n.fromTo("transform", "translateX(0%)", `translateX(${u})`).fromTo(t, 1, .8);
                if (S) {
                    let a = I(S).querySelector(".transition-effect");
                    if (a) {
                        let d = a.querySelector(".transition-cover"),
                            X = a.querySelector(".transition-shadow"),
                            _ = o(),
                            q = o(),
                            R = o();
                        _.addElement(a).beforeStyles({
                            opacity: "1",
                            display: "block"
                        }).afterStyles({
                            opacity: "",
                            display: ""
                        }), q.addElement(d).beforeClearStyles([t]).fromTo(t, .1, 0), R.addElement(X).beforeClearStyles([t]).fromTo(t, .7, .03), _.addAnimation([q, R]), n.addAnimation([_])
                    }
                }
                $.forEach(a => {
                    let d = o();
                    d.addElement(a);
                    let X = o();
                    X.addElement(a.querySelector("ion-title"));
                    let _ = o(),
                        q = a.querySelectorAll("ion-buttons,[menuToggle]"),
                        R = a.closest("ion-header"),
                        O = R ? .classList.contains("header-collapse-condense-inactive"),
                        w = Array.from(q).filter(H => {
                            let Y = H.classList.contains("buttons-collapse");
                            return Y && !O || !Y
                        });
                    _.addElement(w);
                    let N = o(),
                        F = a.querySelectorAll(":scope > *:not(ion-title):not(ion-buttons):not([menuToggle])");
                    F.length > 0 && N.addElement(F);
                    let B = o();
                    B.addElement(I(a).querySelector(".toolbar-background"));
                    let T = o(),
                        M = a.querySelector("ion-back-button");
                    if (M && T.addElement(M), d.addAnimation([X, _, N, T, B]), m.addAnimation(d), T.fromTo(t, .99, 0), _.fromTo(t, .99, 0), N.fromTo(t, .99, 0), c) {
                        if (O || X.fromTo("transform", "translateX(0%)", s ? "translateX(-100%)" : "translateX(100%)").fromTo(t, .99, 0), N.fromTo("transform", "translateX(0%)", s ? "translateX(-100%)" : "translateX(100%)"), B.beforeClearStyles([t, "transform"]), R ? .translucent ? B.fromTo("transform", "translateX(0px)", s ? "translateX(-100%)" : "translateX(100%)") : B.fromTo(t, "var(--opacity)", 0), M && !W) {
                            let Y = o();
                            Y.addElement(I(M).querySelector(".button-text")).fromTo("transform", "translateX(0%)", `translateX(${(s?-124:124)+"px"})`), d.addAnimation(Y)
                        }
                    } else O || X.fromTo("transform", "translateX(0%)", `translateX(${u})`).fromTo(t, .99, 0).afterClearStyles([A, t]), N.fromTo("transform", "translateX(0%)", `translateX(${u})`).afterClearStyles([A, t]), T.afterClearStyles([t]), X.afterClearStyles([t]), _.afterClearStyles([t])
                })
            }
            return m
        } catch (e) {
            throw e
        }
    },
    Z = 10;
export {
    I as a, ot as b
};