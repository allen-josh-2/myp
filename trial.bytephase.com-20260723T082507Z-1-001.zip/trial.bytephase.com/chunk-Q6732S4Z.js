import {
    aa as s,
    ea as c,
    qa as r,
    sd as a
} from "./chunk-GOPIAW4V.js";
import {
    c as l,
    d as h
} from "./chunk-LJZ7ZJF4.js";
import {
    i as o
} from "./chunk-FBFWB55K.js";
var i = h("Network", {
    web: () =>
        import ("./chunk-DDX3WBGE.js").then(t => new t.NetworkWeb)
});
var k = (() => {
    class t {
        constructor() {
            this.router = c(a), this._online = r(!0), this._connectionType = r("unknown"), this.online = this._online.asReadonly(), this.connectionType = this._connectionType.asReadonly(), this.initialized = !1, this.lastOnlineRoute = null
        }
        initialize() {
            return o(this, null, function*() {
                if (!this.initialized) {
                    this.initialized = !0;
                    try {
                        let e = yield i.getStatus();
                        this._online.set(e.connected), this._connectionType.set(e.connectionType)
                    } catch (e) {
                        console.warn("[Network] getStatus failed, assuming online:", e), this._online.set(!0)
                    }
                    i.addListener("networkStatusChange", e => {
                        let n = this._online();
                        this._online.set(e.connected), this._connectionType.set(e.connectionType), n && !e.connected ? this.handleOffline() : !n && e.connected && this.handleBackOnline()
                    })
                }
            })
        }
        refresh() {
            return o(this, null, function*() {
                try {
                    let e = yield i.getStatus();
                    return this._online.set(e.connected), this._connectionType.set(e.connectionType), e.connected && this.handleBackOnline(), e.connected
                } catch (e) {
                    return this._online()
                }
            })
        }
        handleOffline() {
            if (!l.isNativePlatform()) return;
            let e = this.router.url;
            e.startsWith("/errors/offline") || (this.lastOnlineRoute = e, this.router.navigate(["/errors/offline"], {
                skipLocationChange: !0
            }))
        }
        handleBackOnline() {
            if (this.router.url.startsWith("/errors/offline")) {
                let e = this.lastOnlineRoute || "/";
                this.router.navigateByUrl(e, {
                    replaceUrl: !0
                }), this.lastOnlineRoute = null
            }
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275prov = s({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
export {
    k as a
};