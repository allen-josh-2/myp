import {
    Ae as te,
    Ja as Q,
    Pc as Z,
    Te as w,
    Va as B,
    Zd as ee,
    _d as x,
    ab as H,
    ca as W,
    cb as z,
    e as R,
    eb as J,
    g as I,
    h as L,
    ha as j,
    n as O,
    pb as K,
    rd as $,
    sb as X,
    t as q,
    u as U,
    y as Y
} from "./chunk-DCKGQUHB.js";
import {
    $a as C,
    Ab as D,
    Fa as a,
    Ka as S,
    Na as V,
    Pb as A,
    Qb as F,
    Rb as G,
    Sa as N,
    _a as u,
    ea as g,
    eb as o,
    fb as r,
    gb as m,
    ha as y,
    hb as v,
    hi as P,
    ia as _,
    oa as b,
    qb as h,
    sb as c,
    t as E,
    ub as s,
    xk as d,
    yb as k,
    zb as M
} from "./chunk-GOPIAW4V.js";
var f = class {
    constructor(p) {
        return Object.assign(this, p)
    }
    static getForm(p) {
        return new Y().group({
            id: [p.id || null],
            name: [p.name || null, [R.required]]
        })
    }
};

function ae(i, p) {
    i & 1 && v(0, "app-skeleton-loader", 4), i & 2 && o("rows", 3)("columns", 1)
}

function re(i, p) {
    if (i & 1) {
        let e = h();
        r(0, "app-server-error", 12), c("onConflictResolved", function(t) {
            y(e);
            let l = s(3);
            return _(l.onConflictResolved(t))
        }), m()
    }
    if (i & 2) {
        let e = s(3);
        o("errorResponse", e.errorResponse)("service", e.service)("entityName", e.ENTITIES.PAYMENT_TYPE.name)("entityDisplayName", e.formatMessage("payment_type_name_label"))
    }
}

function se(i, p) {
    if (i & 1) {
        let e = h();
        r(0, "form", 6), c("ngSubmit", function() {
            y(e);
            let t = s(2);
            return _(t.add())
        }), r(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), v(5, "dxi-validation-rule", 9), m()()()(), u(6, re, 1, 4, "app-server-error", 10), r(7, "app-save-cancel-footer", 11), c("cancelClick", function() {
            y(e);
            let t = s(2);
            return _(t.onClosing())
        }), m()()
    }
    if (i & 2) {
        let e = s(2);
        o("formGroup", e.form), a(2), o("errorMsg", e.formatMessage("payment_type_name_required_error"))("label", e.formatMessage("payment_type_name_label")), a(3), o("ignoreEmptyValue", !0)("message", e.formatMessage("validation_payment_type_exists"))("validationCallback", e.asyncUniqueNameValidation), a(), C(e.errorResponse ? 6 : -1), a(), o("isOnPopup", !0)
    }
}

function pe(i, p) {
    if (i & 1 && (r(0, "div")(1, "div", 2)(2, "div", 3), u(3, ae, 1, 2, "app-skeleton-loader", 4), u(4, se, 8, 8, "form", 5), m()()()), i & 2) {
        let e = s();
        a(3), C(e.form ? -1 : 3), a(), C(e.form ? 4 : -1)
    }
}
var ie = (() => {
    class i {
        constructor(e) {
            this.service = e, this.formatMessage = d, this.ENTITIES = P, this.formService = g(K), this.toastNotificationService = g(W), this.commonService = g(J), this.isVisiblePopup = !1, this.isCreate = !0, this.paymentType = null, this.paymentTypeSaveClick = new b, this.paymentTypeCancelClick = new b, this.entity = P.PAYMENT_TYPE, this.errorResponse = null, this.isSaving = !1, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.paymentType = new f(this.isCreate ? {} : this.paymentType), this.form = f.getForm(this.paymentType)
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.entity.table,
                name: e.value,
                entity_id: this.paymentType ? .id
            }).pipe(E(n => !!(n.hasOwnProperty("success") && n.success))).toPromise()
        }
        add() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: n => {
                    this.paymentType = new f(n), this.paymentTypeSaveClick.emit(this.paymentType), this.form = null, this.isVisiblePopup = !1, this.isSaving = !1, this.toastNotificationService.success(this.isCreate ? "notification_payment_type_add_success" : "notification_payment_type_update_success")
                },
                error: n => {
                    this.isSaving = !1, this.errorResponse = n
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.paymentType = null, this.paymentTypeCancelClick.emit()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.add()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || i)(S(w))
            }
        }
        static {
            this.\u0275cmp = V({
                type: i,
                selectors: [
                    ["app-payment-type"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate",
                    paymentType: "paymentType"
                },
                outputs: {
                    paymentTypeSaveClick: "paymentTypeSaveClick",
                    paymentTypeCancelClick: "paymentTypeCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", "placeholder", "eg. Cash, Card, Online, etc"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [3, "cancelClick", "isOnPopup"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(n, t) {
                    n & 1 && (r(0, "dx-popup", 0), c("onHidden", function() {
                        return t.onClosing()
                    }), G("visibleChange", function(T) {
                        return F(t.isVisiblePopup, T) || (t.isVisiblePopup = T), T
                    }), N(1, pe, 5, 2, "div", 1), m()), n & 2 && (A("visible", t.isVisiblePopup), o("width", "95vw")("maxWidth", 400)("title", t.isCreate ? t.formatMessage("payment_type_add_new") : t.formatMessage("payment_type_update")), a(), o("dxTemplateOf", "content"))
                },
                dependencies: [$, X, z, ee, j, Q, H, B, Z, O, I, L, U, q],
                encapsulation: 2
            })
        }
    }
    return i
})();

function le(i, p) {
    if (i & 1) {
        let e = h();
        r(0, "app-payment-type", 5), c("paymentTypeCancelClick", function() {
            y(e);
            let t = s();
            return _(t.isVisibleAddPaymentTypePopup = !1)
        })("paymentTypeSaveClick", function() {
            y(e);
            let t = s();
            return _(t.onPaymentTypeSave())
        }), m()
    }
    if (i & 2) {
        let e = s();
        o("paymentType", e.paymentType)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAddPaymentTypePopup)
    }
}
var Oe = (() => {
    class i {
        constructor(e) {
            this.service = e, this.formatMessage = d, this.isVisibleAddPaymentTypePopup = !1, this.isCreate = !1, this.entity = P.PAYMENT_TYPE, this.columns = [{
                dataField: "name",
                caption: d("payment_type_name"),
                width: 240,
                hidingPriority: 6,
                allowSorting: !0
            }, {
                dataField: "payments_count",
                caption: d("payments"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: d("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: d("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.paymentType = null
        }
        ngOnInit() {}
        create() {
            this.isVisibleAddPaymentTypePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.paymentType = e, this.isVisibleAddPaymentTypePopup = !0
        }
        onPaymentTypeSave() {
            this.isCreate = !1, this.isVisibleAddPaymentTypePopup = !1, this.paymentType = null, this.dataGrid.getData()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || i)(S(w))
            }
        }
        static {
            this.\u0275cmp = V({
                type: i,
                selectors: [
                    ["app-payment-type-list"]
                ],
                viewQuery: function(n, t) {
                    if (n & 1 && k(x, 5), n & 2) {
                        let l;
                        M(l = D()) && (t.dataGrid = l.first)
                    }
                },
                standalone: !1,
                decls: 5,
                vars: 7,
                consts: [
                    [1, "row"],
                    [1, "col-12"],
                    [3, "message"],
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "paymentType", "isCreate", "isVisiblePopup"],
                    [3, "paymentTypeCancelClick", "paymentTypeSaveClick", "paymentType", "isCreate", "isVisiblePopup"]
                ],
                template: function(n, t) {
                    n & 1 && (r(0, "div", 0)(1, "div", 1), v(2, "app-alert-panel", 2), r(3, "app-data-grid", 3), c("dataGridAddNewClick", function() {
                        return t.create()
                    })("dataGridEditClick", function(T) {
                        return t.edit(T)
                    }), m()()(), u(4, le, 1, 3, "app-payment-type", 4)), n & 2 && (a(2), o("message", t.formatMessage("payment_types_method_note")), a(), o("columns", t.columns)("entity", t.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", t.service), a(), C(t.isVisibleAddPaymentTypePopup ? 4 : -1))
                },
                dependencies: [x, te, ie],
                encapsulation: 2
            })
        }
    }
    return i
})();
export {
    Oe as a
};