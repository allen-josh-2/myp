import {
    V as _,
    Y as b,
    Z as T,
    ba as x,
    ca as k,
    ph as C
} from "./chunk-DCKGQUHB.js";
import {
    Fa as n,
    Ib as c,
    Jb as u,
    Kb as f,
    Na as l,
    Oa as g,
    aa as p,
    ba as h,
    da as d,
    ea as r,
    fb as a,
    gb as m,
    gf as M,
    hf as A,
    pd as v,
    sd as S,
    ui as y,
    vd as I,
    xk as o
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var N = (() => {
    class i {
        constructor(e) {
            this.api = e
        }
        impersonate(e) {
            return this.api.get(`${M}?token=${e}`)
        }
        getTenantDetails() {
            return this.api.get(A)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(d(y))
            }
        }
        static {
            this.\u0275prov = p({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var D = (() => {
    class i {
        constructor() {
            this.formatMessage = o, this.route = r(v), this.router = r(S), this.impersonationService = r(N), this.authService = r(T), this.storageService = r(_), this.toastService = r(k), this.configService = r(b), this.userSessionService = r(x)
        }
        ngOnInit() {
            let e = this.route.snapshot.queryParamMap.get("token");
            if (!e) {
                this.toastService.error(o("invalid_impersonation_token")), this.router.navigate(["/auth/login"]);
                return
            }
            this.storageService.loggedIn() ? (this.authService.clearUserSession(), localStorage.removeItem("tenantId"), localStorage.removeItem("tenant"), setTimeout(() => {
                this.impersonate(e)
            }, 100)) : (localStorage.removeItem("tenantId"), localStorage.removeItem("tenant"), this.impersonate(e))
        }
        impersonate(e) {
            this.impersonationService.impersonate(e).subscribe({
                next: t => {
                    this.handleLoginResponse(t)
                },
                error: t => {
                    let s = t.error ? .message || o("impersonation_failed");
                    this.toastService.error(s), this.router.navigate(["/auth/login"])
                }
            })
        }
        handleLoginResponse(e) {
            this.storageService.setToken(e.access_token), this.storageService.setImpersonating(e.is_impersonating ? ? !1), this.userSessionService.refreshImpersonationStatus(), this.impersonationService.getTenantDetails().subscribe({
                next: t => {
                    this.configService.setAppConfig(t), this.authService.setUserSession(e.user, e.access_token, e.permissions, "/dashboards"), this.toastService.success(o("logged_in_as", e.user.name))
                },
                error: t => {
                    this.authService.setUserSession(e.user, e.access_token, e.permissions, "/dashboards"), this.toastService.success(o("logged_in_as", e.user.name))
                }
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275cmp = l({
                type: i,
                selectors: [
                    ["app-admin-impersonate"]
                ],
                standalone: !1,
                decls: 6,
                vars: 2,
                consts: [
                    [1, "impersonate-loader"],
                    ["role", "status", 1, "spinner-border", "text-primary"],
                    [1, "visually-hidden"],
                    [1, "mt-3"]
                ],
                template: function(t, s) {
                    t & 1 && (a(0, "div", 0)(1, "div", 1)(2, "span", 2), c(3), m()(), a(4, "p", 3), c(5), m()()), t & 2 && (n(3), u(s.formatMessage("loading")), n(2), f("", s.formatMessage("authenticating"), "..."))
                },
                styles: [".impersonate-loader[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;background:var(--primary-bg)}.spinner-border[_ngcontent-%COMP%]{width:3rem;height:3rem}"]
            })
        }
    }
    return i
})();
var E = [{
        path: "impersonate",
        component: D
    }],
    W = (() => {
        class i {
            static {
                this.\u0275fac = function(t) {
                    return new(t || i)
                }
            }
            static {
                this.\u0275mod = g({
                    type: i
                })
            }
            static {
                this.\u0275inj = h({
                    imports: [C, I.forChild(E)]
                })
            }
        }
        return i
    })();
export {
    W as AdminModule
};