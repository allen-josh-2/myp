import {
    Ak as v,
    Ka as s,
    Na as c,
    aa as n,
    da as a,
    ea as o,
    hb as h,
    pd as p,
    qd as d,
    sd as m,
    ti as l,
    ui as f,
    xk as u
} from "./chunk-GOPIAW4V.js";
import "./chunk-FBFWB55K.js";
var S = (() => {
    class r extends l {
        constructor(t) {
            super(t, ""), this.api = t, this.endpoint = ""
        }
        getDestinationUrl(t) {
            return this.api.get(this.endpoint + `short/${t}`)
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || r)(a(f))
            }
        }
        static {
            this.\u0275prov = n({
                token: r,
                factory: r.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return r
})();
var x = (() => {
    class r {
        constructor(t, e) {
            this.service = t, this.loaderService = e, this.formatMessage = u, this.activatedRouter = o(p), this.router = o(m)
        }
        ngOnInit() {
            let t = this.activatedRouter.snapshot.params.shortUrlCode;
            this.loaderService.show(), this.service.getDestinationUrl(t).subscribe({
                next: e => {
                    let i = new URL(e.destination_url);
                    i.host.includes("bytephase") && !i.href.includes("attachments") ? this.router.navigateByUrl(i.pathname + i.search) : window.location.href = i.href
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || r)(s(S), s(v))
            }
        }
        static {
            this.\u0275cmp = c({
                type: r,
                selectors: [
                    ["app-short"]
                ],
                decls: 1,
                vars: 0,
                template: function(e, i) {
                    e & 1 && h(0, "router-outlet")
                },
                dependencies: [d],
                encapsulation: 2
            })
        }
    }
    return r
})();
export {
    x as ShortComponent
};