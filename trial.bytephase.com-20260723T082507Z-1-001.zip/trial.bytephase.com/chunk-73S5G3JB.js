import {
    aa as r,
    da as o,
    df as i,
    ti as n,
    ui as c
} from "./chunk-GOPIAW4V.js";
var h = (() => {
    class t extends n {
        constructor(e) {
            super(e, i), this.api = e, this.endpoint = i
        }
        checkUniqueName(e) {
            return this.api.post(this.endpoint + "/checkUniqueName", {
                name: e
            })
        }
        static {
            this.\u0275fac = function(s) {
                return new(s || t)(o(c))
            }
        }
        static {
            this.\u0275prov = r({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
export {
    h as a
};