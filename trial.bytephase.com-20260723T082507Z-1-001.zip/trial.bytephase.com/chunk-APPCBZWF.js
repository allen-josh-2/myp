import {
    a as ee
} from "./chunk-Q6732S4Z.js";
import {
    $ as q,
    C as G,
    T as k,
    aa as D,
    ab as X,
    ba as Y,
    bb as Z,
    ha as J,
    ia as K,
    ka as Q,
    ph as $
} from "./chunk-DCKGQUHB.js";
import {
    $a as b,
    Ak as O,
    Dc as L,
    Ec as N,
    Fa as a,
    Ib as r,
    Jb as u,
    Ka as M,
    Kb as I,
    Na as c,
    Oa as E,
    Pb as z,
    Qb as A,
    Rb as U,
    Sa as j,
    Tc as W,
    _a as x,
    ba as S,
    ea as m,
    eb as p,
    fb as i,
    gb as t,
    gc as C,
    hb as l,
    hc as y,
    pd as w,
    qa as R,
    qd as H,
    sb as d,
    sd as V,
    td as P,
    ub as g,
    vd as _,
    xk as f
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    i as F
} from "./chunk-FBFWB55K.js";

function ce(e, T) {
    if (e & 1 && (i(0, "p", 3), r(1), t()), e & 2) {
        let n = g();
        a(), u(n.message)
    }
}
var ie = (() => {
    class e {
        constructor(n) {
            this.loaderService = n, this.formatMessage = f, this.routerHelperService = m(D), this.userSessionService = m(Y), this.activatedRouter = m(w), this.isEmployee = this.userSessionService.isEmployee()
        }
        ngOnInit() {
            this.loaderService.hide(), this.activatedRouter.queryParams.subscribe({
                next: n => {
                    this.message = n.message
                },
                error: n => {
                    console.log(n)
                }
            })
        }
        back() {
            this.routerHelperService.goBack()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || e)(M(O))
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-forbidden"]
                ],
                standalone: !1,
                decls: 11,
                vars: 2,
                consts: [
                    [1, "row"],
                    [1, "col-12", "text-center"],
                    [1, "mt-5"],
                    [1, "text-center"],
                    [1, "fa-thin", "fa-grin-tongue", "fa-9x", "p-5", "forbidden-opacity"],
                    [1, "d-inline-flex", "me-2"],
                    ["buttonType", "default", "text", "back_to_previous_page", "title", "back_to_previous_page", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "go_home", "title", "go_home", 3, "routerLink"]
                ],
                template: function(o, s) {
                    o & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "h5"), r(4, "Access Denied"), t(), x(5, ce, 2, 1, "p", 3), i(6, "div"), l(7, "i", 4), t(), i(8, "div", 5)(9, "app-dx-outline-button", 6), d("onClickEvent", function() {
                        return s.back()
                    }), t()(), l(10, "app-dx-outline-button", 7), t()()()), o & 2 && (a(5), b(s.message ? 5 : -1), a(5), p("routerLink", s.isEmployee ? "/dashboards" : "/jobs"))
                },
                dependencies: [P, Q],
                encapsulation: 2
            })
        }
    }
    return e
})();

function de(e, T) {
    if (e & 1 && (i(0, "p", 7), r(1, " Did you mean "), i(2, "a", 13), r(3), t(), r(4, "? "), t()), e & 2) {
        let n = g();
        a(2), p("routerLink", n.path), a(), u(n.path)
    }
}
var ne = (() => {
    class e {
        constructor() {
            this.location = m(L), this.formatMessage = f
        }
        goBack() {
            this.location.back()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || e)
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-page-not-found"]
                ],
                standalone: !1,
                decls: 18,
                vars: 1,
                consts: [
                    [1, "d-flex", "align-items-center", "justify-content-center", "min-vh-100", "py-5"],
                    [1, "text-center", "px-3", 2, "max-width", "480px"],
                    [1, "text-primary", "mb-3"],
                    [1, "fa-thin", "fa-compass-slash", 2, "font-size", "5rem"],
                    [1, "display-3", "fw-semibold", "mb-1"],
                    [1, "text-body-emphasis", "mb-2"],
                    [1, "text-muted", "mb-4"],
                    [1, "small", "text-muted", "mb-3"],
                    [1, "d-flex", "flex-wrap", "gap-2", "justify-content-center"],
                    ["routerLink", "/", 1, "btn", "btn-primary", "text-white"],
                    [1, "fa-solid", "fa-house", "me-2"],
                    ["type", "button", 1, "btn", "btn-outline-secondary", 3, "click"],
                    [1, "fa-solid", "fa-arrow-left", "me-2"],
                    [3, "routerLink"]
                ],
                template: function(o, s) {
                    o & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2), l(3, "i", 3), t(), i(4, "h1", 4), r(5, "404"), t(), i(6, "h5", 5), r(7, "Page not found"), t(), i(8, "p", 6), r(9, " The page you're looking for doesn't exist or has been moved. "), t(), x(10, de, 5, 2, "p", 7), i(11, "div", 8)(12, "a", 9), l(13, "i", 10), r(14, "Go to Dashboard "), t(), i(15, "button", 11), d("click", function() {
                        return s.goBack()
                    }), l(16, "i", 12), r(17, "Go Back "), t()()()()), o & 2 && (a(10), b(s.path ? 10 : -1))
                },
                dependencies: [P],
                styles: ["h2[_ngcontent-%COMP%]{font-family:Patrick Hand SC,sans-serif;font-size:3rem;font-weight:400}"]
            })
        }
    }
    return e
})();

function fe(e, T) {
    if (e & 1 && (i(0, "p", 6), r(1), t()), e & 2) {
        let n = g(2);
        a(), u(n.message)
    }
}

function ue(e, T) {
    if (e & 1 && (i(0, "div")(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "h3", 5), r(5, "Access Denied"), t(), x(6, fe, 2, 1, "p", 6), i(7, "div"), l(8, "i", 7), t()()()()()), e & 2) {
        let n = g();
        a(6), b(n.message ? 6 : -1)
    }
}
var oe = (() => {
    class e {
        constructor(n) {
            this.loaderService = n, this.formatMessage = f, this.routerHelperService = m(D), this.activatedRouter = m(w), this.isVisiblePopup = !1
        }
        ngOnInit() {
            this.loaderService.hide(), this.activatedRouter.queryParams.subscribe({
                next: n => {
                    this.message = n.message, this.isVisiblePopup = n.isVisiblePopup
                },
                error: n => {
                    console.log(n)
                }
            })
        }
        onClosing() {
            this.isVisiblePopup = !1, this.routerHelperService.goBack()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || e)(M(O))
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-unauthorized-ipaccess"]
                ],
                standalone: !1,
                decls: 2,
                vars: 4,
                consts: [
                    ["id", "UnauthorizedIPAccess", "title", "Unauthorized IP Access", 3, "onHidden", "visibleChange", "visible", "width", "maxWidth"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-12", "text-center"],
                    [1, "mt-5"],
                    [1, "text-danger"],
                    [1, "text-center", "fs-5"],
                    [1, "fa-thin", "fa-grin-tongue", "fa-9x", "p-5", "text-danger", 2, "-webkit-text-stroke", "unset"]
                ],
                template: function(o, s) {
                    o & 1 && (i(0, "dx-popup", 0), d("onHidden", function() {
                        return s.onClosing()
                    }), U("visibleChange", function(B) {
                        return A(s.isVisiblePopup, B) || (s.isVisiblePopup = B), B
                    }), j(1, ue, 9, 1, "div", 1), t()), o & 2 && (z("visible", s.isVisiblePopup), p("width", "95vw")("maxWidth", 600), a(), p("dxTemplateOf", "content"))
                },
                dependencies: [J, X],
                encapsulation: 2
            })
        }
    }
    return e
})();
var re = (() => {
    class e {
        static {
            this.\u0275fac = function(o) {
                return new(o || e)
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-error"]
                ],
                standalone: !1,
                decls: 1,
                vars: 0,
                template: function(o, s) {
                    o & 1 && l(0, "router-outlet")
                },
                dependencies: [H],
                encapsulation: 2
            })
        }
    }
    return e
})();
var ae = (() => {
    class e {
        constructor() {
            this.router = m(V), this.nativeLinkService = m(q)
        }
        watchEmailSettingsVideo() {
            this.nativeLinkService.openExternal("https://youtu.be/h3huwbWG9iY")
        }
        fixEmailError() {
            this.router.navigate(["/settings/email"])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || e)
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-setup-email"]
                ],
                standalone: !1,
                decls: 28,
                vars: 2,
                consts: [
                    [1, "container-fluid"],
                    [1, "row", "mt-5"],
                    [1, "offset-1", "col-5"],
                    [1, "email-error-panel"],
                    [1, "d-flex", "justify-content-center", "align-items-center"],
                    ["alt", "Email Error Icon", "height", "85", "loading", "lazy", "src", "/src/assets/images/email-error-icon.png", "width", "85"],
                    [1, "display-3", "fw-bold", "text-danger"],
                    [1, "d-flex", "flex-column", "justify-content-center"],
                    [1, "d-flex", "justify-content-around"],
                    [1, "d-flex", "align-items-center", "justify-content-center", "flex-column"],
                    ["saveText", "Fix Email Error", "type", "success", 1, "btn-lg", "action-btn", "fw-bolder", "mt-1", 3, "saveBtnClick", "useSubmitBehavior"],
                    ["saveText", "Watch Video", 1, "btn-lg", "action-btn", "fw-bolder", "mt-1", 3, "saveBtnClick", "useSubmitBehavior"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "d-flex", "justify-content-end"],
                    ["alt", "Error Sending Email", "height", "450", "loading", "lazy", "src", "https://bytephase-public.s3.ap-south-1.amazonaws.com/assets/images/email-error.gif", 1, "img-fluid"]
                ],
                template: function(o, s) {
                    o & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4), l(5, "img", 5), t(), i(6, "h1", 6), r(7, "Error Sending Email"), t(), i(8, "div", 7)(9, "h3"), r(10, "Probable Reason:"), t(), i(11, "ul")(12, "li"), r(13, "You recently changed password of your email account"), t(), i(14, "li"), r(15, "Accidentally updated wrong email credentials"), t()()(), i(16, "div", 8)(17, "div", 9)(18, "small"), r(19, "Let's setup up the email right now!"), t(), i(20, "app-save-btn", 10), d("saveBtnClick", function() {
                        return s.fixEmailError()
                    }), t()(), i(21, "div", 9)(22, "small"), r(23, "Watch video to setup an emails."), t(), i(24, "app-save-btn", 11), d("saveBtnClick", function() {
                        return s.watchEmailSettingsVideo()
                    }), t()()()()(), i(25, "div", 12)(26, "div", 13), l(27, "img", 14), t()()()()), o & 2 && (a(20), p("useSubmitBehavior", !1), a(4), p("useSubmitBehavior", !1))
                },
                dependencies: [Z],
                styles: [".action-btn[_ngcontent-%COMP%]{font-size:1.2rem}li[_ngcontent-%COMP%]{font-size:1.25rem}.email-error-panel[_ngcontent-%COMP%]{display:grid;row-gap:2rem}"]
            })
        }
    }
    return e
})();
var se = (() => {
    class e {
        constructor() {
            this.formatMessage = f, this.isMobileDevice = m(k).isMobileDevice()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || e)
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-maintenance-page"]
                ],
                standalone: !1,
                decls: 12,
                vars: 3,
                consts: [
                    [1, "card", "container-fluid", "vh-100", "justify-content-center"],
                    ["id", "main_content", 1, "row", 3, "ngClass"],
                    [1, "col-lg-4", "col-md-4", "col-sm-4", 3, "ngClass"],
                    [1, "theme-secondary-bg", "text-center", "p-4"],
                    [1, "pb-2", "fw-bold", "fs-4"],
                    [1, "pb-1", "fs-5"],
                    [1, "col-lg-8", "col-md-8", "col-sm-8", 3, "ngClass"],
                    ["alt", "Under Maintenance Image", "height", "5100", "src", "../../../../../assets/images/under-maintenance.webp", "width", "9988", 1, "img-fluid"]
                ],
                template: function(o, s) {
                    o & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "h4", 4), r(5, "Site Enhancement Underway: A Brief Maintenance Break !!!"), t(), i(6, "p", 5), r(7, "We're behind the scenes making magic happen! Our website is temporarily down for maintenance. We appreciate your understanding and can't wait to reveal the improvements!, We'll be launching soon."), t(), l(8, "hr"), t()(), i(9, "div", 6)(10, "div"), l(11, "img", 7), t()()()()), o & 2 && (a(), p("ngClass", s.isMobileDevice ? "" : "card-body"), a(), p("ngClass", s.isMobileDevice ? "" : "m-auto"), a(7), p("ngClass", s.isMobileDevice ? "" : "m-auto"))
                },
                dependencies: [N],
                encapsulation: 2
            })
        }
    }
    return e
})();
var le = (() => {
    class e {
        constructor() {
            this.formatMessage = f, this.isMobileDevice = m(k).isMobileDevice(), this.networkService = m(ee), this.isRetrying = R(!1)
        }
        retry() {
            return F(this, null, function*() {
                if (!this.isRetrying()) {
                    this.isRetrying.set(!0);
                    try {
                        yield this.networkService.refresh()
                    } finally {
                        setTimeout(() => this.isRetrying.set(!1), 600)
                    }
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || e)
            }
        }
        static {
            this.\u0275cmp = c({
                type: e,
                selectors: [
                    ["app-offline"]
                ],
                standalone: !1,
                decls: 15,
                vars: 15,
                consts: [
                    [1, "offline-wrap", "d-flex", "flex-column", "align-items-center", "justify-content-center", "text-center"],
                    [1, "offline-icon", "mb-3"],
                    [1, "fa-solid", "fa-wifi-slash"],
                    [1, "offline-title", "mb-2"],
                    [1, "offline-subtitle", "mb-4", "text-muted"],
                    ["stylingMode", "contained", "type", "default", 3, "onClick", "text", "disabled"],
                    [1, "offline-hint", "mt-4", "text-muted", "small"]
                ],
                template: function(o, s) {
                    o & 1 && (i(0, "div", 0)(1, "div", 1), l(2, "i", 2), t(), i(3, "h2", 3), r(4), C(5, "translate"), t(), i(6, "p", 4), r(7), C(8, "translate"), t(), i(9, "dx-button", 5), C(10, "translate"), C(11, "translate"), d("onClick", function() {
                        return s.retry()
                    }), t(), i(12, "p", 6), r(13), C(14, "translate"), t()()), o & 2 && (a(4), u(y(5, 5, "offline_title")), a(3), I(" ", y(8, 7, "offline_subtitle"), " "), a(2), p("text", s.isRetrying() ? y(10, 9, "retrying") : y(11, 11, "retry"))("disabled", s.isRetrying()), a(4), I(" ", y(14, 13, "offline_hint"), " "))
                },
                dependencies: [K, G],
                styles: [".offline-wrap[_ngcontent-%COMP%]{min-height:100dvh;padding:24px;padding-top:calc(24px + env(safe-area-inset-top,0));padding-bottom:calc(24px + env(safe-area-inset-bottom,0));background:var(--bg-body, #ffffff)}.offline-icon[_ngcontent-%COMP%]{width:80px;height:80px;border-radius:20px;background:#3498db1f;color:#3498db;font-size:34px;display:flex;align-items:center;justify-content:center}.offline-title[_ngcontent-%COMP%]{font-weight:700;font-size:22px;letter-spacing:-.01em}.offline-subtitle[_ngcontent-%COMP%]{max-width:320px;line-height:1.5}.offline-hint[_ngcontent-%COMP%]{max-width:300px;opacity:.7}body.dark-theme[_nghost-%COMP%]   .offline-wrap[_ngcontent-%COMP%], body.dark-theme   [_nghost-%COMP%]   .offline-wrap[_ngcontent-%COMP%]{background:#10172a;color:#e8eefb}body.dark-theme[_nghost-%COMP%]   .offline-icon[_ngcontent-%COMP%], body.dark-theme   [_nghost-%COMP%]   .offline-icon[_ngcontent-%COMP%]{background:#3498db2e}"]
            })
        }
    }
    return e
})();
var he = [{
        path: "",
        component: re
    }, {
        path: "forbidden",
        component: ie,
        pathMatch: "full",
        data: {
            title: "BytePhase | Forbidden"
        }
    }, {
        path: "maintenance",
        component: se,
        pathMatch: "full",
        data: {
            title: "Maintenance Mode"
        }
    }, {
        path: "UnauthorizedIPAccess",
        component: oe,
        pathMatch: "full",
        data: {
            title: "BytePhase | UnauthorizedIPAccess"
        }
    }, {
        path: "404",
        component: ne,
        pathMatch: "full",
        data: {
            title: "Page Not Found"
        }
    }, {
        path: "setup-emails",
        component: ae,
        pathMatch: "full",
        data: {
            title: "Guess the domain"
        }
    }, {
        path: "offline",
        component: le,
        pathMatch: "full",
        data: {
            title: "Offline"
        }
    }],
    me = (() => {
        class e {
            static {
                this.\u0275fac = function(o) {
                    return new(o || e)
                }
            }
            static {
                this.\u0275mod = E({
                    type: e
                })
            }
            static {
                this.\u0275inj = S({
                    imports: [_.forChild(he), _]
                })
            }
        }
        return e
    })();
var Bt = (() => {
    class e {
        static {
            this.\u0275fac = function(o) {
                return new(o || e)
            }
        }
        static {
            this.\u0275mod = E({
                type: e
            })
        }
        static {
            this.\u0275inj = S({
                imports: [W, me, _, $]
            })
        }
    }
    return e
})();
export {
    Bt as ErrorModule
};