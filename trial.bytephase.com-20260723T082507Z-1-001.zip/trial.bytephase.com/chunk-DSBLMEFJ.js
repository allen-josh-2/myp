import {
    a as pn
} from "./chunk-OG4EABPU.js";
import {
    a as dn
} from "./chunk-MBAKXBI4.js";
import {
    a as bi
} from "./chunk-KJCCJCIN.js";
import {
    $b as Ne,
    $d as Ft,
    Ab as at,
    Bb as Li,
    Db as rt,
    Df as Ve,
    Ec as Ct,
    Ef as tn,
    Ff as yt,
    Gf as nn,
    Hd as Qi,
    Hf as on,
    Ib as Fi,
    If as an,
    Jb as ct,
    Jd as Ce,
    Jf as rn,
    Kb as ki,
    L as di,
    Lb as st,
    M as Ot,
    Mb as Ui,
    Qb as lt,
    Qe as Zi,
    Qf as St,
    Rb as mt,
    Re as Ji,
    Rf as cn,
    Sc as De,
    T as O,
    Ta as me,
    Ud as Xi,
    Ue as Ki,
    Va as wi,
    Vb as pt,
    Y as Mi,
    Yc as qi,
    Zd as $,
    _b as ue,
    _d as L,
    ab as be,
    ac as we,
    ba as b,
    ca as Q,
    cb as pe,
    cd as vt,
    dd as Wi,
    e as B,
    ec as Yi,
    ed as ft,
    fb as Oi,
    fc as Bi,
    g as oe,
    gc as Oe,
    h as ae,
    ha as Me,
    hc as Gi,
    ia as Ii,
    ic as dt,
    ja as Pi,
    jb as it,
    jc as _t,
    jg as sn,
    ka as Ni,
    kd as Hi,
    l as U,
    lb as Ie,
    n as re,
    nb as Di,
    ob as Pe,
    oe as $i,
    pb as de,
    ph as G,
    q as Se,
    qb as nt,
    qd as zi,
    rd as Tt,
    rg as At,
    sb as _e,
    t as ce,
    tg as ln,
    u as se,
    ub as Vi,
    uc as ji,
    uf as K,
    ug as gt,
    vd as ht,
    vf as F,
    wg as xt,
    xb as Ri,
    xf as en,
    xg as mn,
    y as Ae,
    yb as ot,
    yc as ut
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    $b as Je,
    Ab as H,
    Ai as ze,
    Ak as X,
    Ba as $e,
    Bi as xi,
    Ci as Qe,
    Di as Ei,
    Ec as ne,
    Fa as i,
    Fh as x,
    Fi as Lt,
    Gc as oi,
    Gh as yi,
    Hb as Ge,
    Hc as ai,
    Hg as ui,
    Ib as p,
    Ic as ri,
    Jb as P,
    Ka as g,
    Kb as f,
    Lb as ti,
    Lh as Rt,
    Na as A,
    Nh as V,
    Oa as Ze,
    Oh as le,
    Pb as ee,
    Pc as ci,
    Qb as te,
    Ra as ye,
    Rb as ie,
    Rd as et,
    Sa as R,
    Tc as si,
    Wa as Jt,
    Wb as je,
    Xb as ii,
    Yh as z,
    _a as _,
    aa as fe,
    ai as Si,
    ba as Xe,
    bb as Ue,
    bc as J,
    cb as Ye,
    cc as Ke,
    ch as tt,
    da as Te,
    db as Be,
    de as _i,
    ea as C,
    eb as r,
    fb as c,
    fd as li,
    fe as Dt,
    fh as Ci,
    fi as Ai,
    gb as a,
    gc as k,
    ge as Vt,
    gh as vi,
    ha as y,
    hb as m,
    hc as wt,
    hh as We,
    hi as M,
    ia as S,
    ic as j,
    ih as fi,
    ii as He,
    jh as Ti,
    ji as gi,
    kc as ni,
    lb as Kt,
    mb as ei,
    oa as Z,
    pd as N,
    ph as hi,
    qa as $t,
    qb as I,
    qd as mi,
    rh as D,
    sa as Zt,
    sb as h,
    sd as Y,
    sh as T,
    ta as he,
    td as pi,
    ti as ge,
    ub as l,
    ui as xe,
    vd as qe,
    xk as d,
    yb as q,
    z as ke,
    zb as W,
    zi as Ee
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var _n = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-software-device-information"]
                ],
                decls: 1,
                vars: 0,
                template: function(o, n) {
                    o & 1 && m(0, "router-outlet")
                },
                dependencies: [qe, mi],
                encapsulation: 2
            })
        }
    }
    return t
})();
var un = (() => {
    class t {
        constructor() {
            this.formatMessage = d, this.moduleDataService = C(sn), this.router = C(Y), this.userSessionService = C(b), this.activatedRouter = C(N), this.isMobileDevice = C(O).isMobileDevice(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = M, this.selectedTabIndex = 0, this.amcModuleTabs = [{
                id: 0,
                text: d("contracts"),
                path: "/amcs/list",
                visible: this.userPermissionList.includes(x.AMC_CONTRACT_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.AMC_CONTRACT.name)
            }, {
                id: 1,
                text: d("services"),
                path: "/amcs/amcServices",
                visible: this.userPermissionList.includes(x.AMC_SERVICE_LIST)
            }, {
                id: 2,
                text: d("complaints"),
                path: "/amcs/amcComplaints",
                visible: this.userPermissionList.includes(x.AMC_COMPLAINT_LIST)
            }, {
                id: 3,
                text: d("overview"),
                path: "/amcs/amcOverview",
                visible: this.userPermissionList.includes(x.BUSINESS_SETTING_VIEW)
            }], this.ENTITY_ICONS = Ee, this.activatedRouter.firstChild ? .data.subscribe({
                next: e => {
                    this.selectedTabIndex = e.tab_index
                },
                error: e => {
                    console.error("failed to get selected tab index ", e)
                }
            })
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-component"]
                ],
                standalone: !1,
                decls: 2,
                vars: 8,
                consts: [
                    [1, "container-fluid"],
                    ["mode", "route", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "hideContentHeader", "contentContainerClass", "mobileMenuTitle", "mobileMenuIcon"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "app-responsive-tabs", 1), h("tabChange", function(E) {
                        return n.selectTab(E)
                    }), a()()), o & 2 && (i(), r("tabs", n.amcModuleTabs)("selectedIndex", n.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("hideContentHeader", !0)("contentContainerClass", n.isMobileDevice ? "mb-5" : "")("mobileMenuTitle", n.formatMessage("amc"))("mobileMenuIcon", n.ENTITY_ICONS.AMC_CONTRACT.solid))
                },
                dependencies: [At],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Zn(t, s) {
    if (t & 1 && m(0, "app-send-whats-app-btn", 5), t & 2) {
        let e = l();
        r("entityId", e.amcContract == null ? null : e.amcContract.id)("entityName", e.ENTITIES.AMC_CONTRACT.name)
    }
}

function Jn(t, s) {
    if (t & 1 && m(0, "app-send-notification", 7), t & 2) {
        let e = l();
        r("entityObj", e.amcContract)("entity", e.ENTITIES.AMC_CONTRACT)
    }
}

function Kn(t, s) {
    if (t & 1 && (m(0, "app-currency-symbol"), p(1)), t & 2) {
        let e = l(4);
        i(), f(" ", e.amcContract.total_amount, " ")
    }
}

function eo(t, s) {
    if (t & 1 && (c(0, "div", 20)(1, "span", 22), p(2), a(), c(3, "span", 23), p(4, ":"), a(), _(5, Kn, 2, 1), a()), t & 2) {
        let e = l(3);
        i(2), P(e.formatMessage("payment_payable_amount")), i(3), u(e.amcContract.total_amount ? 5 : -1)
    }
}

function to(t, s) {
    if (t & 1 && (c(0, "div", 21)(1, "span", 24), p(2), a(), c(3, "span", 23), p(4, ":"), a(), m(5, "app-currency-symbol"), p(6), a()), t & 2) {
        let e = l(3);
        i(2), f("", e.formatMessage("payment_received"), " "), i(4), f(" ", e.amcContract.payment_received, " ")
    }
}

function io(t, s) {
    if (t & 1 && (c(0, "div", 21)(1, "span", 24), p(2), a(), c(3, "span", 23), p(4, ":"), a(), p(5), a()), t & 2) {
        let e = l(3);
        i(2), f("", e.formatMessage("payment_frequency"), " "), i(3), f("", e.amcContract.payment_frequency, " ")
    }
}

function no(t, s) {
    if (t & 1 && (c(0, "div", 20)(1, "span", 25), p(2), a(), c(3, "span", 23), p(4, ": "), m(5, "app-status-tag", 26), a()()), t & 2) {
        let e = l(3);
        i(2), f("", e.formatMessage("payment_status"), ":"), i(3), r("status", e.amcContract.payment_status)
    }
}

function oo(t, s) {
    if (t & 1 && (c(0, "div", 15)(1, "div", 2)(2, "h5", 19), p(3), a(), c(4, "div", 1), _(5, eo, 6, 2, "div", 20), _(6, to, 7, 2, "div", 21), _(7, io, 6, 2, "div", 21), _(8, no, 6, 2, "div", 20), a()()()), t & 2) {
        let e = l(2);
        i(3), f(" ", e.formatMessage("payment_information"), " "), i(2), u(e.printOptions.total_amount && e.amcContract.total_amount ? 5 : -1), i(), u(e.printOptions.payment_received && e.amcContract.payment_received ? 6 : -1), i(), u(e.printOptions.payment_frequency && e.amcContract.payment_frequency ? 7 : -1), i(), u(e.printOptions.payment_status && e.amcContract.payment_status ? 8 : -1)
    }
}

function ao(t, s) {
    if (t & 1 && m(0, "app-invoice-term-and-conditions", 16), t & 2) {
        let e = l(2);
        r("termAndCondition", e.amcContract.term_and_condition)
    }
}

function ro(t, s) {
    if (t & 1 && (c(0, "div", 10)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2), m(5, "app-invoice-header", 11)(6, "app-invoice-title", 12)(7, "app-invoice-customer-detail", 13)(8, "app-invoice-amc-contract-details", 14), _(9, oo, 9, 5, "div", 15), _(10, ao, 1, 1, "app-invoice-term-and-conditions", 16), m(11, "hr", 17)(12, "app-invoice-signature", 18), a()()()()()), t & 2) {
        let e = l();
        r("ngClass", e.isMobileDevice ? "p-0" : ""), i(5), r("account", e.account)("qrCode", (e.amcContract == null ? null : e.amcContract.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.amcContract == null ? null : e.amcContract.qr_code)), i(), r("dateTime", e.amcContract == null ? null : e.amcContract.created_at)("title", e.formatMessage("amc_contract_no") + " : " + (e.amcContract == null ? null : e.amcContract.contract_number)), i(), r("userId", e.amcContract.user_id), i(), r("amcContract", e.amcContract), i(), u(e.printOptions.total_amount && e.amcContract.total_amount ? 9 : -1), i(), u(e.amcContract.term_and_condition ? 10 : -1), i(2), r("entityId", e.amcContract == null ? null : e.amcContract.id)("entityType", e.entityType)
    }
}
var vn = (() => {
    class t {
        constructor(e, o) {
            this.amcContractService = e, this.loaderService = o, this.formatMessage = d, this.generalSettingDataService = C(rt), this.userSessionService = C(b), this.configService = C(Mi), this.isEmployee = this.userSessionService.isEmployee(), this.activatedRouter = C(N), this.isMobileDevice = C(O).isMobileDevice(), this.ENTITIES = M, this.isEditMode = !0, this.isVisibleSaveConfirmPopup = !1, this.entityType = M.AMC_CONTRACT.name, this.dateTime = new Date, this.wantTechnicianCopy = !0, this.printOptions = null, this.printOptions = this.generalSettingDataService.getGeneralSettingBySettingType(He.AMC_CONTRACT_PRINT_SETTINGS) ? ? Li.getEmptyObject(), this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(He.PRINT_SETTINGS) ? ? at.getEmptyObject()
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("amc_contract_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("amc_contract_id");
                this.loaderService.show(), ke([this.amcContractService.getDetailById(e)]).subscribe({
                    next: ([o]) => {
                        this.configService.appConfig$.subscribe({
                            next: n => {
                                this.account = n
                            },
                            error: n => {
                                console.log(n)
                            }
                        }), this.amcContract = o
                    },
                    error: o => {
                        console.error(o)
                    }
                }).add(() => {
                    this.loaderService.hide()
                })
            }
        }
        toggle() {
            this.wantTechnicianCopy = !this.wantTechnicianCopy
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(F), g(X))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-contract"]
                ],
                standalone: !1,
                decls: 13,
                vars: 12,
                consts: [
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "title-text", "float-start", "m-1"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [1, "ms-1", 3, "amcContractId"],
                    [1, "ms-1", 3, "entityObj", "entity"],
                    [1, "ms-1", 3, "entityId", "entityName", "isVisiblePrintButton", "isVisibleThermalPrint"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "amcContract"],
                    [1, "row", "background-row", "mb-3"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "ps-4"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold", "ms-1"],
                    [1, "px-1"],
                    [1, "fw-bold", "ms-3"],
                    [1, "fw-bolder", "ms-1"],
                    [3, "status"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div")(1, "div", 0)(2, "div", 1)(3, "div", 2)(4, "span", 3), p(5), a(), c(6, "div", 4), _(7, Zn, 1, 2, "app-send-whats-app-btn", 5), m(8, "app-amc-contract-btn", 6), _(9, Jn, 1, 2, "app-send-notification", 7), m(10, "app-print-button", 8)(11, "app-share-btn", 9), a()()()(), _(12, ro, 13, 11, "div", 10), a()), o & 2 && (i(), r("ngClass", n.isMobileDevice ? "p-0" : ""), i(4), f(" ", n.amcContract == null ? null : n.amcContract.contract_number, " "), i(2), u(n.amcContract && n.isEmployee ? 7 : -1), i(), r("amcContractId", n.amcContract == null ? null : n.amcContract.id), i(), u(n.amcContract && n.isEmployee && !n.isMobileDevice ? 9 : -1), i(), r("entityId", n.amcContract == null ? null : n.amcContract.id)("entityName", n.ENTITIES.AMC_CONTRACT.name)("isVisiblePrintButton", !!(n.amcContract != null && n.amcContract.id))("isVisibleThermalPrint", !1), i(), r("entityId", n.amcContract == null ? null : n.amcContract.id)("entityType", n.ENTITIES.AMC_CONTRACT.name), i(), u(n.amcContract ? 12 : -1))
                },
                dependencies: [ne, ct, Ui, Zi, lt, mt, it, Ce, pt, dt, gt, xt, _t, De],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var Tn = (() => {
    class t extends ge {
        constructor(e) {
            super(e, _i), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(xe))
            }
        }
        static {
            this.\u0275prov = fe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function uo(t, s) {
    t & 1 && m(0, "app-skeleton-loader", 1), t & 2 && r("rows", 8)("columns", 3)
}

function Co(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-save-cancel-footer", 46), h("cancelClick", function() {
            y(e);
            let n = l(3);
            return S(n.cancel())
        }), a()
    }
    if (t & 2) {
        let e = l(3);
        r("isSaving", e.isSaving)("isVisibleHr", !1)("saveText", e.amcContractId ? "common_save" : "create_button")
    }
}

function vo(t, s) {
    if (t & 1 && R(0, Co, 1, 3, "app-save-cancel-footer", 45), t & 2) {
        let e = l(2);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.AMC_CONTRACT_WRITE)
    }
}

function fo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-dx-outline-button", 49), h("onClickEvent", function() {
            y(e);
            let n = l(4);
            return S(n.setEditMode())
        }), a()
    }
}

function To(t, s) {
    if (t & 1 && R(0, fo, 1, 0, "app-dx-outline-button", 48), t & 2) {
        let e = l(3);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.AMC_CONTRACT_WRITE)
    }
}

function ho(t, s) {
    if (t & 1 && _(0, To, 1, 1, "app-dx-outline-button", 47), t & 2) {
        let e = l(2);
        u(e.userPermissionList.includes(e.PERMISSION_LIST.AMC_CONTRACT_WRITE) ? 0 : -1)
    }
}

function yo(t, s) {
    if (t & 1 && (c(0, "app-control-container", 13), m(1, "app-employee-dropdown", 50), a()), t & 2) {
        let e = l(2);
        r("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("common_assignee"))("tooltipText", "amc_contact_assignee_id"), i(), r("entity", e.AMC_CONTRACT)("formControl", e.form.controls.assignee_id)("isEditMode", e.isEditMode)
    }
}

function So(t, s) {
    t & 1 && m(0, "app-section-title", 34), t & 2 && r("title", "payment_information")
}

function Ao(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-attachments", 51), h("afterSaving", function(n) {
            y(e);
            let v = l(2);
            return S(v.afterFileUpload(n))
        }), a()
    }
    if (t & 2) {
        let e = l(2);
        r("attachableType", e.attachableType)("entity", e.amcContract)("isEditMode", e.isEditMode)("isMultipleUploads", !0)
    }
}

function go(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "form", 4), h("ngSubmit", function() {
            y(e);
            let n = l();
            return S(n.save())
        }), c(1, "div", 5)(2, "div", 6), _(3, vo, 1, 1, "app-save-cancel-footer", 7)(4, ho, 1, 1), a()(), c(5, "div", 8)(6, "div", 6), m(7, "app-section-title", 9), c(8, "div", 10)(9, "app-control-container", 11)(10, "app-customer-dropdown", 12), h("itemClick", function(n) {
            y(e);
            let v = l();
            return S(v.onAddCustomer(n))
        }), a()(), _(11, yo, 2, 6, "app-control-container", 13), c(12, "app-control-container", 14), m(13, "dx-select-box", 15), a(), c(14, "app-control-container", 16), m(15, "dx-date-box", 17), a(), c(16, "app-control-container", 18), m(17, "dx-date-box", 19), a()(), m(18, "app-section-title", 20), c(19, "div", 10)(20, "app-control-container", 21), m(21, "dx-number-box", 22), a(), c(22, "app-control-container", 23)(23, "div", 24), m(24, "dx-number-box", 25)(25, "dx-select-box", 26), a()(), c(26, "app-control-container", 27), m(27, "dx-number-box", 28)(28, "app-error", 29), a(), c(29, "app-control-container", 30), m(30, "dx-select-box", 31), a(), c(31, "app-control-container", 32), m(32, "app-switch-btn", 33), a()(), c(33, "div", 10), _(34, So, 1, 1, "app-section-title", 34), c(35, "app-control-container", 35), m(36, "dx-select-box", 36), a(), c(37, "app-control-container", 37), m(38, "dx-number-box", 38)(39, "app-error", 29), a()(), m(40, "app-show-custom-fields", 39), c(41, "app-control-container", 40), m(42, "app-textarea", 41), a(), _(43, Ao, 1, 4, "app-attachments", 42), c(44, "app-control-container", 43), m(45, "app-textarea", 44), a()()()()
    }
    if (t & 2) {
        let e, o = l();
        r("formGroup", o.form), i(3), u(o.isEditMode ? 3 : 4), i(4), r("title", "contract_information"), i(2), r("errorMsg", o.formatMessage("common_error_messages_customer_name_required"))("label", o.formatMessage("user_customer_name")), i(), r("customerId", o.form.getRawValue().id ? (e = o.form.getRawValue()) == null ? null : e.user_id : null)("formControl", o.form.controls.user_id)("isEditMode", o.isEditMode)("showCrateButton", !0), i(), u(o.isEmployee ? 11 : -1), i(), r("errorMsg", o.formatMessage("amc_type_required"))("label", o.formatMessage("amc_type")), i(), r("items", o.amcTypes)("placeholder", o.formatMessage("select_amc_type")), i(), r("errorMsg", o.formatMessage("contract_start_date_required"))("label", o.formatMessage("contract_start_date")), i(), r("dateSerializationFormat", o.DATETIME_SERIALIZATION_FORMAT)("displayFormat", "dd-MMM-yyyy")("pickerType", o.isMobileDevice ? "rollers" : "calendar")("placeholder", o.formatMessage("select_contract_start_date")), i(), r("errorMsg", o.formatMessage("contract_end_date_required"))("label", o.formatMessage("contract_end_date")), i(), r("dateSerializationFormat", o.DATETIME_SERIALIZATION_FORMAT)("displayFormat", "dd-MMM-yyyy")("pickerType", o.isMobileDevice ? "rollers" : "calendar")("placeholder", o.formatMessage("select_contract_end_date")), i(), r("title", "coverage_details"), i(2), r("errorMsg", o.formatMessage("number_of_devices_required"))("label", o.formatMessage("number_of_devices")), i(), r("min", 0), i(), r("errorMsg", o.formatMessage("response_time_required"))("label", o.formatMessage("response_time"))("tooltipText", "amc_contact_response_time"), i(2), r("placeholder", o.formatMessage("response_time_placeholder")), i(), r("items", o.RESPONSE_TIME)("searchEnabled", !1), i(), r("errorMsg", o.formatMessage("number_of_services_required"))("label", o.formatMessage("number_of_services"))("tooltipText", "amc_contact_number_of_services"), i(), r("min", 0), i(), r("displayError", o.form.get("number_of_services").invalid && o.form.get("number_of_services").touched)("errorMsg", o.formatMessage("notification_service")), i(), r("errorMsg", o.formatMessage("service_options_required"))("label", o.formatMessage("service_options"))("tooltipText", "amc_contact_service_options"), i(), r("items", o.SERVICE_OPTIONS)("placeholder", o.formatMessage("select_service_options")), i(), r("isLabelOnSameLine", !0)("tooltipText", "amc_contact_is_contract_auto_renew"), i(), r("isEditMode", o.isEditMode)("label", o.formatMessage("contract_auto_renew")), i(2), u(o.hasAddPaymentPermission ? 34 : -1), i(), r("errorMsg", o.formatMessage("service_options_required"))("label", o.formatMessage("payment_frequency")), i(), r("items", o.PAYMENT_FREQUENCY)("placeholder", o.formatMessage("example_payment_frequency")), i(), r("errorMsg", o.formatMessage("common_amount_required"))("label", o.formatMessage("common_amount")), i(), r("format", o.CURRENCY_FORMAT)("placeholder", o.formatMessage("enter_contract_amount"))("showClearButton", !0), i(), r("displayError", o.form.get("total_amount").invalid && o.form.get("total_amount").touched)("errorMsg", o.formatMessage("common_error_messages_amount_invalid")), i(), r("formType", o.FORM_TYPE_LIST.AMC_CONTRACT)("form", o.form)("hasColumn", 4), i(), r("errorMsg", o.formatMessage("remark_required"))("label", o.formatMessage("contract_remark")), i(), r("isEditMode", o.isEditMode)("placeholder", o.formatMessage("type_contract_remark")), i(), u(o.amcContract ? 43 : -1), i(), r("errorMsg", o.formatMessage("common_error_messages_term_and_condition"))("label", o.formatMessage("common_terms_and_conditions")), i(), r("isEditMode", o.isEditMode)
    }
}

function xo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-send-notification", 52), h("sendNotificationClose", function() {
            y(e);
            let n = l();
            return S(n.redirectToContractDetail())
        })("sendNotificationSave", function() {
            y(e);
            let n = l();
            return S(n.redirectToContractDetail())
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("entityObj", e.amcContract)("entity", e.ENTITIES.AMC_CONTRACT)("isVisiblePopup", e.isVisibleNotificationPopup)("isVisibleSendButton", !1)
    }
}
var bt = (() => {
    class t {
        constructor(e, o, n, v, E, Un) {
            this.service = e, this.amcTypeService = o, this.tableSequenceNumberService = n, this.applicationRef = v, this.termAndConditionService = E, this.loaderService = Un, this.formatMessage = d, this.ENTITIES = M, this.AMC_CONTRACT = M.AMC_CONTRACT, this.formService = C(de), this.router = C(Y), this.userSessionService = C(b), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.activatedRouter = C(N), this.toastNotificationService = C(Q), this.isMobileDevice = C(O).isMobileDevice(), this.RESPONSE_TIME = Object.values(Ci), this.SERVICE_OPTIONS = Object.values(vi), this.PAYMENT_FREQUENCY = Object.values(fi), this.DATETIME_SERIALIZATION_FORMAT = et, this.CURRENCY_FORMAT = ui, this.hasAddPaymentPermission = this.isEmployee && this.userPermissionList.includes(x.PAYMENT_WRITE), this.amcContractId = null, this.amcContract = null, this.attachableType = M.AMC_CONTRACT.name, this.isVisibleNotificationPopup = !1, this.isEditMode = !0, this.form = null, this.isSaving = !1, this.errorResponse = null, this.PERMISSION_LIST = x, this.FORM_TYPE_LIST = tt, this.SETTINGS_SECTION_TYPE = gi
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = null, this.amcContractId = +e.amc_contract_id, this.initialize()
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.amcContractId ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => this.handleSaveResponse(o),
                error: o => this.handleErrorResponse(o)
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        afterFileUpload(e) {
            e || this.handleSaveSuccess()
        }
        handleSaveSuccess() {
            this.isSaving = !1, this.loaderService.hide(), this.activatedRouter.snapshot.parent.paramMap.has("amc_contract_id") ? (this.toastNotificationService.success("contract_updated_successfully"), this.setReadOnlyMode()) : (this.toastNotificationService.success("contract_created_successfully"), this.isVisibleNotificationPopup = !0)
        }
        onAddCustomer(e) {
            this.form.patchValue({
                user_id: e.id
            })
        }
        cancel() {
            this.setReadOnlyMode()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        setReadOnlyMode() {
            this.isSaving = !1, this.isEditMode = !1, this.form.disable()
        }
        initialize() {
            ke([this.amcTypeService.getListByQuery()]).subscribe({
                next: ([e]) => {
                    this.amcTypes = e, this.setForm()
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        setForm() {
            this.amcContractId ? (this.loaderService.show(), this.service.getDetailById(this.amcContractId).subscribe({
                next: e => {
                    this.amcContract = e, this.form = K.getForm(this.amcContract), this.setReadOnlyMode()
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })) : (this.loaderService.show(), ke([this.tableSequenceNumberService.getListByQuery({
                name: Si.AMC_CONTRACT.name
            }), this.termAndConditionService.getByTypeId({
                type_id: Ai.AMC_CONTRACT
            })]).subscribe({
                next: ([e, o]) => {
                    this.form = K.getForm(new K({
                        contract_number: e[0].current_value,
                        term_and_condition: o ? .text ? ? ""
                    })), this.amcContract = new K({}), this.setEditMode()
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.loaderService.hide()
            }))
        }
        redirectToContractDetail() {
            this.isVisibleNotificationPopup = !1, this.router.navigate([`/amcs/${this.amcContract.id}/device/list`])
        }
        handleSaveResponse(e) {
            this.amcContractId ? (this.amcContract = e, this.amcContract = new K(e), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.amcContract)) : (this.amcContract = new K(e), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.amcContract), this.form.disable(), this.isEditMode = !1)
        }
        handleErrorResponse(e) {
            if (this.errorResponse = e, "message" in this.errorResponse.error) {
                if (this.errorResponse.error.message) {
                    this.toastNotificationService.error("notification_service", "", {
                        disableTimeOut: !0
                    });
                    return
                }
                this.toastNotificationService.error("notification_part_add_error", "", {
                    disableTimeOut: !0
                })
            }
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(F), g(Tn), g(dn), g(Jt), g(ki), g(X))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-contract-detail"]
                ],
                viewQuery: function(o, n) {
                    if (o & 1 && q(ft, 5), o & 2) {
                        let v;
                        W(v = H()) && (n.attachmentInstance = v.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 3,
                consts: [
                    [1, "form-container"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "isSaving", "isVisibleHr", "saveText"],
                    [1, "row", "mt-4"],
                    [1, "mb-3", 3, "title"],
                    [1, "row", "mb-5"],
                    ["name", "user_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "showCrateButton"],
                    ["name", "assignee_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["name", "amc_type_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "amc_type_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder"],
                    ["name", "start_date", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "start_date", "type", "date", 3, "dateSerializationFormat", "displayFormat", "pickerType", "placeholder"],
                    ["name", "end_date", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "end_date", "type", "date", 3, "dateSerializationFormat", "displayFormat", "pickerType", "placeholder"],
                    ["id", "contract-coverage-details-title", 1, "mt-3", 3, "title"],
                    ["name", "number_of_devices_covered", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "number_of_devices_covered", "id", "add-number-of-devices-covered", "placeholder", "Eg: 5, 10 etc...", 3, "min"],
                    ["name", "response_time", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    [1, "input-group"],
                    ["aria-label", "Response Time", "formControlName", "response_time", 1, "w-75", 3, "placeholder"],
                    ["formControlName", "response_time_unit", "searchMode", "startswith", 1, "form-control", "w-25", 3, "items", "searchEnabled"],
                    ["name", "number_of_services", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["formControlName", "number_of_services", "id", "add-number-of-services", "placeholder", "Eg: 5, 10 etc...", 3, "min"],
                    [3, "displayError", "errorMsg"],
                    ["name", "service_options", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["formControlName", "service_options", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "is_contract_auto_renew", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "isLabelOnSameLine", "tooltipText"],
                    ["formControlName", "is_contract_auto_renew", 3, "isEditMode", "label"],
                    ["id", "payment-information-title", 1, "mt-3", "mb-2", 3, "title"],
                    ["name", "payment_frequency", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "payment_frequency", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "total_amount", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "total_amount", "id", "contract-total-amount", 3, "format", "placeholder", "showClearButton"],
                    [1, "row", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    ["name", "remark", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "remark", "id", "contract-remark", 3, "isEditMode", "placeholder"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", "id", "amc-contract-detail-attachment", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition", 3, "isEditMode"],
                    [3, "isSaving", "isVisibleHr", "saveText", "cancelClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "isSaving", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    ["placeholder", "common_assignee_placeholder", 3, "entity", "formControl", "isEditMode"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", "id", "amc-contract-detail-attachment", 3, "afterSaving", "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0), _(1, uo, 1, 2, "app-skeleton-loader", 1), _(2, go, 46, 74, "form", 2), a(), _(3, xo, 1, 4, "app-send-notification", 3)), o & 2 && (i(), u(!n.form && n.amcContractId ? 1 : -1), i(), u(n.form ? 2 : -1), i(), u(n.isVisibleNotificationPopup ? 3 : -1))
                },
                dependencies: [nt, _e, ft, pe, Pe, vt, Xi, ht, dt, $, Ni, ue, Hi, ut, Ct, me, re, oe, ae, Se, se, ce, di],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Mo(t, s) {
    t & 1 && m(0, "app-skeleton-loader", 5), t & 2 && r("rows", 4)("columns", 2)
}

function bo(t, s) {
    if (t & 1 && (c(0, "app-control-container", 12), m(1, "app-employee-dropdown", 19), a()), t & 2) {
        let e = l(3);
        r("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("common_assignee"))("tooltipText", "amc_contact_assignee_id"), i(), r("entity", e.ENTITIES.AMC_CONTRACT)("formControl", e.form.controls.assignee_id)
    }
}

function Io(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "form", 7), h("ngSubmit", function() {
            y(e);
            let n = l(2);
            return S(n.updateStatus())
        }), c(1, "div")(2, "dx-scroll-view")(3, "div", 2)(4, "div", 8)(5, "app-control-container", 9), m(6, "dx-select-box", 10), a()(), c(7, "div", 11), _(8, bo, 2, 5, "app-control-container", 12), a()(), c(9, "app-control-container", 13)(10, "app-quick-reply-dropdown", 14), h("itemClick", function(n) {
            y(e);
            let v = l(2);
            return S(v.quickReplyValue(n))
        }), a(), m(11, "app-textarea", 15), a()()(), m(12, "app-user-notification-channel", 16)(13, "app-error", 17), c(14, "app-save-cancel-footer", 18), h("cancelClick", function() {
            y(e);
            let n = l(2);
            return S(n.onCancel())
        }), a()()
    }
    if (t & 2) {
        let e = l(2);
        r("formGroup", e.form), i(), Ge(e.isMobileDevice ? "is-mobile-popup-scrollbar" : "not-mobile-popup-scrollbar"), i(4), r("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status")), i(), r("items", e.amcContractStatusList)("placeholder", e.formatMessage("select_amc_status")), i(2), u(e.isEmployee ? 8 : -1), i(), r("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("common_comment")), i(2), r("quickReply", e.quickReply), i(), r("form", e.form), i(), r("displayError", e.statusErrorMessage !== "")("errorMsg", e.statusErrorMessage), i(), r("gaEvent", "contract_status_update_event")("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function Po(t, s) {
    if (t & 1 && (c(0, "div")(1, "div", 2)(2, "div", 3), m(3, "app-amc-contract-current-info", 4), _(4, Mo, 1, 2, "app-skeleton-loader", 5), _(5, Io, 15, 17, "form", 6), a()()()), t & 2) {
        let e = l();
        i(3), r("amcContract", e.amcContract), i(), u(e.form ? -1 : 4), i(), u(e.form ? 5 : -1)
    }
}
var It = (() => {
    class t {
        constructor(e, o) {
            this.amcContractService = e, this.loaderService = o, this.formatMessage = d, this.isVisiblePopup = !1, this.amcStatusSave = new Z, this.amcStatusClose = new Z, this.ENTITIES = M, this.formService = C(de), this.whatsappService = C(Oi), this.userSessionService = C(b), this.toastNotificationService = C(Q), this.isMobileDevice = C(O).isMobileDevice(), this.fb = new Ae, this.isEmployee = this.userSessionService.isEmployee(), this.amcContractStatusList = Object.values(Ti), this.statusErrorMessage = "", this.isSaving = !1
        }
        ngOnInit() {
            this.initialize()
        }
        initialize() {
            this.form = this.fb.group({
                status: new U(this.amcContract.status),
                assignee_id: new U(this.amcContract.assignee_id),
                comment: new U(null),
                is_send_mail: new U(!1),
                is_send_app: new U(!1),
                is_send_sms: new U(!1),
                is_send_whatsapp: new U(!1)
            })
        }
        onCancel() {
            this.form.reset(), this.isVisiblePopup = !1, this.amcStatusClose.emit()
        }
        onClosing() {
            this.isVisiblePopup = !1
        }
        updateStatus() {
            if (this.form.value.status === this.amcContract.status) return this.statusErrorMessage = this.formatMessage("status_same_error"), !1;
            this.form.valid ? (this.loaderService.show(), this.isSaving = !0, this.amcContractService.updateStatus(this.amcContract.id, this.form.value).subscribe({
                next: () => {
                    this.amcContract.status = this.form.value.status, this.toastNotificationService.success("status_update_success"), this.amcStatusSave.emit(this.form.value.status), this.form.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("job_status_update", this.amcContract.id), this.isVisiblePopup = !1, this.form.reset()
                },
                error: () => {
                    this.toastNotificationService.error("status_update_error")
                }
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        quickReplyValue(e) {
            this.quickReply = e.comment ? ? e.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(F), g(X))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-status-update-popup"]
                ],
                inputs: {
                    amcContract: "amcContract",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    amcStatusSave: "amcStatusSave",
                    amcStatusClose: "amcStatusClose"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "amcContract"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6e"],
                    ["name", "status", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["name", "assignee_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["name", "comment", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["formControlName", "comment", 3, "quickReply"],
                    [3, "form"],
                    [3, "displayError", "errorMsg"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving"],
                    ["placeholder", "common_assignee_placeholder", 3, "entity", "formControl"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "dx-popup", 0), h("onHidden", function() {
                        return n.onCancel()
                    }), ie("visibleChange", function(E) {
                        return te(n.isVisiblePopup, E) || (n.isVisiblePopup = E), E
                    }), R(1, Po, 6, 3, "div", 1), a()), o & 2 && (ee("visible", n.isVisiblePopup), r("maxHeight", 650)("width", "95vw")("maxWidth", 600)("title", n.formatMessage("update_job_status")), i(), r("dxTemplateOf", "content"))
                },
                dependencies: [nt, _e, we, pe, Pe, Bi, Gi, $, ue, Me, be, Ne, me, re, oe, ae, Se, se, ce],
                encapsulation: 2
            })
        }
    }
    return t
})();

function wo(t, s) {
    t & 1 && m(0, "app-skeleton-loader", 1), t & 2 && r("rows", 8)("columns", 3)
}

function Oo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-context-menu", 13), h("contextMenuItemCancelClick", function() {
            y(e);
            let n = l(4);
            return S(n.onCloseContextMenuOption())
        })("contextMenuItemClick", function(n) {
            y(e);
            let v = l(4);
            return S(v.onContextMenuItemClick(n))
        }), a()
    }
    if (t & 2) {
        let e = l(4);
        r("buttonText", e.formatMessage("amc_contract_actions"))("contextMenuItems", e.amcContractContextMenu)("entityName", e.ENTITIES.AMC_CONTRACT.name)("entity", e.amcContract)("isIconOnly", e.isMobileDevice)("isOnDetailPage", !0)
    }
}

function Do(t, s) {
    if (t & 1 && (c(0, "div", 8)(1, "div", 3), m(2, "app-amc-contract-status-tag", 9), c(3, "span", 10), p(4), a(), c(5, "div", 11), _(6, Oo, 1, 6, "app-context-menu", 12), a()()()), t & 2) {
        let e = l(3);
        i(2), r("iconType", e.statusIconTypeList.TITLE)("status", e.amcContract == null ? null : e.amcContract.status), i(2), f(" ", e.amcContract.contract_number, " "), i(2), u(e.amcContractContextMenu.length ? 6 : -1)
    }
}

function Vo(t, s) {
    if (t & 1 && _(0, Do, 7, 4, "div", 8), t & 2) {
        let e = l(2);
        u(e.amcContract && e.amcContract.id ? 0 : -1)
    }
}

function Ro(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "div", 4)(1, "app-responsive-tabs", 7), h("tabChange", function(n) {
            y(e);
            let v = l();
            return S(v.selectTab(n))
        }), R(2, Vo, 1, 1, "ng-template", null, 0, ni), a()()
    }
    if (t & 2) {
        let e = l();
        i(), r("tabs", e.tabs)("selectedIndex", e.selectedTabIndex)("mobileMenuTitle", e.amcContract == null ? null : e.amcContract.contract_number)
    }
}

function Lo(t, s) {
    t & 1 && (c(0, "div", 4), m(1, "app-amc-contract-detail"), a())
}

function Fo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-add-payment-popup", 14), h("addPaymentClose", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        })("addPaymentSave", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("entityType", e.ENTITIES.AMC_CONTRACT.name)("entity", e.currentAmcContract)("isVisiblePopup", e.isVisibleAddPaymentPopup && e.currentContextMenuAction === e.AMC_CONTRACT_CONTEXT_MENU_LIST.ADD_PAYMENT)
    }
}

function ko(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-amc-status-update-popup", 15), h("amcStatusClose", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        })("amcStatusSave", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("amcContract", e.currentAmcContract)("isVisiblePopup", e.isVisibleAmcStatusUpdatePopup && e.currentContextMenuAction === e.AMC_CONTRACT_CONTEXT_MENU_LIST.UPDATE_STATUS)
    }
}
var Wt = (() => {
    class t {
        constructor(e, o, n) {
            this.contractService = e, this.meta = o, this.loaderService = n, this.formatMessage = d, this.ENTITIES = M, this.router = C(Y), this.userSessionService = C(b), this.activatedRouter = C(N), this.isMobileDevice = C(O).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.amcContract = null, this.amcContractId = null, this.currentContextMenuAction = null, this.selectedTabIndex = null, this.amcContractContextMenu = [], this.isVisibleAddPaymentPopup = !1, this.isVisibleAmcStatusUpdatePopup = !1, this.statusIconTypeList = z, this.isRedirectFromAddPayment = !1, this.tabs = [], this.AMC_CONTRACT_CONTEXT_MENU_LIST = V, this.meta.addTags([{
                name: "description",
                content: "View Service jobs details"
            }, {
                name: "keywords",
                content: "service-jobs, jobs"
            }])
        }
        ngOnInit() {
            this.activatedRouter.params.subscribe({
                next: e => {
                    this.amcContractId = null, this.amcContractId = +e.amc_contract_id, this.amcContractId && (this.activatedRouter ? .firstChild.data.subscribe({
                        next: o => {
                            this.selectedTabIndex = o.tab_index
                        },
                        error: o => {
                            console.error(o)
                        }
                    }), this.tabs = [{
                        id: 0,
                        text: d("overview"),
                        path: `/amcs/${this.amcContractId}/overview`,
                        icon: Qe.FOLDER_SEARCH.light,
                        visible: !0
                    }, {
                        id: 1,
                        text: d("details"),
                        path: `/amcs/${this.amcContractId}/details`,
                        icon: xi.INFO.light,
                        visible: this.userPermissionList.includes(x.AMC_CONTRACT_LIST)
                    }, {
                        id: 2,
                        text: d("add_devices"),
                        path: `/amcs/${this.amcContractId}/device`,
                        icon: Qe.LAPTOP.light,
                        visible: this.userPermissionList.includes(x.DEVICE_INFORMATION_LIST)
                    }, {
                        id: 3,
                        text: d("services"),
                        path: `/amcs/${this.amcContractId}/amcServices`,
                        icon: ze.COMMENT.light,
                        visible: this.userPermissionList.includes(x.AMC_SERVICE_LIST)
                    }, {
                        id: 4,
                        text: d("complaints"),
                        path: `/amcs/${this.amcContractId}/amcComplaints`,
                        icon: Ei.PAYMENT_TYPE.light,
                        visible: this.userPermissionList.includes(x.AMC_COMPLAINT_LIST)
                    }, {
                        id: 5,
                        text: d("payment"),
                        path: `/amcs/${this.amcContractId}/amcPayments`,
                        icon: Ee.INVOICE.light,
                        visible: this.userPermissionList.includes(x.AMC_CONTRACT_VIEW_PAYMENT_TAB)
                    }, {
                        id: 6,
                        text: d("private_notes"),
                        path: `/amcs/${this.amcContractId}/notes`,
                        icon: Qe.STICKY_NOTE.light,
                        visible: this.isEmployee && this.userPermissionList.includes(x.AMC_COMPLAINT_LIST)
                    }], this.loaderService.show(), this.getAmcContractDetail(), this.amcContractContextMenu = [{
                        name: V.AMC_CONTRACT,
                        icon: Ee.QUOTATION.light,
                        visible: !0,
                        locale_key: d("amc_action_amc_contract")
                    }, {
                        name: V.ADD_PAYMENT,
                        icon: Ee.PAYMENT.light,
                        visible: this.isEmployee && this.userPermissionList.includes(x.PAYMENT_WRITE),
                        locale_key: d("add_payment")
                    }, {
                        name: V.UPDATE_STATUS,
                        icon: Qe.CIRCLE.light,
                        visible: this.isEmployee,
                        locale_key: d("update_status")
                    }])
                },
                error: e => {
                    console.error("Can't load details ", e)
                }
            })
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentAmcContract = e.entity, this.currentContextMenuAction === V.AMC_CONTRACT && this.router.navigate([`/amcs/${this.currentAmcContract.id}/amcContract`]), this.currentContextMenuAction === V.ADD_PAYMENT && (this.isVisibleAddPaymentPopup = !0), this.currentContextMenuAction === V.UPDATE_STATUS && (this.isVisibleAmcStatusUpdatePopup = !0)
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentAmcContract = null
        }
        getAmcContractDetail() {
            this.contractService.getById(this.amcContractId).subscribe({
                next: e => {
                    this.contractService.setCurrentContract(new K(e))
                },
                error: e => {
                    console.error("Cannot get AMC Contract detail ", e)
                }
            }).add(() => this.loaderService.hide()), this.contractService.currentContract$.subscribe({
                next: e => {
                    e ? .id && (this.amcContract = e)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(F), g(li), g(X))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-detail"]
                ],
                standalone: !1,
                decls: 7,
                vars: 4,
                consts: [
                    ["subheader", ""],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "form-height-mobile-view"],
                    [3, "entityType", "entity", "isVisiblePopup"],
                    [3, "amcContract", "isVisiblePopup"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-shield-halved", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle"],
                    [1, "row", "mb-3"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "buttonText", "contextMenuItems", "entityName", "entity", "isIconOnly", "isOnDetailPage"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "buttonText", "contextMenuItems", "entityName", "entity", "isIconOnly", "isOnDetailPage"],
                    [3, "addPaymentClose", "addPaymentSave", "entityType", "entity", "isVisiblePopup"],
                    [3, "amcStatusClose", "amcStatusSave", "amcContract", "isVisiblePopup"]
                ],
                template: function(o, n) {
                    o & 1 && (_(0, wo, 1, 2, "app-skeleton-loader", 1), c(1, "div", 2)(2, "div", 3), _(3, Ro, 4, 3, "div", 4)(4, Lo, 2, 0, "div", 4), a()(), _(5, Fo, 1, 3, "app-add-payment-popup", 5), _(6, ko, 1, 2, "app-amc-status-update-popup", 6)), o & 2 && (u(!(n.amcContract != null && n.amcContract.id) && n.amcContractId ? 0 : -1), i(3), u(n.amcContractId ? 3 : 4), i(2), u(n.isVisibleAddPaymentPopup && n.currentContextMenuAction === n.AMC_CONTRACT_CONTEXT_MENU_LIST.ADD_PAYMENT ? 5 : -1), i(), u(n.isVisibleAmcStatusUpdatePopup && n.currentContextMenuAction === n.AMC_CONTRACT_CONTEXT_MENU_LIST.UPDATE_STATUS ? 6 : -1))
                },
                dependencies: [Qi, St, Oe, $, At, bt, It],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Uo = (t, s, e) => ({
    paymentable_id: t,
    paymentable_type: s,
    customer_id: e
});

function Yo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-add-payment-popup", 3), h("addPaymentClose", function() {
            y(e);
            let n = l();
            return S(n.isVisiblePopup = !1)
        })("addPaymentSave", function() {
            y(e);
            let n = l();
            return S(n.onSavePayment())
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("entityType", e.ENTITIES.AMC_CONTRACT.name)("isCreate", e.isCreate)("isOnAmcPaymentListTab", !0)("isVisiblePopup", e.isVisiblePopup)("payment", e.payment)
    }
}
var Mn = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.amcContractService = o, this.formatMessage = d, this.amcContractId = null, this.isiVisibleTitle = !1, this.ENTITIES = M, this.userSessionService = C(b), this.activatedRouter = C(N), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.isVisiblePopup = !1, this.isCreate = !1, this.entity = this.ENTITIES.PAYMENT, this.columns = [{
                dataField: "paymentable",
                caption: d("payment_against"),
                cellTemplate: "paymentableLinkTemplate",
                width: 140,
                allowSorting: !1
            }, {
                dataField: "amount",
                caption: d("common_amount"),
                width: 120,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "payment_type.name",
                caption: d("payment_mode_placeholder"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "transaction_id",
                caption: d("common_transaction_id"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "cheque_number",
                caption: d("payment_cheque_number"),
                hidingPriority: 1,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: d("common_created_by"),
                hidingPriority: 4,
                cellTemplate: "employeeTemplate",
                allowSorting: !1
            }, {
                dataField: "updated_user",
                caption: d("common_updated_by"),
                hidingPriority: 5,
                cellTemplate: "employeeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "comment",
                caption: d("common_comment"),
                hidingPriority: 2,
                cellTemplate: "commentTemplate",
                alignment: "center",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: d("common_updated_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                alignment: "center",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: d("common_created_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                alignment: "center",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 7,
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                width: 60
            }], this.PERMISSION_LIST = x
        }
        ngOnInit() {
            this.entity.isVisibleSearchPanel = !1, this.amcContractId || (this.amcContractId = +this.activatedRouter.snapshot.parent.paramMap.get("amc_contract_id")), this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.initialize()
        }
        initialize() {
            let e = {};
            this.amcContractId && (e.amc_contract_id = this.amcContractId), this.customerId && (e.customer_id = this.customerId)
        }
        create() {
            this.isVisiblePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.payment = e, this.isVisiblePopup = !0
        }
        onSavePayment() {
            this.isCreate = !1, this.dataGrid.getData(), this.payment = null, this.isVisiblePopup = !1
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(Ki), g(F))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-payment-list"]
                ],
                viewQuery: function(o, n) {
                    if (o & 1 && q(L, 5), o & 2) {
                        let v;
                        W(v = H()) && (n.dataGrid = v.first)
                    }
                },
                inputs: {
                    amcContractId: "amcContractId",
                    isiVisibleTitle: "isiVisibleTitle"
                },
                standalone: !1,
                decls: 4,
                vars: 15,
                consts: [
                    [3, "ngClass"],
                    [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleTitle", "service"],
                    [3, "entityType", "isCreate", "isOnAmcPaymentListTab", "isVisiblePopup", "payment"],
                    [3, "addPaymentClose", "addPaymentSave", "entityType", "isCreate", "isOnAmcPaymentListTab", "isVisiblePopup", "payment"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "div", 0)(2, "app-data-grid", 1), h("dataGridAddNewClick", function() {
                        return n.create()
                    })("dataGridEditClick", function(E) {
                        return n.edit(E)
                    }), a()()(), _(3, Yo, 1, 5, "app-add-payment-popup", 2)), o & 2 && (r("ngClass", n.customerId ? "card" : ""), i(), r("ngClass", n.customerId ? "card-body" : ""), i(), r("additionalParams", J(11, Uo, n.amcContractId, n.ENTITIES.AMC_CONTRACT.name, n.customerId))("columns", n.columns)("entity", n.entity)("isVisibleAddAction", !1)("isVisibleDeleteAction", n.isAdmin || n.userPermissionList.includes(n.PERMISSION_LIST.PAYMENT_DELETE))("isVisibleEditAction", n.isEmployee)("isVisibleTitle", n.isiVisibleTitle)("service", n.service), i(), u(n.amcContractId && n.isVisiblePopup ? 3 : -1))
                },
                dependencies: [ne, L, St],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Re = (() => {
    class t extends ge {
        constructor(e) {
            super(e, Dt), this.api = e, this.endpoint = Dt
        }
        exportToFile(e, o) {
            return this.api.exportToFile(this.endpoint + "/" + e, o)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(xe))
            }
        }
        static {
            this.\u0275prov = fe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Le = class {
    constructor(s) {
        return Object.assign(this, s)
    }
    static getForm(s) {
        let o = new Ae().group({
                id: [s.id || null],
                amc_contract_id: [s.amc_contract_id || null, [B.required]],
                service_type: [s.service_type || null, [B.required]],
                status: [s.status || We.PENDING, [B.required]],
                service_charge: [s.service_charge || null],
                tax_id: [s.tax_id || null],
                is_rate_including_tax: [s.is_rate_including_tax || !1],
                tax_code: [s.tax_code || null],
                tax_amount: [s.tax_amount || null],
                sub_total: [s.sub_total || null],
                line_total: [s.line_total || null],
                service_expenditure: [s.service_expenditure || null],
                travel_expenditure: [s.travel_expenditure || null],
                assignee_id: [s.assignee_id || null, [B.required]],
                service_remark: [s.service_remark || null, [B.required]],
                service_date: [s.service_date || new Date, [B.required]],
                is_send_mail: new U(!1),
                is_send_app: new U(!1)
            }),
            n = o.get("service_type"),
            v = o.get("service_charge");
        return v.setValidators([E => n.value === "paid" ? B.required(E) : null]), v.updateValueAndValidity(), o
    }
};

function Go(t, s) {
    t & 1 && m(0, "app-skeleton-loader", 3), t & 2 && r("rows", 4)("columns", 2)
}

function jo(t, s) {
    if (t & 1 && (c(0, "app-control-container", 32), m(1, "app-employee-dropdown", 40), a()), t & 2) {
        let e = l(3);
        r("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("common_assignee"))("tooltipText", "job_assignee_id"), i(), r("formControl", e.form.controls.assignee_id)
    }
}

function qo(t, s) {
    if (t & 1 && m(0, "app-server-error", 39), t & 2) {
        let e = l(3);
        r("errorResponse", e.errorResponse)
    }
}

function Wo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "form", 5), h("ngSubmit", function() {
            y(e);
            let n = l(2);
            return S(n.save())
        }), c(1, "dx-scroll-view", 6)(2, "div", 7)(3, "div", 8)(4, "div", 9)(5, "app-control-container", 10), m(6, "dx-select-box", 11), a(), c(7, "app-control-container", 12), m(8, "dx-select-box", 13), a(), c(9, "app-control-container", 14)(10, "dx-number-box", 15), h("onValueChanged", function() {
            y(e);
            let n = l(2);
            return S(n.updateTaxAndLineTotal())
        }), a()(), c(11, "app-control-container", 16)(12, "dx-check-box", 17), h("onValueChanged", function() {
            y(e);
            let n = l(2);
            return S(n.updateTaxAndLineTotal())
        }), a()(), c(13, "app-control-container", 18)(14, "dx-select-box", 19), h("onValueChanged", function() {
            y(e);
            let n = l(2);
            return S(n.updateTaxAndLineTotal())
        }), a()(), c(15, "app-control-container", 20), m(16, "dx-text-box", 21), a(), c(17, "app-control-container", 22), m(18, "dx-number-box", 23), a(), c(19, "app-control-container", 24), m(20, "dx-number-box", 25), a(), c(21, "app-control-container", 26), m(22, "dx-number-box", 27), a(), c(23, "app-control-container", 28), m(24, "dx-number-box", 29), a(), c(25, "app-control-container", 30), m(26, "dx-number-box", 31), a(), _(27, jo, 2, 4, "app-control-container", 32), c(28, "app-control-container", 33), m(29, "dx-date-box", 34), a(), c(30, "app-control-container", 35), m(31, "app-textarea", 36), a()()()(), m(32, "app-user-notification-channel", 37), a(), c(33, "app-save-cancel-footer", 38), h("cancelClick", function() {
            y(e);
            let n = l(2);
            return S(n.onClosing())
        }), a(), _(34, qo, 1, 1, "app-server-error", 39), a()
    }
    if (t & 2) {
        let e = l(2);
        r("formGroup", e.form), i(5), r("errorMsg", e.formatMessage("service_type_required"))("label", e.formatMessage("service_type")), i(), r("items", e.amcServicesTypeList)("placeholder", e.formatMessage("service_type_placeholder")), i(), r("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), i(), r("items", e.amcServiceStatusList)("placeholder", e.formatMessage("common_select_status")), i(), r("errorMsg", e.formatMessage("service_charge_required"))("label", e.formatMessage("service_charge")), i(), r("min", 0)("placeholder", e.formatMessage("service_charge_placeholder")), i(), r("isLabelOnSameLine", !0)("label", e.formatMessage("repair_services_rate_including_tax")), i(2), r("label", e.formatMessage("common_tax")), i(), r("items", e.taxes)("placeholder", e.formatMessage("common_placeholders_tax"))("showClearButton", !0), i(), r("label", e.formatMessage("common_tax_code")), i(), r("placeholder", e.formatMessage("common_placeholders_tax_code")), i(), r("label", e.formatMessage("common_sub_total")), i(), r("placeholder", e.formatMessage("sub_total_placeholder"))("readOnly", !0), i(), r("label", e.formatMessage("common_tax_amount")), i(), r("placeholder", e.formatMessage("tax_amount_placeholder"))("readOnly", !0), i(), r("label", e.formatMessage("common_total_amount")), i(), r("placeholder", e.formatMessage("total_amount_placeholder"))("readOnly", !0), i(), r("errorMsg", e.formatMessage("service_expenditure_required"))("label", e.formatMessage("service_expenditure")), i(), r("min", 0)("placeholder", e.formatMessage("service_expenditure_placeholder")), i(), r("errorMsg", e.formatMessage("travel_expenditure_required"))("label", e.formatMessage("travel_expenditure")), i(), r("min", 0)("placeholder", e.formatMessage("travel_expenditure_placeholder")), i(), u(e.isEmployee ? 27 : -1), i(), r("errorMsg", e.formatMessage("service_date_required"))("label", e.formatMessage("service_date")), i(), r("dateSerializationFormat", e.DATETIME_SERIALIZATION_FORMAT)("displayFormat", "dd-MMM-yyyy")("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("service_date_placeholder")), i(), r("errorMsg", e.formatMessage("remark_required"))("label", e.formatMessage("contract_remark")), i(), r("placeholder", e.formatMessage("contract_remark_placeholder")), i(), r("form", e.form), i(), r("isOnPopup", !0)("isSaving", e.isSaving), i(), u(e.errorResponse ? 34 : -1)
    }
}

function Ho(t, s) {
    if (t & 1 && (c(0, "div", 2), _(1, Go, 1, 2, "app-skeleton-loader", 3), _(2, Wo, 35, 52, "form", 4), a()), t & 2) {
        let e = l();
        i(), u(e.form ? -1 : 1), i(), u(e.form ? 2 : -1)
    }
}
var bn = (() => {
    class t {
        constructor(e, o, n) {
            this.service = e, this.amcContractService = o, this.taxService = n, this.formatMessage = d, this.amcContract = null, this.isVisiblePopup = !1, this.isCreate = !0, this.amcServiceSaveClick = new Z, this.amcServiceCancelClick = new Z, this.formService = C(de), this.userSessionService = C(b), this.activatedRouter = C(N), this.isEmployee = this.userSessionService.isEmployee(), this.router = C(Y), this.isMobileDevice = C(O).isMobileDevice(), this.toastNotificationService = C(Q), this.DATETIME_SERIALIZATION_FORMAT = et, this.isSaving = !1, this.errorResponse = null, this.amcContractId = null, this.amcServiceId = null, this.amcServicesTypeList = ["Paid", "Free"], this.amcServiceStatusList = Object.values(We), this.taxes = []
        }
        ngOnInit() {
            this.taxService.getAll().subscribe({
                next: e => {
                    this.taxes = e
                },
                error: e => {
                    console.error(e)
                }
            }), this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = +e.amc_contract_id, this.amcContractService.currentContract$.subscribe({
                        next: o => {
                            this.amcContract = o
                        },
                        error: o => {
                            console.error(o)
                        }
                    })
                },
                error: e => {
                    console.error(e)
                }
            }), this.isCreate || (this.amcContractId = this.amcService ? .amc_contract ? .id), this.form = Le.getForm(new Le(this.isCreate ? {
                amc_contract_id: this.amcContractId,
                assignee_id: this.amcContract ? .assignee_id,
                status: We.PENDING
            } : this.amcService))
        }
        updateTaxAndLineTotal() {
            let e = this.taxes.find(n => n.id === this.form.value.tax_id),
                o = Ri.calculatePriceAndTaxes({
                    price: this.form.value.service_charge,
                    quantity: 1,
                    discount: 0,
                    is_rate_including_tax: this.form.value.is_rate_including_tax
                }, e);
            this.form.patchValue({
                tax_amount: o.tax_amount,
                sub_total: o.sub_total,
                line_total: o.line_total
            })
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.amcService = new Le(o), this.isVisiblePopup = !1, this.router.navigate([`/amcs/${this.amcContractId}/amcServices`]), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "amc_service_added_success" : "amc_service_updated_success"), this.amcServiceSaveClick.emit(this.amcService), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onAddCustomer(e) {
            this.form.patchValue({
                customer_id: e.id
            })
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.amcService = null, this.amcServiceCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(Re), g(F), g($i))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-service-popup"]
                ],
                inputs: {
                    amcContract: "amcContract",
                    amcService: "amcService",
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate"
                },
                outputs: {
                    amcServiceSaveClick: "amcServiceSaveClick",
                    amcServiceCancelClick: "amcServiceCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "flex-column", "h-100"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "row", "mb-5"],
                    ["name", "service_type", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "service_type", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "service_charge", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "service_charge", "id", "add-service-interval", 3, "onValueChanged", "min", "placeholder"],
                    ["name", "is_rate_including_tax", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "isLabelOnSameLine", "label"],
                    ["formControlName", "is_rate_including_tax", 3, "onValueChanged"],
                    ["name", "tax_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["displayExpr", "name", "formControlName", "tax_id", "valueExpr", "id", 3, "onValueChanged", "items", "placeholder", "showClearButton"],
                    ["name", "tax_code", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "tax_code", 3, "placeholder"],
                    ["name", "sub_total", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "sub_total", 3, "placeholder", "readOnly"],
                    ["name", "tax_amount", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "tax_amount", 3, "placeholder", "readOnly"],
                    ["name", "line_total", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "line_total", 3, "placeholder", "readOnly"],
                    ["name", "service_expenditure", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "service_expenditure", "id", "add-service-expenditure", 3, "min", "placeholder"],
                    ["name", "travel_expenditure", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "travel_expenditure", "id", "add-travel-expenditure", 3, "min", "placeholder"],
                    ["name", "assignee_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label", "tooltipText"],
                    ["name", "service_date", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "service_date", "type", "date", 3, "dateSerializationFormat", "displayFormat", "pickerType", "placeholder"],
                    ["name", "service_remark", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "service_remark", "id", "contract-remark", 3, "placeholder"],
                    [3, "form"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"],
                    ["placeholder", "common_assignee_placeholder", 3, "formControl"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "dx-popup", 0), h("onHidden", function() {
                        return n.onClosing()
                    }), ie("visibleChange", function(E) {
                        return te(n.isVisiblePopup, E) || (n.isVisiblePopup = E), E
                    }), R(1, Ho, 3, 2, "div", 1), a()), o & 2 && (ee("visible", n.isVisiblePopup), r("maxHeight", "90vh")("width", "95vw")("maxWidth", 600)("title", n.amcService != null && n.amcService.id ? n.formatMessage("update_amc_service") : n.formatMessage("add_new_amc_service")), i(), r("dxTemplateOf", "content"))
                },
                dependencies: [Tt, _e, we, pe, Pe, $, ue, Me, ji, ut, Ct, be, Ne, me, wi, re, oe, ae, Se, se, ce],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Qo = t => ({
        amc_contract_id: t
    }),
    Xo = (t, s, e) => [t, s, e],
    $o = (t, s, e, o) => ({
        icon: "dx-icon-todo",
        title: t,
        description: s,
        primaryButtonText: e,
        quickTipsVisible: !0,
        quickTips: o
    });

function Zo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-amc-service-popup", 4), h("amcServiceCancelClick", function() {
            y(e);
            let n = l();
            return S(n.isVisibleAmcServicePopup = !1)
        })("amcServiceSaveClick", function() {
            y(e);
            let n = l();
            return S(n.onAmcServiceSave())
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("amcService", e.amcService)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAmcServicePopup)
    }
}

function Jo(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-archive-delete-popup", 5), ie("isVisibleChange", function(n) {
            y(e);
            let v = l();
            return te(v.isVisibleArchiveDeletePopup, n) || (v.isVisibleArchiveDeletePopup = n), S(n)
        }), h("onSuccess", function(n) {
            y(e);
            let v = l();
            return S(v.handleArchiveDeleteSuccess(n))
        })("onCancel", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = l();
        ee("isVisible", e.isVisibleArchiveDeletePopup), r("service", e.service)("entity", e.currentAmcService)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var Qt = (() => {
    class t {
        get hasTenantAmcServices() {
            return (this.tenantService.config() ? .entity_counts ? .amc_contracts || 0) > 0
        }
        constructor(e) {
            this.service = e, this.formatMessage = d, this.router = C(Y), this.userSessionService = C(b), this.activatedRouter = C(N), this.tenantService = C(Ie), this.toastNotificationService = C(Q), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.amcContractId = null, this.isCreate = !1, this.isVisibleAmcServicePopup = !1, this.isVisiblePopup = !1, this.currentContextMenuAction = null, this.amcServiceContextMenu = [], this.isVisibleArchiveDeletePopup = !1, this.archiveDeleteMode = $t("delete"), this.entity = M.AMC_SERVICE, this.columns = [{
                dataField: "amc_contract",
                caption: d("contract"),
                width: 130,
                allowSorting: !0,
                alignment: "center",
                cellTemplate: "idLinkTemplate"
            }, {
                dataField: "service_date",
                caption: d("service_date"),
                cellTemplate: "dateTimeTemplate",
                alignment: "center",
                width: 130,
                allowSorting: !0
            }, {
                dataField: "assigned_user",
                caption: d("common_assignee"),
                allowSorting: !1,
                cellTemplate: "employeeTemplate",
                hidingPriority: 9
            }, {
                dataField: "status",
                caption: d("common_status"),
                allowSorting: !1,
                hidingPriority: 8,
                alignment: "center",
                cellTemplate: "amcPaymentStatusTemplate"
            }, {
                dataField: "service_type",
                caption: d("service_type"),
                allowSorting: !1,
                alignment: "center",
                hidingPriority: 7
            }, {
                dataField: "service_charge",
                caption: d("service_charge"),
                alignment: "center",
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "tax_amount",
                caption: d("tax_amount"),
                alignment: "center",
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "line_total",
                caption: d("total_amount"),
                alignment: "center",
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "service_expenditure",
                caption: d("service_expenditure"),
                alignment: "center",
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "travel_expenditure",
                caption: d("travel_expenditure"),
                alignment: "center",
                hidingPriority: 2,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: d("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 1,
                alignment: "center",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: d("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 0,
                alignment: "center",
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                width: 65
            }]
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = +e.amc_contract_id
                },
                error: e => {
                    console.error(e)
                }
            }), this.amcServiceContextMenu = [{
                name: le.VIEW,
                icon: Lt.PDF.light,
                visible: !0,
                locale_key: d("amc_action_view")
            }, {
                name: le.DOWNLOAD,
                icon: Lt.DOWNLOAD.light,
                visible: !0,
                locale_key: d("amc_action_download"),
                handledByComponent: !0
            }, {
                name: le.EDIT,
                icon: ze.PENCIL.light,
                visible: this.userPermissionList.includes(x.AMC_SERVICE_WRITE) && this.isEmployee,
                locale_key: d("amc_action_edit")
            }, {
                name: le.DELETE,
                icon: ze.DELETE.light,
                visible: this.userPermissionList.includes(x.AMC_SERVICE_DELETE) && this.isEmployee,
                locale_key: d("amc_action_delete")
            }]
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentAmcService = e.entity, this.currentContextMenuAction === le.VIEW && this.router.navigate(["/amcs/" + this.currentAmcService ? .amc_contract_id + "/amcServiceReceipt/" + this.currentAmcService.id]), this.currentContextMenuAction === le.EDIT && this.edit(this.currentAmcService), this.currentContextMenuAction === le.DELETE && (this.archiveDeleteMode.set(this.currentAmcService.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0)
        }
        handleArchiveDeleteSuccess(e) {
            this.isVisibleArchiveDeletePopup = !1, this.currentContextMenuAction = null, this.currentAmcService = null, this.dataGrid.getData()
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentAmcService = null
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption()
        }
        onAmcServiceSave() {
            this.isCreate = !1, this.isVisibleAmcServicePopup = !1, this.amcService = null, this.dataGrid.getData()
        }
        create() {
            this.isVisibleAmcServicePopup = !0, this.isCreate = !0, this.amcService = null
        }
        edit(e) {
            this.isCreate = !1, this.amcService = e, this.isVisibleAmcServicePopup = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(Re))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-service-list"]
                ],
                viewQuery: function(o, n) {
                    if (o & 1 && q(L, 5), o & 2) {
                        let v;
                        W(v = H()) && (n.dataGrid = v.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 27,
                consts: [
                    [1, "ams-service-list"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "additionalParams", "columns", "contextMenuItems", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleDownloadAction", "isVisibleEditAction", "isVisibleExportAction", "searchPanelPlaceholderText", "isVisibleReportDropdown", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "amcService", "isCreate", "isVisiblePopup"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "amcServiceCancelClick", "amcServiceSaveClick", "amcService", "isCreate", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "app-data-grid", 1), h("contextMenuItemCancelClick", function() {
                        return n.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(E) {
                        return n.onContextMenuItemClick(E)
                    })("dataGridAddNewClick", function() {
                        return n.create()
                    }), a()(), _(2, Zo, 1, 3, "app-amc-service-popup", 2), _(3, Jo, 1, 6, "app-archive-delete-popup", 3)), o & 2 && (i(), r("additionalParams", Je(16, Qo, n.amcContractId))("columns", n.columns)("contextMenuItems", n.amcServiceContextMenu)("entity", n.entity)("isVisibleAddAction", !!n.amcContractId)("isVisibleDeleteAction", !1)("isVisibleDownloadAction", !1)("isVisibleEditAction", !1)("isVisibleExportAction", !0)("searchPanelPlaceholderText", "search_panel_amc_services_placeholder")("isVisibleReportDropdown", !0)("service", n.service)("hasTenantData", n.hasTenantAmcServices)("emptyStateConfig", Ke(22, $o, n.formatMessage("empty_state_amc_service_title"), n.formatMessage("empty_state_amc_service_description"), n.amcContractId ? "empty_state_amc_service_primary_button" : "", J(18, Xo, n.formatMessage("empty_state_amc_service_tip_1"), n.formatMessage("empty_state_amc_service_tip_2"), n.formatMessage("empty_state_amc_service_tip_3")))), i(), u(n.isVisibleAmcServicePopup ? 2 : -1), i(), u(n.isVisibleArchiveDeletePopup ? 3 : -1))
                },
                dependencies: [zi, L, bn],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Pt = (() => {
    class t extends ge {
        constructor(e) {
            super(e, Vt), this.api = e, this.endpoint = Vt
        }
        exportToFile(e, o) {
            return this.api.exportToFile(this.endpoint + "/" + e, o)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(xe))
            }
        }
        static {
            this.\u0275prov = fe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Fe = class {
    constructor(s) {
        return Object.assign(this, s)
    }
    static getForm(s) {
        return new Ae().group({
            id: [s.id || null],
            amc_contract_id: [s.amc_contract_id || null, [B.required]],
            status: [s.status || "Pending", [B.required]],
            custom_fields: Vi.getFormArray(s.custom_fields),
            description: [s.description || null, [B.required]],
            is_send_mail: new U(!1),
            is_send_app: new U(!1)
        })
    }
};

function Ko(t, s) {
    t & 1 && m(0, "app-skeleton-loader", 5), t & 2 && r("rows", 4)("columns", 2)
}

function ea(t, s) {
    if (t & 1 && (c(0, "app-control-container", 9), m(1, "dx-select-box", 18), a()), t & 2) {
        let e = l(3);
        r("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), i(), r("items", e.amcComplaintStatusList)("placeholder", e.formatMessage("common_select_status"))
    }
}

function ta(t, s) {
    if (t & 1 && m(0, "app-server-error", 17), t & 2) {
        let e = l(3);
        r("errorResponse", e.errorResponse)
    }
}

function ia(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "form", 7), h("ngSubmit", function() {
            y(e);
            let n = l(2);
            return S(n.save())
        }), c(1, "div", 8), _(2, ea, 2, 4, "app-control-container", 9), c(3, "app-control-container", 10), m(4, "app-textarea", 11), a(), c(5, "div", 12), m(6, "app-show-custom-fields", 13), a()(), m(7, "app-user-notification-channel", 14), c(8, "div", 15)(9, "app-save-cancel-footer", 16), h("cancelClick", function() {
            y(e);
            let n = l(2);
            return S(n.onClosing())
        }), a()(), _(10, ta, 1, 1, "app-server-error", 17), a()
    }
    if (t & 2) {
        let e = l(2);
        r("formGroup", e.form), i(2), u(e.isEmployee ? 2 : -1), i(), r("errorMsg", e.formatMessage("common_error_messages_description_required"))("label", e.formatMessage("common_description")), i(), r("placeholder", e.formatMessage("placeholder_description")), i(2), r("formType", e.FORM_TYPE_LIST.AMC_COMPLAINT)("form", e.form), i(), r("form", e.form), i(2), r("isOnPopup", !0)("isSaving", e.isSaving), i(), u(e.errorResponse ? 10 : -1)
    }
}

function na(t, s) {
    if (t & 1 && (c(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), _(4, Ko, 1, 2, "app-skeleton-loader", 5), _(5, ia, 11, 11, "form", 6), a()()()()), t & 2) {
        let e = l();
        i(4), u(e.form ? -1 : 4), i(), u(e.form ? 5 : -1)
    }
}
var Pn = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = d, this.amcContract = null, this.isVisiblePopup = !1, this.isCreate = !0, this.amcComplaintSaveClick = new Z, this.amcComplaintCancelClick = new Z, this.formService = C(de), this.toastNotificationService = C(Q), this.router = C(Y), this.userSessionService = C(b), this.isEmployee = this.userSessionService.isEmployee(), this.activatedRouter = C(N), this.isSaving = !1, this.errorResponse = null, this.amcContractId = null, this.amcComplaintStatusList = Object.values(hi), this.FORM_TYPE_LIST = tt
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = +e.amc_contract_id
                },
                error: e => {
                    console.error(e)
                }
            }), this.form = Fe.getForm(new Fe(this.isCreate ? {
                amc_contract_id: this.amcContractId
            } : this.amcComplaint))
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.amcComplaint = new Fe(o), this.isVisiblePopup = !1, this.amcContractId ? this.router.navigate([`/amcs/${this.amcContractId}/amcComplaints`]) : this.router.navigate(["/amcs/amcComplaints"]), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "notification_amc_complaint_add_success" : "notification_amc_complaint_update_success"), this.amcComplaintSaveClick.emit(this.amcComplaint), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.amcComplaint = null, this.amcComplaintCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(Pt))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-complaint-popup"]
                ],
                inputs: {
                    amcContract: "amcContract",
                    amcComplaint: "amcComplaint",
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate"
                },
                outputs: {
                    amcComplaintSaveClick: "amcComplaintSaveClick",
                    amcComplaintCancelClick: "amcComplaintCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-5"],
                    ["name", "status", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["name", "description", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "description", "id", "description", 3, "placeholder"],
                    [1, "custom-field-container"],
                    [1, "row", "d-flex", "justify-content-between", "flex-wrap", 3, "formType", "form"],
                    [3, "form"],
                    [1, "w-100", "px-1"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "dx-popup", 0), h("onHidden", function() {
                        return n.onClosing()
                    }), ie("visibleChange", function(E) {
                        return te(n.isVisiblePopup, E) || (n.isVisiblePopup = E), E
                    }), R(1, na, 6, 2, "div", 1), a()), o & 2 && (ee("visible", n.isVisiblePopup), r("maxHeight", "90vh")("width", "95vw")("maxWidth", 600)("title", n.amcComplaint != null && n.amcComplaint.id ? n.formatMessage("popup_title_update") : n.formatMessage("popup_title_add")), i(), r("dxTemplateOf", "content"))
                },
                dependencies: [Tt, _e, we, pe, ht, $, ue, Me, be, Ne, me, re, oe, ae, se, ce],
                encapsulation: 2
            })
        }
    }
    return t
})();
var aa = t => ({
        amc_contract_id: t
    }),
    ra = (t, s, e) => [t, s, e],
    ca = (t, s, e, o) => ({
        icon: "dx-icon-warning",
        title: t,
        description: s,
        primaryButtonText: e,
        quickTipsVisible: !0,
        quickTips: o
    });

function sa(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-amc-complaint-popup", 3), h("amcComplaintCancelClick", function() {
            y(e);
            let n = l();
            return S(n.isVisibleAmcComplaintPopup = !1)
        })("amcComplaintSaveClick", function() {
            y(e);
            let n = l();
            return S(n.onAmcServiceSave())
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("amcComplaint", e.amcComplaint)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleAmcComplaintPopup)
    }
}
var Xt = (() => {
    class t {
        get hasTenantAmcComplaints() {
            return this.isEmployee ? (this.tenantService.config() ? .entity_counts ? .amc_contracts || 0) > 0 : !0
        }
        constructor(e) {
            this.service = e, this.formatMessage = d, this.userSessionService = C(b), this.tenantService = C(Ie), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.activatedRouter = C(N), this.currentContextMenuAction = null, this.amcContractId = null, this.contractContextMenu = [], this.isCreate = !1, this.isVisibleAmcComplaintPopup = !1, this.isVisiblePopup = !1, this.entity = M.AMC_COMPLAINT, this.columns = [{
                dataField: "amc_contract",
                caption: d("contract"),
                width: 105,
                allowSorting: !0,
                cellTemplate: "idLinkTemplate"
            }, {
                dataField: "status",
                caption: d("common_status"),
                width: 105,
                allowSorting: !1,
                alignment: "center",
                cellTemplate: "amcPaymentStatusTemplate"
            }, {
                dataField: "description",
                caption: d("common_description"),
                allowSorting: !1,
                hidingPriority: 2,
                cellTemplate: "commentTemplate"
            }, {
                dataField: "updated_at",
                caption: d("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                hidingPriority: 1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: d("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                visible: !0,
                hidingPriority: 0,
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                width: 45
            }]
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = +e.amc_contract_id
                },
                error: e => {
                    console.error(e)
                }
            }), this.contractContextMenu = [{
                name: Rt.ADD_PAYMENT,
                icon: "fa-thin fa-money-check-alt",
                visible: this.isEmployee && this.userPermissionList.includes(x.PAYMENT_WRITE)
            }, {
                name: Rt.PURCHASE_INVOICE,
                icon: "fa-thin fa-file-invoice-dollar",
                visible: !0
            }]
        }
        onContextMenuItemClick(e) {}
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentAmcComplaint = null
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption()
        }
        onAmcServiceSave() {
            this.isCreate = !1, this.isVisibleAmcComplaintPopup = !1, this.amcComplaint = null, this.dataGrid.getData()
        }
        create() {
            this.isVisibleAmcComplaintPopup = !0, this.isCreate = !0, this.amcComplaint = null
        }
        edit(e) {
            this.isCreate = !1, this.amcComplaint = e, this.isVisibleAmcComplaintPopup = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(Pt))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-complaint-list"]
                ],
                viewQuery: function(o, n) {
                    if (o & 1 && q(L, 5), o & 2) {
                        let v;
                        W(v = H()) && (n.dataGrid = v.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 23,
                consts: [
                    [1, "complaint-lists"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "searchPanelPlaceholderText", "isVisibleExportAction", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "amcComplaint", "isCreate", "isVisiblePopup"],
                    [3, "amcComplaintCancelClick", "amcComplaintSaveClick", "amcComplaint", "isCreate", "isVisiblePopup"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "app-data-grid", 1), h("contextMenuItemCancelClick", function() {
                        return n.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(E) {
                        return n.onContextMenuItemClick(E)
                    })("dataGridAddNewClick", function() {
                        return n.create()
                    })("dataGridEditClick", function(E) {
                        return n.edit(E)
                    }), a()(), _(2, sa, 1, 3, "app-amc-complaint-popup", 2)), o & 2 && (i(), r("additionalParams", Je(12, aa, n.amcContractId))("columns", n.columns)("entity", n.entity)("isVisibleAddAction", !!n.amcContractId)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("searchPanelPlaceholderText", "search_panel_amc_complaints_placeholder")("isVisibleExportAction", !1)("service", n.service)("hasTenantData", n.hasTenantAmcComplaints)("emptyStateConfig", Ke(18, ca, n.formatMessage("empty_state_amc_complaint_title"), n.formatMessage("empty_state_amc_complaint_description"), n.amcContractId ? "empty_state_amc_complaint_primary_button" : "", J(14, ra, n.formatMessage("empty_state_amc_complaint_tip_1"), n.formatMessage("empty_state_amc_complaint_tip_2"), n.formatMessage("empty_state_amc_complaint_tip_3")))), i(), u(n.isVisibleAmcComplaintPopup ? 2 : -1))
                },
                dependencies: [L, Pn],
                encapsulation: 2
            })
        }
    }
    return t
})();
var la = (t, s, e) => [t, s, e],
    ma = (t, s, e) => ({
        icon: "dx-icon-folder",
        title: t,
        description: s,
        primaryButtonText: "empty_state_amc_primary_button",
        quickTips: e,
        tutorialVisible: !1,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function pa(t, s) {
    if (t & 1 && m(0, "app-overview-report-card-on-list", 0), t & 2) {
        let e = l();
        r("entity", e.ENTITIES.AMC_CONTRACT.name)("label", e.formatMessage("overview_report_amc_contract_quick_overview_report"))
    }
}

function da(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-unified-payment-modal", 4), h("paymentClose", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        })("paymentSuccess", function(n) {
            y(e);
            let v = l();
            return S(v.onPaymentSuccess(n))
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("isVisiblePopup", e.isVisibleUnifiedPaymentModal)("entity", e.currentAmcContract)("entityType", e.ENTITIES.AMC_CONTRACT.name)
    }
}

function _a(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "app-amc-status-update-popup", 5), h("amcStatusClose", function() {
            y(e);
            let n = l();
            return S(n.onCloseContextMenuOption())
        })("amcStatusSave", function(n) {
            y(e);
            let v = l();
            return S(v.onPopupSaveAction(n))
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("amcContract", e.currentAmcContract)("isVisiblePopup", e.isVisibleAmcStatusUpdatePopup && e.currentContextMenuAction === e.AMC_CONTRACT_CONTEXT_MENU_LIST.UPDATE_STATUS)
    }
}
var Nn = (() => {
    class t {
        get hasTenantAmcContracts() {
            return this.isEmployee ? (this.tenantService.config() ? .entity_counts ? .amc_contracts || 0) > 0 : !0
        }
        constructor(e) {
            this.service = e, this.formatMessage = d, this.ENTITIES = M, this.router = C(Y), this.userSessionService = C(b), this.isMobileDevice = C(O).isMobileDevice(), this.tenantService = C(Ie), this.printService = C(Fi), this.isEmployee = this.userSessionService.isEmployee(), this.isAdmin = this.userSessionService.isAdmin(), this.userPermissionList = this.userSessionService.userPermissionList(), this.currentContextMenuAction = null, this.isVisibleUnifiedPaymentModal = !1, this.isVisibleAmcStatusUpdatePopup = !1, this.contractContextMenu = [], this.entity = M.AMC_CONTRACT, this.columns = [{
                dataField: "contract_number",
                caption: d("contracts"),
                width: this.isMobileDevice ? 90 : 130,
                alignment: "center",
                cellTemplate: "idLinkTemplate"
            }, {
                dataField: "user",
                caption: d("user_customer"),
                width: 130,
                allowSorting: !1,
                cellTemplate: "userTemplate"
            }, {
                dataField: "amc_types.name",
                caption: d("amc_type"),
                allowSorting: !1,
                alignment: "center",
                hidingPriority: 9,
                visible: !1,
                width: 130
            }, {
                dataField: "assigned_user",
                caption: d("common_assignee"),
                allowSorting: !1,
                alignment: "center",
                cellTemplate: "employeeTemplate",
                hidingPriority: 8,
                width: 130
            }, {
                dataField: "payment_received",
                caption: d("payment_received"),
                showInColumnChooser: this.userPermissionList.includes(x.AMC_CONTRACT_VIEW_PAYMENT_COLUMN_IN_AMC_CONTRACT_LIST),
                visible: this.userPermissionList.includes(x.AMC_CONTRACT_VIEW_PAYMENT_COLUMN_IN_AMC_CONTRACT_LIST),
                allowSorting: !1,
                hidingPriority: 7,
                alignment: "center",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_amount",
                caption: d("total_amount"),
                dataType: "number",
                showInColumnChooser: this.userPermissionList.includes(x.AMC_CONTRACT_VIEW_PAYMENT_COLUMN_IN_AMC_CONTRACT_LIST),
                visible: this.userPermissionList.includes(x.AMC_CONTRACT_VIEW_PAYMENT_COLUMN_IN_AMC_CONTRACT_LIST),
                allowSorting: !1,
                hidingPriority: 6,
                alignment: "center",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "number_of_services",
                caption: d("services_count"),
                alignment: "center",
                allowSorting: !1,
                hidingPriority: 4,
                visible: !1
            }, {
                dataField: "start_date",
                caption: d("contract_start_on"),
                cellTemplate: "dateTemplate",
                hidingPriority: 5,
                allowSorting: !1,
                alignment: "center"
            }, {
                dataField: "end_date",
                caption: d("contract_ends_at"),
                cellTemplate: "dateTemplate",
                hidingPriority: 3,
                allowSorting: !1,
                alignment: "center"
            }, {
                dataField: "status",
                caption: d("common_status"),
                allowSorting: !1,
                cellTemplate: "amcContractStatusTemplate",
                hidingPriority: 11,
                alignment: "center"
            }, {
                dataField: "payment_status",
                caption: d("payment_status"),
                allowSorting: !1,
                cellTemplate: "amcPaymentStatusTemplate",
                hidingPriority: 10,
                alignment: "center"
            }, {
                dataField: "is_contract_auto_renew",
                caption: d("auto_renew"),
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                hidingPriority: 2,
                visible: !1,
                allowSorting: !1,
                alignment: "center"
            }, {
                dataField: "updated_at",
                caption: d("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 1,
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "created_at",
                caption: d("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 0,
                allowSorting: !0,
                visible: !1,
                alignment: "center"
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                width: 54
            }], this.AMC_CONTRACT_CONTEXT_MENU_LIST = V, this.jobContextMenuList = yi
        }
        ngOnInit() {
            this.contractContextMenu = [{
                name: V.AMC_CONTRACT,
                icon: "fa-thin fa-file-alt",
                visible: !0,
                locale_key: d("amc_action_amc_contract")
            }, {
                name: V.ADD_PAYMENT,
                icon: "fa-thin fa-file-invoice-dollar",
                visible: this.isEmployee && this.userPermissionList.includes(x.PAYMENT_WRITE),
                locale_key: d("add_payment")
            }, {
                name: V.UPDATE_STATUS,
                icon: "fa-thin fa-circle",
                visible: this.isEmployee,
                locale_key: d("update_status")
            }, {
                name: V.STICKER_PRINT,
                icon: "fa-thin fa-print",
                visible: this.isEmployee,
                locale_key: d("sticker_print")
            }]
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentAmcContract = e.entity, this.currentContextMenuAction === V.AMC_CONTRACT && this.router.navigate([`/amcs/${this.currentAmcContract.id}/amcContract`]), this.currentContextMenuAction === V.ADD_PAYMENT && (this.isVisibleUnifiedPaymentModal = !0), this.currentContextMenuAction === V.UPDATE_STATUS && (this.isVisibleAmcStatusUpdatePopup = !0), this.currentContextMenuAction === V.STICKER_PRINT && this.printService.getThermalPrint("amc_contract_sticker", this.currentAmcContract.id, "Sticker", !1)
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentAmcContract = null, this.isVisibleUnifiedPaymentModal = !1
        }
        create() {
            this.router.navigate(["/amcs/add"])
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption()
        }
        onPaymentSuccess(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(F))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-contract-list"]
                ],
                viewQuery: function(o, n) {
                    if (o & 1 && q(L, 5), o & 2) {
                        let v;
                        W(v = H()) && (n.dataGrid = v.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 23,
                consts: [
                    [3, "entity", "label"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "columns", "contextMenuItems", "dataGridId", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "searchPanelPlaceholderText", "isVisibleExportAction", "isVisibleReportDropdown", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "isVisiblePopup", "entity", "entityType"],
                    [3, "amcContract", "isVisiblePopup"],
                    [3, "paymentClose", "paymentSuccess", "isVisiblePopup", "entity", "entityType"],
                    [3, "amcStatusClose", "amcStatusSave", "amcContract", "isVisiblePopup"]
                ],
                template: function(o, n) {
                    o & 1 && (_(0, pa, 1, 2, "app-overview-report-card-on-list", 0), c(1, "app-data-grid", 1), h("contextMenuItemCancelClick", function() {
                        return n.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(E) {
                        return n.onContextMenuItemClick(E)
                    })("dataGridAddNewClick", function() {
                        return n.create()
                    }), a(), _(2, da, 1, 3, "app-unified-payment-modal", 2), _(3, _a, 1, 2, "app-amc-status-update-popup", 3)), o & 2 && (u(n.isAdmin ? 0 : -1), i(), r("columns", n.columns)("contextMenuItems", n.contractContextMenu)("dataGridId", "tabAndGridContainer")("entity", n.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("searchPanelPlaceholderText", "search_panel_amc_contracts_placeholder")("isVisibleExportAction", !0)("isVisibleReportDropdown", !0)("service", n.service)("hasTenantData", n.hasTenantAmcContracts)("emptyStateConfig", J(19, ma, n.formatMessage("empty_state_amc_title"), n.formatMessage("empty_state_amc_description"), J(15, la, n.formatMessage("empty_state_amc_tip_1"), n.formatMessage("empty_state_amc_tip_2"), n.formatMessage("empty_state_amc_tip_3")))), i(), u(n.currentAmcContract != null && n.currentAmcContract.id && n.isVisibleUnifiedPaymentModal ? 2 : -1), i(), u(n.isVisibleAmcStatusUpdatePopup && n.currentContextMenuAction === n.AMC_CONTRACT_CONTEXT_MENU_LIST.UPDATE_STATUS ? 3 : -1))
                },
                dependencies: [L, cn, mn, It],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ca(t, s) {
    if (t & 1 && (c(0, "div")(1, "div", 1), m(2, "app-status-tag", 2)(3, "i", 3)(4, "app-status-tag", 2), a()()), t & 2) {
        let e = l();
        i(2), r("iconType", e.STATUS_ICON_TYPES.EXTRA_SMALL)("status", e.activity == null || e.activity.properties == null || e.activity.properties.old == null ? null : e.activity.properties.old.status), i(2), r("iconType", e.STATUS_ICON_TYPES.EXTRA_SMALL)("status", e.activity == null || e.activity.properties == null || e.activity.properties.attributes == null ? null : e.activity.properties.attributes.status)
    }
}

function va(t, s) {
    if (t & 1 && (c(0, "div")(1, "div", 1)(2, "span"), p(3), a(), m(4, "i", 3)(5, "app-status-tag", 2), a()()), t & 2) {
        let e = l();
        i(3), P(e.formatMessage("common_status")), i(2), r("iconType", e.STATUS_ICON_TYPES.EXTRA_SMALL)("status", e.activity == null || e.activity.properties == null || e.activity.properties.attributes == null ? null : e.activity.properties.attributes.status)
    }
}

function fa(t, s) {
    if (t & 1 && (m(0, "div", 0), k(1, "safe")), t & 2) {
        let e = l();
        r("innerHTML", j(1, 1, e.activity.properties == null || e.activity.properties.attributes == null ? null : e.activity.properties.attributes.description, "html"), $e)
    }
}
var wn = (() => {
    class t extends Ve {
        constructor() {
            super(...arguments), this.AMC_ACTIVITY_EVENT_TYPES = T, this.STATUS_ICON_TYPES = z, this.formatMessage = d, this.allChangedFieldsData = []
        }
        loadFields() {
            this.event === T.AMC_COMPLAINT_UPDATED && this.activity ? .properties ? .old && this.activity ? .properties ? .attributes ? this.allChangedFieldsData = this.extractChangedFields(this.activity.properties.old, this.activity.properties.attributes) : this.activity ? .properties ? .attributes && (this.allFieldsData = this.extractFields(this.activity.properties.attributes))
        }
        static {
            this.\u0275fac = (() => {
                let e;
                return function(n) {
                    return (e || (e = he(t)))(n || t)
                }
            })()
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-complaint-activity"]
                ],
                inputs: {
                    event: "event"
                },
                features: [ye],
                decls: 3,
                vars: 2,
                consts: [
                    [1, "comment-text", 3, "innerHTML"],
                    [1, "d-flex", "align-items-center", "my-2"],
                    [3, "iconType", "status"],
                    [1, "fa-thin", "fa-arrow-right", "mx-2"]
                ],
                template: function(o, n) {
                    o & 1 && (_(0, Ca, 5, 4, "div")(1, va, 6, 3, "div"), _(2, fa, 2, 4, "div", 0)), o & 2 && (u(n.event === n.AMC_ACTIVITY_EVENT_TYPES.AMC_COMPLAINT_UPDATED ? 0 : 1), i(2), u(n.activity && (!(n.activity.properties == null || n.activity.properties.attributes == null) && n.activity.properties.attributes.description) ? 2 : -1))
                },
                dependencies: [G, Ce, st],
                styles: [".comment-text[_ngcontent-%COMP%]{font-size:12px;line-height:1.5;color:var(--text-color)}"]
            })
        }
    }
    return t
})();
var On = (() => {
    class t extends Ve {
        constructor() {
            super(...arguments), this.statusIconTypeList = z, this.AMC_ACTIVITY_EVENT_TYPES = T, this.allChangedFieldsData = []
        }
        loadFields() {
            this.activity ? .properties ? .old && this.activity ? .properties ? .attributes && (this.allChangedFieldsData = this.extractChangedFields(this.activity.properties.old, this.activity.properties.attributes))
        }
        static {
            this.\u0275fac = (() => {
                let e;
                return function(n) {
                    return (e || (e = he(t)))(n || t)
                }
            })()
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-contract-status-activity"]
                ],
                features: [ye],
                decls: 5,
                vars: 4,
                consts: [
                    [1, "d-flex", "align-items-center", "my-2"],
                    [3, "iconType", "status"],
                    [1, "fa-thin", "fa-arrow-right", "mx-2"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div")(1, "div", 0), m(2, "app-amc-contract-status-tag", 1)(3, "i", 2)(4, "app-amc-contract-status-tag", 1), a()()), o & 2 && (i(2), r("iconType", n.statusIconTypeList.EXTRA_SMALL)("status", n.activity.properties == null || n.activity.properties.old == null ? null : n.activity.properties.old.status), i(2), r("iconType", n.statusIconTypeList.EXTRA_SMALL)("status", n.activity.properties == null || n.activity.properties.attributes == null ? null : n.activity.properties.attributes.status))
                },
                dependencies: [G, Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();

function ya(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), m(4, "app-currency-symbol"), p(5)), t & 2) {
        let e = l(2);
        i(3), f("", e.formatMessage("th_service_charge"), ":"), i(2), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.service_charge, " ")
    }
}

function Sa(t, s) {
    if (t & 1 && (c(0, "span"), p(1), a(), m(2, "app-currency-symbol"), p(3)), t & 2) {
        let e = l(3);
        i(), f("", e.formatMessage("th_travel_expenditure"), ":"), i(2), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.travel_expenditure, " ")
    }
}

function Aa(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), m(4, "app-currency-symbol"), p(5)), t & 2) {
        let e = l(3);
        i(3), f("", e.formatMessage("th_service_expenditure"), ":"), i(2), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.service_expenditure, " ")
    }
}

function ga(t, s) {
    if (t & 1 && (c(0, "div", 3), _(1, Sa, 4, 2), _(2, Aa, 6, 2), a()), t & 2) {
        let e = l(2);
        i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.travel_expenditure ? 1 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.service_expenditure ? 2 : -1)
    }
}

function xa(t, s) {
    if (t & 1 && m(0, "app-comment-activity", 4), t & 2) {
        let e = l(2);
        r("comment", e.activity.properties == null || e.activity.properties.attributes == null ? null : e.activity.properties.attributes.service_remark)
    }
}

function Ea(t, s) {
    if (t & 1 && (c(0, "div")(1, "div", 0)(2, "div", 1)(3, "span"), p(4), a(), m(5, "app-status-tag", 2), a(), c(6, "div", 3)(7, "span"), p(8), a(), p(9), k(10, "dateFormat"), a(), c(11, "div", 3)(12, "span"), p(13), a(), p(14), _(15, ya, 6, 2), a(), _(16, ga, 3, 2, "div", 3), a(), _(17, xa, 1, 1, "app-comment-activity", 4), a()), t & 2) {
        let e = l();
        i(4), f("", e.formatMessage("th_status"), ":"), i(), r("iconType", e.STATUS_ICON_TYPES.EXTRA_SMALL)("status", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.status), i(3), f("", e.formatMessage("th_service_date"), ":"), i(), f(" ", j(10, 10, e.activity.properties.attributes == null ? null : e.activity.properties.attributes.service_date, "datetime"), " "), i(4), f("", e.formatMessage("th_service_type"), ":"), i(), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.service_type, " "), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.service_charge ? 15 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.travel_expenditure || e.activity.properties.attributes != null && e.activity.properties.attributes.service_expenditure ? 16 : -1), i(), u(!(e.activity.properties == null || e.activity.properties.attributes == null) && e.activity.properties.attributes.service_remark ? 17 : -1)
    }
}

function Ma(t, s) {
    if (t & 1 && (c(0, "span"), p(1), a(), p(2)), t & 2) {
        let e = l(2);
        i(), f("", e.formatMessage("th_device_type"), ":"), i(), f(" ", e.activity.properties.attributes == null || e.activity.properties.attributes.device_type == null ? null : e.activity.properties.attributes.device_type.name, " ")
    }
}

function ba(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), p(4)), t & 2) {
        let e = l(2);
        i(3), f("", e.formatMessage("th_device_brand"), ":"), i(), f(" ", e.activity.properties.attributes == null || e.activity.properties.attributes.device_brand == null ? null : e.activity.properties.attributes.device_brand.name, " ")
    }
}

function Ia(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), p(4)), t & 2) {
        let e = l(2);
        i(3), f("", e.formatMessage("th_device_model"), ":"), i(), f(" ", e.activity.properties.attributes == null || e.activity.properties.attributes.device_model == null ? null : e.activity.properties.attributes.device_model.name, " ")
    }
}

function Pa(t, s) {
    if (t & 1 && (c(0, "span"), p(1), a(), p(2)), t & 2) {
        let e = l(3);
        i(), f("", e.formatMessage("th_warranty_status"), ":"), i(), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.warranty_status, " ")
    }
}

function Na(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), p(4), k(5, "dateFormat")), t & 2) {
        let e = l(3);
        i(3), f("", e.formatMessage("th_warranty_expiry_date"), ":"), i(), f(" ", j(5, 2, e.activity.properties.attributes == null ? null : e.activity.properties.attributes.warranty_expiry_date, "datetime"), " ")
    }
}

function wa(t, s) {
    if (t & 1 && (c(0, "div", 3), _(1, Pa, 3, 2), _(2, Na, 6, 5), a()), t & 2) {
        let e = l(2);
        i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.warranty_status ? 1 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.warranty_expiry_date ? 2 : -1)
    }
}

function Oa(t, s) {
    if (t & 1 && m(0, "app-comment-activity", 4), t & 2) {
        let e = l(2);
        r("comment", e.activity.properties == null || e.activity.properties.attributes == null ? null : e.activity.properties.attributes.comment)
    }
}

function Da(t, s) {
    if (t & 1 && (c(0, "div")(1, "div", 0)(2, "div", 3), _(3, Ma, 3, 2), _(4, ba, 5, 2), _(5, Ia, 5, 2), a(), _(6, wa, 3, 2, "div", 3), a(), _(7, Oa, 1, 1, "app-comment-activity", 4), a()), t & 2) {
        let e = l();
        i(3), u(!(e.activity.properties.attributes == null || e.activity.properties.attributes.device_type == null) && e.activity.properties.attributes.device_type.name ? 3 : -1), i(), u(!(e.activity.properties.attributes == null || e.activity.properties.attributes.device_brand == null) && e.activity.properties.attributes.device_brand.name ? 4 : -1), i(), u(!(e.activity.properties.attributes == null || e.activity.properties.attributes.device_model == null) && e.activity.properties.attributes.device_model.name ? 5 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.warranty_status || e.activity.properties.attributes != null && e.activity.properties.attributes.warranty_expiry_date ? 6 : -1), i(), u(!(e.activity.properties == null || e.activity.properties.attributes == null) && e.activity.properties.attributes.comment ? 7 : -1)
    }
}

function Va(t, s) {
    if (t & 1 && (c(0, "span"), p(1), a(), p(2)), t & 2) {
        let e = l(2);
        i(), f("", e.formatMessage("th_name"), ":"), i(), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.name, " ")
    }
}

function Ra(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), p(4)), t & 2) {
        let e = l(2);
        i(3), f("", e.formatMessage("th_software_company"), ":"), i(), f(" ", e.activity.properties.attributes == null ? null : e.activity.properties.attributes.vendor, " ")
    }
}

function La(t, s) {
    if (t & 1 && (c(0, "span"), p(1), a(), p(2), k(3, "dateFormat")), t & 2) {
        let e = l(3);
        i(), f("", e.formatMessage("th_purchase_date"), ":"), i(), f(" ", j(3, 2, e.activity.properties.attributes == null ? null : e.activity.properties.attributes.purchase_date, "datetime"), " ")
    }
}

function Fa(t, s) {
    if (t & 1 && (c(0, "span", 5), p(1, "\u2022"), a(), c(2, "span"), p(3), a(), p(4), k(5, "dateFormat")), t & 2) {
        let e = l(3);
        i(3), f("", e.formatMessage("th_expiry_date"), ":"), i(), f(" ", j(5, 2, e.activity.properties.attributes == null ? null : e.activity.properties.attributes.expiry_date, "datetime"), " ")
    }
}

function ka(t, s) {
    if (t & 1 && (c(0, "div", 3), _(1, La, 4, 5), _(2, Fa, 6, 5), a()), t & 2) {
        let e = l(2);
        i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.purchase_date ? 1 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.expiry_date ? 2 : -1)
    }
}

function Ua(t, s) {
    if (t & 1 && m(0, "app-comment-activity", 4), t & 2) {
        let e = l(2);
        r("comment", e.activity.properties == null || e.activity.properties.attributes == null ? null : e.activity.properties.attributes.description)
    }
}

function Ya(t, s) {
    if (t & 1 && (c(0, "div")(1, "div", 0)(2, "div", 3), _(3, Va, 3, 2), _(4, Ra, 5, 2), a(), _(5, ka, 3, 2, "div", 3), a(), _(6, Ua, 1, 1, "app-comment-activity", 4), a()), t & 2) {
        let e = l();
        i(3), u(e.activity.properties.attributes != null && e.activity.properties.attributes.name ? 3 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.vendor ? 4 : -1), i(), u(e.activity.properties.attributes != null && e.activity.properties.attributes.purchase_date || e.activity.properties.attributes != null && e.activity.properties.attributes.expiry_date ? 5 : -1), i(), u(!(e.activity.properties == null || e.activity.properties.attributes == null) && e.activity.properties.attributes.description ? 6 : -1)
    }
}
var Dn = (() => {
    class t extends Ve {
        constructor() {
            super(...arguments), this.formatMessage = d, this.AMC_ACTIVITY_EVENT_TYPES = T, this.STATUS_ICON_TYPES = z
        }
        loadFields() {
            this.activity ? .properties ? .attributes && (this.allFieldsData = this.extractFields(this.activity.properties.attributes))
        }
        static {
            this.\u0275fac = (() => {
                let e;
                return function(n) {
                    return (e || (e = he(t)))(n || t)
                }
            })()
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-service-activity"]
                ],
                features: [ye],
                decls: 4,
                vars: 1,
                consts: [
                    [1, "mb-2"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-2"],
                    [3, "iconType", "status"],
                    [1, "mb-1"],
                    [3, "comment"],
                    [1, "mx-2"]
                ],
                template: function(o, n) {
                    if (o & 1 && (c(0, "div"), _(1, Ea, 18, 13, "div")(2, Da, 8, 5, "div")(3, Ya, 7, 4, "div"), a()), o & 2) {
                        let v;
                        i(), u((v = n.activity.event) === n.AMC_ACTIVITY_EVENT_TYPES.AMC_SERVICE_CREATED ? 1 : v === n.AMC_ACTIVITY_EVENT_TYPES.DEVICE_INFORMATION_CREATED ? 2 : v === n.AMC_ACTIVITY_EVENT_TYPES.SOFTWARE_CREATED ? 3 : -1)
                    }
                },
                dependencies: [G, yt, Ce, De, ot],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ba(t, s) {
    t & 1 && m(0, "div", 15)
}

function Ga(t, s) {
    if (t & 1 && (c(0, "span", 16), p(1), a()), t & 2) {
        let e = l(2);
        i(), f(" by ", e.activity.causer.display_name || e.activity.causer.name, " ")
    }
}

function ja(t, s) {
    if (t & 1 && (c(0, "span", 17), m(1, "i", 18), a()), t & 2) {
        let e = l(2);
        r("title", e.formatMessage("VISIBLE_TO_EMPLOYEES_ONLY"))
    }
}

function qa(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-assignee-activity", 19)(2, "app-comment-activity", 20), a()), t & 2) {
        let e = l(3);
        i(), r("activity", e.activity), i(), r("comment", e.activity.properties == null ? null : e.activity.properties.comment)
    }
}

function Wa(t, s) {
    if (t & 1 && (Kt(0), R(1, qa, 3, 2, "div", 14), ei()), t & 2) {
        let e = l(2);
        i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_ASSIGNEE_UPDATED)
    }
}

function Ha(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-contract-status-activity", 19)(2, "app-comment-activity", 20), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity), i(), r("comment", e.activity.properties == null ? null : e.activity.properties.comment)
    }
}

function za(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-contract-status-activity", 19)(2, "app-assignee-activity", 19)(3, "app-comment-activity", 20), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity), i(), r("activity", e.activity), i(), r("comment", e.activity.properties == null ? null : e.activity.properties.comment)
    }
}

function Qa(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-updated-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function Xa(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-complaint-activity", 21), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)("event", e.AMC_ACTIVITY_EVENT_TYPES.AMC_COMPLAINT_CREATED)
    }
}

function $a(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-complaint-activity", 21), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)("event", e.AMC_ACTIVITY_EVENT_TYPES.AMC_COMPLAINT_UPDATED)
    }
}

function Za(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-created-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function Ja(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-created-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function Ka(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-created-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function er(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-service-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function tr(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-service-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function ir(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-service-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function nr(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-updated-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function or(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-updated-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function ar(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-delete-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function rr(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-entity-delete-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function cr(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-attachment-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function sr(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-attachment-activity", 19), a()), t & 2) {
        let e = l(2);
        i(), r("activity", e.activity)
    }
}

function lr(t, s) {
    if (t & 1 && (c(0, "div", 1)(1, "div", 2)(2, "div"), m(3, "i"), a(), R(4, Ba, 1, 0, "div", 3), a(), c(5, "div", 4)(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "span", 8), p(10), a(), R(11, Ga, 2, 1, "span", 9)(12, ja, 2, 1, "span", 10), a()(), c(13, "div", 11), p(14), k(15, "dateFormat"), a()(), c(16, "div", 12), R(17, Wa, 2, 1, "ng-container", 13)(18, Ha, 3, 2, "div", 14)(19, za, 4, 3, "div", 14)(20, Qa, 2, 1, "div", 14)(21, Xa, 2, 2, "div", 14)(22, $a, 2, 2, "div", 14)(23, Za, 2, 1, "div", 14)(24, Ja, 2, 1, "div", 14)(25, Ka, 2, 1, "div", 14)(26, er, 2, 1, "div", 14)(27, tr, 2, 1, "div", 14)(28, ir, 2, 1, "div", 14)(29, nr, 2, 1, "div", 14)(30, or, 2, 1, "div", 14)(31, ar, 2, 1, "div", 14)(32, rr, 2, 1, "div", 14)(33, cr, 2, 1, "div", 14)(34, sr, 2, 1, "div", 14), a()()()), t & 2) {
        let e = l();
        i(2), Ge(je("activity-icon ", e.getActivityIconColor(), " rounded-circle d-flex align-items-center justify-content-center flex-shrink-0")), i(), Ge(je("fa-thin ", e.getActivityIcon(), " text-white")), i(), r("ngIf", !e.isLast), i(6), P(e.getActivityTitle()), i(), r("ngIf", e.activity.causer), i(), r("ngIf", e.isVisibleToEmployeesOnly()), i(2), f(" ", j(15, 30, e.activity.created_at, "datetime"), " "), i(2), r("ngSwitch", e.activity.event), i(), r("ngIf", e.isEmployee), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_STATUS_UPDATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_UPDATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_COMPLAINT_CREATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_COMPLAINT_UPDATED), i(), r("ngSwitchCase", e.ACTIVITY_EVENT_TYPES.PAYMENT_CREATED), i(), r("ngSwitchCase", e.ACTIVITY_EVENT_TYPES.PAYMENT_UPDATED), i(), r("ngSwitchCase", e.ACTIVITY_EVENT_TYPES.PAYMENT_DELETED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.AMC_SERVICE_CREATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.DEVICE_INFORMATION_CREATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.SOFTWARE_CREATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.SOFTWARE_UPDATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.DEVICE_INFORMATION_UPDATED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.DEVICE_INFORMATION_DELETED), i(), r("ngSwitchCase", e.AMC_ACTIVITY_EVENT_TYPES.SOFTWARE_DELETED), i(), r("ngSwitchCase", e.ACTIVITY_EVENT_TYPES.ATTACHMENT_CREATED), i(), r("ngSwitchCase", e.ACTIVITY_EVENT_TYPES.ATTACHMENT_DELETED)
    }
}
var Vn = (() => {
    class t {
        constructor() {
            this.formatMessage = d, this.isLast = !1, this.userSessionService = C(b), this.isMobileDevice = C(O).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.ACTIVITY_EVENT_TYPES = D, this.AMC_ACTIVITY_EVENT_TYPES = T, this.isVisibleTitle = !0
        }
        ngOnInit() {
            [T.AMC_CONTRACT_ASSIGNEE_UPDATED, T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED].includes(this.activity.event) && !this.isEmployee && (this.isVisibleTitle = !1)
        }
        getActivityIcon() {
            return {
                [T.AMC_CONTRACT_STATUS_UPDATED]: "fa-chart-bar",
                [T.AMC_CONTRACT_ASSIGNEE_UPDATED]: "fa-user-cog",
                [T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED]: "fa-arrows-rotate",
                [T.AMC_CONTRACT_UPDATED]: "fa-pen-to-square",
                [T.AMC_CONTRACT_CREATED]: "fa-plus-circle",
                [T.AMC_COMPLAINT_CREATED]: "fa-message",
                [T.AMC_COMPLAINT_UPDATED]: "fa-pen-to-square",
                [T.AMC_SERVICE_CREATED]: "fa-wrench",
                [T.DEVICE_INFORMATION_CREATED]: "fa-mobile",
                [T.DEVICE_INFORMATION_UPDATED]: "fa-mobile",
                [T.DEVICE_INFORMATION_DELETED]: "fa-trash",
                [T.SOFTWARE_CREATED]: "fa-laptop-code",
                [T.SOFTWARE_UPDATED]: "fa-laptop-code",
                [T.SOFTWARE_DELETED]: "fa-trash",
                [D.PAYMENT_CREATED]: "fa-credit-card",
                [D.PAYMENT_UPDATED]: "fa-credit-card",
                [D.PAYMENT_DELETED]: "fa-credit-card",
                [D.ATTACHMENT_CREATED]: "fa-paperclip",
                [D.ATTACHMENT_DELETED]: "fa-paperclip"
            }[this.activity.event] || "fa-circle-info"
        }
        getActivityIconColor() {
            return {
                [T.AMC_CONTRACT_STATUS_UPDATED]: "activity-icon-blue",
                [T.AMC_CONTRACT_ASSIGNEE_UPDATED]: "activity-icon-purple",
                [T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED]: "activity-icon-purple",
                [T.AMC_CONTRACT_UPDATED]: "activity-icon-orange",
                [T.AMC_CONTRACT_CREATED]: "activity-icon-green",
                [T.AMC_COMPLAINT_CREATED]: "activity-icon-blue",
                [T.AMC_COMPLAINT_UPDATED]: "activity-icon-orange",
                [T.AMC_SERVICE_CREATED]: "activity-icon-green",
                [T.DEVICE_INFORMATION_CREATED]: "activity-icon-green",
                [T.DEVICE_INFORMATION_UPDATED]: "activity-icon-orange",
                [T.DEVICE_INFORMATION_DELETED]: "activity-icon-red",
                [T.SOFTWARE_CREATED]: "activity-icon-green",
                [T.SOFTWARE_UPDATED]: "activity-icon-orange",
                [T.SOFTWARE_DELETED]: "activity-icon-red",
                [D.PAYMENT_CREATED]: "activity-icon-emerald",
                [D.PAYMENT_UPDATED]: "activity-icon-emerald",
                [D.PAYMENT_DELETED]: "activity-icon-emerald",
                [D.ATTACHMENT_CREATED]: "activity-icon-indigo",
                [D.ATTACHMENT_DELETED]: "activity-icon-red"
            }[this.activity.event] || "activity-icon-gray"
        }
        getActivityTitle() {
            let e = {
                [T.AMC_CONTRACT_STATUS_UPDATED]: "STATUS_CHANGED",
                [T.AMC_CONTRACT_ASSIGNEE_UPDATED]: "ASSIGNEE_CHANGED",
                [T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED]: "ASSIGNEE_STATUS_CHANGED",
                [T.AMC_CONTRACT_UPDATED]: "amc_contract_updated",
                [T.AMC_CONTRACT_CREATED]: "amc_contract_created",
                [T.AMC_COMPLAINT_CREATED]: "amc_complaint_created",
                [T.AMC_COMPLAINT_UPDATED]: "amc_complaint_updated",
                [T.AMC_SERVICE_CREATED]: "amc_service_created",
                [T.DEVICE_INFORMATION_CREATED]: "amc_device_created",
                [T.DEVICE_INFORMATION_UPDATED]: "amc_device_updated",
                [T.DEVICE_INFORMATION_DELETED]: "amc_device_deleted",
                [T.SOFTWARE_CREATED]: "amc_software_created",
                [T.SOFTWARE_UPDATED]: "amc_software_updated",
                [T.SOFTWARE_DELETED]: "amc_software_deleted",
                [D.PAYMENT_CREATED]: "PAYMENT_RECEIVED",
                [D.PAYMENT_UPDATED]: "PAYMENT_UPDATED",
                [D.PAYMENT_DELETED]: "PAYMENT_DELETED",
                [D.ATTACHMENT_CREATED]: "ATTACHMENT_ADDED",
                [D.ATTACHMENT_DELETED]: "ATTACHMENT_DELETED"
            };
            return d(e[this.activity.event] || "ACTIVITY")
        }
        isVisibleToEmployeesOnly() {
            return [T.AMC_CONTRACT_ASSIGNEE_UPDATED, T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED].includes(this.activity.event) && !this.isEmployee
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-activity-list"]
                ],
                inputs: {
                    activity: "activity",
                    isLast: "isLast"
                },
                decls: 1,
                vars: 1,
                consts: [
                    ["class", "activity-card-wrapper d-flex gap-2 position-relative", 4, "ngIf"],
                    [1, "activity-card-wrapper", "d-flex", "gap-2", "position-relative"],
                    [1, "activity-icon-wrapper", "position-relative", "d-flex", "flex-column", "align-items-center"],
                    ["class", "timeline-connector", 4, "ngIf"],
                    [1, "activity-content", "flex-grow-1", "pb-4"],
                    [1, "activity-header", "d-flex", "justify-content-between", "align-items-start", "gap-2", "mb-1"],
                    [1, "flex-grow-1"],
                    [1, "d-flex", "align-items-center", "gap-2", "flex-wrap"],
                    [1, "activity-title", "fw-bold"],
                    ["class", "activity-user text-muted", 4, "ngIf"],
                    ["class", "employee-only-badge", 3, "title", 4, "ngIf"],
                    [1, "activity-timestamp", "text-muted", "small", "text-nowrap"],
                    [1, "activity-body", 3, "ngSwitch"],
                    [4, "ngIf"],
                    [4, "ngSwitchCase"],
                    [1, "timeline-connector"],
                    [1, "activity-user", "text-muted"],
                    [1, "employee-only-badge", 3, "title"],
                    [1, "fa-thin", "fa-eye", "text-muted"],
                    [3, "activity"],
                    [3, "comment"],
                    [3, "activity", "event"]
                ],
                template: function(o, n) {
                    o & 1 && R(0, lr, 35, 33, "div", 0), o & 2 && r("ngIf", n.isVisibleTitle)
                },
                dependencies: [oi, ai, ri, G, tn, nn, on, yt, an, rn, On, wn, Dn, ot],
                styles: ["[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-icon-wrapper[_ngcontent-%COMP%]{width:36px}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-icon-wrapper[_ngcontent-%COMP%]   .activity-icon[_ngcontent-%COMP%]{width:32px;height:32px;z-index:10}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-icon-wrapper[_ngcontent-%COMP%]   .activity-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:13px}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-icon-wrapper[_ngcontent-%COMP%]   .timeline-connector[_ngcontent-%COMP%]{position:absolute;top:42px;bottom:-16px;left:50%;transform:translate(-50%);width:1px;background-color:#e5e7eb}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-header[_ngcontent-%COMP%]   .activity-title[_ngcontent-%COMP%]{font-size:12px;font-weight:400;color:var(--text-color)}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-header[_ngcontent-%COMP%]   .activity-user[_ngcontent-%COMP%]{font-size:11px}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-header[_ngcontent-%COMP%]   .activity-timestamp[_ngcontent-%COMP%]{font-size:11px}[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-body[_ngcontent-%COMP%]{font-size:12px;color:var(--text-muted-color)}[_nghost-%COMP%]   .activity-icon-blue[_ngcontent-%COMP%]{background-color:#3b82f6}[_nghost-%COMP%]   .activity-icon-purple[_ngcontent-%COMP%]{background-color:#9333ea}[_nghost-%COMP%]   .activity-icon-orange[_ngcontent-%COMP%]{background-color:#f97316}[_nghost-%COMP%]   .activity-icon-green[_ngcontent-%COMP%]{background-color:#22c55e}[_nghost-%COMP%]   .activity-icon-red[_ngcontent-%COMP%]{background-color:#ef4444}[_nghost-%COMP%]   .activity-icon-indigo[_ngcontent-%COMP%]{background-color:#6366f1}[_nghost-%COMP%]   .activity-icon-emerald[_ngcontent-%COMP%]{background-color:#10b981}[_nghost-%COMP%]   .activity-icon-cyan[_ngcontent-%COMP%]{background-color:#06b6d4}[_nghost-%COMP%]   .activity-icon-gray[_ngcontent-%COMP%]{background-color:#6b7280}.dark-theme[_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-icon-wrapper[_ngcontent-%COMP%]   .timeline-connector[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .activity-card-wrapper[_ngcontent-%COMP%]   .activity-icon-wrapper[_ngcontent-%COMP%]   .timeline-connector[_ngcontent-%COMP%]{background-color:#374151}"]
            })
        }
    }
    return t
})();

function mr(t, s) {
    if (t & 1) {
        let e = I();
        c(0, "dx-button", 2), h("onClick", function() {
            y(e);
            let n = l();
            return S(n.filterBy("Assignee", [n.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_ASSIGNEE_UPDATED, n.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED]))
        }), a()
    }
    if (t & 2) {
        let e = l();
        r("text", e.formatMessage("common_assignee"))("type", e.selectedFilter === "Assignee" ? "default" : "normal")("stylingMode", e.selectedFilter === "Assignee" ? "contained" : "outlined")
    }
}

function pr(t, s) {
    if (t & 1 && (c(0, "div"), m(1, "app-amc-activity-list", 11), a()), t & 2) {
        let e = s.$implicit,
            o = s.$index,
            n = s.$count;
        i(), r("activity", e)("isLast", o === n - 1)
    }
}
var Rn = (() => {
    class t {
        constructor() {
            this.formatMessage = d, this.ENTITIES = M, this.userSessionService = C(b), this.isMobileDevice = C(O).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ACTIVITY_EVENT_TYPES = D, this.AMC_ACTIVITY_EVENT_TYPES = T, this.newOldFilter = !0, this.filterButtonName = d("newest_first"), this.selectedFilter = "All", this.filterManu = [{
                text: d("all"),
                events: [],
                visible: !0
            }, {
                text: d("devices"),
                events: [T.DEVICE_INFORMATION_CREATED, T.DEVICE_INFORMATION_UPDATED],
                visible: !0
            }, {
                text: d("software"),
                events: [T.SOFTWARE_CREATED, T.SOFTWARE_UPDATED],
                visible: this.userPermissionList.includes(x.CUSTOMER_VIEW_PAYMENT_INFORMATION)
            }, {
                text: d("payment"),
                events: [D.PAYMENT_CREATED, D.PAYMENT_UPDATED, D.PAYMENT_DELETED],
                visible: !0
            }, {
                text: d("services"),
                events: [T.AMC_SERVICE_CREATED, T.AMC_SERVICE_UPDATED],
                visible: !0
            }, {
                text: d("complaints"),
                events: [T.AMC_COMPLAINT_CREATED, T.AMC_COMPLAINT_UPDATED],
                visible: !0
            }, {
                text: d("common_assignee"),
                events: [T.AMC_CONTRACT_ASSIGNEE_UPDATED, T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED],
                visible: this.isEmployee
            }, {
                text: d("common_status"),
                events: [T.AMC_CONTRACT_STATUS_UPDATED, T.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED],
                visible: !0
            }], this.deskTopViewFilterMenu = this.filterManu.filter(e => ["Devices", "Software", "Complaints"].includes(e.text))
        }
        ngOnInit() {
            this.filterActivities = this.activities
        }
        ngOnChanges(e) {
            e.activities.previousValue !== e.activities.currentValue && (this.filterActivities = e.activities.currentValue)
        }
        onAll() {
            return this.selectedFilter = "All", this.filterActivities = this.activities, this.filterActivities
        }
        filterBy(e, o) {
            this.selectedFilter = e, this.filterActivities = this.activities.filter(n => o.includes(n.event))
        }
        onSort() {
            return this.newOldFilter = !this.newOldFilter, this.newOldFilter === !0 ? (this.filterButtonName = d("newest_first"), this.filterActivities.reverse()) : (this.filterActivities.reverse(), this.filterButtonName = d("oldest_first"), this.filterActivities)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-activity-filters-and-all-activities"]
                ],
                inputs: {
                    activities: "activities"
                },
                features: [Zt],
                decls: 16,
                vars: 22,
                consts: [
                    [1, "activity-filters", "mb-4"],
                    [1, "d-none", "d-md-flex", "align-items-center", "gap-2", "flex-wrap"],
                    [3, "onClick", "text", "type", "stylingMode"],
                    [3, "text", "type", "stylingMode"],
                    ["stylingMode", "outlined", "type", "normal", "displayExpr", "text", 3, "onItemClick", "text", "items", "splitButton"],
                    ["stylingMode", "outlined", "type", "normal", 1, "ms-auto", 3, "onClick", "icon", "text"],
                    [1, "d-flex", "d-md-none", "gap-2"],
                    ["stylingMode", "outlined", "type", "normal", "displayExpr", "text", 1, "flex-grow-1", 3, "onItemClick", "text", "items", "splitButton"],
                    ["stylingMode", "outlined", "type", "normal", 3, "onClick", "icon"],
                    [1, "my-3"],
                    [1, "activity-timeline"],
                    [3, "activity", "isLast"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "div", 1)(2, "dx-button", 2), h("onClick", function() {
                        return n.onAll()
                    }), a(), c(3, "dx-button", 2), h("onClick", function() {
                        return n.filterBy("Payments", [n.ACTIVITY_EVENT_TYPES.PAYMENT_CREATED])
                    }), a(), c(4, "dx-button", 2), h("onClick", function() {
                        return n.filterBy("Services", [n.AMC_ACTIVITY_EVENT_TYPES.AMC_SERVICE_CREATED, n.AMC_ACTIVITY_EVENT_TYPES.AMC_SERVICE_UPDATED])
                    }), a(), _(5, mr, 1, 3, "dx-button", 3), c(6, "dx-button", 2), h("onClick", function() {
                        return n.filterBy("Status", [n.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_STATUS_UPDATED, n.AMC_ACTIVITY_EVENT_TYPES.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED])
                    }), a(), c(7, "dx-drop-down-button", 4), h("onItemClick", function(E) {
                        return n.filterBy(E.itemData.text, E.itemData.events)
                    }), a(), c(8, "dx-button", 5), h("onClick", function() {
                        return n.onSort()
                    }), a()(), c(9, "div", 6)(10, "dx-drop-down-button", 7), h("onItemClick", function(E) {
                        return E.itemData.text === "All" ? n.onAll() : n.filterBy(E.itemData.text, E.itemData.events)
                    }), a(), c(11, "dx-button", 8), h("onClick", function() {
                        return n.onSort()
                    }), a()()(), m(12, "hr", 9), c(13, "div", 10), Ye(14, pr, 2, 2, "div", null, Ue), a()), o & 2 && (i(2), r("text", n.formatMessage("ALL"))("type", n.selectedFilter === "All" ? "default" : "normal")("stylingMode", n.selectedFilter === "All" ? "contained" : "outlined"), i(), r("text", n.formatMessage("payment"))("type", n.selectedFilter === "Payments" ? "default" : "normal")("stylingMode", n.selectedFilter === "Payments" ? "contained" : "outlined"), i(), r("text", n.formatMessage("filter_services"))("type", n.selectedFilter === "Services" ? "default" : "normal")("stylingMode", n.selectedFilter === "Services" ? "contained" : "outlined"), i(), u(n.isEmployee ? 5 : -1), i(), r("text", n.formatMessage("common_status"))("type", n.selectedFilter === "Status" ? "default" : "normal")("stylingMode", n.selectedFilter === "Status" ? "contained" : "outlined"), i(), r("text", n.formatMessage("MORE_FILTERS"))("items", n.deskTopViewFilterMenu)("splitButton", !1), i(), r("icon", n.newOldFilter ? "fa-thin fa-arrow-down-1-9" : "fa-thin fa-arrow-up-9-1")("text", n.newOldFilter ? n.formatMessage("NEWEST_FIRST") : n.formatMessage("OLDEST_FIRST")), i(2), r("text", n.formatMessage("ALL_FILTERS"))("items", n.filterManu)("splitButton", !1), i(), r("icon", n.newOldFilter ? "fa-thin fa-arrow-down-1-9" : "fa-thin fa-arrow-up-9-1"), i(3), Be(n.filterActivities))
                },
                dependencies: [Vn, Pi, Ii, G, Yi],
                styles: ["ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{margin:2px 4px;list-style:none}.activity-log-list[_ngcontent-%COMP%]{overflow-x:hidden;max-height:calc(100vh + -0rem)!important}.activity-filters[_ngcontent-%COMP%]     .dx-button{height:28px!important;min-height:28px!important;max-height:28px!important}.activity-filters[_ngcontent-%COMP%]     .dx-button .dx-button-content{padding:2px 12px!important;line-height:1.5}.activity-filters[_ngcontent-%COMP%]     .dx-dropdownbutton{height:28px!important;min-height:28px!important;max-height:28px!important}.activity-filters[_ngcontent-%COMP%]     .dx-dropdownbutton .dx-button{height:28px!important;min-height:28px!important}.activity-filters[_ngcontent-%COMP%]     .dx-dropdownbutton .dx-button-content{padding:2px 12px!important;line-height:1.5}"]
            })
        }
    }
    return t
})();

function dr(t, s) {
    if (t & 1 && m(0, "app-amc-activity-filters-and-all-activities", 5), t & 2) {
        let e = l();
        r("activities", e.activities)
    }
}
var Nt = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = d, this.activities = [], this.amcContractId = null, this.activatedRouter = C(N), this.isMobileDevice = C(O).isMobileDevice(), this.ENTITIES = M
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = null, this.amcContractId = +e.amc_contract_id, this.service.getAmcActivityWithParams({
                        amc_contract_id: this.amcContractId,
                        amc_contract_type: this.ENTITIES.AMC_CONTRACT.name
                    }).subscribe({
                        next: o => {
                            this.activities = o
                        },
                        error: o => {
                            console.error(o)
                        }
                    })
                },
                error: e => {
                    console.error("error getting AMC activity ", e)
                }
            })
        }
        ngOnDestroy() {
            this.routeParamsSub && this.routeParamsSub.unsubscribe()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(pn))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-activity"]
                ],
                decls: 8,
                vars: 3,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "amc-activities"],
                    [1, "row", "mb-4", 3, "ngClass"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "title-text", "mb-4"],
                    [3, "activities"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "span"), p(6), a()(), _(7, dr, 1, 1, "app-amc-activity-filters-and-all-activities", 5), a()()()()), o & 2 && (i(3), r("ngClass", n.isMobileDevice ? "" : "ps-3"), i(3), P(n.formatMessage("activity_log")), i(), u(n.activities != null && n.activities.length ? 7 : -1))
                },
                dependencies: [ne, Rn],
                encapsulation: 2
            })
        }
    }
    return t
})();

function ur(t, s) {
    if (t & 1 && m(0, "app-user-badge", 11), t & 2) {
        let e = l(2);
        r("iconOnly", !1)("user", e.amcContract == null ? null : e.amcContract.user)
    }
}

function Cr(t, s) {
    if (t & 1 && m(0, "app-user-badge", 11), t & 2) {
        let e = l(3);
        r("iconOnly", !1)("user", e.amcContract.assigned_user)
    }
}

function vr(t, s) {
    if (t & 1 && (c(0, "div", 9)(1, "p")(2, "strong", 20), p(3), a()(), _(4, Cr, 1, 2, "app-user-badge", 11), a()), t & 2) {
        let e = l(2);
        i(3), f("", e.formatMessage("current_assignee"), ":"), i(), u(e.amcContract.assigned_user ? 4 : -1)
    }
}

function fr(t, s) {
    if (t & 1 && (c(0, "p")(1, "strong"), p(2), a(), p(3), a()), t & 2) {
        let e = l(2);
        i(2), f(" ", e.formatMessage("number_of_devices_covered"), " :"), i(), P(e.amcContract == null ? null : e.amcContract.number_of_devices_covered)
    }
}

function Tr(t, s) {
    if (t & 1 && (c(0, "p")(1, "strong"), p(2), a(), p(3), a()), t & 2) {
        let e = l(2);
        i(2), f("", e.formatMessage("number_of_services"), " :"), i(), P(e.amcContract == null ? null : e.amcContract.number_of_services)
    }
}

function hr(t, s) {
    if (t & 1 && (c(0, "p")(1, "strong"), p(2), a(), p(3), a()), t & 2) {
        let e = l(2);
        i(2), f("", e.formatMessage("response_time"), " :"), i(), P(e.amcContract == null ? null : e.amcContract.response_time)
    }
}

function yr(t, s) {
    if (t & 1 && (c(0, "p")(1, "strong"), p(2), a(), p(3), a()), t & 2) {
        let e = l(2);
        i(2), f("", e.formatMessage("service_options"), " : "), i(), P(e.amcContract == null ? null : e.amcContract.service_options)
    }
}

function Sr(t, s) {
    if (t & 1 && (c(0, "p")(1, "strong"), p(2), a(), p(3), a()), t & 2) {
        let e = l(2);
        i(2), f("", e.formatMessage("contract_auto_renew"), " : "), i(), P(e.amcContract != null && e.amcContract.is_contract_auto_renew ? "Yes" : "No")
    }
}

function Ar(t, s) {
    if (t & 1 && (c(0, "span"), m(1, "app-image-gallery-popup", 21), a()), t & 2) {
        let e = s.$implicit;
        i(), r("attachment", e)("isOnTableListing", !1)
    }
}

function gr(t, s) {
    if (t & 1 && (c(0, "ul", 19)(1, "li")(2, "span", 22), p(3), a(), c(4, "span"), m(5, "app-currency-symbol"), p(6), a(), c(7, "a", 16), p(8), a()()()), t & 2) {
        let e = s.$implicit,
            o = l(2);
        i(3), P(e.payment_type == null ? null : e.payment_type.name), i(3), f(" ", e.amount, " "), i(), r("routerLink", ii("/amcs/", o.amcContract.id, "/paymentReceipts/", e.id, "/")), i(), f(" ", o.formatMessage("view_receipt"))
    }
}

function xr(t, s) {
    if (t & 1 && (c(0, "div", 2)(1, "div", 4)(2, "div", 5)(3, "span"), p(4), a()()(), c(5, "div", 4)(6, "div", 6), m(7, "app-section-title", 7), c(8, "p")(9, "strong"), p(10), a(), m(11, "app-amc-contract-status-tag", 8), a(), c(12, "div", 9)(13, "p")(14, "strong", 10), p(15), a()(), _(16, ur, 1, 2, "app-user-badge", 11), a(), _(17, vr, 5, 2, "div", 9), a()(), c(18, "div", 4)(19, "div", 6), m(20, "app-section-title", 12), c(21, "div", 1)(22, "div", 13), _(23, fr, 4, 2, "p"), _(24, Tr, 4, 2, "p"), _(25, hr, 4, 2, "p"), a(), c(26, "div", 13), _(27, yr, 4, 2, "p"), _(28, Sr, 4, 2, "p"), a()()(), c(29, "p")(30, "strong"), p(31), a()(), c(32, "div", 14), Ye(33, Ar, 2, 2, "span", null, Ue), a()(), c(35, "div", 4)(36, "div", 6), m(37, "app-section-title", 12), c(38, "p")(39, "strong"), p(40), a(), m(41, "app-currency-symbol"), p(42), a(), c(43, "p")(44, "strong"), p(45), a(), p(46), k(47, "date"), a(), c(48, "p")(49, "strong"), p(50), a(), p(51), k(52, "date"), a()()(), c(53, "div", 4)(54, "div", 6), m(55, "app-section-title", 12), c(56, "div", 1)(57, "div", 13)(58, "div")(59, "p"), m(60, "i", 15), c(61, "strong"), p(62), a(), c(63, "a", 16), p(64), a()()()(), c(65, "div", 13)(66, "div")(67, "p", 17), m(68, "i", 18), c(69, "strong"), p(70), a()(), Ye(71, gr, 9, 6, "ul", 19, Ue), a()()()()()()), t & 2) {
        let e = l();
        i(4), P(e.formatMessage("contract_overview")), i(3), r("title", "basic_information"), i(3), ti("", e.formatMessage("contract_number"), " : ", e.amcContract == null ? null : e.amcContract.contract_number, " "), i(), r("iconType", e.statusIconTypeList.EXTRA_SMALL)("status", e.amcContract == null ? null : e.amcContract.status), i(4), f("", e.formatMessage("customer_detail"), ":"), i(), u(e.amcContract != null && e.amcContract.user ? 16 : -1), i(), u(e.isEmployee ? 17 : -1), i(3), r("title", "coverage_details"), i(3), u(e.amcContract.number_of_devices_covered ? 23 : -1), i(), u(e.amcContract.number_of_services ? 24 : -1), i(), u(e.amcContract.response_time ? 25 : -1), i(2), u(e.amcContract.service_options ? 27 : -1), i(), u(e.amcContract.is_contract_auto_renew ? 28 : -1), i(3), f("", e.formatMessage("contract_images"), " : "), i(2), Be(e.amcContract.attachments), i(4), r("title", "additional_information"), i(3), f("", e.formatMessage("contract_amount"), ": "), i(2), f(" ", e.amcContract == null ? null : e.amcContract.total_amount, " "), i(3), f("", e.formatMessage("contract_start"), ": "), i(), P(wt(47, 29, e.amcContract.start_date)), i(4), f("", e.formatMessage("contract_start"), ": "), i(), P(wt(52, 31, e.amcContract.end_date)), i(4), r("title", "documents"), i(7), f("", e.formatMessage("contract_receipt"), ": "), i(), r("routerLink", je("/amcs/", e.amcContract == null ? null : e.amcContract.id, "/amcContract")), i(), P(e.formatMessage("view_amc_contract")), i(6), f("", e.formatMessage("payment"), ": "), i(), Be(e.amcContract.paymentable)
    }
}
var Ln = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = d, this.userSessionService = C(b), this.isEmployee = this.userSessionService.isEmployee(), this.activatedRouter = C(N), this.statusIconTypeList = z
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.amcContractId = null, this.amcContractId = +e.amc_contract_id, this.service.currentContract$.subscribe({
                        next: o => {
                            this.amcContract = o
                        },
                        error: o => {
                            console.error(o)
                        }
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(F))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-contract-overview"]
                ],
                standalone: !1,
                decls: 5,
                vars: 1,
                consts: [
                    [1, "m-2", "amc-contract-overview"],
                    [1, "row"],
                    [1, "col-sm-5", "col-md-5", "col-lg-5", "overview-divider"],
                    [1, "col-sm-7", "col-md-7", "col-lg-7"],
                    [1, "row", "mb-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "title-text"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["id", "job-overview-title", 1, "mt-3", 3, "title"],
                    [3, "iconType", "status"],
                    [1, "d-flex"],
                    [1, "me-3"],
                    [1, "ms-2", "fw-bold", 3, "iconOnly", "user"],
                    [1, "mt-3", 3, "title"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "d-flex", "align-items-center", "justify-content-evenly", "flex-wrap"],
                    [1, "fa-thin", "fa-file-alt", "me-3"],
                    [3, "routerLink"],
                    [1, "mb-1"],
                    [1, "fa-thin", "fa-money-check-alt", "me-3"],
                    [1, "ms-3", "mb-0"],
                    [1, "me-2"],
                    [3, "attachment", "isOnTableListing"],
                    [1, "me-1"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div", 0)(1, "div", 1), _(2, xr, 73, 33, "div", 2), c(3, "div", 3), m(4, "app-amc-activity"), a()()()), o & 2 && (i(2), u(n.amcContract ? 2 : -1))
                },
                dependencies: [pi, Di, vt, Wi, Oe, De, Nt, ci],
                styles: [".amc-contract-overview[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{margin-right:2px}.amc-contract-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]{border-right:1px solid #ecf0f1}.dark-theme[_nghost-%COMP%]   .amc-contract-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .amc-contract-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]{border-right:1px solid #334155}"]
            })
        }
    }
    return t
})();

function Er(t, s) {
    if (t & 1 && m(0, "app-send-whats-app-btn", 5), t & 2) {
        let e = l();
        r("entityId", e.amcService == null ? null : e.amcService.id)("entityName", e.ENTITIES.AMC_SERVICE.name)
    }
}

function Mr(t, s) {
    if (t & 1 && (c(0, "div", 16)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), p(5), a()), t & 2) {
        let e = l(2);
        i(2), P(e.formatMessage("service_done_by")), i(3), f("", (e.amcService.assigned_user == null ? null : e.amcService.assigned_user.display_name) ? ? (e.amcService.assigned_user == null ? null : e.amcService.assigned_user.name), " ")
    }
}

function br(t, s) {
    if (t & 1 && (c(0, "div", 16)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), p(5), a()), t & 2) {
        let e = l(2);
        i(2), P(e.formatMessage("service_type")), i(3), f("", e.amcService.service_type, " ")
    }
}

function Ir(t, s) {
    if (t & 1 && (c(0, "div", 16)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), m(5, "app-status-tag", 20), a()), t & 2) {
        let e = l(2);
        i(2), f("", e.formatMessage("common_status"), " "), i(3), r("status", e.amcService == null ? null : e.amcService.status)
    }
}

function Pr(t, s) {
    if (t & 1 && (c(0, "div", 16)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), p(5), a()), t & 2) {
        let e = l(2);
        i(2), P(e.formatMessage("service_charge")), i(3), f("", e.amcService.service_charge, " ")
    }
}

function Nr(t, s) {
    if (t & 1 && (c(0, "div", 16)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), p(5), a()), t & 2) {
        let e = l(2);
        i(2), P(e.formatMessage("service_expenditure")), i(3), f("", e.amcService.service_expenditure, " ")
    }
}

function wr(t, s) {
    if (t & 1 && (c(0, "div", 16)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), p(5), a()), t & 2) {
        let e = l(2);
        i(2), P(e.formatMessage("travel_expenditure")), i(3), f("", e.amcService.travel_expenditure, " ")
    }
}

function Or(t, s) {
    if (t & 1 && (c(0, "div", 17)(1, "span", 18), p(2), a(), c(3, "span", 19), p(4, ":"), a(), m(5, "span", 21), k(6, "safe"), a()), t & 2) {
        let e = l(2);
        i(2), P(e.formatMessage("common_comment")), i(3), r("innerHTML", j(6, 2, e.amcService.service_remark, "html"), $e)
    }
}

function Dr(t, s) {
    if (t & 1 && (c(0, "div", 9)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2), m(5, "app-invoice-header", 10)(6, "app-invoice-title", 11)(7, "app-invoice-customer-detail", 12)(8, "app-invoice-amc-contract-details", 13), c(9, "div", 14)(10, "div", 2)(11, "h5", 15), p(12), a(), c(13, "div", 1), _(14, Mr, 6, 2, "div", 16), _(15, br, 6, 2, "div", 16), _(16, Ir, 6, 2, "div", 16), _(17, Pr, 6, 2, "div", 16), _(18, Nr, 6, 2, "div", 16), _(19, wr, 6, 2, "div", 16), _(20, Or, 7, 5, "div", 17), a()()()()()()()()), t & 2) {
        let e = l();
        r("ngClass", e.isMobileDevice ? "p-0" : ""), i(5), r("account", e.account)("qrCode", (e.amcService == null ? null : e.amcService.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.amcService == null ? null : e.amcService.qr_code)), i(), r("dateTime", e.amcService == null || e.amcService.amc_contract == null ? null : e.amcService.amc_contract.created_at)("title", e.formatMessage("service_receipt")), i(), r("userId", e.amcService == null || e.amcService.amc_contract == null ? null : e.amcService.amc_contract.user_id), i(), r("amcContract", e.amcService == null ? null : e.amcService.amc_contract), i(4), P(e.formatMessage("amc_service_detail")), i(2), u(e.amcService != null && e.amcService.assigned_user ? 14 : -1), i(), u(e.amcService != null && e.amcService.service_type ? 15 : -1), i(), u(e.amcService != null && e.amcService.status ? 16 : -1), i(), u(e.amcService != null && e.amcService.service_charge ? 17 : -1), i(), u(e.amcService != null && e.amcService.service_expenditure ? 18 : -1), i(), u(e.amcService != null && e.amcService.travel_expenditure ? 19 : -1), i(), u(e.amcService != null && e.amcService.service_remark ? 20 : -1)
    }
}
var Fn = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.loaderService = o, this.formatMessage = d, this.ENTITIES = M, this.userSessionService = C(b), this.generalSettingDataService = C(rt), this.activatedRouter = C(N), this.isMobileDevice = C(O).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.dateTime = new Date, this.printOptions = null, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(He.PRINT_SETTINGS) ? ? at.getEmptyObject()
        }
        ngOnInit() {
            let e = +this.activatedRouter.snapshot.paramMap.get("amc_service_id");
            this.loaderService.show(), this.service.getById(e).subscribe({
                next: o => {
                    this.amcService = o
                },
                error: o => {
                    console.error(o)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(g(Re), g(X))
            }
        }
        static {
            this.\u0275cmp = A({
                type: t,
                selectors: [
                    ["app-amc-service-receipt"]
                ],
                standalone: !1,
                decls: 12,
                vars: 11,
                consts: [
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "title-text", "float-start", "m-1"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [1, "mx-1", 3, "amcContractId"],
                    [3, "entityId", "entityName", "isVisiblePrintButton", "isVisibleThermalPrint"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "amcContract"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "ps-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [3, "status"],
                    [1, "d-inline-block", 3, "innerHTML"]
                ],
                template: function(o, n) {
                    o & 1 && (c(0, "div")(1, "div", 0)(2, "div", 1)(3, "div", 2)(4, "span", 3), p(5), a(), c(6, "div", 4), _(7, Er, 1, 2, "app-send-whats-app-btn", 5), m(8, "app-amc-contract-btn", 6)(9, "app-print-button", 7)(10, "app-share-btn", 8), a()()()(), _(11, Dr, 21, 15, "div", 9), a()), o & 2 && (i(), r("ngClass", n.isMobileDevice ? "p-0" : ""), i(4), f(" ", n.amcService == null || n.amcService.amc_contract == null ? null : n.amcService.amc_contract.contract_number, " "), i(2), u(n.amcService && n.isEmployee ? 7 : -1), i(), r("amcContractId", n.amcService == null || n.amcService.amc_contract == null ? null : n.amcService.amc_contract.id), i(), r("entityId", n.amcService == null ? null : n.amcService.id)("entityName", n.ENTITIES.AMC_SERVICE.name)("isVisiblePrintButton", !!(n.amcService != null && n.amcService.id))("isVisibleThermalPrint", !1), i(), r("entityId", n.amcService == null ? null : n.amcService.id)("entityType", n.ENTITIES.AMC_SERVICE.name), i(), u(n.amcService ? 11 : -1))
                },
                dependencies: [ne, ct, lt, mt, it, Ce, pt, gt, xt, _t, st],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var Vr = [{
        path: "",
        component: un,
        children: [{
            path: "list",
            component: Nn,
            data: {
                tab_index: 0
            },
            title: "BytePhase | AMC Contract List"
        }, {
            path: "amcServices",
            component: Qt,
            data: {
                tab_index: 1
            },
            pathMatch: "full",
            title: "BytePhase Service | Amc Services"
        }, {
            path: "amcComplaints",
            component: Xt,
            data: {
                tab_index: 2
            },
            title: "BytePhase Service | Complaints List"
        }, {
            path: "amcOverview",
            component: qi,
            data: {
                tab_index: 3
            },
            title: "BytePhase Service | Overview List"
        }, {
            path: "add",
            component: Wt,
            canActivate: [Ot, bi],
            data: {
                user_id: null,
                isCreate: !0,
                permissions: {
                    only: [x.AMC_CONTRACT_WRITE]
                }
            },
            pathMatch: "full",
            title: "BytePhase | AMC Basic Info List"
        }, {
            path: ":amc_contract_id",
            component: Wt,
            data: {
                user_id: null,
                tab_index: 0
            },
            children: [{
                path: "overview",
                component: Ln,
                data: {
                    tab_index: 0
                },
                pathMatch: "full",
                title: "BytePhase Service | Overview"
            }, {
                path: "details",
                component: bt,
                data: {
                    tab_index: 1
                },
                title: "BytePhase Service | Details"
            }, {
                path: "device",
                component: _n,
                children: [{
                    path: "list",
                    component: ln,
                    title: "BytePhase Software And DeviceInformation | Details"
                }, {
                    path: "add",
                    component: Ft,
                    title: "BytePhase DeviceInformation | Details"
                }, {
                    path: ":device_id/details",
                    component: Ft,
                    title: "BytePhase DeviceInformation | Details"
                }, {
                    path: "",
                    redirectTo: "list",
                    pathMatch: "full"
                }],
                data: {
                    tab_index: 2
                },
                title: "BytePhase Software And DeviceInformation | Details"
            }, {
                path: "amcServices",
                component: Qt,
                data: {
                    tab_index: 3
                },
                title: "BytePhase Service | Amc Services List"
            }, {
                path: "amcComplaints",
                component: Xt,
                data: {
                    tab_index: 4
                },
                title: "BytePhase Service | Complaints List"
            }, {
                path: "amcPayments",
                component: Mn,
                data: {
                    tab_index: 5,
                    paymentable_type: M.AMC_CONTRACT.name
                },
                title: "BytePhase Service | AMC Payment List"
            }, {
                path: "notes",
                component: Ji,
                data: {
                    tab_index: 6,
                    notable_type: M.AMC_CONTRACT.name
                },
                title: "BytePhase Service | Private Notes"
            }]
        }, {
            path: ":amc_contract_id/amcContract",
            component: vn,
            canActivate: [Ot],
            data: {
                permissions: {
                    only: [x.AMC_CONTRACT_WRITE, x.AMC_CONTRACT_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Service | Amc Contract"
        }, {
            path: ":amc_contract_id/paymentReceipts/:payment_id",
            component: en,
            data: {
                permissions: {
                    only: [x.PAYMENT_DELETE, x.PAYMENT_WRITE]
                }
            },
            pathMatch: "full",
            title: "BytePhase Service | AMC Payment Receipt"
        }, {
            path: ":amc_contract_id/amcServiceReceipt/:amc_service_id",
            component: Fn,
            data: {
                permissions: {
                    only: [x.AMC_SERVICE_WRITE, x.AMC_SERVICE_DELETE]
                }
            },
            pathMatch: "full",
            title: "BytePhase Service | AMC Services Receipt"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    kn = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = Ze({
                    type: t
                })
            }
            static {
                this.\u0275inj = Xe({
                    imports: [qe.forChild(Vr), qe]
                })
            }
        }
        return t
    })();
var zp = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = Ze({
                type: t
            })
        }
        static {
            this.\u0275inj = Xe({
                imports: [si, kn, G, Nt]
            })
        }
    }
    return t
})();
export {
    zp as AmcModule
};