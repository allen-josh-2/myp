import {
    a as be
} from "./chunk-2B6TWJ62.js";
import {
    a as Qt
} from "./chunk-ZJPVWREV.js";
import {
    b as Kt
} from "./chunk-2E5FSGQH.js";
import {
    a as zt,
    b as Xt
} from "./chunk-FJFEFX5C.js";
import {
    a as st
} from "./chunk-HDTUMYRX.js";
import {
    c as qt,
    g as Jt
} from "./chunk-WDS5LHZR.js";
import "./chunk-36T2HUF3.js";
import "./chunk-OG4EABPU.js";
import {
    a as lt
} from "./chunk-HUDETQT5.js";
import "./chunk-PGAHHPJ5.js";
import "./chunk-MBAKXBI4.js";
import "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import "./chunk-FAP35UT3.js";
import "./chunk-2KS5UOZO.js";
import "./chunk-KJCCJCIN.js";
import {
    Ag as $t,
    De as kt,
    Hb as Ct,
    Kc as Et,
    Kf as jt,
    L as Ze,
    M as xe,
    O as et,
    Rd as It,
    Re as Lt,
    T as Y,
    Ta as fe,
    Td as Dt,
    Ug as Gt,
    Va as he,
    Wc as Tt,
    Xc as bt,
    Zd as Rt,
    Ze as Ft,
    _d as Z,
    aa as mt,
    ba as $,
    bf as Vt,
    ca as F,
    cb as Ce,
    cd as St,
    db as ct,
    e as ne,
    g as _e,
    h as $e,
    ha as pt,
    ic as gt,
    ih as Ht,
    j as Ge,
    ka as Q,
    l as ve,
    lb as X,
    lf as Ut,
    m as He,
    mf as Bt,
    n as We,
    nc as vt,
    p as qe,
    pb as dt,
    ph as Wt,
    q as Je,
    qb as _t,
    qc as yt,
    rd as Mt,
    re as Te,
    rg as Yt,
    sb as ut,
    t as Ke,
    tb as ft,
    te as wt,
    u as Qe,
    ub as ht,
    ue as Nt,
    vd as Pt,
    we as Ot,
    y as ze,
    yc as xt,
    ze as At
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    $b as B,
    Ab as Oe,
    Ak as z,
    Bh as ot,
    Ci as L,
    Db as P,
    Ec as de,
    Fa as r,
    Fc as Ue,
    Fh as O,
    Ib as C,
    Ih as A,
    Jb as v,
    Ka as I,
    Kb as Ae,
    Lc as Be,
    Na as b,
    Oa as pe,
    Pb as ke,
    Pg as T,
    Qb as Le,
    Rb as Fe,
    Sa as g,
    Tc as je,
    V as le,
    Yb as Ve,
    _a as _,
    _b as ie,
    _h as nt,
    aa as De,
    ac as oe,
    ba as me,
    c as Pe,
    cb as G,
    ch as tt,
    da as Re,
    db as H,
    ea as c,
    eb as a,
    ei as ue,
    fb as l,
    fd as Ye,
    gb as s,
    ha as x,
    hb as d,
    hi as R,
    ia as E,
    kc as j,
    mc as ce,
    nb as S,
    pd as D,
    qa as q,
    qb as M,
    qd as Xe,
    qh as it,
    sb as h,
    sd as J,
    ti as rt,
    ub as m,
    ui as at,
    vd as ye,
    wh as K,
    wi as k,
    xk as p,
    yb as we,
    z as Ie,
    zb as Ne,
    ze as Ee,
    zi as re
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as w,
    b as N,
    i as ge
} from "./chunk-FBFWB55K.js";

function ui(t, n) {
    if (t & 1 && d(0, "app-activity-list", 5), t & 2) {
        let e = m();
        a("activities", e.activities)
    }
}
var Zt = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = p, this.activatedRouter = c(D), this.activities = [], this.employeeId = null
        }
        ngOnInit() {
            this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.service.activities(this.employeeId).subscribe({
                next: e => {
                    this.activities = e
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(I(k))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-employee-activities"]
                ],
                standalone: !1,
                decls: 8,
                vars: 2,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "job-activities"],
                    [1, "row", "mb-4", "ps-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "title-text"],
                    [3, "activities"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "span"), C(6), s()(), _(7, ui, 1, 1, "app-activity-list", 5), s()()()()), i & 2 && (r(6), v(o.formatMessage("activity_log")), r(), u(o.activities.length ? 7 : -1))
                },
                dependencies: [jt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var W = class t {
    constructor(n) {
        return Object.assign(this, n)
    }
    static getForm(n) {
        return new Ge({
            name: new ve(n.name || null),
            ip_address: new ve(n.ip_address || null)
        })
    }
    static getFormArray(n) {
        let e = new qe([]);
        return n && n.length && n.forEach(i => {
            e.push(t.getForm(i))
        }), e
    }
};
var U = class {
    constructor(n) {
        return this.firebase_tokens = [], this.is_push_token_missing = !1, Object.assign(this, n)
    }
    static getForm(n) {
        return new ze().group({
            id: [n.id || null],
            role_id: [n.roles && n.roles.length ? n.roles[0].id : null, ne.required],
            name: [n.name || null, [ne.required]],
            display_name: [n.display_name || null],
            email: [n.email || null, ne.required],
            date_of_birth: [n.date_of_birth || null],
            tax_number: [n.tax_number || null],
            custom_fields: ht.getFormArray(n.custom_fields),
            unique_identification_number: [n.unique_identification_number || null],
            mobile_number: [n.mobile_number || null, [ne.required]],
            phone_number: [n.phone_number || null, [ft.phoneNumberValidator]],
            gender: [n.gender || null],
            address: Te.getForm(new Te(n.address)),
            bank: be.getForm(new be(n.bank), !1),
            ip_addresses: W.getFormArray(n.ip_addresses),
            mobile_country_code: [n.mobile_country_code || null]
        })
    }
};

function yi(t, n) {
    t & 1 && d(0, "app-skeleton-loader", 0), t & 2 && a("rows", 8)("columns", 3)
}

function xi(t, n) {
    if (t & 1 && (l(0, "h3", 5), C(1), s()), t & 2) {
        let e = m(2);
        r(), v(e.formatMessage("create_button"))
    }
}

function Ei(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-save-cancel-footer", 36), h("cancelClick", function() {
            x(e);
            let o = m(2);
            return E(o.cancel())
        }), s()
    }
    if (t & 2) {
        let e = m(2);
        a("isVisibleHr", !1)("saveText", e.employeeId ? "common_save" : "create_button")
    }
}

function Ti(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-dx-outline-button", 39), h("onClickEvent", function() {
            x(e);
            let o = m(4);
            return E(o.setEditMode())
        }), s()
    }
}

function bi(t, n) {
    if (t & 1 && g(0, Ti, 1, 0, "app-dx-outline-button", 38), t & 2) {
        let e = m(3);
        a("ngxPermissionsOnly", e.PERMISSION_LIST.EMPLOYEE_WRITE)
    }
}

function Si(t, n) {
    if (t & 1 && _(0, bi, 1, 1, "app-dx-outline-button", 37), t & 2) {
        let e = m(2);
        u(e.userPermissionList.includes(e.PERMISSION_LIST.EMPLOYEE_WRITE) ? 0 : -1)
    }
}

function Mi(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-server-error", 40), h("onConflictResolved", function(o) {
            x(e);
            let f = m(2);
            return E(f.onConflictResolved(o))
        }), s()
    }
    if (t & 2) {
        let e = m(2);
        a("errorResponse", e.errorResponse)("service", e.employeeService)("entityName", e.ENTITIES.EMPLOYEE.name)("entityDisplayName", e.formatMessage("common_employee"))
    }
}

function Pi(t, n) {
    if (t & 1 && (l(0, "app-control-container", 9), d(1, "app-user-type-dropdown", 41), s()), t & 2) {
        let e = m(2);
        a("errorMsg", e.formatMessage("employee_required_error"))("label", e.formatMessage("employee_role_label")), r(), a("formControl", e.form.controls.role_id)("isCustomerTypes", !1)("isEditMode", e.isEditMode)
    }
}

function Ii(t, n) {
    if (t & 1 && (l(0, "app-control-container", 14), d(1, "app-email", 42), s()), t & 2) {
        let e = m(2);
        a("errorMsg", e.formatMessage("email_required_error"))("label", e.formatMessage("common_email_id")), r(), a("entity", e.ENTITIES.EMPLOYEE)("formControl", e.form.controls.email)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("typeId", e.USER_TYPES.EMPLOYEE)
    }
}

function Di(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-dx-outline-button", 43), h("onClickEvent", function() {
            x(e);
            let o = m(2);
            return E(o.addIpAddress())
        }), s()
    }
    if (t & 2) {
        let e = m(2);
        a("disabled", !e.isEditMode)
    }
}

function Ri(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "div", 49)(1, "i", 50), h("click", function() {
            x(e);
            let o = m().index,
                f = m(3);
            return E(f.removeIpAddress(o))
        }), s()()
    }
}

function wi(t, n) {
    if (t & 1 && (l(0, "div", 34)(1, "app-control-container", 45), d(2, "dx-text-box", 46), s(), l(3, "app-control-container", 47), d(4, "dx-text-box", 48), s(), _(5, Ri, 2, 0, "div", 49), s()), t & 2) {
        let e = n.$implicit,
            i = m(3);
        a("formGroup", e), r(), a("errorMsg", i.formatMessage("ip_name_required_error"))("label", i.formatMessage("common_name")), r(), a("placeholder", i.formatMessage("ip_name_placeholder")), r(), a("errorMsg", i.formatMessage("ip_address_required_error"))("label", i.formatMessage("ip_address_label")), r(2), u(i.isEditMode ? 5 : -1)
    }
}

function Ni(t, n) {
    if (t & 1 && g(0, wi, 6, 7, "div", 44), t & 2) {
        let e = m(2);
        a("ngForOf", e.form.get("ip_addresses").controls)
    }
}

function Oi(t, n) {
    if (t & 1 && (l(0, "table", 35)(1, "thead")(2, "tr")(3, "th", 51), C(4), s(), l(5, "th", 51), C(6), s()()(), l(7, "tbody")(8, "tr")(9, "td", 52)(10, "h6", 53), C(11), s()()()()()), t & 2) {
        let e = m(2);
        r(4), v(e.formatMessage("common_name")), r(2), v(e.formatMessage("ip_address_label")), r(5), v(e.formatMessage("no_ip_address_added"))
    }
}

function Ai(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "form", 2), h("ngSubmit", function() {
            x(e);
            let o = m();
            return E(o.save())
        }), l(1, "div", 3)(2, "div", 4), _(3, xi, 2, 1, "h3", 5), _(4, Ei, 1, 2, "app-save-cancel-footer", 6)(5, Si, 1, 1), _(6, Mi, 1, 4, "app-server-error", 7), s()(), l(7, "h5"), C(8), s(), d(9, "hr"), l(10, "div", 8), _(11, Pi, 2, 5, "app-control-container", 9), l(12, "app-control-container", 10), d(13, "dx-text-box", 11), s(), l(14, "app-control-container", 12), d(15, "dx-text-box", 13), s(), _(16, Ii, 2, 7, "app-control-container", 14), l(17, "app-control-container", 15), d(18, "app-mobile-number", 16)(19, "app-error", 17), s(), l(20, "app-control-container", 18), d(21, "app-phone-number", 19)(22, "app-error", 17), s(), l(23, "app-control-container", 20), d(24, "dx-text-box", 21), s(), l(25, "app-control-container", 22), d(26, "dx-select-box", 23), s(), l(27, "app-control-container", 24), d(28, "dx-text-box", 25), s(), l(29, "app-control-container", 26), d(30, "dx-date-box", 27), s(), d(31, "app-show-custom-fields", 28), s(), l(32, "div", 29), d(33, "app-address", 30), s(), l(34, "div", 29), d(35, "app-bank", 31), s(), l(36, "div"), d(37, "app-section-title", 32), s(), l(38, "div", 29)(39, "div", 8)(40, "div", 4), g(41, Di, 1, 1, "app-dx-outline-button", 33), s()(), _(42, Ni, 1, 1, "div", 34)(43, Oi, 12, 3, "table", 35), s()()
    }
    if (t & 2) {
        let e = m();
        a("formGroup", e.form), r(3), u(e.employeeId ? -1 : 3), r(), u(e.isEditMode ? 4 : 5), r(2), u(e.errorResponse ? 6 : -1), r(2), v(e.formatMessage("employee_information")), r(3), u(e.form.getRawValue().id ? -1 : 11), r(), a("errorMsg", e.formatMessage("employee_name_required_error"))("label", e.formatMessage("employee_name_label")), r(), a("placeholder", e.formatMessage("employee_name_placeholder")), r(), a("errorMsg", e.formatMessage("display_name_required_error"))("label", e.formatMessage("display_name_label"))("tooltipText", "employee_display_name"), r(), a("placeholder", e.formatMessage("display_name_placeholder")), r(), u(e.form.getRawValue().id ? -1 : 16), r(), a("errorMsg", e.formatMessage("common_mobile_number_required"))("label", e.formatMessage("common_mobile_number")), r(), a("entity", e.ENTITIES.EMPLOYEE)("entityId", e.employeeId)("formControl", e.form.controls.mobile_number)("isEditMode", e.isEditMode)("form", e.form)("isUniqueValidation", !0)("typeId", e.USER_TYPES.EMPLOYEE), r(), a("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), r(), a("label", e.formatMessage("common_phone_number")), r(), a("formControl", e.form.controls.phone_number)("isEditMode", e.isEditMode), r(), a("displayError", e.form.get("phone_number").invalid && e.form.get("phone_number").touched && e.form.get("phone_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), r(), a("label", e.formatMessage("identification_number_label"))("tooltipText", e.formatMessage("identity_number_tooltip")), r(), a("placeholder", e.formatMessage("aadhaar_number_placeholder")), r(), a("errorMsg", e.formatMessage("gender_required_error"))("label", e.formatMessage("gender_label")), r(), a("items", e.genderList)("placeholder", e.formatMessage("gender_placeholder"))("searchEnabled", !0), r(), a("errorMsg", e.formatMessage("common_tax_number_required"))("label", e.isIndia ? e.formatMessage("pan_card_number") : e.formatMessage("tax_number")), r(2), a("errorMsg", e.formatMessage("dob_required_error"))("label", e.formatMessage("date_of_birth_label")), r(), a("max", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("select_date_of_birth_placeholder")), r(), a("formType", e.FORM_TYPE_LIST.EMPLOYEE)("form", e.form)("hasColumn", 4), r(2), a("parentForm", e.form), r(2), a("parentForm", e.form)("isBankOptional", !0), r(2), a("title", "ip_whitelist"), r(4), a("ngxPermissionsOnly", e.PERMISSION_LIST.EMPLOYEE_WRITE), r(), u(e.form.get("ip_addresses").controls.length ? 42 : 43)
    }
}
var Me = (() => {
    class t {
        constructor(e, i) {
            this.employeeService = e, this.loaderService = i, this.formatMessage = p, this.formService = c(dt), this.routerHelperService = c(mt), this.router = c(J), this.userSessionService = c($), this.activatedRouter = c(D), this.isMobileDevice = c(Y).isMobileDevice(), this.toastNotificationService = c(F), this.tenantService = c(X), this.isIndia = this.tenantService.isIndia(), this.today = new Date, this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = R, this.errorResponse = null, this.genderList = Object.values(ot), this.USER_TYPES = ue, this.isSaving = !1, this.isEditMode = !1, this.employeeId = null, this.PERMISSION_LIST = O, this.FORM_TYPE_LIST = tt
        }
        ngOnInit() {
            this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.employeeId ? (this.loaderService.show(), this.employeeService.getById(this.employeeId).subscribe({
                next: e => {
                    this.employee = new U(e), this.form = U.getForm(this.employee), this.setFormReadOnly()
                },
                error: e => {
                    console.log("can't get employee by id ", e)
                }
            }).add(() => this.loaderService.hide())) : (this.employee = new U({}), this.form = U.getForm(this.employee), this.isEditMode = !0)
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable()
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, this.loaderService.show(), (this.employeeId ? this.employeeService.update(this.form.value) : this.employeeService.create(this.form.value)).subscribe({
                next: i => {
                    this.activatedRouter.snapshot.parent.paramMap.has("employee_id") ? (this.employee = new U(i), this.toastNotificationService.success("notification_employee_update_success"), this.setFormReadOnly()) : (this.employeeId = i.id, this.toastNotificationService.success("notification_employee_add_success"), this.router.navigateByUrl(`/employees/${i.id}/profiles`), this.ngOnInit())
                },
                error: i => {
                    this.errorResponse = i
                }
            }).add(() => {
                this.isSaving = !1, this.loaderService.hide()
            })) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form = U.getForm(this.employee), this.isEditMode = !1, this.routerHelperService.goBack()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        removeIpAddress(e) {
            this.form.get("ip_addresses").removeAt(e)
        }
        addIpAddress() {
            this.form.get("ip_addresses").push(W.getForm(new W({})))
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.save()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(I(k), I(z))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-employee-detail"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start"],
                    [3, "isVisibleHr", "saveText"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [1, "row"],
                    ["name", "role_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["name", "display_name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["formControlName", "display_name", 3, "placeholder"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "mobile_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    [3, "entity", "entityId", "formControl", "isEditMode", "form", "isUniqueValidation", "typeId"],
                    [3, "displayError", "errorMsg"],
                    ["name", "phone_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "label"],
                    [3, "formControl", "isEditMode"],
                    ["name", "unique_identification_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "label", "tooltipText"],
                    ["formControlName", "unique_identification_number", 3, "placeholder"],
                    ["name", "gender", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "gender", "searchMode", "contains", 3, "items", "placeholder", "searchEnabled"],
                    ["name", "tax_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "tax_number", "placeholder", "Eg: ABCD1234A"],
                    ["name", "date_of_birth", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "date_of_birth", "type", "date", 3, "max", "pickerType", "placeholder"],
                    [1, "row", "d-flex", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    [1, "mt-5"],
                    [3, "parentForm"],
                    [3, "parentForm", "isBankOptional"],
                    ["id", "Ip-Address-title", 3, "title"],
                    ["buttonType", "default", "class", "float-end", "text", "add_new_ip", "title", "add_new_ip", 3, "disabled", "onClickEvent", 4, "ngxPermissionsOnly"],
                    [1, "row", 3, "formGroup"],
                    [1, "table", "table-bordered", "table-hover", "table-striped", "align-middle", "text-center", "theme-secondary-bg", "w-100", "mt-3"],
                    [3, "cancelClick", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", 3, "onClickEvent"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"],
                    ["placeholder", "employee_role_placeholder", 3, "formControl", "isCustomerTypes", "isEditMode"],
                    [3, "entity", "formControl", "isEditMode", "isUniqueValidation", "typeId"],
                    ["buttonType", "default", "text", "add_new_ip", "title", "add_new_ip", 1, "float-end", 3, "onClickEvent", "disabled"],
                    ["class", "row", 3, "formGroup", 4, "ngFor", "ngForOf"],
                    ["name", "name", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "name", "id", "name", 3, "placeholder"],
                    ["name", "ip_address", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "ip_address", "id", "ip-addresses", "placeholder", "192.29.09.83"],
                    [1, "col-sm-2", "col-md-2", "col-lg-2", "d-flex", "align-items-center", "mt-1"],
                    [1, "fa-thin", "fa-trash", "close-icon", 3, "click"],
                    ["scope", "col"],
                    ["colspan", "2", 1, "text-muted", "fst-italic"],
                    [1, "mb-0"]
                ],
                template: function(i, o) {
                    i & 1 && (_(0, yi, 1, 2, "app-skeleton-loader", 0), _(1, Ai, 44, 54, "form", 1)), i & 2 && (u(!o.form && o.employeeId ? 0 : -1), r(), u(o.form ? 1 : -1))
                },
                dependencies: [Ue, _t, Mt, ut, Ce, At, kt, St, Pt, Rt, Q, wt, Nt, Dt, Ot, xt, fe, he, We, _e, $e, Je, Qe, Ke, Ze],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ii = (t, n) => ({
    "btn-primary": t,
    "btn-outline-primary": n
});

function Li(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-send-notification", 6), h("sendNotificationClose", function() {
            x(e);
            let o = m();
            return E(o.sendNotificationClose())
        })("sendNotificationSave", function() {
            x(e);
            let o = m();
            return E(o.sendNotificationSave())
        }), s()
    }
    if (t & 2) {
        let e = m();
        a("entityObj", e.currentEmployee)("entity", e.ENTITIES.EMPLOYEE)("isVisiblePopup", e.isVisibleNotificationPopup())("isVisibleSendButton", !1)
    }
}

function Fi(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-confirmation-popup", 7), h("confirmActionCallback", function() {
            x(e);
            let o = m();
            return E(o.updateUserActivation())
        })("rejectActionCallback", function() {
            x(e);
            let o = m();
            return E(o.onCancelUserActivationToggle())
        }), s()
    }
    if (t & 2) {
        let e = m();
        a("confirmButtonText", e.isAccountActivated ? "deactivate" : "activate")("confirmationMessage", e.formatMessage(e.activationSwitchConfirmationMessage))("isSaving", e.isSavingActivationSetting)("rejectButtonText", "cancel")
    }
}
var oi = (() => {
    class t {
        get hasTenantEmployees() {
            return (this.tenantService.config() ? .entity_counts ? .employees || 0) > 0
        }
        constructor(e, i, o) {
            this.service = e, this.meta = i, this.notifyService = o, this.formatMessage = p, this.router = c(J), this.ENTITIES = R, this.entity = R.EMPLOYEE, this.toastNotificationService = c(F), this.isCapacitorNative = c(Y).isCapacitorNative(), this.tenantService = c(X), this.currentContextMenuAction = null, this.isVisibleUserActiveConfirmation = !1, this.activationSwitchConfirmationMessage = null, this.isVisibleNotificationPopup = q(!1), this.isSavingActivationSetting = !1, this.isAccountActivated = !0, this.customerContextMenu = [], this.selectedViewType = "table", this.selectedEmployees = [], this.userSessionService = c($), this.isAdmin = this.userSessionService.isAdmin, this.plan = this.tenantService.plan(), this.columns = [{
                dataField: "name",
                caption: p("user_employee"),
                width: 160,
                allowSorting: !0,
                sortOrder: "asc",
                cellTemplate: "originalEmployeeNameTemplate"
            }, {
                dataField: "display_name",
                caption: p("display_name_label"),
                hidingPriority: 6,
                allowSorting: !0
            }, {
                dataField: "roles[0].display_name",
                caption: p("role"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "mobile_number",
                caption: p("common_mobile"),
                width: 100,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "email",
                caption: p("common_email"),
                hidingPriority: 4,
                allowSorting: !0,
                cellTemplate: "emailTemplate"
            }, {
                dataField: "gender",
                caption: p("gender"),
                hidingPriority: 1,
                allowSorting: !1
            }, {
                dataField: "is_active",
                caption: p("is_active"),
                cellTemplate: "booleanTemplate",
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "is_employee_on_ride",
                caption: p("is_ride_active"),
                cellTemplate: "booleanTemplate",
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "last_login",
                caption: p("last_login"),
                hidingPriority: 0,
                allowSorting: !0,
                cellTemplate: "dateTimeTemplate"
            }, {
                dataField: "created_at",
                caption: p("common_created_on"),
                hidingPriority: 2,
                allowSorting: !0,
                cellTemplate: "dateTimeTemplate",
                visible: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                visible: !0
            }], this.PERMISSION_LIST = O, this.meta.addTags([{
                name: "description",
                content: "Manage your Employees Work With easily in CRM"
            }, {
                name: "keywords",
                content: "Cloud-based CRM, Secure, Laptop, Repair, Services, Parts , Repairing-Business, Recovery"
            }])
        }
        ngOnInit() {
            this.customerContextMenu = [{
                name: A.SEND_ACTIVATION_LINK,
                icon: "fal fa-paper-plane",
                visible: !0,
                locale_key: p("send_activation_link")
            }, {
                name: A.DEACTIVATE_ACTIVATE_ACCOUNT,
                icon: "fal fa-user-times",
                visible: !0,
                locale_key: p("customer_action_deactivate_activate_account")
            }, {
                name: A.TRACK,
                icon: "fal fa-location",
                visible: this.isCapacitorNative && this.isAdmin && [T.STANDARD, T.ENTERPRISE].includes(this.plan),
                disabled: !this.isCapacitorNative,
                hint: this.isCapacitorNative ? p("employee_tracking") : p("hint_employee_tracking_only_on_mobile"),
                locale_key: p("track_employee")
            }];
            let e = localStorage.getItem("employee_view_type");
            (e === "table" || e === "card") && (this.selectedViewType = e)
        }
        setViewType(e) {
            this.selectedViewType = e, localStorage.setItem("employee_view_type", e)
        }
        onContextMenuItemClick(e) {
            if (this.currentContextMenuAction = e.action, this.currentEmployee = e.entity, this.isAccountActivated = e.entity.is_active, this.currentContextMenuAction === A.TRACK) {
                if (console.log(this.currentEmployee), !this.currentEmployee ? .is_employee_on_ride) {
                    this.notifyService.error(p("error_employee_not_on_ride"));
                    return
                }
                this.router.navigate(["pickupDrop/map"], {
                    queryParams: {
                        employee: JSON.stringify(this.currentEmployee)
                    }
                });
                return
            }
            if (this.currentContextMenuAction === A.SEND_ACTIVATION_LINK) {
                this.isVisibleNotificationPopup.set(!0);
                return
            }
            this.isAccountActivated ? this.currentContextMenuAction = A.DEACTIVATE_ACCOUNT : this.currentContextMenuAction = A.ACTIVATE_ACCOUNT, (this.currentContextMenuAction === A.DEACTIVATE_ACCOUNT || this.currentContextMenuAction === A.ACTIVATE_ACCOUNT) && (this.isVisibleUserActiveConfirmation = !0, this.activationSwitchConfirmationMessage = this.isAccountActivated ? "deactivate_user_and_prevent_login" : "activate_employee_and_grant_access")
        }
        updateUserActivation() {
            this.isSavingActivationSetting = !0, this.service.toggleActivation(this.currentEmployee ? .id).subscribe({
                next: e => {
                    this.isAccountActivated = e.is_active, this.toastNotificationService.success("activation_updated_success"), setTimeout(() => {
                        window.location.reload()
                    }, 1500)
                },
                error: () => {
                    this.toastNotificationService.error("activation_update_error")
                }
            }).add(() => {
                this.isSavingActivationSetting = !1, this.isVisibleUserActiveConfirmation = !1
            })
        }
        create() {
            this.router.navigate(["/employees/add"])
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentEmployee = null
        }
        sendNotificationSave() {
            this.isVisibleNotificationPopup.set(!1)
        }
        sendNotificationClose() {
            this.isVisibleNotificationPopup.set(!1)
        }
        onCancelUserActivationToggle() {
            this.isVisibleUserActiveConfirmation = !1
        }
        onEmployeeSelectionChanged(e) {
            this.selectedEmployees = e
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(I(k), I(Ye), I(et))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-employee-list"]
                ],
                standalone: !1,
                decls: 9,
                vars: 18,
                consts: [
                    ["role", "group", 1, "btn-group", "btn-group-sm", "border"],
                    ["type", "button", 1, "btn", 3, "click", "ngClass"],
                    [1, "pb-3"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "selectionChanged", "viewType", "columns", "contextMenuItems", "entity", "isVisibleEditAction", "service", "writeAccessPermissionName", "searchPanelPlaceholderText"],
                    [3, "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "confirmButtonText", "confirmationMessage", "isSaving", "rejectButtonText"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage", "isSaving", "rejectButtonText"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "div", 0)(1, "button", 1), h("click", function() {
                        return o.setViewType("table")
                    }), C(2, " Table "), s(), l(3, "button", 1), h("click", function() {
                        return o.setViewType("card")
                    }), C(4, " Card "), s()(), l(5, "div", 2)(6, "app-data-grid", 3), h("contextMenuItemCancelClick", function() {
                        return o.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(y) {
                        return o.onContextMenuItemClick(y)
                    })("dataGridAddNewClick", function() {
                        return o.create()
                    })("selectionChanged", function(y) {
                        return o.onEmployeeSelectionChanged(y)
                    }), s()(), _(7, Li, 1, 4, "app-send-notification", 4), _(8, Fi, 1, 4, "app-confirmation-popup", 5)), i & 2 && (r(), a("ngClass", oe(12, ii, o.selectedViewType === "table", o.selectedViewType !== "table")), r(2), a("ngClass", oe(15, ii, o.selectedViewType === "card", o.selectedViewType !== "card")), r(3), a("viewType", o.selectedViewType)("columns", o.columns)("contextMenuItems", o.customerContextMenu)("entity", o.entity)("isVisibleEditAction", !1)("service", o.service)("writeAccessPermissionName", o.PERMISSION_LIST.EMPLOYEE_WRITE)("searchPanelPlaceholderText", "search_panel_employee_placeholder"), r(), u(o.isVisibleNotificationPopup() ? 7 : -1), r(), u(o.isVisibleUserActiveConfirmation ? 8 : -1))
                },
                dependencies: [de, ct, Z, gt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Vi(t, n) {
    if (t & 1 && d(0, "app-user-profile-info", 0), t & 2) {
        let e = m();
        a("entity", e.entity)("isOnProfilePage", !0)("typeId", e.USER_TYPES.EMPLOYEE)("user", e.employee)
    }
}
var ni = (() => {
    class t {
        constructor(e, i) {
            this.employeeService = e, this.loaderService = i, this.formatMessage = p, this.router = c(J), this.userSessionService = c($), this.tenantService = c(X), this.activatedRouter = c(D), this.toastNotificationService = c(F), this.USER_TYPES = ue, this.plan = this.tenantService.plan(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.currentUser = this.userSessionService.currentUser(), this.userPermissionList = this.userSessionService.userPermissionList(), this.entity = R.EMPLOYEE, this.tabs = [], this.employee = null, this.employeeId = null, this.selectedTabIndex = 0, this.errorResponse = null, this.isEditMode = !1
        }
        ngOnInit() {
            this.employeeId = +this.activatedRouter.snapshot.paramMap.get("employee_id"), this.tabs = [{
                id: 0,
                text: p("profile"),
                path: `/employees/${this.employeeId}/profiles`,
                icon: L.ID_BADGE.light
            }, {
                id: 1,
                text: p("assigned_jobs"),
                path: `/employees/${this.employeeId}/jobs`,
                icon: L.TICKET.light
            }, {
                id: 2,
                text: p("assigned_task"),
                path: `/employees/${this.employeeId}/tasks`,
                icon: re.TASK.light,
                visible: this.userPermissionList.includes(O.TASK_LIST) && [T.STANDARD, T.ENTERPRISE].includes(this.plan)
            }, {
                id: 3,
                text: p("assigned_leads"),
                path: `/employees/${this.employeeId}/leads`,
                icon: re.LEAD.light,
                disabled: [T.LITE, T.BASIC].includes(this.plan),
                visible: this.userPermissionList.includes(O.LEAD_LIST)
            }, {
                id: 4,
                text: p("assigned_pickup_drops"),
                path: `/employees/${this.employeeId}/pickUps`,
                icon: L.BUSINESS_TIME.light,
                disabled: [T.LITE].includes(this.plan),
                visible: this.userPermissionList.includes(O.PICKUP_DROP_LIST)
            }, {
                id: 5,
                text: p("permissions"),
                path: `/employees/${this.employeeId}/permissions`,
                icon: L.USER_LOCK.light,
                disabled: [T.LITE, T.BASIC].includes(this.plan),
                visible: this.isAdmin
            }, {
                id: 6,
                text: p("private_notes"),
                path: `/employees/${this.employeeId}/notes`,
                icon: L.STICKY_NOTE.light,
                visible: this.isEmployee && this.employeeId === this.currentUser.id
            }, {
                id: 7,
                text: p("activities"),
                path: `/employees/${this.employeeId}/activities`,
                icon: L.CHART_NETWORK.light,
                visible: !1
            }, {
                id: 7,
                text: p("notification_preferences"),
                path: `/employees/${this.employeeId}/notificationPreferences`,
                icon: re.NOTIFICATION.light,
                disabled: [T.LITE, T.BASIC].includes(this.plan),
                visible: !0
            }, {
                id: 8,
                text: p("conversations"),
                path: `/employees/${this.employeeId}/chats`,
                icon: L.MESSAGES.light,
                disabled: [T.LITE, T.BASIC].includes(this.plan),
                visible: !1
            }, {
                id: 9,
                text: p("employee_travel_log"),
                path: `/employees/${this.employeeId}/travels`,
                icon: L.ROUTE.light,
                disabled: [T.LITE, T.BASIC].includes(this.plan),
                visible: !0
            }, {
                id: 10,
                text: p("reports"),
                path: `/employees/${this.employeeId}/reports`,
                icon: re.REPORT.light,
                visible: !0
            }, {
                id: 11,
                text: p("messages"),
                path: `/employees/${this.employeeId}/messages`,
                icon: L.MESSAGES.light,
                visible: this.isEmployee
            }], this.employeeId ? (this.selectedTabIndex = this.activatedRouter.firstChild.snapshot.data.tab_index, this.initialize()) : this.getMyProfile()
        }
        initialize() {
            this.loaderService.show(), this.employeeService.getById(this.employeeId).subscribe({
                next: e => {
                    this.handleUserResponse(e)
                },
                error: e => {
                    console.log("can't get emoloyee by id ", e)
                }
            }).add(() => this.loaderService.hide())
        }
        getMyProfile() {
            this.loaderService.show(), this.employeeService.me().subscribe({
                next: e => {
                    this.handleUserResponse(e)
                },
                error: e => {
                    this.toastNotificationService.error("notification_profile_load_error"), console.log("can't load employee profile ", e)
                }
            }).add(() => this.loaderService.hide())
        }
        handleUserResponse(e) {
            this.employee = e, this.employeeId = e.id
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(I(k), I(z))
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-user-profile"]
                ],
                standalone: !1,
                features: [Ve([{
                    provide: Ut,
                    useExisting: k
                }])],
                decls: 3,
                vars: 4,
                consts: [
                    [3, "entity", "isOnProfilePage", "typeId", "user"],
                    [1, "mt-1", "mb-1"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-user-tie", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle"]
                ],
                template: function(i, o) {
                    i & 1 && (_(0, Vi, 1, 4, "app-user-profile-info", 0), l(1, "div", 1)(2, "app-responsive-tabs", 2), h("tabChange", function(y) {
                        return o.selectTab(y)
                    }), s()()), i & 2 && (u(o.employee != null && o.employee.id ? 0 : -1), r(2), a("tabs", o.tabs)("selectedIndex", o.selectedTabIndex)("mobileMenuTitle", o.employee == null ? null : o.employee.name))
                },
                dependencies: [Bt, Yt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ri = (() => {
    class t extends rt {
        constructor(e) {
            super(e, Ee), this.api = e, this.endpoint = Ee
        }
        getAll() {
            return this.api.get(this.endpoint)
        }
        getByUserId(e) {
            return this.api.get(this.endpoint + `/getByUserId/${e}`)
        }
        saveUserPermissions(e, i) {
            return this.api.post(this.endpoint + `/${e}/save`, i)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(Re(at))
            }
        }
        static {
            this.\u0275prov = De({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var ae = t => ({
        $implicit: t
    }),
    Ui = t => ({
        "bg-body-secondary rounded-2 px-2 my-2": t
    }),
    Bi = t => ({
        isDesktop: t
    }),
    ai = () => ({
        isDesktop: !0
    }),
    si = () => ({
        isDesktop: !1
    }),
    ee = (t, n) => n.name;

function ji(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-save-cancel-footer", 13), h("cancelClick", function() {
            x(e);
            let o = m(2);
            return E(o.cancel())
        })("saveClick", function() {
            x(e);
            let o = m(2);
            return E(o.savePermissions())
        }), s()
    }
    if (t & 2) {
        let e = m(2);
        a("isSaving", e.isSaving)("isVisibleHr", !1)("saveText", "save_permissions")("savingText", "saving")
    }
}

function Yi(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "app-dx-outline-button", 14), h("onClickEvent", function() {
            x(e);
            let o = m(2);
            return E(o.isEditMode = !0)
        }), s()
    }
}

function $i(t, n) {
    if (t & 1 && (l(0, "div", 9)(1, "span", 10), C(2), s(), _(3, ji, 1, 4, "app-save-cancel-footer", 11)(4, Yi, 1, 0, "app-dx-outline-button", 12), s()), t & 2) {
        let e = n.isDesktop,
            i = m();
        r(), a("ngClass", e ? "fs-5 fw-semibold" : "fw-semibold"), r(), v(i.formatMessage("permissions")), r(), u(i.isEditMode ? 3 : 4)
    }
}

function Gi(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "div", 15)(1, "div", 16)(2, "span", 17), C(3), s()(), l(4, "dx-switch", 18), h("onValueChanged", function(o) {
            let f = x(e).$implicit,
                y = m();
            return E(y.onPermissionChange(o, f))
        }), s()()
    }
    if (t & 2) {
        let e = n.$implicit,
            i = m();
        r(3), v(e.display_name), r(), a("disabled", !i.isEditMode)("value", i.isPermissionEnabled(e.name))
    }
}

function Hi(t, n) {
    if (t & 1) {
        let e = M();
        l(0, "dx-text-box", 19), h("onValueChanged", function(o) {
            x(e);
            let f = m();
            return E(f.onSearchChange(o.value))
        }), s()
    }
    if (t & 2) {
        let e = m();
        a("placeholder", e.formatMessage("common_search"))("value", e.searchQuery())("showClearButton", !0)
    }
}

function Wi(t, n) {
    if (t & 1 && C(0), t & 2) {
        let e = m().$implicit;
        Ae(" / ", e.groupName, " ")
    }
}

function qi(t, n) {
    t & 1 && S(0)
}

function Ji(t, n) {
    if (t & 1 && (l(0, "div", 21)(1, "div", 22), C(2), _(3, Wi, 1, 1), s(), g(4, qi, 1, 0, "ng-container", 23), s()), t & 2) {
        let e = n.$implicit;
        m(2);
        let i = P(3);
        r(2), v(e.moduleName), r(), u(e.groupName ? 3 : -1), r(), a("ngTemplateOutlet", i)("ngTemplateOutletContext", B(4, ae, e))
    }
}

function Ki(t, n) {
    if (t & 1 && (l(0, "div", 20), G(1, Ji, 5, 6, "div", 21, ee), s()), t & 2) {
        let e = m();
        r(), H(e.searchResults())
    }
}

function Qi(t, n) {
    if (t & 1 && (l(0, "div")(1, "div", 26), d(2, "i", 27), l(3, "span", 28), C(4), s(), l(5, "span", 29), C(6), s()()()), t & 2) {
        let e = n.$implicit,
            i = m(2);
        r(2), a("ngClass", e.icon), r(2), v(e.module), r(2), v(i.getItemCount(e))
    }
}

function zi(t, n) {
    t & 1 && S(0)
}

function Xi(t, n) {
    if (t & 1 && (l(0, "div", 32), g(1, zi, 1, 0, "ng-container", 23), s()), t & 2) {
        let e = n.$implicit;
        m(5);
        let i = P(3);
        r(), a("ngTemplateOutlet", i)("ngTemplateOutletContext", B(2, ae, e))
    }
}

function Zi(t, n) {
    if (t & 1 && (l(0, "div", 30), G(1, Xi, 2, 4, "div", 32, ee), s()), t & 2) {
        let e = m(2).$implicit;
        r(), H(e.items)
    }
}

function eo(t, n) {
    t & 1 && S(0)
}

function to(t, n) {
    if (t & 1 && g(0, eo, 1, 0, "ng-container", 23), t & 2) {
        let e = n.$implicit;
        m(5);
        let i = P(3);
        a("ngTemplateOutlet", i)("ngTemplateOutletContext", B(2, ae, e))
    }
}

function io(t, n) {
    if (t & 1 && (l(0, "div", 31), G(1, to, 1, 4, "ng-container", null, ee), s()), t & 2) {
        let e = m(2).$implicit;
        r(), H(e.items)
    }
}

function oo(t, n) {
    if (t & 1 && _(0, Zi, 3, 0, "div", 30)(1, io, 3, 0, "div", 31), t & 2) {
        let e = m(2).isDesktop;
        u(e ? 0 : 1)
    }
}

function no(t, n) {
    t & 1 && S(0)
}

function ro(t, n) {
    if (t & 1 && (l(0, "div", 32), g(1, no, 1, 0, "ng-container", 23), s()), t & 2) {
        let e = n.$implicit;
        m(6);
        let i = P(3);
        r(), a("ngTemplateOutlet", i)("ngTemplateOutletContext", B(2, ae, e))
    }
}

function ao(t, n) {
    if (t & 1 && (l(0, "div", 35), G(1, ro, 2, 4, "div", 32, ee), s()), t & 2) {
        let e = m().$implicit;
        r(), H(e.items)
    }
}

function so(t, n) {
    t & 1 && S(0)
}

function lo(t, n) {
    if (t & 1 && g(0, so, 1, 0, "ng-container", 23), t & 2) {
        let e = n.$implicit;
        m(6);
        let i = P(3);
        a("ngTemplateOutlet", i)("ngTemplateOutletContext", B(2, ae, e))
    }
}

function mo(t, n) {
    if (t & 1 && G(0, lo, 1, 4, "ng-container", null, ee), t & 2) {
        let e = m().$implicit;
        H(e.items)
    }
}

function po(t, n) {
    if (t & 1 && (l(0, "div", 33)(1, "h6", 34), C(2), s(), _(3, ao, 3, 0, "div", 35)(4, mo, 2, 0), s()), t & 2) {
        let e = n.$implicit,
            i = n.$index,
            o = m(3).isDesktop;
        a("ngClass", B(3, Ui, i % 2 === 0)), r(2), v(e.name), r(), u(o ? 3 : 4)
    }
}

function co(t, n) {
    if (t & 1 && G(0, po, 5, 5, "div", 33, ee), t & 2) {
        let e = m().$implicit;
        H(e.jobSettingsGroups)
    }
}

function _o(t, n) {
    if (t & 1 && (l(0, "div"), _(1, oo, 2, 1)(2, co, 2, 0), s()), t & 2) {
        let e = n.$implicit;
        r(), u(e.isJobSettings ? 2 : 1)
    }
}

function uo(t, n) {
    if (t & 1 && (l(0, "dx-accordion", 24), g(1, Qi, 7, 3, "div", 25)(2, _o, 3, 1, "div", 25), s()), t & 2) {
        let e = m();
        a("dataSource", e.filteredCategories())("collapsible", !0)("multiple", !1)("animationDuration", 200)("selectedItems", e.defaultExpandedItems), r(), a("dxTemplateOf", "categoryTitle"), r(), a("dxTemplateOf", "categoryContent")
    }
}

function fo(t, n) {
    if (t & 1 && (l(0, "div", 36), d(1, "i", 37), l(2, "p", 38), C(3), s()()), t & 2) {
        let e = m();
        r(3), v(e.formatMessage("common_no_results_found"))
    }
}

function ho(t, n) {
    t & 1 && S(0)
}

function Co(t, n) {
    if (t & 1 && g(0, ho, 1, 0, "ng-container", 39), t & 2) {
        m(3);
        let e = P(7);
        a("ngTemplateOutlet", e)
    }
}

function go(t, n) {
    t & 1 && S(0)
}

function vo(t, n) {
    if (t & 1 && g(0, go, 1, 0, "ng-container", 39), t & 2) {
        m(3);
        let e = P(11);
        a("ngTemplateOutlet", e)
    }
}

function yo(t, n) {
    if (t & 1 && (_(0, Co, 1, 1, "ng-container"), _(1, vo, 1, 1, "ng-container")), t & 2) {
        let e = m(2);
        u(e.searchResults().length ? 0 : -1), r(), u(!e.filteredCategories().length && !e.searchResults().length ? 1 : -1)
    }
}

function xo(t, n) {
    t & 1 && S(0)
}

function Eo(t, n) {
    if (t & 1 && g(0, xo, 1, 0, "ng-container", 23), t & 2) {
        let e = m().isDesktop;
        m();
        let i = P(9);
        a("ngTemplateOutlet", i)("ngTemplateOutletContext", B(2, Bi, e))
    }
}

function To(t, n) {
    if (t & 1 && (_(0, yo, 2, 2), _(1, Eo, 1, 4, "ng-container")), t & 2) {
        let e = m();
        u(e.isSearching() ? 0 : -1), r(), u(!e.isSearching() || e.filteredCategories().length ? 1 : -1)
    }
}

function bo(t, n) {
    t & 1 && S(0)
}

function So(t, n) {
    t & 1 && S(0)
}

function Mo(t, n) {
    t & 1 && S(0)
}

function Po(t, n) {
    if (t & 1 && (l(0, "div", 7)(1, "div", 40), g(2, bo, 1, 0, "ng-container", 23), l(3, "div", 41), g(4, So, 1, 0, "ng-container", 39), s(), g(5, Mo, 1, 0, "ng-container", 23), s()()), t & 2) {
        m();
        let e = P(1),
            i = P(5),
            o = P(13);
        r(2), a("ngTemplateOutlet", e)("ngTemplateOutletContext", ie(5, ai)), r(2), a("ngTemplateOutlet", i), r(), a("ngTemplateOutlet", o)("ngTemplateOutletContext", ie(6, ai))
    }
}

function Io(t, n) {
    t & 1 && S(0)
}

function Do(t, n) {
    t & 1 && S(0)
}

function Ro(t, n) {
    t & 1 && S(0)
}

function wo(t, n) {
    if (t & 1 && (l(0, "div", 8)(1, "div", 42), g(2, Io, 1, 0, "ng-container", 23)(3, Do, 1, 0, "ng-container", 39), s(), l(4, "div", 43), g(5, Ro, 1, 0, "ng-container", 23), s()()), t & 2) {
        m();
        let e = P(1),
            i = P(5),
            o = P(13);
        r(2), a("ngTemplateOutlet", e)("ngTemplateOutletContext", ie(5, si)), r(), a("ngTemplateOutlet", i), r(2), a("ngTemplateOutlet", o)("ngTemplateOutletContext", ie(6, si))
    }
}
var li = (() => {
    class t {
        constructor() {
            this.activatedRouter = c(D), this.toastNotificationService = c(F), this.service = c(ri), this.userDeviceService = c(Y), this.formatMessage = p, this.employeeId = null, this.isSaving = !1, this.isEditMode = !1, this.userPermissions = null, this.searchQuery = q(""), this.defaultExpandedItems = [], this.permissionSet = q(new Set), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.moduleIcons = {
                AMC: "fa-thin fa-file-contract",
                "Backup Drive": "fa-thin fa-hard-drive",
                Billing: "fa-thin fa-file-invoice-dollar",
                "Contact Us": "fa-thin fa-envelope",
                Customer: "fa-thin fa-users",
                Employee: "fa-thin fa-user-tie",
                Expense: "fa-thin fa-receipt",
                Job: "fa-thin fa-briefcase",
                "Job Settings": "fa-thin fa-sliders",
                Lead: "fa-thin fa-bullseye",
                "Outsource Vendor": "fa-thin fa-truck",
                "Outsourced Job": "fa-thin fa-share-nodes",
                Part: "fa-thin fa-microchip",
                Payment: "fa-thin fa-credit-card",
                "Pickup Drop": "fa-thin fa-truck-pickup",
                Purchase: "fa-thin fa-cart-shopping",
                Quotation: "fa-thin fa-file-lines",
                Report: "fa-thin fa-chart-bar",
                Sale: "fa-thin fa-cash-register",
                Task: "fa-thin fa-list-check",
                "Mail Marketing": "fa-thin fa-envelope-open-text",
                "Business Settings": "fa-thin fa-cog",
                Commission: "fa-thin fa-percent"
            }, this.modules = ["AMC", "Backup Drive", "Billing", "Commission", "Contact Us", "Customer", "Employee", "Expense", "Job", "Job Settings", "Lead", "Outsource Vendor", "Outsourced Job", "Part", "Payment", "Pickup Drop", "Purchase", "Quotation", "Report", "Sale", "Task", "Business Settings", "Mail Marketing", "Ledger"], this.jobSettingsEntities = ["Device Type", "Device Brand", "Device Model", "Accessory", "Repair Service", "Job Status", "Storage Location", "Device Color", "Job Source", "Quick Reply"], this.permissionCategories = q([]), this.isSearching = ce(() => this.searchQuery().length > 0), this.searchResults = ce(() => {
                let e = this.searchQuery();
                return e ? this.permissionCategories().flatMap(i => i.isJobSettings && i.jobSettingsGroups ? i.jobSettingsGroups.flatMap(o => o.items.map(f => N(w({}, f), {
                    groupName: o.name,
                    moduleName: i.module
                }))) : i.items.map(o => N(w({}, o), {
                    moduleName: i.module
                }))).filter(i => i.display_name ? .toLowerCase().includes(e)) : []
            }), this.filteredCategories = ce(() => {
                let e = this.searchQuery();
                return e ? this.permissionCategories().map(i => {
                    if (i.isJobSettings && i.jobSettingsGroups) {
                        let o = i.jobSettingsGroups.map(f => N(w({}, f), {
                            items: f.items.filter(y => y.display_name ? .toLowerCase().includes(e) || f.name ? .toLowerCase().includes(e) || i.module.toLowerCase().includes(e))
                        })).filter(f => f.items.length > 0);
                        return N(w({}, i), {
                            jobSettingsGroups: o,
                            items: []
                        })
                    }
                    return N(w({}, i), {
                        items: i.items.filter(o => o.display_name ? .toLowerCase().includes(e) || i.module.toLowerCase().includes(e))
                    })
                }).filter(i => i.items.length > 0 || i.jobSettingsGroups && i.jobSettingsGroups.length > 0) : this.permissionCategories()
            })
        }
        isPermissionEnabled(e) {
            return this.permissionSet().has(e)
        }
        ngOnInit() {
            this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.loadPermissions()
        }
        loadPermissions() {
            this.service.getByUserId(this.employeeId).subscribe({
                next: e => {
                    this.userPermissions = e;
                    let i = this.userPermissions.flatMap(o => o.items).filter(o => o.checked).map(o => o.name);
                    this.permissionSet.set(new Set(i)), this.buildPermissionCategories()
                },
                error: e => {
                    console.error("Error loading permissions:", e), this.toastNotificationService.error("notification_error_loading_permissions")
                }
            })
        }
        buildPermissionCategories() {
            let e = this.modules.map(i => {
                if (i === "Job Settings") return {
                    module: i,
                    icon: this.moduleIcons[i] || "fa-thin fa-folder",
                    items: [],
                    isJobSettings: !0,
                    jobSettingsGroups: this.userPermissions.filter(f => this.jobSettingsEntities.includes(f.name))
                };
                let o = this.userPermissions ? .find(f => f.name.toLowerCase() === i.toLowerCase());
                return {
                    module: i,
                    icon: this.moduleIcons[i] || "fa-thin fa-folder",
                    items: o ? .items || []
                }
            });
            this.permissionCategories.set(e), e.length > 0 && (this.defaultExpandedItems = [e[0]])
        }
        savePermissions() {
            this.isSaving = !0;
            let e = Array.from(this.permissionSet());
            this.service.saveUserPermissions(this.employeeId, {
                permissions: e
            }).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_user_permission_update_success"), this.isEditMode = !1
                },
                error: i => {
                    this.toastNotificationService.error("notification_user_permission_update_error"), console.error("Failed to update permissions:", i)
                }
            }).add(() => this.isSaving = !1)
        }
        onPermissionChange(e, i) {
            let o = new Set(this.permissionSet());
            e.value ? o.add(i.name) : o.delete(i.name), this.permissionSet.set(o)
        }
        onSearchChange(e) {
            this.searchQuery.set(e ? .toLowerCase() || "")
        }
        getItemCount(e) {
            return e.isJobSettings && e.jobSettingsGroups ? e.jobSettingsGroups.reduce((i, o) => i + (o.items ? .length || 0), 0) : e.items ? .length || 0
        }
        cancel() {
            this.loadPermissions(), this.isEditMode = !1
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-permission-detail"]
                ],
                standalone: !1,
                decls: 16,
                vars: 2,
                consts: [
                    ["editHeader", ""],
                    ["permissionToggle", ""],
                    ["searchBox", ""],
                    ["searchResultsList", ""],
                    ["permissionsAccordion", ""],
                    ["noResults", ""],
                    ["settingsContent", ""],
                    [1, "container-fluid", "pt-3"],
                    [1, "d-flex", "flex-column", "min-vh-100", "permission-mobile-container", 2, "margin", "-30px -12px 0", "padding-bottom", "80px", "background-color", "var(--primary-bg)"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-3"],
                    [3, "ngClass"],
                    [3, "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["buttonType", "default", "text", "edit_permissions", "title", "edit_permissions"],
                    [3, "cancelClick", "saveClick", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["buttonType", "default", "text", "edit_permissions", "title", "edit_permissions", 3, "onClickEvent"],
                    [1, "d-flex", "align-items-center", "py-2"],
                    [1, "me-2"],
                    [1, "small"],
                    [3, "onValueChanged", "disabled", "value"],
                    ["mode", "search", "valueChangeEvent", "input", "stylingMode", "outlined", 3, "onValueChanged", "placeholder", "value", "showClearButton"],
                    [1, "border", "rounded-2", "overflow-hidden", "mb-3"],
                    [1, "p-3", "border-bottom"],
                    [1, "small", "text-muted", "mb-1"],
                    [4, "ngTemplateOutlet", "ngTemplateOutletContext"],
                    ["itemTitleTemplate", "categoryTitle", "itemTemplate", "categoryContent", 3, "dataSource", "collapsible", "multiple", "animationDuration", "selectedItems"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "align-items-center", "gap-2", "w-100"],
                    [1, "text-muted", 3, "ngClass"],
                    [1, "flex-grow-1", "fw-medium"],
                    [1, "badge", "bg-secondary"],
                    [1, "row", "py-2"],
                    [1, "py-2"],
                    [1, "col-4", "mb-2"],
                    [1, "py-2", 3, "ngClass"],
                    [1, "mb-2", "fw-semibold", "small"],
                    [1, "row"],
                    [1, "d-flex", "flex-column", "align-items-center", "justify-content-center", "p-5", "rounded-2", "text-center", "border", "text-muted"],
                    [1, "fa-thin", "fa-search", "fs-2", "mb-3"],
                    [1, "m-0", "small"],
                    [4, "ngTemplateOutlet"],
                    [1, "desktop-permissions-sidebar"],
                    [1, "mb-3"],
                    [1, "flex-shrink-0", "sticky-top", 2, "top", "-30px", "z-index", "100", "padding", "28px 16px 12px", "background-color", "var(--primary-bg)"],
                    [1, "mobile-permissions-content", "px-3", "pt-3", 2, "background-color", "var(--primary-bg)"]
                ],
                template: function(i, o) {
                    i & 1 && (g(0, $i, 5, 3, "ng-template", null, 0, j)(2, Gi, 5, 3, "ng-template", null, 1, j)(4, Hi, 1, 3, "ng-template", null, 2, j)(6, Ki, 3, 0, "ng-template", null, 3, j)(8, uo, 3, 7, "ng-template", null, 4, j)(10, fo, 4, 1, "ng-template", null, 5, j)(12, To, 2, 2, "ng-template", null, 6, j), _(14, Po, 6, 7, "div", 7), _(15, wo, 6, 7, "div", 8)), i & 2 && (r(14), u(o.isMobileDevice() ? -1 : 14), r(), u(o.isMobileDevice() ? 15 : -1))
                },
                dependencies: [de, Be, Ce, Q, yt, pt, Et, he],
                styles: [".mobile-permissions-content[_ngcontent-%COMP%]     .dx-list-item, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-list-item{background-color:transparent!important}.mobile-permissions-content[_ngcontent-%COMP%]     .dx-list-item.dx-state-hover, .mobile-permissions-content[_ngcontent-%COMP%]     .dx-list-item.dx-state-focused, .mobile-permissions-content[_ngcontent-%COMP%]     .dx-list-item.dx-state-active, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-list-item.dx-state-hover, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-list-item.dx-state-focused, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-list-item.dx-state-active{background-color:var(--theme-hover-color)!important}.mobile-permissions-content[_ngcontent-%COMP%]     .dx-accordion-item, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-accordion-item{border-color:var(--border-color)}.mobile-permissions-content[_ngcontent-%COMP%]     .dx-accordion-item-title, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-accordion-item-title{background-color:transparent}.mobile-permissions-content[_ngcontent-%COMP%]     .dx-accordion-item-title:hover, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-accordion-item-title:hover{background-color:var(--theme-hover-color)}.mobile-permissions-content[_ngcontent-%COMP%]     .dx-accordion-item-body, .desktop-permissions-sidebar[_ngcontent-%COMP%]     .dx-accordion-item-body{background-color:transparent}"]
            })
        }
    }
    return t
})();
var mi = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-employee"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "div", 0), d(1, "router-outlet"), s())
                },
                dependencies: [Xe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var No = (t, n) => ({
        assigned_only: t,
        employee_id: n
    }),
    pi = (() => {
        class t {
            constructor(e) {
                this.service = e, this.formatMessage = p, this.assignedOnly = !1, this.userSessionService = c($), this.isMobileDevice = c(Y).isMobileDevice(), this.entity = R.RIDE, this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.activatedRouter = c(D), this.columns = [{
                    dataField: "user",
                    caption: p("user_employee"),
                    cellTemplate: "employeeTemplate",
                    allowSorting: !1,
                    width: 120
                }, {
                    dataField: "customer",
                    caption: p("user_customer"),
                    cellTemplate: "userTemplate",
                    allowSorting: !1,
                    hidingPriority: 4
                }, {
                    dataField: "origin_address",
                    caption: p("origin_location"),
                    allowSorting: !1,
                    hidingPriority: 2
                }, {
                    dataField: "destination_address",
                    caption: p("destination_location"),
                    allowSorting: !1,
                    hidingPriority: 3
                }, {
                    dataField: "started_at",
                    caption: p("start_time"),
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !1,
                    hidingPriority: 0
                }, {
                    dataField: "ended_at",
                    caption: p("end_time"),
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !1,
                    hidingPriority: 1
                }, {
                    dataField: "total_distance",
                    caption: p("distance"),
                    cellTemplate: "distanceTemplate",
                    allowSorting: !1,
                    width: 80,
                    alignment: "right"
                }]
            }
            ngOnInit() {
                this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id")
            }
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)(I(vt))
                }
            }
            static {
                this.\u0275cmp = b({
                    type: t,
                    selectors: [
                        ["app-employee-travel-list"]
                    ],
                    viewQuery: function(i, o) {
                        if (i & 1 && we(Z, 5), i & 2) {
                            let f;
                            Ne(f = Oe()) && (o.dataGrid = f.first)
                        }
                    },
                    inputs: {
                        assignedOnly: "assignedOnly"
                    },
                    standalone: !1,
                    decls: 1,
                    vars: 12,
                    consts: [
                        [3, "additionalParams", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleExportAction", "searchPanelPlaceholderText", "isVisibleReportDropdown", "service"]
                    ],
                    template: function(i, o) {
                        i & 1 && d(0, "app-data-grid", 0), i & 2 && a("additionalParams", oe(9, No, o.assignedOnly, o.employeeId))("columns", o.columns)("entity", o.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !1)("isVisibleExportAction", o.isAdmin && !o.isMobileDevice)("searchPanelPlaceholderText", "search_panel_tasks_placeholder")("isVisibleReportDropdown", !0)("service", o.service)
                    },
                    dependencies: [Z],
                    encapsulation: 2
                })
            }
        }
        return t
    })();

function Oo(t, n) {
    if (t & 1 && d(0, "app-trend-matrix-card", 3), t & 2) {
        let e = m();
        a("tooltipId", e.REPORT_TYPE.EMPLOYEE_JOBS_COMPLETED_TREND)("toolTip", "tooltip_employee_jobs_completed_trend")("currentDateRangeValue", e.jobCountTrendReport == null ? null : e.jobCountTrendReport.current_period_total)("percentage", e.jobCountTrendReport == null ? null : e.jobCountTrendReport.percentage_change)("dateRange", e.dateRangeLabel)
    }
}

function Ao(t, n) {
    if (t & 1 && d(0, "app-trend-matrix-card", 4), t & 2) {
        let e = m();
        a("tooltipId", e.REPORT_TYPE.EMPLOYEE_REVENUE_TREND)("toolTip", "tooltip_employee_revenue_trend")("currentDateRangeValue", e.revenueTrendReport == null ? null : e.revenueTrendReport.current_period_total)("percentage", e.revenueTrendReport == null ? null : e.revenueTrendReport.percentage_change)("dateRange", e.dateRangeLabel)
    }
}

function ko(t, n) {
    if (t & 1 && d(0, "app-charts", 15), t & 2) {
        let e = m();
        a("entityData", e.jobTrendChartData)("entityLabel", e.CHART_ENTITY_TYPES.EMPLOYEE_JOB_COMPLETION_TREND)("graphType", e.graphType)("isNameWise", !0)
    }
}

function Lo(t, n) {
    if (t & 1 && d(0, "app-charts", 15), t & 2) {
        let e = m();
        a("entityData", e.revenueTrendChartData)("entityLabel", e.CHART_ENTITY_TYPES.EMPLOYEE_REVENUE_TREND)("graphType", e.graphType)("isNameWise", !0)
    }
}

function Fo(t, n) {
    if (t & 1 && d(0, "app-charts", 15), t & 2) {
        let e = m();
        a("entityData", e.taskBreakdownData)("entityLabel", e.CHART_ENTITY_TYPES.EMPLOYEE_TASK_BREAKDOWN)("graphType", e.graphType)("isNameWise", !0)
    }
}
var ci = (() => {
    class t {
        constructor() {
            this.formatMessage = p, this.CHART_ENTITY_TYPES = it, this.activatedRoute = c(D), this.employeeReportService = c(Qt), this.loaderService = c(z), this.toastNotificationService = c(F), this.exportService = c(It), this.nativeFileService = c(Ct), this.destroy$ = new Pe, this.employeeId = null, this.jobTrendChartData = [], this.revenueTrendChartData = [], this.taskBreakdownData = [], this.graphType = "bar", this.reportTypes = [{
                displayName: "Bar",
                value: "bar"
            }, {
                displayName: "Line",
                value: "line"
            }], this.isLoading = !0, this.dateRangeLabel = "", this.performanceSummaryColumns = [{
                dataField: "total_jobs_completed",
                caption: p("employee_report_jobs_completed"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_jobs_completed"
            }, {
                dataField: "repairs_completed",
                caption: p("employee_report_repairs_completed"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_repairs_completed"
            }, {
                dataField: "total_payment_collected",
                caption: p("employee_report_payment_collected"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_payment_collected",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_travel_distance",
                caption: p("employee_report_travel_distance"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_travel_distance"
            }, {
                dataField: "total_revenue",
                caption: p("employee_report_total_revenue"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_total_revenue",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }], this.taskSummaryColumns = [{
                dataField: "total_sales_revenue",
                caption: p("employee_report_sales_revenue"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_sales_revenue",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_amc_revenue",
                caption: p("employee_report_amc_revenue"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_amc_revenue",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_sales_count",
                caption: p("employee_report_sales_count"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_sales_count"
            }, {
                dataField: "total_amc_services_completed",
                caption: p("employee_report_amc_services_completed"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_amc_services"
            }, {
                dataField: "completed_tasks",
                caption: p("employee_report_completed_tasks"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_tasks_completed"
            }, {
                dataField: "total_tasks",
                caption: p("employee_report_total_tasks"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_total_tasks"
            }], this.REPORT_TYPE = K, this.REPORT_DURATION_LIST = nt
        }
        ngOnInit() {
            let e = this.activatedRoute.snapshot.parent ? .paramMap.get("employee_id");
            this.employeeId = e ? +e : null
        }
        setReportForDuration(e) {
            let i = {
                from_date: e.fromDate,
                to_date: e.toDate,
                employee_id: this.employeeId
            };
            this.dateDuration = i, this.dateRangeLabel = e.fromDate && e.toDate ? e.fromDate + " - " + e.toDate : p("all"), this.isLoading = !0, this.loaderService.show(), Ie([this.employeeReportService.getReport(N(w({}, i), {
                type: K.EMPLOYEE_JOBS_COMPLETED_TREND
            })), this.employeeReportService.getReport(N(w({}, i), {
                type: K.EMPLOYEE_REVENUE_TREND
            })), this.employeeReportService.getReport(N(w({}, i), {
                type: K.EMPLOYEE_MONTHLY_TREND
            })), this.employeeReportService.getReport(N(w({}, i), {
                type: K.EMPLOYEE_TASK_SUMMARY
            }))]).pipe(le(this.destroy$)).subscribe({
                next: ([o, f, y, _i]) => {
                    this.jobCountTrendReport = o, this.revenueTrendReport = f, this.jobTrendChartData = (y || []).map(te => ({
                        name: te.month,
                        total: te.jobs_count
                    })), this.revenueTrendChartData = (y || []).map(te => ({
                        name: te.month,
                        total: te.revenue
                    }));
                    let se = _i ? .data ? .data ? .[0];
                    se && (this.taskBreakdownData = [{
                        name: p("employee_report_completed_tasks"),
                        total: se.completed_tasks || 0
                    }, {
                        name: p("employee_report_in_progress_tasks"),
                        total: se.in_progress_tasks || 0
                    }, {
                        name: p("employee_report_not_started_tasks"),
                        total: se.not_started_tasks || 0
                    }])
                },
                error: o => {
                    console.error("Employee profile report error:", o), this.toastNotificationService.error("notification_something_went_wrong")
                }
            }).add(() => {
                this.isLoading = !1, this.loaderService.hide()
            })
        }
        exportPerformanceSummary() {
            this.loaderService.show(), this.exportService.exportToFile("normalExport", {
                type: "xlsx",
                entity_type: "employee_performance_summary",
                from_date: this.dateDuration ? .from_date,
                to_date: this.dateDuration ? .to_date,
                employee_id: this.employeeId
            }).pipe(le(this.destroy$)).subscribe({
                next: e => ge(this, null, function*() {
                    return yield this.nativeFileService.downloadFile(e.body, "employee_performance_summary.xlsx")
                }),
                error: e => this.toastNotificationService.error(e.message)
            }).add(() => this.loaderService.hide())
        }
        exportTaskSummary() {
            this.loaderService.show(), this.exportService.exportToFile("normalExport", {
                type: "xlsx",
                entity_type: "employee_task_summary",
                from_date: this.dateDuration ? .from_date,
                to_date: this.dateDuration ? .to_date,
                employee_id: this.employeeId
            }).pipe(le(this.destroy$)).subscribe({
                next: e => ge(this, null, function*() {
                    return yield this.nativeFileService.downloadFile(e.body, "employee_task_summary.xlsx")
                }),
                error: e => this.toastNotificationService.error(e.message)
            }).add(() => this.loaderService.hide())
        }
        ngOnDestroy() {
            this.destroy$.next(), this.destroy$.complete()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = b({
                type: t,
                selectors: [
                    ["app-employee-profile-report"]
                ],
                standalone: !1,
                decls: 27,
                vars: 24,
                consts: [
                    [3, "durationDateChanges", "selectedDuration"],
                    [1, "row", "mt-3"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["icon", "fa-thin fa-ticket", "title", "employee_report_jobs_completed", 3, "tooltipId", "toolTip", "currentDateRangeValue", "percentage", "dateRange"],
                    ["icon", "fa-thin fa-wallet", "title", "employee_report_revenue_generated", 3, "tooltipId", "toolTip", "currentDateRangeValue", "percentage", "dateRange"],
                    [1, "row", "pt-2"],
                    [1, "col-12", "mt-2"],
                    [1, "position-relative", "d-flex", "justify-content-center", "align-items-center", "mb-3"],
                    [1, "m-0"],
                    ["buttonType", "default", "icon", "fa-thin fa-file-excel", "text", "export", 1, "position-absolute", "end-0", 3, "onClickEvent", "isVisibleIcon"],
                    [3, "columns", "dateDuration", "reportType", "service", "userId"],
                    [1, "col-12", "mt-5"],
                    [1, "col-12", "d-flex", "justify-content-end", "mt-5"],
                    ["displayExpr", "displayName", "valueExpr", "value", 3, "ngModelChange", "ngModel", "items", "searchEnabled", "width"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [3, "entityData", "entityLabel", "graphType", "isNameWise"]
                ],
                template: function(i, o) {
                    i & 1 && (l(0, "app-report-duration-dropdown", 0), h("durationDateChanges", function(y) {
                        return o.setReportForDuration(y)
                    }), s(), l(1, "div", 1)(2, "div", 2), _(3, Oo, 1, 5, "app-trend-matrix-card", 3), s(), l(4, "div", 2), _(5, Ao, 1, 5, "app-trend-matrix-card", 4), s()(), l(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "h5", 8), C(10), s(), l(11, "app-dx-outline-button", 9), h("onClickEvent", function() {
                        return o.exportPerformanceSummary()
                    }), s()(), d(12, "app-report-data-grid", 10), s(), l(13, "div", 11)(14, "div", 7)(15, "h5", 8), C(16), s(), l(17, "app-dx-outline-button", 9), h("onClickEvent", function() {
                        return o.exportTaskSummary()
                    }), s()(), d(18, "app-report-data-grid", 10), s(), l(19, "div", 12)(20, "dx-select-box", 13), Fe("ngModelChange", function(y) {
                        return Le(o.graphType, y) || (o.graphType = y), y
                    }), s()(), l(21, "div", 14), _(22, ko, 1, 4, "app-charts", 15), s(), l(23, "div", 14), _(24, Lo, 1, 4, "app-charts", 15), s(), l(25, "div", 14), _(26, Fo, 1, 4, "app-charts", 15), s()()), i & 2 && (a("selectedDuration", o.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), r(3), u(o.jobCountTrendReport ? 3 : -1), r(2), u(o.revenueTrendReport ? 5 : -1), r(5), v(o.formatMessage("employee_report_performance_summary")), r(), a("isVisibleIcon", !0), r(), a("columns", o.performanceSummaryColumns)("dateDuration", o.dateDuration)("reportType", o.REPORT_TYPE.EMPLOYEE_PERFORMANCE_SUMMARY)("service", o.employeeReportService)("userId", o.employeeId), r(4), v(o.formatMessage("employee_report_activity_summary")), r(), a("isVisibleIcon", !0), r(), a("columns", o.taskSummaryColumns)("dateDuration", o.dateDuration)("reportType", o.REPORT_TYPE.EMPLOYEE_TASK_SUMMARY)("service", o.employeeReportService)("userId", o.employeeId), r(2), ke("ngModel", o.graphType), a("items", o.reportTypes)("searchEnabled", !1)("width", 110), r(2), u(!o.isLoading && (o.jobTrendChartData == null ? null : o.jobTrendChartData.length) > 0 ? 22 : -1), r(2), u(!o.isLoading && (o.revenueTrendChartData == null ? null : o.revenueTrendChartData.length) > 0 ? 24 : -1), r(2), u(!o.isLoading && (o.taskBreakdownData == null ? null : o.taskBreakdownData.length) > 0 ? 26 : -1))
                },
                dependencies: [Tt, Ft, bt, Gt, Q, fe, _e, He],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Vo = [{
        path: "",
        component: mi,
        children: [{
            path: "add",
            component: Me,
            canActivate: [xe],
            data: {
                permissions: {
                    only: [O.EMPLOYEE_WRITE]
                }
            },
            pathMatch: "full",
            title: "BytePhase Add/Manage Employees"
        }, {
            path: "",
            component: oi,
            canActivate: [xe],
            data: {
                permissions: {
                    only: [O.EMPLOYEE_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Employees List"
        }, {
            path: ":employee_id",
            component: ni,
            data: {
                employee_id: null
            },
            title: "BytePhase Employees Profile List",
            children: [{
                path: "profiles",
                component: Me,
                data: {
                    tab_index: 0
                },
                title: "BytePhase Employees Detail"
            }, {
                path: "jobs",
                component: qt,
                data: {
                    tab_index: 1
                },
                title: "BytePhase Jobs/Services"
            }, {
                path: "tasks",
                component: zt,
                data: {
                    tab_index: 2
                },
                title: "BytePhase | Tasks"
            }, {
                path: "leads",
                component: Kt,
                data: {
                    tab_index: 3
                },
                title: "BytePhase | Leads"
            }, {
                path: "pickUps",
                component: Vt,
                data: {
                    tab_index: 4
                },
                title: "BytePhase | Pick-Ups"
            }, {
                path: "permissions",
                component: li,
                data: {
                    tab_index: 5,
                    entity: R.PERMISSION
                },
                canActivate: [st, lt],
                title: "BytePhase | Permissions"
            }, {
                path: "notes",
                component: Lt,
                data: {
                    notable_type: R.USER.name,
                    tab_index: 6
                },
                title: "BytePhase | Notes"
            }, {
                path: "activities",
                component: Zt,
                data: {
                    tab_index: 7
                },
                title: "BytePhase | Employee Activities"
            }, {
                path: "notificationPreferences",
                component: $t,
                data: {
                    tab_index: 8
                },
                title: "BytePhase | User Notification Preferences"
            }, {
                path: "travels",
                component: pi,
                data: {
                    tab_index: 9
                }
            }, {
                path: "reports",
                component: ci,
                data: {
                    tab_index: 10
                },
                title: "BytePhase | Employee Performance Report"
            }, {
                path: "messages",
                component: Ht,
                data: {
                    tab_index: 11
                },
                title: "BytePhase | Employee Messages"
            }]
        }]
    }],
    di = (() => {
        class t {
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275mod = pe({
                    type: t
                })
            }
            static {
                this.\u0275inj = me({
                    imports: [ye.forChild(Vo), ye]
                })
            }
        }
        return t
    })();
var Va = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275mod = pe({
                type: t
            })
        }
        static {
            this.\u0275inj = me({
                imports: [je, di, Jt, Xt, Wt]
            })
        }
    }
    return t
})();
export {
    Va as EmployeeModule
};