/*!
 * Bootstrap v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
(function(be, b) {
    typeof exports == "object" && typeof module < "u" ? module.exports = b() : typeof define == "function" && define.amd ? define(b) : (be = typeof globalThis < "u" ? globalThis : be || self).bootstrap = b()
})(this, function() {
    "use strict";
    const be = new Map,
        b = {
            set(o, t, s) {
                be.has(o) || be.set(o, new Map);
                const a = be.get(o);
                a.has(t) || a.size === 0 ? a.set(t, s) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(a.keys())[0]}.`)
            },
            get: (o, t) => be.has(o) && be.get(o).get(t) || null,
            remove(o, t) {
                if (!be.has(o)) return;
                const s = be.get(o);
                s.delete(t), s.size === 0 && be.delete(o)
            }
        },
        De = "transitionend",
        yt = o => (o && window.CSS && window.CSS.escape && (o = o.replace(/#([^\s"#']+)/g, (t, s) => `#${CSS.escape(s)}`)), o),
        $ = o => o == null ? `${o}` : Object.prototype.toString.call(o).match(/\s([a-z]+)/i)[1].toLowerCase(),
        jn = o => {
            o.dispatchEvent(new Event(De))
        },
        te = o => !(!o || typeof o != "object") && (o.jquery !== void 0 && (o = o[0]), o.nodeType !== void 0),
        ue = o => te(o) ? o.jquery ? o[0] : o : typeof o == "string" && o.length > 0 ? document.querySelector(yt(o)) : null,
        Ve = o => {
            if (!te(o) || o.getClientRects().length === 0) return !1;
            const t = getComputedStyle(o).getPropertyValue("visibility") === "visible",
                s = o.closest("details:not([open])");
            if (!s) return t;
            if (s !== o) {
                const a = o.closest("summary");
                if (a && a.parentNode !== s || a === null) return !1
            }
            return t
        },
        st = o => !o || o.nodeType !== Node.ELEMENT_NODE || !!o.classList.contains("disabled") || (o.disabled !== void 0 ? o.disabled : o.hasAttribute("disabled") && o.getAttribute("disabled") !== "false"),
        rt = o => {
            if (!document.documentElement.attachShadow) return null;
            if (typeof o.getRootNode == "function") {
                const t = o.getRootNode();
                return t instanceof ShadowRoot ? t : null
            }
            return o instanceof ShadowRoot ? o : o.parentNode ? rt(o.parentNode) : null
        },
        Oe = () => {},
        A = o => {
            o.offsetHeight
        },
        Rn = () => window.jQuery && !document.body.hasAttribute("data-bs-no-jquery") ? window.jQuery : null,
        Ht = [],
        Ee = () => document.documentElement.dir === "rtl",
        Me = o => {
            var t;
            t = () => {
                const s = Rn();
                if (s) {
                    const a = o.NAME,
                        c = s.fn[a];
                    s.fn[a] = o.jQueryInterface, s.fn[a].Constructor = o, s.fn[a].noConflict = () => (s.fn[a] = c, o.jQueryInterface)
                }
            }, document.readyState === "loading" ? (Ht.length || document.addEventListener("DOMContentLoaded", () => {
                for (const s of Ht) s()
            }), Ht.push(t)) : t()
        },
        he = (o, t = [], s = o) => typeof o == "function" ? o.call(...t) : s,
        Fn = (o, t, s = !0) => {
            if (!s) return void he(o);
            const a = (f => {
                if (!f) return 0;
                let {
                    transitionDuration: _,
                    transitionDelay: w
                } = window.getComputedStyle(f);
                const D = Number.parseFloat(_),
                    O = Number.parseFloat(w);
                return D || O ? (_ = _.split(",")[0], w = w.split(",")[0], 1e3 * (Number.parseFloat(_) + Number.parseFloat(w))) : 0
            })(t) + 5;
            let c = !1;
            const u = ({
                target: f
            }) => {
                f === t && (c = !0, t.removeEventListener(De, u), he(o))
            };
            t.addEventListener(De, u), setTimeout(() => {
                c || jn(t)
            }, a)
        },
        Tt = (o, t, s, a) => {
            const c = o.length;
            let u = o.indexOf(t);
            return u === -1 ? !s && a ? o[c - 1] : o[0] : (u += s ? 1 : -1, a && (u = (u + c) % c), o[Math.max(0, Math.min(u, c - 1))])
        },
        Pe = /[^.]*(?=\..*)\.|.*/,
        ki = /\..*/,
        Ae = /::\d+$/,
        Hn = {};
    let ii = 1;
    const Le = {
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        },
        si = new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);

    function $n(o, t) {
        return t && `${t}::${ii++}` || o.uidEvent || ii++
    }

    function Si(o) {
        const t = $n(o);
        return o.uidEvent = t, Hn[t] = Hn[t] || {}, Hn[t]
    }

    function Ie(o, t, s = null) {
        return Object.values(o).find(a => a.callable === t && a.delegationSelector === s)
    }

    function Un(o, t, s) {
        const a = typeof t == "string",
            c = a ? s : t || s;
        let u = M(o);
        return si.has(u) || (u = o), [a, c, u]
    }

    function an(o, t, s, a, c) {
        if (typeof t != "string" || !o) return;
        let [u, f, _] = Un(t, s, a);
        t in Le && (f = (N => function(Y) {
            if (!Y.relatedTarget || Y.relatedTarget !== Y.delegateTarget && !Y.delegateTarget.contains(Y.relatedTarget)) return N.call(this, Y)
        })(f));
        const w = Si(o),
            D = w[_] || (w[_] = {}),
            O = Ie(D, f, u ? s : null);
        if (O) return void(O.oneOff = O.oneOff && c);
        const k = $n(f, t.replace(Pe, "")),
            L = u ? (function(E, N, Y) {
                return function P(X) {
                    const ee = E.querySelectorAll(N);
                    for (let {
                            target: R
                        } = X; R && R !== this; R = R.parentNode)
                        for (const z of ee)
                            if (z === R) return Vn(X, {
                                delegateTarget: R
                            }), P.oneOff && p.off(E, X.type, N, Y), Y.apply(R, [X])
                }
            })(o, s, f) : (function(E, N) {
                return function Y(P) {
                    return Vn(P, {
                        delegateTarget: E
                    }), Y.oneOff && p.off(E, P.type, N), N.apply(E, [P])
                }
            })(o, f);
        L.delegationSelector = u ? s : null, L.callable = f, L.oneOff = c, L.uidEvent = k, D[k] = L, o.addEventListener(_, L, u)
    }

    function ln(o, t, s, a, c) {
        const u = Ie(t[s], a, c);
        u && (o.removeEventListener(s, u, !!c), delete t[s][u.uidEvent])
    }

    function $t(o, t, s, a) {
        const c = t[s] || {};
        for (const [u, f] of Object.entries(c)) u.includes(a) && ln(o, t, s, f.callable, f.delegationSelector)
    }

    function M(o) {
        return o = o.replace(ki, ""), Le[o] || o
    }
    const p = {
        on(o, t, s, a) {
            an(o, t, s, a, !1)
        },
        one(o, t, s, a) {
            an(o, t, s, a, !0)
        },
        off(o, t, s, a) {
            if (typeof t != "string" || !o) return;
            const [c, u, f] = Un(t, s, a), _ = f !== t, w = Si(o), D = w[f] || {}, O = t.startsWith(".");
            if (u === void 0) {
                if (O)
                    for (const k of Object.keys(w)) $t(o, w, k, t.slice(1));
                for (const [k, L] of Object.entries(D)) {
                    const E = k.replace(Ae, "");
                    _ && !t.includes(E) || ln(o, w, f, L.callable, L.delegationSelector)
                }
            } else {
                if (!Object.keys(D).length) return;
                ln(o, w, f, u, c ? s : null)
            }
        },
        trigger(o, t, s) {
            if (typeof t != "string" || !o) return null;
            const a = Rn();
            let c = null,
                u = !0,
                f = !0,
                _ = !1;
            t !== M(t) && a && (c = a.Event(t, s), a(o).trigger(c), u = !c.isPropagationStopped(), f = !c.isImmediatePropagationStopped(), _ = c.isDefaultPrevented());
            const w = Vn(new Event(t, {
                bubbles: u,
                cancelable: !0
            }), s);
            return _ && w.preventDefault(), f && o.dispatchEvent(w), w.defaultPrevented && c && c.preventDefault(), w
        }
    };

    function Vn(o, t = {}) {
        for (const [s, a] of Object.entries(t)) try {
            o[s] = a
        } catch {
            Object.defineProperty(o, s, {
                configurable: !0,
                get: () => a
            })
        }
        return o
    }

    function ri(o) {
        if (o === "true") return !0;
        if (o === "false") return !1;
        if (o === Number(o).toString()) return Number(o);
        if (o === "" || o === "null") return null;
        if (typeof o != "string") return o;
        try {
            return JSON.parse(decodeURIComponent(o))
        } catch {
            return o
        }
    }

    function we(o) {
        return o.replace(/[A-Z]/g, t => `-${t.toLowerCase()}`)
    }
    const We = {
        setDataAttribute(o, t, s) {
            o.setAttribute(`data-bs-${we(t)}`, s)
        },
        removeDataAttribute(o, t) {
            o.removeAttribute(`data-bs-${we(t)}`)
        },
        getDataAttributes(o) {
            if (!o) return {};
            const t = {},
                s = Object.keys(o.dataset).filter(a => a.startsWith("bs") && !a.startsWith("bsConfig"));
            for (const a of s) {
                let c = a.replace(/^bs/, "");
                c = c.charAt(0).toLowerCase() + c.slice(1), t[c] = ri(o.dataset[a])
            }
            return t
        },
        getDataAttribute: (o, t) => ri(o.getAttribute(`data-bs-${we(t)}`))
    };
    class cn {
        static get Default() {
            return {}
        }
        static get DefaultType() {
            return {}
        }
        static get NAME() {
            throw new Error('You have to implement the static method "NAME", for each component!')
        }
        _getConfig(t) {
            return t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t
        }
        _configAfterMerge(t) {
            return t
        }
        _mergeConfigObj(t, s) {
            const a = te(s) ? We.getDataAttribute(s, "config") : {};
            return { ...this.constructor.Default,
                ...typeof a == "object" ? a : {},
                ...te(s) ? We.getDataAttributes(s) : {},
                ...typeof t == "object" ? t : {}
            }
        }
        _typeCheckConfig(t, s = this.constructor.DefaultType) {
            for (const [a, c] of Object.entries(s)) {
                const u = t[a],
                    f = te(u) ? "element" : $(u);
                if (!new RegExp(c).test(f)) throw new TypeError(`${this.constructor.NAME.toUpperCase()}: Option "${a}" provided type "${f}" but expected type "${c}".`)
            }
        }
    }
    class me extends cn {
        constructor(t, s) {
            super(), (t = ue(t)) && (this._element = t, this._config = this._getConfig(s), b.set(this._element, this.constructor.DATA_KEY, this))
        }
        dispose() {
            b.remove(this._element, this.constructor.DATA_KEY), p.off(this._element, this.constructor.EVENT_KEY);
            for (const t of Object.getOwnPropertyNames(this)) this[t] = null
        }
        _queueCallback(t, s, a = !0) {
            Fn(t, s, a)
        }
        _getConfig(t) {
            return t = this._mergeConfigObj(t, this._element), t = this._configAfterMerge(t), this._typeCheckConfig(t), t
        }
        static getInstance(t) {
            return b.get(ue(t), this.DATA_KEY)
        }
        static getOrCreateInstance(t, s = {}) {
            return this.getInstance(t) || new this(t, typeof s == "object" ? s : null)
        }
        static get VERSION() {
            return "5.3.8"
        }
        static get DATA_KEY() {
            return `bs.${this.NAME}`
        }
        static get EVENT_KEY() {
            return `.${this.DATA_KEY}`
        }
        static eventName(t) {
            return `${t}${this.EVENT_KEY}`
        }
    }
    const le = o => {
            let t = o.getAttribute("data-bs-target");
            if (!t || t === "#") {
                let s = o.getAttribute("href");
                if (!s || !s.includes("#") && !s.startsWith(".")) return null;
                s.includes("#") && !s.startsWith("#") && (s = `#${s.split("#")[1]}`), t = s && s !== "#" ? s.trim() : null
            }
            return t ? t.split(",").map(s => yt(s)).join(",") : null
        },
        T = {
            find: (o, t = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(t, o)),
            findOne: (o, t = document.documentElement) => Element.prototype.querySelector.call(t, o),
            children: (o, t) => [].concat(...o.children).filter(s => s.matches(t)),
            parents(o, t) {
                const s = [];
                let a = o.parentNode.closest(t);
                for (; a;) s.push(a), a = a.parentNode.closest(t);
                return s
            },
            prev(o, t) {
                let s = o.previousElementSibling;
                for (; s;) {
                    if (s.matches(t)) return [s];
                    s = s.previousElementSibling
                }
                return []
            },
            next(o, t) {
                let s = o.nextElementSibling;
                for (; s;) {
                    if (s.matches(t)) return [s];
                    s = s.nextElementSibling
                }
                return []
            },
            focusableChildren(o) {
                const t = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map(s => `${s}:not([tabindex^="-"])`).join(",");
                return this.find(t, o).filter(s => !st(s) && Ve(s))
            },
            getSelectorFromElement(o) {
                const t = le(o);
                return t && T.findOne(t) ? t : null
            },
            getElementFromSelector(o) {
                const t = le(o);
                return t ? T.findOne(t) : null
            },
            getMultipleElementsFromSelector(o) {
                const t = le(o);
                return t ? T.find(t) : []
            }
        },
        G = (o, t = "hide") => {
            const s = `click.dismiss${o.EVENT_KEY}`,
                a = o.NAME;
            p.on(document, s, `[data-bs-dismiss="${a}"]`, function(c) {
                if (["A", "AREA"].includes(this.tagName) && c.preventDefault(), st(this)) return;
                const u = T.getElementFromSelector(this) || this.closest(`.${a}`);
                o.getOrCreateInstance(u)[t]()
            })
        },
        xt = ".bs.alert",
        Ut = `close${xt}`,
        Vt = `closed${xt}`;
    class ze extends me {
        static get NAME() {
            return "alert"
        }
        close() {
            if (p.trigger(this._element, Ut).defaultPrevented) return;
            this._element.classList.remove("show");
            const t = this._element.classList.contains("fade");
            this._queueCallback(() => this._destroyElement(), this._element, t)
        }
        _destroyElement() {
            this._element.remove(), p.trigger(this._element, Vt), this.dispose()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = ze.getOrCreateInstance(this);
                if (typeof t == "string") {
                    if (s[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                    s[t](this)
                }
            })
        }
    }
    G(ze, "close"), Me(ze);
    const un = '[data-bs-toggle="button"]';
    class hn extends me {
        static get NAME() {
            return "button"
        }
        toggle() {
            this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = hn.getOrCreateInstance(this);
                t === "toggle" && s[t]()
            })
        }
    }
    p.on(document, "click.bs.button.data-api", un, o => {
        o.preventDefault();
        const t = o.target.closest(un);
        hn.getOrCreateInstance(t).toggle()
    }), Me(hn);
    const ot = ".bs.swipe",
        at = `touchstart${ot}`,
        g = `touchmove${ot}`,
        S = `touchend${ot}`,
        Zi = `pointerdown${ot}`,
        lt = `pointerup${ot}`,
        Ye = {
            endCallback: null,
            leftCallback: null,
            rightCallback: null
        },
        j = {
            endCallback: "(function|null)",
            leftCallback: "(function|null)",
            rightCallback: "(function|null)"
        };
    class zt extends cn {
        constructor(t, s) {
            super(), this._element = t, t && zt.isSupported() && (this._config = this._getConfig(s), this._deltaX = 0, this._supportPointerEvents = !!window.PointerEvent, this._initEvents())
        }
        static get Default() {
            return Ye
        }
        static get DefaultType() {
            return j
        }
        static get NAME() {
            return "swipe"
        }
        dispose() {
            p.off(this._element, ot)
        }
        _start(t) {
            this._supportPointerEvents ? this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX) : this._deltaX = t.touches[0].clientX
        }
        _end(t) {
            this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX - this._deltaX), this._handleSwipe(), he(this._config.endCallback)
        }
        _move(t) {
            this._deltaX = t.touches && t.touches.length > 1 ? 0 : t.touches[0].clientX - this._deltaX
        }
        _handleSwipe() {
            const t = Math.abs(this._deltaX);
            if (t <= 40) return;
            const s = t / this._deltaX;
            this._deltaX = 0, s && he(s > 0 ? this._config.rightCallback : this._config.leftCallback)
        }
        _initEvents() {
            this._supportPointerEvents ? (p.on(this._element, Zi, t => this._start(t)), p.on(this._element, lt, t => this._end(t)), this._element.classList.add("pointer-event")) : (p.on(this._element, at, t => this._start(t)), p.on(this._element, g, t => this._move(t)), p.on(this._element, S, t => this._end(t)))
        }
        _eventIsPointerPenTouch(t) {
            return this._supportPointerEvents && (t.pointerType === "pen" || t.pointerType === "touch")
        }
        static isSupported() {
            return "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0
        }
    }
    const Ge = ".bs.carousel",
        U = ".data-api",
        dn = "ArrowLeft",
        zn = "ArrowRight",
        ie = "next",
        ke = "prev",
        pe = "left",
        ne = "right",
        je = `slide${Ge}`,
        Re = `slid${Ge}`,
        Ct = `keydown${Ge}`,
        Ki = `mouseenter${Ge}`,
        Xi = `mouseleave${Ge}`,
        fn = `dragstart${Ge}`,
        se = `load${Ge}${U}`,
        Gt = `click${Ge}${U}`,
        Bt = "carousel",
        mn = "active",
        Gn = ".active",
        qt = ".carousel-item",
        Di = Gn + qt,
        Oi = {
            [dn]: ne,
            [zn]: pe
        },
        Qi = {
            interval: 5e3,
            keyboard: !0,
            pause: "hover",
            ride: !1,
            touch: !0,
            wrap: !0
        },
        Ji = {
            interval: "(number|boolean)",
            keyboard: "boolean",
            pause: "(string|boolean)",
            ride: "(boolean|string)",
            touch: "boolean",
            wrap: "boolean"
        };
    class Et extends me {
        constructor(t, s) {
            super(t, s), this._interval = null, this._activeElement = null, this._isSliding = !1, this.touchTimeout = null, this._swipeHelper = null, this._indicatorsElement = T.findOne(".carousel-indicators", this._element), this._addEventListeners(), this._config.ride === Bt && this.cycle()
        }
        static get Default() {
            return Qi
        }
        static get DefaultType() {
            return Ji
        }
        static get NAME() {
            return "carousel"
        }
        next() {
            this._slide(ie)
        }
        nextWhenVisible() {
            !document.hidden && Ve(this._element) && this.next()
        }
        prev() {
            this._slide(ke)
        }
        pause() {
            this._isSliding && jn(this._element), this._clearInterval()
        }
        cycle() {
            this._clearInterval(), this._updateInterval(), this._interval = setInterval(() => this.nextWhenVisible(), this._config.interval)
        }
        _maybeEnableCycle() {
            this._config.ride && (this._isSliding ? p.one(this._element, Re, () => this.cycle()) : this.cycle())
        }
        to(t) {
            const s = this._getItems();
            if (t > s.length - 1 || t < 0) return;
            if (this._isSliding) return void p.one(this._element, Re, () => this.to(t));
            const a = this._getItemIndex(this._getActive());
            if (a === t) return;
            const c = t > a ? ie : ke;
            this._slide(c, s[t])
        }
        dispose() {
            this._swipeHelper && this._swipeHelper.dispose(), super.dispose()
        }
        _configAfterMerge(t) {
            return t.defaultInterval = t.interval, t
        }
        _addEventListeners() {
            this._config.keyboard && p.on(this._element, Ct, t => this._keydown(t)), this._config.pause === "hover" && (p.on(this._element, Ki, () => this.pause()), p.on(this._element, Xi, () => this._maybeEnableCycle())), this._config.touch && zt.isSupported() && this._addTouchEventListeners()
        }
        _addTouchEventListeners() {
            for (const s of T.find(".carousel-item img", this._element)) p.on(s, fn, a => a.preventDefault());
            const t = {
                leftCallback: () => this._slide(this._directionToOrder(pe)),
                rightCallback: () => this._slide(this._directionToOrder(ne)),
                endCallback: () => {
                    this._config.pause === "hover" && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(() => this._maybeEnableCycle(), 500 + this._config.interval))
                }
            };
            this._swipeHelper = new zt(this._element, t)
        }
        _keydown(t) {
            if (/input|textarea/i.test(t.target.tagName)) return;
            const s = Oi[t.key];
            s && (t.preventDefault(), this._slide(this._directionToOrder(s)))
        }
        _getItemIndex(t) {
            return this._getItems().indexOf(t)
        }
        _setActiveIndicatorElement(t) {
            if (!this._indicatorsElement) return;
            const s = T.findOne(Gn, this._indicatorsElement);
            s.classList.remove(mn), s.removeAttribute("aria-current");
            const a = T.findOne(`[data-bs-slide-to="${t}"]`, this._indicatorsElement);
            a && (a.classList.add(mn), a.setAttribute("aria-current", "true"))
        }
        _updateInterval() {
            const t = this._activeElement || this._getActive();
            if (!t) return;
            const s = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
            this._config.interval = s || this._config.defaultInterval
        }
        _slide(t, s = null) {
            if (this._isSliding) return;
            const a = this._getActive(),
                c = t === ie,
                u = s || Tt(this._getItems(), a, c, this._config.wrap);
            if (u === a) return;
            const f = this._getItemIndex(u),
                _ = k => p.trigger(this._element, k, {
                    relatedTarget: u,
                    direction: this._orderToDirection(t),
                    from: this._getItemIndex(a),
                    to: f
                });
            if (_(je).defaultPrevented || !a || !u) return;
            const w = !!this._interval;
            this.pause(), this._isSliding = !0, this._setActiveIndicatorElement(f), this._activeElement = u;
            const D = c ? "carousel-item-start" : "carousel-item-end",
                O = c ? "carousel-item-next" : "carousel-item-prev";
            u.classList.add(O), A(u), a.classList.add(D), u.classList.add(D), this._queueCallback(() => {
                u.classList.remove(D, O), u.classList.add(mn), a.classList.remove(mn, O, D), this._isSliding = !1, _(Re)
            }, a, this._isAnimated()), w && this.cycle()
        }
        _isAnimated() {
            return this._element.classList.contains("slide")
        }
        _getActive() {
            return T.findOne(Di, this._element)
        }
        _getItems() {
            return T.find(qt, this._element)
        }
        _clearInterval() {
            this._interval && (clearInterval(this._interval), this._interval = null)
        }
        _directionToOrder(t) {
            return Ee() ? t === pe ? ke : ie : t === pe ? ie : ke
        }
        _orderToDirection(t) {
            return Ee() ? t === ke ? pe : ne : t === ke ? ne : pe
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Et.getOrCreateInstance(this, t);
                if (typeof t != "number") {
                    if (typeof t == "string") {
                        if (s[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                        s[t]()
                    }
                } else s.to(t)
            })
        }
    }
    p.on(document, Gt, "[data-bs-slide], [data-bs-slide-to]", function(o) {
        const t = T.getElementFromSelector(this);
        if (!t || !t.classList.contains(Bt)) return;
        o.preventDefault();
        const s = Et.getOrCreateInstance(t),
            a = this.getAttribute("data-bs-slide-to");
        return a ? (s.to(a), void s._maybeEnableCycle()) : We.getDataAttribute(this, "slide") === "next" ? (s.next(), void s._maybeEnableCycle()) : (s.prev(), void s._maybeEnableCycle())
    }), p.on(window, se, () => {
        const o = T.find('[data-bs-ride="carousel"]');
        for (const t of o) Et.getOrCreateInstance(t)
    }), Me(Et);
    const Zt = ".bs.collapse",
        Mi = `show${Zt}`,
        es = `shown${Zt}`,
        pn = `hide${Zt}`,
        Bn = `hidden${Zt}`,
        Ti = `click${Zt}.data-api`,
        At = "show",
        Se = "collapse",
        Kt = "collapsing",
        _n = `:scope .${Se} .${Se}`,
        qn = '[data-bs-toggle="collapse"]',
        Zn = {
            parent: null,
            toggle: !0
        },
        ts = {
            parent: "(null|element)",
            toggle: "boolean"
        };
    class Xt extends me {
        constructor(t, s) {
            super(t, s), this._isTransitioning = !1, this._triggerArray = [];
            const a = T.find(qn);
            for (const c of a) {
                const u = T.getSelectorFromElement(c),
                    f = T.find(u).filter(_ => _ === this._element);
                u !== null && f.length && this._triggerArray.push(c)
            }
            this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle()
        }
        static get Default() {
            return Zn
        }
        static get DefaultType() {
            return ts
        }
        static get NAME() {
            return "collapse"
        }
        toggle() {
            this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (this._isTransitioning || this._isShown()) return;
            let t = [];
            if (this._config.parent && (t = this._getFirstLevelChildren(".collapse.show, .collapse.collapsing").filter(c => c !== this._element).map(c => Xt.getOrCreateInstance(c, {
                    toggle: !1
                }))), t.length && t[0]._isTransitioning || p.trigger(this._element, Mi).defaultPrevented) return;
            for (const c of t) c.hide();
            const s = this._getDimension();
            this._element.classList.remove(Se), this._element.classList.add(Kt), this._element.style[s] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
            const a = `scroll${s[0].toUpperCase()+s.slice(1)}`;
            this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove(Kt), this._element.classList.add(Se, At), this._element.style[s] = "", p.trigger(this._element, es)
            }, this._element, !0), this._element.style[s] = `${this._element[a]}px`
        }
        hide() {
            if (this._isTransitioning || !this._isShown() || p.trigger(this._element, pn).defaultPrevented) return;
            const t = this._getDimension();
            this._element.style[t] = `${this._element.getBoundingClientRect()[t]}px`, A(this._element), this._element.classList.add(Kt), this._element.classList.remove(Se, At);
            for (const s of this._triggerArray) {
                const a = T.getElementFromSelector(s);
                a && !this._isShown(a) && this._addAriaAndCollapsedClass([s], !1)
            }
            this._isTransitioning = !0, this._element.style[t] = "", this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove(Kt), this._element.classList.add(Se), p.trigger(this._element, Bn)
            }, this._element, !0)
        }
        _isShown(t = this._element) {
            return t.classList.contains(At)
        }
        _configAfterMerge(t) {
            return t.toggle = !!t.toggle, t.parent = ue(t.parent), t
        }
        _getDimension() {
            return this._element.classList.contains("collapse-horizontal") ? "width" : "height"
        }
        _initializeChildren() {
            if (!this._config.parent) return;
            const t = this._getFirstLevelChildren(qn);
            for (const s of t) {
                const a = T.getElementFromSelector(s);
                a && this._addAriaAndCollapsedClass([s], this._isShown(a))
            }
        }
        _getFirstLevelChildren(t) {
            const s = T.find(_n, this._config.parent);
            return T.find(t, this._config.parent).filter(a => !s.includes(a))
        }
        _addAriaAndCollapsedClass(t, s) {
            if (t.length)
                for (const a of t) a.classList.toggle("collapsed", !s), a.setAttribute("aria-expanded", s)
        }
        static jQueryInterface(t) {
            const s = {};
            return typeof t == "string" && /show|hide/.test(t) && (s.toggle = !1), this.each(function() {
                const a = Xt.getOrCreateInstance(this, s);
                if (typeof t == "string") {
                    if (a[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    a[t]()
                }
            })
        }
    }
    p.on(document, Ti, qn, function(o) {
        (o.target.tagName === "A" || o.delegateTarget && o.delegateTarget.tagName === "A") && o.preventDefault();
        for (const t of T.getMultipleElementsFromSelector(this)) Xt.getOrCreateInstance(t, {
            toggle: !1
        }).toggle()
    }), Me(Xt);
    var _e = "top",
        ge = "bottom",
        ye = "right",
        de = "left",
        gn = "auto",
        Be = [_e, ge, ye, de],
        vt = "start",
        V = "end",
        Qt = "clippingParents",
        Kn = "viewport",
        Jt = "popper",
        yn = "reference",
        qe = Be.reduce(function(o, t) {
            return o.concat([t + "-" + vt, t + "-" + V])
        }, []),
        vn = [].concat(Be, [gn]).reduce(function(o, t) {
            return o.concat([t, t + "-" + vt, t + "-" + V])
        }, []),
        Ze = "beforeRead",
        Xn = "read",
        xi = "afterRead",
        Ci = "beforeMain",
        Ei = "main",
        bn = "afterMain",
        Qn = "beforeWrite",
        Ai = "write",
        Yi = "afterWrite",
        Ni = [Ze, Xn, xi, Ci, Ei, bn, Qn, Ai, Yi];

    function Fe(o) {
        return o ? (o.nodeName || "").toLowerCase() : null
    }

    function Te(o) {
        if (o == null) return window;
        if (o.toString() !== "[object Window]") {
            var t = o.ownerDocument;
            return t && t.defaultView || window
        }
        return o
    }

    function bt(o) {
        return o instanceof Te(o).Element || o instanceof Element
    }

    function ce(o) {
        return o instanceof Te(o).HTMLElement || o instanceof HTMLElement
    }

    function wn(o) {
        return typeof ShadowRoot < "u" && (o instanceof Te(o).ShadowRoot || o instanceof ShadowRoot)
    }
    const kn = {
        name: "applyStyles",
        enabled: !0,
        phase: "write",
        fn: function(o) {
            var t = o.state;
            Object.keys(t.elements).forEach(function(s) {
                var a = t.styles[s] || {},
                    c = t.attributes[s] || {},
                    u = t.elements[s];
                ce(u) && Fe(u) && (Object.assign(u.style, a), Object.keys(c).forEach(function(f) {
                    var _ = c[f];
                    _ === !1 ? u.removeAttribute(f) : u.setAttribute(f, _ === !0 ? "" : _)
                }))
            })
        },
        effect: function(o) {
            var t = o.state,
                s = {
                    popper: {
                        position: t.options.strategy,
                        left: "0",
                        top: "0",
                        margin: "0"
                    },
                    arrow: {
                        position: "absolute"
                    },
                    reference: {}
                };
            return Object.assign(t.elements.popper.style, s.popper), t.styles = s, t.elements.arrow && Object.assign(t.elements.arrow.style, s.arrow),
                function() {
                    Object.keys(t.elements).forEach(function(a) {
                        var c = t.elements[a],
                            u = t.attributes[a] || {},
                            f = Object.keys(t.styles.hasOwnProperty(a) ? t.styles[a] : s[a]).reduce(function(_, w) {
                                return _[w] = "", _
                            }, {});
                        ce(c) && Fe(c) && (Object.assign(c.style, f), Object.keys(u).forEach(function(_) {
                            c.removeAttribute(_)
                        }))
                    })
                }
        },
        requires: ["computeStyles"]
    };

    function He(o) {
        return o.split("-")[0]
    }
    var wt = Math.max,
        B = Math.min,
        Yt = Math.round;

    function Nt() {
        var o = navigator.userAgentData;
        return o != null && o.brands && Array.isArray(o.brands) ? o.brands.map(function(t) {
            return t.brand + "/" + t.version
        }).join(" ") : navigator.userAgent
    }

    function Sn() {
        return !/^((?!chrome|android).)*safari/i.test(Nt())
    }

    function ct(o, t, s) {
        t === void 0 && (t = !1), s === void 0 && (s = !1);
        var a = o.getBoundingClientRect(),
            c = 1,
            u = 1;
        t && ce(o) && (c = o.offsetWidth > 0 && Yt(a.width) / o.offsetWidth || 1, u = o.offsetHeight > 0 && Yt(a.height) / o.offsetHeight || 1);
        var f = (bt(o) ? Te(o) : window).visualViewport,
            _ = !Sn() && s,
            w = (a.left + (_ && f ? f.offsetLeft : 0)) / c,
            D = (a.top + (_ && f ? f.offsetTop : 0)) / u,
            O = a.width / c,
            k = a.height / u;
        return {
            width: O,
            height: k,
            top: D,
            right: w + O,
            bottom: D + k,
            left: w,
            x: w,
            y: D
        }
    }

    function Dn(o) {
        var t = ct(o),
            s = o.offsetWidth,
            a = o.offsetHeight;
        return Math.abs(t.width - s) <= 1 && (s = t.width), Math.abs(t.height - a) <= 1 && (a = t.height), {
            x: o.offsetLeft,
            y: o.offsetTop,
            width: s,
            height: a
        }
    }

    function oi(o, t) {
        var s = t.getRootNode && t.getRootNode();
        if (o.contains(t)) return !0;
        if (s && wn(s)) {
            var a = t;
            do {
                if (a && o.isSameNode(a)) return !0;
                a = a.parentNode || a.host
            } while (a)
        }
        return !1
    }

    function ut(o) {
        return Te(o).getComputedStyle(o)
    }

    function ai(o) {
        return ["table", "td", "th"].indexOf(Fe(o)) >= 0
    }

    function Ke(o) {
        return ((bt(o) ? o.ownerDocument : o.document) || window.document).documentElement
    }

    function en(o) {
        return Fe(o) === "html" ? o : o.assignedSlot || o.parentNode || (wn(o) ? o.host : null) || Ke(o)
    }

    function li(o) {
        return ce(o) && ut(o).position !== "fixed" ? o.offsetParent : null
    }

    function On(o) {
        for (var t = Te(o), s = li(o); s && ai(s) && ut(s).position === "static";) s = li(s);
        return s && (Fe(s) === "html" || Fe(s) === "body" && ut(s).position === "static") ? t : s || (function(a) {
            var c = /firefox/i.test(Nt());
            if (/Trident/i.test(Nt()) && ce(a) && ut(a).position === "fixed") return null;
            var u = en(a);
            for (wn(u) && (u = u.host); ce(u) && ["html", "body"].indexOf(Fe(u)) < 0;) {
                var f = ut(u);
                if (f.transform !== "none" || f.perspective !== "none" || f.contain === "paint" || ["transform", "perspective"].indexOf(f.willChange) !== -1 || c && f.willChange === "filter" || c && f.filter && f.filter !== "none") return u;
                u = u.parentNode
            }
            return null
        })(o) || t
    }

    function ci(o) {
        return ["top", "bottom"].indexOf(o) >= 0 ? "x" : "y"
    }

    function ve(o, t, s) {
        return wt(o, B(t, s))
    }

    function kt(o) {
        return Object.assign({}, {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        }, o)
    }

    function ui(o, t) {
        return t.reduce(function(s, a) {
            return s[a] = o, s
        }, {})
    }
    const hi = {
        name: "arrow",
        enabled: !0,
        phase: "main",
        fn: function(o) {
            var t, s = o.state,
                a = o.name,
                c = o.options,
                u = s.elements.arrow,
                f = s.modifiersData.popperOffsets,
                _ = He(s.placement),
                w = ci(_),
                D = [de, ye].indexOf(_) >= 0 ? "height" : "width";
            if (u && f) {
                var O = (function(Q, K) {
                        return kt(typeof(Q = typeof Q == "function" ? Q(Object.assign({}, K.rects, {
                            placement: K.placement
                        })) : Q) != "number" ? Q : ui(Q, Be))
                    })(c.padding, s),
                    k = Dn(u),
                    L = w === "y" ? _e : de,
                    E = w === "y" ? ge : ye,
                    N = s.rects.reference[D] + s.rects.reference[w] - f[w] - s.rects.popper[D],
                    Y = f[w] - s.rects.reference[w],
                    P = On(u),
                    X = P ? w === "y" ? P.clientHeight || 0 : P.clientWidth || 0 : 0,
                    ee = N / 2 - Y / 2,
                    R = O[L],
                    z = X - k[D] - O[E],
                    W = X / 2 - k[D] / 2 + ee,
                    H = ve(R, W, z),
                    Z = w;
                s.modifiersData[a] = ((t = {})[Z] = H, t.centerOffset = H - W, t)
            }
        },
        effect: function(o) {
            var t = o.state,
                s = o.options.element,
                a = s === void 0 ? "[data-popper-arrow]" : s;
            a != null && (typeof a != "string" || (a = t.elements.popper.querySelector(a))) && oi(t.elements.popper, a) && (t.elements.arrow = a)
        },
        requires: ["popperOffsets"],
        requiresIfExists: ["preventOverflow"]
    };

    function Pt(o) {
        return o.split("-")[1]
    }
    var Pi = {
        top: "auto",
        right: "auto",
        bottom: "auto",
        left: "auto"
    };

    function Li(o) {
        var t, s = o.popper,
            a = o.popperRect,
            c = o.placement,
            u = o.variation,
            f = o.offsets,
            _ = o.position,
            w = o.gpuAcceleration,
            D = o.adaptive,
            O = o.roundOffsets,
            k = o.isFixed,
            L = f.x,
            E = L === void 0 ? 0 : L,
            N = f.y,
            Y = N === void 0 ? 0 : N,
            P = typeof O == "function" ? O({
                x: E,
                y: Y
            }) : {
                x: E,
                y: Y
            };
        E = P.x, Y = P.y;
        var X = f.hasOwnProperty("x"),
            ee = f.hasOwnProperty("y"),
            R = de,
            z = _e,
            W = window;
        if (D) {
            var H = On(s),
                Z = "clientHeight",
                Q = "clientWidth";
            H === Te(s) && ut(H = Ke(s)).position !== "static" && _ === "absolute" && (Z = "scrollHeight", Q = "scrollWidth"), (c === _e || (c === de || c === ye) && u === V) && (z = ge, Y -= (k && H === W && W.visualViewport ? W.visualViewport.height : H[Z]) - a.height, Y *= w ? 1 : -1), c !== de && (c !== _e && c !== ge || u !== V) || (R = ye, E -= (k && H === W && W.visualViewport ? W.visualViewport.width : H[Q]) - a.width, E *= w ? 1 : -1)
        }
        var K, ae = Object.assign({
                position: _
            }, D && Pi),
            Ue = O === !0 ? (function(gt, xe) {
                var tt = gt.x,
                    nt = gt.y,
                    oe = xe.devicePixelRatio || 1;
                return {
                    x: Yt(tt * oe) / oe || 0,
                    y: Yt(nt * oe) / oe || 0
                }
            })({
                x: E,
                y: Y
            }, Te(s)) : {
                x: E,
                y: Y
            };
        return E = Ue.x, Y = Ue.y, w ? Object.assign({}, ae, ((K = {})[z] = ee ? "0" : "", K[R] = X ? "0" : "", K.transform = (W.devicePixelRatio || 1) <= 1 ? "translate(" + E + "px, " + Y + "px)" : "translate3d(" + E + "px, " + Y + "px, 0)", K)) : Object.assign({}, ae, ((t = {})[z] = ee ? Y + "px" : "", t[R] = X ? E + "px" : "", t.transform = "", t))
    }
    const tn = {
        name: "computeStyles",
        enabled: !0,
        phase: "beforeWrite",
        fn: function(o) {
            var t = o.state,
                s = o.options,
                a = s.gpuAcceleration,
                c = a === void 0 || a,
                u = s.adaptive,
                f = u === void 0 || u,
                _ = s.roundOffsets,
                w = _ === void 0 || _,
                D = {
                    placement: He(t.placement),
                    variation: Pt(t.placement),
                    popper: t.elements.popper,
                    popperRect: t.rects.popper,
                    gpuAcceleration: c,
                    isFixed: t.options.strategy === "fixed"
                };
            t.modifiersData.popperOffsets != null && (t.styles.popper = Object.assign({}, t.styles.popper, Li(Object.assign({}, D, {
                offsets: t.modifiersData.popperOffsets,
                position: t.options.strategy,
                adaptive: f,
                roundOffsets: w
            })))), t.modifiersData.arrow != null && (t.styles.arrow = Object.assign({}, t.styles.arrow, Li(Object.assign({}, D, {
                offsets: t.modifiersData.arrow,
                position: "absolute",
                adaptive: !1,
                roundOffsets: w
            })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
                "data-popper-placement": t.placement
            })
        },
        data: {}
    };
    var Mn = {
        passive: !0
    };
    const Jn = {
        name: "eventListeners",
        enabled: !0,
        phase: "write",
        fn: function() {},
        effect: function(o) {
            var t = o.state,
                s = o.instance,
                a = o.options,
                c = a.scroll,
                u = c === void 0 || c,
                f = a.resize,
                _ = f === void 0 || f,
                w = Te(t.elements.popper),
                D = [].concat(t.scrollParents.reference, t.scrollParents.popper);
            return u && D.forEach(function(O) {
                    O.addEventListener("scroll", s.update, Mn)
                }), _ && w.addEventListener("resize", s.update, Mn),
                function() {
                    u && D.forEach(function(O) {
                        O.removeEventListener("scroll", s.update, Mn)
                    }), _ && w.removeEventListener("resize", s.update, Mn)
                }
        },
        data: {}
    };
    var Ii = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    };

    function ht(o) {
        return o.replace(/left|right|bottom|top/g, function(t) {
            return Ii[t]
        })
    }
    var Wi = {
        start: "end",
        end: "start"
    };

    function di(o) {
        return o.replace(/start|end/g, function(t) {
            return Wi[t]
        })
    }

    function Tn(o) {
        var t = Te(o);
        return {
            scrollLeft: t.pageXOffset,
            scrollTop: t.pageYOffset
        }
    }

    function xn(o) {
        return ct(Ke(o)).left + Tn(o).scrollLeft
    }

    function nn(o) {
        var t = ut(o),
            s = t.overflow,
            a = t.overflowX,
            c = t.overflowY;
        return /auto|scroll|overlay|hidden/.test(s + c + a)
    }

    function fi(o) {
        return ["html", "body", "#document"].indexOf(Fe(o)) >= 0 ? o.ownerDocument.body : ce(o) && nn(o) ? o : fi(en(o))
    }

    function Ne(o, t) {
        var s;
        t === void 0 && (t = []);
        var a = fi(o),
            c = a === ((s = o.ownerDocument) == null ? void 0 : s.body),
            u = Te(a),
            f = c ? [u].concat(u.visualViewport || [], nn(a) ? a : []) : a,
            _ = t.concat(f);
        return c ? _ : _.concat(Ne(en(f)))
    }

    function dt(o) {
        return Object.assign({}, o, {
            left: o.x,
            top: o.y,
            right: o.x + o.width,
            bottom: o.y + o.height
        })
    }

    function ji(o, t, s) {
        return t === Kn ? dt((function(a, c) {
            var u = Te(a),
                f = Ke(a),
                _ = u.visualViewport,
                w = f.clientWidth,
                D = f.clientHeight,
                O = 0,
                k = 0;
            if (_) {
                w = _.width, D = _.height;
                var L = Sn();
                (L || !L && c === "fixed") && (O = _.offsetLeft, k = _.offsetTop)
            }
            return {
                width: w,
                height: D,
                x: O + xn(a),
                y: k
            }
        })(o, s)) : bt(t) ? (function(a, c) {
            var u = ct(a, !1, c === "fixed");
            return u.top = u.top + a.clientTop, u.left = u.left + a.clientLeft, u.bottom = u.top + a.clientHeight, u.right = u.left + a.clientWidth, u.width = a.clientWidth, u.height = a.clientHeight, u.x = u.left, u.y = u.top, u
        })(t, s) : dt((function(a) {
            var c, u = Ke(a),
                f = Tn(a),
                _ = (c = a.ownerDocument) == null ? void 0 : c.body,
                w = wt(u.scrollWidth, u.clientWidth, _ ? _.scrollWidth : 0, _ ? _.clientWidth : 0),
                D = wt(u.scrollHeight, u.clientHeight, _ ? _.scrollHeight : 0, _ ? _.clientHeight : 0),
                O = -f.scrollLeft + xn(a),
                k = -f.scrollTop;
            return ut(_ || u).direction === "rtl" && (O += wt(u.clientWidth, _ ? _.clientWidth : 0) - w), {
                width: w,
                height: D,
                x: O,
                y: k
            }
        })(Ke(o)))
    }

    function mi(o) {
        var t, s = o.reference,
            a = o.element,
            c = o.placement,
            u = c ? He(c) : null,
            f = c ? Pt(c) : null,
            _ = s.x + s.width / 2 - a.width / 2,
            w = s.y + s.height / 2 - a.height / 2;
        switch (u) {
            case _e:
                t = {
                    x: _,
                    y: s.y - a.height
                };
                break;
            case ge:
                t = {
                    x: _,
                    y: s.y + s.height
                };
                break;
            case ye:
                t = {
                    x: s.x + s.width,
                    y: w
                };
                break;
            case de:
                t = {
                    x: s.x - a.width,
                    y: w
                };
                break;
            default:
                t = {
                    x: s.x,
                    y: s.y
                }
        }
        var D = u ? ci(u) : null;
        if (D != null) {
            var O = D === "y" ? "height" : "width";
            switch (f) {
                case vt:
                    t[D] = t[D] - (s[O] / 2 - a[O] / 2);
                    break;
                case V:
                    t[D] = t[D] + (s[O] / 2 - a[O] / 2)
            }
        }
        return t
    }

    function ft(o, t) {
        t === void 0 && (t = {});
        var s = t,
            a = s.placement,
            c = a === void 0 ? o.placement : a,
            u = s.strategy,
            f = u === void 0 ? o.strategy : u,
            _ = s.boundary,
            w = _ === void 0 ? Qt : _,
            D = s.rootBoundary,
            O = D === void 0 ? Kn : D,
            k = s.elementContext,
            L = k === void 0 ? Jt : k,
            E = s.altBoundary,
            N = E !== void 0 && E,
            Y = s.padding,
            P = Y === void 0 ? 0 : Y,
            X = kt(typeof P != "number" ? P : ui(P, Be)),
            ee = L === Jt ? yn : Jt,
            R = o.rects.popper,
            z = o.elements[N ? ee : L],
            W = (function(xe, tt, nt, oe) {
                var Ot = tt === "clippingParents" ? (function(J) {
                        var Ce = Ne(en(J)),
                            it = ["absolute", "fixed"].indexOf(ut(J).position) >= 0 && ce(J) ? On(J) : J;
                        return bt(it) ? Ce.filter(function(on) {
                            return bt(on) && oi(on, it) && Fe(on) !== "body"
                        }) : []
                    })(xe) : [].concat(tt),
                    Mt = [].concat(Ot, [nt]),
                    ni = Mt[0],
                    fe = Mt.reduce(function(J, Ce) {
                        var it = ji(xe, Ce, oe);
                        return J.top = wt(it.top, J.top), J.right = B(it.right, J.right), J.bottom = B(it.bottom, J.bottom), J.left = wt(it.left, J.left), J
                    }, ji(xe, ni, oe));
                return fe.width = fe.right - fe.left, fe.height = fe.bottom - fe.top, fe.x = fe.left, fe.y = fe.top, fe
            })(bt(z) ? z : z.contextElement || Ke(o.elements.popper), w, O, f),
            H = ct(o.elements.reference),
            Z = mi({
                reference: H,
                element: R,
                placement: c
            }),
            Q = dt(Object.assign({}, R, Z)),
            K = L === Jt ? Q : H,
            ae = {
                top: W.top - K.top + X.top,
                bottom: K.bottom - W.bottom + X.bottom,
                left: W.left - K.left + X.left,
                right: K.right - W.right + X.right
            },
            Ue = o.modifiersData.offset;
        if (L === Jt && Ue) {
            var gt = Ue[c];
            Object.keys(ae).forEach(function(xe) {
                var tt = [ye, ge].indexOf(xe) >= 0 ? 1 : -1,
                    nt = [_e, ge].indexOf(xe) >= 0 ? "y" : "x";
                ae[xe] += gt[nt] * tt
            })
        }
        return ae
    }

    function Ri(o, t) {
        t === void 0 && (t = {});
        var s = t,
            a = s.placement,
            c = s.boundary,
            u = s.rootBoundary,
            f = s.padding,
            _ = s.flipVariations,
            w = s.allowedAutoPlacements,
            D = w === void 0 ? vn : w,
            O = Pt(a),
            k = O ? _ ? qe : qe.filter(function(N) {
                return Pt(N) === O
            }) : Be,
            L = k.filter(function(N) {
                return D.indexOf(N) >= 0
            });
        L.length === 0 && (L = k);
        var E = L.reduce(function(N, Y) {
            return N[Y] = ft(o, {
                placement: Y,
                boundary: c,
                rootBoundary: u,
                padding: f
            })[He(Y)], N
        }, {});
        return Object.keys(E).sort(function(N, Y) {
            return E[N] - E[Y]
        })
    }
    const ei = {
        name: "flip",
        enabled: !0,
        phase: "main",
        fn: function(o) {
            var t = o.state,
                s = o.options,
                a = o.name;
            if (!t.modifiersData[a]._skip) {
                for (var c = s.mainAxis, u = c === void 0 || c, f = s.altAxis, _ = f === void 0 || f, w = s.fallbackPlacements, D = s.padding, O = s.boundary, k = s.rootBoundary, L = s.altBoundary, E = s.flipVariations, N = E === void 0 || E, Y = s.allowedAutoPlacements, P = t.options.placement, X = He(P), ee = w || (X !== P && N ? (function(J) {
                        if (He(J) === gn) return [];
                        var Ce = ht(J);
                        return [di(J), Ce, di(Ce)]
                    })(P) : [ht(P)]), R = [P].concat(ee).reduce(function(J, Ce) {
                        return J.concat(He(Ce) === gn ? Ri(t, {
                            placement: Ce,
                            boundary: O,
                            rootBoundary: k,
                            padding: D,
                            flipVariations: N,
                            allowedAutoPlacements: Y
                        }) : Ce)
                    }, []), z = t.rects.reference, W = t.rects.popper, H = new Map, Z = !0, Q = R[0], K = 0; K < R.length; K++) {
                    var ae = R[K],
                        Ue = He(ae),
                        gt = Pt(ae) === vt,
                        xe = [_e, ge].indexOf(Ue) >= 0,
                        tt = xe ? "width" : "height",
                        nt = ft(t, {
                            placement: ae,
                            boundary: O,
                            rootBoundary: k,
                            altBoundary: L,
                            padding: D
                        }),
                        oe = xe ? gt ? ye : de : gt ? ge : _e;
                    z[tt] > W[tt] && (oe = ht(oe));
                    var Ot = ht(oe),
                        Mt = [];
                    if (u && Mt.push(nt[Ue] <= 0), _ && Mt.push(nt[oe] <= 0, nt[Ot] <= 0), Mt.every(function(J) {
                            return J
                        })) {
                        Q = ae, Z = !1;
                        break
                    }
                    H.set(ae, Mt)
                }
                if (Z)
                    for (var ni = function(J) {
                            var Ce = R.find(function(it) {
                                var on = H.get(it);
                                if (on) return on.slice(0, J).every(function(Gi) {
                                    return Gi
                                })
                            });
                            if (Ce) return Q = Ce, "break"
                        }, fe = N ? 3 : 1; fe > 0 && ni(fe) !== "break"; fe--);
                t.placement !== Q && (t.modifiersData[a]._skip = !0, t.placement = Q, t.reset = !0)
            }
        },
        requiresIfExists: ["offset"],
        data: {
            _skip: !1
        }
    };

    function Xe(o, t, s) {
        return s === void 0 && (s = {
            x: 0,
            y: 0
        }), {
            top: o.top - t.height - s.y,
            right: o.right - t.width + s.x,
            bottom: o.bottom - t.height + s.y,
            left: o.left - t.width - s.x
        }
    }

    function pi(o) {
        return [_e, ye, ge, de].some(function(t) {
            return o[t] >= 0
        })
    }
    const _i = {
            name: "hide",
            enabled: !0,
            phase: "main",
            requiresIfExists: ["preventOverflow"],
            fn: function(o) {
                var t = o.state,
                    s = o.name,
                    a = t.rects.reference,
                    c = t.rects.popper,
                    u = t.modifiersData.preventOverflow,
                    f = ft(t, {
                        elementContext: "reference"
                    }),
                    _ = ft(t, {
                        altBoundary: !0
                    }),
                    w = Xe(f, a),
                    D = Xe(_, c, u),
                    O = pi(w),
                    k = pi(D);
                t.modifiersData[s] = {
                    referenceClippingOffsets: w,
                    popperEscapeOffsets: D,
                    isReferenceHidden: O,
                    hasPopperEscaped: k
                }, t.attributes.popper = Object.assign({}, t.attributes.popper, {
                    "data-popper-reference-hidden": O,
                    "data-popper-escaped": k
                })
            }
        },
        gi = {
            name: "offset",
            enabled: !0,
            phase: "main",
            requires: ["popperOffsets"],
            fn: function(o) {
                var t = o.state,
                    s = o.options,
                    a = o.name,
                    c = s.offset,
                    u = c === void 0 ? [0, 0] : c,
                    f = vn.reduce(function(O, k) {
                        return O[k] = (function(L, E, N) {
                            var Y = He(L),
                                P = [de, _e].indexOf(Y) >= 0 ? -1 : 1,
                                X = typeof N == "function" ? N(Object.assign({}, E, {
                                    placement: L
                                })) : N,
                                ee = X[0],
                                R = X[1];
                            return ee = ee || 0, R = (R || 0) * P, [de, ye].indexOf(Y) >= 0 ? {
                                x: R,
                                y: ee
                            } : {
                                x: ee,
                                y: R
                            }
                        })(k, t.rects, u), O
                    }, {}),
                    _ = f[t.placement],
                    w = _.x,
                    D = _.y;
                t.modifiersData.popperOffsets != null && (t.modifiersData.popperOffsets.x += w, t.modifiersData.popperOffsets.y += D), t.modifiersData[a] = f
            }
        },
        Cn = {
            name: "popperOffsets",
            enabled: !0,
            phase: "read",
            fn: function(o) {
                var t = o.state,
                    s = o.name;
                t.modifiersData[s] = mi({
                    reference: t.rects.reference,
                    element: t.rects.popper,
                    placement: t.placement
                })
            },
            data: {}
        },
        Qe = {
            name: "preventOverflow",
            enabled: !0,
            phase: "main",
            fn: function(o) {
                var t = o.state,
                    s = o.options,
                    a = o.name,
                    c = s.mainAxis,
                    u = c === void 0 || c,
                    f = s.altAxis,
                    _ = f !== void 0 && f,
                    w = s.boundary,
                    D = s.rootBoundary,
                    O = s.altBoundary,
                    k = s.padding,
                    L = s.tether,
                    E = L === void 0 || L,
                    N = s.tetherOffset,
                    Y = N === void 0 ? 0 : N,
                    P = ft(t, {
                        boundary: w,
                        rootBoundary: D,
                        padding: k,
                        altBoundary: O
                    }),
                    X = He(t.placement),
                    ee = Pt(t.placement),
                    R = !ee,
                    z = ci(X),
                    W = z === "x" ? "y" : "x",
                    H = t.modifiersData.popperOffsets,
                    Z = t.rects.reference,
                    Q = t.rects.popper,
                    K = typeof Y == "function" ? Y(Object.assign({}, t.rects, {
                        placement: t.placement
                    })) : Y,
                    ae = typeof K == "number" ? {
                        mainAxis: K,
                        altAxis: K
                    } : Object.assign({
                        mainAxis: 0,
                        altAxis: 0
                    }, K),
                    Ue = t.modifiersData.offset ? t.modifiersData.offset[t.placement] : null,
                    gt = {
                        x: 0,
                        y: 0
                    };
                if (H) {
                    if (u) {
                        var xe, tt = z === "y" ? _e : de,
                            nt = z === "y" ? ge : ye,
                            oe = z === "y" ? "height" : "width",
                            Ot = H[z],
                            Mt = Ot + P[tt],
                            ni = Ot - P[nt],
                            fe = E ? -Q[oe] / 2 : 0,
                            J = ee === vt ? Z[oe] : Q[oe],
                            Ce = ee === vt ? -Q[oe] : -Z[oe],
                            it = t.elements.arrow,
                            on = E && it ? Dn(it) : {
                                width: 0,
                                height: 0
                            },
                            Gi = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : {
                                top: 0,
                                right: 0,
                                bottom: 0,
                                left: 0
                            },
                            Zs = Gi[tt],
                            Ks = Gi[nt],
                            Bi = ve(0, Z[oe], on[oe]),
                            ko = R ? Z[oe] / 2 - fe - Bi - Zs - ae.mainAxis : J - Bi - Zs - ae.mainAxis,
                            So = R ? -Z[oe] / 2 + fe + Bi + Ks + ae.mainAxis : Ce + Bi + Ks + ae.mainAxis,
                            ms = t.elements.arrow && On(t.elements.arrow),
                            Do = ms ? z === "y" ? ms.clientTop || 0 : ms.clientLeft || 0 : 0,
                            Xs = (xe = Ue ? .[z]) != null ? xe : 0,
                            Oo = Ot + So - Xs,
                            Qs = ve(E ? B(Mt, Ot + ko - Xs - Do) : Mt, Ot, E ? wt(ni, Oo) : ni);
                        H[z] = Qs, gt[z] = Qs - Ot
                    }
                    if (_) {
                        var Js, Mo = z === "x" ? _e : de,
                            To = z === "x" ? ge : ye,
                            Wn = H[W],
                            qi = W === "y" ? "height" : "width",
                            er = Wn + P[Mo],
                            tr = Wn - P[To],
                            ps = [_e, de].indexOf(X) !== -1,
                            nr = (Js = Ue ? .[W]) != null ? Js : 0,
                            ir = ps ? er : Wn - Z[qi] - Q[qi] - nr + ae.altAxis,
                            sr = ps ? Wn + Z[qi] + Q[qi] - nr - ae.altAxis : tr,
                            rr = E && ps ? (function(xo, Co, _s) {
                                var or = ve(xo, Co, _s);
                                return or > _s ? _s : or
                            })(ir, Wn, sr) : ve(E ? ir : er, Wn, E ? sr : tr);
                        H[W] = rr, gt[W] = rr - Wn
                    }
                    t.modifiersData[a] = gt
                }
            },
            requiresIfExists: ["offset"]
        };

    function Lt(o, t, s) {
        s === void 0 && (s = !1);
        var a, c, u = ce(t),
            f = ce(t) && (function(k) {
                var L = k.getBoundingClientRect(),
                    E = Yt(L.width) / k.offsetWidth || 1,
                    N = Yt(L.height) / k.offsetHeight || 1;
                return E !== 1 || N !== 1
            })(t),
            _ = Ke(t),
            w = ct(o, f, s),
            D = {
                scrollLeft: 0,
                scrollTop: 0
            },
            O = {
                x: 0,
                y: 0
            };
        return (u || !u && !s) && ((Fe(t) !== "body" || nn(_)) && (D = (a = t) !== Te(a) && ce(a) ? {
            scrollLeft: (c = a).scrollLeft,
            scrollTop: c.scrollTop
        } : Tn(a)), ce(t) ? ((O = ct(t, !0)).x += t.clientLeft, O.y += t.clientTop) : _ && (O.x = xn(_))), {
            x: w.left + D.scrollLeft - O.x,
            y: w.top + D.scrollTop - O.y,
            width: w.width,
            height: w.height
        }
    }

    function St(o) {
        var t = new Map,
            s = new Set,
            a = [];

        function c(u) {
            s.add(u.name), [].concat(u.requires || [], u.requiresIfExists || []).forEach(function(f) {
                if (!s.has(f)) {
                    var _ = t.get(f);
                    _ && c(_)
                }
            }), a.push(u)
        }
        return o.forEach(function(u) {
            t.set(u.name, u)
        }), o.forEach(function(u) {
            s.has(u.name) || c(u)
        }), a
    }
    var mt = {
        placement: "bottom",
        modifiers: [],
        strategy: "absolute"
    };

    function pt() {
        for (var o = arguments.length, t = new Array(o), s = 0; s < o; s++) t[s] = arguments[s];
        return !t.some(function(a) {
            return !(a && typeof a.getBoundingClientRect == "function")
        })
    }

    function It(o) {
        o === void 0 && (o = {});
        var t = o,
            s = t.defaultModifiers,
            a = s === void 0 ? [] : s,
            c = t.defaultOptions,
            u = c === void 0 ? mt : c;
        return function(f, _, w) {
            w === void 0 && (w = u);
            var D, O, k = {
                    placement: "bottom",
                    orderedModifiers: [],
                    options: Object.assign({}, mt, u),
                    modifiersData: {},
                    elements: {
                        reference: f,
                        popper: _
                    },
                    attributes: {},
                    styles: {}
                },
                L = [],
                E = !1,
                N = {
                    state: k,
                    setOptions: function(P) {
                        var X = typeof P == "function" ? P(k.options) : P;
                        Y(), k.options = Object.assign({}, u, k.options, X), k.scrollParents = {
                            reference: bt(f) ? Ne(f) : f.contextElement ? Ne(f.contextElement) : [],
                            popper: Ne(_)
                        };
                        var ee, R, z = (function(W) {
                            var H = St(W);
                            return Ni.reduce(function(Z, Q) {
                                return Z.concat(H.filter(function(K) {
                                    return K.phase === Q
                                }))
                            }, [])
                        })((ee = [].concat(a, k.options.modifiers), R = ee.reduce(function(W, H) {
                            var Z = W[H.name];
                            return W[H.name] = Z ? Object.assign({}, Z, H, {
                                options: Object.assign({}, Z.options, H.options),
                                data: Object.assign({}, Z.data, H.data)
                            }) : H, W
                        }, {}), Object.keys(R).map(function(W) {
                            return R[W]
                        })));
                        return k.orderedModifiers = z.filter(function(W) {
                            return W.enabled
                        }), k.orderedModifiers.forEach(function(W) {
                            var H = W.name,
                                Z = W.options,
                                Q = Z === void 0 ? {} : Z,
                                K = W.effect;
                            if (typeof K == "function") {
                                var ae = K({
                                    state: k,
                                    name: H,
                                    instance: N,
                                    options: Q
                                });
                                L.push(ae || function() {})
                            }
                        }), N.update()
                    },
                    forceUpdate: function() {
                        if (!E) {
                            var P = k.elements,
                                X = P.reference,
                                ee = P.popper;
                            if (pt(X, ee)) {
                                k.rects = {
                                    reference: Lt(X, On(ee), k.options.strategy === "fixed"),
                                    popper: Dn(ee)
                                }, k.reset = !1, k.placement = k.options.placement, k.orderedModifiers.forEach(function(K) {
                                    return k.modifiersData[K.name] = Object.assign({}, K.data)
                                });
                                for (var R = 0; R < k.orderedModifiers.length; R++)
                                    if (k.reset !== !0) {
                                        var z = k.orderedModifiers[R],
                                            W = z.fn,
                                            H = z.options,
                                            Z = H === void 0 ? {} : H,
                                            Q = z.name;
                                        typeof W == "function" && (k = W({
                                            state: k,
                                            options: Z,
                                            name: Q,
                                            instance: N
                                        }) || k)
                                    } else k.reset = !1, R = -1
                            }
                        }
                    },
                    update: (D = function() {
                        return new Promise(function(P) {
                            N.forceUpdate(), P(k)
                        })
                    }, function() {
                        return O || (O = new Promise(function(P) {
                            Promise.resolve().then(function() {
                                O = void 0, P(D())
                            })
                        })), O
                    }),
                    destroy: function() {
                        Y(), E = !0
                    }
                };
            if (!pt(f, _)) return N;

            function Y() {
                L.forEach(function(P) {
                    return P()
                }), L = []
            }
            return N.setOptions(w).then(function(P) {
                !E && w.onFirstUpdate && w.onFirstUpdate(P)
            }), N
        }
    }
    var I = It(),
        ns = It({
            defaultModifiers: [Jn, Cn, tn, kn]
        }),
        yi = It({
            defaultModifiers: [Jn, Cn, tn, kn, gi, ei, Qe, hi, _i]
        });
    const Je = Object.freeze(Object.defineProperty({
            __proto__: null,
            afterMain: bn,
            afterRead: xi,
            afterWrite: Yi,
            applyStyles: kn,
            arrow: hi,
            auto: gn,
            basePlacements: Be,
            beforeMain: Ci,
            beforeRead: Ze,
            beforeWrite: Qn,
            bottom: ge,
            clippingParents: Qt,
            computeStyles: tn,
            createPopper: yi,
            createPopperBase: I,
            createPopperLite: ns,
            detectOverflow: ft,
            end: V,
            eventListeners: Jn,
            flip: ei,
            hide: _i,
            left: de,
            main: Ei,
            modifierPhases: Ni,
            offset: gi,
            placements: vn,
            popper: Jt,
            popperGenerator: It,
            popperOffsets: Cn,
            preventOverflow: Qe,
            read: Xn,
            reference: yn,
            right: ye,
            start: vt,
            top: _e,
            variationPlacements: qe,
            viewport: Kn,
            write: Ai
        }, Symbol.toStringTag, {
            value: "Module"
        })),
        Wt = "dropdown",
        jt = ".bs.dropdown",
        En = ".data-api",
        sn = "ArrowUp",
        An = "ArrowDown",
        F = `hide${jt}`,
        e = `hidden${jt}`,
        n = `show${jt}`,
        i = `shown${jt}`,
        r = `click${jt}${En}`,
        l = `keydown${jt}${En}`,
        h = `keyup${jt}${En}`,
        d = "show",
        m = '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)',
        v = `${m}.${d}`,
        y = ".dropdown-menu",
        x = Ee() ? "top-end" : "top-start",
        C = Ee() ? "top-start" : "top-end",
        q = Ee() ? "bottom-end" : "bottom-start",
        re = Ee() ? "bottom-start" : "bottom-end",
        $e = Ee() ? "left-start" : "right-start",
        Dt = Ee() ? "right-start" : "left-start",
        ar = {
            autoClose: !0,
            boundary: "clippingParents",
            display: "dynamic",
            offset: [0, 2],
            popperConfig: null,
            reference: "toggle"
        },
        lr = {
            autoClose: "(boolean|string)",
            boundary: "(string|element)",
            display: "string",
            offset: "(array|string|function)",
            popperConfig: "(null|object|function)",
            reference: "(string|element|object)"
        };
    class _t extends me {
        constructor(t, s) {
            super(t, s), this._popper = null, this._parent = this._element.parentNode, this._menu = T.next(this._element, y)[0] || T.prev(this._element, y)[0] || T.findOne(y, this._parent), this._inNavbar = this._detectNavbar()
        }
        static get Default() {
            return ar
        }
        static get DefaultType() {
            return lr
        }
        static get NAME() {
            return Wt
        }
        toggle() {
            return this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (st(this._element) || this._isShown()) return;
            const t = {
                relatedTarget: this._element
            };
            if (!p.trigger(this._element, n, t).defaultPrevented) {
                if (this._createPopper(), "ontouchstart" in document.documentElement && !this._parent.closest(".navbar-nav"))
                    for (const s of [].concat(...document.body.children)) p.on(s, "mouseover", Oe);
                this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add(d), this._element.classList.add(d), p.trigger(this._element, i, t)
            }
        }
        hide() {
            if (st(this._element) || !this._isShown()) return;
            const t = {
                relatedTarget: this._element
            };
            this._completeHide(t)
        }
        dispose() {
            this._popper && this._popper.destroy(), super.dispose()
        }
        update() {
            this._inNavbar = this._detectNavbar(), this._popper && this._popper.update()
        }
        _completeHide(t) {
            if (!p.trigger(this._element, F, t).defaultPrevented) {
                if ("ontouchstart" in document.documentElement)
                    for (const s of [].concat(...document.body.children)) p.off(s, "mouseover", Oe);
                this._popper && this._popper.destroy(), this._menu.classList.remove(d), this._element.classList.remove(d), this._element.setAttribute("aria-expanded", "false"), We.removeDataAttribute(this._menu, "popper"), p.trigger(this._element, e, t)
            }
        }
        _getConfig(t) {
            if (typeof(t = super._getConfig(t)).reference == "object" && !te(t.reference) && typeof t.reference.getBoundingClientRect != "function") throw new TypeError(`${Wt.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
            return t
        }
        _createPopper() {
            if (Je === void 0) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)");
            let t = this._element;
            this._config.reference === "parent" ? t = this._parent : te(this._config.reference) ? t = ue(this._config.reference) : typeof this._config.reference == "object" && (t = this._config.reference);
            const s = this._getPopperConfig();
            this._popper = yi(t, this._menu, s)
        }
        _isShown() {
            return this._menu.classList.contains(d)
        }
        _getPlacement() {
            const t = this._parent;
            if (t.classList.contains("dropend")) return $e;
            if (t.classList.contains("dropstart")) return Dt;
            if (t.classList.contains("dropup-center")) return "top";
            if (t.classList.contains("dropdown-center")) return "bottom";
            const s = getComputedStyle(this._menu).getPropertyValue("--bs-position").trim() === "end";
            return t.classList.contains("dropup") ? s ? C : x : s ? re : q
        }
        _detectNavbar() {
            return this._element.closest(".navbar") !== null
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return typeof t == "string" ? t.split(",").map(s => Number.parseInt(s, 10)) : typeof t == "function" ? s => t(s, this._element) : t
        }
        _getPopperConfig() {
            const t = {
                placement: this._getPlacement(),
                modifiers: [{
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }]
            };
            return (this._inNavbar || this._config.display === "static") && (We.setDataAttribute(this._menu, "popper", "static"), t.modifiers = [{
                name: "applyStyles",
                enabled: !1
            }]), { ...t,
                ...he(this._config.popperConfig, [void 0, t])
            }
        }
        _selectMenuItem({
            key: t,
            target: s
        }) {
            const a = T.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter(c => Ve(c));
            a.length && Tt(a, s, t === An, !a.includes(s)).focus()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = _t.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (s[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
        static clearMenus(t) {
            if (t.button === 2 || t.type === "keyup" && t.key !== "Tab") return;
            const s = T.find(v);
            for (const a of s) {
                const c = _t.getInstance(a);
                if (!c || c._config.autoClose === !1) continue;
                const u = t.composedPath(),
                    f = u.includes(c._menu);
                if (u.includes(c._element) || c._config.autoClose === "inside" && !f || c._config.autoClose === "outside" && f || c._menu.contains(t.target) && (t.type === "keyup" && t.key === "Tab" || /input|select|option|textarea|form/i.test(t.target.tagName))) continue;
                const _ = {
                    relatedTarget: c._element
                };
                t.type === "click" && (_.clickEvent = t), c._completeHide(_)
            }
        }
        static dataApiKeydownHandler(t) {
            const s = /input|textarea/i.test(t.target.tagName),
                a = t.key === "Escape",
                c = [sn, An].includes(t.key);
            if (!c && !a || s && !a) return;
            t.preventDefault();
            const u = this.matches(m) ? this : T.prev(this, m)[0] || T.next(this, m)[0] || T.findOne(m, t.delegateTarget.parentNode),
                f = _t.getOrCreateInstance(u);
            if (c) return t.stopPropagation(), f.show(), void f._selectMenuItem(t);
            f._isShown() && (t.stopPropagation(), f.hide(), u.focus())
        }
    }
    p.on(document, l, m, _t.dataApiKeydownHandler), p.on(document, l, y, _t.dataApiKeydownHandler), p.on(document, r, _t.clearMenus), p.on(document, h, _t.clearMenus), p.on(document, r, m, function(o) {
        o.preventDefault(), _t.getOrCreateInstance(this).toggle()
    }), Me(_t);
    const gs = "backdrop",
        ys = "show",
        vs = `mousedown.bs.${gs}`,
        cr = {
            className: "modal-backdrop",
            clickCallback: null,
            isAnimated: !1,
            isVisible: !0,
            rootElement: "body"
        },
        ur = {
            className: "string",
            clickCallback: "(function|null)",
            isAnimated: "boolean",
            isVisible: "boolean",
            rootElement: "(element|string)"
        };
    class bs extends cn {
        constructor(t) {
            super(), this._config = this._getConfig(t), this._isAppended = !1, this._element = null
        }
        static get Default() {
            return cr
        }
        static get DefaultType() {
            return ur
        }
        static get NAME() {
            return gs
        }
        show(t) {
            if (!this._config.isVisible) return void he(t);
            this._append();
            const s = this._getElement();
            this._config.isAnimated && A(s), s.classList.add(ys), this._emulateAnimation(() => {
                he(t)
            })
        }
        hide(t) {
            this._config.isVisible ? (this._getElement().classList.remove(ys), this._emulateAnimation(() => {
                this.dispose(), he(t)
            })) : he(t)
        }
        dispose() {
            this._isAppended && (p.off(this._element, vs), this._element.remove(), this._isAppended = !1)
        }
        _getElement() {
            if (!this._element) {
                const t = document.createElement("div");
                t.className = this._config.className, this._config.isAnimated && t.classList.add("fade"), this._element = t
            }
            return this._element
        }
        _configAfterMerge(t) {
            return t.rootElement = ue(t.rootElement), t
        }
        _append() {
            if (this._isAppended) return;
            const t = this._getElement();
            this._config.rootElement.append(t), p.on(t, vs, () => {
                he(this._config.clickCallback)
            }), this._isAppended = !0
        }
        _emulateAnimation(t) {
            Fn(t, this._getElement(), this._config.isAnimated)
        }
    }
    const Fi = ".bs.focustrap",
        hr = `focusin${Fi}`,
        dr = `keydown.tab${Fi}`,
        ws = "backward",
        fr = {
            autofocus: !0,
            trapElement: null
        },
        mr = {
            autofocus: "boolean",
            trapElement: "element"
        };
    class ks extends cn {
        constructor(t) {
            super(), this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null
        }
        static get Default() {
            return fr
        }
        static get DefaultType() {
            return mr
        }
        static get NAME() {
            return "focustrap"
        }
        activate() {
            this._isActive || (this._config.autofocus && this._config.trapElement.focus(), p.off(document, Fi), p.on(document, hr, t => this._handleFocusin(t)), p.on(document, dr, t => this._handleKeydown(t)), this._isActive = !0)
        }
        deactivate() {
            this._isActive && (this._isActive = !1, p.off(document, Fi))
        }
        _handleFocusin(t) {
            const {
                trapElement: s
            } = this._config;
            if (t.target === document || t.target === s || s.contains(t.target)) return;
            const a = T.focusableChildren(s);
            a.length === 0 ? s.focus() : this._lastTabNavDirection === ws ? a[a.length - 1].focus() : a[0].focus()
        }
        _handleKeydown(t) {
            t.key === "Tab" && (this._lastTabNavDirection = t.shiftKey ? ws : "forward")
        }
    }
    const Ss = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
        Ds = ".sticky-top",
        Hi = "padding-right",
        Os = "margin-right";
    class is {
        constructor() {
            this._element = document.body
        }
        getWidth() {
            const t = document.documentElement.clientWidth;
            return Math.abs(window.innerWidth - t)
        }
        hide() {
            const t = this.getWidth();
            this._disableOverFlow(), this._setElementAttributes(this._element, Hi, s => s + t), this._setElementAttributes(Ss, Hi, s => s + t), this._setElementAttributes(Ds, Os, s => s - t)
        }
        reset() {
            this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, Hi), this._resetElementAttributes(Ss, Hi), this._resetElementAttributes(Ds, Os)
        }
        isOverflowing() {
            return this.getWidth() > 0
        }
        _disableOverFlow() {
            this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden"
        }
        _setElementAttributes(t, s, a) {
            const c = this.getWidth();
            this._applyManipulationCallback(t, u => {
                if (u !== this._element && window.innerWidth > u.clientWidth + c) return;
                this._saveInitialAttribute(u, s);
                const f = window.getComputedStyle(u).getPropertyValue(s);
                u.style.setProperty(s, `${a(Number.parseFloat(f))}px`)
            })
        }
        _saveInitialAttribute(t, s) {
            const a = t.style.getPropertyValue(s);
            a && We.setDataAttribute(t, s, a)
        }
        _resetElementAttributes(t, s) {
            this._applyManipulationCallback(t, a => {
                const c = We.getDataAttribute(a, s);
                c !== null ? (We.removeDataAttribute(a, s), a.style.setProperty(s, c)) : a.style.removeProperty(s)
            })
        }
        _applyManipulationCallback(t, s) {
            if (te(t)) s(t);
            else
                for (const a of T.find(t, this._element)) s(a)
        }
    }
    const et = ".bs.modal",
        pr = `hide${et}`,
        _r = `hidePrevented${et}`,
        Ms = `hidden${et}`,
        Ts = `show${et}`,
        gr = `shown${et}`,
        yr = `resize${et}`,
        vr = `click.dismiss${et}`,
        br = `mousedown.dismiss${et}`,
        wr = `keydown.dismiss${et}`,
        kr = `click${et}.data-api`,
        xs = "modal-open",
        Cs = "show",
        ss = "modal-static",
        Sr = {
            backdrop: !0,
            focus: !0,
            keyboard: !0
        },
        Dr = {
            backdrop: "(boolean|string)",
            focus: "boolean",
            keyboard: "boolean"
        };
    class Yn extends me {
        constructor(t, s) {
            super(t, s), this._dialog = T.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._isTransitioning = !1, this._scrollBar = new is, this._addEventListeners()
        }
        static get Default() {
            return Sr
        }
        static get DefaultType() {
            return Dr
        }
        static get NAME() {
            return "modal"
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || this._isTransitioning || p.trigger(this._element, Ts, {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._isTransitioning = !0, this._scrollBar.hide(), document.body.classList.add(xs), this._adjustDialog(), this._backdrop.show(() => this._showElement(t)))
        }
        hide() {
            this._isShown && !this._isTransitioning && (p.trigger(this._element, pr).defaultPrevented || (this._isShown = !1, this._isTransitioning = !0, this._focustrap.deactivate(), this._element.classList.remove(Cs), this._queueCallback(() => this._hideModal(), this._element, this._isAnimated())))
        }
        dispose() {
            p.off(window, et), p.off(this._dialog, et), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        handleUpdate() {
            this._adjustDialog()
        }
        _initializeBackDrop() {
            return new bs({
                isVisible: !!this._config.backdrop,
                isAnimated: this._isAnimated()
            })
        }
        _initializeFocusTrap() {
            return new ks({
                trapElement: this._element
            })
        }
        _showElement(t) {
            document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
            const s = T.findOne(".modal-body", this._dialog);
            s && (s.scrollTop = 0), A(this._element), this._element.classList.add(Cs), this._queueCallback(() => {
                this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, p.trigger(this._element, gr, {
                    relatedTarget: t
                })
            }, this._dialog, this._isAnimated())
        }
        _addEventListeners() {
            p.on(this._element, wr, t => {
                t.key === "Escape" && (this._config.keyboard ? this.hide() : this._triggerBackdropTransition())
            }), p.on(window, yr, () => {
                this._isShown && !this._isTransitioning && this._adjustDialog()
            }), p.on(this._element, br, t => {
                p.one(this._element, vr, s => {
                    this._element === t.target && this._element === s.target && (this._config.backdrop !== "static" ? this._config.backdrop && this.hide() : this._triggerBackdropTransition())
                })
            })
        }
        _hideModal() {
            this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
                document.body.classList.remove(xs), this._resetAdjustments(), this._scrollBar.reset(), p.trigger(this._element, Ms)
            })
        }
        _isAnimated() {
            return this._element.classList.contains("fade")
        }
        _triggerBackdropTransition() {
            if (p.trigger(this._element, _r).defaultPrevented) return;
            const t = this._element.scrollHeight > document.documentElement.clientHeight,
                s = this._element.style.overflowY;
            s === "hidden" || this._element.classList.contains(ss) || (t || (this._element.style.overflowY = "hidden"), this._element.classList.add(ss), this._queueCallback(() => {
                this._element.classList.remove(ss), this._queueCallback(() => {
                    this._element.style.overflowY = s
                }, this._dialog)
            }, this._dialog), this._element.focus())
        }
        _adjustDialog() {
            const t = this._element.scrollHeight > document.documentElement.clientHeight,
                s = this._scrollBar.getWidth(),
                a = s > 0;
            if (a && !t) {
                const c = Ee() ? "paddingLeft" : "paddingRight";
                this._element.style[c] = `${s}px`
            }
            if (!a && t) {
                const c = Ee() ? "paddingRight" : "paddingLeft";
                this._element.style[c] = `${s}px`
            }
        }
        _resetAdjustments() {
            this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
        }
        static jQueryInterface(t, s) {
            return this.each(function() {
                const a = Yn.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (a[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    a[t](s)
                }
            })
        }
    }
    p.on(document, kr, '[data-bs-toggle="modal"]', function(o) {
        const t = T.getElementFromSelector(this);
        ["A", "AREA"].includes(this.tagName) && o.preventDefault(), p.one(t, Ts, a => {
            a.defaultPrevented || p.one(t, Ms, () => {
                Ve(this) && this.focus()
            })
        });
        const s = T.findOne(".modal.show");
        s && Yn.getInstance(s).hide(), Yn.getOrCreateInstance(t).toggle(this)
    }), G(Yn), Me(Yn);
    const Rt = ".bs.offcanvas",
        Es = ".data-api",
        Or = `load${Rt}${Es}`,
        As = "show",
        Ys = "showing",
        Ns = "hiding",
        Ps = ".offcanvas.show",
        Mr = `show${Rt}`,
        Tr = `shown${Rt}`,
        xr = `hide${Rt}`,
        Ls = `hidePrevented${Rt}`,
        Is = `hidden${Rt}`,
        Cr = `resize${Rt}`,
        Er = `click${Rt}${Es}`,
        Ar = `keydown.dismiss${Rt}`,
        Yr = {
            backdrop: !0,
            keyboard: !0,
            scroll: !1
        },
        Nr = {
            backdrop: "(boolean|string)",
            keyboard: "boolean",
            scroll: "boolean"
        };
    class Ft extends me {
        constructor(t, s) {
            super(t, s), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners()
        }
        static get Default() {
            return Yr
        }
        static get DefaultType() {
            return Nr
        }
        static get NAME() {
            return "offcanvas"
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || p.trigger(this._element, Mr, {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._backdrop.show(), this._config.scroll || new is().hide(), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add(Ys), this._queueCallback(() => {
                this._config.scroll && !this._config.backdrop || this._focustrap.activate(), this._element.classList.add(As), this._element.classList.remove(Ys), p.trigger(this._element, Tr, {
                    relatedTarget: t
                })
            }, this._element, !0))
        }
        hide() {
            this._isShown && (p.trigger(this._element, xr).defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.add(Ns), this._backdrop.hide(), this._queueCallback(() => {
                this._element.classList.remove(As, Ns), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._config.scroll || new is().reset(), p.trigger(this._element, Is)
            }, this._element, !0)))
        }
        dispose() {
            this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        _initializeBackDrop() {
            const t = !!this._config.backdrop;
            return new bs({
                className: "offcanvas-backdrop",
                isVisible: t,
                isAnimated: !0,
                rootElement: this._element.parentNode,
                clickCallback: t ? () => {
                    this._config.backdrop !== "static" ? this.hide() : p.trigger(this._element, Ls)
                } : null
            })
        }
        _initializeFocusTrap() {
            return new ks({
                trapElement: this._element
            })
        }
        _addEventListeners() {
            p.on(this._element, Ar, t => {
                t.key === "Escape" && (this._config.keyboard ? this.hide() : p.trigger(this._element, Ls))
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Ft.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (s[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                    s[t](this)
                }
            })
        }
    }
    p.on(document, Er, '[data-bs-toggle="offcanvas"]', function(o) {
        const t = T.getElementFromSelector(this);
        if (["A", "AREA"].includes(this.tagName) && o.preventDefault(), st(this)) return;
        p.one(t, Is, () => {
            Ve(this) && this.focus()
        });
        const s = T.findOne(Ps);
        s && s !== t && Ft.getInstance(s).hide(), Ft.getOrCreateInstance(t).toggle(this)
    }), p.on(window, Or, () => {
        for (const o of T.find(Ps)) Ft.getOrCreateInstance(o).show()
    }), p.on(window, Cr, () => {
        for (const o of T.find("[aria-modal][class*=show][class*=offcanvas-]")) getComputedStyle(o).position !== "fixed" && Ft.getOrCreateInstance(o).hide()
    }), G(Ft), Me(Ft);
    const Ws = {
            "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
            a: ["target", "href", "title", "rel"],
            area: [],
            b: [],
            br: [],
            col: [],
            code: [],
            dd: [],
            div: [],
            dl: [],
            dt: [],
            em: [],
            hr: [],
            h1: [],
            h2: [],
            h3: [],
            h4: [],
            h5: [],
            h6: [],
            i: [],
            img: ["src", "srcset", "alt", "title", "width", "height"],
            li: [],
            ol: [],
            p: [],
            pre: [],
            s: [],
            small: [],
            span: [],
            sub: [],
            sup: [],
            strong: [],
            u: [],
            ul: []
        },
        Pr = new Set(["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]),
        Lr = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i,
        Ir = (o, t) => {
            const s = o.nodeName.toLowerCase();
            return t.includes(s) ? !Pr.has(s) || !!Lr.test(o.nodeValue) : t.filter(a => a instanceof RegExp).some(a => a.test(s))
        },
        Wr = {
            allowList: Ws,
            content: {},
            extraClass: "",
            html: !1,
            sanitize: !0,
            sanitizeFn: null,
            template: "<div></div>"
        },
        jr = {
            allowList: "object",
            content: "object",
            extraClass: "(string|function)",
            html: "boolean",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            template: "string"
        },
        Rr = {
            entry: "(string|element|function|null)",
            selector: "(string|element)"
        };
    class Fr extends cn {
        constructor(t) {
            super(), this._config = this._getConfig(t)
        }
        static get Default() {
            return Wr
        }
        static get DefaultType() {
            return jr
        }
        static get NAME() {
            return "TemplateFactory"
        }
        getContent() {
            return Object.values(this._config.content).map(t => this._resolvePossibleFunction(t)).filter(Boolean)
        }
        hasContent() {
            return this.getContent().length > 0
        }
        changeContent(t) {
            return this._checkContent(t), this._config.content = { ...this._config.content,
                ...t
            }, this
        }
        toHtml() {
            const t = document.createElement("div");
            t.innerHTML = this._maybeSanitize(this._config.template);
            for (const [c, u] of Object.entries(this._config.content)) this._setContent(t, u, c);
            const s = t.children[0],
                a = this._resolvePossibleFunction(this._config.extraClass);
            return a && s.classList.add(...a.split(" ")), s
        }
        _typeCheckConfig(t) {
            super._typeCheckConfig(t), this._checkContent(t.content)
        }
        _checkContent(t) {
            for (const [s, a] of Object.entries(t)) super._typeCheckConfig({
                selector: s,
                entry: a
            }, Rr)
        }
        _setContent(t, s, a) {
            const c = T.findOne(a, t);
            c && ((s = this._resolvePossibleFunction(s)) ? te(s) ? this._putElementInTemplate(ue(s), c) : this._config.html ? c.innerHTML = this._maybeSanitize(s) : c.textContent = s : c.remove())
        }
        _maybeSanitize(t) {
            return this._config.sanitize ? (function(s, a, c) {
                if (!s.length) return s;
                if (c && typeof c == "function") return c(s);
                const u = new window.DOMParser().parseFromString(s, "text/html"),
                    f = [].concat(...u.body.querySelectorAll("*"));
                for (const _ of f) {
                    const w = _.nodeName.toLowerCase();
                    if (!Object.keys(a).includes(w)) {
                        _.remove();
                        continue
                    }
                    const D = [].concat(..._.attributes),
                        O = [].concat(a["*"] || [], a[w] || []);
                    for (const k of D) Ir(k, O) || _.removeAttribute(k.nodeName)
                }
                return u.body.innerHTML
            })(t, this._config.allowList, this._config.sanitizeFn) : t
        }
        _resolvePossibleFunction(t) {
            return he(t, [void 0, this])
        }
        _putElementInTemplate(t, s) {
            if (this._config.html) return s.innerHTML = "", void s.append(t);
            s.textContent = t.textContent
        }
    }
    const Hr = new Set(["sanitize", "allowList", "sanitizeFn"]),
        rs = "fade",
        $i = "show",
        $r = ".tooltip-inner",
        js = ".modal",
        Rs = "hide.bs.modal",
        vi = "hover",
        os = "focus",
        as = "click",
        Ur = {
            AUTO: "auto",
            TOP: "top",
            RIGHT: Ee() ? "left" : "right",
            BOTTOM: "bottom",
            LEFT: Ee() ? "right" : "left"
        },
        Vr = {
            allowList: Ws,
            animation: !0,
            boundary: "clippingParents",
            container: !1,
            customClass: "",
            delay: 0,
            fallbackPlacements: ["top", "right", "bottom", "left"],
            html: !1,
            offset: [0, 6],
            placement: "top",
            popperConfig: null,
            sanitize: !0,
            sanitizeFn: null,
            selector: !1,
            template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
            title: "",
            trigger: "hover focus"
        },
        zr = {
            allowList: "object",
            animation: "boolean",
            boundary: "(string|element)",
            container: "(string|element|boolean)",
            customClass: "(string|function)",
            delay: "(number|object)",
            fallbackPlacements: "array",
            html: "boolean",
            offset: "(array|string|function)",
            placement: "(string|function)",
            popperConfig: "(null|object|function)",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            selector: "(string|boolean)",
            template: "string",
            title: "(string|element|function)",
            trigger: "string"
        };
    class Nn extends me {
        constructor(t, s) {
            if (Je === void 0) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)");
            super(t, s), this._isEnabled = !0, this._timeout = 0, this._isHovered = null, this._activeTrigger = {}, this._popper = null, this._templateFactory = null, this._newContent = null, this.tip = null, this._setListeners(), this._config.selector || this._fixTitle()
        }
        static get Default() {
            return Vr
        }
        static get DefaultType() {
            return zr
        }
        static get NAME() {
            return "tooltip"
        }
        enable() {
            this._isEnabled = !0
        }
        disable() {
            this._isEnabled = !1
        }
        toggleEnabled() {
            this._isEnabled = !this._isEnabled
        }
        toggle() {
            this._isEnabled && (this._isShown() ? this._leave() : this._enter())
        }
        dispose() {
            clearTimeout(this._timeout), p.off(this._element.closest(js), Rs, this._hideModalHandler), this._element.getAttribute("data-bs-original-title") && this._element.setAttribute("title", this._element.getAttribute("data-bs-original-title")), this._disposePopper(), super.dispose()
        }
        show() {
            if (this._element.style.display === "none") throw new Error("Please use show on visible elements");
            if (!this._isWithContent() || !this._isEnabled) return;
            const t = p.trigger(this._element, this.constructor.eventName("show")),
                s = (rt(this._element) || this._element.ownerDocument.documentElement).contains(this._element);
            if (t.defaultPrevented || !s) return;
            this._disposePopper();
            const a = this._getTipElement();
            this._element.setAttribute("aria-describedby", a.getAttribute("id"));
            const {
                container: c
            } = this._config;
            if (this._element.ownerDocument.documentElement.contains(this.tip) || (c.append(a), p.trigger(this._element, this.constructor.eventName("inserted"))), this._popper = this._createPopper(a), a.classList.add($i), "ontouchstart" in document.documentElement)
                for (const u of [].concat(...document.body.children)) p.on(u, "mouseover", Oe);
            this._queueCallback(() => {
                p.trigger(this._element, this.constructor.eventName("shown")), this._isHovered === !1 && this._leave(), this._isHovered = !1
            }, this.tip, this._isAnimated())
        }
        hide() {
            if (this._isShown() && !p.trigger(this._element, this.constructor.eventName("hide")).defaultPrevented) {
                if (this._getTipElement().classList.remove($i), "ontouchstart" in document.documentElement)
                    for (const t of [].concat(...document.body.children)) p.off(t, "mouseover", Oe);
                this._activeTrigger[as] = !1, this._activeTrigger[os] = !1, this._activeTrigger[vi] = !1, this._isHovered = null, this._queueCallback(() => {
                    this._isWithActiveTrigger() || (this._isHovered || this._disposePopper(), this._element.removeAttribute("aria-describedby"), p.trigger(this._element, this.constructor.eventName("hidden")))
                }, this.tip, this._isAnimated())
            }
        }
        update() {
            this._popper && this._popper.update()
        }
        _isWithContent() {
            return !!this._getTitle()
        }
        _getTipElement() {
            return this.tip || (this.tip = this._createTipElement(this._newContent || this._getContentForTemplate())), this.tip
        }
        _createTipElement(t) {
            const s = this._getTemplateFactory(t).toHtml();
            if (!s) return null;
            s.classList.remove(rs, $i), s.classList.add(`bs-${this.constructor.NAME}-auto`);
            const a = (c => {
                do c += Math.floor(1e6 * Math.random()); while (document.getElementById(c));
                return c
            })(this.constructor.NAME).toString();
            return s.setAttribute("id", a), this._isAnimated() && s.classList.add(rs), s
        }
        setContent(t) {
            this._newContent = t, this._isShown() && (this._disposePopper(), this.show())
        }
        _getTemplateFactory(t) {
            return this._templateFactory ? this._templateFactory.changeContent(t) : this._templateFactory = new Fr({ ...this._config,
                content: t,
                extraClass: this._resolvePossibleFunction(this._config.customClass)
            }), this._templateFactory
        }
        _getContentForTemplate() {
            return {
                [$r]: this._getTitle()
            }
        }
        _getTitle() {
            return this._resolvePossibleFunction(this._config.title) || this._element.getAttribute("data-bs-original-title")
        }
        _initializeOnDelegatedTarget(t) {
            return this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig())
        }
        _isAnimated() {
            return this._config.animation || this.tip && this.tip.classList.contains(rs)
        }
        _isShown() {
            return this.tip && this.tip.classList.contains($i)
        }
        _createPopper(t) {
            const s = he(this._config.placement, [this, t, this._element]),
                a = Ur[s.toUpperCase()];
            return yi(this._element, t, this._getPopperConfig(a))
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return typeof t == "string" ? t.split(",").map(s => Number.parseInt(s, 10)) : typeof t == "function" ? s => t(s, this._element) : t
        }
        _resolvePossibleFunction(t) {
            return he(t, [this._element, this._element])
        }
        _getPopperConfig(t) {
            const s = {
                placement: t,
                modifiers: [{
                    name: "flip",
                    options: {
                        fallbackPlacements: this._config.fallbackPlacements
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }, {
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "arrow",
                    options: {
                        element: `.${this.constructor.NAME}-arrow`
                    }
                }, {
                    name: "preSetPlacement",
                    enabled: !0,
                    phase: "beforeMain",
                    fn: a => {
                        this._getTipElement().setAttribute("data-popper-placement", a.state.placement)
                    }
                }]
            };
            return { ...s,
                ...he(this._config.popperConfig, [void 0, s])
            }
        }
        _setListeners() {
            const t = this._config.trigger.split(" ");
            for (const s of t)
                if (s === "click") p.on(this._element, this.constructor.eventName("click"), this._config.selector, a => {
                    const c = this._initializeOnDelegatedTarget(a);
                    c._activeTrigger[as] = !(c._isShown() && c._activeTrigger[as]), c.toggle()
                });
                else if (s !== "manual") {
                const a = s === vi ? this.constructor.eventName("mouseenter") : this.constructor.eventName("focusin"),
                    c = s === vi ? this.constructor.eventName("mouseleave") : this.constructor.eventName("focusout");
                p.on(this._element, a, this._config.selector, u => {
                    const f = this._initializeOnDelegatedTarget(u);
                    f._activeTrigger[u.type === "focusin" ? os : vi] = !0, f._enter()
                }), p.on(this._element, c, this._config.selector, u => {
                    const f = this._initializeOnDelegatedTarget(u);
                    f._activeTrigger[u.type === "focusout" ? os : vi] = f._element.contains(u.relatedTarget), f._leave()
                })
            }
            this._hideModalHandler = () => {
                this._element && this.hide()
            }, p.on(this._element.closest(js), Rs, this._hideModalHandler)
        }
        _fixTitle() {
            const t = this._element.getAttribute("title");
            t && (this._element.getAttribute("aria-label") || this._element.textContent.trim() || this._element.setAttribute("aria-label", t), this._element.setAttribute("data-bs-original-title", t), this._element.removeAttribute("title"))
        }
        _enter() {
            this._isShown() || this._isHovered ? this._isHovered = !0 : (this._isHovered = !0, this._setTimeout(() => {
                this._isHovered && this.show()
            }, this._config.delay.show))
        }
        _leave() {
            this._isWithActiveTrigger() || (this._isHovered = !1, this._setTimeout(() => {
                this._isHovered || this.hide()
            }, this._config.delay.hide))
        }
        _setTimeout(t, s) {
            clearTimeout(this._timeout), this._timeout = setTimeout(t, s)
        }
        _isWithActiveTrigger() {
            return Object.values(this._activeTrigger).includes(!0)
        }
        _getConfig(t) {
            const s = We.getDataAttributes(this._element);
            for (const a of Object.keys(s)) Hr.has(a) && delete s[a];
            return t = { ...s,
                ...typeof t == "object" && t ? t : {}
            }, t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t
        }
        _configAfterMerge(t) {
            return t.container = t.container === !1 ? document.body : ue(t.container), typeof t.delay == "number" && (t.delay = {
                show: t.delay,
                hide: t.delay
            }), typeof t.title == "number" && (t.title = t.title.toString()), typeof t.content == "number" && (t.content = t.content.toString()), t
        }
        _getDelegateConfig() {
            const t = {};
            for (const [s, a] of Object.entries(this._config)) this.constructor.Default[s] !== a && (t[s] = a);
            return t.selector = !1, t.trigger = "manual", t
        }
        _disposePopper() {
            this._popper && (this._popper.destroy(), this._popper = null), this.tip && (this.tip.remove(), this.tip = null)
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Nn.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (s[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    Me(Nn);
    const Gr = ".popover-header",
        Br = ".popover-body",
        qr = { ...Nn.Default,
            content: "",
            offset: [0, 8],
            placement: "right",
            template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>',
            trigger: "click"
        },
        Zr = { ...Nn.DefaultType,
            content: "(null|string|element|function)"
        };
    class Ui extends Nn {
        static get Default() {
            return qr
        }
        static get DefaultType() {
            return Zr
        }
        static get NAME() {
            return "popover"
        }
        _isWithContent() {
            return this._getTitle() || this._getContent()
        }
        _getContentForTemplate() {
            return {
                [Gr]: this._getTitle(),
                [Br]: this._getContent()
            }
        }
        _getContent() {
            return this._resolvePossibleFunction(this._config.content)
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Ui.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (s[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    Me(Ui);
    const ls = ".bs.scrollspy",
        Kr = `activate${ls}`,
        Fs = `click${ls}`,
        Xr = `load${ls}.data-api`,
        ti = "active",
        cs = "[href]",
        Hs = ".nav-link",
        Qr = `${Hs}, .nav-item > ${Hs}, .list-group-item`,
        Jr = {
            offset: null,
            rootMargin: "0px 0px -25%",
            smoothScroll: !1,
            target: null,
            threshold: [.1, .5, 1]
        },
        eo = {
            offset: "(number|null)",
            rootMargin: "string",
            smoothScroll: "boolean",
            target: "element",
            threshold: "array"
        };
    class bi extends me {
        constructor(t, s) {
            super(t, s), this._targetLinks = new Map, this._observableSections = new Map, this._rootElement = getComputedStyle(this._element).overflowY === "visible" ? null : this._element, this._activeTarget = null, this._observer = null, this._previousScrollData = {
                visibleEntryTop: 0,
                parentScrollTop: 0
            }, this.refresh()
        }
        static get Default() {
            return Jr
        }
        static get DefaultType() {
            return eo
        }
        static get NAME() {
            return "scrollspy"
        }
        refresh() {
            this._initializeTargetsAndObservables(), this._maybeEnableSmoothScroll(), this._observer ? this._observer.disconnect() : this._observer = this._getNewObserver();
            for (const t of this._observableSections.values()) this._observer.observe(t)
        }
        dispose() {
            this._observer.disconnect(), super.dispose()
        }
        _configAfterMerge(t) {
            return t.target = ue(t.target) || document.body, t.rootMargin = t.offset ? `${t.offset}px 0px -30%` : t.rootMargin, typeof t.threshold == "string" && (t.threshold = t.threshold.split(",").map(s => Number.parseFloat(s))), t
        }
        _maybeEnableSmoothScroll() {
            this._config.smoothScroll && (p.off(this._config.target, Fs), p.on(this._config.target, Fs, cs, t => {
                const s = this._observableSections.get(t.target.hash);
                if (s) {
                    t.preventDefault();
                    const a = this._rootElement || window,
                        c = s.offsetTop - this._element.offsetTop;
                    if (a.scrollTo) return void a.scrollTo({
                        top: c,
                        behavior: "smooth"
                    });
                    a.scrollTop = c
                }
            }))
        }
        _getNewObserver() {
            const t = {
                root: this._rootElement,
                threshold: this._config.threshold,
                rootMargin: this._config.rootMargin
            };
            return new IntersectionObserver(s => this._observerCallback(s), t)
        }
        _observerCallback(t) {
            const s = f => this._targetLinks.get(`#${f.target.id}`),
                a = f => {
                    this._previousScrollData.visibleEntryTop = f.target.offsetTop, this._process(s(f))
                },
                c = (this._rootElement || document.documentElement).scrollTop,
                u = c >= this._previousScrollData.parentScrollTop;
            this._previousScrollData.parentScrollTop = c;
            for (const f of t) {
                if (!f.isIntersecting) {
                    this._activeTarget = null, this._clearActiveClass(s(f));
                    continue
                }
                const _ = f.target.offsetTop >= this._previousScrollData.visibleEntryTop;
                if (u && _) {
                    if (a(f), !c) return
                } else u || _ || a(f)
            }
        }
        _initializeTargetsAndObservables() {
            this._targetLinks = new Map, this._observableSections = new Map;
            const t = T.find(cs, this._config.target);
            for (const s of t) {
                if (!s.hash || st(s)) continue;
                const a = T.findOne(decodeURI(s.hash), this._element);
                Ve(a) && (this._targetLinks.set(decodeURI(s.hash), s), this._observableSections.set(s.hash, a))
            }
        }
        _process(t) {
            this._activeTarget !== t && (this._clearActiveClass(this._config.target), this._activeTarget = t, t.classList.add(ti), this._activateParents(t), p.trigger(this._element, Kr, {
                relatedTarget: t
            }))
        }
        _activateParents(t) {
            if (t.classList.contains("dropdown-item")) T.findOne(".dropdown-toggle", t.closest(".dropdown")).classList.add(ti);
            else
                for (const s of T.parents(t, ".nav, .list-group"))
                    for (const a of T.prev(s, Qr)) a.classList.add(ti)
        }
        _clearActiveClass(t) {
            t.classList.remove(ti);
            const s = T.find(`${cs}.${ti}`, t);
            for (const a of s) a.classList.remove(ti)
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = bi.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (s[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    p.on(window, Xr, () => {
        for (const o of T.find('[data-bs-spy="scroll"]')) bi.getOrCreateInstance(o)
    }), Me(bi);
    const Pn = ".bs.tab",
        to = `hide${Pn}`,
        no = `hidden${Pn}`,
        io = `show${Pn}`,
        so = `shown${Pn}`,
        ro = `click${Pn}`,
        oo = `keydown${Pn}`,
        ao = `load${Pn}`,
        lo = "ArrowLeft",
        $s = "ArrowRight",
        co = "ArrowUp",
        Us = "ArrowDown",
        us = "Home",
        Vs = "End",
        Ln = "active",
        zs = "fade",
        hs = "show",
        Gs = ".dropdown-toggle",
        ds = `:not(${Gs})`,
        Bs = '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]',
        fs = `.nav-link${ds}, .list-group-item${ds}, [role="tab"]${ds}, ${Bs}`,
        uo = `.${Ln}[data-bs-toggle="tab"], .${Ln}[data-bs-toggle="pill"], .${Ln}[data-bs-toggle="list"]`;
    class In extends me {
        constructor(t) {
            super(t), this._parent = this._element.closest('.list-group, .nav, [role="tablist"]'), this._parent && (this._setInitialAttributes(this._parent, this._getChildren()), p.on(this._element, oo, s => this._keydown(s)))
        }
        static get NAME() {
            return "tab"
        }
        show() {
            const t = this._element;
            if (this._elemIsActive(t)) return;
            const s = this._getActiveElem(),
                a = s ? p.trigger(s, to, {
                    relatedTarget: t
                }) : null;
            p.trigger(t, io, {
                relatedTarget: s
            }).defaultPrevented || a && a.defaultPrevented || (this._deactivate(s, t), this._activate(t, s))
        }
        _activate(t, s) {
            t && (t.classList.add(Ln), this._activate(T.getElementFromSelector(t)), this._queueCallback(() => {
                t.getAttribute("role") === "tab" ? (t.removeAttribute("tabindex"), t.setAttribute("aria-selected", !0), this._toggleDropDown(t, !0), p.trigger(t, so, {
                    relatedTarget: s
                })) : t.classList.add(hs)
            }, t, t.classList.contains(zs)))
        }
        _deactivate(t, s) {
            t && (t.classList.remove(Ln), t.blur(), this._deactivate(T.getElementFromSelector(t)), this._queueCallback(() => {
                t.getAttribute("role") === "tab" ? (t.setAttribute("aria-selected", !1), t.setAttribute("tabindex", "-1"), this._toggleDropDown(t, !1), p.trigger(t, no, {
                    relatedTarget: s
                })) : t.classList.remove(hs)
            }, t, t.classList.contains(zs)))
        }
        _keydown(t) {
            if (![lo, $s, co, Us, us, Vs].includes(t.key)) return;
            t.stopPropagation(), t.preventDefault();
            const s = this._getChildren().filter(c => !st(c));
            let a;
            if ([us, Vs].includes(t.key)) a = s[t.key === us ? 0 : s.length - 1];
            else {
                const c = [$s, Us].includes(t.key);
                a = Tt(s, t.target, c, !0)
            }
            a && (a.focus({
                preventScroll: !0
            }), In.getOrCreateInstance(a).show())
        }
        _getChildren() {
            return T.find(fs, this._parent)
        }
        _getActiveElem() {
            return this._getChildren().find(t => this._elemIsActive(t)) || null
        }
        _setInitialAttributes(t, s) {
            this._setAttributeIfNotExists(t, "role", "tablist");
            for (const a of s) this._setInitialAttributesOnChild(a)
        }
        _setInitialAttributesOnChild(t) {
            t = this._getInnerElement(t);
            const s = this._elemIsActive(t),
                a = this._getOuterElement(t);
            t.setAttribute("aria-selected", s), a !== t && this._setAttributeIfNotExists(a, "role", "presentation"), s || t.setAttribute("tabindex", "-1"), this._setAttributeIfNotExists(t, "role", "tab"), this._setInitialAttributesOnTargetPanel(t)
        }
        _setInitialAttributesOnTargetPanel(t) {
            const s = T.getElementFromSelector(t);
            s && (this._setAttributeIfNotExists(s, "role", "tabpanel"), t.id && this._setAttributeIfNotExists(s, "aria-labelledby", `${t.id}`))
        }
        _toggleDropDown(t, s) {
            const a = this._getOuterElement(t);
            if (!a.classList.contains("dropdown")) return;
            const c = (u, f) => {
                const _ = T.findOne(u, a);
                _ && _.classList.toggle(f, s)
            };
            c(Gs, Ln), c(".dropdown-menu", hs), a.setAttribute("aria-expanded", s)
        }
        _setAttributeIfNotExists(t, s, a) {
            t.hasAttribute(s) || t.setAttribute(s, a)
        }
        _elemIsActive(t) {
            return t.classList.contains(Ln)
        }
        _getInnerElement(t) {
            return t.matches(fs) ? t : T.findOne(fs, t)
        }
        _getOuterElement(t) {
            return t.closest(".nav-item, .list-group-item") || t
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = In.getOrCreateInstance(this);
                if (typeof t == "string") {
                    if (s[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    p.on(document, ro, Bs, function(o) {
        ["A", "AREA"].includes(this.tagName) && o.preventDefault(), st(this) || In.getOrCreateInstance(this).show()
    }), p.on(window, ao, () => {
        for (const o of T.find(uo)) In.getOrCreateInstance(o)
    }), Me(In);
    const rn = ".bs.toast",
        ho = `mouseover${rn}`,
        fo = `mouseout${rn}`,
        mo = `focusin${rn}`,
        po = `focusout${rn}`,
        _o = `hide${rn}`,
        go = `hidden${rn}`,
        yo = `show${rn}`,
        vo = `shown${rn}`,
        qs = "hide",
        Vi = "show",
        zi = "showing",
        bo = {
            animation: "boolean",
            autohide: "boolean",
            delay: "number"
        },
        wo = {
            animation: !0,
            autohide: !0,
            delay: 5e3
        };
    class wi extends me {
        constructor(t, s) {
            super(t, s), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners()
        }
        static get Default() {
            return wo
        }
        static get DefaultType() {
            return bo
        }
        static get NAME() {
            return "toast"
        }
        show() {
            p.trigger(this._element, yo).defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(qs), A(this._element), this._element.classList.add(Vi, zi), this._queueCallback(() => {
                this._element.classList.remove(zi), p.trigger(this._element, vo), this._maybeScheduleHide()
            }, this._element, this._config.animation))
        }
        hide() {
            this.isShown() && (p.trigger(this._element, _o).defaultPrevented || (this._element.classList.add(zi), this._queueCallback(() => {
                this._element.classList.add(qs), this._element.classList.remove(zi, Vi), p.trigger(this._element, go)
            }, this._element, this._config.animation)))
        }
        dispose() {
            this._clearTimeout(), this.isShown() && this._element.classList.remove(Vi), super.dispose()
        }
        isShown() {
            return this._element.classList.contains(Vi)
        }
        _maybeScheduleHide() {
            this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
                this.hide()
            }, this._config.delay)))
        }
        _onInteraction(t, s) {
            switch (t.type) {
                case "mouseover":
                case "mouseout":
                    this._hasMouseInteraction = s;
                    break;
                case "focusin":
                case "focusout":
                    this._hasKeyboardInteraction = s
            }
            if (s) return void this._clearTimeout();
            const a = t.relatedTarget;
            this._element === a || this._element.contains(a) || this._maybeScheduleHide()
        }
        _setListeners() {
            p.on(this._element, ho, t => this._onInteraction(t, !0)), p.on(this._element, fo, t => this._onInteraction(t, !1)), p.on(this._element, mo, t => this._onInteraction(t, !0)), p.on(this._element, po, t => this._onInteraction(t, !1))
        }
        _clearTimeout() {
            clearTimeout(this._timeout), this._timeout = null
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = wi.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (s[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    s[t](this)
                }
            })
        }
    }
    return G(wi), Me(wi), {
        Alert: ze,
        Button: hn,
        Carousel: Et,
        Collapse: Xt,
        Dropdown: _t,
        Modal: Yn,
        Offcanvas: Ft,
        Popover: Ui,
        ScrollSpy: bi,
        Tab: In,
        Toast: wi,
        Tooltip: Nn
    }
}), (function(be, b) {
    typeof exports == "object" && typeof module < "u" ? module.exports = b() : typeof define == "function" && define.amd ? define(b) : be.moment = b()
})(this, function() {
    "use strict";
    var be;

    function b() {
        return be.apply(null, arguments)
    }

    function De(e) {
        return e instanceof Array || Object.prototype.toString.call(e) === "[object Array]"
    }

    function yt(e) {
        return e != null && Object.prototype.toString.call(e) === "[object Object]"
    }

    function $(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n)
    }

    function jn(e) {
        if (Object.getOwnPropertyNames) return Object.getOwnPropertyNames(e).length === 0;
        for (var n in e)
            if ($(e, n)) return;
        return 1
    }

    function te(e) {
        return e === void 0
    }

    function ue(e) {
        return typeof e == "number" || Object.prototype.toString.call(e) === "[object Number]"
    }

    function Ve(e) {
        return e instanceof Date || Object.prototype.toString.call(e) === "[object Date]"
    }

    function st(e, n) {
        for (var i = [], r = e.length, l = 0; l < r; ++l) i.push(n(e[l], l));
        return i
    }

    function rt(e, n) {
        for (var i in n) $(n, i) && (e[i] = n[i]);
        return $(n, "toString") && (e.toString = n.toString), $(n, "valueOf") && (e.valueOf = n.valueOf), e
    }

    function Oe(e, n, i, r) {
        return wt(e, n, i, r, !0).utc()
    }

    function A(e) {
        return e._pf == null && (e._pf = {
            empty: !1,
            unusedTokens: [],
            unusedInput: [],
            overflow: -2,
            charsLeftOver: 0,
            nullInput: !1,
            invalidEra: null,
            invalidMonth: null,
            invalidFormat: !1,
            userInvalidated: !1,
            iso: !1,
            parsedDateParts: [],
            era: null,
            meridiem: null,
            rfc2822: !1,
            weekdayMismatch: !1
        }), e._pf
    }

    function Rn(e) {
        var n, i, r = e._d && !isNaN(e._d.getTime());
        return r && (n = A(e), i = Ee.call(n.parsedDateParts, function(l) {
            return l != null
        }), r = n.overflow < 0 && !n.empty && !n.invalidEra && !n.invalidMonth && !n.invalidWeekday && !n.weekdayMismatch && !n.nullInput && !n.invalidFormat && !n.userInvalidated && (!n.meridiem || n.meridiem && i), e._strict) && (r = r && n.charsLeftOver === 0 && n.unusedTokens.length === 0 && n.bigHour === void 0), Object.isFrozen != null && Object.isFrozen(e) ? r : (e._isValid = r, e._isValid)
    }

    function Ht(e) {
        var n = Oe(NaN);
        return e != null ? rt(A(n), e) : A(n).userInvalidated = !0, n
    }
    var Ee = Array.prototype.some || function(e) {
            for (var n = Object(this), i = n.length >>> 0, r = 0; r < i; r++)
                if (r in n && e.call(this, n[r], r, n)) return !0;
            return !1
        },
        Me = b.momentProperties = [],
        he = !1;

    function Fn(e, n) {
        var i, r, l, h = Me.length;
        if (te(n._isAMomentObject) || (e._isAMomentObject = n._isAMomentObject), te(n._i) || (e._i = n._i), te(n._f) || (e._f = n._f), te(n._l) || (e._l = n._l), te(n._strict) || (e._strict = n._strict), te(n._tzm) || (e._tzm = n._tzm), te(n._isUTC) || (e._isUTC = n._isUTC), te(n._offset) || (e._offset = n._offset), te(n._pf) || (e._pf = A(n)), te(n._locale) || (e._locale = n._locale), 0 < h)
            for (i = 0; i < h; i++) te(l = n[r = Me[i]]) || (e[r] = l);
        return e
    }

    function Tt(e) {
        Fn(this, e), this._d = new Date(e._d != null ? e._d.getTime() : NaN), this.isValid() || (this._d = new Date(NaN)), he === !1 && (he = !0, b.updateOffset(this), he = !1)
    }

    function Pe(e) {
        return e instanceof Tt || e != null && e._isAMomentObject != null
    }

    function ki(e) {
        b.suppressDeprecationWarnings === !1 && typeof console < "u" && console.warn && console.warn("Deprecation warning: " + e)
    }

    function Ae(e, n) {
        var i = !0;
        return rt(function() {
            if (b.deprecationHandler != null && b.deprecationHandler(null, e), i) {
                for (var r, l, h = [], d = arguments.length, m = 0; m < d; m++) {
                    if (r = "", typeof arguments[m] == "object") {
                        for (l in r += `
[` + m + "] ", arguments[0]) $(arguments[0], l) && (r += l + ": " + arguments[0][l] + ", ");
                        r = r.slice(0, -2)
                    } else r = arguments[m];
                    h.push(r)
                }
                ki(e + `
Arguments: ` + Array.prototype.slice.call(h).join("") + `
` + new Error().stack), i = !1
            }
            return n.apply(this, arguments)
        }, n)
    }
    var Hn = {};

    function ii(e, n) {
        b.deprecationHandler != null && b.deprecationHandler(e, n), Hn[e] || (ki(n), Hn[e] = !0)
    }

    function Le(e) {
        return typeof Function < "u" && e instanceof Function || Object.prototype.toString.call(e) === "[object Function]"
    }

    function si(e, n) {
        var i, r = rt({}, e);
        for (i in n) $(n, i) && (yt(e[i]) && yt(n[i]) ? (r[i] = {}, rt(r[i], e[i]), rt(r[i], n[i])) : n[i] != null ? r[i] = n[i] : delete r[i]);
        for (i in e) $(e, i) && !$(n, i) && yt(e[i]) && (r[i] = rt({}, r[i]));
        return r
    }

    function $n(e) {
        e != null && this.set(e)
    }
    b.suppressDeprecationWarnings = !1, b.deprecationHandler = null;
    var Si = Object.keys || function(e) {
        var n, i = [];
        for (n in e) $(e, n) && i.push(n);
        return i
    };

    function Ie(e, n, i) {
        var r = "" + Math.abs(e);
        return (0 <= e ? i ? "+" : "" : "-") + Math.pow(10, Math.max(0, n - r.length)).toString().substr(1) + r
    }
    var Un = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,
        an = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,
        ln = {},
        $t = {};

    function M(e, n, i, r) {
        var l = typeof r == "string" ? function() {
            return this[r]()
        } : r;
        e && ($t[e] = l), n && ($t[n[0]] = function() {
            return Ie(l.apply(this, arguments), n[1], n[2])
        }), i && ($t[i] = function() {
            return this.localeData().ordinal(l.apply(this, arguments), e)
        })
    }

    function p(e, n) {
        return e.isValid() ? (n = Vn(n, e.localeData()), ln[n] = ln[n] || (function(i) {
            for (var r, l = i.match(Un), h = 0, d = l.length; h < d; h++) $t[l[h]] ? l[h] = $t[l[h]] : l[h] = (r = l[h]).match(/\[[\s\S]/) ? r.replace(/^\[|\]$/g, "") : r.replace(/\\/g, "");
            return function(m) {
                for (var v = "", y = 0; y < d; y++) v += Le(l[y]) ? l[y].call(m, i) : l[y];
                return v
            }
        })(n), ln[n](e)) : e.localeData().invalidDate()
    }

    function Vn(e, n) {
        var i = 5;

        function r(l) {
            return n.longDateFormat(l) || l
        }
        for (an.lastIndex = 0; 0 <= i && an.test(e);) e = e.replace(an, r), an.lastIndex = 0, --i;
        return e
    }
    var ri = {
        D: "date",
        dates: "date",
        date: "date",
        d: "day",
        days: "day",
        day: "day",
        e: "weekday",
        weekdays: "weekday",
        weekday: "weekday",
        E: "isoWeekday",
        isoweekdays: "isoWeekday",
        isoweekday: "isoWeekday",
        DDD: "dayOfYear",
        dayofyears: "dayOfYear",
        dayofyear: "dayOfYear",
        h: "hour",
        hours: "hour",
        hour: "hour",
        ms: "millisecond",
        milliseconds: "millisecond",
        millisecond: "millisecond",
        m: "minute",
        minutes: "minute",
        minute: "minute",
        M: "month",
        months: "month",
        month: "month",
        Q: "quarter",
        quarters: "quarter",
        quarter: "quarter",
        s: "second",
        seconds: "second",
        second: "second",
        gg: "weekYear",
        weekyears: "weekYear",
        weekyear: "weekYear",
        GG: "isoWeekYear",
        isoweekyears: "isoWeekYear",
        isoweekyear: "isoWeekYear",
        w: "week",
        weeks: "week",
        week: "week",
        W: "isoWeek",
        isoweeks: "isoWeek",
        isoweek: "isoWeek",
        y: "year",
        years: "year",
        year: "year"
    };

    function we(e) {
        return typeof e == "string" ? ri[e] || ri[e.toLowerCase()] : void 0
    }

    function We(e) {
        var n, i, r = {};
        for (i in e) $(e, i) && (n = we(i)) && (r[n] = e[i]);
        return r
    }
    var cn = {
            date: 9,
            day: 11,
            weekday: 11,
            isoWeekday: 11,
            dayOfYear: 4,
            hour: 13,
            millisecond: 16,
            minute: 14,
            month: 8,
            quarter: 7,
            second: 15,
            weekYear: 1,
            isoWeekYear: 1,
            week: 5,
            isoWeek: 5,
            year: 1
        },
        me = /\d/,
        le = /\d\d/,
        T = /\d{3}/,
        dt = /\d{4}/,
        mt = /[+-]?\d{6}/,
        G = /\d\d?/,
        xt = /\d\d\d\d?/,
        Ut = /\d\d\d\d\d\d?/,
        Vt = /\d{1,3}/,
        pt = /\d{1,4}/,
        St = /[+-]?\d{1,6}/,
        ze = /\d+/,
        un = /[+-]?\d+/,
        hn = /Z|[+-]\d\d:?\d\d/gi,
        ot = /Z|[+-]\d\d(?::?\d\d)?/gi,
        at = /[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i,
        g = /^[1-9]\d?/,
        I = /^([1-9]\d|\d)/;

    function S(e, n, i) {
        zt[e] = Le(n) ? n : function(r, l) {
            return r && i ? i : n
        }
    }

    function Zi(e, n) {
        return $(zt, e) ? zt[e](n._strict, n._locale) : new RegExp(lt(e.replace("\\", "").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(i, r, l, h, d) {
            return r || l || h || d
        })))
    }

    function lt(e) {
        return e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")
    }

    function Ye(e) {
        return e < 0 ? Math.ceil(e) || 0 : Math.floor(e)
    }

    function j(n) {
        var n = +n,
            i = 0;
        return i = n != 0 && isFinite(n) ? Ye(n) : i
    }
    var zt = {},
        Ge = {};

    function U(e, n) {
        var i, r, l = n;
        for (typeof e == "string" && (e = [e]), ue(n) && (l = function(h, d) {
                d[n] = j(h)
            }), r = e.length, i = 0; i < r; i++) Ge[e[i]] = l
    }

    function dn(e, n) {
        U(e, function(i, r, l, h) {
            l._w = l._w || {}, n(i, l._w, l, h)
        })
    }

    function zn(e) {
        return e % 4 == 0 && e % 100 != 0 || e % 400 == 0
    }
    var ie = 0,
        ke = 1,
        pe = 2,
        ne = 3,
        je = 4,
        Re = 5,
        Ct = 6,
        Ki = 7,
        Xi = 8;

    function fn(e) {
        return zn(e) ? 366 : 365
    }
    M("Y", 0, 0, function() {
        var e = this.year();
        return e <= 9999 ? Ie(e, 4) : "+" + e
    }), M(0, ["YY", 2], 0, function() {
        return this.year() % 100
    }), M(0, ["YYYY", 4], 0, "year"), M(0, ["YYYYY", 5], 0, "year"), M(0, ["YYYYYY", 6, !0], 0, "year"), S("Y", un), S("YY", G, le), S("YYYY", pt, dt), S("YYYYY", St, mt), S("YYYYYY", St, mt), U(["YYYYY", "YYYYYY"], ie), U("YYYY", function(e, n) {
        n[ie] = e.length === 2 ? b.parseTwoDigitYear(e) : j(e)
    }), U("YY", function(e, n) {
        n[ie] = b.parseTwoDigitYear(e)
    }), U("Y", function(e, n) {
        n[ie] = parseInt(e, 10)
    }), b.parseTwoDigitYear = function(e) {
        return j(e) + (68 < j(e) ? 1900 : 2e3)
    };
    var se, It = Gt("FullYear", !0);

    function Gt(e, n) {
        return function(i) {
            return i != null ? (mn(this, e, i), b.updateOffset(this, n), this) : Bt(this, e)
        }
    }

    function Bt(e, n) {
        if (!e.isValid()) return NaN;
        var i = e._d,
            r = e._isUTC;
        switch (n) {
            case "Milliseconds":
                return r ? i.getUTCMilliseconds() : i.getMilliseconds();
            case "Seconds":
                return r ? i.getUTCSeconds() : i.getSeconds();
            case "Minutes":
                return r ? i.getUTCMinutes() : i.getMinutes();
            case "Hours":
                return r ? i.getUTCHours() : i.getHours();
            case "Date":
                return r ? i.getUTCDate() : i.getDate();
            case "Day":
                return r ? i.getUTCDay() : i.getDay();
            case "Month":
                return r ? i.getUTCMonth() : i.getMonth();
            case "FullYear":
                return r ? i.getUTCFullYear() : i.getFullYear();
            default:
                return NaN
        }
    }

    function mn(e, n, i) {
        var r, l, h;
        if (e.isValid() && !isNaN(i)) {
            switch (r = e._d, l = e._isUTC, n) {
                case "Milliseconds":
                    return l ? r.setUTCMilliseconds(i) : r.setMilliseconds(i);
                case "Seconds":
                    return l ? r.setUTCSeconds(i) : r.setSeconds(i);
                case "Minutes":
                    return l ? r.setUTCMinutes(i) : r.setMinutes(i);
                case "Hours":
                    return l ? r.setUTCHours(i) : r.setHours(i);
                case "Date":
                    return l ? r.setUTCDate(i) : r.setDate(i);
                case "FullYear":
                    break;
                default:
                    return
            }
            n = i, h = e.month(), e = (e = e.date()) !== 29 || h !== 1 || zn(n) ? e : 28, l ? r.setUTCFullYear(n, h, e) : r.setFullYear(n, h, e)
        }
    }

    function Gn(e, n) {
        var i;
        return isNaN(e) || isNaN(n) ? NaN : (i = (n % (i = 12) + i) % i, e += (n - i) / 12, i == 1 ? zn(e) ? 29 : 28 : 31 - i % 7 % 2)
    }
    se = Array.prototype.indexOf || function(e) {
        for (var n = 0; n < this.length; ++n)
            if (this[n] === e) return n;
        return -1
    }, M("M", ["MM", 2], "Mo", function() {
        return this.month() + 1
    }), M("MMM", 0, 0, function(e) {
        return this.localeData().monthsShort(this, e)
    }), M("MMMM", 0, 0, function(e) {
        return this.localeData().months(this, e)
    }), S("M", G, g), S("MM", G, le), S("MMM", function(e, n) {
        return n.monthsShortRegex(e)
    }), S("MMMM", function(e, n) {
        return n.monthsRegex(e)
    }), U(["M", "MM"], function(e, n) {
        n[ke] = j(e) - 1
    }), U(["MMM", "MMMM"], function(e, n, i, r) {
        r = i._locale.monthsParse(e, r, i._strict), r != null ? n[ke] = r : A(i).invalidMonth = e
    });
    var qt = "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
        Di = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
        Oi = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/,
        Qi = at,
        Ji = at;

    function Et(e, n) {
        if (e.isValid()) {
            if (typeof n == "string") {
                if (/^\d+$/.test(n)) n = j(n);
                else if (!ue(n = e.localeData().monthsParse(n))) return
            }
            var i = (i = e.date()) < 29 ? i : Math.min(i, Gn(e.year(), n));
            e._isUTC ? e._d.setUTCMonth(n, i) : e._d.setMonth(n, i)
        }
    }

    function Zt(e) {
        return e != null ? (Et(this, e), b.updateOffset(this, !0), this) : Bt(this, "Month")
    }

    function Mi() {
        function e(m, v) {
            return v.length - m.length
        }
        for (var n, i, r = [], l = [], h = [], d = 0; d < 12; d++) i = Oe([2e3, d]), n = lt(this.monthsShort(i, "")), i = lt(this.months(i, "")), r.push(n), l.push(i), h.push(i), h.push(n);
        r.sort(e), l.sort(e), h.sort(e), this._monthsRegex = new RegExp("^(" + h.join("|") + ")", "i"), this._monthsShortRegex = this._monthsRegex, this._monthsStrictRegex = new RegExp("^(" + l.join("|") + ")", "i"), this._monthsShortStrictRegex = new RegExp("^(" + r.join("|") + ")", "i")
    }

    function es(e, n, i, r, l, h, d) {
        var m;
        return e < 100 && 0 <= e ? (m = new Date(e + 400, n, i, r, l, h, d), isFinite(m.getFullYear()) && m.setFullYear(e)) : m = new Date(e, n, i, r, l, h, d), m
    }

    function pn(e) {
        var n;
        return e < 100 && 0 <= e ? ((n = Array.prototype.slice.call(arguments))[0] = e + 400, n = new Date(Date.UTC.apply(null, n)), isFinite(n.getUTCFullYear()) && n.setUTCFullYear(e)) : n = new Date(Date.UTC.apply(null, arguments)), n
    }

    function Bn(e, n, i) {
        return i = 7 + n - i, i - (7 + pn(e, 0, i).getUTCDay() - n) % 7 - 1
    }

    function Ti(e, d, m, r, l) {
        var h, d = 1 + 7 * (d - 1) + (7 + m - r) % 7 + Bn(e, r, l),
            m = d <= 0 ? fn(h = e - 1) + d : d > fn(e) ? (h = e + 1, d - fn(e)) : (h = e, d);
        return {
            year: h,
            dayOfYear: m
        }
    }

    function At(e, n, i) {
        var r, l, h = Bn(e.year(), n, i),
            h = Math.floor((e.dayOfYear() - h - 1) / 7) + 1;
        return h < 1 ? r = h + Se(l = e.year() - 1, n, i) : h > Se(e.year(), n, i) ? (r = h - Se(e.year(), n, i), l = e.year() + 1) : (l = e.year(), r = h), {
            week: r,
            year: l
        }
    }

    function Se(e, l, i) {
        var r = Bn(e, l, i),
            l = Bn(e + 1, l, i);
        return (fn(e) - r + l) / 7
    }
    M("w", ["ww", 2], "wo", "week"), M("W", ["WW", 2], "Wo", "isoWeek"), S("w", G, g), S("ww", G, le), S("W", G, g), S("WW", G, le), dn(["w", "ww", "W", "WW"], function(e, n, i, r) {
        n[r.substr(0, 1)] = j(e)
    });

    function Kt(e, n) {
        return e.slice(n, 7).concat(e.slice(0, n))
    }
    M("d", 0, "do", "day"), M("dd", 0, 0, function(e) {
        return this.localeData().weekdaysMin(this, e)
    }), M("ddd", 0, 0, function(e) {
        return this.localeData().weekdaysShort(this, e)
    }), M("dddd", 0, 0, function(e) {
        return this.localeData().weekdays(this, e)
    }), M("e", 0, 0, "weekday"), M("E", 0, 0, "isoWeekday"), S("d", G), S("e", G), S("E", G), S("dd", function(e, n) {
        return n.weekdaysMinRegex(e)
    }), S("ddd", function(e, n) {
        return n.weekdaysShortRegex(e)
    }), S("dddd", function(e, n) {
        return n.weekdaysRegex(e)
    }), dn(["dd", "ddd", "dddd"], function(e, n, i, r) {
        r = i._locale.weekdaysParse(e, r, i._strict), r != null ? n.d = r : A(i).invalidWeekday = e
    }), dn(["d", "e", "E"], function(e, n, i, r) {
        n[r] = j(e)
    });
    var _n = "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
        qn = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
        Zn = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"),
        ts = at,
        Xt = at,
        _e = at;

    function ge() {
        function e(y, x) {
            return x.length - y.length
        }
        for (var n, i, r, l = [], h = [], d = [], m = [], v = 0; v < 7; v++) r = Oe([2e3, 1]).day(v), n = lt(this.weekdaysMin(r, "")), i = lt(this.weekdaysShort(r, "")), r = lt(this.weekdays(r, "")), l.push(n), h.push(i), d.push(r), m.push(n), m.push(i), m.push(r);
        l.sort(e), h.sort(e), d.sort(e), m.sort(e), this._weekdaysRegex = new RegExp("^(" + m.join("|") + ")", "i"), this._weekdaysShortRegex = this._weekdaysRegex, this._weekdaysMinRegex = this._weekdaysRegex, this._weekdaysStrictRegex = new RegExp("^(" + d.join("|") + ")", "i"), this._weekdaysShortStrictRegex = new RegExp("^(" + h.join("|") + ")", "i"), this._weekdaysMinStrictRegex = new RegExp("^(" + l.join("|") + ")", "i")
    }

    function ye() {
        return this.hours() % 12 || 12
    }

    function de(e, n) {
        M(e, 0, 0, function() {
            return this.localeData().meridiem(this.hours(), this.minutes(), n)
        })
    }

    function gn(e, n) {
        return n._meridiemParse
    }
    M("H", ["HH", 2], 0, "hour"), M("h", ["hh", 2], 0, ye), M("k", ["kk", 2], 0, function() {
        return this.hours() || 24
    }), M("hmm", 0, 0, function() {
        return "" + ye.apply(this) + Ie(this.minutes(), 2)
    }), M("hmmss", 0, 0, function() {
        return "" + ye.apply(this) + Ie(this.minutes(), 2) + Ie(this.seconds(), 2)
    }), M("Hmm", 0, 0, function() {
        return "" + this.hours() + Ie(this.minutes(), 2)
    }), M("Hmmss", 0, 0, function() {
        return "" + this.hours() + Ie(this.minutes(), 2) + Ie(this.seconds(), 2)
    }), de("a", !0), de("A", !1), S("a", gn), S("A", gn), S("H", G, I), S("h", G, g), S("k", G, g), S("HH", G, le), S("hh", G, le), S("kk", G, le), S("hmm", xt), S("hmmss", Ut), S("Hmm", xt), S("Hmmss", Ut), U(["H", "HH"], ne), U(["k", "kk"], function(e, n, i) {
        e = j(e), n[ne] = e === 24 ? 0 : e
    }), U(["a", "A"], function(e, n, i) {
        i._isPm = i._locale.isPM(e), i._meridiem = e
    }), U(["h", "hh"], function(e, n, i) {
        n[ne] = j(e), A(i).bigHour = !0
    }), U("hmm", function(e, n, i) {
        var r = e.length - 2;
        n[ne] = j(e.substr(0, r)), n[je] = j(e.substr(r)), A(i).bigHour = !0
    }), U("hmmss", function(e, n, i) {
        var r = e.length - 4,
            l = e.length - 2;
        n[ne] = j(e.substr(0, r)), n[je] = j(e.substr(r, 2)), n[Re] = j(e.substr(l)), A(i).bigHour = !0
    }), U("Hmm", function(e, n, i) {
        var r = e.length - 2;
        n[ne] = j(e.substr(0, r)), n[je] = j(e.substr(r))
    }), U("Hmmss", function(e, n, i) {
        var r = e.length - 4,
            l = e.length - 2;
        n[ne] = j(e.substr(0, r)), n[je] = j(e.substr(r, 2)), n[Re] = j(e.substr(l))
    }), at = Gt("Hours", !0);
    var Be, vt = {
            calendar: {
                sameDay: "[Today at] LT",
                nextDay: "[Tomorrow at] LT",
                nextWeek: "dddd [at] LT",
                lastDay: "[Yesterday at] LT",
                lastWeek: "[Last] dddd [at] LT",
                sameElse: "L"
            },
            longDateFormat: {
                LTS: "h:mm:ss A",
                LT: "h:mm A",
                L: "MM/DD/YYYY",
                LL: "MMMM D, YYYY",
                LLL: "MMMM D, YYYY h:mm A",
                LLLL: "dddd, MMMM D, YYYY h:mm A"
            },
            invalidDate: "Invalid date",
            ordinal: "%d",
            dayOfMonthOrdinalParse: /\d{1,2}/,
            relativeTime: {
                future: "in %s",
                past: "%s ago",
                s: "a few seconds",
                ss: "%d seconds",
                m: "a minute",
                mm: "%d minutes",
                h: "an hour",
                hh: "%d hours",
                d: "a day",
                dd: "%d days",
                w: "a week",
                ww: "%d weeks",
                M: "a month",
                MM: "%d months",
                y: "a year",
                yy: "%d years"
            },
            months: qt,
            monthsShort: Di,
            week: {
                dow: 0,
                doy: 6
            },
            weekdays: _n,
            weekdaysMin: Zn,
            weekdaysShort: qn,
            meridiemParse: /[ap]\.?m?\.?/i
        },
        V = {},
        Qt = {};

    function Kn(e) {
        return e && e.toLowerCase().replace("_", "-")
    }

    function Jt(e) {
        for (var n, i, r, l, h = 0; h < e.length;) {
            for (n = (l = Kn(e[h]).split("-")).length, i = (i = Kn(e[h + 1])) ? i.split("-") : null; 0 < n;) {
                if (r = yn(l.slice(0, n).join("-"))) return r;
                if (i && i.length >= n && (function(d, m) {
                        for (var v = Math.min(d.length, m.length), y = 0; y < v; y += 1)
                            if (d[y] !== m[y]) return y;
                        return v
                    })(l, i) >= n - 1) break;
                n--
            }
            h++
        }
        return Be
    }

    function yn(e) {
        var n, i;
        if (V[e] === void 0 && typeof module < "u" && module && module.exports && (i = e) && i.match("^[^/\\\\]*$")) try {
            n = Be._abbr, require("./locale/" + e), qe(n)
        } catch {
            V[e] = null
        }
        return V[e]
    }

    function qe(e, n) {
        return e && ((n = te(n) ? Ze(e) : vn(e, n)) ? Be = n : typeof console < "u" && console.warn && console.warn("Locale " + e + " not found. Did you forget to load it?")), Be._abbr
    }

    function vn(e, n) {
        if (n === null) return delete V[e], null;
        var i, r = vt;
        if (n.abbr = e, V[e] != null) ii("defineLocaleOverride", "use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."), r = V[e]._config;
        else if (n.parentLocale != null)
            if (V[n.parentLocale] != null) r = V[n.parentLocale]._config;
            else {
                if ((i = yn(n.parentLocale)) == null) return Qt[n.parentLocale] || (Qt[n.parentLocale] = []), Qt[n.parentLocale].push({
                    name: e,
                    config: n
                }), null;
                r = i._config
            }
        return V[e] = new $n(si(r, n)), Qt[e] && Qt[e].forEach(function(l) {
            vn(l.name, l.config)
        }), qe(e), V[e]
    }

    function Ze(e) {
        var n;
        if (!(e = e && e._locale && e._locale._abbr ? e._locale._abbr : e)) return Be;
        if (!De(e)) {
            if (n = yn(e)) return n;
            e = [e]
        }
        return Jt(e)
    }

    function Xn(e) {
        var n = e._a;
        return n && A(e).overflow === -2 && (n = n[ke] < 0 || 11 < n[ke] ? ke : n[pe] < 1 || n[pe] > Gn(n[ie], n[ke]) ? pe : n[ne] < 0 || 24 < n[ne] || n[ne] === 24 && (n[je] !== 0 || n[Re] !== 0 || n[Ct] !== 0) ? ne : n[je] < 0 || 59 < n[je] ? je : n[Re] < 0 || 59 < n[Re] ? Re : n[Ct] < 0 || 999 < n[Ct] ? Ct : -1, A(e)._overflowDayOfYear && (n < ie || pe < n) && (n = pe), A(e)._overflowWeeks && n === -1 && (n = Ki), A(e)._overflowWeekday && n === -1 && (n = Xi), A(e).overflow = n), e
    }
    var xi = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
        Ci = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
        Ei = /Z|[+-]\d\d(?::?\d\d)?/,
        bn = [
            ["YYYYYY-MM-DD", /[+-]\d{6}-\d\d-\d\d/],
            ["YYYY-MM-DD", /\d{4}-\d\d-\d\d/],
            ["GGGG-[W]WW-E", /\d{4}-W\d\d-\d/],
            ["GGGG-[W]WW", /\d{4}-W\d\d/, !1],
            ["YYYY-DDD", /\d{4}-\d{3}/],
            ["YYYY-MM", /\d{4}-\d\d/, !1],
            ["YYYYYYMMDD", /[+-]\d{10}/],
            ["YYYYMMDD", /\d{8}/],
            ["GGGG[W]WWE", /\d{4}W\d{3}/],
            ["GGGG[W]WW", /\d{4}W\d{2}/, !1],
            ["YYYYDDD", /\d{7}/],
            ["YYYYMM", /\d{6}/, !1],
            ["YYYY", /\d{4}/, !1]
        ],
        Qn = [
            ["HH:mm:ss.SSSS", /\d\d:\d\d:\d\d\.\d+/],
            ["HH:mm:ss,SSSS", /\d\d:\d\d:\d\d,\d+/],
            ["HH:mm:ss", /\d\d:\d\d:\d\d/],
            ["HH:mm", /\d\d:\d\d/],
            ["HHmmss.SSSS", /\d\d\d\d\d\d\.\d+/],
            ["HHmmss,SSSS", /\d\d\d\d\d\d,\d+/],
            ["HHmmss", /\d\d\d\d\d\d/],
            ["HHmm", /\d\d\d\d/],
            ["HH", /\d\d/]
        ],
        Ai = /^\/?Date\((-?\d+)/i,
        Yi = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/,
        Ni = {
            UT: 0,
            GMT: 0,
            EDT: -240,
            EST: -300,
            CDT: -300,
            CST: -360,
            MDT: -360,
            MST: -420,
            PDT: -420,
            PST: -480
        };

    function Fe(e) {
        var n, i, r, l, h, d, v = e._i,
            m = xi.exec(v) || Ci.exec(v),
            v = bn.length,
            y = Qn.length;
        if (m) {
            for (A(e).iso = !0, n = 0, i = v; n < i; n++)
                if (bn[n][1].exec(m[1])) {
                    l = bn[n][0], r = bn[n][2] !== !1;
                    break
                }
            if (l == null) e._isValid = !1;
            else {
                if (m[3]) {
                    for (n = 0, i = y; n < i; n++)
                        if (Qn[n][1].exec(m[3])) {
                            h = (m[2] || " ") + Qn[n][0];
                            break
                        }
                    if (h == null) return void(e._isValid = !1)
                }
                if (r || h == null) {
                    if (m[4]) {
                        if (!Ei.exec(m[4])) return void(e._isValid = !1);
                        d = "Z"
                    }
                    e._f = l + (h || "") + (d || ""), kn(e)
                } else e._isValid = !1
            }
        } else e._isValid = !1
    }

    function Te(e, n, i, r, l, h) {
        return e = [(function(d) {
            d = parseInt(d, 10); {
                if (d <= 49) return 2e3 + d;
                if (d <= 999) return 1900 + d
            }
            return d
        })(e), Di.indexOf(n), parseInt(i, 10), parseInt(r, 10), parseInt(l, 10)], h && e.push(parseInt(h, 10)), e
    }

    function bt(e) {
        var n, i, r = Yi.exec(e._i.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").replace(/^\s\s*/, "").replace(/\s\s*$/, ""));
        r ? (n = Te(r[4], r[3], r[2], r[5], r[6], r[7]), (function(l, h, d) {
            if (!l || qn.indexOf(l) === new Date(h[0], h[1], h[2]).getDay()) return 1;
            A(d).weekdayMismatch = !0, d._isValid = !1
        })(r[1], n, e) && (e._a = n, e._tzm = (n = r[8], i = r[9], r = r[10], n ? Ni[n] : i ? 0 : 60 * (((n = parseInt(r, 10)) - (i = n % 100)) / 100) + i), e._d = pn.apply(null, e._a), e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), A(e).rfc2822 = !0)) : e._isValid = !1
    }

    function ce(e, n, i) {
        return e ? ? n ? ? i
    }

    function wn(e) {
        var n, i, r, l, h, d, m, v, y, x, C, q = [];
        if (!e._d) {
            for (r = e, l = new Date(b.now()), i = r._useUTC ? [l.getUTCFullYear(), l.getUTCMonth(), l.getUTCDate()] : [l.getFullYear(), l.getMonth(), l.getDate()], e._w && e._a[pe] == null && e._a[ke] == null && ((l = (r = e)._w).GG != null || l.W != null || l.E != null ? (v = 1, y = 4, h = ce(l.GG, r._a[ie], At(B(), 1, 4).year), d = ce(l.W, 1), ((m = ce(l.E, 1)) < 1 || 7 < m) && (x = !0)) : (v = r._locale._week.dow, y = r._locale._week.doy, C = At(B(), v, y), h = ce(l.gg, r._a[ie], C.year), d = ce(l.w, C.week), l.d != null ? ((m = l.d) < 0 || 6 < m) && (x = !0) : l.e != null ? (m = l.e + v, (l.e < 0 || 6 < l.e) && (x = !0)) : m = v), d < 1 || d > Se(h, v, y) ? A(r)._overflowWeeks = !0 : x != null ? A(r)._overflowWeekday = !0 : (C = Ti(h, d, m, v, y), r._a[ie] = C.year, r._dayOfYear = C.dayOfYear)), e._dayOfYear != null && (l = ce(e._a[ie], i[ie]), (e._dayOfYear > fn(l) || e._dayOfYear === 0) && (A(e)._overflowDayOfYear = !0), x = pn(l, 0, e._dayOfYear), e._a[ke] = x.getUTCMonth(), e._a[pe] = x.getUTCDate()), n = 0; n < 3 && e._a[n] == null; ++n) e._a[n] = q[n] = i[n];
            for (; n < 7; n++) e._a[n] = q[n] = e._a[n] == null ? n === 2 ? 1 : 0 : e._a[n];
            e._a[ne] === 24 && e._a[je] === 0 && e._a[Re] === 0 && e._a[Ct] === 0 && (e._nextDay = !0, e._a[ne] = 0), e._d = (e._useUTC ? pn : es).apply(null, q), h = e._useUTC ? e._d.getUTCDay() : e._d.getDay(), e._tzm != null && e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), e._nextDay && (e._a[ne] = 24), e._w && e._w.d !== void 0 && e._w.d !== h && (A(e).weekdayMismatch = !0)
        }
    }

    function kn(e) {
        if (e._f === b.ISO_8601) Fe(e);
        else if (e._f === b.RFC_2822) bt(e);
        else {
            e._a = [], A(e).empty = !0;
            for (var n, i, r, l, h, d = "" + e._i, m = d.length, v = 0, y = Vn(e._f, e._locale).match(Un) || [], x = y.length, C = 0; C < x; C++) i = y[C], (n = (d.match(Zi(i, e)) || [])[0]) && (0 < (r = d.substr(0, d.indexOf(n))).length && A(e).unusedInput.push(r), d = d.slice(d.indexOf(n) + n.length), v += n.length), $t[i] ? (n ? A(e).empty = !1 : A(e).unusedTokens.push(i), r = i, h = e, (l = n) != null && $(Ge, r) && Ge[r](l, h._a, h, r)) : e._strict && !n && A(e).unusedTokens.push(i);
            A(e).charsLeftOver = m - v, 0 < d.length && A(e).unusedInput.push(d), e._a[ne] <= 12 && A(e).bigHour === !0 && 0 < e._a[ne] && (A(e).bigHour = void 0), A(e).parsedDateParts = e._a.slice(0), A(e).meridiem = e._meridiem, e._a[ne] = (function(q, re, $e) {
                return $e == null ? re : q.meridiemHour != null ? q.meridiemHour(re, $e) : q.isPM != null ? ((q = q.isPM($e)) && re < 12 && (re += 12), re = q || re !== 12 ? re : 0) : re
            })(e._locale, e._a[ne], e._meridiem), (m = A(e).era) !== null && (e._a[ie] = e._locale.erasConvertYear(m, e._a[ie])), wn(e), Xn(e)
        }
    }

    function He(e) {
        var n, i, r, l = e._i,
            h = e._f;
        if (e._locale = e._locale || Ze(e._l), l === null || h === void 0 && l === "") return Ht({
            nullInput: !0
        });
        if (typeof l == "string" && (e._i = l = e._locale.preparse(l)), Pe(l)) return new Tt(Xn(l));
        if (Ve(l)) e._d = l;
        else if (De(h)) {
            var d, m, v, y, x, C, q = e,
                re = !1,
                $e = q._f.length;
            if ($e === 0) A(q).invalidFormat = !0, q._d = new Date(NaN);
            else {
                for (y = 0; y < $e; y++) x = 0, C = !1, d = Fn({}, q), q._useUTC != null && (d._useUTC = q._useUTC), d._f = q._f[y], kn(d), Rn(d) && (C = !0), x = (x += A(d).charsLeftOver) + 10 * A(d).unusedTokens.length, A(d).score = x, re ? x < v && (v = x, m = d) : (v == null || x < v || C) && (v = x, m = d, C) && (re = !0);
                rt(q, m || d)
            }
        } else h ? kn(e) : te(h = (l = e)._i) ? l._d = new Date(b.now()) : Ve(h) ? l._d = new Date(h.valueOf()) : typeof h == "string" ? (i = l, (n = Ai.exec(i._i)) !== null ? i._d = new Date(+n[1]) : (Fe(i), i._isValid === !1 && (delete i._isValid, bt(i), i._isValid === !1) && (delete i._isValid, i._strict ? i._isValid = !1 : b.createFromInputFallback(i)))) : De(h) ? (l._a = st(h.slice(0), function(Dt) {
            return parseInt(Dt, 10)
        }), wn(l)) : yt(h) ? (n = l)._d || (r = (i = We(n._i)).day === void 0 ? i.date : i.day, n._a = st([i.year, i.month, r, i.hour, i.minute, i.second, i.millisecond], function(Dt) {
            return Dt && parseInt(Dt, 10)
        }), wn(n)) : ue(h) ? l._d = new Date(h) : b.createFromInputFallback(l);
        return Rn(e) || (e._d = null), e
    }

    function wt(e, n, i, r, l) {
        var h = {};
        return n !== !0 && n !== !1 || (r = n, n = void 0), i !== !0 && i !== !1 || (r = i, i = void 0), (yt(e) && jn(e) || De(e) && e.length === 0) && (e = void 0), h._isAMomentObject = !0, h._useUTC = h._isUTC = l, h._l = i, h._i = e, h._f = n, h._strict = r, (l = new Tt(Xn(He(l = h))))._nextDay && (l.add(1, "d"), l._nextDay = void 0), l
    }

    function B(e, n, i, r) {
        return wt(e, n, i, r, !1)
    }
    b.createFromInputFallback = Ae("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.", function(e) {
        e._d = new Date(e._i + (e._useUTC ? " UTC" : ""))
    }), b.ISO_8601 = function() {}, b.RFC_2822 = function() {}, xt = Ae("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/", function() {
        var e = B.apply(null, arguments);
        return this.isValid() && e.isValid() ? e < this ? this : e : Ht()
    }), Ut = Ae("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/", function() {
        var e = B.apply(null, arguments);
        return this.isValid() && e.isValid() ? this < e ? this : e : Ht()
    });

    function Yt(e, n) {
        var i, r;
        if (!(n = n.length === 1 && De(n[0]) ? n[0] : n).length) return B();
        for (i = n[0], r = 1; r < n.length; ++r) n[r].isValid() && !n[r][e](i) || (i = n[r]);
        return i
    }
    var Nt = ["year", "quarter", "month", "week", "day", "hour", "minute", "second", "millisecond"];

    function Sn(n) {
        var n = We(n),
            i = n.year || 0,
            r = n.quarter || 0,
            l = n.month || 0,
            h = n.week || n.isoWeek || 0,
            d = n.day || 0,
            m = n.hour || 0,
            v = n.minute || 0,
            y = n.second || 0,
            x = n.millisecond || 0;
        this._isValid = (function(C) {
            var q, re, $e = !1,
                Dt = Nt.length;
            for (q in C)
                if ($(C, q) && (se.call(Nt, q) === -1 || C[q] != null && isNaN(C[q]))) return !1;
            for (re = 0; re < Dt; ++re)
                if (C[Nt[re]]) {
                    if ($e) return !1;
                    parseFloat(C[Nt[re]]) !== j(C[Nt[re]]) && ($e = !0)
                }
            return !0
        })(n), this._milliseconds = +x + 1e3 * y + 6e4 * v + 1e3 * m * 60 * 60, this._days = +d + 7 * h, this._months = +l + 3 * r + 12 * i, this._data = {}, this._locale = Ze(), this._bubble()
    }

    function ct(e) {
        return e instanceof Sn
    }

    function Dn(e) {
        return e < 0 ? -1 * Math.round(-1 * e) : Math.round(e)
    }

    function oi(e, n) {
        M(e, 0, 0, function() {
            var i = this.utcOffset(),
                r = "+";
            return i < 0 && (i = -i, r = "-"), r + Ie(~~(i / 60), 2) + n + Ie(~~i % 60, 2)
        })
    }
    oi("Z", ":"), oi("ZZ", ""), S("Z", ot), S("ZZ", ot), U(["Z", "ZZ"], function(e, n, i) {
        i._useUTC = !0, i._tzm = ai(ot, e)
    });
    var ut = /([\+\-]|\d\d)/gi;

    function ai(e, i) {
        var i = (i || "").match(e);
        return i === null ? null : (i = 60 * (e = ((i[i.length - 1] || []) + "").match(ut) || ["-", 0, 0])[1] + j(e[2])) === 0 ? 0 : e[0] === "+" ? i : -i
    }

    function Ke(e, n) {
        var i;
        return n._isUTC ? (n = n.clone(), i = (Pe(e) || Ve(e) ? e : B(e)).valueOf() - n.valueOf(), n._d.setTime(n._d.valueOf() + i), b.updateOffset(n, !1), n) : B(e).local()
    }

    function en(e) {
        return -Math.round(e._d.getTimezoneOffset())
    }

    function li() {
        return !!this.isValid() && this._isUTC && this._offset === 0
    }
    b.updateOffset = function() {};
    var On = /^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/,
        ci = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;

    function ve(e, n) {
        var i, r = e;
        return ct(e) ? r = {
            ms: e._milliseconds,
            d: e._days,
            M: e._months
        } : ue(e) || !isNaN(+e) ? (r = {}, n ? r[n] = +e : r.milliseconds = +e) : (n = On.exec(e)) ? (i = n[1] === "-" ? -1 : 1, r = {
            y: 0,
            d: j(n[pe]) * i,
            h: j(n[ne]) * i,
            m: j(n[je]) * i,
            s: j(n[Re]) * i,
            ms: j(Dn(1e3 * n[Ct])) * i
        }) : (n = ci.exec(e)) ? (i = n[1] === "-" ? -1 : 1, r = {
            y: kt(n[2], i),
            M: kt(n[3], i),
            w: kt(n[4], i),
            d: kt(n[5], i),
            h: kt(n[6], i),
            m: kt(n[7], i),
            s: kt(n[8], i)
        }) : r == null ? r = {} : typeof r == "object" && ("from" in r || "to" in r) && (n = (function(l, h) {
            var d;
            return !l.isValid() || !h.isValid() ? {
                milliseconds: 0,
                months: 0
            } : (h = Ke(h, l), l.isBefore(h) ? d = ui(l, h) : ((d = ui(h, l)).milliseconds = -d.milliseconds, d.months = -d.months), d)
        })(B(r.from), B(r.to)), (r = {}).ms = n.milliseconds, r.M = n.months), i = new Sn(r), ct(e) && $(e, "_locale") && (i._locale = e._locale), ct(e) && $(e, "_isValid") && (i._isValid = e._isValid), i
    }

    function kt(e, n) {
        return e = e && parseFloat(e.replace(",", ".")), (isNaN(e) ? 0 : e) * n
    }

    function ui(e, n) {
        var i = {};
        return i.months = n.month() - e.month() + 12 * (n.year() - e.year()), e.clone().add(i.months, "M").isAfter(n) && --i.months, i.milliseconds = +n - +e.clone().add(i.months, "M"), i
    }

    function hi(e, n) {
        return function(i, r) {
            var l;
            return r === null || isNaN(+r) || (ii(n, "moment()." + n + "(period, number) is deprecated. Please use moment()." + n + "(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."), l = i, i = r, r = l), Pt(this, ve(i, r), e), this
        }
    }

    function Pt(e, d, i, r) {
        var l = d._milliseconds,
            h = Dn(d._days),
            d = Dn(d._months);
        e.isValid() && (r = r == null || r, d && Et(e, Bt(e, "Month") + d * i), h && mn(e, "Date", Bt(e, "Date") + h * i), l && e._d.setTime(e._d.valueOf() + l * i), r) && b.updateOffset(e, h || d)
    }
    ve.fn = Sn.prototype, ve.invalid = function() {
        return ve(NaN)
    }, qt = hi(1, "add"), _n = hi(-1, "subtract");

    function Pi(e) {
        return typeof e == "string" || e instanceof String
    }

    function Li(e) {
        return Pe(e) || Ve(e) || Pi(e) || ue(e) || (function(n) {
            var i = De(n),
                r = !1;
            return i && (r = n.filter(function(l) {
                return !ue(l) && Pi(n)
            }).length === 0), i && r
        })(e) || (function(n) {
            var i, r, l = yt(n) && !jn(n),
                h = !1,
                d = ["years", "year", "y", "months", "month", "M", "days", "day", "d", "dates", "date", "D", "hours", "hour", "h", "minutes", "minute", "m", "seconds", "second", "s", "milliseconds", "millisecond", "ms"],
                m = d.length;
            for (i = 0; i < m; i += 1) r = d[i], h = h || $(n, r);
            return l && h
        })(e) || e == null
    }

    function tn(e, n) {
        var i, r;
        return e.date() < n.date() ? -tn(n, e) : -((i = 12 * (n.year() - e.year()) + (n.month() - e.month())) + (n - (r = e.clone().add(i, "months")) < 0 ? (n - r) / (r - e.clone().add(i - 1, "months")) : (n - r) / (e.clone().add(1 + i, "months") - r))) || 0
    }

    function Mn(e) {
        return e === void 0 ? this._locale._abbr : ((e = Ze(e)) != null && (this._locale = e), this)
    }
    b.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", b.defaultFormatUtc = "YYYY-MM-DDTHH:mm:ss[Z]", Zn = Ae("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function(e) {
        return e === void 0 ? this.localeData() : this.locale(e)
    });

    function Jn() {
        return this._locale
    }
    var Ii = 126227808e5;

    function ht(e, n) {
        return (e % n + n) % n
    }

    function Wi(e, n, i) {
        return e < 100 && 0 <= e ? new Date(e + 400, n, i) - Ii : new Date(e, n, i).valueOf()
    }

    function di(e, n, i) {
        return e < 100 && 0 <= e ? Date.UTC(e + 400, n, i) - Ii : Date.UTC(e, n, i)
    }

    function Tn(e, n) {
        return n.erasAbbrRegex(e)
    }

    function xn() {
        for (var e, n, i, r = [], l = [], h = [], d = [], m = this.eras(), v = 0, y = m.length; v < y; ++v) e = lt(m[v].name), n = lt(m[v].abbr), i = lt(m[v].narrow), l.push(e), r.push(n), h.push(i), d.push(e), d.push(n), d.push(i);
        this._erasRegex = new RegExp("^(" + d.join("|") + ")", "i"), this._erasNameRegex = new RegExp("^(" + l.join("|") + ")", "i"), this._erasAbbrRegex = new RegExp("^(" + r.join("|") + ")", "i"), this._erasNarrowRegex = new RegExp("^(" + h.join("|") + ")", "i")
    }

    function nn(e, n) {
        M(0, [e, e.length], 0, n)
    }

    function fi(e, n, i, r, l) {
        var h;
        return e == null ? At(this, r, l).year : (h = Se(e, r, l), function(d, m, v, y, x) {
            return d = Ti(d, m, v, y, x), m = pn(d.year, 0, d.dayOfYear), this.year(m.getUTCFullYear()), this.month(m.getUTCMonth()), this.date(m.getUTCDate()), this
        }.call(this, e, n = h < n ? h : n, i, r, l))
    }
    M("N", 0, 0, "eraAbbr"), M("NN", 0, 0, "eraAbbr"), M("NNN", 0, 0, "eraAbbr"), M("NNNN", 0, 0, "eraName"), M("NNNNN", 0, 0, "eraNarrow"), M("y", ["y", 1], "yo", "eraYear"), M("y", ["yy", 2], 0, "eraYear"), M("y", ["yyy", 3], 0, "eraYear"), M("y", ["yyyy", 4], 0, "eraYear"), S("N", Tn), S("NN", Tn), S("NNN", Tn), S("NNNN", function(e, n) {
        return n.erasNameRegex(e)
    }), S("NNNNN", function(e, n) {
        return n.erasNarrowRegex(e)
    }), U(["N", "NN", "NNN", "NNNN", "NNNNN"], function(e, n, i, r) {
        r = i._locale.erasParse(e, r, i._strict), r ? A(i).era = r : A(i).invalidEra = e
    }), S("y", ze), S("yy", ze), S("yyy", ze), S("yyyy", ze), S("yo", function(e, n) {
        return n._eraYearOrdinalRegex || ze
    }), U(["y", "yy", "yyy", "yyyy"], ie), U(["yo"], function(e, n, i, r) {
        var l;
        i._locale._eraYearOrdinalRegex && (l = e.match(i._locale._eraYearOrdinalRegex)), i._locale.eraYearOrdinalParse ? n[ie] = i._locale.eraYearOrdinalParse(e, l) : n[ie] = parseInt(e, 10)
    }), M(0, ["gg", 2], 0, function() {
        return this.weekYear() % 100
    }), M(0, ["GG", 2], 0, function() {
        return this.isoWeekYear() % 100
    }), nn("gggg", "weekYear"), nn("ggggg", "weekYear"), nn("GGGG", "isoWeekYear"), nn("GGGGG", "isoWeekYear"), S("G", un), S("g", un), S("GG", G, le), S("gg", G, le), S("GGGG", pt, dt), S("gggg", pt, dt), S("GGGGG", St, mt), S("ggggg", St, mt), dn(["gggg", "ggggg", "GGGG", "GGGGG"], function(e, n, i, r) {
        n[r.substr(0, 2)] = j(e)
    }), dn(["gg", "GG"], function(e, n, i, r) {
        n[r] = b.parseTwoDigitYear(e)
    }), M("Q", 0, "Qo", "quarter"), S("Q", me), U("Q", function(e, n) {
        n[ke] = 3 * (j(e) - 1)
    }), M("D", ["DD", 2], "Do", "date"), S("D", G, g), S("DD", G, le), S("Do", function(e, n) {
        return e ? n._dayOfMonthOrdinalParse || n._ordinalParse : n._dayOfMonthOrdinalParseLenient
    }), U(["D", "DD"], pe), U("Do", function(e, n) {
        n[pe] = j(e.match(G)[0])
    }), pt = Gt("Date", !0), M("DDD", ["DDDD", 3], "DDDo", "dayOfYear"), S("DDD", Vt), S("DDDD", T), U(["DDD", "DDDD"], function(e, n, i) {
        i._dayOfYear = j(e)
    }), M("m", ["mm", 2], 0, "minute"), S("m", G, I), S("mm", G, le), U(["m", "mm"], je);
    var Ne, dt = Gt("Minutes", !1),
        St = (M("s", ["ss", 2], 0, "second"), S("s", G, I), S("ss", G, le), U(["s", "ss"], Re), Gt("Seconds", !1));
    for (M("S", 0, 0, function() {
            return ~~(this.millisecond() / 100)
        }), M(0, ["SS", 2], 0, function() {
            return ~~(this.millisecond() / 10)
        }), M(0, ["SSS", 3], 0, "millisecond"), M(0, ["SSSS", 4], 0, function() {
            return 10 * this.millisecond()
        }), M(0, ["SSSSS", 5], 0, function() {
            return 100 * this.millisecond()
        }), M(0, ["SSSSSS", 6], 0, function() {
            return 1e3 * this.millisecond()
        }), M(0, ["SSSSSSS", 7], 0, function() {
            return 1e4 * this.millisecond()
        }), M(0, ["SSSSSSSS", 8], 0, function() {
            return 1e5 * this.millisecond()
        }), M(0, ["SSSSSSSSS", 9], 0, function() {
            return 1e6 * this.millisecond()
        }), S("S", Vt, me), S("SS", Vt, le), S("SSS", Vt, T), Ne = "SSSS"; Ne.length <= 9; Ne += "S") S(Ne, ze);

    function ji(e, n) {
        n[Ct] = j(1e3 * ("0." + e))
    }
    for (Ne = "S"; Ne.length <= 9; Ne += "S") U(Ne, ji);
    mt = Gt("Milliseconds", !1), M("z", 0, 0, "zoneAbbr"), M("zz", 0, 0, "zoneName"), g = Tt.prototype;

    function mi(e) {
        return e
    }
    g.add = qt, g.calendar = function(i, l) {
        arguments.length === 1 && (arguments[0] ? Li(arguments[0]) ? (i = arguments[0], l = void 0) : (function(h) {
            for (var d = yt(h) && !jn(h), m = !1, v = ["sameDay", "nextDay", "lastDay", "nextWeek", "lastWeek", "sameElse"], y = 0; y < v.length; y += 1) m = m || $(h, v[y]);
            return d && m
        })(arguments[0]) && (l = arguments[0], i = void 0) : l = i = void 0);
        var i = i || B(),
            r = Ke(i, this).startOf("day"),
            r = b.calendarFormat(this, r) || "sameElse",
            l = l && (Le(l[r]) ? l[r].call(this, i) : l[r]);
        return this.format(l || this.localeData().calendar(r, this, B(i)))
    }, g.clone = function() {
        return new Tt(this)
    }, g.diff = function(e, n, i) {
        var r, l, h;
        if (!this.isValid()) return NaN;
        if (!(r = Ke(e, this)).isValid()) return NaN;
        switch (l = 6e4 * (r.utcOffset() - this.utcOffset()), n = we(n)) {
            case "year":
                h = tn(this, r) / 12;
                break;
            case "month":
                h = tn(this, r);
                break;
            case "quarter":
                h = tn(this, r) / 3;
                break;
            case "second":
                h = (this - r) / 1e3;
                break;
            case "minute":
                h = (this - r) / 6e4;
                break;
            case "hour":
                h = (this - r) / 36e5;
                break;
            case "day":
                h = (this - r - l) / 864e5;
                break;
            case "week":
                h = (this - r - l) / 6048e5;
                break;
            default:
                h = this - r
        }
        return i ? h : Ye(h)
    }, g.endOf = function(e) {
        var n, i;
        if ((e = we(e)) !== void 0 && e !== "millisecond" && this.isValid()) {
            switch (i = this._isUTC ? di : Wi, e) {
                case "year":
                    n = i(this.year() + 1, 0, 1) - 1;
                    break;
                case "quarter":
                    n = i(this.year(), this.month() - this.month() % 3 + 3, 1) - 1;
                    break;
                case "month":
                    n = i(this.year(), this.month() + 1, 1) - 1;
                    break;
                case "week":
                    n = i(this.year(), this.month(), this.date() - this.weekday() + 7) - 1;
                    break;
                case "isoWeek":
                    n = i(this.year(), this.month(), this.date() - (this.isoWeekday() - 1) + 7) - 1;
                    break;
                case "day":
                case "date":
                    n = i(this.year(), this.month(), this.date() + 1) - 1;
                    break;
                case "hour":
                    n = this._d.valueOf(), n += 36e5 - ht(n + (this._isUTC ? 0 : 6e4 * this.utcOffset()), 36e5) - 1;
                    break;
                case "minute":
                    n = this._d.valueOf(), n += 6e4 - ht(n, 6e4) - 1;
                    break;
                case "second":
                    n = this._d.valueOf(), n += 1e3 - ht(n, 1e3) - 1;
                    break
            }
            this._d.setTime(n), b.updateOffset(this, !0)
        }
        return this
    }, g.format = function(e) {
        return e = e || (this.isUtc() ? b.defaultFormatUtc : b.defaultFormat), e = p(this, e), this.localeData().postformat(e)
    }, g.from = function(e, n) {
        return this.isValid() && (Pe(e) && e.isValid() || B(e).isValid()) ? ve({
            to: this,
            from: e
        }).locale(this.locale()).humanize(!n) : this.localeData().invalidDate()
    }, g.fromNow = function(e) {
        return this.from(B(), e)
    }, g.to = function(e, n) {
        return this.isValid() && (Pe(e) && e.isValid() || B(e).isValid()) ? ve({
            from: this,
            to: e
        }).locale(this.locale()).humanize(!n) : this.localeData().invalidDate()
    }, g.toNow = function(e) {
        return this.to(B(), e)
    }, g.get = function(e) {
        return Le(this[e = we(e)]) ? this[e]() : this
    }, g.invalidAt = function() {
        return A(this).overflow
    }, g.isAfter = function(e, n) {
        return e = Pe(e) ? e : B(e), !(!this.isValid() || !e.isValid()) && ((n = we(n) || "millisecond") === "millisecond" ? this.valueOf() > e.valueOf() : e.valueOf() < this.clone().startOf(n).valueOf())
    }, g.isBefore = function(e, n) {
        return e = Pe(e) ? e : B(e), !(!this.isValid() || !e.isValid()) && ((n = we(n) || "millisecond") === "millisecond" ? this.valueOf() < e.valueOf() : this.clone().endOf(n).valueOf() < e.valueOf())
    }, g.isBetween = function(e, n, i, r) {
        return e = Pe(e) ? e : B(e), n = Pe(n) ? n : B(n), !!(this.isValid() && e.isValid() && n.isValid()) && ((r = r || "()")[0] === "(" ? this.isAfter(e, i) : !this.isBefore(e, i)) && (r[1] === ")" ? this.isBefore(n, i) : !this.isAfter(n, i))
    }, g.isSame = function(i, n) {
        var i = Pe(i) ? i : B(i);
        return !(!this.isValid() || !i.isValid()) && ((n = we(n) || "millisecond") === "millisecond" ? this.valueOf() === i.valueOf() : (i = i.valueOf(), this.clone().startOf(n).valueOf() <= i && i <= this.clone().endOf(n).valueOf()))
    }, g.isSameOrAfter = function(e, n) {
        return this.isSame(e, n) || this.isAfter(e, n)
    }, g.isSameOrBefore = function(e, n) {
        return this.isSame(e, n) || this.isBefore(e, n)
    }, g.isValid = function() {
        return Rn(this)
    }, g.lang = Zn, g.locale = Mn, g.localeData = Jn, g.max = Ut, g.min = xt, g.parsingFlags = function() {
        return rt({}, A(this))
    }, g.set = function(e, n) {
        if (typeof e == "object")
            for (var i = (function(h) {
                    var d, m = [];
                    for (d in h) $(h, d) && m.push({
                        unit: d,
                        priority: cn[d]
                    });
                    return m.sort(function(v, y) {
                        return v.priority - y.priority
                    }), m
                })(e = We(e)), r = i.length, l = 0; l < r; l++) this[i[l].unit](e[i[l].unit]);
        else if (Le(this[e = we(e)])) return this[e](n);
        return this
    }, g.startOf = function(e) {
        var n, i;
        if ((e = we(e)) !== void 0 && e !== "millisecond" && this.isValid()) {
            switch (i = this._isUTC ? di : Wi, e) {
                case "year":
                    n = i(this.year(), 0, 1);
                    break;
                case "quarter":
                    n = i(this.year(), this.month() - this.month() % 3, 1);
                    break;
                case "month":
                    n = i(this.year(), this.month(), 1);
                    break;
                case "week":
                    n = i(this.year(), this.month(), this.date() - this.weekday());
                    break;
                case "isoWeek":
                    n = i(this.year(), this.month(), this.date() - (this.isoWeekday() - 1));
                    break;
                case "day":
                case "date":
                    n = i(this.year(), this.month(), this.date());
                    break;
                case "hour":
                    n = this._d.valueOf(), n -= ht(n + (this._isUTC ? 0 : 6e4 * this.utcOffset()), 36e5);
                    break;
                case "minute":
                    n = this._d.valueOf(), n -= ht(n, 6e4);
                    break;
                case "second":
                    n = this._d.valueOf(), n -= ht(n, 1e3);
                    break
            }
            this._d.setTime(n), b.updateOffset(this, !0)
        }
        return this
    }, g.subtract = _n, g.toArray = function() {
        var e = this;
        return [e.year(), e.month(), e.date(), e.hour(), e.minute(), e.second(), e.millisecond()]
    }, g.toObject = function() {
        var e = this;
        return {
            years: e.year(),
            months: e.month(),
            date: e.date(),
            hours: e.hours(),
            minutes: e.minutes(),
            seconds: e.seconds(),
            milliseconds: e.milliseconds()
        }
    }, g.toDate = function() {
        return new Date(this.valueOf())
    }, g.toISOString = function(e) {
        var n;
        return this.isValid() ? (n = (e = e !== !0) ? this.clone().utc() : this).year() < 0 || 9999 < n.year() ? p(n, e ? "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYYYY-MM-DD[T]HH:mm:ss.SSSZ") : Le(Date.prototype.toISOString) ? e ? this.toDate().toISOString() : new Date(this.valueOf() + 60 * this.utcOffset() * 1e3).toISOString().replace("Z", p(n, "Z")) : p(n, e ? "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYY-MM-DD[T]HH:mm:ss.SSSZ") : null
    }, g.inspect = function() {
        var e, n, i;
        return this.isValid() ? (n = "moment", e = "", this.isLocal() || (n = this.utcOffset() === 0 ? "moment.utc" : "moment.parseZone", e = "Z"), n = "[" + n + '("]', i = 0 <= this.year() && this.year() <= 9999 ? "YYYY" : "YYYYYY", this.format(n + i + "-MM-DD[T]HH:mm:ss.SSS" + (e + '[")]'))) : "moment.invalid(/* " + this._i + " */)"
    }, typeof Symbol < "u" && Symbol.for != null && (g[Symbol.for("nodejs.util.inspect.custom")] = function() {
        return "Moment<" + this.format() + ">"
    }), g.toJSON = function() {
        return this.isValid() ? this.toISOString() : null
    }, g.toString = function() {
        return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")
    }, g.unix = function() {
        return Math.floor(this.valueOf() / 1e3)
    }, g.valueOf = function() {
        return this._d.valueOf() - 6e4 * (this._offset || 0)
    }, g.creationData = function() {
        return {
            input: this._i,
            format: this._f,
            locale: this._locale,
            isUTC: this._isUTC,
            strict: this._strict
        }
    }, g.eraName = function() {
        for (var e, n = this.localeData().eras(), i = 0, r = n.length; i < r; ++i)
            if (e = this.clone().startOf("day").valueOf(), n[i].since <= e && e <= n[i].until || n[i].until <= e && e <= n[i].since) return n[i].name;
        return ""
    }, g.eraNarrow = function() {
        for (var e, n = this.localeData().eras(), i = 0, r = n.length; i < r; ++i)
            if (e = this.clone().startOf("day").valueOf(), n[i].since <= e && e <= n[i].until || n[i].until <= e && e <= n[i].since) return n[i].narrow;
        return ""
    }, g.eraAbbr = function() {
        for (var e, n = this.localeData().eras(), i = 0, r = n.length; i < r; ++i)
            if (e = this.clone().startOf("day").valueOf(), n[i].since <= e && e <= n[i].until || n[i].until <= e && e <= n[i].since) return n[i].abbr;
        return ""
    }, g.eraYear = function() {
        for (var e, n, i = this.localeData().eras(), r = 0, l = i.length; r < l; ++r)
            if (e = i[r].since <= i[r].until ? 1 : -1, n = this.clone().startOf("day").valueOf(), i[r].since <= n && n <= i[r].until || i[r].until <= n && n <= i[r].since) return (this.year() - b(i[r].since).year()) * e + i[r].offset;
        return this.year()
    }, g.year = It, g.isLeapYear = function() {
        return zn(this.year())
    }, g.weekYear = function(e) {
        return fi.call(this, e, this.week(), this.weekday() + this.localeData()._week.dow, this.localeData()._week.dow, this.localeData()._week.doy)
    }, g.isoWeekYear = function(e) {
        return fi.call(this, e, this.isoWeek(), this.isoWeekday(), 1, 4)
    }, g.quarter = g.quarters = function(e) {
        return e == null ? Math.ceil((this.month() + 1) / 3) : this.month(3 * (e - 1) + this.month() % 3)
    }, g.month = Zt, g.daysInMonth = function() {
        return Gn(this.year(), this.month())
    }, g.week = g.weeks = function(e) {
        var n = this.localeData().week(this);
        return e == null ? n : this.add(7 * (e - n), "d")
    }, g.isoWeek = g.isoWeeks = function(e) {
        var n = At(this, 1, 4).week;
        return e == null ? n : this.add(7 * (e - n), "d")
    }, g.weeksInYear = function() {
        var e = this.localeData()._week;
        return Se(this.year(), e.dow, e.doy)
    }, g.weeksInWeekYear = function() {
        var e = this.localeData()._week;
        return Se(this.weekYear(), e.dow, e.doy)
    }, g.isoWeeksInYear = function() {
        return Se(this.year(), 1, 4)
    }, g.isoWeeksInISOWeekYear = function() {
        return Se(this.isoWeekYear(), 1, 4)
    }, g.date = pt, g.day = g.days = function(e) {
        var n, i, r;
        return this.isValid() ? (n = Bt(this, "Day"), e != null ? (i = e, r = this.localeData(), e = typeof i != "string" ? i : isNaN(i) ? typeof(i = r.weekdaysParse(i)) == "number" ? i : null : parseInt(i, 10), this.add(e - n, "d")) : n) : e != null ? this : NaN
    }, g.weekday = function(e) {
        var n;
        return this.isValid() ? (n = (this.day() + 7 - this.localeData()._week.dow) % 7, e == null ? n : this.add(e - n, "d")) : e != null ? this : NaN
    }, g.isoWeekday = function(e) {
        var n, i;
        return this.isValid() ? e != null ? (n = e, i = this.localeData(), i = typeof n == "string" ? i.weekdaysParse(n) % 7 || 7 : isNaN(n) ? null : n, this.day(this.day() % 7 ? i : i - 7)) : this.day() || 7 : e != null ? this : NaN
    }, g.dayOfYear = function(e) {
        var n = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1;
        return e == null ? n : this.add(e - n, "d")
    }, g.hour = g.hours = at, g.minute = g.minutes = dt, g.second = g.seconds = St, g.millisecond = g.milliseconds = mt, g.utcOffset = function(e, n, i) {
        var r, l = this._offset || 0;
        if (!this.isValid()) return e != null ? this : NaN;
        if (e == null) return this._isUTC ? l : en(this);
        if (typeof e == "string") {
            if ((e = ai(ot, e)) === null) return this
        } else Math.abs(e) < 16 && !i && (e *= 60);
        return !this._isUTC && n && (r = en(this)), this._offset = e, this._isUTC = !0, r != null && this.add(r, "m"), l !== e && (!n || this._changeInProgress ? Pt(this, ve(e - l, "m"), 1, !1) : this._changeInProgress || (this._changeInProgress = !0, b.updateOffset(this, !0), this._changeInProgress = null)), this
    }, g.utc = function(e) {
        return this.utcOffset(0, e)
    }, g.local = function(e) {
        return this._isUTC && (this.utcOffset(0, e), this._isUTC = !1, e) && this.subtract(en(this), "m"), this
    }, g.parseZone = function() {
        var e;
        return this._tzm != null ? this.utcOffset(this._tzm, !1, !0) : typeof this._i == "string" && ((e = ai(hn, this._i)) != null ? this.utcOffset(e) : this.utcOffset(0, !0)), this
    }, g.hasAlignedHourOffset = function(e) {
        return !!this.isValid() && (e = e ? B(e).utcOffset() : 0, (this.utcOffset() - e) % 60 == 0)
    }, g.isDST = function() {
        return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset()
    }, g.isLocal = function() {
        return !!this.isValid() && !this._isUTC
    }, g.isUtcOffset = function() {
        return !!this.isValid() && this._isUTC
    }, g.isUtc = li, g.isUTC = li, g.zoneAbbr = function() {
        return this._isUTC ? "UTC" : ""
    }, g.zoneName = function() {
        return this._isUTC ? "Coordinated Universal Time" : ""
    }, g.dates = Ae("dates accessor is deprecated. Use date instead.", pt), g.months = Ae("months accessor is deprecated. Use month instead", Zt), g.years = Ae("years accessor is deprecated. Use year instead", It), g.zone = Ae("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/", function(e, n) {
        return e != null ? (this.utcOffset(e = typeof e != "string" ? -e : e, n), this) : -this.utcOffset()
    }), g.isDSTShifted = Ae("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information", function() {
        var e, n;
        return te(this._isDSTShifted) && (Fn(e = {}, this), (e = He(e))._a ? (n = (e._isUTC ? Oe : B)(e._a), this._isDSTShifted = this.isValid() && 0 < (function(i, r, l) {
            for (var h = Math.min(i.length, r.length), d = Math.abs(i.length - r.length), m = 0, v = 0; v < h; v++)(l && i[v] !== r[v] || !l && j(i[v]) !== j(r[v])) && m++;
            return m + d
        })(e._a, n.toArray())) : this._isDSTShifted = !1), this._isDSTShifted
    }), I = $n.prototype;

    function ft(e, n, i, h) {
        var l = Ze(),
            h = Oe().set(h, n);
        return l[i](h, e)
    }

    function Ri(e, n, i) {
        if (ue(e) && (n = e, e = void 0), e = e || "", n != null) return ft(e, n, i, "month");
        for (var r = [], l = 0; l < 12; l++) r[l] = ft(e, l, i, "month");
        return r
    }

    function ei(e, n, i, r) {
        n = (typeof e == "boolean" ? ue(n) && (i = n, n = void 0) : (n = e, e = !1, ue(i = n) && (i = n, n = void 0)), n || "");
        var l, h = Ze(),
            d = e ? h._week.dow : 0,
            m = [];
        if (i != null) return ft(n, (i + d) % 7, r, "day");
        for (l = 0; l < 7; l++) m[l] = ft(n, (l + d) % 7, r, "day");
        return m
    }
    I.calendar = function(e, n, i) {
        return Le(e = this._calendar[e] || this._calendar.sameElse) ? e.call(n, i) : e
    }, I.longDateFormat = function(e) {
        var n = this._longDateFormat[e],
            i = this._longDateFormat[e.toUpperCase()];
        return n || !i ? n : (this._longDateFormat[e] = i.match(Un).map(function(r) {
            return r === "MMMM" || r === "MM" || r === "DD" || r === "dddd" ? r.slice(1) : r
        }).join(""), this._longDateFormat[e])
    }, I.invalidDate = function() {
        return this._invalidDate
    }, I.ordinal = function(e) {
        return this._ordinal.replace("%d", e)
    }, I.preparse = mi, I.postformat = mi, I.relativeTime = function(e, n, i, r) {
        var l = this._relativeTime[i];
        return Le(l) ? l(e, n, i, r) : l.replace(/%d/i, e)
    }, I.pastFuture = function(e, n) {
        return Le(e = this._relativeTime[0 < e ? "future" : "past"]) ? e(n) : e.replace(/%s/i, n)
    }, I.set = function(e) {
        var n, i;
        for (i in e) $(e, i) && (Le(n = e[i]) ? this[i] = n : this["_" + i] = n);
        this._config = e, this._dayOfMonthOrdinalParseLenient = new RegExp((this._dayOfMonthOrdinalParse.source || this._ordinalParse.source) + "|" + /\d{1,2}/.source)
    }, I.eras = function(e, n) {
        for (var i, r = this._eras || Ze("en")._eras, l = 0, h = r.length; l < h; ++l) switch (typeof r[l].since === "string" && (i = b(r[l].since).startOf("day"), r[l].since = i.valueOf()), typeof r[l].until) {
            case "undefined":
                r[l].until = 1 / 0;
                break;
            case "string":
                i = b(r[l].until).startOf("day").valueOf(), r[l].until = i.valueOf();
                break
        }
        return r
    }, I.erasParse = function(e, n, i) {
        var r, l, h, d, m, v = this.eras();
        for (e = e.toUpperCase(), r = 0, l = v.length; r < l; ++r)
            if (h = v[r].name.toUpperCase(), d = v[r].abbr.toUpperCase(), m = v[r].narrow.toUpperCase(), i) switch (n) {
                case "N":
                case "NN":
                case "NNN":
                    if (d === e) return v[r];
                    break;
                case "NNNN":
                    if (h === e) return v[r];
                    break;
                case "NNNNN":
                    if (m === e) return v[r];
                    break
            } else if (0 <= [h, d, m].indexOf(e)) return v[r]
    }, I.erasConvertYear = function(e, n) {
        var i = e.since <= e.until ? 1 : -1;
        return n === void 0 ? b(e.since).year() : b(e.since).year() + (n - e.offset) * i
    }, I.erasAbbrRegex = function(e) {
        return $(this, "_erasAbbrRegex") || xn.call(this), e ? this._erasAbbrRegex : this._erasRegex
    }, I.erasNameRegex = function(e) {
        return $(this, "_erasNameRegex") || xn.call(this), e ? this._erasNameRegex : this._erasRegex
    }, I.erasNarrowRegex = function(e) {
        return $(this, "_erasNarrowRegex") || xn.call(this), e ? this._erasNarrowRegex : this._erasRegex
    }, I.months = function(e, n) {
        return e ? (De(this._months) ? this._months : this._months[(this._months.isFormat || Oi).test(n) ? "format" : "standalone"])[e.month()] : De(this._months) ? this._months : this._months.standalone
    }, I.monthsShort = function(e, n) {
        return e ? (De(this._monthsShort) ? this._monthsShort : this._monthsShort[Oi.test(n) ? "format" : "standalone"])[e.month()] : De(this._monthsShort) ? this._monthsShort : this._monthsShort.standalone
    }, I.monthsParse = function(e, n, i) {
        var r, l;
        if (this._monthsParseExact) return function(C, d, m) {
            var v, y, x, C = C.toLocaleLowerCase();
            if (!this._monthsParse)
                for (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = [], v = 0; v < 12; ++v) x = Oe([2e3, v]), this._shortMonthsParse[v] = this.monthsShort(x, "").toLocaleLowerCase(), this._longMonthsParse[v] = this.months(x, "").toLocaleLowerCase();
            return m ? d === "MMM" ? (y = se.call(this._shortMonthsParse, C)) !== -1 ? y : null : (y = se.call(this._longMonthsParse, C)) !== -1 ? y : null : d === "MMM" ? (y = se.call(this._shortMonthsParse, C)) !== -1 || (y = se.call(this._longMonthsParse, C)) !== -1 ? y : null : (y = se.call(this._longMonthsParse, C)) !== -1 || (y = se.call(this._shortMonthsParse, C)) !== -1 ? y : null
        }.call(this, e, n, i);
        for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), r = 0; r < 12; r++)
            if (l = Oe([2e3, r]), i && !this._longMonthsParse[r] && (this._longMonthsParse[r] = new RegExp("^" + this.months(l, "").replace(".", "") + "$", "i"), this._shortMonthsParse[r] = new RegExp("^" + this.monthsShort(l, "").replace(".", "") + "$", "i")), i || this._monthsParse[r] || (l = "^" + this.months(l, "") + "|^" + this.monthsShort(l, ""), this._monthsParse[r] = new RegExp(l.replace(".", ""), "i")), i && n === "MMMM" && this._longMonthsParse[r].test(e) || i && n === "MMM" && this._shortMonthsParse[r].test(e) || !i && this._monthsParse[r].test(e)) return r
    }, I.monthsRegex = function(e) {
        return this._monthsParseExact ? ($(this, "_monthsRegex") || Mi.call(this), e ? this._monthsStrictRegex : this._monthsRegex) : ($(this, "_monthsRegex") || (this._monthsRegex = Ji), this._monthsStrictRegex && e ? this._monthsStrictRegex : this._monthsRegex)
    }, I.monthsShortRegex = function(e) {
        return this._monthsParseExact ? ($(this, "_monthsRegex") || Mi.call(this), e ? this._monthsShortStrictRegex : this._monthsShortRegex) : ($(this, "_monthsShortRegex") || (this._monthsShortRegex = Qi), this._monthsShortStrictRegex && e ? this._monthsShortStrictRegex : this._monthsShortRegex)
    }, I.week = function(e) {
        return At(e, this._week.dow, this._week.doy).week
    }, I.firstDayOfYear = function() {
        return this._week.doy
    }, I.firstDayOfWeek = function() {
        return this._week.dow
    }, I.weekdays = function(e, n) {
        return n = De(this._weekdays) ? this._weekdays : this._weekdays[e && e !== !0 && this._weekdays.isFormat.test(n) ? "format" : "standalone"], e === !0 ? Kt(n, this._week.dow) : e ? n[e.day()] : n
    }, I.weekdaysMin = function(e) {
        return e === !0 ? Kt(this._weekdaysMin, this._week.dow) : e ? this._weekdaysMin[e.day()] : this._weekdaysMin
    }, I.weekdaysShort = function(e) {
        return e === !0 ? Kt(this._weekdaysShort, this._week.dow) : e ? this._weekdaysShort[e.day()] : this._weekdaysShort
    }, I.weekdaysParse = function(e, n, i) {
        var r, l;
        if (this._weekdaysParseExact) return function(C, d, m) {
            var v, y, x, C = C.toLocaleLowerCase();
            if (!this._weekdaysParse)
                for (this._weekdaysParse = [], this._shortWeekdaysParse = [], this._minWeekdaysParse = [], v = 0; v < 7; ++v) x = Oe([2e3, 1]).day(v), this._minWeekdaysParse[v] = this.weekdaysMin(x, "").toLocaleLowerCase(), this._shortWeekdaysParse[v] = this.weekdaysShort(x, "").toLocaleLowerCase(), this._weekdaysParse[v] = this.weekdays(x, "").toLocaleLowerCase();
            return m ? d === "dddd" ? (y = se.call(this._weekdaysParse, C)) !== -1 ? y : null : d === "ddd" ? (y = se.call(this._shortWeekdaysParse, C)) !== -1 ? y : null : (y = se.call(this._minWeekdaysParse, C)) !== -1 ? y : null : d === "dddd" ? (y = se.call(this._weekdaysParse, C)) !== -1 || (y = se.call(this._shortWeekdaysParse, C)) !== -1 || (y = se.call(this._minWeekdaysParse, C)) !== -1 ? y : null : d === "ddd" ? (y = se.call(this._shortWeekdaysParse, C)) !== -1 || (y = se.call(this._weekdaysParse, C)) !== -1 || (y = se.call(this._minWeekdaysParse, C)) !== -1 ? y : null : (y = se.call(this._minWeekdaysParse, C)) !== -1 || (y = se.call(this._weekdaysParse, C)) !== -1 || (y = se.call(this._shortWeekdaysParse, C)) !== -1 ? y : null
        }.call(this, e, n, i);
        for (this._weekdaysParse || (this._weekdaysParse = [], this._minWeekdaysParse = [], this._shortWeekdaysParse = [], this._fullWeekdaysParse = []), r = 0; r < 7; r++)
            if (l = Oe([2e3, 1]).day(r), i && !this._fullWeekdaysParse[r] && (this._fullWeekdaysParse[r] = new RegExp("^" + this.weekdays(l, "").replace(".", "\\.?") + "$", "i"), this._shortWeekdaysParse[r] = new RegExp("^" + this.weekdaysShort(l, "").replace(".", "\\.?") + "$", "i"), this._minWeekdaysParse[r] = new RegExp("^" + this.weekdaysMin(l, "").replace(".", "\\.?") + "$", "i")), this._weekdaysParse[r] || (l = "^" + this.weekdays(l, "") + "|^" + this.weekdaysShort(l, "") + "|^" + this.weekdaysMin(l, ""), this._weekdaysParse[r] = new RegExp(l.replace(".", ""), "i")), i && n === "dddd" && this._fullWeekdaysParse[r].test(e) || i && n === "ddd" && this._shortWeekdaysParse[r].test(e) || i && n === "dd" && this._minWeekdaysParse[r].test(e) || !i && this._weekdaysParse[r].test(e)) return r
    }, I.weekdaysRegex = function(e) {
        return this._weekdaysParseExact ? ($(this, "_weekdaysRegex") || ge.call(this), e ? this._weekdaysStrictRegex : this._weekdaysRegex) : ($(this, "_weekdaysRegex") || (this._weekdaysRegex = ts), this._weekdaysStrictRegex && e ? this._weekdaysStrictRegex : this._weekdaysRegex)
    }, I.weekdaysShortRegex = function(e) {
        return this._weekdaysParseExact ? ($(this, "_weekdaysRegex") || ge.call(this), e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex) : ($(this, "_weekdaysShortRegex") || (this._weekdaysShortRegex = Xt), this._weekdaysShortStrictRegex && e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex)
    }, I.weekdaysMinRegex = function(e) {
        return this._weekdaysParseExact ? ($(this, "_weekdaysRegex") || ge.call(this), e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex) : ($(this, "_weekdaysMinRegex") || (this._weekdaysMinRegex = _e), this._weekdaysMinStrictRegex && e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex)
    }, I.isPM = function(e) {
        return (e + "").toLowerCase().charAt(0) === "p"
    }, I.meridiem = function(e, n, i) {
        return 11 < e ? i ? "pm" : "PM" : i ? "am" : "AM"
    }, qe("en", {
        eras: [{
            since: "0001-01-01",
            until: 1 / 0,
            offset: 1,
            name: "Anno Domini",
            narrow: "AD",
            abbr: "AD"
        }, {
            since: "0000-12-31",
            until: -1 / 0,
            offset: 1,
            name: "Before Christ",
            narrow: "BC",
            abbr: "BC"
        }],
        dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/,
        ordinal: function(e) {
            var n = e % 10;
            return e + (j(e % 100 / 10) === 1 ? "th" : n == 1 ? "st" : n == 2 ? "nd" : n == 3 ? "rd" : "th")
        }
    }), b.lang = Ae("moment.lang is deprecated. Use moment.locale instead.", qe), b.langData = Ae("moment.langData is deprecated. Use moment.localeData instead.", Ze);
    var Xe = Math.abs;

    function pi(e, n, i, r) {
        return n = ve(n, i), e._milliseconds += r * n._milliseconds, e._days += r * n._days, e._months += r * n._months, e._bubble()
    }

    function _i(e) {
        return e < 0 ? Math.floor(e) : Math.ceil(e)
    }

    function gi(e) {
        return 4800 * e / 146097
    }

    function Cn(e) {
        return 146097 * e / 4800
    }

    function Qe(e) {
        return function() {
            return this.as(e)
        }
    }
    me = Qe("ms"), le = Qe("s"), Vt = Qe("m"), T = Qe("h"), qt = Qe("d"), Ut = Qe("w"), xt = Qe("M"), _n = Qe("Q"), at = Qe("y"), dt = me;

    function Lt(e) {
        return function() {
            return this.isValid() ? this._data[e] : NaN
        }
    }
    var St = Lt("milliseconds"),
        mt = Lt("seconds"),
        pt = Lt("minutes"),
        It = Lt("hours"),
        I = Lt("days"),
        ns = Lt("months"),
        yi = Lt("years"),
        Je = Math.round,
        Wt = {
            ss: 44,
            s: 45,
            m: 45,
            h: 22,
            d: 26,
            w: null,
            M: 11
        };

    function jt(e, n, i, r) {
        var y = ve(e).abs(),
            x = Je(y.as("s")),
            l = Je(y.as("m")),
            h = Je(y.as("h")),
            d = Je(y.as("d")),
            m = Je(y.as("M")),
            v = Je(y.as("w")),
            y = Je(y.as("y")),
            x = (x <= i.ss ? ["s", x] : x < i.s && ["ss", x]) || (l <= 1 ? ["m"] : l < i.m && ["mm", l]) || (h <= 1 ? ["h"] : h < i.h && ["hh", h]) || (d <= 1 ? ["d"] : d < i.d && ["dd", d]);
        return (x = (x = i.w != null ? x || (v <= 1 ? ["w"] : v < i.w && ["ww", v]) : x) || (m <= 1 ? ["M"] : m < i.M && ["MM", m]) || (y <= 1 ? ["y"] : ["yy", y]))[2] = n, x[3] = 0 < +e, x[4] = r,
            function(C, q, re, $e, Dt) {
                return Dt.relativeTime(q || 1, !!re, C, $e)
            }.apply(null, x)
    }
    var En = Math.abs;

    function sn(e) {
        return (0 < e) - (e < 0) || +e
    }

    function An() {
        var e, n, i, r, l, h, d, m, v, y, x;
        return this.isValid() ? (e = En(this._milliseconds) / 1e3, n = En(this._days), i = En(this._months), (m = this.asSeconds()) ? (r = Ye(e / 60), l = Ye(r / 60), e %= 60, r %= 60, h = Ye(i / 12), i %= 12, d = e ? e.toFixed(3).replace(/\.?0+$/, "") : "", v = sn(this._months) !== sn(m) ? "-" : "", y = sn(this._days) !== sn(m) ? "-" : "", x = sn(this._milliseconds) !== sn(m) ? "-" : "", (m < 0 ? "-" : "") + "P" + (h ? v + h + "Y" : "") + (i ? v + i + "M" : "") + (n ? y + n + "D" : "") + (l || r || e ? "T" : "") + (l ? x + l + "H" : "") + (r ? x + r + "M" : "") + (e ? x + d + "S" : "")) : "P0D") : this.localeData().invalidDate()
    }
    var F = Sn.prototype;
    return F.isValid = function() {
        return this._isValid
    }, F.abs = function() {
        var e = this._data;
        return this._milliseconds = Xe(this._milliseconds), this._days = Xe(this._days), this._months = Xe(this._months), e.milliseconds = Xe(e.milliseconds), e.seconds = Xe(e.seconds), e.minutes = Xe(e.minutes), e.hours = Xe(e.hours), e.months = Xe(e.months), e.years = Xe(e.years), this
    }, F.add = function(e, n) {
        return pi(this, e, n, 1)
    }, F.subtract = function(e, n) {
        return pi(this, e, n, -1)
    }, F.as = function(e) {
        if (!this.isValid()) return NaN;
        var n, i, r = this._milliseconds;
        if ((e = we(e)) === "month" || e === "quarter" || e === "year") switch (n = this._days + r / 864e5, i = this._months + gi(n), e) {
            case "month":
                return i;
            case "quarter":
                return i / 3;
            case "year":
                return i / 12
        } else switch (n = this._days + Math.round(Cn(this._months)), e) {
            case "week":
                return n / 7 + r / 6048e5;
            case "day":
                return n + r / 864e5;
            case "hour":
                return 24 * n + r / 36e5;
            case "minute":
                return 1440 * n + r / 6e4;
            case "second":
                return 86400 * n + r / 1e3;
            case "millisecond":
                return Math.floor(864e5 * n) + r;
            default:
                throw new Error("Unknown unit " + e)
        }
    }, F.asMilliseconds = me, F.asSeconds = le, F.asMinutes = Vt, F.asHours = T, F.asDays = qt, F.asWeeks = Ut, F.asMonths = xt, F.asQuarters = _n, F.asYears = at, F.valueOf = dt, F._bubble = function() {
        var e = this._milliseconds,
            n = this._days,
            i = this._months,
            r = this._data;
        return 0 <= e && 0 <= n && 0 <= i || e <= 0 && n <= 0 && i <= 0 || (e += 864e5 * _i(Cn(i) + n), i = n = 0), r.milliseconds = e % 1e3, e = Ye(e / 1e3), r.seconds = e % 60, e = Ye(e / 60), r.minutes = e % 60, e = Ye(e / 60), r.hours = e % 24, n += Ye(e / 24), i += e = Ye(gi(n)), n -= _i(Cn(e)), e = Ye(i / 12), i %= 12, r.days = n, r.months = i, r.years = e, this
    }, F.clone = function() {
        return ve(this)
    }, F.get = function(e) {
        return e = we(e), this.isValid() ? this[e + "s"]() : NaN
    }, F.milliseconds = St, F.seconds = mt, F.minutes = pt, F.hours = It, F.days = I, F.weeks = function() {
        return Ye(this.days() / 7)
    }, F.months = ns, F.years = yi, F.humanize = function(e, n) {
        var i, r;
        return this.isValid() ? (i = !1, r = Wt, typeof e == "object" && (n = e, e = !1), typeof e == "boolean" && (i = e), typeof n == "object" && (r = Object.assign({}, Wt, n), n.s != null) && n.ss == null && (r.ss = n.s - 1), e = this.localeData(), n = jt(this, !i, r, e), i && (n = e.pastFuture(+this, n)), e.postformat(n)) : this.localeData().invalidDate()
    }, F.toISOString = An, F.toString = An, F.toJSON = An, F.locale = Mn, F.localeData = Jn, F.toIsoString = Ae("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", An), F.lang = Zn, M("X", 0, 0, "unix"), M("x", 0, 0, "valueOf"), S("x", un), S("X", /[+-]?\d+(\.\d{1,3})?/), U("X", function(e, n, i) {
        i._d = new Date(1e3 * parseFloat(e))
    }), U("x", function(e, n, i) {
        i._d = new Date(j(e))
    }), b.version = "2.30.1", be = B, b.fn = g, b.min = function() {
        return Yt("isBefore", [].slice.call(arguments, 0))
    }, b.max = function() {
        return Yt("isAfter", [].slice.call(arguments, 0))
    }, b.now = function() {
        return Date.now ? Date.now() : +new Date
    }, b.utc = Oe, b.unix = function(e) {
        return B(1e3 * e)
    }, b.months = function(e, n) {
        return Ri(e, n, "months")
    }, b.isDate = Ve, b.locale = qe, b.invalid = Ht, b.duration = ve, b.isMoment = Pe, b.weekdays = function(e, n, i) {
        return ei(e, n, i, "weekdays")
    }, b.parseZone = function() {
        return B.apply(null, arguments).parseZone()
    }, b.localeData = Ze, b.isDuration = ct, b.monthsShort = function(e, n) {
        return Ri(e, n, "monthsShort")
    }, b.weekdaysMin = function(e, n, i) {
        return ei(e, n, i, "weekdaysMin")
    }, b.defineLocale = vn, b.updateLocale = function(e, n) {
        var i, r;
        return n != null ? (r = vt, V[e] != null && V[e].parentLocale != null ? V[e].set(si(V[e]._config, n)) : (n = si(r = (i = yn(e)) != null ? i._config : r, n), i == null && (n.abbr = e), (r = new $n(n)).parentLocale = V[e], V[e] = r), qe(e)) : V[e] != null && (V[e].parentLocale != null ? (V[e] = V[e].parentLocale, e === qe() && qe(e)) : V[e] != null && delete V[e]), V[e]
    }, b.locales = function() {
        return Si(V)
    }, b.weekdaysShort = function(e, n, i) {
        return ei(e, n, i, "weekdaysShort")
    }, b.normalizeUnits = we, b.relativeTimeRounding = function(e) {
        return e === void 0 ? Je : typeof e == "function" && (Je = e, !0)
    }, b.relativeTimeThreshold = function(e, n) {
        return Wt[e] !== void 0 && (n === void 0 ? Wt[e] : (Wt[e] = n, e === "s" && (Wt.ss = n - 1), !0))
    }, b.calendarFormat = function(e, n) {
        return (e = e.diff(n, "days", !0)) < -6 ? "sameElse" : e < -1 ? "lastWeek" : e < 0 ? "lastDay" : e < 1 ? "sameDay" : e < 2 ? "nextDay" : e < 7 ? "nextWeek" : "sameElse"
    }, b.prototype = g, b.HTML5_FMT = {
        DATETIME_LOCAL: "YYYY-MM-DDTHH:mm",
        DATETIME_LOCAL_SECONDS: "YYYY-MM-DDTHH:mm:ss",
        DATETIME_LOCAL_MS: "YYYY-MM-DDTHH:mm:ss.SSS",
        DATE: "YYYY-MM-DD",
        TIME: "HH:mm",
        TIME_SECONDS: "HH:mm:ss",
        TIME_MS: "HH:mm:ss.SSS",
        WEEK: "GGGG-[W]WW",
        MONTH: "YYYY-MM"
    }, b
});