import {
    a as z
} from "./chunk-2KS5UOZO.js";
import {
    a as j
} from "./chunk-KJCCJCIN.js";
import {
    M as C,
    T as N,
    _d as f,
    ba as Q,
    jf as K,
    kf as q,
    lb as B,
    ph as U
} from "./chunk-DCKGQUHB.js";
import {
    $a as V,
    Ab as I,
    Fa as b,
    Fh as v,
    Ka as M,
    Na as d,
    Oa as c,
    Tc as L,
    _a as P,
    ac as G,
    ba as m,
    bc as k,
    ea as n,
    eb as T,
    fb as r,
    gb as l,
    ha as _,
    hb as F,
    hi as x,
    ia as h,
    pd as R,
    qb as A,
    qd as O,
    sb as g,
    ub as u,
    vd as y,
    xk as s,
    yb as D,
    zb as E
} from "./chunk-GOPIAW4V.js";
var X = (e, o) => ({
        assigned_only: e,
        employee_id: o
    }),
    Y = (e, o, i) => [e, o, i],
    Z = (e, o, i) => ({
        icon: "dx-icon-todo",
        title: e,
        description: o,
        primaryButtonText: "empty_state_task_primary_button",
        quickTips: i,
        tutorialUrl: "https://www.youtube.com/watch?v=ChTpoKQevmw",
        tutorialVisible: !0,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function $(e, o) {
    if (e & 1) {
        let i = A();
        r(0, "app-task-popup", 2), g("taskCancelClick", function() {
            _(i);
            let t = u();
            return h(t.isVisibleTaskPopup = !1)
        })("taskSaveClick", function() {
            _(i);
            let t = u();
            return h(t.onTaskSave())
        }), l()
    }
    if (e & 2) {
        let i = u();
        T("isCreate", i.isCreate)("isVisiblePopup", i.isVisibleTaskPopup)("task", i.task)
    }
}
var w = (() => {
    class e {
        get hasTenantTasks() {
            return (this.tenantService.config() ? .entity_counts ? .tasks || 0) > 0
        }
        constructor(i) {
            this.service = i, this.formatMessage = s, this.assignedOnly = !1, this.userSessionService = n(Q), this.tenantService = n(B), this.activatedRouter = n(R), this.isMobileDevice = n(N).isMobileDevice(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.isCreate = !1, this.employeeId = null, this.isVisibleTaskPopup = !1, this.entity = x.TASK, this.isVisiblePopup = !1, this.columns = [{
                dataField: "id",
                caption: s("common_id"),
                width: 40,
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "title",
                caption: s("common_title"),
                width: 150,
                allowSorting: !0
            }, {
                dataField: "description",
                caption: s("common_description"),
                hidingPriority: 5,
                cellTemplate: "commentTemplate",
                allowSorting: !1
            }, {
                dataField: "assigned_user",
                caption: s("common_assignee"),
                cellTemplate: "employeeTemplate",
                width: 110,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: s("created_by"),
                hidingPriority: 3,
                cellTemplate: "employeeTemplate",
                visible: !1,
                allowSorting: !1,
                showInColumnChooser: this.isEmployee
            }, {
                dataField: "status",
                caption: s("common_status"),
                cellTemplate: "entityStatusTemplate",
                hidingPriority: 4,
                alignment: "center",
                allowSorting: !1
            }, {
                dataField: "priority",
                caption: s("priority"),
                hidingPriority: 7,
                alignment: "center",
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "due_date",
                caption: s("common_due_date"),
                cellTemplate: "dueDateTimeTemplate",
                hidingPriority: 6,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: s("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                alignment: "center",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "attachments",
                caption: s("common_attachment"),
                hidingPriority: 0,
                alignment: "center",
                cellTemplate: "attachmentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: s("common_updated_on"),
                hidingPriority: 1,
                alignment: "center",
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "user",
                caption: s("user_customer"),
                width: 160,
                cellTemplate: "userTemplate",
                allowSorting: !0,
                sortOrder: "asc"
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 8,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        ngOnInit() {
            this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.assignedOnly = this.activatedRouter.snapshot.data.assigned_only ? ? this.assignedOnly
        }
        onTaskSave() {
            this.isCreate = !1, this.isVisibleTaskPopup = !1, this.task = null, this.dataGrid.getData()
        }
        create() {
            this.isVisibleTaskPopup = !0, this.isCreate = !0, this.task = null
        }
        edit(i) {
            this.isCreate = !1, this.task = i, this.isVisibleTaskPopup = !0
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)(M(K))
            }
        }
        static {
            this.\u0275cmp = d({
                type: e,
                selectors: [
                    ["app-task-list"]
                ],
                viewQuery: function(a, t) {
                    if (a & 1 && D(f, 5), a & 2) {
                        let p;
                        E(p = I()) && (t.dataGrid = p.first)
                    }
                },
                inputs: {
                    assignedOnly: "assignedOnly"
                },
                standalone: !1,
                decls: 2,
                vars: 23,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleExportAction", "searchPanelPlaceholderText", "isVisibleReportDropdown", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "isCreate", "isVisiblePopup", "task"],
                    [3, "taskCancelClick", "taskSaveClick", "isCreate", "isVisiblePopup", "task"]
                ],
                template: function(a, t) {
                    a & 1 && (r(0, "app-data-grid", 0), g("dataGridAddNewClick", function() {
                        return t.create()
                    })("dataGridEditClick", function(W) {
                        return t.edit(W)
                    }), l(), P(1, $, 1, 3, "app-task-popup", 1)), a & 2 && (T("additionalParams", G(12, X, t.assignedOnly, t.employeeId))("columns", t.columns)("entity", t.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("isVisibleExportAction", t.isAdmin && !t.isMobileDevice)("searchPanelPlaceholderText", "search_panel_tasks_placeholder")("isVisibleReportDropdown", !0)("service", t.service)("hasTenantData", t.hasTenantTasks)("emptyStateConfig", k(19, Z, t.formatMessage("empty_state_task_title"), t.formatMessage("empty_state_task_description"), k(15, Y, t.formatMessage("empty_state_task_tip_1"), t.formatMessage("empty_state_task_tip_2"), t.formatMessage("empty_state_task_tip_3")))), b(), V(t.isVisibleTaskPopup ? 1 : -1))
                },
                dependencies: [f, q],
                encapsulation: 2
            })
        }
    }
    return e
})();
var H = (() => {
    class e {
        constructor() {
            this.formatMessage = s
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = d({
                type: e,
                selectors: [
                    ["app-task"]
                ],
                standalone: !1,
                decls: 4,
                vars: 0,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"]
                ],
                template: function(a, t) {
                    a & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), F(3, "router-outlet"), l()()())
                },
                dependencies: [O],
                encapsulation: 2
            })
        }
    }
    return e
})();
var ee = [{
        path: "",
        component: H,
        children: [{
            path: "list",
            component: w,
            canActivate: [C],
            data: {
                permissions: {
                    only: [v.TASK_LIST]
                }
            },
            title: "BytePhase Task Management"
        }, {
            path: "assigned",
            component: w,
            canActivate: [j, C, z],
            data: {
                permissions: {
                    only: [v.TASK_LIST]
                },
                assigned_only: !0
            },
            title: "BytePhase Assigned Tasks"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    J = (() => {
        class e {
            static {
                this.\u0275fac = function(a) {
                    return new(a || e)
                }
            }
            static {
                this.\u0275mod = c({
                    type: e
                })
            }
            static {
                this.\u0275inj = m({
                    imports: [y.forChild(ee), y]
                })
            }
        }
        return e
    })();
var Ge = (() => {
    class e {
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275mod = c({
                type: e
            })
        }
        static {
            this.\u0275inj = m({
                imports: [L, J, U]
            })
        }
    }
    return e
})();
export {
    w as a, Ge as b
};