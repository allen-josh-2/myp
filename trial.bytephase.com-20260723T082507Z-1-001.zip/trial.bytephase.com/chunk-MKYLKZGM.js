import {
    Bc as je,
    C as J,
    Cb as q,
    Db as ie,
    Ge as ze,
    Ig as Qe,
    Q as Te,
    Rc as Be,
    Se as qe,
    T as Ee,
    Uf as Ke,
    V as Re,
    Vf as Ge,
    Zg as $e,
    _a as z,
    ba as B,
    c as xe,
    ca as Ae,
    fh as He,
    g as Se,
    ha as ee,
    jg as oe,
    kf as Fe,
    lb as te,
    lh as Ye,
    m as ke,
    mb as Ve,
    nb as De,
    oc as Le,
    ph as Je,
    qc as Ue,
    qg as We,
    xb as ne
} from "./chunk-DCKGQUHB.js";
import {
    $a as O,
    $b as be,
    Ab as fe,
    Ai as Z,
    Ci as L,
    Di as Ne,
    Eb as y,
    Ec as Pe,
    Fa as a,
    Fb as w,
    Fh as s,
    Hb as j,
    Ib as d,
    J as de,
    Jb as h,
    Kb as Q,
    Na as T,
    Oa as G,
    Oc as Oe,
    Og as Ie,
    Pb as $,
    Pg as D,
    Qb as H,
    Rb as Y,
    Sa as W,
    Tc as ve,
    Xa as ge,
    _a as P,
    aa as me,
    ab as he,
    ba as K,
    c as pe,
    cb as N,
    db as R,
    ea as m,
    eb as v,
    ei as we,
    fb as o,
    gb as r,
    gc as I,
    ha as b,
    hb as u,
    hc as A,
    hi as l,
    ia as M,
    ic as Me,
    mc as k,
    oa as ue,
    pd as ye,
    qa as x,
    qb as S,
    sb as _,
    sd as V,
    th as X,
    ub as c,
    vd as re,
    wd as ae,
    xk as f,
    yb as _e,
    zb as Ce,
    zi as C
} from "./chunk-GOPIAW4V.js";
import {
    a as se,
    b as ce,
    i as le
} from "./chunk-FBFWB55K.js";
var Xe = [{
    id: "assigned-only",
    label: "assigned_only",
    icon: C.EMPLOYEE.solid,
    color: "#6366f1",
    employeeOnly: !0,
    subItems: [{
        id: "assigned-jobs",
        label: "assigned_jobs",
        route: "/jobs/assigned",
        permission: s.JOB_LIST
    }, {
        id: "assigned-tasks",
        label: "assigned_task",
        route: "/tasks/assigned",
        permission: s.TASK_LIST,
        planCheck: l.TASK
    }, {
        id: "assigned-leads",
        label: "assigned_leads",
        route: "/leads/assigned",
        permission: s.LEAD_LIST,
        planCheck: l.LEAD
    }, {
        id: "assigned-pickups",
        label: "assigned_scheduled_pickups",
        route: "/pickupDrops/assigned",
        permission: s.PICKUP_DROP_LIST,
        planCheck: l.PICKUP_DROP
    }]
}, {
    id: "job",
    label: "jobs",
    icon: C.JOB.solid,
    color: "#6366f1",
    permission: s.JOB_LIST,
    moduleCheck: l.JOB.name,
    subItems: [{
        id: "open-jobs",
        label: "open_jobs",
        route: "/jobs/list",
        permission: s.JOB_LIST,
        badgeColor: "#6366f1"
    }, {
        id: "all-jobs",
        label: "all_jobs",
        route: "/jobs/all",
        permission: s.JOB_LIST
    }, {
        id: "outsourced-jobs",
        label: "outsourced_jobs",
        route: "/jobs/outsourceTo",
        permission: s.OUTSOURCED_JOB_LIST
    }, {
        id: "self-check-in",
        label: "job_self_check_in",
        route: "/jobs/selfCheckIn",
        permission: s.CONTACT_US_LIST,
        moduleCheck: l.CONTACT_US.name
    }, {
        id: "job-settings",
        label: "job_job_settings",
        route: "/jobs/jobSettings",
        permission: s.BUSINESS_SETTING_VIEW
    }, {
        id: "job-overview",
        label: "job_overview",
        route: "/jobs/jobOverview",
        permission: s.BUSINESS_SETTING_VIEW
    }]
}, {
    id: "amc",
    label: "amc",
    icon: C.AMC_CONTRACT.solid,
    color: "#06b6d4",
    employeeOnly: !0,
    permission: s.AMC_CONTRACT_LIST,
    planCheck: l.AMC_CONTRACT,
    moduleCheck: l.AMC_CONTRACT.name,
    subItems: [{
        id: "amc-contracts",
        label: "contracts",
        route: "/amcs/list",
        permission: s.AMC_CONTRACT_LIST,
        badgeColor: "#06b6d4"
    }, {
        id: "amc-services",
        label: "services",
        route: "/amcs/amcServices",
        permission: s.AMC_SERVICE_LIST
    }, {
        id: "amc-complaints",
        label: "complaints",
        route: "/amcs/amcComplaints",
        permission: s.AMC_COMPLAINT_LIST
    }, {
        id: "amc-overview",
        label: "overview",
        route: "/amcs/amcOverview",
        permission: s.BUSINESS_SETTING_VIEW
    }]
}, {
    id: "billing",
    label: "billing",
    icon: C.BILLING.solid,
    color: "#8b5cf6",
    employeeOnly: !0,
    permission: s.BILLING_LIST,
    subItems: [{
        id: "billing-invoices",
        label: "invoices",
        route: "/billings/invoices",
        permission: s.JOB_INVOICE_LIST,
        moduleCheck: l.JOB_INVOICE.name,
        badgeColor: "#8b5cf6"
    }, {
        id: "billing-payments",
        label: "payment",
        route: "/billings/payments",
        permission: s.BILLING_LIST,
        moduleCheck: l.PAYMENT.name
    }, {
        id: "billing-collect-payments",
        label: "collect_payments",
        route: "/billings/collectPayments",
        permission: s.BILLING_LIST,
        moduleCheck: l.COLLECT_PAYMENT.name
    }]
}, {
    id: "customer",
    label: "customers",
    icon: C.CUSTOMER.solid,
    color: "#0ea5e9",
    employeeOnly: !0,
    permission: s.CUSTOMER_LIST,
    moduleCheck: l.CUSTOMER.name,
    subItems: [{
        id: "customer-list",
        label: "customers_list",
        route: "/customers/list",
        permission: s.CUSTOMER_LIST,
        badgeColor: "#0ea5e9"
    }, {
        id: "add-customer",
        label: "add_new_customer",
        route: "/customers/add",
        permission: s.CUSTOMER_WRITE
    }]
}, {
    id: "sale",
    label: "sales",
    icon: C.SALE.solid,
    color: "#10b981",
    employeeOnly: !0,
    permission: s.SALE_LIST,
    moduleCheck: l.SALE.name,
    subItems: [{
        id: "sales-list",
        label: "sales_list",
        route: "/sales/list",
        permission: s.SALE_LIST,
        badgeColor: "#10b981"
    }, {
        id: "add-sale",
        label: "add_sale",
        route: "/sales/add",
        permission: s.SALE_WRITE
    }]
}, {
    id: "quotation",
    label: "quotations",
    icon: C.QUOTATION.solid,
    color: "#f43f5e",
    permission: s.QUOTATION_LIST,
    planCheck: l.QUOTATION,
    moduleCheck: l.QUOTATION.name,
    subItems: [{
        id: "quotations-list",
        label: "quotations_list",
        route: "/quotations/list",
        permission: s.QUOTATION_LIST,
        badgeColor: "#f43f5e"
    }, {
        id: "add-quotation",
        label: "add_quotation",
        route: "/quotations/add",
        permission: s.QUOTATION_WRITE
    }]
}, {
    id: "purchase",
    label: "common_purchase",
    icon: C.PURCHASE.solid,
    color: "#ec4899",
    employeeOnly: !0,
    permission: s.PURCHASE_LIST,
    planCheck: l.PURCHASE,
    moduleCheck: l.PURCHASE.name,
    subItems: [{
        id: "purchase-list",
        label: "purchases_list",
        route: "/purchases/list",
        permission: s.PURCHASE_LIST,
        badgeColor: "#ec4899"
    }, {
        id: "add-purchase",
        label: "add_purchase",
        route: "/purchases/add",
        permission: s.PURCHASE_WRITE
    }]
}, {
    id: "inventory",
    label: "inventory",
    icon: C.INVENTORY.solid,
    color: "#f59e0b",
    employeeOnly: !0,
    permission: s.PART_LIST,
    moduleCheck: l.PART.name,
    subItems: [{
        id: "parts-list",
        label: "parts_list",
        route: "/parts/list",
        permission: s.PART_LIST
    }, {
        id: "add-part",
        label: "add_new_part",
        route: "/parts/add",
        permission: s.PART_WRITE
    }, {
        id: "suppliers",
        label: "suppliers_list",
        route: "/parts/partSuppliers/list",
        permission: s.PART_SUPPLIER_LIST
    }, {
        id: "add-supplier",
        label: "add_new_supplier",
        route: "/parts/partSuppliers/add",
        permission: s.PART_SUPPLIER_WRITE
    }]
}, {
    id: "backup-drive",
    label: "backup_drives",
    icon: C.BACKUP_DRIVE.solid,
    color: "#0891b2",
    employeeOnly: !0,
    permission: s.BACKUP_DRIVE_LIST,
    planCheck: l.BACKUP_DRIVE,
    moduleCheck: l.BACKUP_DRIVE.name,
    serviceOptionCheck: Ie.RECOVERY_SERVICE,
    subItems: [{
        id: "backup-drive-list",
        label: "backup_drives_list",
        route: "/backupDrives/list",
        permission: s.BACKUP_DRIVE_LIST,
        badgeColor: "#0891b2"
    }, {
        id: "add-backup-drive",
        label: "create_backup_drive",
        route: "/backupDrives/add",
        permission: s.BACKUP_DRIVE_WRITE
    }]
}, {
    id: "report",
    label: "reports",
    icon: C.REPORT.solid,
    color: "#6366f1",
    route: "/reports",
    employeeOnly: !0,
    permission: s.REPORT_VIEW,
    moduleCheck: l.REPORT.name
}, {
    id: "calendar",
    label: "calendar",
    icon: "fa-solid fa-calendar",
    color: "#3b82f6",
    route: "/calendar",
    employeeOnly: !0
}, {
    id: "employee",
    label: "employees",
    icon: C.EMPLOYEE.solid,
    color: "#14b8a6",
    employeeOnly: !0,
    permission: s.EMPLOYEE_LIST,
    moduleCheck: l.EMPLOYEE.name,
    subItems: [{
        id: "employee-list",
        label: "employees_list",
        route: "/employees",
        permission: s.EMPLOYEE_LIST
    }, {
        id: "add-employee",
        label: "add_new_employee",
        route: "/employees/add",
        permission: s.EMPLOYEE_WRITE
    }]
}, {
    id: "commission",
    label: "commission",
    icon: "fa-solid fa-percent",
    color: "#eab308",
    employeeOnly: !0,
    permission: s.COMMISSION_VIEW_OWN,
    planCheck: l.COMMISSION,
    disableOnPlanFail: !0,
    route: "/commission"
}, {
    id: "task",
    label: "tasks",
    icon: C.TASK.solid,
    color: "#3b82f6",
    employeeOnly: !0,
    permission: s.TASK_LIST,
    planCheck: l.TASK,
    moduleCheck: l.TASK.name,
    subItems: [{
        id: "tasks-list",
        label: "tasks_list",
        route: "/tasks/list",
        permission: s.TASK_LIST,
        badgeColor: "#3b82f6"
    }, {
        id: "add-task",
        label: "add_new_task",
        permission: s.TASK_WRITE,
        badgeColor: "#3b82f6",
        isPopUpPresent: !0
    }]
}, {
    id: "lead",
    label: "leads",
    icon: C.LEAD.solid,
    color: "#a855f7",
    employeeOnly: !0,
    permission: s.LEAD_LIST,
    planCheck: l.LEAD,
    moduleCheck: l.LEAD.name,
    subItems: [{
        id: "leads-list",
        label: "leads_list",
        route: "/leads/list",
        permission: s.LEAD_LIST,
        badgeColor: "#a855f7"
    }, {
        id: "add-lead",
        label: "add_lead",
        route: "/leads/add",
        permission: s.LEAD_WRITE
    }]
}, {
    id: "expense",
    label: "expenses",
    icon: C.EXPENSE.solid,
    color: "#ef4444",
    employeeOnly: !0,
    permission: s.EXPENSES_LIST,
    planCheck: l.EXPENSE,
    moduleCheck: l.EXPENSE.name,
    subItems: [{
        id: "expenses-list",
        label: "expenses_list",
        route: "/expenses/list",
        permission: s.EXPENSES_LIST
    }, {
        id: "add-expense",
        label: "add_expense",
        route: "/expenses/add",
        permission: s.EXPENSES_WRITE
    }]
}, {
    id: "pickup-drop",
    label: "pickup_drops",
    icon: C.PICKUP_DROP.solid,
    color: "#f97316",
    employeeOnly: !0,
    permission: s.PICKUP_DROP_LIST,
    planCheck: l.PICKUP_DROP,
    moduleCheck: l.PICKUP_DROP.name,
    subItems: [{
        id: "pickup-drop-list",
        label: "pickup_drops_list",
        route: "/pickupDrops",
        permission: s.PICKUP_DROP_LIST,
        badgeColor: "#f97316"
    }, {
        id: "add-pickup-drop",
        label: "outsource_action_schedule_pickup_drop",
        route: "/pickupDrops/add",
        permission: s.PICKUP_DROP_WRITE
    }]
}, {
    id: "marketing",
    label: "marketing",
    icon: C.MARKETING.solid,
    color: "#22c55e",
    employeeOnly: !0,
    permission: s.MAIL_MARKETING_LIST,
    planCheck: l.MAIL_MARKETING,
    moduleCheck: l.MAIL_MARKETING.name,
    subItems: [{
        id: "campaign-list",
        label: "campaigns_list",
        route: "/mailMarketings/list",
        permission: s.MAIL_MARKETING_LIST,
        badgeColor: "#22c55e"
    }]
}, {
    id: "settings",
    label: "settings",
    icon: C.SETTINGS.solid,
    color: "#64748b",
    route: "/settings",
    employeeOnly: !0,
    permission: s.BUSINESS_SETTING_VIEW
}, {
    id: "help",
    label: "help",
    icon: C.HELP.solid,
    color: "#64748b",
    employeeOnly: !0,
    subItems: [{
        id: "help-center",
        label: "help_center",
        route: "/supports/centers"
    }]
}, {
    id: "customer-amc",
    label: "amc",
    icon: C.AMC_CONTRACT.solid,
    color: "#06b6d4",
    customerOnly: !0,
    planCheck: l.AMC_CONTRACT,
    moduleCheck: l.AMC_CONTRACT.name,
    route: "/amcs/list"
}, {
    id: "customer-sales",
    label: "sales",
    icon: C.SALE.solid,
    color: "#10b981",
    customerOnly: !0,
    moduleCheck: l.SALE.name,
    route: "/sales/list"
}, {
    id: "customer-pickup-drop",
    label: "pickup_drops",
    icon: C.PICKUP_DROP.solid,
    color: "#f97316",
    customerOnly: !0,
    planCheck: l.PICKUP_DROP,
    moduleCheck: l.PICKUP_DROP.name,
    route: "/pickupDrops"
}, {
    id: "customer-self-check-in",
    label: "job_self_check_in",
    icon: C.SELF_CHECK_IN.solid,
    color: "#6366f1",
    customerOnly: !0,
    planCheck: l.CONTACT_US,
    route: "/guest/lead"
}];

function ct(t, p) {
    if (t & 1 && (o(0, "span", 11), d(1), r()), t & 2) {
        let e = c().$implicit,
            i = c(2);
        y("background-color", e.badgeColor || (i.category == null ? null : i.category.color) || "#6366f1")("color", "#ffffff"), a(), Q(" ", i.getBadgeCount(e.badge), " ")
    }
}

function lt(t, p) {
    if (t & 1 && (o(0, "div")(1, "div", 6)(2, "div", 7)(3, "span", 8), d(4), I(5, "translate"), r()(), o(6, "div", 7), P(7, ct, 2, 5, "span", 9), u(8, "i", 10), r()()()), t & 2) {
        let e = p.$implicit,
            i = c(2);
        a(), y("opacity", i.isItemDisabled(e) ? "0.5" : "1")("pointer-events", i.isItemDisabled(e) ? "none" : "auto"), w("disabled-item", i.isItemDisabled(e)), a(3), h(A(5, 8, e.label)), a(3), O(e.badge && i.getBadgeCount(e.badge) > 0 ? 7 : -1)
    }
}

function pt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "dx-accordion", 4), _("onItemClick", function(n) {
            b(e);
            let g = c();
            return M(g.navigateToRoute(n.itemData))
        }), W(1, lt, 9, 10, "div", 5), r()
    }
    if (t & 2) {
        let e = c();
        v("dataSource", e.visibleSubItems())("collapsible", !1)("multiple", !1)("animationDuration", 0)("selectedIndex", -1)("deferRendering", !1), a(), v("dxTemplateOf", "submenuTitle")
    }
}

function dt(t, p) {
    t & 1 && (o(0, "div", 2)(1, "p", 12), d(2), I(3, "translate"), r()()), t & 2 && (a(2), h(A(3, 1, "no_items_available")))
}

function mt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "app-task-popup", 13), _("taskCancelClick", function() {
            b(e);
            let n = c();
            return M(n.isVisibleTaskPopup.set(!1))
        })("taskSaveClick", function() {
            b(e);
            let n = c();
            return M(n.isVisibleTaskPopup.set(!1))
        }), r()
    }
    if (t & 2) {
        let e = c();
        v("isCreate", !0)("isVisiblePopup", e.isVisibleTaskPopup())
    }
}
var Ze = (() => {
    class t {
        constructor() {
            this.router = m(V), this.userSessionService = m(B), this.authService = m(q), this.moduleService = m(oe), this.tenantService = m(te), this.generalSettingDataService = m(ie), this.serviceOptions = ne.getServiceOptionFromConfig(this.generalSettingDataService.getGeneralSettingByKey(X.WORKFLOW_SETTINGS.SERVICE_OPTION)), this.isVisibleTaskPopup = x(!1), this.plan = this.tenantService.plan(), this.visibleSubItems = k(() => {
                if (!this.category) return [];
                let e = this.userSessionService.isEmployee(),
                    i = this.userSessionService.permissions();
                return this.category.subItems.filter(n => !(n.employeeOnly && !e || n.customerOnly && e || n.permission && !i.includes(n.permission) || n.planCheck && !this.authService.canAccess(n.planCheck) || n.moduleCheck && !this.moduleService.isModuleActive(n.moduleCheck) || n.serviceOptionCheck && !this.serviceOptions.some(g => g === n.serviceOptionCheck)))
            })
        }
        navigateToRoute(e) {
            this.isItemDisabled(e) || (e.isPopUpPresent ? e.label === "add_new_task" && this.isVisibleTaskPopup.set(!0) : this.router.navigate([e.route], {
                state: {
                    fromMobileMenu: !0
                }
            }))
        }
        getBadgeCount(e) {
            return 0
        }
        isItemDisabled(e) {
            return e.id === "outsourced-jobs" ? [D.LITE, D.BASIC].includes(this.plan) : !1
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = T({
                type: t,
                selectors: [
                    ["app-mobile-submenu"]
                ],
                inputs: {
                    category: "category"
                },
                standalone: !1,
                decls: 5,
                vars: 7,
                consts: [
                    [3, "title", "icon", "iconColor"],
                    ["itemTitleTemplate", "submenuTitle", 1, "accordion-list-mode", "submenu-accordion", "px-2", "pt-2", 3, "dataSource", "collapsible", "multiple", "animationDuration", "selectedIndex", "deferRendering"],
                    [1, "empty-state-message"],
                    [3, "isCreate", "isVisiblePopup"],
                    ["itemTitleTemplate", "submenuTitle", 1, "accordion-list-mode", "submenu-accordion", "px-2", "pt-2", 3, "onItemClick", "dataSource", "collapsible", "multiple", "animationDuration", "selectedIndex", "deferRendering"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "w-100"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fw-medium", "text-capitalize"],
                    [1, "badge", "rounded-pill", "small", 3, "backgroundColor", "color"],
                    [1, "fa-solid", "fa-chevron-right", "text-muted", 2, "opacity", "0.5", "font-size", "14px"],
                    [1, "badge", "rounded-pill", "small"],
                    [1, "text-muted"],
                    [3, "taskCancelClick", "taskSaveClick", "isCreate", "isVisiblePopup"]
                ],
                template: function(i, n) {
                    i & 1 && (u(0, "app-mobile-submenu-header", 0), I(1, "translate"), P(2, pt, 2, 7, "dx-accordion", 1)(3, dt, 4, 3, "div", 2), P(4, mt, 1, 2, "app-task-popup", 3)), i & 2 && (v("title", A(1, 5, n.category == null ? null : n.category.label))("icon", n.category == null ? null : n.category.icon)("iconColor", n.category == null ? null : n.category.color), a(2), O(n.visibleSubItems().length > 0 ? 2 : 3), a(2), O(n.isVisibleTaskPopup() ? 4 : -1))
                },
                dependencies: [Fe, We, Ue, ee, J],
                styles: [".submenu-accordion[_ngcontent-%COMP%]{min-height:100px;width:100%}.empty-state-message[_ngcontent-%COMP%]{padding:40px 20px;text-align:center;color:var(--text-muted)}.empty-state-message[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:14px;font-weight:500}"]
            })
        }
    }
    return t
})();
var ht = t => ({
        "pe-none opacity-50": t
    }),
    _t = (t, p) => p.id;

function Ct(t, p) {
    t & 1 && u(0, "div", 7)
}

function ft(t, p) {
    if (t & 1 && u(0, "i"), t & 2) {
        let e = c().$implicit;
        j(e.icon + " icon-override-color"), y("color", e.color)
    }
}

function bt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "div", 5), _("click", function() {
            let n = b(e).$implicit,
                g = c(2);
            return M(g.selectCategory(n))
        }), o(1, "div", 6), P(2, Ct, 1, 0, "div", 7)(3, ft, 1, 4, "i", 8), r(), o(4, "span", 9), d(5), I(6, "translate"), r()()
    }
    if (t & 2) {
        let e = p.$implicit,
            i = c(2);
        w("navigating", i.navigatingId() === e.id), v("ngClass", be(10, ht, e.disabled)), ge("aria-disabled", e.disabled ? "true" : null), a(), y("background-color", e.color + "15"), a(), O(i.navigatingId() === e.id ? 2 : 3), a(3), h(A(6, 8, e.label))
    }
}

function Mt(t, p) {
    if (t & 1 && (o(0, "div", 1)(1, "div", 3), N(2, bt, 7, 12, "div", 4, _t), r()()), t & 2) {
        let e = c();
        a(2), R(e.visibleCategories())
    }
}

function Pt(t, p) {
    if (t & 1 && u(0, "app-mobile-submenu", 2), t & 2) {
        let e = c();
        v("category", e.selectedCategory())
    }
}
var et = (() => {
    class t {
        constructor() {
            this.router = m(V), this.activatedRoute = m(ye), this.userSessionService = m(B), this.authService = m(q), this.moduleService = m(oe), this.mobileMenuService = m(He), this.generalSettingDataService = m(ie), this.hapticService = m(z), this.serviceOptions = ne.getServiceOptionFromConfig(this.generalSettingDataService.getGeneralSettingByKey(X.WORKFLOW_SETTINGS.SERVICE_OPTION)), this.selectedCategory = this.mobileMenuService.selectedCategory, this.allCategories = Xe, this.visibleCategories = k(() => {
                let e = this.userSessionService.isEmployee(),
                    i = this.userSessionService.permissions();
                return this.allCategories.flatMap(n => n.employeeOnly && !e ? [] : n.customerOnly && e ? [] : n.permission && !i.includes(n.permission) ? [] : n.moduleCheck && !this.moduleService.isModuleActive(n.moduleCheck) ? [] : n.serviceOptionCheck && !this.serviceOptions.some(g => g === n.serviceOptionCheck) ? [] : n.planCheck && !this.authService.canAccess(n.planCheck) ? n.disableOnPlanFail ? [ce(se({}, n), {
                    disabled: !0
                })] : [] : [n])
            }), this.navigatingId = x(null), this.activatedRoute.queryParamMap.pipe(Te()).subscribe(e => {
                let i = e.get("cat");
                if (!i) {
                    this.mobileMenuService.resetToMainMenu();
                    return
                }
                let n = this.allCategories.find(g => g.id === i) ? ? null;
                n ? this.mobileMenuService.selectCategory(n) : this.mobileMenuService.resetToMainMenu()
            })
        }
        selectCategory(e) {
            e.disabled || (this.hapticService.lightImpact(), e.route ? (this.navigatingId.set(e.id), this.router.navigate([e.route], {
                state: {
                    fromMobileMenu: !0
                }
            }).then(() => {
                this.navigatingId.set(null)
            })) : this.router.navigate([], {
                relativeTo: this.activatedRoute,
                queryParams: {
                    cat: e.id
                },
                queryParamsHandling: "merge"
            }))
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = T({
                type: t,
                selectors: [
                    ["app-mobile-menu"]
                ],
                standalone: !1,
                decls: 3,
                vars: 1,
                consts: [
                    [1, "app-menu-container-list"],
                    [1, "main-menu-list"],
                    [3, "category"],
                    [1, "menu-grid-list"],
                    [1, "menu-card-small-list", 3, "navigating", "ngClass"],
                    [1, "menu-card-small-list", 3, "click", "ngClass"],
                    [1, "icon-circle-list"],
                    [1, "card-spinner"],
                    [3, "class", "color"],
                    [1, "menu-card-label-list"]
                ],
                template: function(i, n) {
                    i & 1 && (o(0, "div", 0), P(1, Mt, 4, 0, "div", 1)(2, Pt, 1, 1, "app-mobile-submenu", 2), r()), i & 2 && (a(), O(n.selectedCategory() ? 2 : 1))
                },
                dependencies: [Pe, Ze, J],
                styles: [".app-menu-container-list[_ngcontent-%COMP%]{max-width:480px;margin:0 auto;padding:0;background:var(--primary-bg)}.main-menu-list[_ngcontent-%COMP%]{padding:16px}.menu-grid-list[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.menu-card-small-list[_ngcontent-%COMP%]{background:var(--bg-secondary);border:none;border-radius:16px;padding:20px 12px;display:flex;flex-direction:column;align-items:center;gap:10px;cursor:pointer;transition:all .2s ease;min-height:110px;position:relative;overflow:hidden}.menu-card-small-list[_ngcontent-%COMP%]:active{transform:scale(.96);opacity:.9}@media(hover:hover)and (pointer:fine){.menu-card-small-list[_ngcontent-%COMP%]:hover{transform:translateY(-2px)}.menu-card-small-list[_ngcontent-%COMP%]:hover   .icon-circle-list[_ngcontent-%COMP%]{transform:scale(1.08)}}.icon-circle-list[_ngcontent-%COMP%]{width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;transition:transform .2s ease;position:relative;z-index:1}.icon-circle-list[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:24px}.menu-card-label-list[_ngcontent-%COMP%]{font-size:12px;font-weight:600;color:var(--primary-text);text-align:center;line-height:1.2;position:relative;z-index:1;letter-spacing:.1px;text-transform:capitalize}.menu-card-small-list.navigating[_ngcontent-%COMP%]{opacity:.7;pointer-events:none}.card-spinner[_ngcontent-%COMP%]{width:24px;height:24px;border:3px solid var(--theme-border-color, #e5e7eb);border-top-color:var(--theme-accent-color, #3b82f6);border-radius:50%;animation:_ngcontent-%COMP%_spin .6s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}.dark-theme[_nghost-%COMP%]   .menu-card-label-list[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .menu-card-label-list[_ngcontent-%COMP%]{color:#fff}@media(min-width:375px){.menu-grid-list[_ngcontent-%COMP%]{grid-template-columns:repeat(3,1fr)}}@media(min-width:768px){.app-menu-container-list[_ngcontent-%COMP%]{max-width:900px}.menu-grid-list[_ngcontent-%COMP%]{grid-template-columns:repeat(4,1fr);gap:16px}}@media(min-width:1024px){.app-menu-container-list[_ngcontent-%COMP%]{max-width:1100px}.menu-grid-list[_ngcontent-%COMP%]{grid-template-columns:repeat(5,1fr)}}"],
                changeDetection: 0
            })
        }
    }
    return t
})();
var Ot = ["searchInput"],
    vt = (t, p) => p.name;

function xt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "button", 12), _("click", function() {
            b(e);
            let n = c();
            return M(n.clearSearch())
        }), u(1, "i", 13), r()
    }
}

function St(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "button", 9), _("click", function() {
            b(e);
            let n = c().$implicit,
                g = c();
            return M(g.toggleFilter(n.name))
        }), u(1, "i"), o(2, "span"), d(3), r()()
    }
    if (t & 2) {
        let e = c().$implicit,
            i = c();
        w("active", i.selectedTags().includes(e.name)), a(), j(e.icon), a(2), h(e.name)
    }
}

function kt(t, p) {
    if (t & 1 && P(0, St, 4, 5, "button", 14), t & 2) {
        let e = p.$implicit;
        O(e.disabled ? -1 : 0)
    }
}

function yt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "div", 30)(1, "button", 31), _("click", function() {
            let n = b(e).$implicit,
                g = c(3);
            return M(g.selectRecentSearch(n))
        }), u(2, "i", 32), o(3, "span"), d(4), r()(), o(5, "button", 33), _("click", function() {
            let n = b(e).$index,
                g = c(3);
            return M(g.removeRecentSearch(n))
        }), u(6, "i", 13), r()()
    }
    if (t & 2) {
        let e = p.$implicit;
        a(4), h(e)
    }
}

function Tt(t, p) {
    if (t & 1 && (o(0, "div", 15)(1, "h3", 27), u(2, "i", 28), d(3, " Recent Searches "), r(), o(4, "div", 29), N(5, yt, 7, 1, "div", 30, he), r()()), t & 2) {
        let e = c(2);
        a(5), R(e.recentSearches())
    }
}

function Et(t, p) {
    if (t & 1) {
        let e = S();
        P(0, Tt, 7, 0, "div", 15), o(1, "div", 15)(2, "h5", 16), d(3, "Quick Actions"), r(), o(4, "div", 17)(5, "button", 18), _("click", function() {
            b(e);
            let n = c();
            return M(n.onQuickAction("status"))
        }), o(6, "div", 19), u(7, "i", 20), r(), o(8, "span", 21), d(9, "Search by Status"), r()(), o(10, "button", 18), _("click", function() {
            b(e);
            let n = c();
            return M(n.onQuickAction("date"))
        }), o(11, "div", 19), u(12, "i", 22), r(), o(13, "span", 21), d(14, "Date Range"), r()(), o(15, "button", 18), _("click", function() {
            b(e);
            let n = c();
            return M(n.onQuickAction("popular"))
        }), o(16, "div", 23), u(17, "i", 24), r(), o(18, "span", 21), d(19, "Popular Items"), r()(), o(20, "button", 18), _("click", function() {
            b(e);
            let n = c();
            return M(n.onQuickAction("favorites"))
        }), o(21, "div", 25), u(22, "i", 26), r(), o(23, "span", 21), d(24, "Favorites"), r()()()()
    }
    if (t & 2) {
        let e = c();
        O(e.recentSearches().length > 0 ? 0 : -1)
    }
}

function It(t, p) {
    t & 1 && (o(0, "div", 34), u(1, "dx-load-indicator", 37), o(2, "p"), d(3, "Searching..."), r()()), t & 2 && (a(), v("visible", !0))
}

function wt(t, p) {
    if (t & 1 && (o(0, "div", 42)(1, "span", 43), d(2), r(), o(3, "span", 44), d(4), r()(), o(5, "p", 45), d(6, "Job Details"), r(), o(7, "div", 46)(8, "span"), d(9), r()()), t & 2) {
        let e = c().$implicit;
        a(2), h(e.job_number), a(), y("background-color", (e.status == null ? null : e.status.color) || "#6c757d"), a(), h(e.status == null ? null : e.status.name), a(5), h(e.user == null ? null : e.user.name)
    }
}

function Nt(t, p) {
    if (t & 1 && (o(0, "div", 42)(1, "span", 43), d(2), r(), o(3, "span", 44), d(4), r()(), o(5, "p", 45), d(6, "Sale"), r(), o(7, "div", 46)(8, "span"), d(9), r()()), t & 2) {
        let e = c().$implicit;
        a(2), h(e.sale_number), a(), y("background-color", (e.status == null ? null : e.status.color) || "#6c757d"), a(), h(e.status == null ? null : e.status.name), a(5), h(e.user == null ? null : e.user.name)
    }
}

function Rt(t, p) {
    if (t & 1 && (o(0, "div", 46)(1, "span"), d(2), I(3, "mobileDisplay"), r()()), t & 2) {
        let e = c(2).$implicit;
        a(2), h(Me(3, 1, e.mobile_number, e == null ? null : e.mobile_country_code))
    }
}

function At(t, p) {
    if (t & 1 && (o(0, "div", 47)(1, "span", 43), d(2, "Customer"), r()(), o(3, "p", 45), d(4), r(), P(5, Rt, 4, 4, "div", 46)), t & 2) {
        let e = c().$implicit;
        a(4), h(e.name), a(), O(e.mobile_number ? 5 : -1)
    }
}

function Vt(t, p) {
    if (t & 1 && (o(0, "div", 42)(1, "span", 43), d(2, "Lead"), r(), o(3, "span", 44), d(4), r()(), o(5, "p", 45), d(6), r()), t & 2) {
        let e = c().$implicit;
        a(3), y("background-color", (e.status == null ? null : e.status.color) || "#6c757d"), a(), h((e.status == null ? null : e.status.name) || e.status), a(2), h(e.name)
    }
}

function Dt(t, p) {
    if (t & 1 && (o(0, "div")(1, "div", 40), P(2, wt, 10, 5), P(3, Nt, 10, 5), P(4, At, 6, 2), P(5, Vt, 7, 4), u(6, "i", 41), r()()), t & 2) {
        let e = p.$implicit;
        a(2), O(e.job_number ? 2 : -1), a(), O(e.sale_number ? 3 : -1), a(), O(e.type_id ? 4 : -1), a(), O(e.name && e.status && !e.type_id ? 5 : -1)
    }
}

function Lt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "div", 35)(1, "dx-list", 38), _("onItemClick", function(n) {
            b(e);
            let g = c(2);
            return M(g.navigateToResult(n.itemData))
        }), W(2, Dt, 7, 4, "div", 39), r()()
    }
    if (t & 2) {
        let e = c(2);
        a(), v("dataSource", e.searchResults())("grouped", !0)("collapsibleGroups", !1), a(), v("dxTemplateOf", "item")
    }
}

function Ut(t, p) {
    if (t & 1 && (o(0, "div", 36), u(1, "i", 10), o(2, "p"), d(3), r()()), t & 2) {
        let e = c(2);
        a(3), Q('No results found for "', e.searchQueryValue, '"')
    }
}

function jt(t, p) {
    if (t & 1 && P(0, It, 4, 1, "div", 34)(1, Lt, 3, 4, "div", 35)(2, Ut, 4, 1, "div", 36), t & 2) {
        let e = c();
        O(e.isLoading() ? 0 : e.searchResults().length > 0 ? 1 : 2)
    }
}
var tt = (() => {
    class t {
        constructor() {
            this.router = m(V), this.searchService = m(Ke), this.recentSearchService = m(Ge), this.authService = m(q), this.hapticService = m(z), this.searchQueryValue = "", this.selectedTags = x([]), this.searchResults = x([]), this.isLoading = x(!1), this.recentSearches = x([]), this.searchSubject = new pe, this.filterChips = [{
                icon: "fa-regular fa-ticket",
                name: "Jobs",
                local_key: "sidebar_Jobs",
                disabled: !this.authService.canAccess(l.JOB)
            }, {
                icon: "fa-regular fa-calendar-check",
                name: "Sales",
                local_key: "sales",
                disabled: !this.authService.canAccess(l.SALE)
            }, {
                icon: "fa-regular fa-user-plus",
                name: "Leads",
                local_key: "lead",
                disabled: !this.authService.canAccess(l.LEAD)
            }, {
                icon: "fa-regular fa-box",
                name: "Inventory",
                local_key: "inventory",
                disabled: !this.authService.canAccess(l.PART)
            }, {
                icon: "fa-regular fa-users",
                name: "Customers",
                local_key: "customers",
                disabled: !this.authService.canAccess(l.CUSTOMER)
            }, {
                icon: "fa-regular fa-user-tie",
                name: "Employees",
                local_key: "employees",
                disabled: !this.authService.canAccess(l.EMPLOYEE)
            }], this.loadRecentSearches(), this.setupSearchDebounce()
        }
        ngAfterViewInit() {
            this.searchInput ? .nativeElement ? .focus()
        }
        loadRecentSearches() {
            let e = this.recentSearchService.getRecentSearches();
            this.recentSearches.set(e)
        }
        setupSearchDebounce() {
            this.searchSubject.pipe(de(500)).subscribe(() => {
                this.performSearch()
            })
        }
        onSearchChange(e) {
            this.searchQueryValue = e, e.length > 0 ? this.searchSubject.next(e) : this.searchResults.set([])
        }
        clearSearch() {
            this.hapticService.lightImpact(), this.searchQueryValue = "", this.searchResults.set([])
        }
        clearFilters() {
            this.selectedTags.set([]), this.searchQueryValue && this.performSearch()
        }
        performSearch() {
            let e = this.searchQueryValue;
            e && (this.isLoading.set(!0), e.length > 4 && (this.recentSearchService.addRecentSearch(e), this.loadRecentSearches()), this.searchService.globalSearch({
                search_term: e,
                selected_tags: this.selectedTags()
            }).subscribe({
                next: i => {
                    this.isLoading.set(!1), this.searchResults.set(i || [])
                },
                error: i => {
                    console.error("Search error:", i), this.isLoading.set(!1)
                }
            }))
        }
        toggleFilter(e) {
            this.hapticService.selectionClick();
            let i = this.selectedTags();
            i.includes(e) ? this.selectedTags.set(i.filter(n => n !== e)) : this.selectedTags.set([...i, e]), this.searchQueryValue && this.performSearch()
        }
        selectRecentSearch(e) {
            this.searchQueryValue = e, this.performSearch()
        }
        removeRecentSearch(e) {
            this.recentSearchService.removeRecentSearch(e), this.loadRecentSearches()
        }
        onQuickAction(e) {
            switch (e) {
                case "status":
                    this.router.navigate(["/jobs"]);
                    break;
                case "date":
                    this.router.navigate(["/sales"]);
                    break;
                case "popular":
                    this.router.navigate(["/parts"]);
                    break;
                case "favorites":
                    this.router.navigate(["/customers"]);
                    break
            }
        }
        navigateToResult(e) {
            this.hapticService.lightImpact(), e ? .job_number ? this.router.navigate([`/jobs/${e.id}/overview`]) : e ? .type_id ? this.router.navigate([`/customers/${e.id}/profiles`]) : e ? .sale_number ? this.router.navigate([`/sales/${e.id}`]) : e ? .name && e ? .status && this.router.navigate([`/leads/${e.id}/profiles`])
        }
        goBack() {
            this.router.navigate(["/mobileMenu"])
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = T({
                type: t,
                selectors: [
                    ["app-mobile-search-page"]
                ],
                viewQuery: function(i, n) {
                    if (i & 1 && _e(Ot, 5), i & 2) {
                        let g;
                        Ce(g = fe()) && (n.searchInput = g.first)
                    }
                },
                standalone: !1,
                decls: 18,
                vars: 6,
                consts: [
                    ["searchInput", ""],
                    [1, "search-page"],
                    [1, "search-input-wrapper"],
                    [1, "search-input-container"],
                    [1, "fa-regular", "fa-magnifying-glass", "search-icon"],
                    ["type", "text", 1, "search-input", 3, "ngModelChange", "placeholder", "ngModel"],
                    [1, "clear-btn"],
                    [1, "filter-categories"],
                    [1, "filter-scroll"],
                    [1, "filter-chip", 3, "click"],
                    [1, "fa-regular", "fa-magnifying-glass"],
                    [1, "search-content"],
                    [1, "clear-btn", 3, "click"],
                    [1, "fa-solid", "fa-times"],
                    [1, "filter-chip", 3, "active"],
                    [1, "section"],
                    [1, "section-title-plain"],
                    [1, "quick-actions-grid"],
                    [1, "quick-action-card", 3, "click"],
                    [1, "quick-action-icon", "teal"],
                    [1, "fa-regular", "fa-filter"],
                    [1, "quick-action-label"],
                    [1, "fa-regular", "fa-calendar"],
                    [1, "quick-action-icon", "orange"],
                    [1, "fa-regular", "fa-chart-line"],
                    [1, "quick-action-icon", "purple"],
                    [1, "fa-regular", "fa-star"],
                    [1, "section-title"],
                    [1, "fa-regular", "fa-clock"],
                    [1, "recent-searches"],
                    [1, "recent-search-item"],
                    [1, "recent-search-content", 3, "click"],
                    [1, "fa-regular", "fa-clock", "recent-icon"],
                    [1, "remove-search-btn", 3, "click"],
                    [1, "loading-container"],
                    [1, "search-results"],
                    [1, "no-results"],
                    [3, "visible"],
                    [3, "onItemClick", "dataSource", "grouped", "collapsibleGroups"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "result-item"],
                    [1, "fa-solid", "fa-chevron-right", "result-arrow"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-1"],
                    [1, "result-id"],
                    [1, "badge", "rounded-pill", "px-2", "py-1", 2, "color", "#fff", "font-size", "0.75rem"],
                    [1, "result-title"],
                    [1, "result-meta"],
                    [1, "result-header"]
                ],
                template: function(i, n) {
                    if (i & 1) {
                        let g = S();
                        o(0, "div", 1)(1, "div", 2)(2, "div", 3), u(3, "i", 4), o(4, "input", 5, 0), Y("ngModelChange", function(F) {
                            return b(g), H(n.searchQueryValue, F) || (n.searchQueryValue = F), M(F)
                        }), _("ngModelChange", function(F) {
                            return n.onSearchChange(F)
                        }), r(), P(6, xt, 2, 0, "button", 6), r()(), o(7, "div", 7)(8, "div", 8)(9, "button", 9), _("click", function() {
                            return n.clearFilters()
                        }), u(10, "i", 10), o(11, "span"), d(12, "All"), r()(), N(13, kt, 1, 1, null, null, vt), r()(), o(15, "div", 11), P(16, Et, 25, 1)(17, jt, 3, 1), r()()
                    }
                    i & 2 && (a(4), v("placeholder", "Search jobs, customers, sales, inventory..."), $("ngModel", n.searchQueryValue), a(2), O(n.searchQueryValue ? 6 : -1), a(3), w("active", n.selectedTags().length === 0), a(4), R(n.filterChips), a(3), O(n.searchQueryValue ? 17 : 16))
                },
                dependencies: [ee, Le, je, xe, Se, ke, Ve],
                styles: [".search-page[_ngcontent-%COMP%]{padding-bottom:100px}.search-input-wrapper[_ngcontent-%COMP%]{padding:16px}.search-input-container[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:12px;transition:all .2s ease}.search-input-container[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]{font-size:16px;flex-shrink:0}.search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{flex:1;border:none;outline:none;font-size:15px;background:transparent}.search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder{font-size:14px}.search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]{background:none;border:none;padding:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:all .2s ease}.search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:14px}.filter-categories[_ngcontent-%COMP%]{padding:0 16px 16px}.filter-scroll[_ngcontent-%COMP%]{display:flex;gap:10px;overflow-x:auto;scrollbar-width:none;-ms-overflow-style:none;padding-bottom:4px}.filter-scroll[_ngcontent-%COMP%]::-webkit-scrollbar{display:none}.filter-chip[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;padding:10px 18px;border-radius:25px;font-size:14px;font-weight:500;cursor:pointer;transition:all .2s ease;white-space:nowrap;flex-shrink:0}.filter-chip[_ngcontent-%COMP%]:active{transform:scale(.97)}.filter-chip[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:14px;flex-shrink:0}.search-content[_ngcontent-%COMP%]{padding:0 16px;overflow-y:auto;max-height:calc(100vh - 180px)}.section[_ngcontent-%COMP%]{margin-bottom:28px}.section-title[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;font-size:16px;font-weight:700;margin-bottom:16px}.section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:16px}.section-title-plain[_ngcontent-%COMP%]{font-size:16px;font-weight:700;margin-bottom:16px}.recent-searches[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px}.recent-search-item[_ngcontent-%COMP%]{display:flex;align-items:center;border-radius:12px;transition:all .2s ease;overflow:hidden}.recent-search-content[_ngcontent-%COMP%]{display:flex;align-items:center;gap:14px;padding:16px;flex:1;background:transparent;border:none;cursor:pointer;text-align:left}.recent-search-content[_ngcontent-%COMP%]:active{transform:scale(.98)}.recent-search-content[_ngcontent-%COMP%]   .recent-icon[_ngcontent-%COMP%]{font-size:16px;flex-shrink:0}.recent-search-content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{flex:1;font-size:15px;font-weight:400}.remove-search-btn[_ngcontent-%COMP%]{background:transparent;border:none;padding:16px;cursor:pointer;transition:all .2s ease;display:flex;align-items:center;justify-content:center}.remove-search-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:14px}.remove-search-btn[_ngcontent-%COMP%]:active{transform:scale(.9)}.quick-actions-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.quick-action-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;gap:12px;padding:20px 12px;border-radius:14px;cursor:pointer;transition:all .2s ease;text-align:center}.quick-action-card[_ngcontent-%COMP%]:active{transform:scale(.96)}.quick-action-icon[_ngcontent-%COMP%]{width:48px;height:48px;border-radius:14px;display:flex;align-items:center;justify-content:center}.quick-action-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:20px}.quick-action-icon.teal[_ngcontent-%COMP%]{background:#10b98126}.quick-action-icon.teal[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#10b981}.quick-action-icon.orange[_ngcontent-%COMP%]{background:#f9731626}.quick-action-icon.orange[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#f97316}.quick-action-icon.purple[_ngcontent-%COMP%]{background:#8b5cf626}.quick-action-icon.purple[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#8b5cf6}.quick-action-label[_ngcontent-%COMP%]{font-size:12px;font-weight:500;line-height:1.3}.search-results[_ngcontent-%COMP%]{margin-top:8px}.result-item[_ngcontent-%COMP%]{position:relative;display:flex;flex-direction:column;gap:8px;padding:16px 40px 16px 16px;border-radius:12px;cursor:pointer;transition:all .2s ease;margin-bottom:8px}.result-item[_ngcontent-%COMP%]:active{transform:scale(.98)}.result-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:8px}.result-id[_ngcontent-%COMP%]{font-size:14px;font-weight:600;color:#6366f1}.result-status[_ngcontent-%COMP%]{padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;background:#6366f126;color:#6366f1}.result-title[_ngcontent-%COMP%]{font-size:15px;font-weight:600;margin:0}.result-meta[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;font-size:13px}.result-arrow[_ngcontent-%COMP%]{position:absolute;right:16px;top:50%;transform:translateY(-50%);opacity:.5}.loading-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;gap:16px}.loading-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:16px;margin:0}.no-results[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;gap:16px}.no-results[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:64px;opacity:.3}.no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:16px;text-align:center;margin:0}body:not(.dark-theme)[_nghost-%COMP%]   .search-page[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .search-page[_ngcontent-%COMP%]{background:#f0f4ff}body:not(.dark-theme)[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]{background:#fff;border:1px solid #e2e8f0}body:not(.dark-theme)[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{color:#1e293b}body:not(.dark-theme)[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder, body:not(.dark-theme)   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]:hover, body:not(.dark-theme)   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]:hover{background:#f1f5f9}body:not(.dark-theme)[_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%]{background:#fff;border:1px solid #e2e8f0;color:#475569}body:not(.dark-theme)[_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%]:hover, body:not(.dark-theme)   [_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%]:hover{border-color:#6366f1}body:not(.dark-theme)[_nghost-%COMP%]   .filter-chip.active[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .filter-chip.active[_ngcontent-%COMP%]{background:#6366f1;border-color:#6366f1;color:#fff}body:not(.dark-theme)[_nghost-%COMP%]   .section-title[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]{color:#1e293b}body:not(.dark-theme)[_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#1e293b}body:not(.dark-theme)[_nghost-%COMP%]   .section-title-plain[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .section-title-plain[_ngcontent-%COMP%]{color:#1e293b}body:not(.dark-theme)[_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%]{background:#fff;border:1px solid #e2e8f0}body:not(.dark-theme)[_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%]:hover, body:not(.dark-theme)   [_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%]:hover{border-color:#6366f1}body:not(.dark-theme)[_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   .recent-icon[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   .recent-icon[_ngcontent-%COMP%]{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#1e293b}body:not(.dark-theme)[_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%]{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%]:hover, body:not(.dark-theme)   [_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%]:hover{color:#ef4444}body:not(.dark-theme)[_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%]{background:#fff;border:1px solid #e2e8f0}body:not(.dark-theme)[_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%]:hover, body:not(.dark-theme)   [_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%]:hover{border-color:#6366f1}body:not(.dark-theme)[_nghost-%COMP%]   .quick-action-label[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .quick-action-label[_ngcontent-%COMP%]{color:#475569}body:not(.dark-theme)[_nghost-%COMP%]   .result-item[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .result-item[_ngcontent-%COMP%]{background:#fff;border:1px solid #e2e8f0}body:not(.dark-theme)[_nghost-%COMP%]   .result-item[_ngcontent-%COMP%]:hover, body:not(.dark-theme)   [_nghost-%COMP%]   .result-item[_ngcontent-%COMP%]:hover{border-color:#6366f1}body:not(.dark-theme)[_nghost-%COMP%]   .result-title[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .result-title[_ngcontent-%COMP%]{color:#1e293b}body:not(.dark-theme)[_nghost-%COMP%]   .result-meta[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .result-meta[_ngcontent-%COMP%]{color:#64748b}body:not(.dark-theme)[_nghost-%COMP%]   .result-arrow[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .result-arrow[_ngcontent-%COMP%]{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .loading-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .loading-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#64748b}body:not(.dark-theme)[_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#94a3b8}body:not(.dark-theme)[_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .search-page[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-page[_ngcontent-%COMP%]{background:#0f172a}.dark-theme[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]{background:#1e293b;border:1px solid #334155}.dark-theme[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder, .dark-theme   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder{color:#64748b}.dark-theme[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .search-input-container[_ngcontent-%COMP%]   .clear-btn[_ngcontent-%COMP%]:hover{background:#334155}.dark-theme[_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%]{background:#1e293b;border:1px solid #334155;color:#cbd5e1}.dark-theme[_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .filter-chip[_ngcontent-%COMP%]:hover{border-color:#6366f1}.dark-theme[_nghost-%COMP%]   .filter-chip.active[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .filter-chip.active[_ngcontent-%COMP%]{background:#6366f1;border-color:#6366f1;color:#fff}.dark-theme[_nghost-%COMP%]   .section-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .section-title-plain[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-title-plain[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%]{background:#1e293b;border:1px solid #334155}.dark-theme[_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .recent-search-item[_ngcontent-%COMP%]:hover{border-color:#6366f1}.dark-theme[_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   .recent-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   .recent-icon[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .recent-search-content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#e2e8f0}.dark-theme[_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .remove-search-btn[_ngcontent-%COMP%]:hover{color:#ef4444}.dark-theme[_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%]{background:#1e293b;border:1px solid #334155}.dark-theme[_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .quick-action-card[_ngcontent-%COMP%]:hover{border-color:#6366f1}.dark-theme[_nghost-%COMP%]   .quick-action-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .quick-action-label[_ngcontent-%COMP%]{color:#cbd5e1}.dark-theme[_nghost-%COMP%]   .result-item[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .result-item[_ngcontent-%COMP%]{background:#1e293b;border:1px solid #334155}.dark-theme[_nghost-%COMP%]   .result-item[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .result-item[_ngcontent-%COMP%]:hover{border-color:#6366f1}.dark-theme[_nghost-%COMP%]   .result-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .result-title[_ngcontent-%COMP%]{color:#f1f5f9}.dark-theme[_nghost-%COMP%]   .result-meta[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .result-meta[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .result-arrow[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .result-arrow[_ngcontent-%COMP%]{color:#64748b}.dark-theme[_nghost-%COMP%]   .loading-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .loading-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#94a3b8}.dark-theme[_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#475569}.dark-theme[_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#94a3b8}@media(max-width:380px){.quick-actions-grid[_ngcontent-%COMP%]{grid-template-columns:repeat(2,1fr)}.quick-action-card[_ngcontent-%COMP%]{padding:16px 10px}.quick-action-icon[_ngcontent-%COMP%]{width:44px;height:44px}.quick-action-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:18px}.quick-action-label[_ngcontent-%COMP%]{font-size:11px}}"]
            })
        }
    }
    return t
})();
var nt = (() => {
    class t {
        constructor() {
            this.displayNotifications = x(!0)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = T({
                type: t,
                selectors: [
                    ["app-mobile-notifications"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    [1, "d-block", "h-100"],
                    [3, "showMobileNotificationsChange", "showTrigger", "showMobileNotifications"]
                ],
                template: function(i, n) {
                    i & 1 && (o(0, "div", 0)(1, "app-notification", 1), Y("showMobileNotificationsChange", function(E) {
                        return H(n.displayNotifications, E) || (n.displayNotifications = E), E
                    }), r()()), i & 2 && (a(), v("showTrigger", !1), $("showMobileNotifications", n.displayNotifications))
                },
                dependencies: [qe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var it = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = T({
                type: t,
                selectors: [
                    ["app-mobile-permissions-page"]
                ],
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "pageMode"]
                ],
                template: function(i, n) {
                    i & 1 && u(0, "app-permissions-prompt", 0), i & 2 && v("pageMode", !0)
                },
                dependencies: [Ye],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Bt = [{
        path: "",
        component: et,
        title: "BytePhase Mobile Menu",
        pathMatch: "full"
    }, {
        path: "search",
        component: tt,
        title: "BytePhase Search",
        pathMatch: "full"
    }, {
        path: "notifications",
        component: nt,
        title: "BytePhase Notifications",
        pathMatch: "full"
    }, {
        path: "permissions",
        component: it,
        title: "BytePhase Permissions",
        pathMatch: "full"
    }],
    ot = (() => {
        class t {
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275mod = G({
                    type: t
                })
            }
            static {
                this.\u0275inj = K({
                    imports: [re.forChild(Bt), re]
                })
            }
        }
        return t
    })();
var rt = (() => {
    class t {
        constructor() {
            this.deferredPrompt = null, this.canInstall = x(!1), !this.isStandalone() && (window.addEventListener("beforeinstallprompt", e => {
                e.preventDefault(), this.deferredPrompt = e, this.canInstall.set(!0)
            }), window.addEventListener("appinstalled", () => {
                this.deferredPrompt = null, this.canInstall.set(!1)
            }))
        }
        install() {
            return le(this, null, function*() {
                if (!this.deferredPrompt) return;
                let e = this.deferredPrompt;
                this.deferredPrompt = null, this.canInstall.set(!1), e.prompt(), yield e.userChoice
            })
        }
        isStandalone() {
            return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === !0
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275prov = me({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var zt = (t, p) => p.title,
    qt = (t, p) => p.id;

function Ft(t, p) {
    if (t & 1 && (o(0, "span", 15), d(1), I(2, "uppercase"), r()), t & 2) {
        let e = c();
        a(), h(A(2, 1, e.environmentBadge))
    }
}

function Kt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "div", 27), _("click", function() {
            let n = b(e).$implicit,
                g = c(2);
            return M(g.executeAction(n))
        }), o(1, "div", 28), u(2, "i"), r(), o(3, "div", 29)(4, "span", 30), d(5), r(), o(6, "span", 31), d(7), r()()()
    }
    if (t & 2) {
        let e = p.$implicit;
        a(), y("background-color", e.color + "15"), a(), j(e.icon), y("color", e.color), a(3), h(e.label), a(2), h(e.description)
    }
}

function Gt(t, p) {
    if (t & 1 && (o(0, "div", 18)(1, "span", 24), d(2), r(), o(3, "div", 25), N(4, Kt, 8, 8, "div", 26, qt), r()()), t & 2) {
        let e = p.$implicit;
        a(2), h(e.title), a(2), R(e.options)
    }
}

function Wt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "app-change-password", 32), _("changePasswordSaveClick", function() {
            b(e);
            let n = c();
            return M(n.closeChangePassword())
        })("changePasswordCancelClick", function() {
            b(e);
            let n = c();
            return M(n.closeChangePassword())
        }), r()
    }
    if (t & 2) {
        let e = c();
        v("isVisiblePopup", e.isChangePasswordVisible())
    }
}

function Qt(t, p) {
    if (t & 1) {
        let e = S();
        o(0, "app-forget-self-popup", 33), _("closeEvent", function() {
            b(e);
            let n = c();
            return M(n.closeForgetSelf())
        }), r()
    }
    if (t & 2) {
        let e = c();
        v("isVisiblePopup", e.isForgetSelfVisible())
    }
}
var yi = (() => {
    class t {
        constructor() {
            this.isVisible = !1, this.closeEvent = new ue, this.router = m(V), this.userSessionService = m(B), this.tenantService = m(te), this.storageService = m(Re), this.toastNotificationService = m(Ae), this.themeService = m(Be), this.userDeviceService = m(Ee), this.hapticService = m(z), this.pwaInstallService = m(rt), this.formatMessage = f, this.isChangePasswordVisible = x(!1), this.isThemePopupVisible = x(!1), this.isPermissionsPopupVisible = x(!1), this.isForgetSelfVisible = x(!1), this.isMobileDevice = this.userDeviceService.isMobileDevice(), this.isIOSNative = this.userDeviceService.isIOS, this.themeOptions = [{
                text: f("theme_dark"),
                value: "fluent.blue.dark",
                icon: L.THEME_DARK.light
            }, {
                text: f("theme_light"),
                value: "fluent.blue.light",
                icon: L.THEME_LIGHT.light
            }, {
                text: f("theme_system"),
                value: "system",
                icon: this.isMobileDevice ? L.MOBILE.light : L.LAPTOP.light
            }], this.currentUser = k(() => this.userSessionService.currentUser()), this.isEmployee = k(() => this.userSessionService.isEmployee()), this.permissions = k(() => this.userSessionService.permissions()), this.tenantConfig = k(() => this.tenantService.config()), this.plan = k(() => this.tenantService.plan()), this.userDisplayName = k(() => this.currentUser() ? .name || "User"), this.userEmail = k(() => this.currentUser() ? .email || ""), this.userBadge = k(() => {
                let e = this.plan();
                return e === D.ENTERPRISE ? "Enterprise" : e === D.STANDARD ? "Standard" : e === D.BASIC ? "Basic" : e === D.LITE ? "Lite" : "Premium User"
            }), this.environmentBadge = ae.currentEnvironment, this.isProduction = ae.production, this.menuSections = k(() => {
                let i = this.permissions().includes(s.BUSINESS_SETTING_VIEW);
                return [{
                    title: f("account_settings") || "ACCOUNT SETTINGS",
                    options: [{
                        id: "business-settings",
                        label: f("business_settings_group_name") || "Business Settings",
                        description: f("business_settings_description") || "Manage your business configuration",
                        icon: Ne.BUSINESS_INFO.light,
                        color: "#6366f1",
                        visible: this.isEmployee() && i,
                        action: () => this.navigateTo("/settings")
                    }, {
                        id: "change-password",
                        label: f("change_password_title") || "Change Password",
                        description: f("change_password_description") || "Update your security credentials",
                        icon: L.KEY.light,
                        color: "#10b981",
                        visible: !0,
                        action: () => this.openChangePassword()
                    }, {
                        id: "clear-cache",
                        label: f("clear_cache") || "Clear Cache",
                        description: f("clear_cache_description") || "Remove temporary files",
                        icon: Z.CLEAR_CACHE.light,
                        color: "#f59e0b",
                        visible: !0,
                        action: () => this.clearCache()
                    }].filter(n => n.visible)
                }, {
                    title: f("system") || "SYSTEM",
                    options: [{
                        id: "imports",
                        label: f("imports") || "Imports",
                        description: f("imports_description") || "Import and manage data",
                        icon: Z.IMPORT.light,
                        color: "#8b5cf6",
                        visible: this.isEmployee(),
                        action: () => this.navigateTo("/imports")
                    }, {
                        id: "app-permissions",
                        label: f("app_permissions") || "App Permissions",
                        description: f("app_permissions_description") || "Manage browser and app permissions",
                        icon: L.SHIELD_CHECK.light,
                        color: "#14b8a6",
                        visible: this.isEmployee(),
                        action: () => this.openPermissions()
                    }, {
                        id: "install-pwa",
                        label: f("install_pwa") || "Install PWA",
                        description: f("install_pwa_description") || "Install the app on your device",
                        icon: Z.DOWNLOAD.light,
                        color: "#0ea5e9",
                        visible: !!this.tenantConfig() ? .is_white_label_request && this.pwaInstallService.canInstall(),
                        action: () => this.installPwa()
                    }, {
                        id: "help-support",
                        label: f("help_support") || "Help & Support",
                        description: f("help_support_description") || "Get assistance and documentation",
                        icon: L.CIRCLE_QUESTION.light,
                        color: "#3b82f6",
                        visible: this.isEmployee(),
                        action: () => this.openHelpSupport()
                    }, {
                        id: "forget-self",
                        label: f("forget_self_button"),
                        description: f("forget_self_section_description"),
                        icon: "fa-light fa-user-slash",
                        color: "#ef4444",
                        visible: this.isIOSNative(),
                        action: () => this.openForgetSelf()
                    }].filter(n => n.visible)
                }].filter(n => n.options.length > 0)
            })
        }
        get currentTheme() {
            return this.themeService.getCurrentThemeSelection()
        }
        navigateTo(e) {
            this.router.navigate([e]), this.close()
        }
        navigateToProfile() {
            let e = this.currentUser();
            e ? .id && (e.type_id === we.EMPLOYEE ? this.router.navigate([`/employees/${e.id}/profiles`]) : this.router.navigate([`/customers/${e.id}/profiles`])), this.close()
        }
        openChangePassword() {
            this.isChangePasswordVisible.set(!0), this.close()
        }
        closeChangePassword() {
            this.isChangePasswordVisible.set(!1)
        }
        openThemePopup() {
            this.isThemePopupVisible.set(!0), this.close()
        }
        closeThemePopup() {
            this.isThemePopupVisible.set(!1)
        }
        onThemePopupVisibleChange(e) {
            this.isThemePopupVisible.set(e)
        }
        onThemeChange(e) {
            let i = e ? .value;
            i && (this.hapticService.mediumImpact(), this.themeService.changeTheme(i)), this.closeThemePopup()
        }
        clearCache() {
            this.storageService.clearCache(), this.toastNotificationService.success("notification_cache_clear_success"), window.location.reload()
        }
        openPermissions() {
            this.navigateTo("/mobileMenu/permissions")
        }
        closePermissions() {
            this.isPermissionsPopupVisible.set(!1)
        }
        openHelpSupport() {
            this.router.navigate(["supports/centers"]), this.close()
        }
        openForgetSelf() {
            this.isForgetSelfVisible.set(!0), this.close()
        }
        closeForgetSelf() {
            this.isForgetSelfVisible.set(!1)
        }
        installPwa() {
            this.pwaInstallService.install(), this.close()
        }
        logout() {
            this.hapticService.mediumImpact(), this.userSessionService.logout(), this.close()
        }
        executeAction(e) {
            e && e.action && (this.hapticService.lightImpact(), e.action())
        }
        close() {
            this.closeEvent.emit()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = T({
                type: t,
                selectors: [
                    ["app-mobile-profile-menu"]
                ],
                inputs: {
                    isVisible: "isVisible"
                },
                outputs: {
                    closeEvent: "closeEvent"
                },
                standalone: !1,
                decls: 32,
                vars: 17,
                consts: [
                    [1, "profile-menu-sheet"],
                    [1, "menu-header"],
                    [1, "back-btn", 3, "click"],
                    [1, "fa-solid", "fa-arrow-left"],
                    [1, "header-title"],
                    [1, "header-spacer"],
                    [1, "user-info-header", 3, "click"],
                    [1, "user-avatar-wrapper"],
                    [3, "user", "iconOnly", "size", "isClickable"],
                    [1, "user-details"],
                    [1, "user-name-row"],
                    [1, "user-name"],
                    [1, "fa-solid", "fa-chevron-right", "chevron-icon"],
                    [1, "user-email"],
                    [1, "user-badges"],
                    [1, "badge", "badge-environment"],
                    [1, "badge", "badge-plan"],
                    [1, "menu-content"],
                    [1, "menu-section"],
                    [1, "logout-section"],
                    [1, "logout-btn", 3, "click"],
                    [1, "fa-solid", "fa-arrow-right-from-bracket"],
                    [3, "isVisiblePopup"],
                    [3, "themeChanged", "updateThemeChangePopupStatus", "isThemeChangePopupOpen", "currentTheme", "themeOptions"],
                    [1, "section-title"],
                    [1, "section-options"],
                    [1, "menu-option"],
                    [1, "menu-option", 3, "click"],
                    [1, "option-icon-wrapper"],
                    [1, "option-text"],
                    [1, "option-label"],
                    [1, "option-description"],
                    [3, "changePasswordSaveClick", "changePasswordCancelClick", "isVisiblePopup"],
                    [3, "closeEvent", "isVisiblePopup"]
                ],
                template: function(i, n) {
                    i & 1 && (o(0, "div", 0)(1, "div", 1)(2, "button", 2), _("click", function() {
                        return n.close()
                    }), u(3, "i", 3), r(), o(4, "span", 4), d(5), r(), u(6, "div", 5), r(), o(7, "div", 6), _("click", function() {
                        return n.navigateToProfile()
                    }), o(8, "div", 7), u(9, "app-user-badge", 8), r(), o(10, "div", 9)(11, "div", 10)(12, "span", 11), d(13), r(), u(14, "i", 12), r(), o(15, "span", 13), d(16), r(), o(17, "div", 14), P(18, Ft, 3, 3, "span", 15), o(19, "span", 16), d(20), r()()()(), o(21, "div", 17), N(22, Gt, 6, 1, "div", 18, zt), r(), o(24, "div", 19)(25, "button", 20), _("click", function() {
                        return n.logout()
                    }), u(26, "i", 21), o(27, "span"), d(28), r()()()(), P(29, Wt, 1, 1, "app-change-password", 22), P(30, Qt, 1, 1, "app-forget-self-popup", 22), o(31, "app-theme-change-mobile-view-popup", 23), _("themeChanged", function(E) {
                        return n.onThemeChange(E)
                    })("updateThemeChangePopupStatus", function(E) {
                        return n.onThemePopupVisibleChange(E)
                    }), r()), i & 2 && (w("visible", n.isVisible), a(5), h(n.formatMessage("account") || "Account"), a(4), v("user", n.currentUser())("iconOnly", !0)("size", "mobile-profile")("isClickable", !1), a(4), h(n.userDisplayName()), a(3), h(n.userEmail()), a(2), O(n.isProduction ? -1 : 18), a(2), h(n.userBadge()), a(2), R(n.menuSections()), a(6), h(n.formatMessage("logout") || "Logout"), a(), O(n.isChangePasswordVisible() ? 29 : -1), a(), O(n.isForgetSelfVisible() ? 30 : -1), a(), v("isThemeChangePopupOpen", n.isThemePopupVisible())("currentTheme", n.currentTheme)("themeOptions", n.themeOptions))
                },
                dependencies: [De, ze, Qe, $e, Oe],
                styles: [".profile-menu-backdrop[_ngcontent-%COMP%]{position:fixed;inset:0;background:#00000080;z-index:9998;animation:_ngcontent-%COMP%_fadeIn .2s ease-out}@keyframes _ngcontent-%COMP%_fadeIn{0%{opacity:0}to{opacity:1}}.profile-menu-sheet[_ngcontent-%COMP%]{position:fixed;inset:0;background:#fff;border-radius:0;z-index:9999;transform:translate(100%);transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;overflow:hidden}.profile-menu-sheet.visible[_ngcontent-%COMP%]{transform:translate(0)}.menu-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;padding-top:calc(16px + env(safe-area-inset-top,0));border-bottom:1px solid #f0f0f0;flex-shrink:0}.back-btn[_ngcontent-%COMP%]{width:40px;height:40px;border-radius:12px;border:none;background:#f3f4f6;color:#374151;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s ease}.back-btn[_ngcontent-%COMP%]:active{transform:scale(.95);background:#e5e7eb}.back-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:16px}.header-title[_ngcontent-%COMP%]{font-size:18px;font-weight:700;color:#1a1a1a;letter-spacing:-.3px}.header-spacer[_ngcontent-%COMP%]{width:40px}.user-info-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:16px;padding:20px;cursor:pointer;transition:background .2s ease;border-bottom:1px solid #f0f0f0}.user-info-header[_ngcontent-%COMP%]:active{background:#f9fafb}.user-avatar-wrapper[_ngcontent-%COMP%]{flex-shrink:0}.user-avatar-wrapper[_ngcontent-%COMP%]     app-user-badge .profile{margin:0}.user-avatar-wrapper[_ngcontent-%COMP%]     app-user-badge .mobile-profile{border-radius:12px!important}.user-details[_ngcontent-%COMP%]{flex:1;display:flex;flex-direction:column;gap:4px;min-width:0}.user-name-row[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:8px}.user-name[_ngcontent-%COMP%]{font-size:18px;font-weight:700;color:#1a1a1a;letter-spacing:-.3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.chevron-icon[_ngcontent-%COMP%]{font-size:12px;color:#9ca3af;flex-shrink:0}.user-email[_ngcontent-%COMP%]{font-size:13px;color:#6b7280;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.user-badges[_ngcontent-%COMP%]{display:flex;gap:8px;margin-top:4px}.badge[_ngcontent-%COMP%]{padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.3px}.badge-environment[_ngcontent-%COMP%]{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff}.badge-plan[_ngcontent-%COMP%]{background:#fef3c7;color:#d97706}.menu-content[_ngcontent-%COMP%]{flex:1;overflow-y:auto;padding:8px 0;-webkit-overflow-scrolling:touch}.menu-section[_ngcontent-%COMP%]{padding:12px 0}.section-title[_ngcontent-%COMP%]{display:block;font-size:11px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.8px;padding:0 20px 12px}.section-options[_ngcontent-%COMP%]{display:flex;flex-direction:column}.menu-option[_ngcontent-%COMP%]{display:flex;align-items:center;gap:16px;padding:14px 20px;cursor:pointer;transition:all .2s ease;border-left:3px solid transparent}.menu-option[_ngcontent-%COMP%]:active{background:#f9fafb;transform:scale(.98)}@media(hover:hover)and (pointer:fine){.menu-option[_ngcontent-%COMP%]:hover{border-left-color:var(--link-hover-color, #6366f1)}}.option-icon-wrapper[_ngcontent-%COMP%]{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .2s ease}.option-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:20px}.option-text[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0}.option-label[_ngcontent-%COMP%]{font-size:15px;font-weight:600;color:#1a1a1a;letter-spacing:-.2px}.option-description[_ngcontent-%COMP%]{font-size:12px;color:#9ca3af;font-weight:500}.logout-section[_ngcontent-%COMP%]{padding:16px 20px;padding-bottom:calc(16px + env(safe-area-inset-bottom,0));border-top:1px solid #f0f0f0;flex-shrink:0}.logout-btn[_ngcontent-%COMP%]{width:100%;padding:14px 20px;border:none;border-radius:12px;background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;font-size:15px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:10px;cursor:pointer;transition:all .2s ease}.logout-btn[_ngcontent-%COMP%]:active{transform:scale(.98);opacity:.9}.logout-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:16px}.theme-popup-content[_ngcontent-%COMP%]{padding:16px}.dark-theme[_nghost-%COMP%]   .profile-menu-sheet[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .profile-menu-sheet[_ngcontent-%COMP%]{background:var(--primary-bg, #1a1a2e)}.dark-theme[_nghost-%COMP%]   .menu-header[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .menu-header[_ngcontent-%COMP%]{border-bottom-color:var(--theme-border-color, #2d2d44)}.dark-theme[_nghost-%COMP%]   .back-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .back-btn[_ngcontent-%COMP%]{background:var(--bg-secondary, #252540);color:#fff}.dark-theme[_nghost-%COMP%]   .back-btn[_ngcontent-%COMP%]:active, .dark-theme   [_nghost-%COMP%]   .back-btn[_ngcontent-%COMP%]:active{background:var(--theme-hover-color, #3d3d5c)}.dark-theme[_nghost-%COMP%]   .header-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .header-title[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .user-info-header[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .user-info-header[_ngcontent-%COMP%]{border-bottom-color:var(--theme-border-color, #2d2d44)}.dark-theme[_nghost-%COMP%]   .user-info-header[_ngcontent-%COMP%]:active, .dark-theme   [_nghost-%COMP%]   .user-info-header[_ngcontent-%COMP%]:active{background:var(--bg-secondary, #252540)}.dark-theme[_nghost-%COMP%]   .user-name[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .user-name[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .user-email[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .user-email[_ngcontent-%COMP%]{color:var(--font-color, #a0a0b0)}.dark-theme[_nghost-%COMP%]   .chevron-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .chevron-icon[_ngcontent-%COMP%]{color:var(--font-color, #a0a0b0)}.dark-theme[_nghost-%COMP%]   .badge-plan[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .badge-plan[_ngcontent-%COMP%]{background:#d9770633;color:#fbbf24}.dark-theme[_nghost-%COMP%]   .section-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-title[_ngcontent-%COMP%]{color:var(--font-color, #6b7280)}.dark-theme[_nghost-%COMP%]   .menu-option[_ngcontent-%COMP%]:active, .dark-theme   [_nghost-%COMP%]   .menu-option[_ngcontent-%COMP%]:active{background:var(--bg-secondary, #252540)}.dark-theme[_nghost-%COMP%]   .option-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .option-label[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .option-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .option-description[_ngcontent-%COMP%]{color:var(--font-color, #6b7280)}.dark-theme[_nghost-%COMP%]   .logout-section[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .logout-section[_ngcontent-%COMP%]{border-top-color:var(--theme-border-color, #2d2d44)}.dark-theme[_nghost-%COMP%]   .logout-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .logout-btn[_ngcontent-%COMP%]{background:linear-gradient(135deg,#ef4444,#dc2626)}@media(max-width:360px){.user-avatar-wrapper[_ngcontent-%COMP%]     .mobile-profile{width:40px!important;height:40px!important;font-size:16px!important}.user-name[_ngcontent-%COMP%]{font-size:16px}.user-email[_ngcontent-%COMP%]{font-size:12px}.option-icon-wrapper[_ngcontent-%COMP%]{width:44px;height:44px}.option-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:18px}.option-label[_ngcontent-%COMP%]{font-size:14px}.option-description[_ngcontent-%COMP%]{font-size:11px}}"],
                changeDetection: 0
            })
        }
    }
    return t
})();
var Ki = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275mod = G({
                type: t
            })
        }
        static {
            this.\u0275inj = K({
                imports: [ve, Je, ot]
            })
        }
    }
    return t
})();
export {
    rt as a, yi as b, Ki as c
};