import {
    Qd as a,
    aa as s,
    da as i,
    dd as h
} from "./chunk-GOPIAW4V.js";
var c = (() => {
    class e {
        constructor(t) {
            this.http = t, this.baseUrl = a
        }
        get(t) {
            return this.http.get(this.baseUrl + t)
        }
        getWithParams(t, r) {
            return this.http.get(this.baseUrl + t, {
                params: r
            })
        }
        getListByQuery(t, r) {
            return this.http.get(this.baseUrl + t, {
                params: r
            })
        }
        post(t, r = {}) {
            return this.http.post(this.baseUrl + t, r)
        }
        put(t, r = {}) {
            return this.http.put(this.baseUrl + t, r)
        }
        patch(t, r = {}) {
            return this.http.patch(this.baseUrl + t, r)
        }
        delete(t) {
            return this.http.delete(this.baseUrl + t)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)(i(h))
            }
        }
        static {
            this.\u0275prov = s({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
export {
    c as a
};