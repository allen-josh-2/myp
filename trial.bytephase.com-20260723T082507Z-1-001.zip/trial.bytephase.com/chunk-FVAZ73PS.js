import {
    aa as r,
    da as o,
    ti as n,
    ui as s,
    ye as i
} from "./chunk-GOPIAW4V.js";
var l = (() => {
    class t extends n {
        constructor(e) {
            super(e, i), this.api = e, this.endpoint = i
        }
        getAll() {
            return this.api.get(this.endpoint + "/getAll")
        }
        static {
            this.\u0275fac = function(c) {
                return new(c || t)(o(s))
            }
        }
        static {
            this.\u0275prov = r({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
export {
    l as a
};