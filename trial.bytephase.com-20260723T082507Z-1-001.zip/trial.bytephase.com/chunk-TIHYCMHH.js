import {
    g as ei
} from "./chunk-WDS5LHZR.js";
import {
    a as Zt
} from "./chunk-MBAKXBI4.js";
import {
    a as Je
} from "./chunk-KJCCJCIN.js";
import {
    Ab as ct,
    Cb as me,
    Db as ce,
    Ec as xt,
    Fa as tt,
    Gd as Nt,
    Hc as bt,
    Hd as Ot,
    Ia as it,
    Jb as dt,
    Je as Gt,
    Kb as _t,
    Kd as Lt,
    Ke as jt,
    L as Qe,
    Lb as ut,
    M as z,
    Mb as Ct,
    Md as kt,
    Mg as F,
    Nd as Rt,
    Nf as Ht,
    Of as zt,
    Og as $t,
    Qb as ft,
    Qe as Yt,
    Qf as fe,
    Rb as yt,
    Rf as Kt,
    Sc as Pt,
    T as G,
    Ud as Ut,
    Ue as qt,
    Va as nt,
    Vb as St,
    We as Qt,
    Xa as ot,
    Y as $e,
    Zc as Et,
    Zd as Ft,
    _b as ht,
    _d as k,
    aa as Ze,
    ac as vt,
    ba as L,
    ca as re,
    cb as at,
    cc as de,
    cd as Mt,
    df as _e,
    e as ve,
    g as Le,
    gf as ue,
    h as ke,
    ha as et,
    ic as gt,
    jb as rt,
    jc as Tt,
    jd as It,
    ka as le,
    kd as wt,
    lb as pe,
    mb as lt,
    n as Re,
    pb as st,
    pe as Bt,
    ph as Jt,
    q as Ue,
    qd as At,
    r as Fe,
    rd as Dt,
    sb as pt,
    sf as Y,
    t as Be,
    tf as Ce,
    u as Ge,
    vd as Vt,
    xb as mt,
    xc as j,
    xf as Wt,
    xg as Xt,
    y as je
} from "./chunk-DCKGQUHB.js";
import {
    $a as d,
    $b as Ae,
    Ab as V,
    Ai as Xe,
    Ak as se,
    Ba as $,
    Ca as he,
    Ci as ae,
    Ec as Ve,
    Fa as o,
    Fh as b,
    Hg as We,
    Hh as v,
    Ib as g,
    Jb as R,
    Ka as T,
    Kb as M,
    Lb as we,
    Na as E,
    Oa as J,
    Pb as Z,
    Pg as K,
    Qb as ee,
    Rb as te,
    Sa as Q,
    Tc as Ne,
    Wb as W,
    Yh as ne,
    Zg as x,
    _a as c,
    _b as B,
    ai as xe,
    ba as X,
    bb as Ee,
    bc as H,
    bi as oe,
    cb as Me,
    ch as He,
    db as Ie,
    ea as y,
    eb as a,
    fb as s,
    fd as Oe,
    fi as ze,
    gb as l,
    gc as w,
    ha as C,
    hb as _,
    hi as I,
    ia as f,
    ic as N,
    ii as Ke,
    jc as De,
    n as Pe,
    pd as O,
    qa as Se,
    qb as h,
    qd as Ye,
    sb as S,
    sd as ie,
    td as qe,
    th as Te,
    ub as r,
    vd as ge,
    xk as u,
    yb as A,
    z as ye,
    zb as D,
    zi as U
} from "./chunk-GOPIAW4V.js";
var ci = (t, p, e) => ({
    paymentable_id: t,
    paymentable_type: p,
    customer_id: e
});

function di(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-add-payment-popup", 2), S("addPaymentClose", function() {
            C(e);
            let i = r();
            return f(i.isVisiblePopup = !1)
        })("addPaymentSave", function() {
            C(e);
            let i = r();
            return f(i.onSavePayment())
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("amountRemaining", e.amountRemaining)("isCreate", e.isCreate)("isVisiblePopup", e.isVisiblePopup)("payment", e.payment)
    }
}
var ti = (() => {
    class t {
        constructor(e, n) {
            this.service = e, this.jobService = n, this.formatMessage = u, this.ENTITIES = I, this.paymentableId = null, this.paymentableType = this.ENTITIES.SALE.name, this.isiVisibleTitle = !1, this.userSessionService = y(L), this.activatedRouter = y(O), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.isVisiblePopup = !1, this.isCreate = !1, this.entity = I.PAYMENT, this.columns = [{
                dataField: "paymentable",
                caption: u("payment_against"),
                cellTemplate: "paymentableLinkTemplate",
                width: 140,
                allowSorting: !1
            }, {
                dataField: "amount",
                caption: u("common_amount"),
                width: 120,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "payment_type.name",
                caption: u("payment_mode"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "transaction_id",
                caption: u("common_transaction_id"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "cheque_number",
                caption: u("payment_cheque_number"),
                hidingPriority: 1,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: u("common_created_by"),
                hidingPriority: 4,
                cellTemplate: "employeeTemplate",
                allowSorting: !1
            }, {
                dataField: "updated_user",
                caption: u("common_updated_by"),
                hidingPriority: 5,
                cellTemplate: "employeeTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "comment",
                caption: u("common_comment"),
                hidingPriority: 2,
                cellTemplate: "commentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: u("common_created_at"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 7,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        ngOnInit() {
            this.entity.isVisibleSearchPanel = !1, this.paymentableId || (this.paymentableId = +this.activatedRouter.snapshot.parent.paramMap.get("sale_id")), this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.jobService.paymentListReload$.subscribe({
                next: () => {
                    this.dataGrid && this.dataGrid.getData()
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        create() {
            this.isVisiblePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.payment = e, this.isVisiblePopup = !0, this.amountRemaining = e.paymentable ? .total_amount - e.paymentable ? .paymentable_sum_amount
        }
        onSavePayment() {
            this.isCreate = !1, this.dataGrid.getData(), this.payment = null, this.isVisiblePopup = !1
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(T(qt), T(Et))
            }
        }
        static {
            this.\u0275cmp = E({
                type: t,
                selectors: [
                    ["app-sale-payment-list"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && A(k, 5), n & 2) {
                        let m;
                        D(m = V()) && (i.dataGrid = m.first)
                    }
                },
                inputs: {
                    paymentableId: "paymentableId",
                    paymentableType: "paymentableType",
                    isiVisibleTitle: "isiVisibleTitle"
                },
                standalone: !1,
                decls: 2,
                vars: 13,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleTitle", "service"],
                    [3, "amountRemaining", "isCreate", "isVisiblePopup", "payment"],
                    [3, "addPaymentClose", "addPaymentSave", "amountRemaining", "isCreate", "isVisiblePopup", "payment"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "app-data-grid", 0), S("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(P) {
                        return i.edit(P)
                    }), l(), c(1, di, 1, 4, "app-add-payment-popup", 1)), n & 2 && (a("additionalParams", H(9, ci, i.paymentableId, i.paymentableType, i.customerId))("columns", i.columns)("entity", i.entity)("isVisibleAddAction", !1)("isVisibleDeleteAction", i.isAdmin)("isVisibleEditAction", i.isEmployee)("isVisibleTitle", i.isiVisibleTitle)("service", i.service), o(), d(i.payment && i.isVisiblePopup ? 1 : -1))
                },
                dependencies: [k, fe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var hi = () => ({
        enabled: !1
    }),
    vi = () => ({
        groupPaging: !1
    }),
    gi = () => ({
        mode: "standard"
    }),
    Ti = () => ({
        type: "fixedPoint",
        precision: 2
    }),
    xi = () => [2, 4];

function bi(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-context-menu", 13), S("contextMenuItemCancelClick", function() {
            C(e);
            let i = r(2);
            return f(i.onCloseContextMenuOption())
        })("contextMenuItemClick", function(i) {
            C(e);
            let m = r(2);
            return f(m.onContextMenuItemClick(i))
        }), l()
    }
    if (t & 2) {
        let e = r(2);
        a("buttonText", e.formatMessage("sale_actions"))("contextMenuItems", e.saleContextMenu)("entityName", e.ENTITIES.SALE.name)("entity", e.sale)("isIconOnly", e.isMobileDevice)("isOnDetailPage", !0)
    }
}

function Pi(t, p) {
    if (t & 1 && (s(0, "div", 0)(1, "div", 2), _(2, "app-payment-status", 9), s(3, "span", 10), g(4), l(), s(5, "div", 11), c(6, bi, 1, 6, "app-context-menu", 12), l()()()), t & 2) {
        let e = r();
        o(2), a("iconType", e.statusIconTypeList.TITLE)("status", e.sale == null ? null : e.sale.status), o(2), M(" ", e.sale == null ? null : e.sale.sale_number, " "), o(2), d(e.saleContextMenu.length ? 6 : -1)
    }
}

function Ei(t, p) {
    t & 1 && _(0, "app-skeleton-loader", 3), t & 2 && a("rows", 8)("columns", 3)
}

function Mi(t, p) {
    if (t & 1 && (s(0, "h4", 16), g(1), l()), t & 2) {
        let e = r(2);
        o(), we(" ", e.formatMessage("sale_name"), " : ", e.form.getRawValue().sale_number, " ")
    }
}

function Ii(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-save-cancel-footer", 37), S("cancelClick", function() {
            C(e);
            let i = r(4);
            return f(i.routerHelperService.goBack())
        }), l()
    }
    if (t & 2) {
        let e = r(4);
        a("isOnPopup", !1)("isSaving", e.isSaving)("isVisibleHr", !1)("saveText", e.sale != null && e.sale.id ? "common_update" : "common_create")("savingText", e.sale != null && e.sale.id ? "common_updating" : "common_creating")
    }
}

function wi(t, p) {
    if (t & 1 && Q(0, Ii, 1, 5, "app-save-cancel-footer", 36), t & 2) {
        let e = r(3);
        a("ngxPermissionsOnly", e.PERMISSION_LIST.SALE_WRITE)
    }
}

function Ai(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-dx-outline-button", 40), S("onClickEvent", function() {
            C(e);
            let i = r(4);
            return f(i.setEditMode())
        }), l()
    }
}

function Di(t, p) {
    if (t & 1 && (_(0, "app-location-back", 38), Q(1, Ai, 1, 0, "app-dx-outline-button", 39)), t & 2) {
        let e = r(3);
        o(), a("ngxPermissionsOnly", e.PERMISSION_LIST.SALE_WRITE)
    }
}

function Vi(t, p) {
    if (t & 1 && (s(0, "div", 15)(1, "div", 34), c(2, wi, 1, 1, "app-save-cancel-footer", 35), c(3, Di, 2, 1), l()()), t & 2) {
        let e = r(2);
        o(2), d(!e.isMobileDevice && e.isEditMode ? 2 : -1), o(), d(e.isEditMode ? -1 : 3)
    }
}

function Ni(t, p) {
    if (t & 1 && _(0, "app-server-error", 17), t & 2) {
        let e = r(2);
        a("errorResponse", e.errorResponse)
    }
}

function Oi(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-control-container", 23)(1, "app-customer-dropdown", 41), S("itemClick", function(i) {
            C(e);
            let m = r(2);
            return f(m.onReferredSelect(i))
        }), l()()
    }
    if (t & 2) {
        let e, n = r(2);
        a("errorMsg", n.formatMessage("common_error_messages_referred_by_required"))("label", n.formatMessage("sale_referred_by")), o(), a("customerId", n.form.getRawValue().id ? (e = n.form.getRawValue()) == null ? null : e.referred_by_id : null)("formControl", n.form.controls.referred_by_id)("isEditMode", n.isEditMode)("isVisibleAddAction", !1)("showCrateButton", !0)
    }
}

function Li(t, p) {
    if (t & 1 && (_(0, "app-copy-to-clipboard", 47), w(1, "mobileDisplay")), t & 2) {
        let e = r(3);
        a("textToBeCopied", N(1, 1, e.selectedUser.mobile_number, e.selectedUser == null ? null : e.selectedUser.mobile_country_code))
    }
}

function ki(t, p) {
    if (t & 1 && _(0, "app-copy-to-clipboard", 47), t & 2) {
        let e = r(3);
        a("textToBeCopied", e.selectedUser.email)
    }
}

function Ri(t, p) {
    if (t & 1 && (s(0, "div", 24)(1, "div", 42)(2, "p", 43)(3, "strong")(4, "span", 44), _(5, "i", 45), l(), g(6), l(), s(7, "a", 46), w(8, "mobileDisplay"), g(9), w(10, "mobileDisplay"), l(), c(11, Li, 2, 4, "app-copy-to-clipboard", 47), l()(), s(12, "div", 42)(13, "p", 43)(14, "strong")(15, "span", 44), _(16, "i", 48), l(), g(17), l(), s(18, "a", 46), g(19), l(), c(20, ki, 1, 1, "app-copy-to-clipboard", 47), l()()()), t & 2) {
        let e = r(2);
        o(6), M(" ", e.formatMessage("common_phone"), " "), o(), a("href", W("tel:", De(8, 10, e.selectedUser.mobile_number, e.selectedUser == null ? null : e.selectedUser.mobile_country_code, "tel")), he), o(2), R(N(10, 14, e.selectedUser.mobile_number, e.selectedUser == null ? null : e.selectedUser.mobile_country_code)), o(2), d(e.selectedUser.mobile_number ? 11 : -1), o(6), M(" ", e.formatMessage("common_email"), " "), o(), a("href", W("mailto:", e.selectedUser.email), he), o(), R(e.selectedUser.email), o(), d(e.selectedUser.email ? 20 : -1)
    }
}

function Ui(t, p) {
    if (t & 1 && (s(0, "div"), _(1, "span", 54), w(2, "taxSplit"), w(3, "safe"), l()), t & 2) {
        let e = p.$implicit;
        o(), a("innerHTML", N(3, 4, N(2, 1, e.data, "amount"), "html"), $)
    }
}

function Fi(t, p) {
    if (t & 1 && (s(0, "div"), _(1, "span", 54), w(2, "taxSplit"), w(3, "safe"), l()), t & 2) {
        let e = p.$implicit;
        o(), a("innerHTML", N(3, 4, N(2, 1, e.data, "name"), "html"), $)
    }
}

function Bi(t, p) {
    if (t & 1 && (s(0, "div"), _(1, "span", 55), w(2, "safe"), l()), t & 2) {
        let e = p.$implicit;
        o(), a("innerHTML", N(2, 1, e.value, "html"), $)
    }
}

function Gi(t, p) {
    if (t & 1 && (s(0, "div"), _(1, "app-part-name", 56), l()), t & 2) {
        let e = p.$implicit;
        o(), a("part", e.data)
    }
}

function ji(t, p) {
    if (t & 1 && (s(0, "div")(1, "span", 57), g(2), l()()), t & 2) {
        let e = r(3);
        o(), a("ngClass", e.isMobileDevice ? "h6" : "h4"), o(), R(e.formatMessage("part_label"))
    }
}

function Yi(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-dx-outline-button", 59), S("onClickEvent", function() {
            C(e);
            let i = r(4);
            return f(i.addPart("scan"))
        }), l(), s(1, "app-dx-outline-button", 60), S("onClickEvent", function() {
            C(e);
            let i = r(4);
            return f(i.addPart("withoutScan"))
        }), l()
    }
    if (t & 2) {
        let e = r(4);
        a("text", e.isMobileDevice ? "" : "inventory_add_part")("isVisibleIcon", !0), o(), a("text", e.isMobileDevice ? "" : "inventory_add_part")("isVisibleIcon", !0)
    }
}

function qi(t, p) {
    if (t & 1 && (s(0, "div", 58), c(1, Yi, 2, 4), l()), t & 2) {
        let e = r(3);
        o(), d(e.isEditMode ? 1 : -1)
    }
}

function Qi(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "i", 63), S("click", function() {
            C(e);
            let i = r().$implicit,
                m = r(3);
            return f(m.edit(i))
        }), l()
    }
    if (t & 2) {
        let e = r(4);
        a("title", e.formatMessage("common_edit"))
    }
}

function Wi(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "i", 64), S("click", function() {
            C(e);
            let i = r().$implicit,
                m = r(3);
            return f(m.delete(i.data))
        }), l()
    }
    if (t & 2) {
        let e = r(4);
        a("title", e.formatMessage("common_delete"))
    }
}

function Hi(t, p) {
    if (t & 1 && (s(0, "div"), c(1, Qi, 1, 1, "i", 61), c(2, Wi, 1, 1, "i", 62), l()), t & 2) {
        let e = r(3);
        o(), d(e.isEditMode && e.isEmployee ? 1 : -1), o(), d(e.isEditMode && e.isEmployee ? 2 : -1)
    }
}

function zi(t, p) {
    if (t & 1 && _(0, "dxi-total-item", 53), t & 2) {
        let e = p.$implicit;
        a("alignment", e.alignment)("column", e.column)("name", e.column)("summaryType", e.summaryType)("valueFormat", B(5, Ti))
    }
}

function Ki(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "dx-data-grid", 49), S("onToolbarPreparing", function(i) {
            C(e);
            let m = r(2);
            return f(m.onToolbarPreparing(i))
        }), te("dataSourceChange", function(i) {
            C(e);
            let m = r(2);
            return ee(m.partDataSource, i) || (m.partDataSource = i), f(i)
        }), Q(1, Ui, 4, 7, "div", 50)(2, Fi, 4, 7, "div", 50)(3, Bi, 3, 4, "div", 50)(4, Gi, 2, 1, "div", 50)(5, ji, 3, 2, "div", 50)(6, qi, 2, 1, "div", 51)(7, Hi, 3, 2, "div", 50), s(8, "dxo-summary", 52), Me(9, zi, 1, 6, "dxi-total-item", 53, Ee), l()()
    }
    if (t & 2) {
        let e = r(2);
        Z("dataSource", e.partDataSource), a("columnAutoWidth", !1)("columns", e.columns)("paging", B(14, hi))("remoteOperations", B(15, vi))("scrolling", B(16, gi)), o(), a("dxTemplateOf", "taxAmountSplitSubClassTemplate"), o(), a("dxTemplateOf", "taxSplitSubClassTemplate"), o(), a("dxTemplateOf", "commentTemplate"), o(), a("dxTemplateOf", "partNameTemplate"), o(), a("dxTemplateOf", "tableHeaderTemplate"), o(), a("dxTemplateOf", "addBtnTemplate"), o(), a("dxTemplateOf", "actionTemplate"), o(), a("skipEmptyValues", !0), o(), Ie(e.summaryRows)
    }
}

function Xi(t, p) {
    if (t & 1 && (s(0, "div", 1), _(1, "app-summary-table", 65), l()), t & 2) {
        let e = r(2);
        o(), a("grandTotal", e.dataGrid.instance.getTotalSummaryValue("line_total"))("taxAmount", e.dataGrid.instance.getTotalSummaryValue("tax_amount"))("totalAmount", e.dataGrid.instance.getTotalSummaryValue("sub_total"))
    }
}

function $i(t, p) {
    t & 1 && _(0, "app-section-title", 28), t & 2 && a("title", "payment_information")
}

function Ji(t, p) {
    if (t & 1 && _(0, "app-sale-payment-list", 66), t & 2) {
        let e = r(3);
        a("paymentableId", e.saleId)
    }
}

function Zi(t, p) {
    if (t & 1 && _(0, "app-switch-btn", 69), t & 2) {
        let e = r(4);
        a("isEditMode", e.isEditMode)("label", e.formatMessage("sale_print_payment_qr"))
    }
}

function en(t, p) {
    if (t & 1 && (s(0, "app-control-container", 73), _(1, "dx-text-box", 77), l()), t & 2) {
        let e = r(5);
        a("errorMsg", e.formatMessage("common_error_messages_transaction_id_required"))("label", e.formatMessage("common_transaction_id")), o(), a("placeholder", e.formatMessage("common_placeholders_transaction_id"))("readOnly", !e.isEditMode)
    }
}

function tn(t, p) {
    if (t & 1 && (s(0, "app-control-container", 74), _(1, "dx-text-box", 78), l()), t & 2) {
        let e = r(5);
        a("errorMsg", e.formatMessage("common_error_messages_cheque_number_required"))("label", e.formatMessage("payment_cheque_number")), o(), a("placeholder", e.formatMessage("common_placeholders_cheque_number"))("readOnly", !e.isEditMode)
    }
}

function nn(t, p) {
    if (t & 1 && (s(0, "div", 70)(1, "app-control-container", 71), _(2, "app-payment-type-dropdown", 72), l(), c(3, en, 2, 4, "app-control-container", 73), c(4, tn, 2, 4, "app-control-container", 74), s(5, "app-control-container", 75), _(6, "dx-number-box", 76), l()()), t & 2) {
        let e, n, i = r(4);
        o(), a("errorMsg", i.formatMessage("common_error_messages_payment_mode_required"))("label", i.formatMessage("payment_mode")), o(), a("isEditMode", i.isEditMode), o(), d(B(10, xi).includes((e = i.form.getRawValue()) == null || e.paymentable == null ? null : e.paymentable.payment_type_id) ? 3 : -1), o(), d(((n = i.form.getRawValue()) == null || n.paymentable == null ? null : n.paymentable.payment_type_id) === 3 ? 4 : -1), o(), a("errorMsg", i.formatMessage("common_error_messages_amount_required"))("label", i.formatMessage("common_amount")), o(), a("format", i.CURRENCY_FORMAT)("min", 0)("readOnly", !i.isEditMode)
    }
}

function on(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "div", 67)(1, "dx-radio-group", 68), S("onValueChanged", function(i) {
            C(e);
            let m = r(3);
            return f(m.setPaymentOption(i))
        }), l(), c(2, Zi, 1, 2, "app-switch-btn", 69), l(), c(3, nn, 7, 11, "div", 70)
    }
    if (t & 2) {
        let e = r(3);
        o(), a("items", e.paymentOptions), o(), d(e.isPrintPaymentQr ? 2 : -1), o(), d(e.form.getRawValue().status !== e.PAYMENT_STATUS_LIST.UNPAID ? 3 : -1)
    }
}

function an(t, p) {
    if (t & 1 && (s(0, "div", 1)(1, "div", 2), c(2, Ji, 1, 1, "app-sale-payment-list", 66)(3, on, 4, 3), l()()), t & 2) {
        let e = r(2);
        o(2), d(e.saleId ? 2 : 3)
    }
}

function rn(t, p) {
    if (t & 1 && (s(0, "div", 32)(1, "div", 2), _(2, "app-user-notification-channel", 79), l()()), t & 2) {
        let e = r(2);
        o(2), a("form", e.form)
    }
}

function ln(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-save-cancel-footer", 81), S("cancelClick", function() {
            C(e);
            let i = r(3);
            return f(i.routerHelperService.goBack())
        }), l()
    }
    if (t & 2) {
        let e = r(3);
        a("gaEvent", "create_update_sale_event")("isOnPopup", !0)("isSaving", e.isSaving)("isVisibleHr", !1)("saveText", e.sale != null && e.sale.id ? "common_update" : "common_create")("savingText", e.sale != null && e.sale.id ? "common_updating" : "common_creating")
    }
}

function sn(t, p) {
    if (t & 1 && (s(0, "div", 33), Q(1, ln, 1, 6, "app-save-cancel-footer", 80), l()), t & 2) {
        let e = r(2);
        o(), a("ngxPermissionsOnly", e.PERMISSION_LIST.SALE_WRITE)
    }
}

function pn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "form", 14), S("ngSubmit", function() {
            C(e);
            let i = r();
            return f(i.save())
        }), s(1, "div", 1)(2, "div", 15), c(3, Mi, 2, 2, "h4", 16), l(), c(4, Vi, 4, 2, "div", 15), l(), c(5, Ni, 1, 1, "app-server-error", 17), _(6, "app-section-title", 18), s(7, "div", 1)(8, "app-control-container", 19)(9, "app-customer-dropdown", 20), S("itemClick", function(i) {
            C(e);
            let m = r();
            return f(m.onCustomerSelect(i))
        }), l()(), s(10, "app-control-container", 21), _(11, "app-date-picker", 22), l(), c(12, Oi, 2, 7, "app-control-container", 23), c(13, Ri, 21, 17, "div", 24), _(14, "app-show-custom-fields", 25), l(), _(15, "app-section-title", 26), s(16, "div", 1)(17, "div", 2), c(18, Ki, 11, 17, "dx-data-grid", 27), l()(), c(19, Xi, 2, 3, "div", 1), c(20, $i, 1, 1, "app-section-title", 28), c(21, an, 4, 1, "div", 1), s(22, "div", 29)(23, "app-control-container", 30), _(24, "app-textarea", 31), l()(), c(25, rn, 3, 1, "div", 32), c(26, sn, 2, 1, "div", 33), l()
    }
    if (t & 2) {
        let e, n = r();
        a("formGroup", n.form), o(3), d(n.saleId ? -1 : 3), o(), d(n.isEmployee ? 4 : -1), o(), d(n.errorResponse ? 5 : -1), o(), a("title", "common_customer_information"), o(2), a("errorMsg", n.formatMessage("common_error_messages_customer_name_required"))("label", n.formatMessage("user_customer_name")), o(), a("customerId", n.form.getRawValue().id ? (e = n.form.getRawValue()) == null ? null : e.user_id : null)("formControl", n.form.controls.user_id)("isEditMode", n.isEditMode)("isVisibleAddAction", !0), o(), a("errorMsg", n.formatMessage("common_error_messages_sale_date_required"))("label", n.formatMessage("sale_date")), o(), a("isEditMode", n.isEditMode)("placeholder", n.formatMessage("sale_date")), o(), d(n.isEmployee ? 12 : -1), o(), d(n.selectedUser ? 13 : -1), o(), a("formType", n.FORM_TYPE_LIST.SALE)("form", n.form)("hasColumn", 3), o(), a("title", "sale_items"), o(3), d(n.isLoadingPart ? -1 : 18), o(), d(n.partDataSource.length && (n.dataGrid != null && n.dataGrid.instance) && !n.isLoadingPart && n.form ? 19 : -1), o(), d(n.hasAddPaymentPermission ? 20 : -1), o(), d(n.hasAddPaymentPermission ? 21 : -1), o(2), a("errorMsg", n.formatMessage("common_error_messages_terms_required"))("label", n.formatMessage("common_terms_and_conditions")), o(), a("isEditMode", n.isEditMode), o(), d(n.saleId ? -1 : 25), o(), d(n.isEmployee && n.isMobileDevice && n.isEditMode ? 26 : -1)
    }
}

function mn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-add-part-to-entity-popup", 82), S("addPartToEntityCancelClick", function() {
            C(e);
            let i = r();
            return f(i.onPopupClose())
        })("addPartToEntitySaveClick", function(i) {
            C(e);
            let m = r();
            return f(m.onPartSave(i))
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("isCreate", e.isCreate)("isVisibleBarcodeScannerPopUp", e.isVisibleBarcodeScannerPopUp)("isVisiblePopup", e.isVisibleSalePartPopup)("partableType", e.ENTITIES.SALE.name)("partable", e.currentPart)
    }
}

function cn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-add-payment-popup", 83), S("addPaymentClose", function() {
            C(e);
            let i = r();
            return f(i.onCloseContextMenuOption())
        })("addPaymentSave", function(i) {
            C(e);
            let m = r();
            return f(m.onPopupSaveAction(i))
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("entityType", e.ENTITIES.SALE.name)("entity", e.sale)("isVisiblePopup", e.currentContextMenuAction === e.SALE_CONTEXT_MENU_LIST.ADD_PAYMENT)
    }
}

function dn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-send-payment-link-popup", 84), S("sendPaymentLinkClose", function(i) {
            C(e);
            let m = r();
            return f(m.onPopupSaveAction(i))
        })("sendPaymentLinkSave", function() {
            C(e);
            let i = r();
            return f(i.onCloseContextMenuOption())
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("entityId", e.sale.id)("entityType", e.ENTITIES.SALE.name)("isVisiblePopup", e.currentContextMenuAction === e.saleContextMenuList.SEND_UPI_LINK)
    }
}

function _n(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-collect-payment-popup", 85), S("collectPaymentClose", function() {
            C(e);
            let i = r();
            return f(i.onCloseContextMenuOption())
        })("collectPaymentSave", function(i) {
            C(e);
            let m = r();
            return f(m.onPopupSaveAction(i))
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("entityId", e.sale == null ? null : e.sale.id)("entityType", e.ENTITIES.SALE.name)("entity", e.sale)("isVisiblePopup", e.currentContextMenuAction === e.SALE_CONTEXT_MENU_LIST.COLLECT_PAYMENT)("service", e.service)
    }
}
var be = (() => {
    class t {
        static {
            this.autoId = 0
        }
        constructor(e, n, i, m, P, li) {
            this.service = e, this.partService = n, this.tableSequenceNumberService = i, this.termAndConditionService = m, this.loaderService = P, this.meta = li, this.formatMessage = u, this.ENTITIES = I, this.authorizationService = y(me), this.columns = y(_e).partColumns, this.formService = y(st), this.uuidService = y(It), this.routerHelperService = y(Ze), this.router = y(ie), this.generalSettingDataService = y(ce), this.userSessionService = y(L), this.tenantService = y(pe), this.activatedRouter = y(O), this.isMobileDevice = y(G).isMobileDevice(), this.plan = this.tenantService.plan(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.toastNotificationService = y(re), this.PAYMENT_STATUS_LIST = x, this.statusIconTypeList = ne, this.SETTINGS = Te, this.SALE_CONTEXT_MENU_LIST = v, this.CURRENCY_FORMAT = We, this.errorResponse = null, this.hasAddPaymentPermission = this.isEmployee && this.userPermissionList.includes(b.PAYMENT_WRITE), this.isCreate = !1, this.isSaving = !1, this.isEditMode = !1, this.sale = null, this.isLoadingPart = !1, this.saleContextMenu = [], this.isVisibleAddCustomerPopup = !1, this.isVisibleBarcodeScannerPopUp = !1, this.currentContextMenuAction = null, this.customers = [], this.partDataSource = [], this.isVisibleSalePartPopup = !1, this.isPrintPaymentQr = !1, this.saleId = null, this.currentPart = null, this.summaryRows = oe, this.paymentOptions = Object.values(x).filter(si => [x.PAID, x.UNPAID, x.PARTIALLY_PAID].includes(si)), this.store = null, this.saleContextMenuList = v, this.PERMISSION_LIST = b, this.FORM_TYPE_LIST = He, this.meta.addTags([{
                name: "description",
                content: "Manage Your Total Sales"
            }, {
                name: "keywords",
                content: "Sales, Laptops, Repairable, repairs, sale"
            }]), this.addUserOption = {
                icon: "add",
                type: "default",
                hint: "Add New Customer",
                onClick: () => {
                    this.isVisibleAddCustomerPopup = !0
                }
            }
        }
        ngOnInit() {
            this.saleId = +this.activatedRouter.snapshot.paramMap ? .get("sale_id");
            let e = this.getObservables();
            this.loaderService.show(), ye(e).subscribe({
                next: ([n]) => {
                    this.sale = new F(n), this.sale ? .id ? this.setSaleEditForm() : this.setSaleCreateForm(), this.initialize(), this.setSelectedUser()
                },
                error: n => {
                    console.error(n)
                }
            }).add(() => this.loaderService.hide()), this.saleContextMenu = this.saleContextMenu = [{
                name: v.ADD_PAYMENT,
                icon: U.PAYMENT.light,
                visible: this.hasAddPaymentPermission,
                locale_key: u("add_payment")
            }, {
                name: v.COLLECT_PAYMENT,
                icon: U.PAYMENT.light,
                visible: this.hasAddPaymentPermission && [K.STANDARD, K.ENTERPRISE].includes(this.plan),
                locale_key: u("common_collect_payment")
            }, {
                name: v.SALE_INVOICE,
                icon: U.INVOICE.light,
                visible: !0,
                locale_key: u("sale_invoice")
            }, {
                name: v.SEND_UPI_LINK,
                icon: ae.QR_CODE.light,
                visible: this.isEmployee && this.authorizationService.canAccess(this.ENTITIES.UPI_LINK) && this.tenantService.isIndia(),
                locale_key: u("common_send_upi_link")
            }]
        }
        addPaymentForm() {
            if (this.userPermissionList.includes(b.PAYMENT_WRITE)) {
                let e = this.dataGrid ? .instance ? .getTotalSummaryValue("line_total"),
                    n = this.form.value ? .auto_round_off === !0 ? e : e || null,
                    i = new je().group({
                        id: [null],
                        payment_type_id: [1, ve.required],
                        amount: [n, ve.required],
                        transaction_id: [null],
                        cheque_number: [null]
                    });
                this.form.addControl("paymentable", i), this.subscribeToPaymentTypeChanges()
            }
        }
        subscribeToPaymentTypeChanges() {
            this.form.get("paymentable.payment_type_id") ? .valueChanges.subscribe(n => {
                this.setPaymentType()
            })
        }
        initialize() {
            this.columns.push({
                dataField: "",
                caption: "",
                hidingPriority: 9,
                width: 45,
                cellTemplate: "actionTemplate",
                visible: this.isEditMode && this.isEmployee
            }), mt.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice)
        }
        save() {
            if (this.errorResponse = null, this.form.valid) {
                let e = this.getData(),
                    n = this.sale ? .id ? this.service.update(e) : this.service.create(e);
                this.isSaving = !0, n.subscribe({
                    next: i => this.handleSaveResponse(i),
                    error: i => this.handleErrorResponse(i)
                }).add(() => this.isSaving = !1)
            } else this.formService.validateFormFields(this.form)
        }
        getData() {
            let e = this.form.getRawValue();
            e.partables = this.getSaleParts();
            let n = this.dataGrid.instance.getTotalSummaryValue("line_total");
            return e.total_amount = this.form ? .value.auto_round_off ? Math.round(n) : n, e.tax_amount = this.dataGrid.instance.getTotalSummaryValue("tax_amount"), e
        }
        getSaleParts() {
            return this.sale ? .id ? this.partDataSource : this.partDataSource.map(e => (e.id = null, e))
        }
        onToolbarPreparing(e) {
            e.toolbarOptions.items.push({
                template: "tableHeaderTemplate",
                location: "before",
                locateInMenu: "never"
            }, {
                template: "addBtnTemplate",
                location: "after",
                locateInMenu: "never"
            })
        }
        addPart(e) {
            e === "scan" ? (this.isVisibleSalePartPopup = !0, this.isVisibleBarcodeScannerPopUp = !0, this.isCreate = !0) : (this.isVisibleSalePartPopup = !0, this.isCreate = !0)
        }
        edit(e) {
            this.isCreate = !1, this.currentPart = e.data, this.isVisibleSalePartPopup = !0
        }
        onPartSave(e) {
            this.isCreate ? (e.id = ++t.autoId, this.partDataSource.push(e)) : this.partDataSource[this.partDataSource.findIndex(n => n.id === e.id)] = e, this.recalculatePaymentAmount(), this.isCreate = !1, this.isVisibleSalePartPopup = !1, this.isVisibleBarcodeScannerPopUp = !1, this.currentPart = null
        }
        recalculatePaymentAmount() {
            setTimeout(() => {
                this.form.patchValue({
                    paymentable: {
                        amount: this.getPaymentAmount()
                    }
                })
            }, 1e3)
        }
        getPaymentAmount() {
            let e = this.form.value ? .auto_round_off,
                n = this.dataGrid.instance.getTotalSummaryValue("line_total");
            return e === !0 ? Math.round(n) : n
        }
        delete(e) {
            this.partDataSource = this.partDataSource.filter(n => n.id !== e.id), this.recalculatePaymentAmount()
        }
        setPaymentType() {
            zt.updateFormForPaymentType(this.form ? .get("paymentable")), this.form.updateValueAndValidity()
        }
        setPaymentOption(e) {
            this.showPaymentQrOption(e.value), e.value === x.PAID ? (this.form.contains("paymentable") || this.addPaymentForm(), this.recalculatePaymentAmount(), this.form ? .get("paymentable") ? .get("amount").disable()) : e.value === x.PARTIALLY_PAID ? (this.form.contains("paymentable") || this.addPaymentForm(), this.form ? .get("paymentable") ? .get("amount").enable()) : e.value === x.UNPAID && this.form.removeControl("paymentable"), this.form.updateValueAndValidity()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable(), this.columns[this.columns.findIndex(e => e.cellTemplate === "actionTemplate")].visible = !0, this.isLoadingPart = !0, this.form.patchValue({
                is_generate_qr: this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.PRINT_SETTINGS.PAYMENT_QR) || this.sale ? .qr_string ? .length > 0
            }), setTimeout(() => {
                this.isLoadingPart = !1
            })
        }
        onCustomerSelect(e) {
            this.selectedUser = null, this.form.patchValue({
                user_id: e.id,
                referred_by_id: e ? .referred_by_id
            }), this.selectedUser = e
        }
        onReferredSelect(e) {
            this.form.patchValue({
                referred_by_id: e.id
            })
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.sale = e.entity, this.currentContextMenuAction === v.VIEW_SALE && this.router.navigate(["/sales/" + e.entity.id]), this.currentContextMenuAction === v.SALE_INVOICE && this.router.navigate(["/sales/" + e.entity.id + "/invoices"])
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption()
        }
        onPopupClose() {
            this.isVisibleSalePartPopup = !1, this.isVisibleBarcodeScannerPopUp = !1
        }
        showPaymentQrOption(e) {
            let n = ![x.PAID, x.PARTIALLY_PAID].includes(e),
                i = [K.STANDARD, K.ENTERPRISE].includes(this.plan),
                m = this.tenantService ? .config() ? .merchant_id !== null;
            this.isPrintPaymentQr = n && i && m, this.form.patchValue({
                is_generate_qr: this.isPrintPaymentQr && this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.PRINT_SETTINGS.PAYMENT_QR)
            })
        }
        getObservables() {
            let e = [];
            return e.push(this.saleId ? this.service.getById(this.saleId) : Pe(new F({}))), e
        }
        setSelectedUser() {
            this.form ? .get("user_id").valueChanges.subscribe({
                next: e => {
                    this.selectedUser = this.customers.find(n => n.id === e)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        setSaleCreateForm() {
            ye([this.tableSequenceNumberService.getListByQuery({
                name: this.generalSettingDataService.getGeneralSettingByKey("unified_invoice_number_for_sales_and_jobs") ? xe.SERVICE_INVOICE.name : xe.SALE_NUMBER.name
            }), this.termAndConditionService.getByTypeId({
                type_id: ze.SALE
            })]).subscribe({
                next: ([e, n]) => {
                    this.form = F.getForm(new F({
                        sale_number: e[0].current_value,
                        term_and_condition: n ? .text ? ? "",
                        auto_round_off: this.generalSettingDataService.getGeneralSettingByKey(Te.GENERAL_SETTINGS.AUTO_ROUND_OFF),
                        status: this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SALE_CREATE_NEXT_PAYMENT_STATUS) ? ? x.PAID
                    }));
                    let i = this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SALE_CREATE_NEXT_PAYMENT_STATUS) ? ? x.PAID;
                    [x.PAID, x.PARTIALLY_PAID].includes(i) ? this.addPaymentForm() : (this.showPaymentQrOption(i), this.form.removeControl("paymentable")), this.form ? .get("paymentable") ? .get("amount").disable(), this.isEditMode = !0
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.columns[this.columns.findIndex(e => e.cellTemplate === "actionTemplate")].visible = !0, this.loaderService.hide()
            })
        }
        setSaleEditForm() {
            this.form = F.getForm(this.sale), this.partDataSource = this.sale.partables, this.selectedUser = this.sale.user, this.isEditMode = !1, this.form.disable()
        }
        handleSaveResponse(e) {
            this.sale ? .id ? (this.sale = new F(e), this.toastNotificationService.success("notification_sale_update_success"), this.form.patchValue(this.sale), this.form.disable(), this.isEditMode = !1) : (this.router.navigate([`/sales/${e.id}/invoices`]), this.toastNotificationService.success("notification_sale_add_success"))
        }
        handleErrorResponse(e) {
            this.errorResponse = e
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(T(Y), T(Nt), T(Zt), T(_t), T(se), T(Oe))
            }
        }
        static {
            this.\u0275cmp = E({
                type: t,
                selectors: [
                    ["app-sale-detail"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && A(j, 5), n & 2) {
                        let m;
                        D(m = V()) && (i.dataGrid = m.first)
                    }
                },
                standalone: !1,
                decls: 9,
                vars: 7,
                consts: [
                    [1, "row", "mb-3"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "isCreate", "isVisibleBarcodeScannerPopUp", "isVisiblePopup", "partableType", "partable"],
                    [3, "entityType", "entity", "isVisiblePopup"],
                    [3, "entityId", "entityType", "isVisiblePopup"],
                    [3, "entityId", "entityType", "entity", "isVisiblePopup", "service"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "buttonText", "contextMenuItems", "entityName", "entity", "isIconOnly", "isOnDetailPage"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "buttonText", "contextMenuItems", "entityName", "entity", "isIconOnly", "isOnDetailPage"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "float-start"],
                    [3, "errorResponse"],
                    ["id", "job-basic-info-title", 1, "mt-3", 3, "title"],
                    ["name", "user_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "isVisibleAddAction"],
                    ["name", "created_at", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "created_at", 3, "isEditMode", "placeholder"],
                    ["name", "referred_by_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "row", "my-2"],
                    [1, "row", "d-flex", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    ["id", "sale-items-title", 1, "mt-3", 3, "title"],
                    ["keyExpr", "id", 3, "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    ["id", "payment-information-title", 1, "mt-3", "mb-2", 3, "title"],
                    [1, "row", "mt-3"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition", 3, "isEditMode"],
                    [1, "row", "mt-4"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "cancelClick", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["id", "job-basic-info-back"],
                    ["buttonType", "default", "class", "ms-2", "text", "common_edit", "title", "common_edit", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "ms-2", 3, "onClickEvent"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "isVisibleAddAction", "showCrateButton"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4"],
                    [1, "card-text"],
                    [1, "me-2"],
                    [1, "fa-thin", "fa-phone"],
                    [3, "href"],
                    [1, "mx-4", 3, "textToBeCopied"],
                    [1, "fa-thin", "fa-envelope"],
                    ["keyExpr", "id", 3, "onToolbarPreparing", "dataSourceChange", "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["class", "d-flex", 4, "dxTemplate", "dxTemplateOf"],
                    [3, "skipEmptyValues"],
                    ["displayFormat", "{0}", 3, "alignment", "column", "name", "summaryType", "valueFormat"],
                    [1, "tax-split", 3, "innerHTML"],
                    [3, "innerHTML"],
                    [3, "part"],
                    [3, "ngClass"],
                    [1, "d-flex"],
                    ["buttonType", "default", "icon", "fa-thin fa-barcode-read", 1, "float-end", "me-1", 3, "onClickEvent", "text", "isVisibleIcon"],
                    ["buttonType", "default", "icon", "fa-thin fa-plus", 1, "float-end", 3, "onClickEvent", "text", "isVisibleIcon"],
                    [1, "fa-thin", "fa-pencil", "me-1", 3, "title"],
                    [1, "fa-thin", "fa-trash", 3, "title"],
                    [1, "fa-thin", "fa-pencil", "me-1", 3, "click", "title"],
                    [1, "fa-thin", "fa-trash", 3, "click", "title"],
                    [3, "grandTotal", "taxAmount", "totalAmount"],
                    [3, "paymentableId"],
                    [1, "d-flex", "align-items-center"],
                    ["formControlName", "status", "layout", "horizontal", 1, "mb-2", "d-inline-block", 3, "onValueChanged", "items"],
                    ["formControlName", "is_generate_qr", 3, "isEditMode", "label"],
                    ["formGroupName", "paymentable", 1, "row"],
                    ["name", "payment_type_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "payment_type_id", 3, "isEditMode"],
                    ["name", "transaction_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "cheque_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "amount", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "amount", "id", "add-payment-popup-remaining-amount", 3, "format", "min", "readOnly"],
                    ["formControlName", "transaction_id", "id", "add-payment-popup-transaction_id", 3, "placeholder", "readOnly"],
                    ["formControlName", "cheque_number", "id", "add-payment-popup-cheque_number", 3, "placeholder", "readOnly"],
                    [1, "mt-2", 3, "form"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "gaEvent", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "cancelClick", "gaEvent", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    [3, "addPartToEntityCancelClick", "addPartToEntitySaveClick", "isCreate", "isVisibleBarcodeScannerPopUp", "isVisiblePopup", "partableType", "partable"],
                    [3, "addPaymentClose", "addPaymentSave", "entityType", "entity", "isVisiblePopup"],
                    [3, "sendPaymentLinkClose", "sendPaymentLinkSave", "entityId", "entityType", "isVisiblePopup"],
                    [3, "collectPaymentClose", "collectPaymentSave", "entityId", "entityType", "entity", "isVisiblePopup", "service"]
                ],
                template: function(n, i) {
                    n & 1 && (c(0, Pi, 7, 4, "div", 0), s(1, "div", 1)(2, "div", 2), c(3, Ei, 1, 2, "app-skeleton-loader", 3), c(4, pn, 27, 30, "form", 4), l()(), c(5, mn, 1, 5, "app-add-part-to-entity-popup", 5), c(6, cn, 1, 3, "app-add-payment-popup", 6), c(7, dn, 1, 3, "app-send-payment-link-popup", 7), c(8, _n, 1, 5, "app-collect-payment-popup", 8)), n & 2 && (d(i.saleId ? 0 : -1), o(3), d(!i.form && i.saleId ? 3 : -1), o(), d(i.form ? 4 : -1), o(), d(i.isVisibleSalePartPopup ? 5 : -1), o(), d(i.currentContextMenuAction === i.SALE_CONTEXT_MENU_LIST.ADD_PAYMENT ? 6 : -1), o(), d(i.sale != null && i.sale.id && i.currentContextMenuAction === i.saleContextMenuList.SEND_UPI_LINK ? 7 : -1), o(), d(i.sale != null && i.sale.id && i.currentContextMenuAction === i.SALE_CONTEXT_MENU_LIST.COLLECT_PAYMENT ? 8 : -1))
                },
                dependencies: [Ve, jt, Dt, pt, vt, at, Mt, Ut, Bt, Ce, Ot, de, ue, Ht, Lt, Vt, fe, Ft, ot, le, ht, Gt, Qt, wt, et, j, tt, it, xt, bt, nt, Re, Le, ke, Ue, Ge, Be, Fe, Qe, ti, ut, kt, lt],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var un = t => ({
        customer_id: t
    }),
    Cn = (t, p, e) => [t, p, e],
    fn = (t, p, e) => ({
        icon: "dx-icon-cart",
        title: t,
        description: p,
        primaryButtonText: "empty_state_sale_primary_button",
        quickTips: e,
        tutorialUrl: "https://www.youtube.com/watch?v=h6eb8CH-OCk",
        tutorialVisible: !0,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function yn(t, p) {
    if (t & 1 && _(0, "app-overview-report-card-on-list", 0), t & 2) {
        let e = r();
        a("entity", e.ENTITIES.SALE.name)("label", e.formatMessage("overview_report_sale_quick_overview_report"))
    }
}

function Sn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-unified-payment-modal", 6), S("paymentClose", function() {
            C(e);
            let i = r();
            return f(i.onCloseContextMenuOption())
        })("paymentSuccess", function(i) {
            C(e);
            let m = r();
            return f(m.onPaymentSuccess(i))
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("isVisiblePopup", e.isVisibleUnifiedPaymentModal)("entity", e.currentSale)("entityType", e.ENTITIES.SALE.name)
    }
}

function hn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-refund-popup", 7), S("saveClick", function(i) {
            C(e);
            let m = r();
            return f(m.onPopupSaveAction(i))
        })("cancelClick", function() {
            C(e);
            let i = r();
            return f(i.onCloseContextMenuOption())
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("entityNumber", e.currentSale.sale_number)("paymentReceived", e.currentSale == null ? null : e.currentSale.paymentable_sum_amount)("entityType", e.ENTITIES.SALE.name)("entity", e.currentSale)("paymentEntityId", e.currentSale == null ? null : e.currentSale.id)("paymentEntityType", e.ENTITIES.SALE.name)("userId", e.currentSale == null ? null : e.currentSale.user_id)("isVisiblePopup", (e.currentSale == null ? null : e.currentSale.id) && e.currentContextMenuAction === e.SALE_CONTEXT_MENU_LIST.REFUND)
    }
}

function vn(t, p) {
    if (t & 1) {
        let e = h();
        s(0, "app-send-payment-link-popup", 8), S("sendPaymentLinkClose", function(i) {
            C(e);
            let m = r();
            return f(m.onPopupSaveAction(i))
        })("sendPaymentLinkSave", function() {
            C(e);
            let i = r();
            return f(i.onCloseContextMenuOption())
        }), l()
    }
    if (t & 2) {
        let e = r();
        a("entityId", e.currentSale.id)("entityType", e.ENTITIES.SALE.name)("isVisiblePopup", e.currentContextMenuAction === e.SALE_CONTEXT_MENU_LIST.SEND_UPI_LINK)
    }
}
var ni = (() => {
    class t {
        get hasTenantSales() {
            return this.isEmployee ? (this.tenantService.config() ? .entity_counts ? .sales || 0) > 0 : !0
        }
        constructor(e) {
            this.service = e, this.formatMessage = u, this.authorizationService = y(me), this.userSessionService = y(L), this.tenantService = y(pe), this.activatedRouter = y(O), this.router = y(ie), this.isMobileDevice = y(G).isMobileDevice(), this.toastNotificationService = y(re), this.plan = this.tenantService.plan(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.SALE_CONTEXT_MENU_LIST = v, this.entity = I.SALE, this.customerId = null, this.currentContextMenuAction = null, this.isVisibleUnifiedPaymentModal = !1, this.saleContextMenu = [], this.isVisibleArchiveDeletePopup = Se(!1), this.archiveDeleteMode = Se("delete"), this.columns = [{
                dataField: "sale_number",
                caption: u("sale_number"),
                width: this.isMobileDevice ? 80 : 100,
                cellTemplate: "idLinkTemplate",
                allowSorting: !0
            }, {
                dataField: "user",
                caption: u("user_customer_name"),
                width: this.isMobileDevice ? 120 : 160,
                cellTemplate: "userTemplate",
                allowSorting: !1
            }, {
                dataField: "user.mobile_number",
                caption: u("common_mobile_number"),
                cellTemplate: "phoneTemplate",
                hidingPriority: 5,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "user.gst_number",
                caption: u("sale_tax_number"),
                hidingPriority: 4,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "partables",
                caption: u("part_label"),
                cellTemplate: "objToStringTemplate",
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "total_amount",
                caption: u("common_total_amount"),
                hidingPriority: 6,
                alignment: "center",
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "paymentable_sum_amount",
                caption: u("payment_received"),
                hidingPriority: 7,
                alignment: "center",
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "",
                caption: u("payment_remaining"),
                hidingPriority: 8,
                allowSorting: !1,
                alignment: "center",
                calculateCellValue: n => Number(((n.total_amount ? ? 0) - (n.paymentable_sum_amount ? ? 0)).toFixed(2)),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "status",
                caption: u("payment_status"),
                cellTemplate: "saleStatusTemplate",
                hidingPriority: 9,
                allowSorting: !1,
                alignment: "center"
            }, {
                dataField: "created_user",
                caption: u("common_created_by"),
                cellTemplate: "employeeTemplate",
                visible: !1,
                hidingPriority: 7,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: u("common_updated_on"),
                alignment: "center",
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: u("common_created_on"),
                alignment: "center",
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.ENTITIES = I
        }
        ngOnInit() {
            this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.saleContextMenu = [{
                name: v.ADD_PAYMENT,
                icon: U.PAYMENT.light,
                visible: this.isEmployee && this.userPermissionList.includes(b.PAYMENT_WRITE),
                locale_key: u("add_payment")
            }, {
                name: v.SALE_INVOICE,
                icon: U.INVOICE.light,
                visible: !0,
                locale_key: u("sale_invoice")
            }, {
                name: v.SEND_UPI_LINK,
                icon: ae.QR_CODE.light,
                visible: this.isEmployee && this.authorizationService.canAccess(this.ENTITIES.UPI_LINK) && this.tenantService.isIndia(),
                locale_key: u("common_send_upi_link")
            }, {
                name: v.DELETE_SALE,
                icon: Xe.DELETE.light,
                visible: this.userPermissionList.includes(b.SALE_DELETE),
                locale_key: u("sale_action_delete_sale")
            }]
        }
        create() {
            this.router.navigate(["/sales/add"])
        }
        edit(e) {
            this.router.navigate(["/sales/" + e.id])
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentSale = e.entity, this.currentContextMenuAction === v.VIEW_SALE && this.router.navigate(["/sales/" + e.entity.id]), this.currentContextMenuAction === v.SALE_INVOICE && this.router.navigate(["/sales/" + e.entity.id + "/invoices"]), this.currentContextMenuAction === v.ADD_PAYMENT && (this.currentSale.total_amount > 0 ? this.isVisibleUnifiedPaymentModal = !0 : this.toastNotificationService.warning("payment_warning_no_items")), this.currentContextMenuAction === v.DELETE_SALE && (this.archiveDeleteMode.set(this.currentSale.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup.set(!0))
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentSale = null, this.isVisibleUnifiedPaymentModal = !1
        }
        onPaymentSuccess(e) {
            this.isVisibleUnifiedPaymentModal = !1, this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption()
        }
        handleArchiveDeleteSuccess(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(T(Y))
            }
        }
        static {
            this.\u0275cmp = E({
                type: t,
                selectors: [
                    ["app-sale-list"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && A(k, 5), n & 2) {
                        let m;
                        D(m = V()) && (i.dataGrid = m.first)
                    }
                },
                standalone: !1,
                decls: 6,
                vars: 33,
                consts: [
                    [3, "entity", "label"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "contextMenuItems", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleExportAction", "isVisibleReportDropdown", "service", "searchPanelPlaceholderText", "hasTenantData", "emptyStateConfig"],
                    [3, "isVisiblePopup", "entity", "entityType"],
                    [3, "entityNumber", "paymentReceived", "entityType", "entity", "paymentEntityId", "paymentEntityType", "userId", "isVisiblePopup"],
                    [3, "entityId", "entityType", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "paymentClose", "paymentSuccess", "isVisiblePopup", "entity", "entityType"],
                    [3, "saveClick", "cancelClick", "entityNumber", "paymentReceived", "entityType", "entity", "paymentEntityId", "paymentEntityType", "userId", "isVisiblePopup"],
                    [3, "sendPaymentLinkClose", "sendPaymentLinkSave", "entityId", "entityType", "isVisiblePopup"]
                ],
                template: function(n, i) {
                    n & 1 && (c(0, yn, 1, 2, "app-overview-report-card-on-list", 0), s(1, "app-data-grid", 1), S("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(P) {
                        return i.onContextMenuItemClick(P)
                    })("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(P) {
                        return i.edit(P)
                    }), l(), c(2, Sn, 1, 3, "app-unified-payment-modal", 2), c(3, hn, 1, 8, "app-refund-popup", 3), c(4, vn, 1, 3, "app-send-payment-link-popup", 4), s(5, "app-archive-delete-popup", 5), te("isVisibleChange", function(P) {
                        return ee(i.isVisibleArchiveDeletePopup, P) || (i.isVisibleArchiveDeletePopup = P), P
                    }), S("onSuccess", function(P) {
                        return i.handleArchiveDeleteSuccess(P)
                    })("onCancel", function() {
                        return i.onCloseContextMenuOption()
                    }), l()), n & 2 && (d(i.isAdmin && !i.customerId ? 0 : -1), o(), a("additionalParams", Ae(23, un, i.customerId))("columns", i.columns)("contextMenuItems", i.saleContextMenu)("entity", i.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("isVisibleReportDropdown", !0)("service", i.service)("searchPanelPlaceholderText", "search_panel_sale_placeholder")("hasTenantData", i.hasTenantSales)("emptyStateConfig", H(29, fn, i.formatMessage("empty_state_sale_title"), i.formatMessage("empty_state_sale_description"), H(25, Cn, i.formatMessage("empty_state_sale_tip_1"), i.formatMessage("empty_state_sale_tip_2"), i.formatMessage("empty_state_sale_tip_3")))), o(), d(i.currentSale != null && i.currentSale.id && i.currentContextMenuAction === i.SALE_CONTEXT_MENU_LIST.ADD_PAYMENT && i.isVisibleUnifiedPaymentModal ? 2 : -1), o(), d(i.currentContextMenuAction === i.SALE_CONTEXT_MENU_LIST.REFUND ? 3 : -1), o(), d(i.currentContextMenuAction === i.SALE_CONTEXT_MENU_LIST.SEND_UPI_LINK ? 4 : -1), o(), Z("isVisible", i.isVisibleArchiveDeletePopup), a("service", i.service)("entity", i.currentSale)("entityName", i.entity == null ? null : i.entity.name)("entityDisplayName", i.entity == null ? null : i.entity.displayName)("entityNumberField", "sale_number")("mode", i.archiveDeleteMode()))
                },
                dependencies: [At, k, Ce, Kt, $t, Xt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Tn(t, p) {
    if (t & 1 && _(0, "app-send-whats-app-btn", 5), t & 2) {
        let e = r();
        a("entityId", e.sale == null ? null : e.sale.id)("entityName", e.ENTITIES.SALE.name)
    }
}

function xn(t, p) {
    if (t & 1 && _(0, "app-send-notification", 6), t & 2) {
        let e = r();
        a("entityObj", e.sale)("entity", e.ENTITIES.SALE)("sale", e.sale)
    }
}

function bn(t, p) {
    if (t & 1 && (_(0, "app-currency-symbol"), g(1)), t & 2) {
        let e = r(2);
        o(), M(" ", e.sale == null ? null : e.sale.total_amount, " ")
    }
}

function Pn(t, p) {
    if (t & 1 && (_(0, "app-currency-symbol"), g(1)), t & 2) {
        let e = r(2);
        o(), M(" ", e.sale.paymentable_sum_amount, " ")
    }
}

function En(t, p) {
    if (t & 1 && (s(0, "div", 20)(1, "span", 27), g(2), l(), s(3, "span", 22), _(4, "app-payment-status", 28), l()()), t & 2) {
        let e = r(2);
        o(2), M("", e.formatMessage("payment_status"), ":"), o(2), a("status", e.sale.status)
    }
}

function Mn(t, p) {
    if (t & 1 && (s(0, "div", 10)(1, "div", 11)(2, "div", 1), _(3, "app-invoice-header", 12)(4, "app-invoice-title", 13)(5, "app-invoice-customer-detail", 14), s(6, "div", 15)(7, "div", 1), _(8, "app-print-table", 16)(9, "app-summary-table", 17), l()(), s(10, "div", 18)(11, "div", 1)(12, "h5", 19), g(13), l(), s(14, "div", 11)(15, "div", 20)(16, "span", 21), g(17), l(), s(18, "span", 22), g(19, ":"), l(), c(20, bn, 2, 1), l(), s(21, "div", 23)(22, "span", 21), g(23), l(), _(24, "span", 22), c(25, Pn, 2, 1), l(), c(26, En, 5, 2, "div", 20), l()()(), _(27, "app-invoice-term-and-conditions", 24)(28, "hr", 25)(29, "app-invoice-signature", 26), l()()()), t & 2) {
        let e = r();
        o(3), a("account", e.account)("qrCode", (e.sale == null ? null : e.sale.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.sale == null ? null : e.sale.qr_code)), o(), a("dateTime", e.sale == null ? null : e.sale.created_at)("title", e.printSettings != null && e.printSettings.sale_invoice_title ? e.printSettings.sale_invoice_title + " " + ((e.sale == null ? null : e.sale.sale_number) ? ? "") : e.formatMessage("sale_invoice") + " " + ((e.sale == null ? null : e.sale.sale_number) ? ? "")), o(), a("userId", e.sale.user_id), o(3), a("columns", e.partColumns)("rows", e.sale.partables), o(), a("isBarcode", !!(e.sale != null && e.sale.qr_string))("qrString", e.sale == null ? null : e.sale.qr_string)("rows", e.sale.partables), o(4), M(" ", e.formatMessage("payment_information"), " "), o(4), R(e.formatMessage("payment_payable_amount")), o(3), d(e.sale != null && e.sale.total_amount ? 20 : -1), o(3), M("", e.formatMessage("payment_received"), " : "), o(2), d(e.sale.paymentable_sum_amount ? 25 : -1), o(), d(e.printSettings.status ? 26 : -1), o(), a("termAndCondition", e.sale.term_and_condition), o(2), a("entityId", e.sale == null ? null : e.sale.id)("entityType", e.entityType)
    }
}
var oi = (() => {
    class t {
        constructor(e, n) {
            this.service = e, this.loaderService = n, this.formatMessage = u, this.ENTITIES = I, this.partColumns = y(_e).partColumns, this.configService = y($e), this.generalSettingDataService = y(ce), this.userSessionService = y(L), this.activatedRouter = y(O), this.isMobileDevice = y(G).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.statusIconTypeList = ne, this.entityType = this.ENTITIES.SALE.name, this.isEditMode = !0, this.dateTime = new Date, this.summaryRows = oe, this.printSettings = null, this.PERMISSION_LIST = b, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(Ke.PRINT_SETTINGS) ? ? ct.getEmptyObject()
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("sale_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("sale_id");
                this.loaderService.show(), this.service.getById(e).subscribe({
                    next: n => {
                        this.configService.appConfig$.subscribe({
                            next: i => {
                                this.account = i
                            },
                            error: i => {
                                console.log(i)
                            }
                        }), this.sale = n
                    },
                    error: n => {
                        console.error(n)
                    }
                }).add(() => {
                    this.loaderService.hide()
                })
            }
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(T(Y), T(se))
            }
        }
        static {
            this.\u0275cmp = E({
                type: t,
                selectors: [
                    ["app-sale-receipt"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && A(j, 5), n & 2) {
                        let m;
                        D(m = V()) && (i.dataGrid = m.first)
                    }
                },
                standalone: !1,
                decls: 12,
                vars: 13,
                consts: [
                    [1, "row", "mb-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [1, "me-1", 3, "entityObj", "entity", "sale"],
                    [3, "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["buttonType", "default", "text", "view_sale", 1, "float-end", "mx-1", 3, "routerLink"],
                    ["id", "print-section"],
                    [1, "row"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [1, "row", "mt-2"],
                    [3, "columns", "rows"],
                    [3, "isBarcode", "qrString", "rows"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "fw-bolder"],
                    [3, "status"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "div", 0)(1, "div", 1), _(2, "app-payment-status", 2), s(3, "span", 3), g(4), l(), s(5, "div", 4), c(6, Tn, 1, 2, "app-send-whats-app-btn", 5), c(7, xn, 1, 3, "app-send-notification", 6), _(8, "app-print-button", 7)(9, "app-share-btn", 8)(10, "app-dx-outline-button", 9), l()()(), c(11, Mn, 30, 19, "div", 10)), n & 2 && (o(2), a("iconType", i.statusIconTypeList.TITLE)("status", i.sale == null ? null : i.sale.status), o(2), R(i.sale == null ? null : i.sale.sale_number), o(2), d(i.isEmployee && i.userPermissionList.includes(i.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION) ? 6 : -1), o(), d(i.sale && i.isEmployee && !i.isMobileDevice ? 7 : -1), o(), a("entityId", i.sale == null ? null : i.sale.id)("entityName", i.ENTITIES.SALE.name)("isVisiblePrintButton", !!(i.sale != null && i.sale.id)), o(), a("entityId", i.sale == null ? null : i.sale.id)("entityType", i.ENTITIES.SALE.name), o(), a("routerLink", W("/sales/", i.sale == null ? null : i.sale.id)), o(), d(i.sale ? 11 : -1))
                },
                dependencies: [qe, dt, Ct, Yt, ft, yt, de, rt, Rt, ue, St, gt, Tt, Pt, le],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var ai = (() => {
    class t {
        constructor() {
            this.formatMessage = u
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = E({
                type: t,
                selectors: [
                    ["app-sale"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "div", 0), _(1, "router-outlet"), l())
                },
                dependencies: [Ye],
                encapsulation: 2
            })
        }
    }
    return t
})();
var In = [{
        path: "",
        component: ai,
        children: [{
            path: "list",
            component: ni,
            canActivate: [z],
            data: {
                permissions: {
                    only: [b.SALE_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Sale Management | List"
        }, {
            path: "add",
            component: be,
            canActivate: [z, Je],
            data: {
                permissions: {
                    only: [b.SALE_WRITE]
                }
            },
            title: "BytePhase Sale | Add"
        }, {
            path: ":sale_id/invoices",
            component: oi,
            canActivate: [z],
            data: {
                permissions: {
                    only: [b.SALE_LIST]
                }
            },
            title: "BytePhase Sale | Invoices",
            pathMatch: "full"
        }, {
            path: ":sale_id/paymentReceipts/:payment_id",
            component: Wt,
            pathMatch: "full",
            title: "BytePhase Sale | Payment Receipt"
        }, {
            path: ":sale_id",
            component: be,
            canActivate: [z],
            data: {
                permissions: {
                    only: [b.SALE_LIST]
                }
            },
            title: "BytePhase Sale | Details"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    ri = (() => {
        class t {
            static {
                this.\u0275fac = function(n) {
                    return new(n || t)
                }
            }
            static {
                this.\u0275mod = J({
                    type: t
                })
            }
            static {
                this.\u0275inj = X({
                    imports: [ge.forChild(In), ge]
                })
            }
        }
        return t
    })();
var rr = (() => {
    class t {
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275mod = J({
                type: t
            })
        }
        static {
            this.\u0275inj = X({
                imports: [Ne, ri, Jt, ei]
            })
        }
    }
    return t
})();
export {
    ni as a, rr as b
};