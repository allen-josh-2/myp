import {
    f as zd,
    h as Ud
} from "./chunk-VHNNKQQY.js";
import {
    a as Ln,
    b as Bd,
    c as Vd
} from "./chunk-MKYLKZGM.js";
import {
    a as we
} from "./chunk-EPB2WS6Q.js";
import {
    a as Ld,
    b as jd
} from "./chunk-CX2GSZ36.js";
import {
    a as In
} from "./chunk-HDTUMYRX.js";
import {
    a as Fd
} from "./chunk-Q6732S4Z.js";
import {
    a as On,
    b as Nn,
    c as Rd,
    d as Ad,
    e as Od,
    f as Nd
} from "./chunk-J36DGFIN.js";
import {
    a as Md
} from "./chunk-57ITRS7T.js";
import "./chunk-CNGJSDOD.js";
import "./chunk-TIHYCMHH.js";
import {
    b as kd
} from "./chunk-WDS5LHZR.js";
import "./chunk-36T2HUF3.js";
import "./chunk-OG4EABPU.js";
import {
    a as Ze
} from "./chunk-HUDETQT5.js";
import {
    b as Pd
} from "./chunk-PGAHHPJ5.js";
import "./chunk-MBAKXBI4.js";
import "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import "./chunk-FAP35UT3.js";
import "./chunk-2KS5UOZO.js";
import {
    a as be
} from "./chunk-KJCCJCIN.js";
import {
    a as Pn
} from "./chunk-MYGQO4K4.js";
import {
    a as ee
} from "./chunk-BLJF2YPR.js";
import {
    a as Jc
} from "./chunk-RW3SLQZQ.js";
import {
    $a as Gc,
    A as Wl,
    B as Xl,
    Cb as pi,
    D as Jl,
    Db as xn,
    E as me,
    F as _n,
    G as ec,
    Ge as sd,
    H as nc,
    I as oc,
    J as rc,
    Jg as fd,
    K as sc,
    La as Ac,
    Lc as id,
    M as Go,
    Ma as Oc,
    N as ac,
    O as lc,
    Oa as Nc,
    Od as kn,
    P as cc,
    Pa as Lc,
    Pd as Mn,
    Pg as ui,
    Q as Pe,
    Qa as jc,
    Qc as nd,
    Qg as hi,
    R as uc,
    Ra as Fc,
    Rc as Ye,
    Rg as gd,
    S as ri,
    Se as ad,
    T as Le,
    Tc as od,
    Tg as vd,
    U as nr,
    V as Cn,
    Va as Bc,
    Vg as _d,
    W as Dc,
    Wb as Ph,
    Wf as pd,
    Wg as bd,
    X as Tc,
    Xa as Vc,
    Xb as Zc,
    Xf as ud,
    Y as xc,
    Ya as zc,
    Z as dt,
    Za as Uc,
    Zg as yd,
    _ as Pc,
    _a as Tn,
    a as Mi,
    aa as kc,
    ab as Hc,
    af as ld,
    ah as Cd,
    ba as pt,
    ca as di,
    d as zo,
    db as Wc,
    eb as qc,
    ec as Yc,
    eh as Sd,
    f as zl,
    fh as Id,
    ga as Mc,
    gb as Kc,
    gh as Rn,
    ha as wn,
    ia as En,
    id as rd,
    if as cd,
    jg as hd,
    jh as zt,
    ka as Rc,
    kc as Xc,
    kf as dd,
    kg as md,
    kh as wd,
    lb as ut,
    lc as ed,
    lh as Ed,
    mh as Dd,
    nb as $c,
    nh as Td,
    oh as xd,
    ph as An,
    v as Ul,
    w as Gl,
    wc as td,
    xb as Qc,
    z as Hl,
    zb as or
} from "./chunk-DCKGQUHB.js";
import {
    $ as rn,
    $a as M,
    $b as ii,
    A as en,
    Ab as He,
    Af as er,
    Ai as ci,
    Ak as Dn,
    B as tn,
    Bc as ki,
    Bg as mc,
    C as dl,
    Ca as gl,
    Cc as Ml,
    Cg as fc,
    Ci as Mt,
    D as To,
    Db as dn,
    Dc as gt,
    E as Tt,
    Ea as vl,
    Ec as ni,
    F as ve,
    Fa as u,
    Fb as Oe,
    Fh as $,
    G as pl,
    Ga as Mo,
    Gc as mn,
    H as nn,
    Ha as Ti,
    Hb as bl,
    Ia as Ft,
    Ib as G,
    Ig as gc,
    Ja as xi,
    Jb as Te,
    K as st,
    Ka as l,
    Kb as ge,
    Kc as Rl,
    La as Bt,
    Lb as pn,
    Lc as Bo,
    M as xo,
    Mc as Al,
    Na as _,
    Oa as Ie,
    Og as vc,
    P as ul,
    Pa as ue,
    Pb as yl,
    Pg as ct,
    Qb as Cl,
    Ra as De,
    Rb as Sl,
    S as Po,
    Sa as it,
    T as wi,
    Tc as oi,
    U as $e,
    Ua as _l,
    V as Ei,
    Va as sn,
    Vb as Il,
    Vc as Ol,
    Wa as at,
    Wh as yc,
    X as on,
    Xa as Ue,
    Xh as yn,
    Yb as lt,
    Yc as Nl,
    Z as q,
    Zc as Ll,
    _ as hl,
    _a as k,
    _b as un,
    _c as fn,
    a as jt,
    aa as A,
    ac as ft,
    ad as We,
    b as wt,
    ba as Se,
    bb as Ro,
    bc as wl,
    bd as jl,
    c as Z,
    ca as _e,
    cb as Ao,
    cd as Vo,
    d as Et,
    da as K,
    db as Oo,
    dc as El,
    dd as gn,
    e as rl,
    ea as p,
    eb as T,
    ed as Fl,
    ei as si,
    f as sl,
    fa as ml,
    fb as m,
    fd as Bl,
    g as Eo,
    ga as tt,
    gb as b,
    gc as Dl,
    gd as Vl,
    h as al,
    ha as L,
    hb as V,
    hc as Tl,
    hi as le,
    ia as j,
    ib as an,
    id as Uo,
    ii as Cc,
    jb as No,
    jd as ql,
    jg as tr,
    k as I,
    kb as Lo,
    kd as Kl,
    la as se,
    lb as ln,
    ld as vt,
    ma as Ae,
    mb as cn,
    mc as xe,
    md as $l,
    mg as ir,
    mh as _c,
    mi as Sc,
    n as Dt,
    na as Di,
    nb as jo,
    nd as Ql,
    o as Ji,
    oa as pe,
    od as Ri,
    oi as Ic,
    p as Do,
    pa as f,
    pd as _t,
    qa as ne,
    qb as W,
    qd as Zl,
    ra as Jt,
    rd as vn,
    sa as ei,
    sb as x,
    sd as te,
    sj as Sn,
    t as ze,
    ta as xt,
    tc as xl,
    td as Ai,
    th as bc,
    ti as ai,
    u as ll,
    ua as ti,
    ub as v,
    uc as C,
    ud as Yl,
    uh as bn,
    ui as li,
    v as cl,
    va as g,
    vb as w,
    vd as Vt,
    vi as wc,
    wa as fl,
    wb as S,
    wc as Fo,
    wd as Ne,
    wg as hc,
    wi as Ec,
    xa as ko,
    xb as Pi,
    xc as Pl,
    xk as Q,
    yb as Pt,
    yc as hn,
    zb as Ge,
    zc as kl,
    zi as fe
} from "./chunk-GOPIAW4V.js";
import {
    a as tc,
    b as ic
} from "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import {
    c as Qe,
    d as kt
} from "./chunk-LJZ7ZJF4.js";
import "./chunk-R3UD2OM4.js";
import "./chunk-QUJFQN2Y.js";
import "./chunk-3TR6LAYC.js";
import "./chunk-GVIE7AVN.js";
import "./chunk-X4EY4JYZ.js";
import "./chunk-YUK2B4W4.js";
import "./chunk-7VMAFNFA.js";
import {
    a as dc,
    c as Ho,
    d as Wo,
    e as qo,
    f as Ko,
    g as $o,
    h as Qo
} from "./chunk-62N2W5YM.js";
import {
    b as Jo
} from "./chunk-5ZIGTUBY.js";
import {
    e as Yo,
    f as Xo
} from "./chunk-Z7S3W5GA.js";
import "./chunk-M4ULIW7S.js";
import "./chunk-5LCCWDBB.js";
import "./chunk-L2KSLXYG.js";
import {
    c as Zo
} from "./chunk-VIJPFQLN.js";
import "./chunk-VSSNYSR2.js";
import "./chunk-VZWY4NEG.js";
import "./chunk-WI5MSH4N.js";
import "./chunk-LD36GOMT.js";
import "./chunk-CKP3SGE2.js";
import {
    t as pc
} from "./chunk-R5YFTT7F.js";
import {
    a as oe,
    b as It,
    e as Lt,
    h as xh,
    i as re
} from "./chunk-FBFWB55K.js";
var sr = class {
        constructor() {
            this.onHasErrorChange = new pe, this.onIsLoadedChange = new pe, this.hasError = !1, this.isLoaded = !1
        }
        loadScript(n, e, t, o = null, r = null) {
            if (typeof document < "u" && !document.getElementById(n)) {
                let s = document.createElement("script");
                s.async = !0, s.src = e, s.onload = t, s.onerror = r, o || (o = document.head), o.appendChild(s)
            }
        }
    },
    ar = class {
        constructor() {}
    },
    Hd = () => typeof window.google ? .accounts < "u",
    kh = () => {
        if (!Hd()) throw new Error("Google Accounts API is undefined")
    },
    rr = () => (kh(), window.google.accounts),
    Mh = {
        oneTapEnabled: !0
    },
    mi = (() => {
        class i extends sr {
            static {
                this.PROVIDER_ID = "GOOGLE"
            }
            constructor(e, t) {
                super(), this.clientId = e, this.initOptions = t, this.changeUser = new pe, this._socialUser = new Et(null), this._accessToken = new Et(null), this._receivedAccessToken = new pe, this.initOptions = oe(oe({}, Mh), this.initOptions), this._socialUser.pipe(Po(1)).subscribe(this.changeUser), this._accessToken.pipe(Po(1)).subscribe(this._receivedAccessToken)
            }
            initialize(e, t) {
                return new Promise((o, r) => {
                    try {
                        this.loadScript(i.PROVIDER_ID, this.getGoogleLoginScriptSrc(t || ""), () => {
                            if (Hd()) {
                                if (google.accounts.id.initialize({
                                        client_id: this.clientId,
                                        auto_select: e,
                                        callback: ({
                                            credential: s
                                        }) => {
                                            let a = this.createSocialUser(s);
                                            this._socialUser.next(a)
                                        },
                                        prompt_parent_id: this.initOptions ? .prompt_parent_id,
                                        itp_support: this.initOptions.oneTapEnabled,
                                        use_fedcm_for_prompt: this.initOptions.oneTapEnabled
                                    }), this.initOptions.oneTapEnabled && this._socialUser.pipe(ve(s => s === null)).subscribe(() => google.accounts.id.prompt(console.debug)), this.initOptions.scopes) {
                                    let s = this.initOptions.scopes instanceof Array ? this.initOptions.scopes.filter(a => a).join(" ") : this.initOptions.scopes;
                                    this._tokenClient = google.accounts.oauth2.initTokenClient({
                                        client_id: this.clientId,
                                        scope: s,
                                        prompt: this.initOptions.prompt,
                                        callback: a => {
                                            a.error ? this._accessToken.error({
                                                code: a.error,
                                                description: a.error_description,
                                                uri: a.error_uri
                                            }) : this._accessToken.next(a.access_token)
                                        }
                                    })
                                }
                                o()
                            }
                        }, null, () => {
                            this.hasError = !0, this.onHasErrorChange.emit(this.hasError), r(`There was an issue loading the ${i.PROVIDER_ID} authentication script.`)
                        })
                    } catch (s) {
                        r(s)
                    } finally {
                        this.isLoaded = !0, this.onIsLoadedChange.emit(this.isLoaded)
                    }
                })
            }
            getLoginStatus() {
                return new Promise((e, t) => {
                    this._socialUser.value ? e(this._socialUser.value) : t(`No user is currently logged in with ${i.PROVIDER_ID}`)
                })
            }
            refreshToken() {
                return new Promise((e, t) => {
                    rr().id.revoke(this._socialUser.value.id, o => {
                        o.error ? t(o.error) : e(this._socialUser.value)
                    })
                })
            }
            getAccessToken() {
                return new Promise((e, t) => {
                    this._tokenClient ? (this._tokenClient.requestAccessToken({
                        hint: this._socialUser.value ? .email
                    }), this._receivedAccessToken.pipe(st(1)).subscribe(e)) : this._socialUser.value ? t("No token client was instantiated, you should specify some scopes.") : t("You should be logged-in first.")
                })
            }
            revokeAccessToken() {
                return new Promise((e, t) => {
                    this._tokenClient ? this._accessToken.value ? rr().oauth2.revoke(this._accessToken.value, () => {
                        this._accessToken.next(null), e()
                    }) : t("No access token to revoke") : t("No token client was instantiated, you should specify some scopes.")
                })
            }
            signIn() {
                return Promise.reject('You should not call this method directly for Google, use "<asl-google-signin-button>" wrapper or generate the button yourself with "google.accounts.id.renderButton()" (https://developers.google.com/identity/gsi/web/guides/display-button#javascript)')
            }
            signOut() {
                return re(this, null, function*() {
                    rr().id.disableAutoSelect(), this._socialUser.next(null)
                })
            }
            createSocialUser(e) {
                let t = new ar;
                t.idToken = e;
                let o = this.decodeJwt(e);
                return t.id = o.sub, t.name = o.name, t.email = o.email, t.photoUrl = o.picture, t.firstName = o.given_name, t.lastName = o.family_name, t
            }
            decodeJwt(e) {
                let o = e.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"),
                    r = decodeURIComponent(window.atob(o).split("").map(function(s) {
                        return "%" + ("00" + s.charCodeAt(0).toString(16)).slice(-2)
                    }).join(""));
                return JSON.parse(r)
            }
            getGoogleLoginScriptSrc(e) {
                return e ? `https://accounts.google.com/gsi/client?hl=${e}` : "https://accounts.google.com/gsi/client"
            }
        }
        return i
    })(),
    Rh = new _e("SocialAuthServiceConfig"),
    Gd = (() => {
        class i {
            static {
                this.ERR_LOGIN_PROVIDER_NOT_FOUND = "Login provider not found"
            }
            static {
                this.ERR_NOT_LOGGED_IN = "Not logged in"
            }
            static {
                this.ERR_NOT_INITIALIZED = "Login providers not ready yet. Are there errors on your console?"
            }
            static {
                this.ERR_NOT_SUPPORTED_FOR_REFRESH_TOKEN = "Chosen login provider is not supported for refreshing a token"
            }
            static {
                this.ERR_NOT_SUPPORTED_FOR_ACCESS_TOKEN = "Chosen login provider is not supported for getting an access token"
            }
            get authState() {
                return this._authState.asObservable()
            }
            get initState() {
                return this._initState.asObservable()
            }
            constructor() {
                this.providers = new Map, this.autoLogin = !1, this.lang = "", this._user = null, this._authState = new rl(1), this.initialized = !1, this._initState = new sl, this._ngZone = p(f), this._injector = p(se), this._config = p(Rh), Promise.resolve(this._config).then(e => this.initialize(e))
            }
            initialize(e) {
                this.autoLogin = e.autoLogin !== void 0 ? e.autoLogin : !1, this.lang = e.lang !== void 0 ? e.lang : "";
                let {
                    onError: t = console.error
                } = e;
                e.providers.forEach(o => {
                    this.providers.set(o.id, "prototype" in o.provider ? this._injector.get(o.provider) : o.provider)
                }), Promise.all(Array.from(this.providers.values()).map(o => o.initialize(this.autoLogin, this.lang))).then(() => {
                    if (this.autoLogin) {
                        let o = [],
                            r = !1;
                        this.providers.forEach((s, a) => {
                            let c = s.getLoginStatus();
                            o.push(c), c.then(d => {
                                this.setUser(d, a), r = !0
                            }).catch(console.debug)
                        }), Promise.all(o).catch(() => {
                            r || (this._user = null, this._authState.next(null))
                        })
                    }
                    this.providers.forEach((o, r) => {
                        Do(o.changeUser) && o.changeUser.subscribe(s => {
                            this._ngZone.run(() => {
                                this.setUser(s, r)
                            })
                        })
                    })
                }).catch(o => {
                    t(o)
                }).finally(() => {
                    this.initialized = !0, this._initState.next(this.initialized), this._initState.complete()
                })
            }
            getAccessToken(e) {
                return re(this, null, function*() {
                    let t = this.providers.get(e);
                    if (this.initialized)
                        if (t) {
                            if (!(t instanceof mi)) throw i.ERR_NOT_SUPPORTED_FOR_ACCESS_TOKEN
                        } else throw i.ERR_LOGIN_PROVIDER_NOT_FOUND;
                    else throw i.ERR_NOT_INITIALIZED;
                    return yield t.getAccessToken()
                })
            }
            refreshAuthToken(e) {
                return new Promise((t, o) => {
                    if (!this.initialized) o(i.ERR_NOT_INITIALIZED);
                    else {
                        let r = this.providers.get(e);
                        r ? typeof r.refreshToken != "function" ? o(i.ERR_NOT_SUPPORTED_FOR_REFRESH_TOKEN) : r.refreshToken().then(s => {
                            this.setUser(s, e), t()
                        }).catch(s => {
                            o(s)
                        }) : o(i.ERR_LOGIN_PROVIDER_NOT_FOUND)
                    }
                })
            }
            refreshAccessToken(e) {
                return new Promise((t, o) => {
                    if (!this.initialized) o(i.ERR_NOT_INITIALIZED);
                    else if (e !== mi.PROVIDER_ID) o(i.ERR_NOT_SUPPORTED_FOR_REFRESH_TOKEN);
                    else {
                        let r = this.providers.get(e);
                        r instanceof mi ? r.revokeAccessToken().then(t).catch(o) : o(i.ERR_LOGIN_PROVIDER_NOT_FOUND)
                    }
                })
            }
            signIn(e, t) {
                return new Promise((o, r) => {
                    if (!this.initialized) r(i.ERR_NOT_INITIALIZED);
                    else {
                        let s = this.providers.get(e);
                        s ? s.signIn(t).then(a => {
                            this.setUser(a, e), o(a)
                        }).catch(a => {
                            r(a)
                        }) : r(i.ERR_LOGIN_PROVIDER_NOT_FOUND)
                    }
                })
            }
            signOut(e = !1) {
                return new Promise((t, o) => {
                    if (!this.initialized) o(i.ERR_NOT_INITIALIZED);
                    else if (!this._user) o(i.ERR_NOT_LOGGED_IN);
                    else {
                        let r = this._user.provider,
                            s = this.providers.get(r);
                        s ? s.signOut(e).then(() => {
                            t(), this.setUser(null)
                        }).catch(a => {
                            o(a)
                        }) : o(i.ERR_LOGIN_PROVIDER_NOT_FOUND)
                    }
                })
            }
            setUser(e, t) {
                e && t && (e.provider = t), this._user = e, this._authState.next(e)
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || i)
                }
            }
            static {
                this.\u0275prov = A({
                    token: i,
                    factory: i.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return i
    })(),
    Wd = (() => {
        class i {
            static initialize(e) {
                return {
                    ngModule: i,
                    providers: [Gd, {
                        provide: "SocialAuthServiceConfig",
                        useValue: e
                    }]
                }
            }
            constructor() {
                if (p(i, {
                        optional: !0,
                        skipSelf: !0
                    })) throw new Error("SocialLoginModule is already loaded. Import it in the AppModule only")
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || i)
                }
            }
            static {
                this.\u0275mod = Ie({
                    type: i
                })
            }
            static {
                this.\u0275inj = Se({
                    providers: [Gd],
                    imports: [oi]
                })
            }
        }
        return i
    })();
var U = (function(i) {
        return i[i.State = 0] = "State", i[i.Transition = 1] = "Transition", i[i.Sequence = 2] = "Sequence", i[i.Group = 3] = "Group", i[i.Animate = 4] = "Animate", i[i.Keyframes = 5] = "Keyframes", i[i.Style = 6] = "Style", i[i.Trigger = 7] = "Trigger", i[i.Reference = 8] = "Reference", i[i.AnimateChild = 9] = "AnimateChild", i[i.AnimateRef = 10] = "AnimateRef", i[i.Query = 11] = "Query", i[i.Stagger = 12] = "Stagger", i
    })(U || {}),
    Xe = "*";

function lr(i, n) {
    return {
        type: U.Trigger,
        name: i,
        definitions: n,
        options: {}
    }
}

function Gt(i, n = null) {
    return {
        type: U.Animate,
        styles: n,
        timings: i
    }
}

function jn(i, n = null) {
    return {
        type: U.Group,
        steps: i,
        options: n
    }
}

function qd(i, n = null) {
    return {
        type: U.Sequence,
        steps: i,
        options: n
    }
}

function ke(i) {
    return {
        type: U.Style,
        styles: i,
        offset: null
    }
}

function Oi(i, n, e = null) {
    return {
        type: U.Transition,
        expr: i,
        animation: n,
        options: e
    }
}

function bt(i, n, e = null) {
    return {
        type: U.Query,
        selector: i,
        animation: n,
        options: e
    }
}
var ht = class {
        _onDoneFns = [];
        _onStartFns = [];
        _onDestroyFns = [];
        _originalOnDoneFns = [];
        _originalOnStartFns = [];
        _started = !1;
        _destroyed = !1;
        _finished = !1;
        _position = 0;
        parentPlayer = null;
        totalTime;
        constructor(n = 0, e = 0) {
            this.totalTime = n + e
        }
        _onFinish() {
            this._finished || (this._finished = !0, this._onDoneFns.forEach(n => n()), this._onDoneFns = [])
        }
        onStart(n) {
            this._originalOnStartFns.push(n), this._onStartFns.push(n)
        }
        onDone(n) {
            this._originalOnDoneFns.push(n), this._onDoneFns.push(n)
        }
        onDestroy(n) {
            this._onDestroyFns.push(n)
        }
        hasStarted() {
            return this._started
        }
        init() {}
        play() {
            this.hasStarted() || (this._onStart(), this.triggerMicrotask()), this._started = !0
        }
        triggerMicrotask() {
            queueMicrotask(() => this._onFinish())
        }
        _onStart() {
            this._onStartFns.forEach(n => n()), this._onStartFns = []
        }
        pause() {}
        restart() {}
        finish() {
            this._onFinish()
        }
        destroy() {
            this._destroyed || (this._destroyed = !0, this.hasStarted() || this._onStart(), this.finish(), this._onDestroyFns.forEach(n => n()), this._onDestroyFns = [])
        }
        reset() {
            this._started = !1, this._finished = !1, this._onStartFns = this._originalOnStartFns, this._onDoneFns = this._originalOnDoneFns
        }
        setPosition(n) {
            this._position = this.totalTime ? n * this.totalTime : 1
        }
        getPosition() {
            return this.totalTime ? this._position / this.totalTime : 1
        }
        triggerCallback(n) {
            let e = n == "start" ? this._onStartFns : this._onDoneFns;
            e.forEach(t => t()), e.length = 0
        }
    },
    Ut = class {
        _onDoneFns = [];
        _onStartFns = [];
        _finished = !1;
        _started = !1;
        _destroyed = !1;
        _onDestroyFns = [];
        parentPlayer = null;
        totalTime = 0;
        players;
        constructor(n) {
            this.players = n;
            let e = 0,
                t = 0,
                o = 0,
                r = this.players.length;
            r == 0 ? queueMicrotask(() => this._onFinish()) : this.players.forEach(s => {
                s.onDone(() => {
                    ++e == r && this._onFinish()
                }), s.onDestroy(() => {
                    ++t == r && this._onDestroy()
                }), s.onStart(() => {
                    ++o == r && this._onStart()
                })
            }), this.totalTime = this.players.reduce((s, a) => Math.max(s, a.totalTime), 0)
        }
        _onFinish() {
            this._finished || (this._finished = !0, this._onDoneFns.forEach(n => n()), this._onDoneFns = [])
        }
        init() {
            this.players.forEach(n => n.init())
        }
        onStart(n) {
            this._onStartFns.push(n)
        }
        _onStart() {
            this.hasStarted() || (this._started = !0, this._onStartFns.forEach(n => n()), this._onStartFns = [])
        }
        onDone(n) {
            this._onDoneFns.push(n)
        }
        onDestroy(n) {
            this._onDestroyFns.push(n)
        }
        hasStarted() {
            return this._started
        }
        play() {
            this.parentPlayer || this.init(), this._onStart(), this.players.forEach(n => n.play())
        }
        pause() {
            this.players.forEach(n => n.pause())
        }
        restart() {
            this.players.forEach(n => n.restart())
        }
        finish() {
            this._onFinish(), this.players.forEach(n => n.finish())
        }
        destroy() {
            this._onDestroy()
        }
        _onDestroy() {
            this._destroyed || (this._destroyed = !0, this._onFinish(), this.players.forEach(n => n.destroy()), this._onDestroyFns.forEach(n => n()), this._onDestroyFns = [])
        }
        reset() {
            this.players.forEach(n => n.reset()), this._destroyed = !1, this._finished = !1, this._started = !1
        }
        setPosition(n) {
            let e = n * this.totalTime;
            this.players.forEach(t => {
                let o = t.totalTime ? Math.min(1, e / t.totalTime) : 1;
                t.setPosition(o)
            })
        }
        getPosition() {
            let n = this.players.reduce((e, t) => e === null || t.totalTime > e.totalTime ? t : e, null);
            return n != null ? n.getPosition() : 0
        }
        beforeDestroy() {
            this.players.forEach(n => {
                n.beforeDestroy && n.beforeDestroy()
            })
        }
        triggerCallback(n) {
            let e = n == "start" ? this._onStartFns : this._onDoneFns;
            e.forEach(t => t()), e.length = 0
        }
    },
    fi = "!";

function Kd(i) {
    return new q(3e3, !1)
}

function Ah() {
    return new q(3100, !1)
}

function Oh() {
    return new q(3101, !1)
}

function Nh(i) {
    return new q(3001, !1)
}

function Lh(i) {
    return new q(3003, !1)
}

function jh(i) {
    return new q(3004, !1)
}

function Qd(i, n) {
    return new q(3005, !1)
}

function Zd() {
    return new q(3006, !1)
}

function Yd() {
    return new q(3007, !1)
}

function Xd(i, n) {
    return new q(3008, !1)
}

function Jd(i) {
    return new q(3002, !1)
}

function ep(i, n, e, t, o) {
    return new q(3010, !1)
}

function tp() {
    return new q(3011, !1)
}

function ip() {
    return new q(3012, !1)
}

function np() {
    return new q(3200, !1)
}

function op() {
    return new q(3202, !1)
}

function rp() {
    return new q(3013, !1)
}

function sp(i) {
    return new q(3014, !1)
}

function ap(i) {
    return new q(3015, !1)
}

function lp(i) {
    return new q(3016, !1)
}

function cp(i, n) {
    return new q(3404, !1)
}

function Fh(i) {
    return new q(3502, !1)
}

function dp(i) {
    return new q(3503, !1)
}

function pp() {
    return new q(3300, !1)
}

function up(i) {
    return new q(3504, !1)
}

function hp(i) {
    return new q(3301, !1)
}

function mp(i, n) {
    return new q(3302, !1)
}

function fp(i) {
    return new q(3303, !1)
}

function gp(i, n) {
    return new q(3400, !1)
}

function vp(i) {
    return new q(3401, !1)
}

function _p(i) {
    return new q(3402, !1)
}

function bp(i, n) {
    return new q(3505, !1)
}

function yt(i) {
    switch (i.length) {
        case 0:
            return new ht;
        case 1:
            return i[0];
        default:
            return new Ut(i)
    }
}

function ur(i, n, e = new Map, t = new Map) {
    let o = [],
        r = [],
        s = -1,
        a = null;
    if (n.forEach(c => {
            let d = c.get("offset"),
                h = d == s,
                y = h && a || new Map;
            c.forEach((O, B) => {
                let R = B,
                    N = O;
                if (B !== "offset") switch (R = i.normalizePropertyName(R, o), N) {
                    case fi:
                        N = e.get(B);
                        break;
                    case Xe:
                        N = t.get(B);
                        break;
                    default:
                        N = i.normalizeStyleValue(B, R, N, o);
                        break
                }
                y.set(R, N)
            }), h || r.push(y), a = y, s = d
        }), o.length) throw Fh(o);
    return r
}

function Fn(i, n, e, t) {
    switch (n) {
        case "start":
            i.onStart(() => t(e && cr(e, "start", i)));
            break;
        case "done":
            i.onDone(() => t(e && cr(e, "done", i)));
            break;
        case "destroy":
            i.onDestroy(() => t(e && cr(e, "destroy", i)));
            break
    }
}

function cr(i, n, e) {
    let t = e.totalTime,
        o = !!e.disabled,
        r = Bn(i.element, i.triggerName, i.fromState, i.toState, n || i.phaseName, t ? ? i.totalTime, o),
        s = i._data;
    return s != null && (r._data = s), r
}

function Bn(i, n, e, t, o = "", r = 0, s) {
    return {
        element: i,
        triggerName: n,
        fromState: e,
        toState: t,
        phaseName: o,
        totalTime: r,
        disabled: !!s
    }
}

function je(i, n, e) {
    let t = i.get(n);
    return t || i.set(n, t = e), t
}

function hr(i) {
    let n = i.indexOf(":"),
        e = i.substring(1, n),
        t = i.slice(n + 1);
    return [e, t]
}
var Bh = typeof document > "u" ? null : document.documentElement;

function Vn(i) {
    let n = i.parentNode || i.host || null;
    return n === Bh ? null : n
}

function Vh(i) {
    return i.substring(1, 6) == "ebkit"
}
var Ht = null,
    $d = !1;

function yp(i) {
    Ht || (Ht = zh() || {}, $d = Ht.style ? "WebkitAppearance" in Ht.style : !1);
    let n = !0;
    return Ht.style && !Vh(i) && (n = i in Ht.style, !n && $d && (n = "Webkit" + i.charAt(0).toUpperCase() + i.slice(1) in Ht.style)), n
}

function zh() {
    return typeof document < "u" ? document.body : null
}

function mr(i, n) {
    for (; n;) {
        if (n === i) return !0;
        n = Vn(n)
    }
    return !1
}

function fr(i, n, e) {
    if (e) return Array.from(i.querySelectorAll(n));
    let t = i.querySelector(n);
    return t ? [t] : []
}
var Uh = 1e3,
    gr = "{{",
    Gh = "}}",
    vr = "ng-enter",
    zn = "ng-leave",
    Ni = "ng-trigger",
    Li = ".ng-trigger",
    _r = "ng-animating",
    Un = ".ng-animating";

function mt(i) {
    if (typeof i == "number") return i;
    let n = i.match(/^(-?[\.\d]+)(m?s)/);
    return !n || n.length < 2 ? 0 : dr(parseFloat(n[1]), n[2])
}

function dr(i, n) {
    return n === "s" ? i * Uh : i
}

function ji(i, n, e) {
    return i.hasOwnProperty("duration") ? i : Wh(i, n, e)
}
var Hh = /^(-?[\.\d]+)(m?s)(?:\s+(-?[\.\d]+)(m?s))?(?:\s+([-a-z]+(?:\(.+?\))?))?$/i;

function Wh(i, n, e) {
    let t, o = 0,
        r = "";
    if (typeof i == "string") {
        let s = i.match(Hh);
        if (s === null) return n.push(Kd(i)), {
            duration: 0,
            delay: 0,
            easing: ""
        };
        t = dr(parseFloat(s[1]), s[2]);
        let a = s[3];
        a != null && (o = dr(parseFloat(a), s[4]));
        let c = s[5];
        c && (r = c)
    } else t = i;
    if (!e) {
        let s = !1,
            a = n.length;
        t < 0 && (n.push(Ah()), s = !0), o < 0 && (n.push(Oh()), s = !0), s && n.splice(a, 0, Kd(i))
    }
    return {
        duration: t,
        delay: o,
        easing: r
    }
}

function Cp(i) {
    return i.length ? i[0] instanceof Map ? i : i.map(n => new Map(Object.entries(n))) : []
}

function nt(i, n, e) {
    n.forEach((t, o) => {
        let r = Gn(o);
        e && !e.has(o) && e.set(o, i.style[r]), i.style[r] = t
    })
}

function Rt(i, n) {
    n.forEach((e, t) => {
        let o = Gn(t);
        i.style[o] = ""
    })
}

function gi(i) {
    return Array.isArray(i) ? i.length == 1 ? i[0] : qd(i) : i
}

function Sp(i, n, e) {
    let t = n.params || {},
        o = br(i);
    o.length && o.forEach(r => {
        t.hasOwnProperty(r) || e.push(Nh(r))
    })
}
var pr = new RegExp(`${gr}\\s*(.+?)\\s*${Gh}`, "g");

function br(i) {
    let n = [];
    if (typeof i == "string") {
        let e;
        for (; e = pr.exec(i);) n.push(e[1]);
        pr.lastIndex = 0
    }
    return n
}

function vi(i, n, e) {
    let t = `${i}`,
        o = t.replace(pr, (r, s) => {
            let a = n[s];
            return a == null && (e.push(Lh(s)), a = ""), a.toString()
        });
    return o == t ? i : o
}
var qh = /-+([a-z0-9])/g;

function Gn(i) {
    return i.replace(qh, (...n) => n[1].toUpperCase())
}

function Ip(i, n) {
    return i === 0 || n === 0
}

function wp(i, n, e) {
    if (e.size && n.length) {
        let t = n[0],
            o = [];
        if (e.forEach((r, s) => {
                t.has(s) || o.push(s), t.set(s, r)
            }), o.length)
            for (let r = 1; r < n.length; r++) {
                let s = n[r];
                o.forEach(a => s.set(a, Hn(i, a)))
            }
    }
    return n
}

function Fe(i, n, e) {
    switch (n.type) {
        case U.Trigger:
            return i.visitTrigger(n, e);
        case U.State:
            return i.visitState(n, e);
        case U.Transition:
            return i.visitTransition(n, e);
        case U.Sequence:
            return i.visitSequence(n, e);
        case U.Group:
            return i.visitGroup(n, e);
        case U.Animate:
            return i.visitAnimate(n, e);
        case U.Keyframes:
            return i.visitKeyframes(n, e);
        case U.Style:
            return i.visitStyle(n, e);
        case U.Reference:
            return i.visitReference(n, e);
        case U.AnimateChild:
            return i.visitAnimateChild(n, e);
        case U.AnimateRef:
            return i.visitAnimateRef(n, e);
        case U.Query:
            return i.visitQuery(n, e);
        case U.Stagger:
            return i.visitStagger(n, e);
        default:
            throw jh(n.type)
    }
}

function Hn(i, n) {
    return window.getComputedStyle(i)[n]
}
var Lr = (() => {
        class i {
            validateStyleProperty(e) {
                return yp(e)
            }
            containsElement(e, t) {
                return mr(e, t)
            }
            getParentElement(e) {
                return Vn(e)
            }
            query(e, t, o) {
                return fr(e, t, o)
            }
            computeStyle(e, t, o) {
                return o || ""
            }
            animate(e, t, o, r, s, a = [], c) {
                return new ht(o, r)
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
        return i
    })(),
    qt = class {
        static NOOP = new Lr
    },
    Kt = class {};
var Kh = new Set(["width", "height", "minWidth", "minHeight", "maxWidth", "maxHeight", "left", "top", "bottom", "right", "fontSize", "outlineWidth", "outlineOffset", "paddingTop", "paddingLeft", "paddingBottom", "paddingRight", "marginTop", "marginLeft", "marginBottom", "marginRight", "borderRadius", "borderWidth", "borderTopWidth", "borderLeftWidth", "borderRightWidth", "borderBottomWidth", "textIndent", "perspective"]),
    Qn = class extends Kt {
        normalizePropertyName(n, e) {
            return Gn(n)
        }
        normalizeStyleValue(n, e, t, o) {
            let r = "",
                s = t.toString().trim();
            if (Kh.has(e) && t !== 0 && t !== "0")
                if (typeof t == "number") r = "px";
                else {
                    let a = t.match(/^[+-]?[\d\.]+([a-z]*)$/);
                    a && a[1].length == 0 && o.push(Qd(n, t))
                }
            return s + r
        }
    };
var Zn = "*";

function $h(i, n) {
    let e = [];
    return typeof i == "string" ? i.split(/\s*,\s*/).forEach(t => Qh(t, e, n)) : e.push(i), e
}

function Qh(i, n, e) {
    if (i[0] == ":") {
        let c = Zh(i, e);
        if (typeof c == "function") {
            n.push(c);
            return
        }
        i = c
    }
    let t = i.match(/^(\*|[-\w]+)\s*(<?[=-]>)\s*(\*|[-\w]+)$/);
    if (t == null || t.length < 4) return e.push(ap(i)), n;
    let o = t[1],
        r = t[2],
        s = t[3];
    n.push(Ep(o, s));
    let a = o == Zn && s == Zn;
    r[0] == "<" && !a && n.push(Ep(s, o))
}

function Zh(i, n) {
    switch (i) {
        case ":enter":
            return "void => *";
        case ":leave":
            return "* => void";
        case ":increment":
            return (e, t) => parseFloat(t) > parseFloat(e);
        case ":decrement":
            return (e, t) => parseFloat(t) < parseFloat(e);
        default:
            return n.push(lp(i)), "* => *"
    }
}
var Wn = new Set(["true", "1"]),
    qn = new Set(["false", "0"]);

function Ep(i, n) {
    let e = Wn.has(i) || qn.has(i),
        t = Wn.has(n) || qn.has(n);
    return (o, r) => {
        let s = i == Zn || i == o,
            a = n == Zn || n == r;
        return !s && e && typeof o == "boolean" && (s = o ? Wn.has(i) : qn.has(i)), !a && t && typeof r == "boolean" && (a = r ? Wn.has(n) : qn.has(n)), s && a
    }
}
var Np = ":self",
    Yh = new RegExp(`s*${Np}s*,?`, "g");

function Lp(i, n, e, t) {
    return new Er(i).build(n, e, t)
}
var Dp = "",
    Er = class {
        _driver;
        constructor(n) {
            this._driver = n
        }
        build(n, e, t) {
            let o = new Dr(e);
            return this._resetContextStyleTimingState(o), Fe(this, gi(n), o)
        }
        _resetContextStyleTimingState(n) {
            n.currentQuerySelector = Dp, n.collectedStyles = new Map, n.collectedStyles.set(Dp, new Map), n.currentTime = 0
        }
        visitTrigger(n, e) {
            let t = e.queryCount = 0,
                o = e.depCount = 0,
                r = [],
                s = [];
            return n.name.charAt(0) == "@" && e.errors.push(Zd()), n.definitions.forEach(a => {
                if (this._resetContextStyleTimingState(e), a.type == U.State) {
                    let c = a,
                        d = c.name;
                    d.toString().split(/\s*,\s*/).forEach(h => {
                        c.name = h, r.push(this.visitState(c, e))
                    }), c.name = d
                } else if (a.type == U.Transition) {
                    let c = this.visitTransition(a, e);
                    t += c.queryCount, o += c.depCount, s.push(c)
                } else e.errors.push(Yd())
            }), {
                type: U.Trigger,
                name: n.name,
                states: r,
                transitions: s,
                queryCount: t,
                depCount: o,
                options: null
            }
        }
        visitState(n, e) {
            let t = this.visitStyle(n.styles, e),
                o = n.options && n.options.params || null;
            if (t.containsDynamicStyles) {
                let r = new Set,
                    s = o || {};
                t.styles.forEach(a => {
                    a instanceof Map && a.forEach(c => {
                        br(c).forEach(d => {
                            s.hasOwnProperty(d) || r.add(d)
                        })
                    })
                }), r.size && e.errors.push(Xd(n.name, [...r.values()]))
            }
            return {
                type: U.State,
                name: n.name,
                style: t,
                options: o ? {
                    params: o
                } : null
            }
        }
        visitTransition(n, e) {
            e.queryCount = 0, e.depCount = 0;
            let t = Fe(this, gi(n.animation), e),
                o = $h(n.expr, e.errors);
            return {
                type: U.Transition,
                matchers: o,
                animation: t,
                queryCount: e.queryCount,
                depCount: e.depCount,
                options: Wt(n.options)
            }
        }
        visitSequence(n, e) {
            return {
                type: U.Sequence,
                steps: n.steps.map(t => Fe(this, t, e)),
                options: Wt(n.options)
            }
        }
        visitGroup(n, e) {
            let t = e.currentTime,
                o = 0,
                r = n.steps.map(s => {
                    e.currentTime = t;
                    let a = Fe(this, s, e);
                    return o = Math.max(o, e.currentTime), a
                });
            return e.currentTime = o, {
                type: U.Group,
                steps: r,
                options: Wt(n.options)
            }
        }
        visitAnimate(n, e) {
            let t = tm(n.timings, e.errors);
            e.currentAnimateTimings = t;
            let o, r = n.styles ? n.styles : ke({});
            if (r.type == U.Keyframes) o = this.visitKeyframes(r, e);
            else {
                let s = n.styles,
                    a = !1;
                if (!s) {
                    a = !0;
                    let d = {};
                    t.easing && (d.easing = t.easing), s = ke(d)
                }
                e.currentTime += t.duration + t.delay;
                let c = this.visitStyle(s, e);
                c.isEmptyStep = a, o = c
            }
            return e.currentAnimateTimings = null, {
                type: U.Animate,
                timings: t,
                style: o,
                options: null
            }
        }
        visitStyle(n, e) {
            let t = this._makeStyleAst(n, e);
            return this._validateStyleAst(t, e), t
        }
        _makeStyleAst(n, e) {
            let t = [],
                o = Array.isArray(n.styles) ? n.styles : [n.styles];
            for (let a of o) typeof a == "string" ? a === Xe ? t.push(a) : e.errors.push(Jd(a)) : t.push(new Map(Object.entries(a)));
            let r = !1,
                s = null;
            return t.forEach(a => {
                if (a instanceof Map && (a.has("easing") && (s = a.get("easing"), a.delete("easing")), !r)) {
                    for (let c of a.values())
                        if (c.toString().indexOf(gr) >= 0) {
                            r = !0;
                            break
                        }
                }
            }), {
                type: U.Style,
                styles: t,
                easing: s,
                offset: n.offset,
                containsDynamicStyles: r,
                options: null
            }
        }
        _validateStyleAst(n, e) {
            let t = e.currentAnimateTimings,
                o = e.currentTime,
                r = e.currentTime;
            t && r > 0 && (r -= t.duration + t.delay), n.styles.forEach(s => {
                typeof s != "string" && s.forEach((a, c) => {
                    let d = e.collectedStyles.get(e.currentQuerySelector),
                        h = d.get(c),
                        y = !0;
                    h && (r != o && r >= h.startTime && o <= h.endTime && (e.errors.push(ep(c, h.startTime, h.endTime, r, o)), y = !1), r = h.startTime), y && d.set(c, {
                        startTime: r,
                        endTime: o
                    }), e.options && Sp(a, e.options, e.errors)
                })
            })
        }
        visitKeyframes(n, e) {
            let t = {
                type: U.Keyframes,
                styles: [],
                options: null
            };
            if (!e.currentAnimateTimings) return e.errors.push(tp()), t;
            let o = 1,
                r = 0,
                s = [],
                a = !1,
                c = !1,
                d = 0,
                h = n.steps.map(ie => {
                    let ce = this._makeStyleAst(ie, e),
                        he = ce.offset != null ? ce.offset : em(ce.styles),
                        ae = 0;
                    return he != null && (r++, ae = ce.offset = he), c = c || ae < 0 || ae > 1, a = a || ae < d, d = ae, s.push(ae), ce
                });
            c && e.errors.push(ip()), a && e.errors.push(np());
            let y = n.steps.length,
                O = 0;
            r > 0 && r < y ? e.errors.push(op()) : r == 0 && (O = o / (y - 1));
            let B = y - 1,
                R = e.currentTime,
                N = e.currentAnimateTimings,
                H = N.duration;
            return h.forEach((ie, ce) => {
                let he = O > 0 ? ce == B ? 1 : O * ce : s[ce],
                    ae = he * H;
                e.currentTime = R + N.delay + ae, N.duration = ae, this._validateStyleAst(ie, e), ie.offset = he, t.styles.push(ie)
            }), t
        }
        visitReference(n, e) {
            return {
                type: U.Reference,
                animation: Fe(this, gi(n.animation), e),
                options: Wt(n.options)
            }
        }
        visitAnimateChild(n, e) {
            return e.depCount++, {
                type: U.AnimateChild,
                options: Wt(n.options)
            }
        }
        visitAnimateRef(n, e) {
            return {
                type: U.AnimateRef,
                animation: this.visitReference(n.animation, e),
                options: Wt(n.options)
            }
        }
        visitQuery(n, e) {
            let t = e.currentQuerySelector,
                o = n.options || {};
            e.queryCount++, e.currentQuery = n;
            let [r, s] = Xh(n.selector);
            e.currentQuerySelector = t.length ? t + " " + r : r, je(e.collectedStyles, e.currentQuerySelector, new Map);
            let a = Fe(this, gi(n.animation), e);
            return e.currentQuery = null, e.currentQuerySelector = t, {
                type: U.Query,
                selector: r,
                limit: o.limit || 0,
                optional: !!o.optional,
                includeSelf: s,
                animation: a,
                originalSelector: n.selector,
                options: Wt(n.options)
            }
        }
        visitStagger(n, e) {
            e.currentQuery || e.errors.push(rp());
            let t = n.timings === "full" ? {
                duration: 0,
                delay: 0,
                easing: "full"
            } : ji(n.timings, e.errors, !0);
            return {
                type: U.Stagger,
                animation: Fe(this, gi(n.animation), e),
                timings: t,
                options: null
            }
        }
    };

function Xh(i) {
    let n = !!i.split(/\s*,\s*/).find(e => e == Np);
    return n && (i = i.replace(Yh, "")), i = i.replace(/@\*/g, Li).replace(/@\w+/g, e => Li + "-" + e.slice(1)).replace(/:animating/g, Un), [i, n]
}

function Jh(i) {
    return i ? oe({}, i) : null
}
var Dr = class {
    errors;
    queryCount = 0;
    depCount = 0;
    currentTransition = null;
    currentQuery = null;
    currentQuerySelector = null;
    currentAnimateTimings = null;
    currentTime = 0;
    collectedStyles = new Map;
    options = null;
    unsupportedCSSPropertiesFound = new Set;
    constructor(n) {
        this.errors = n
    }
};

function em(i) {
    if (typeof i == "string") return null;
    let n = null;
    if (Array.isArray(i)) i.forEach(e => {
        if (e instanceof Map && e.has("offset")) {
            let t = e;
            n = parseFloat(t.get("offset")), t.delete("offset")
        }
    });
    else if (i instanceof Map && i.has("offset")) {
        let e = i;
        n = parseFloat(e.get("offset")), e.delete("offset")
    }
    return n
}

function tm(i, n) {
    if (i.hasOwnProperty("duration")) return i;
    if (typeof i == "number") {
        let r = ji(i, n).duration;
        return yr(r, 0, "")
    }
    let e = i;
    if (e.split(/\s+/).some(r => r.charAt(0) == "{" && r.charAt(1) == "{")) {
        let r = yr(0, 0, "");
        return r.dynamic = !0, r.strValue = e, r
    }
    let o = ji(e, n);
    return yr(o.duration, o.delay, o.easing)
}

function Wt(i) {
    return i ? (i = oe({}, i), i.params && (i.params = Jh(i.params))) : i = {}, i
}

function yr(i, n, e) {
    return {
        duration: i,
        delay: n,
        easing: e
    }
}

function jr(i, n, e, t, o, r, s = null, a = !1) {
    return {
        type: 1,
        element: i,
        keyframes: n,
        preStyleProps: e,
        postStyleProps: t,
        duration: o,
        delay: r,
        totalTime: o + r,
        easing: s,
        subTimeline: a
    }
}
var Bi = class {
        _map = new Map;
        get(n) {
            return this._map.get(n) || []
        }
        append(n, e) {
            let t = this._map.get(n);
            t || this._map.set(n, t = []), t.push(...e)
        }
        has(n) {
            return this._map.has(n)
        }
        clear() {
            this._map.clear()
        }
    },
    im = 1,
    nm = ":enter",
    om = new RegExp(nm, "g"),
    rm = ":leave",
    sm = new RegExp(rm, "g");

function jp(i, n, e, t, o, r = new Map, s = new Map, a, c, d = []) {
    return new Tr().buildKeyframes(i, n, e, t, o, r, s, a, c, d)
}
var Tr = class {
        buildKeyframes(n, e, t, o, r, s, a, c, d, h = []) {
            d = d || new Bi;
            let y = new xr(n, e, d, o, r, h, []);
            y.options = c;
            let O = c.delay ? mt(c.delay) : 0;
            y.currentTimeline.delayNextStep(O), y.currentTimeline.setStyles([s], null, y.errors, c), Fe(this, t, y);
            let B = y.timelines.filter(R => R.containsAnimation());
            if (B.length && a.size) {
                let R;
                for (let N = B.length - 1; N >= 0; N--) {
                    let H = B[N];
                    if (H.element === e) {
                        R = H;
                        break
                    }
                }
                R && !R.allowOnlyTimelineStyles() && R.setStyles([a], null, y.errors, c)
            }
            return B.length ? B.map(R => R.buildKeyframes()) : [jr(e, [], [], [], 0, O, "", !1)]
        }
        visitTrigger(n, e) {}
        visitState(n, e) {}
        visitTransition(n, e) {}
        visitAnimateChild(n, e) {
            let t = e.subInstructions.get(e.element);
            if (t) {
                let o = e.createSubContext(n.options),
                    r = e.currentTimeline.currentTime,
                    s = this._visitSubInstructions(t, o, o.options);
                r != s && e.transformIntoNewTimeline(s)
            }
            e.previousNode = n
        }
        visitAnimateRef(n, e) {
            let t = e.createSubContext(n.options);
            t.transformIntoNewTimeline(), this._applyAnimationRefDelays([n.options, n.animation.options], e, t), this.visitReference(n.animation, t), e.transformIntoNewTimeline(t.currentTimeline.currentTime), e.previousNode = n
        }
        _applyAnimationRefDelays(n, e, t) {
            for (let o of n) {
                let r = o ? .delay;
                if (r) {
                    let s = typeof r == "number" ? r : mt(vi(r, o ? .params ? ? {}, e.errors));
                    t.delayNextStep(s)
                }
            }
        }
        _visitSubInstructions(n, e, t) {
            let r = e.currentTimeline.currentTime,
                s = t.duration != null ? mt(t.duration) : null,
                a = t.delay != null ? mt(t.delay) : null;
            return s !== 0 && n.forEach(c => {
                let d = e.appendInstructionToTimeline(c, s, a);
                r = Math.max(r, d.duration + d.delay)
            }), r
        }
        visitReference(n, e) {
            e.updateOptions(n.options, !0), Fe(this, n.animation, e), e.previousNode = n
        }
        visitSequence(n, e) {
            let t = e.subContextCount,
                o = e,
                r = n.options;
            if (r && (r.params || r.delay) && (o = e.createSubContext(r), o.transformIntoNewTimeline(), r.delay != null)) {
                o.previousNode.type == U.Style && (o.currentTimeline.snapshotCurrentStyles(), o.previousNode = Yn);
                let s = mt(r.delay);
                o.delayNextStep(s)
            }
            n.steps.length && (n.steps.forEach(s => Fe(this, s, o)), o.currentTimeline.applyStylesToKeyframe(), o.subContextCount > t && o.transformIntoNewTimeline()), e.previousNode = n
        }
        visitGroup(n, e) {
            let t = [],
                o = e.currentTimeline.currentTime,
                r = n.options && n.options.delay ? mt(n.options.delay) : 0;
            n.steps.forEach(s => {
                let a = e.createSubContext(n.options);
                r && a.delayNextStep(r), Fe(this, s, a), o = Math.max(o, a.currentTimeline.currentTime), t.push(a.currentTimeline)
            }), t.forEach(s => e.currentTimeline.mergeTimelineCollectedStyles(s)), e.transformIntoNewTimeline(o), e.previousNode = n
        }
        _visitTiming(n, e) {
            if (n.dynamic) {
                let t = n.strValue,
                    o = e.params ? vi(t, e.params, e.errors) : t;
                return ji(o, e.errors)
            } else return {
                duration: n.duration,
                delay: n.delay,
                easing: n.easing
            }
        }
        visitAnimate(n, e) {
            let t = e.currentAnimateTimings = this._visitTiming(n.timings, e),
                o = e.currentTimeline;
            t.delay && (e.incrementTime(t.delay), o.snapshotCurrentStyles());
            let r = n.style;
            r.type == U.Keyframes ? this.visitKeyframes(r, e) : (e.incrementTime(t.duration), this.visitStyle(r, e), o.applyStylesToKeyframe()), e.currentAnimateTimings = null, e.previousNode = n
        }
        visitStyle(n, e) {
            let t = e.currentTimeline,
                o = e.currentAnimateTimings;
            !o && t.hasCurrentStyleProperties() && t.forwardFrame();
            let r = o && o.easing || n.easing;
            n.isEmptyStep ? t.applyEmptyStep(r) : t.setStyles(n.styles, r, e.errors, e.options), e.previousNode = n
        }
        visitKeyframes(n, e) {
            let t = e.currentAnimateTimings,
                o = e.currentTimeline.duration,
                r = t.duration,
                a = e.createSubContext().currentTimeline;
            a.easing = t.easing, n.styles.forEach(c => {
                let d = c.offset || 0;
                a.forwardTime(d * r), a.setStyles(c.styles, c.easing, e.errors, e.options), a.applyStylesToKeyframe()
            }), e.currentTimeline.mergeTimelineCollectedStyles(a), e.transformIntoNewTimeline(o + r), e.previousNode = n
        }
        visitQuery(n, e) {
            let t = e.currentTimeline.currentTime,
                o = n.options || {},
                r = o.delay ? mt(o.delay) : 0;
            r && (e.previousNode.type === U.Style || t == 0 && e.currentTimeline.hasCurrentStyleProperties()) && (e.currentTimeline.snapshotCurrentStyles(), e.previousNode = Yn);
            let s = t,
                a = e.invokeQuery(n.selector, n.originalSelector, n.limit, n.includeSelf, !!o.optional, e.errors);
            e.currentQueryTotal = a.length;
            let c = null;
            a.forEach((d, h) => {
                e.currentQueryIndex = h;
                let y = e.createSubContext(n.options, d);
                r && y.delayNextStep(r), d === e.element && (c = y.currentTimeline), Fe(this, n.animation, y), y.currentTimeline.applyStylesToKeyframe();
                let O = y.currentTimeline.currentTime;
                s = Math.max(s, O)
            }), e.currentQueryIndex = 0, e.currentQueryTotal = 0, e.transformIntoNewTimeline(s), c && (e.currentTimeline.mergeTimelineCollectedStyles(c), e.currentTimeline.snapshotCurrentStyles()), e.previousNode = n
        }
        visitStagger(n, e) {
            let t = e.parentContext,
                o = e.currentTimeline,
                r = n.timings,
                s = Math.abs(r.duration),
                a = s * (e.currentQueryTotal - 1),
                c = s * e.currentQueryIndex;
            switch (r.duration < 0 ? "reverse" : r.easing) {
                case "reverse":
                    c = a - c;
                    break;
                case "full":
                    c = t.currentStaggerTime;
                    break
            }
            let h = e.currentTimeline;
            c && h.delayNextStep(c);
            let y = h.currentTime;
            Fe(this, n.animation, e), e.previousNode = n, t.currentStaggerTime = o.currentTime - y + (o.startTime - t.currentTimeline.startTime)
        }
    },
    Yn = {},
    xr = class i {
        _driver;
        element;
        subInstructions;
        _enterClassName;
        _leaveClassName;
        errors;
        timelines;
        parentContext = null;
        currentTimeline;
        currentAnimateTimings = null;
        previousNode = Yn;
        subContextCount = 0;
        options = {};
        currentQueryIndex = 0;
        currentQueryTotal = 0;
        currentStaggerTime = 0;
        constructor(n, e, t, o, r, s, a, c) {
            this._driver = n, this.element = e, this.subInstructions = t, this._enterClassName = o, this._leaveClassName = r, this.errors = s, this.timelines = a, this.currentTimeline = c || new Xn(this._driver, e, 0), a.push(this.currentTimeline)
        }
        get params() {
            return this.options.params
        }
        updateOptions(n, e) {
            if (!n) return;
            let t = n,
                o = this.options;
            t.duration != null && (o.duration = mt(t.duration)), t.delay != null && (o.delay = mt(t.delay));
            let r = t.params;
            if (r) {
                let s = o.params;
                s || (s = this.options.params = {}), Object.keys(r).forEach(a => {
                    (!e || !s.hasOwnProperty(a)) && (s[a] = vi(r[a], s, this.errors))
                })
            }
        }
        _copyOptions() {
            let n = {};
            if (this.options) {
                let e = this.options.params;
                if (e) {
                    let t = n.params = {};
                    Object.keys(e).forEach(o => {
                        t[o] = e[o]
                    })
                }
            }
            return n
        }
        createSubContext(n = null, e, t) {
            let o = e || this.element,
                r = new i(this._driver, o, this.subInstructions, this._enterClassName, this._leaveClassName, this.errors, this.timelines, this.currentTimeline.fork(o, t || 0));
            return r.previousNode = this.previousNode, r.currentAnimateTimings = this.currentAnimateTimings, r.options = this._copyOptions(), r.updateOptions(n), r.currentQueryIndex = this.currentQueryIndex, r.currentQueryTotal = this.currentQueryTotal, r.parentContext = this, this.subContextCount++, r
        }
        transformIntoNewTimeline(n) {
            return this.previousNode = Yn, this.currentTimeline = this.currentTimeline.fork(this.element, n), this.timelines.push(this.currentTimeline), this.currentTimeline
        }
        appendInstructionToTimeline(n, e, t) {
            let o = {
                    duration: e ? ? n.duration,
                    delay: this.currentTimeline.currentTime + (t ? ? 0) + n.delay,
                    easing: ""
                },
                r = new Pr(this._driver, n.element, n.keyframes, n.preStyleProps, n.postStyleProps, o, n.stretchStartingKeyframe);
            return this.timelines.push(r), o
        }
        incrementTime(n) {
            this.currentTimeline.forwardTime(this.currentTimeline.duration + n)
        }
        delayNextStep(n) {
            n > 0 && this.currentTimeline.delayNextStep(n)
        }
        invokeQuery(n, e, t, o, r, s) {
            let a = [];
            if (o && a.push(this.element), n.length > 0) {
                n = n.replace(om, "." + this._enterClassName), n = n.replace(sm, "." + this._leaveClassName);
                let c = t != 1,
                    d = this._driver.query(this.element, n, c);
                t !== 0 && (d = t < 0 ? d.slice(d.length + t, d.length) : d.slice(0, t)), a.push(...d)
            }
            return !r && a.length == 0 && s.push(sp(e)), a
        }
    },
    Xn = class i {
        _driver;
        element;
        startTime;
        _elementTimelineStylesLookup;
        duration = 0;
        easing = null;
        _previousKeyframe = new Map;
        _currentKeyframe = new Map;
        _keyframes = new Map;
        _styleSummary = new Map;
        _localTimelineStyles = new Map;
        _globalTimelineStyles;
        _pendingStyles = new Map;
        _backFill = new Map;
        _currentEmptyStepKeyframe = null;
        constructor(n, e, t, o) {
            this._driver = n, this.element = e, this.startTime = t, this._elementTimelineStylesLookup = o, this._elementTimelineStylesLookup || (this._elementTimelineStylesLookup = new Map), this._globalTimelineStyles = this._elementTimelineStylesLookup.get(e), this._globalTimelineStyles || (this._globalTimelineStyles = this._localTimelineStyles, this._elementTimelineStylesLookup.set(e, this._localTimelineStyles)), this._loadKeyframe()
        }
        containsAnimation() {
            switch (this._keyframes.size) {
                case 0:
                    return !1;
                case 1:
                    return this.hasCurrentStyleProperties();
                default:
                    return !0
            }
        }
        hasCurrentStyleProperties() {
            return this._currentKeyframe.size > 0
        }
        get currentTime() {
            return this.startTime + this.duration
        }
        delayNextStep(n) {
            let e = this._keyframes.size === 1 && this._pendingStyles.size;
            this.duration || e ? (this.forwardTime(this.currentTime + n), e && this.snapshotCurrentStyles()) : this.startTime += n
        }
        fork(n, e) {
            return this.applyStylesToKeyframe(), new i(this._driver, n, e || this.currentTime, this._elementTimelineStylesLookup)
        }
        _loadKeyframe() {
            this._currentKeyframe && (this._previousKeyframe = this._currentKeyframe), this._currentKeyframe = this._keyframes.get(this.duration), this._currentKeyframe || (this._currentKeyframe = new Map, this._keyframes.set(this.duration, this._currentKeyframe))
        }
        forwardFrame() {
            this.duration += im, this._loadKeyframe()
        }
        forwardTime(n) {
            this.applyStylesToKeyframe(), this.duration = n, this._loadKeyframe()
        }
        _updateStyle(n, e) {
            this._localTimelineStyles.set(n, e), this._globalTimelineStyles.set(n, e), this._styleSummary.set(n, {
                time: this.currentTime,
                value: e
            })
        }
        allowOnlyTimelineStyles() {
            return this._currentEmptyStepKeyframe !== this._currentKeyframe
        }
        applyEmptyStep(n) {
            n && this._previousKeyframe.set("easing", n);
            for (let [e, t] of this._globalTimelineStyles) this._backFill.set(e, t || Xe), this._currentKeyframe.set(e, Xe);
            this._currentEmptyStepKeyframe = this._currentKeyframe
        }
        setStyles(n, e, t, o) {
            e && this._previousKeyframe.set("easing", e);
            let r = o && o.params || {},
                s = am(n, this._globalTimelineStyles);
            for (let [a, c] of s) {
                let d = vi(c, r, t);
                this._pendingStyles.set(a, d), this._localTimelineStyles.has(a) || this._backFill.set(a, this._globalTimelineStyles.get(a) ? ? Xe), this._updateStyle(a, d)
            }
        }
        applyStylesToKeyframe() {
            this._pendingStyles.size != 0 && (this._pendingStyles.forEach((n, e) => {
                this._currentKeyframe.set(e, n)
            }), this._pendingStyles.clear(), this._localTimelineStyles.forEach((n, e) => {
                this._currentKeyframe.has(e) || this._currentKeyframe.set(e, n)
            }))
        }
        snapshotCurrentStyles() {
            for (let [n, e] of this._localTimelineStyles) this._pendingStyles.set(n, e), this._updateStyle(n, e)
        }
        getFinalKeyframe() {
            return this._keyframes.get(this.duration)
        }
        get properties() {
            let n = [];
            for (let e in this._currentKeyframe) n.push(e);
            return n
        }
        mergeTimelineCollectedStyles(n) {
            n._styleSummary.forEach((e, t) => {
                let o = this._styleSummary.get(t);
                (!o || e.time > o.time) && this._updateStyle(t, e.value)
            })
        }
        buildKeyframes() {
            this.applyStylesToKeyframe();
            let n = new Set,
                e = new Set,
                t = this._keyframes.size === 1 && this.duration === 0,
                o = [];
            this._keyframes.forEach((a, c) => {
                let d = new Map([...this._backFill, ...a]);
                d.forEach((h, y) => {
                    h === fi ? n.add(y) : h === Xe && e.add(y)
                }), t || d.set("offset", c / this.duration), o.push(d)
            });
            let r = [...n.values()],
                s = [...e.values()];
            if (t) {
                let a = o[0],
                    c = new Map(a);
                a.set("offset", 0), c.set("offset", 1), o = [a, c]
            }
            return jr(this.element, o, r, s, this.duration, this.startTime, this.easing, !1)
        }
    },
    Pr = class extends Xn {
        keyframes;
        preStyleProps;
        postStyleProps;
        _stretchStartingKeyframe;
        timings;
        constructor(n, e, t, o, r, s, a = !1) {
            super(n, e, s.delay), this.keyframes = t, this.preStyleProps = o, this.postStyleProps = r, this._stretchStartingKeyframe = a, this.timings = {
                duration: s.duration,
                delay: s.delay,
                easing: s.easing
            }
        }
        containsAnimation() {
            return this.keyframes.length > 1
        }
        buildKeyframes() {
            let n = this.keyframes,
                {
                    delay: e,
                    duration: t,
                    easing: o
                } = this.timings;
            if (this._stretchStartingKeyframe && e) {
                let r = [],
                    s = t + e,
                    a = e / s,
                    c = new Map(n[0]);
                c.set("offset", 0), r.push(c);
                let d = new Map(n[0]);
                d.set("offset", Tp(a)), r.push(d);
                let h = n.length - 1;
                for (let y = 1; y <= h; y++) {
                    let O = new Map(n[y]),
                        B = O.get("offset"),
                        R = e + B * t;
                    O.set("offset", Tp(R / s)), r.push(O)
                }
                t = s, e = 0, o = "", n = r
            }
            return jr(this.element, n, this.preStyleProps, this.postStyleProps, t, e, o, !0)
        }
    };

function Tp(i, n = 3) {
    let e = Math.pow(10, n - 1);
    return Math.round(i * e) / e
}

function am(i, n) {
    let e = new Map,
        t;
    return i.forEach(o => {
        if (o === "*") {
            t ? ? = n.keys();
            for (let r of t) e.set(r, Xe)
        } else
            for (let [r, s] of o) e.set(r, s)
    }), e
}

function xp(i, n, e, t, o, r, s, a, c, d, h, y, O) {
    return {
        type: 0,
        element: i,
        triggerName: n,
        isRemovalTransition: o,
        fromState: e,
        fromStyles: r,
        toState: t,
        toStyles: s,
        timelines: a,
        queriedElements: c,
        preStyleProps: d,
        postStyleProps: h,
        totalTime: y,
        errors: O
    }
}
var Cr = {},
    Jn = class {
        _triggerName;
        ast;
        _stateStyles;
        constructor(n, e, t) {
            this._triggerName = n, this.ast = e, this._stateStyles = t
        }
        match(n, e, t, o) {
            return lm(this.ast.matchers, n, e, t, o)
        }
        buildStyles(n, e, t) {
            let o = this._stateStyles.get("*");
            return n !== void 0 && (o = this._stateStyles.get(n ? .toString()) || o), o ? o.buildStyles(e, t) : new Map
        }
        build(n, e, t, o, r, s, a, c, d, h) {
            let y = [],
                O = this.ast.options && this.ast.options.params || Cr,
                B = a && a.params || Cr,
                R = this.buildStyles(t, B, y),
                N = c && c.params || Cr,
                H = this.buildStyles(o, N, y),
                ie = new Set,
                ce = new Map,
                he = new Map,
                ae = o === "void",
                qe = {
                    params: Fp(N, O),
                    delay: this.ast.options ? .delay
                },
                Be = h ? [] : jp(n, e, this.ast.animation, r, s, R, H, qe, d, y),
                ye = 0;
            return Be.forEach(Re => {
                ye = Math.max(Re.duration + Re.delay, ye)
            }), y.length ? xp(e, this._triggerName, t, o, ae, R, H, [], [], ce, he, ye, y) : (Be.forEach(Re => {
                let At = Re.element,
                    Xt = je(ce, At, new Set);
                Re.preStyleProps.forEach(Ot => Xt.add(Ot));
                let tl = je(he, At, new Set);
                Re.postStyleProps.forEach(Ot => tl.add(Ot)), At !== e && ie.add(At)
            }), xp(e, this._triggerName, t, o, ae, R, H, Be, [...ie.values()], ce, he, ye))
        }
    };

function lm(i, n, e, t, o) {
    return i.some(r => r(n, e, t, o))
}

function Fp(i, n) {
    let e = oe({}, n);
    return Object.entries(i).forEach(([t, o]) => {
        o != null && (e[t] = o)
    }), e
}
var kr = class {
    styles;
    defaultParams;
    normalizer;
    constructor(n, e, t) {
        this.styles = n, this.defaultParams = e, this.normalizer = t
    }
    buildStyles(n, e) {
        let t = new Map,
            o = Fp(n, this.defaultParams);
        return this.styles.styles.forEach(r => {
            typeof r != "string" && r.forEach((s, a) => {
                s && (s = vi(s, o, e));
                let c = this.normalizer.normalizePropertyName(a, e);
                s = this.normalizer.normalizeStyleValue(a, c, s, e), t.set(a, s)
            })
        }), t
    }
};

function cm(i, n, e) {
    return new Mr(i, n, e)
}
var Mr = class {
    name;
    ast;
    _normalizer;
    transitionFactories = [];
    fallbackTransition;
    states = new Map;
    constructor(n, e, t) {
        this.name = n, this.ast = e, this._normalizer = t, e.states.forEach(o => {
            let r = o.options && o.options.params || {};
            this.states.set(o.name, new kr(o.style, r, t))
        }), Pp(this.states, "true", "1"), Pp(this.states, "false", "0"), e.transitions.forEach(o => {
            this.transitionFactories.push(new Jn(n, o, this.states))
        }), this.fallbackTransition = dm(n, this.states)
    }
    get containsQueries() {
        return this.ast.queryCount > 0
    }
    matchTransition(n, e, t, o) {
        return this.transitionFactories.find(s => s.match(n, e, t, o)) || null
    }
    matchStyles(n, e, t) {
        return this.fallbackTransition.buildStyles(n, e, t)
    }
};

function dm(i, n, e) {
    let t = [(s, a) => !0],
        o = {
            type: U.Sequence,
            steps: [],
            options: null
        },
        r = {
            type: U.Transition,
            animation: o,
            matchers: t,
            options: null,
            queryCount: 0,
            depCount: 0
        };
    return new Jn(i, r, n)
}

function Pp(i, n, e) {
    i.has(n) ? i.has(e) || i.set(e, i.get(n)) : i.has(e) && i.set(n, i.get(e))
}
var pm = new Bi,
    Rr = class {
        bodyNode;
        _driver;
        _normalizer;
        _animations = new Map;
        _playersById = new Map;
        players = [];
        constructor(n, e, t) {
            this.bodyNode = n, this._driver = e, this._normalizer = t
        }
        register(n, e) {
            let t = [],
                o = [],
                r = Lp(this._driver, e, t, o);
            if (t.length) throw dp(t);
            this._animations.set(n, r)
        }
        _buildPlayer(n, e, t) {
            let o = n.element,
                r = ur(this._normalizer, n.keyframes, e, t);
            return this._driver.animate(o, r, n.duration, n.delay, n.easing, [], !0)
        }
        create(n, e, t = {}) {
            let o = [],
                r = this._animations.get(n),
                s, a = new Map;
            if (r ? (s = jp(this._driver, e, r, vr, zn, new Map, new Map, t, pm, o), s.forEach(h => {
                    let y = je(a, h.element, new Map);
                    h.postStyleProps.forEach(O => y.set(O, null))
                })) : (o.push(pp()), s = []), o.length) throw up(o);
            a.forEach((h, y) => {
                h.forEach((O, B) => {
                    h.set(B, this._driver.computeStyle(y, B, Xe))
                })
            });
            let c = s.map(h => {
                    let y = a.get(h.element);
                    return this._buildPlayer(h, new Map, y)
                }),
                d = yt(c);
            return this._playersById.set(n, d), d.onDestroy(() => this.destroy(n)), this.players.push(d), d
        }
        destroy(n) {
            let e = this._getPlayer(n);
            e.destroy(), this._playersById.delete(n);
            let t = this.players.indexOf(e);
            t >= 0 && this.players.splice(t, 1)
        }
        _getPlayer(n) {
            let e = this._playersById.get(n);
            if (!e) throw hp(n);
            return e
        }
        listen(n, e, t, o) {
            let r = Bn(e, "", "", "");
            return Fn(this._getPlayer(n), t, r, o), () => {}
        }
        command(n, e, t, o) {
            if (t == "register") {
                this.register(n, o[0]);
                return
            }
            if (t == "create") {
                let s = o[0] || {};
                this.create(n, e, s);
                return
            }
            let r = this._getPlayer(n);
            switch (t) {
                case "play":
                    r.play();
                    break;
                case "pause":
                    r.pause();
                    break;
                case "reset":
                    r.reset();
                    break;
                case "restart":
                    r.restart();
                    break;
                case "finish":
                    r.finish();
                    break;
                case "init":
                    r.init();
                    break;
                case "setPosition":
                    r.setPosition(parseFloat(o[0]));
                    break;
                case "destroy":
                    this.destroy(n);
                    break
            }
        }
    },
    kp = "ng-animate-queued",
    um = ".ng-animate-queued",
    Sr = "ng-animate-disabled",
    hm = ".ng-animate-disabled",
    mm = "ng-star-inserted",
    fm = ".ng-star-inserted",
    gm = [],
    Bp = {
        namespaceId: "",
        setForRemoval: !1,
        setForMove: !1,
        hasAnimation: !1,
        removedBeforeQueried: !1
    },
    vm = {
        namespaceId: "",
        setForMove: !1,
        setForRemoval: !1,
        hasAnimation: !1,
        removedBeforeQueried: !0
    },
    ot = "__ng_removed",
    Vi = class {
        namespaceId;
        value;
        options;
        get params() {
            return this.options.params
        }
        constructor(n, e = "") {
            this.namespaceId = e;
            let t = n && n.hasOwnProperty("value"),
                o = t ? n.value : n;
            if (this.value = bm(o), t) {
                let r = n,
                    {
                        value: s
                    } = r,
                    a = Lt(r, ["value"]);
                this.options = a
            } else this.options = {};
            this.options.params || (this.options.params = {})
        }
        absorbOptions(n) {
            let e = n.params;
            if (e) {
                let t = this.options.params;
                Object.keys(e).forEach(o => {
                    t[o] == null && (t[o] = e[o])
                })
            }
        }
    },
    Fi = "void",
    Ir = new Vi(Fi),
    Ar = class {
        id;
        hostElement;
        _engine;
        players = [];
        _triggers = new Map;
        _queue = [];
        _elementListeners = new Map;
        _hostClassName;
        constructor(n, e, t) {
            this.id = n, this.hostElement = e, this._engine = t, this._hostClassName = "ng-tns-" + n, Je(e, this._hostClassName)
        }
        listen(n, e, t, o) {
            if (!this._triggers.has(e)) throw mp(t, e);
            if (t == null || t.length == 0) throw fp(e);
            if (!ym(t)) throw gp(t, e);
            let r = je(this._elementListeners, n, []),
                s = {
                    name: e,
                    phase: t,
                    callback: o
                };
            r.push(s);
            let a = je(this._engine.statesByElement, n, new Map);
            return a.has(e) || (Je(n, Ni), Je(n, Ni + "-" + e), a.set(e, Ir)), () => {
                this._engine.afterFlush(() => {
                    let c = r.indexOf(s);
                    c >= 0 && r.splice(c, 1), this._triggers.has(e) || a.delete(e)
                })
            }
        }
        register(n, e) {
            return this._triggers.has(n) ? !1 : (this._triggers.set(n, e), !0)
        }
        _getTrigger(n) {
            let e = this._triggers.get(n);
            if (!e) throw vp(n);
            return e
        }
        trigger(n, e, t, o = !0) {
            let r = this._getTrigger(e),
                s = new zi(this.id, e, n),
                a = this._engine.statesByElement.get(n);
            a || (Je(n, Ni), Je(n, Ni + "-" + e), this._engine.statesByElement.set(n, a = new Map));
            let c = a.get(e),
                d = new Vi(t, this.id);
            if (!(t && t.hasOwnProperty("value")) && c && d.absorbOptions(c.options), a.set(e, d), c || (c = Ir), !(d.value === Fi) && c.value === d.value) {
                if (!Im(c.params, d.params)) {
                    let N = [],
                        H = r.matchStyles(c.value, c.params, N),
                        ie = r.matchStyles(d.value, d.params, N);
                    N.length ? this._engine.reportError(N) : this._engine.afterFlush(() => {
                        Rt(n, H), nt(n, ie)
                    })
                }
                return
            }
            let O = je(this._engine.playersByElement, n, []);
            O.forEach(N => {
                N.namespaceId == this.id && N.triggerName == e && N.queued && N.destroy()
            });
            let B = r.matchTransition(c.value, d.value, n, d.params),
                R = !1;
            if (!B) {
                if (!o) return;
                B = r.fallbackTransition, R = !0
            }
            return this._engine.totalQueuedPlayers++, this._queue.push({
                element: n,
                triggerName: e,
                transition: B,
                fromState: c,
                toState: d,
                player: s,
                isFallbackTransition: R
            }), R || (Je(n, kp), s.onStart(() => {
                _i(n, kp)
            })), s.onDone(() => {
                let N = this.players.indexOf(s);
                N >= 0 && this.players.splice(N, 1);
                let H = this._engine.playersByElement.get(n);
                if (H) {
                    let ie = H.indexOf(s);
                    ie >= 0 && H.splice(ie, 1)
                }
            }), this.players.push(s), O.push(s), s
        }
        deregister(n) {
            this._triggers.delete(n), this._engine.statesByElement.forEach(e => e.delete(n)), this._elementListeners.forEach((e, t) => {
                this._elementListeners.set(t, e.filter(o => o.name != n))
            })
        }
        clearElementCache(n) {
            this._engine.statesByElement.delete(n), this._elementListeners.delete(n);
            let e = this._engine.playersByElement.get(n);
            e && (e.forEach(t => t.destroy()), this._engine.playersByElement.delete(n))
        }
        _signalRemovalForInnerTriggers(n, e) {
            let t = this._engine.driver.query(n, Li, !0);
            t.forEach(o => {
                if (o[ot]) return;
                let r = this._engine.fetchNamespacesByElement(o);
                r.size ? r.forEach(s => s.triggerLeaveAnimation(o, e, !1, !0)) : this.clearElementCache(o)
            }), this._engine.afterFlushAnimationsDone(() => t.forEach(o => this.clearElementCache(o)))
        }
        triggerLeaveAnimation(n, e, t, o) {
            let r = this._engine.statesByElement.get(n),
                s = new Map;
            if (r) {
                let a = [];
                if (r.forEach((c, d) => {
                        if (s.set(d, c.value), this._triggers.has(d)) {
                            let h = this.trigger(n, d, Fi, o);
                            h && a.push(h)
                        }
                    }), a.length) return this._engine.markElementAsRemoved(this.id, n, !0, e, s), t && yt(a).onDone(() => this._engine.processLeaveNode(n)), !0
            }
            return !1
        }
        prepareLeaveAnimationListeners(n) {
            let e = this._elementListeners.get(n),
                t = this._engine.statesByElement.get(n);
            if (e && t) {
                let o = new Set;
                e.forEach(r => {
                    let s = r.name;
                    if (o.has(s)) return;
                    o.add(s);
                    let c = this._triggers.get(s).fallbackTransition,
                        d = t.get(s) || Ir,
                        h = new Vi(Fi),
                        y = new zi(this.id, s, n);
                    this._engine.totalQueuedPlayers++, this._queue.push({
                        element: n,
                        triggerName: s,
                        transition: c,
                        fromState: d,
                        toState: h,
                        player: y,
                        isFallbackTransition: !0
                    })
                })
            }
        }
        removeNode(n, e) {
            let t = this._engine;
            if (n.childElementCount && this._signalRemovalForInnerTriggers(n, e), this.triggerLeaveAnimation(n, e, !0)) return;
            let o = !1;
            if (t.totalAnimations) {
                let r = t.players.length ? t.playersByQueriedElement.get(n) : [];
                if (r && r.length) o = !0;
                else {
                    let s = n;
                    for (; s = s.parentNode;)
                        if (t.statesByElement.get(s)) {
                            o = !0;
                            break
                        }
                }
            }
            if (this.prepareLeaveAnimationListeners(n), o) t.markElementAsRemoved(this.id, n, !1, e);
            else {
                let r = n[ot];
                (!r || r === Bp) && (t.afterFlush(() => this.clearElementCache(n)), t.destroyInnerAnimations(n), t._onRemovalComplete(n, e))
            }
        }
        insertNode(n, e) {
            Je(n, this._hostClassName)
        }
        drainQueuedTransitions(n) {
            let e = [];
            return this._queue.forEach(t => {
                let o = t.player;
                if (o.destroyed) return;
                let r = t.element,
                    s = this._elementListeners.get(r);
                s && s.forEach(a => {
                    if (a.name == t.triggerName) {
                        let c = Bn(r, t.triggerName, t.fromState.value, t.toState.value);
                        c._data = n, Fn(t.player, a.phase, c, a.callback)
                    }
                }), o.markedForDestroy ? this._engine.afterFlush(() => {
                    o.destroy()
                }) : e.push(t)
            }), this._queue = [], e.sort((t, o) => {
                let r = t.transition.ast.depCount,
                    s = o.transition.ast.depCount;
                return r == 0 || s == 0 ? r - s : this._engine.driver.containsElement(t.element, o.element) ? 1 : -1
            })
        }
        destroy(n) {
            this.players.forEach(e => e.destroy()), this._signalRemovalForInnerTriggers(this.hostElement, n)
        }
    },
    Or = class {
        bodyNode;
        driver;
        _normalizer;
        players = [];
        newHostElements = new Map;
        playersByElement = new Map;
        playersByQueriedElement = new Map;
        statesByElement = new Map;
        disabledNodes = new Set;
        totalAnimations = 0;
        totalQueuedPlayers = 0;
        _namespaceLookup = {};
        _namespaceList = [];
        _flushFns = [];
        _whenQuietFns = [];
        namespacesByHostElement = new Map;
        collectedEnterElements = [];
        collectedLeaveElements = [];
        onRemovalComplete = (n, e) => {};
        _onRemovalComplete(n, e) {
            this.onRemovalComplete(n, e)
        }
        constructor(n, e, t) {
            this.bodyNode = n, this.driver = e, this._normalizer = t
        }
        get queuedPlayers() {
            let n = [];
            return this._namespaceList.forEach(e => {
                e.players.forEach(t => {
                    t.queued && n.push(t)
                })
            }), n
        }
        createNamespace(n, e) {
            let t = new Ar(n, e, this);
            return this.bodyNode && this.driver.containsElement(this.bodyNode, e) ? this._balanceNamespaceList(t, e) : (this.newHostElements.set(e, t), this.collectEnterElement(e)), this._namespaceLookup[n] = t
        }
        _balanceNamespaceList(n, e) {
            let t = this._namespaceList,
                o = this.namespacesByHostElement;
            if (t.length - 1 >= 0) {
                let s = !1,
                    a = this.driver.getParentElement(e);
                for (; a;) {
                    let c = o.get(a);
                    if (c) {
                        let d = t.indexOf(c);
                        t.splice(d + 1, 0, n), s = !0;
                        break
                    }
                    a = this.driver.getParentElement(a)
                }
                s || t.unshift(n)
            } else t.push(n);
            return o.set(e, n), n
        }
        register(n, e) {
            let t = this._namespaceLookup[n];
            return t || (t = this.createNamespace(n, e)), t
        }
        registerTrigger(n, e, t) {
            let o = this._namespaceLookup[n];
            o && o.register(e, t) && this.totalAnimations++
        }
        destroy(n, e) {
            n && (this.afterFlush(() => {}), this.afterFlushAnimationsDone(() => {
                let t = this._fetchNamespace(n);
                this.namespacesByHostElement.delete(t.hostElement);
                let o = this._namespaceList.indexOf(t);
                o >= 0 && this._namespaceList.splice(o, 1), t.destroy(e), delete this._namespaceLookup[n]
            }))
        }
        _fetchNamespace(n) {
            return this._namespaceLookup[n]
        }
        fetchNamespacesByElement(n) {
            let e = new Set,
                t = this.statesByElement.get(n);
            if (t) {
                for (let o of t.values())
                    if (o.namespaceId) {
                        let r = this._fetchNamespace(o.namespaceId);
                        r && e.add(r)
                    }
            }
            return e
        }
        trigger(n, e, t, o) {
            if (Kn(e)) {
                let r = this._fetchNamespace(n);
                if (r) return r.trigger(e, t, o), !0
            }
            return !1
        }
        insertNode(n, e, t, o) {
            if (!Kn(e)) return;
            let r = e[ot];
            if (r && r.setForRemoval) {
                r.setForRemoval = !1, r.setForMove = !0;
                let s = this.collectedLeaveElements.indexOf(e);
                s >= 0 && this.collectedLeaveElements.splice(s, 1)
            }
            if (n) {
                let s = this._fetchNamespace(n);
                s && s.insertNode(e, t)
            }
            o && this.collectEnterElement(e)
        }
        collectEnterElement(n) {
            this.collectedEnterElements.push(n)
        }
        markElementAsDisabled(n, e) {
            e ? this.disabledNodes.has(n) || (this.disabledNodes.add(n), Je(n, Sr)) : this.disabledNodes.has(n) && (this.disabledNodes.delete(n), _i(n, Sr))
        }
        removeNode(n, e, t) {
            if (Kn(e)) {
                let o = n ? this._fetchNamespace(n) : null;
                o ? o.removeNode(e, t) : this.markElementAsRemoved(n, e, !1, t);
                let r = this.namespacesByHostElement.get(e);
                r && r.id !== n && r.removeNode(e, t)
            } else this._onRemovalComplete(e, t)
        }
        markElementAsRemoved(n, e, t, o, r) {
            this.collectedLeaveElements.push(e), e[ot] = {
                namespaceId: n,
                setForRemoval: o,
                hasAnimation: t,
                removedBeforeQueried: !1,
                previousTriggersValues: r
            }
        }
        listen(n, e, t, o, r) {
            return Kn(e) ? this._fetchNamespace(n).listen(e, t, o, r) : () => {}
        }
        _buildInstruction(n, e, t, o, r) {
            return n.transition.build(this.driver, n.element, n.fromState.value, n.toState.value, t, o, n.fromState.options, n.toState.options, e, r)
        }
        destroyInnerAnimations(n) {
            let e = this.driver.query(n, Li, !0);
            e.forEach(t => this.destroyActiveAnimationsForElement(t)), this.playersByQueriedElement.size != 0 && (e = this.driver.query(n, Un, !0), e.forEach(t => this.finishActiveQueriedAnimationOnElement(t)))
        }
        destroyActiveAnimationsForElement(n) {
            let e = this.playersByElement.get(n);
            e && e.forEach(t => {
                t.queued ? t.markedForDestroy = !0 : t.destroy()
            })
        }
        finishActiveQueriedAnimationOnElement(n) {
            let e = this.playersByQueriedElement.get(n);
            e && e.forEach(t => t.finish())
        }
        whenRenderingDone() {
            return new Promise(n => {
                if (this.players.length) return yt(this.players).onDone(() => n());
                n()
            })
        }
        processLeaveNode(n) {
            let e = n[ot];
            if (e && e.setForRemoval) {
                if (n[ot] = Bp, e.namespaceId) {
                    this.destroyInnerAnimations(n);
                    let t = this._fetchNamespace(e.namespaceId);
                    t && t.clearElementCache(n)
                }
                this._onRemovalComplete(n, e.setForRemoval)
            }
            n.classList ? .contains(Sr) && this.markElementAsDisabled(n, !1), this.driver.query(n, hm, !0).forEach(t => {
                this.markElementAsDisabled(t, !1)
            })
        }
        flush(n = -1) {
            let e = [];
            if (this.newHostElements.size && (this.newHostElements.forEach((t, o) => this._balanceNamespaceList(t, o)), this.newHostElements.clear()), this.totalAnimations && this.collectedEnterElements.length)
                for (let t = 0; t < this.collectedEnterElements.length; t++) {
                    let o = this.collectedEnterElements[t];
                    Je(o, mm)
                }
            if (this._namespaceList.length && (this.totalQueuedPlayers || this.collectedLeaveElements.length)) {
                let t = [];
                try {
                    e = this._flushAnimations(t, n)
                } finally {
                    for (let o = 0; o < t.length; o++) t[o]()
                }
            } else
                for (let t = 0; t < this.collectedLeaveElements.length; t++) {
                    let o = this.collectedLeaveElements[t];
                    this.processLeaveNode(o)
                }
            if (this.totalQueuedPlayers = 0, this.collectedEnterElements.length = 0, this.collectedLeaveElements.length = 0, this._flushFns.forEach(t => t()), this._flushFns = [], this._whenQuietFns.length) {
                let t = this._whenQuietFns;
                this._whenQuietFns = [], e.length ? yt(e).onDone(() => {
                    t.forEach(o => o())
                }) : t.forEach(o => o())
            }
        }
        reportError(n) {
            throw _p(n)
        }
        _flushAnimations(n, e) {
            let t = new Bi,
                o = [],
                r = new Map,
                s = [],
                a = new Map,
                c = new Map,
                d = new Map,
                h = new Set;
            this.disabledNodes.forEach(P => {
                h.add(P);
                let F = this.driver.query(P, um, !0);
                for (let z = 0; z < F.length; z++) h.add(F[z])
            });
            let y = this.bodyNode,
                O = Array.from(this.statesByElement.keys()),
                B = Ap(O, this.collectedEnterElements),
                R = new Map,
                N = 0;
            B.forEach((P, F) => {
                let z = vr + N++;
                R.set(F, z), P.forEach(X => Je(X, z))
            });
            let H = [],
                ie = new Set,
                ce = new Set;
            for (let P = 0; P < this.collectedLeaveElements.length; P++) {
                let F = this.collectedLeaveElements[P],
                    z = F[ot];
                z && z.setForRemoval && (H.push(F), ie.add(F), z.hasAnimation ? this.driver.query(F, fm, !0).forEach(X => ie.add(X)) : ce.add(F))
            }
            let he = new Map,
                ae = Ap(O, Array.from(ie));
            ae.forEach((P, F) => {
                let z = zn + N++;
                he.set(F, z), P.forEach(X => Je(X, z))
            }), n.push(() => {
                B.forEach((P, F) => {
                    let z = R.get(F);
                    P.forEach(X => _i(X, z))
                }), ae.forEach((P, F) => {
                    let z = he.get(F);
                    P.forEach(X => _i(X, z))
                }), H.forEach(P => {
                    this.processLeaveNode(P)
                })
            });
            let qe = [],
                Be = [];
            for (let P = this._namespaceList.length - 1; P >= 0; P--) this._namespaceList[P].drainQueuedTransitions(e).forEach(z => {
                let X = z.player,
                    Ce = z.element;
                if (qe.push(X), this.collectedEnterElements.length) {
                    let Ee = Ce[ot];
                    if (Ee && Ee.setForMove) {
                        if (Ee.previousTriggersValues && Ee.previousTriggersValues.has(z.triggerName)) {
                            let Nt = Ee.previousTriggersValues.get(z.triggerName),
                                Ke = this.statesByElement.get(z.element);
                            if (Ke && Ke.has(z.triggerName)) {
                                let Xi = Ke.get(z.triggerName);
                                Xi.value = Nt, Ke.set(z.triggerName, Xi)
                            }
                        }
                        X.destroy();
                        return
                    }
                }
                let rt = !y || !this.driver.containsElement(y, Ce),
                    Ve = he.get(Ce),
                    St = R.get(Ce),
                    de = this._buildInstruction(z, t, St, Ve, rt);
                if (de.errors && de.errors.length) {
                    Be.push(de);
                    return
                }
                if (rt) {
                    X.onStart(() => Rt(Ce, de.fromStyles)), X.onDestroy(() => nt(Ce, de.toStyles)), o.push(X);
                    return
                }
                if (z.isFallbackTransition) {
                    X.onStart(() => Rt(Ce, de.fromStyles)), X.onDestroy(() => nt(Ce, de.toStyles)), o.push(X);
                    return
                }
                let ol = [];
                de.timelines.forEach(Ee => {
                    Ee.stretchStartingKeyframe = !0, this.disabledNodes.has(Ee.element) || ol.push(Ee)
                }), de.timelines = ol, t.append(Ce, de.timelines);
                let Th = {
                    instruction: de,
                    player: X,
                    element: Ce
                };
                s.push(Th), de.queriedElements.forEach(Ee => je(a, Ee, []).push(X)), de.preStyleProps.forEach((Ee, Nt) => {
                    if (Ee.size) {
                        let Ke = c.get(Nt);
                        Ke || c.set(Nt, Ke = new Set), Ee.forEach((Xi, wo) => Ke.add(wo))
                    }
                }), de.postStyleProps.forEach((Ee, Nt) => {
                    let Ke = d.get(Nt);
                    Ke || d.set(Nt, Ke = new Set), Ee.forEach((Xi, wo) => Ke.add(wo))
                })
            });
            if (Be.length) {
                let P = [];
                Be.forEach(F => {
                    P.push(bp(F.triggerName, F.errors))
                }), qe.forEach(F => F.destroy()), this.reportError(P)
            }
            let ye = new Map,
                Re = new Map;
            s.forEach(P => {
                let F = P.element;
                t.has(F) && (Re.set(F, F), this._beforeAnimationBuild(P.player.namespaceId, P.instruction, ye))
            }), o.forEach(P => {
                let F = P.element;
                this._getPreviousPlayers(F, !1, P.namespaceId, P.triggerName, null).forEach(X => {
                    je(ye, F, []).push(X), X.destroy()
                })
            });
            let At = H.filter(P => Op(P, c, d)),
                Xt = new Map;
            Rp(Xt, this.driver, ce, d, Xe).forEach(P => {
                Op(P, c, d) && At.push(P)
            });
            let Ot = new Map;
            B.forEach((P, F) => {
                Rp(Ot, this.driver, new Set(P), c, fi)
            }), At.forEach(P => {
                let F = Xt.get(P),
                    z = Ot.get(P);
                Xt.set(P, new Map([...F ? .entries() ? ? [], ...z ? .entries() ? ? []]))
            });
            let Io = [],
                il = [],
                nl = {};
            s.forEach(P => {
                let {
                    element: F,
                    player: z,
                    instruction: X
                } = P;
                if (t.has(F)) {
                    if (h.has(F)) {
                        z.onDestroy(() => nt(F, X.toStyles)), z.disabled = !0, z.overrideTotalTime(X.totalTime), o.push(z);
                        return
                    }
                    let Ce = nl;
                    if (Re.size > 1) {
                        let Ve = F,
                            St = [];
                        for (; Ve = Ve.parentNode;) {
                            let de = Re.get(Ve);
                            if (de) {
                                Ce = de;
                                break
                            }
                            St.push(Ve)
                        }
                        St.forEach(de => Re.set(de, Ce))
                    }
                    let rt = this._buildAnimation(z.namespaceId, X, ye, r, Ot, Xt);
                    if (z.setRealPlayer(rt), Ce === nl) Io.push(z);
                    else {
                        let Ve = this.playersByElement.get(Ce);
                        Ve && Ve.length && (z.parentPlayer = yt(Ve)), o.push(z)
                    }
                } else Rt(F, X.fromStyles), z.onDestroy(() => nt(F, X.toStyles)), il.push(z), h.has(F) && o.push(z)
            }), il.forEach(P => {
                let F = r.get(P.element);
                if (F && F.length) {
                    let z = yt(F);
                    P.setRealPlayer(z)
                }
            }), o.forEach(P => {
                P.parentPlayer ? P.syncPlayerEvents(P.parentPlayer) : P.destroy()
            });
            for (let P = 0; P < H.length; P++) {
                let F = H[P],
                    z = F[ot];
                if (_i(F, zn), z && z.hasAnimation) continue;
                let X = [];
                if (a.size) {
                    let rt = a.get(F);
                    rt && rt.length && X.push(...rt);
                    let Ve = this.driver.query(F, Un, !0);
                    for (let St = 0; St < Ve.length; St++) {
                        let de = a.get(Ve[St]);
                        de && de.length && X.push(...de)
                    }
                }
                let Ce = X.filter(rt => !rt.destroyed);
                Ce.length ? Cm(this, F, Ce) : this.processLeaveNode(F)
            }
            return H.length = 0, Io.forEach(P => {
                this.players.push(P), P.onDone(() => {
                    P.destroy();
                    let F = this.players.indexOf(P);
                    this.players.splice(F, 1)
                }), P.play()
            }), Io
        }
        afterFlush(n) {
            this._flushFns.push(n)
        }
        afterFlushAnimationsDone(n) {
            this._whenQuietFns.push(n)
        }
        _getPreviousPlayers(n, e, t, o, r) {
            let s = [];
            if (e) {
                let a = this.playersByQueriedElement.get(n);
                a && (s = a)
            } else {
                let a = this.playersByElement.get(n);
                if (a) {
                    let c = !r || r == Fi;
                    a.forEach(d => {
                        d.queued || !c && d.triggerName != o || s.push(d)
                    })
                }
            }
            return (t || o) && (s = s.filter(a => !(t && t != a.namespaceId || o && o != a.triggerName))), s
        }
        _beforeAnimationBuild(n, e, t) {
            let o = e.triggerName,
                r = e.element,
                s = e.isRemovalTransition ? void 0 : n,
                a = e.isRemovalTransition ? void 0 : o;
            for (let c of e.timelines) {
                let d = c.element,
                    h = d !== r,
                    y = je(t, d, []);
                this._getPreviousPlayers(d, h, s, a, e.toState).forEach(B => {
                    let R = B.getRealPlayer();
                    R.beforeDestroy && R.beforeDestroy(), B.destroy(), y.push(B)
                })
            }
            Rt(r, e.fromStyles)
        }
        _buildAnimation(n, e, t, o, r, s) {
            let a = e.triggerName,
                c = e.element,
                d = [],
                h = new Set,
                y = new Set,
                O = e.timelines.map(R => {
                    let N = R.element;
                    h.add(N);
                    let H = N[ot];
                    if (H && H.removedBeforeQueried) return new ht(R.duration, R.delay);
                    let ie = N !== c,
                        ce = Sm((t.get(N) || gm).map(ye => ye.getRealPlayer())).filter(ye => {
                            let Re = ye;
                            return Re.element ? Re.element === N : !1
                        }),
                        he = r.get(N),
                        ae = s.get(N),
                        qe = ur(this._normalizer, R.keyframes, he, ae),
                        Be = this._buildPlayer(R, qe, ce);
                    if (R.subTimeline && o && y.add(N), ie) {
                        let ye = new zi(n, a, N);
                        ye.setRealPlayer(Be), d.push(ye)
                    }
                    return Be
                });
            d.forEach(R => {
                je(this.playersByQueriedElement, R.element, []).push(R), R.onDone(() => _m(this.playersByQueriedElement, R.element, R))
            }), h.forEach(R => Je(R, _r));
            let B = yt(O);
            return B.onDestroy(() => {
                h.forEach(R => _i(R, _r)), nt(c, e.toStyles)
            }), y.forEach(R => {
                je(o, R, []).push(B)
            }), B
        }
        _buildPlayer(n, e, t) {
            return e.length > 0 ? this.driver.animate(n.element, e, n.duration, n.delay, n.easing, t) : new ht(n.duration, n.delay)
        }
    },
    zi = class {
        namespaceId;
        triggerName;
        element;
        _player = new ht;
        _containsRealPlayer = !1;
        _queuedCallbacks = new Map;
        destroyed = !1;
        parentPlayer = null;
        markedForDestroy = !1;
        disabled = !1;
        queued = !0;
        totalTime = 0;
        constructor(n, e, t) {
            this.namespaceId = n, this.triggerName = e, this.element = t
        }
        setRealPlayer(n) {
            this._containsRealPlayer || (this._player = n, this._queuedCallbacks.forEach((e, t) => {
                e.forEach(o => Fn(n, t, void 0, o))
            }), this._queuedCallbacks.clear(), this._containsRealPlayer = !0, this.overrideTotalTime(n.totalTime), this.queued = !1)
        }
        getRealPlayer() {
            return this._player
        }
        overrideTotalTime(n) {
            this.totalTime = n
        }
        syncPlayerEvents(n) {
            let e = this._player;
            e.triggerCallback && n.onStart(() => e.triggerCallback("start")), n.onDone(() => this.finish()), n.onDestroy(() => this.destroy())
        }
        _queueEvent(n, e) {
            je(this._queuedCallbacks, n, []).push(e)
        }
        onDone(n) {
            this.queued && this._queueEvent("done", n), this._player.onDone(n)
        }
        onStart(n) {
            this.queued && this._queueEvent("start", n), this._player.onStart(n)
        }
        onDestroy(n) {
            this.queued && this._queueEvent("destroy", n), this._player.onDestroy(n)
        }
        init() {
            this._player.init()
        }
        hasStarted() {
            return this.queued ? !1 : this._player.hasStarted()
        }
        play() {
            !this.queued && this._player.play()
        }
        pause() {
            !this.queued && this._player.pause()
        }
        restart() {
            !this.queued && this._player.restart()
        }
        finish() {
            this._player.finish()
        }
        destroy() {
            this.destroyed = !0, this._player.destroy()
        }
        reset() {
            !this.queued && this._player.reset()
        }
        setPosition(n) {
            this.queued || this._player.setPosition(n)
        }
        getPosition() {
            return this.queued ? 0 : this._player.getPosition()
        }
        triggerCallback(n) {
            let e = this._player;
            e.triggerCallback && e.triggerCallback(n)
        }
    };

function _m(i, n, e) {
    let t = i.get(n);
    if (t) {
        if (t.length) {
            let o = t.indexOf(e);
            t.splice(o, 1)
        }
        t.length == 0 && i.delete(n)
    }
    return t
}

function bm(i) {
    return i ? ? null
}

function Kn(i) {
    return i && i.nodeType === 1
}

function ym(i) {
    return i == "start" || i == "done"
}

function Mp(i, n) {
    let e = i.style.display;
    return i.style.display = n ? ? "none", e
}

function Rp(i, n, e, t, o) {
    let r = [];
    e.forEach(c => r.push(Mp(c)));
    let s = [];
    t.forEach((c, d) => {
        let h = new Map;
        c.forEach(y => {
            let O = n.computeStyle(d, y, o);
            h.set(y, O), (!O || O.length == 0) && (d[ot] = vm, s.push(d))
        }), i.set(d, h)
    });
    let a = 0;
    return e.forEach(c => Mp(c, r[a++])), s
}

function Ap(i, n) {
    let e = new Map;
    if (i.forEach(a => e.set(a, [])), n.length == 0) return e;
    let t = 1,
        o = new Set(n),
        r = new Map;

    function s(a) {
        if (!a) return t;
        let c = r.get(a);
        if (c) return c;
        let d = a.parentNode;
        return e.has(d) ? c = d : o.has(d) ? c = t : c = s(d), r.set(a, c), c
    }
    return n.forEach(a => {
        let c = s(a);
        c !== t && e.get(c).push(a)
    }), e
}

function Je(i, n) {
    i.classList ? .add(n)
}

function _i(i, n) {
    i.classList ? .remove(n)
}

function Cm(i, n, e) {
    yt(e).onDone(() => i.processLeaveNode(n))
}

function Sm(i) {
    let n = [];
    return Vp(i, n), n
}

function Vp(i, n) {
    for (let e = 0; e < i.length; e++) {
        let t = i[e];
        t instanceof Ut ? Vp(t.players, n) : n.push(t)
    }
}

function Im(i, n) {
    let e = Object.keys(i),
        t = Object.keys(n);
    if (e.length != t.length) return !1;
    for (let o = 0; o < e.length; o++) {
        let r = e[o];
        if (!n.hasOwnProperty(r) || i[r] !== n[r]) return !1
    }
    return !0
}

function Op(i, n, e) {
    let t = e.get(i);
    if (!t) return !1;
    let o = n.get(i);
    return o ? t.forEach(r => o.add(r)) : n.set(i, t), e.delete(i), !0
}
var bi = class {
    _driver;
    _normalizer;
    _transitionEngine;
    _timelineEngine;
    _triggerCache = {};
    onRemovalComplete = (n, e) => {};
    constructor(n, e, t) {
        this._driver = e, this._normalizer = t, this._transitionEngine = new Or(n.body, e, t), this._timelineEngine = new Rr(n.body, e, t), this._transitionEngine.onRemovalComplete = (o, r) => this.onRemovalComplete(o, r)
    }
    registerTrigger(n, e, t, o, r) {
        let s = n + "-" + o,
            a = this._triggerCache[s];
        if (!a) {
            let c = [],
                d = [],
                h = Lp(this._driver, r, c, d);
            if (c.length) throw cp(o, c);
            a = cm(o, h, this._normalizer), this._triggerCache[s] = a
        }
        this._transitionEngine.registerTrigger(e, o, a)
    }
    register(n, e) {
        this._transitionEngine.register(n, e)
    }
    destroy(n, e) {
        this._transitionEngine.destroy(n, e)
    }
    onInsert(n, e, t, o) {
        this._transitionEngine.insertNode(n, e, t, o)
    }
    onRemove(n, e, t) {
        this._transitionEngine.removeNode(n, e, t)
    }
    disableAnimations(n, e) {
        this._transitionEngine.markElementAsDisabled(n, e)
    }
    process(n, e, t, o) {
        if (t.charAt(0) == "@") {
            let [r, s] = hr(t), a = o;
            this._timelineEngine.command(r, e, s, a)
        } else this._transitionEngine.trigger(n, e, t, o)
    }
    listen(n, e, t, o, r) {
        if (t.charAt(0) == "@") {
            let [s, a] = hr(t);
            return this._timelineEngine.listen(s, e, a, r)
        }
        return this._transitionEngine.listen(n, e, t, o, r)
    }
    flush(n = -1) {
        this._transitionEngine.flush(n)
    }
    get players() {
        return [...this._transitionEngine.players, ...this._timelineEngine.players]
    }
    whenRenderingDone() {
        return this._transitionEngine.whenRenderingDone()
    }
    afterFlushAnimationsDone(n) {
        this._transitionEngine.afterFlushAnimationsDone(n)
    }
};

function wm(i, n) {
    let e = null,
        t = null;
    return Array.isArray(n) && n.length ? (e = wr(n[0]), n.length > 1 && (t = wr(n[n.length - 1]))) : n instanceof Map && (e = wr(n)), e || t ? new Em(i, e, t) : null
}
var Em = (() => {
    class i {
        _element;
        _startStyles;
        _endStyles;
        static initialStylesByElement = new WeakMap;
        _state = 0;
        _initialStyles;
        constructor(e, t, o) {
            this._element = e, this._startStyles = t, this._endStyles = o;
            let r = i.initialStylesByElement.get(e);
            r || i.initialStylesByElement.set(e, r = new Map), this._initialStyles = r
        }
        start() {
            this._state < 1 && (this._startStyles && nt(this._element, this._startStyles, this._initialStyles), this._state = 1)
        }
        finish() {
            this.start(), this._state < 2 && (nt(this._element, this._initialStyles), this._endStyles && (nt(this._element, this._endStyles), this._endStyles = null), this._state = 1)
        }
        destroy() {
            this.finish(), this._state < 3 && (i.initialStylesByElement.delete(this._element), this._startStyles && (Rt(this._element, this._startStyles), this._endStyles = null), this._endStyles && (Rt(this._element, this._endStyles), this._endStyles = null), nt(this._element, this._initialStyles), this._state = 3)
        }
    }
    return i
})();

function wr(i) {
    let n = null;
    return i.forEach((e, t) => {
        Dm(t) && (n = n || new Map, n.set(t, e))
    }), n
}

function Dm(i) {
    return i === "display" || i === "position"
}
var eo = class {
        element;
        keyframes;
        options;
        _specialStyles;
        _onDoneFns = [];
        _onStartFns = [];
        _onDestroyFns = [];
        _duration;
        _delay;
        _initialized = !1;
        _finished = !1;
        _started = !1;
        _destroyed = !1;
        _finalKeyframe;
        _originalOnDoneFns = [];
        _originalOnStartFns = [];
        domPlayer = null;
        time = 0;
        parentPlayer = null;
        currentSnapshot = new Map;
        constructor(n, e, t, o) {
            this.element = n, this.keyframes = e, this.options = t, this._specialStyles = o, this._duration = t.duration, this._delay = t.delay || 0, this.time = this._duration + this._delay
        }
        _onFinish() {
            this._finished || (this._finished = !0, this._onDoneFns.forEach(n => n()), this._onDoneFns = [])
        }
        init() {
            this._buildPlayer() && this._preparePlayerBeforeStart()
        }
        _buildPlayer() {
            if (this._initialized) return this.domPlayer;
            this._initialized = !0;
            let n = this.keyframes,
                e = this._triggerWebAnimation(this.element, n, this.options);
            if (!e) return this._onFinish(), null;
            this.domPlayer = e, this._finalKeyframe = n.length ? n[n.length - 1] : new Map;
            let t = () => this._onFinish();
            return e.addEventListener("finish", t), this.onDestroy(() => {
                e.removeEventListener("finish", t)
            }), e
        }
        _preparePlayerBeforeStart() {
            this._delay ? this._resetDomPlayerState() : this.domPlayer ? .pause()
        }
        _convertKeyframesToObject(n) {
            let e = [];
            return n.forEach(t => {
                e.push(Object.fromEntries(t))
            }), e
        }
        _triggerWebAnimation(n, e, t) {
            let o = this._convertKeyframesToObject(e);
            try {
                return n.animate(o, t)
            } catch (r) {
                return null
            }
        }
        onStart(n) {
            this._originalOnStartFns.push(n), this._onStartFns.push(n)
        }
        onDone(n) {
            this._originalOnDoneFns.push(n), this._onDoneFns.push(n)
        }
        onDestroy(n) {
            this._onDestroyFns.push(n)
        }
        play() {
            let n = this._buildPlayer();
            n && (this.hasStarted() || (this._onStartFns.forEach(e => e()), this._onStartFns = [], this._started = !0, this._specialStyles && this._specialStyles.start()), n.play())
        }
        pause() {
            this.init(), this.domPlayer ? .pause()
        }
        finish() {
            this.init(), this.domPlayer && (this._specialStyles && this._specialStyles.finish(), this._onFinish(), this.domPlayer.finish())
        }
        reset() {
            this._resetDomPlayerState(), this._destroyed = !1, this._finished = !1, this._started = !1, this._onStartFns = this._originalOnStartFns, this._onDoneFns = this._originalOnDoneFns
        }
        _resetDomPlayerState() {
            this.domPlayer ? .cancel()
        }
        restart() {
            this.reset(), this.play()
        }
        hasStarted() {
            return this._started
        }
        destroy() {
            this._destroyed || (this._destroyed = !0, this._resetDomPlayerState(), this._onFinish(), this._specialStyles && this._specialStyles.destroy(), this._onDestroyFns.forEach(n => n()), this._onDestroyFns = [])
        }
        setPosition(n) {
            this.domPlayer || this.init(), this.domPlayer && (this.domPlayer.currentTime = n * this.time)
        }
        getPosition() {
            return this.domPlayer ? +(this.domPlayer.currentTime ? ? 0) / this.time : this._initialized ? 1 : 0
        }
        get totalTime() {
            return this._delay + this._duration
        }
        beforeDestroy() {
            let n = new Map;
            this.hasStarted() && this._finalKeyframe.forEach((t, o) => {
                o !== "offset" && n.set(o, this._finished ? t : Hn(this.element, o))
            }), this.currentSnapshot = n
        }
        triggerCallback(n) {
            let e = n === "start" ? this._onStartFns : this._onDoneFns;
            e.forEach(t => t()), e.length = 0
        }
    },
    to = class {
        validateStyleProperty(n) {
            return !0
        }
        validateAnimatableStyleProperty(n) {
            return !0
        }
        containsElement(n, e) {
            return mr(n, e)
        }
        getParentElement(n) {
            return Vn(n)
        }
        query(n, e, t) {
            return fr(n, e, t)
        }
        computeStyle(n, e, t) {
            return Hn(n, e)
        }
        animate(n, e, t, o, r, s = []) {
            let a = o == 0 ? "both" : "forwards",
                c = {
                    duration: t,
                    delay: o,
                    fill: a
                };
            r && (c.easing = r);
            let d = new Map,
                h = s.filter(B => B instanceof eo);
            Ip(t, o) && h.forEach(B => {
                B.currentSnapshot.forEach((R, N) => d.set(N, R))
            });
            let y = Cp(e).map(B => new Map(B));
            y = wp(n, y, d);
            let O = wm(n, y);
            return new eo(n, y, c, O)
        }
    };
var $n = "@",
    zp = "@.disabled",
    io = class {
        namespaceId;
        delegate;
        engine;
        _onDestroy;\
        u0275type = 0;
        constructor(n, e, t, o) {
            this.namespaceId = n, this.delegate = e, this.engine = t, this._onDestroy = o
        }
        get data() {
            return this.delegate.data
        }
        destroyNode(n) {
            this.delegate.destroyNode ? .(n)
        }
        destroy() {
            this.engine.destroy(this.namespaceId, this.delegate), this.engine.afterFlushAnimationsDone(() => {
                queueMicrotask(() => {
                    this.delegate.destroy()
                })
            }), this._onDestroy ? .()
        }
        createElement(n, e) {
            return this.delegate.createElement(n, e)
        }
        createComment(n) {
            return this.delegate.createComment(n)
        }
        createText(n) {
            return this.delegate.createText(n)
        }
        appendChild(n, e) {
            this.delegate.appendChild(n, e), this.engine.onInsert(this.namespaceId, e, n, !1)
        }
        insertBefore(n, e, t, o = !0) {
            this.delegate.insertBefore(n, e, t), this.engine.onInsert(this.namespaceId, e, n, o)
        }
        removeChild(n, e, t, o) {
            if (o) {
                this.delegate.removeChild(n, e, t, o);
                return
            }
            this.parentNode(e) && this.engine.onRemove(this.namespaceId, e, this.delegate)
        }
        selectRootElement(n, e) {
            return this.delegate.selectRootElement(n, e)
        }
        parentNode(n) {
            return this.delegate.parentNode(n)
        }
        nextSibling(n) {
            return this.delegate.nextSibling(n)
        }
        setAttribute(n, e, t, o) {
            this.delegate.setAttribute(n, e, t, o)
        }
        removeAttribute(n, e, t) {
            this.delegate.removeAttribute(n, e, t)
        }
        addClass(n, e) {
            this.delegate.addClass(n, e)
        }
        removeClass(n, e) {
            this.delegate.removeClass(n, e)
        }
        setStyle(n, e, t, o) {
            this.delegate.setStyle(n, e, t, o)
        }
        removeStyle(n, e, t) {
            this.delegate.removeStyle(n, e, t)
        }
        setProperty(n, e, t) {
            e.charAt(0) == $n && e == zp ? this.disableAnimations(n, !!t) : this.delegate.setProperty(n, e, t)
        }
        setValue(n, e) {
            this.delegate.setValue(n, e)
        }
        listen(n, e, t, o) {
            return this.delegate.listen(n, e, t, o)
        }
        disableAnimations(n, e) {
            this.engine.disableAnimations(n, e)
        }
    },
    Nr = class extends io {
        factory;
        constructor(n, e, t, o, r) {
            super(e, t, o, r), this.factory = n, this.namespaceId = e
        }
        setProperty(n, e, t) {
            e.charAt(0) == $n ? e.charAt(1) == "." && e == zp ? (t = t === void 0 ? !0 : !!t, this.disableAnimations(n, t)) : this.engine.process(this.namespaceId, n, e.slice(1), t) : this.delegate.setProperty(n, e, t)
        }
        listen(n, e, t, o) {
            if (e.charAt(0) == $n) {
                let r = Tm(n),
                    s = e.slice(1),
                    a = "";
                return s.charAt(0) != $n && ([s, a] = xm(s)), this.engine.listen(this.namespaceId, r, s, a, c => {
                    let d = c._data || -1;
                    this.factory.scheduleListenerCallback(d, t, c)
                })
            }
            return this.delegate.listen(n, e, t, o)
        }
    };

function Tm(i) {
    switch (i) {
        case "body":
            return document.body;
        case "document":
            return document;
        case "window":
            return window;
        default:
            return i
    }
}

function xm(i) {
    let n = i.indexOf("."),
        e = i.substring(0, n),
        t = i.slice(n + 1);
    return [e, t]
}
var no = class {
    delegate;
    engine;
    _zone;
    _currentId = 0;
    _microtaskId = 1;
    _animationCallbacksBuffer = [];
    _rendererCache = new Map;
    _cdRecurDepth = 0;
    constructor(n, e, t) {
        this.delegate = n, this.engine = e, this._zone = t, e.onRemovalComplete = (o, r) => {
            r ? .removeChild(null, o)
        }
    }
    createRenderer(n, e) {
        let o = this.delegate.createRenderer(n, e);
        if (!n || !e ? .data ? .animation) {
            let d = this._rendererCache,
                h = d.get(o);
            if (!h) {
                let y = () => d.delete(o);
                h = new io("", o, this.engine, y), d.set(o, h)
            }
            return h
        }
        let r = e.id,
            s = e.id + "-" + this._currentId;
        this._currentId++, this.engine.register(s, n);
        let a = d => {
            Array.isArray(d) ? d.forEach(a) : this.engine.registerTrigger(r, s, n, d.name, d)
        };
        return e.data.animation.forEach(a), new Nr(this, s, o, this.engine)
    }
    begin() {
        this._cdRecurDepth++, this.delegate.begin && this.delegate.begin()
    }
    _scheduleCountTask() {
        queueMicrotask(() => {
            this._microtaskId++
        })
    }
    scheduleListenerCallback(n, e, t) {
        if (n >= 0 && n < this._microtaskId) {
            this._zone.run(() => e(t));
            return
        }
        let o = this._animationCallbacksBuffer;
        o.length == 0 && queueMicrotask(() => {
            this._zone.run(() => {
                o.forEach(r => {
                    let [s, a] = r;
                    s(a)
                }), this._animationCallbacksBuffer = []
            })
        }), o.push([e, t])
    }
    end() {
        this._cdRecurDepth--, this._cdRecurDepth == 0 && this._zone.runOutsideAngular(() => {
            this._scheduleCountTask(), this.engine.flush(this._microtaskId)
        }), this.delegate.end && this.delegate.end()
    }
    whenRenderingDone() {
        return this.engine.whenRenderingDone()
    }
    componentReplaced(n) {
        this.engine.flush(), this.delegate.componentReplaced ? .(n)
    }
};
var km = (() => {
    class i extends bi {
        constructor(e, t, o) {
            super(e, t, o)
        }
        ngOnDestroy() {
            this.flush()
        }
        static\ u0275fac = function(t) {
            return new(t || i)(K(Ae), K(qt), K(Kt))
        };
        static\ u0275prov = A({
            token: i,
            factory: i.\u0275fac
        })
    }
    return i
})();

function Mm() {
    return new Qn
}

function Rm() {
    return new no(p(Nl), p(bi), p(f))
}
var Gp = [{
        provide: Kt,
        useFactory: Mm
    }, {
        provide: bi,
        useClass: km
    }, {
        provide: Ft,
        useFactory: Rm
    }],
    Am = [{
        provide: qt,
        useClass: Lr
    }, {
        provide: ko,
        useValue: "NoopAnimations"
    }, ...Gp],
    Up = [{
        provide: qt,
        useFactory: () => new to
    }, {
        provide: ko,
        useFactory: () => "BrowserAnimations"
    }, ...Gp],
    Hp = (() => {
        class i {
            static withConfig(e) {
                return {
                    ngModule: i,
                    providers: e.disableAnimations ? Am : Up
                }
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275mod = Ie({
                type: i
            });
            static\ u0275inj = Se({
                providers: Up,
                imports: [fn]
            })
        }
        return i
    })();
var Fr = "Service workers are disabled or not supported by this browser",
    yi = class {
        serviceWorker;
        worker;
        registration;
        events;
        constructor(n, e) {
            if (this.serviceWorker = n, !n) this.worker = this.events = this.registration = new wt(t => t.error(new q(5601, !1)));
            else {
                let t = null,
                    o = new Z;
                this.worker = new wt(d => (t !== null && d.next(t), o.subscribe(h => d.next(h))));
                let r = () => {
                    let {
                        controller: d
                    } = n;
                    d !== null && (t = d, o.next(t))
                };
                n.addEventListener("controllerchange", r), r(), this.registration = this.worker.pipe($e(() => n.getRegistration().then(d => {
                    if (!d) throw new q(5601, !1);
                    return d
                })));
                let s = new Z;
                this.events = s.asObservable();
                let a = d => {
                    let {
                        data: h
                    } = d;
                    h ? .type && s.next(h)
                };
                n.addEventListener("message", a), e ? .get(at, null, {
                    optional: !0
                }) ? .onDestroy(() => {
                    n.removeEventListener("controllerchange", r), n.removeEventListener("message", a)
                })
            }
        }
        postMessage(n, e) {
            return new Promise(t => {
                this.worker.pipe(st(1)).subscribe(o => {
                    o.postMessage(oe({
                        action: n
                    }, e)), t()
                })
            })
        }
        postMessageWithOperation(n, e, t) {
            let o = this.waitForOperationCompleted(t),
                r = this.postMessage(n, e);
            return Promise.all([r, o]).then(([, s]) => s)
        }
        generateNonce() {
            return Math.round(Math.random() * 1e7)
        }
        eventsOfType(n) {
            let e;
            return typeof n == "string" ? e = t => t.type === n : e = t => n.includes(t.type), this.events.pipe(ve(e))
        }
        nextEventOfType(n) {
            return this.eventsOfType(n).pipe(st(1))
        }
        waitForOperationCompleted(n) {
            return new Promise((e, t) => {
                this.eventsOfType("OPERATION_COMPLETED").pipe(ve(o => o.nonce === n), st(1), ze(o => {
                    if (o.result !== void 0) return o.result;
                    throw new Error(o.error)
                })).subscribe({
                    next: e,
                    error: t
                })
            })
        }
        get isEnabled() {
            return !!this.serviceWorker
        }
    },
    qp = (() => {
        class i {
            sw;
            messages;
            notificationClicks;
            notificationCloses;
            pushSubscriptionChanges;
            subscription;
            get isEnabled() {
                return this.sw.isEnabled
            }
            pushManager = null;
            subscriptionChanges = new Z;
            constructor(e) {
                if (this.sw = e, !e.isEnabled) {
                    this.messages = Tt, this.notificationClicks = Tt, this.notificationCloses = Tt, this.pushSubscriptionChanges = Tt, this.subscription = Tt;
                    return
                }
                this.messages = this.sw.eventsOfType("PUSH").pipe(ze(o => o.data)), this.notificationClicks = this.sw.eventsOfType("NOTIFICATION_CLICK").pipe(ze(o => o.data)), this.notificationCloses = this.sw.eventsOfType("NOTIFICATION_CLOSE").pipe(ze(o => o.data)), this.pushSubscriptionChanges = this.sw.eventsOfType("PUSH_SUBSCRIPTION_CHANGE").pipe(ze(o => o.data)), this.pushManager = this.sw.registration.pipe(ze(o => o.pushManager));
                let t = this.pushManager.pipe($e(o => o.getSubscription()));
                this.subscription = new wt(o => {
                    let r = t.subscribe(o),
                        s = this.subscriptionChanges.subscribe(o);
                    return () => {
                        r.unsubscribe(), s.unsubscribe()
                    }
                })
            }
            requestSubscription(e) {
                if (!this.sw.isEnabled || this.pushManager === null) return Promise.reject(new Error(Fr));
                let t = {
                        userVisibleOnly: !0
                    },
                    o = this.decodeBase64(e.serverPublicKey.replace(/_/g, "/").replace(/-/g, "+")),
                    r = new Uint8Array(new ArrayBuffer(o.length));
                for (let s = 0; s < o.length; s++) r[s] = o.charCodeAt(s);
                return t.applicationServerKey = r, new Promise((s, a) => {
                    this.pushManager.pipe($e(c => c.subscribe(t)), st(1)).subscribe({
                        next: c => {
                            this.subscriptionChanges.next(c), s(c)
                        },
                        error: a
                    })
                })
            }
            unsubscribe() {
                if (!this.sw.isEnabled) return Promise.reject(new Error(Fr));
                let e = t => {
                    if (t === null) throw new q(5602, !1);
                    return t.unsubscribe().then(o => {
                        if (!o) throw new q(5603, !1);
                        this.subscriptionChanges.next(null)
                    })
                };
                return new Promise((t, o) => {
                    this.subscription.pipe(st(1), $e(e)).subscribe({
                        next: t,
                        error: o
                    })
                })
            }
            decodeBase64(e) {
                return atob(e)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(K(yi))
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
        return i
    })(),
    oo = (() => {
        class i {
            sw;
            versionUpdates;
            unrecoverable;
            get isEnabled() {
                return this.sw.isEnabled
            }
            ongoingCheckForUpdate = null;
            constructor(e) {
                if (this.sw = e, !e.isEnabled) {
                    this.versionUpdates = Tt, this.unrecoverable = Tt;
                    return
                }
                this.versionUpdates = this.sw.eventsOfType(["VERSION_DETECTED", "VERSION_INSTALLATION_FAILED", "VERSION_READY", "NO_NEW_VERSION_DETECTED"]), this.unrecoverable = this.sw.eventsOfType("UNRECOVERABLE_STATE")
            }
            checkForUpdate() {
                if (!this.sw.isEnabled) return Promise.reject(new Error(Fr));
                if (this.ongoingCheckForUpdate) return this.ongoingCheckForUpdate;
                let e = this.sw.generateNonce();
                return this.ongoingCheckForUpdate = this.sw.postMessageWithOperation("CHECK_FOR_UPDATES", {
                    nonce: e
                }, e).finally(() => {
                    this.ongoingCheckForUpdate = null
                }), this.ongoingCheckForUpdate
            }
            activateUpdate() {
                if (!this.sw.isEnabled) return Promise.reject(new q(5601, !1));
                let e = this.sw.generateNonce();
                return this.sw.postMessageWithOperation("ACTIVATE_UPDATE", {
                    nonce: e
                }, e)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(K(yi))
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
        return i
    })(),
    Kp = new _e("");

function Om() {
    let i = p(Ui);
    if (!("serviceWorker" in navigator && i.enabled !== !1)) return;
    let n = p(Kp),
        e = p(f),
        t = p(at);
    e.runOutsideAngular(() => {
        let o = navigator.serviceWorker,
            r = () => o.controller ? .postMessage({
                action: "INITIALIZE"
            });
        o.addEventListener("controllerchange", r), t.onDestroy(() => {
            o.removeEventListener("controllerchange", r)
        })
    }), e.runOutsideAngular(() => {
        let o, {
            registrationStrategy: r
        } = i;
        if (typeof r == "function") o = new Promise(s => r().subscribe(() => s()));
        else {
            let [s, ...a] = (r || "registerWhenStable:30000").split(":");
            switch (s) {
                case "registerImmediately":
                    o = Promise.resolve();
                    break;
                case "registerWithDelay":
                    o = Wp(+a[0] || 0);
                    break;
                case "registerWhenStable":
                    o = Promise.race([t.whenStable(), Wp(+a[0])]);
                    break;
                default:
                    throw new q(5600, !1)
            }
        }
        o.then(() => {
            t.destroyed || navigator.serviceWorker.register(n, {
                scope: i.scope,
                updateViaCache: i.updateViaCache,
                type: i.type
            }).catch(s => console.error(hl(5604, !1)))
        })
    })
}

function Wp(i) {
    return new Promise(n => setTimeout(n, i))
}

function Nm() {
    let i = p(Ui),
        n = p(se),
        e = !0;
    return new yi(e && i.enabled !== !1 ? navigator.serviceWorker : void 0, n)
}
var Ui = class {
    enabled;
    updateViaCache;
    type;
    scope;
    registrationStrategy
};

function Lm(i, n = {}) {
    return ml([qp, oo, {
        provide: Kp,
        useValue: i
    }, {
        provide: Ui,
        useValue: n
    }, {
        provide: yi,
        useFactory: Nm
    }, sn(Om)])
}
var Br = (() => {
    class i {
        static register(e, t = {}) {
            return {
                ngModule: i,
                providers: [Lm(e, t)]
            }
        }
        static\ u0275fac = function(t) {
            return new(t || i)
        };
        static\ u0275mod = Ie({
            type: i
        });
        static\ u0275inj = Se({
            providers: [qp, oo]
        })
    }
    return i
})();
var ro = new WeakMap,
    $p = (() => {
        class i {
            _appRef;
            _injector = p(se);
            _environmentInjector = p(tt);
            load(e) {
                let t = this._appRef = this._appRef || this._injector.get(at),
                    o = ro.get(t);
                o || (o = {
                    loaders: new Set,
                    refs: []
                }, ro.set(t, o), t.onDestroy(() => {
                    ro.get(t) ? .refs.forEach(r => r.destroy()), ro.delete(t)
                })), o.loaders.has(e) || (o.loaders.add(e), o.refs.push(hn(e, {
                    environmentInjector: this._environmentInjector
                })))
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })();
var Vr;

function jm() {
    if (Vr == null) {
        let i = typeof document < "u" ? document.head : null;
        Vr = !!(i && (i.createShadowRoot || i.attachShadow))
    }
    return Vr
}

function so(i) {
    if (jm()) {
        let n = i.getRootNode ? i.getRootNode() : null;
        if (typeof ShadowRoot < "u" && ShadowRoot && n instanceof ShadowRoot) return n
    }
    return null
}

function Gi(i) {
    return i.composedPath ? i.composedPath()[0] : i.target
}

function Qp(i) {
    return i.buttons === 0 || i.detail === 0
}

function Zp(i) {
    let n = i.touches && i.touches[0] || i.changedTouches && i.changedTouches[0];
    return !!n && n.identifier === -1 && (n.radiusX == null || n.radiusX === 1) && (n.radiusY == null || n.radiusY === 1)
}

function Yp(i, n = 0) {
    return Fm(i) ? Number(i) : arguments.length === 2 ? n : 0
}

function Fm(i) {
    return !isNaN(parseFloat(i)) && !isNaN(Number(i))
}

function Ct(i) {
    return i instanceof g ? i.nativeElement : i
}
var zr;
try {
    zr = typeof Intl < "u" && Intl.v8BreakIterator
} catch (i) {
    zr = !1
}
var Xp = (() => {
    class i {
        _platformId = p(fl);
        isBrowser = this._platformId ? Ol(this._platformId) : typeof document == "object" && !!document;
        EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
        TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
        BLINK = this.isBrowser && !!(window.chrome || zr) && typeof CSS < "u" && !this.EDGE && !this.TRIDENT;
        WEBKIT = this.isBrowser && /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
        IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) && !("MSStream" in window);
        FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
        ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
        SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
        constructor() {}
        static\ u0275fac = function(t) {
            return new(t || i)
        };
        static\ u0275prov = A({
            token: i,
            factory: i.\u0275fac,
            providedIn: "root"
        })
    }
    return i
})();
var Bm = new _e("cdk-dir-doc", {
        providedIn: "root",
        factory: () => p(Ae)
    }),
    Vm = /^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;

function zm(i) {
    let n = i ? .toLowerCase() || "";
    return n === "auto" && typeof navigator < "u" && navigator ? .language ? Vm.test(navigator.language) ? "rtl" : "ltr" : n === "rtl" ? "rtl" : "ltr"
}
var Jp = (() => {
    class i {
        get value() {
            return this.valueSignal()
        }
        valueSignal = ne("ltr");
        change = new pe;
        constructor() {
            let e = p(Bm, {
                optional: !0
            });
            if (e) {
                let t = e.body ? e.body.dir : null,
                    o = e.documentElement ? e.documentElement.dir : null;
                this.valueSignal.set(zm(t || o || "ltr"))
            }
        }
        ngOnDestroy() {
            this.change.complete()
        }
        static\ u0275fac = function(t) {
            return new(t || i)
        };
        static\ u0275prov = A({
            token: i,
            factory: i.\u0275fac,
            providedIn: "root"
        })
    }
    return i
})();
var Um = 20,
    Ur = (() => {
        class i {
            _platform = p(Xp);
            _listeners;
            _viewportSize = null;
            _change = new Z;
            _document = p(Ae);
            constructor() {
                let e = p(f),
                    t = p(Ft).createRenderer(null, null);
                e.runOutsideAngular(() => {
                    if (this._platform.isBrowser) {
                        let o = r => this._change.next(r);
                        this._listeners = [t.listen("window", "resize", o), t.listen("window", "orientationchange", o)]
                    }
                    this.change().subscribe(() => this._viewportSize = null)
                })
            }
            ngOnDestroy() {
                this._listeners ? .forEach(e => e()), this._change.complete()
            }
            getViewportSize() {
                this._viewportSize || this._updateViewportSize();
                let e = {
                    width: this._viewportSize.width,
                    height: this._viewportSize.height
                };
                return this._platform.isBrowser || (this._viewportSize = null), e
            }
            getViewportRect() {
                let e = this.getViewportScrollPosition(),
                    {
                        width: t,
                        height: o
                    } = this.getViewportSize();
                return {
                    top: e.top,
                    left: e.left,
                    bottom: e.top + o,
                    right: e.left + t,
                    height: o,
                    width: t
                }
            }
            getViewportScrollPosition() {
                if (!this._platform.isBrowser) return {
                    top: 0,
                    left: 0
                };
                let e = this._document,
                    t = this._getWindow(),
                    o = e.documentElement,
                    r = o.getBoundingClientRect(),
                    s = -r.top || e.body ? .scrollTop || t.scrollY || o.scrollTop || 0,
                    a = -r.left || e.body ? .scrollLeft || t.scrollX || o.scrollLeft || 0;
                return {
                    top: s,
                    left: a
                }
            }
            change(e = Um) {
                return e > 0 ? this._change.pipe(pl(e)) : this._change
            }
            _getWindow() {
                return this._document.defaultView || window
            }
            _updateViewportSize() {
                let e = this._getWindow();
                this._viewportSize = this._platform.isBrowser ? {
                    width: e.innerWidth,
                    height: e.innerHeight
                } : {
                    width: 0,
                    height: 0
                }
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })();
var eu = (() => {
    class i {
        static\ u0275fac = function(t) {
            return new(t || i)
        };
        static\ u0275mod = Ie({
            type: i
        });
        static\ u0275inj = Se({})
    }
    return i
})();

function Wr(i) {
    let n = i.cloneNode(!0),
        e = n.querySelectorAll("[id]"),
        t = i.nodeName.toLowerCase();
    n.removeAttribute("id");
    for (let o = 0; o < e.length; o++) e[o].removeAttribute("id");
    return t === "canvas" ? nu(i, n) : (t === "input" || t === "select" || t === "textarea") && iu(i, n), tu("canvas", i, n, nu), tu("input, textarea, select", i, n, iu), n
}

function tu(i, n, e, t) {
    let o = n.querySelectorAll(i);
    if (o.length) {
        let r = e.querySelectorAll(i);
        for (let s = 0; s < o.length; s++) t(o[s], r[s])
    }
}
var Gm = 0;

function iu(i, n) {
    n.type !== "file" && (n.value = i.value), n.type === "radio" && n.name && (n.name = `mat-clone-${n.name}-${Gm++}`)
}

function nu(i, n) {
    let e = n.getContext("2d");
    if (e) try {
        e.drawImage(i, 0, 0)
    } catch (t) {}
}

function Yr(i) {
    let n = i.getBoundingClientRect();
    return {
        top: n.top,
        right: n.right,
        bottom: n.bottom,
        left: n.left,
        width: n.width,
        height: n.height,
        x: n.x,
        y: n.y
    }
}

function qr(i, n, e) {
    let {
        top: t,
        bottom: o,
        left: r,
        right: s
    } = i;
    return e >= t && e <= o && n >= r && n <= s
}

function Hm(i, n) {
    let e = n.left < i.left,
        t = n.left + n.width > i.right,
        o = n.top < i.top,
        r = n.top + n.height > i.bottom;
    return e || t || o || r
}

function qi(i, n, e) {
    i.top += n, i.bottom = i.top + i.height, i.left += e, i.right = i.left + i.width
}

function ou(i, n, e, t) {
    let {
        top: o,
        right: r,
        bottom: s,
        left: a,
        width: c,
        height: d
    } = i, h = c * n, y = d * n;
    return t > o - y && t < s + y && e > a - h && e < r + h
}
var ao = class {
    _document;
    positions = new Map;
    constructor(n) {
        this._document = n
    }
    clear() {
        this.positions.clear()
    }
    cache(n) {
        this.clear(), this.positions.set(this._document, {
            scrollPosition: this.getViewportScrollPosition()
        }), n.forEach(e => {
            this.positions.set(e, {
                scrollPosition: {
                    top: e.scrollTop,
                    left: e.scrollLeft
                },
                clientRect: Yr(e)
            })
        })
    }
    handleScroll(n) {
        let e = Gi(n),
            t = this.positions.get(e);
        if (!t) return null;
        let o = t.scrollPosition,
            r, s;
        if (e === this._document) {
            let d = this.getViewportScrollPosition();
            r = d.top, s = d.left
        } else r = e.scrollTop, s = e.scrollLeft;
        let a = o.top - r,
            c = o.left - s;
        return this.positions.forEach((d, h) => {
            d.clientRect && e !== h && e.contains(h) && qi(d.clientRect, a, c)
        }), o.top = r, o.left = s, {
            top: a,
            left: c
        }
    }
    getViewportScrollPosition() {
        return {
            top: window.scrollY,
            left: window.scrollX
        }
    }
};

function gu(i, n) {
    let e = i.rootNodes;
    if (e.length === 1 && e[0].nodeType === n.ELEMENT_NODE) return e[0];
    let t = n.createElement("div");
    return e.forEach(o => t.appendChild(o)), t
}

function Xr(i, n, e) {
    for (let t in n)
        if (n.hasOwnProperty(t)) {
            let o = n[t];
            o ? i.setProperty(t, o, e ? .has(t) ? "important" : "") : i.removeProperty(t)
        }
    return i
}

function Ci(i, n) {
    let e = n ? "" : "none";
    Xr(i.style, {
        "touch-action": n ? "" : "none",
        "-webkit-user-drag": n ? "" : "none",
        "-webkit-tap-highlight-color": n ? "" : "transparent",
        "user-select": e,
        "-ms-user-select": e,
        "-webkit-user-select": e,
        "-moz-user-select": e
    })
}

function ru(i, n, e) {
    Xr(i.style, {
        position: n ? "" : "fixed",
        top: n ? "" : "0",
        opacity: n ? "" : "0",
        left: n ? "" : "-999em"
    }, e)
}

function lo(i, n) {
    return n && n != "none" ? i + " " + n : i
}

function su(i, n) {
    i.style.width = `${n.width}px`, i.style.height = `${n.height}px`, i.style.transform = Ki(n.left, n.top)
}

function Ki(i, n) {
    return `translate3d(${Math.round(i)}px, ${Math.round(n)}px, 0)`
}
var Hi = {
        capture: !0
    },
    Gr = {
        passive: !1,
        capture: !0
    },
    Wm = (() => {
        class i {
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ng-component"]
                ],
                hostAttrs: ["cdk-drag-resets-container", ""],
                decls: 0,
                vars: 0,
                template: function(t, o) {},
                styles: [`@layer cdk-resets {
  .cdk-drag-preview {
    background: none;
    border: none;
    padding: 0;
    color: inherit;
    inset: auto;
  }
}
.cdk-drag-placeholder *,
.cdk-drag-preview * {
  pointer-events: none !important;
}
`],
                encapsulation: 2,
                changeDetection: 0
            })
        }
        return i
    })(),
    Jr = (() => {
        class i {
            _ngZone = p(f);
            _document = p(Ae);
            _styleLoader = p($p);
            _renderer = p(Ft).createRenderer(null, null);
            _cleanupDocumentTouchmove;
            _scroll = new Z;
            _dropInstances = new Set;
            _dragInstances = new Set;
            _activeDragInstances = ne([]);
            _globalListeners;
            _draggingPredicate = e => e.isDragging();
            _domNodesToDirectives = null;
            pointerMove = new Z;
            pointerUp = new Z;
            constructor() {}
            registerDropContainer(e) {
                this._dropInstances.has(e) || this._dropInstances.add(e)
            }
            registerDragItem(e) {
                this._dragInstances.add(e), this._dragInstances.size === 1 && this._ngZone.runOutsideAngular(() => {
                    this._cleanupDocumentTouchmove ? .(), this._cleanupDocumentTouchmove = this._renderer.listen(this._document, "touchmove", this._persistentTouchmoveListener, Gr)
                })
            }
            removeDropContainer(e) {
                this._dropInstances.delete(e)
            }
            removeDragItem(e) {
                this._dragInstances.delete(e), this.stopDragging(e), this._dragInstances.size === 0 && this._cleanupDocumentTouchmove ? .()
            }
            startDragging(e, t) {
                if (!(this._activeDragInstances().indexOf(e) > -1) && (this._styleLoader.load(Wm), this._activeDragInstances.update(o => [...o, e]), this._activeDragInstances().length === 1)) {
                    let o = t.type.startsWith("touch"),
                        r = a => this.pointerUp.next(a),
                        s = [
                            ["scroll", a => this._scroll.next(a), Hi],
                            ["selectstart", this._preventDefaultWhileDragging, Gr]
                        ];
                    o ? s.push(["touchend", r, Hi], ["touchcancel", r, Hi]) : s.push(["mouseup", r, Hi]), o || s.push(["mousemove", a => this.pointerMove.next(a), Gr]), this._ngZone.runOutsideAngular(() => {
                        this._globalListeners = s.map(([a, c, d]) => this._renderer.listen(this._document, a, c, d))
                    })
                }
            }
            stopDragging(e) {
                this._activeDragInstances.update(t => {
                    let o = t.indexOf(e);
                    return o > -1 ? (t.splice(o, 1), [...t]) : t
                }), this._activeDragInstances().length === 0 && this._clearGlobalListeners()
            }
            isDragging(e) {
                return this._activeDragInstances().indexOf(e) > -1
            }
            scrolled(e) {
                let t = [this._scroll];
                return e && e !== this._document && t.push(new wt(o => this._ngZone.runOutsideAngular(() => {
                    let r = this._renderer.listen(e, "scroll", s => {
                        this._activeDragInstances().length && o.next(s)
                    }, Hi);
                    return () => {
                        r()
                    }
                }))), To(...t)
            }
            registerDirectiveNode(e, t) {
                this._domNodesToDirectives ? ? = new WeakMap, this._domNodesToDirectives.set(e, t)
            }
            removeDirectiveNode(e) {
                this._domNodesToDirectives ? .delete(e)
            }
            getDragDirectiveForNode(e) {
                return this._domNodesToDirectives ? .get(e) || null
            }
            ngOnDestroy() {
                this._dragInstances.forEach(e => this.removeDragItem(e)), this._dropInstances.forEach(e => this.removeDropContainer(e)), this._domNodesToDirectives = null, this._clearGlobalListeners(), this.pointerMove.complete(), this.pointerUp.complete()
            }
            _preventDefaultWhileDragging = e => {
                this._activeDragInstances().length > 0 && e.preventDefault()
            };
            _persistentTouchmoveListener = e => {
                this._activeDragInstances().length > 0 && (this._activeDragInstances().some(this._draggingPredicate) && e.preventDefault(), this.pointerMove.next(e))
            };
            _clearGlobalListeners() {
                this._globalListeners ? .forEach(e => e()), this._globalListeners = void 0
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })();

function au(i) {
    let n = i.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3;
    return parseFloat(i) * n
}

function qm(i) {
    let n = getComputedStyle(i),
        e = Hr(n, "transition-property"),
        t = e.find(a => a === "transform" || a === "all");
    if (!t) return 0;
    let o = e.indexOf(t),
        r = Hr(n, "transition-duration"),
        s = Hr(n, "transition-delay");
    return au(r[o]) + au(s[o])
}

function Hr(i, n) {
    return i.getPropertyValue(n).split(",").map(t => t.trim())
}
var Km = new Set(["position"]),
    Kr = class {
        _document;
        _rootElement;
        _direction;
        _initialDomRect;
        _previewTemplate;
        _previewClass;
        _pickupPositionOnPage;
        _initialTransform;
        _zIndex;
        _renderer;
        _previewEmbeddedView = null;
        _preview;
        get element() {
            return this._preview
        }
        constructor(n, e, t, o, r, s, a, c, d, h) {
            this._document = n, this._rootElement = e, this._direction = t, this._initialDomRect = o, this._previewTemplate = r, this._previewClass = s, this._pickupPositionOnPage = a, this._initialTransform = c, this._zIndex = d, this._renderer = h
        }
        attach(n) {
            this._preview = this._createPreview(), n.appendChild(this._preview), lu(this._preview) && this._preview.showPopover()
        }
        destroy() {
            this._preview.remove(), this._previewEmbeddedView ? .destroy(), this._preview = this._previewEmbeddedView = null
        }
        setTransform(n) {
            this._preview.style.transform = n
        }
        getBoundingClientRect() {
            return this._preview.getBoundingClientRect()
        }
        addClass(n) {
            this._preview.classList.add(n)
        }
        getTransitionDuration() {
            return qm(this._preview)
        }
        addEventListener(n, e) {
            return this._renderer.listen(this._preview, n, e)
        }
        _createPreview() {
            let n = this._previewTemplate,
                e = this._previewClass,
                t = n ? n.template : null,
                o;
            if (t && n) {
                let r = n.matchSize ? this._initialDomRect : null,
                    s = n.viewContainer.createEmbeddedView(t, n.context);
                s.detectChanges(), o = gu(s, this._document), this._previewEmbeddedView = s, n.matchSize ? su(o, r) : o.style.transform = Ki(this._pickupPositionOnPage.x, this._pickupPositionOnPage.y)
            } else o = Wr(this._rootElement), su(o, this._initialDomRect), this._initialTransform && (o.style.transform = this._initialTransform);
            return Xr(o.style, {
                "pointer-events": "none",
                margin: lu(o) ? "0 auto 0 0" : "0",
                position: "fixed",
                top: "0",
                left: "0",
                "z-index": this._zIndex + ""
            }, Km), Ci(o, !1), o.classList.add("cdk-drag-preview"), o.setAttribute("popover", "manual"), o.setAttribute("dir", this._direction), e && (Array.isArray(e) ? e.forEach(r => o.classList.add(r)) : o.classList.add(e)), o
        }
    };

function lu(i) {
    return "showPopover" in i
}
var $m = {
        passive: !0
    },
    cu = {
        passive: !1
    },
    Qm = {
        passive: !1,
        capture: !0
    },
    Zm = 800,
    du = "cdk-drag-placeholder",
    pu = new Set(["position"]);

function vu(i, n, e = {
    dragStartThreshold: 5,
    pointerDirectionChangeThreshold: 5
}) {
    let t = i.get(xi, null, {
        optional: !0
    }) || i.get(Ft).createRenderer(null, null);
    return new $r(n, e, i.get(Ae), i.get(f), i.get(Ur), i.get(Jr), t)
}
var $r = class {
    _config;
    _document;
    _ngZone;
    _viewportRuler;
    _dragDropRegistry;
    _renderer;
    _rootElementCleanups;
    _cleanupShadowRootSelectStart;
    _preview = null;
    _previewContainer;
    _placeholderRef = null;
    _placeholder;
    _pickupPositionInElement;
    _pickupPositionOnPage;
    _marker;
    _anchor = null;
    _passiveTransform = {
        x: 0,
        y: 0
    };
    _activeTransform = {
        x: 0,
        y: 0
    };
    _initialTransform;
    _hasStartedDragging = ne(!1);
    _hasMoved = !1;
    _initialContainer;
    _initialIndex;
    _parentPositions;
    _moveEvents = new Z;
    _pointerDirectionDelta;
    _pointerPositionAtLastDirectionChange;
    _lastKnownPointerPosition;
    _rootElement;
    _ownerSVGElement = null;
    _rootElementTapHighlight;
    _pointerMoveSubscription = jt.EMPTY;
    _pointerUpSubscription = jt.EMPTY;
    _scrollSubscription = jt.EMPTY;
    _resizeSubscription = jt.EMPTY;
    _lastTouchEventTime;
    _dragStartTime;
    _boundaryElement = null;
    _nativeInteractionsEnabled = !0;
    _initialDomRect;
    _previewRect;
    _boundaryRect;
    _previewTemplate;
    _placeholderTemplate;
    _handles = [];
    _disabledHandles = new Set;
    _dropContainer;
    _direction = "ltr";
    _parentDragRef = null;
    _cachedShadowRoot;
    lockAxis = null;
    dragStartDelay = 0;
    previewClass;
    scale = 1;
    get disabled() {
        return this._disabled || !!(this._dropContainer && this._dropContainer.disabled)
    }
    set disabled(n) {
        n !== this._disabled && (this._disabled = n, this._toggleNativeDragInteractions(), this._handles.forEach(e => Ci(e, n)))
    }
    _disabled = !1;
    beforeStarted = new Z;
    started = new Z;
    released = new Z;
    ended = new Z;
    entered = new Z;
    exited = new Z;
    dropped = new Z;
    moved = this._moveEvents;
    data;
    constrainPosition;
    constructor(n, e, t, o, r, s, a) {
        this._config = e, this._document = t, this._ngZone = o, this._viewportRuler = r, this._dragDropRegistry = s, this._renderer = a, this.withRootElement(n).withParent(e.parentDragRef || null), this._parentPositions = new ao(t), s.registerDragItem(this)
    }
    getPlaceholderElement() {
        return this._placeholder
    }
    getRootElement() {
        return this._rootElement
    }
    getVisibleElement() {
        return this.isDragging() ? this.getPlaceholderElement() : this.getRootElement()
    }
    withHandles(n) {
        this._handles = n.map(t => Ct(t)), this._handles.forEach(t => Ci(t, this.disabled)), this._toggleNativeDragInteractions();
        let e = new Set;
        return this._disabledHandles.forEach(t => {
            this._handles.indexOf(t) > -1 && e.add(t)
        }), this._disabledHandles = e, this
    }
    withPreviewTemplate(n) {
        return this._previewTemplate = n, this
    }
    withPlaceholderTemplate(n) {
        return this._placeholderTemplate = n, this
    }
    withRootElement(n) {
        let e = Ct(n);
        if (e !== this._rootElement) {
            this._removeRootElementListeners();
            let t = this._renderer;
            this._rootElementCleanups = this._ngZone.runOutsideAngular(() => [t.listen(e, "mousedown", this._pointerDown, cu), t.listen(e, "touchstart", this._pointerDown, $m), t.listen(e, "dragstart", this._nativeDragStart, cu)]), this._initialTransform = void 0, this._rootElement = e
        }
        return typeof SVGElement < "u" && this._rootElement instanceof SVGElement && (this._ownerSVGElement = this._rootElement.ownerSVGElement), this
    }
    withBoundaryElement(n) {
        return this._boundaryElement = n ? Ct(n) : null, this._resizeSubscription.unsubscribe(), n && (this._resizeSubscription = this._viewportRuler.change(10).subscribe(() => this._containInsideBoundaryOnResize())), this
    }
    withParent(n) {
        return this._parentDragRef = n, this
    }
    dispose() {
        this._removeRootElementListeners(), this.isDragging() && this._rootElement ? .remove(), this._marker ? .remove(), this._destroyPreview(), this._destroyPlaceholder(), this._dragDropRegistry.removeDragItem(this), this._removeListeners(), this.beforeStarted.complete(), this.started.complete(), this.released.complete(), this.ended.complete(), this.entered.complete(), this.exited.complete(), this.dropped.complete(), this._moveEvents.complete(), this._handles = [], this._disabledHandles.clear(), this._dropContainer = void 0, this._resizeSubscription.unsubscribe(), this._parentPositions.clear(), this._boundaryElement = this._rootElement = this._ownerSVGElement = this._placeholderTemplate = this._previewTemplate = this._marker = this._parentDragRef = null
    }
    isDragging() {
        return this._hasStartedDragging() && this._dragDropRegistry.isDragging(this)
    }
    reset() {
        this._rootElement.style.transform = this._initialTransform || "", this._activeTransform = {
            x: 0,
            y: 0
        }, this._passiveTransform = {
            x: 0,
            y: 0
        }
    }
    resetToBoundary() {
        if (this._boundaryElement && this._rootElement && Hm(this._boundaryElement.getBoundingClientRect(), this._rootElement.getBoundingClientRect())) {
            let n = this._boundaryElement.getBoundingClientRect(),
                e = this._rootElement.getBoundingClientRect(),
                t = 0,
                o = 0;
            e.left < n.left ? t = n.left - e.left : e.right > n.right && (t = n.right - e.right), e.top < n.top ? o = n.top - e.top : e.bottom > n.bottom && (o = n.bottom - e.bottom);
            let r = this._activeTransform.x,
                s = this._activeTransform.y,
                a = r + t,
                c = s + o;
            this._rootElement.style.transform = Ki(a, c), this._activeTransform = {
                x: a,
                y: c
            }, this._passiveTransform = {
                x: a,
                y: c
            }
        }
    }
    disableHandle(n) {
        !this._disabledHandles.has(n) && this._handles.indexOf(n) > -1 && (this._disabledHandles.add(n), Ci(n, !0))
    }
    enableHandle(n) {
        this._disabledHandles.has(n) && (this._disabledHandles.delete(n), Ci(n, this.disabled))
    }
    withDirection(n) {
        return this._direction = n, this
    }
    _withDropContainer(n) {
        this._dropContainer = n
    }
    getFreeDragPosition() {
        let n = this.isDragging() ? this._activeTransform : this._passiveTransform;
        return {
            x: n.x,
            y: n.y
        }
    }
    setFreeDragPosition(n) {
        return this._activeTransform = {
            x: 0,
            y: 0
        }, this._passiveTransform.x = n.x, this._passiveTransform.y = n.y, this._dropContainer || this._applyRootElementTransform(n.x, n.y), this
    }
    withPreviewContainer(n) {
        return this._previewContainer = n, this
    }
    _sortFromLastPointerPosition() {
        let n = this._lastKnownPointerPosition;
        n && this._dropContainer && this._updateActiveDropContainer(this._getConstrainedPointerPosition(n), n)
    }
    _removeListeners() {
        this._pointerMoveSubscription.unsubscribe(), this._pointerUpSubscription.unsubscribe(), this._scrollSubscription.unsubscribe(), this._cleanupShadowRootSelectStart ? .(), this._cleanupShadowRootSelectStart = void 0
    }
    _destroyPreview() {
        this._preview ? .destroy(), this._preview = null
    }
    _destroyPlaceholder() {
        this._anchor ? .remove(), this._placeholder ? .remove(), this._placeholderRef ? .destroy(), this._placeholder = this._anchor = this._placeholderRef = null
    }
    _pointerDown = n => {
        if (this.beforeStarted.next(), this._handles.length) {
            let e = this._getTargetHandle(n);
            e && !this._disabledHandles.has(e) && !this.disabled && this._initializeDragSequence(e, n)
        } else this.disabled || this._initializeDragSequence(this._rootElement, n)
    };
    _pointerMove = n => {
        let e = this._getPointerPositionOnPage(n);
        if (!this._hasStartedDragging()) {
            let o = Math.abs(e.x - this._pickupPositionOnPage.x),
                r = Math.abs(e.y - this._pickupPositionOnPage.y);
            if (o + r >= this._config.dragStartThreshold) {
                let a = Date.now() >= this._dragStartTime + this._getDragStartDelay(n),
                    c = this._dropContainer;
                if (!a) {
                    this._endDragSequence(n);
                    return
                }(!c || !c.isDragging() && !c.isReceiving()) && (n.cancelable && n.preventDefault(), this._hasStartedDragging.set(!0), this._ngZone.run(() => this._startDragSequence(n)))
            }
            return
        }
        n.cancelable && n.preventDefault();
        let t = this._getConstrainedPointerPosition(e);
        if (this._hasMoved = !0, this._lastKnownPointerPosition = e, this._updatePointerDirectionDelta(t), this._dropContainer) this._updateActiveDropContainer(t, e);
        else {
            let o = this.constrainPosition ? this._initialDomRect : this._pickupPositionOnPage,
                r = this._activeTransform;
            r.x = t.x - o.x + this._passiveTransform.x, r.y = t.y - o.y + this._passiveTransform.y, this._applyRootElementTransform(r.x, r.y)
        }
        this._moveEvents.observers.length && this._ngZone.run(() => {
            this._moveEvents.next({
                source: this,
                pointerPosition: t,
                event: n,
                distance: this._getDragDistance(t),
                delta: this._pointerDirectionDelta
            })
        })
    };
    _pointerUp = n => {
        this._endDragSequence(n)
    };
    _endDragSequence(n) {
        if (this._dragDropRegistry.isDragging(this) && (this._removeListeners(), this._dragDropRegistry.stopDragging(this), this._toggleNativeDragInteractions(), this._handles && (this._rootElement.style.webkitTapHighlightColor = this._rootElementTapHighlight), !!this._hasStartedDragging()))
            if (this.released.next({
                    source: this,
                    event: n
                }), this._dropContainer) this._dropContainer._stopScrolling(), this._animatePreviewToPlaceholder().then(() => {
                this._cleanupDragArtifacts(n), this._cleanupCachedDimensions(), this._dragDropRegistry.stopDragging(this)
            });
            else {
                this._passiveTransform.x = this._activeTransform.x;
                let e = this._getPointerPositionOnPage(n);
                this._passiveTransform.y = this._activeTransform.y, this._ngZone.run(() => {
                    this.ended.next({
                        source: this,
                        distance: this._getDragDistance(e),
                        dropPoint: e,
                        event: n
                    })
                }), this._cleanupCachedDimensions(), this._dragDropRegistry.stopDragging(this)
            }
    }
    _startDragSequence(n) {
        Wi(n) && (this._lastTouchEventTime = Date.now()), this._toggleNativeDragInteractions();
        let e = this._getShadowRoot(),
            t = this._dropContainer;
        if (e && this._ngZone.runOutsideAngular(() => {
                this._cleanupShadowRootSelectStart = this._renderer.listen(e, "selectstart", Ym, Qm)
            }), t) {
            let o = this._rootElement,
                r = o.parentNode,
                s = this._placeholder = this._createPlaceholderElement(),
                a = this._marker = this._marker || this._document.createComment("");
            r.insertBefore(a, o), this._initialTransform = o.style.transform || "", this._preview = new Kr(this._document, this._rootElement, this._direction, this._initialDomRect, this._previewTemplate || null, this.previewClass || null, this._pickupPositionOnPage, this._initialTransform, this._config.zIndex || 1e3, this._renderer), this._preview.attach(this._getPreviewInsertionPoint(r, e)), ru(o, !1, pu), this._document.body.appendChild(r.replaceChild(s, o)), this.started.next({
                source: this,
                event: n
            }), t.start(), this._initialContainer = t, this._initialIndex = t.getItemIndex(this)
        } else this.started.next({
            source: this,
            event: n
        }), this._initialContainer = this._initialIndex = void 0;
        this._parentPositions.cache(t ? t.getScrollableParents() : [])
    }
    _initializeDragSequence(n, e) {
        this._parentDragRef && e.stopPropagation();
        let t = this.isDragging(),
            o = Wi(e),
            r = !o && e.button !== 0,
            s = this._rootElement,
            a = Gi(e),
            c = !o && this._lastTouchEventTime && this._lastTouchEventTime + Zm > Date.now(),
            d = o ? Zp(e) : Qp(e);
        if (a && a.draggable && e.type === "mousedown" && e.preventDefault(), t || r || c || d) return;
        if (this._handles.length) {
            let O = s.style;
            this._rootElementTapHighlight = O.webkitTapHighlightColor || "", O.webkitTapHighlightColor = "transparent"
        }
        this._hasMoved = !1, this._hasStartedDragging.set(this._hasMoved), this._removeListeners(), this._initialDomRect = this._rootElement.getBoundingClientRect(), this._pointerMoveSubscription = this._dragDropRegistry.pointerMove.subscribe(this._pointerMove), this._pointerUpSubscription = this._dragDropRegistry.pointerUp.subscribe(this._pointerUp), this._scrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(O => this._updateOnScroll(O)), this._boundaryElement && (this._boundaryRect = Yr(this._boundaryElement));
        let h = this._previewTemplate;
        this._pickupPositionInElement = h && h.template && !h.matchSize ? {
            x: 0,
            y: 0
        } : this._getPointerPositionInElement(this._initialDomRect, n, e);
        let y = this._pickupPositionOnPage = this._lastKnownPointerPosition = this._getPointerPositionOnPage(e);
        this._pointerDirectionDelta = {
            x: 0,
            y: 0
        }, this._pointerPositionAtLastDirectionChange = {
            x: y.x,
            y: y.y
        }, this._dragStartTime = Date.now(), this._dragDropRegistry.startDragging(this, e)
    }
    _cleanupDragArtifacts(n) {
        ru(this._rootElement, !0, pu), this._marker.parentNode.replaceChild(this._rootElement, this._marker), this._destroyPreview(), this._destroyPlaceholder(), this._initialDomRect = this._boundaryRect = this._previewRect = this._initialTransform = void 0, this._ngZone.run(() => {
            let e = this._dropContainer,
                t = e.getItemIndex(this),
                o = this._getPointerPositionOnPage(n),
                r = this._getDragDistance(o),
                s = e._isOverContainer(o.x, o.y);
            this.ended.next({
                source: this,
                distance: r,
                dropPoint: o,
                event: n
            }), this.dropped.next({
                item: this,
                currentIndex: t,
                previousIndex: this._initialIndex,
                container: e,
                previousContainer: this._initialContainer,
                isPointerOverContainer: s,
                distance: r,
                dropPoint: o,
                event: n
            }), e.drop(this, t, this._initialIndex, this._initialContainer, s, r, o, n), this._dropContainer = this._initialContainer
        })
    }
    _updateActiveDropContainer({
        x: n,
        y: e
    }, {
        x: t,
        y: o
    }) {
        let r = this._initialContainer._getSiblingContainerFromPosition(this, n, e);
        !r && this._dropContainer !== this._initialContainer && this._initialContainer._isOverContainer(n, e) && (r = this._initialContainer), r && r !== this._dropContainer && this._ngZone.run(() => {
            let s = this._dropContainer.getItemIndex(this),
                a = this._dropContainer.getItemAtIndex(s + 1) ? .getVisibleElement() || null;
            this.exited.next({
                item: this,
                container: this._dropContainer
            }), this._dropContainer.exit(this), this._conditionallyInsertAnchor(r, this._dropContainer, a), this._dropContainer = r, this._dropContainer.enter(this, n, e, r === this._initialContainer && r.sortingDisabled ? this._initialIndex : void 0), this.entered.next({
                item: this,
                container: r,
                currentIndex: r.getItemIndex(this)
            })
        }), this.isDragging() && (this._dropContainer._startScrollingIfNecessary(t, o), this._dropContainer._sortItem(this, n, e, this._pointerDirectionDelta), this.constrainPosition ? this._applyPreviewTransform(n, e) : this._applyPreviewTransform(n - this._pickupPositionInElement.x, e - this._pickupPositionInElement.y))
    }
    _animatePreviewToPlaceholder() {
        if (!this._hasMoved) return Promise.resolve();
        let n = this._placeholder.getBoundingClientRect();
        this._preview.addClass("cdk-drag-animating"), this._applyPreviewTransform(n.left, n.top);
        let e = this._preview.getTransitionDuration();
        return e === 0 ? Promise.resolve() : this._ngZone.runOutsideAngular(() => new Promise(t => {
            let o = a => {
                    (!a || this._preview && Gi(a) === this._preview.element && a.propertyName === "transform") && (s(), t(), clearTimeout(r))
                },
                r = setTimeout(o, e * 1.5),
                s = this._preview.addEventListener("transitionend", o)
        }))
    }
    _createPlaceholderElement() {
        let n = this._placeholderTemplate,
            e = n ? n.template : null,
            t;
        return e ? (this._placeholderRef = n.viewContainer.createEmbeddedView(e, n.context), this._placeholderRef.detectChanges(), t = gu(this._placeholderRef, this._document)) : t = Wr(this._rootElement), t.style.pointerEvents = "none", t.classList.add(du), t
    }
    _getPointerPositionInElement(n, e, t) {
        let o = e === this._rootElement ? null : e,
            r = o ? o.getBoundingClientRect() : n,
            s = Wi(t) ? t.targetTouches[0] : t,
            a = this._getViewportScrollPosition(),
            c = s.pageX - r.left - a.left,
            d = s.pageY - r.top - a.top;
        return {
            x: r.left - n.left + c,
            y: r.top - n.top + d
        }
    }
    _getPointerPositionOnPage(n) {
        let e = this._getViewportScrollPosition(),
            t = Wi(n) ? n.touches[0] || n.changedTouches[0] || {
                pageX: 0,
                pageY: 0
            } : n,
            o = t.pageX - e.left,
            r = t.pageY - e.top;
        if (this._ownerSVGElement) {
            let s = this._ownerSVGElement.getScreenCTM();
            if (s) {
                let a = this._ownerSVGElement.createSVGPoint();
                return a.x = o, a.y = r, a.matrixTransform(s.inverse())
            }
        }
        return {
            x: o,
            y: r
        }
    }
    _getConstrainedPointerPosition(n) {
        let e = this._dropContainer ? this._dropContainer.lockAxis : null,
            {
                x: t,
                y: o
            } = this.constrainPosition ? this.constrainPosition(n, this, this._initialDomRect, this._pickupPositionInElement) : n;
        if (this.lockAxis === "x" || e === "x" ? o = this._pickupPositionOnPage.y - (this.constrainPosition ? this._pickupPositionInElement.y : 0) : (this.lockAxis === "y" || e === "y") && (t = this._pickupPositionOnPage.x - (this.constrainPosition ? this._pickupPositionInElement.x : 0)), this._boundaryRect) {
            let {
                x: r,
                y: s
            } = this.constrainPosition ? {
                x: 0,
                y: 0
            } : this._pickupPositionInElement, a = this._boundaryRect, {
                width: c,
                height: d
            } = this._getPreviewRect(), h = a.top + s, y = a.bottom - (d - s), O = a.left + r, B = a.right - (c - r);
            t = uu(t, O, B), o = uu(o, h, y)
        }
        return {
            x: t,
            y: o
        }
    }
    _updatePointerDirectionDelta(n) {
        let {
            x: e,
            y: t
        } = n, o = this._pointerDirectionDelta, r = this._pointerPositionAtLastDirectionChange, s = Math.abs(e - r.x), a = Math.abs(t - r.y);
        return s > this._config.pointerDirectionChangeThreshold && (o.x = e > r.x ? 1 : -1, r.x = e), a > this._config.pointerDirectionChangeThreshold && (o.y = t > r.y ? 1 : -1, r.y = t), o
    }
    _toggleNativeDragInteractions() {
        if (!this._rootElement || !this._handles) return;
        let n = this._handles.length > 0 || !this.isDragging();
        n !== this._nativeInteractionsEnabled && (this._nativeInteractionsEnabled = n, Ci(this._rootElement, n))
    }
    _removeRootElementListeners() {
        this._rootElementCleanups ? .forEach(n => n()), this._rootElementCleanups = void 0
    }
    _applyRootElementTransform(n, e) {
        let t = 1 / this.scale,
            o = Ki(n * t, e * t),
            r = this._rootElement.style;
        this._initialTransform == null && (this._initialTransform = r.transform && r.transform != "none" ? r.transform : ""), r.transform = lo(o, this._initialTransform)
    }
    _applyPreviewTransform(n, e) {
        let t = this._previewTemplate ? .template ? void 0 : this._initialTransform,
            o = Ki(n, e);
        this._preview.setTransform(lo(o, t))
    }
    _getDragDistance(n) {
        let e = this._pickupPositionOnPage;
        return e ? {
            x: n.x - e.x,
            y: n.y - e.y
        } : {
            x: 0,
            y: 0
        }
    }
    _cleanupCachedDimensions() {
        this._boundaryRect = this._previewRect = void 0, this._parentPositions.clear()
    }
    _containInsideBoundaryOnResize() {
        let {
            x: n,
            y: e
        } = this._passiveTransform;
        if (n === 0 && e === 0 || this.isDragging() || !this._boundaryElement) return;
        let t = this._rootElement.getBoundingClientRect(),
            o = this._boundaryElement.getBoundingClientRect();
        if (o.width === 0 && o.height === 0 || t.width === 0 && t.height === 0) return;
        let r = o.left - t.left,
            s = t.right - o.right,
            a = o.top - t.top,
            c = t.bottom - o.bottom;
        o.width > t.width ? (r > 0 && (n += r), s > 0 && (n -= s)) : n = 0, o.height > t.height ? (a > 0 && (e += a), c > 0 && (e -= c)) : e = 0, (n !== this._passiveTransform.x || e !== this._passiveTransform.y) && this.setFreeDragPosition({
            y: e,
            x: n
        })
    }
    _getDragStartDelay(n) {
        let e = this.dragStartDelay;
        return typeof e == "number" ? e : Wi(n) ? e.touch : e ? e.mouse : 0
    }
    _updateOnScroll(n) {
        let e = this._parentPositions.handleScroll(n);
        if (e) {
            let t = Gi(n);
            this._boundaryRect && t !== this._boundaryElement && t.contains(this._boundaryElement) && qi(this._boundaryRect, e.top, e.left), this._pickupPositionOnPage.x += e.left, this._pickupPositionOnPage.y += e.top, this._dropContainer || (this._activeTransform.x -= e.left, this._activeTransform.y -= e.top, this._applyRootElementTransform(this._activeTransform.x, this._activeTransform.y))
        }
    }
    _getViewportScrollPosition() {
        return this._parentPositions.positions.get(this._document) ? .scrollPosition || this._parentPositions.getViewportScrollPosition()
    }
    _getShadowRoot() {
        return this._cachedShadowRoot === void 0 && (this._cachedShadowRoot = so(this._rootElement)), this._cachedShadowRoot
    }
    _getPreviewInsertionPoint(n, e) {
        let t = this._previewContainer || "global";
        if (t === "parent") return n;
        if (t === "global") {
            let o = this._document;
            return e || o.fullscreenElement || o.webkitFullscreenElement || o.mozFullScreenElement || o.msFullscreenElement || o.body
        }
        return Ct(t)
    }
    _getPreviewRect() {
        return (!this._previewRect || !this._previewRect.width && !this._previewRect.height) && (this._previewRect = this._preview ? this._preview.getBoundingClientRect() : this._initialDomRect), this._previewRect
    }
    _nativeDragStart = n => {
        if (this._handles.length) {
            let e = this._getTargetHandle(n);
            e && !this._disabledHandles.has(e) && !this.disabled && n.preventDefault()
        } else this.disabled || n.preventDefault()
    };
    _getTargetHandle(n) {
        return this._handles.find(e => n.target && (n.target === e || e.contains(n.target)))
    }
    _conditionallyInsertAnchor(n, e, t) {
        if (n === this._initialContainer) this._anchor ? .remove(), this._anchor = null;
        else if (e === this._initialContainer && e.hasAnchor) {
            let o = this._anchor ? ? = Wr(this._placeholder);
            o.classList.remove(du), o.classList.add("cdk-drag-anchor"), o.style.transform = "", t ? t.before(o) : Ct(e.element).appendChild(o)
        }
    }
};

function uu(i, n, e) {
    return Math.max(n, Math.min(e, i))
}

function Wi(i) {
    return i.type[0] === "t"
}

function Ym(i) {
    i.preventDefault()
}

function _u(i, n, e) {
    let t = hu(n, i.length - 1),
        o = hu(e, i.length - 1);
    if (t === o) return;
    let r = i[t],
        s = o < t ? -1 : 1;
    for (let a = t; a !== o; a += s) i[a] = i[a + s];
    i[o] = r
}

function hu(i, n) {
    return Math.max(0, Math.min(n, i))
}
var co = class {
        _dragDropRegistry;
        _element;
        _sortPredicate;
        _itemPositions = [];
        _activeDraggables;
        orientation = "vertical";
        direction = "ltr";
        constructor(n) {
            this._dragDropRegistry = n
        }
        _previousSwap = {
            drag: null,
            delta: 0,
            overlaps: !1
        };
        start(n) {
            this.withItems(n)
        }
        sort(n, e, t, o) {
            let r = this._itemPositions,
                s = this._getItemIndexFromPointerPosition(n, e, t, o);
            if (s === -1 && r.length > 0) return null;
            let a = this.orientation === "horizontal",
                c = r.findIndex(H => H.drag === n),
                d = r[s],
                h = r[c].clientRect,
                y = d.clientRect,
                O = c > s ? 1 : -1,
                B = this._getItemOffsetPx(h, y, O),
                R = this._getSiblingOffsetPx(c, r, O),
                N = r.slice();
            return _u(r, c, s), r.forEach((H, ie) => {
                if (N[ie] === H) return;
                let ce = H.drag === n,
                    he = ce ? B : R,
                    ae = ce ? n.getPlaceholderElement() : H.drag.getRootElement();
                H.offset += he;
                let qe = Math.round(H.offset * (1 / H.drag.scale));
                a ? (ae.style.transform = lo(`translate3d(${qe}px, 0, 0)`, H.initialTransform), qi(H.clientRect, 0, he)) : (ae.style.transform = lo(`translate3d(0, ${qe}px, 0)`, H.initialTransform), qi(H.clientRect, he, 0))
            }), this._previousSwap.overlaps = qr(y, e, t), this._previousSwap.drag = d.drag, this._previousSwap.delta = a ? o.x : o.y, {
                previousIndex: c,
                currentIndex: s
            }
        }
        enter(n, e, t, o) {
            let r = this._activeDraggables,
                s = r.indexOf(n),
                a = n.getPlaceholderElement();
            s > -1 && r.splice(s, 1);
            let c = o == null || o < 0 ? this._getItemIndexFromPointerPosition(n, e, t) : o,
                d = r[c];
            if (d === n && (d = r[c + 1]), !d && (c == null || c === -1 || c < r.length - 1) && this._shouldEnterAsFirstChild(e, t) && (d = r[0]), d && !this._dragDropRegistry.isDragging(d)) {
                let h = d.getRootElement();
                h.parentElement.insertBefore(a, h), r.splice(c, 0, n)
            } else this._element.appendChild(a), r.push(n);
            a.style.transform = "", this._cacheItemPositions()
        }
        withItems(n) {
            this._activeDraggables = n.slice(), this._cacheItemPositions()
        }
        withSortPredicate(n) {
            this._sortPredicate = n
        }
        reset() {
            this._activeDraggables ? .forEach(n => {
                let e = n.getRootElement();
                if (e) {
                    let t = this._itemPositions.find(o => o.drag === n) ? .initialTransform;
                    e.style.transform = t || ""
                }
            }), this._itemPositions = [], this._activeDraggables = [], this._previousSwap.drag = null, this._previousSwap.delta = 0, this._previousSwap.overlaps = !1
        }
        getActiveItemsSnapshot() {
            return this._activeDraggables
        }
        getItemIndex(n) {
            return this._getVisualItemPositions().findIndex(e => e.drag === n)
        }
        getItemAtIndex(n) {
            return this._getVisualItemPositions()[n] ? .drag || null
        }
        updateOnScroll(n, e) {
            this._itemPositions.forEach(({
                clientRect: t
            }) => {
                qi(t, n, e)
            }), this._itemPositions.forEach(({
                drag: t
            }) => {
                this._dragDropRegistry.isDragging(t) && t._sortFromLastPointerPosition()
            })
        }
        withElementContainer(n) {
            this._element = n
        }
        _cacheItemPositions() {
            let n = this.orientation === "horizontal";
            this._itemPositions = this._activeDraggables.map(e => {
                let t = e.getVisibleElement();
                return {
                    drag: e,
                    offset: 0,
                    initialTransform: t.style.transform || "",
                    clientRect: Yr(t)
                }
            }).sort((e, t) => n ? e.clientRect.left - t.clientRect.left : e.clientRect.top - t.clientRect.top)
        }
        _getVisualItemPositions() {
            return this.orientation === "horizontal" && this.direction === "rtl" ? this._itemPositions.slice().reverse() : this._itemPositions
        }
        _getItemOffsetPx(n, e, t) {
            let o = this.orientation === "horizontal",
                r = o ? e.left - n.left : e.top - n.top;
            return t === -1 && (r += o ? e.width - n.width : e.height - n.height), r
        }
        _getSiblingOffsetPx(n, e, t) {
            let o = this.orientation === "horizontal",
                r = e[n].clientRect,
                s = e[n + t * -1],
                a = r[o ? "width" : "height"] * t;
            if (s) {
                let c = o ? "left" : "top",
                    d = o ? "right" : "bottom";
                t === -1 ? a -= s.clientRect[c] - r[d] : a += r[c] - s.clientRect[d]
            }
            return a
        }
        _shouldEnterAsFirstChild(n, e) {
            if (!this._activeDraggables.length) return !1;
            let t = this._itemPositions,
                o = this.orientation === "horizontal";
            if (t[0].drag !== this._activeDraggables[0]) {
                let s = t[t.length - 1].clientRect;
                return o ? n >= s.right : e >= s.bottom
            } else {
                let s = t[0].clientRect;
                return o ? n <= s.left : e <= s.top
            }
        }
        _getItemIndexFromPointerPosition(n, e, t, o) {
            let r = this.orientation === "horizontal",
                s = this._itemPositions.findIndex(({
                    drag: a,
                    clientRect: c
                }) => {
                    if (a === n) return !1;
                    if (o) {
                        let d = r ? o.x : o.y;
                        if (a === this._previousSwap.drag && this._previousSwap.overlaps && d === this._previousSwap.delta) return !1
                    }
                    return r ? e >= Math.floor(c.left) && e < Math.floor(c.right) : t >= Math.floor(c.top) && t < Math.floor(c.bottom)
                });
            return s === -1 || !this._sortPredicate(s, n) ? -1 : s
        }
    },
    Qr = class {
        _document;
        _dragDropRegistry;
        _element;
        _sortPredicate;
        _rootNode;
        _activeItems;
        _previousSwap = {
            drag: null,
            deltaX: 0,
            deltaY: 0,
            overlaps: !1
        };
        _relatedNodes = [];
        constructor(n, e) {
            this._document = n, this._dragDropRegistry = e
        }
        start(n) {
            let e = this._element.childNodes;
            this._relatedNodes = [];
            for (let t = 0; t < e.length; t++) {
                let o = e[t];
                this._relatedNodes.push([o, o.nextSibling])
            }
            this.withItems(n)
        }
        sort(n, e, t, o) {
            let r = this._getItemIndexFromPointerPosition(n, e, t),
                s = this._previousSwap;
            if (r === -1 || this._activeItems[r] === n) return null;
            let a = this._activeItems[r];
            if (s.drag === a && s.overlaps && s.deltaX === o.x && s.deltaY === o.y) return null;
            let c = this.getItemIndex(n),
                d = n.getPlaceholderElement(),
                h = a.getRootElement();
            r > c ? h.after(d) : h.before(d), _u(this._activeItems, c, r);
            let y = this._getRootNode().elementFromPoint(e, t);
            return s.deltaX = o.x, s.deltaY = o.y, s.drag = a, s.overlaps = h === y || h.contains(y), {
                previousIndex: c,
                currentIndex: r
            }
        }
        enter(n, e, t, o) {
            let r = this._activeItems.indexOf(n);
            r > -1 && this._activeItems.splice(r, 1);
            let s = o == null || o < 0 ? this._getItemIndexFromPointerPosition(n, e, t) : o;
            s === -1 && (s = this._getClosestItemIndexToPointer(n, e, t));
            let a = this._activeItems[s];
            a && !this._dragDropRegistry.isDragging(a) ? (this._activeItems.splice(s, 0, n), a.getRootElement().before(n.getPlaceholderElement())) : (this._activeItems.push(n), this._element.appendChild(n.getPlaceholderElement()))
        }
        withItems(n) {
            this._activeItems = n.slice()
        }
        withSortPredicate(n) {
            this._sortPredicate = n
        }
        reset() {
            let n = this._element,
                e = this._previousSwap;
            for (let t = this._relatedNodes.length - 1; t > -1; t--) {
                let [o, r] = this._relatedNodes[t];
                o.parentNode === n && o.nextSibling !== r && (r === null ? n.appendChild(o) : r.parentNode === n && n.insertBefore(o, r))
            }
            this._relatedNodes = [], this._activeItems = [], e.drag = null, e.deltaX = e.deltaY = 0, e.overlaps = !1
        }
        getActiveItemsSnapshot() {
            return this._activeItems
        }
        getItemIndex(n) {
            return this._activeItems.indexOf(n)
        }
        getItemAtIndex(n) {
            return this._activeItems[n] || null
        }
        updateOnScroll() {
            this._activeItems.forEach(n => {
                this._dragDropRegistry.isDragging(n) && n._sortFromLastPointerPosition()
            })
        }
        withElementContainer(n) {
            n !== this._element && (this._element = n, this._rootNode = void 0)
        }
        _getItemIndexFromPointerPosition(n, e, t) {
            let o = this._getRootNode().elementFromPoint(Math.floor(e), Math.floor(t)),
                r = o ? this._activeItems.findIndex(s => {
                    let a = s.getRootElement();
                    return o === a || a.contains(o)
                }) : -1;
            return r === -1 || !this._sortPredicate(r, n) ? -1 : r
        }
        _getRootNode() {
            return this._rootNode || (this._rootNode = so(this._element) || this._document), this._rootNode
        }
        _getClosestItemIndexToPointer(n, e, t) {
            if (this._activeItems.length === 0) return -1;
            if (this._activeItems.length === 1) return 0;
            let o = 1 / 0,
                r = -1;
            for (let s = 0; s < this._activeItems.length; s++) {
                let a = this._activeItems[s];
                if (a !== n) {
                    let {
                        x: c,
                        y: d
                    } = a.getRootElement().getBoundingClientRect(), h = Math.hypot(e - c, t - d);
                    h < o && (o = h, r = s)
                }
            }
            return r
        }
    },
    mu = .05,
    bu = .05,
    et = (function(i) {
        return i[i.NONE = 0] = "NONE", i[i.UP = 1] = "UP", i[i.DOWN = 2] = "DOWN", i
    })(et || {}),
    Me = (function(i) {
        return i[i.NONE = 0] = "NONE", i[i.LEFT = 1] = "LEFT", i[i.RIGHT = 2] = "RIGHT", i
    })(Me || {});

function Xm(i, n) {
    return new Zr(n, i.get(Jr), i.get(Ae), i.get(f), i.get(Ur))
}
var Zr = class {
    _dragDropRegistry;
    _ngZone;
    _viewportRuler;
    element;
    disabled = !1;
    sortingDisabled = !1;
    lockAxis = null;
    autoScrollDisabled = !1;
    autoScrollStep = 2;
    hasAnchor = !1;
    enterPredicate = () => !0;
    sortPredicate = () => !0;
    beforeStarted = new Z;
    entered = new Z;
    exited = new Z;
    dropped = new Z;
    sorted = new Z;
    receivingStarted = new Z;
    receivingStopped = new Z;
    data;
    _container;
    _isDragging = !1;
    _parentPositions;
    _sortStrategy;
    _domRect;
    _draggables = [];
    _siblings = [];
    _activeSiblings = new Set;
    _viewportScrollSubscription = jt.EMPTY;
    _verticalScrollDirection = et.NONE;
    _horizontalScrollDirection = Me.NONE;
    _scrollNode;
    _stopScrollTimers = new Z;
    _cachedShadowRoot = null;
    _document;
    _scrollableElements = [];
    _initialScrollSnap;
    _direction = "ltr";
    constructor(n, e, t, o, r) {
        this._dragDropRegistry = e, this._ngZone = o, this._viewportRuler = r;
        let s = this.element = Ct(n);
        this._document = t, this.withOrientation("vertical").withElementContainer(s), e.registerDropContainer(this), this._parentPositions = new ao(t)
    }
    dispose() {
        this._stopScrolling(), this._stopScrollTimers.complete(), this._viewportScrollSubscription.unsubscribe(), this.beforeStarted.complete(), this.entered.complete(), this.exited.complete(), this.dropped.complete(), this.sorted.complete(), this.receivingStarted.complete(), this.receivingStopped.complete(), this._activeSiblings.clear(), this._scrollNode = null, this._parentPositions.clear(), this._dragDropRegistry.removeDropContainer(this)
    }
    isDragging() {
        return this._isDragging
    }
    start() {
        this._draggingStarted(), this._notifyReceivingSiblings()
    }
    enter(n, e, t, o) {
        this._draggingStarted(), o == null && this.sortingDisabled && (o = this._draggables.indexOf(n)), this._sortStrategy.enter(n, e, t, o), this._cacheParentPositions(), this._notifyReceivingSiblings(), this.entered.next({
            item: n,
            container: this,
            currentIndex: this.getItemIndex(n)
        })
    }
    exit(n) {
        this._reset(), this.exited.next({
            item: n,
            container: this
        })
    }
    drop(n, e, t, o, r, s, a, c = {}) {
        this._reset(), this.dropped.next({
            item: n,
            currentIndex: e,
            previousIndex: t,
            container: this,
            previousContainer: o,
            isPointerOverContainer: r,
            distance: s,
            dropPoint: a,
            event: c
        })
    }
    withItems(n) {
        let e = this._draggables;
        return this._draggables = n, n.forEach(t => t._withDropContainer(this)), this.isDragging() && (e.filter(o => o.isDragging()).every(o => n.indexOf(o) === -1) ? this._reset() : this._sortStrategy.withItems(this._draggables)), this
    }
    withDirection(n) {
        return this._direction = n, this._sortStrategy instanceof co && (this._sortStrategy.direction = n), this
    }
    connectedTo(n) {
        return this._siblings = n.slice(), this
    }
    withOrientation(n) {
        if (n === "mixed") this._sortStrategy = new Qr(this._document, this._dragDropRegistry);
        else {
            let e = new co(this._dragDropRegistry);
            e.direction = this._direction, e.orientation = n, this._sortStrategy = e
        }
        return this._sortStrategy.withElementContainer(this._container), this._sortStrategy.withSortPredicate((e, t) => this.sortPredicate(e, t, this)), this
    }
    withScrollableParents(n) {
        let e = this._container;
        return this._scrollableElements = n.indexOf(e) === -1 ? [e, ...n] : n.slice(), this
    }
    withElementContainer(n) {
        if (n === this._container) return this;
        let e = Ct(this.element),
            t = this._scrollableElements.indexOf(this._container),
            o = this._scrollableElements.indexOf(n);
        return t > -1 && this._scrollableElements.splice(t, 1), o > -1 && this._scrollableElements.splice(o, 1), this._sortStrategy && this._sortStrategy.withElementContainer(n), this._cachedShadowRoot = null, this._scrollableElements.unshift(n), this._container = n, this
    }
    getScrollableParents() {
        return this._scrollableElements
    }
    getItemIndex(n) {
        return this._isDragging ? this._sortStrategy.getItemIndex(n) : this._draggables.indexOf(n)
    }
    getItemAtIndex(n) {
        return this._isDragging ? this._sortStrategy.getItemAtIndex(n) : this._draggables[n] || null
    }
    isReceiving() {
        return this._activeSiblings.size > 0
    }
    _sortItem(n, e, t, o) {
        if (this.sortingDisabled || !this._domRect || !ou(this._domRect, mu, e, t)) return;
        let r = this._sortStrategy.sort(n, e, t, o);
        r && this.sorted.next({
            previousIndex: r.previousIndex,
            currentIndex: r.currentIndex,
            container: this,
            item: n
        })
    }
    _startScrollingIfNecessary(n, e) {
        if (this.autoScrollDisabled) return;
        let t, o = et.NONE,
            r = Me.NONE;
        if (this._parentPositions.positions.forEach((s, a) => {
                a === this._document || !s.clientRect || t || ou(s.clientRect, mu, n, e) && ([o, r] = Jm(a, s.clientRect, this._direction, n, e), (o || r) && (t = a))
            }), !o && !r) {
            let {
                width: s,
                height: a
            } = this._viewportRuler.getViewportSize(), c = {
                width: s,
                height: a,
                top: 0,
                right: s,
                bottom: a,
                left: 0
            };
            o = yu(c, e), r = Cu(c, n), t = window
        }
        t && (o !== this._verticalScrollDirection || r !== this._horizontalScrollDirection || t !== this._scrollNode) && (this._verticalScrollDirection = o, this._horizontalScrollDirection = r, this._scrollNode = t, (o || r) && t ? this._ngZone.runOutsideAngular(this._startScrollInterval) : this._stopScrolling())
    }
    _stopScrolling() {
        this._stopScrollTimers.next()
    }
    _draggingStarted() {
        let n = this._container.style;
        this.beforeStarted.next(), this._isDragging = !0, this._initialScrollSnap = n.msScrollSnapType || n.scrollSnapType || "", n.scrollSnapType = n.msScrollSnapType = "none", this._sortStrategy.start(this._draggables), this._cacheParentPositions(), this._viewportScrollSubscription.unsubscribe(), this._listenToScrollEvents()
    }
    _cacheParentPositions() {
        this._parentPositions.cache(this._scrollableElements), this._domRect = this._parentPositions.positions.get(this._container).clientRect
    }
    _reset() {
        this._isDragging = !1;
        let n = this._container.style;
        n.scrollSnapType = n.msScrollSnapType = this._initialScrollSnap, this._siblings.forEach(e => e._stopReceiving(this)), this._sortStrategy.reset(), this._stopScrolling(), this._viewportScrollSubscription.unsubscribe(), this._parentPositions.clear()
    }
    _startScrollInterval = () => {
        this._stopScrolling(), dl(0, Eo).pipe(Ei(this._stopScrollTimers)).subscribe(() => {
            let n = this._scrollNode,
                e = this.autoScrollStep;
            this._verticalScrollDirection === et.UP ? n.scrollBy(0, -e) : this._verticalScrollDirection === et.DOWN && n.scrollBy(0, e), this._horizontalScrollDirection === Me.LEFT ? n.scrollBy(-e, 0) : this._horizontalScrollDirection === Me.RIGHT && n.scrollBy(e, 0)
        })
    };
    _isOverContainer(n, e) {
        return this._domRect != null && qr(this._domRect, n, e)
    }
    _getSiblingContainerFromPosition(n, e, t) {
        return this._siblings.find(o => o._canReceive(n, e, t))
    }
    _canReceive(n, e, t) {
        if (!this._domRect || !qr(this._domRect, e, t) || !this.enterPredicate(n, this)) return !1;
        let o = this._getShadowRoot().elementFromPoint(e, t);
        return o ? o === this._container || this._container.contains(o) : !1
    }
    _startReceiving(n, e) {
        let t = this._activeSiblings;
        !t.has(n) && e.every(o => this.enterPredicate(o, this) || this._draggables.indexOf(o) > -1) && (t.add(n), this._cacheParentPositions(), this._listenToScrollEvents(), this.receivingStarted.next({
            initiator: n,
            receiver: this,
            items: e
        }))
    }
    _stopReceiving(n) {
        this._activeSiblings.delete(n), this._viewportScrollSubscription.unsubscribe(), this.receivingStopped.next({
            initiator: n,
            receiver: this
        })
    }
    _listenToScrollEvents() {
        this._viewportScrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(n => {
            if (this.isDragging()) {
                let e = this._parentPositions.handleScroll(n);
                e && this._sortStrategy.updateOnScroll(e.top, e.left)
            } else this.isReceiving() && this._cacheParentPositions()
        })
    }
    _getShadowRoot() {
        if (!this._cachedShadowRoot) {
            let n = so(this._container);
            this._cachedShadowRoot = n || this._document
        }
        return this._cachedShadowRoot
    }
    _notifyReceivingSiblings() {
        let n = this._sortStrategy.getActiveItemsSnapshot().filter(e => e.isDragging());
        this._siblings.forEach(e => e._startReceiving(this, n))
    }
};

function yu(i, n) {
    let {
        top: e,
        bottom: t,
        height: o
    } = i, r = o * bu;
    return n >= e - r && n <= e + r ? et.UP : n >= t - r && n <= t + r ? et.DOWN : et.NONE
}

function Cu(i, n) {
    let {
        left: e,
        right: t,
        width: o
    } = i, r = o * bu;
    return n >= e - r && n <= e + r ? Me.LEFT : n >= t - r && n <= t + r ? Me.RIGHT : Me.NONE
}

function Jm(i, n, e, t, o) {
    let r = yu(n, o),
        s = Cu(n, t),
        a = et.NONE,
        c = Me.NONE;
    if (r) {
        let d = i.scrollTop;
        r === et.UP ? d > 0 && (a = et.UP) : i.scrollHeight - d > i.clientHeight && (a = et.DOWN)
    }
    if (s) {
        let d = i.scrollLeft;
        e === "rtl" ? s === Me.RIGHT ? d < 0 && (c = Me.RIGHT) : i.scrollWidth + d > i.clientWidth && (c = Me.LEFT) : s === Me.LEFT ? d > 0 && (c = Me.LEFT) : i.scrollWidth - d > i.clientWidth && (c = Me.RIGHT)
    }
    return [a, c]
}
var ef = (() => {
        class i {
            _injector = p(se);
            constructor() {}
            createDrag(e, t) {
                return vu(this._injector, e, t)
            }
            createDropList(e) {
                return Xm(this._injector, e)
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })(),
    fu = new _e("CDK_DRAG_PARENT");
var tf = new _e("CdkDragHandle");
var nf = new _e("CDK_DRAG_CONFIG"),
    of = new _e("CdkDropList"),
    Su = (() => {
        class i {
            element = p(g);
            dropContainer = p( of , {
                optional: !0,
                skipSelf: !0
            });
            _ngZone = p(f);
            _viewContainerRef = p(Bt);
            _dir = p(Jp, {
                optional: !0
            });
            _changeDetectorRef = p(C);
            _selfHandle = p(tf, {
                optional: !0,
                self: !0
            });
            _parentDrag = p(fu, {
                optional: !0,
                skipSelf: !0
            });
            _dragDropRegistry = p(Jr);
            _destroyed = new Z;
            _handles = new Et([]);
            _previewTemplate = null;
            _placeholderTemplate = null;
            _dragRef;
            data;
            lockAxis = null;
            rootElementSelector;
            boundaryElement;
            dragStartDelay;
            freeDragPosition;
            get disabled() {
                return this._disabled || !!(this.dropContainer && this.dropContainer.disabled)
            }
            set disabled(e) {
                this._disabled = e, this._dragRef.disabled = this._disabled
            }
            _disabled = !1;
            constrainPosition;
            previewClass;
            previewContainer;
            scale = 1;
            started = new pe;
            released = new pe;
            ended = new pe;
            entered = new pe;
            exited = new pe;
            dropped = new pe;
            moved = new wt(e => {
                let t = this._dragRef.moved.pipe(ze(o => ({
                    source: this,
                    pointerPosition: o.pointerPosition,
                    event: o.event,
                    delta: o.delta,
                    distance: o.distance
                }))).subscribe(e);
                return () => {
                    t.unsubscribe()
                }
            });
            _injector = p(se);
            constructor() {
                let e = this.dropContainer,
                    t = p(nf, {
                        optional: !0
                    });
                this._dragRef = vu(this._injector, this.element, {
                    dragStartThreshold: t && t.dragStartThreshold != null ? t.dragStartThreshold : 5,
                    pointerDirectionChangeThreshold: t && t.pointerDirectionChangeThreshold != null ? t.pointerDirectionChangeThreshold : 5,
                    zIndex: t ? .zIndex
                }), this._dragRef.data = this, this._dragDropRegistry.registerDirectiveNode(this.element.nativeElement, this), t && this._assignDefaults(t), e && (e.addItem(this), e._dropListRef.beforeStarted.pipe(Ei(this._destroyed)).subscribe(() => {
                    this._dragRef.scale = this.scale
                })), this._syncInputs(this._dragRef), this._handleEvents(this._dragRef)
            }
            getPlaceholderElement() {
                return this._dragRef.getPlaceholderElement()
            }
            getRootElement() {
                return this._dragRef.getRootElement()
            }
            reset() {
                this._dragRef.reset()
            }
            resetToBoundary() {
                this._dragRef.resetToBoundary()
            }
            getFreeDragPosition() {
                return this._dragRef.getFreeDragPosition()
            }
            setFreeDragPosition(e) {
                this._dragRef.setFreeDragPosition(e)
            }
            ngAfterViewInit() {
                Mo(() => {
                    this._updateRootElement(), this._setupHandlesListener(), this._dragRef.scale = this.scale, this.freeDragPosition && this._dragRef.setFreeDragPosition(this.freeDragPosition)
                }, {
                    injector: this._injector
                })
            }
            ngOnChanges(e) {
                let t = e.rootElementSelector,
                    o = e.freeDragPosition;
                t && !t.firstChange && this._updateRootElement(), this._dragRef.scale = this.scale, o && !o.firstChange && this.freeDragPosition && this._dragRef.setFreeDragPosition(this.freeDragPosition)
            }
            ngOnDestroy() {
                this.dropContainer && this.dropContainer.removeItem(this), this._dragDropRegistry.removeDirectiveNode(this.element.nativeElement), this._ngZone.runOutsideAngular(() => {
                    this._handles.complete(), this._destroyed.next(), this._destroyed.complete(), this._dragRef.dispose()
                })
            }
            _addHandle(e) {
                let t = this._handles.getValue();
                t.push(e), this._handles.next(t)
            }
            _removeHandle(e) {
                let t = this._handles.getValue(),
                    o = t.indexOf(e);
                o > -1 && (t.splice(o, 1), this._handles.next(t))
            }
            _setPreviewTemplate(e) {
                this._previewTemplate = e
            }
            _resetPreviewTemplate(e) {
                e === this._previewTemplate && (this._previewTemplate = null)
            }
            _setPlaceholderTemplate(e) {
                this._placeholderTemplate = e
            }
            _resetPlaceholderTemplate(e) {
                e === this._placeholderTemplate && (this._placeholderTemplate = null)
            }
            _updateRootElement() {
                let e = this.element.nativeElement,
                    t = e;
                this.rootElementSelector && (t = e.closest !== void 0 ? e.closest(this.rootElementSelector) : e.parentElement ? .closest(this.rootElementSelector)), this._dragRef.withRootElement(t || e)
            }
            _getBoundaryElement() {
                let e = this.boundaryElement;
                return e ? typeof e == "string" ? this.element.nativeElement.closest(e) : Ct(e) : null
            }
            _syncInputs(e) {
                e.beforeStarted.subscribe(() => {
                    if (!e.isDragging()) {
                        let t = this._dir,
                            o = this.dragStartDelay,
                            r = this._placeholderTemplate ? {
                                template: this._placeholderTemplate.templateRef,
                                context: this._placeholderTemplate.data,
                                viewContainer: this._viewContainerRef
                            } : null,
                            s = this._previewTemplate ? {
                                template: this._previewTemplate.templateRef,
                                context: this._previewTemplate.data,
                                matchSize: this._previewTemplate.matchSize,
                                viewContainer: this._viewContainerRef
                            } : null;
                        e.disabled = this.disabled, e.lockAxis = this.lockAxis, e.scale = this.scale, e.dragStartDelay = typeof o == "object" && o ? o : Yp(o), e.constrainPosition = this.constrainPosition, e.previewClass = this.previewClass, e.withBoundaryElement(this._getBoundaryElement()).withPlaceholderTemplate(r).withPreviewTemplate(s).withPreviewContainer(this.previewContainer || "global"), t && e.withDirection(t.value)
                    }
                }), e.beforeStarted.pipe(st(1)).subscribe(() => {
                    if (this._parentDrag) {
                        e.withParent(this._parentDrag._dragRef);
                        return
                    }
                    let t = this.element.nativeElement.parentElement;
                    for (; t;) {
                        let o = this._dragDropRegistry.getDragDirectiveForNode(t);
                        if (o) {
                            e.withParent(o._dragRef);
                            break
                        }
                        t = t.parentElement
                    }
                })
            }
            _handleEvents(e) {
                e.started.subscribe(t => {
                    this.started.emit({
                        source: this,
                        event: t.event
                    }), this._changeDetectorRef.markForCheck()
                }), e.released.subscribe(t => {
                    this.released.emit({
                        source: this,
                        event: t.event
                    })
                }), e.ended.subscribe(t => {
                    this.ended.emit({
                        source: this,
                        distance: t.distance,
                        dropPoint: t.dropPoint,
                        event: t.event
                    }), this._changeDetectorRef.markForCheck()
                }), e.entered.subscribe(t => {
                    this.entered.emit({
                        container: t.container.data,
                        item: this,
                        currentIndex: t.currentIndex
                    })
                }), e.exited.subscribe(t => {
                    this.exited.emit({
                        container: t.container.data,
                        item: this
                    })
                }), e.dropped.subscribe(t => {
                    this.dropped.emit({
                        previousIndex: t.previousIndex,
                        currentIndex: t.currentIndex,
                        previousContainer: t.previousContainer.data,
                        container: t.container.data,
                        isPointerOverContainer: t.isPointerOverContainer,
                        item: this,
                        distance: t.distance,
                        dropPoint: t.dropPoint,
                        event: t.event
                    })
                })
            }
            _assignDefaults(e) {
                let {
                    lockAxis: t,
                    dragStartDelay: o,
                    constrainPosition: r,
                    previewClass: s,
                    boundaryElement: a,
                    draggingDisabled: c,
                    rootElementSelector: d,
                    previewContainer: h
                } = e;
                this.disabled = c ? ? !1, this.dragStartDelay = o || 0, this.lockAxis = t || null, r && (this.constrainPosition = r), s && (this.previewClass = s), a && (this.boundaryElement = a), d && (this.rootElementSelector = d), h && (this.previewContainer = h)
            }
            _setupHandlesListener() {
                this._handles.pipe(on(e => {
                    let t = e.map(o => o.element);
                    this._selfHandle && this.rootElementSelector && t.push(this.element), this._dragRef.withHandles(t)
                }), $e(e => To(...e.map(t => t._stateChanges.pipe(wi(t))))), Ei(this._destroyed)).subscribe(e => {
                    let t = this._dragRef,
                        o = e.element.nativeElement;
                    e.disabled ? t.disableHandle(o) : t.enableHandle(o)
                })
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["", "cdkDrag", ""]
                ],
                hostAttrs: [1, "cdk-drag"],
                hostVars: 4,
                hostBindings: function(t, o) {
                    t & 2 && Oe("cdk-drag-disabled", o.disabled)("cdk-drag-dragging", o._dragRef.isDragging())
                },
                inputs: {
                    data: [0, "cdkDragData", "data"],
                    lockAxis: [0, "cdkDragLockAxis", "lockAxis"],
                    rootElementSelector: [0, "cdkDragRootElement", "rootElementSelector"],
                    boundaryElement: [0, "cdkDragBoundary", "boundaryElement"],
                    dragStartDelay: [0, "cdkDragStartDelay", "dragStartDelay"],
                    freeDragPosition: [0, "cdkDragFreeDragPosition", "freeDragPosition"],
                    disabled: [2, "cdkDragDisabled", "disabled", Fo],
                    constrainPosition: [0, "cdkDragConstrainPosition", "constrainPosition"],
                    previewClass: [0, "cdkDragPreviewClass", "previewClass"],
                    previewContainer: [0, "cdkDragPreviewContainer", "previewContainer"],
                    scale: [2, "cdkDragScale", "scale", Pl]
                },
                outputs: {
                    started: "cdkDragStarted",
                    released: "cdkDragReleased",
                    ended: "cdkDragEnded",
                    entered: "cdkDragEntered",
                    exited: "cdkDragExited",
                    dropped: "cdkDragDropped",
                    moved: "cdkDragMoved"
                },
                exportAs: ["cdkDrag"],
                features: [lt([{
                    provide: fu,
                    useExisting: i
                }]), ei]
            })
        }
        return i
    })();
var Iu = (() => {
    class i {
        static\ u0275fac = function(t) {
            return new(t || i)
        };
        static\ u0275mod = Ie({
            type: i
        });
        static\ u0275inj = Se({
            providers: [ef],
            imports: [eu]
        })
    }
    return i
})();
var es = new _e("TRANSLATE_HTTP_LOADER_CONFIG"),
    sf = (() => {
        class i {
            http;
            config;
            constructor() {
                this.config = oe({
                    prefix: "/assets/i18n/",
                    suffix: ".json",
                    enforceLoading: !1,
                    useHttpBackend: !1
                }, p(es)), this.http = this.config.useHttpBackend ? new gn(p(Vo)) : p(gn)
            }
            getTranslation(e) {
                let t = this.config.enforceLoading ? `?enforceLoading=${Date.now()}` : "";
                return this.http.get(`${this.config.prefix}${e}${this.config.suffix}${t}`)
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
        return i
    })();

function wu(i = {}) {
    let n = i.useHttpBackend ? ? !1;
    return [{
        provide: es,
        useValue: i
    }, {
        provide: Xl,
        useClass: sf,
        deps: [n ? Vo : gn, es]
    }]
}
var af = "firebase",
    lf = "12.13.0";
ic(af, lf, "app");
var uo = i => cf(i),
    is = (i, n) => (typeof i == "string" && (n = i, i = void 0), uo(i).includes(n)),
    cf = (i = window) => {
        if (i === void 0) return [];
        i.Ionic = i.Ionic || {};
        let n = i.Ionic.platforms;
        return n == null && (n = i.Ionic.platforms = df(i), n.forEach(e => i.document.documentElement.classList.add(`plt-${e}`))), n
    },
    df = i => {
        let n = dc.get("platform");
        return Object.keys(Tu).filter(e => {
            let t = n ? .[e];
            return typeof t == "function" ? t(i) : Tu[e](i)
        })
    },
    ts = i => !!$t(i, /iPad/i) || !(!$t(i, /Macintosh/i) || !po(i)),
    Eu = i => $t(i, /android|sink/i),
    po = i => pf(i, "(any-pointer:coarse)"),
    Du = i => xu(i) || Pu(i),
    xu = i => !!(i.cordova || i.phonegap || i.PhoneGap),
    Pu = i => {
        let n = i.Capacitor;
        return !!(n ? .isNative || n ? .isNativePlatform && n.isNativePlatform())
    },
    $t = (i, n) => n.test(i.navigator.userAgent),
    pf = (i, n) => {
        var e;
        return (e = i.matchMedia) === null || e === void 0 ? void 0 : e.call(i, n).matches
    },
    Tu = {
        ipad: ts,
        iphone: i => $t(i, /iPhone/i),
        ios: i => $t(i, /iPhone|iPod/i) || ts(i),
        android: Eu,
        phablet: i => {
            let n = i.innerWidth,
                e = i.innerHeight,
                t = Math.min(n, e),
                o = Math.max(n, e);
            return t > 390 && t < 520 && o > 620 && o < 800
        },
        tablet: i => {
            let n = i.innerWidth,
                e = i.innerHeight,
                t = Math.min(n, e),
                o = Math.max(n, e);
            return ts(i) || (r => Eu(r) && !$t(r, /mobile/i))(i) || t > 460 && t < 820 && o > 780 && o < 1400
        },
        cordova: xu,
        capacitor: Pu,
        electron: i => $t(i, /electron/i),
        pwa: i => {
            var n;
            return !(!(!((n = i.matchMedia) === null || n === void 0) && n.call(i, "(display-mode: standalone)").matches) && !i.navigator.standalone)
        },
        mobile: po,
        mobileweb: i => po(i) && !Du(i),
        desktop: i => !po(i),
        hybrid: Du
    };
var uf = ["tabsInner"];
var hf = (() => {
        class i {
            doc;
            _readyPromise;
            win;
            backButton = new Z;
            keyboardDidShow = new Z;
            keyboardDidHide = new Z;
            pause = new Z;
            resume = new Z;
            resize = new Z;
            constructor(e, t) {
                this.doc = e, t.run(() => {
                    this.win = e.defaultView, this.backButton.subscribeWithPriority = function(r, s) {
                        return this.subscribe(a => a.register(r, c => t.run(() => s(c))))
                    }, Si(this.pause, e, "pause", t), Si(this.resume, e, "resume", t), Si(this.backButton, e, "ionBackButton", t), Si(this.resize, this.win, "resize", t), Si(this.keyboardDidShow, this.win, "ionKeyboardDidShow", t), Si(this.keyboardDidHide, this.win, "ionKeyboardDidHide", t);
                    let o;
                    this._readyPromise = new Promise(r => {
                        o = r
                    }), this.win ? .cordova ? e.addEventListener("deviceready", () => {
                        o("cordova")
                    }, {
                        once: !0
                    }) : o("dom")
                })
            }
            is(e) {
                return is(this.win, e)
            }
            platforms() {
                return uo(this.win)
            }
            ready() {
                return this._readyPromise
            }
            get isRTL() {
                return this.doc.dir === "rtl"
            }
            getQueryParam(e) {
                return mf(this.win.location.href, e)
            }
            isLandscape() {
                return !this.isPortrait()
            }
            isPortrait() {
                return this.win.matchMedia ? .("(orientation: portrait)").matches
            }
            testUserAgent(e) {
                let t = this.win.navigator;
                return !!(t ? .userAgent && t.userAgent.indexOf(e) >= 0)
            }
            url() {
                return this.win.location.href
            }
            width() {
                return this.win.innerWidth
            }
            height() {
                return this.win.innerHeight
            }
            static\ u0275fac = function(t) {
                return new(t || i)(K(Ae), K(f))
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })(),
    mf = (i, n) => {
        n = n.replace(/[[\]\\]/g, "\\$&");
        let t = new RegExp("[\\?&]" + n + "=([^&#]*)").exec(i);
        return t ? decodeURIComponent(t[1].replace(/\+/g, " ")) : null
    },
    Si = (i, n, e, t) => {
        n && n.addEventListener(e, o => {
            t.run(() => {
                let r = o ? .detail;
                i.next(r)
            })
        })
    },
    Zt = (() => {
        class i {
            location;
            serializer;
            router;
            topOutlet;
            direction = ns;
            animated = os;
            animationBuilder;
            guessDirection = "forward";
            guessAnimation;
            lastNavId = -1;
            constructor(e, t, o, r) {
                this.location = t, this.serializer = o, this.router = r, r && r.events.subscribe(s => {
                    if (s instanceof Kl) {
                        let a = s.restoredState ? s.restoredState.navigationId : s.id;
                        this.guessDirection = this.guessAnimation = a < this.lastNavId ? "back" : "forward", this.lastNavId = this.guessDirection === "forward" ? s.id : a
                    }(s instanceof $l || s instanceof Ql) && (this.direction = ns, this.animated = os, this.animationBuilder = void 0)
                }), e.backButton.subscribeWithPriority(0, s => {
                    this.pop(), s()
                })
            }
            navigateForward(e, t = {}) {
                return this.setDirection("forward", t.animated, t.animationDirection, t.animation), this.navigate(e, t)
            }
            navigateBack(e, t = {}) {
                return this.setDirection("back", t.animated, t.animationDirection, t.animation), this.navigate(e, t)
            }
            navigateRoot(e, t = {}) {
                return this.setDirection("root", t.animated, t.animationDirection, t.animation), this.navigate(e, t)
            }
            back(e = {
                animated: !0,
                animationDirection: "back"
            }) {
                return this.setDirection("back", e.animated, e.animationDirection, e.animation), this.location.back()
            }
            pop() {
                return re(this, null, function*() {
                    let e = this.topOutlet;
                    for (; e;) {
                        if (yield e.pop()) return !0;
                        e = e.parentOutlet
                    }
                    return !1
                })
            }
            setDirection(e, t, o, r) {
                this.direction = e, this.animated = ff(e, t, o), this.animationBuilder = r
            }
            setTopOutlet(e) {
                this.topOutlet = e
            }
            consumeTransition() {
                let e = "root",
                    t, o = this.animationBuilder;
                return this.direction === "auto" ? (e = this.guessDirection, t = this.guessAnimation) : (t = this.animated, e = this.direction), this.direction = ns, this.animated = os, this.animationBuilder = void 0, {
                    direction: e,
                    animation: t,
                    animationBuilder: o
                }
            }
            navigate(e, t) {
                if (Array.isArray(e)) return this.router.navigate(e, t); {
                    let o = this.serializer.parse(e.toString());
                    return t.queryParams !== void 0 && (o.queryParams = oe({}, t.queryParams)), t.fragment !== void 0 && (o.fragment = t.fragment), this.router.navigateByUrl(o, t)
                }
            }
            static\ u0275fac = function(t) {
                return new(t || i)(K(hf), K(gt), K(ql), K(te, 8))
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })(),
    ff = (i, n, e) => {
        if (n !== !1) {
            if (e !== void 0) return e;
            if (i === "forward" || i === "back") return i;
            if (i === "root" && n === !0) return "forward"
        }
    },
    ns = "auto",
    os = void 0,
    fo = (() => {
        class i {
            get(e, t) {
                let o = rs();
                return o ? o.get(e, t) : null
            }
            getBoolean(e, t) {
                let o = rs();
                return o ? o.getBoolean(e, t) : !1
            }
            getNumber(e, t) {
                let o = rs();
                return o ? o.getNumber(e, t) : 0
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
        return i
    })(),
    go = new _e("USERCONFIG"),
    rs = () => {
        if (typeof window < "u") {
            let i = window.Ionic;
            if (i ? .config) return i.config
        }
        return null
    },
    ho = class {
        data;
        constructor(n = {}) {
            this.data = n, console.warn("[Ionic Warning]: NavParams has been deprecated in favor of using Angular's input API. Developers should migrate to either the @Input decorator or the Signals-based input API.")
        }
        get(n) {
            return this.data[n]
        }
    },
    gf = new _e("IonModalToken"),
    Yt = (() => {
        class i {
            zone = p(f);
            applicationRef = p(at);
            config = p(go);
            create(e, t, o, r) {
                return new as(e, t, this.applicationRef, this.zone, o, this.config.useSetInputAPI ? ? !1, r)
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
        return i
    })(),
    as = class {
        environmentInjector;
        injector;
        applicationRef;
        zone;
        elementReferenceKey;
        enableSignalsSupport;
        customInjector;
        elRefMap = new WeakMap;
        elEventsMap = new WeakMap;
        constructor(n, e, t, o, r, s, a) {
            this.environmentInjector = n, this.injector = e, this.applicationRef = t, this.zone = o, this.elementReferenceKey = r, this.enableSignalsSupport = s, this.customInjector = a
        }
        attachViewToDom(n, e, t, o) {
            return this.zone.run(() => new Promise(r => {
                let s = oe({}, t);
                this.elementReferenceKey !== void 0 && (s[this.elementReferenceKey] = n);
                let a = vf(this.zone, this.environmentInjector, this.injector, this.applicationRef, this.elRefMap, this.elEventsMap, n, e, s, o, this.elementReferenceKey, this.enableSignalsSupport, this.customInjector);
                r(a)
            }))
        }
        removeViewFromDom(n, e) {
            return this.zone.run(() => new Promise(t => {
                let o = this.elRefMap.get(e);
                if (o) {
                    o.destroy(), this.elRefMap.delete(e);
                    let r = this.elEventsMap.get(e);
                    r && (r(), this.elEventsMap.delete(e))
                }
                t()
            }))
        }
    },
    vf = (i, n, e, t, o, r, s, a, c, d, h, y, O) => {
        let B = bf(c);
        s.tagName.toLowerCase() === "ion-modal" && B.push({
            provide: gf,
            useValue: s
        });
        let R = se.create({
                providers: B,
                parent: O ? ? e
            }),
            N = hn(a, {
                environmentInjector: n,
                elementInjector: R
            }),
            H = N.instance,
            ie = N.location.nativeElement;
        if (c)
            if (h && H[h] !== void 0 && console.error(`[Ionic Error]: ${h} is a reserved property when using ${s.tagName.toLowerCase()}. Rename or remove the "${h}" property from ${a.name}.`), y === !0 && N.setInput !== void 0) {
                let he = c,
                    {
                        modal: ae,
                        popover: qe
                    } = he,
                    Be = Lt(he, ["modal", "popover"]);
                for (let ye in Be) N.setInput(ye, Be[ye]);
                ae !== void 0 && Object.assign(H, {
                    modal: ae
                }), qe !== void 0 && Object.assign(H, {
                    popover: qe
                })
            } else Object.assign(H, c);
        if (d)
            for (let ae of d) ie.classList.add(ae);
        let ce = Mu(i, H, ie);
        return s.appendChild(ie), t.attachView(N.hostView), o.set(ie, N), r.set(ie, ce), ie
    },
    _f = [Wo, qo, Ko, $o, Qo],
    Mu = (i, n, e) => i.run(() => {
        let t = _f.filter(o => typeof n[o] == "function").map(o => {
            let r = s => n[o](s.detail);
            return e.addEventListener(o, r), () => e.removeEventListener(o, r)
        });
        return () => t.forEach(o => o())
    }),
    ku = new _e("NavParamsToken"),
    bf = i => [{
        provide: ku,
        useValue: i
    }, {
        provide: ho,
        useFactory: yf,
        deps: [ku]
    }],
    yf = i => new ho(i),
    Cf = (i, n) => {
        let e = i.prototype;
        n.forEach(t => {
            Object.defineProperty(e, t, {
                get() {
                    return this.el[t]
                },
                set(o) {
                    this.z.runOutsideAngular(() => this.el[t] = o)
                }
            })
        })
    },
    Sf = (i, n) => {
        let e = i.prototype;
        n.forEach(t => {
            e[t] = function() {
                let o = arguments;
                return this.z.runOutsideAngular(() => this.el[t].apply(this.el, o))
            }
        })
    },
    fs = (i, n, e) => {
        e.forEach(t => i[t] = en(n, t))
    };

function vo(i) {
    return function(e) {
        let {
            defineCustomElementFn: t,
            inputs: o,
            methods: r
        } = i;
        return t !== void 0 && t(), o && Cf(e, o), r && Sf(e, r), e
    }
}
var If = ["animated", "keepContentsMounted", "backdropBreakpoint", "backdropDismiss", "breakpoints", "canDismiss", "cssClass", "enterAnimation", "expandToScroll", "event", "focusTrap", "handle", "handleBehavior", "initialBreakpoint", "isOpen", "keyboardClose", "leaveAnimation", "mode", "presentingElement", "showBackdrop", "translucent", "trigger"],
    wf = ["present", "dismiss", "onDidDismiss", "onWillDismiss", "setCurrentBreakpoint", "getCurrentBreakpoint"],
    Ru = (() => {
        let i = class ls {
            z;
            template;
            isCmpOpen = !1;
            el;
            constructor(e, t, o) {
                this.z = o, this.el = t.nativeElement, this.el.addEventListener("ionMount", () => {
                    this.isCmpOpen = !0, e.detectChanges()
                }), this.el.addEventListener("didDismiss", () => {
                    this.isCmpOpen = !1, e.detectChanges()
                }), fs(this, this.el, ["ionModalDidPresent", "ionModalWillPresent", "ionModalWillDismiss", "ionModalDidDismiss", "ionBreakpointDidChange", "didPresent", "willPresent", "willDismiss", "didDismiss", "ionDragStart", "ionDragMove", "ionDragEnd"])
            }
            static\ u0275fac = function(t) {
                return new(t || ls)(l(C), l(g), l(f))
            };
            static\ u0275dir = ue({
                type: ls,
                selectors: [
                    ["ion-modal"]
                ],
                contentQueries: function(t, o, r) {
                    if (t & 1 && Pi(r, Ti, 5), t & 2) {
                        let s;
                        Ge(s = He()) && (o.template = s.first)
                    }
                },
                inputs: {
                    animated: "animated",
                    keepContentsMounted: "keepContentsMounted",
                    backdropBreakpoint: "backdropBreakpoint",
                    backdropDismiss: "backdropDismiss",
                    breakpoints: "breakpoints",
                    canDismiss: "canDismiss",
                    cssClass: "cssClass",
                    enterAnimation: "enterAnimation",
                    expandToScroll: "expandToScroll",
                    event: "event",
                    focusTrap: "focusTrap",
                    handle: "handle",
                    handleBehavior: "handleBehavior",
                    initialBreakpoint: "initialBreakpoint",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    leaveAnimation: "leaveAnimation",
                    mode: "mode",
                    presentingElement: "presentingElement",
                    showBackdrop: "showBackdrop",
                    translucent: "translucent",
                    trigger: "trigger"
                },
                standalone: !1
            })
        };
        return i = I([vo({
            inputs: If,
            methods: wf
        })], i), i
    })(),
    Ef = ["alignment", "animated", "arrow", "keepContentsMounted", "backdropDismiss", "cssClass", "dismissOnSelect", "enterAnimation", "event", "focusTrap", "isOpen", "keyboardClose", "leaveAnimation", "mode", "showBackdrop", "translucent", "trigger", "triggerAction", "reference", "size", "side"],
    Df = ["present", "dismiss", "onDidDismiss", "onWillDismiss"],
    Au = (() => {
        let i = class cs {
            z;
            template;
            isCmpOpen = !1;
            el;
            constructor(e, t, o) {
                this.z = o, this.el = t.nativeElement, this.el.addEventListener("ionMount", () => {
                    this.isCmpOpen = !0, e.detectChanges()
                }), this.el.addEventListener("didDismiss", () => {
                    this.isCmpOpen = !1, e.detectChanges()
                }), fs(this, this.el, ["ionPopoverDidPresent", "ionPopoverWillPresent", "ionPopoverWillDismiss", "ionPopoverDidDismiss", "didPresent", "willPresent", "willDismiss", "didDismiss"])
            }
            static\ u0275fac = function(t) {
                return new(t || cs)(l(C), l(g), l(f))
            };
            static\ u0275dir = ue({
                type: cs,
                selectors: [
                    ["ion-popover"]
                ],
                contentQueries: function(t, o, r) {
                    if (t & 1 && Pi(r, Ti, 5), t & 2) {
                        let s;
                        Ge(s = He()) && (o.template = s.first)
                    }
                },
                inputs: {
                    alignment: "alignment",
                    animated: "animated",
                    arrow: "arrow",
                    keepContentsMounted: "keepContentsMounted",
                    backdropDismiss: "backdropDismiss",
                    cssClass: "cssClass",
                    dismissOnSelect: "dismissOnSelect",
                    enterAnimation: "enterAnimation",
                    event: "event",
                    focusTrap: "focusTrap",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    leaveAnimation: "leaveAnimation",
                    mode: "mode",
                    showBackdrop: "showBackdrop",
                    translucent: "translucent",
                    trigger: "trigger",
                    triggerAction: "triggerAction",
                    reference: "reference",
                    size: "size",
                    side: "side"
                },
                standalone: !1
            })
        };
        return i = I([vo({
            inputs: Ef,
            methods: Df
        })], i), i
    })(),
    Tf = (i, n, e) => e === "root" ? Ou(i, n) : e === "forward" ? xf(i, n) : Pf(i, n),
    Ou = (i, n) => (i = i.filter(e => e.stackId !== n.stackId), i.push(n), i),
    xf = (i, n) => (i.indexOf(n) >= 0 ? i = i.filter(t => t.stackId !== n.stackId || t.id <= n.id) : i.push(n), i),
    Pf = (i, n) => i.indexOf(n) >= 0 ? i.filter(t => t.stackId !== n.stackId || t.id <= n.id) : Ou(i, n),
    ds = (i, n) => {
        let e = i.createUrlTree(["."], {
            relativeTo: n
        });
        return i.serializeUrl(e)
    },
    Nu = (i, n) => n ? i.stackId !== n.stackId : !0,
    kf = (i, n) => {
        if (!i) return;
        let e = Lu(n);
        for (let t = 0; t < e.length; t++) {
            if (t >= i.length) return e[t];
            if (e[t] !== i[t]) return
        }
    },
    Lu = i => i.split("/").map(n => n.trim()).filter(n => n !== ""),
    ju = i => {
        i && (i.ref.destroy(), i.unlistenEvents())
    },
    ps = class {
        containerEl;
        router;
        navCtrl;
        zone;
        location;
        views = [];
        runningTask;
        skipTransition = !1;
        tabsPrefix;
        activeView;
        nextId = 0;
        constructor(n, e, t, o, r, s) {
            this.containerEl = e, this.router = t, this.navCtrl = o, this.zone = r, this.location = s, this.tabsPrefix = n !== void 0 ? Lu(n) : void 0
        }
        createView(n, e) {
            let t = ds(this.router, e),
                o = n ? .location ? .nativeElement,
                r = Mu(this.zone, n.instance, o);
            return {
                id: this.nextId++,
                stackId: kf(this.tabsPrefix, t),
                unlistenEvents: r,
                element: o,
                ref: n,
                url: t
            }
        }
        getExistingView(n) {
            let e = ds(this.router, n),
                t = this.views.find(o => o.url === e);
            return t && t.ref.changeDetectorRef.reattach(), t
        }
        setActive(n) {
            let e = this.navCtrl.consumeTransition(),
                {
                    direction: t,
                    animation: o,
                    animationBuilder: r
                } = e,
                s = this.activeView,
                a = Nu(n, s);
            a && (t = "back", o = void 0);
            let c = this.views.slice(),
                d, h = this.router;
            h.getCurrentNavigation ? d = h.getCurrentNavigation() : h.navigations ? .value && (d = h.navigations.value), d ? .extras ? .replaceUrl && this.views.length > 0 && this.views.splice(-1, 1);
            let y = this.views.includes(n),
                O = this.insertView(n, t);
            y || n.ref.changeDetectorRef.detectChanges();
            let B = n.animationBuilder;
            return r === void 0 && t === "back" && !a && B !== void 0 && (r = B), s && (s.animationBuilder = r), this.zone.runOutsideAngular(() => this.wait(() => (s && s.ref.changeDetectorRef.detach(), n.ref.changeDetectorRef.reattach(), this.transition(n, s, o, this.canGoBack(1), !1, r).then(() => Mf(n, O, c, this.location, this.zone)).then(() => ({
                enteringView: n,
                direction: t,
                animation: o,
                tabSwitch: a
            })))))
        }
        canGoBack(n, e = this.getActiveStackId()) {
            return this.getStack(e).length > n
        }
        pop(n, e = this.getActiveStackId()) {
            return this.zone.run(() => {
                let t = this.getStack(e);
                if (t.length <= n) return Promise.resolve(!1);
                let o = t[t.length - n - 1],
                    r = o.url,
                    s = o.savedData;
                if (s) {
                    let c = s.get("primary");
                    c ? .route ? ._routerState ? .snapshot.url && (r = c.route._routerState.snapshot.url)
                }
                let {
                    animationBuilder: a
                } = this.navCtrl.consumeTransition();
                return this.navCtrl.navigateBack(r, It(oe({}, o.savedExtras), {
                    animation: a
                })).then(() => !0)
            })
        }
        startBackTransition() {
            let n = this.activeView;
            if (n) {
                let e = this.getStack(n.stackId),
                    t = e[e.length - 2],
                    o = t.animationBuilder;
                return this.wait(() => this.transition(t, n, "back", this.canGoBack(2), !0, o))
            }
            return Promise.resolve()
        }
        endBackTransition(n) {
            n ? (this.skipTransition = !0, this.pop(1)) : this.activeView && Fu(this.activeView, this.views, this.views, this.location, this.zone)
        }
        getLastUrl(n) {
            let e = this.getStack(n);
            return e.length > 0 ? e[e.length - 1] : void 0
        }
        getRootUrl(n) {
            let e = this.getStack(n);
            return e.length > 0 ? e[0] : void 0
        }
        getActiveStackId() {
            return this.activeView ? this.activeView.stackId : void 0
        }
        getActiveView() {
            return this.activeView
        }
        hasRunningTask() {
            return this.runningTask !== void 0
        }
        destroy() {
            this.containerEl = void 0, this.views.forEach(ju), this.activeView = void 0, this.views = []
        }
        getStack(n) {
            return this.views.filter(e => e.stackId === n)
        }
        insertView(n, e) {
            return this.activeView = n, this.views = Tf(this.views, n, e), this.views.slice()
        }
        transition(n, e, t, o, r, s) {
            if (this.skipTransition) return this.skipTransition = !1, Promise.resolve(!1);
            if (e === n) return Promise.resolve(!1);
            let a = n ? n.element : void 0,
                c = e ? e.element : void 0,
                d = this.containerEl;
            return a && a !== c && (a.classList.add("ion-page"), a.classList.add("ion-page-invisible"), d.commit) ? d.commit(a, c, {
                duration: t === void 0 ? 0 : void 0,
                direction: t,
                showGoBack: o,
                progressAnimation: r,
                animationBuilder: s
            }) : Promise.resolve(!1)
        }
        wait(n) {
            return re(this, null, function*() {
                this.runningTask !== void 0 && (yield this.runningTask, this.runningTask = void 0);
                let e = this.runningTask = n();
                return e.finally(() => this.runningTask = void 0), e
            })
        }
    },
    Mf = (i, n, e, t, o) => typeof requestAnimationFrame == "function" ? new Promise(r => {
        requestAnimationFrame(() => {
            Fu(i, n, e, t, o), r()
        })
    }) : Promise.resolve(),
    Fu = (i, n, e, t, o) => {
        o.run(() => e.filter(r => !n.includes(r)).forEach(ju)), n.forEach(r => {
            let a = t.path().split("?")[0].split("#")[0];
            if (r !== i && r.url !== a) {
                let c = r.element;
                c.setAttribute("aria-hidden", "true"), c.classList.add("ion-page-hidden"), r.ref.changeDetectorRef.detach()
            }
        })
    },
    gs = (() => {
        class i {
            parentOutlet;
            nativeEl;
            activatedView = null;
            tabsPrefix;
            _swipeGesture;
            stackCtrl;
            proxyMap = new WeakMap;
            currentActivatedRoute$ = new Et(null);
            activated = null;
            get activatedComponentRef() {
                return this.activated
            }
            _activatedRoute = null;
            name = Uo;
            stackWillChange = new pe;
            stackDidChange = new pe;
            activateEvents = new pe;
            deactivateEvents = new pe;
            parentContexts = p(Ri);
            location = p(Bt);
            environmentInjector = p(tt);
            inputBinder = p(Bu, {
                optional: !0
            });
            supportsBindingToComponentInputs = !0;
            config = p(fo);
            navCtrl = p(Zt);
            set animation(e) {
                this.nativeEl.animation = e
            }
            set animated(e) {
                this.nativeEl.animated = e
            }
            set swipeGesture(e) {
                this._swipeGesture = e, this.nativeEl.swipeHandler = e ? {
                    canStart: () => this.stackCtrl.canGoBack(1) && !this.stackCtrl.hasRunningTask(),
                    onStart: () => this.stackCtrl.startBackTransition(),
                    onEnd: t => this.stackCtrl.endBackTransition(t)
                } : void 0
            }
            constructor(e, t, o, r, s, a, c, d) {
                this.parentOutlet = d, this.nativeEl = r.nativeElement, this.name = e || Uo, this.tabsPrefix = t === "true" ? ds(s, c) : void 0, this.stackCtrl = new ps(this.tabsPrefix, this.nativeEl, s, this.navCtrl, a, o), this.parentContexts.onChildOutletCreated(this.name, this)
            }
            ngOnDestroy() {
                this.stackCtrl.destroy(), this.inputBinder ? .unsubscribeFromRouteData(this)
            }
            getContext() {
                return this.parentContexts.getContext(this.name)
            }
            ngOnInit() {
                this.initializeOutletWithName()
            }
            initializeOutletWithName() {
                if (!this.activated) {
                    let e = this.getContext();
                    e ? .route && this.activateWith(e.route, e.injector)
                }
                new Promise(e => Ho(this.nativeEl, e)).then(() => {
                    this._swipeGesture === void 0 && (this.swipeGesture = this.config.getBoolean("swipeBackEnabled", this.nativeEl.mode === "ios"))
                })
            }
            get isActivated() {
                return !!this.activated
            }
            get component() {
                if (!this.activated) throw new Error("Outlet is not activated");
                return this.activated.instance
            }
            get activatedRoute() {
                if (!this.activated) throw new Error("Outlet is not activated");
                return this._activatedRoute
            }
            get activatedRouteData() {
                return this._activatedRoute ? this._activatedRoute.snapshot.data : {}
            }
            detach() {
                throw new Error("incompatible reuse strategy")
            }
            attach(e, t) {
                throw new Error("incompatible reuse strategy")
            }
            deactivate() {
                if (this.activated) {
                    if (this.activatedView) {
                        let t = this.getContext();
                        this.activatedView.savedData = new Map(t.children.contexts);
                        let o = this.activatedView.savedData.get("primary");
                        if (o && t.route && (o.route = oe({}, t.route)), this.activatedView.savedExtras = {}, t.route) {
                            let r = t.route.snapshot;
                            this.activatedView.savedExtras.queryParams = r.queryParams, this.activatedView.savedExtras.fragment = r.fragment
                        }
                    }
                    let e = this.component;
                    this.activatedView = null, this.activated = null, this._activatedRoute = null, this.deactivateEvents.emit(e)
                }
            }
            activateWith(e, t) {
                if (this.isActivated) throw new Error("Cannot activate an already activated outlet");
                this._activatedRoute = e;
                let o, r = this.stackCtrl.getExistingView(e);
                if (r) {
                    o = this.activated = r.ref;
                    let a = r.savedData;
                    if (a) {
                        let c = this.getContext();
                        c.children.contexts = a
                    }
                    this.updateActivatedRouteProxy(o.instance, e)
                } else {
                    let a = e._futureSnapshot,
                        c = this.parentContexts.getOrCreateContext(this.name).children,
                        d = new Et(null),
                        h = this.createActivatedRouteProxy(d, e),
                        y = new us(h, c, this.location.injector),
                        O = a.routeConfig.component ? ? a.component;
                    o = this.activated = this.outletContent.createComponent(O, {
                        index: this.outletContent.length,
                        injector: y,
                        environmentInjector: t ? ? this.environmentInjector
                    }), d.next(o.instance), r = this.stackCtrl.createView(this.activated, e), this.proxyMap.set(o.instance, h), this.currentActivatedRoute$.next({
                        component: o.instance,
                        activatedRoute: e
                    })
                }
                this.inputBinder ? .bindActivatedRouteToOutletComponent(this), this.activatedView = r, this.navCtrl.setTopOutlet(this);
                let s = this.stackCtrl.getActiveView();
                this.stackWillChange.emit({
                    enteringView: r,
                    tabSwitch: Nu(r, s)
                }), this.stackCtrl.setActive(r).then(a => {
                    this.activateEvents.emit(o.instance), this.stackDidChange.emit(a)
                })
            }
            canGoBack(e = 1, t) {
                return this.stackCtrl.canGoBack(e, t)
            }
            pop(e = 1, t) {
                return this.stackCtrl.pop(e, t)
            }
            getLastUrl(e) {
                let t = this.stackCtrl.getLastUrl(e);
                return t ? t.url : void 0
            }
            getLastRouteView(e) {
                return this.stackCtrl.getLastUrl(e)
            }
            getRootView(e) {
                return this.stackCtrl.getRootUrl(e)
            }
            getActiveStackId() {
                return this.stackCtrl.getActiveStackId()
            }
            createActivatedRouteProxy(e, t) {
                let o = new _t;
                return o._futureSnapshot = t._futureSnapshot, o._routerState = t._routerState, o.snapshot = t.snapshot, o.outlet = t.outlet, o.component = t.component, o._paramMap = this.proxyObservable(e, "paramMap"), o._queryParamMap = this.proxyObservable(e, "queryParamMap"), o.url = this.proxyObservable(e, "url"), o.params = this.proxyObservable(e, "params"), o.queryParams = this.proxyObservable(e, "queryParams"), o.fragment = this.proxyObservable(e, "fragment"), o.data = this.proxyObservable(e, "data"), o
            }
            proxyObservable(e, t) {
                return e.pipe(ve(o => !!o), $e(o => this.currentActivatedRoute$.pipe(ve(r => r !== null && r.component === o), $e(r => r && r.activatedRoute[t]), xo())))
            }
            updateActivatedRouteProxy(e, t) {
                let o = this.proxyMap.get(e);
                if (!o) throw new Error("Could not find activated route proxy for view");
                o._futureSnapshot = t._futureSnapshot, o._routerState = t._routerState, o.snapshot = t.snapshot, o.outlet = t.outlet, o.component = t.component, this.currentActivatedRoute$.next({
                    component: e,
                    activatedRoute: t
                })
            }
            static\ u0275fac = function(t) {
                return new(t || i)(ti("name"), ti("tabs"), l(gt), l(g), l(te), l(f), l(_t), l(i, 12))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-router-outlet"]
                ],
                inputs: {
                    animated: "animated",
                    animation: "animation",
                    mode: "mode",
                    swipeGesture: "swipeGesture",
                    name: "name"
                },
                outputs: {
                    stackWillChange: "stackWillChange",
                    stackDidChange: "stackDidChange",
                    activateEvents: "activate",
                    deactivateEvents: "deactivate"
                },
                exportAs: ["outlet"],
                standalone: !1
            })
        }
        return i
    })(),
    us = class {
        route;
        childContexts;
        parent;
        constructor(n, e, t) {
            this.route = n, this.childContexts = e, this.parent = t
        }
        get(n, e) {
            return n === _t ? this.route : n === Ri ? this.childContexts : this.parent.get(n, e)
        }
    },
    Bu = new _e(""),
    Rf = (() => {
        class i {
            outletDataSubscriptions = new Map;
            bindActivatedRouteToOutletComponent(e) {
                this.unsubscribeFromRouteData(e), this.subscribeToRouteData(e)
            }
            unsubscribeFromRouteData(e) {
                this.outletDataSubscriptions.get(e) ? .unsubscribe(), this.outletDataSubscriptions.delete(e)
            }
            subscribeToRouteData(e) {
                let {
                    activatedRoute: t
                } = e, o = ll([t.queryParams, t.params, t.data]).pipe($e(([r, s, a], c) => (a = oe(oe(oe({}, r), s), a), c === 0 ? Dt(a) : Promise.resolve(a)))).subscribe(r => {
                    if (!e.isActivated || !e.activatedComponentRef || e.activatedRoute !== t || t.component === null) {
                        this.unsubscribeFromRouteData(e);
                        return
                    }
                    let s = kl(t.component);
                    if (!s) {
                        this.unsubscribeFromRouteData(e);
                        return
                    }
                    for (let {
                            templateName: a
                        } of s.inputs) e.activatedComponentRef.setInput(a, r[a])
                });
                this.outletDataSubscriptions.set(e, o)
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
        return i
    })(),
    Vu = () => ({
        provide: Bu,
        useFactory: Af,
        deps: [te]
    });

function Af(i) {
    return i ? .componentInputBindingEnabled ? new Rf : null
}
var vs = i => typeof __zone_symbol__requestAnimationFrame == "function" ? __zone_symbol__requestAnimationFrame(i) : typeof requestAnimationFrame == "function" ? requestAnimationFrame(i) : setTimeout(i),
    Qi = (() => {
        class i {
            injector;
            elementRef;
            onChange = () => {};
            onTouched = () => {};
            lastValue;
            statusChanges;
            constructor(e, t) {
                this.injector = e, this.elementRef = t
            }
            writeValue(e) {
                this.elementRef.nativeElement.value = this.lastValue = e, Qt(this.elementRef)
            }
            handleValueChange(e, t) {
                e === this.elementRef.nativeElement && (t !== this.lastValue && (this.lastValue = t, this.onChange(t)), Qt(this.elementRef))
            }
            _handleBlurEvent(e) {
                e === this.elementRef.nativeElement ? (this.onTouched(), Qt(this.elementRef)) : e.closest("ion-radio-group") === this.elementRef.nativeElement && this.onTouched()
            }
            registerOnChange(e) {
                this.onChange = e
            }
            registerOnTouched(e) {
                this.onTouched = e
            }
            setDisabledState(e) {
                this.elementRef.nativeElement.disabled = e
            }
            ngOnDestroy() {
                this.statusChanges && this.statusChanges.unsubscribe()
            }
            ngAfterViewInit() {
                let e;
                try {
                    e = this.injector.get(zl)
                } catch (o) {}
                if (!e) return;
                e.statusChanges && (this.statusChanges = e.statusChanges.subscribe(() => Qt(this.elementRef)));
                let t = e.control;
                t && ["markAsTouched", "markAllAsTouched", "markAsUntouched", "markAsDirty", "markAsPristine"].forEach(r => {
                    if (typeof t[r] < "u") {
                        let s = t[r].bind(t);
                        t[r] = (...a) => {
                            s(...a), Qt(this.elementRef)
                        }
                    }
                })
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(se), l(g))
            };
            static\ u0275dir = ue({
                type: i,
                hostBindings: function(t, o) {
                    t & 1 && x("ionBlur", function(s) {
                        return o._handleBlurEvent(s.target)
                    })
                },
                standalone: !1
            })
        }
        return i
    })(),
    Qt = i => {
        vs(() => {
            let n = i.nativeElement,
                e = n.value != null && n.value.toString().length > 0,
                t = Of(n);
            ss(n, t);
            let o = n.closest("ion-item");
            o && (e ? ss(o, [...t, "item-has-value"]) : ss(o, t))
        })
    },
    Of = i => {
        let n = i.classList,
            e = [];
        for (let t = 0; t < n.length; t++) {
            let o = n.item(t);
            o !== null && Nf(o, "ng-") && e.push(`ion-${o.substring(3)}`)
        }
        return e
    },
    ss = (i, n) => {
        let e = i.classList;
        e.remove("ion-valid", "ion-invalid", "ion-touched", "ion-untouched", "ion-dirty", "ion-pristine"), e.add(...n)
    },
    Nf = (i, n) => i.substring(0, n.length) === n,
    Lf = ["color", "defaultHref", "disabled", "icon", "mode", "routerAnimation", "text", "type"],
    zu = (() => {
        let i = class hs {
            routerOutlet;
            navCtrl;
            config;
            r;
            z;
            el;
            constructor(e, t, o, r, s, a) {
                this.routerOutlet = e, this.navCtrl = t, this.config = o, this.r = r, this.z = s, a.detach(), this.el = this.r.nativeElement
            }
            onClick(e) {
                let t = this.defaultHref || this.config.get("backButtonDefaultHref");
                this.routerOutlet ? .canGoBack() ? (this.navCtrl.setDirection("back", void 0, void 0, this.routerAnimation), this.routerOutlet.pop(), e.preventDefault()) : t != null && (this.navCtrl.navigateBack(t, {
                    animation: this.routerAnimation
                }), e.preventDefault())
            }
            static\ u0275fac = function(t) {
                return new(t || hs)(l(gs, 8), l(Zt), l(fo), l(g), l(f), l(C))
            };
            static\ u0275dir = ue({
                type: hs,
                hostBindings: function(t, o) {
                    t & 1 && x("click", function(s) {
                        return o.onClick(s)
                    })
                },
                inputs: {
                    color: "color",
                    defaultHref: "defaultHref",
                    disabled: "disabled",
                    icon: "icon",
                    mode: "mode",
                    routerAnimation: "routerAnimation",
                    text: "text",
                    type: "type"
                },
                standalone: !1
            })
        };
        return i = I([vo({
            inputs: Lf
        })], i), i
    })(),
    jf = ["animated", "animation", "root", "rootParams", "swipeGesture"],
    Ff = ["push", "insert", "insertPages", "pop", "popTo", "popToRoot", "removeIndex", "setRoot", "setPages", "getActive", "getByIndex", "canGoBack", "getPrevious"],
    Uu = (() => {
        let i = class ms {
            z;
            el;
            constructor(e, t, o, r, s, a) {
                this.z = s, a.detach(), this.el = e.nativeElement, e.nativeElement.delegate = r.create(t, o), fs(this, this.el, ["ionNavDidChange", "ionNavWillChange"])
            }
            static\ u0275fac = function(t) {
                return new(t || ms)(l(g), l(tt), l(se), l(Yt), l(f), l(C))
            };
            static\ u0275dir = ue({
                type: ms,
                inputs: {
                    animated: "animated",
                    animation: "animation",
                    root: "root",
                    rootParams: "rootParams",
                    swipeGesture: "swipeGesture"
                },
                standalone: !1
            })
        };
        return i = I([vo({
            inputs: jf,
            methods: Ff
        })], i), i
    })(),
    Gu = (() => {
        class i {
            locationStrategy;
            navCtrl;
            elementRef;
            router;
            routerLink;
            routerDirection = "forward";
            routerAnimation;
            constructor(e, t, o, r, s) {
                this.locationStrategy = e, this.navCtrl = t, this.elementRef = o, this.router = r, this.routerLink = s
            }
            ngOnInit() {
                this.updateTargetUrlAndHref(), this.updateTabindex()
            }
            ngOnChanges() {
                this.updateTargetUrlAndHref()
            }
            updateTabindex() {
                let e = ["ION-BACK-BUTTON", "ION-BREADCRUMB", "ION-BUTTON", "ION-CARD", "ION-FAB-BUTTON", "ION-ITEM", "ION-ITEM-OPTION", "ION-MENU-BUTTON", "ION-SEGMENT-BUTTON", "ION-TAB-BUTTON"],
                    t = this.elementRef.nativeElement;
                e.includes(t.tagName) && t.getAttribute("tabindex") === "0" && t.removeAttribute("tabindex")
            }
            updateTargetUrlAndHref() {
                if (this.routerLink ? .urlTree) {
                    let e = this.locationStrategy.prepareExternalUrl(this.router.serializeUrl(this.routerLink.urlTree));
                    this.elementRef.nativeElement.href = e
                }
            }
            onClick(e) {
                this.navCtrl.setDirection(this.routerDirection, void 0, void 0, this.routerAnimation), e.preventDefault()
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(ki), l(Zt), l(g), l(te), l(Ai, 8))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["", "routerLink", "", 5, "a", 5, "area"]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("click", function(s) {
                        return o.onClick(s)
                    })
                },
                inputs: {
                    routerDirection: "routerDirection",
                    routerAnimation: "routerAnimation"
                },
                standalone: !1,
                features: [ei]
            })
        }
        return i
    })(),
    Hu = (() => {
        class i {
            locationStrategy;
            navCtrl;
            elementRef;
            router;
            routerLink;
            routerDirection = "forward";
            routerAnimation;
            constructor(e, t, o, r, s) {
                this.locationStrategy = e, this.navCtrl = t, this.elementRef = o, this.router = r, this.routerLink = s
            }
            ngOnInit() {
                this.updateTargetUrlAndHref()
            }
            ngOnChanges() {
                this.updateTargetUrlAndHref()
            }
            updateTargetUrlAndHref() {
                if (this.routerLink ? .urlTree) {
                    let e = this.locationStrategy.prepareExternalUrl(this.router.serializeUrl(this.routerLink.urlTree));
                    this.elementRef.nativeElement.href = e
                }
            }
            onClick() {
                this.navCtrl.setDirection(this.routerDirection, void 0, void 0, this.routerAnimation)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(ki), l(Zt), l(g), l(te), l(Ai, 8))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["a", "routerLink", ""],
                    ["area", "routerLink", ""]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("click", function() {
                        return o.onClick()
                    })
                },
                inputs: {
                    routerDirection: "routerDirection",
                    routerAnimation: "routerAnimation"
                },
                standalone: !1,
                features: [ei]
            })
        }
        return i
    })(),
    Bf = i => {
        if (!i) return;
        let n = i.indexOf("#"),
            e = n >= 0 && n < i.length - 1 ? i.slice(n + 1) : void 0,
            t = n >= 0 ? i.slice(0, n) : i,
            o = t.indexOf("?"),
            r = o >= 0 ? t.slice(o + 1) : "",
            s;
        if (r) {
            let c = new URLSearchParams(r);
            s = {};
            for (let d of new Set(c.keys())) {
                let h = c.getAll(d);
                s[d] = h.length > 1 ? h : h[0]
            }
        }
        if (!s && e === void 0) return;
        let a = {};
        return s && (a.queryParams = s), e !== void 0 && (a.fragment = e), a
    },
    Wu = (() => {
        class i {
            navCtrl;
            tabsInner;
            ionTabsWillChange = new pe;
            ionTabsDidChange = new pe;
            tabBarSlot = "bottom";
            hasTab = !1;
            selectedTab;
            leavingTab;
            constructor(e) {
                this.navCtrl = e
            }
            ngAfterViewInit() {
                let e = this.tabs.length > 0 ? this.tabs.first : void 0;
                e && (this.hasTab = !0, this.setActiveTab(e.tab), this.tabSwitch())
            }
            ngAfterContentInit() {
                this.detectSlotChanges()
            }
            ngAfterContentChecked() {
                this.detectSlotChanges()
            }
            onStackWillChange({
                enteringView: e,
                tabSwitch: t
            }) {
                let o = e.stackId;
                t && o !== void 0 && this.ionTabsWillChange.emit({
                    tab: o
                })
            }
            onStackDidChange({
                enteringView: e,
                tabSwitch: t
            }) {
                let o = e.stackId;
                t && o !== void 0 && (this.tabBar && (this.tabBar.selectedTab = o), this.ionTabsDidChange.emit({
                    tab: o
                }))
            }
            select(e) {
                let t = typeof e == "string",
                    o = t ? e : e.detail.tab,
                    r = t ? void 0 : e.detail.href;
                if (this.hasTab) {
                    this.setActiveTab(o), this.tabSwitch();
                    return
                }
                let s = this.outlet.getActiveStackId() === o,
                    a = `${this.outlet.tabsPrefix}/${o}`,
                    c = Bf(r);
                if (t || e.stopPropagation(), s) {
                    let d = this.outlet.getActiveStackId();
                    if (this.outlet.getLastRouteView(d) ? .url === a) return;
                    let y = this.outlet.getRootView(o),
                        O = y && a === y.url && y.savedExtras;
                    return this.navCtrl.navigateRoot(a, It(oe(oe({}, O), c), {
                        animated: !0,
                        animationDirection: "back"
                    }))
                } else {
                    let d = this.outlet.getLastRouteView(o),
                        h = d ? .url || a,
                        y = d ? .savedExtras ? ? (h === a ? c : void 0);
                    return this.navCtrl.navigateRoot(h, It(oe({}, y), {
                        animated: !0,
                        animationDirection: "back"
                    }))
                }
            }
            setActiveTab(e) {
                let o = this.tabs.find(r => r.tab === e);
                if (!o) {
                    console.error(`[Ionic Error]: Tab with id: "${e}" does not exist`);
                    return
                }
                this.leavingTab = this.selectedTab, this.selectedTab = o, this.ionTabsWillChange.emit({
                    tab: e
                }), o.el.active = !0
            }
            tabSwitch() {
                let {
                    selectedTab: e,
                    leavingTab: t
                } = this;
                this.tabBar && e && (this.tabBar.selectedTab = e.tab), t ? .tab !== e ? .tab && t ? .el && (t.el.active = !1), e && this.ionTabsDidChange.emit({
                    tab: e.tab
                })
            }
            getSelected() {
                return this.hasTab ? this.selectedTab ? .tab : this.outlet.getActiveStackId()
            }
            detectSlotChanges() {
                this.tabBars.forEach(e => {
                    let t = e.el.getAttribute("slot");
                    t !== this.tabBarSlot && (this.tabBarSlot = t, this.relocateTabBar())
                })
            }
            relocateTabBar() {
                let e = this.tabBar.el;
                this.tabBarSlot === "top" ? this.tabsInner.nativeElement.before(e) : this.tabsInner.nativeElement.after(e)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(Zt))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-tabs"]
                ],
                viewQuery: function(t, o) {
                    if (t & 1 && Pt(uf, 7, g), t & 2) {
                        let r;
                        Ge(r = He()) && (o.tabsInner = r.first)
                    }
                },
                hostBindings: function(t, o) {
                    t & 1 && x("ionTabButtonClick", function(s) {
                        return o.select(s)
                    })
                },
                outputs: {
                    ionTabsWillChange: "ionTabsWillChange",
                    ionTabsDidChange: "ionTabsDidChange"
                },
                standalone: !1
            })
        }
        return i
    })(),
    $i = class {
        ctrl;
        constructor(n) {
            this.ctrl = n
        }
        create(n) {
            return this.ctrl.create(n || {})
        }
        dismiss(n, e, t) {
            return this.ctrl.dismiss(n, e, t)
        }
        getTop() {
            return this.ctrl.getTop()
        }
    };
var eg = Zo || (() => {}),
    Qu = eg;
var Zu = (i, n) => re(null, null, function*() {
    if (!(typeof window > "u")) return yield Qu(), pc(JSON.parse('[["ion-menu_3",[[289,"ion-menu-button",{"color":[513],"disabled":[4],"menu":[1],"autoHide":[4,"auto-hide"],"type":[1],"visible":[32]},[[16,"ionMenuChange","visibilityChanged"],[16,"ionSplitPaneVisible","visibilityChanged"]]],[289,"ion-menu",{"contentId":[513,"content-id"],"menuId":[513,"menu-id"],"type":[1025],"disabled":[1028],"side":[513],"swipeGesture":[4,"swipe-gesture"],"maxEdgeStart":[2,"max-edge-start"],"isPaneVisible":[32],"isEndSide":[32],"isOpen":[64],"isActive":[64],"open":[64],"close":[64],"toggle":[64],"setOpen":[64]},[[16,"ionSplitPaneVisible","onSplitPaneChanged"],[2,"click","onBackdropClick"]],{"type":[{"typeChanged":0}],"disabled":[{"disabledChanged":0}],"side":[{"sideChanged":0}],"swipeGesture":[{"swipeGestureChanged":0}]}],[257,"ion-menu-toggle",{"menu":[1],"autoHide":[4,"auto-hide"],"visible":[32]},[[16,"ionMenuChange","visibilityChanged"],[16,"ionSplitPaneVisible","visibilityChanged"]]]]],["ion-input-password-toggle",[[33,"ion-input-password-toggle",{"color":[513],"showIcon":[1,"show-icon"],"hideIcon":[1,"hide-icon"],"type":[1025]},null,{"type":[{"onTypeChange":0}]}]]],["ion-fab_3",[[289,"ion-fab-button",{"color":[513],"activated":[4],"disabled":[4],"download":[1],"href":[1],"rel":[1],"routerDirection":[1,"router-direction"],"routerAnimation":[16],"target":[1],"show":[4],"translucent":[4],"type":[1],"size":[1],"closeIcon":[1,"close-icon"]}],[257,"ion-fab",{"horizontal":[1],"vertical":[1],"edge":[4],"activated":[1028],"close":[64],"toggle":[64]},null,{"activated":[{"activatedChanged":0}]}],[257,"ion-fab-list",{"activated":[4],"side":[1]},null,{"activated":[{"activatedChanged":0}]}]]],["ion-refresher_2",[[0,"ion-refresher-content",{"pullingIcon":[1025,"pulling-icon"],"pullingText":[1,"pulling-text"],"refreshingSpinner":[1025,"refreshing-spinner"],"refreshingText":[1,"refreshing-text"]}],[32,"ion-refresher",{"pullMin":[2,"pull-min"],"pullMax":[2,"pull-max"],"closeDuration":[1,"close-duration"],"snapbackDuration":[1,"snapback-duration"],"pullFactor":[2,"pull-factor"],"disabled":[4],"nativeRefresher":[32],"state":[32],"complete":[64],"cancel":[64],"getProgress":[64]},null,{"disabled":[{"disabledChanged":0}]}]]],["ion-back-button",[[33,"ion-back-button",{"color":[513],"defaultHref":[1025,"default-href"],"disabled":[516],"icon":[1],"text":[1],"type":[1],"routerAnimation":[16]}]]],["ion-toast",[[33,"ion-toast",{"overlayIndex":[2,"overlay-index"],"delegate":[16],"hasController":[4,"has-controller"],"color":[513],"enterAnimation":[16],"leaveAnimation":[16],"cssClass":[1,"css-class"],"duration":[2],"header":[1],"layout":[1],"message":[1],"keyboardClose":[4,"keyboard-close"],"position":[1],"positionAnchor":[1,"position-anchor"],"buttons":[16],"translucent":[4],"animated":[4],"icon":[1],"htmlAttributes":[16],"swipeGesture":[1,"swipe-gesture"],"isOpen":[4,"is-open"],"trigger":[1],"revealContentToScreenReader":[32],"present":[64],"dismiss":[64],"onDidDismiss":[64],"onWillDismiss":[64]},null,{"swipeGesture":[{"swipeGestureChanged":0}],"isOpen":[{"onIsOpenChange":0}],"trigger":[{"triggerChanged":0}]}]]],["ion-card_5",[[289,"ion-card",{"color":[513],"button":[4],"type":[1],"disabled":[4],"download":[1],"href":[1],"rel":[1],"routerDirection":[1,"router-direction"],"routerAnimation":[16],"target":[1]}],[32,"ion-card-content"],[289,"ion-card-header",{"color":[513],"translucent":[4]}],[289,"ion-card-subtitle",{"color":[513]}],[289,"ion-card-title",{"color":[513]}]]],["ion-item-option_3",[[289,"ion-item-option",{"color":[513],"disabled":[4],"download":[1],"expandable":[4],"href":[1],"rel":[1],"target":[1],"type":[1]}],[32,"ion-item-options",{"side":[1],"fireSwipeEvent":[64]}],[0,"ion-item-sliding",{"disabled":[4],"state":[32],"getOpenAmount":[64],"getSlidingRatio":[64],"open":[64],"close":[64],"closeOpened":[64]},null,{"disabled":[{"disabledChanged":0}]}]]],["ion-accordion_2",[[305,"ion-accordion",{"value":[1],"disabled":[4],"readonly":[4],"toggleIcon":[1,"toggle-icon"],"toggleIconSlot":[1,"toggle-icon-slot"],"state":[32],"isNext":[32],"isPrevious":[32],"hasInteracted":[32]},null,{"value":[{"valueChanged":0}]}],[289,"ion-accordion-group",{"animated":[4],"multiple":[4],"value":[1025],"disabled":[4],"readonly":[4],"expand":[1],"requestAccordionToggle":[64],"getAccordions":[64]},[[0,"keydown","onKeydown"]],{"value":[{"valueChanged":0}],"disabled":[{"disabledChanged":0}],"readonly":[{"readonlyChanged":0}]}]]],["ion-infinite-scroll_2",[[32,"ion-infinite-scroll-content",{"loadingSpinner":[1025,"loading-spinner"],"loadingText":[1,"loading-text"]}],[0,"ion-infinite-scroll",{"threshold":[1],"disabled":[4],"position":[1],"isLoading":[32],"complete":[64]},null,{"threshold":[{"thresholdChanged":0}],"disabled":[{"disabledChanged":0}]}]]],["ion-reorder_2",[[289,"ion-reorder",null,[[2,"click","onClick"]]],[0,"ion-reorder-group",{"disabled":[4],"state":[32],"complete":[64]},null,{"disabled":[{"disabledChanged":0}]}]]],["ion-segment_2",[[289,"ion-segment-button",{"contentId":[513,"content-id"],"disabled":[1028],"layout":[1],"type":[1],"value":[8],"checked":[32],"setFocus":[64]},null,{"value":[{"valueChanged":0}]}],[289,"ion-segment",{"color":[513],"disabled":[4],"scrollable":[4],"swipeGesture":[4,"swipe-gesture"],"value":[1032],"selectOnFocus":[4,"select-on-focus"],"activated":[32]},[[16,"ionSegmentViewScroll","handleSegmentViewScroll"],[0,"keydown","onKeyDown"]],{"color":[{"colorChanged":0}],"swipeGesture":[{"swipeGestureChanged":0}],"value":[{"valueChanged":0}],"disabled":[{"disabledChanged":0}]}]]],["ion-chip",[[289,"ion-chip",{"color":[513],"outline":[4],"disabled":[4]}]]],["ion-input",[[294,"ion-input",{"color":[513],"autocapitalize":[1],"autocomplete":[1],"autocorrect":[1],"autofocus":[4],"clearInput":[4,"clear-input"],"clearInputIcon":[1,"clear-input-icon"],"clearOnEdit":[4,"clear-on-edit"],"counter":[4],"counterFormatter":[16],"debounce":[2],"disabled":[516],"enterkeyhint":[1],"errorText":[1,"error-text"],"fill":[1],"inputmode":[1],"helperText":[1,"helper-text"],"label":[1],"labelPlacement":[1,"label-placement"],"max":[8],"maxlength":[2],"min":[8],"minlength":[2],"multiple":[4],"name":[1],"pattern":[1],"placeholder":[1],"readonly":[516],"required":[4],"shape":[1],"spellcheck":[4],"step":[1],"type":[1],"value":[1032],"hasFocus":[32],"isInvalid":[32],"setFocus":[64],"getInputElement":[64]},[[2,"click","onClickCapture"]],{"debounce":[{"debounceChanged":0}],"type":[{"onTypeChange":0}],"value":[{"valueChanged":0}],"dir":[{"onDirChanged":0}]}]]],["ion-searchbar",[[34,"ion-searchbar",{"color":[513],"animated":[4],"autocapitalize":[1],"autocomplete":[1],"autocorrect":[1],"cancelButtonIcon":[1,"cancel-button-icon"],"cancelButtonText":[1,"cancel-button-text"],"clearIcon":[1,"clear-icon"],"debounce":[2],"disabled":[4],"inputmode":[1],"enterkeyhint":[1],"maxlength":[2],"minlength":[2],"name":[1],"placeholder":[1],"searchIcon":[1,"search-icon"],"showCancelButton":[1,"show-cancel-button"],"showClearButton":[1,"show-clear-button"],"spellcheck":[4],"type":[1],"value":[1025],"focused":[32],"noAnimate":[32],"setFocus":[64],"getInputElement":[64]},null,{"lang":[{"onLangChanged":0}],"dir":[{"onDirChanged":0}],"debounce":[{"debounceChanged":0}],"value":[{"valueChanged":0}],"showCancelButton":[{"showCancelButtonChanged":0}]}]]],["ion-toggle",[[289,"ion-toggle",{"color":[513],"name":[1],"checked":[1028],"disabled":[4],"errorText":[1,"error-text"],"helperText":[1,"helper-text"],"value":[1],"enableOnOffLabels":[4,"enable-on-off-labels"],"labelPlacement":[1,"label-placement"],"justify":[1],"alignment":[1],"required":[4],"activated":[32],"isInvalid":[32],"hintTextId":[32]},null,{"disabled":[{"disabledChanged":0}]}]]],["ion-nav_2",[[257,"ion-nav",{"delegate":[16],"swipeGesture":[1028,"swipe-gesture"],"animated":[4],"animation":[16],"rootParams":[16],"root":[1],"push":[64],"insert":[64],"insertPages":[64],"pop":[64],"popTo":[64],"popToRoot":[64],"removeIndex":[64],"setRoot":[64],"setPages":[64],"setRouteId":[64],"getRouteId":[64],"getActive":[64],"getByIndex":[64],"canGoBack":[64],"getPrevious":[64],"getLength":[64]},null,{"swipeGesture":[{"swipeGestureChanged":0}],"root":[{"rootChanged":0}]}],[0,"ion-nav-link",{"component":[1],"componentProps":[16],"routerDirection":[1,"router-direction"],"routerAnimation":[16]}]]],["ion-tab_2",[[257,"ion-tab",{"active":[1028],"delegate":[16],"tab":[1],"component":[1],"setActive":[64]},null,{"active":[{"changeActive":0}]}],[257,"ion-tabs",{"useRouter":[1028,"use-router"],"selectedTab":[32],"select":[64],"getTab":[64],"getSelected":[64],"setRouteId":[64],"getRouteId":[64]}]]],["ion-textarea",[[294,"ion-textarea",{"color":[513],"autocapitalize":[1],"autofocus":[4],"clearOnEdit":[4,"clear-on-edit"],"debounce":[2],"disabled":[516],"fill":[1],"inputmode":[1],"enterkeyhint":[1],"maxlength":[2],"minlength":[2],"name":[1],"placeholder":[1],"readonly":[516],"required":[4],"spellcheck":[4],"cols":[514],"rows":[2],"wrap":[1],"autoGrow":[516,"auto-grow"],"value":[1025],"counter":[4],"counterFormatter":[16],"errorText":[1,"error-text"],"helperText":[1,"helper-text"],"label":[1],"labelPlacement":[1,"label-placement"],"shape":[1],"hasFocus":[32],"isInvalid":[32],"setFocus":[64],"getInputElement":[64]},[[2,"click","onClickCapture"]],{"debounce":[{"debounceChanged":0}],"value":[{"valueChanged":0}],"dir":[{"onDirChanged":0}]}]]],["ion-backdrop",[[33,"ion-backdrop",{"visible":[4],"tappable":[4],"stopPropagation":[4,"stop-propagation"]},[[2,"click","onMouseDown"]]]]],["ion-loading",[[34,"ion-loading",{"overlayIndex":[2,"overlay-index"],"delegate":[16],"hasController":[4,"has-controller"],"keyboardClose":[4,"keyboard-close"],"enterAnimation":[16],"leaveAnimation":[16],"message":[1],"cssClass":[1,"css-class"],"duration":[2],"backdropDismiss":[4,"backdrop-dismiss"],"showBackdrop":[4,"show-backdrop"],"spinner":[1025],"translucent":[4],"animated":[4],"htmlAttributes":[16],"isOpen":[4,"is-open"],"trigger":[1],"present":[64],"dismiss":[64],"onDidDismiss":[64],"onWillDismiss":[64]},null,{"isOpen":[{"onIsOpenChange":0}],"trigger":[{"triggerChanged":0}]}]]],["ion-breadcrumb_2",[[289,"ion-breadcrumb",{"collapsed":[4],"last":[4],"showCollapsedIndicator":[4,"show-collapsed-indicator"],"color":[1],"active":[4],"disabled":[4],"download":[1],"href":[1],"rel":[1],"separator":[4],"target":[1],"routerDirection":[1,"router-direction"],"routerAnimation":[16]}],[289,"ion-breadcrumbs",{"color":[513],"maxItems":[2,"max-items"],"itemsBeforeCollapse":[2,"items-before-collapse"],"itemsAfterCollapse":[2,"items-after-collapse"],"collapsed":[32],"activeChanged":[32]},[[0,"collapsedClick","onCollapsedClick"]],{"maxItems":[{"maxItemsChanged":0}],"itemsBeforeCollapse":[{"maxItemsChanged":0}],"itemsAfterCollapse":[{"maxItemsChanged":0}]}]]],["ion-tab-bar_2",[[289,"ion-tab-button",{"disabled":[4],"download":[1],"href":[1],"rel":[1],"layout":[1025],"selected":[1028],"tab":[1],"target":[1]},[[8,"ionTabBarChanged","onTabBarChanged"]]],[289,"ion-tab-bar",{"color":[513],"selectedTab":[1,"selected-tab"],"translucent":[4],"keyboardVisible":[32]},null,{"selectedTab":[{"selectedTabChanged":0}]}]]],["ion-datetime-button",[[289,"ion-datetime-button",{"color":[513],"disabled":[516],"datetime":[1],"datetimePresentation":[32],"dateText":[32],"timeText":[32],"datetimeActive":[32],"selectedButton":[32]}]]],["ion-route_4",[[0,"ion-route",{"url":[1],"component":[1],"componentProps":[16],"beforeLeave":[16],"beforeEnter":[16]},null,{"url":[{"onUpdate":0}],"component":[{"onUpdate":0}],"componentProps":[{"onComponentProps":0}]}],[0,"ion-route-redirect",{"from":[1],"to":[1]},null,{"from":[{"propDidChange":0}],"to":[{"propDidChange":0}]}],[0,"ion-router",{"root":[1],"useHash":[4,"use-hash"],"canTransition":[64],"push":[64],"back":[64],"printDebug":[64],"navChanged":[64]},[[8,"popstate","onPopState"],[4,"ionBackButton","onBackButton"]]],[257,"ion-router-link",{"color":[513],"href":[1],"rel":[1],"routerDirection":[1,"router-direction"],"routerAnimation":[16],"target":[1]}]]],["ion-avatar_3",[[289,"ion-avatar"],[289,"ion-badge",{"color":[513]}],[257,"ion-thumbnail"]]],["ion-col_3",[[257,"ion-col",{"offset":[1],"offsetXs":[1,"offset-xs"],"offsetSm":[1,"offset-sm"],"offsetMd":[1,"offset-md"],"offsetLg":[1,"offset-lg"],"offsetXl":[1,"offset-xl"],"pull":[1],"pullXs":[1,"pull-xs"],"pullSm":[1,"pull-sm"],"pullMd":[1,"pull-md"],"pullLg":[1,"pull-lg"],"pullXl":[1,"pull-xl"],"push":[1],"pushXs":[1,"push-xs"],"pushSm":[1,"push-sm"],"pushMd":[1,"push-md"],"pushLg":[1,"push-lg"],"pushXl":[1,"push-xl"],"size":[1],"sizeXs":[1,"size-xs"],"sizeSm":[1,"size-sm"],"sizeMd":[1,"size-md"],"sizeLg":[1,"size-lg"],"sizeXl":[1,"size-xl"]},[[9,"resize","onResize"]]],[257,"ion-grid",{"fixed":[4]}],[257,"ion-row"]]],["ion-img",[[1,"ion-img",{"alt":[1],"src":[1],"loadSrc":[32],"loadError":[32]},null,{"src":[{"srcChanged":0}]}]]],["ion-input-otp",[[294,"ion-input-otp",{"autocapitalize":[1],"color":[513],"disabled":[516],"fill":[1],"inputmode":[1],"length":[2],"pattern":[1],"readonly":[516],"separators":[1],"shape":[1],"size":[1],"type":[1],"value":[1032],"inputValues":[32],"hasFocus":[32],"previousInputValues":[32],"setFocus":[64]},null,{"value":[{"valueChanged":0}],"separators":[{"processSeparators":0}],"length":[{"processSeparators":0}]}]]],["ion-progress-bar",[[33,"ion-progress-bar",{"type":[1],"reversed":[4],"value":[2],"buffer":[2],"color":[513]}]]],["ion-range",[[289,"ion-range",{"color":[513],"debounce":[2],"name":[1],"label":[1],"dualKnobs":[4,"dual-knobs"],"min":[2],"max":[2],"pin":[4],"pinFormatter":[16],"snaps":[4],"step":[2],"ticks":[4],"activeBarStart":[1026,"active-bar-start"],"disabled":[4],"value":[1026],"labelPlacement":[1,"label-placement"],"ratioA":[32],"ratioB":[32],"activatedKnob":[32],"focusedKnob":[32],"hoveredKnob":[32],"pressedKnob":[32]},null,{"debounce":[{"debounceChanged":0}],"min":[{"minChanged":0}],"max":[{"maxChanged":0}],"step":[{"stepChanged":0}],"activeBarStart":[{"activeBarStartChanged":0}],"disabled":[{"disabledChanged":0}],"value":[{"valueChanged":0}]}]]],["ion-segment-content",[[257,"ion-segment-content"]]],["ion-segment-view",[[289,"ion-segment-view",{"disabled":[4],"swipeGesture":[4,"swipe-gesture"],"isManualScroll":[32],"setContent":[64]},[[1,"scroll","handleScroll"],[1,"touchstart","handleScrollStart"],[1,"touchend","handleTouchEnd"]]]]],["ion-split-pane",[[289,"ion-split-pane",{"contentId":[513,"content-id"],"disabled":[4],"when":[8],"visible":[32],"isVisible":[64]},null,{"visible":[{"visibleChanged":0}],"disabled":[{"updateState":0}],"when":[{"updateState":0}]}]]],["ion-text",[[257,"ion-text",{"color":[513]}]]],["ion-select-modal",[[34,"ion-select-modal",{"header":[1],"cancelText":[1,"cancel-text"],"multiple":[4],"options":[16]}]]],["ion-datetime_3",[[289,"ion-datetime",{"color":[1],"name":[1],"disabled":[4],"formatOptions":[16],"readonly":[4],"isDateEnabled":[16],"showAdjacentDays":[4,"show-adjacent-days"],"min":[1025],"max":[1025],"presentation":[1],"cancelText":[1,"cancel-text"],"doneText":[1,"done-text"],"clearText":[1,"clear-text"],"yearValues":[8,"year-values"],"monthValues":[8,"month-values"],"dayValues":[8,"day-values"],"hourValues":[8,"hour-values"],"minuteValues":[8,"minute-values"],"locale":[1],"firstDayOfWeek":[2,"first-day-of-week"],"titleSelectedDatesFormatter":[16],"multiple":[4],"highlightedDates":[16],"value":[1025],"showDefaultTitle":[4,"show-default-title"],"showDefaultButtons":[4,"show-default-buttons"],"showClearButton":[4,"show-clear-button"],"showDefaultTimeLabel":[4,"show-default-time-label"],"hourCycle":[1,"hour-cycle"],"size":[1],"preferWheel":[4,"prefer-wheel"],"showMonthAndYear":[32],"activeParts":[32],"workingParts":[32],"isTimePopoverOpen":[32],"forceRenderDate":[32],"confirm":[64],"reset":[64],"cancel":[64]},null,{"formatOptions":[{"formatOptionsChanged":0}],"disabled":[{"disabledChanged":0}],"min":[{"minChanged":0}],"max":[{"maxChanged":0}],"presentation":[{"presentationChanged":0}],"yearValues":[{"yearValuesChanged":0}],"monthValues":[{"monthValuesChanged":0}],"dayValues":[{"dayValuesChanged":0}],"hourValues":[{"hourValuesChanged":0}],"minuteValues":[{"minuteValuesChanged":0}],"value":[{"valueChanged":0}]}],[34,"ion-picker-legacy",{"overlayIndex":[2,"overlay-index"],"delegate":[16],"hasController":[4,"has-controller"],"keyboardClose":[4,"keyboard-close"],"enterAnimation":[16],"leaveAnimation":[16],"buttons":[16],"columns":[16],"cssClass":[1,"css-class"],"duration":[2],"showBackdrop":[4,"show-backdrop"],"backdropDismiss":[4,"backdrop-dismiss"],"animated":[4],"htmlAttributes":[16],"isOpen":[4,"is-open"],"trigger":[1],"presented":[32],"present":[64],"dismiss":[64],"onDidDismiss":[64],"onWillDismiss":[64],"getColumn":[64]},null,{"isOpen":[{"onIsOpenChange":0}],"trigger":[{"triggerChanged":0}]}],[32,"ion-picker-legacy-column",{"col":[16]},null,{"col":[{"colChanged":0}]}]]],["ion-action-sheet",[[34,"ion-action-sheet",{"overlayIndex":[2,"overlay-index"],"delegate":[16],"hasController":[4,"has-controller"],"keyboardClose":[4,"keyboard-close"],"enterAnimation":[16],"leaveAnimation":[16],"buttons":[16],"cssClass":[1,"css-class"],"backdropDismiss":[4,"backdrop-dismiss"],"header":[1],"subHeader":[1,"sub-header"],"translucent":[4],"animated":[4],"htmlAttributes":[16],"isOpen":[4,"is-open"],"trigger":[1],"activeRadioId":[32],"present":[64],"dismiss":[64],"onDidDismiss":[64],"onWillDismiss":[64]},[[0,"keydown","onKeydown"]],{"buttons":[{"buttonsChanged":0}],"isOpen":[{"onIsOpenChange":0}],"trigger":[{"triggerChanged":0}]}]]],["ion-alert",[[34,"ion-alert",{"overlayIndex":[2,"overlay-index"],"delegate":[16],"hasController":[4,"has-controller"],"keyboardClose":[4,"keyboard-close"],"enterAnimation":[16],"leaveAnimation":[16],"cssClass":[1,"css-class"],"header":[1],"subHeader":[1,"sub-header"],"message":[1],"buttons":[16],"inputs":[1040],"backdropDismiss":[4,"backdrop-dismiss"],"translucent":[4],"animated":[4],"htmlAttributes":[16],"isOpen":[4,"is-open"],"trigger":[1],"isButtonGroupWrapped":[32],"present":[64],"dismiss":[64],"onDidDismiss":[64],"onWillDismiss":[64]},[[4,"keydown","onKeydown"]],{"isOpen":[{"onIsOpenChange":0}],"trigger":[{"triggerChanged":0}],"buttons":[{"buttonsChanged":0}],"inputs":[{"inputsChanged":0}]}]]],["ion-modal",[[289,"ion-modal",{"hasController":[4,"has-controller"],"overlayIndex":[2,"overlay-index"],"delegate":[16],"keyboardClose":[4,"keyboard-close"],"enterAnimation":[16],"leaveAnimation":[16],"breakpoints":[16],"expandToScroll":[4,"expand-to-scroll"],"initialBreakpoint":[2,"initial-breakpoint"],"backdropBreakpoint":[2,"backdrop-breakpoint"],"handle":[4],"handleBehavior":[1,"handle-behavior"],"component":[1],"componentProps":[16],"cssClass":[1,"css-class"],"backdropDismiss":[4,"backdrop-dismiss"],"showBackdrop":[4,"show-backdrop"],"animated":[4],"presentingElement":[16],"htmlAttributes":[16],"isOpen":[4,"is-open"],"trigger":[1],"keepContentsMounted":[4,"keep-contents-mounted"],"focusTrap":[4,"focus-trap"],"canDismiss":[4,"can-dismiss"],"isSheetModal":[32],"presented":[32],"present":[64],"dismiss":[64],"onDidDismiss":[64],"onWillDismiss":[64],"setCurrentBreakpoint":[64],"getCurrentBreakpoint":[64]},[[9,"resize","onWindowResize"]],{"isOpen":[{"onIsOpenChange":0}],"trigger":[{"triggerChanged":0}]}]]],["ion-picker",[[289,"ion-picker",{"exitInputMode":[64]},[[1,"touchstart","preventTouchStartPropagation"]]]]],["ion-picker-column",[[257,"ion-picker-column",{"disabled":[4],"value":[1032],"color":[513],"numericInput":[4,"numeric-input"],"ariaLabel":[32],"isActive":[32],"scrollActiveItemIntoView":[64],"setValue":[64],"setFocus":[64]},null,{"aria-label":[{"ariaLabelChanged":0}],"value":[{"valueChange":0}]}]]],["ion-picker-column-option",[[289,"ion-picker-column-option",{"disabled":[4],"value":[8],"color":[513],"ariaLabel":[32]},null,{"aria-label":[{"onAriaLabelChange":0}]}]]],["ion-popover",[[289,"ion-popover",{"hasController":[4,"has-controller"],"delegate":[16],"overlayIndex":[2,"overlay-index"],"enterAnimation":[16],"leaveAnimation":[16],"component":[1],"componentProps":[16],"keyboardClose":[4,"keyboard-close"],"cssClass":[1,"css-class"],"backdropDismiss":[4,"backdrop-dismiss"],"event":[8],"showBackdrop":[4,"show-backdrop"],"translucent":[4],"animated":[4],"htmlAttributes":[16],"triggerAction":[1,"trigger-action"],"trigger":[1],"size":[1],"dismissOnSelect":[4,"dismiss-on-select"],"reference":[1],"side":[1],"alignment":[1025],"arrow":[4],"isOpen":[4,"is-open"],"keyboardEvents":[4,"keyboard-events"],"focusTrap":[4,"focus-trap"],"keepContentsMounted":[4,"keep-contents-mounted"],"presented":[32],"presentFromTrigger":[64],"present":[64],"dismiss":[64],"getParentPopover":[64],"onDidDismiss":[64],"onWillDismiss":[64]},null,{"trigger":[{"onTriggerChange":0}],"triggerAction":[{"onTriggerChange":0}],"isOpen":[{"onIsOpenChange":0}]}]]],["ion-checkbox",[[289,"ion-checkbox",{"color":[513],"name":[1],"checked":[1028],"indeterminate":[1028],"disabled":[4],"errorText":[1,"error-text"],"helperText":[1,"helper-text"],"value":[8],"labelPlacement":[1,"label-placement"],"justify":[1],"alignment":[1],"required":[4],"isInvalid":[32],"hasLabelContent":[32],"hintTextId":[32],"setFocus":[64]}]]],["ion-item_8",[[289,"ion-item-divider",{"color":[513],"sticky":[4]}],[32,"ion-item-group"],[289,"ion-note",{"color":[513]}],[1,"ion-skeleton-text",{"animated":[4]}],[294,"ion-label",{"color":[513],"position":[1],"noAnimate":[32]},null,{"color":[{"colorChanged":0}],"position":[{"positionChanged":0}]}],[289,"ion-list-header",{"color":[513],"lines":[1]}],[289,"ion-item",{"color":[513],"button":[4],"detail":[4],"detailIcon":[1,"detail-icon"],"disabled":[516],"download":[1],"href":[1],"rel":[1],"lines":[1],"routerAnimation":[16],"routerDirection":[1,"router-direction"],"target":[1],"type":[1],"multipleInputs":[32],"focusable":[32],"isInteractive":[32]},[[0,"ionColor","labelColorChanged"],[0,"ionStyle","itemStyle"]],{"button":[{"buttonChanged":0}]}],[32,"ion-list",{"lines":[1],"inset":[4],"closeSlidingItems":[64]}]]],["ion-app_8",[[0,"ion-app",{"setFocus":[64]}],[292,"ion-footer",{"collapse":[1],"translucent":[4],"keyboardVisible":[32]}],[257,"ion-router-outlet",{"mode":[1025],"delegate":[16],"animated":[4],"animation":[16],"swipeHandler":[16],"commit":[64],"setRouteId":[64],"getRouteId":[64]},null,{"swipeHandler":[{"swipeHandlerChanged":0}]}],[257,"ion-content",{"color":[513],"fullscreen":[4],"fixedSlotPlacement":[1,"fixed-slot-placement"],"forceOverscroll":[1028,"force-overscroll"],"scrollX":[4,"scroll-x"],"scrollY":[4,"scroll-y"],"scrollEvents":[4,"scroll-events"],"recalculateDimensions":[64],"getScrollElement":[64],"getBackgroundElement":[64],"scrollToTop":[64],"scrollToBottom":[64],"scrollByPoint":[64],"scrollToPoint":[64]},[[9,"resize","onResize"]]],[292,"ion-header",{"collapse":[1],"translucent":[4]}],[289,"ion-title",{"color":[513],"size":[1]},null,{"size":[{"sizeChanged":0}]}],[289,"ion-toolbar",{"color":[513]},[[0,"ionStyle","childrenStyle"]]],[294,"ion-buttons",{"collapse":[4]}]]],["ion-select_3",[[289,"ion-select",{"cancelText":[1,"cancel-text"],"color":[513],"compareWith":[1,"compare-with"],"disabled":[4],"fill":[1],"errorText":[1,"error-text"],"helperText":[1,"helper-text"],"interface":[1],"interfaceOptions":[8,"interface-options"],"justify":[1],"label":[1],"labelPlacement":[1,"label-placement"],"multiple":[4],"name":[1],"okText":[1,"ok-text"],"placeholder":[1],"selectedText":[1,"selected-text"],"toggleIcon":[1,"toggle-icon"],"expandedIcon":[1,"expanded-icon"],"shape":[1],"value":[1032],"required":[4],"isExpanded":[32],"hasFocus":[32],"isInvalid":[32],"hintTextId":[32],"open":[64]},null,{"disabled":[{"styleChanged":0}],"isExpanded":[{"styleChanged":0}],"placeholder":[{"styleChanged":0}],"value":[{"styleChanged":0}]}],[1,"ion-select-option",{"disabled":[4],"value":[8]}],[34,"ion-select-popover",{"header":[1],"subHeader":[1,"sub-header"],"message":[1],"multiple":[4],"options":[16]}]]],["ion-spinner",[[1,"ion-spinner",{"color":[513],"duration":[2],"name":[1],"paused":[4]}]]],["ion-radio_2",[[289,"ion-radio",{"color":[513],"name":[1],"disabled":[4],"value":[8],"labelPlacement":[1,"label-placement"],"justify":[1],"alignment":[1],"checked":[32],"buttonTabindex":[32],"setFocus":[64],"setButtonTabindex":[64]},null,{"value":[{"valueChanged":0}]}],[292,"ion-radio-group",{"allowEmptySelection":[4,"allow-empty-selection"],"compareWith":[1,"compare-with"],"name":[1],"value":[1032],"helperText":[1,"helper-text"],"errorText":[1,"error-text"],"isInvalid":[32],"hintTextId":[32],"setFocus":[64]},[[4,"keydown","onKeydown"]],{"value":[{"valueChanged":0}]}]]],["ion-ripple-effect",[[1,"ion-ripple-effect",{"type":[1],"addRipple":[64]}]]],["ion-button_2",[[289,"ion-button",{"color":[513],"buttonType":[1025,"button-type"],"disabled":[516],"expand":[513],"fill":[1537],"routerDirection":[1,"router-direction"],"routerAnimation":[16],"download":[1],"href":[1],"rel":[1],"shape":[513],"size":[513],"strong":[4],"target":[1],"type":[1],"form":[1],"isCircle":[32]},null,{"disabled":[{"disabledChanged":0}],"aria-checked":[{"onAriaChanged":0}],"aria-label":[{"onAriaChanged":0}],"aria-pressed":[{"onAriaChanged":0}]}],[1,"ion-icon",{"mode":[1025],"color":[1],"ios":[1],"md":[1],"flipRtl":[4,"flip-rtl"],"name":[513],"src":[1],"icon":[8],"size":[1],"lazy":[4],"sanitize":[4],"svgContent":[32],"isVisible":[32]},null,{"name":[{"loadIcon":0}],"src":[{"loadIcon":0}],"icon":[{"loadIcon":0}],"ios":[{"loadIcon":0}],"md":[{"loadIcon":0}]}]]]]'), n)
});
(function() {
    if (typeof window < "u" && window.Reflect !== void 0 && window.customElements !== void 0) {
        var i = HTMLElement;
        window.HTMLElement = function() {
            return Reflect.construct(i, [], this.constructor)
        }, HTMLElement.prototype = i.prototype, HTMLElement.prototype.constructor = HTMLElement, Object.setPrototypeOf(HTMLElement, i)
    }
})();
var E = ["*"],
    tg = ["outletContent"],
    ig = ["outlet"],
    ng = [
        [
            ["", "slot", "top"]
        ], "*", [
            ["ion-tab"]
        ]
    ],
    og = ["[slot=top]", "*", "ion-tab"];

function rg(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "ion-router-outlet", 5, 1), x("stackWillChange", function(o) {
            L(e);
            let r = v();
            return j(r.onStackWillChange(o))
        })("stackDidChange", function(o) {
            L(e);
            let r = v();
            return j(r.onStackDidChange(o))
        }), b()
    }
}

function sg(i, n) {
    i & 1 && S(0, 2, ["*ngIf", "tabs.length > 0"])
}

function ag(i, n) {
    if (i & 1 && (m(0, "div", 1), jo(1, 2), b()), i & 2) {
        let e = v();
        u(), T("ngTemplateOutlet", e.template)
    }
}

function lg(i, n) {
    if (i & 1 && jo(0, 1), i & 2) {
        let e = v();
        T("ngTemplateOutlet", e.template)
    }
}
var cg = (() => {
        class i extends Qi {
            constructor(e, t) {
                super(e, t)
            }
            writeValue(e) {
                this.elementRef.nativeElement.checked = this.lastValue = e, Qt(this.elementRef)
            }
            _handleIonChange(e) {
                this.handleValueChange(e, e.checked)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(se), l(g))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-checkbox"],
                    ["ion-toggle"]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("ionChange", function(s) {
                        return o._handleIonChange(s.target)
                    })
                },
                standalone: !1,
                features: [lt([{
                    provide: Mi,
                    useExisting: i,
                    multi: !0
                }]), De]
            })
        }
        return i
    })(),
    dg = (() => {
        class i extends Qi {
            el;
            constructor(e, t) {
                super(e, t), this.el = t
            }
            handleInputEvent(e) {
                this.handleValueChange(e, e.value)
            }
            registerOnChange(e) {
                this.el.nativeElement.tagName === "ION-INPUT" || this.el.nativeElement.tagName === "ION-INPUT-OTP" ? super.registerOnChange(t => {
                    e(t === "" ? null : parseFloat(t))
                }) : super.registerOnChange(e)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(se), l(g))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-input", "type", "number"],
                    ["ion-input-otp", 3, "type", "text"],
                    ["ion-range"]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("ionInput", function(s) {
                        return o.handleInputEvent(s.target)
                    })
                },
                standalone: !1,
                features: [lt([{
                    provide: Mi,
                    useExisting: i,
                    multi: !0
                }]), De]
            })
        }
        return i
    })(),
    pg = (() => {
        class i extends Qi {
            constructor(e, t) {
                super(e, t)
            }
            _handleChangeEvent(e) {
                this.handleValueChange(e, e.value)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(se), l(g))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-select"],
                    ["ion-radio-group"],
                    ["ion-segment"],
                    ["ion-datetime"]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("ionChange", function(s) {
                        return o._handleChangeEvent(s.target)
                    })
                },
                standalone: !1,
                features: [lt([{
                    provide: Mi,
                    useExisting: i,
                    multi: !0
                }]), De]
            })
        }
        return i
    })(),
    ug = (() => {
        class i extends Qi {
            constructor(e, t) {
                super(e, t)
            }
            _handleInputEvent(e) {
                this.handleValueChange(e, e.value)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(se), l(g))
            };
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-input", 3, "type", "number"],
                    ["ion-input-otp", "type", "text"],
                    ["ion-textarea"],
                    ["ion-searchbar"]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("ionInput", function(s) {
                        return o._handleInputEvent(s.target)
                    })
                },
                standalone: !1,
                features: [lt([{
                    provide: Mi,
                    useExisting: i,
                    multi: !0
                }]), De]
            })
        }
        return i
    })(),
    hg = (i, n) => {
        let e = i.prototype;
        n.forEach(t => {
            Object.defineProperty(e, t, {
                get() {
                    return this.el[t]
                },
                set(o) {
                    this.z.runOutsideAngular(() => this.el[t] = o)
                },
                configurable: !0
            })
        })
    },
    mg = (i, n) => {
        let e = i.prototype;
        n.forEach(t => {
            e[t] = function() {
                let o = arguments;
                return this.z.runOutsideAngular(() => this.el[t].apply(this.el, o))
            }
        })
    },
    Y = (i, n, e) => {
        e.forEach(t => i[t] = en(n, t))
    };

function D(i) {
    return function(e) {
        let {
            defineCustomElementFn: t,
            inputs: o,
            methods: r
        } = i;
        return t !== void 0 && t(), o && hg(e, o), r && mg(e, r), e
    }
}
var fg = (() => {
        let i = class _s {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || _s)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: _s,
                selectors: [
                    ["ion-accordion"]
                ],
                inputs: {
                    disabled: "disabled",
                    mode: "mode",
                    readonly: "readonly",
                    toggleIcon: "toggleIcon",
                    toggleIconSlot: "toggleIconSlot",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled", "mode", "readonly", "toggleIcon", "toggleIconSlot", "value"]
        })], i), i
    })(),
    gg = (() => {
        let i = class bs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange"])
            }
            static\ u0275fac = function(t) {
                return new(t || bs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: bs,
                selectors: [
                    ["ion-accordion-group"]
                ],
                inputs: {
                    animated: "animated",
                    disabled: "disabled",
                    expand: "expand",
                    mode: "mode",
                    multiple: "multiple",
                    readonly: "readonly",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "disabled", "expand", "mode", "multiple", "readonly", "value"]
        })], i), i
    })(),
    vg = (() => {
        let i = class ys {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionActionSheetDidPresent", "ionActionSheetWillPresent", "ionActionSheetWillDismiss", "ionActionSheetDidDismiss", "didPresent", "willPresent", "willDismiss", "didDismiss"])
            }
            static\ u0275fac = function(t) {
                return new(t || ys)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ys,
                selectors: [
                    ["ion-action-sheet"]
                ],
                inputs: {
                    animated: "animated",
                    backdropDismiss: "backdropDismiss",
                    buttons: "buttons",
                    cssClass: "cssClass",
                    enterAnimation: "enterAnimation",
                    header: "header",
                    htmlAttributes: "htmlAttributes",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    leaveAnimation: "leaveAnimation",
                    mode: "mode",
                    subHeader: "subHeader",
                    translucent: "translucent",
                    trigger: "trigger"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "backdropDismiss", "buttons", "cssClass", "enterAnimation", "header", "htmlAttributes", "isOpen", "keyboardClose", "leaveAnimation", "mode", "subHeader", "translucent", "trigger"],
            methods: ["present", "dismiss", "onDidDismiss", "onWillDismiss"]
        })], i), i
    })(),
    _g = (() => {
        let i = class Cs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionAlertDidPresent", "ionAlertWillPresent", "ionAlertWillDismiss", "ionAlertDidDismiss", "didPresent", "willPresent", "willDismiss", "didDismiss"])
            }
            static\ u0275fac = function(t) {
                return new(t || Cs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Cs,
                selectors: [
                    ["ion-alert"]
                ],
                inputs: {
                    animated: "animated",
                    backdropDismiss: "backdropDismiss",
                    buttons: "buttons",
                    cssClass: "cssClass",
                    enterAnimation: "enterAnimation",
                    header: "header",
                    htmlAttributes: "htmlAttributes",
                    inputs: "inputs",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    leaveAnimation: "leaveAnimation",
                    message: "message",
                    mode: "mode",
                    subHeader: "subHeader",
                    translucent: "translucent",
                    trigger: "trigger"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "backdropDismiss", "buttons", "cssClass", "enterAnimation", "header", "htmlAttributes", "inputs", "isOpen", "keyboardClose", "leaveAnimation", "message", "mode", "subHeader", "translucent", "trigger"],
            methods: ["present", "dismiss", "onDidDismiss", "onWillDismiss"]
        })], i), i
    })(),
    bg = (() => {
        let i = class Ss {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ss)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ss,
                selectors: [
                    ["ion-app"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            methods: ["setFocus"]
        })], i), i
    })(),
    yg = (() => {
        let i = class Is {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Is)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Is,
                selectors: [
                    ["ion-avatar"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({})], i), i
    })(),
    Cg = (() => {
        let i = class ws {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionBackdropTap"])
            }
            static\ u0275fac = function(t) {
                return new(t || ws)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ws,
                selectors: [
                    ["ion-backdrop"]
                ],
                inputs: {
                    stopPropagation: "stopPropagation",
                    tappable: "tappable",
                    visible: "visible"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["stopPropagation", "tappable", "visible"]
        })], i), i
    })(),
    Sg = (() => {
        let i = class Es {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Es)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Es,
                selectors: [
                    ["ion-badge"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode"]
        })], i), i
    })(),
    Ig = (() => {
        let i = class Ds {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ds)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ds,
                selectors: [
                    ["ion-breadcrumb"]
                ],
                inputs: {
                    active: "active",
                    color: "color",
                    disabled: "disabled",
                    download: "download",
                    href: "href",
                    mode: "mode",
                    rel: "rel",
                    routerAnimation: "routerAnimation",
                    routerDirection: "routerDirection",
                    separator: "separator",
                    target: "target"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["active", "color", "disabled", "download", "href", "mode", "rel", "routerAnimation", "routerDirection", "separator", "target"]
        })], i), i
    })(),
    wg = (() => {
        let i = class Ts {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionCollapsedClick"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ts)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ts,
                selectors: [
                    ["ion-breadcrumbs"]
                ],
                inputs: {
                    color: "color",
                    itemsAfterCollapse: "itemsAfterCollapse",
                    itemsBeforeCollapse: "itemsBeforeCollapse",
                    maxItems: "maxItems",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "itemsAfterCollapse", "itemsBeforeCollapse", "maxItems", "mode"]
        })], i), i
    })(),
    Eg = (() => {
        let i = class xs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || xs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: xs,
                selectors: [
                    ["ion-button"]
                ],
                inputs: {
                    buttonType: "buttonType",
                    color: "color",
                    disabled: "disabled",
                    download: "download",
                    expand: "expand",
                    fill: "fill",
                    form: "form",
                    href: "href",
                    mode: "mode",
                    rel: "rel",
                    routerAnimation: "routerAnimation",
                    routerDirection: "routerDirection",
                    shape: "shape",
                    size: "size",
                    strong: "strong",
                    target: "target",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["buttonType", "color", "disabled", "download", "expand", "fill", "form", "href", "mode", "rel", "routerAnimation", "routerDirection", "shape", "size", "strong", "target", "type"]
        })], i), i
    })(),
    Dg = (() => {
        let i = class Ps {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ps)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ps,
                selectors: [
                    ["ion-buttons"]
                ],
                inputs: {
                    collapse: "collapse"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["collapse"]
        })], i), i
    })(),
    Tg = (() => {
        let i = class ks {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ks)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ks,
                selectors: [
                    ["ion-card"]
                ],
                inputs: {
                    button: "button",
                    color: "color",
                    disabled: "disabled",
                    download: "download",
                    href: "href",
                    mode: "mode",
                    rel: "rel",
                    routerAnimation: "routerAnimation",
                    routerDirection: "routerDirection",
                    target: "target",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["button", "color", "disabled", "download", "href", "mode", "rel", "routerAnimation", "routerDirection", "target", "type"]
        })], i), i
    })(),
    xg = (() => {
        let i = class Ms {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ms)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ms,
                selectors: [
                    ["ion-card-content"]
                ],
                inputs: {
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["mode"]
        })], i), i
    })(),
    Pg = (() => {
        let i = class Rs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Rs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Rs,
                selectors: [
                    ["ion-card-header"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode",
                    translucent: "translucent"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode", "translucent"]
        })], i), i
    })(),
    kg = (() => {
        let i = class As {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || As)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: As,
                selectors: [
                    ["ion-card-subtitle"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode"]
        })], i), i
    })(),
    Mg = (() => {
        let i = class Os {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Os)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Os,
                selectors: [
                    ["ion-card-title"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode"]
        })], i), i
    })(),
    Rg = (() => {
        let i = class Ns {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange", "ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ns)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ns,
                selectors: [
                    ["ion-checkbox"]
                ],
                inputs: {
                    alignment: "alignment",
                    checked: "checked",
                    color: "color",
                    disabled: "disabled",
                    errorText: "errorText",
                    helperText: "helperText",
                    indeterminate: "indeterminate",
                    justify: "justify",
                    labelPlacement: "labelPlacement",
                    mode: "mode",
                    name: "name",
                    required: "required",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["alignment", "checked", "color", "disabled", "errorText", "helperText", "indeterminate", "justify", "labelPlacement", "mode", "name", "required", "value"]
        })], i), i
    })(),
    Ag = (() => {
        let i = class Ls {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ls)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ls,
                selectors: [
                    ["ion-chip"]
                ],
                inputs: {
                    color: "color",
                    disabled: "disabled",
                    mode: "mode",
                    outline: "outline"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "disabled", "mode", "outline"]
        })], i), i
    })(),
    Og = (() => {
        let i = class js {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || js)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: js,
                selectors: [
                    ["ion-col"]
                ],
                inputs: {
                    offset: "offset",
                    offsetLg: "offsetLg",
                    offsetMd: "offsetMd",
                    offsetSm: "offsetSm",
                    offsetXl: "offsetXl",
                    offsetXs: "offsetXs",
                    pull: "pull",
                    pullLg: "pullLg",
                    pullMd: "pullMd",
                    pullSm: "pullSm",
                    pullXl: "pullXl",
                    pullXs: "pullXs",
                    push: "push",
                    pushLg: "pushLg",
                    pushMd: "pushMd",
                    pushSm: "pushSm",
                    pushXl: "pushXl",
                    pushXs: "pushXs",
                    size: "size",
                    sizeLg: "sizeLg",
                    sizeMd: "sizeMd",
                    sizeSm: "sizeSm",
                    sizeXl: "sizeXl",
                    sizeXs: "sizeXs"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["offset", "offsetLg", "offsetMd", "offsetSm", "offsetXl", "offsetXs", "pull", "pullLg", "pullMd", "pullSm", "pullXl", "pullXs", "push", "pushLg", "pushMd", "pushSm", "pushXl", "pushXs", "size", "sizeLg", "sizeMd", "sizeSm", "sizeXl", "sizeXs"]
        })], i), i
    })(),
    Ng = (() => {
        let i = class Fs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionScrollStart", "ionScroll", "ionScrollEnd"])
            }
            static\ u0275fac = function(t) {
                return new(t || Fs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Fs,
                selectors: [
                    ["ion-content"]
                ],
                inputs: {
                    color: "color",
                    fixedSlotPlacement: "fixedSlotPlacement",
                    forceOverscroll: "forceOverscroll",
                    fullscreen: "fullscreen",
                    scrollEvents: "scrollEvents",
                    scrollX: "scrollX",
                    scrollY: "scrollY"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "fixedSlotPlacement", "forceOverscroll", "fullscreen", "scrollEvents", "scrollX", "scrollY"],
            methods: ["getScrollElement", "scrollToTop", "scrollToBottom", "scrollByPoint", "scrollToPoint"]
        })], i), i
    })(),
    Lg = (() => {
        let i = class Bs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionCancel", "ionChange", "ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || Bs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Bs,
                selectors: [
                    ["ion-datetime"]
                ],
                inputs: {
                    cancelText: "cancelText",
                    clearText: "clearText",
                    color: "color",
                    dayValues: "dayValues",
                    disabled: "disabled",
                    doneText: "doneText",
                    firstDayOfWeek: "firstDayOfWeek",
                    formatOptions: "formatOptions",
                    highlightedDates: "highlightedDates",
                    hourCycle: "hourCycle",
                    hourValues: "hourValues",
                    isDateEnabled: "isDateEnabled",
                    locale: "locale",
                    max: "max",
                    min: "min",
                    minuteValues: "minuteValues",
                    mode: "mode",
                    monthValues: "monthValues",
                    multiple: "multiple",
                    name: "name",
                    preferWheel: "preferWheel",
                    presentation: "presentation",
                    readonly: "readonly",
                    showAdjacentDays: "showAdjacentDays",
                    showClearButton: "showClearButton",
                    showDefaultButtons: "showDefaultButtons",
                    showDefaultTimeLabel: "showDefaultTimeLabel",
                    showDefaultTitle: "showDefaultTitle",
                    size: "size",
                    titleSelectedDatesFormatter: "titleSelectedDatesFormatter",
                    value: "value",
                    yearValues: "yearValues"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["cancelText", "clearText", "color", "dayValues", "disabled", "doneText", "firstDayOfWeek", "formatOptions", "highlightedDates", "hourCycle", "hourValues", "isDateEnabled", "locale", "max", "min", "minuteValues", "mode", "monthValues", "multiple", "name", "preferWheel", "presentation", "readonly", "showAdjacentDays", "showClearButton", "showDefaultButtons", "showDefaultTimeLabel", "showDefaultTitle", "size", "titleSelectedDatesFormatter", "value", "yearValues"],
            methods: ["confirm", "reset", "cancel"]
        })], i), i
    })(),
    jg = (() => {
        let i = class Vs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Vs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Vs,
                selectors: [
                    ["ion-datetime-button"]
                ],
                inputs: {
                    color: "color",
                    datetime: "datetime",
                    disabled: "disabled",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "datetime", "disabled", "mode"]
        })], i), i
    })(),
    Fg = (() => {
        let i = class zs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || zs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: zs,
                selectors: [
                    ["ion-fab"]
                ],
                inputs: {
                    activated: "activated",
                    edge: "edge",
                    horizontal: "horizontal",
                    vertical: "vertical"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["activated", "edge", "horizontal", "vertical"],
            methods: ["close"]
        })], i), i
    })(),
    Bg = (() => {
        let i = class Us {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || Us)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Us,
                selectors: [
                    ["ion-fab-button"]
                ],
                inputs: {
                    activated: "activated",
                    closeIcon: "closeIcon",
                    color: "color",
                    disabled: "disabled",
                    download: "download",
                    href: "href",
                    mode: "mode",
                    rel: "rel",
                    routerAnimation: "routerAnimation",
                    routerDirection: "routerDirection",
                    show: "show",
                    size: "size",
                    target: "target",
                    translucent: "translucent",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["activated", "closeIcon", "color", "disabled", "download", "href", "mode", "rel", "routerAnimation", "routerDirection", "show", "size", "target", "translucent", "type"]
        })], i), i
    })(),
    Vg = (() => {
        let i = class Gs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Gs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Gs,
                selectors: [
                    ["ion-fab-list"]
                ],
                inputs: {
                    activated: "activated",
                    side: "side"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["activated", "side"]
        })], i), i
    })(),
    zg = (() => {
        let i = class Hs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Hs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Hs,
                selectors: [
                    ["ion-footer"]
                ],
                inputs: {
                    collapse: "collapse",
                    mode: "mode",
                    translucent: "translucent"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["collapse", "mode", "translucent"]
        })], i), i
    })(),
    Ug = (() => {
        let i = class Ws {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ws)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ws,
                selectors: [
                    ["ion-grid"]
                ],
                inputs: {
                    fixed: "fixed"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["fixed"]
        })], i), i
    })(),
    Gg = (() => {
        let i = class qs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || qs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: qs,
                selectors: [
                    ["ion-header"]
                ],
                inputs: {
                    collapse: "collapse",
                    mode: "mode",
                    translucent: "translucent"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["collapse", "mode", "translucent"]
        })], i), i
    })(),
    Hg = (() => {
        let i = class Ks {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ks)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ks,
                selectors: [
                    ["ion-icon"]
                ],
                inputs: {
                    color: "color",
                    flipRtl: "flipRtl",
                    icon: "icon",
                    ios: "ios",
                    lazy: "lazy",
                    md: "md",
                    mode: "mode",
                    name: "name",
                    sanitize: "sanitize",
                    size: "size",
                    src: "src"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"]
        })], i), i
    })(),
    Wg = (() => {
        let i = class $s {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionImgWillLoad", "ionImgDidLoad", "ionError"])
            }
            static\ u0275fac = function(t) {
                return new(t || $s)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: $s,
                selectors: [
                    ["ion-img"]
                ],
                inputs: {
                    alt: "alt",
                    src: "src"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["alt", "src"]
        })], i), i
    })(),
    qg = (() => {
        let i = class Qs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionInfinite"])
            }
            static\ u0275fac = function(t) {
                return new(t || Qs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Qs,
                selectors: [
                    ["ion-infinite-scroll"]
                ],
                inputs: {
                    disabled: "disabled",
                    position: "position",
                    threshold: "threshold"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled", "position", "threshold"],
            methods: ["complete"]
        })], i), i
    })(),
    Kg = (() => {
        let i = class Zs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Zs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Zs,
                selectors: [
                    ["ion-infinite-scroll-content"]
                ],
                inputs: {
                    loadingSpinner: "loadingSpinner",
                    loadingText: "loadingText"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["loadingSpinner", "loadingText"]
        })], i), i
    })(),
    $g = (() => {
        let i = class Ys {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionInput", "ionChange", "ionBlur", "ionFocus"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ys)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ys,
                selectors: [
                    ["ion-input"]
                ],
                inputs: {
                    autocapitalize: "autocapitalize",
                    autocomplete: "autocomplete",
                    autocorrect: "autocorrect",
                    autofocus: "autofocus",
                    clearInput: "clearInput",
                    clearInputIcon: "clearInputIcon",
                    clearOnEdit: "clearOnEdit",
                    color: "color",
                    counter: "counter",
                    counterFormatter: "counterFormatter",
                    debounce: "debounce",
                    disabled: "disabled",
                    enterkeyhint: "enterkeyhint",
                    errorText: "errorText",
                    fill: "fill",
                    helperText: "helperText",
                    inputmode: "inputmode",
                    label: "label",
                    labelPlacement: "labelPlacement",
                    max: "max",
                    maxlength: "maxlength",
                    min: "min",
                    minlength: "minlength",
                    mode: "mode",
                    multiple: "multiple",
                    name: "name",
                    pattern: "pattern",
                    placeholder: "placeholder",
                    readonly: "readonly",
                    required: "required",
                    shape: "shape",
                    spellcheck: "spellcheck",
                    step: "step",
                    type: "type",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["autocapitalize", "autocomplete", "autocorrect", "autofocus", "clearInput", "clearInputIcon", "clearOnEdit", "color", "counter", "counterFormatter", "debounce", "disabled", "enterkeyhint", "errorText", "fill", "helperText", "inputmode", "label", "labelPlacement", "max", "maxlength", "min", "minlength", "mode", "multiple", "name", "pattern", "placeholder", "readonly", "required", "shape", "spellcheck", "step", "type", "value"],
            methods: ["setFocus", "getInputElement"]
        })], i), i
    })(),
    Qg = (() => {
        let i = class Xs {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionInput", "ionChange", "ionComplete", "ionBlur", "ionFocus"])
            }
            static\ u0275fac = function(t) {
                return new(t || Xs)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Xs,
                selectors: [
                    ["ion-input-otp"]
                ],
                inputs: {
                    autocapitalize: "autocapitalize",
                    color: "color",
                    disabled: "disabled",
                    fill: "fill",
                    inputmode: "inputmode",
                    length: "length",
                    pattern: "pattern",
                    readonly: "readonly",
                    separators: "separators",
                    shape: "shape",
                    size: "size",
                    type: "type",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["autocapitalize", "color", "disabled", "fill", "inputmode", "length", "pattern", "readonly", "separators", "shape", "size", "type", "value"],
            methods: ["setFocus"]
        })], i), i
    })(),
    Zg = (() => {
        let i = class Js {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Js)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Js,
                selectors: [
                    ["ion-input-password-toggle"]
                ],
                inputs: {
                    color: "color",
                    hideIcon: "hideIcon",
                    mode: "mode",
                    showIcon: "showIcon"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "hideIcon", "mode", "showIcon"]
        })], i), i
    })(),
    Yg = (() => {
        let i = class ea {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ea)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ea,
                selectors: [
                    ["ion-item"]
                ],
                inputs: {
                    button: "button",
                    color: "color",
                    detail: "detail",
                    detailIcon: "detailIcon",
                    disabled: "disabled",
                    download: "download",
                    href: "href",
                    lines: "lines",
                    mode: "mode",
                    rel: "rel",
                    routerAnimation: "routerAnimation",
                    routerDirection: "routerDirection",
                    target: "target",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["button", "color", "detail", "detailIcon", "disabled", "download", "href", "lines", "mode", "rel", "routerAnimation", "routerDirection", "target", "type"]
        })], i), i
    })(),
    Xg = (() => {
        let i = class ta {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ta)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ta,
                selectors: [
                    ["ion-item-divider"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode",
                    sticky: "sticky"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode", "sticky"]
        })], i), i
    })(),
    Jg = (() => {
        let i = class ia {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ia)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ia,
                selectors: [
                    ["ion-item-group"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({})], i), i
    })(),
    ev = (() => {
        let i = class na {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || na)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: na,
                selectors: [
                    ["ion-item-option"]
                ],
                inputs: {
                    color: "color",
                    disabled: "disabled",
                    download: "download",
                    expandable: "expandable",
                    href: "href",
                    mode: "mode",
                    rel: "rel",
                    target: "target",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "disabled", "download", "expandable", "href", "mode", "rel", "target", "type"]
        })], i), i
    })(),
    tv = (() => {
        let i = class oa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionSwipe"])
            }
            static\ u0275fac = function(t) {
                return new(t || oa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: oa,
                selectors: [
                    ["ion-item-options"]
                ],
                inputs: {
                    side: "side"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["side"]
        })], i), i
    })(),
    iv = (() => {
        let i = class ra {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionDrag"])
            }
            static\ u0275fac = function(t) {
                return new(t || ra)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ra,
                selectors: [
                    ["ion-item-sliding"]
                ],
                inputs: {
                    disabled: "disabled"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled"],
            methods: ["getOpenAmount", "getSlidingRatio", "open", "close", "closeOpened"]
        })], i), i
    })(),
    nv = (() => {
        let i = class sa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || sa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: sa,
                selectors: [
                    ["ion-label"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode",
                    position: "position"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode", "position"]
        })], i), i
    })(),
    ov = (() => {
        let i = class aa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || aa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: aa,
                selectors: [
                    ["ion-list"]
                ],
                inputs: {
                    inset: "inset",
                    lines: "lines",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["inset", "lines", "mode"],
            methods: ["closeSlidingItems"]
        })], i), i
    })(),
    rv = (() => {
        let i = class la {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || la)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: la,
                selectors: [
                    ["ion-list-header"]
                ],
                inputs: {
                    color: "color",
                    lines: "lines",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "lines", "mode"]
        })], i), i
    })(),
    sv = (() => {
        let i = class ca {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionLoadingDidPresent", "ionLoadingWillPresent", "ionLoadingWillDismiss", "ionLoadingDidDismiss", "didPresent", "willPresent", "willDismiss", "didDismiss"])
            }
            static\ u0275fac = function(t) {
                return new(t || ca)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ca,
                selectors: [
                    ["ion-loading"]
                ],
                inputs: {
                    animated: "animated",
                    backdropDismiss: "backdropDismiss",
                    cssClass: "cssClass",
                    duration: "duration",
                    enterAnimation: "enterAnimation",
                    htmlAttributes: "htmlAttributes",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    leaveAnimation: "leaveAnimation",
                    message: "message",
                    mode: "mode",
                    showBackdrop: "showBackdrop",
                    spinner: "spinner",
                    translucent: "translucent",
                    trigger: "trigger"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "backdropDismiss", "cssClass", "duration", "enterAnimation", "htmlAttributes", "isOpen", "keyboardClose", "leaveAnimation", "message", "mode", "showBackdrop", "spinner", "translucent", "trigger"],
            methods: ["present", "dismiss", "onDidDismiss", "onWillDismiss"]
        })], i), i
    })(),
    av = (() => {
        let i = class da {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionWillOpen", "ionWillClose", "ionDidOpen", "ionDidClose"])
            }
            static\ u0275fac = function(t) {
                return new(t || da)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: da,
                selectors: [
                    ["ion-menu"]
                ],
                inputs: {
                    contentId: "contentId",
                    disabled: "disabled",
                    maxEdgeStart: "maxEdgeStart",
                    menuId: "menuId",
                    side: "side",
                    swipeGesture: "swipeGesture",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["contentId", "disabled", "maxEdgeStart", "menuId", "side", "swipeGesture", "type"],
            methods: ["isOpen", "isActive", "open", "close", "toggle", "setOpen"]
        })], i), i
    })(),
    lv = (() => {
        let i = class pa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || pa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: pa,
                selectors: [
                    ["ion-menu-button"]
                ],
                inputs: {
                    autoHide: "autoHide",
                    color: "color",
                    disabled: "disabled",
                    menu: "menu",
                    mode: "mode",
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["autoHide", "color", "disabled", "menu", "mode", "type"]
        })], i), i
    })(),
    cv = (() => {
        let i = class ua {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ua)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ua,
                selectors: [
                    ["ion-menu-toggle"]
                ],
                inputs: {
                    autoHide: "autoHide",
                    menu: "menu"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["autoHide", "menu"]
        })], i), i
    })(),
    dv = (() => {
        let i = class ha {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ha)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ha,
                selectors: [
                    ["ion-nav-link"]
                ],
                inputs: {
                    component: "component",
                    componentProps: "componentProps",
                    routerAnimation: "routerAnimation",
                    routerDirection: "routerDirection"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["component", "componentProps", "routerAnimation", "routerDirection"]
        })], i), i
    })(),
    pv = (() => {
        let i = class ma {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ma)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ma,
                selectors: [
                    ["ion-note"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode"]
        })], i), i
    })(),
    uv = (() => {
        let i = class fa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || fa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: fa,
                selectors: [
                    ["ion-picker"]
                ],
                inputs: {
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["mode"]
        })], i), i
    })(),
    hv = (() => {
        let i = class ga {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange"])
            }
            static\ u0275fac = function(t) {
                return new(t || ga)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ga,
                selectors: [
                    ["ion-picker-column"]
                ],
                inputs: {
                    color: "color",
                    disabled: "disabled",
                    mode: "mode",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "disabled", "mode", "value"],
            methods: ["setFocus"]
        })], i), i
    })(),
    mv = (() => {
        let i = class va {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || va)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: va,
                selectors: [
                    ["ion-picker-column-option"]
                ],
                inputs: {
                    color: "color",
                    disabled: "disabled",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "disabled", "value"]
        })], i), i
    })(),
    fv = (() => {
        let i = class _a {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionPickerDidPresent", "ionPickerWillPresent", "ionPickerWillDismiss", "ionPickerDidDismiss", "didPresent", "willPresent", "willDismiss", "didDismiss"])
            }
            static\ u0275fac = function(t) {
                return new(t || _a)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: _a,
                selectors: [
                    ["ion-picker-legacy"]
                ],
                inputs: {
                    animated: "animated",
                    backdropDismiss: "backdropDismiss",
                    buttons: "buttons",
                    columns: "columns",
                    cssClass: "cssClass",
                    duration: "duration",
                    enterAnimation: "enterAnimation",
                    htmlAttributes: "htmlAttributes",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    leaveAnimation: "leaveAnimation",
                    mode: "mode",
                    showBackdrop: "showBackdrop",
                    trigger: "trigger"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "backdropDismiss", "buttons", "columns", "cssClass", "duration", "enterAnimation", "htmlAttributes", "isOpen", "keyboardClose", "leaveAnimation", "mode", "showBackdrop", "trigger"],
            methods: ["present", "dismiss", "onDidDismiss", "onWillDismiss", "getColumn"]
        })], i), i
    })(),
    gv = (() => {
        let i = class ba {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ba)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ba,
                selectors: [
                    ["ion-progress-bar"]
                ],
                inputs: {
                    buffer: "buffer",
                    color: "color",
                    mode: "mode",
                    reversed: "reversed",
                    type: "type",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["buffer", "color", "mode", "reversed", "type", "value"]
        })], i), i
    })(),
    vv = (() => {
        let i = class ya {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || ya)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ya,
                selectors: [
                    ["ion-radio"]
                ],
                inputs: {
                    alignment: "alignment",
                    color: "color",
                    disabled: "disabled",
                    justify: "justify",
                    labelPlacement: "labelPlacement",
                    mode: "mode",
                    name: "name",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["alignment", "color", "disabled", "justify", "labelPlacement", "mode", "name", "value"]
        })], i), i
    })(),
    _v = (() => {
        let i = class Ca {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ca)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ca,
                selectors: [
                    ["ion-radio-group"]
                ],
                inputs: {
                    allowEmptySelection: "allowEmptySelection",
                    compareWith: "compareWith",
                    errorText: "errorText",
                    helperText: "helperText",
                    name: "name",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["allowEmptySelection", "compareWith", "errorText", "helperText", "name", "value"]
        })], i), i
    })(),
    bv = (() => {
        let i = class Sa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange", "ionInput", "ionFocus", "ionBlur", "ionKnobMoveStart", "ionKnobMoveEnd"])
            }
            static\ u0275fac = function(t) {
                return new(t || Sa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Sa,
                selectors: [
                    ["ion-range"]
                ],
                inputs: {
                    activeBarStart: "activeBarStart",
                    color: "color",
                    debounce: "debounce",
                    disabled: "disabled",
                    dualKnobs: "dualKnobs",
                    label: "label",
                    labelPlacement: "labelPlacement",
                    max: "max",
                    min: "min",
                    mode: "mode",
                    name: "name",
                    pin: "pin",
                    pinFormatter: "pinFormatter",
                    snaps: "snaps",
                    step: "step",
                    ticks: "ticks",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["activeBarStart", "color", "debounce", "disabled", "dualKnobs", "label", "labelPlacement", "max", "min", "mode", "name", "pin", "pinFormatter", "snaps", "step", "ticks", "value"]
        })], i), i
    })(),
    yv = (() => {
        let i = class Ia {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionRefresh", "ionPull", "ionStart", "ionPullStart", "ionPullEnd"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ia)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ia,
                selectors: [
                    ["ion-refresher"]
                ],
                inputs: {
                    closeDuration: "closeDuration",
                    disabled: "disabled",
                    mode: "mode",
                    pullFactor: "pullFactor",
                    pullMax: "pullMax",
                    pullMin: "pullMin",
                    snapbackDuration: "snapbackDuration"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["closeDuration", "disabled", "mode", "pullFactor", "pullMax", "pullMin", "snapbackDuration"],
            methods: ["complete", "cancel", "getProgress"]
        })], i), i
    })(),
    Cv = (() => {
        let i = class wa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || wa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: wa,
                selectors: [
                    ["ion-refresher-content"]
                ],
                inputs: {
                    pullingIcon: "pullingIcon",
                    pullingText: "pullingText",
                    refreshingSpinner: "refreshingSpinner",
                    refreshingText: "refreshingText"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["pullingIcon", "pullingText", "refreshingSpinner", "refreshingText"]
        })], i), i
    })(),
    Sv = (() => {
        let i = class Ea {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ea)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ea,
                selectors: [
                    ["ion-reorder"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({})], i), i
    })(),
    Iv = (() => {
        let i = class Da {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionItemReorder", "ionReorderStart", "ionReorderMove", "ionReorderEnd"])
            }
            static\ u0275fac = function(t) {
                return new(t || Da)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Da,
                selectors: [
                    ["ion-reorder-group"]
                ],
                inputs: {
                    disabled: "disabled"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled"],
            methods: ["complete"]
        })], i), i
    })(),
    wv = (() => {
        let i = class Ta {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ta)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ta,
                selectors: [
                    ["ion-ripple-effect"]
                ],
                inputs: {
                    type: "type"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["type"],
            methods: ["addRipple"]
        })], i), i
    })(),
    Ev = (() => {
        let i = class xa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || xa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: xa,
                selectors: [
                    ["ion-row"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({})], i), i
    })(),
    Dv = (() => {
        let i = class Pa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionInput", "ionChange", "ionCancel", "ionClear", "ionBlur", "ionFocus"])
            }
            static\ u0275fac = function(t) {
                return new(t || Pa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Pa,
                selectors: [
                    ["ion-searchbar"]
                ],
                inputs: {
                    animated: "animated",
                    autocapitalize: "autocapitalize",
                    autocomplete: "autocomplete",
                    autocorrect: "autocorrect",
                    cancelButtonIcon: "cancelButtonIcon",
                    cancelButtonText: "cancelButtonText",
                    clearIcon: "clearIcon",
                    color: "color",
                    debounce: "debounce",
                    disabled: "disabled",
                    enterkeyhint: "enterkeyhint",
                    inputmode: "inputmode",
                    maxlength: "maxlength",
                    minlength: "minlength",
                    mode: "mode",
                    name: "name",
                    placeholder: "placeholder",
                    searchIcon: "searchIcon",
                    showCancelButton: "showCancelButton",
                    showClearButton: "showClearButton",
                    spellcheck: "spellcheck",
                    type: "type",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "autocapitalize", "autocomplete", "autocorrect", "cancelButtonIcon", "cancelButtonText", "clearIcon", "color", "debounce", "disabled", "enterkeyhint", "inputmode", "maxlength", "minlength", "mode", "name", "placeholder", "searchIcon", "showCancelButton", "showClearButton", "spellcheck", "type", "value"],
            methods: ["setFocus", "getInputElement"]
        })], i), i
    })(),
    Tv = (() => {
        let i = class ka {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange"])
            }
            static\ u0275fac = function(t) {
                return new(t || ka)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ka,
                selectors: [
                    ["ion-segment"]
                ],
                inputs: {
                    color: "color",
                    disabled: "disabled",
                    mode: "mode",
                    scrollable: "scrollable",
                    selectOnFocus: "selectOnFocus",
                    swipeGesture: "swipeGesture",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "disabled", "mode", "scrollable", "selectOnFocus", "swipeGesture", "value"]
        })], i), i
    })(),
    xv = (() => {
        let i = class Ma {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ma)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ma,
                selectors: [
                    ["ion-segment-button"]
                ],
                inputs: {
                    contentId: "contentId",
                    disabled: "disabled",
                    layout: "layout",
                    mode: "mode",
                    type: "type",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["contentId", "disabled", "layout", "mode", "type", "value"]
        })], i), i
    })(),
    Pv = (() => {
        let i = class Ra {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ra)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ra,
                selectors: [
                    ["ion-segment-content"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({})], i), i
    })(),
    kv = (() => {
        let i = class Aa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionSegmentViewScroll"])
            }
            static\ u0275fac = function(t) {
                return new(t || Aa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Aa,
                selectors: [
                    ["ion-segment-view"]
                ],
                inputs: {
                    disabled: "disabled",
                    swipeGesture: "swipeGesture"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled", "swipeGesture"]
        })], i), i
    })(),
    Mv = (() => {
        let i = class Oa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange", "ionCancel", "ionDismiss", "ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || Oa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Oa,
                selectors: [
                    ["ion-select"]
                ],
                inputs: {
                    cancelText: "cancelText",
                    color: "color",
                    compareWith: "compareWith",
                    disabled: "disabled",
                    errorText: "errorText",
                    expandedIcon: "expandedIcon",
                    fill: "fill",
                    helperText: "helperText",
                    interface: "interface",
                    interfaceOptions: "interfaceOptions",
                    justify: "justify",
                    label: "label",
                    labelPlacement: "labelPlacement",
                    mode: "mode",
                    multiple: "multiple",
                    name: "name",
                    okText: "okText",
                    placeholder: "placeholder",
                    required: "required",
                    selectedText: "selectedText",
                    shape: "shape",
                    toggleIcon: "toggleIcon",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["cancelText", "color", "compareWith", "disabled", "errorText", "expandedIcon", "fill", "helperText", "interface", "interfaceOptions", "justify", "label", "labelPlacement", "mode", "multiple", "name", "okText", "placeholder", "required", "selectedText", "shape", "toggleIcon", "value"],
            methods: ["open"]
        })], i), i
    })(),
    Rv = (() => {
        let i = class Na {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Na)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Na,
                selectors: [
                    ["ion-select-modal"]
                ],
                inputs: {
                    cancelText: "cancelText",
                    header: "header",
                    multiple: "multiple",
                    options: "options"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["cancelText", "header", "multiple", "options"]
        })], i), i
    })(),
    Av = (() => {
        let i = class La {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || La)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: La,
                selectors: [
                    ["ion-select-option"]
                ],
                inputs: {
                    disabled: "disabled",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled", "value"]
        })], i), i
    })(),
    Ov = (() => {
        let i = class ja {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || ja)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: ja,
                selectors: [
                    ["ion-skeleton-text"]
                ],
                inputs: {
                    animated: "animated"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated"]
        })], i), i
    })(),
    Nv = (() => {
        let i = class Fa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Fa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Fa,
                selectors: [
                    ["ion-spinner"]
                ],
                inputs: {
                    color: "color",
                    duration: "duration",
                    name: "name",
                    paused: "paused"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "duration", "name", "paused"]
        })], i), i
    })(),
    Lv = (() => {
        let i = class Ba {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionSplitPaneVisible"])
            }
            static\ u0275fac = function(t) {
                return new(t || Ba)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ba,
                selectors: [
                    ["ion-split-pane"]
                ],
                inputs: {
                    contentId: "contentId",
                    disabled: "disabled",
                    when: "when"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["contentId", "disabled", "when"]
        })], i), i
    })(),
    Yu = (() => {
        let i = class Va {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Va)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Va,
                selectors: [
                    ["ion-tab"]
                ],
                inputs: {
                    component: "component",
                    tab: "tab"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["component", "tab"],
            methods: ["setActive"]
        })], i), i
    })(),
    za = (() => {
        let i = class Ua {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ua)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ua,
                selectors: [
                    ["ion-tab-bar"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode",
                    selectedTab: "selectedTab",
                    translucent: "translucent"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode", "selectedTab", "translucent"]
        })], i), i
    })(),
    jv = (() => {
        let i = class Ga {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ga)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ga,
                selectors: [
                    ["ion-tab-button"]
                ],
                inputs: {
                    disabled: "disabled",
                    download: "download",
                    href: "href",
                    layout: "layout",
                    mode: "mode",
                    rel: "rel",
                    selected: "selected",
                    tab: "tab",
                    target: "target"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["disabled", "download", "href", "layout", "mode", "rel", "selected", "tab", "target"]
        })], i), i
    })(),
    Fv = (() => {
        let i = class Ha {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ha)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ha,
                selectors: [
                    ["ion-text"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode"]
        })], i), i
    })(),
    Bv = (() => {
        let i = class Wa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange", "ionInput", "ionBlur", "ionFocus"])
            }
            static\ u0275fac = function(t) {
                return new(t || Wa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Wa,
                selectors: [
                    ["ion-textarea"]
                ],
                inputs: {
                    autoGrow: "autoGrow",
                    autocapitalize: "autocapitalize",
                    autofocus: "autofocus",
                    clearOnEdit: "clearOnEdit",
                    color: "color",
                    cols: "cols",
                    counter: "counter",
                    counterFormatter: "counterFormatter",
                    debounce: "debounce",
                    disabled: "disabled",
                    enterkeyhint: "enterkeyhint",
                    errorText: "errorText",
                    fill: "fill",
                    helperText: "helperText",
                    inputmode: "inputmode",
                    label: "label",
                    labelPlacement: "labelPlacement",
                    maxlength: "maxlength",
                    minlength: "minlength",
                    mode: "mode",
                    name: "name",
                    placeholder: "placeholder",
                    readonly: "readonly",
                    required: "required",
                    rows: "rows",
                    shape: "shape",
                    spellcheck: "spellcheck",
                    value: "value",
                    wrap: "wrap"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["autoGrow", "autocapitalize", "autofocus", "clearOnEdit", "color", "cols", "counter", "counterFormatter", "debounce", "disabled", "enterkeyhint", "errorText", "fill", "helperText", "inputmode", "label", "labelPlacement", "maxlength", "minlength", "mode", "name", "placeholder", "readonly", "required", "rows", "shape", "spellcheck", "value", "wrap"],
            methods: ["setFocus", "getInputElement"]
        })], i), i
    })(),
    Vv = (() => {
        let i = class qa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || qa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: qa,
                selectors: [
                    ["ion-thumbnail"]
                ],
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({})], i), i
    })(),
    zv = (() => {
        let i = class Ka {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Ka)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Ka,
                selectors: [
                    ["ion-title"]
                ],
                inputs: {
                    color: "color",
                    size: "size"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "size"]
        })], i), i
    })(),
    Uv = (() => {
        let i = class $a {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionToastDidPresent", "ionToastWillPresent", "ionToastWillDismiss", "ionToastDidDismiss", "didPresent", "willPresent", "willDismiss", "didDismiss"])
            }
            static\ u0275fac = function(t) {
                return new(t || $a)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: $a,
                selectors: [
                    ["ion-toast"]
                ],
                inputs: {
                    animated: "animated",
                    buttons: "buttons",
                    color: "color",
                    cssClass: "cssClass",
                    duration: "duration",
                    enterAnimation: "enterAnimation",
                    header: "header",
                    htmlAttributes: "htmlAttributes",
                    icon: "icon",
                    isOpen: "isOpen",
                    keyboardClose: "keyboardClose",
                    layout: "layout",
                    leaveAnimation: "leaveAnimation",
                    message: "message",
                    mode: "mode",
                    position: "position",
                    positionAnchor: "positionAnchor",
                    swipeGesture: "swipeGesture",
                    translucent: "translucent",
                    trigger: "trigger"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["animated", "buttons", "color", "cssClass", "duration", "enterAnimation", "header", "htmlAttributes", "icon", "isOpen", "keyboardClose", "layout", "leaveAnimation", "message", "mode", "position", "positionAnchor", "swipeGesture", "translucent", "trigger"],
            methods: ["present", "dismiss", "onDidDismiss", "onWillDismiss"]
        })], i), i
    })(),
    Gv = (() => {
        let i = class Qa {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement, Y(this, this.el, ["ionChange", "ionFocus", "ionBlur"])
            }
            static\ u0275fac = function(t) {
                return new(t || Qa)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Qa,
                selectors: [
                    ["ion-toggle"]
                ],
                inputs: {
                    alignment: "alignment",
                    checked: "checked",
                    color: "color",
                    disabled: "disabled",
                    enableOnOffLabels: "enableOnOffLabels",
                    errorText: "errorText",
                    helperText: "helperText",
                    justify: "justify",
                    labelPlacement: "labelPlacement",
                    mode: "mode",
                    name: "name",
                    required: "required",
                    value: "value"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["alignment", "checked", "color", "disabled", "enableOnOffLabels", "errorText", "helperText", "justify", "labelPlacement", "mode", "name", "required", "value"]
        })], i), i
    })(),
    Hv = (() => {
        let i = class Za {
            z;
            el;
            constructor(e, t, o) {
                this.z = o, e.detach(), this.el = t.nativeElement
            }
            static\ u0275fac = function(t) {
                return new(t || Za)(l(C), l(g), l(f))
            };
            static\ u0275cmp = _({
                type: Za,
                selectors: [
                    ["ion-toolbar"]
                ],
                inputs: {
                    color: "color",
                    mode: "mode"
                },
                standalone: !1,
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        };
        return i = I([D({
            inputs: ["color", "mode"]
        })], i), i
    })(),
    _o = (() => {
        class i extends gs {
            parentOutlet;
            outletContent;
            constructor(e, t, o, r, s, a, c, d) {
                super(e, t, o, r, s, a, c, d), this.parentOutlet = d
            }
            static\ u0275fac = function(t) {
                return new(t || i)(ti("name"), ti("tabs"), l(gt), l(g), l(te), l(f), l(_t), l(i, 12))
            };
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ion-router-outlet"]
                ],
                viewQuery: function(t, o) {
                    if (t & 1 && Pt(tg, 7, Bt), t & 2) {
                        let r;
                        Ge(r = He()) && (o.outletContent = r.first)
                    }
                },
                standalone: !1,
                features: [De],
                ngContentSelectors: E,
                decls: 3,
                vars: 0,
                consts: [
                    ["outletContent", ""]
                ],
                template: function(t, o) {
                    t & 1 && (w(), ln(0, null, 0), S(2), cn())
                },
                encapsulation: 2
            })
        }
        return i
    })(),
    Wv = (() => {
        class i extends Wu {
            outlet;
            tabBar;
            tabBars;
            tabs;
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ion-tabs"]
                ],
                contentQueries: function(t, o, r) {
                    if (t & 1 && Pi(r, za, 5)(r, za, 4)(r, Yu, 4), t & 2) {
                        let s;
                        Ge(s = He()) && (o.tabBar = s.first), Ge(s = He()) && (o.tabBars = s), Ge(s = He()) && (o.tabs = s)
                    }
                },
                viewQuery: function(t, o) {
                    if (t & 1 && Pt(ig, 5, _o), t & 2) {
                        let r;
                        Ge(r = He()) && (o.outlet = r.first)
                    }
                },
                standalone: !1,
                features: [De],
                ngContentSelectors: og,
                decls: 6,
                vars: 2,
                consts: [
                    ["tabsInner", ""],
                    ["outlet", ""],
                    [1, "tabs-inner"],
                    ["tabs", "true", 3, "stackWillChange", "stackDidChange", 4, "ngIf"],
                    [4, "ngIf"],
                    ["tabs", "true", 3, "stackWillChange", "stackDidChange"]
                ],
                template: function(t, o) {
                    t & 1 && (w(ng), S(0), m(1, "div", 2, 0), it(3, rg, 2, 0, "ion-router-outlet", 3)(4, sg, 1, 0, "ng-content", 4), b(), S(5, 1)), t & 2 && (u(3), T("ngIf", o.tabs.length === 0), u(), T("ngIf", o.tabs.length > 0))
                },
                dependencies: [mn, _o],
                styles: ["[_nghost-%COMP%]{display:flex;position:absolute;inset:0;flex-direction:column;width:100%;height:100%;contain:layout size style}.tabs-inner[_ngcontent-%COMP%]{position:relative;flex:1;contain:layout size style}"]
            })
        }
        return i
    })(),
    qv = (() => {
        class i extends zu {
            constructor(e, t, o, r, s, a) {
                super(e, t, o, r, s, a)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(_o, 8), l(Zt), l(fo), l(g), l(f), l(C))
            };
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ion-back-button"]
                ],
                standalone: !1,
                features: [De],
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        }
        return i
    })(),
    Kv = (() => {
        class i extends Uu {
            constructor(e, t, o, r, s, a) {
                super(e, t, o, r, s, a)
            }
            static\ u0275fac = function(t) {
                return new(t || i)(l(g), l(tt), l(se), l(Yt), l(f), l(C))
            };
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ion-nav"]
                ],
                standalone: !1,
                features: [De],
                ngContentSelectors: E,
                decls: 1,
                vars: 0,
                template: function(t, o) {
                    t & 1 && (w(), S(0))
                },
                encapsulation: 2,
                changeDetection: 0
            })
        }
        return i
    })(),
    $v = (() => {
        class i extends Gu {
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["", "routerLink", "", 5, "a", 5, "area"]
                ],
                standalone: !1,
                features: [De]
            })
        }
        return i
    })(),
    Qv = (() => {
        class i extends Hu {
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["a", "routerLink", ""],
                    ["area", "routerLink", ""]
                ],
                standalone: !1,
                features: [De]
            })
        }
        return i
    })(),
    Zv = (() => {
        class i extends Ru {
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ion-modal"]
                ],
                standalone: !1,
                features: [De],
                decls: 1,
                vars: 1,
                consts: [
                    ["class", "ion-delegate-host ion-page", 4, "ngIf"],
                    [1, "ion-delegate-host", "ion-page"],
                    [3, "ngTemplateOutlet"]
                ],
                template: function(t, o) {
                    t & 1 && it(0, ag, 2, 1, "div", 0), t & 2 && T("ngIf", o.isCmpOpen || o.keepContentsMounted)
                },
                dependencies: [mn, Bo],
                encapsulation: 2,
                changeDetection: 0
            })
        }
        return i
    })(),
    Yv = (() => {
        class i extends Au {
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275cmp = _({
                type: i,
                selectors: [
                    ["ion-popover"]
                ],
                standalone: !1,
                features: [De],
                decls: 1,
                vars: 1,
                consts: [
                    [3, "ngTemplateOutlet", 4, "ngIf"],
                    [3, "ngTemplateOutlet"]
                ],
                template: function(t, o) {
                    t & 1 && it(0, lg, 1, 1, "ng-container", 0), t & 2 && T("ngIf", o.isCmpOpen || o.keepContentsMounted)
                },
                dependencies: [mn, Bo],
                encapsulation: 2,
                changeDetection: 0
            })
        }
        return i
    })(),
    Xv = {
        provide: zo,
        useExisting: rn(() => Xu),
        multi: !0
    },
    Xu = (() => {
        class i extends Ul {
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-input", "type", "number", "max", "", "formControlName", ""],
                    ["ion-input", "type", "number", "max", "", "formControl", ""],
                    ["ion-input", "type", "number", "max", "", "ngModel", ""]
                ],
                hostVars: 1,
                hostBindings: function(t, o) {
                    t & 2 && Ue("max", o._enabled ? o.max : null)
                },
                standalone: !1,
                features: [lt([Xv]), De]
            })
        }
        return i
    })(),
    Jv = {
        provide: zo,
        useExisting: rn(() => Ju),
        multi: !0
    },
    Ju = (() => {
        class i extends Gl {
            static\ u0275fac = (() => {
                let e;
                return function(o) {
                    return (e || (e = xt(i)))(o || i)
                }
            })();
            static\ u0275dir = ue({
                type: i,
                selectors: [
                    ["ion-input", "type", "number", "min", "", "formControlName", ""],
                    ["ion-input", "type", "number", "min", "", "formControl", ""],
                    ["ion-input", "type", "number", "min", "", "ngModel", ""]
                ],
                hostVars: 1,
                hostBindings: function(t, o) {
                    t & 2 && Ue("min", o._enabled ? o.min : null)
                },
                standalone: !1,
                features: [lt([Jv]), De]
            })
        }
        return i
    })();
var e_ = (() => {
    class i extends $i {
        angularDelegate = p(Yt);
        injector = p(se);
        environmentInjector = p(tt);
        constructor() {
            super(Yo)
        }
        create(e) {
            let r = e,
                {
                    injector: t
                } = r,
                o = Lt(r, ["injector"]);
            return super.create(It(oe({}, o), {
                delegate: this.angularDelegate.create(this.environmentInjector, this.injector, "modal", t)
            }))
        }
        static\ u0275fac = function(t) {
            return new(t || i)
        };
        static\ u0275prov = A({
            token: i,
            factory: i.\u0275fac
        })
    }
    return i
})();
var Ya = class extends $i {
    angularDelegate = p(Yt);
    injector = p(se);
    environmentInjector = p(tt);
    constructor() {
        super(Xo)
    }
    create(n) {
        let o = n,
            {
                injector: e
            } = o,
            t = Lt(o, ["injector"]);
        return super.create(It(oe({}, t), {
            delegate: this.angularDelegate.create(this.environmentInjector, this.injector, "popover", e)
        }))
    }
};
var t_ = (i, n, e) => () => {
        let t = n.defaultView;
        if (t && typeof window < "u") {
            Jo(It(oe({}, i), {
                _zoneGate: r => e.run(r)
            }));
            let o = "__zone_symbol__addEventListener" in n.body ? "__zone_symbol__addEventListener" : "addEventListener";
            return Zu(t, {
                exclude: ["ion-tabs"],
                syncQueue: !0,
                raf: vs,
                jmp: r => e.runOutsideAngular(r),
                ael(r, s, a, c) {
                    r[o](s, a, c)
                },
                rel(r, s, a, c) {
                    r.removeEventListener(s, a, c)
                }
            })
        }
    },
    i_ = [fg, gg, vg, _g, bg, yg, Cg, Sg, Ig, wg, Eg, Dg, Tg, xg, Pg, kg, Mg, Rg, Ag, Og, Ng, Lg, jg, Fg, Bg, Vg, zg, Ug, Gg, Hg, Wg, qg, Kg, $g, Qg, Zg, Yg, Xg, Jg, ev, tv, iv, nv, ov, rv, sv, av, lv, cv, dv, pv, uv, hv, mv, fv, gv, vv, _v, bv, yv, Cv, Sv, Iv, wv, Ev, Dv, Tv, xv, Pv, kv, Mv, Rv, Av, Ov, Nv, Lv, Yu, za, jv, Fv, Bv, Vv, zv, Uv, Gv, Hv],
    ES = [...i_, Zv, Yv, cg, dg, pg, ug, Wv, _o, qv, Kv, $v, Qv, Ju, Xu],
    eh = (() => {
        class i {
            static forRoot(e = {}) {
                return {
                    ngModule: i,
                    providers: [{
                        provide: go,
                        useValue: e
                    }, {
                        provide: _l,
                        useFactory: t_,
                        multi: !0,
                        deps: [go, Ae, f]
                    }, Yt, Vu()]
                }
            }
            static\ u0275fac = function(t) {
                return new(t || i)
            };
            static\ u0275mod = Ie({
                type: i
            });
            static\ u0275inj = Se({
                providers: [e_, Ya],
                imports: [oi]
            })
        }
        return i
    })();
var n_ = ["jobs", "dashboards", "customers", "mobileMenu"],
    th = (() => {
        class i {
            constructor(e) {
                this.userDeviceService = e
            }
            preload(e, t) {
                return this.userDeviceService.isMobileDevice() ? e.path && n_.includes(e.path) ? tn(3e3).pipe(cl(() => t())) : Dt(null) : t()
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || i)(K(Le))
                }
            }
            static {
                this.\u0275prov = A({
                    token: i,
                    factory: i.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return i
    })();
var bo = (() => {
    class i {
        constructor(e, t) {
            this.service = e, this.router = t
        }
        canActivate() {
            return new Promise((e, t) => {
                this.service.getTenant().subscribe({
                    next: o => o.is_completed_wizard_setup ? (this.router.navigate(["/jobs"]), e(!1)) : e(!0),
                    error: o => {
                        console.error(o)
                    }
                }).add(() => t(!1))
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(Pc), K(te))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var ih = (() => {
    class i extends ai {
        constructor(e) {
            super(e, er), this.api = e, this.endpoint = er
        }
        getDestinationUrlByUuid(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(Jc))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var nh = (() => {
    class i {
        constructor(e, t) {
            this.service = e, this.loaderService = t, this.formatMessage = Q, this.router = p(te), this.activatedRouter = p(_t), this.userDeviceService = p(Le)
        }
        ngOnInit() {
            let e = this.activatedRouter.snapshot.queryParamMap.get("c"),
                t = this.activatedRouter.snapshot.queryParamMap.get("t");
            this.loaderService.show(), this.service.getDestinationUrlByUuid({
                uuidCode: e,
                tenantId: t
            }).subscribe({
                next: o => {
                    let r = new URL(o.destination_url),
                        s = r.host.includes("bytephase"),
                        a = r.href.includes("attachments");
                    s && !a && this.userDeviceService.isCapacitorNative() ? this.router.navigateByUrl(r.pathname + r.search) : window.location.href = r.href
                },
                error: o => {
                    console.error(o)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(l(ih), l(Dn))
            }
        }
        static {
            this.\u0275cmp = _({
                type: i,
                selectors: [
                    ["app-signed-sms-short-url"]
                ],
                decls: 4,
                vars: 1,
                consts: [
                    [1, "d-flex", "flex-column", "align-items-center", "justify-content-center", "vh-100", "gap-2"],
                    [1, "fa-thin", "fa-spinner", "fa-spin", "fs-1", "text-primary"],
                    [1, "text-muted", "mb-0"]
                ],
                template: function(t, o) {
                    t & 1 && (an(0, "div", 0), Lo(1, "i", 1), an(2, "p", 2), G(3), No()()), t & 2 && (u(3), ge("", o.formatMessage("loading"), "..."))
                },
                encapsulation: 2
            })
        }
    }
    return i
})();
var r_ = [{
        path: "pricing",
        loadChildren: () =>
            import ("./chunk-VZHTWBZ2.js").then(i => i.SubscriptionModule),
        title: "BytePhase Pricing"
    }, {
        path: "auth",
        loadChildren: () =>
            import ("./chunk-LA57C4SE.js").then(i => i.AuthModule),
        title: "BytePhase Authentication"
    }, {
        path: "permissions",
        loadChildren: () =>
            import ("./chunk-RM26QYHS.js").then(i => i.PermissionsModule),
        title: "BytePhase Permissions"
    }, {
        path: "admin",
        loadChildren: () =>
            import ("./chunk-V3MIHN2B.js").then(i => i.AdminModule),
        title: "Admin Impersonation"
    }, {
        path: "guest",
        loadChildren: () =>
            import ("./chunk-CUPTUCUR.js").then(i => i.GuestModule),
        title: "BytePhase Guest Forms"
    }, {
        path: "jobs",
        loadChildren: () =>
            import ("./chunk-WTNPOCXM.js").then(i => i.JobModule),
        canActivate: [ee, we],
        data: {
            entity: le.JOB
        },
        title: "BytePhase Service Tickets"
    }, {
        path: "leads",
        loadChildren: () =>
            import ("./chunk-AMZOZB7Y.js").then(i => i.LeadModule),
        canActivate: [ee, be, Ze, we],
        data: {
            entity: le.LEAD
        },
        title: "BytePhase Leads"
    }, {
        path: "administrations",
        loadChildren: () =>
            import ("./chunk-PANUDJSZ.js").then(i => i.AdministrationModule),
        canActivate: [ee, be],
        title: "BytePhase Business- Administration"
    }, {
        path: "reports",
        loadChildren: () =>
            import ("./chunk-6PLWPCAA.js").then(i => i.ReportModule),
        canActivate: [ee, be, we],
        data: {
            entity: le.REPORT
        },
        title: "BytePhase Business Reports"
    }, {
        path: "customers",
        loadChildren: () =>
            import ("./chunk-VZD5G554.js").then(i => i.CustomerModule),
        canActivate: [ee, we],
        data: {
            entity: le.CUSTOMER
        },
        title: "BytePhase Manage Customers"
    }, {
        path: "dashboards",
        loadChildren: () =>
            import ("./chunk-2DRW6ZAR.js").then(i => i.DashboardModule),
        canActivate: [ee, be],
        title: "BytePhase Dashboard"
    }, {
        path: "settings",
        loadChildren: () =>
            import ("./chunk-JK2LPPCX.js").then(i => i.SettingModule),
        canActivate: [ee, be],
        title: "BytePhase Settings"
    }, {
        path: "feedbacks",
        loadChildren: () =>
            import ("./chunk-JVQOAI67.js").then(i => i.FeedbackModule),
        canActivate: [ee],
        title: "Feedbacks"
    }, {
        path: "employees",
        loadChildren: () =>
            import ("./chunk-SE2X4BXE.js").then(i => i.EmployeeModule),
        canActivate: [ee, be, we],
        data: {
            entity: le.EMPLOYEE
        },
        title: "BytePhase Manage Employee"
    }, {
        path: "errors",
        loadChildren: () =>
            import ("./chunk-APPCBZWF.js").then(i => i.ErrorModule),
        title: "BytePhase Errors"
    }, {
        path: "setups",
        loadChildren: () =>
            import ("./chunk-UDCV5ZFL.js").then(i => i.SetupModule),
        canActivate: [ee, In, bo],
        title: "BytePhase Setup"
    }, {
        path: "tasks",
        loadChildren: () =>
            import ("./chunk-KGSW36QQ.js").then(i => i.TaskModule),
        canActivate: [ee, be, Ze, we],
        data: {
            entity: le.TASK
        },
        title: "BytePhase Manage Tasks"
    }, {
        path: "templates",
        loadChildren: () =>
            import ("./chunk-XOVLJMKF.js").then(i => i.TemplateModule),
        canActivate: [ee, be],
        title: "BytePhase Notification Templates"
    }, {
        path: "supports",
        loadChildren: () =>
            import ("./chunk-YYSBDW7L.js").then(i => i.SupportModule),
        canActivate: [ee],
        title: "BytePhase Support"
    }, {
        path: "sales",
        loadChildren: () =>
            import ("./chunk-2JMYBBHQ.js").then(i => i.SaleModule),
        canActivate: [ee, Ze, we],
        data: {
            entity: le.SALE
        },
        title: "BytePhase Manage Sales"
    }, {
        path: "expenses",
        loadChildren: () =>
            import ("./chunk-WBY7P2HA.js").then(i => i.ExpenseModule),
        canActivate: [ee, Ze, be, we],
        data: {
            entity: le.EXPENSE
        },
        title: "BytePhase Manage Expenses"
    }, {
        path: "commission",
        loadChildren: () =>
            import ("./chunk-6NS72PNS.js").then(i => i.CommissionModule),
        canActivate: [ee, Ze, be],
        data: {
            entity: le.COMMISSION
        },
        title: "BytePhase Commission"
    }, {
        path: "tracks",
        loadChildren: () =>
            import ("./chunk-XCAOAE3B.js").then(i => i.TrackModule),
        title: "Status Tracking",
        canActivate: [Pn]
    }, {
        path: "amcs",
        loadChildren: () =>
            import ("./chunk-DSBLMEFJ.js").then(i => i.AmcModule),
        data: {
            entity: le.AMC_CONTRACT
        },
        canActivate: [ee, Ze, we],
        title: "BytePhase Manage AMC"
    }, {
        path: "pickupDrops",
        loadChildren: () =>
            import ("./chunk-VMJQ6WTG.js").then(i => i.PickupAndDropModule),
        canActivate: [ee, Ze, Go, we],
        data: {
            entity: le.PICKUP_DROP,
            permissions: {
                only: [$.PICKUP_DROP_LIST]
            }
        },
        title: "BytePhase Manage Pickup Drops"
    }, {
        path: "quotations",
        loadChildren: () =>
            import ("./chunk-WPD2SJGO.js").then(i => i.QuotationModule),
        canActivate: [ee, Ze, we],
        data: {
            entity: le.QUOTATION,
            permissions: {
                only: [$.QUOTATION_LIST]
            }
        },
        title: "BytePhase Manage Quotations"
    }, {
        path: "api",
        loadChildren: () =>
            import ("./chunk-PKXQMD4D.js").then(i => i.SignedRoutesModule)
    }, {
        path: "short/:shortUrlCode",
        loadComponent: () =>
            import ("./chunk-2Z7JDQF3.js").then(i => i.ShortComponent),
        title: "BytePhase Short Urls",
        pathMatch: "full"
    }, {
        path: "billings",
        loadChildren: () =>
            import ("./chunk-K4RMZ5QV.js").then(i => i.BillingModule),
        canActivate: [ee],
        title: "BytePhase Billing"
    }, {
        path: "accounting",
        redirectTo: "billings/accounting",
        pathMatch: "prefix"
    }, {
        path: "mobileMenu",
        loadChildren: () =>
            import ("./chunk-5OA2EMK3.js").then(i => i.MobilesModule),
        canActivate: [ee],
        title: "BytePhase Mobile Menu"
    }, {
        path: "backupDrives",
        loadChildren: () =>
            import ("./chunk-W2R7GSUR.js").then(i => i.BackupDriveModule),
        canActivate: [ee, be, Ze, we],
        data: {
            entity: le.BACKUP_DRIVE,
            permissions: {
                only: [$.BACKUP_DRIVE_LIST]
            }
        },
        title: "BytePhase Backup Drives"
    }, {
        path: "parts",
        loadChildren: () =>
            import ("./chunk-Z2OUDZFP.js").then(i => i.PartModule),
        canActivate: [ee, be, we],
        data: {
            entity: le.PART
        },
        title: "BytePhase Inventory"
    }, {
        path: "imports",
        loadChildren: () =>
            import ("./chunk-THT4FL42.js").then(i => i.ImportModule),
        canActivate: [ee, be],
        title: "BytePhase Import Data"
    }, {
        path: "calender/:user_id",
        component: or,
        canActivate: [ee, be],
        title: "BytePhase Calender"
    }, {
        path: "calendar",
        component: or,
        canActivate: [ee],
        title: "BytePhase Calendar"
    }, {
        path: "purchases",
        loadChildren: () =>
            import ("./chunk-L22FOVT2.js").then(i => i.PurchaseModule),
        canActivate: [ee, be, Ze, we],
        data: {
            entity: le.PURCHASE,
            permissions: {
                only: [$.PURCHASE_LIST]
            }
        },
        title: "BytePhase Manage Purchases"
    }, {
        path: "mailMarketings",
        loadChildren: () =>
            import ("./chunk-JCXRDEWN.js").then(i => i.MailMarketingModule),
        canActivate: [ee, be, Ze, we],
        data: {
            entity: le.MAIL_MARKETING,
            permissions: {
                only: [$.MAIL_MARKETING_LIST]
            }
        },
        title: "BytePhase Manage Marketing"
    }, {
        path: "pickupDrop/receipt/:id",
        component: Xc,
        canActivate: [Go, we],
        data: {
            entity: le.PICKUP_DROP,
            permissions: {
                only: [$.PICKUP_DROP_LIST]
            }
        }
    }, {
        path: "pickupDrop/map",
        component: nd,
        data: {
            entity: le.PICKUP_DROP,
            permissions: {
                only: [$.PICKUP_DROP_WRITE]
            }
        }
    }, {
        path: "referral",
        title: "BytePhase Referrals",
        component: od
    }, {
        path: "s",
        title: "BytePhase SMS Urls",
        component: nh,
        pathMatch: "full"
    }, {
        path: "",
        redirectTo: "/auth/login",
        pathMatch: "full"
    }, {
        path: "**",
        redirectTo: "/errors/404"
    }],
    oh = (() => {
        class i {
            static {
                this.\u0275fac = function(t) {
                    return new(t || i)
                }
            }
            static {
                this.\u0275mod = Ie({
                    type: i
                })
            }
            static {
                this.\u0275inj = Se({
                    imports: [Vt.forRoot(r_, {
                        preloadingStrategy: th
                    }), Vt]
                })
            }
        }
        return i
    })();
var yo = kt("Keyboard");
var rh = kt("SplashScreen", {
    web: () =>
        import ("./chunk-6ZGH2LWF.js").then(i => new i.SplashScreenWeb)
});
var Co = (function(i) {
    return i.Dark = "DARK", i.Light = "LIGHT", i.Default = "DEFAULT", i
})(Co || {});
var Zi = kt("StatusBar");
var Xa = xh(Ph());
var sh = (() => {
    class i {
        constructor() {
            this.tenantService = p(ut), this.generalSettingDataService = p(xn), this.themeService = p(Ye), this.userDeviceService = p(Le)
        }
        initialize() {
            this.configureQuill(), this.configureGlobalSettings(), this.configureComponents()
        }
        reconfigure() {
            this.configureComponents()
        }
        configureQuill() {
            let e = Xa.default.import("blots/block");
            e.tagName = "div", Xa.default.register(e)
        }
        configureGlobalSettings() {
            Sn({
                defaultCurrency: "INR",
                floatingActionButtonConfig: {
                    position: {
                        at: "right bottom",
                        my: "right bottom",
                        offset: "-16 -16"
                    }
                },
                forceIsoDateParsing: !1,
                oDataFilterToLower: !0
            })
        }
        configureComponents() {
            let e = this.themeService.isDarkTheme(),
                t = this.userDeviceService.isMobileDevice();
            if (!this.tenantService.config() ? .general_settings) return;
            let r = this.generalSettingDataService.getGeneralSettingBySettingType(Cc.TABLE_SETTINGS);
            Mc.defaultOptions({
                options: {
                    stylingMode: "contained",
                    type: "normal"
                }
            });
            let s = t ? bn[1].id : this.generalSettingDataService.getGeneralSettingByKey("scrolling_mode") ? ? bn[1].id,
                a = s === bn[0].id;
            td.defaultOptions({
                options: {
                    errorRowEnabled: !1,
                    cellHintEnabled: !0,
                    rowAlternationEnabled: r.row_alternation_enabled ? ? !0,
                    showBorders: !0,
                    showColumnLines: r.show_column_lines ? ? !1,
                    allowColumnReordering: !0,
                    allowColumnResizing: !0,
                    showRowLines: r ? .show_row_lines ? ? !0,
                    hoverStateEnabled: !0,
                    resizeEnabled: !0,
                    columnHidingEnabled: t,
                    columnChooser: {
                        position: t ? {
                            my: "center",
                            at: "center",
                            of: window,
                            collision: "fit"
                        } : {
                            my: "right top",
                            at: "right bottom",
                            of: ".dx-datagrid-column-chooser-button"
                        }
                    },
                    remoteOperations: {
                        groupPaging: !0
                    },
                    sorting: {
                        mode: "single"
                    },
                    pager: {
                        showPageSizeSelector: !t,
                        allowedPageSizes: [15, 20, 25],
                        showInfo: !t,
                        displayMode: t ? "compact" : "full",
                        visible: !t && a
                    },
                    paging: {
                        pageSize: 15
                    },
                    scrolling: {
                        mode: s,
                        useNative: !1
                    },
                    wordWrapEnabled: !0
                }
            }), Gc.defaultOptions({
                options: {
                    showCloseButton: !0,
                    shading: !0,
                    dragEnabled: !t,
                    showTitle: !0,
                    resizeEnabled: !t,
                    hideOnOutsideClick: !1,
                    shadingColor: e ? "rgba(255, 255, 255, 0.2118)" : "rgba(0, 0, 0, 0.5)",
                    height: "auto",
                    maxHeight: t ? "90vh" : "auto"
                }
            }), zc.defaultOptions({
                options: {
                    shading: !0,
                    dragEnabled: !0,
                    showTitle: !1,
                    hideOnOutsideClick: !0,
                    shadingColor: e ? "rgba(255, 255, 255, 0.2118)" : "rgba(0, 0, 0, 0.5)",
                    height: "auto",
                    maxHeight: "auto"
                }
            }), Ac.defaultOptions({
                options: {
                    shading: !0,
                    showIndicator: !0,
                    showPane: !0,
                    shadingColor: "rgba(0,0,0,0.4)"
                }
            }), id.defaultOptions({
                options: {
                    hoverStateEnabled: !0,
                    showNavButtons: !0,
                    focusStateEnabled: !0,
                    scrollByContent: !0,
                    scrollingEnabled: !0
                }
            }), Fc.defaultOptions({
                options: {
                    shading: !0,
                    useNativeScrolling: !0,
                    animationConfig: {}
                }
            }), jc.defaultOptions({
                options: {
                    searchEnabled: !0,
                    useNativeScrolling: !0
                }
            }), Lc.defaultOptions({
                options: {
                    searchEnabled: !0,
                    useNativeScrolling: !0
                }
            }), Nc.defaultOptions({
                options: {
                    displayFormat: fc,
                    dateSerializationFormat: mc
                }
            }), Zc.defaultOptions({
                options: {
                    allowSoftLineBreak: !0
                }
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var ah = (() => {
    class i {
        constructor() {
            this.router = p(te), this.hotkeysService = p(_n), this.authorizationService = p(pi), this.userSessionService = p(pt), this.sidebarService = p(ui)
        }
        registerShortcuts(e) {
            this.registerNavigationShortcuts(e), this.registerPermissionBasedShortcuts(e), this.registerUiActionShortcuts()
        }
        registerNavigationShortcuts(e) {
            this.hotkeysService.add(new me(["alt+j"], () => (e.onJobAdd(), !1))), this.hotkeysService.add(new me(["alt+s"], () => (this.router.navigate(["sales/add"]), !1))), this.hotkeysService.add(new me(["alt+l"], () => (this.router.navigate(["leads/add"]), !1))), this.hotkeysService.add(new me(["alt+c"], () => (this.router.navigate(["customers/add"]), !1))), this.hotkeysService.add(new me(["alt+q"], () => (this.router.navigate(["quotations/add"]), !1))), this.hotkeysService.add(new me(["alt+shift+p"], () => (this.router.navigate(["purchases/add"]), !1))), this.hotkeysService.add(new me(["alt+r"], () => (this.router.navigate(["reports/revenues"]), !1))), this.hotkeysService.add(new me(["ctrl+shift+e"], () => (this.router.navigate(["employees/add"]), !1))), this.hotkeysService.add(new me(["alt+i"], () => (this.router.navigate(["parts/add"]), !1)))
        }
        registerPermissionBasedShortcuts(e) {
            this.hotkeysService.add(new me(["alt+t"], () => (this.authorizationService.canAccess(le.TASK) && e.onShowTaskPopup(), !1))), this.hotkeysService.add(new me(["alt+e"], () => (this.authorizationService.canAccess(le.EXPENSE) && this.router.navigate(["expenses/add"]), !1))), this.hotkeysService.add(new me(["alt+p"], () => (this.authorizationService.canAccess(le.PICKUP_DROP) && e.onShowPickupDropPopup(), !1))), this.hotkeysService.add(new me(["ctrl+shift+s"], () => (this.userSessionService.userPermissionList().includes($.PART_SUPPLIER_WRITE) && this.router.navigate(["parts/partSuppliers/add"]), !1)))
        }
        registerUiActionShortcuts() {
            this.hotkeysService.add(new me(["ctrl+f", "command+f"], () => {
                let e = document.getElementsByClassName("dx-icon-search");
                if (e.length) {
                    let t = e[0].parentElement ? .querySelector("input");
                    t && t.focus()
                }
                return !1
            })), this.hotkeysService.add(new me(["ctrl+/", "command+/"], () => (this.router.navigate(["/globalSearch"]), !1))), this.hotkeysService.add(new me(["alt+w"], () => {
                let e = this.sidebarService.sidebarExpanded.getValue();
                return this.sidebarService.setExpanded(!e), !1
            })), this.hotkeysService.add(new me(["alt+n"], () => (this.toggleBootstrapOffcanvas("notificationAsideLeft"), !1))), this.hotkeysService.add(new me(["alt+x"], () => (this.toggleBootstrapOffcanvas("keyboardAsideLeft"), !1)))
        }
        toggleBootstrapOffcanvas(e) {
            let t = document.getElementById(e);
            if (t)
                if (typeof window.bootstrap < "u")(window.bootstrap.Offcanvas.getInstance(t) || new window.bootstrap.Offcanvas(t)).toggle();
                else {
                    let o = document.querySelector(`[data-bs-target="#${e}"]`);
                    o && o.click()
                }
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var Ja = (function(i) {
    return i[i.UNKNOWN = 0] = "UNKNOWN", i[i.UPDATE_NOT_AVAILABLE = 1] = "UPDATE_NOT_AVAILABLE", i[i.UPDATE_AVAILABLE = 2] = "UPDATE_AVAILABLE", i[i.UPDATE_IN_PROGRESS = 3] = "UPDATE_IN_PROGRESS", i
})(Ja || {});
var el = kt("AppUpdate", {
    web: () =>
        import ("./chunk-EDUW7JBL.js").then(i => new i.AppUpdateWeb)
});
var So = (() => {
    class i extends ai {
        constructor(e) {
            super(e, tr), this.api = e, this.endPoint = tr
        }
        isAppInstalled() {
            return this.api.get(this.endPoint)
        }
        markAppInstalled() {
            return this.api.get(this.endPoint + "/installed")
        }
        isUpdateAvailable() {
            return re(this, null, function*() {
                let e = Qe.getPlatform();
                if (e !== ri.Android && e !== ri.IOS) return !1;
                try {
                    let t = yield el.getAppUpdateInfo();
                    return console.log("[MOBILE-APP-SERVICE] App update info:", {
                        platform: e,
                        updateAvailability: t.updateAvailability,
                        currentVersion: t.currentVersionName,
                        availableVersion: t.availableVersionName ? ? t.availableVersionCode
                    }), t.updateAvailability === Ja.UPDATE_AVAILABLE
                } catch (t) {
                    return (t ? .message ? ? "").includes("Required app information could not be fetched") ? console.log("[MOBILE-APP-SERVICE] Update check skipped \u2014 app not yet listed on store") : console.error("[MOBILE-APP-SERVICE] Error checking for updates:", t), !1
                }
            })
        }
        openAppStore() {
            return re(this, null, function*() {
                try {
                    yield el.openAppStore()
                } catch (e) {
                    throw console.error("[MOBILE-APP-SERVICE] Error opening app store:", e), e
                }
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(li))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var lh = (() => {
    class i {
        constructor() {
            this.mobileAppService = p(So), this.TWENTY_FOUR_HOURS = 1440 * 60 * 1e3, this.LOCAL_STORAGE_KEY = "lastAppUpdatePopupDismissedAt"
        }
        initialize(e) {
            this.updateAvailableCallback = e;
            let t = Qe.getPlatform();
            t !== ri.Android && t !== ri.IOS || (this.handleUpdate(), this.setupAppResumeListener(), this.setupDailyUpdateCheck())
        }
        checkForUpdate() {
            return re(this, null, function*() {
                return (yield this.mobileAppService.isUpdateAvailable()) && this.shouldShowUpdatePopup()
            })
        }
        openAppStore() {
            return re(this, null, function*() {
                try {
                    yield this.mobileAppService.openAppStore()
                } catch (e) {
                    console.error("[NATIVE-UPDATE] Error opening app store:", e)
                }
            })
        }
        dismissUpdate() {
            localStorage.setItem(this.LOCAL_STORAGE_KEY, Date.now().toString())
        }
        shouldShowUpdatePopup() {
            let e = localStorage.getItem(this.LOCAL_STORAGE_KEY);
            return e ? (Date.now() - parseInt(e, 10)) / (1e3 * 60 * 60 * 24) >= 1 : !0
        }
        handleUpdate() {
            return re(this, null, function*() {
                (yield this.checkForUpdate()) && this.updateAvailableCallback && this.updateAvailableCallback()
            })
        }
        setupAppResumeListener() {
            zt.addListener("appStateChange", e => re(this, null, function*() {
                e.isActive && (yield this.handleUpdate())
            }))
        }
        setupDailyUpdateCheck() {
            setInterval(() => {
                this.handleUpdate()
            }, this.TWENTY_FOUR_HOURS)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var ch = (() => {
    class i {
        constructor() {
            this.swUpdate = p(oo), this.appRef = p(at)
        }
        initialize(e) {
            this.updateAvailableCallback = e, this.handleUpdates()
        }
        handleUpdates() {
            this.swUpdate.versionUpdates.pipe(Pe()).subscribe({
                next: e => {
                    switch (e.type) {
                        case "VERSION_DETECTED":
                            console.log(`[PWA-UPDATE] Downloading new app version: ${e.version.hash}`);
                            break;
                        case "VERSION_READY":
                            console.log(`[PWA-UPDATE] Current app version: ${e.currentVersion.hash}`), console.log(`[PWA-UPDATE] New app version ready for use: ${e.latestVersion.hash}`), this.updateAvailableCallback && this.updateAvailableCallback();
                            break;
                        case "VERSION_INSTALLATION_FAILED":
                            console.error(`[PWA-UPDATE] Failed to install app version '${e.version.hash}': ${e.error}`);
                            break
                    }
                },
                error: e => {
                    console.error("[PWA-UPDATE] Error handling updates", e)
                }
            })
        }
        activateUpdate() {
            return re(this, null, function*() {
                try {
                    yield this.swUpdate.activateUpdate(), console.log("[PWA-UPDATE] Update activated, reloading page..."), window.location = window.location.href + "?eraseCache=true", location.reload()
                } catch (e) {
                    console.error("[PWA-UPDATE] Error activating update", e)
                }
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var Yi = "cubic-bezier(0.4, 0.0, 0.2, 1)",
    dh = lr("mobileRouteAnimation", [Oi(":increment", [bt(":enter, :leave", [ke({
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%"
    })], {
        optional: !0
    }), jn([bt(":leave", [Gt(`250ms ${Yi}`, ke({
        opacity: 0,
        transform: "translateX(-30%)"
    }))], {
        optional: !0
    }), bt(":enter", [ke({
        opacity: 0,
        transform: "translateX(100%)"
    }), Gt(`250ms ${Yi}`, ke({
        opacity: 1,
        transform: "translateX(0)"
    }))], {
        optional: !0
    })])]), Oi(":decrement", [bt(":enter, :leave", [ke({
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%"
    })], {
        optional: !0
    }), jn([bt(":leave", [Gt(`200ms ${Yi}`, ke({
        opacity: 0,
        transform: "translateX(30%)"
    }))], {
        optional: !0
    }), bt(":enter", [ke({
        opacity: 0,
        transform: "translateX(-100%)"
    }), Gt(`200ms ${Yi}`, ke({
        opacity: 1,
        transform: "translateX(0)"
    }))], {
        optional: !0
    })])]), Oi("* <=> *", [bt(":enter", [ke({
        opacity: 0
    }), Gt(`150ms ${Yi}`, ke({
        opacity: 1
    }))], {
        optional: !0
    })])]);
var ph = (() => {
    class i extends ai {
        constructor(e) {
            super(e, ir), this.api = e, this.endpoint = ir
        }
        getNoticePanelMessage() {
            return this.api.get(this.endpoint)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(li))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var f_ = ["headerMessagePushButton"],
    g_ = (i, n, e, t, o) => ({
        "bg-impersonating": i,
        "bg-expire": n,
        "bg-expired": e,
        "": t,
        "p-0 m-0": o
    }),
    v_ = (i, n) => [i, n],
    __ = () => ({
        width: 200
    }),
    b_ = i => ({
        color: i
    });

function y_(i, n) {
    if (i & 1 && (m(0, "a", 32), G(1, "View Updates"), b()), i & 2) {
        let e = v(2);
        T("href", Il(e.noticePanelLink), gl)
    }
}

function C_(i, n) {
    if (i & 1 && (m(0, "h5", 5), G(1), k(2, y_, 2, 2, "a", 32), b()), i & 2) {
        let e = v();
        u(), Te(e.noticePanelMessage), u(), M(e.noticePanelLink ? 2 : -1)
    }
}

function S_(i, n) {
    i & 1 && V(0, "app-workspace-logo-dropdown")
}

function I_(i, n) {
    if (i & 1 && (m(0, "div", 13), V(1, "i", 33), m(2, "span", 34), G(3), b()()), i & 2) {
        let e = v();
        u(3), pn("", e.formatMessage("impersonating"), ": ", e.currentUser == null ? null : e.currentUser.name)
    }
}

function w_(i, n) {
    i & 1 && V(0, "app-subscription-alert")
}

function E_(i, n) {
    i & 1 && V(0, "app-tours-launcher")
}

function D_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-button", 35), x("onClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleGlobalSearchPopUp = !0)
        }), m(1, "div", 36)(2, "div", 37), V(3, "i", 38), b()()()
    }
    if (i & 2) {
        let e = v();
        T("hint", e.formatMessage("global_search_title")), Ue("aria-label", e.formatMessage("global_search_title"))
    }
}

function T_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 15), V(1, "i", 39), m(2, "dx-text-box", 40), x("click", function() {
            L(e);
            let o = v();
            return j(o.isVisibleGlobalSearchPopUp = !0)
        }), b(), m(3, "span", 41), G(4), b()()
    }
    if (i & 2) {
        let e = v();
        T("title", e.formatMessage("search_placeholder")), u(2), T("placeholder", e.formatMessage("search_placeholder")), u(2), Te(e.isIOSDevice ? "\u2318 / " : "Ctrl /")
    }
}

function x_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-button", 42), x("onClick", function() {
            L(e);
            let o = v();
            return j(o.navigateToCalendar())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("hint", e.formatMessage("topbar_calendar"))
    }
}

function P_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-button", 43), x("onClick", function() {
            L(e);
            let o = v();
            return j(o.openQrScanner())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("hint", e.formatMessage("scan_qr_code"))
    }
}

function k_(i, n) {
    i & 1 && (m(0, "div", 18), V(1, "app-quick-create"), b())
}

function M_(i, n) {
    i & 1 && V(0, "div", 19)
}

function R_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-drop-down-button", 45), x("onItemClick", function(o) {
            L(e);
            let r = v(2);
            return j(r.onThemeChange(o))
        }), b()
    }
    if (i & 2) {
        let e = v(2);
        T("dropDownOptions", un(8, __))("items", e.themeOptions)("useSelectMode", !0)("splitButton", !1)("showArrowIcon", !0)("selectedItemKey", e.currentTheme)("hint", e.formatMessage("system_theme"))("ngClass", e.isMobileDevice ? "theme-dx-btn" : "")
    }
}

function A_(i, n) {
    if (i & 1 && k(0, R_, 1, 9, "dx-drop-down-button", 44), i & 2) {
        let e = v();
        M(e.isMobileDevice ? -1 : 0)
    }
}

function O_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 46), x("click", function() {
            L(e);
            let o = v();
            return j(o.openBusinessReadinessModal())
        }), V(1, "app-progress-badge", 47), b()
    }
    if (i & 2) {
        let e = v();
        T("title", e.formatMessage("business_readiness_title")), u(), T("percentage", e.businessReadinessService.score())("color", e.businessReadinessService.progressColor())("size", 40)
    }
}

function N_(i, n) {
    if (i & 1 && (m(0, "div"), V(1, "app-user-badge", 51), b()), i & 2) {
        let e = v(2);
        u(), T("iconOnly", e.isMobileDevice)("isClickable", !1)("isUserTextOnly", !1)("size", e.isMobileDevice ? e.COMPONENT_SIZES.HEADER : e.COMPONENT_SIZES.SMALL)("user", e.currentUser)
    }
}

function L_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 50)(1, "h6"), G(2), m(3, "span", 53), G(4), b()(), m(5, "p", 54), G(6), b(), m(7, "p", 55), G(8), V(9, "app-copy-to-clipboard", 56), b(), m(10, "button", 57), x("click", function() {
            L(e);
            let o = v(3);
            return j(o.handleOnTrackReferrals())
        }), G(11), V(12, "i", 58), b()()
    }
    if (i & 2) {
        let e = v(3);
        T("ngClass", e.isDarkTheme() ? "referral-item-styles-for-dark-theme" : "referral-item-styles-for-light-theme"), u(2), ge("\u{1F381} ", e.formatMessage("referral_dropdown_title_part_1"), " "), u(2), Te(e.formatMessage("referral_dropdown_title_part_2")), u(2), Te(e.formatMessage("referral_dropdown_description")), u(), T("ngStyle", ii(8, b_, e.isDarkTheme() ? "color-white" : "color-black")), u(), ge(" ", e.formatMessage("referral_dropdown_copy_code_text"), " "), u(), T("textToBeCopied", e.referralCode()), u(2), ge(" ", e.formatMessage("referral_dropdown_track_referrals_text"), " ")
    }
}

function j_(i, n) {
    i & 1 && it(0, L_, 13, 10, "div", 52), i & 2 && T("dxTemplateOf", "referral-template")
}

function F_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-drop-down-button", 48, 1), x("onButtonClick", function() {
            L(e);
            let o = dn(1),
                r = v();
            return j(r.onProfileButtonClick(o))
        })("onItemClick", function(o) {
            L(e);
            let r = v();
            return j(r.onUserProfileActionButtonClickNavigateTo(o))
        }), it(2, N_, 2, 5, "div", 49), k(3, j_, 1, 1, "div", 50), b()
    }
    if (i & 2) {
        let e = v();
        T("hint", e.formatMessage("account_actions"))("items", e.profileMenu)("showArrowIcon", !e.isMobileDevice)("splitButton", !e.isMobileDevice)("useSelectMode", !0), u(2), T("dxTemplateOf", "template"), u(), M(e.isMobileDevice ? -1 : 3)
    }
}

function B_(i, n) {
    if (i & 1 && (m(0, "a", 23), V(1, "app-user-badge", 51), b()), i & 2) {
        let e = v();
        T("title", e.formatMessage("account_actions")), Ue("aria-controls", e.accountSettingsAsideConfiguration.ariaControl)("data-bs-target", e.accountSettingsAsideConfiguration.target)("data-bs-toggle", e.accountSettingsAsideConfiguration.toggle)("aria-label", e.formatMessage("account_actions")), u(), T("iconOnly", e.isMobileDevice)("isClickable", !1)("isUserTextOnly", !1)("size", e.COMPONENT_SIZES.HEADER)("user", e.currentUser)
    }
}

function V_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-change-password", 59), x("changePasswordCancelClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleChangePasswordDropdown = !1)
        })("changePasswordSaveClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleChangePasswordDropdown = !1)
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isVisiblePopup", e.isVisibleChangePasswordDropdown)
    }
}

function z_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-global-search", 60), x("globalSearchClose", function(o) {
            L(e);
            let r = v();
            return j(r.onClose(o))
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isVisibleGlobalSearchPopUp", e.isVisibleGlobalSearchPopUp)
    }
}

function U_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-show-video-popup", 61), x("onPostClose", function(o) {
            L(e);
            let r = v();
            return j(r.onClose(o))
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isPost", !0)("isVisiblePostPopup", e.isVisiblePostPopUp)
    }
}

function G_(i, n) {
    if (i & 1 && V(0, "app-feedback-form", 28), i & 2) {
        let e = v();
        T("isVisibleFeedbackPopup", e.isVisiblePostPopUp)
    }
}

function H_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-checklist-modal", 62), x("closeModal", function() {
            L(e);
            let o = v();
            return j(o.closeBusinessReadinessModal())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("visible", e.isBusinessReadinessModalVisible())
    }
}

function W_(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-qrcode-scanner", 63), x("scannerToSave", function(o) {
            L(e);
            let r = v();
            return j(r.onQrScanResult(o))
        })("scannerToClose", function() {
            L(e);
            let o = v();
            return j(o.closeQrScanner())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isVisiblePopup", e.isQrScannerOpen())("type", "get_barcode_number")
    }
}
var hh = (() => {
    class i {
        get currentTheme() {
            return this.themeService.getCurrentThemeSelection()
        }
        constructor(e, t, o) {
            this.storageService = e, this.noticePanelService = t, this.whatsAppApi = o, this.formatMessage = Q, this.userSessionService = p(pt), this.router = p(te), this.authService = p(dt), this.isIOSDevice = p(Le).isIOSDevice(), this.isMobileDevice = p(Le).isMobileDevice(), this.themeService = p(Ye), this.isEmployee = this.userSessionService.isEmployee(), this.currentUser = this.userSessionService.currentUser(), this.userPermissionList = this.userSessionService.userPermissionList(), this.isImpersonating = this.userSessionService.isImpersonating, this.tenantService = p(ut), this.pwaInstallService = p(Ln), this.tenantConfig = this.tenantService.config(), this.daysRemainingForExpiry = this.tenantService.daysRemainingForExpiry(), this.hotkeysService = p(_n), this.toastNotificationService = p(di), this.isIndia = this.tenantService.isIndia(), this.plan = this.tenantService.plan(), this.destroyRef = p(Di), this.businessReadinessService = p(On), this.isBusinessReadinessModalVisible = ne(!1), this.COMPONENT_SIZES = yc, this.isVisibleFeedbackPopup = !1, this.isVisibleChangePasswordDropdown = !1, this.isVisibleHelpDropdown = !1, this.isVisibleCallbackPopup = !1, this.isVisibleGlobalSearchPopUp = !1, this.show = !0, this.isVisiblePostPopUp = !1, this.role = null, this.PROFILE_SETTINGS = null, this.isVisibleUserDropdown = !1, this.isQrScannerOpen = ne(!1), this.doNotShowAgainNoticePanelMsgFlag = !1, this.hideSMSCreditsFromNonGupshupUsers = !1, this.isDarkTheme = this.themeService.isDarkTheme, this.isThemeChangePopupOpen = ne(!1), this.referralCode = ne("https://join.bytephase.com/join.bytephase.com/bytecode"), this.themeOptions = [{
                text: Q("theme_dark"),
                value: "fluent.blue.dark",
                icon: Mt.THEME_DARK.light
            }, {
                text: Q("theme_light"),
                value: "fluent.blue.light",
                icon: Mt.THEME_LIGHT.light
            }, {
                text: Q("theme_system"),
                value: "system",
                icon: this.isMobileDevice ? Mt.MOBILE.light : Mt.LAPTOP.light
            }], this.accountSettingsAsideConfiguration = {
                target: "#accountActionsAside",
                ariaControl: "accountActionsAside",
                ariaLabel: "Account Actions",
                toggle: "offcanvas",
                offcanvasTitle: "Accounts Actions"
            }, this.PERMISSION_LIST = $, this.FEATURE_BADGE_TYPES = yn, this.TENANT_PLANS = ct, this.CURRENT_ENVIRONMENT = Ne.currentEnvironment, this.scanBarcodeService = p(kn), this.tenantConfig ? .active_integrations ? .some(r => r.group === "sms" && r.is_primary === !0 && r.status === "Active" && r.service_name === _c.GUPSHUP) && (this.hideSMSCreditsFromNonGupshupUsers = !0), window.location.href.includes("setups") || this.openDailyPopUp(), this.setKeyboardShortcut(), this.PROFILE_SETTINGS = {
                ACCOUNT: {
                    text: Q("profile"),
                    icon: Mt.USER_CIRCLE.light,
                    visible: !0
                },
                BUSINESS_SETTINGS: {
                    text: Q("business_settings_group_name"),
                    icon: fe.SETTINGS.light,
                    visible: this.isEmployee && this.userPermissionList.includes($.BUSINESS_SETTING_VIEW)
                },
                IMPORTS: {
                    text: Q("imports"),
                    icon: ci.IMPORT.light,
                    visible: this.isEmployee
                },
                CHANGE_PASSWORD: {
                    text: Q("change_password_title"),
                    icon: Mt.KEY.light,
                    visible: !0
                },
                CLEAR_CACHE: {
                    text: Q("clear_cache"),
                    icon: ci.CLEAR_CACHE.light,
                    visible: !0
                },
                APP_PERMISSIONS: {
                    text: Q("app_permissions"),
                    icon: Mt.SHIELD_CHECK.light,
                    visible: this.isEmployee
                },
                INSTALL_PWA: {
                    text: Q("install_pwa"),
                    icon: ci.DOWNLOAD.light,
                    visible: !1
                },
                SMS: {
                    text: `${Q("available_sms")} (${this.tenantConfig.sms_credits})`,
                    icon: ci.SMS.light,
                    visible: this.isEmployee && this.userPermissionList.includes($.BUSINESS_SETTING_VIEW) && this.hideSMSCreditsFromNonGupshupUsers
                },
                LOGOUT: {
                    text: Q("logout"),
                    icon: ci.LOGOUT.light
                }
            }, this.profileMenu = Object.values(this.PROFILE_SETTINGS), Jt(() => {
                this.PROFILE_SETTINGS.INSTALL_PWA.visible = !!this.tenantConfig ? .is_white_label_request && this.pwaInstallService.canInstall(), this.profileMenu = [...Object.values(this.PROFILE_SETTINGS)]
            }), this.isEmployee
        }
        onProfileButtonClick(e) {
            e.instance.open()
        }
        navigateToCalendar() {
            this.router.navigate(["/calendar"])
        }
        ngOnInit() {
            this.authService.currentUser.pipe(Pe(this.destroyRef)).subscribe({
                next: e => {
                    this.currentUser = e
                },
                error: e => {
                    console.log("cannot get current user : ", e)
                }
            }), this.tenantConfig.sms_credits >= 100 ? this.sms_Remaining_Status = "success" : this.tenantConfig.sms_credits >= 50 ? this.sms_Remaining_Status = "warning" : this.tenantConfig.sms_credits >= 0 && (this.sms_Remaining_Status = "danger"), this.daysRemainingForExpiry <= 7 && this.daysRemainingForExpiry > 0 && (this.isExpiring = "warning"), this.daysRemainingForExpiry < 0 && (this.isExpiring = "danger"), this.daysRemainingForExpiry > 7 && (this.isExpiring = "normal"), this.isEmployee && this.businessReadinessService.fetchProgress().subscribe()
        }
        openBusinessReadinessModal() {
            this.isBusinessReadinessModalVisible.set(!0)
        }
        closeBusinessReadinessModal() {
            this.isBusinessReadinessModalVisible.set(!1)
        }
        onThemeChange(e) {
            let t = e ? .itemData ? .value || e ? .value;
            this.themeService.changeTheme(t)
        }
        setKeyboardShortcut() {
            this.hotkeysService.add(new me(["ctrl+/", "command+/"], () => (this.isEmployee && (this.isVisibleGlobalSearchPopUp = !0), !1)))
        }
        onUserProfileActionButtonClickNavigateTo(e) {
            let t = e.itemData;
            t.text === this.PROFILE_SETTINGS.LOGOUT.text ? this.userSessionService.logout() : t.text === this.PROFILE_SETTINGS.BUSINESS_SETTINGS.text ? this.router.navigate(["/settings"]) : t.text === this.PROFILE_SETTINGS.IMPORTS.text ? this.router.navigate(["/imports"]) : t.text === this.PROFILE_SETTINGS.CHANGE_PASSWORD.text ? this.isVisibleChangePasswordDropdown = !0 : t.text === this.PROFILE_SETTINGS.SMS.text ? this.router.navigate(["/settings/sms-history"]) : t.text === this.PROFILE_SETTINGS.CLEAR_CACHE.text ? (this.storageService.clearCache(), window.location.reload(), this.toastNotificationService.success("notification_cache_clear_success")) : t.text === this.PROFILE_SETTINGS.APP_PERMISSIONS.text ? this.router.navigate(["/permissions"], {
                queryParams: {
                    reason: "manual-from-settings",
                    return: this.router.url || "/"
                }
            }) : t.text === this.PROFILE_SETTINGS.INSTALL_PWA.text ? this.pwaInstallService.install() : t.text === Ic.SYSTEM_DISPLAY ? this.manageThemeChangePopup(!0) : this.currentUser.type_id === si.EMPLOYEE ? this.router.navigate([`/employees/${this.currentUser.id}/profiles`]) : this.router.navigate([`/customers/${this.currentUser.id}/profiles`]), this.isVisibleUserDropdown = !1
        }
        feedback() {
            this.isVisibleFeedbackPopup = !0, this.isVisibleHelpDropdown = !1
        }
        callback() {
            this.isVisibleCallbackPopup = !0, this.isVisibleHelpDropdown = !1
        }
        openDailyPopUp() {
            tn(0, hc).pipe(Pe(this.destroyRef)).subscribe({
                next: () => {
                    this.isVisiblePostPopUp = !0, this.noticePanelService.getNoticePanelMessage().subscribe({
                        next: t => {
                            t ? .id && (this.noticePanelMessage = t ? .message, this.noticePanelLink = t ? .url, this.doNotShowAgainNoticePanelMsgFlag = JSON.parse(localStorage.getItem("doNotShowAgainNoticePanelMsgFlag")) ? ? !1, !this.doNotShowAgainNoticePanelMsgFlag && this.showHeaderMessage())
                        },
                        error: t => {
                            console.log(t)
                        }
                    })
                },
                error: t => {
                    console.log(t)
                }
            })
        }
        doNotShowAgainNoticePanelMessage() {
            this.doNotShowAgainNoticePanelMsgFlag && localStorage.setItem("doNotShowAgainNoticePanelMsgFlag", JSON.stringify(this.doNotShowAgainNoticePanelMsgFlag)), setTimeout(function() {
                localStorage.removeItem("doNotShowAgainNoticePanelMsgFlag")
            }, 1440 * 60 * 1e3)
        }
        onClose(e) {
            this.isVisiblePostPopUp = !1, this.isVisibleGlobalSearchPopUp = !1
        }
        showHeaderMessage() {
            this.myButton && this.myButton.nativeElement && this.myButton.nativeElement.click()
        }
        itemClick(e) {
            e.itemData ? .is_domain ? window.location.href = e.itemData.path : this.router.navigate([e.itemData.path])
        }
        manageThemeChangePopup(e) {
            this.isThemeChangePopupOpen.set(e)
        }
        handleOnTrackReferrals() {
            this.router.navigate(["/referral"])
        }
        openQrScanner() {
            this.isQrScannerOpen.set(!0)
        }
        closeQrScanner() {
            this.isQrScannerOpen.set(!1)
        }
        onQrScanResult(e) {
            this.isQrScannerOpen.set(!1), this.scanBarcodeService.handleQrScanResult(e)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(l(Cn), l(ph), l(Kc))
            }
        }
        static {
            this.\u0275cmp = _({
                type: i,
                selectors: [
                    ["app-header"]
                ],
                viewQuery: function(t, o) {
                    if (t & 1 && Pt(f_, 5), t & 2) {
                        let r;
                        Ge(r = He()) && (o.myButton = r.first)
                    }
                },
                standalone: !1,
                decls: 38,
                vars: 43,
                consts: [
                    ["headerMessagePushButton", ""],
                    ["dropDownButton", ""],
                    [1, "navbar", "header-wrapper", "sticky-top", "top-header", "header-bg-text-color", "shadow-box", 3, "ngClass"],
                    ["aria-labelledby", "offcanvasTopLabel", "data-bs-backdrop", "false", "id", "offcanvasTop", "tabindex", "-1", 1, "offcanvas", "offcanvas-top", "header-notice-panel"],
                    [1, "offcanvas-header", "alert", "alert-warning", "alert-dismissible", "fade", "show", "justify-content-between", "flex-wrap"],
                    ["id", "offcanvasTopLabel", 1, "offcanvas-title"],
                    ["id", "do-not-show-again"],
                    [1, "form-check", "form-check-inline"],
                    ["id", "inlineCheckbox1", "type", "checkbox", 1, "form-check-input", 3, "click", "value"],
                    ["for", "inlineCheckbox1", 1, "form-check-label"],
                    ["aria-label", "Close", "data-bs-dismiss", "offcanvas", "title", "Close", "type", "button", 3, "click"],
                    ["aria-controls", "offcanvasTop", "data-bs-target", "#offcanvasTop", "data-bs-toggle", "offcanvas", "title", "Notice Panel Message alert", "type", "button", 1, "btn", "btn-primary", "d-none"],
                    [1, "ms-auto", "d-flex", "pe-1", "flex-row", "align-items-center", "gap-2", 3, "ngClass"],
                    [1, "impersonation-indicator", "me-3"],
                    ["height", "40", "icon", "", "stylingMode", "outlined", "type", "default", "width", "20", 1, "fade-in-scale-hover", "d-flex", "customized-dx-btn", 3, "hint"],
                    [1, "align-self-center", "search-box", "shadow-box-small", "placeholder-font", 2, "height", "35px", 3, "title"],
                    ["icon", "fa-thin fa-calendar", "stylingMode", "outlined", "type", "default", 1, "px-2", 3, "hint"],
                    ["icon", "fa-thin fa-qrcode", "stylingMode", "outlined", "type", "default", 1, "px-2", 3, "hint"],
                    [1, "fab-wrapper"],
                    ["aria-hidden", "true", 1, "vr", "mx-1", "opacity-25"],
                    [1, "notification-badge", "dev-customized-btn", 3, "title"],
                    [1, "business-readiness-badge-wrapper", "cursor-pointer", "me-1", 3, "title"],
                    ["id", "profile-menu-btn", "displayExpr", "text", "template", "template", 3, "hint", "items", "showArrowIcon", "splitButton", "useSelectMode"],
                    ["role", "button", 1, "d-flex", "flex-column", 3, "title"],
                    [3, "accountActionsItemClicked", "ariaControl", "ariaLabel", "offcanvasTitle", "profileMenu", "target", "toggle"],
                    [3, "isVisiblePopup"],
                    [3, "isVisibleGlobalSearchPopUp"],
                    [3, "isPost", "isVisiblePostPopup"],
                    [1, "row", "d-flex", "flex-wrap", 3, "isVisibleFeedbackPopup"],
                    [3, "themeChanged", "updateThemeChangePopupStatus", "isThemeChangePopupOpen", "currentTheme", "themeOptions"],
                    [3, "visible"],
                    [3, "isVisiblePopup", "type"],
                    ["target", "_blank", 1, "btn-sm", "btn-link", "ms-2", "link-without-effect", "fs-5", 3, "href"],
                    [1, "fa-solid", "fa-user-secret", "me-1"],
                    [1, "fw-bold"],
                    ["height", "40", "icon", "", "stylingMode", "outlined", "type", "default", "width", "20", 1, "fade-in-scale-hover", "d-flex", "customized-dx-btn", 3, "onClick", "hint"],
                    [1, "d-flex"],
                    [1, "justify-content-center"],
                    [1, "fa-thin", "fa-magnifying-glass"],
                    [1, "bi", "bi-search", "search-icon"],
                    ["height", "25", "id", "searchField", "type", "text", 1, "search-input", 3, "click", "placeholder"],
                    [1, "global-search-shortcut", "fs-6"],
                    ["icon", "fa-thin fa-calendar", "stylingMode", "outlined", "type", "default", 1, "px-2", 3, "onClick", "hint"],
                    ["icon", "fa-thin fa-qrcode", "stylingMode", "outlined", "type", "default", 1, "px-2", 3, "onClick", "hint"],
                    ["stylingMode", "outlined", "type", "default", "keyExpr", "value", "id", "theme-change", 1, "theme-switcher", 3, "dropDownOptions", "items", "useSelectMode", "splitButton", "showArrowIcon", "selectedItemKey", "hint", "ngClass"],
                    ["stylingMode", "outlined", "type", "default", "keyExpr", "value", "id", "theme-change", 1, "theme-switcher", 3, "onItemClick", "dropDownOptions", "items", "useSelectMode", "splitButton", "showArrowIcon", "selectedItemKey", "hint", "ngClass"],
                    [1, "business-readiness-badge-wrapper", "cursor-pointer", "me-1", 3, "click", "title"],
                    [3, "percentage", "color", "size"],
                    ["id", "profile-menu-btn", "displayExpr", "text", "template", "template", 3, "onButtonClick", "onItemClick", "hint", "items", "showArrowIcon", "splitButton", "useSelectMode"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "profile-menu-item", 3, "ngClass"],
                    [1, "border-user", 3, "iconOnly", "isClickable", "isUserTextOnly", "size", "user"],
                    ["class", "profile-menu-item", 3, "ngClass", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "referral-item-text-2"],
                    [1, "m-0"],
                    [1, "referral-link", "referral-font-styles", "d-inline-flex", "align-items-center", 3, "ngStyle"],
                    [2, "padding-left", "15px", 3, "textToBeCopied"],
                    [1, "referral-font-styles", "track-referral-text", 3, "click"],
                    [1, "fa-solid", "fa-arrow-right", "track-referral-arrow-icon"],
                    [3, "changePasswordCancelClick", "changePasswordSaveClick", "isVisiblePopup"],
                    [3, "globalSearchClose", "isVisibleGlobalSearchPopUp"],
                    [3, "onPostClose", "isPost", "isVisiblePostPopup"],
                    [3, "closeModal", "visible"],
                    [3, "scannerToSave", "scannerToClose", "isVisiblePopup", "type"]
                ],
                template: function(t, o) {
                    t & 1 && (m(0, "nav", 2)(1, "div", 3)(2, "div", 4), k(3, C_, 3, 2, "h5", 5), m(4, "div", 6)(5, "div", 7)(6, "input", 8), x("click", function() {
                        return o.doNotShowAgainNoticePanelMsgFlag = !o.doNotShowAgainNoticePanelMsgFlag
                    }), b(), m(7, "label", 9), G(8, "Do Not Show Again"), b()(), m(9, "button", 10), x("click", function() {
                        return o.doNotShowAgainNoticePanelMessage()
                    }), G(10, "X "), b()()()(), V(11, "button", 11, 0), k(13, S_, 1, 0, "app-workspace-logo-dropdown"), m(14, "div", 12), k(15, I_, 4, 2, "div", 13), k(16, w_, 1, 0, "app-subscription-alert"), k(17, E_, 1, 0, "app-tours-launcher"), k(18, D_, 4, 2, "dx-button", 14), k(19, T_, 5, 3, "div", 15), k(20, x_, 1, 1, "dx-button", 16), k(21, P_, 1, 1, "dx-button", 17), k(22, k_, 2, 0, "div", 18), k(23, M_, 1, 0, "div", 19), k(24, A_, 1, 1), m(25, "div", 20), V(26, "app-notification"), b(), k(27, O_, 2, 4, "div", 21), k(28, F_, 4, 7, "dx-drop-down-button", 22), k(29, B_, 2, 10, "a", 23), m(30, "app-accounts-actions-mobile-view", 24), x("accountActionsItemClicked", function(s) {
                        return o.onUserProfileActionButtonClickNavigateTo(s)
                    }), b()()(), k(31, V_, 1, 1, "app-change-password", 25), k(32, z_, 1, 1, "app-global-search", 26), k(33, U_, 1, 2, "app-show-video-popup", 27), k(34, G_, 1, 1, "app-feedback-form", 28), m(35, "app-theme-change-mobile-view-popup", 29), x("themeChanged", function(s) {
                        return o.onThemeChange(s)
                    })("updateThemeChangePopupStatus", function(s) {
                        return o.manageThemeChangePopup(s)
                    }), b(), k(36, H_, 1, 1, "app-checklist-modal", 30), k(37, W_, 1, 2, "app-qrcode-scanner", 31)), t & 2 && (T("ngClass", El(34, g_, o.isImpersonating(), o.isExpiring === "warning" && !o.isImpersonating(), o.isExpiring === "danger" && !o.isImpersonating(), o.isExpiring === "normal" && !o.isImpersonating(), o.isMobileDevice)), u(3), M(o.noticePanelMessage ? 3 : -1), u(3), T("value", o.doNotShowAgainNoticePanelMsgFlag), u(7), M(o.isMobileDevice ? 13 : -1), u(), T("ngClass", o.isMobileDevice ? "gap-2" : ""), u(), M(o.isImpersonating() ? 15 : -1), u(), M(o.isEmployee && !o.isMobileDevice ? 16 : -1), u(), M(o.isEmployee && !o.isMobileDevice ? 17 : -1), u(), M(o.isEmployee && o.isMobileDevice ? 18 : -1), u(), M(o.isEmployee && !o.isMobileDevice ? 19 : -1), u(), M(!o.isMobileDevice && o.isEmployee ? 20 : -1), u(), M(!o.isMobileDevice && o.isEmployee ? 21 : -1), u(), M(o.isEmployee && !o.isMobileDevice ? 22 : -1), u(), M(o.isEmployee && !o.isMobileDevice ? 23 : -1), u(), M(ft(40, v_, o.TENANT_PLANS.STANDARD, o.TENANT_PLANS.ENTERPRISE).includes(o.plan) ? 24 : -1), u(), T("title", o.formatMessage("notifications_title")), u(2), M(o.isEmployee && o.isMobileDevice ? 27 : -1), u(), M(o.isMobileDevice ? -1 : 28), u(), M(o.isMobileDevice ? 29 : -1), u(), T("ariaControl", o.accountSettingsAsideConfiguration.ariaControl)("ariaLabel", o.accountSettingsAsideConfiguration.ariaLabel)("offcanvasTitle", o.accountSettingsAsideConfiguration.offcanvasTitle)("profileMenu", o.profileMenu)("target", o.accountSettingsAsideConfiguration.target)("toggle", o.accountSettingsAsideConfiguration.toggle), u(), M(o.isVisibleChangePasswordDropdown ? 31 : -1), u(), M(o.isVisibleGlobalSearchPopUp ? 32 : -1), u(), M(o.isVisiblePostPopUp && o.isEmployee && o.isIndia ? 33 : -1), u(), M(o.isVisiblePostPopUp && o.isEmployee ? 34 : -1), u(), T("isThemeChangePopupOpen", o.isThemeChangePopupOpen())("currentTheme", o.currentTheme)("themeOptions", o.themeOptions), u(), M(o.isEmployee ? 36 : -1), u(), M(o.isQrScannerOpen() ? 37 : -1))
                },
                dependencies: [ni, Rl, $c, ad, sd, cd, pd, Mn, hi, gd, Rn, Vc, wn, En, Yc, Bc, bd, yd, Ld, Rd, Nn, Od],
                styles: [`.color-white{color:#fff}.color-black{color:#000}.profile-menu-item{width:200px!important;text-wrap:auto}.track-referral-arrow-icon{margin-left:10px!important;color:#3498db}.referral-item-styles-for-light-theme{color:#fff;background-color:#10172a}.referral-item-text-2{color:green}.referral-item-styles-for-dark-theme{color:#000;background-color:#fff}.referral-link{white-space:normal;margin-bottom:5px}.referral-font-styles{font-size:.8rem;font-weight:500}.track-referral-text{color:#3498db;background-color:transparent;border:none;padding:0;font-weight:700}.shadow{box-shadow:0 .5rem 1rem #00000026!important;background:#fff}.header-wrapper{z-index:10}.header-wrapper .user-name{margin-right:10px}.header-wrapper .notification-badge{cursor:pointer}.header-wrapper .business-readiness-badge-wrapper{cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .2s ease}@media(hover:hover)and (pointer:fine){.header-wrapper .business-readiness-badge-wrapper:hover{transform:scale(1.1)}}.header-wrapper .business-readiness-badge-wrapper:active{transform:scale(.95)}.border-user{padding-left:3px}.fa-caret-margin{margin-top:3px;margin-left:3px}.mobile-logo{position:relative;top:4px;width:auto;max-width:100px;height:auto;max-height:35px;margin-left:1rem!important}.live-chat{color:green}.callback{text-decoration:none}.top-header{position:fixed;top:0;width:100vw;z-index:10}.customTooltip{font-size:12px;color:#5a3939}.customTooltip .introjs-tooltip-title{font-size:18px!important;color:#3498db}.customTooltip .introjs-tooltiptext{padding-bottom:0}.customTooltip .introjs-tooltiptext small{font-size:12px;color:#000}.customTooltip .introjs-tooltiptext mark{color:#fff;padding:0 4px 1px;border-radius:4px;background-color:red}.customTooltip .introjs-progress{margin:5px 17px 10px}.bg-impersonating{color:#fff!important;background-color:#dc3545!important}.impersonation-indicator{color:#fff;font-size:.9rem;display:flex;align-items:center;animation:pulse 2s infinite}.impersonation-indicator i{font-size:1.1rem}@keyframes pulse{0%,to{opacity:1}50%{opacity:.7}}.bg-expire{color:#664d03;background-color:#fff3cd}.bg-expired{color:#842029;background-color:#f8d7da}.header-notice-panel{z-index:100;max-height:55px!important;--bs-offcanvas-padding-y: 1.3rem}.header-notice-panel .offcanvas-title{max-width:90rem;margin-left:auto}.header-notice-panel #do-not-show-again{margin-left:auto;margin-right:10px}.header-notice-panel #do-not-show-again input{cursor:pointer}.header-notice-panel button{background:transparent;border:none;font-size:1.2rem;color:gray}.user-name .dx-button{height:40px!important}.shadow-box-small{box-shadow:0 0 5px var(--link-hover-color);border-radius:.5rem}.search-box{display:flex;align-items:center;border-radius:8px;padding:5px;width:300px;height:39px!important}.search-box .search-icon{margin-right:10px}.search-box .search-input{flex-grow:1;border:none;background:transparent;color:#fff}.search-box .global-search-shortcut{border:2px solid #479ef5;padding:3px 6px;border-radius:8px;margin-left:10px}.timezone-display{padding:8px;background-color:#e6e6e6b5;border-radius:7px;margin-right:7px}.timezone-display p{margin-right:1rem;margin-bottom:0;font-size:14px!important;color:#000!important}.customized-dx-btn{height:30px!important;font-weight:400!important}.theme-dx-btn .dx-button,.account-dx-btn .dx-button{height:30px!important;line-height:30px!important}@media(max-width:768px){.dx-dropdownbutton:not(.dx-dropdownbutton-has-arrow) .dx-button-has-icon:not(.dx-button-has-text) .dx-icon{width:20px!important;height:20px!important;font-size:15px!important;margin-inline-end:0!important;margin-inline-start:0!important}}.dev-customized-btn{border:1px solid #3498db;padding:2px 9px;border-radius:4px;display:inline-flex;align-items:center;justify-content:center}@media(max-width:768px){.top-header{position:fixed!important;padding-top:.5rem!important;min-height:56px;display:flex;align-items:center}.header-wrapper{display:flex;align-items:center;gap:.5rem;flex-wrap:nowrap}.mobile-logo{max-height:35px!important;width:auto!important;margin-left:0!important;margin-right:auto}app-header .dx-button,app-header button,app-header .notification-badge,app-header .customized-dx-btn{min-width:40px!important;min-height:40px!important;max-width:40px!important;max-height:40px!important;width:40px!important;height:40px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:0!important}app-header .dx-button .dx-icon,app-header .dx-button i,app-header .dx-button fa,app-header button .dx-icon,app-header button i,app-header button fa,app-header .notification-badge .dx-icon,app-header .notification-badge i,app-header .notification-badge fa,app-header .customized-dx-btn .dx-icon,app-header .customized-dx-btn i,app-header .customized-dx-btn fa{font-size:18px!important;line-height:1!important}.business-readiness-badge-wrapper{margin-right:.5rem!important;flex-shrink:0}app-header .dx-dropdownbutton,app-header .theme-dx-btn,app-header .account-dx-btn{min-width:40px!important;min-height:40px!important;max-width:40px!important;max-height:40px!important;width:40px!important;height:40px!important}app-header .dx-dropdownbutton .dx-button,app-header .theme-dx-btn .dx-button,app-header .account-dx-btn .dx-button{min-width:40px!important;min-height:40px!important;max-width:40px!important;max-height:40px!important;width:40px!important;height:40px!important;padding:0!important}app-header .dx-dropdownbutton .dx-icon,app-header .dx-dropdownbutton i,app-header .theme-dx-btn .dx-icon,app-header .theme-dx-btn i,app-header .account-dx-btn .dx-icon,app-header .account-dx-btn i{font-size:18px!important}app-header .dx-dropdownbutton img,app-header .theme-dx-btn img,app-header .account-dx-btn img{width:40px!important;height:40px!important;object-fit:cover;border-radius:50%!important}.border-user{padding-left:0!important}.header-wrapper [class*=col-]{padding-left:0!important;padding-right:0!important}app-header .user-name{min-width:40px!important;min-height:40px!important;max-width:40px!important;max-height:40px!important;width:40px!important;height:40px!important;margin:0!important}app-header .user-name .dx-button{min-width:40px!important;min-height:40px!important;max-width:40px!important;max-height:40px!important;width:40px!important;height:40px!important;padding:0!important;border-radius:50%!important;margin:0!important}app-header .user-name .dx-button-content{padding:0!important;display:flex!important;align-items:center!important;justify-content:center!important;width:40px!important;height:40px!important}app-header .user-name img,app-header .user-name .dx-icon,app-header .user-name i{width:40px!important;height:40px!important;font-size:18px!important;border-radius:50%!important}.notification-badge{position:relative}.notification-badge .dx-badge{font-size:12px!important;min-width:18px!important;height:18px!important;line-height:18px!important}.profile-menu-item{min-height:48px;padding:.75rem 1rem}.impersonation-indicator{font-size:.75rem;padding:.25rem .5rem;white-space:nowrap}}
`],
                encapsulation: 2
            })
        }
    }
    return i
})();
var $_ = (i, n) => ({
        expanded: i,
        "dark-theme": n
    }),
    Q_ = (i, n) => ({
        "fa-2x": !0,
        "me-3": !0,
        "toggle-sidebar-icon": !0,
        "fa-thin": !0,
        "fa-chevron-double-left": i,
        "fa-chevron-double-right": n
    }),
    Z_ = (i, n) => [i, n],
    Y_ = (i, n, e) => ({
        permissions: i,
        modules: n,
        isEmployee: e
    }),
    X_ = (i, n) => ({
        "has-submenu": i,
        active: n
    }),
    J_ = () => ({
        exact: !1
    }),
    e0 = i => ({
        "pe-none text-muted opacity-50": i
    });

function t0(i, n) {
    if (i & 1 && (m(0, "span", 18), G(1), b()), i & 2) {
        let e = v(3).$implicit,
            t = v();
        u(), Te(t.formatMessage(e.title))
    }
}

function i0(i, n) {
    if (i & 1 && V(0, "i", 17), i & 2) {
        let e = v(3).$implicit,
            t = v();
        T("ngClass", t.isMenuExpanded(e.title) ? "fa-thin fa-chevron-up" : "fa-thin fa-chevron-down")
    }
}

function n0(i, n) {
    if (i & 1 && (m(0, "div", 19), G(1), b()), i & 2) {
        let e = v(3).$implicit;
        u(), ge(" ", e.title, " ")
    }
}

function o0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 15), x("click", function() {
            L(e);
            let o = v(2).$implicit,
                r = v();
            return j(o.children ? r.toggleMenu(o.title) : null)
        }), m(1, "a", 16), V(2, "i", 17), k(3, t0, 2, 1, "span", 18), k(4, i0, 1, 1, "i", 17), b(), k(5, n0, 2, 1, "div", 19), b()
    }
    if (i & 2) {
        let e = v(2).$implicit,
            t = v();
        T("id", (e == null ? null : e.id) ? ? "")("ngClass", ft(12, X_, e.children, t.isMenuExpanded(e.title)))("routerLinkActiveOptions", un(15, J_))("title", e.disabled ? t.formatMessage("upgrade_to_standard") : t.formatMessage(e.title))("routerLinkActive", e.disabled ? "" : "active"), u(), T("routerLink", e.disabled ? null : e.link)("ngClass", ii(16, e0, e.disabled)), Ue("aria-disabled", e.disabled ? "true" : null), u(), T("ngClass", e.icon), u(), M(t.isExpanded ? 3 : -1), u(), M(e.children && t.isExpanded ? 4 : -1), u(), M(t.isExpanded ? -1 : 5)
    }
}

function r0(i, n) {
    if (i & 1 && (m(0, "li")(1, "a", 20), V(2, "i", 17), m(3, "span", 18), G(4), b()()()), i & 2) {
        let e = n.$implicit;
        u(), T("routerLink", e.link), u(), T("ngClass", e.icon), u(2), Te(e.title)
    }
}

function s0(i, n) {
    if (i & 1 && (m(0, "ul", 14), Ao(1, r0, 5, 3, "li", null, Ro), b()), i & 2) {
        let e = v(2).$implicit;
        u(), Oo(e.children)
    }
}

function a0(i, n) {
    if (i & 1 && (it(0, o0, 6, 18, "div", 13), k(1, s0, 3, 0, "ul", 14)), i & 2) {
        let e = v().$implicit,
            t = v();
        T("appAccessControl", wl(2, Y_, e == null ? null : e.permissions, e == null ? null : e.modules, e == null ? null : e.userTypeId)), u(), M(e.children && t.isMenuExpanded(e.title) && t.isExpanded ? 1 : -1)
    }
}

function l0(i, n) {
    if (i & 1 && (m(0, "li"), k(1, a0, 2, 6), b()), i & 2) {
        let e = n.$implicit;
        u(), M(e.visible ? 1 : -1)
    }
}

function c0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div")(1, "div", 23)(2, "p", 24), G(3), m(4, "strong"), G(5), b(), G(6), m(7, "strong"), G(8), b(), G(9), b(), m(10, "ul", 25)(11, "li"), G(12), b(), m(13, "li"), G(14), b(), m(15, "li"), G(16), b(), m(17, "li"), G(18), b(), m(19, "li"), G(20), b(), m(21, "li"), G(22), b()(), m(23, "p", 26), G(24, "\u{1F4B0} "), m(25, "strong"), G(26), b(), V(27, "br"), G(28), b(), m(29, "div", 27)(30, "p", 28), G(31), b(), m(32, "app-dx-outline-button", 29), x("onClickEvent", function() {
            L(e);
            let o = v(2);
            return j(o.requestUpgradePlan())
        }), b()()()()
    }
    if (i & 2) {
        let e = v(2);
        u(3), ge("", e.formatMessage("intro_text"), " "), u(2), Te(e.formatMessage("plan_type_lite_basic")), u(), ge("", e.formatMessage("middle_text"), " "), u(2), Te(e.formatMessage("plan_type_standard")), u(), ge(" ", e.formatMessage("outro_text"), ": "), u(3), ge("\u{1F510} ", e.formatMessage("configurable_employee_permissions")), u(2), ge("\u{1F4F2} ", e.formatMessage("delivery_otp_verification")), u(2), ge("\u{1F4BC} ", e.formatMessage("amc_outsourcing_leads_tasks")), u(2), ge("\u{1F4B8} ", e.formatMessage("expense_management")), u(2), ge("\u270D\uFE0F ", e.formatMessage("digital_signature_support")), u(2), ge("\u267E\uFE0F ", e.formatMessage("and_many_more_advanced_modules")), u(4), Te(e.formatMessage("fair_upgrade_pricing")), u(2), ge(" ", e.formatMessage("we_will_prorate_your_current_plan"), " "), u(3), ge("", e.formatMessage("take_your_repair_business_to_the_next_level_today"), " ")
    }
}

function d0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-popup", 21), x("onHidden", function() {
            L(e);
            let o = v();
            return j(o.onClosing())
        }), Sl("visibleChange", function(o) {
            L(e);
            let r = v();
            return Cl(r.isVisibleUpdatePlanPopup, o) || (r.isVisibleUpdatePlanPopup = o), j(o)
        }), it(1, c0, 33, 14, "div", 22), b()
    }
    if (i & 2) {
        let e = v();
        yl("visible", e.isVisibleUpdatePlanPopup), T("width", "95vw")("maxWidth", 700)("title", e.formatMessage("upgrade_to_standard_unlock_more_power_for_your_business"))("dragEnabled", !1)("showCloseButton", !0), u(), T("dxTemplateOf", "content")
    }
}

function p0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 8)(1, "app-business-readiness-widget", 30), x("openChecklist", function() {
            L(e);
            let o = v();
            return j(o.openBusinessReadinessChecklist())
        }), b()()
    }
    if (i & 2) {
        let e = v();
        u(), T("displayMode", "sidebar")("isExpanded", e.isExpanded)
    }
}

function u0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div")(1, "app-dx-outline-button", 31), x("onClickEvent", function() {
            L(e);
            let o = v();
            return j(o.isVisibleUpdatePlanPopup = !0)
        }), b()()
    }
    if (i & 2) {
        let e = v();
        u(), T("isVisibleIcon", !0)("text", e.isExpanded ? "upgrade_to_standard" : "")
    }
}

function h0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div")(1, "div", 36), x("mouseleave", function() {
            L(e), v();
            let o = dn(5);
            return j(o.instance.hide())
        }), m(2, "h5", 37), G(3, "BytePhase"), b(), m(4, "div", 38), V(5, "img", 39), b(), m(6, "div", 40), G(7), b(), m(8, "div", 41), G(9), b(), m(10, "div", 42)(11, "a", 43), V(12, "img", 44), b()()()()
    }
    if (i & 2) {
        let e = v(2);
        u(5), T("title", e.formatMessage("custom_title_attribute"))("alt", e.formatMessage("qr_code")), u(2), ge("", e.formatMessage("scan_to_download_an_app"), " "), u(2), pn("", e.formatMessage("app_version"), " ", e.ANDROID_APP.VERSION, " "), u(3), T("alt", e.formatMessage("get_it_on_google_play"))
    }
}

function m0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 9)(1, "dx-button", 32), x("onClick", function() {
            L(e);
            let o = v();
            return j(o.openSupportCenter())
        }), b(), m(2, "dx-button", 33), x("onClick", function() {
            L(e);
            let o = v();
            return j(o.userSessionService.logout())
        }), b(), V(3, "dx-button", 34), m(4, "dx-popover", 35, 0), it(6, h0, 13, 6, "div", 22), b()()
    }
    if (i & 2) {
        let e = v();
        u(), T("text", e.formatMessage("help"))("title", e.formatMessage("help"))("visible", e.isEmployee), u(), T("text", e.formatMessage("logout"))("title", e.formatMessage("logout")), u(), T("text", "App")("title", "App")("visible", e.isEmployee && !e.isNativeApp), u(), T("hideOnOutsideClick", !0)("showTitle", !1)("width", 300), u(2), T("dxTemplateOf", "content")
    }
}

function f0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "dx-button", 45), x("onClick", function() {
            L(e);
            let o = v();
            return j(o.userSessionService.logout())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("title", e.formatMessage("logout"))
    }
}

function g0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-checklist-modal", 46), x("closeModal", function() {
            L(e);
            let o = v();
            return j(o.closeBusinessReadinessChecklist())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("visible", e.isChecklistModalVisible())
    }
}
var mh = (() => {
    class i {
        constructor(e) {
            this.sidebarService = e, this.formatMessage = Q, this.isExpanded = !0, this.themeToggled = new pe, this.authorizationService = p(pi), this.moduleDataService = p(hd), this.userSessionService = p(pt), this.router = p(te), this.themeService = p(Ye), this.tenantService = p(ut), this.isMobileDevice = p(Le).isMobileDevice(), this.isNativeApp = p(Le).isCapacitorNative(), this.toastNotificationService = p(di), this.businessReadinessService = p(On), this.SETTINGS = bc, this.generalSettingDataService = p(xn), this.serviceOptions = Qc.getServiceOptionFromConfig(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SERVICE_OPTION)), this.plan = this.tenantService.plan(), this.isDarkTheme = this.themeService.isDarkTheme, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = le, this.menuItems = [], this.expandedMenus = new Set, this.isVisibleRequestAppAccessPopup = ne(!1), this.isVisibleUpdatePlanPopup = !1, this.isVisibleFeedbackFormPopup = ne(!1), this.isChecklistModalVisible = ne(!1), this.service = p(qc), this.FEATURE_BADGE_TYPES = yn, this.environment = Ne, this.ANDROID_APP = Sc, this.TENANT_PLANS = ct
        }
        openSupportCenter() {
            this.router.navigate(["/supports/centers"])
        }
        toggleMenu(e) {
            this.expandedMenus.has(e) ? this.expandedMenus.delete(e) : this.expandedMenus.add(e)
        }
        toggleSidebar() {
            this.isExpanded = !this.isExpanded, this.sidebarService.setExpanded(this.isExpanded)
        }
        isMenuExpanded(e) {
            return this.expandedMenus.has(e)
        }
        ngOnInit() {
            this.sidebarService.sidebarExpanded$.subscribe(e => {
                this.isExpanded = e
            }), this.menuItems = [{
                title: "dashboard",
                id: "sidebarDashboard",
                icon: fe.DASHBOARD.light,
                active: !1,
                link: "dashboards",
                visible: !0,
                userTypeId: si.EMPLOYEE
            }, {
                title: "sidebar_Jobs",
                id: "sidebarJobs",
                icon: fe.JOB.light,
                active: !1,
                link: "jobs",
                entity: this.ENTITIES.JOB.name,
                permissions: [$.JOB_LIST],
                modules: [this.ENTITIES.JOB.name],
                visible: !0
            }, {
                title: "amc",
                id: "sidebarAmcs",
                icon: fe.AMC_CONTRACT.light,
                active: !1,
                link: "amcs",
                permissions: [$.AMC_CONTRACT_LIST],
                modules: [this.ENTITIES.AMC_CONTRACT.name],
                visible: !0
            }, {
                title: "billing",
                id: "sidebarBilling",
                icon: fe.BILLING.light,
                active: !1,
                link: "billings",
                permissions: [$.BILLING_LIST],
                visible: this.userPermissionList.includes($.BILLING_LIST)
            }, {
                title: "customers",
                id: "sidebarCustomer",
                icon: fe.CUSTOMER.light,
                active: !1,
                link: "customers",
                permissions: [$.CUSTOMER_LIST],
                modules: [this.ENTITIES.CUSTOMER.name],
                visible: this.isEmployee && this.userPermissionList.includes($.CUSTOMER_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.CUSTOMER.name),
                userTypeId: si.EMPLOYEE
            }, {
                title: "sales",
                id: "sidebarSales",
                icon: fe.SALE.light,
                active: !1,
                link: "sales",
                entity: this.ENTITIES.SALE.name,
                permissions: [$.SALE_LIST],
                modules: [this.ENTITIES.SALE.name],
                visible: this.authorizationService.canAccess(this.ENTITIES.SALE) && this.userPermissionList.includes($.SALE_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.SALE.name)
            }, {
                title: "quotations_title",
                id: "sidebarQuotations",
                icon: fe.QUOTATION.light,
                active: !1,
                link: "quotations",
                permissions: [$.QUOTATION_LIST],
                modules: [this.ENTITIES.QUOTATION.name],
                visible: this.authorizationService.canAccess(this.ENTITIES.QUOTATION) && this.userPermissionList.includes($.QUOTATION_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.QUOTATION.name)
            }, {
                title: "common_purchase",
                id: "sidebarPurchases",
                icon: fe.PURCHASE.light,
                active: !1,
                link: "purchases",
                entity: this.ENTITIES.PURCHASE.name,
                userTypeId: si.EMPLOYEE,
                visible: this.authorizationService.canAccess(this.ENTITIES.PURCHASE) && this.userPermissionList.includes($.PURCHASE_LIST) && this.isEmployee && this.moduleDataService.isModuleActive(this.ENTITIES.PURCHASE.name)
            }, {
                title: "inventory",
                id: "sidebarParts",
                icon: fe.INVENTORY.light,
                active: !1,
                link: "parts",
                entity: this.ENTITIES.PART.name,
                visible: this.userPermissionList.includes($.PART_LIST) && this.isEmployee && this.moduleDataService.isModuleActive(this.ENTITIES.PART.name)
            }, {
                title: "backup_drives",
                id: "sidebarBackupDrives",
                icon: fe.BACKUP_DRIVE.light,
                active: !1,
                link: "backupDrives",
                visible: this.isEmployee && [ct.STANDARD, ct.ENTERPRISE].includes(this.plan) && this.userPermissionList.includes($.BACKUP_DRIVE_LIST) && this.serviceOptions.some(e => e === vc.RECOVERY_SERVICE) && this.moduleDataService.isModuleActive(this.ENTITIES.BACKUP_DRIVE.name)
            }, {
                title: "reports",
                id: "sidebarReports",
                icon: fe.REPORT.light,
                active: !1,
                link: "reports",
                visible: this.isEmployee && this.userPermissionList.includes($.REPORT_VIEW) && this.moduleDataService.isModuleActive(this.ENTITIES.REPORT.name)
            }, {
                title: "commission",
                id: "sidebarCommission",
                icon: "fa-thin fa-percent",
                active: !1,
                link: "commission",
                modules: [this.ENTITIES.COMMISSION.name],
                visible: this.isEmployee && (this.userPermissionList.includes($.COMMISSION_VIEW_OWN) || this.userPermissionList.includes($.COMMISSION_VIEW_ALL)) && this.moduleDataService.isModuleActive(this.ENTITIES.COMMISSION.name),
                disabled: [ct.LITE, ct.BASIC].includes(this.plan)
            }, {
                title: "employees_title",
                id: "sidebarEmployees",
                icon: fe.EMPLOYEE.light,
                active: !1,
                link: "employees",
                visible: this.isEmployee && this.userPermissionList.includes($.EMPLOYEE_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.EMPLOYEE.name)
            }, {
                title: "tasks",
                id: "sidebarTasks",
                icon: fe.TASK.light,
                active: !1,
                link: "tasks",
                entity: this.ENTITIES.TASK.name,
                visible: this.isEmployee && this.authorizationService.canAccess(this.ENTITIES.TASK) && this.userPermissionList.includes($.TASK_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.TASK.name)
            }, {
                title: "leads",
                id: "sidebarLeads",
                icon: fe.LEAD.light,
                active: !1,
                link: "leads",
                entity: this.ENTITIES.LEAD.name,
                visible: this.isEmployee && this.authorizationService.canAccess(this.ENTITIES.LEAD) && this.userPermissionList.includes($.LEAD_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.LEAD.name)
            }, {
                title: "expenses",
                id: "sidebarExpenses",
                icon: fe.EXPENSE.light,
                active: !1,
                link: "expenses",
                entity: this.ENTITIES.EXPENSE.name,
                visible: this.authorizationService.canAccess(this.ENTITIES.EXPENSE) && this.userPermissionList.includes($.EXPENSES_LIST) && this.isEmployee && this.moduleDataService.isModuleActive(this.ENTITIES.EXPENSE.name)
            }, {
                title: "pickup_drops",
                id: "sidebarPickupDrops",
                icon: fe.PICKUP_DROP.light,
                active: !1,
                link: "pickupDrops",
                entity: this.ENTITIES.PICKUP_DROP.name,
                visible: this.authorizationService.canAccess(this.ENTITIES.PICKUP_DROP) && this.userPermissionList.includes($.PICKUP_DROP_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.PICKUP_DROP.name)
            }, {
                title: "job_self_check_in",
                id: "sidebarSelfCheckIn",
                icon: fe.SELF_CHECK_IN.light,
                active: !1,
                link: "/guest/lead",
                entity: this.ENTITIES.CONTACT_US.name,
                visible: !this.isEmployee && [ct.STANDARD, ct.ENTERPRISE].includes(this.plan)
            }, {
                title: "marketing",
                id: "sidebarMarketing",
                icon: fe.MARKETING.light,
                active: !1,
                link: "mailMarketings",
                entity: this.ENTITIES.MAIL_MARKETING.name,
                visible: this.authorizationService.canAccess(this.ENTITIES.MAIL_MARKETING) && this.userPermissionList.includes($.MAIL_MARKETING_LIST) && this.moduleDataService.isModuleActive(this.ENTITIES.MAIL_MARKETING.name)
            }], this.isEmployee && (this.businessReadinessService.fetchProgress().subscribe({
                error: e => {
                    console.error("Failed to fetch business readiness progress:", e)
                }
            }), this.routerSubscription = this.router.events.pipe(ve(e => e instanceof vt)).subscribe(() => {
                this.businessReadinessService.checkPendingRefresh() && this.businessReadinessService.fetchProgress(!0).subscribe()
            }))
        }
        ngOnDestroy() {
            this.routerSubscription ? .unsubscribe()
        }
        closeRequestAccessPopup() {
            this.isVisibleRequestAppAccessPopup.update(() => !1)
        }
        openRequestAccess() {
            this.isVisibleRequestAppAccessPopup.update(() => !0)
        }
        onClosing() {
            this.isVisibleUpdatePlanPopup = !1
        }
        openFeedbackPopup() {
            this.isVisibleFeedbackFormPopup.update(() => !0)
        }
        closeFeedbackPopup() {
            this.isVisibleFeedbackFormPopup.update(() => !1)
        }
        requestUpgradePlan() {
            this.service.requestUpgradePlan().subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_request_submitted_success")
                },
                error: e => {
                    console.error(e), this.toastNotificationService.error("notification_upgrade_plan_request_error")
                },
                complete: () => {
                    this.onClosing()
                }
            })
        }
        openBusinessReadinessChecklist() {
            this.businessReadinessService.checkPendingRefresh(), this.businessReadinessService.fetchProgress(!0).subscribe(), this.isChecklistModalVisible.set(!0)
        }
        closeBusinessReadinessChecklist() {
            this.isChecklistModalVisible.set(!1)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(l(ui))
            }
        }
        static {
            this.\u0275cmp = _({
                type: i,
                selectors: [
                    ["app-sidebar"]
                ],
                inputs: {
                    isExpanded: "isExpanded"
                },
                outputs: {
                    themeToggled: "themeToggled"
                },
                standalone: !1,
                decls: 19,
                vars: 19,
                consts: [
                    ["downloadAndroidAppPopover", ""],
                    [1, "sidebar", 3, "ngClass"],
                    [1, "d-flex", "justify-content-around", "align-items-center", "sidebar-header"],
                    [3, "click", "ngClass", "title"],
                    [1, "nav-menu"],
                    [1, "menu-section"],
                    [1, "sidebar-footer", "d-flex", "flex-column", "align-items-start", "ms-1"],
                    [3, "visible", "width", "maxWidth", "title", "dragEnabled", "showCloseButton"],
                    [1, "d-flex", "justify-content-center", "w-100"],
                    [1, "d-flex", "justify-content-between"],
                    ["icon", "fa-thin fa-sign-out-alt icon-override-color", "id", "logout-collapsed", "stylingMode", "text", "type", "danger", 1, "icon-color", 3, "title"],
                    [3, "onClosePopup", "isVisiblePopup"],
                    [3, "visible"],
                    ["class", "menu-item", 3, "id", "ngClass", "routerLinkActiveOptions", "title", "routerLinkActive", "click", 4, "appAccessControl"],
                    [1, "submenu"],
                    [1, "menu-item", 3, "click", "id", "ngClass", "routerLinkActiveOptions", "title", "routerLinkActive"],
                    [1, "item-content", "link-without-effect", 3, "routerLink", "ngClass"],
                    [3, "ngClass"],
                    [1, "label"],
                    [1, "tooltip"],
                    ["routerLinkActive", "active", 1, "submenu-item", "link-without-effect", 3, "routerLink"],
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title", "dragEnabled", "showCloseButton"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "popup-content"],
                    [1, "popup-text"],
                    [1, "feature-list", "list-unstyled", "d-flex", "flex-column", "gap-2"],
                    [1, "popup-highlight"],
                    [1, "upgrade-action", "mb-1", "d-flex", "align-items-center", "justify-content-between"],
                    [1, "popup-footer"],
                    ["text", "request_upgrade_quote", "buttonType", "default", 3, "onClickEvent"],
                    [3, "openChecklist", "displayMode", "isExpanded"],
                    ["buttonStyle", "text", "buttonType", "default", "icon", "fa-thin fa-rocket-launch", "title", "upgrade_to_standard", 3, "onClickEvent", "isVisibleIcon", "text"],
                    ["icon", "fa-thin fa-question-circle", "id", "help-center", "stylingMode", "text", "type", "default", 3, "onClick", "text", "title", "visible"],
                    ["icon", "fa-thin fa-sign-out-alt icon-override-color", "id", "logout", "stylingMode", "text", "type", "danger", 1, "icon-color", 3, "onClick", "text", "title"],
                    ["icon", "fa-thin fa-mobile-notch", "id", "download-app", "stylingMode", "text", "type", "default", 3, "text", "title", "visible"],
                    ["hideEvent", "mouseleave", "position", "top", "showEvent", "mouseenter", "target", "#download-app", 3, "hideOnOutsideClick", "showTitle", "width"],
                    [3, "mouseleave"],
                    [1, "text-center", "my-2"],
                    [1, "d-flex", "justify-content-center", "align-items-center"],
                    ["aria-label", "QR Code image with the following content...", "src", "assets/images/screenshots/download-app-qr.png", "width", "200", 1, "center", 3, "title", "alt"],
                    [1, "text-secondary", "text-center", "fs-10", "mt-2"],
                    [1, "text-secondary", "text-center", "fs-10"],
                    [1, "text-center", "mt-3"],
                    ["href", "https://play.google.com/store/apps/details?id=com.bytephase.app.twa&hl=en", "rel", "noopener noreferrer", "target", "_blank"],
                    ["src", "../../../../../assets/images/google-play-download-app-icon.png", 1, "img-fluid", "w-75", 3, "alt"],
                    ["icon", "fa-thin fa-sign-out-alt icon-override-color", "id", "logout-collapsed", "stylingMode", "text", "type", "danger", 1, "icon-color", 3, "onClick", "title"],
                    [3, "closeModal", "visible"]
                ],
                template: function(t, o) {
                    t & 1 && (m(0, "aside", 1)(1, "div", 2), V(2, "app-workspace-logo-dropdown"), m(3, "div")(4, "i", 3), x("click", function() {
                        return o.toggleSidebar()
                    }), b()()(), m(5, "nav", 4)(6, "div", 5)(7, "ul"), Ao(8, l0, 2, 1, "li", null, Ro), b()()(), m(10, "div", 6), k(11, d0, 2, 7, "dx-popup", 7), k(12, p0, 2, 2, "div", 8), k(13, u0, 2, 2, "div"), k(14, m0, 7, 12, "div", 9)(15, f0, 1, 1, "dx-button", 10), b()(), m(16, "app-request-app-beta-access-popup", 11), x("onClosePopup", function() {
                        return o.closeRequestAccessPopup()
                    }), b(), m(17, "app-overall-app-feedback", 11), x("onClosePopup", function() {
                        return o.closeFeedbackPopup()
                    }), b(), k(18, g0, 1, 1, "app-checklist-modal", 12)), t & 2 && (T("ngClass", ft(10, $_, o.isExpanded, o.isDarkTheme())), u(4), T("ngClass", ft(13, Q_, o.isExpanded, !o.isExpanded))("title", o.isExpanded ? o.formatMessage("close_sidebar") : o.formatMessage("open_sidebar")), u(4), Oo(o.menuItems), u(3), M(o.isVisibleUpdatePlanPopup ? 11 : -1), u(), M(o.isEmployee && !o.isMobileDevice && o.businessReadinessService.shouldShowInSidebar() ? 12 : -1), u(), M(o.isEmployee && ft(16, Z_, o.TENANT_PLANS.LITE, o.TENANT_PLANS.BASIC).includes(o.plan) ? 13 : -1), u(), M(o.isExpanded ? 14 : 15), u(2), T("isVisiblePopup", o.isVisibleRequestAppAccessPopup()), u(), T("isVisiblePopup", o.isVisibleFeedbackFormPopup()), u(), M(o.isChecklistModalVisible() ? 18 : -1))
                },
                dependencies: [ni, Ai, Yl, fd, hi, _d, Cd, Rc, wn, En, Uc, Hc, Nn, Ad],
                styles: [".sidebar[_ngcontent-%COMP%]{height:100vh;width:260px;transition:width .3s ease;display:flex;flex-direction:column;box-shadow:0 .5rem 1rem #00000026!important}.sidebar[_ngcontent-%COMP%]:not(.expanded){width:72px}.sidebar[_ngcontent-%COMP%]:not(.expanded)   .item-content[_ngcontent-%COMP%]{padding:21px!important}.sidebar[_ngcontent-%COMP%]:not(.expanded)   .tooltip[_ngcontent-%COMP%]{position:absolute;left:100%;background:var(--tooltip-bg);color:var(--tooltip-color);padding:8px;border-radius:4px;font-size:14px;margin-left:8px;opacity:0;pointer-events:none}.menu-item[_ngcontent-%COMP%]:hover   .sidebar[_ngcontent-%COMP%]:not(.expanded)   .tooltip[_ngcontent-%COMP%]{opacity:1}.sidebar[_ngcontent-%COMP%]{--bg-primary: #ffffff;--bg-secondary: #ffffff;--text-primary: #2c3e50;--text-secondary: #95a5a6;--accent-color: #3498db;--border-color: #ecf0f1;--tooltip-bg: #34495e;--tooltip-color: #ffffff}.sidebar.dark-theme[_ngcontent-%COMP%]{--bg-primary: #10172A;--bg-secondary: #1E293B;--text-primary: #94A3B8;--text-secondary: #a0aec0;--accent-color: #3498db;--border-color: #334155;--tooltip-bg: #334155;--tooltip-color: #ffffff}.sidebar[_ngcontent-%COMP%]   .fa-thin[_ngcontent-%COMP%]{font-weight:100!important}.sidebar[_ngcontent-%COMP%]{background:var(--bg-secondary);color:var(--text-primary)}.sidebar[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]{list-style:none;padding:0;margin:0}.nav-menu[_ngcontent-%COMP%]{flex:1;overflow-y:auto;overflow-x:hidden}.nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]{position:relative;margin:2px 8px;border-radius:6px}.nav-menu[_ngcontent-%COMP%]   .menu-item.active[_ngcontent-%COMP%], .nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]:hover{border:.1px solid var(--accent-color)}.nav-menu[_ngcontent-%COMP%]   .menu-item.active[_ngcontent-%COMP%]   .item-content[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%], .nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]:hover   .item-content[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%]{color:var(--accent-color)}.nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .item-content[_ngcontent-%COMP%]{padding:12px 16px!important;display:flex;align-items:center;text-decoration:none;color:var(--text-primary);gap:12px;width:100%;margin:0}.nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .item-content[_ngcontent-%COMP%]:hover{background:var(--bg-secondary);border-radius:6px}.nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .item-content[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{width:24px;text-align:center;font-size:18px;display:flex;align-items:center;justify-content:center}.nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .item-content[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%]{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nav-menu[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .item-content[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%]{margin-left:auto;font-size:1.33rem}.nav-menu[_ngcontent-%COMP%]   .submenu[_ngcontent-%COMP%]{background:var(--bg-secondary);margin:4px 0}.nav-menu[_ngcontent-%COMP%]   .submenu[_ngcontent-%COMP%]   .submenu-item[_ngcontent-%COMP%]{padding:8px 12px 8px 44px;display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text-primary);margin:2px 8px;border-radius:6px}.nav-menu[_ngcontent-%COMP%]   .submenu[_ngcontent-%COMP%]   .submenu-item[_ngcontent-%COMP%]:hover, .nav-menu[_ngcontent-%COMP%]   .submenu[_ngcontent-%COMP%]   .submenu-item.active[_ngcontent-%COMP%]{background:var(--bg-primary)}.nav-menu[_ngcontent-%COMP%]   .submenu[_ngcontent-%COMP%]   .submenu-item[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{width:16px;text-align:center;font-size:14px}.nav-menu[_ngcontent-%COMP%]   .submenu[_ngcontent-%COMP%]   .submenu-item[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%]{font-size:1.33rem}.sidebar-footer[_ngcontent-%COMP%]{border-top:1px solid var(--border-color);padding:12px}.sidebar-footer[_ngcontent-%COMP%]   .footer-btn[_ngcontent-%COMP%]{width:100%;padding:10px 12px;display:flex;align-items:center;gap:12px;background:none;border:none;color:var(--text-primary);cursor:pointer;border-radius:6px}.sidebar-footer[_ngcontent-%COMP%]   .footer-btn[_ngcontent-%COMP%]:hover{background:var(--bg-secondary)}.sidebar-footer[_ngcontent-%COMP%]   .footer-btn.logout-btn[_ngcontent-%COMP%]{color:#e74c3c}.sidebar-footer[_ngcontent-%COMP%]   .footer-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{width:20px;text-align:center}.link-without-effect[_ngcontent-%COMP%]{text-decoration:none;color:inherit}.beta-sidebar-opened[_ngcontent-%COMP%], .beta-sidebar-closed[_ngcontent-%COMP%]{position:absolute;top:1rem;transition:all .1s ease}.beta-sidebar-opened[_ngcontent-%COMP%]{left:calc(100vw - (100vw - 256px))}.beta-sidebar-closed[_ngcontent-%COMP%]{left:5.5rem;animation:badgeFadeIn .1s ease forwards}.toggle-sidebar-icon[_ngcontent-%COMP%]{font-size:1.5rem;padding:10px;cursor:pointer}.toggle-sidebar-icon[_ngcontent-%COMP%]:hover{border:.1px solid var(--accent-color)}.d-contents[_ngcontent-%COMP%]{display:contents!important}"]
            })
        }
    }
    return i
})();

function _0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "button", 2), x("click", function() {
            L(e);
            let o = v();
            return j(o.navigate("dashboard"))
        }), V(1, "i", 3), m(2, "span", 4), G(3, "Dashboard"), b()()
    }
    if (i & 2) {
        let e = v();
        Oe("active", e.activeTab() === "dashboard"), u(), Oe("fa-solid", e.activeTab() === "dashboard")("fa-regular", e.activeTab() !== "dashboard")("fa-gauge-high", !0)
    }
}

function b0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "button", 9), x("click", function() {
            L(e);
            let o = v();
            return j(o.openQuickCreate())
        }), m(1, "div", 10), V(2, "i", 11), b()()
    }
}

function y0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-qrcode-scanner", 12), x("scannerToSave", function(o) {
            L(e);
            let r = v();
            return j(r.onQrScanResult(o))
        })("scannerToClose", function() {
            L(e);
            let o = v();
            return j(o.closeQrScanner())
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isVisiblePopup", e.isQrScannerOpen())("type", "get_barcode_number")
    }
}
var fh = (() => {
    class i {
        constructor() {
            this.formatMessage = Q, this.router = p(te), this.userSessionService = p(pt), this.mobileMenuService = p(Id), this.scanBarcodeService = p(kn), this.hapticService = p(Tn), this.activeTab = ne(this.resolveTab(this.router.url)), this.isQuickCreateOpen = ne(!1), this.isQrScannerOpen = ne(!1), this.isProfileMenuOpen = ne(!1), this.isEmployee = xe(() => this.userSessionService.isEmployee()), this.currentUser = xe(() => this.userSessionService.currentUser()), this.router.events.pipe(ve(e => e instanceof vt)).subscribe(e => {
                this.activeTab.set(this.resolveTab(e.urlAfterRedirects))
            })
        }
        resolveTab(e) {
            return e.startsWith("/dashboards") ? "dashboard" : e.startsWith("/mobileMenu") ? "home" : this.activeTab ? .() ? ? "home"
        }
        navigate(e) {
            switch (this.hapticService.selectionClick(), this.activeTab.set(e), e) {
                case "home":
                    this.mobileMenuService.resetToMainMenu(), this.router.navigate(["/mobileMenu"]);
                    break;
                case "dashboard":
                    this.router.navigate(["/dashboards"]);
                    break;
                case "scan":
                    this.openQrScanner();
                    break;
                case "account":
                    this.openProfileMenu();
                    break
            }
        }
        openQuickCreate() {
            this.hapticService.mediumImpact(), this.isQuickCreateOpen.set(!0)
        }
        closeQuickCreate() {
            this.isQuickCreateOpen.set(!1)
        }
        openQrScanner() {
            this.isQrScannerOpen.set(!0)
        }
        closeQrScanner() {
            this.isQrScannerOpen.set(!1)
        }
        openProfileMenu() {
            this.isProfileMenuOpen.set(!0)
        }
        closeProfileMenu() {
            this.isProfileMenuOpen.set(!1)
        }
        onQrScanResult(e) {
            this.isQrScannerOpen.set(!1), this.scanBarcodeService.handleQrScanResult(e)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275cmp = _({
                type: i,
                selectors: [
                    ["app-mobile-bottom-nav"]
                ],
                standalone: !1,
                decls: 19,
                vars: 30,
                consts: [
                    [1, "bottom-nav-container"],
                    [1, "bottom-nav"],
                    [1, "nav-item", 3, "click"],
                    [1, "nav-icon", "icon-override-color"],
                    [1, "nav-label"],
                    [1, "nav-item", 3, "active"],
                    [1, "nav-item-quick-create"],
                    [3, "closeEvent", "isVisible"],
                    [3, "isVisiblePopup", "type"],
                    [1, "nav-item-quick-create", 3, "click"],
                    [1, "quick-create-button"],
                    [1, "fa-solid", "fa-plus", "icon-override-color"],
                    [3, "scannerToSave", "scannerToClose", "isVisiblePopup", "type"]
                ],
                template: function(t, o) {
                    t & 1 && (m(0, "div", 0)(1, "div", 1)(2, "button", 2), x("click", function() {
                        return o.navigate("home")
                    }), V(3, "i", 3), m(4, "span", 4), G(5, "Menu"), b()(), k(6, _0, 4, 8, "button", 5), k(7, b0, 3, 0, "button", 6), m(8, "button", 2), x("click", function() {
                        return o.navigate("scan")
                    }), V(9, "i", 3), m(10, "span", 4), G(11), b()(), m(12, "button", 2), x("click", function() {
                        return o.navigate("account")
                    }), V(13, "i", 3), m(14, "span", 4), G(15, "Profile"), b()()()(), m(16, "app-quick-create", 7), x("closeEvent", function() {
                        return o.closeQuickCreate()
                    }), b(), k(17, y0, 1, 2, "app-qrcode-scanner", 8), m(18, "app-mobile-profile-menu", 7), x("closeEvent", function() {
                        return o.closeProfileMenu()
                    }), b()), t & 2 && (u(2), Oe("active", o.activeTab() === "home"), u(), Oe("fa-solid", o.activeTab() === "home")("fa-regular", o.activeTab() !== "home")("fa-bars", !0), u(3), M(o.isEmployee() ? 6 : -1), u(), M(o.isEmployee() ? 7 : -1), u(), Oe("active", o.activeTab() === "scan"), u(), Oe("fa-solid", o.activeTab() === "scan")("fa-regular", o.activeTab() !== "scan")("fa-qrcode", !0), u(2), Te(o.formatMessage("scan_code")), u(), Oe("active", o.activeTab() === "account"), u(), Oe("fa-solid", o.activeTab() === "account")("fa-regular", o.activeTab() !== "account")("fa-user", !0), u(3), T("isVisible", o.isQuickCreateOpen()), u(), M(o.isQrScannerOpen() ? 17 : -1), u(), T("isVisible", o.isProfileMenuOpen()))
                },
                dependencies: [Mn, Rn, Bd],
                styles: ['.bottom-nav-container[_ngcontent-%COMP%]{position:fixed;bottom:0;left:0;right:0;z-index:1000;background:var(--primary-bg);padding-bottom:env(safe-area-inset-bottom,0)}.bottom-nav[_ngcontent-%COMP%]{background:var(--primary-bg);display:flex;align-items:flex-end;justify-content:space-around;padding:12px 16px 16px;position:relative}.nav-item[_ngcontent-%COMP%]{background:none!important;background-color:transparent!important;border:none!important;outline:none!important;box-shadow:none!important;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;padding:8px 0 0;transition:all .2s ease;flex:1;max-width:72px;-webkit-tap-highlight-color:transparent;position:relative}.nav-item[_ngcontent-%COMP%]:before{content:"";position:absolute;top:0;left:50%;transform:translate(-50%);width:0;height:3px;background:#6366f1;border-radius:0 0 3px 3px;transition:width .2s ease}.nav-item.active[_ngcontent-%COMP%]:before{width:24px}.nav-item[_ngcontent-%COMP%]:focus, .nav-item[_ngcontent-%COMP%]:active, .nav-item[_ngcontent-%COMP%]:hover{background:none!important;background-color:transparent!important;border:none!important;outline:none!important;box-shadow:none!important}.nav-item[_ngcontent-%COMP%]:active{transform:scale(.95)}.nav-icon[_ngcontent-%COMP%]{font-size:22px;line-height:1;transition:color .2s ease;background:none!important;background-color:transparent!important;border:none!important;border-radius:0!important;box-shadow:none!important;outline:none!important;padding:0!important;margin:0}.nav-icon[_ngcontent-%COMP%]:before, .nav-icon[_ngcontent-%COMP%]:after{border:none!important;box-shadow:none!important}.nav-label[_ngcontent-%COMP%]{font-size:11px;font-weight:500;letter-spacing:.1px;transition:color .2s ease}.nav-item-quick-create[_ngcontent-%COMP%]{background:none;border:none;cursor:pointer;padding:0;margin:0;flex:1;max-width:72px;display:flex;justify-content:center;align-items:flex-end;position:relative;height:50px}.quick-create-button[_ngcontent-%COMP%]{width:52px;height:52px;border-radius:50%;background:#6366f1!important;display:flex;align-items:center;justify-content:center;color:#fff;box-shadow:0 4px 15px #6366f180;transition:all .2s ease;position:absolute;bottom:6px;will-change:transform}.quick-create-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:20px;font-weight:300;color:#fff!important;-webkit-text-stroke:0!important}.quick-create-button[_ngcontent-%COMP%]:active{transform:scale(.95);box-shadow:0 2px 8px #6366f166}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav-container[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav-container[_ngcontent-%COMP%]{background:#fff}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]{background:#fff!important}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%]{color:#6366f1!important;-webkit-text-stroke:0!important}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%]{color:#6366f1!important}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%]{color:#6366f1!important}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%]{color:#6366f1!important}body:not(.dark-theme)[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .quick-create-button[_ngcontent-%COMP%], body:not(.dark-theme)   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .quick-create-button[_ngcontent-%COMP%]{background:#6366f1!important;box-shadow:0 4px 15px #6366f166}.dark-theme[_nghost-%COMP%]   .bottom-nav-container[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav-container[_ngcontent-%COMP%]{background:#0f172a}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]{background:#0f172a!important;border-top:1px solid rgba(99,102,241,.2)}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%]{color:#94a3b8!important;-webkit-text-stroke:0!important}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%]{color:#94a3b8!important}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]:before, .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]:before{background:#818cf8}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   i.nav-icon[_ngcontent-%COMP%]{color:#818cf8!important}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .nav-item.active[_ngcontent-%COMP%]   .nav-label[_ngcontent-%COMP%]{color:#818cf8!important}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .quick-create-button[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .quick-create-button[_ngcontent-%COMP%]{background:#6366f1!important;box-shadow:0 4px 20px #6366f180!important}.dark-theme[_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .quick-create-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .bottom-nav[_ngcontent-%COMP%]   .quick-create-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#fff!important}@media(max-width:360px){.nav-label[_ngcontent-%COMP%]{font-size:10px}.nav-icon[_ngcontent-%COMP%]{font-size:20px}.quick-create-button[_ngcontent-%COMP%]{width:46px;height:46px}.quick-create-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:18px}}'],
                changeDetection: 0
            })
        }
    }
    return i
})();

function S0(i, n) {
    if (i & 1 && (m(0, "span", 5), G(1), b()), i & 2) {
        let e = v(2);
        u(), Te(e.pageTitle())
    }
}

function I0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 1)(1, "div", 2)(2, "button", 3), x("click", function() {
            L(e);
            let o = v();
            return j(o.goBack())
        }), V(3, "i", 4), b(), k(4, S0, 2, 1, "span", 5), b()()
    }
    if (i & 2) {
        let e = v();
        u(2), Ue("aria-label", e.formatMessage("common_back")), u(2), M(e.pageTitle() ? 4 : -1)
    }
}

function w0(i, n) {
    if (i & 1 && (m(0, "span", 9), G(1), b()), i & 2) {
        let e = v(2);
        u(), Te(e.notificationCount())
    }
}

function E0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "button", 3), x("click", function() {
            L(e);
            let o = v(2);
            return j(o.toggleTheme())
        }), V(1, "i"), b()
    }
    if (i & 2) {
        let e = v(2);
        u(), bl((e.isDarkTheme() ? "fa-solid fa-sun-bright" : "fa-solid fa-moon") + " icon-override-color")
    }
}

function D0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "div", 1)(1, "div", 2)(2, "div", 6), V(3, "app-workspace-logo-dropdown"), b()(), m(4, "div", 7)(5, "button", 3), x("click", function() {
            L(e);
            let o = v();
            return j(o.openNotifications())
        }), V(6, "i", 8), k(7, w0, 2, 1, "span", 9), b(), k(8, E0, 2, 2, "button", 10), m(9, "button", 3), x("click", function() {
            L(e);
            let o = v();
            return j(o.openSearch())
        }), V(10, "i", 11), b()()()
    }
    if (i & 2) {
        let e = v();
        u(7), M(e.notificationCount() > 0 ? 7 : -1), u(), M(e.canChangeTheme() ? 8 : -1)
    }
}
var gh = (() => {
    class i {
        constructor() {
            this.router = p(te), this.location = p(gt), this.themeService = p(Ye), this.hapticService = p(Tn), this.notificationCount = ne(0), this.isDarkTheme = xe(() => this.themeService.isDarkTheme()), this.canChangeTheme = this.themeService.canChangeTheme, this.formatMessage = Q, this.topLevelRoots = ["mobileMenu", "dashboards"], this.segmentTitles = {
                jobs: "jobs",
                customers: "customers",
                sales: "common_sale",
                purchases: "common_purchase",
                quotations: "quotation",
                amcs: "amc",
                employees: "employees",
                leads: "leads",
                parts: "common_parts",
                expenses: "expenses",
                tasks: "tasks",
                reports: "reports",
                settings: "settings",
                billings: "commission",
                imports: "imports",
                calender: "topbar_calendar"
            }, this.currentUrl = uc(this.router.events.pipe(ve(e => e instanceof vt), ze(e => e.urlAfterRedirects), wi(this.router.url), Pe()), {
                initialValue: this.router.url
            }), this.currentRoot = xe(() => this.currentUrl().split("?")[0].split("/").filter(Boolean)[0] ? ? ""), this.isDeepPage = xe(() => !this.topLevelRoots.includes(this.currentRoot())), this.pageTitle = xe(() => {
                let e = this.segmentTitles[this.currentRoot()];
                return e ? Q(e) : Q("common_back")
            })
        }
        goBack() {
            this.hapticService.lightImpact(), this.location.back()
        }
        toggleTheme() {
            this.hapticService.mediumImpact(), this.themeService.toggleTheme()
        }
        openSearch() {
            this.hapticService.lightImpact(), this.router.navigate(["/mobileMenu/search"])
        }
        openNotifications() {
            this.hapticService.lightImpact(), this.router.navigate(["/mobileMenu/notifications"])
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275cmp = _({
                type: i,
                selectors: [
                    ["app-mobile-top-nav"]
                ],
                standalone: !1,
                decls: 3,
                vars: 1,
                consts: [
                    [1, "top-nav-wrapper"],
                    [1, "top-nav"],
                    [1, "nav-left"],
                    [1, "icon-button", 3, "click"],
                    [1, "fa-thin", "fa-arrow-left", "icon-override-color"],
                    [1, "back-header-title"],
                    [1, "logo-section"],
                    [1, "nav-right"],
                    [1, "fa-solid", "fa-bell", "icon-override-color"],
                    [1, "notification-badge"],
                    [1, "icon-button"],
                    [1, "fa-solid", "fa-search", "icon-override-color"]
                ],
                template: function(t, o) {
                    t & 1 && (m(0, "div", 0), k(1, I0, 5, 2, "div", 1)(2, D0, 11, 2, "div", 1), b()), t & 2 && (u(), M(o.isDeepPage() ? 1 : 2))
                },
                dependencies: [hi],
                styles: [".top-nav-wrapper[_ngcontent-%COMP%]{position:sticky;top:0;z-index:100;background:var(--primary-bg);backdrop-filter:blur(20px);border-bottom:1px solid var(--theme-border-color);padding-top:env(safe-area-inset-top,0px)}.top-nav[_ngcontent-%COMP%]{padding:12px 16px;display:flex;justify-content:space-between;align-items:center}.nav-left[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px}.back-header-title[_ngcontent-%COMP%]{font-size:18px;font-weight:700;color:var(--font-color);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.logo-section[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px}.brand-info[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:0}.brand-name[_ngcontent-%COMP%]{font-size:18px;font-weight:700;color:var(--primary-text);line-height:1.2;letter-spacing:-.3px;margin:0}.brand-tagline[_ngcontent-%COMP%]{font-size:11px;color:var(--section-header-color);font-weight:500;margin:0}.nav-right[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px}.icon-button[_ngcontent-%COMP%]{width:44px;height:44px;border-radius:12px;border:1px solid var(--theme-border-color);background-color:var(--bg-secondary);color:var(--primary-text);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s ease;position:relative}@media(hover:hover)and (pointer:fine){.icon-button[_ngcontent-%COMP%]:hover{background-color:var(--theme-hover-color);border-color:var(--theme-accent-color)}}.icon-button[_ngcontent-%COMP%]:active{transform:scale(.95)}.icon-button[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:17px}.notification-badge[_ngcontent-%COMP%]{position:absolute;top:-4px;right:-4px;background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;font-size:10px;font-weight:700;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid var(--primary-bg);box-shadow:0 2px 8px #ef444466}.dark-theme[_nghost-%COMP%]   .icon-button[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .icon-button[_ngcontent-%COMP%]{color:#fff;border-color:transparent}"],
                changeDetection: 0
            })
        }
    }
    return i
})();
var x0 = (i, n) => ({
        "page-content": !0,
        "sidebar-expanded": i,
        "sidebar-not-expanded": n
    }),
    P0 = i => ({
        "menu-overlap-margin": i
    });

function k0(i, n) {
    i & 1 && V(0, "app-mobile-top-nav")
}

function M0(i, n) {
    i & 1 && V(0, "app-header")
}

function R0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-confirmation-popup", 11), x("confirmActionCallback", function() {
            L(e);
            let o = v(2);
            return j(o.isNativeShell ? o.updateNativeApp() : o.updateApp())
        })("rejectActionCallback", function() {
            L(e);
            let o = v(2);
            return j(o.handleDenialOfUpdate())
        }), b()
    }
    if (i & 2) {
        let e = v(2);
        T("appUpdatePopUp", !0)("confirmButtonText", e.isMobileDevice ? "update_app" : "reload_page")("title", e.isNativeShell ? e.formatMessage("app_update_available") : e.formatMessage("reload_page_and_update_byte_phase"))("isAndroid", !0)
    }
}

function A0(i, n) {
    if (i & 1 && V(0, "app-sidebar", 7), i & 2) {
        let e = v(2);
        T("ngClass", e.isSidebarExpanded ? "expanded" : "collapsed")
    }
}

function O0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-pull-to-refresh", 12), x("refresh", function(o) {
            L(e);
            let r = v(2);
            return j(r.handleRefresh(o))
        }), b()
    }
}

function N0(i, n) {
    i & 1 && (m(0, "footer"), V(1, "app-mobile-bottom-nav"), b())
}

function L0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "button", 13), x("cdkDragStarted", function() {
            L(e);
            let o = v(2);
            return j(o.onFabDragStarted())
        })("cdkDragEnded", function(o) {
            L(e);
            let r = v(2);
            return j(r.onFabDragEnded(o))
        })("click", function() {
            L(e);
            let o = v(2);
            return j(o.onFabClick())
        }), V(1, "i", 14), b()
    }
    if (i & 2) {
        let e = v(2);
        T("cdkDragFreeDragPosition", e.fabPosition())("title", e.formatMessage("bytephase_assistant")), Ue("aria-label", e.formatMessage("bytephase_assistant"))
    }
}

function j0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-bytephase-assistant", 15), x("onClose", function() {
            L(e);
            let o = v(2);
            return j(o.closeChatbot())
        }), b()
    }
    if (i & 2) {
        let e = v(2);
        T("isVisible", e.isChatbotVisible())
    }
}

function F0(i, n) {
    if (i & 1 && (ln(0), k(1, k0, 1, 0, "app-mobile-top-nav")(2, M0, 1, 0, "app-header"), k(3, R0, 1, 4, "app-confirmation-popup", 5), m(4, "div", 6), k(5, A0, 1, 1, "app-sidebar", 7), m(6, "main", 7), k(7, O0, 1, 0, "app-pull-to-refresh"), m(8, "div", 8), V(9, "router-outlet"), b()()(), k(10, N0, 2, 0, "footer"), k(11, L0, 2, 3, "button", 9), k(12, j0, 1, 1, "app-bytephase-assistant", 10), cn()), i & 2) {
        let e = v();
        u(), M(e.isMobileDevice ? 1 : 2), u(2), M(e.isVisibleUpdateAppPopup || e.isVisibleAndroidAppUpdatePopup ? 3 : -1), u(2), M(e.isMobileDevice ? -1 : 5), u(), T("ngClass", ft(10, x0, !e.isMobileDevice && e.isSidebarExpanded, !e.isMobileDevice && !e.isSidebarExpanded)), u(), M(e.isMobileDevice ? 7 : -1), u(), T("ngClass", ii(13, P0, e.isMobileDevice))("@mobileRouteAnimation", e.getRouteAnimationData()), u(2), M(e.isMobileDevice ? 10 : -1), u(), M(e.isEmployee && !e.isChatbotVisible() ? 11 : -1), u(), M(e.isEmployee ? 12 : -1)
    }
}

function B0(i, n) {
    i & 1 && (m(0, "main", 2)(1, "div", 16), V(2, "router-outlet"), b()())
}

function V0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-task-popup", 17), x("taskCancelClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleTaskPopup = !1)
        })("taskSaveClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleTaskPopup = !1)
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isCreate", !0)("isVisiblePopup", e.isVisibleTaskPopup)
    }
}

function z0(i, n) {
    if (i & 1) {
        let e = W();
        m(0, "app-pickup-drop-popup", 18), x("pickupDropCancelClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleSchedulePickupPopup = !1)
        })("pickupDropSaveClick", function() {
            L(e);
            let o = v();
            return j(o.isVisibleSchedulePickupPopup = !1)
        }), b()
    }
    if (i & 2) {
        let e = v();
        T("isCreate", !0)("isVisiblePopup", e.isVisibleSchedulePickupPopup)
    }
}

function U0(i, n) {
    i & 1 && V(0, "app-install-android-app-popup")
}
var _h = (() => {
    class i {
        constructor(e, t, o, r, s) {
            this.sidebarService = e, this.meta = t, this.location = o, this.mobileAppService = r, this.renderer = s, this.formatMessage = Q, this.toastNotificationService = p(di), this.routerHelperService = p(kc), this.authorizationService = p(pi), this.jobDataService = p(md), this.router = p(te), this.authService = p(dt), this.userSessionService = p(pt), this.themeService = p(Ye), this.tenantService = p(ut), this.userDeviceService = p(Le), this.loaderService = p(Dn), this.devextremeConfigService = p(sh), this.pushNotificationService = p(wd), this.permissionService = p(ed), this.mobileAppUpdateService = p(lh), this.pwaUpdateService = p(ch), this.pwaInstallService = p(Ln), this.guidedTourService = p(Pd), this.welcomeTourStarted = !1, this.networkService = p(Fd), this.ngZone = p(f), this.destroyRef = p(Di), this.employeeService = p(Ec), this.customerService = p(wc), this.contexts = p(Ri), this.isLoading$ = this.loaderService.isLoading$, this.isMobileDevice = this.userDeviceService.isMobileDevice(), this.isNativeShell = this.userDeviceService.isCapacitorNative(), this.isDarkTheme = this.themeService.isDarkTheme, this.isEmployee = this.userSessionService.isEmployee(), this.hasEarlyAccess = this.tenantService.hasEarlyAccess, this.isLoggedIn = this.userSessionService.isLoggedIn, this.userPermissionList = this.userSessionService.userPermissionList(), this.isSetupWizardCompleted = xe(() => this.tenantService.config() ? .is_completed_wizard_setup ? ? !1), this.keyboardShortcutService = p(ah), this.refreshService = p(kd), this.isVisibleUpdateAppPopup = !1, this.isVisibleSchedulePickupPopup = !1, this.isVisibleTaskPopup = !1, this.isVisibleInstallAppPopUp = !1, this.isVisibleAndroidAppUpdatePopup = !1, this.isSidebarExpanded = !0, this.isChatbotVisible = ne(!1), this.FAB_STORAGE_KEY = "chatbotFabPosition", this.FAB_EDGE_MARGIN = 24, this.SIDEBAR_W = {
                collapsed: 72,
                expanded: 248
            }, this.fabPosition = ne({
                x: 0,
                y: 0
            }), this.fabWasDragged = !1, this.isSplashVisible = ne(!0), this.isSplashExiting = ne(!1), this.splashBootedAt = Date.now(), this.loaderLogo = gc, this.setStatusBar = () => re(this, null, function*() {
                if (this.userDeviceService.isCapacitorNative()) try {
                    yield Zi.show(), yield Zi.setOverlaysWebView({
                        overlay: !1
                    });
                    let a = this.isDarkTheme() ? "#10172A" : "#ffffff",
                        c = this.isDarkTheme() ? Co.Light : Co.Dark;
                    yield Zi.setBackgroundColor({
                        color: a
                    }), yield Zi.setStyle({
                        style: c
                    }), console.log(`[StatusBar] Set overlay: false, color: ${a}, style: ${c}`)
                } catch (a) {
                    console.error("[StatusBar] Error setting status bar:", a)
                }
            }), this.lastBackPress = 0, Jt(() => {
                this.isDarkTheme() ? this.renderer.addClass(document.body, "dark-theme") : this.renderer.removeClass(document.body, "dark-theme")
            }), Jt(() => {
                this.welcomeTourStarted || !this.isLoggedIn() || !this.isSetupWizardCompleted() || localStorage.getItem("pendingWelcomeTour") === "1" && this.userSessionService.isAdmin() && (this.welcomeTourStarted = !0, localStorage.removeItem("pendingWelcomeTour"), setTimeout(() => this.guidedTourService.startTour("OVERVIEW"), 1200))
            }), this.setStatusBar(), this.initializeBackButton(), this.initializeDeepLinks(), this.initializeKeyboard(), this.initializeAppResumeUserRefresh(), this.hideNativeSplash(), this.scheduleAppSplashDismiss(), this.networkService.initialize(), this.markInstallOrPromptPwa(), this.initFabPosition(), nc.register(oc), this.sidebarService.sidebarExpanded$.pipe(Pe()).subscribe(a => this.isSidebarExpanded = a), this.themeService.currentTheme$.pipe(Pe()).subscribe(() => {
                this.setStatusBar(), this.devextremeConfigService.reconfigure()
            }), this.meta.addTags([{
                name: "description",
                content: "Repair tracking, inventory, sale, expense management software for Computer, Laptop, Cell Phone Stores, Easy to use and trusted by thousands of customers"
            }, {
                name: "keywords",
                content: "mobile phone repair shop, laptop repair shop, computer repair shop, laptop repairing, computer repairing, mobile repairing,Repair tracking, inventory management, and Sale management software for laptop, computer, and cell phone repair shops,repair, repairdesk, business, phone, laptop, computer, phone repair, repair business, computer repair, ticket management,repair ticket, point of sale, grow your repair, repair restoration, repair computer, employee management, inventory management,cellphone repair, repair ticket management, your repair shop, phone repair business, computer repair business, laptop repair business,cheap iphone repair near me, cheap laptop repair near me, laptop fixer, computer fixer, laptop screen repair,computer cpu repair, chip level laptop repair, chip level computer repair, data recovery, HDD recovery, hard drive data recovery,service center, laptop repair service center, computer service center, dell service center, apple service center, hp service center,motherboard repair, mobile service center, iphone repair, macbook repair, imac repair, lenovo service center,printer repair service near me, lenovo customer care, dell customer care, apple customer care, windows 11, hp laptop repair near me,dell laptop repair near me, lenovo laptop near me, computer repair services, laptop repair services,expense management, lead management, laptop repair management, laptop repair management crm, computer repair management,computer repair management crm, data recovery management crm, pickup drop management, task management, customer management software"
            }]), this.devextremeConfigService.initialize(), this.router.events.pipe(ve(a => a instanceof vt), Pe()).subscribe({
                next: () => {
                    this.authService.setIsVisibleSetup(this.router.url === "/setups")
                },
                error: a => {
                    console.error(a)
                }
            }), this.registerKeyboardShortcuts(), this.authService.currentUser.pipe(ve(a => !!a), Pe()).subscribe(a => re(this, null, function*() {
                if (this.userSessionService.isEmployee() && (yield this.permissionService.refresh(), this.permissionService.needsLoginOnboarding() && !this.permissionService.isLoginOnboardingSkipped())) {
                    let c = this.isMobileDevice ? "/mobileMenu/permissions" : "/permissions";
                    this.router.navigate([c], {
                        queryParams: {
                            reason: "login-onboarding"
                        }
                    });
                    return
                }
                this.pushNotificationService.initialize(), a ? .is_push_token_missing && (yield this.pushNotificationService.forceReacquire())
            })), this.mobileAppUpdateService.initialize(() => {
                this.isVisibleAndroidAppUpdatePopup = !0
            }), this.userDeviceService.isWeb() && this.pwaUpdateService.initialize(() => {
                this.isVisibleUpdateAppPopup = !0
            })
        }
        updateApp() {
            this.pwaUpdateService.activateUpdate()
        }
        updateNativeApp() {
            return re(this, null, function*() {
                this.isVisibleAndroidAppUpdatePopup = !1, yield this.mobileAppUpdateService.openAppStore()
            })
        }
        handleDenialOfUpdate() {
            this.isVisibleUpdateAppPopup = !1, this.isVisibleAndroidAppUpdatePopup = !1, this.mobileAppUpdateService.dismissUpdate()
        }
        redirectToJobAdd() {
            this.jobDataService.isRecoveryJob ? this.routerHelperService.navigateAddRecoveryJob() : this.jobDataService.isRepairJob && this.routerHelperService.navigateAddRepairJob()
        }
        registerKeyboardShortcuts() {
            this.keyboardShortcutService.registerShortcuts({
                onJobAdd: () => this.redirectToJobAdd(),
                onShowTaskPopup: () => this.isVisibleTaskPopup = !0,
                onShowPickupDropPopup: () => this.isVisibleSchedulePickupPopup = !0
            })
        }
        initializeBackButton() {
            Qe.isNativePlatform() && zt.addListener("backButton", ({
                canGoBack: e
            }) => {
                this.ngZone.run(() => {
                    let t = document.querySelector('.dx-overlay-wrapper.dx-popup-wrapper:not([style*="display: none"])');
                    if (t) {
                        let r = t.querySelector(".dx-closebutton");
                        if (r) {
                            r.click();
                            return
                        }
                    }
                    if (this.isVisibleTaskPopup) {
                        this.isVisibleTaskPopup = !1;
                        return
                    }
                    if (this.isVisibleSchedulePickupPopup) {
                        this.isVisibleSchedulePickupPopup = !1;
                        return
                    }
                    if (this.isChatbotVisible()) {
                        this.closeChatbot();
                        return
                    }
                    if (this.router.url === "/mobileMenu" || this.router.url.split("?")[0].startsWith("/dashboards") || !e) {
                        let r = Date.now();
                        r - this.lastBackPress < 2e3 ? zt.exitApp() : (this.lastBackPress = r, this.toastNotificationService.info("press_back_again_to_exit"));
                        return
                    }
                    this.location.back()
                })
            })
        }
        initializeDeepLinks() {
            Qe.isNativePlatform() && zt.addListener("appUrlOpen", e => {
                let t = e.url.split("://")[1];
                if (!t) return;
                let o = "/" + t.split("?")[0].replace(/^\/+/, "");
                this.ngZone.run(() => this.router.navigateByUrl(o))
            })
        }
        initializeAppResumeUserRefresh() {
            Qe.isNativePlatform() && zt.addListener("appStateChange", e => {
                if (!e.isActive || !this.authService.currentUserValue) return;
                (this.userSessionService.isEmployee() ? this.employeeService.me() : this.customerService.me()).pipe(Pe(this.destroyRef)).subscribe({
                    next: o => {
                        let r = o ? .data ? ? o;
                        if (!r || !r.id) return;
                        this.authService.currentUserValue ? .is_push_token_missing !== r.is_push_token_missing && this.authService.updateCurrentUser(r)
                    },
                    error: o => {
                        console.warn("[App] Silent user refresh on resume failed:", o ? .status)
                    }
                })
            })
        }
        initializeKeyboard() {
            Qe.isNativePlatform() && (yo.addListener("keyboardWillShow", () => {
                this.renderer.addClass(document.body, "kb-open")
            }), yo.addListener("keyboardWillHide", () => {
                this.renderer.removeClass(document.body, "kb-open")
            }), yo.addListener("keyboardDidShow", () => {
                this.scrollFocusedInputIntoView()
            }))
        }
        scrollFocusedInputIntoView() {
            let e = document.activeElement;
            if (!e) return;
            let t = e.tagName;
            (t === "INPUT" || t === "TEXTAREA" || e.isContentEditable === !0) && requestAnimationFrame(() => setTimeout(() => {
                let r = this.findScrollableAncestor(e);
                if (r) {
                    let s = e.getBoundingClientRect(),
                        a = r.getBoundingClientRect(),
                        c = s.top - a.top,
                        d = r.scrollTop + c - (a.height / 2 - s.height / 2);
                    r.scrollTo({
                        top: Math.max(0, d),
                        behavior: "smooth"
                    })
                }
                try {
                    e.scrollIntoView({
                        block: "center",
                        behavior: "smooth"
                    })
                } catch (s) {
                    e.scrollIntoView({
                        block: "center"
                    })
                }
            }, 100))
        }
        findScrollableAncestor(e) {
            let t = e.parentElement;
            for (; t;) {
                if (t.classList.contains("dx-scrollable-container") || t.classList.contains("dx-scrollable-content")) return t;
                let o = getComputedStyle(t).overflowY;
                if ((o === "auto" || o === "scroll") && t.scrollHeight > t.clientHeight) return t;
                t = t.parentElement
            }
            return null
        }
        hideNativeSplash() {
            return re(this, null, function*() {
                Qe.isNativePlatform() && setTimeout(() => {
                    rh.hide({
                        fadeOutDuration: 250
                    }).catch(e => {
                        console.warn("[SplashScreen] hide failed:", e)
                    })
                }, 0)
            })
        }
        scheduleAppSplashDismiss() {
            this.router.events.pipe(ve(o => o instanceof vt), Pe()).subscribe(() => {
                if (!this.isSplashVisible() || this.isSplashExiting()) return;
                let o = Date.now() - this.splashBootedAt,
                    r = Math.max(0, 900 - o);
                setTimeout(() => {
                    this.isSplashExiting.set(!0), setTimeout(() => this.isSplashVisible.set(!1), 320)
                }, r)
            }), setTimeout(() => {
                this.isSplashVisible() && !this.isSplashExiting() && (this.isSplashExiting.set(!0), setTimeout(() => this.isSplashVisible.set(!1), 320))
            }, 6e3)
        }
        markInstallOrPromptPwa() {
            this.userDeviceService.isCapacitorNative() ? this.mobileAppService.markAppInstalled().pipe(Pe()).subscribe() : this.isVisibleInstallAppPopUp = !0
        }
        getRouteAnimationData() {
            if (!this.isMobileDevice) return;
            let e = this.contexts.getContext("primary") ? .route;
            if (!e) return;
            let t = 0,
                o = e.snapshot;
            for (; o;) t += o.url.length, o = o.firstChild;
            return t
        }
        toggleChatbot() {
            this.isChatbotVisible.update(e => !e)
        }
        getFabMetrics() {
            let e = window.innerWidth;
            return e <= 768 ? {
                size: 48,
                bottomGap: 112
            } : e <= 1024 ? {
                size: 52,
                bottomGap: 20
            } : {
                size: 56,
                bottomGap: 64
            }
        }
        getLeftSnapX() {
            return this.isMobileDevice ? this.FAB_EDGE_MARGIN : (this.isSidebarExpanded ? this.SIDEBAR_W.expanded : this.SIDEBAR_W.collapsed) + this.FAB_EDGE_MARGIN
        }
        getFabDefault() {
            let {
                size: e,
                bottomGap: t
            } = this.getFabMetrics();
            return {
                x: window.innerWidth - e - this.FAB_EDGE_MARGIN,
                y: window.innerHeight - e - t
            }
        }
        initFabPosition() {
            let e = this.getFabDefault();
            try {
                let t = localStorage.getItem(this.FAB_STORAGE_KEY);
                t && (e = this.clampFabPosition(JSON.parse(t)))
            } catch (t) {}
            this.fabPosition.set(e)
        }
        clampFabPosition(e) {
            let {
                size: t
            } = this.getFabMetrics(), o = this.isMobileDevice ? this.FAB_EDGE_MARGIN : 0, r = window.innerWidth - t - this.FAB_EDGE_MARGIN, s = window.innerHeight - t - this.FAB_EDGE_MARGIN;
            return {
                x: Math.min(Math.max(e.x, o), Math.max(r, o)),
                y: Math.min(Math.max(e.y, this.FAB_EDGE_MARGIN), Math.max(s, this.FAB_EDGE_MARGIN))
            }
        }
        onFabDragStarted() {
            this.fabWasDragged = !0
        }
        onFabDragEnded(e) {
            let {
                x: t,
                y: o
            } = e.source.getFreeDragPosition(), {
                size: r
            } = this.getFabMetrics(), s = window.innerWidth - r - this.FAB_EDGE_MARGIN, c = t + r / 2 < window.innerWidth / 2 ? this.getLeftSnapX() : s, d = this.clampFabPosition({
                x: c,
                y: o
            });
            this.fabPosition.set(d), e.source.setFreeDragPosition(d);
            try {
                localStorage.setItem(this.FAB_STORAGE_KEY, JSON.stringify(d))
            } catch (h) {}
            setTimeout(() => this.fabWasDragged = !1, 0)
        }
        onFabClick() {
            this.fabWasDragged || this.toggleChatbot()
        }
        onWindowResize() {
            this.fabPosition.set(this.clampFabPosition(this.fabPosition()))
        }
        closeChatbot() {
            this.isChatbotVisible.set(!1)
        }
        handleRefresh(e) {
            this.refreshService.triggerRefresh(), setTimeout(() => {
                e.complete()
            }, 1500)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(l(ui), l(Bl), l(gt), l(So), l(xi))
            }
        }
        static {
            this.\u0275cmp = _({
                type: i,
                selectors: [
                    ["app-root"]
                ],
                hostBindings: function(t, o) {
                    t & 1 && x("resize", function() {
                        return o.onWindowResize()
                    }, vl)
                },
                standalone: !1,
                decls: 11,
                vars: 14,
                consts: [
                    [3, "visible", "exiting"],
                    [1, "app-container"],
                    [1, "full-page"],
                    [3, "indicatorSrc", "showPane", "visible"],
                    [3, "isCreate", "isVisiblePopup"],
                    [3, "appUpdatePopUp", "confirmButtonText", "title", "isAndroid"],
                    [1, "content-wrapper"],
                    [3, "ngClass"],
                    ["id", "testing", 1, "container-fluid", "p-0", 3, "ngClass"],
                    ["cdkDrag", "", 1, "chatbot-fab", "btn", "btn-primary", "rounded-circle", "shadow-lg", "position-fixed", "d-flex", "align-items-center", "justify-content-center", 3, "cdkDragFreeDragPosition", "title"],
                    [3, "isVisible"],
                    [3, "confirmActionCallback", "rejectActionCallback", "appUpdatePopUp", "confirmButtonText", "title", "isAndroid"],
                    [3, "refresh"],
                    ["cdkDrag", "", 1, "chatbot-fab", "btn", "btn-primary", "rounded-circle", "shadow-lg", "position-fixed", "d-flex", "align-items-center", "justify-content-center", 3, "cdkDragStarted", "cdkDragEnded", "click", "cdkDragFreeDragPosition", "title"],
                    [1, "fa-thin", "fa-robot", "fs-3"],
                    [3, "onClose", "isVisible"],
                    [1, "container-fluid", "p-0"],
                    [3, "taskCancelClick", "taskSaveClick", "isCreate", "isVisiblePopup"],
                    [3, "pickupDropCancelClick", "pickupDropSaveClick", "isCreate", "isVisiblePopup"]
                ],
                template: function(t, o) {
                    t & 1 && (V(0, "app-splash", 0), m(1, "div", 1), k(2, F0, 13, 15, "ng-container"), k(3, B0, 3, 0, "main", 2), b(), V(4, "dx-load-panel", 3), Dl(5, "async"), k(6, V0, 1, 2, "app-task-popup", 4), k(7, z0, 1, 2, "app-pickup-drop-popup", 4), k(8, U0, 1, 0, "app-install-android-app-popup"), V(9, "app-plan-limit-popup")(10, "app-permissions-prompt")), t & 2 && (T("visible", o.isSplashVisible())("exiting", o.isSplashExiting()), u(), Oe("dark-theme", o.isDarkTheme()), u(), M(o.isLoggedIn() && o.isSetupWizardCompleted() ? 2 : -1), u(), M(!o.isLoggedIn() || !o.isSetupWizardCompleted() ? 3 : -1), u(), T("indicatorSrc", o.loaderLogo)("showPane", !1)("visible", Tl(5, 12, o.isLoading$)), u(2), M(o.isVisibleTaskPopup ? 6 : -1), u(), M(o.isVisibleSchedulePickupPopup ? 7 : -1), u(), M(o.isEmployee && o.isVisibleInstallAppPopUp ? 8 : -1))
                },
                dependencies: [ni, Zl, Su, Wc, dd, ld, ud, Sd, Ed, Dd, xd, Oc, vd, hh, mh, fh, gh, Al],
                styles: [".full-page[_ngcontent-%COMP%]{height:100%;overflow-y:auto;-webkit-overflow-scrolling:touch}.menu-overlap-margin[_ngcontent-%COMP%]{margin-bottom:5em!important}.content-wrapper[_ngcontent-%COMP%]{display:flex;height:100vh;width:100%;overflow:hidden}app-sidebar[_ngcontent-%COMP%]{flex-shrink:0;height:100vh;position:fixed;top:0;left:0;z-index:1050}.expanded[_ngcontent-%COMP%]{width:15.5rem}.collapsed[_ngcontent-%COMP%]{width:4.5rem}.page-content[_ngcontent-%COMP%]{flex:1;margin-top:4rem;height:calc(100vh - 4.5rem);overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior-y:contain}.sidebar-not-expanded[_ngcontent-%COMP%]{width:calc(100% - 72px);margin-left:72px}.sidebar-expanded[_ngcontent-%COMP%]{width:calc(100% - 260px);margin-left:260px}@media(max-width:768px){.app-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100vh;height:100dvh;overflow:hidden}.content-wrapper[_ngcontent-%COMP%]{flex:1;min-height:0}.page-content[_ngcontent-%COMP%]{width:100%;margin-top:0;height:100%;padding-bottom:calc(5rem + env(safe-area-inset-bottom,0px));box-sizing:border-box}.sidebar-not-expanded[_ngcontent-%COMP%], .sidebar-expanded[_ngcontent-%COMP%]{width:100%;margin-left:0}}.chatbot-fab[_ngcontent-%COMP%]{top:0;left:0;width:3.5rem;height:3.5rem;z-index:1055;border:none;transition:box-shadow .3s ease;cursor:pointer;touch-action:none}.chatbot-fab[_ngcontent-%COMP%]:hover{box-shadow:0 .5rem 1.5rem #0000004d!important}.chatbot-fab[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{margin:0}@media(max-width:768px){.chatbot-fab[_ngcontent-%COMP%]{width:3rem;height:3rem}.chatbot-fab[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem!important}}@media(min-width:769px)and (max-width:1024px){.chatbot-fab[_ngcontent-%COMP%]{width:3.25rem;height:3.25rem}}"],
                data: {
                    animation: [dh]
                }
            })
        }
    }
    return i
})();
var bh = (() => {
    class i {
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275mod = Ie({
                type: i
            })
        }
        static {
            this.\u0275inj = Se({
                imports: [oi, Vt, An, Md, jd, Nd, Vd]
            })
        }
    }
    return i
})();
var yh = (() => {
    class i {
        constructor(e, t) {
            this.router = e, this.authService = t
        }
        canActivate(e, t) {
            return this.authService.authStatus.pipe(ze(o => o && this.authService.redirectUrl !== "/auth/login" ? (this.router.navigate(["/jobs"]), !1) : (this.router.navigate(["/auth/login"]), !0)), nn(() => Dt(!0)), ul(() => Dt(!0)))
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(te), K(dt))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
    }
    return i
})();
var Ch = (() => {
    class i {
        constructor(e, t, o, r, s, a) {
            this.storageService = e, this.roleService = t, this.authenticationService = o, this.router = r, this.notifyService = s, this.popupService = a
        }
        isAppDomain() {
            return window.location.hostname.split(".")[0] === "app"
        }
        intercept(e, t) {
            let o = e.url.includes("/tracking/"),
                r = e.headers.set("app_version", Ne ? .appVersion),
                s = this.storageService.getTenantId();
            if (s && (r = r.set("X-Tenant", s)), !o) {
                let c = this.storageService.getToken();
                c && (r = r.set("Authorization", "Bearer " + c))
            }
            let a = e.clone({
                headers: r
            });
            return t.handle(a).pipe(nn(c => c instanceof We && c.status === 413 && c.error ? .type === "plan_limit_exceeded" ? (this.popupService.showPlanLimitPopup(c.error), al) : Ji(() => c)), on(() => {}, c => {
                if (c instanceof We && c.status === 0 || c.status === 504) return this.notifyService.error(Q("error_status_504"), "Error"), console.error("Please check internet connection", c), Ji("Please check internet connection");
                if (c instanceof We && c.status === 423 && this.router.navigate(["/errors/UnauthorizedIPAccess"], {
                        queryParams: {
                            message: c.error.message,
                            isVisiblePopup: !0
                        }
                    }), c instanceof We && c.status === 401) this.authenticationService.clearUserSession();
                else if (c instanceof We && c.status === 402) this.notifyService.error(Q("error_status_402"), Q("account_expired"), {
                    disableTimeOut: !0
                }), this.router.navigate(["/settings/subscription"], {
                    queryParams: {
                        message: c.error.message
                    }
                });
                else if (c instanceof We && c.status === 406) this.notifyService.error(c ? .error ? .message, Q("error_status_406"), {
                    disableTimeOut: !0
                });
                else if (c instanceof We && c.status === 403) this.router.navigate(["/errors/forbidden"], {
                    queryParams: {
                        message: c.error.message
                    }
                }), this.notifyService.error(Q("error_status_403"), Q("title_error_status_403"));
                else if (c instanceof We && c.status === 501) this.notifyService.warning(c.error.message, Q("error_sending_notification"), {
                    disableTimeOut: !0
                }), this.router.navigate(["/errors/setup-emails"], {
                    queryParams: {
                        message: c.error.message
                    }
                }), console.error("Error sending email please check and verify email settings", c);
                else if (c instanceof We && c.status === 503) this.authenticationService.clearUserSession(), this.router.navigate(["/errors/maintenance"]), this.notifyService.warning(Q("error_status_503"));
                else if (c instanceof We && c.status === 412) this.isAppDomain() || this.notifyService.error(c ? .error ? .message || "Tenant could not be identified", "Error"), console.error("Tenant identification error", c);
                else if (c instanceof We && c.status === 422) {
                    let d = c ? .error ? .errors,
                        h = d ? Object.keys(d)[0] : null,
                        y = h ? d[h] ? .[0] : c ? .error ? .message;
                    y && this.notifyService.error(y, "Validation Error")
                } else c instanceof We && c.status >= 500 && (this.notifyService.error("Something went wrong", "Error"), console.error("API Error 500", c));
                return Ji("Something went wrong")
            }))
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(Cn), K(Dc), K(dt), K(te), K(lc), K(Td))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac
            })
        }
    }
    return i
})();
var Sh = (() => {
    class i {
        constructor() {
            this.tenantService = p(ut), this.isWhiteLabel = xe(() => this.tenantService.config() ? .is_white_label ? !window.location.hostname.endsWith(Ne.domainName) : !1), this.brandName = xe(() => this.isWhiteLabel() ? this.tenantService.config() ? .name ? ? "BytePhase" : "BytePhase"), this.supportEmail = xe(() => this.isWhiteLabel() ? this.tenantService.config() ? .support_email ? ? "support@bytephase.com" : "support@bytephase.com"), this.logoUrl = xe(() => this.isWhiteLabel() ? this.tenantService.config() ? .logo ? ? null : null)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var Ih = (() => {
    class i extends vn {
        constructor(e, t) {
            super(), this.title = e, this.injector = t, this.brandingService = null
        }
        getBrandingService() {
            return this.brandingService || (this.brandingService = this.injector.get(Sh)), this.brandingService
        }
        updateTitle(e) {
            let t = this.buildTitle(e);
            if (t) {
                let o = this.getBrandingService(),
                    r = o.isWhiteLabel() ? t.replace(/BytePhase/gi, o.brandName()) : t;
                this.title.setTitle(r)
            }
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(K(Vl), K(se))
            }
        }
        static {
            this.\u0275prov = A({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var wh = "ewogICJmb3JtYXQiOiAxLAogICJjdXN0b21lcklkIjogIjU2ODIyMWE5LTBlMmEtNDdhOC04NjZlLTNlZTExNjQwOGQyYyIsCiAgIm1heFZlcnNpb25BbGxvd2VkIjogMjUxCn0=.WFcQoyP+4imeHXlD/lK35QJvW+AgCvODAKqgxXwreIgrOnt09SusjTpxOuiLELMuT65ngOXKbSgQL7L2wmZtb+kld7OO89hmFrbJYzAM4NofDkWahzZiyQz5ZDNLnzISZjUEgw==";
Sn({
    licenseKey: wh
});
tc(Ne.firebase);

function H0() {
    let i = window.location.href.toLowerCase();
    return !localStorage.getItem("token") || !localStorage.getItem("tenantId") ? !0 : i.includes("signup") || i.includes("login.") || i.includes("tenantlogin") || i.includes("auth/tenants") || i.includes("auth/tenantverify") || i.includes("auth/callback") || i.includes("admin/impersonate") || i.includes("s?c") && i.includes("&t=")
}

function W0(i, n, e, t) {
    return () => {
        e.initializeTheme();
        let o = [i.load(), n.init()];
        return H0() ? Promise.all(o) : Promise.all([...o, t.initLookups(), t.initAmcLookups()])
    }
}
var Eh = (() => {
    class i {
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275mod = Ie({
                type: i,
                bootstrap: [_h]
            })
        }
        static {
            this.\u0275inj = Se({
                providers: [sc(rc()), wu({
                    prefix: "/assets/i18n/",
                    suffix: ".json"
                }), sn(() => W0(p(xc), p(Tc), p(Ye), p(rd))()), Pn, dt, li, [{
                    provide: jl,
                    useClass: Ch,
                    multi: !0
                }], {
                    provide: ki,
                    useClass: Ml
                }, ee, In, be, yh, bo, {
                    provide: vn,
                    useClass: Ih
                }, {
                    provide: "SocialAuthServiceConfig",
                    useValue: {
                        autoLogin: !0,
                        providers: [{
                            id: mi.PROVIDER_ID,
                            provider: new mi("227637855601-4eo5ur85hsse36feqq5kpmcbovhp2ds9.apps.googleusercontent.com", {
                                prompt: "none"
                            })
                        }],
                        onError: e => {
                            console.error(e)
                        }
                    }
                }],
                imports: [fn, oh, Vt, Fl, Iu, An, bh, Wl, Hl, ac.forRoot(), Br.register("ngsw-worker.js", {
                    enabled: Ne.production,
                    registrationStrategy: "registerImmediately"
                }), Jl.forRoot(), Hp, eh.forRoot(), cc.forRoot({
                    timeOut: 5e3,
                    positionClass: "toast-top-right",
                    preventDuplicates: !1,
                    maxOpened: 10,
                    autoDismiss: !0,
                    closeButton: !0
                }), ec.forRoot(), Br.register("ngsw-worker.js", {
                    enabled: Ne.production,
                    registrationStrategy: "registerWhenStable:30000"
                }), Wd]
            })
        }
    }
    return i
})();
var q0 = () => Ud(),
    Dh = (i, n) => typeof window > "u" ? Promise.resolve() : q0().then(() => zd([
        ["pwa-camera-modal", [
            [1, "pwa-camera-modal", {
                facingMode: [1, "facing-mode"],
                hidePicker: [4, "hide-picker"],
                present: [64],
                dismiss: [64]
            }]
        ]],
        ["pwa-action-sheet", [
            [1, "pwa-action-sheet", {
                header: [1],
                cancelable: [4],
                options: [16],
                open: [32]
            }]
        ]],
        ["pwa-toast", [
            [1, "pwa-toast", {
                message: [1],
                duration: [2],
                closing: [32]
            }]
        ]],
        ["pwa-camera", [
            [1, "pwa-camera", {
                facingMode: [1, "facing-mode"],
                handlePhoto: [16],
                hidePicker: [4, "hide-picker"],
                handleNoDeviceError: [16],
                noDevicesText: [1, "no-devices-text"],
                noDevicesButtonText: [1, "no-devices-button-text"],
                photo: [32],
                photoSrc: [32],
                showShutterOverlay: [32],
                flashIndex: [32],
                hasCamera: [32],
                rotation: [32],
                deviceError: [32]
            }]
        ]],
        ["pwa-camera-modal-instance", [
            [1, "pwa-camera-modal-instance", {
                    facingMode: [1, "facing-mode"],
                    hidePicker: [4, "hide-picker"],
                    noDevicesText: [1, "no-devices-text"],
                    noDevicesButtonText: [1, "no-devices-button-text"]
                },
                [
                    [16, "keyup", "handleBackdropKeyUp"]
                ]
            ]
        ]]
    ], n));
window.process = {
    env: {}
};
Dh(window);
Ne.production && void 0;

function K0() {
    return re(this, null, function*() {
        if (Qe.isNativePlatform()) try {
            let {
                keys: i
            } = yield nr.keys();
            for (let n of i) {
                if (localStorage.getItem(n) !== null) continue;
                let {
                    value: e
                } = yield nr.get({
                    key: n
                });
                e !== null && localStorage.setItem(n, e)
            }
        } catch (i) {}
    })
}
K0().finally(() => {
    Ll().bootstrapModule(Eh, {
        applicationProviders: [xl()]
    }).catch(i => console.error(i))
});