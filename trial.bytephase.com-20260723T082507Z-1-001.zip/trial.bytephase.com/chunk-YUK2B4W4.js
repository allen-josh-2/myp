import {
    b as n,
    i as F
} from "./chunk-62N2W5YM.js";
var M = i => document.querySelector(`${i}.ion-cloned-element`),
    X = i => i.shadowRoot || i,
    G = i => {
        let c = i.tagName === "ION-TABS" ? i : i.querySelector("ion-tabs"),
            b = "ion-content ion-header:not(.header-collapse-condense-inactive) ion-title.title-large";
        if (c != null) {
            let r = c.querySelector("ion-tab:not(.tab-hidden), .ion-page:not(.ion-page-hidden)");
            return r != null ? r.querySelector(b) : null
        }
        return i.querySelector(b)
    },
    H = (i, c) => {
        let b = i.tagName === "ION-TABS" ? i : i.querySelector("ion-tabs"),
            r = [];
        if (b != null) {
            let t = b.querySelector("ion-tab:not(.tab-hidden), .ion-page:not(.ion-page-hidden)");
            t != null && (r = t.querySelectorAll("ion-buttons"))
        } else r = i.querySelectorAll("ion-buttons");
        for (let t of r) {
            let E = t.closest("ion-header"),
                C = E && !E.classList.contains("header-collapse-condense-inactive"),
                z = t.querySelector("ion-back-button"),
                l = t.classList.contains("buttons-collapse");
            if (z !== null && (t.slot === "start" || t.slot === "") && (l && C && c || !l)) return z
        }
        return null
    },
    J = (i, c, b, r, t, E, C, z, l) => {
        var w, S;
        let A = c ? `calc(100% - ${t.right+4}px)` : t.left - 4 + "px",
            x = c ? "right" : "left",
            k = c ? "left" : "right",
            W = c ? "right" : "left",
            B = 1,
            L = 1,
            u = `scale(${L})`,
            T = "scale(1)";
        if (E && C) {
            let v = ((w = E.textContent) === null || w === void 0 ? void 0 : w.trim()) === ((S = z.textContent) === null || S === void 0 ? void 0 : S.trim());
            B = l.width / C.width, L = (l.height - Q) / C.height, u = v ? `scale(${B}, ${L})` : `scale(${L})`
        }
        let O = X(r).querySelector("ion-icon").getBoundingClientRect(),
            R = c ? O.width / 2 - (O.right - t.right) + "px" : t.left - O.width / 2 + "px",
            I = c ? `-${window.innerWidth-t.right}px` : `${t.left}px`,
            e = `${l.top}px`,
            y = `${t.top}px`,
            f = b ? [{
                offset: 0,
                transform: `translate3d(${I}, ${y}, 0)`
            }, {
                offset: 1,
                transform: `translate3d(${R}, ${e}, 0)`
            }] : [{
                offset: 0,
                transform: `translate3d(${R}, ${e}, 0)`
            }, {
                offset: 1,
                transform: `translate3d(${I}, ${y}, 0)`
            }],
            g = b ? [{
                offset: 0,
                opacity: 1,
                transform: T
            }, {
                offset: 1,
                opacity: 0,
                transform: u
            }] : [{
                offset: 0,
                opacity: 0,
                transform: u
            }, {
                offset: 1,
                opacity: 1,
                transform: T
            }],
            a = b ? [{
                offset: 0,
                opacity: 1,
                transform: "scale(1)"
            }, {
                offset: .2,
                opacity: 0,
                transform: "scale(0.6)"
            }, {
                offset: 1,
                opacity: 0,
                transform: "scale(0.6)"
            }] : [{
                offset: 0,
                opacity: 0,
                transform: "scale(0.6)"
            }, {
                offset: .6,
                opacity: 0,
                transform: "scale(0.6)"
            }, {
                offset: 1,
                opacity: 1,
                transform: "scale(1)"
            }],
            s = n(),
            m = n(),
            d = n(),
            o = M("ion-back-button"),
            p = X(o).querySelector(".button-text"),
            q = X(o).querySelector("ion-icon");
        o.text = r.text, o.mode = r.mode, o.icon = r.icon, o.color = r.color, o.disabled = r.disabled, o.style.setProperty("display", "block"), o.style.setProperty("position", "fixed"), m.addElement(q), s.addElement(p), d.addElement(o), d.beforeStyles({
            position: "absolute",
            top: "0px",
            [W]: "0px"
        }).beforeAddWrite(() => {
            r.style.setProperty("display", "none"), o.style.setProperty(x, A)
        }).afterAddWrite(() => {
            r.style.setProperty("display", ""), o.style.setProperty("display", "none"), o.style.removeProperty(x)
        }).keyframes(f), s.beforeStyles({
            "transform-origin": `${x} top`
        }).keyframes(g), m.beforeStyles({
            "transform-origin": `${k} center`
        }).keyframes(a), i.addAnimation([s, m, d])
    },
    K = (i, c, b, r, t, E, C, z, l) => {
        var w, S;
        let A = c ? "right" : "left",
            x = c ? `calc(100% - ${t.right}px)` : `${t.left}px`,
            k = `${t.top}px`,
            W = c ? `-${window.innerWidth-C.right-8}px` : `${C.x+8}px`,
            B = .5,
            L = "scale(1)",
            u = `scale(${B})`;
        if (z && l) {
            W = c ? `-${window.innerWidth-l.right-8}px` : l.x - 8 + "px";
            let e = ((w = z.textContent) === null || w === void 0 ? void 0 : w.trim()) === ((S = r.textContent) === null || S === void 0 ? void 0 : S.trim());
            B = l.height / (E.height - Q), u = e ? `scale(${l.width/E.width}, ${B})` : `scale(${B})`
        }
        let T = C.top + C.height / 2 - t.height * B / 2 + "px",
            O = b ? [{
                offset: 0,
                opacity: 0,
                transform: `translate3d(${W}, ${T}, 0) ${u}`
            }, {
                offset: .1,
                opacity: 0
            }, {
                offset: 1,
                opacity: 1,
                transform: `translate3d(0px, ${k}, 0) ${L}`
            }] : [{
                offset: 0,
                opacity: .99,
                transform: `translate3d(0px, ${k}, 0) ${L}`
            }, {
                offset: .6,
                opacity: 0
            }, {
                offset: 1,
                opacity: 0,
                transform: `translate3d(${W}, ${T}, 0) ${u}`
            }],
            R = M("ion-title"),
            I = n();
        R.innerText = r.innerText, R.size = r.size, R.color = r.color, I.addElement(R), I.beforeStyles({
            "transform-origin": `${A} top`,
            height: `${t.height}px`,
            display: "",
            position: "relative",
            [A]: x
        }).beforeAddWrite(() => {
            r.style.setProperty("opacity", "0")
        }).afterAddWrite(() => {
            r.style.setProperty("opacity", ""), R.style.setProperty("display", "none")
        }).keyframes(O), i.addAnimation(I)
    },
    Z = (i, c) => {
        var b;
        try {
            let r = "cubic-bezier(0.32,0.72,0,1)",
                t = "opacity",
                E = "transform",
                l = i.ownerDocument.dir === "rtl",
                w = l ? "-99.5%" : "99.5%",
                S = l ? "33%" : "-33%",
                A = c.enteringEl,
                x = c.leavingEl,
                k = c.direction === "back",
                W = A.querySelector(":scope > ion-content"),
                B = A.querySelectorAll(":scope > ion-header > *:not(ion-toolbar), :scope > ion-footer > *"),
                L = A.querySelectorAll(":scope > ion-header > ion-toolbar"),
                u = n(),
                T = n();
            if (u.addElement(A).duration(((b = c.duration) !== null && b !== void 0 ? b : 0) || 540).easing(c.easing || r).fill("both").beforeRemoveClass("ion-page-invisible"), x && i != null) {
                let e = n();
                e.addElement(i), u.addAnimation(e)
            }
            if (W || L.length !== 0 || B.length !== 0 ? (T.addElement(W), T.addElement(B)) : T.addElement(A.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs")), u.addAnimation(T), k ? T.beforeClearStyles([t]).fromTo("transform", `translateX(${S})`, "translateX(0%)").fromTo(t, .8, 1) : T.beforeClearStyles([t]).fromTo("transform", `translateX(${w})`, "translateX(0%)"), W) {
                let e = X(W).querySelector(".transition-effect");
                if (e) {
                    let y = e.querySelector(".transition-cover"),
                        f = e.querySelector(".transition-shadow"),
                        g = n(),
                        a = n(),
                        s = n();
                    g.addElement(e).beforeStyles({
                        opacity: "1",
                        display: "block"
                    }).afterStyles({
                        opacity: "",
                        display: ""
                    }), a.addElement(y).beforeClearStyles([t]).fromTo(t, 0, .1), s.addElement(f).beforeClearStyles([t]).fromTo(t, .03, .7), g.addAnimation([a, s]), T.addAnimation([g])
                }
            }
            let O = A.querySelector("ion-header.header-collapse-condense"),
                {
                    forward: R,
                    backward: I
                } = ((e, y, f, g, a) => {
                    let s = H(g, f),
                        m = G(a),
                        d = G(g),
                        o = H(a, f),
                        p = s !== null && m !== null && !f,
                        q = d !== null && o !== null && f;
                    if (p) {
                        let v = m.getBoundingClientRect(),
                            $ = s.getBoundingClientRect(),
                            h = X(s).querySelector(".button-text"),
                            P = h ? .getBoundingClientRect(),
                            N = X(m).querySelector(".toolbar-title").getBoundingClientRect();
                        K(e, y, f, m, v, N, $, h, P), J(e, y, f, s, $, h, P, m, N)
                    } else if (q) {
                        let v = d.getBoundingClientRect(),
                            $ = o.getBoundingClientRect(),
                            h = X(o).querySelector(".button-text"),
                            P = h ? .getBoundingClientRect(),
                            N = X(d).querySelector(".toolbar-title").getBoundingClientRect();
                        K(e, y, f, d, v, N, $, h, P), J(e, y, f, o, $, h, P, d, N)
                    }
                    return {
                        forward: p,
                        backward: q
                    }
                })(u, l, k, A, x);
            if (L.forEach(e => {
                    let y = n();
                    y.addElement(e), u.addAnimation(y);
                    let f = n();
                    f.addElement(e.querySelector("ion-title"));
                    let g = n(),
                        a = Array.from(e.querySelectorAll("ion-buttons,[menuToggle]")),
                        s = e.closest("ion-header"),
                        m = s ? .classList.contains("header-collapse-condense-inactive"),
                        d;
                    d = a.filter(k ? $ => {
                        let h = $.classList.contains("buttons-collapse");
                        return h && !m || !h
                    } : $ => !$.classList.contains("buttons-collapse")), g.addElement(d);
                    let o = n();
                    o.addElement(e.querySelectorAll(":scope > *:not(ion-title):not(ion-buttons):not([menuToggle])"));
                    let p = n();
                    p.addElement(X(e).querySelector(".toolbar-background"));
                    let q = n(),
                        v = e.querySelector("ion-back-button");
                    if (v && q.addElement(v), y.addAnimation([f, g, o, p, q]), g.fromTo(t, .01, 1), o.fromTo(t, .01, 1), k) m || f.fromTo("transform", `translateX(${S})`, "translateX(0%)").fromTo(t, .01, 1), o.fromTo("transform", `translateX(${S})`, "translateX(0%)"), q.fromTo(t, .01, 1);
                    else if (O || f.fromTo("transform", `translateX(${w})`, "translateX(0%)").fromTo(t, .01, 1), o.fromTo("transform", `translateX(${w})`, "translateX(0%)"), p.beforeClearStyles([t, "transform"]), s ? .translucent ? p.fromTo("transform", l ? "translateX(-100%)" : "translateX(100%)", "translateX(0px)") : p.fromTo(t, .01, "var(--opacity)"), R || q.fromTo(t, .01, 1), v && !R) {
                        let $ = n();
                        $.addElement(X(v).querySelector(".button-text")).fromTo("transform", l ? "translateX(-100px)" : "translateX(100px)", "translateX(0px)"), y.addAnimation($)
                    }
                }), x) {
                let e = n(),
                    y = x.querySelector(":scope > ion-content"),
                    f = x.querySelectorAll(":scope > ion-header > ion-toolbar"),
                    g = x.querySelectorAll(":scope > ion-header > *:not(ion-toolbar), :scope > ion-footer > *");
                if (y || f.length !== 0 || g.length !== 0 ? (e.addElement(y), e.addElement(g)) : e.addElement(x.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs")), u.addAnimation(e), k) {
                    e.beforeClearStyles([t]).fromTo("transform", "translateX(0%)", l ? "translateX(-100%)" : "translateX(100%)");
                    let a = F(x);
                    u.afterAddWrite(() => {
                        u.getDirection() === "normal" && a.style.setProperty("display", "none")
                    })
                } else e.fromTo("transform", "translateX(0%)", `translateX(${S})`).fromTo(t, 1, .8);
                if (y) {
                    let a = X(y).querySelector(".transition-effect");
                    if (a) {
                        let s = a.querySelector(".transition-cover"),
                            m = a.querySelector(".transition-shadow"),
                            d = n(),
                            o = n(),
                            p = n();
                        d.addElement(a).beforeStyles({
                            opacity: "1",
                            display: "block"
                        }).afterStyles({
                            opacity: "",
                            display: ""
                        }), o.addElement(s).beforeClearStyles([t]).fromTo(t, .1, 0), p.addElement(m).beforeClearStyles([t]).fromTo(t, .7, .03), d.addAnimation([o, p]), e.addAnimation([d])
                    }
                }
                f.forEach(a => {
                    let s = n();
                    s.addElement(a);
                    let m = n();
                    m.addElement(a.querySelector("ion-title"));
                    let d = n(),
                        o = a.querySelectorAll("ion-buttons,[menuToggle]"),
                        p = a.closest("ion-header"),
                        q = p ? .classList.contains("header-collapse-condense-inactive"),
                        v = Array.from(o).filter(D => {
                            let U = D.classList.contains("buttons-collapse");
                            return U && !q || !U
                        });
                    d.addElement(v);
                    let $ = n(),
                        h = a.querySelectorAll(":scope > *:not(ion-title):not(ion-buttons):not([menuToggle])");
                    h.length > 0 && $.addElement(h);
                    let P = n();
                    P.addElement(X(a).querySelector(".toolbar-background"));
                    let N = n(),
                        j = a.querySelector("ion-back-button");
                    if (j && N.addElement(j), s.addAnimation([m, d, $, N, P]), u.addAnimation(s), N.fromTo(t, .99, 0), d.fromTo(t, .99, 0), $.fromTo(t, .99, 0), k) {
                        if (q || m.fromTo("transform", "translateX(0%)", l ? "translateX(-100%)" : "translateX(100%)").fromTo(t, .99, 0), $.fromTo("transform", "translateX(0%)", l ? "translateX(-100%)" : "translateX(100%)"), P.beforeClearStyles([t, "transform"]), p ? .translucent ? P.fromTo("transform", "translateX(0px)", l ? "translateX(-100%)" : "translateX(100%)") : P.fromTo(t, "var(--opacity)", 0), j && !I) {
                            let D = n();
                            D.addElement(X(j).querySelector(".button-text")).fromTo("transform", "translateX(0%)", `translateX(${(l?-124:124)+"px"})`), s.addAnimation(D)
                        }
                    } else q || m.fromTo("transform", "translateX(0%)", `translateX(${S})`).fromTo(t, .99, 0).afterClearStyles([E, t]), $.fromTo("transform", "translateX(0%)", `translateX(${S})`).afterClearStyles([E, t]), N.afterClearStyles([t]), m.afterClearStyles([t]), d.afterClearStyles([t])
                })
            }
            return u
        } catch (r) {
            throw r
        }
    },
    Q = 10;
export {
    X as a, Z as b
};