import {
    a as q,
    d as Me,
    i as se
} from "./chunk-FBFWB55K.js";
var Rt = Me({
    "./ion-accordion_2.entry.js": () =>
        import ("./chunk-RYAX2KS5.js"),
    "./ion-action-sheet.entry.js": () =>
        import ("./chunk-ACLPGF6P.js"),
    "./ion-alert.entry.js": () =>
        import ("./chunk-HKZETDZF.js"),
    "./ion-app_8.entry.js": () =>
        import ("./chunk-RV6HYCJY.js"),
    "./ion-avatar_3.entry.js": () =>
        import ("./chunk-WHSKAVXQ.js"),
    "./ion-back-button.entry.js": () =>
        import ("./chunk-IY77HVD7.js"),
    "./ion-backdrop.entry.js": () =>
        import ("./chunk-UIAEUGS3.js"),
    "./ion-breadcrumb_2.entry.js": () =>
        import ("./chunk-CXARHO6E.js"),
    "./ion-button_2.entry.js": () =>
        import ("./chunk-MV25T2WE.js"),
    "./ion-card_5.entry.js": () =>
        import ("./chunk-ASPD24VM.js"),
    "./ion-checkbox.entry.js": () =>
        import ("./chunk-54QDZ2E3.js"),
    "./ion-chip.entry.js": () =>
        import ("./chunk-OUN76B4S.js"),
    "./ion-col_3.entry.js": () =>
        import ("./chunk-WO26JXTY.js"),
    "./ion-datetime-button.entry.js": () =>
        import ("./chunk-3H55G4CD.js"),
    "./ion-datetime_3.entry.js": () =>
        import ("./chunk-7KLKLHWA.js"),
    "./ion-fab_3.entry.js": () =>
        import ("./chunk-AR62KTX4.js"),
    "./ion-img.entry.js": () =>
        import ("./chunk-WPBB4YBS.js"),
    "./ion-infinite-scroll_2.entry.js": () =>
        import ("./chunk-7LCMLCUY.js"),
    "./ion-input-otp.entry.js": () =>
        import ("./chunk-HRBKW67Z.js"),
    "./ion-input-password-toggle.entry.js": () =>
        import ("./chunk-IFPQ7WZB.js"),
    "./ion-input.entry.js": () =>
        import ("./chunk-5JX5RBTK.js"),
    "./ion-item-option_3.entry.js": () =>
        import ("./chunk-KEO6VSLP.js"),
    "./ion-item_8.entry.js": () =>
        import ("./chunk-RXAJQHYU.js"),
    "./ion-loading.entry.js": () =>
        import ("./chunk-L5EOYHQD.js"),
    "./ion-menu_3.entry.js": () =>
        import ("./chunk-JTV6J7D3.js"),
    "./ion-modal.entry.js": () =>
        import ("./chunk-VA5WCRVS.js"),
    "./ion-nav_2.entry.js": () =>
        import ("./chunk-OAVWUWYJ.js"),
    "./ion-picker-column-option.entry.js": () =>
        import ("./chunk-TLZGV4D2.js"),
    "./ion-picker-column.entry.js": () =>
        import ("./chunk-MJ2DOI67.js"),
    "./ion-picker.entry.js": () =>
        import ("./chunk-XIXUQLPY.js"),
    "./ion-popover.entry.js": () =>
        import ("./chunk-P4EWAKQO.js"),
    "./ion-progress-bar.entry.js": () =>
        import ("./chunk-KQJD54FO.js"),
    "./ion-radio_2.entry.js": () =>
        import ("./chunk-AYJB7ZJS.js"),
    "./ion-range.entry.js": () =>
        import ("./chunk-PDWM2P6A.js"),
    "./ion-refresher_2.entry.js": () =>
        import ("./chunk-DMQDFZ5X.js"),
    "./ion-reorder_2.entry.js": () =>
        import ("./chunk-GU6ZXNPU.js"),
    "./ion-ripple-effect.entry.js": () =>
        import ("./chunk-V53H6DVR.js"),
    "./ion-route_4.entry.js": () =>
        import ("./chunk-BFEBN35O.js"),
    "./ion-searchbar.entry.js": () =>
        import ("./chunk-YJLSKACD.js"),
    "./ion-segment-content.entry.js": () =>
        import ("./chunk-2BAM4ERB.js"),
    "./ion-segment-view.entry.js": () =>
        import ("./chunk-UIVEVLP7.js"),
    "./ion-segment_2.entry.js": () =>
        import ("./chunk-Z7GL2537.js"),
    "./ion-select-modal.entry.js": () =>
        import ("./chunk-DZ4DYVQE.js"),
    "./ion-select_3.entry.js": () =>
        import ("./chunk-3CBTL5RX.js"),
    "./ion-spinner.entry.js": () =>
        import ("./chunk-MORRDVOU.js"),
    "./ion-split-pane.entry.js": () =>
        import ("./chunk-VZP7STKI.js"),
    "./ion-tab-bar_2.entry.js": () =>
        import ("./chunk-AYWKRBU2.js"),
    "./ion-tab_2.entry.js": () =>
        import ("./chunk-EF2FZ6EJ.js"),
    "./ion-text.entry.js": () =>
        import ("./chunk-GFMLMASE.js"),
    "./ion-textarea.entry.js": () =>
        import ("./chunk-MXQBDCVM.js"),
    "./ion-toast.entry.js": () =>
        import ("./chunk-ZZ6FAU2Y.js"),
    "./ion-toggle.entry.js": () =>
        import ("./chunk-STKW3OED.js")
});
var wt = "ionic",
    B = {
        hotModuleReplacement: !1,
        hydratedSelectorName: "hydrated",
        lazyLoad: !0,
        propChangeCallback: !0,
        shadowDom: !0,
        slotRelocation: !0,
        state: !0,
        updatable: !0
    },
    be = class {
        constructor() {
            this.m = new Map
        }
        reset(t) {
            this.m = new Map(Object.entries(t))
        }
        get(t, s) {
            let n = this.m.get(t);
            return n !== void 0 ? n : s
        }
        getBoolean(t, s = !1) {
            let n = this.m.get(t);
            return n === void 0 ? s : typeof n == "string" ? n === "true" : !!n
        }
        getNumber(t, s) {
            let n = parseFloat(this.m.get(t));
            return isNaN(n) ? s !== void 0 ? s : NaN : n
        }
        set(t, s) {
            this.m.set(t, s)
        }
    },
    it = new be,
    Qs = e => {
        try {
            let t = e.sessionStorage.getItem(lt);
            return t !== null ? JSON.parse(t) : {}
        } catch (t) {
            return {}
        }
    },
    Vs = (e, t) => {
        try {
            e.sessionStorage.setItem(lt, JSON.stringify(t))
        } catch (s) {
            return
        }
    },
    en = e => {
        let t = {};
        return e.location.search.slice(1).split("&").map(s => s.split("=")).map(([s, n]) => {
            try {
                return [decodeURIComponent(s), decodeURIComponent(n)]
            } catch (r) {
                return ["", ""]
            }
        }).filter(([s]) => Dt(s, We)).map(([s, n]) => [s.slice(We.length), n]).forEach(([s, n]) => {
            t[s] = n
        }), t
    },
    Dt = (e, t) => e.substr(0, t.length) === t,
    We = "ionic:",
    lt = "ionic-persist-config",
    P = (function(e) {
        return e.OFF = "OFF", e.ERROR = "ERROR", e.WARN = "WARN", e
    })(P || {}),
    tn = (e, ...t) => {
        let s = it.get("logLevel", P.WARN);
        if ([P.WARN].includes(s)) return console.warn(`[Ionic Warning]: ${e}`, ...t)
    },
    sn = (e, ...t) => {
        let s = it.get("logLevel", P.ERROR);
        if ([P.ERROR, P.WARN].includes(s)) return console.error(`[Ionic Error]: ${e}`, ...t)
    },
    nn = (e, ...t) => console.error(`<${e.tagName.toLowerCase()}> must be used inside ${t.join(" or ")}.`),
    rn = {
        isBrowser: !0
    },
    zt = "http://www.w3.org/2000/svg",
    Bt = "http://www.w3.org/1999/xhtml",
    ot = (e => (e.Undefined = "undefined", e.Null = "null", e.String = "string", e.Number = "number", e.SpecialNumber = "number", e.Boolean = "boolean", e.BigInt = "bigint", e))(ot || {}),
    at = (e => (e.Array = "array", e.Date = "date", e.Map = "map", e.Object = "object", e.RegularExpression = "regexp", e.Set = "set", e.Channel = "channel", e.Symbol = "symbol", e))(at || {}),
    ye = "type",
    Se = "value",
    xe = "serialized:",
    Ut = (e, t) => {
        var s;
        let n = t.$cmpMeta$;
        Object.entries((s = n.$members$) != null ? s : {}).map(([i, [a]]) => {
            if (a & 31 || a & 32) {
                let l = e[i],
                    $ = Ft(Object.getPrototypeOf(e), i) || Object.getOwnPropertyDescriptor(e, i);
                $ && Object.defineProperty(e, i, {
                    get() {
                        return $.get.call(this)
                    },
                    set(o) {
                        $.set.call(this, o)
                    },
                    configurable: !0,
                    enumerable: !0
                }), e[i] = t.$instanceValues$.has(i) ? t.$instanceValues$.get(i) : l
            }
        })
    };

function Ft(e, t) {
    for (; e;) {
        let s = Object.getOwnPropertyDescriptor(e, t);
        if (s ? .get) return s;
        e = Object.getPrototypeOf(e)
    }
}
var I = e => {
        if (e.__stencil__getHostRef) return e.__stencil__getHostRef()
    },
    ln = (e, t) => {
        t && (e.__stencil__getHostRef = () => t, t.$lazyInstance$ = e, t.$cmpMeta$.$flags$ & 512 && B.state && Ut(e, t))
    },
    Mt = (e, t) => {
        let s = {
            $flags$: 0,
            $hostElement$: e,
            $cmpMeta$: t,
            $instanceValues$: new Map,
            $serializerValues$: new Map
        };
        s.$onInstancePromise$ = new Promise(r => s.$onInstanceResolve$ = r), s.$onReadyPromise$ = new Promise(r => s.$onReadyResolve$ = r), e["s-p"] = [], e["s-rc"] = [], s.$fetchedCbList$ = [];
        let n = s;
        return e.__stencil__getHostRef = () => n, n
    },
    qe = (e, t) => t in e,
    F = (e, t) => (0, console.error)(e, t),
    He = new Map,
    Wt = (e, t, s) => {
        let n = e.$tagName$.replace(/-/g, "_"),
            r = e.$lazyBundleId$;
        if (!r) return;
        let i = He.get(r);
        if (i) return i[n];
        return Rt(`./${r}.entry.js`).then(a => (He.set(r, a), a[n]), a => {
            F(a, t.$hostElement$)
        })
    },
    ie = new Map,
    ct = [],
    qt = "r",
    Ht = "o",
    me = "s",
    Pt = "t",
    Gt = "c",
    K = "s-id",
    le = "sty-id",
    Pe = "c-id",
    Yt = "{visibility:hidden}.hydrated{visibility:inherit}",
    $t = "slot-fb{display:contents}slot-fb[hidden]{display:none}",
    Ge = "http://www.w3.org/1999/xlink",
    p = typeof window < "u" ? window : {},
    on = p.HTMLElement || class {},
    v = {
        $flags$: 0,
        $resourcesUrl$: "",
        jmp: e => e(),
        raf: e => requestAnimationFrame(e),
        ael: (e, t, s, n) => e.addEventListener(t, s, n),
        rel: (e, t, s, n) => e.removeEventListener(t, s, n),
        ce: (e, t) => new CustomEvent(e, t)
    },
    Xt = B.shadowDom,
    Jt = (() => {
        var e;
        let t = !1;
        try {
            (e = p.document) == null || e.addEventListener("e", null, Object.defineProperty({}, "passive", {
                get() {
                    t = !0
                }
            }))
        } catch (s) {}
        return t
    })(),
    Kt = e => Promise.resolve(e),
    we = (() => {
        try {
            return p.document.adoptedStyleSheets ? (new CSSStyleSheet, typeof new CSSStyleSheet().replaceSync == "function") : !1
        } catch (e) {}
        return !1
    })(),
    Te = we ? !!p.document && Object.getOwnPropertyDescriptor(p.document.adoptedStyleSheets, "length").writable : !1,
    Ae = !1,
    Le = [],
    ft = [],
    dt = (e, t) => s => {
        e.push(s), Ae || (Ae = !0, t && v.$flags$ & 4 ? De(Ee) : v.raf(Ee))
    },
    Ye = e => {
        for (let t = 0; t < e.length; t++) try {
            e[t](performance.now())
        } catch (s) {
            F(s)
        }
        e.length = 0
    },
    Ee = () => {
        Ye(Le), Ye(ft), (Ae = Le.length > 0) && v.raf(Ee)
    },
    De = e => Kt().then(e),
    an = dt(Le, !1),
    ut = dt(ft, !0),
    cn = e => {
        let t = new URL(e, v.$resourcesUrl$);
        return t.origin !== p.location.origin ? t.href : t.pathname
    };
var J;

function Zt(e) {
    var t;
    let s = {
        mode: "open"
    };
    s.delegatesFocus = !!(e.$flags$ & 16);
    let n = this.attachShadow(s);
    J === void 0 && (J = (t = void 0) != null ? t : null), J && (Te ? n.adoptedStyleSheets.push(J) : n.adoptedStyleSheets = [...n.adoptedStyleSheets, J])
}
var fe = e => {
        let t = O(e, "childNodes");
        e.tagName && e.tagName.includes("-") && e["s-cr"] && e.tagName !== "SLOT-FB" && ee(t, e.tagName).forEach(n => {
            n.nodeType === 1 && n.tagName === "SLOT-FB" && (ze(n, Y(n), !1).length ? n.hidden = !0 : n.hidden = !1)
        });
        let s = 0;
        for (s = 0; s < t.length; s++) {
            let n = t[s];
            n.nodeType === 1 && O(n, "childNodes").length && fe(n)
        }
    },
    Z = e => {
        let t = [];
        for (let s = 0; s < e.length; s++) {
            let n = e[s]["s-nr"] || void 0;
            n && n.isConnected && t.push(n)
        }
        return t
    };

function ee(e, t, s) {
    let n = 0,
        r = [],
        i;
    for (; n < e.length; n++) {
        if (i = e[n], i["s-sr"] && (!t || i["s-hn"] === t) && (s === void 0 || Y(i) === s) && (r.push(i), typeof s < "u")) return r;
        r = [...r, ...ee(i.childNodes, t, s)]
    }
    return r
}
var ze = (e, t, s = !0) => {
        let n = [];
        (s && e["s-sr"] || !e["s-sr"]) && n.push(e);
        let r = e;
        for (; r = r.nextSibling;) Y(r) === t && (s || !r["s-sr"]) && n.push(r);
        return n
    },
    Xe = (e, t) => e.nodeType === 1 ? e.getAttribute("slot") === null && t === "" || e.getAttribute("slot") === t : e["s-sn"] === t ? !0 : t === "",
    de = (e, t, s, n) => {
        if (e["s-ol"] && e["s-ol"].isConnected) return;
        let r = document.createTextNode("");
        if (r["s-nr"] = e, !t["s-cr"] || !t["s-cr"].parentNode) return;
        let i = t["s-cr"].parentNode,
            a = s ? O(i, "prepend") : O(i, "appendChild");
        if (typeof n < "u") {
            r["s-oo"] = n;
            let l = O(i, "childNodes"),
                $ = [r];
            l.forEach(o => {
                o["s-nr"] && $.push(o)
            }), $.sort((o, c) => !o["s-oo"] || o["s-oo"] < (c["s-oo"] || 0) ? -1 : !c["s-oo"] || c["s-oo"] < o["s-oo"] ? 1 : 0), $.forEach(o => a.call(i, o))
        } else a.call(i, r);
        e["s-ol"] = r, e["s-sh"] = t["s-hn"]
    },
    Y = e => typeof e["s-sn"] == "string" ? e["s-sn"] : e.nodeType === 1 && e.getAttribute("slot") || void 0;

function ht(e) {
    if (e.assignedElements || e.assignedNodes || !e["s-sr"]) return;
    let t = s => function(n) {
        let r = [],
            i = this["s-sn"];
        n ? .flatten && console.error(`
          Flattening is not supported for Stencil non-shadow slots.
          You can use \`.childNodes\` to nested slot fallback content.
          If you have a particular use case, please open an issue on the Stencil repo.
        `);
        let a = this["s-cr"].parentElement;
        return (a.__childNodes ? a.childNodes : Z(a.childNodes)).forEach($ => {
            i === Y($) && r.push($)
        }), s ? r.filter($ => $.nodeType === 1) : r
    }.bind(e);
    e.assignedElements = t(!0), e.assignedNodes = t(!1)
}

function ue(e) {
    e.dispatchEvent(new CustomEvent("slotchange", {
        bubbles: !1,
        cancelable: !1,
        composed: !1
    }))
}

function Be(e, t) {
    var s;
    if (t = t || ((s = e["s-ol"]) == null ? void 0 : s.parentElement), !t) return {
        slotNode: null,
        slotName: ""
    };
    let n = e["s-sn"] = Y(e) || "",
        r = O(t, "childNodes");
    return {
        slotNode: ee(r, t.tagName, n)[0],
        slotName: n
    }
}
var Qt = e => {
        pt(e), Vt(e), ss(e), ts(e), ls(e), ns(e), rs(e), is(e), os(e), as(e), es(e)
    },
    pt = e => {
        if (e.__cloneNode) return;
        let t = e.__cloneNode = e.cloneNode;
        e.cloneNode = function(s) {
            let n = this,
                r = n.shadowRoot && Xt,
                i = t.call(n, r ? s : !1);
            if (!r && s) {
                let a = 0,
                    l, $, o = ["s-id", "s-cr", "s-lr", "s-rc", "s-sc", "s-p", "s-cn", "s-sr", "s-sn", "s-hn", "s-ol", "s-nr", "s-si", "s-rf", "s-scs"],
                    c = this.__childNodes || this.childNodes;
                for (; a < c.length; a++) l = c[a]["s-nr"], $ = o.every(d => !c[a][d]), l && (i.__appendChild ? i.__appendChild(l.cloneNode(!0)) : i.appendChild(l.cloneNode(!0))), $ && i.appendChild(c[a].cloneNode(!0))
            }
            return i
        }
    },
    Vt = e => {
        e.__appendChild || (e.__appendChild = e.appendChild, e.appendChild = function(t) {
            let {
                slotName: s,
                slotNode: n
            } = Be(t, this);
            if (n) {
                de(t, n);
                let r = ze(n, s),
                    i = r[r.length - 1],
                    a = O(i, "parentNode"),
                    l = O(a, "insertBefore")(t, i.nextSibling);
                return ue(n), fe(this), l
            }
            return this.__appendChild(t)
        })
    },
    es = e => {
        e.__removeChild || (e.__removeChild = e.removeChild, e.removeChild = function(t) {
            if (t && typeof t["s-sn"] < "u") {
                let s = this.__childNodes || this.childNodes;
                if (ee(s, this.tagName, t["s-sn"]) && t.isConnected) {
                    t.remove(), fe(this);
                    return
                }
            }
            return this.__removeChild(t)
        })
    },
    ts = e => {
        e.__prepend || (e.__prepend = e.prepend, e.prepend = function(...t) {
            t.forEach(s => {
                typeof s == "string" && (s = this.ownerDocument.createTextNode(s));
                let n = (s["s-sn"] = Y(s)) || "",
                    r = O(this, "childNodes"),
                    i = ee(r, this.tagName, n)[0];
                if (i) {
                    de(s, i, !0);
                    let l = ze(i, n)[0],
                        $ = O(l, "parentNode"),
                        o = O($, "insertBefore")(s, O(l, "nextSibling"));
                    return ue(i), o
                }
                return s.nodeType === 1 && s.getAttribute("slot") && (s.hidden = !0), e.__prepend(s)
            })
        })
    },
    ss = e => {
        e.__append || (e.__append = e.append, e.append = function(...t) {
            t.forEach(s => {
                typeof s == "string" && (s = this.ownerDocument.createTextNode(s)), this.appendChild(s)
            })
        })
    },
    ns = e => {
        if (e.__insertAdjacentHTML) return;
        let t = e.insertAdjacentHTML;
        e.insertAdjacentHTML = function(s, n) {
            if (s !== "afterbegin" && s !== "beforeend") return t.call(this, s, n);
            let r = this.ownerDocument.createElement("_"),
                i;
            if (r.innerHTML = n, s === "afterbegin")
                for (; i = r.firstChild;) this.prepend(i);
            else if (s === "beforeend")
                for (; i = r.firstChild;) this.append(i)
        }
    },
    rs = e => {
        e.insertAdjacentText = function(t, s) {
            this.insertAdjacentHTML(t, s)
        }
    },
    is = e => {
        if (e.__insertBefore) return;
        let t = e;
        t.__insertBefore || (t.__insertBefore = e.insertBefore, e.insertBefore = function(s, n) {
            let {
                slotName: r,
                slotNode: i
            } = Be(s, this), a = this.__childNodes ? this.childNodes : Z(this.childNodes);
            if (i) {
                let $ = !1;
                if (a.forEach(o => {
                        if (o === n || n === null) {
                            if ($ = !0, n === null || r !== n["s-sn"]) {
                                this.appendChild(s);
                                return
                            }
                            if (r === n["s-sn"]) {
                                de(s, i);
                                let c = O(n, "parentNode");
                                O(c, "insertBefore")(s, n), ue(i)
                            }
                            return
                        }
                    }), $) return s
            }
            let l = n ? .__parentNode;
            return l && !this.isSameNode(l) ? this.appendChild(s) : this.__insertBefore(s, n)
        })
    },
    ls = e => {
        if (e.__insertAdjacentElement) return;
        let t = e.insertAdjacentElement;
        e.insertAdjacentElement = function(s, n) {
            return s !== "afterbegin" && s !== "beforeend" ? t.call(this, s, n) : s === "afterbegin" ? (this.prepend(n), n) : (s === "beforeend" && this.append(n), n)
        }
    },
    os = e => {
        w("textContent", e), Object.defineProperty(e, "textContent", {
            get: function() {
                let t = "";
                return (this.__childNodes ? this.childNodes : Z(this.childNodes)).forEach(n => t += n.textContent || ""), t
            },
            set: function(t) {
                (this.__childNodes ? this.childNodes : Z(this.childNodes)).forEach(n => {
                    n["s-ol"] && n["s-ol"].remove(), n.remove()
                }), this.insertAdjacentHTML("beforeend", t)
            }
        })
    },
    as = e => {
        class t extends Array {
            item(n) {
                return this[n]
            }
        }
        w("children", e), Object.defineProperty(e, "children", {
            get() {
                return this.childNodes.filter(s => s.nodeType === 1)
            }
        }), Object.defineProperty(e, "childElementCount", {
            get() {
                return this.children.length
            }
        }), w("firstChild", e), Object.defineProperty(e, "firstChild", {
            get() {
                return this.childNodes[0]
            }
        }), w("lastChild", e), Object.defineProperty(e, "lastChild", {
            get() {
                return this.childNodes[this.childNodes.length - 1]
            }
        }), w("childNodes", e), Object.defineProperty(e, "childNodes", {
            get() {
                let s = new t;
                return s.push(...Z(this.__childNodes)), s
            }
        })
    },
    cs = e => {
        !e || e.__nextSibling !== void 0 || !globalThis.Node || ($s(e), ds(e), gt(e), e.nodeType === Node.ELEMENT_NODE && (fs(e), us(e)))
    },
    $s = e => {
        !e || e.__nextSibling || (w("nextSibling", e), Object.defineProperty(e, "nextSibling", {
            get: function() {
                var t;
                let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.childNodes,
                    n = s ? .indexOf(this);
                return s && n > -1 ? s[n + 1] : this.__nextSibling
            }
        }))
    },
    fs = e => {
        !e || e.__nextElementSibling || (w("nextElementSibling", e), Object.defineProperty(e, "nextElementSibling", {
            get: function() {
                var t;
                let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.children,
                    n = s ? .indexOf(this);
                return s && n > -1 ? s[n + 1] : this.__nextElementSibling
            }
        }))
    },
    ds = e => {
        !e || e.__previousSibling || (w("previousSibling", e), Object.defineProperty(e, "previousSibling", {
            get: function() {
                var t;
                let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.childNodes,
                    n = s ? .indexOf(this);
                return s && n > -1 ? s[n - 1] : this.__previousSibling
            }
        }))
    },
    us = e => {
        !e || e.__previousElementSibling || (w("previousElementSibling", e), Object.defineProperty(e, "previousElementSibling", {
            get: function() {
                var t;
                let s = (t = this["s-ol"]) == null ? void 0 : t.parentNode.children,
                    n = s ? .indexOf(this);
                return s && n > -1 ? s[n - 1] : this.__previousElementSibling
            }
        }))
    },
    gt = e => {
        !e || e.__parentNode || (w("parentNode", e), Object.defineProperty(e, "parentNode", {
            get: function() {
                var t;
                return ((t = this["s-ol"]) == null ? void 0 : t.parentNode) || this.__parentNode
            },
            set: function(t) {
                this.__parentNode = t
            }
        }))
    },
    hs = ["children", "nextElementSibling", "previousElementSibling"],
    ps = ["childNodes", "firstChild", "lastChild", "nextSibling", "previousSibling", "textContent", "parentNode"];

function w(e, t) {
    if (!globalThis.Node || !globalThis.Element) return;
    let s;
    hs.includes(e) ? s = Object.getOwnPropertyDescriptor(Element.prototype, e) : ps.includes(e) && (s = Object.getOwnPropertyDescriptor(Node.prototype, e)), s || (s = Object.getOwnPropertyDescriptor(t, e)), s && Object.defineProperty(t, "__" + e, s)
}

function O(e, t) {
    if ("__" + t in e) {
        let s = e["__" + t];
        return typeof s != "function" ? s : s.bind(e)
    } else return typeof e[t] != "function" ? e[t] : e[t].bind(e)
}
var D = (e, t = "") => () => {},
    gs = (e, t) => () => {};

function vt(e) {
    var t, s, n;
    return (n = (s = (t = e.head) == null ? void 0 : t.querySelector('meta[name="csp-nonce"]')) == null ? void 0 : s.getAttribute("content")) != null ? n : void 0
}
var U = new WeakMap,
    yt = (e, t, s) => {
        let n = ie.get(e);
        we && s ? (n = n || new CSSStyleSheet, typeof n == "string" ? n = t : n.replaceSync(t)) : n = t, ie.set(e, n)
    },
    St = (e, t, s) => {
        var n, r, i;
        let a = he(t, s),
            l = ie.get(a);
        if (!p.document) return a;
        if (e = e.nodeType === 11 ? e : p.document, l)
            if (typeof l == "string") {
                e = e.head || e;
                let $ = U.get(e),
                    o;
                $ || U.set(e, $ = new Set);
                let c = e.querySelector(`[${le}="${a}"]`);
                if (c) c.textContent = l;
                else if (!$.has(a)) {
                    o = p.document.createElement("style"), o.textContent = l;
                    let d = (n = v.$nonce$) != null ? n : vt(p.document);
                    if (d != null && o.setAttribute("nonce", d), !(t.$flags$ & 1))
                        if (e.nodeName === "HEAD") {
                            let f = e.querySelectorAll("link[rel=preconnect]"),
                                h = f.length > 0 ? f[f.length - 1].nextSibling : e.querySelector("style");
                            e.insertBefore(o, h ? .parentNode === e ? h : null)
                        } else if ("host" in e)
                        if (we) {
                            let f = (r = e.defaultView) != null ? r : e.ownerDocument.defaultView,
                                h = new f.CSSStyleSheet;
                            h.replaceSync(l), Te ? e.adoptedStyleSheets.unshift(h) : e.adoptedStyleSheets = [h, ...e.adoptedStyleSheets]
                        } else {
                            let f = e.querySelector("style");
                            f ? f.textContent = l + f.textContent : e.prepend(o)
                        }
                    else e.append(o);
                    t.$flags$ & 1 && e.insertBefore(o, null), t.$flags$ & 4 && (o.textContent += $t), $ && $.add(a)
                }
            } else {
                let $ = U.get(e);
                if ($ || U.set(e, $ = new Set), !$.has(a)) {
                    let o = (i = e.defaultView) != null ? i : e.ownerDocument.defaultView,
                        c;
                    if (l.constructor === o.CSSStyleSheet) c = l;
                    else {
                        c = new o.CSSStyleSheet;
                        for (let d = 0; d < l.cssRules.length; d++) c.insertRule(l.cssRules[d].cssText, d)
                    }
                    if (Te ? e.adoptedStyleSheets.push(c) : e.adoptedStyleSheets = [...e.adoptedStyleSheets, c], $.add(a), "host" in e) {
                        let d = e.querySelector(`[${le}="${a}"]`);
                        d && ut(() => d.remove())
                    }
                }
            }
        return a
    },
    vs = e => {
        let t = e.$cmpMeta$,
            s = e.$hostElement$,
            n = t.$flags$,
            r = D("attachStyles", t.$tagName$),
            i = St(s.shadowRoot ? s.shadowRoot : s.getRootNode(), t, e.$modeName$);
        n & 10 && (s["s-sc"] = i, s.classList.add(i + "-h")), r()
    },
    he = (e, t) => "sc-" + (t && e.$flags$ & 32 ? e.$tagName$ + "-" + t : e.$tagName$),
    ys = e => e.replace(/\/\*!@([^\/]+)\*\/[^\{]+\{/g, "$1{"),
    Ss = () => {
        if (!p.document) return;
        let e = p.document.querySelectorAll(`[${le}]`),
            t = 0;
        for (; t < e.length; t++) yt(e[t].getAttribute(le), ys(e[t].innerHTML), !0)
    },
    _s = e => e != null && e !== void 0,
    Ue = e => (e = typeof e, e === "object" || e === "function"),
    _t = (e, t, ...s) => {
        typeof e == "string" && (e = e);
        let n = null,
            r = null,
            i = null,
            a = !1,
            l = !1,
            $ = [],
            o = d => {
                for (let f = 0; f < d.length; f++) n = d[f], Array.isArray(n) ? o(n) : n != null && typeof n != "boolean" && ((a = typeof e != "function" && !Ue(n)) && (n = String(n)), a && l ? $[$.length - 1].$text$ += n : $.push(a ? G(null, n) : n), l = a)
            };
        if (o(s), t) {
            t.key && (r = t.key), t.name && (i = t.name); {
                let d = t.className || t.class;
                d && (t.class = typeof d != "object" ? d : Object.keys(d).filter(f => d[f]).join(" "))
            }
        }
        if (typeof e == "function") return e(t === null ? {} : t, $, ms);
        let c = G(e, null);
        return c.$attrs$ = t, $.length > 0 && (c.$children$ = $), c.$key$ = r, c.$name$ = i, c
    },
    G = (e, t) => {
        let s = {
            $flags$: 0,
            $tag$: e,
            $text$: t ? ? null,
            $elm$: null,
            $children$: null
        };
        return s.$attrs$ = null, s.$key$ = null, s.$name$ = null, s
    },
    bs = {},
    xs = e => e && e.$tag$ === bs,
    ms = {
        forEach: (e, t) => e.map(Je).forEach(t),
        map: (e, t) => e.map(Je).map(t).map(Ts)
    },
    Je = e => ({
        vattrs: e.$attrs$,
        vchildren: e.$children$,
        vkey: e.$key$,
        vname: e.$name$,
        vtag: e.$tag$,
        vtext: e.$text$
    }),
    Ts = e => {
        if (typeof e.vtag == "function") {
            let s = q({}, e.vattrs);
            return e.vkey && (s.key = e.vkey), e.vname && (s.name = e.vname), _t(e.vtag, s, ...e.vchildren || [])
        }
        let t = G(e.vtag, e.vtext);
        return t.$attrs$ = e.vattrs, t.$children$ = e.vchildren, t.$key$ = e.vkey, t.$name$ = e.vname, t
    },
    As = (e, t, s, n) => {
        var r, i, a, l;
        let $ = D("hydrateClient", t),
            o = e.shadowRoot,
            c = [],
            d = [],
            f = [],
            h = o ? [] : null,
            u = G(t, null);
        u.$elm$ = e;
        let g; {
            let A = n.$cmpMeta$;
            A && A.$flags$ & 10 && e["s-sc"] ? (g = e["s-sc"], e.classList.add(g + "-h")) : e["s-sc"] && delete e["s-sc"]
        }
        p.document && (!v.$orgLocNodes$ || !v.$orgLocNodes$.size) && Ie(p.document.body, v.$orgLocNodes$ = new Map), e[K] = s, e.removeAttribute(K), n.$vnode$ = Oe(u, c, d, h, e, e, s, f);
        let T = 0,
            L = c.length,
            y;
        for (T; T < L; T++) {
            y = c[T];
            let A = y.$hostId$ + "." + y.$nodeId$,
                N = v.$orgLocNodes$.get(A),
                E = y.$elm$;
            if (!o) E["s-hn"] = t.toUpperCase(), y.$tag$ === "slot" && (E["s-cr"] = e["s-cr"]);
            else if ((r = y.$tag$) != null && r.toString().includes("-") && y.$tag$ !== "slot-fb" && !y.$elm$.shadowRoot) {
                let te = I(y.$elm$);
                if (te) {
                    let jt = he(te.$cmpMeta$, y.$elm$.getAttribute("s-mode")),
                        Fe = p.document.querySelector(`style[sty-id="${jt}"]`);
                    Fe && h.unshift(Fe.cloneNode(!0))
                }
            }
            y.$tag$ === "slot" && (y.$name$ = y.$elm$["s-sn"] || y.$elm$.name || null, y.$children$ ? (y.$flags$ |= 2, y.$elm$.childNodes.length || y.$children$.forEach(te => {
                y.$elm$.appendChild(te.$elm$)
            })) : y.$flags$ |= 1), N && N.isConnected && (N.parentElement.shadowRoot && N["s-en"] === "" && N.parentNode.insertBefore(E, N.nextSibling), N.parentNode.removeChild(N), o || (E["s-oo"] = parseInt(y.$nodeId$))), N && !N["s-id"] && v.$orgLocNodes$.delete(A)
        }
        let S = [],
            x = f.length,
            _ = 0,
            m, C, X, b, ve = 0;
        for (_; _ < x; _++)
            if (m = f[_], !(!m || !m.length))
                for (X = m.length, C = 0, C; C < X; C++) {
                    if (b = m[C], S[b.hostId] || (S[b.hostId] = v.$orgLocNodes$.get(b.hostId)), !S[b.hostId]) continue;
                    let A = S[b.hostId];
                    A.shadowRoot && b.node.parentElement !== A && A.insertBefore(b.node, (a = (i = m[C - 1]) == null ? void 0 : i.node) == null ? void 0 : a.nextSibling), (!A.shadowRoot || !o) && (b.slot["s-cr"] || (b.slot["s-cr"] = A["s-cr"], !b.slot["s-cr"] && A.shadowRoot ? b.slot["s-cr"] = A : b.slot["s-cr"] = (A.__childNodes || A.childNodes)[0]), de(b.node, b.slot, !1, b.node["s-oo"] || ve), (l = b.node.parentElement) != null && l.shadowRoot && b.node.getAttribute && b.node.getAttribute("slot") && b.node.removeAttribute("slot"), cs(b.node)), ve = (b.node["s-oo"] || ve) + 1
                }
        if (g && d.length && d.forEach(A => {
                A.$elm$.parentElement.classList.add(g + "-s")
            }), o && !o.childNodes.length) {
            let A = 0,
                N = h.length;
            if (N) {
                for (A; A < N; A++) {
                    let E = h[A];
                    E && o.appendChild(E)
                }
                Array.from(e.childNodes).forEach(E => {
                    typeof E["s-en"] != "string" && typeof E["s-sn"] != "string" && (E.nodeType === 1 && E.slot && E.hidden ? E.removeAttribute("hidden") : E.nodeType === 8 && !E.nodeValue && E.parentNode.removeChild(E))
                })
            }
        }
        n.$hostElement$ = e, $()
    },
    Oe = (e, t, s, n, r, i, a, l = []) => {
        let $, o, c, d, f = r["s-sc"];
        if (i.nodeType === 1) {
            if ($ = i.getAttribute(Pe), $ && (o = $.split("."), o[0] === a || o[0] === "0")) {
                c = Ke({
                    $flags$: 0,
                    $hostId$: o[0],
                    $nodeId$: o[1],
                    $depth$: o[2],
                    $index$: o[3],
                    $tag$: i.tagName.toLowerCase(),
                    $elm$: i,
                    $attrs$: {
                        class: i.className || ""
                    }
                }), t.push(c), i.removeAttribute(Pe), e.$children$ || (e.$children$ = []), f && o[0] === a && (i["s-si"] = f, c.$attrs$.class += " " + f);
                let u = c.$elm$.getAttribute("s-sn");
                typeof u == "string" && (c.$tag$ === "slot-fb" && (Ze(u, o[2], c, i, e, t, s, n, l), f && i.classList.add(f)), c.$elm$["s-sn"] = u, c.$elm$.removeAttribute("s-sn")), c.$index$ !== void 0 && (e.$children$[c.$index$] = c), e = c, n && c.$depth$ === "0" && (n[c.$index$] = c.$elm$)
            }
            if (i.shadowRoot)
                for (d = i.shadowRoot.childNodes.length - 1; d >= 0; d--) Oe(e, t, s, n, r, i.shadowRoot.childNodes[d], a, l);
            let h = i.__childNodes || i.childNodes;
            for (d = h.length - 1; d >= 0; d--) Oe(e, t, s, n, r, h[d], a, l)
        } else if (i.nodeType === 8) {
            if (o = i.nodeValue.split("."), o[1] === a || o[1] === "0") {
                if ($ = o[0], c = Ke({
                        $hostId$: o[1],
                        $nodeId$: o[2],
                        $depth$: o[3],
                        $index$: o[4] || "0",
                        $elm$: i,
                        $attrs$: null,
                        $children$: null,
                        $key$: null,
                        $name$: null,
                        $tag$: null,
                        $text$: null
                    }), $ === Pt) c.$elm$ = Ve(i, 3), c.$elm$ && c.$elm$.nodeType === 3 && (c.$text$ = c.$elm$.textContent, t.push(c), i.remove(), a === c.$hostId$ && (e.$children$ || (e.$children$ = []), e.$children$[c.$index$] = c), n && c.$depth$ === "0" && (n[c.$index$] = c.$elm$));
                else if ($ === Gt) c.$elm$ = Ve(i, 8), c.$elm$ && c.$elm$.nodeType === 8 && (t.push(c), i.remove());
                else if (c.$hostId$ === a)
                    if ($ === me) {
                        let h = i["s-sn"] = o[5] || "";
                        Ze(h, o[2], c, i, e, t, s, n, l)
                    } else $ === qt && (n ? i.remove() : (r["s-cr"] = i, i["s-cn"] = !0))
            }
        } else if (e && e.$tag$ === "style") {
            let h = G(null, i.textContent);
            h.$elm$ = i, h.$index$ = "0", e.$children$ = [h]
        }
        return e
    },
    Ie = (e, t) => {
        if (e.nodeType === 1) {
            let s = e[K] || e.getAttribute(K);
            s && t.set(s, e);
            let n = 0;
            if (e.shadowRoot)
                for (; n < e.shadowRoot.childNodes.length; n++) Ie(e.shadowRoot.childNodes[n], t);
            let r = e.__childNodes || e.childNodes;
            for (n = 0; n < r.length; n++) Ie(r[n], t)
        } else if (e.nodeType === 8) {
            let s = e.nodeValue.split(".");
            s[0] === Ht && (t.set(s[1] + "." + s[2], e), e.nodeValue = "", e["s-en"] = s[3])
        }
    },
    Ke = e => q(q({}, {
        $flags$: 0,
        $hostId$: null,
        $nodeId$: null,
        $depth$: null,
        $index$: "0",
        $elm$: null,
        $attrs$: null,
        $children$: null,
        $key$: null,
        $name$: null,
        $tag$: null,
        $text$: null
    }), e);

function Ze(e, t, s, n, r, i, a, l, $) {
    n["s-sr"] = !0, s.$name$ = e || null, s.$tag$ = "slot";
    let o = r ? .$elm$ ? r.$elm$["s-id"] || r.$elm$.getAttribute("s-id") : "";
    if (l && p.document) {
        let c = s.$elm$ = p.document.createElement(s.$tag$);
        s.$name$ && s.$elm$.setAttribute("name", e), r.$elm$.shadowRoot && o && o !== s.$hostId$ ? O(r.$elm$, "insertBefore")(c, O(r.$elm$, "children")[0]) : O(O(n, "parentNode"), "insertBefore")(c, n), Qe($, t, e, n, s.$hostId$), n.remove(), s.$depth$ === "0" && (l[s.$index$] = s.$elm$)
    } else {
        let c = s.$elm$,
            d = o && o !== s.$hostId$ && r.$elm$.shadowRoot;
        Qe($, t, e, n, d ? o : s.$hostId$), ht(n), d && r.$elm$.insertBefore(c, r.$elm$.children[0])
    }
    i.push(s), a.push(s), r.$children$ || (r.$children$ = []), r.$children$[s.$index$] = s
}
var Qe = (e, t, s, n, r) => {
        var i, a;
        let l = n.nextSibling;
        if (e[t] = e[t] || [], !(!l || (i = l.nodeValue) != null && i.startsWith(me + ".")))
            do l && ((l.getAttribute && l.getAttribute("slot") || l["s-sn"]) === s || s === "" && !l["s-sn"] && (!l.getAttribute || !l.getAttribute("slot")) && (l.nodeType === 8 || l.nodeType === 3)) && (l["s-sn"] = s, e[t].push({
                slot: n,
                node: l,
                hostId: r
            })), l = l ? .nextSibling; while (l && !((a = l.nodeValue) != null && a.startsWith(me + ".")))
    },
    Ve = (e, t) => {
        let s = e;
        do s = s.nextSibling; while (s && (s.nodeType !== t || !s.nodeValue));
        return s
    },
    Ls = e => ct.map(t => t(e)).find(t => !!t),
    $n = e => ct.push(e),
    fn = e => {
        var t;
        return (t = I(e)) == null ? void 0 : t.$modeName$
    },
    Es = class M {
        static fromLocalValue(t) {
            let s = t[ye],
                n = Se in t ? t[Se] : void 0;
            switch (s) {
                case "string":
                    return n;
                case "boolean":
                    return n;
                case "bigint":
                    return BigInt(n);
                case "undefined":
                    return;
                case "null":
                    return null;
                case "number":
                    return n === "NaN" ? NaN : n === "-0" ? -0 : n === "Infinity" ? 1 / 0 : n === "-Infinity" ? -1 / 0 : n;
                case "array":
                    return n.map(o => M.fromLocalValue(o));
                case "date":
                    return new Date(n);
                case "map":
                    let r = new Map;
                    for (let [o, c] of n) {
                        let d = typeof o == "object" && o !== null ? M.fromLocalValue(o) : o,
                            f = M.fromLocalValue(c);
                        r.set(d, f)
                    }
                    return r;
                case "object":
                    let i = {};
                    for (let [o, c] of n) i[o] = M.fromLocalValue(c);
                    return i;
                case "regexp":
                    let {
                        pattern: a,
                        flags: l
                    } = n;
                    return new RegExp(a, l);
                case "set":
                    let $ = new Set;
                    for (let o of n) $.add(M.fromLocalValue(o));
                    return $;
                case "symbol":
                    return Symbol(n);
                default:
                    throw new Error(`Unsupported type: ${s}`)
            }
        }
        static fromLocalValueArray(t) {
            return t.map(s => M.fromLocalValue(s))
        }
        static isLocalValueObject(t) {
            if (typeof t != "object" || t === null || !t.hasOwnProperty(ye)) return !1;
            let s = t[ye];
            return Object.values(q(q({}, ot), at)).includes(s) ? s !== "null" && s !== "undefined" ? t.hasOwnProperty(Se) : !0 : !1
        }
    };

function Os(e) {
    return typeof e != "string" || !e.startsWith(xe) ? e : Es.fromLocalValue(JSON.parse(atob(e.slice(xe.length))))
}
var ke = (e, t, s) => typeof e == "string" && e.startsWith(xe) ? (e = Os(e), e) : e != null && !Ue(e) ? t & 4 ? e === "false" ? !1 : e === "" || !!e : t & 2 ? typeof e == "string" ? parseFloat(e) : typeof e == "number" ? e : NaN : t & 1 ? String(e) : e : e,
    Is = e => {
        var t;
        return (t = I(e)) == null ? void 0 : t.$hostElement$
    },
    dn = (e, t, s) => {
        let n = Is(e);
        return {
            emit: r => bt(n, t, {
                bubbles: !!(s & 4),
                composed: !!(s & 2),
                cancelable: !!(s & 1),
                detail: r
            })
        }
    },
    bt = (e, t, s) => {
        let n = v.ce(t, s);
        return e.dispatchEvent(n), n
    },
    et = (e, t, s, n, r, i, a) => {
        if (s === n) return;
        let l = qe(e, t),
            $ = t.toLowerCase();
        if (t === "class") {
            let o = e.classList,
                c = tt(s),
                d = tt(n);
            if ((e["s-si"] || e["s-sc"]) && a) {
                let f = e["s-sc"] || e["s-si"];
                d.push(f), c.forEach(h => {
                    h.startsWith(f) && d.push(h)
                }), d = [...new Set(d)].filter(h => h), o.add(...d)
            } else o.remove(...c.filter(f => f && !d.includes(f))), o.add(...d.filter(f => f && !c.includes(f)))
        } else if (t === "style") {
            for (let o in s)(!n || n[o] == null) && (o.includes("-") ? e.style.removeProperty(o) : e.style[o] = "");
            for (let o in n)(!s || n[o] !== s[o]) && (o.includes("-") ? e.style.setProperty(o, n[o]) : e.style[o] = n[o])
        } else if (t !== "key")
            if (t === "ref") n && js(n, e);
            else if (!l && t[0] === "o" && t[1] === "n") {
            if (t[2] === "-" ? t = t.slice(3) : qe(p, $) ? t = $.slice(2) : t = $[2] + t.slice(3), s || n) {
                let o = t.endsWith(xt);
                t = t.replace(Ns, ""), s && v.rel(e, t, s, o), n && v.ael(e, t, n, o)
            }
        } else if (t[0] === "a" && t.startsWith("attr:")) {
            let o = t.slice(5),
                c; {
                let d = I(e);
                if (d && d.$cmpMeta$ && d.$cmpMeta$.$members$) {
                    let f = d.$cmpMeta$.$members$[o];
                    f && f[1] && (c = f[1])
                }
            }
            c || (c = o.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase()), n == null || n === !1 ? (n !== !1 || e.getAttribute(c) === "") && e.removeAttribute(c) : e.setAttribute(c, n === !0 ? "" : n);
            return
        } else if (t[0] === "p" && t.startsWith("prop:")) {
            let o = t.slice(5);
            try {
                e[o] = n
            } catch (c) {}
            return
        } else {
            let o = Ue(n);
            if ((l || o && n !== null) && !r) try {
                if (e.tagName.includes("-")) e[t] !== n && (e[t] = n);
                else {
                    let d = n ? ? "";
                    t === "list" ? l = !1 : (s == null || e[t] !== d) && (typeof e.__lookupSetter__(t) == "function" ? e[t] = d : e.setAttribute(t, d))
                }
            } catch (d) {}
            let c = !1;
            $ !== ($ = $.replace(/^xlink\:?/, "")) && (t = $, c = !0), n == null || n === !1 ? (n !== !1 || e.getAttribute(t) === "") && (c ? e.removeAttributeNS(Ge, t) : e.removeAttribute(t)) : (!l || i & 4 || r) && !o && e.nodeType === 1 && (n = n === !0 ? "" : n, c ? e.setAttributeNS(Ge, t, n) : e.setAttribute(t, n))
        }
    },
    ks = /\s/,
    tt = e => (typeof e == "object" && e && "baseVal" in e && (e = e.baseVal), !e || typeof e != "string" ? [] : e.split(ks)),
    xt = "Capture",
    Ns = new RegExp(xt + "$"),
    Ne = (e, t, s, n) => {
        let r = t.$elm$.nodeType === 11 && t.$elm$.host ? t.$elm$.host : t.$elm$,
            i = e && e.$attrs$ || {},
            a = t.$attrs$ || {};
        for (let l of st(Object.keys(i))) l in a || et(r, l, i[l], void 0, s, t.$flags$, n);
        for (let l of st(Object.keys(a))) et(r, l, i[l], a[l], s, t.$flags$, n)
    };

function st(e) {
    return e.includes("ref") ? [...e.filter(t => t !== "ref"), "ref"] : e
}
var re, oe, W, Q = !1,
    ae = !1,
    pe = !1,
    k = !1,
    Ce = [],
    je = [],
    ce = (e, t, s) => {
        var n;
        let r = t.$children$[s],
            i = 0,
            a, l, $;
        if (Q || (pe = !0, r.$tag$ === "slot" && (r.$flags$ |= r.$children$ ? 2 : 1)), r.$text$ != null) a = r.$elm$ = p.document.createTextNode(r.$text$);
        else if (r.$flags$ & 1) a = r.$elm$ = p.document.createTextNode(""), Ne(null, r, k);
        else {
            if (k || (k = r.$tag$ === "svg"), !p.document) throw new Error("You are trying to render a Stencil component in an environment that doesn't support the DOM.");
            if (a = r.$elm$ = p.document.createElementNS(k ? zt : Bt, !Q && B.slotRelocation && r.$flags$ & 2 ? "slot-fb" : r.$tag$), k && r.$tag$ === "foreignObject" && (k = !1), Ne(null, r, k), _s(re) && a["s-si"] !== re && a.classList.add(a["s-si"] = re), r.$children$) {
                let o = r.$tag$ === "template" ? a.content : a;
                for (i = 0; i < r.$children$.length; ++i) l = ce(e, r, i), l && o.appendChild(l)
            }
            r.$tag$ === "svg" ? k = !1 : a.tagName === "foreignObject" && (k = !0)
        }
        return a["s-hn"] = W, r.$flags$ & 3 && (a["s-sr"] = !0, a["s-cr"] = oe, a["s-sn"] = r.$name$ || "", a["s-rf"] = (n = r.$attrs$) == null ? void 0 : n.ref, ht(a), $ = e && e.$children$ && e.$children$[s], $ && $.$tag$ === r.$tag$ && e.$elm$ && mt(e.$elm$), Ot(oe, a, t.$elm$, e ? .$elm$)), a
    },
    mt = e => {
        v.$flags$ |= 1;
        let t = e.closest(W.toLowerCase());
        if (t != null) {
            let s = Array.from(t.__childNodes || t.childNodes).find(r => r["s-cr"]),
                n = Array.from(e.__childNodes || e.childNodes);
            for (let r of s ? n.reverse() : n) r["s-sh"] != null && (j(t, r, s ? ? null), r["s-sh"] = void 0, pe = !0)
        }
        v.$flags$ &= -2
    },
    $e = (e, t) => {
        v.$flags$ |= 1;
        let s = Array.from(e.__childNodes || e.childNodes);
        if (e["s-sr"]) {
            let n = e;
            for (; n = n.nextSibling;) n && n["s-sn"] === e["s-sn"] && n["s-sh"] === W && s.push(n)
        }
        for (let n = s.length - 1; n >= 0; n--) {
            let r = s[n];
            r["s-hn"] !== W && r["s-ol"] && (j(V(r).parentNode, r, V(r)), r["s-ol"].remove(), r["s-ol"] = void 0, r["s-sh"] = void 0, pe = !0), t && $e(r, t)
        }
        v.$flags$ &= -2
    },
    Tt = (e, t, s, n, r, i) => {
        let a = e["s-cr"] && e["s-cr"].parentNode || e,
            l;
        for (a.shadowRoot && a.tagName === W && (a = a.shadowRoot), s.$tag$ === "template" && (a = a.content); r <= i; ++r) n[r] && (l = ce(null, s, r), l && (n[r].$elm$ = l, j(a, l, V(t))))
    },
    At = (e, t, s) => {
        for (let n = t; n <= s; ++n) {
            let r = e[n];
            if (r) {
                let i = r.$elm$;
                Et(r), i && (ae = !0, i["s-ol"] ? i["s-ol"].remove() : $e(i, !0), i.remove())
            }
        }
    },
    Cs = (e, t, s, n, r = !1) => {
        let i = 0,
            a = 0,
            l = 0,
            $ = 0,
            o = t.length - 1,
            c = t[0],
            d = t[o],
            f = n.length - 1,
            h = n[0],
            u = n[f],
            g, T, L = s.$tag$ === "template" ? e.content : e;
        for (; i <= o && a <= f;)
            if (c == null) c = t[++i];
            else if (d == null) d = t[--o];
        else if (h == null) h = n[++a];
        else if (u == null) u = n[--f];
        else if (ne(c, h, r)) H(c, h, r), c = t[++i], h = n[++a];
        else if (ne(d, u, r)) H(d, u, r), d = t[--o], u = n[--f];
        else if (ne(c, u, r))(c.$tag$ === "slot" || u.$tag$ === "slot") && $e(c.$elm$.parentNode, !1), H(c, u, r), j(L, c.$elm$, d.$elm$.nextSibling), c = t[++i], u = n[--f];
        else if (ne(d, h, r))(c.$tag$ === "slot" || u.$tag$ === "slot") && $e(d.$elm$.parentNode, !1), H(d, h, r), j(L, d.$elm$, c.$elm$), d = t[--o], h = n[++a];
        else {
            for (l = -1, $ = i; $ <= o; ++$)
                if (t[$] && t[$].$key$ !== null && t[$].$key$ === h.$key$) {
                    l = $;
                    break
                }
            l >= 0 ? (T = t[l], T.$tag$ !== h.$tag$ ? g = ce(t && t[a], s, l) : (H(T, h, r), t[l] = void 0, g = T.$elm$), h = n[++a]) : (g = ce(t && t[a], s, a), h = n[++a]), g && j(V(c.$elm$).parentNode, g, V(c.$elm$))
        }
        i > o ? Tt(e, n[f + 1] == null ? null : n[f + 1].$elm$, s, n, a, f) : a > f && At(t, i, o)
    },
    ne = (e, t, s = !1) => e.$tag$ === t.$tag$ ? e.$tag$ === "slot" ? e.$name$ === t.$name$ : s ? (s && !e.$key$ && t.$key$ && (e.$key$ = t.$key$), !0) : e.$key$ === t.$key$ : !1,
    V = e => e && e["s-ol"] || e,
    H = (e, t, s = !1) => {
        let n = t.$elm$ = e.$elm$,
            r = e.$children$,
            i = t.$children$,
            a = t.$tag$,
            l = t.$text$,
            $;
        l == null ? (k = a === "svg" ? !0 : a === "foreignObject" ? !1 : k, a === "slot" && !Q && e.$name$ !== t.$name$ && (t.$elm$["s-sn"] = t.$name$ || "", mt(t.$elm$.parentElement)), Ne(e, t, k, s), r !== null && i !== null ? Cs(n, r, t, i, s) : i !== null ? (e.$text$ !== null && (n.textContent = ""), Tt(n, null, t, i, 0, i.length - 1)) : !s && B.updatable && r !== null ? At(r, 0, r.length - 1) : s && B.updatable && r !== null && i === null && (t.$children$ = r), k && a === "svg" && (k = !1)) : ($ = n["s-cr"]) ? $.parentNode.textContent = l : e.$text$ !== l && (n.data = l)
    },
    z = [],
    Lt = e => {
        let t, s, n, r = e.__childNodes || e.childNodes;
        for (let i of r) {
            if (i["s-sr"] && (t = i["s-cr"]) && t.parentNode) {
                s = t.parentNode.__childNodes || t.parentNode.childNodes;
                let a = i["s-sn"];
                for (n = s.length - 1; n >= 0; n--)
                    if (t = s[n], !t["s-cn"] && !t["s-nr"] && t["s-hn"] !== i["s-hn"] && (!t["s-sh"] || t["s-sh"] !== i["s-hn"]))
                        if (Xe(t, a)) {
                            let l = z.find($ => $.$nodeToRelocate$ === t);
                            ae = !0, t["s-sn"] = t["s-sn"] || a, l ? (l.$nodeToRelocate$["s-sh"] = i["s-hn"], l.$slotRefNode$ = i) : (t["s-sh"] = i["s-hn"], z.push({
                                $slotRefNode$: i,
                                $nodeToRelocate$: t
                            })), t["s-sr"] && z.map($ => {
                                Xe($.$nodeToRelocate$, t["s-sn"]) && (l = z.find(o => o.$nodeToRelocate$ === t), l && !$.$slotRefNode$ && ($.$slotRefNode$ = l.$slotRefNode$))
                            })
                        } else z.some(l => l.$nodeToRelocate$ === t) || z.push({
                            $nodeToRelocate$: t
                        })
            }
            i.nodeType === 1 && Lt(i)
        }
    },
    Et = e => {
        e.$attrs$ && e.$attrs$.ref && Ce.push(() => e.$attrs$.ref(null)), e.$children$ && e.$children$.map(Et)
    },
    js = (e, t) => {
        je.push(() => e(t))
    },
    Rs = () => {
        Ce.forEach(e => e()), Ce.length = 0, je.forEach(e => e()), je.length = 0
    },
    j = (e, t, s, n) => {
        if (typeof t["s-sn"] == "string" && t["s-sr"] && t["s-cr"]) Ot(t["s-cr"], t, e, t.parentElement);
        else if (typeof t["s-sn"] == "string") {
            e.getRootNode().nodeType !== 11 && gt(t), e.insertBefore(t, s);
            let {
                slotNode: r
            } = Be(t);
            return r && !n && ue(r), t
        }
        return e.__insertBefore ? e.__insertBefore(t, s) : e ? .insertBefore(t, s)
    };

function Ot(e, t, s, n) {
    var r, i;
    let a;
    if (e && typeof t["s-sn"] == "string" && t["s-sr"] && e.parentNode && e.parentNode["s-sc"] && (a = t["s-si"] || e.parentNode["s-sc"])) {
        let l = t["s-sn"],
            $ = t["s-hn"];
        if ((r = s.classList) == null || r.add(a + "-s"), n && ((i = n.classList) != null && i.contains(a + "-s"))) {
            let o = (n.__childNodes || n.childNodes)[0],
                c = !1;
            for (; o;) {
                if (o["s-sn"] !== l && o["s-hn"] === $ && o["s-sr"]) {
                    c = !0;
                    break
                }
                o = o.nextSibling
            }
            c || n.classList.remove(a + "-s")
        }
    }
}
var ws = (e, t, s = !1) => {
        var n, r, i, a, l;
        let $ = e.$hostElement$,
            o = e.$cmpMeta$,
            c = e.$vnode$ || G(null, null),
            f = xs(t) ? t : _t(null, null, t);
        if (W = $.tagName, o.$attrsToReflect$ && (f.$attrs$ = f.$attrs$ || {}, o.$attrsToReflect$.forEach(([h, u]) => {
                f.$attrs$[u] = $[h]
            })), s && f.$attrs$)
            for (let h of Object.keys(f.$attrs$)) $.hasAttribute(h) && !["key", "ref", "style", "class"].includes(h) && (f.$attrs$[h] = $[h]);
        f.$tag$ = null, f.$flags$ |= 4, e.$vnode$ = f, f.$elm$ = c.$elm$ = $.shadowRoot || $, re = $["s-sc"], Q = !!(o.$flags$ & 1) && !(o.$flags$ & 128), oe = $["s-cr"], ae = !1, H(c, f, s); {
            if (v.$flags$ |= 1, pe) {
                Lt(f.$elm$);
                for (let h of z) {
                    let u = h.$nodeToRelocate$;
                    if (!u["s-ol"] && p.document) {
                        let g = p.document.createTextNode("");
                        g["s-nr"] = u, j(u.parentNode, u["s-ol"] = g, u, s)
                    }
                }
                for (let h of z) {
                    let u = h.$nodeToRelocate$,
                        g = h.$slotRefNode$;
                    if (u.nodeType === 1 && s && (u["s-ih"] = (n = u.hidden) != null ? n : !1), g) {
                        let T = g.parentNode,
                            L = g.nextSibling;
                        if (L && L.nodeType === 1) {
                            let x = (r = u["s-ol"]) == null ? void 0 : r.previousSibling;
                            for (; x;) {
                                let _ = (i = x["s-nr"]) != null ? i : null;
                                if (_ && _["s-sn"] === u["s-sn"] && T === (_.__parentNode || _.parentNode)) {
                                    for (_ = _.nextSibling; _ === u || _ ? .["s-sr"];) _ = _ ? .nextSibling;
                                    if (!_ || !_["s-nr"]) {
                                        L = _;
                                        break
                                    }
                                }
                                x = x.previousSibling
                            }
                        }
                        let y = u.__parentNode || u.parentNode,
                            S = u.__nextSibling || u.nextSibling;
                        if ((!L && T !== y || S !== L) && u !== L) {
                            if (j(T, u, L, s), u.nodeType === 8 && u.nodeValue.startsWith("s-nt-")) {
                                let x = p.document.createTextNode(u.nodeValue.replace(/^s-nt-/, ""));
                                x["s-hn"] = u["s-hn"], x["s-sn"] = u["s-sn"], x["s-sh"] = u["s-sh"], x["s-sr"] = u["s-sr"], x["s-ol"] = u["s-ol"], x["s-ol"]["s-nr"] = x, j(u.parentNode, x, u, s), u.parentNode.removeChild(u)
                            }
                            u.nodeType === 1 && u.tagName !== "SLOT-FB" && (u.hidden = (a = u["s-ih"]) != null ? a : !1)
                        }
                        u && typeof g["s-rf"] == "function" && g["s-rf"](g)
                    } else u.nodeType === 1 && (u.hidden = !0)
                }
            }
            ae && fe(f.$elm$), v.$flags$ &= -2, z.length = 0
        }
        if (!Q && !(o.$flags$ & 1) && $["s-cr"]) {
            let h = f.$elm$.__childNodes || f.$elm$.childNodes;
            for (let u of h)
                if (u["s-hn"] !== W && !u["s-sh"]) {
                    if (s && u["s-ih"] == null && (u["s-ih"] = (l = u.hidden) != null ? l : !1), u.nodeType === 1) u.hidden = !0;
                    else if (u.nodeType === 3 && u.nodeValue.trim()) {
                        let g = p.document.createComment("s-nt-" + u.nodeValue);
                        g["s-sn"] = u["s-sn"], j(u.parentNode, g, u, s), u.parentNode.removeChild(u)
                    }
                }
        }
        oe = void 0, Rs()
    },
    It = (e, t) => {
        if (t && !e.$onRenderResolve$ && t["s-p"]) {
            let s = t["s-p"].push(new Promise(n => e.$onRenderResolve$ = () => {
                t["s-p"].splice(s - 1, 1), n()
            }))
        }
    },
    ge = (e, t) => {
        if (e.$flags$ |= 16, e.$flags$ & 4) {
            e.$flags$ |= 512;
            return
        }
        It(e, e.$ancestorComponent$);
        let s = () => Ds(e, t);
        if (t) {
            queueMicrotask(() => {
                s()
            });
            return
        }
        return ut(s)
    },
    Ds = (e, t) => {
        let s = e.$hostElement$,
            n = D("scheduleUpdate", e.$cmpMeta$.$tagName$),
            r = e.$lazyInstance$;
        if (!r) throw new Error(`Can't render component <${s.tagName.toLowerCase()} /> with invalid Stencil runtime! Make sure this imported component is compiled with a \`externalRuntime: true\` flag. For more information, please refer to https://stenciljs.com/docs/custom-elements#externalruntime`);
        let i;
        return t ? (e.$deferredConnectedCallback$ && (e.$deferredConnectedCallback$ = !1, R(r, "connectedCallback", void 0, s)), e.$flags$ |= 256, e.$queuedListeners$ && (e.$queuedListeners$.map(([a, l]) => R(r, a, l, s)), e.$queuedListeners$ = void 0), e.$fetchedCbList$.length && e.$fetchedCbList$.forEach(a => a(s)), i = R(r, "componentWillLoad", void 0, s)) : i = R(r, "componentWillUpdate", void 0, s), i = nt(i, () => R(r, "componentWillRender", void 0, s)), n(), nt(i, () => Bs(e, r, t))
    },
    nt = (e, t) => zs(e) ? e.then(t).catch(s => {
        console.error(s), t()
    }) : t(),
    zs = e => e instanceof Promise || e && e.then && typeof e.then == "function",
    Bs = (e, t, s) => se(null, null, function*() {
        var n;
        let r = e.$hostElement$,
            i = D("update", e.$cmpMeta$.$tagName$),
            a = r["s-rc"];
        s && vs(e);
        let l = D("render", e.$cmpMeta$.$tagName$);
        Us(e, t, r, s), a && (a.map($ => $()), r["s-rc"] = void 0), l(), i(); {
            let $ = (n = r["s-p"]) != null ? n : [],
                o = () => Fs(e);
            $.length === 0 ? o() : (Promise.all($).then(o).catch(o), e.$flags$ |= 4, $.length = 0)
        }
    }),
    Us = (e, t, s, n) => {
        try {
            t = t.render && t.render(), e.$flags$ &= -17, e.$flags$ |= 2, ws(e, t, n)
        } catch (r) {
            F(r, e.$hostElement$)
        }
        return null
    },
    Fs = e => {
        let t = e.$cmpMeta$.$tagName$,
            s = e.$hostElement$,
            n = D("postUpdate", t),
            r = e.$lazyInstance$,
            i = e.$ancestorComponent$;
        R(r, "componentDidRender", void 0, s), e.$flags$ & 64 ? (R(r, "componentDidUpdate", void 0, s), n()) : (e.$flags$ |= 64, Ms(s), R(r, "componentDidLoad", void 0, s), n(), e.$onReadyResolve$(s), i || kt()), e.$onInstanceResolve$(s), e.$onRenderResolve$ && (e.$onRenderResolve$(), e.$onRenderResolve$ = void 0), e.$flags$ & 512 && De(() => ge(e, !1)), e.$flags$ &= -517
    },
    un = e => {
        var t; {
            let s = I(e),
                n = (t = s ? .$hostElement$) == null ? void 0 : t.isConnected;
            return n && (s.$flags$ & 18) === 2 && ge(s, !1), n
        }
    },
    kt = e => {
        var t;
        De(() => bt(p, "appload", {
            detail: {
                namespace: wt
            }
        })), (t = v.$orgLocNodes$) != null && t.size && v.$orgLocNodes$.clear()
    },
    R = (e, t, s, n) => {
        if (e && e[t]) try {
            return e[t](s)
        } catch (r) {
            F(r, n)
        }
    },
    Ms = e => {
        var t;
        return e.classList.add((t = B.hydratedSelectorName) != null ? t : "hydrated")
    },
    Ws = (e, t) => I(e).$instanceValues$.get(t),
    _e = (e, t, s, n) => {
        let r = I(e);
        if (!r) return;
        if (!r) throw new Error(`Couldn't find host element for "${n.$tagName$}" as it is unknown to this Stencil runtime. This usually happens when integrating a 3rd party Stencil component with another Stencil component or application. Please reach out to the maintainers of the 3rd party Stencil component or report this on the Stencil Discord server (https://chat.stenciljs.com) or comment on this similar [GitHub issue](https://github.com/stenciljs/core/issues/5457).`);
        let i = r.$hostElement$,
            a = r.$instanceValues$.get(t),
            l = r.$flags$,
            $ = r.$lazyInstance$;
        s = ke(s, n.$members$[t][0]);
        let o = Number.isNaN(a) && Number.isNaN(s),
            c = s !== a && !o;
        if ((!(l & 8) || a === void 0) && c) {
            if (r.$instanceValues$.set(t, s), n.$watchers$) {
                let d = n.$watchers$[t];
                d && d.map(f => {
                    try {
                        let [
                            [h, u]
                        ] = Object.entries(f);
                        (l & 128 || u & 1) && ($ ? $[h](s, a, t) : r.$fetchedCbList$.push(() => {
                            r.$lazyInstance$[h](s, a, t)
                        }))
                    } catch (h) {
                        F(h, i)
                    }
                })
            }
            if (l & 2) {
                if ($.componentShouldUpdate && $.componentShouldUpdate(s, a, t) === !1 && !(l & 16)) return;
                l & 16 || ge(r, !1)
            }
        }
    },
    Nt = (e, t, s) => {
        var n, r;
        let i = e.prototype;
        if (t.$members$ || B.propChangeCallback) {
            e.watchers && !t.$watchers$ && (t.$watchers$ = e.watchers), e.deserializers && !t.$deserializers$ && (t.$deserializers$ = e.deserializers), e.serializers && !t.$serializers$ && (t.$serializers$ = e.serializers);
            let a = Object.entries((n = t.$members$) != null ? n : {});
            if (a.map(([l, [$]]) => {
                    if ($ & 31 || s & 2 && $ & 32) {
                        let {
                            get: o,
                            set: c
                        } = Object.getOwnPropertyDescriptor(i, l) || {};
                        o && (t.$members$[l][0] |= 2048), c && (t.$members$[l][0] |= 4096), (s & 1 || !o) && Object.defineProperty(i, l, {
                            get() {
                                {
                                    if ((t.$members$[l][0] & 2048) === 0) return Ws(this, l);
                                    let d = I(this),
                                        f = d ? d.$lazyInstance$ : i;
                                    return f ? f[l] : void 0
                                }
                            },
                            configurable: !0,
                            enumerable: !0
                        }), Object.defineProperty(i, l, {
                            set(d) {
                                let f = I(this);
                                if (f) {
                                    if (c) {
                                        typeof($ & 32 ? this[l] : f.$hostElement$[l]) > "u" && f.$instanceValues$.get(l) && (d = f.$instanceValues$.get(l)), c.apply(this, [ke(d, $)]), d = $ & 32 ? this[l] : f.$hostElement$[l], _e(this, l, d, t);
                                        return
                                    } {
                                        if ((s & 1) === 0 || (t.$members$[l][0] & 4096) === 0) {
                                            _e(this, l, d, t), s & 1 && !f.$lazyInstance$ && f.$fetchedCbList$.push(() => {
                                                t.$members$[l][0] & 4096 && f.$lazyInstance$[l] !== f.$instanceValues$.get(l) && (f.$lazyInstance$[l] = d)
                                            });
                                            return
                                        }
                                        let h = () => {
                                            let u = f.$lazyInstance$[l];
                                            !f.$instanceValues$.get(l) && u && f.$instanceValues$.set(l, u), f.$lazyInstance$[l] = ke(d, $), _e(this, l, f.$lazyInstance$[l], t)
                                        };
                                        f.$lazyInstance$ ? h() : f.$fetchedCbList$.push(() => {
                                            h()
                                        })
                                    }
                                }
                            }
                        })
                    } else s & 1 && $ & 64 && Object.defineProperty(i, l, {
                        value(...o) {
                            var c;
                            let d = I(this);
                            return (c = d ? .$onInstancePromise$) == null ? void 0 : c.then(() => {
                                var f;
                                return (f = d.$lazyInstance$) == null ? void 0 : f[l](...o)
                            })
                        }
                    })
                }), s & 1) {
                let l = new Map;
                i.attributeChangedCallback = function($, o, c) {
                    v.jmp(() => {
                        var d;
                        let f = l.get($),
                            h = I(this);
                        if (this.hasOwnProperty(f) && B.lazyLoad && (c = this[f], delete this[f]), i.hasOwnProperty(f) && typeof this[f] == "number" && this[f] == c) return;
                        if (f == null) {
                            let T = h ? .$flags$;
                            if (h && T && !(T & 8) && c !== o) {
                                let L = h.$lazyInstance$,
                                    y = (d = t.$watchers$) == null ? void 0 : d[$];
                                y ? .forEach(S => {
                                    let [
                                        [x, _]
                                    ] = Object.entries(S);
                                    L[x] != null && (T & 128 || _ & 1) && L[x].call(L, c, o, $)
                                })
                            }
                            return
                        }
                        let u = a.find(([T]) => T === f);
                        u && u[1][0] & 4 && (c = !(c === null || c === "false"));
                        let g = Object.getOwnPropertyDescriptor(i, f);
                        c != this[f] && (!g.get || g.set) && (this[f] = c)
                    })
                }, e.observedAttributes = Array.from(new Set([...Object.keys((r = t.$watchers$) != null ? r : {}), ...a.filter(([$, o]) => o[0] & 31).map(([$, o]) => {
                    var c;
                    let d = o[1] || $;
                    return l.set(d, $), o[0] & 512 && ((c = t.$attrsToReflect$) == null || c.push([$, d])), d
                })]))
            }
        }
        return e
    },
    qs = (e, t, s, n) => se(null, null, function*() {
        let r;
        try {
            if ((t.$flags$ & 32) === 0) {
                if (t.$flags$ |= 32, s.$lazyBundleId$) {
                    let $ = Wt(s, t);
                    if ($ && "then" in $) {
                        let d = gs();
                        r = yield $, d()
                    } else r = $;
                    if (!r) throw new Error(`Constructor for "${s.$tagName$}#${t.$modeName$}" was not found`);
                    r.isProxied || (s.$watchers$ = r.watchers, s.$serializers$ = r.serializers, s.$deserializers$ = r.deserializers, Nt(r, s, 2), r.isProxied = !0);
                    let o = D("createInstance", s.$tagName$);
                    t.$flags$ |= 8;
                    try {
                        new r(t)
                    } catch (d) {
                        F(d, e)
                    }
                    t.$flags$ &= -9, t.$flags$ |= 128, o(), s.$flags$ & 4 ? t.$deferredConnectedCallback$ = !0 : Re(t.$lazyInstance$, e)
                } else {
                    r = e.constructor;
                    let $ = e.localName;
                    customElements.whenDefined($).then(() => t.$flags$ |= 128)
                }
                if (r && r.style) {
                    let $;
                    typeof r.style == "string" ? $ = r.style : typeof r.style != "string" && (t.$modeName$ = Ls(e), t.$modeName$ && ($ = r.style[t.$modeName$]));
                    let o = he(s, t.$modeName$);
                    if (!ie.has(o) || B.hotModuleReplacement) {
                        let c = D("registerStyles", s.$tagName$);
                        yt(o, $, !!(s.$flags$ & 1)), c()
                    }
                }
            }
            let i = t.$ancestorComponent$,
                a = () => ge(t, !0);
            i && i["s-rc"] ? i["s-rc"].push(a) : a()
        } catch (i) {
            F(i, e), t.$onRenderResolve$ && (t.$onRenderResolve$(), t.$onRenderResolve$ = void 0), t.$onReadyResolve$ && t.$onReadyResolve$(e)
        }
    }),
    Re = (e, t) => {
        R(e, "connectedCallback", void 0, t)
    },
    Hs = e => {
        if ((v.$flags$ & 1) === 0) {
            let t = I(e);
            if (!t) return;
            let s = t.$cmpMeta$,
                n = D("connectedCallback", s.$tagName$);
            if (t.$flags$ & 1) Ct(e, t, s.$listeners$), t ? .$lazyInstance$ ? Re(t.$lazyInstance$, e) : t ? .$onReadyPromise$ && t.$onReadyPromise$.then(() => Re(t.$lazyInstance$, e));
            else {
                t.$flags$ |= 1;
                let r;
                if (r = e.getAttribute(K), r) {
                    if (s.$flags$ & 1) {
                        let i = St(e.shadowRoot, s, e.getAttribute("s-mode"));
                        e.classList.remove(i + "-h", i + "-s")
                    } else if (s.$flags$ & 2) {
                        let i = he(s, e.getAttribute("s-mode"));
                        e["s-sc"] = i
                    }
                    As(e, s.$tagName$, r, t)
                }
                r || s.$flags$ & 12 && Ps(e); {
                    let i = e;
                    for (; i = i.parentNode || i.host;)
                        if (i.nodeType === 1 && i.hasAttribute("s-id") && i["s-p"] || i["s-p"]) {
                            It(t, t.$ancestorComponent$ = i);
                            break
                        }
                }
                s.$members$ && Object.entries(s.$members$).map(([i, [a]]) => {
                    if (a & 31 && i in e && e[i] !== Object.prototype[i]) {
                        let l = e[i];
                        delete e[i], e[i] = l
                    }
                }), qs(e, t, s)
            }
            n()
        }
    },
    Ps = e => {
        if (!p.document) return;
        let t = e["s-cr"] = p.document.createComment("");
        t["s-cn"] = !0, j(e, t, e.firstChild)
    },
    rt = (e, t) => {
        R(e, "disconnectedCallback", void 0, t || e)
    },
    Gs = e => se(null, null, function*() {
        if ((v.$flags$ & 1) === 0) {
            let t = I(e);
            t ? .$rmListeners$ && (t.$rmListeners$.map(s => s()), t.$rmListeners$ = void 0), t ? .$lazyInstance$ ? rt(t.$lazyInstance$, e) : t ? .$onReadyPromise$ && t.$onReadyPromise$.then(() => rt(t.$lazyInstance$, e))
        }
        U.has(e) && U.delete(e), e.shadowRoot && U.has(e.shadowRoot) && U.delete(e.shadowRoot)
    }),
    hn = (e, t = {}) => {
        var s;
        if (!p.document) {
            console.warn("Stencil: No document found. Skipping bootstrapping lazy components.");
            return
        }
        let n = D(),
            r = [],
            i = t.exclude || [],
            a = p.customElements,
            l = p.document.head,
            $ = l.querySelector("meta[charset]"),
            o = p.document.createElement("style"),
            c = [],
            d, f = !0;
        Object.assign(v, t), v.$resourcesUrl$ = new URL(t.resourcesUrl || "./", p.document.baseURI).href, v.$flags$ |= 2, Ss();
        let h = !1;
        if (e.map(u => {
                u[1].map(g => {
                    var T, L, y;
                    let S = {
                        $flags$: g[0],
                        $tagName$: g[1],
                        $members$: g[2],
                        $listeners$: g[3]
                    };
                    S.$flags$ & 4 && (h = !0), S.$members$ = g[2], S.$listeners$ = g[3], S.$attrsToReflect$ = [], S.$watchers$ = (T = g[4]) != null ? T : {}, S.$serializers$ = (L = g[5]) != null ? L : {}, S.$deserializers$ = (y = g[6]) != null ? y : {};
                    let x = S.$tagName$,
                        _ = class extends HTMLElement {
                            "s-p";
                            "s-rc";
                            hasRegisteredEventListeners = !1;
                            constructor(m) {
                                if (super(m), m = this, Mt(m, S), S.$flags$ & 1) {
                                    if (!m.shadowRoot) Zt.call(m, S);
                                    else if (m.shadowRoot.mode !== "open") throw new Error(`Unable to re-use existing shadow root for ${S.$tagName$}! Mode is set to ${m.shadowRoot.mode} but Stencil only supports open shadow roots.`)
                                }
                            }
                            connectedCallback() {
                                let m = I(this);
                                m && (this.hasRegisteredEventListeners || (this.hasRegisteredEventListeners = !0, Ct(this, m, S.$listeners$)), d && (clearTimeout(d), d = null), f ? c.push(this) : v.jmp(() => Hs(this)))
                            }
                            disconnectedCallback() {
                                v.jmp(() => Gs(this)), v.raf(() => {
                                    var m;
                                    let C = I(this);
                                    if (!C) return;
                                    let X = c.findIndex(b => b === this);
                                    X > -1 && c.splice(X, 1), ((m = C ? .$vnode$) == null ? void 0 : m.$elm$) instanceof Node && !C.$vnode$.$elm$.isConnected && delete C.$vnode$.$elm$
                                })
                            }
                            componentOnReady() {
                                var m;
                                return (m = I(this)) == null ? void 0 : m.$onReadyPromise$
                            }
                        };
                    !(S.$flags$ & 1) && S.$flags$ & 256 ? Qt(_.prototype) : pt(_.prototype), S.$lazyBundleId$ = u[0], !i.includes(x) && !a.get(x) && (r.push(x), a.define(x, Nt(_, S, 1)))
                })
            }), r.length > 0 && (h && (o.textContent += $t), o.textContent += r.sort() + Yt, o.innerHTML.length)) {
            o.setAttribute("data-styles", "");
            let u = (s = v.$nonce$) != null ? s : vt(p.document);
            u != null && o.setAttribute("nonce", u), l.insertBefore(o, $ ? $.nextSibling : l.firstChild)
        }
        f = !1, c.length ? c.map(u => u.connectedCallback()) : v.jmp(() => d = setTimeout(kt, 30)), n()
    },
    pn = (e, t) => t,
    Ct = (e, t, s, n) => {
        s && p.document && s.map(([r, i, a]) => {
            let l = Xs(p.document, e, r),
                $ = Ys(t, a),
                o = Js(r);
            v.ael(l, i, $, o), (t.$rmListeners$ = t.$rmListeners$ || []).push(() => v.rel(l, i, $, o))
        })
    },
    Ys = (e, t) => s => {
        var n;
        try {
            e.$flags$ & 256 ? (n = e.$lazyInstance$) == null || n[t](s) : (e.$queuedListeners$ = e.$queuedListeners$ || []).push([t, s])
        } catch (r) {
            F(r, e.$hostElement$)
        }
    },
    Xs = (e, t, s) => s & 4 ? e : s & 8 ? p : s & 16 ? e.body : t,
    Js = e => Jt ? {
        passive: (e & 1) !== 0,
        capture: (e & 2) !== 0
    } : (e & 2) !== 0;
export {
    it as a, Qs as b, Vs as c, en as d, tn as e, sn as f, nn as g, rn as h, ln as i, an as j, ut as k, cn as l, _t as m, bs as n, $n as o, fn as p, Is as q, dn as r, un as s, hn as t, pn as u
};