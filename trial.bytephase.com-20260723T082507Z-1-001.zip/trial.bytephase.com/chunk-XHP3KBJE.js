import {
    Ud as s,
    aa as r,
    da as o,
    ui as n
} from "./chunk-GOPIAW4V.js";
var h = (() => {
    class i {
        constructor(t) {
            this.api = t, this.endpoint = s + "two-factor/"
        }
        verify(t) {
            return this.api.post(this.endpoint + "verify", t)
        }
        setupQr(t) {
            return this.api.postWithHeaders(this.endpoint + "setup-qr", {}, {
                "X-Two-Factor-Token": t
            })
        }
        setupAndConfirm(t, e) {
            return this.api.postWithHeaders(this.endpoint + "setup-confirm", {
                code: t
            }, {
                "X-Two-Factor-Token": e
            })
        }
        getStatus() {
            return this.api.get(this.endpoint + "status")
        }
        setup() {
            return this.api.post(this.endpoint + "setup")
        }
        confirm(t) {
            return this.api.post(this.endpoint + "confirm", {
                code: t
            })
        }
        disable(t) {
            return this.api.post(this.endpoint + "disable", {
                password: t
            })
        }
        regenerateBackupCodes(t) {
            return this.api.post(this.endpoint + "regenerate-backup-codes", {
                password: t
            })
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || i)(o(n))
            }
        }
        static {
            this.\u0275prov = r({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
export {
    h as a
};