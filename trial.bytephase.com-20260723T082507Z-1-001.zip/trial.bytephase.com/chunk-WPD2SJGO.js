import {
    a as We
} from "./chunk-WNEBY3WS.js";
import {
    a as Dt,
    d as O,
    e as et,
    g as Ge
} from "./chunk-WDS5LHZR.js";
import "./chunk-36T2HUF3.js";
import "./chunk-OG4EABPU.js";
import "./chunk-HUDETQT5.js";
import "./chunk-PGAHHPJ5.js";
import {
    a as Ue
} from "./chunk-MBAKXBI4.js";
import "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import "./chunk-FAP35UT3.js";
import "./chunk-2KS5UOZO.js";
import {
    a as se
} from "./chunk-KJCCJCIN.js";
import {
    $b as Mt,
    Ab as ve,
    Db as Pt,
    Fa as vt,
    Ia as xt,
    Jb as xe,
    Kb as ge,
    Kd as Ie,
    Ke as Ae,
    L as te,
    Lb as Z,
    Ld as Qe,
    M as _t,
    Mb as he,
    Md as It,
    Mg as Be,
    Nd as tt,
    Qb as Se,
    Qe as Ne,
    Rb as be,
    Sc as Ee,
    T as D,
    Ta as ce,
    Ub as Te,
    Ud as Ve,
    Vb as Pe,
    Zd as Qt,
    _b as yt,
    _d as ke,
    aa as le,
    ab as gt,
    ac as wt,
    ba as R,
    bb as me,
    ca as Ct,
    cb as ht,
    cd as Oe,
    db as de,
    df as Fe,
    fb as ue,
    fc as Et,
    g as lt,
    ge as Vt,
    gf as kt,
    h as ct,
    ha as L,
    hd as Ot,
    ic as ye,
    id as U,
    jb as _e,
    jc as Me,
    ka as B,
    l as ot,
    lb as fe,
    m as $t,
    n as pt,
    pb as St,
    pe as De,
    ph as je,
    q as Kt,
    qe as Re,
    rd as qt,
    sb as bt,
    sf as Le,
    t as mt,
    u as dt,
    vd as qe,
    xb as Tt,
    xc as j,
    y as Xt,
    yb as Ce,
    yc as we
} from "./chunk-DCKGQUHB.js";
import {
    $a as d,
    $b as Rt,
    Ab as W,
    Ak as pe,
    Ba as A,
    Ec as Ht,
    Fa as o,
    Fh as y,
    Hb as Gt,
    Ib as x,
    Jb as P,
    Ka as q,
    Kb as E,
    Lb as N,
    Na as M,
    Oa as st,
    Pb as I,
    Qb as Q,
    Rb as V,
    Rc as zt,
    Sa as w,
    Tc as Jt,
    _a as m,
    _b as k,
    ac as Wt,
    ai as ne,
    ba as at,
    bb as z,
    bc as At,
    bi as ft,
    cb as J,
    ch as ee,
    ci as oe,
    db as Y,
    ea as v,
    eb as s,
    fb as r,
    fd as Yt,
    fi as ae,
    gb as l,
    gc as S,
    ha as _,
    hb as u,
    hi as F,
    ia as f,
    ic as b,
    ii as re,
    n as jt,
    pd as ut,
    qb as g,
    qd as Zt,
    sa as rt,
    sb as C,
    sd as K,
    th as ie,
    ub as a,
    vd as Nt,
    xd as X,
    xk as h,
    yb as $,
    z as Ut,
    zb as G
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var ai = () => ({
        enabled: !1
    }),
    ri = () => ({
        groupPaging: !1
    }),
    si = () => ({
        mode: "standard"
    }),
    li = () => ({
        type: "fixedPoint",
        precision: 2
    });

function ci(e, c) {
    if (e & 1 && (r(0, "h5"), x(1), l()), e & 2) {
        let t = a();
        o(), P(t.formatMessage("common_parts"))
    }
}

function pi(e, c) {
    if (e & 1 && u(0, "app-print-table", 3), e & 2) {
        let t = a();
        s("columns", t.columns)("rows", t.dataSource)
    }
}

function mi(e, c) {
    if (e & 1 && (r(0, "div"), u(1, "span", 11), S(2, "taxSplit"), S(3, "safe"), l()), e & 2) {
        let t = c.$implicit;
        o(), s("innerHTML", b(3, 4, b(2, 1, t.data, "amount"), "html"), A)
    }
}

function di(e, c) {
    if (e & 1 && (r(0, "div"), u(1, "span", 11), S(2, "taxSplit"), S(3, "safe"), l()), e & 2) {
        let t = c.$implicit;
        o(), s("innerHTML", b(3, 4, b(2, 1, t.data, "name"), "html"), A)
    }
}

function ui(e, c) {
    if (e & 1 && (r(0, "div")(1, "h6"), x(2), l()()), e & 2) {
        let t = a(2);
        o(2), P(t.formatMessage("common_parts"))
    }
}

function _i(e, c) {
    if (e & 1 && (r(0, "div"), u(1, "app-part-name", 12), l()), e & 2) {
        let t = c.$implicit;
        o(), s("part", t.data)
    }
}

function fi(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 14), C("onClickEvent", function() {
            _(t);
            let i = a(3);
            return f(i.onScanPartBtnClick())
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("text", t.isMobileDevice ? "" : "scan_part")("isVisibleIcon", !0)
    }
}

function Ci(e, c) {
    if (e & 1 && (r(0, "div"), m(1, fi, 1, 2, "app-dx-outline-button", 13), l()), e & 2) {
        let t = a(2);
        o(), d(t.isEditMode ? 1 : -1)
    }
}

function vi(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 16), C("onClickEvent", function() {
            _(t);
            let i = a(3);
            return f(i.addPart())
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("text", t.isMobileDevice ? "" : "inventory_add_part")("isVisibleIcon", !0)
    }
}

function xi(e, c) {
    if (e & 1 && (r(0, "div"), m(1, vi, 1, 2, "app-dx-outline-button", 15), l()), e & 2) {
        let t = a(2);
        o(), d(t.isEditMode ? 1 : -1)
    }
}

function gi(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "i", 19), C("click", function() {
            _(t);
            let i = a().$implicit,
                p = a(2);
            return f(p.editPart(i))
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("title", t.formatMessage("common_edit"))
    }
}

function hi(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "i", 20), C("click", function() {
            _(t);
            let i = a().$implicit,
                p = a(2);
            return f(p.deletePart(i.data))
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("title", t.formatMessage("delete"))
    }
}

function Si(e, c) {
    if (e & 1 && (r(0, "div"), m(1, gi, 1, 1, "i", 17), m(2, hi, 1, 1, "i", 18), l()), e & 2) {
        let t = a(2);
        o(), d(t.isEditMode && t.isEmployee ? 1 : -1), o(), d(t.isEditMode && t.isEmployee ? 2 : -1)
    }
}

function bi(e, c) {
    if (e & 1 && u(0, "dxi-total-item", 10), e & 2) {
        let t = c.$implicit;
        s("alignment", t.alignment)("column", t.column)("name", t.column)("summaryType", t.summaryType)("valueFormat", k(5, li))
    }
}

function Ti(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "dx-data-grid", 7), C("onContentReady", function() {
            _(t);
            let i = a();
            return f(i.onContentReady())
        })("onToolbarPreparing", function(i) {
            _(t);
            let p = a();
            return f(p.onToolbarPreparing(i))
        }), V("dataSourceChange", function(i) {
            _(t);
            let p = a();
            return Q(p.dataSource, i) || (p.dataSource = i), f(i)
        }), w(1, mi, 4, 7, "div", 8)(2, di, 4, 7, "div", 8)(3, ui, 3, 1, "div", 8)(4, _i, 2, 1, "div", 8)(5, Ci, 2, 1, "div", 8)(6, xi, 2, 1, "div", 8)(7, Si, 3, 2, "div", 8), r(8, "dxo-summary", 9), J(9, bi, 1, 6, "dxi-total-item", 10, z), l()()
    }
    if (e & 2) {
        let t = a();
        I("dataSource", t.dataSource), s("columnAutoWidth", !1)("columns", t.columns)("paging", k(14, ai))("remoteOperations", k(15, ri))("scrolling", k(16, si)), o(), s("dxTemplateOf", "taxAmountSplitSubClassTemplate"), o(), s("dxTemplateOf", "taxSplitSubClassTemplate"), o(), s("dxTemplateOf", "tableHeaderTemplate"), o(), s("dxTemplateOf", "partNameTemplate"), o(), s("dxTemplateOf", "scanPartButton"), o(), s("dxTemplateOf", "addBtnTemplate"), o(), s("dxTemplateOf", "actionTemplate"), o(), s("skipEmptyValues", !0), o(), Y(t.summaryRows)
    }
}

function Pi(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-add-part-to-entity-popup", 21), C("addPartToEntityCancelClick", function() {
            _(t);
            let i = a();
            return f(i.isVisiblePartPopup = !1)
        })("addPartToEntitySaveClick", function(i) {
            _(t);
            let p = a();
            return f(p.onPartSave(i))
        }), l()
    }
    if (e & 2) {
        let t = a();
        s("isCreate", t.isCreate)("isVisibleBarcodeScannerPopUp", t.isVisibleBarcodeScannerPopUp)("isVisiblePopup", t.isVisiblePartPopup)("partableType", t.ENTITIES.QUOTATION.name)("partable", t.currentPart)
    }
}
var it = (() => {
    class e {
        constructor() {
            this.formatMessage = h, this.ENTITIES = F, this.isEditMode = !1, this.columns = v(Fe).partColumns, this.dataService = v(U), this.userSessionService = v(R), this.isMobileDevice = v(D).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.isLoading = !1, this.isVisibleBarcodeScannerPopUp = !1, this.summaryRows = ft, this.isVisiblePartPopup = !1, this.dataSource = [], this.isCreate = !1
        }
        static {
            this.autoId = 0
        }
        ngOnInit() {
            this.columns.push({
                dataField: "",
                hidingPriority: 7,
                caption: "",
                width: 45,
                cellTemplate: "actionTemplate",
                visible: this.isEditMode && this.isEmployee
            }), Tt.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice), this.dataSource = this.quotation ? .partables || []
        }
        ngOnChanges(t) {
            t.isEditMode && (this.isEditMode = t.isEditMode.currentValue, this.columns ? .length && this.columns.findIndex(n => n.cellTemplate === "actionTemplate") !== -1 && (this.columns[this.columns.length - 1].visible = this.isEditMode), !t.isEditMode.previousValue && t.isEditMode.currentValue && (this.isLoading = !0, setTimeout(() => {
                this.isLoading = !1
            })))
        }
        onToolbarPreparing(t) {
            this.isEditMode ? t.toolbarOptions.items.push({
                template: "tableHeaderTemplate",
                location: "before",
                locateInMenu: "never"
            }, {
                template: "scanPartButton",
                location: "after",
                locateInMenu: "auto",
                visible: this.userPermissionList.includes(y.QUOTATION_WRITE)
            }, {
                template: "addBtnTemplate",
                location: "after",
                locateInMenu: "never"
            }) : t.toolbarOptions.visible = !1
        }
        addPart() {
            this.isVisiblePartPopup = !0, this.isCreate = !0
        }
        onScanPartBtnClick() {
            this.isVisiblePartPopup = !0, this.isCreate = !0, this.isVisibleBarcodeScannerPopUp = !0
        }
        editPart(t) {
            this.isCreate = !1, this.currentPart = t.data, this.isVisiblePartPopup = !0
        }
        onPartSave(t) {
            this.isCreate ? (t.id = ++e.autoId, this.dataSource.push(t)) : this.dataSource[this.dataSource.findIndex(n => n.id === t.id)] = t, this.isCreate = !1, this.isVisiblePartPopup = !1, this.currentPart = null
        }
        deletePart(t) {
            this.dataSource = this.dataSource.filter(n => n.id !== t.id)
        }
        onContentReady() {
            let t = new Ot({
                price: this.dataGrid.instance.getTotalSummaryValue("price"),
                sub_total: this.dataGrid.instance.getTotalSummaryValue("sub_total"),
                discount: this.dataGrid.instance.getTotalSummaryValue("discount"),
                tax_amount: this.dataGrid.instance.getTotalSummaryValue("tax_amount"),
                line_total: this.dataGrid.instance.getTotalSummaryValue("line_total")
            });
            this.dataService.currentQuotationPartTotalSource.next(t);
            let n = this.dataSource ? .some(p => p ? .part ? .sku),
                i = this.dataGrid.instance.columnOption("part.sku");
            i && i.visible !== n && this.dataGrid.instance.columnOption("part.sku", "visible", n)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || e)
            }
        }
        static {
            this.\u0275cmp = M({
                type: e,
                selectors: [
                    ["app-quotation-part"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && $(j, 5), n & 2) {
                        let p;
                        G(p = W()) && (i.dataGrid = p.first)
                    }
                },
                inputs: {
                    quotation: "quotation",
                    isEditMode: "isEditMode"
                },
                standalone: !1,
                features: [rt],
                decls: 8,
                vars: 4,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "print"],
                    [3, "columns", "rows"],
                    [1, "no-print"],
                    ["id", "partGrid", "keyExpr", "id", 3, "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [3, "isCreate", "isVisibleBarcodeScannerPopUp", "isVisiblePopup", "partableType", "partable"],
                    ["id", "partGrid", "keyExpr", "id", 3, "onContentReady", "onToolbarPreparing", "dataSourceChange", "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "skipEmptyValues"],
                    ["displayFormat", "{0}", 3, "alignment", "column", "name", "summaryType", "valueFormat"],
                    [1, "tax-split", 3, "innerHTML"],
                    [3, "part"],
                    ["buttonType", "default", "icon", "fa-thin fa-barcode-read", 1, "float-end", "me-1", 3, "text", "isVisibleIcon"],
                    ["buttonType", "default", "icon", "fa-thin fa-barcode-read", 1, "float-end", "me-1", 3, "onClickEvent", "text", "isVisibleIcon"],
                    ["buttonType", "default", "icon", "fa-thin fa-plus", 1, "float-end", 3, "text", "isVisibleIcon"],
                    ["buttonType", "default", "icon", "fa-thin fa-plus", 1, "float-end", 3, "onClickEvent", "text", "isVisibleIcon"],
                    [1, "fa-thin", "fa-pencil", "me-2", 3, "title"],
                    [1, "fa-thin", "fa-trash", 3, "title"],
                    [1, "fa-thin", "fa-pencil", "me-2", 3, "click", "title"],
                    [1, "fa-thin", "fa-trash", 3, "click", "title"],
                    [3, "addPartToEntityCancelClick", "addPartToEntitySaveClick", "isCreate", "isVisibleBarcodeScannerPopUp", "isVisiblePopup", "partableType", "partable"]
                ],
                template: function(n, i) {
                    n & 1 && (r(0, "div", 0)(1, "div", 1), m(2, ci, 2, 1, "h5"), r(3, "div", 2), m(4, pi, 1, 2, "app-print-table", 3), l(), r(5, "div", 4), m(6, Ti, 11, 17, "dx-data-grid", 5), l()()(), m(7, Pi, 1, 5, "app-add-part-to-entity-popup", 6)), n & 2 && (o(2), d(i.isEditMode ? -1 : 2), o(2), d(i.dataSource.length ? 4 : -1), o(2), d(i.isLoading ? -1 : 6), o(), d(i.isVisiblePartPopup ? 7 : -1))
                },
                dependencies: [De, tt, Ie, B, L, j, vt, xt, Z, It],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return e
})();
var yi = () => ({
        enabled: !1
    }),
    Mi = () => ({
        groupPaging: !1
    }),
    wi = () => ({
        mode: "standard"
    }),
    Ei = () => ({
        type: "fixedPoint",
        precision: 2
    });

function Oi(e, c) {
    if (e & 1 && (r(0, "h5"), x(1), l()), e & 2) {
        let t = a();
        o(), P(t.formatMessage("job_services"))
    }
}

function qi(e, c) {
    if (e & 1 && u(0, "app-print-table", 3), e & 2) {
        let t = a();
        s("columns", t.columns)("rows", t.dataSource)
    }
}

function Ii(e, c) {
    if (e & 1 && (r(0, "div"), u(1, "span", 11), S(2, "taxSplit"), S(3, "safe"), l()), e & 2) {
        let t = c.$implicit;
        o(), s("innerHTML", b(3, 4, b(2, 1, t.data, "amount"), "html"), A)
    }
}

function Qi(e, c) {
    if (e & 1 && (r(0, "div"), u(1, "span", 11), S(2, "taxSplit"), S(3, "safe"), l()), e & 2) {
        let t = c.$implicit;
        o(), s("innerHTML", b(3, 4, b(2, 1, t.data, "name"), "html"), A)
    }
}

function Vi(e, c) {
    if (e & 1 && (r(0, "div"), u(1, "app-service-name", 12), l()), e & 2) {
        let t = c.$implicit;
        o(), s("repairable", t.data)
    }
}

function ki(e, c) {
    if (e & 1 && (r(0, "div")(1, "h6"), x(2), l()()), e & 2) {
        let t = a(2);
        o(2), P(t.formatMessage("repair_services"))
    }
}

function Di(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 14), C("onClickEvent", function() {
            _(t);
            let i = a(3);
            return f(i.add())
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("text", t.isMobileDevice ? "" : "add_services")("isVisibleIcon", !0)
    }
}

function Ri(e, c) {
    if (e & 1 && (r(0, "div"), m(1, Di, 1, 2, "app-dx-outline-button", 13), l()), e & 2) {
        let t = a(2);
        o(), d(t.isEditMode ? 1 : -1)
    }
}

function Ai(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "i", 17), C("click", function() {
            _(t);
            let i = a().$implicit,
                p = a(2);
            return f(p.edit(i.data))
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("title", t.formatMessage("common_edit"))
    }
}

function Ni(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "i", 18), C("click", function() {
            _(t);
            let i = a().$implicit,
                p = a(2);
            return f(p.delete(i.data))
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("title", t.formatMessage("delete"))
    }
}

function Fi(e, c) {
    if (e & 1 && (r(0, "div"), m(1, Ai, 1, 1, "i", 15), m(2, Ni, 1, 1, "i", 16), l()), e & 2) {
        let t = a(2);
        o(), d(t.isEditMode && t.isEmployee ? 1 : -1), o(), d(t.isEditMode && t.isEmployee ? 2 : -1)
    }
}

function Li(e, c) {
    if (e & 1 && u(0, "dxi-total-item", 10), e & 2) {
        let t = c.$implicit;
        s("alignment", t.alignment)("column", t.column)("name", t.column)("summaryType", t.summaryType)("valueFormat", k(5, Ei))
    }
}

function Bi(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "dx-data-grid", 7), C("onContentReady", function() {
            _(t);
            let i = a();
            return f(i.onContentReady())
        })("onToolbarPreparing", function(i) {
            _(t);
            let p = a();
            return f(p.onToolbarPreparing(i))
        }), V("dataSourceChange", function(i) {
            _(t);
            let p = a();
            return Q(p.dataSource, i) || (p.dataSource = i), f(i)
        }), w(1, Ii, 4, 7, "div", 8)(2, Qi, 4, 7, "div", 8)(3, Vi, 2, 1, "div", 8)(4, ki, 3, 1, "div", 8)(5, Ri, 2, 1, "div", 8)(6, Fi, 3, 2, "div", 8), r(7, "dxo-summary", 9), J(8, Li, 1, 6, "dxi-total-item", 10, z), l()()
    }
    if (e & 2) {
        let t = a();
        I("dataSource", t.dataSource), s("columnAutoWidth", !1)("columns", t.columns)("paging", k(13, yi))("remoteOperations", k(14, Mi))("scrolling", k(15, wi)), o(), s("dxTemplateOf", "taxAmountSplitSubClassTemplate"), o(), s("dxTemplateOf", "taxSplitSubClassTemplate"), o(), s("dxTemplateOf", "serviceNameTemplate"), o(), s("dxTemplateOf", "tableHeaderTemplate"), o(), s("dxTemplateOf", "addBtnTemplate"), o(), s("dxTemplateOf", "actionTemplate"), o(), s("skipEmptyValues", !0), o(), Y(t.summaryRows)
    }
}

function ji(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-add-repairable-to-entity-popup", 19), C("repairServiceCancelClick", function() {
            _(t);
            let i = a();
            return f(i.isVisiblePopup = !1)
        })("repairServiceSaveClick", function(i) {
            _(t);
            let p = a();
            return f(p.onRepairServiceSave(i))
        }), l()
    }
    if (e & 2) {
        let t = a();
        s("isCreate", t.isCreate)("isVisiblePopup", t.isVisiblePopup)("repairableType", t.ENTITIES.QUOTATION.name)("repairable", t.repairable)
    }
}
var nt = (() => {
    class e {
        constructor() {
            this.formatMessage = h, this.ENTITIES = F, this.isEditMode = !1, this.servicesColumns = v(We).servicesColumns(), this.dataService = v(U), this.userSessionService = v(R), this.isMobileDevice = v(D).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.isLoading = !1, this.summaryRows = ft, this.isVisiblePopup = !1, this.dataSource = [], this.isCreate = !1, this.columns = []
        }
        static {
            this.autoId = 0
        }
        ngOnInit() {
            this.dataSource = this.quotation ? .repairables || [], this.columns = [...this.servicesColumns], Tt.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice), this.columns.some(t => t.cellTemplate === "actionTemplate") || this.columns.push({
                dataField: "",
                hidingPriority: 6,
                caption: "",
                width: 45,
                cellTemplate: "actionTemplate",
                visible: this.isEditMode && this.isEmployee
            })
        }
        ngOnChanges(t) {
            t.isEditMode && (this.isEditMode = t.isEditMode.currentValue, this.columns ? .length && this.columns.findIndex(n => n.cellTemplate === "actionTemplate") !== -1 && (this.columns[this.columns.length - 1].visible = this.isEditMode), !t.isEditMode.previousValue && t.isEditMode.currentValue && (this.isLoading = !0, setTimeout(() => {
                this.isLoading = !1
            })))
        }
        onToolbarPreparing(t) {
            this.isEditMode ? t.toolbarOptions.items.push({
                template: "tableHeaderTemplate",
                location: "before",
                locateInMenu: "never"
            }, {
                template: "addBtnTemplate",
                location: "after",
                locateInMenu: "never"
            }) : t.toolbarOptions.visible = !1
        }
        add() {
            this.isVisiblePopup = !0, this.isCreate = !0
        }
        edit(t) {
            this.isCreate = !1, this.repairable = t, this.isVisiblePopup = !0
        }
        onRepairServiceSave(t) {
            this.isCreate ? (t.id = ++e.autoId, this.dataSource.push(t)) : this.dataSource[this.dataSource.findIndex(n => n.id === t.id)] = t, this.isCreate = !1, this.isVisiblePopup = !1, this.repairable = null
        }
        delete(t) {
            this.dataSource = this.dataSource.filter(n => n.id !== t.id)
        }
        onContentReady() {
            let t = new Ot({
                price: this.dataGrid.instance.getTotalSummaryValue("price"),
                sub_total: this.dataGrid.instance.getTotalSummaryValue("sub_total"),
                discount: this.dataGrid.instance.getTotalSummaryValue("discount"),
                tax_amount: this.dataGrid.instance.getTotalSummaryValue("tax_amount"),
                line_total: this.dataGrid.instance.getTotalSummaryValue("line_total")
            });
            this.dataService.currentQuotationServiceTotalSource.next(t)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || e)
            }
        }
        static {
            this.\u0275cmp = M({
                type: e,
                selectors: [
                    ["app-quotation-service"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && $(j, 5), n & 2) {
                        let p;
                        G(p = W()) && (i.dataGrid = p.first)
                    }
                },
                inputs: {
                    quotation: "quotation",
                    isEditMode: "isEditMode"
                },
                standalone: !1,
                features: [rt],
                decls: 8,
                vars: 4,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "print"],
                    [3, "columns", "rows"],
                    [1, "no-print"],
                    ["id", "serviceGrid", "keyExpr", "id", 3, "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [3, "isCreate", "isVisiblePopup", "repairableType", "repairable"],
                    ["id", "serviceGrid", "keyExpr", "id", 3, "onContentReady", "onToolbarPreparing", "dataSourceChange", "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "skipEmptyValues"],
                    ["displayFormat", "{0}", 3, "alignment", "column", "name", "summaryType", "valueFormat"],
                    [1, "tax-split", 3, "innerHTML"],
                    [3, "repairable"],
                    ["buttonType", "default", "icon", "fa-thin fa-plus", 1, "float-end", 3, "text", "isVisibleIcon"],
                    ["buttonType", "default", "icon", "fa-thin fa-plus", 1, "float-end", 3, "onClickEvent", "text", "isVisibleIcon"],
                    [1, "fa-thin", "fa-pencil", "me-2", 3, "title"],
                    [1, "fa-thin", "fa-trash", 3, "title"],
                    [1, "fa-thin", "fa-pencil", "me-2", 3, "click", "title"],
                    [1, "fa-thin", "fa-trash", 3, "click", "title"],
                    [3, "repairServiceCancelClick", "repairServiceSaveClick", "isCreate", "isVisiblePopup", "repairableType", "repairable"]
                ],
                template: function(n, i) {
                    n & 1 && (r(0, "div", 0)(1, "div", 1), m(2, Oi, 2, 1, "h5"), r(3, "div", 2), m(4, qi, 1, 2, "app-print-table", 3), l(), r(5, "div", 4), m(6, Bi, 10, 16, "dx-data-grid", 5), l()()(), m(7, ji, 1, 4, "app-add-repairable-to-entity-popup", 6)), n & 2 && (o(2), d(i.isEditMode ? -1 : 2), o(2), d(i.dataSource.length ? 4 : -1), o(2), d(i.isLoading ? -1 : 6), o(), d(i.isVisiblePopup ? 7 : -1))
                },
                dependencies: [Re, tt, Qe, B, L, j, vt, xt, Z, It],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return e
})();

function en(e, c) {
    e & 1 && u(0, "app-skeleton-loader", 2), e & 2 && s("rows", 8)("columns", 3)
}

function nn(e, c) {
    if (e & 1 && (r(0, "small", 9), x(1), l()), e & 2) {
        let t = a(2);
        o(), P(t.formatMessage("rev-") + (t.quotation == null ? null : t.quotation.revision))
    }
}

function on(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-save-cancel-footer", 28), C("cancelClick", function() {
            _(t);
            let i = a(4);
            return f(i.cancel())
        }), l()
    }
    if (e & 2) {
        let t = a(4);
        s("isOnPopup", !1)("isSaving", t.isSaving)("isVisibleHr", !1)("saveText", t.quotation != null && t.quotation.id ? "common_update" : "common_create")("savingText", t.quotation != null && t.quotation.id ? "common_updating" : "common_creating")
    }
}

function an(e, c) {
    if (e & 1 && w(0, on, 1, 5, "app-save-cancel-footer", 27), e & 2) {
        let t = a(3);
        s("ngxPermissionsOnly", t.PERMISSION_LIST.QUOTATION_WRITE)
    }
}

function rn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 32), C("onClickEvent", function() {
            _(t);
            let i = a(5);
            return f(i.setEditMode())
        }), l()
    }
}

function sn(e, c) {
    if (e & 1 && w(0, rn, 1, 0, "app-dx-outline-button", 31), e & 2) {
        let t = a(4);
        s("ngxPermissionsOnly", t.PERMISSION_LIST.QUOTATION_WRITE)
    }
}

function ln(e, c) {
    if (e & 1 && (u(0, "app-location-back", 29), m(1, sn, 1, 1, "app-dx-outline-button", 30)), e & 2) {
        let t = a(3);
        o(), d(t.userPermissionList.includes(t.PERMISSION_LIST.QUOTATION_WRITE) ? 1 : -1)
    }
}

function cn(e, c) {
    if (e & 1 && (r(0, "div", 7)(1, "div", 25), m(2, an, 1, 1, "app-save-cancel-footer", 26), m(3, ln, 2, 1), l()()), e & 2) {
        let t = a(2);
        o(2), d(!t.isMobileDevice && t.isEditMode ? 2 : -1), o(), d(t.isEditMode ? -1 : 3)
    }
}

function pn(e, c) {
    if (e & 1 && u(0, "app-server-error", 10), e & 2) {
        let t = a(2);
        s("errorResponse", t.errorResponse)
    }
}

function mn(e, c) {
    if (e & 1 && (r(0, "p", 11), x(1), l()), e & 2) {
        let t = a(2);
        o(), E(" ", t.formatMessage("add_at_least_one_part"))
    }
}

function dn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-save-cancel-footer", 28), C("cancelClick", function() {
            _(t);
            let i = a(3);
            return f(i.cancel())
        }), l()
    }
    if (e & 2) {
        let t = a(3);
        s("isOnPopup", !0)("isSaving", t.isSaving)("isVisibleHr", !1)("saveText", t.quotation != null && t.quotation.id ? "common_update" : "common_create")("savingText", t.quotation != null && t.quotation.id ? "common_updating" : "common_creating")
    }
}

function un(e, c) {
    if (e & 1 && (r(0, "div", 24), w(1, dn, 1, 5, "app-save-cancel-footer", 27), l()), e & 2) {
        let t = a(2);
        o(), s("ngxPermissionsOnly", t.PERMISSION_LIST.QUOTATION_WRITE)
    }
}

function _n(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "form", 6), C("ngSubmit", function() {
            _(t);
            let i = a();
            return f(i.save())
        }), r(1, "div", 0)(2, "div", 7)(3, "h3", 8), x(4), m(5, nn, 2, 1, "small", 9), l()(), m(6, cn, 4, 2, "div", 7), l(), m(7, pn, 1, 1, "app-server-error", 10), m(8, mn, 2, 1, "p", 11), u(9, "app-section-title", 12), r(10, "div", 0)(11, "app-control-container", 13)(12, "app-customer-dropdown", 14), C("itemClick", function(i) {
            _(t);
            let p = a();
            return f(p.onCustomerSelect(i))
        }), l()(), r(13, "app-control-container", 15), u(14, "dx-date-box", 16), l(), u(15, "app-show-custom-fields", 17), l(), u(16, "app-quotation-service", 18)(17, "app-quotation-part", 18)(18, "app-summary-table", 19), r(19, "app-edit-input", 20), C("viewData", function(i) {
            _(t);
            let p = a();
            return f(p.onSaveData(i))
        }), l(), r(20, "div", 21)(21, "app-control-container", 22), u(22, "app-textarea", 23), l()(), m(23, un, 2, 1, "div", 24), l()
    }
    if (e & 2) {
        let t, n = a();
        s("formGroup", n.form), o(4), N(" ", n.formatMessage("quotation_name"), " : ", n.form.getRawValue().quotation_number), o(), d((n.quotation == null ? null : n.quotation.revision) > 0 ? 5 : -1), o(), d(n.isEmployee ? 6 : -1), o(), d(n.errorResponse ? 7 : -1), o(), d(n.atleastOneServicePartErrorMessage ? 8 : -1), o(), s("title", n.formatMessage("common_customer_information")), o(2), s("errorMsg", n.formatMessage("common_error_messages_customer_name_required"))("label", n.formatMessage("user_customer_name")), o(), s("customerId", n.form.getRawValue().id ? (t = n.form.getRawValue()) == null ? null : t.user_id : null)("formControl", n.form.controls.user_id)("isEditMode", n.isEditMode)("isVisibleAddAction", !0), o(), s("errorMsg", n.formatMessage("expiry_date_is_a_required_field"))("label", n.formatMessage("expired_on")), o(), s("min", n.today)("pickerType", n.isMobileDevice ? "rollers" : "calendar")("placeholder", n.formatMessage("select_expiry_date")), o(), s("formType", n.FORM_TYPE_LIST.QUOTATION)("form", n.form), o(), s("isEditMode", n.isEditMode)("quotation", n.quotation), o(), s("isEditMode", n.isEditMode)("quotation", n.quotation), o(), s("grandTotal", n.partSum.line_total + n.serviceSum.line_total)("taxAmount", n.partSum.tax_amount + n.serviceSum.tax_amount)("totalAmount", n.partSum.sub_total + n.serviceSum.sub_total), o(), s("isEditMode", n.isEditMode)("noteData", n.noteData), o(2), s("errorMsg", n.formatMessage("common_error_messages_terms_required"))("label", n.formatMessage("common_terms_and_conditions")), o(2), d(n.isMobileDevice && n.isEditMode ? 23 : -1)
    }
}

function fn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "form", 35), C("ngSubmit", function() {
            _(t);
            let i = a(2);
            return f(i.createOrUpdate())
        }), r(1, "dx-scroll-view", 36)(2, "p"), x(3), l(), r(4, "app-control-container", 37)(5, "app-quick-reply-dropdown", 38), C("itemClick", function(i) {
            _(t);
            let p = a(2);
            return f(p.quickReplyValue(i))
        }), l(), u(6, "app-textarea", 39), l(), r(7, "div", 40), u(8, "app-user-notification-channel", 41), l()(), r(9, "app-save-cancel-footer", 42), C("cancelClick", function() {
            _(t);
            let i = a(2);
            return f(i.isClosingPopup())
        }), l()()
    }
    if (e & 2) {
        let t = a(2);
        s("formGroup", t.form), o(3), E(" ", t.quotation != null && t.quotation.id ? t.formatMessage("quotation_update_confirmation") : t.formatMessage("create_quotation_confirmation"), " "), o(), s("errorMsg", t.formatMessage("common_error_messages_comment_required"))("label", t.formatMessage("common_comment")), o(2), s("quickReply", t.quickReply), o(2), s("form", t.form), o(), s("isOnPopup", !0)("isSaving", t.isSaving)("saveText", t.quotation != null && t.quotation.id ? t.isMobileDevice ? "common_update" : "update_quotation" : t.isMobileDevice ? "common_create" : "create_quotation")
    }
}

function Cn(e, c) {
    if (e & 1 && (r(0, "div", 33), m(1, fn, 10, 9, "form", 34), l()), e & 2) {
        let t = a();
        o(), d(t.form ? 1 : -1)
    }
}
var Bt = (() => {
    class e {
        constructor(t, n, i, p) {
            this.service = t, this.tableSequenceNumberService = n, this.termAndConditionService = i, this.loaderService = p, this.formatMessage = h, this.routerHelperService = v(le), this.formService = v(St), this.dataService = v(U), this.router = v(K), this.generalSettingDataService = v(Pt), this.userSessionService = v(R), this.activatedRouter = v(ut), this.isMobileDevice = v(D).isMobileDevice(), this.toastNotificationService = v(Ct), this.notifDefaults = v(Vt), this.today = new Date, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.errorResponse = null, this.isCreate = !1, this.isSaving = !1, this.isEditMode = !1, this.quotation = null, this.isVisibleAddCustomerPopup = !1, this.customers = [], this.quotationId = null, this.isVisibleSaveConfirmPopup = !1, this.atleastOneServicePartErrorMessage = !1, this.PERMISSION_LIST = y, this.FORM_TYPE_LIST = ee, this.addUserOption = {
                icon: "add",
                type: "default",
                hint: "Add New Customer",
                onClick: () => {
                    this.isVisibleAddCustomerPopup = !0
                }
            }
        }
        ngOnInit() {
            this.dataService.currentQuotationPartTotal$.subscribe({
                next: t => {
                    this.partSum = t
                },
                error: t => {
                    console.error(t)
                }
            }), this.dataService.currentQuotationServiceTotal$.subscribe({
                next: t => {
                    this.serviceSum = t
                },
                error: t => {
                    console.error(t)
                }
            }), this.quotationId = +this.activatedRouter.snapshot.paramMap.get("quotation_id"), this.loaderService.show(), Ut(this.tableSequenceNumberService.getListByQuery({
                name: ne.QUOTATION.name
            }), this.termAndConditionService.getByTypeId({
                type_id: ae.QUOTATION
            }), this.quotationId ? this.service.getById(this.quotationId) : jt(new O({}))).subscribe({
                next: ([t, n, i]) => {
                    this.quotation = new O(i), this.quotation ? .id ? (this.form = O.getForm(this.quotation), this.selectedUser = this.quotation.user, this.noteData = this.quotation.note, this.isEditMode = !1, this.form.disable()) : (this.form = O.getForm(new O({
                        quotation_number: t[0].current_value,
                        term_and_condition: n ? .text ? ? "",
                        auto_round_off: this.generalSettingDataService.getGeneralSettingByKey(ie.GENERAL_SETTINGS.AUTO_ROUND_OFF) ? ? !1
                    }), this.notifDefaults.getEntityDefaults(X.QUOTATION)), this.isEditMode = !0), this.form.get("user_id").valueChanges.subscribe({
                        next: p => {
                            this.selectedUser = this.customers.find(T => T.id === p)
                        },
                        error: p => {
                            console.error(p)
                        }
                    })
                },
                error: t => {
                    console.error(t)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        save() {
            this.errorResponse = null, this.atleastOneServicePartErrorMessage = !1, this.form.valid && this.validateAtleastOnePartOrService() ? this.showSaveConfirmationPopup() : this.formService.validateFormFields(this.form)
        }
        validateAtleastOnePartOrService() {
            return Object.keys(this.partGrid.dataGrid.dataSource).length || Object.keys(this.serviceGrid.dataGrid.dataSource).length ? !0 : (this.atleastOneServicePartErrorMessage = !0, !1)
        }
        onSaveData(t) {
            this.noteData = t
        }
        createOrUpdate() {
            this.form.patchValue({
                note: this.noteData
            });
            let t = this.form.getRawValue();
            t.partables = this.partGrid.dataGrid.dataSource, t.repairables = this.serviceGrid.dataGrid.dataSource, t.total_amount = this.partSum.line_total + this.serviceSum.line_total, t.tax_amount = this.partSum.tax_amount + this.serviceSum.tax_amount;
            let n = this.quotation ? .id ? this.service.update(t) : this.service.create(t);
            this.isSaving = !0, n.subscribe({
                next: i => {
                    this.quotation ? .id ? this.toastNotificationService.success("notification_quotation_update_success") : this.toastNotificationService.success("notification_quotation_add_success"), this.router.navigate([`/quotations/${i.id}/prints`])
                },
                error: i => {
                    this.errorResponse = i, this.errorResponse.error.hasOwnProperty("message") && this.toastNotificationService.error("notification_part_add_error", "", {
                        disableTimeOut: !0
                    })
                }
            }).add(() => {
                this.isSaving = !1
            })
        }
        cancel() {
            this.routerHelperService.goBack()
        }
        onCustomerSelect(t) {
            this.selectedUser = null, this.form.patchValue({
                user_id: t.id
            }), this.selectedUser = t
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        quickReplyValue(t) {
            this.quickReply = t.comment ? ? t.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        showSaveConfirmationPopup() {
            this.isVisibleSaveConfirmPopup = !0
        }
        isClosingPopup() {
            this.isVisibleSaveConfirmPopup = !1, this.form.reset()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || e)(q(et), q(Ue), q(ge), q(pe))
            }
        }
        static {
            this.\u0275cmp = M({
                type: e,
                selectors: [
                    ["app-quotation-detail"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && $(it, 5)(nt, 5), n & 2) {
                        let p;
                        G(p = W()) && (i.partGrid = p.first), G(p = W()) && (i.serviceGrid = p.first)
                    }
                },
                standalone: !1,
                decls: 6,
                vars: 8,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "float-start"],
                    [1, "text-secondary"],
                    [3, "errorResponse"],
                    [1, "text-danger"],
                    ["id", "job-basic-info-title", 1, "mt-3", 3, "title"],
                    ["name", "user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "isVisibleAddAction"],
                    ["name", "expired_at", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "expired_at", "type", "date", 3, "min", "pickerType", "placeholder"],
                    [1, "row", "d-flex", "justify-content-between", "flex-wrap", 3, "formType", "form"],
                    [3, "isEditMode", "quotation"],
                    [3, "grandTotal", "taxAmount", "totalAmount"],
                    [3, "viewData", "isEditMode", "noteData"],
                    [1, "row", "mt-3"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "cancelClick", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["id", "job-basic-info-back"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [1, "d-flex", "flex-column", "h-100"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["formControlName", "comment", 3, "quickReply"],
                    [1, "mt-3"],
                    [3, "form"],
                    [3, "cancelClick", "isOnPopup", "isSaving", "saveText"]
                ],
                template: function(n, i) {
                    n & 1 && (r(0, "div", 0)(1, "div", 1), m(2, en, 1, 2, "app-skeleton-loader", 2), m(3, _n, 24, 33, "form", 3), l()(), r(4, "dx-popup", 4), C("onHidden", function() {
                        return i.isVisibleSaveConfirmPopup = !1
                    }), V("visibleChange", function(T) {
                        return Q(i.isVisibleSaveConfirmPopup, T) || (i.isVisibleSaveConfirmPopup = T), T
                    }), w(5, Cn, 2, 1, "div", 5), l()), n & 2 && (o(2), d(!i.form && i.quotationId ? 2 : -1), o(), d(i.form ? 3 : -1), o(), I("visible", i.isVisibleSaveConfirmPopup), s("maxHeight", "90vh")("width", "95vw")("maxWidth", 550)("title", i.formatMessage("quotation_confirmation")), o(), s("dxTemplateOf", "content"))
                },
                dependencies: [Ae, qt, bt, wt, ht, Oe, Ve, kt, Et, qe, Qt, B, yt, L, we, gt, Mt, pt, lt, ct, Kt, dt, mt, te, Dt, it, nt],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return e
})();
var vn = (e, c, t) => [e, c, t],
    xn = (e, c, t) => ({
        icon: "dx-icon-file",
        title: e,
        description: c,
        primaryButtonText: "empty_state_quotation_primary_button",
        quickTips: t,
        tutorialUrl: "https://www.youtube.com/watch?v=iENDANJoEWM",
        tutorialVisible: !0,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    }),
    Ke = (() => {
        class e {
            get hasTenantQuotations() {
                return this.isEmployee ? (this.tenantService.config() ? .entity_counts ? .quotations || 0) > 0 : !0
            }
            constructor(t, n) {
                this.service = t, this.meta = n, this.formatMessage = h, this.router = v(K), this.userSessionService = v(R), this.tenantService = v(fe), this.isMobileDevice = v(D).isMobileDevice(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.columns = [], this.entity = F.QUOTATION, this.meta.addTags([{
                    name: "description",
                    content: "Create A Quotation for of laptop repair jobs"
                }, {
                    name: "keywords",
                    content: "Cloud-based CRM, Secure, Laptop, Repair, Services, Parts , Repairing-Business, Recovery, Quotations"
                }])
            }
            ngOnInit() {
                this.columns = [{
                    dataField: "quotation_number",
                    caption: h("quotation"),
                    width: 130,
                    cellTemplate: "quotationLinkTemplate",
                    allowSorting: !1,
                    alignment: "center"
                }, {
                    dataField: "quotationable_type",
                    caption: h("quotation_for"),
                    width: 130,
                    cellTemplate: "morphIdLinkTemplate",
                    hidingPriority: 6,
                    allowSorting: !1,
                    alignment: "center"
                }, {
                    dataField: "user",
                    caption: h("user_customer_name"),
                    cellTemplate: "userTemplate",
                    allowSorting: !1
                }, {
                    dataField: "approved_user.name",
                    caption: h("approved_rejected_by"),
                    hidingPriority: 5,
                    allowSorting: !1,
                    alignment: "center"
                }, {
                    dataField: "status",
                    caption: h("common_status"),
                    hidingPriority: 9,
                    cellTemplate: "quotationStatusTemplate",
                    allowSorting: !1,
                    alignment: "center"
                }, {
                    dataField: "created_user",
                    caption: h("common_created_by"),
                    hidingPriority: 4,
                    cellTemplate: "employeeTemplate",
                    allowSorting: !1,
                    alignment: "center"
                }, {
                    dataField: "revision",
                    caption: h("revision"),
                    hidingPriority: 3,
                    visible: !1,
                    allowSorting: !1,
                    alignment: "center"
                }, {
                    dataField: "tax_amount",
                    caption: h("tax_amt"),
                    hidingPriority: 2,
                    dataType: "number",
                    allowSorting: !1,
                    alignment: "center",
                    format: {
                        type: "fixedPoint",
                        precision: 2
                    }
                }, {
                    dataField: "total_amount",
                    caption: h("common_amount"),
                    hidingPriority: 7,
                    dataType: "number",
                    allowSorting: !1,
                    alignment: "center",
                    format: {
                        type: "fixedPoint",
                        precision: 2
                    }
                }, {
                    dataField: "updated_at",
                    caption: h("common_updated_on"),
                    hidingPriority: 0,
                    cellTemplate: "dateTimeTemplate",
                    visible: !1,
                    allowSorting: !0,
                    alignment: "center"
                }, {
                    dataField: "created_at",
                    caption: h("common_created_on"),
                    hidingPriority: 1,
                    cellTemplate: "dateTimeTemplate",
                    visible: !1,
                    allowSorting: !0,
                    alignment: "center"
                }, {
                    dataField: "",
                    caption: "",
                    hidingPriority: 8,
                    cellTemplate: "actionTemplate",
                    visible: this.userPermissionList.includes(y.QUOTATION_DELETE),
                    allowSorting: !1,
                    alignment: "center"
                }]
            }
            create() {
                this.router.navigate(["/quotations/add"])
            }
            edit(t) {
                this.router.navigate(["/quotations/" + t.id])
            }
            static {
                this.\u0275fac = function(n) {
                    return new(n || e)(q(et), q(Yt))
                }
            }
            static {
                this.\u0275cmp = M({
                    type: e,
                    selectors: [
                        ["app-quotation-list"]
                    ],
                    standalone: !1,
                    decls: 1,
                    vars: 19,
                    consts: [
                        [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleDownloadAction", "isVisibleEditAction", "isVisibleExportAction", "searchPanelPlaceholderText", "isVisibleReportDropdown", "service", "hasTenantData", "emptyStateConfig"]
                    ],
                    template: function(n, i) {
                        n & 1 && (r(0, "app-data-grid", 0), C("dataGridAddNewClick", function() {
                            return i.create()
                        })("dataGridEditClick", function(T) {
                            return i.edit(T)
                        }), l()), n & 2 && s("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleDownloadAction", !0)("isVisibleEditAction", !1)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("searchPanelPlaceholderText", "search_panel_quotation_placeholder")("isVisibleReportDropdown", !0)("service", i.service)("hasTenantData", i.hasTenantQuotations)("emptyStateConfig", At(15, xn, i.formatMessage("empty_state_quotation_title"), i.formatMessage("empty_state_quotation_description"), At(11, vn, i.formatMessage("empty_state_quotation_tip_1"), i.formatMessage("empty_state_quotation_tip_2"), i.formatMessage("empty_state_quotation_tip_3"))))
                    },
                    dependencies: [ke],
                    encapsulation: 2
                })
            }
        }
        return e
    })();
var Xe = e => [e],
    gn = (e, c) => [e, c];

function hn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "dx-select-box", 16), C("onItemClick", function(i) {
            _(t);
            let p = a();
            return f(p.onQuotationRevisionChange(i))
        }), V("ngModelChange", function(i) {
            _(t);
            let p = a();
            return Q(p.currentQuotationId, i) || (p.currentQuotationId = i), f(i)
        }), l()
    }
    if (e & 2) {
        let t = a();
        I("ngModel", t.currentQuotationId), s("items", t.quotationList)("searchEnabled", !1)
    }
}

function Sn(e, c) {
    if (e & 1 && u(0, "app-send-whats-app-btn", 6), e & 2) {
        let t = a();
        s("entityId", t.quotation == null ? null : t.quotation.id)("entityName", t.ENTITIES.QUOTATION.name)
    }
}

function bn(e, c) {
    if (e & 1 && u(0, "app-send-notification", 7), e & 2) {
        let t = a();
        s("entityObj", t.quotation)("entity", t.ENTITIES.STANDALONE_QUOTATION)("isVisiblePopup", !1)
    }
}

function Tn(e, c) {
    if (e & 1 && u(0, "app-job-btn", 8), e & 2) {
        let t = a();
        s("jobId", t.quotation == null ? null : t.quotation.quotationable_id)
    }
}

function Pn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 24), C("onClickEvent", function() {
            _(t);
            let i = a(2);
            return f(i.showApprovalPopupUp(!1))
        }), l()
    }
}

function yn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 25), C("onClickEvent", function() {
            _(t);
            let i = a(2);
            return f(i.showApprovalPopupUp(!0))
        }), l()
    }
}

function Mn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 26), C("onClickEvent", function() {
            _(t);
            let i = a(2);
            return f(i.convertToSle())
        }), l()
    }
}

function wn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 27), C("onClickEvent", function() {
            _(t);
            let i = a(2);
            return f(i.isVisibleRevisedConfirmationPopup = !0)
        }), l()
    }
}

function En(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-dx-outline-button", 28), C("onClickEvent", function() {
            _(t);
            let i = a(2);
            return f(i.showSaveConfirmationPopup())
        }), l()
    }
}

function On(e, c) {
    if (e & 1 && (m(0, Pn, 1, 0, "app-dx-outline-button", 17), m(1, yn, 1, 0, "app-dx-outline-button", 18), m(2, Mn, 1, 0, "app-dx-outline-button", 19), u(3, "app-print-button", 20)(4, "app-share-btn", 21), m(5, wn, 1, 0, "app-dx-outline-button", 22), m(6, En, 1, 0, "app-dx-outline-button", 23)), e & 2) {
        let t = a();
        d(Rt(10, Xe, t.quotationStatuses.AWAITING_APPROVAL).includes(t.quotation == null ? null : t.quotation.status) && t.userPermissionList.includes(t.PERMISSION_LIST.QUOTATION_APPROVE_OR_REJECT) ? 0 : -1), o(), d(Rt(12, Xe, t.quotationStatuses.AWAITING_APPROVAL).includes(t.quotation == null ? null : t.quotation.status) && t.userPermissionList.includes(t.PERMISSION_LIST.QUOTATION_APPROVE_OR_REJECT) ? 1 : -1), o(), d(t.isShowConvertToSaleOrJobBtn() ? 2 : -1), o(), s("entityId", t.quotation == null ? null : t.quotation.id)("entityName", t.ENTITIES.QUOTATION.name)("isVisiblePrintButton", !!(t.quotation != null && t.quotation.id)), o(), s("entityId", t.quotation == null ? null : t.quotation.id)("entityType", t.ENTITIES.QUOTATION.name), o(), d(t.quotation != null && t.quotation.id && t.isEmployee && t.userPermissionList.includes(t.PERMISSION_LIST.QUOTATION_WRITE) ? 5 : -1), o(), d(t.quotation.id && t.quotation.status === t.quotationStatuses.MODIFIED && t.isEmployee && t.userPermissionList.includes(t.PERMISSION_LIST.QUOTATION_WRITE) ? 6 : -1)
    }
}

function qn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-save-btn", 30), C("saveBtnClick", function() {
            _(t);
            let i = a(2);
            return f(i.showSaveConfirmationPopup())
        }), l()
    }
    if (e & 2) {
        let t = a(2);
        Gt("mt-1"), s("isSaving", t.isSaving)
    }
}

function In(e, c) {
    if (e & 1 && m(0, qn, 1, 3, "app-save-btn", 29), e & 2) {
        let t = a();
        d(t.isEmployee && !(t.quotation != null && t.quotation.id) && t.userPermissionList.includes(t.PERMISSION_LIST.QUOTATION_WRITE) ? 0 : -1)
    }
}

function Qn(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), l()), e & 2) {
        let t = a(2);
        o(), N("", t.formatMessage("job_sheet_number"), " ", t.quotation == null || t.quotation.quotationable == null ? null : t.quotation.quotationable.job_number, " ")
    }
}

function Vn(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), r(2, "span", 32), x(3), l()()), e & 2) {
        let t = a(2);
        o(), E("", t.formatMessage("quotation_status"), ": "), o(2), P(t.quotation == null ? null : t.quotation.status)
    }
}

function kn(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), l()), e & 2) {
        let t = a(2);
        o(), N("", t.quotation.status === t.quotationStatuses.APPROVED ? t.formatMessage("approved_by") : t.formatMessage("rejected_by"), " : ", t.quotation == null || t.quotation.approved_user == null ? null : t.quotation.approved_user.name, " ")
    }
}

function Dn(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), S(2, "dateFormat"), l()), e & 2) {
        let t = a(2);
        o(), N("", t.formatMessage("approved_on"), " : ", b(2, 2, t.quotation == null ? null : t.quotation.approved_at, "datetime"), " ")
    }
}

function Rn(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), S(2, "dateFormat"), l()), e & 2) {
        let t = a(2);
        o(), N("", t.formatMessage("rejected_on"), " : ", b(2, 2, t.quotation == null ? null : t.quotation.approved_at, "datetime"), " ")
    }
}

function An(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), r(2, "span", 33), x(3), l()()), e & 2) {
        let t = a(2);
        o(), E("", t.formatMessage("quotation_status"), ": "), o(2), P(t.quotation == null ? null : t.quotation.status)
    }
}

function Nn(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1, " Quotation Status : "), r(2, "span", 34), x(3), l()()), e & 2) {
        let t = a(2);
        o(2), s("ngClass", (t.quotation == null ? null : t.quotation.status) === t.quotationStatuses.MODIFIED ? "bg-info" : "bg-warning"), o(), P(t.quotation == null ? null : t.quotation.status)
    }
}

function Fn(e, c) {
    e & 1 && u(0, "app-currency-symbol")
}

function Ln(e, c) {
    if (e & 1 && (r(0, "div", 31), x(1), l()), e & 2) {
        let t = c.$implicit;
        o(), N(" ", t.label, " : ", t.field_value, " ")
    }
}

function Bn(e, c) {
    if (e & 1 && (r(0, "div")(1, "span", 35), x(2), l(), u(3, "span", 36), S(4, "safe"), l()), e & 2) {
        let t = a(2);
        o(2), E("", t.formatMessage("quotation_comment"), ": "), o(), s("innerHTML", b(4, 2, t.quotation == null ? null : t.quotation.comment, "html"), A)
    }
}

function jn(e, c) {
    if (e & 1 && (r(0, "div")(1, "span", 35), x(2), l(), u(3, "span", 36), S(4, "safe"), l()), e & 2) {
        let t = a(2);
        o(2), E("", (t.quotation == null ? null : t.quotation.status) === t.quotationStatuses.APPROVED ? t.formatMessage("quotation_approval_comment") : t.formatMessage("quotation_rejected_comment"), " : "), o(), s("innerHTML", b(4, 2, t.quotation == null ? null : t.quotation.approval_comment, "html"), A)
    }
}

function Un(e, c) {
    if (e & 1 && (r(0, "div", 10)(1, "div", 1), m(2, Qn, 2, 2, "div", 31), r(3, "div", 31), x(4), l(), m(5, Vn, 4, 2, "div", 31), m(6, kn, 2, 2, "div", 31), m(7, Dn, 3, 5, "div", 31), m(8, Rn, 3, 5, "div", 31), m(9, An, 4, 2, "div", 31), m(10, Nn, 4, 2, "div", 31), r(11, "div", 31), x(12), m(13, Fn, 1, 0, "app-currency-symbol"), x(14), S(15, "number"), l(), J(16, Ln, 2, 2, "div", 31, z), l(), m(18, Bn, 5, 5, "div"), m(19, jn, 5, 5, "div"), l()), e & 2) {
        let t = a();
        s("ngClass", t.isMobileDevice ? "p-0" : ""), o(2), d((t.quotation == null ? null : t.quotation.quotationable_type) === t.ENTITIES.JOB.name ? 2 : -1), o(2), N("", t.formatMessage("quotation_number"), ": ", t.quotation == null ? null : t.quotation.quotation_number, " "), o(), d(t.quotation.status === t.quotationStatuses.APPROVED ? 5 : -1), o(), d(t.quotation.status === t.quotationStatuses.APPROVED || t.quotation.status === t.quotationStatuses.REJECTED ? 6 : -1), o(), d(t.quotation.status === t.quotationStatuses.APPROVED ? 7 : -1), o(), d(t.quotation.status === t.quotationStatuses.REJECTED ? 8 : -1), o(), d(t.quotation.status === t.quotationStatuses.REJECTED ? 9 : -1), o(), d((t.quotation == null ? null : t.quotation.status) !== t.quotationStatuses.APPROVED && (t.quotation == null ? null : t.quotation.status) !== t.quotationStatuses.REJECTED ? 10 : -1), o(2), E("", t.formatMessage("quotation_amount"), ": "), o(), d(t.quotation != null && t.quotation.total_amount ? 13 : -1), o(), E(" ", b(15, 15, t.quotation == null ? null : t.quotation.total_amount, "1.2-2"), " "), o(2), Y(t.quotation.custom_fields), o(2), d(t.quotation != null && t.quotation.comment ? 18 : -1), o(), d(Wt(18, gn, t.quotationStatuses.APPROVED, t.quotationStatuses.REJECTED).includes(t.quotation == null ? null : t.quotation.status) && (t.quotation != null && t.quotation.approval_comment) ? 19 : -1)
    }
}

function Gn(e, c) {
    if (e & 1 && u(0, "app-invoice-term-and-conditions", 45), e & 2) {
        let t = a(2);
        s("termAndCondition", t.quotation.term_and_condition)
    }
}

function Wn(e, c) {
    if (e & 1 && u(0, "app-invoice-signature", 47), e & 2) {
        let t = a(2);
        s("entityId", t.quotation == null ? null : t.quotation.id)("entityType", t.entityType)
    }
}

function Hn(e, c) {
    if (e & 1 && (r(0, "div", 11)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2), u(5, "app-invoice-header", 37)(6, "app-invoice-title", 38), r(7, "div", 1)(8, "div", 2), u(9, "app-invoice-customer-detail", 39), l()(), r(10, "div", 40)(11, "div", 2)(12, "h5", 41), x(13), l(), r(14, "div", 1)(15, "div"), u(16, "app-print-table"), l(), r(17, "div", 2), u(18, "app-quotation-service", 42)(19, "app-quotation-part", 42)(20, "app-summary-table", 43), l()()()(), u(21, "app-edit-input", 44), m(22, Gn, 1, 1, "app-invoice-term-and-conditions", 45), u(23, "hr", 46), m(24, Wn, 1, 2, "app-invoice-signature", 47), l()()()()()), e & 2) {
        let t = a();
        s("ngClass", t.isMobileDevice ? "p-0" : ""), o(5), s("qrCode", (t.quotation == null ? null : t.quotation.id) && (t.printSettings == null ? null : t.printSettings.qr_code) && (t.quotation == null ? null : t.quotation.qr_code)), o(), s("dateTime", t.quotation == null ? null : t.quotation.created_at)("revision", t.quotation == null ? null : t.quotation.revision)("title", t.formatMessage("quotation_name") + " : " + (t.quotation == null ? null : t.quotation.quotation_number)), o(3), s("userId", t.quotation.user_id), o(4), P(t.formatMessage("quotation_details")), o(5), s("quotation", t.quotation), o(), s("quotation", t.quotation), o(), s("grandTotal", t.partSum.line_total + t.serviceSum.line_total)("taxAmount", t.partSum.tax_amount + t.serviceSum.tax_amount)("totalAmount", t.partSum.sub_total + t.serviceSum.sub_total), o(), s("noteData", t.quotation == null ? null : t.quotation.note), o(), d(t.quotation.term_and_condition ? 22 : -1), o(2), d(t.quotation != null && t.quotation.id ? 24 : -1)
    }
}

function zn(e, c) {
    if (e & 1 && u(0, "app-user-notification-channel", 55), e & 2) {
        let t = a(3);
        s("form", t.approveRejectForm)
    }
}

function Jn(e, c) {
    if (e & 1 && u(0, "app-server-error", 56), e & 2) {
        let t = a(3);
        s("errorResponse", t.errorResponse)
    }
}

function Yn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "form", 50), C("ngSubmit", function() {
            _(t);
            let i = a(2);
            return f(i.updateQuotationApproval())
        }), r(1, "dx-scroll-view", 51)(2, "p", 35), x(3), l(), r(4, "app-control-container", 52)(5, "app-quick-reply-dropdown", 53), C("itemClick", function(i) {
            _(t);
            let p = a(2);
            return f(p.quickReplyValue(i))
        }), l(), u(6, "app-textarea", 54), l(), m(7, zn, 1, 1, "app-user-notification-channel", 55), m(8, Jn, 1, 1, "app-server-error", 56), l(), r(9, "app-save-cancel-footer", 57), C("cancelClick", function() {
            _(t);
            let i = a(2);
            return f(i.isVisibleApprovalPopup = !1)
        }), l()()
    }
    if (e & 2) {
        let t = a(2);
        s("formGroup", t.approveRejectForm), o(3), E(" ", t.isApproving ? t.formatMessage("approve_quotation_confirmation") : t.formatMessage("reject_quotation_confirmation"), " "), o(), s("errorMsg", t.formatMessage("common_error_messages_comment_required"))("label", t.formatMessage("common_comment")), o(2), s("quickReply", t.approvalComment), o(), d(t.isEmployee ? 7 : -1), o(), d(t.errorResponse ? 8 : -1), o(), s("isSaving", t.isSaving)("saveText", t.isApproving ? "approve_quotation" : "reject_quotation")("savingText", t.isApproving ? "approving" : "rejecting")
    }
}

function $n(e, c) {
    if (e & 1 && (r(0, "div", 48), m(1, Yn, 10, 10, "form", 49), l()), e & 2) {
        let t = a();
        o(), d(t.approveRejectForm ? 1 : -1)
    }
}

function Kn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "app-confirmation-popup", 58), C("confirmActionCallback", function() {
            _(t);
            let i = a();
            return f(i.reviseQuotation())
        })("rejectActionCallback", function() {
            _(t);
            let i = a();
            return f(i.isVisibleRevisedConfirmationPopup = !1)
        }), l()
    }
    if (e & 2) {
        let t = a();
        s("confirmationMessage", t.formatMessage("revise_quotation_popup_message"))
    }
}

function Xn(e, c) {
    e & 1 && u(0, "app-skeleton-loader", 59), e & 2 && s("rows", 3)("columns", 1)
}

function Zn(e, c) {
    if (e & 1) {
        let t = g();
        r(0, "form", 50), C("ngSubmit", function() {
            _(t);
            let i = a(2);
            return f(i.update())
        }), r(1, "dx-scroll-view", 51)(2, "p"), x(3), l(), r(4, "app-control-container", 60), u(5, "app-textarea", 61), l(), r(6, "div", 62), u(7, "app-user-notification-channel", 55), l()(), r(8, "app-save-cancel-footer", 63), C("cancelClick", function() {
            _(t);
            let i = a(2);
            return f(i.isVisibleSaveConfirmPopup = !1)
        }), l()()
    }
    if (e & 2) {
        let t = a(2);
        s("formGroup", t.form), o(3), P(t.formatMessage("quotation_update_confirmation")), o(), s("errorMsg", t.formatMessage("common_error_messages_comment_required"))("label", t.formatMessage("common_comment")), o(3), s("form", t.form), o(), s("isSaving", t.isSaving)("saveText", t.quotation != null && t.quotation.id ? t.isMobileDevice ? "common_update" : "update_quotation" : t.isMobileDevice ? "common_create" : "create_quotation")
    }
}

function to(e, c) {
    if (e & 1 && (r(0, "div", 48), m(1, Xn, 1, 2, "app-skeleton-loader", 59), m(2, Zn, 9, 7, "form", 49), l()), e & 2) {
        let t = a();
        o(), d(t.form ? -1 : 1), o(), d(t.form ? 2 : -1)
    }
}
var Ze = (() => {
    class e {
        constructor(t, n) {
            this.service = t, this.saleService = n, this.formatMessage = h, this.formService = v(St), this.whatsappService = v(ue), this.router = v(K), this.dataService = v(U), this.userSessionService = v(R), this.activatedRouter = v(ut), this.isMobileDevice = v(D).isMobileDevice(), this.toastNotificationService = v(Ct), this.generalSettingDataService = v(Pt), this.notifDefaults = v(Vt), this.fb = new Xt, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = F, this.quotation = null, this.quotationId = null, this.currentQuotationId = null, this.isVisibleApprovalPopup = !1, this.isApproving = !1, this.quotationList = [], this.isSaving = !1, this.approvalComment = "", this.entityType = null, this.quotationStatuses = oe, this.isVisibleRevisedConfirmationPopup = !1, this.isVisibleSaveConfirmPopup = !1, this.errorResponse = null, this.PERMISSION_LIST = y, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(re.PRINT_SETTINGS) ? ? ve.getEmptyObject()
        }
        ngOnInit() {
            this.dataService.currentQuotationPartTotal$.subscribe({
                next: t => {
                    this.partSum = t
                },
                error: t => {
                    console.error(t)
                }
            }), this.dataService.currentQuotationServiceTotal$.subscribe({
                next: t => {
                    this.serviceSum = t
                },
                error: t => {
                    console.error(t)
                }
            }), this.quotationId = this.currentQuotationId = +this.activatedRouter.snapshot.paramMap.get("quotation_id"), this.service.getById(this.currentQuotationId).subscribe({
                next: t => {
                    this.quotation = new O(t), this.initialize(), this.service.getHistory(this.quotation.quotation_number).subscribe({
                        next: n => {
                            this.quotationList = n
                        },
                        error: n => {
                            console.error(n)
                        }
                    })
                },
                error: t => {
                    console.error(t)
                }
            })
        }
        initialize() {
            this.form = O.getForm(this.quotation, this.notifDefaults.getEntityDefaults(X.QUOTATION)), this.entityType = this.quotation.quotationable_type ? this.quotation.quotationable_type : this.ENTITIES.QUOTATION.name
        }
        update() {
            this.service.submitQuotation(this.quotation.id, this.form.value).subscribe({
                next: t => {
                    this.toastNotificationService.success("notification_quotation_send_success"), this.router.navigate(["/quotations"]), this.quotation = t, this.form = O.getForm(this.quotation, this.notifDefaults.getEntityDefaults(X.QUOTATION))
                }
            })
        }
        showApprovalPopupUp(t) {
            this.isApproving = t, this.setApproveRejectForm(), this.isVisibleApprovalPopup = !0, this.approvalComment = null
        }
        setApproveRejectForm() {
            this.approveRejectForm = this.fb.group({
                comment: new ot(null),
                is_send_mail: new ot(!1),
                is_send_app: new ot(!1),
                is_send_whatsapp: new ot(!1)
            })
        }
        updateQuotationApproval() {
            this.isSaving = !0, this.errorResponse = null, this.approveRejectForm.valid ? (this.isSaving = !0, (this.isApproving ? this.service.approve(this.quotation.id, this.approveRejectForm.value) : this.service.reject(this.quotation.id, this.approveRejectForm.value)).subscribe({
                next: n => {
                    this.isApproving ? (this.toastNotificationService.success("notification_quotation_approve_success"), this.approveRejectForm.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("quotation_approved", this.quotation.id)) : (this.toastNotificationService.success("notification_quotation_reject_success"), this.approveRejectForm.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("quotation_rejected", this.quotation.id)), this.quotation = n, this.form = O.getForm(this.quotation, this.notifDefaults.getEntityDefaults(X.QUOTATION))
                },
                error: n => {
                    this.errorResponse = n
                },
                complete: () => {
                    this.isSaving = !1, this.isVisibleApprovalPopup = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        showSaveConfirmationPopup() {
            this.isVisibleSaveConfirmPopup = !0
        }
        reviseQuotation() {
            this.service.reviseQuotation(this.quotation.id).subscribe({
                next: t => {
                    this.toastNotificationService.success("notification_quotation_revision_create_success"), this.isVisibleRevisedConfirmationPopup = !1, this.router.navigate(["/quotations/" + t.id + "/details"])
                },
                error: t => {
                    console.error(t)
                }
            })
        }
        onQuotationRevisionChange(t) {
            this.currentQuotationId = t.itemData.id, this.form = null, this.service.getById(this.currentQuotationId).subscribe({
                next: n => {
                    this.quotation = new O(n), this.currentQuotationId = this.quotation.id, this.initialize()
                },
                error: n => {
                    console.error(n)
                }
            })
        }
        quickReplyValue(t) {
            this.approvalComment = t.comment ? ? t.title, this.approveRejectForm.patchValue({
                comment: this.approvalComment
            })
        }
        convertToSle() {
            let t = new Be({
                user_id: this.quotation.user_id,
                total_amount: this.quotation.total_amount,
                tax_amount: this.quotation.tax_amount,
                partables: this.quotation.partables,
                status: "Unpaid",
                is_from_quotation: !0,
                quotation_id: this.quotation ? .id
            });
            this.saleService.create(t).subscribe({
                next: n => {
                    console.log("Sale Crate From Quotation", n), this.router.navigate([`sales/${n.id}`])
                },
                error: n => {
                    console.log("ERROR While Sale Crate From Quotation", n)
                }
            })
        }
        isShowConvertToSaleOrJobBtn() {
            return this.quotation ? .repairables ? .length < 1 && this.quotation ? .quotationable_id === null && this.isEmployee && this.userPermissionList.includes(y.SALE_WRITE)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || e)(q(et), q(Le))
            }
        }
        static {
            this.\u0275cmp = M({
                type: e,
                selectors: [
                    ["app-quotation-print"]
                ],
                standalone: !1,
                decls: 20,
                vars: 23,
                consts: [
                    [1, "container-fluid", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "title-text", "float-start"],
                    [1, "print-actions-bar"],
                    ["displayExpr", "revision", "valueExpr", "id", 1, "mx-1", 3, "ngModel", "items", "searchEnabled"],
                    [3, "entityId", "entityName"],
                    [1, "ms-2", 3, "entityObj", "entity", "isVisiblePopup"],
                    [1, "ms-2", 3, "jobId"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "container-fluid", "card", "p-3", "mt-3", 3, "ngClass"],
                    ["id", "print-section", 1, "container-fluid", "mt-3", 3, "ngClass"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "minWidth", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    ["id", "revise-quotation-popup", 3, "confirmationMessage"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    ["displayExpr", "revision", "valueExpr", "id", 1, "mx-1", 3, "onItemClick", "ngModelChange", "ngModel", "items", "searchEnabled"],
                    ["buttonType", "danger", "text", "reject", 1, "ms-2"],
                    ["buttonType", "default", "text", "approve", 1, "ms-2"],
                    ["buttonType", "default", "text", "convert_to_sale", "title", "convert_to_sale", 1, "ms-2"],
                    [1, "ms-2", 3, "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["buttonType", "default", "text", "common_edit", 1, "ms-2"],
                    ["buttonType", "default", "text", "common_update", 1, "ms-2"],
                    ["buttonType", "danger", "text", "reject", 1, "ms-2", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "approve", 1, "ms-2", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "convert_to_sale", "title", "convert_to_sale", 1, "ms-2", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "common_edit", 1, "ms-2", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "common_update", 1, "ms-2", 3, "onClickEvent"],
                    ["saveText", "create_quotation", "savingText", "saving_quotation", 3, "class", "isSaving"],
                    ["saveText", "create_quotation", "savingText", "saving_quotation", 3, "saveBtnClick", "isSaving"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "fw-bold"],
                    [1, "badge", "bg-success"],
                    [1, "badge", "bg-danger"],
                    [1, "badge", 3, "ngClass"],
                    [1, "fw-bold"],
                    [3, "innerHTML"],
                    [3, "qrCode"],
                    [3, "dateTime", "revision", "title"],
                    [3, "userId"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [3, "quotation"],
                    [3, "grandTotal", "taxAmount", "totalAmount"],
                    [3, "noteData"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "d-flex", "flex-column", "h-100"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    ["name", "comment", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["height", "auto", "formControlName", "comment", 3, "quickReply"],
                    [3, "form"],
                    [3, "errorResponse"],
                    [3, "cancelClick", "isSaving", "saveText", "savingText"],
                    ["id", "revise-quotation-popup", 3, "confirmActionCallback", "rejectActionCallback", "confirmationMessage"],
                    ["type", "form", 3, "rows", "columns"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "comment"],
                    [1, "mt-3"],
                    [3, "cancelClick", "isSaving", "saveText"]
                ],
                template: function(n, i) {
                    n & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "span", 3), x(4), l()(), r(5, "div", 4), m(6, hn, 1, 3, "dx-select-box", 5), m(7, Sn, 1, 2, "app-send-whats-app-btn", 6), m(8, bn, 1, 3, "app-send-notification", 7), m(9, Tn, 1, 1, "app-job-btn", 8), m(10, On, 7, 14)(11, In, 1, 1), u(12, "div", 9), l()()(), m(13, Un, 20, 21, "div", 10), m(14, Hn, 25, 15, "div", 11), r(15, "dx-popup", 12), C("onHidden", function() {
                        return i.isVisibleApprovalPopup = !1
                    }), V("visibleChange", function(T) {
                        return Q(i.isVisibleApprovalPopup, T) || (i.isVisibleApprovalPopup = T), T
                    }), w(16, $n, 2, 1, "div", 13), l(), m(17, Kn, 1, 1, "app-confirmation-popup", 14), r(18, "dx-popup", 15), C("onHidden", function() {
                        return i.isVisibleSaveConfirmPopup = !1
                    }), V("visibleChange", function(T) {
                        return Q(i.isVisibleSaveConfirmPopup, T) || (i.isVisibleSaveConfirmPopup = T), T
                    }), w(19, to, 3, 2, "div", 13), l()), n & 2 && (s("ngClass", i.isMobileDevice ? "p-0" : ""), o(4), E(" ", i.quotation == null ? null : i.quotation.quotation_number, " "), o(2), d(i.quotationList.length > 1 ? 6 : -1), o(), d(i.isEmployee && (i.quotation != null && i.quotation.id) && i.userPermissionList.includes(i.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION) ? 7 : -1), o(), d(i.isEmployee && (i.quotation != null && i.quotation.id) ? 8 : -1), o(), d(!i.isMobileDevice && (i.quotation == null ? null : i.quotation.quotationable_type) === i.ENTITIES.JOB.name && (i.quotation != null && i.quotation.quotationable_id) ? 9 : -1), o(), d(i.quotation != null && i.quotation.id ? 10 : 11), o(3), d(i.quotation != null && i.quotation.id && i.form ? 13 : -1), o(), d(i.quotation && i.form ? 14 : -1), o(), I("visible", i.isVisibleApprovalPopup), s("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("minWidth", 350)("title", i.isApproving ? i.formatMessage("approve_quotation") : i.formatMessage("reject_quotation")), o(), s("dxTemplateOf", "content"), o(), d(i.isVisibleRevisedConfirmationPopup ? 17 : -1), o(), I("visible", i.isVisibleSaveConfirmPopup), s("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", i.formatMessage("quotation_confirmation")), o(), s("dxTemplateOf", "content"))
                },
                dependencies: [Ht, qt, me, xe, bt, de, wt, ht, he, Ne, Se, be, _e, Te, tt, kt, Pe, Et, ye, Me, Qt, Ee, B, yt, L, gt, Mt, ce, pt, lt, ct, $t, dt, mt, Dt, it, nt, zt, Z, Ce],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return e
})();
var ti = (() => {
    class e {
        constructor() {
            this.formatMessage = h
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || e)
            }
        }
        static {
            this.\u0275cmp = M({
                type: e,
                selectors: [
                    ["app-quotation"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(n, i) {
                    n & 1 && (r(0, "div", 0), u(1, "router-outlet"), l())
                },
                dependencies: [Zt],
                encapsulation: 2
            })
        }
    }
    return e
})();
var eo = [{
        path: "",
        component: ti,
        children: [{
            path: "list",
            component: Ke,
            data: {
                permissions: {
                    only: [y.QUOTATION_LIST]
                }
            },
            title: "BytePhase Quotations List"
        }, {
            path: "add",
            component: Bt,
            canActivate: [_t, se],
            data: {
                permissions: {
                    only: [y.QUOTATION_WRITE]
                }
            },
            title: "BytePhase Quotations | Add"
        }, {
            path: ":quotation_id/details",
            component: Bt,
            canActivate: [_t],
            data: {
                permissions: {
                    only: [y.QUOTATION_LIST]
                }
            },
            title: "BytePhase Quotation | Details"
        }, {
            path: ":quotation_id/prints",
            component: Ze,
            canActivate: [_t],
            data: {
                permissions: {
                    only: [y.QUOTATION_LIST]
                }
            },
            title: "BytePhase Quotation | Print"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    ei = (() => {
        class e {
            static {
                this.\u0275fac = function(n) {
                    return new(n || e)
                }
            }
            static {
                this.\u0275mod = st({
                    type: e
                })
            }
            static {
                this.\u0275inj = at({
                    imports: [Nt.forChild(eo), Nt]
                })
            }
        }
        return e
    })();
var wr = (() => {
    class e {
        static {
            this.\u0275fac = function(n) {
                return new(n || e)
            }
        }
        static {
            this.\u0275mod = st({
                type: e
            })
        }
        static {
            this.\u0275inj = at({
                imports: [Jt, je, ei, Ge]
            })
        }
    }
    return e
})();
export {
    wr as QuotationModule
};