import {
    Bc as te,
    Hb as Z,
    M as R,
    Rd as oe,
    Sc as ie,
    T as $,
    Ta as Q,
    Va as X,
    ba as w,
    ca as U,
    ce as ae,
    de as ne,
    ha as Y,
    ia as q,
    na as H,
    ph as se,
    rg as re,
    xa as J,
    xc as ee,
    ya as K
} from "./chunk-DCKGQUHB.js";
import {
    $a as F,
    Fa as o,
    Fb as O,
    Fh as g,
    Ib as b,
    Jb as V,
    Kb as C,
    Na as f,
    Oa as _,
    Rc as j,
    Sa as P,
    Tc as z,
    Vb as h,
    _a as N,
    _b as k,
    ba as y,
    ea as r,
    eb as n,
    fb as s,
    gb as m,
    gc as S,
    ha as L,
    hb as p,
    ia as D,
    ic as x,
    pd as T,
    qb as A,
    sb as d,
    sd as G,
    ub as B,
    vd as M,
    xk as c,
    zi as W
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    i as E
} from "./chunk-FBFWB55K.js";
var me = (() => {
    class e {
        constructor() {
            this.formatMessage = c, this.activatedRouter = r(T), this.userSessionService = r(w), this.isMobileDevice = r($).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.selectedTabIndex = this.activatedRouter.snapshot.firstChild ? .data.tab_index ? ? 0, this.tabs = [{
                id: 0,
                text: c("customer_ledger"),
                path: "/billings/accounting/customer-ledger",
                attrId: "customer-ledger",
                visible: this.userPermissionList.includes(g.LEDGER_LIST)
            }, {
                id: 1,
                text: c("receivable_summary"),
                path: "/billings/accounting/receivable-summary",
                attrId: "receivable-summary",
                visible: this.isEmployee && this.userPermissionList.includes(g.LEDGER_LIST)
            }], this.ENTITY_ICONS = W
        }
        selectTab(t) {
            this.selectedTabIndex = t.itemIndex
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = f({
                type: e,
                selectors: [
                    ["app-accounting"]
                ],
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    [1, "container-fluid"],
                    ["mode", "route", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "contentContainerClass", "mobileMenuTitle", "mobileMenuIcon"]
                ],
                template: function(a, i) {
                    a & 1 && (s(0, "div", 0)(1, "app-responsive-tabs", 1), d("tabChange", function(u) {
                        return i.selectTab(u)
                    }), m()()), a & 2 && (o(), n("tabs", i.tabs)("selectedIndex", i.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("contentContainerClass", i.isMobileDevice ? "mb-5" : "")("mobileMenuTitle", i.formatMessage("accounting"))("mobileMenuIcon", i.ENTITY_ICONS.LEDGER.solid))
                },
                dependencies: [re],
                encapsulation: 2
            })
        }
    }
    return e
})();
var le = (() => {
    class e {
        constructor() {
            this.activatedRoute = r(T), this.userSessionService = r(w), this.isEmployee = this.userSessionService.isEmployee(), this.customerId = null
        }
        ngOnInit() {
            if (!this.isEmployee) this.customerId = this.userSessionService.userId();
            else {
                let t = this.activatedRoute.snapshot.queryParams.customer_id;
                t && (this.customerId = +t)
            }
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = f({
                type: e,
                selectors: [
                    ["app-customer-ledger"]
                ],
                standalone: !1,
                decls: 1,
                vars: 3,
                consts: [
                    [3, "customerId", "showCustomerSelector", "showCustomerInfo"]
                ],
                template: function(a, i) {
                    a & 1 && p(0, "app-customer-ledger-view", 0), a & 2 && n("customerId", i.customerId)("showCustomerSelector", i.isEmployee)("showCustomerInfo", !0)
                },
                dependencies: [ne],
                encapsulation: 2
            })
        }
    }
    return e
})();
var de = () => [10, 20, 50];

function ue(e, l) {
    if (e & 1 && (s(0, "div")(1, "span", 18), b(2), m()()), e & 2) {
        let t = l.$implicit;
        o(2), V(t.value)
    }
}

function he(e, l) {
    if (e & 1 && (s(0, "div"), p(1, "app-currency-symbol"), b(2), S(3, "number"), m()), e & 2) {
        let t = l.$implicit;
        o(2), C(" ", x(3, 1, t.value, "1.2-2"), " ")
    }
}

function ve(e, l) {
    if (e & 1 && (s(0, "div"), p(1, "app-currency-symbol"), b(2), S(3, "number"), m()), e & 2) {
        let t = l.$implicit;
        o(2), C(" ", x(3, 1, t.value, "1.2-2"), " ")
    }
}

function fe(e, l) {
    if (e & 1 && (s(0, "div")(1, "span", 19), p(2, "app-currency-symbol"), b(3), S(4, "number"), m()()), e & 2) {
        let t = l.$implicit;
        o(), O("text-danger", t.value > 0)("text-success", t.value < 0), o(2), C(" ", x(4, 5, t.value, "1.2-2"), " ")
    }
}

function ge(e, l) {
    if (e & 1) {
        let t = A();
        s(0, "div")(1, "dx-button", 20), d("onClick", function() {
            let i = L(t).$implicit,
                v = B();
            return D(v.viewLedger(i.data))
        }), m()()
    }
}

function be(e, l) {
    e & 1 && p(0, "dx-load-indicator", 17), e & 2 && n("visible", !0)
}
var ce = (() => {
    class e {
        constructor() {
            this.formatMessage = c, this.ledgerService = r(ae), this.exportService = r(oe), this.nativeFileService = r(Z), this.toastNotificationService = r(U), this.router = r(G), this.data = [], this.totalCount = 0, this.isLoading = !1, this.searchTerm = "", this.balanceType = null, this.currentPage = 1, this.perPage = 20, this.balanceTypes = [{
                value: null,
                text: c("common_all")
            }, {
                value: "receivable",
                text: c("receivable")
            }, {
                value: "overpaid",
                text: c("overpaid")
            }], this.loadData()
        }
        loadData() {
            this.isLoading = !0;
            let t = {
                page: this.currentPage,
                per_page: this.perPage
            };
            this.searchTerm && (t.search_term = this.searchTerm), this.balanceType && (t.balance_type = this.balanceType), this.ledgerService.getReceivableSummary(t).subscribe({
                next: a => {
                    this.data = a.data, this.totalCount = a.total, this.isLoading = !1
                },
                error: () => {
                    this.isLoading = !1
                }
            })
        }
        onSearchChange(t) {
            this.searchTerm = t.value, this.currentPage = 1, this.loadData()
        }
        onBalanceTypeChange(t) {
            this.balanceType = t.value, this.currentPage = 1, this.loadData()
        }
        onPageChanged(t) {
            this.currentPage = t.component.pageIndex() + 1, this.loadData()
        }
        viewLedger(t) {
            this.router.navigate([`/customers/${t.user_id}/ledger`])
        }
        exportExcel() {
            let t = {
                entity_type: "ledger",
                type: "xlsx"
            };
            this.searchTerm && (t.search_term = this.searchTerm), this.balanceType && (t.balance_type = this.balanceType), this.exportService.exportToFile("normalExport", t).subscribe({
                next: a => E(this, null, function*() {
                    return yield this.nativeFileService.downloadFile(a.body, "receivable_summary.xlsx")
                }),
                error: a => this.toastNotificationService.error(a.message)
            })
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275cmp = f({
                type: e,
                selectors: [
                    ["app-receivable-summary"]
                ],
                standalone: !1,
                decls: 22,
                vars: 43,
                consts: [
                    [1, "d-flex", "mb-3", "gap-2", "flex-wrap", "align-items-center", "justify-content-end"],
                    [2, "width", "300px"],
                    ["mode", "search", 3, "onValueChanged", "value", "placeholder"],
                    [2, "width", "180px"],
                    ["displayExpr", "text", "valueExpr", "value", 3, "onValueChanged", "dataSource", "value", "placeholder"],
                    ["icon", "exportxlsx", "stylingMode", "outlined", 3, "onClick", "hint"],
                    ["keyExpr", "user_id", 3, "onRowClick", "dataSource", "showBorders", "columnAutoWidth", "rowAlternationEnabled", "allowColumnResizing", "showRowLines"],
                    [3, "pageSize"],
                    [3, "showPageSizeSelector", "allowedPageSizes", "showInfo"],
                    ["dataField", "name", "cellTemplate", "nameTemplate", 3, "caption", "minWidth"],
                    ["dataField", "mobile_number", 3, "caption", "width"],
                    ["dataField", "email", 3, "caption", "width", "visible"],
                    ["dataField", "total_debit", "dataType", "number", "alignment", "right", "cellTemplate", "debitTemplate", 3, "caption", "width"],
                    ["dataField", "total_credit", "dataType", "number", "alignment", "right", "cellTemplate", "creditTemplate", 3, "caption", "width"],
                    ["dataField", "balance", "dataType", "number", "alignment", "right", "cellTemplate", "balanceTemplate", "sortOrder", "desc", 3, "caption", "width"],
                    ["caption", "", "cellTemplate", "actionTemplate", "alignment", "center", 3, "width"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "visible"],
                    [1, "fw-semibold", "cursor-pointer", "text-primary"],
                    [1, "fw-bold"],
                    ["icon", "chevrondoubleright", "stylingMode", "text", "hint", "View Ledger", 3, "onClick"]
                ],
                template: function(a, i) {
                    a & 1 && (s(0, "div", 0)(1, "div", 1)(2, "dx-text-box", 2), d("onValueChanged", function(u) {
                        return i.onSearchChange(u)
                    }), m()(), s(3, "div", 3)(4, "dx-select-box", 4), d("onValueChanged", function(u) {
                        return i.onBalanceTypeChange(u)
                    }), m()(), s(5, "dx-button", 5), d("onClick", function() {
                        return i.exportExcel()
                    }), m()(), s(6, "dx-data-grid", 6), d("onRowClick", function(u) {
                        return i.viewLedger(u.data)
                    }), p(7, "dxo-paging", 7)(8, "dxo-pager", 8)(9, "dxi-column", 9)(10, "dxi-column", 10)(11, "dxi-column", 11)(12, "dxi-column", 12)(13, "dxi-column", 13)(14, "dxi-column", 14)(15, "dxi-column", 15), P(16, ue, 3, 1, "div", 16)(17, he, 4, 4, "div", 16)(18, ve, 4, 4, "div", 16)(19, fe, 5, 8, "div", 16)(20, ge, 2, 0, "div", 16), m(), N(21, be, 1, 1, "dx-load-indicator", 17)), a & 2 && (o(2), n("value", i.searchTerm)("placeholder", i.formatMessage("search_by_name_mobile_email")), o(2), n("dataSource", i.balanceTypes)("value", i.balanceType)("placeholder", i.formatMessage("balance_type")), o(), n("hint", i.formatMessage("export")), o(), n("dataSource", i.data)("showBorders", !0)("columnAutoWidth", !0)("rowAlternationEnabled", !0)("allowColumnResizing", !0)("showRowLines", !0), o(), n("pageSize", i.perPage), o(), n("showPageSizeSelector", !0)("allowedPageSizes", k(42, de))("showInfo", !0), o(), n("caption", h(i.formatMessage("common_name")))("minWidth", 150), o(), n("caption", h(i.formatMessage("common_mobile")))("width", 130), o(), n("caption", h(i.formatMessage("common_email")))("width", 200)("visible", !1), o(), n("caption", h(i.formatMessage("total_debit")))("width", 130), o(), n("caption", h(i.formatMessage("total_credit")))("width", 130), o(), n("caption", h(i.formatMessage("balance")))("width", 140), o(), n("width", 80), o(), n("dxTemplateOf", "nameTemplate"), o(), n("dxTemplateOf", "debitTemplate"), o(), n("dxTemplateOf", "creditTemplate"), o(), n("dxTemplateOf", "balanceTemplate"), o(), n("dxTemplateOf", "actionTemplate"), o(), F(i.isLoading ? 21 : -1))
                },
                dependencies: [ie, Y, q, ee, H, J, K, te, Q, X, j],
                encapsulation: 2
            })
        }
    }
    return e
})();
var ye = [{
        path: "",
        component: me,
        children: [{
            path: "customer-ledger",
            component: le,
            canActivate: [R],
            data: {
                tab_index: 0,
                permissions: {
                    only: [g.LEDGER_LIST]
                }
            },
            title: "BytePhase | Customer Ledger"
        }, {
            path: "receivable-summary",
            component: ce,
            canActivate: [R],
            data: {
                tab_index: 1,
                permissions: {
                    only: [g.LEDGER_LIST]
                }
            },
            title: "BytePhase | Receivable Summary"
        }, {
            path: "",
            redirectTo: "customer-ledger",
            pathMatch: "full"
        }]
    }],
    pe = (() => {
        class e {
            static {
                this.\u0275fac = function(a) {
                    return new(a || e)
                }
            }
            static {
                this.\u0275mod = _({
                    type: e
                })
            }
            static {
                this.\u0275inj = y({
                    imports: [M.forChild(ye), M]
                })
            }
        }
        return e
    })();
var ft = (() => {
    class e {
        static {
            this.\u0275fac = function(a) {
                return new(a || e)
            }
        }
        static {
            this.\u0275mod = _({
                type: e
            })
        }
        static {
            this.\u0275inj = y({
                imports: [z, pe, se]
            })
        }
    }
    return e
})();
export {
    ft as AccountingModule
};