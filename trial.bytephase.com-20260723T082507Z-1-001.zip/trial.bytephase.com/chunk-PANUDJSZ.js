import "./chunk-ZE4JIEWS.js";
import {
    a as g,
    b as A,
    c as x,
    d as D,
    e as M,
    f as R,
    g as E,
    h as J,
    j as O,
    k as j,
    l as P
} from "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import {
    M as e,
    Mc as y,
    kg as _,
    ph as I
} from "./chunk-DCKGQUHB.js";
import {
    Fa as S,
    Fh as n,
    Na as a,
    Oa as p,
    Tc as L,
    ba as m,
    ea as s,
    eb as h,
    fb as l,
    gb as f,
    hb as c,
    pd as b,
    qd as d,
    sb as v,
    sd as T,
    vd as u
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var B = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = a({
                type: t,
                selectors: [
                    ["app-administration"]
                ],
                standalone: !1,
                decls: 1,
                vars: 0,
                template: function(o, r) {
                    o & 1 && c(0, "router-outlet")
                },
                dependencies: [d],
                encapsulation: 2
            })
        }
    }
    return t
})();
var N = (() => {
    class t {
        constructor() {
            this.jobSettings = s(_).jobSettings(), this.router = s(T), this.activatedRouter = s(b), this.selectedTabIndex = null
        }
        selectTab(i) {
            this.selectedTabIndex = i.itemIndex, this.router.navigate([i.itemData.path])
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRouter.firstChild.snapshot.data.tab_index
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = a({
                type: t,
                selectors: [
                    ["app-job-settings"]
                ],
                standalone: !1,
                decls: 4,
                vars: 4,
                consts: [
                    [1, "container-fluid"],
                    [3, "onItemClick", "dataSource", "scrollByContent", "selectedIndex", "showNavButtons"],
                    [1, "content", "mt-1"]
                ],
                template: function(o, r) {
                    o & 1 && (l(0, "div", 0)(1, "dx-tabs", 1), v("onItemClick", function(w) {
                        return r.selectTab(w)
                    }), f(), l(2, "div", 2), c(3, "router-outlet"), f()()), o & 2 && (S(), h("dataSource", r.jobSettings)("scrollByContent", !0)("selectedIndex", r.selectedTabIndex)("showNavButtons", !0))
                },
                dependencies: [y, d],
                encapsulation: 2
            })
        }
    }
    return t
})();
var F = [{
        path: "",
        component: B,
        children: [{
            path: "",
            redirectTo: "jobSettings",
            pathMatch: "full"
        }, {
            path: "jobSettings",
            component: N,
            children: [{
                path: "",
                redirectTo: "deviceTypes",
                pathMatch: "full"
            }, {
                path: "deviceTypes",
                component: R,
                canActivate: [e],
                data: {
                    tab_index: 0,
                    permissions: {
                        only: [n.DEVICE_TYPE_LIST]
                    }
                }
            }, {
                path: "deviceBrands",
                component: x,
                canActivate: [e],
                data: {
                    tab_index: 1,
                    permissions: {
                        only: [n.DEVICE_BRAND_LIST]
                    }
                }
            }, {
                path: "deviceModels",
                component: M,
                canActivate: [e],
                data: {
                    tab_index: 2,
                    permissions: {
                        only: [n.DEVICE_MODEL_LIST]
                    }
                }
            }, {
                path: "prePostConditions",
                component: P,
                canActivate: [e],
                data: {
                    tab_index: 3,
                    permissions: {
                        only: [n.DEVICE_MODEL_LIST]
                    }
                }
            }, {
                path: "accessories",
                component: g,
                canActivate: [e],
                data: {
                    tab_index: 4,
                    permissions: {
                        only: [n.ACCESSORY_LIST]
                    }
                }
            }, {
                path: "repairServices",
                component: O,
                canActivate: [e],
                data: {
                    tab_index: 5,
                    permissions: {
                        only: [n.REPAIR_SERVICE_LIST]
                    }
                }
            }, {
                path: "statuses",
                component: J,
                canActivate: [e],
                data: {
                    tab_index: 6,
                    permissions: {
                        only: [n.JOB_STATUS_LIST]
                    }
                }
            }, {
                path: "quickReply",
                component: A,
                canActivate: [e],
                data: {
                    tab_index: 7,
                    permissions: {
                        only: [n.QUICK_REPLY_LIST]
                    }
                }
            }, {
                path: "storageLocations",
                component: j,
                canActivate: [e],
                data: {
                    tab_index: 8,
                    permissions: {
                        only: [n.STORAGE_LOCATION_LIST]
                    }
                }
            }, {
                path: "deviceColors",
                component: D,
                canActivate: [e],
                data: {
                    tab_index: 9,
                    permissions: {
                        only: [n.DEVICE_COLOR_LIST]
                    }
                }
            }, {
                path: "jobSources",
                component: E,
                canActivate: [e],
                data: {
                    tab_index: 10,
                    permissions: {
                        only: [n.JOB_STATUS_LIST]
                    }
                }
            }, {
                path: "",
                redirectTo: "deviceTypes",
                pathMatch: "full"
            }]
        }]
    }],
    k = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = p({
                    type: t
                })
            }
            static {
                this.\u0275inj = m({
                    imports: [u.forChild(F), u]
                })
            }
        }
        return t
    })();
var mo = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = p({
                type: t
            })
        }
        static {
            this.\u0275inj = m({
                imports: [L, I, k]
            })
        }
    }
    return t
})();
export {
    mo as AdministrationModule
};