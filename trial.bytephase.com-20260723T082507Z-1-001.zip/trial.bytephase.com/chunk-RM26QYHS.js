import {
    lh as c,
    ph as d
} from "./chunk-DCKGQUHB.js";
import {
    Na as r,
    Oa as i,
    Tc as a,
    ba as e,
    eb as m,
    hb as p,
    vd as n
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var l = (() => {
    class o {
        static {
            this.\u0275fac = function(t) {
                return new(t || o)
            }
        }
        static {
            this.\u0275cmp = r({
                type: o,
                selectors: [
                    ["app-permissions"]
                ],
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "pageMode"]
                ],
                template: function(t, h) {
                    t & 1 && p(0, "app-permissions-prompt", 0), t & 2 && m("pageMode", !0)
                },
                dependencies: [c],
                encapsulation: 2
            })
        }
    }
    return o
})();
var M = [{
        path: "",
        component: l,
        pathMatch: "full",
        data: {
            title: "BytePhase Permissions"
        }
    }],
    u = (() => {
        class o {
            static {
                this.\u0275fac = function(t) {
                    return new(t || o)
                }
            }
            static {
                this.\u0275mod = i({
                    type: o
                })
            }
            static {
                this.\u0275inj = e({
                    imports: [n.forChild(M), n]
                })
            }
        }
        return o
    })();
var R = (() => {
    class o {
        static {
            this.\u0275fac = function(t) {
                return new(t || o)
            }
        }
        static {
            this.\u0275mod = i({
                type: o
            })
        }
        static {
            this.\u0275inj = e({
                imports: [a, d, u]
            })
        }
    }
    return o
})();
export {
    R as PermissionsModule
};