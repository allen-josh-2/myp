import {
    aa as e,
    da as a,
    qe as r,
    ti as o,
    ui as s
} from "./chunk-GOPIAW4V.js";
var f = (() => {
    class i extends o {
        constructor(t) {
            super(t, r), this.api = t, this.endpoint = r
        }
        getWithParams(t) {
            return this.api.getWithParams(this.endpoint, t)
        }
        getAmcActivityWithParams(t) {
            return this.api.getWithParams(this.endpoint + "/getAmcActivityWithParams", t)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || i)(a(s))
            }
        }
        static {
            this.\u0275prov = e({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
export {
    f as a
};