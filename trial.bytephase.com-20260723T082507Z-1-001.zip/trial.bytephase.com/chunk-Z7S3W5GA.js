import {
    c as B
} from "./chunk-M4ULIW7S.js";
import {
    b as O
} from "./chunk-VIJPFQLN.js";
import {
    b as L,
    f as R,
    g as T,
    h as k,
    k as y
} from "./chunk-VSSNYSR2.js";
import {
    a as C
} from "./chunk-WI5MSH4N.js";
import {
    a as F,
    d as x
} from "./chunk-LD36GOMT.js";
import {
    b as E
} from "./chunk-CKP3SGE2.js";
import {
    a as g,
    e as P,
    f as _
} from "./chunk-R5YFTT7F.js";
import {
    i as f
} from "./chunk-FBFWB55K.js";
var h = '[tabindex]:not([tabindex^="-"]):not([hidden]):not([disabled]), input:not([type=hidden]):not([tabindex^="-"]):not([hidden]):not([disabled]), textarea:not([tabindex^="-"]):not([hidden]):not([disabled]), button:not([tabindex^="-"]):not([hidden]):not([disabled]), select:not([tabindex^="-"]):not([hidden]):not([disabled]), ion-checkbox:not([tabindex^="-"]):not([hidden]):not([disabled]), ion-radio:not([tabindex^="-"]):not([hidden]):not([disabled]), .ion-focusable:not([tabindex^="-"]):not([hidden]):not([disabled]), .ion-focusable[disabled="false"]:not([tabindex^="-"]):not([hidden])',
    N = (e, n) => {
        let t = e.querySelector(h);
        j(t, n ? ? e)
    },
    q = (e, n) => {
        let t = Array.from(e.querySelectorAll(h)),
            o = t.length > 0 ? t[t.length - 1] : null;
        j(o, n ? ? e)
    },
    j = (e, n) => {
        let t = e,
            o = e ? .shadowRoot;
        if (o && (t = o.querySelector(h) || e), t) {
            let s = t.closest("ion-radio-group");
            s ? s.setFocus() : y(t)
        } else n.focus()
    },
    A = 0,
    $ = 0,
    w = new WeakMap,
    S = e => {
        var n;
        return e.showBackdrop !== !1 && !(((n = e.backdropBreakpoint) !== null && n !== void 0 ? n : 0) > 0)
    },
    b = e => ({
        create(t) {
            return H(e, t)
        },
        dismiss(t, o, s) {
            return X(document, t, o, e, s)
        },
        getTop() {
            return f(this, null, function*() {
                return v(document, e)
            })
        }
    }),
    fe = b("ion-alert"),
    pe = b("ion-action-sheet");
var ge = b("ion-modal");
var ve = b("ion-popover");
var he = e => {
        typeof document < "u" && J(document);
        let n = A++;
        e.overlayIndex = n
    },
    we = e => (e.hasAttribute("id") || (e.id = `ion-overlay-${++$}`), e.id),
    H = (e, n) => typeof window < "u" && typeof window.customElements < "u" ? window.customElements.whenDefined(e).then(() => {
        let t = document.createElement(e);
        return t.classList.add("overlay-hidden"), Object.assign(t, Object.assign(Object.assign({}, n), {
            hasController: !0
        })), D(document).appendChild(t), new Promise(o => L(t, o))
    }) : Promise.resolve(),
    z = e => e.classList.contains("overlay-hidden"),
    V = (e, n) => {
        let t = e,
            o = e ? .shadowRoot;
        o && (t = o.querySelector(h) || e), t ? y(t) : n.focus()
    },
    Q = (e, n) => {
        let t = v(n, "ion-alert,ion-action-sheet,ion-loading,ion-modal,ion-picker-legacy,ion-popover"),
            o = e.target;
        if (!t || !o || t.classList.contains(se)) return;
        let s = () => {
                if (t === o) t.lastFocus = void 0;
                else if (o.tagName === "ION-TOAST") V(t.lastFocus, t);
                else {
                    let a = k(t);
                    if (!a.contains(o)) return;
                    let i = a.querySelector(".ion-overlay-wrapper");
                    if (!i) return;
                    if (i.contains(o) || o === a.querySelector("ion-backdrop")) t.lastFocus = o;
                    else {
                        let c = t.lastFocus;
                        N(i, t), c === n.activeElement && q(i, t), t.lastFocus = n.activeElement
                    }
                }
            },
            r = () => {
                if (t.contains(o)) t.lastFocus = o;
                else if (o.tagName === "ION-TOAST") V(t.lastFocus, t);
                else {
                    let a = t.lastFocus;
                    N(t), a === n.activeElement && q(t), t.lastFocus = n.activeElement
                }
            };
        t.shadowRoot ? r() : s()
    },
    J = e => {
        A === 0 && (A = 1, e.addEventListener("focus", n => {
            Q(n, e)
        }, !0), e.addEventListener("ionBackButton", n => {
            let t = v(e);
            t ? .backdropDismiss && n.detail.register(x, () => {
                t.dismiss(void 0, I)
            })
        }), F() || e.addEventListener("keydown", n => {
            if (n.key === "Escape") {
                let t = v(e);
                t ? .backdropDismiss && t.dismiss(void 0, I)
            }
        }))
    },
    X = (e, n, t, o, s) => {
        let r = v(e, o, s);
        return r ? r.dismiss(n, t) : Promise.reject("overlay does not exist")
    },
    Z = (e, n) => (n === void 0 && (n = "ion-alert,ion-action-sheet,ion-loading,ion-modal,ion-picker-legacy,ion-popover,ion-toast"), Array.from(e.querySelectorAll(n)).filter(t => t.overlayIndex > 0)),
    G = (e, n) => Z(e, n).filter(t => !z(t)),
    v = (e, n, t) => {
        let o = G(e, n);
        return (t === void 0 ? o : o.filter(s => s.id === t)).slice(-1)[0]
    },
    M = (e = !1) => {
        let t = D(document).querySelector("ion-router-outlet, #ion-view-container-root");
        t && (e ? t.setAttribute("aria-hidden", "true") : t.removeAttribute("aria-hidden"))
    },
    be = (e, n, t, o, s) => f(null, null, function*() {
        var r, a;
        if (e.presented) return;
        e.el.tagName !== "ION-TOAST" && ee(e.el);
        let i = e.el,
            d = i.tagName !== "ION-TOAST" && i.focusTrap !== !1 && S(i);
        if (e.presented = !0, e.willPresent.emit(), d) {
            let l = D(document).querySelector("ion-router-outlet, #ion-view-container-root");
            l && l.contains(i) || M(!0), document.body.classList.add(C)
        }(r = e.willPresentShorthand) === null || r === void 0 || r.emit();
        let u = O(e),
            m = e.enterAnimation ? e.enterAnimation : g.get(n, u === "ios" ? t : o);
        (yield U(e, m, e.el, s)) && (e.didPresent.emit(), (a = e.didPresentShorthand) === null || a === void 0 || a.emit()), e.keyboardClose && (document.activeElement === null || !e.el.contains(document.activeElement)) && e.el.focus(), e.el.removeAttribute("aria-hidden"), e.el.removeAttribute("inert")
    }),
    ee = e => f(null, null, function*() {
        let n = document.activeElement;
        if (!n) return;
        n.blur();
        let t = n ? .shadowRoot;
        t && (n = t.querySelector(h) || n), yield e.onDidDismiss(), (document.activeElement === null || document.activeElement === document.body) && n.focus()
    }),
    ye = (e, n, t, o, s, r, a) => f(null, null, function*() {
        var i, c;
        if (!e.presented) return !1;
        let u = (E !== void 0 ? G(E) : []).filter(l => {
                let p = l;
                return p.tagName !== "ION-TOAST" && p.focusTrap !== !1 && S(p)
            }),
            m = e.el;
        m.tagName !== "ION-TOAST" && m.focusTrap !== !1 && S(m) && u.length === 1 && u[0].id === m.id && (M(!1), document.body.classList.remove(C)), e.presented = !1;
        try {
            e.el.style.setProperty("pointer-events", "none"), e.willDismiss.emit({
                data: n,
                role: t
            }), (i = e.willDismissShorthand) === null || i === void 0 || i.emit({
                data: n,
                role: t
            });
            let l = O(e),
                p = e.leaveAnimation ? e.leaveAnimation : g.get(o, l === "ios" ? s : r);
            t !== oe && (yield U(e, p, e.el, a)), e.didDismiss.emit({
                data: n,
                role: t
            }), (c = e.didDismissShorthand) === null || c === void 0 || c.emit({
                data: n,
                role: t
            }), (w.get(e) || []).forEach(Y => Y.destroy()), w.delete(e), e.el.classList.add("overlay-hidden"), e.el.style.removeProperty("pointer-events"), e.el.lastFocus !== void 0 && (e.el.lastFocus = void 0)
        } catch (l) {
            _(`[${e.el.tagName.toLowerCase()}] - `, l)
        }
        return e.el.remove(), !0
    }),
    D = e => e.querySelector("ion-app") || e.body,
    U = (e, n, t, o) => f(null, null, function*() {
        t.classList.remove("overlay-hidden");
        let s = e.el,
            r = n(s, o);
        (!e.animated || !g.getBoolean("animated", !0)) && r.duration(0), e.keyboardClose && r.beforeAddWrite(() => {
            let i = t.ownerDocument.activeElement;
            i ? .matches("input,ion-input, ion-textarea") && i.blur()
        });
        let a = w.get(e) || [];
        return w.set(e, [...a, r]), yield r.play(), !0
    }),
    Oe = (e, n) => {
        let t, o = new Promise(s => t = s);
        return te(e, n, s => {
            t(s.detail)
        }), o
    },
    te = (e, n, t) => {
        let o = s => {
            T(e, n, o), t(s)
        };
        R(e, n, o)
    },
    Ee = e => e === "cancel" || e === I,
    ne = e => e(),
    Ce = (e, n) => {
        if (typeof e == "function") return g.get("_zoneGate", ne)(() => {
            try {
                return e(n)
            } catch (o) {
                throw o
            }
        })
    },
    I = "backdrop",
    oe = "gesture",
    Ae = 39,
    Se = e => {
        let n = !1,
            t, o = B(),
            s = (i = !1) => {
                if (t && !i) return {
                    delegate: t,
                    inline: n
                };
                let {
                    el: c,
                    hasController: d,
                    delegate: u
                } = e;
                return n = c.parentNode !== null && !d, t = n ? u || o : u, {
                    inline: n,
                    delegate: t
                }
            };
        return {
            attachViewToDom: i => f(null, null, function*() {
                let {
                    delegate: c
                } = s(!0);
                if (c) return yield c.attachViewToDom(e.el, i);
                let {
                    hasController: d
                } = e;
                if (d && i !== void 0) throw new Error("framework delegate is missing");
                return null
            }),
            removeViewFromDom: () => {
                let {
                    delegate: i
                } = s();
                i && e.el !== void 0 && i.removeViewFromDom(e.el.parentElement, e.el)
            }
        }
    },
    Ie = () => {
        let e, n = () => {
            e && (e(), e = void 0)
        };
        return {
            addClickListener: (o, s) => {
                n();
                let r = s !== void 0 ? document.getElementById(s) : null;
                if (!r) {
                    P(`[${o.tagName.toLowerCase()}] - A trigger element with the ID "${s}" was not found in the DOM. The trigger element must be in the DOM when the "trigger" property is set on an overlay component.`, o);
                    return
                }
                e = ((i, c) => {
                    let d = () => {
                        c.present()
                    };
                    return i.addEventListener("click", d), () => {
                        i.removeEventListener("click", d)
                    }
                })(r, o)
            },
            removeClickListener: n
        }
    },
    se = "ion-disable-focus-trap";
export {
    N as a, q as b, fe as c, pe as d, ge as e, ve as f, he as g, we as h, v as i, be as j, ye as k, Oe as l, Ee as m, Ce as n, I as o, oe as p, Ae as q, Se as r, Ie as s, se as t
};