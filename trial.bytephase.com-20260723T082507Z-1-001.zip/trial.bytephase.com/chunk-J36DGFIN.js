import {
    b as G
} from "./chunk-PGAHHPJ5.js";
import {
    O as ce,
    T as le,
    V as ge,
    aa as ue,
    ab as j,
    ha as K,
    ia as N,
    lb as he,
    ph as _e
} from "./chunk-DCKGQUHB.js";
import {
    $a as k,
    Eb as E,
    Fa as s,
    Fb as T,
    Hb as S,
    Ib as r,
    Jb as w,
    Kb as p,
    Lb as Y,
    Mb as oe,
    Na as y,
    Nb as re,
    Oa as se,
    Pb as B,
    Qb as A,
    Qg as J,
    Rb as F,
    Rg as pe,
    Sa as H,
    Vb as U,
    Wb as O,
    X as $,
    Xa as W,
    _a as v,
    _b as de,
    aa as ee,
    ba as te,
    bb as ae,
    cb as I,
    db as D,
    ea as x,
    eb as g,
    fb as a,
    gb as o,
    ha as f,
    hb as l,
    ia as C,
    ja as ie,
    ka as ne,
    mc as _,
    n as Z,
    ne as X,
    oa as P,
    qa as R,
    qb as M,
    sa as L,
    sb as m,
    ub as d,
    ui as me,
    xk as u
} from "./chunk-GOPIAW4V.js";
var xe = (() => {
    class t {
        constructor() {
            this.percentage = 0, this.color = "primary", this.size = 40, this.Math = Math
        }
        get radius() {
            return (this.size - 4) / 2
        }
        get circumference() {
            return 2 * Math.PI * this.radius
        }
        get strokeDashoffset() {
            return this.circumference - this.percentage / 100 * this.circumference
        }
        get viewBox() {
            return `0 0 ${this.size} ${this.size}`
        }
        get center() {
            return this.size / 2
        }
        get colorClass() {
            switch (this.color) {
                case "success":
                    return "text-success";
                case "warning":
                    return "text-warning";
                case "danger":
                    return "text-danger";
                default:
                    return "text-primary"
            }
        }
        get strokeColor() {
            switch (this.color) {
                case "success":
                    return "#198754";
                case "warning":
                    return "#ffc107";
                case "danger":
                    return "#dc3545";
                default:
                    return "#3498db"
            }
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-progress-badge"]
                ],
                inputs: {
                    percentage: "percentage",
                    color: "color",
                    size: "size"
                },
                standalone: !1,
                decls: 6,
                vars: 17,
                consts: [
                    [1, "progress-badge"],
                    [1, "progress-ring"],
                    ["fill", "transparent", "stroke", "#e9ecef", "stroke-width", "3", 1, "progress-ring-bg"],
                    ["fill", "transparent", "stroke-width", "3", 1, "progress-ring-circle"],
                    [1, "progress-badge-text"]
                ],
                template: function(n, i) {
                    n & 1 && (a(0, "div", 0), ie(), a(1, "svg", 1), l(2, "circle", 2)(3, "circle", 3), o(), ne(), a(4, "div", 4), r(5), o()()), n & 2 && (E("width", i.size, "px")("height", i.size, "px"), s(), W("viewBox", i.viewBox), s(), W("cx", i.center)("cy", i.center)("r", i.radius), s(), W("cx", i.center)("cy", i.center)("r", i.radius)("stroke", i.strokeColor)("stroke-dasharray", i.circumference)("stroke-dashoffset", i.strokeDashoffset), s(), S(i.colorClass), s(), p(" ", i.Math.round(i.percentage), "% "))
                },
                styles: ["[_nghost-%COMP%]{display:inline-block}.progress-badge[_ngcontent-%COMP%]{position:relative;display:flex;align-items:center;justify-content:center}.progress-ring[_ngcontent-%COMP%]{transform:rotate(-90deg);width:100%;height:100%}.progress-ring-circle[_ngcontent-%COMP%]{transition:stroke-dashoffset .3s ease;stroke-linecap:round}.progress-badge-text[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:1rem;font-weight:600;line-height:1;color:var(--primary-text)}"]
            })
        }
    }
    return t
})();
var z = (() => {
    class t {
        getCacheKey() {
            let e = this.storageService.getTenantId();
            return `${this.CACHE_KEY_PREFIX}${e}`
        }
        getSettingsBannerDismissedKey() {
            let e = this.storageService.getTenantId();
            return `${this.SETTINGS_BANNER_DISMISSED_KEY_PREFIX}${e}`
        }
        constructor() {
            this.apiService = x(me), this.storageService = x(ge), this.CACHE_KEY_PREFIX = "business_readiness_progress_", this.SETTINGS_BANNER_DISMISSED_KEY_PREFIX = "business_readiness_settings_dismissed_", this.CACHE_TTL_MS = 30 * 1e3, this.progressData = R(null), this.settingsBannerDismissed = R(this.readSettingsBannerDismissed()), this.summary = _(() => this.progressData() ? .summary ? ? null), this.score = _(() => this.summary() ? .score ? ? 0), this.completedTasks = _(() => this.summary() ? .completed_tasks ? ? 0), this.totalTasks = _(() => this.summary() ? .total_tasks ? ? 20), this.isRewardUnlocked = _(() => this.summary() ? .reward_unlocked ? ? !1), this.isRewardClaimed = _(() => this.summary() ? .reward_claimed ? ? !1), this.isCompleted = _(() => this.summary() ? .is_completed ? ? !1), this.rewardType = _(() => this.summary() ? .reward_type ? ? null), this.categoryProgress = _(() => this.progressData() ? .category_progress ? ? {}), this.tasks = _(() => this.progressData() ? .tasks ? ? {}), this.suggestedNext = _(() => this.progressData() ? .suggested_next ? ? null), this.scoreDisplay = _(() => `${Math.round(this.score())}%`), this.progressPercentage = _(() => this.summary() ? .progress_percentage ? ? 0), this.progressColor = _(() => this.summary() ? .progress_color ? ? "danger"), this.shouldShowInSidebar = _(() => this.score() <= 80 && !this.isCompleted()), this.shouldShowInSettings = _(() => this.score() > 80 && !this.isCompleted() && !this.settingsBannerDismissed()), this.loadFromCache()
        }
        readSettingsBannerDismissed() {
            try {
                return localStorage.getItem(this.getSettingsBannerDismissedKey()) === "true"
            } catch (e) {
                return !1
            }
        }
        dismissSettingsBanner() {
            try {
                localStorage.setItem(this.getSettingsBannerDismissedKey(), "true")
            } catch (e) {}
            this.settingsBannerDismissed.set(!0)
        }
        loadFromCache() {
            try {
                let e = this.getCacheKey(),
                    n = localStorage.getItem(e);
                if (n) {
                    let i = JSON.parse(n);
                    this.isCacheValid(i.timestamp) && this.progressData.set(i.data)
                }
            } catch (e) {
                this.clearCache()
            }
        }
        saveToCache(e) {
            try {
                let n = {
                    data: e,
                    timestamp: Date.now()
                };
                localStorage.setItem(this.getCacheKey(), JSON.stringify(n))
            } catch (n) {}
        }
        isCacheValid(e) {
            return Date.now() - e < this.CACHE_TTL_MS
        }
        hasValidCache() {
            try {
                let e = localStorage.getItem(this.getCacheKey());
                if (e) {
                    let n = JSON.parse(e);
                    return this.isCacheValid(n.timestamp)
                }
            } catch (e) {}
            return !1
        }
        clearCache() {
            try {
                localStorage.removeItem(this.getCacheKey())
            } catch (e) {}
        }
        fetchProgress(e = !1) {
            return !e && this.hasValidCache() && this.progressData() ? Z({
                data: this.progressData()
            }) : this.apiService.get(`${X}/progress`).pipe($(n => {
                n ? .data && (this.progressData.set(n.data), this.saveToCache(n.data))
            }))
        }
        claimReward(e) {
            let n = {
                reward_type: e
            };
            return this.apiService.post(`${X}/claim-reward`, n).pipe($(() => {
                this.clearCache(), this.fetchProgress(!0).subscribe()
            }))
        }
        recalculateScore() {
            return this.apiService.post(`${X}/recalculate`, {}).pipe($(() => {
                this.clearCache(), this.fetchProgress(!0).subscribe()
            }))
        }
        getTasksByCategory(e) {
            return this.tasks()[e] ? ? []
        }
        getCategoryProgress(e) {
            return this.categoryProgress()[e] ? ? null
        }
        isTaskCompleted(e) {
            return Object.values(this.tasks()).flat().find(h => h.code === e) ? .is_completed ? ? !1
        }
        getSuggestedNextTask() {
            let e = this.suggestedNext();
            return e ? Object.values(this.tasks()).flat().find(i => i.code === e) ? ? null : null
        }
        resetState() {
            this.progressData.set(null), this.clearCache()
        }
        invalidateAndRefresh() {
            this.clearCache(), this.fetchProgress(!0).subscribe()
        }
        markTaskActionStarted() {
            this.clearCache();
            try {
                localStorage.setItem(`${this.CACHE_KEY_PREFIX}action_started`, Date.now().toString())
            } catch (e) {}
        }
        checkPendingRefresh() {
            try {
                if (localStorage.getItem(`${this.CACHE_KEY_PREFIX}action_started`)) return localStorage.removeItem(`${this.CACHE_KEY_PREFIX}action_started`), !0
            } catch (e) {}
            return !1
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275prov = ee({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function Se(t, c) {
    t & 1 && l(0, "i", 3)
}

function Pe(t, c) {
    t & 1 && l(0, "i", 4)
}

function Te(t, c) {
    if (t & 1 && (a(0, "span", 9), r(1), o()), t & 2) {
        let e = d();
        s(), w(e.formatMessage("suggested_next"))
    }
}

function Oe(t, c) {
    if (t & 1 && (a(0, "span", 14), l(1, "i", 17), r(2), o()), t & 2) {
        let e = d();
        s(2), p(" ", e.formatMessage("completed"), " ")
    }
}

function Ee(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "button", 18), m("click", function() {
            f(e);
            let i = d();
            return C(i.onActionClick())
        }), r(1), l(2, "i", 19), o()
    }
    if (t & 2) {
        let e = d();
        s(), p(" ", e.formatMessage("start"), " ")
    }
}

function Re(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "button", 20), m("click", function() {
            f(e);
            let i = d();
            return C(i.onShowMeHow())
        }), l(1, "i", 21), r(2), o()
    }
    if (t & 2) {
        let e = d();
        s(2), p("", e.formatMessage("show_me_how"), " ")
    }
}
var fe = (() => {
    class t {
        constructor() {
            this.isSuggestedNext = !1, this.actionStarted = new P, this.routerHelper = x(ue), this.businessReadinessService = x(z), this.guidedTourService = x(G), this.formatMessage = u
        }
        get canTakeAction() {
            return !this.task.is_completed && !!this.task.action_target
        }
        get hasTour() {
            return this.guidedTourService.hasTourForTask(this.task.code)
        }
        get actionButtonText() {
            return this.task.is_completed ? u("completed") : u("start")
        }
        onActionClick() {
            this.canTakeAction && (this.businessReadinessService.markTaskActionStarted(), this.task.action_type === "navigate" && this.task.action_target ? (this.actionStarted.emit(), this.routerHelper.navigateWithReload(this.task.action_target)) : this.task.action_type === "modal" && this.task.action_target && (this.actionStarted.emit(), console.log("Modal action:", this.task.action_target)))
        }
        onShowMeHow() {
            this.actionStarted.emit(), this.guidedTourService.startTaskTour(this.task.code)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-task-item"]
                ],
                inputs: {
                    task: "task",
                    isSuggestedNext: "isSuggestedNext"
                },
                outputs: {
                    actionStarted: "actionStarted"
                },
                standalone: !1,
                decls: 21,
                vars: 17,
                consts: [
                    [1, "task-item"],
                    [1, "task-item-content"],
                    [1, "task-item-checkbox"],
                    [1, "fas", "fa-check-circle", "text-success"],
                    [1, "far", "fa-circle", "text-muted"],
                    [1, "task-item-details"],
                    [1, "task-item-header"],
                    [1, "task-item-title"],
                    [1, "badge", "bg-info", "text-white", "ms-2", 2, "font-size", "0.75rem"],
                    [1, "badge", "bg-primary", "ms-2"],
                    [1, "task-item-time", "text-muted"],
                    [1, "far", "fa-clock", "me-1"],
                    [1, "task-item-description", "text-muted", "mb-0"],
                    [1, "task-item-action", "d-flex", "flex-column", "align-items-end", "gap-1"],
                    [1, "badge", "bg-success"],
                    ["type", "button", 1, "btn", "btn-sm", "btn-primary"],
                    ["type", "button", 1, "btn", "btn-sm", "btn-link", "p-0", "text-decoration-none"],
                    [1, "fas", "fa-check", "me-1"],
                    ["type", "button", 1, "btn", "btn-sm", "btn-primary", 3, "click"],
                    [1, "fas", "fa-arrow-right", "ms-1"],
                    ["type", "button", 1, "btn", "btn-sm", "btn-link", "p-0", "text-decoration-none", 3, "click"],
                    [1, "fas", "fa-circle-play", "me-1"]
                ],
                template: function(n, i) {
                    n & 1 && (a(0, "div", 0)(1, "div", 1)(2, "div", 2), v(3, Se, 1, 0, "i", 3)(4, Pe, 1, 0, "i", 4), o(), a(5, "div", 5)(6, "div", 6)(7, "h6", 7), r(8), a(9, "span", 8), r(10), o(), v(11, Te, 2, 1, "span", 9), o(), a(12, "span", 10), l(13, "i", 11), r(14), o()(), a(15, "p", 12), r(16), o()(), a(17, "div", 13), v(18, Oe, 3, 1, "span", 14)(19, Ee, 3, 1, "button", 15), v(20, Re, 3, 1, "button", 16), o()()()), n & 2 && (T("task-item-completed", i.task.is_completed)("task-item-suggested", i.isSuggestedNext), s(3), k(i.task.is_completed ? 3 : 4), s(4), T("text-decoration-line-through", i.task.is_completed), s(), p(" ", i.task.title, " "), s(2), p("", i.task.weight, "%"), s(), k(i.isSuggestedNext ? 11 : -1), s(3), Y(" ", i.task.estimated_minutes, " ", i.formatMessage("minutes"), " "), s(), T("text-decoration-line-through", i.task.is_completed), s(), p(" ", i.task.description, " "), s(2), k(i.task.is_completed ? 18 : i.canTakeAction ? 19 : -1), s(2), k(i.hasTour ? 20 : -1))
                },
                styles: [".task-item[_ngcontent-%COMP%]{padding:12px 16px;margin-bottom:8px;border-radius:8px;background:var(--primary-bg);border:1px solid var(--theme-border-color);transition:all .2s ease}@media(max-width:768px){.task-item[_ngcontent-%COMP%]{padding:10px 12px;margin-bottom:6px;border-radius:6px}}.task-item[_ngcontent-%COMP%]:hover{background:var(--bg-secondary)}.task-item.task-item-suggested[_ngcontent-%COMP%]{border-color:#3498db;border-width:2px;box-shadow:0 0 0 3px #3498db1a}.task-item.task-item-completed[_ngcontent-%COMP%]{opacity:.7}.task-item-content[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px}@media(max-width:768px){.task-item-content[_ngcontent-%COMP%]{gap:10px;flex-wrap:wrap}}.task-item-checkbox[_ngcontent-%COMP%]{flex-shrink:0;font-size:20px;margin-top:2px}@media(max-width:768px){.task-item-checkbox[_ngcontent-%COMP%]{font-size:18px}}.task-item-details[_ngcontent-%COMP%]{flex:1;min-width:0}@media(max-width:768px){.task-item-details[_ngcontent-%COMP%]{flex:1 1 100%}}.task-item-header[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:4px}@media(max-width:768px){.task-item-header[_ngcontent-%COMP%]{flex-direction:column;gap:4px}}.task-item-title[_ngcontent-%COMP%]{font-size:14px;font-weight:600;margin:0;flex:1;min-width:0;color:var(--primary-text);line-height:1.4}@media(max-width:768px){.task-item-title[_ngcontent-%COMP%]{font-size:13px}}@media(max-width:768px){.task-item-title[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%]{font-size:10px;padding:2px 6px}}.task-item-title[_ngcontent-%COMP%]   .badge.bg-info[_ngcontent-%COMP%]{font-weight:600;padding:3px 8px;border-radius:4px}@media(max-width:768px){.task-item-title[_ngcontent-%COMP%]   .badge.bg-info[_ngcontent-%COMP%]{padding:2px 6px;font-size:10px!important}}.task-item-time[_ngcontent-%COMP%]{font-size:12px;white-space:nowrap;color:var(--primary-text);opacity:.6}@media(max-width:768px){.task-item-time[_ngcontent-%COMP%]{font-size:11px}}.task-item-time[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:var(--primary-text);opacity:.6}.task-item-description[_ngcontent-%COMP%]{font-size:13px;line-height:1.4;color:var(--primary-text);opacity:.8}@media(max-width:768px){.task-item-description[_ngcontent-%COMP%]{font-size:12px}}.task-item-action[_ngcontent-%COMP%]{flex-shrink:0}@media(max-width:768px){.task-item-action[_ngcontent-%COMP%]{width:100%;margin-top:8px}}@media(max-width:768px){.task-item-action[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{width:100%;font-size:12px;padding:6px 12px}}@media(max-width:768px){.task-item-action[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%]{font-size:11px;padding:4px 8px}}"]
            })
        }
    }
    return t
})();
var De = (t, c) => c.code;

function Ne(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "app-task-item", 10), m("actionStarted", function() {
            f(e);
            let i = d(2);
            return C(i.onTaskActionStarted())
        }), o()
    }
    if (t & 2) {
        let e = c.$implicit,
            n = d(2);
        g("task", e)("isSuggestedNext", n.isTaskSuggested(e))
    }
}

function Ve(t, c) {
    if (t & 1 && (a(0, "div", 8), I(1, Ne, 1, 2, "app-task-item", 9, De), o()), t & 2) {
        let e = d();
        s(), D(e.tasks)
    }
}
var Ce = (() => {
    class t {
        constructor() {
            this.tasks = [], this.suggestedNextTaskCode = null, this.isExpanded = !1, this.taskActionStarted = new P, this.expanded = R(this.isExpanded), this.formatMessage = u
        }
        onTaskActionStarted() {
            this.taskActionStarted.emit()
        }
        ngOnInit() {
            this.expanded.set(this.isExpanded)
        }
        ngOnChanges() {
            this.expanded.set(this.isExpanded)
        }
        toggleExpand() {
            this.expanded.update(e => !e)
        }
        get categoryIcon() {
            switch (this.category) {
                case "business_basics":
                    return "fa-building";
                case "repair_workflow":
                    return "fa-wrench";
                case "finance_billing":
                    return "fa-money-bill-wave";
                case "run_business":
                    return "fa-chart-line";
                case "silent_signals":
                    return "fa-signal";
                default:
                    return "fa-tasks"
            }
        }
        get categoryTitle() {
            return u(this.category)
        }
        get progressText() {
            if (!this.progress) return "0 / 0";
            let e = this.progress.completed_tasks ? ? 0,
                n = this.progress.total_tasks ? ? 0;
            return `${e} / ${n}`
        }
        get progressPercentage() {
            return this.progress ? this.progress.percentage ? ? this.progress.completion_percentage ? ? 0 : 0
        }
        get progressColor() {
            return this.progress ? .color ? ? "danger"
        }
        isTaskSuggested(e) {
            return e.code === this.suggestedNextTaskCode
        }
        get totalWeight() {
            return this.progress ? this.progress.total_weight ? ? 0 : 0
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-task-category"]
                ],
                inputs: {
                    category: "category",
                    tasks: "tasks",
                    progress: "progress",
                    suggestedNextTaskCode: "suggestedNextTaskCode",
                    isExpanded: "isExpanded"
                },
                outputs: {
                    taskActionStarted: "taskActionStarted"
                },
                standalone: !1,
                features: [L],
                decls: 15,
                vars: 14,
                consts: [
                    [1, "task-category"],
                    [1, "task-category-header", 3, "click"],
                    [1, "task-category-title"],
                    [1, "badge", "bg-secondary", "ms-2", 2, "font-size", "0.7rem"],
                    [1, "task-category-meta"],
                    [1, "task-category-progress-text", "text-muted", "me-3"],
                    [1, "fas", "fa-chevron-down", "task-category-chevron"],
                    [1, "progress", "task-category-progress-bar", 2, "height", "4px"],
                    [1, "task-category-tasks"],
                    [3, "task", "isSuggestedNext"],
                    [3, "actionStarted", "task", "isSuggestedNext"]
                ],
                template: function(n, i) {
                    n & 1 && (a(0, "div", 0)(1, "div", 1), m("click", function() {
                        return i.toggleExpand()
                    }), a(2, "div", 2), l(3, "i"), a(4, "span"), r(5), o(), a(6, "span", 3), r(7), o()(), a(8, "div", 4)(9, "span", 5), r(10), o(), l(11, "i", 6), o()(), a(12, "div", 7), l(13, "div"), o(), v(14, Ve, 3, 0, "div", 8), o()), n & 2 && (s(3), S(O("fas ", i.categoryIcon, " me-2")), s(2), w(i.categoryTitle), s(2), p("", i.totalWeight, "%"), s(3), p(" ", i.progressText, " "), s(), T("rotated", i.expanded()), s(2), S(O("progress-bar bg-", i.progressColor)), E("width", i.progressPercentage, "%"), s(), k(i.expanded() ? 14 : -1))
                },
                dependencies: [fe],
                styles: [".task-category[_ngcontent-%COMP%]{margin-bottom:16px;border-radius:8px;border:1px solid var(--theme-border-color);overflow:hidden;transition:border-color .2s ease}@media(max-width:768px){.task-category[_ngcontent-%COMP%]{margin-bottom:12px;border-radius:6px}}.task-category-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;cursor:pointer;background:var(--bg-secondary);transition:background-color .2s ease}@media(max-width:768px){.task-category-header[_ngcontent-%COMP%]{padding:10px 12px;flex-wrap:wrap;gap:8px}}.task-category-header[_ngcontent-%COMP%]:hover{background:var(--primary-bg)}.task-category-title[_ngcontent-%COMP%]{display:flex;align-items:center;font-size:15px;font-weight:600;color:var(--primary-text);flex:1;min-width:0}@media(max-width:768px){.task-category-title[_ngcontent-%COMP%]{font-size:14px}}.task-category-title[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#3498db;flex-shrink:0}.task-category-title[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.task-category-meta[_ngcontent-%COMP%]{display:flex;align-items:center;flex-shrink:0}@media(max-width:768px){.task-category-meta[_ngcontent-%COMP%]{width:100%;justify-content:space-between;order:2}}.task-category-progress-text[_ngcontent-%COMP%]{font-size:13px;font-weight:500;color:var(--primary-text);opacity:.7}@media(max-width:768px){.task-category-progress-text[_ngcontent-%COMP%]{font-size:12px}}.task-category-chevron[_ngcontent-%COMP%]{font-size:12px;color:var(--primary-text);transition:transform .2s ease}.task-category-chevron.rotated[_ngcontent-%COMP%]{transform:rotate(180deg)}.task-category-progress-bar[_ngcontent-%COMP%]{margin:0}.task-category-tasks[_ngcontent-%COMP%]{padding:12px;background:var(--primary-bg);transition:background-color .2s ease}@media(max-width:768px){.task-category-tasks[_ngcontent-%COMP%]{padding:8px}}"]
            })
        }
    }
    return t
})();
var Be = (t, c) => c.value;

function Ae(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "div", 13), m("click", function() {
            let i = f(e).$implicit,
                h = d(2);
            return C(h.selectReward(i.value))
        }), a(1, "div", 14), l(2, "i"), o(), a(3, "div", 15)(4, "h6", 16), r(5), o(), a(6, "p", 17), r(7), o()(), a(8, "div", 18), l(9, "i", 19), o()()
    }
    if (t & 2) {
        let e = c.$implicit,
            n = d(2);
        T("selected", n.selectedRewardType() === e.value), s(2), S(O("fas ", e.icon)), s(3), w(n.formatMessage(e.titleKey)), s(2), w(n.formatMessage(e.descriptionKey)), s(2), T("fa-circle", n.selectedRewardType() !== e.value)("fa-check-circle", n.selectedRewardType() === e.value)("text-primary", n.selectedRewardType() === e.value)("text-muted", n.selectedRewardType() !== e.value)
    }
}

function Fe(t, c) {
    if (t & 1 && (a(0, "p", 12), l(1, "i", 20), r(2), o()), t & 2) {
        let e = d(2);
        s(2), p(" ", e.formatMessage("select_reward_first"), " ")
    }
}

function He(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "div")(1, "div", 2)(2, "div", 3), l(3, "i", 4), o(), a(4, "h5", 5), r(5), o(), a(6, "p", 6), r(7), o(), a(8, "div", 7), I(9, Ae, 10, 15, "div", 8, Be), o(), a(11, "div", 9)(12, "dx-button", 10), m("onClick", function() {
            f(e);
            let i = d();
            return C(i.onClose())
        }), o(), a(13, "dx-button", 11), m("onClick", function() {
            f(e);
            let i = d();
            return C(i.onClaim())
        }), o()(), v(14, Fe, 3, 1, "p", 12), o()()
    }
    if (t & 2) {
        let e = d();
        s(5), w(e.formatMessage("reward_unlocked_title")), s(2), p(" ", e.formatMessage("reward_unlocked_message"), " "), s(2), D(e.rewardOptions), s(3), g("text", U(e.formatMessage("cancel")))("width", "50%"), s(), g("text", e.formatMessage("claim_reward"))("icon", e.isSubmitting() ? "fas fa-spinner fa-spin" : "fas fa-gift")("disabled", !e.canClaim)("width", "50%"), s(), k(e.selectedRewardType() ? -1 : 14)
    }
}
var ke = (() => {
    class t {
        constructor() {
            this.visible = !1, this.visibleChange = new P, this.claimed = new P, this.businessReadinessService = x(z), this.toastr = x(ce), this.formatMessage = u, this.selectedRewardType = R(null), this.isSubmitting = R(!1), this.rewardOptions = [{
                value: "discount",
                titleKey: "reward_discount_title",
                descriptionKey: "reward_discount_description",
                icon: "fa-percent"
            }, {
                value: "trial_extension",
                titleKey: "reward_trial_title",
                descriptionKey: "reward_trial_description",
                icon: "fa-calendar-plus"
            }]
        }
        get canClaim() {
            return !!this.selectedRewardType() && !this.isSubmitting()
        }
        selectReward(e) {
            this.selectedRewardType.set(e)
        }
        onClaim() {
            let e = this.selectedRewardType();
            if (!e) {
                this.toastr.warning(u("select_reward_first"));
                return
            }
            this.isSubmitting.set(!0), this.businessReadinessService.claimReward(e).subscribe({
                next: n => {
                    this.toastr.success(n.message, u("congratulations")), n.data.discount_code && this.toastr.info(`${u("your_reward_code")}: ${n.data.discount_code}`, u("reward_code"), {
                        timeOut: 1e4
                    }), this.onClose(), this.claimed.emit()
                },
                error: n => {
                    this.toastr.error(n.error ? .message || u("error_claiming_reward")), this.isSubmitting.set(!1)
                }
            })
        }
        onClose() {
            this.selectedRewardType.set(null), this.isSubmitting.set(!1), this.visibleChange.emit(!1)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-reward-modal"]
                ],
                inputs: {
                    visible: "visible"
                },
                outputs: {
                    visibleChange: "visibleChange",
                    claimed: "claimed"
                },
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    [3, "visibleChange", "onHidden", "visible", "showTitle", "title", "dragEnabled", "showCloseButton", "width"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "reward-modal-content"],
                    [1, "text-center", "mb-4"],
                    [1, "fas", "fa-trophy", "reward-icon"],
                    [1, "text-center", "mb-2"],
                    [1, "text-center", "text-muted", "mb-4"],
                    [1, "reward-options", "mb-4"],
                    [1, "reward-option", 3, "selected"],
                    [1, "d-flex", "gap-2"],
                    ["type", "normal", "stylingMode", "outlined", 3, "onClick", "text", "width"],
                    ["type", "success", 3, "onClick", "text", "icon", "disabled", "width"],
                    [1, "text-center", "text-muted", "small", "mt-3", "mb-0"],
                    [1, "reward-option", 3, "click"],
                    [1, "reward-option-icon"],
                    [1, "reward-option-details"],
                    [1, "mb-1"],
                    [1, "text-muted", "small", "mb-0"],
                    [1, "reward-option-radio"],
                    [1, "fas"],
                    [1, "fas", "fa-info-circle", "me-1"]
                ],
                template: function(n, i) {
                    n & 1 && (a(0, "dx-popup", 0), F("visibleChange", function(b) {
                        return A(i.visible, b) || (i.visible = b), b
                    }), m("onHidden", function() {
                        return i.onClose()
                    }), H(1, He, 15, 10, "div", 1), o()), n & 2 && (B("visible", i.visible), g("showTitle", !0)("title", i.formatMessage("congratulations"))("dragEnabled", !1)("showCloseButton", !0)("width", 500), s(), g("dxTemplateOf", "content"))
                },
                dependencies: [K, N, j],
                styles: [".reward-modal-content[_ngcontent-%COMP%]{padding:16px}@media(max-width:768px){.reward-modal-content[_ngcontent-%COMP%]{padding:12px}}.reward-icon[_ngcontent-%COMP%]{font-size:64px;color:#ffc107;animation:_ngcontent-%COMP%_pulse 2s ease-in-out infinite}@media(max-width:768px){.reward-icon[_ngcontent-%COMP%]{font-size:48px}}@keyframes _ngcontent-%COMP%_pulse{0%,to{transform:scale(1)}50%{transform:scale(1.1)}}.reward-options[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:12px}@media(max-width:768px){.reward-options[_ngcontent-%COMP%]{gap:8px}}.reward-option[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:16px;border:2px solid var(--theme-border-color);border-radius:8px;cursor:pointer;transition:all .2s ease;background:var(--primary-bg)}@media(max-width:768px){.reward-option[_ngcontent-%COMP%]{padding:12px;gap:10px}}.reward-option[_ngcontent-%COMP%]:hover{background:var(--bg-secondary)}.reward-option.selected[_ngcontent-%COMP%]{border-color:#3498db;background:#3498db0d}.reward-option-icon[_ngcontent-%COMP%]{flex-shrink:0;width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:var(--bg-secondary);border-radius:50%;font-size:20px;color:#3498db;transition:background-color .2s ease}@media(max-width:768px){.reward-option-icon[_ngcontent-%COMP%]{width:40px;height:40px;font-size:18px}}.reward-option-details[_ngcontent-%COMP%]{flex:1;min-width:0}.reward-option-details[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{font-size:15px;font-weight:600;margin:0;color:var(--primary-text)}@media(max-width:768px){.reward-option-details[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{font-size:14px}}.reward-option-details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:var(--primary-text);opacity:.8}@media(max-width:768px){.reward-option-details[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:12px}}.reward-option-radio[_ngcontent-%COMP%]{flex-shrink:0;font-size:20px;color:var(--primary-text)}@media(max-width:768px){.reward-option-radio[_ngcontent-%COMP%]{font-size:18px}}"]
            })
        }
    }
    return t
})();
var Ke = () => ({
    class: "business-readiness-modal-wrapper"
});

function je(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "p", 17), r(1), o(), a(2, "dx-button", 18), m("onClick", function() {
            f(e);
            let i = d(3);
            return C(i.openRewardModal())
        }), l(3, "i", 19), o()
    }
    if (t & 2) {
        let e = d(3);
        s(), p(" ", e.formatMessage("reward_unlocked_choose"), " "), s(), g("text", U(e.formatMessage("claim_reward")))("height", 32)
    }
}

function $e(t, c) {
    if (t & 1 && (a(0, "p", 20), r(1), o(), a(2, "div", 21), l(3, "div", 22), o(), a(4, "p", 23)(5, "strong"), r(6), o()()), t & 2) {
        let e = d(3);
        s(), p(" ", e.formatMessage("reward_unlock_description"), " "), s(2), E("width", e.score() / 80 * 100, "%"), s(3), p("", e.score(), "/80%")
    }
}

function Le(t, c) {
    if (t & 1 && (a(0, "div", 12)(1, "div", 13), l(2, "i", 14), o(), a(3, "div", 15)(4, "h6", 16), r(5), o(), v(6, je, 4, 4)(7, $e, 7, 4), o()()), t & 2) {
        let e = d(2);
        T("unlocked", e.isRewardUnlocked()), s(5), p(" ", e.formatMessage("unlock_reward_at_80"), " "), s(), k(e.isRewardUnlocked() ? 6 : 7)
    }
}

function Ye(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "app-task-category", 25), m("taskActionStarted", function() {
            f(e);
            let i = d(3);
            return C(i.onClose())
        }), o()
    }
    if (t & 2) {
        let e = d().$implicit,
            n = d(2);
        g("category", e)("tasks", n.filteredTasks()[e])("progress", n.categoryProgress()[e])("suggestedNextTaskCode", n.suggestedNext())("isExpanded", n.isCategoryExpanded(e))
    }
}

function Ue(t, c) {
    if (t & 1 && v(0, Ye, 1, 5, "app-task-category", 24), t & 2) {
        let e = c.$implicit,
            n = d(2);
        k(n.categoryProgress()[e] && n.filteredTasks()[e] ? 0 : -1)
    }
}

function Xe(t, c) {
    if (t & 1 && (a(0, "div")(1, "div", 3)(2, "div", 4)(3, "div", 5)(4, "h6", 6), r(5), o(), a(6, "span"), r(7), o()(), a(8, "div", 7), l(9, "div"), o(), a(10, "p", 8), r(11), o()(), l(12, "hr", 9), v(13, Le, 8, 4, "div", 10), a(14, "div", 11), I(15, Ue, 1, 1, null, null, ae), o()()()), t & 2) {
        let e = d();
        s(5), w(e.formatMessage("overall_progress")), s(), S(O("badge bg-", e.progressColor(), " fs-6")), s(), w(e.scoreDisplay()), s(2), S(O("progress-bar bg-", e.progressColor())), E("width", e.score(), "%"), s(2), re(" ", e.progressMessage, " (", e.completedTasks(), " / ", e.totalTasks(), " ", e.formatMessage("tasks_completed"), ") "), s(2), k(!e.isRewardClaimed() && !e.isCompleted() ? 13 : -1), s(2), D(e.visibleCategories)
    }
}
var At = (() => {
    class t {
        constructor() {
            this.visible = !1, this.visibleChange = new P, this.closeModal = new P, this.businessReadinessService = x(z), this.userDeviceService = x(le), this.tenantService = x(he), this.formatMessage = u, this.isMobile = this.userDeviceService.isMobileDevice(), this.score = this.businessReadinessService.score, this.scoreDisplay = this.businessReadinessService.scoreDisplay, this.progressColor = this.businessReadinessService.progressColor, this.categoryProgress = this.businessReadinessService.categoryProgress, this.tasks = this.businessReadinessService.tasks, this.suggestedNext = this.businessReadinessService.suggestedNext, this.completedTasks = this.businessReadinessService.completedTasks, this.totalTasks = this.businessReadinessService.totalTasks, this.isRewardUnlocked = this.businessReadinessService.isRewardUnlocked, this.isRewardClaimed = this.businessReadinessService.isRewardClaimed, this.isCompleted = this.businessReadinessService.isCompleted, this.filteredTasks = _(() => {
                let e = this.tasks(),
                    n = this.tenantService.plan(),
                    i = J.indexOf(n),
                    h = {};
                for (let [b, we] of Object.entries(e)) h[b] = we.filter(Me => {
                    let Q = pe[Me.code];
                    return Q ? i >= J.indexOf(Q) : !0
                });
                return h
            }), this.visibleCategories = ["business_basics", "repair_workflow", "finance_billing", "run_business"], this.expandedCategories = new Set, this.isRewardModalVisible = !1
        }
        ngOnInit() {
            this.autoExpandFirstIncomplete()
        }
        ngOnChanges() {
            this.visible && (this.businessReadinessService.checkPendingRefresh(), this.businessReadinessService.fetchProgress(!0).subscribe(() => {
                this.autoExpandFirstIncomplete()
            }))
        }
        autoExpandFirstIncomplete() {
            this.expandedCategories.clear();
            for (let e of this.visibleCategories) {
                let n = this.categoryProgress()[e];
                if (n && n.percentage < 100) {
                    this.expandedCategories.add(e);
                    break
                }
            }
            this.expandedCategories.size === 0 && this.expandedCategories.add(this.visibleCategories[0])
        }
        isCategoryExpanded(e) {
            return this.expandedCategories.has(e)
        }
        get progressMessage() {
            return this.score() >= 80 ? u("almost_there_message") : u("complete_tasks_message")
        }
        get modalWidth() {
            return this.isMobile ? 360 : 700
        }
        get modalMaxHeight() {
            return this.isMobile ? "80vh" : "90vh"
        }
        onClose() {
            this.visibleChange.emit(!1), this.closeModal.emit()
        }
        onShowing() {
            this.businessReadinessService.checkPendingRefresh(), this.businessReadinessService.fetchProgress(!0).subscribe(() => {
                this.autoExpandFirstIncomplete()
            })
        }
        openRewardModal() {
            this.isRewardModalVisible = !0
        }
        closeRewardModal() {
            this.isRewardModalVisible = !1
        }
        onRewardClaimed() {
            this.closeRewardModal(), this.businessReadinessService.fetchProgress().subscribe()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-checklist-modal"]
                ],
                inputs: {
                    visible: "visible"
                },
                outputs: {
                    visibleChange: "visibleChange",
                    closeModal: "closeModal"
                },
                standalone: !1,
                features: [L],
                decls: 3,
                vars: 11,
                consts: [
                    [3, "visibleChange", "onShowing", "onHidden", "visible", "showTitle", "title", "dragEnabled", "showCloseButton", "width", "maxHeight", "wrapperAttr"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "visibleChange", "claimed", "visible"],
                    [1, "checklist-modal-content"],
                    [1, "overall-progress-section"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-2"],
                    [1, "mb-0"],
                    [1, "progress", "mb-2", 2, "height", "12px"],
                    [1, "text-muted", "small", "mb-0"],
                    [1, "my-3"],
                    [1, "reward-unlock-banner", "mb-3", 3, "unlocked"],
                    [1, "categories-section"],
                    [1, "reward-unlock-banner", "mb-3"],
                    [1, "reward-unlock-icon"],
                    [1, "fas", "fa-gift"],
                    [1, "reward-unlock-content"],
                    [1, "mb-1"],
                    [1, "mb-2", "small"],
                    ["type", "success", "stylingMode", "contained", 3, "onClick", "text", "height"],
                    [1, "fas", "fa-trophy", "me-1"],
                    [1, "mb-1", "small"],
                    [1, "progress", "reward-progress", "mt-2", 2, "height", "8px"],
                    [1, "progress-bar", "bg-success"],
                    [1, "text-end", "small", "mb-0", "mt-1"],
                    [3, "category", "tasks", "progress", "suggestedNextTaskCode", "isExpanded"],
                    [3, "taskActionStarted", "category", "tasks", "progress", "suggestedNextTaskCode", "isExpanded"]
                ],
                template: function(n, i) {
                    n & 1 && (a(0, "dx-popup", 0), F("visibleChange", function(b) {
                        return A(i.visible, b) || (i.visible = b), b
                    }), m("onShowing", function() {
                        return i.onShowing()
                    })("onHidden", function() {
                        return i.onClose()
                    }), H(1, Xe, 17, 15, "div", 1), o(), a(2, "app-reward-modal", 2), F("visibleChange", function(b) {
                        return A(i.isRewardModalVisible, b) || (i.isRewardModalVisible = b), b
                    }), m("claimed", function() {
                        return i.onRewardClaimed()
                    }), o()), n & 2 && (B("visible", i.visible), g("showTitle", !0)("title", i.formatMessage("business_readiness_title"))("dragEnabled", !1)("showCloseButton", !0)("width", i.modalWidth)("maxHeight", i.modalMaxHeight)("wrapperAttr", de(10, Ke)), s(), g("dxTemplateOf", "content"), s(), B("visible", i.isRewardModalVisible))
                },
                dependencies: [K, N, j, Ce, ke],
                styles: [".business-readiness-modal-wrapper .dx-popup-content{padding:16px}@media(max-width:768px){  .business-readiness-modal-wrapper .dx-popup-content{padding:12px}}@media(max-width:768px){  .business-readiness-modal-wrapper .dx-popup-wrapper .dx-overlay-content{width:calc(100vw - 24px)!important;margin:12px}}.checklist-modal-content[_ngcontent-%COMP%]{padding:0}.overall-progress-section[_ngcontent-%COMP%]{padding:16px;background:var(--bg-secondary);border-radius:8px;border:1px solid var(--theme-border-color);transition:background-color .2s ease,border-color .2s ease}@media(max-width:768px){.overall-progress-section[_ngcontent-%COMP%]{padding:12px}}.overall-progress-section[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{color:var(--primary-text);font-size:15px}@media(max-width:768px){.overall-progress-section[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{font-size:14px}}.overall-progress-section[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%]{font-size:14px!important;padding:6px 12px}@media(max-width:768px){.overall-progress-section[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%]{font-size:12px!important;padding:4px 8px}}.overall-progress-section[_ngcontent-%COMP%]   .text-muted[_ngcontent-%COMP%]{color:var(--primary-text)!important;opacity:.7}.reward-unlock-banner[_ngcontent-%COMP%]{display:flex;gap:16px;padding:16px;background:linear-gradient(135deg,#e8f5e9,#c8e6c9);border:2px solid #81c784;border-radius:12px;transition:all .3s ease}.reward-unlock-banner.unlocked[_ngcontent-%COMP%]{background:linear-gradient(135deg,#fff3e0,#ffe0b2);border-color:#ffb74d;animation:_ngcontent-%COMP%_pulse-glow 2s ease-in-out infinite}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-icon[_ngcontent-%COMP%]{flex-shrink:0;width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:#ffffffe6;border-radius:50%;font-size:24px;color:#4caf50}.unlocked[_ngcontent-%COMP%]   .reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-icon[_ngcontent-%COMP%]{color:#ff9800}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]{flex:1}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{color:#2e7d32;font-size:15px;font-weight:600}.unlocked[_ngcontent-%COMP%]   .reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{color:#e65100}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#1b5e20;margin:0}.unlocked[_ngcontent-%COMP%]   .reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#bf360c}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]   .reward-progress[_ngcontent-%COMP%]{background-color:#0000001a}@media(max-width:768px){.reward-unlock-banner[_ngcontent-%COMP%]{gap:12px;padding:12px}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-icon[_ngcontent-%COMP%]{width:40px;height:40px;font-size:20px}.reward-unlock-banner[_ngcontent-%COMP%]   .reward-unlock-content[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{font-size:14px}}@keyframes _ngcontent-%COMP%_pulse-glow{0%,to{box-shadow:0 0 10px #ff98004d}50%{box-shadow:0 0 20px #ff980099}}.categories-section[_ngcontent-%COMP%]{max-height:430px;overflow-y:auto;padding-right:4px}@media(max-width:768px){.categories-section[_ngcontent-%COMP%]{max-height:380px;padding-right:2px}}.categories-section[_ngcontent-%COMP%]::-webkit-scrollbar{width:6px}.categories-section[_ngcontent-%COMP%]::-webkit-scrollbar-track{background:var(--bg-secondary);border-radius:3px}.categories-section[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{background:var(--theme-border-color);border-radius:3px}.categories-section[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover{background:var(--primary-text);opacity:.5}"]
            })
        }
    }
    return t
})();

function Ge(t, c) {
    if (t & 1 && (a(0, "div", 5)(1, "span", 6), r(2), o(), a(3, "span", 7), r(4), o()()), t & 2) {
        let e = d(2);
        s(2), w(e.formatMessage("business_readiness_title")), s(2), oe(" ", e.businessReadinessService.completedTasks(), "/", e.businessReadinessService.totalTasks(), " ", e.formatMessage("tasks_completed"), " ")
    }
}

function Je(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "div", 2), m("click", function() {
            f(e);
            let i = d();
            return C(i.onClick())
        }), a(1, "div", 3), l(2, "app-progress-badge", 4), v(3, Ge, 5, 4, "div", 5), o()()
    }
    if (t & 2) {
        let e = d();
        S("business-readiness-section mt-2 " + (e.isExpanded ? "px-3 py-2 mb-2" : "px-2 py-2 mb-2")), g("title", e.isExpanded ? "" : e.formatMessage("business_readiness_title")), s(2), g("percentage", e.businessReadinessService.score())("color", e.businessReadinessService.progressColor())("size", e.isExpanded ? 50 : 40), s(), k(e.isExpanded ? 3 : -1)
    }
}

function qe(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "div", 8), m("click", function() {
            f(e);
            let i = d();
            return C(i.onClick())
        }), a(1, "button", 9), m("click", function(i) {
            f(e);
            let h = d();
            return C(h.onDismissSettingsBanner(i))
        }), o(), a(2, "div", 10)(3, "div", 11)(4, "div", 12), l(5, "app-progress-badge", 4), o(), a(6, "div", 13)(7, "h4", 14), l(8, "i", 15), r(9), o(), a(10, "p", 16), r(11), o(), a(12, "div", 17), l(13, "div"), o(), a(14, "p", 18)(15, "strong"), r(16), o(), r(17), a(18, "span"), r(19), o()()(), a(20, "div", 12), l(21, "dx-button", 19), o()()()()
    }
    if (t & 2) {
        let e = d();
        s(), g("title", e.formatMessage("close")), W("aria-label", e.formatMessage("close")), s(4), g("percentage", e.businessReadinessService.score())("color", e.businessReadinessService.progressColor())("size", 80), s(4), p(" ", e.formatMessage("congratulations_business_ready"), " "), s(2), p(" ", e.formatMessage("business_readiness_achievement_message"), " "), s(2), S(O("progress-bar bg-", e.businessReadinessService.progressColor())), E("width", e.businessReadinessService.score(), "%"), s(3), Y("", e.businessReadinessService.completedTasks(), "/", e.businessReadinessService.totalTasks()), s(), p(" ", e.formatMessage("tasks_completed"), " - "), s(), S(O("text-", e.businessReadinessService.progressColor())), s(), p(" ", e.businessReadinessService.scoreDisplay(), " "), s(2), g("text", e.formatMessage("view_details"))
    }
}
var Yt = (() => {
    class t {
        constructor() {
            this.displayMode = "sidebar", this.isExpanded = !1, this.openChecklist = new P, this.businessReadinessService = x(z), this.formatMessage = u
        }
        onClick() {
            this.openChecklist.emit()
        }
        onDismissSettingsBanner(e) {
            e.stopPropagation(), this.businessReadinessService.dismissSettingsBanner()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-business-readiness-widget"]
                ],
                inputs: {
                    displayMode: "displayMode",
                    isExpanded: "isExpanded"
                },
                outputs: {
                    openChecklist: "openChecklist"
                },
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["onmouseover", "this.style.backgroundColor='var(--bg-secondary)'", "onmouseout", "this.style.backgroundColor='transparent'", 2, "cursor", "pointer", "border-radius", "8px", "transition", "background-color 0.2s", 3, "class", "title"],
                    [1, "card", "business-readiness-card", "shadow-sm", "position-relative", 2, "cursor", "pointer"],
                    ["onmouseover", "this.style.backgroundColor='var(--bg-secondary)'", "onmouseout", "this.style.backgroundColor='transparent'", 2, "cursor", "pointer", "border-radius", "8px", "transition", "background-color 0.2s", 3, "click", "title"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [3, "percentage", "color", "size"],
                    [1, "d-flex", "flex-column", "flex-grow-1", 2, "min-width", "0"],
                    [1, "fw-semibold", "text-truncate", 2, "font-size", "12px"],
                    [1, "text-muted", 2, "font-size", "11px"],
                    [1, "card", "business-readiness-card", "shadow-sm", "position-relative", 2, "cursor", "pointer", 3, "click"],
                    ["type", "button", 1, "btn-close", "position-absolute", "top-0", "end-0", "m-2", 3, "click", "title"],
                    [1, "card-body", "p-4"],
                    [1, "row", "align-items-center"],
                    [1, "col-auto"],
                    [1, "col"],
                    [1, "mb-2"],
                    [1, "fa", "fa-party-horn", "me-2", "text-success"],
                    [1, "mb-2", "text-muted"],
                    [1, "progress", "mb-2", 2, "height", "8px"],
                    [1, "mb-0"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-arrow-right", 3, "text"]
                ],
                template: function(n, i) {
                    n & 1 && (v(0, Je, 4, 7, "div", 0), v(1, qe, 22, 20, "div", 1)), n & 2 && (k(i.displayMode === "sidebar" ? 0 : -1), s(), k(i.displayMode === "settings" ? 1 : -1))
                },
                dependencies: [N, xe],
                styles: [".business-readiness-card[_ngcontent-%COMP%]{border-left:4px solid var(--bs-success);transition:transform .2s,box-shadow .2s}.business-readiness-card[_ngcontent-%COMP%]:hover{transform:translateY(-2px);box-shadow:0 4px 12px #0000001a!important}.business-readiness-section[_ngcontent-%COMP%]{transition:background-color .2s}"]
            })
        }
    }
    return t
})();
var Qe = (t, c) => c.id;

function Ze(t, c) {
    if (t & 1) {
        let e = M();
        a(0, "div", 5)(1, "div")(2, "div", 6), r(3), o(), a(4, "div", 7), r(5), o()(), a(6, "dx-button", 8), m("onClick", function() {
            let i = f(e).$implicit,
                h = d(2);
            return C(h.start(i))
        }), o()()
    }
    if (t & 2) {
        let e = c.$implicit,
            n = d(2);
        s(3), w(n.formatMessage(e.titleKey)), s(2), w(n.formatMessage(e.descKey)), s(), g("text", n.formatMessage("start"))
    }
}

function et(t, c) {
    if (t & 1 && (a(0, "div")(1, "p", 3), r(2), o(), a(3, "div", 4), I(4, Ze, 7, 3, "div", 5, Qe), o()()), t & 2) {
        let e = d();
        s(2), w(e.formatMessage("tours_menu_subtitle")), s(2), D(e.tours)
    }
}
var Qt = (() => {
    class t {
        constructor() {
            this.guidedTourService = x(G), this.formatMessage = u, this.isVisible = !1, this.tours = this.guidedTourService.getAvailableTours()
        }
        open() {
            this.isVisible = !0
        }
        close() {
            this.isVisible = !1
        }
        start(e) {
            this.isVisible = !1, this.guidedTourService.startTour(e.id)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-tours-launcher"]
                ],
                standalone: !1,
                decls: 3,
                vars: 9,
                consts: [
                    ["id", "tours-launcher-btn", "icon", "fa-thin fa-compass", "stylingMode", "outlined", "type", "default", 1, "px-2", 3, "onClick", "hint"],
                    [3, "visibleChange", "onHidden", "visible", "width", "height", "showTitle", "title", "dragEnabled", "hideOnOutsideClick"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "text-muted", "small", "mb-3"],
                    [1, "tours-launcher-list"],
                    [1, "tours-launcher-item", "d-flex", "justify-content-between", "align-items-center", "gap-3", "py-3"],
                    [1, "fw-semibold"],
                    [1, "text-muted", "small"],
                    ["type", "default", "stylingMode", "contained", 1, "flex-shrink-0", 3, "onClick", "text"]
                ],
                template: function(n, i) {
                    n & 1 && (a(0, "dx-button", 0), m("onClick", function() {
                        return i.open()
                    }), o(), a(1, "dx-popup", 1), F("visibleChange", function(b) {
                        return A(i.isVisible, b) || (i.isVisible = b), b
                    }), m("onHidden", function() {
                        return i.close()
                    }), H(2, et, 6, 1, "div", 2), o()), n & 2 && (g("hint", i.formatMessage("tours_menu_title")), s(), B("visible", i.isVisible), g("width", 440)("height", "auto")("showTitle", !0)("title", i.formatMessage("tours_menu_title"))("dragEnabled", !1)("hideOnOutsideClick", !0), s(), g("dxTemplateOf", "content"))
                },
                dependencies: [K, N, j],
                styles: [".tours-launcher-item[_ngcontent-%COMP%]{border-bottom:1px solid rgba(128,128,128,.25)}.tours-launcher-item[_ngcontent-%COMP%]:last-child{border-bottom:none}"]
            })
        }
    }
    return t
})();
var hi = (() => {
    class t {
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275mod = se({
                type: t
            })
        }
        static {
            this.\u0275inj = te({
                imports: [_e]
            })
        }
    }
    return t
})();
export {
    z as a, At as b, xe as c, Yt as d, Qt as e, hi as f
};