import {
    a as Oe
} from "./chunk-FVAZ73PS.js";
import {
    a as Pe
} from "./chunk-HUDETQT5.js";
import {
    $c as Vt,
    Cd as Re,
    Ec as Ve,
    Fg as ee,
    Gd as K,
    Gg as Jt,
    Hc as kt,
    Ib as Mt,
    Ja as Me,
    Ke as Yt,
    L as le,
    Lb as Et,
    M as pe,
    Pc as Ne,
    Qd as Ce,
    T as z,
    Ta as Ee,
    Va as ue,
    Xa as yt,
    Zd as X,
    _b as It,
    _d as A,
    aa as Te,
    ab as Ie,
    ae as qt,
    ba as O,
    be as Ut,
    ca as j,
    cb as Y,
    cd as Nt,
    dd as At,
    e as R,
    eb as we,
    ed as Ae,
    g as U,
    h as G,
    ha as ht,
    hb as bt,
    id as Rt,
    jd as Dt,
    ka as de,
    kd as Ot,
    la as gt,
    lb as ke,
    mb as xt,
    md as jt,
    n as H,
    nb as Pt,
    od as Lt,
    oe as Gt,
    pb as $,
    ph as Kt,
    q as xe,
    qb as _e,
    qd as Bt,
    rd as fe,
    rg as De,
    sb as J,
    t as W,
    tb as Tt,
    te as Ht,
    u as Q,
    ud as Ft,
    ue as Wt,
    we as Qt,
    xc as wt,
    xg as $t,
    y as se,
    ze as zt
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    $b as be,
    Ab as q,
    Ai as He,
    Ak as St,
    Ba as Xe,
    Ca as Fe,
    Di as vt,
    Ec as rt,
    Fa as o,
    Fh as T,
    Ib as f,
    Jb as S,
    Jg as ut,
    Ka as y,
    Kb as E,
    Mc as at,
    Na as x,
    Ne as mt,
    Oa as ye,
    Pb as ne,
    Pg as _t,
    Ph as N,
    Qb as re,
    Rb as ae,
    Sa as D,
    Tc as st,
    Wa as Ze,
    Wb as ve,
    Wh as ft,
    Ye as dt,
    _a as u,
    aa as te,
    ba as Se,
    bc as it,
    cb as et,
    cc as ot,
    da as ie,
    db as tt,
    ea as d,
    eb as r,
    ei as Ct,
    fb as s,
    fd as lt,
    gb as a,
    gc as L,
    ha as h,
    hb as c,
    hc as qe,
    hi as M,
    ia as g,
    ic as he,
    jc as nt,
    kf as Ge,
    oa as oe,
    pd as w,
    qa as Be,
    qb as b,
    qd as pt,
    sb as v,
    sd as V,
    t as ge,
    td as ct,
    ti as ce,
    ub as p,
    ui as me,
    vd as Ue,
    xk as m,
    yb as B,
    zb as F
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";

function Ti(t, l) {
    t & 1 && c(0, "app-skeleton-loader", 3), t & 2 && r("rows", 4)("columns", 1)
}

function Mi(t, l) {
    if (t & 1 && c(0, "app-part-current-info", 6), t & 2) {
        let e = p(2);
        r("part", e.part)
    }
}

function Ei(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "form", 5), v("ngSubmit", function() {
            h(e);
            let i = p();
            return g(i.onStockAdjust())
        }), u(1, Mi, 1, 1, "app-part-current-info", 6), s(2, "div", 1)(3, "app-control-container", 7), c(4, "dx-radio-group", 8), a(), s(5, "app-control-container", 9), c(6, "dx-number-box", 10)(7, "app-error", 11), a(), s(8, "div", 12)(9, "p"), f(10), a(), s(11, "h5", 12), f(12), a()(), s(13, "app-control-container", 13), c(14, "dx-text-area", 14), a()(), s(15, "app-save-cancel-footer", 15), v("cancelClick", function() {
            h(e);
            let i = p();
            return g(i.onClosing())
        }), a()()
    }
    if (t & 2) {
        let e = p();
        r("formGroup", e.form), o(), _(e.part ? 1 : -1), o(2), r("errorMsg", e.formatMessage("common_error_part_adjust_stock_type_required"))("label", e.formatMessage("adjust_stock_label_type")), o(), r("items", e.adjustTypes), o(), r("errorMsg", e.formatMessage("common_error_part_adjust_quantity_required"))("label", e.formatMessage("adjust_stock_label_quantity")), o(2), r("displayError", e.form.get("adjusted_quantity").invalid && e.form.get("adjusted_quantity").touched)("errorMsg", e.formatMessage("common_error_adjust_stock_quantity_invalid")), o(3), S(e.formatMessage("adjust_stock_label_final")), o(2), S(e.stockAfterAdjustment), o(), r("label", e.formatMessage("adjust_stock_label_remarks")), o(), r("placeholder", e.formatMessage("common_placeholders_adjust_stock_remarks")), o(), r("gaEvent", "adjust_stock_save_event")("isOnPopup", !0)
    }
}
var je = (() => {
    class t {
        constructor(e) {
            this.partService = e, this.formatMessage = m, this.isVisibleAdjustStockPopup = !1, this.formService = d($), this.toastNotificationService = d(j), this.fb = new se, this.isSaving = !1, this.adjustTypes = [{
                value: "add",
                name: "Add(+)"
            }, {
                value: "reduce",
                name: "Reduce(-)"
            }], this.addAdjustStockSave = new oe, this.addAdjustStockClose = new oe
        }
        get stockAfterAdjustment() {
            return this.form.value.adjust_type ? this.form.value.adjust_type === this.adjustTypes[0].value ? this.part.quantity + this.form.value.adjusted_quantity : this.part.quantity - this.form.value.adjusted_quantity : this.part.quantity
        }
        ngOnInit() {
            this.form = this.fb.group({
                adjust_type: ["", [R.required]],
                adjusted_quantity: ["", [R.required, R.min(0)]],
                comment: [""]
            })
        }
        onClosing() {
            this.addAdjustStockClose.emit(), this.isVisibleAdjustStockPopup = !1, this.form.reset()
        }
        onStockAdjust() {
            this.form.valid ? this.partService.adjustStock(this.part.id, this.form.value).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_part_adjust_success"), this.isVisibleAdjustStockPopup = !1
                },
                error: e => {
                    console.log("error adjusting stock ", e)
                }
            }) : this.formService.validateFormFields(this.form)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(K))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-adjust-stock"]
                ],
                inputs: {
                    part: "part",
                    isVisibleAdjustStockPopup: "isVisibleAdjustStockPopup"
                },
                outputs: {
                    addAdjustStockSave: "addAdjustStockSave",
                    addAdjustStockClose: "addAdjustStockClose"
                },
                standalone: !1,
                decls: 5,
                vars: 8,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "height", "width", "maxWidth", "minHeight", "title"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "form-vertical", 3, "formGroup"],
                    [1, "form-vertical", 3, "ngSubmit", "formGroup"],
                    [3, "part"],
                    ["name", "adjust_type", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "adjust_type", "layout", "horizontal", "valueExpr", "value", 3, "items"],
                    ["name", "adjusted_quantity", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "adjusted_quantity", "placeholder", "0.0", "type", "text"],
                    [3, "displayError", "errorMsg"],
                    [1, "my-3"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label"],
                    ["formControlName", "comment", 3, "placeholder"],
                    [3, "cancelClick", "gaEvent", "isOnPopup"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "dx-popup", 0), v("onHidden", function() {
                        return i.onClosing()
                    }), ae("visibleChange", function(P) {
                        return re(i.isVisibleAdjustStockPopup, P) || (i.isVisibleAdjustStockPopup = P), P
                    }), s(1, "div", 1)(2, "div", 2), u(3, Ti, 1, 2, "app-skeleton-loader", 3), u(4, Ei, 16, 15, "form", 4), a()()()), n & 2 && (ne("visible", i.isVisibleAdjustStockPopup), r("height", "auto")("width", "95vw")("maxWidth", 400)("minHeight", 500)("title", i.formatMessage("part_adjust_stock_quantity")), o(3), _(i.form ? -1 : 3), o(), _(i.form ? 4 : -1))
                },
                dependencies: [_e, J, Y, qt, X, Ve, Ie, kt, bt, H, U, G, Q, W],
                encapsulation: 2
            })
        }
    }
    return t
})();
var k = class {
    constructor(l) {
        return Object.assign(this, l)
    }
    static getForm(l) {
        return new se().group({
            id: [l.id || null],
            barcode_no: [l.barcode_no || null],
            sku: [l.sku || null],
            low_stock_unit: [l.low_stock_unit || null],
            tax_id: [l.tax_id || null],
            unit: [l.unit || null],
            category_id: [l.category_id || null],
            sub_category_id: [l.sub_category_id || null],
            is_rate_including_tax: [l.is_rate_including_tax || !1],
            tax_code: [l.tax_code || null],
            description: [l.description || null],
            is_manage_stock: [l.is_manage_stock ? ? !0],
            is_low_stock_alert: [l.is_low_stock_alert ? ? !0],
            purchase_price: [l.purchase_price || 0, [R.required]],
            selling_price: [l.selling_price || null],
            warranty: [l.warranty || null],
            storage_location_id: [l.storage_location_id || null],
            quantity: [l.quantity, [R.required]],
            name: [l.name || null, [R.required, Tt.emptyTextValidator]],
            attachments: [l.attachments || []]
        })
    }
};
var Z = class {
    constructor(l) {
        return Object.assign(this, l)
    }
    static getForm(l) {
        return new se().group({
            id: [l.id || null],
            name: [l.name || null, [R.required]],
            part_category_id: [l.part_category_id || null, [R.required]]
        })
    }
};
var ti = (() => {
    class t extends ce {
        constructor(e) {
            super(e, Ge), this.api = e, this.endpoint = Ge
        }
        getAll() {
            return this.api.get(this.endpoint)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(ie(me))
            }
        }
        static {
            this.\u0275prov = te({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function Ri(t, l) {
    t & 1 && c(0, "app-skeleton-loader", 4), t & 2 && r("rows", 3)("columns", 1)
}

function Di(t, l) {
    if (t & 1 && c(0, "app-server-error", 12), t & 2) {
        let e = p(3);
        r("errorResponse", e.errorResponse)
    }
}

function Oi(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "form", 6), v("ngSubmit", function() {
            h(e);
            let i = p(2);
            return g(i.add())
        }), s(1, "div", 2)(2, "app-control-container", 7), c(3, "dx-select-box", 8), a(), s(4, "app-control-container", 9)(5, "dx-text-box", 10)(6, "dx-validator"), c(7, "dxi-validation-rule", 11), a()()()(), u(8, Di, 1, 1, "app-server-error", 12), s(9, "app-save-cancel-footer", 13), v("cancelClick", function() {
            h(e);
            let i = p(2);
            return g(i.onClosing())
        }), a()()
    }
    if (t & 2) {
        let e = p(2);
        r("formGroup", e.form), o(2), r("errorMsg", e.formatMessage("common_category_required"))("label", e.formatMessage("common_category")), o(), r("items", e.categories)("placeholder", e.formatMessage("placeholder_select_category"))("searchEnabled", !0), o(), r("errorMsg", e.formatMessage("common_error_part_sub_category_name_required"))("label", e.formatMessage("part_label_sub_category_name")), o(), r("placeholder", e.formatMessage("common_part_placeholder_category")), o(2), r("ignoreEmptyValue", !0)("message", e.formatMessage("common_error_part_sub_category_name_exists"))("validationCallback", e.asyncUniqueNameValidation), o(), _(e.errorResponse ? 8 : -1), o(), r("isOnPopup", !0)
    }
}

function ji(t, l) {
    if (t & 1 && (s(0, "div")(1, "div", 2)(2, "div", 3), u(3, Ri, 1, 2, "app-skeleton-loader", 4), u(4, Oi, 10, 14, "form", 5), a()()()), t & 2) {
        let e = p();
        o(3), _(e.form ? -1 : 3), o(), _(e.form ? 4 : -1)
    }
}
var ni = (() => {
    class t {
        constructor(e, n) {
            this.service = e, this.partCategoryService = n, this.formatMessage = m, this.partSubCategory = new Z({}), this.isCreate = !0, this.isVisiblePopup = !1, this.partSubCategorySaveClick = new oe, this.partSubCategoryCancelClick = new oe, this.ENTITIES = M, this.formService = d($), this.commonService = d(we), this.toastNotificationService = d(j), this.errorResponse = null, this.entity = this.ENTITIES.PART_SUB_CATEGORY, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.partCategoryService.getAll().subscribe({
                next: e => {
                    this.categories = e
                },
                error: e => {
                    this.toastNotificationService.error("notification_part_fetch_error")
                }
            }), this.form = Z.getForm(this.partSubCategory)
        }
        asyncUniqueNameValidation(e) {
            let n = {
                name: e.value,
                entity: this.entity.table,
                entity_id: this.partSubCategory ? .id
            };
            return this.commonService.checkUniqueName(n).pipe(ge(i => !!(i.hasOwnProperty("success") && i.success))).toPromise()
        }
        add() {
            this.errorResponse = null, this.form.valid ? (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: n => {
                    this.partSubCategory = new Z(n), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "notification_part_sub_category_add_success" : "notification_part_sub_category_update_success"), this.partSubCategorySaveClick.emit(this.partSubCategory), this.form = null
                },
                error: n => {
                    this.errorResponse = n
                }
            }) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form = null, this.isCreate = !1, this.partSubCategoryCancelClick.emit()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(Oe), y(Re))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-sub-category"]
                ],
                inputs: {
                    partSubCategory: "partSubCategory",
                    isCreate: "isCreate",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    partSubCategorySaveClick: "partSubCategorySaveClick",
                    partSubCategoryCancelClick: "partSubCategoryCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "part_category_id", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "part_category_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    [1, "mt-2", 3, "errorResponse"],
                    [3, "cancelClick", "isOnPopup"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "dx-popup", 0), v("onHidden", function() {
                        return i.onClosing()
                    }), ae("visibleChange", function(P) {
                        return re(i.isVisiblePopup, P) || (i.isVisiblePopup = P), P
                    }), D(1, ji, 5, 2, "div", 1), a()), n & 2 && (ne("visible", i.isVisiblePopup), r("width", "95vw")("maxWidth", 400)("title", i.partSubCategory != null && i.partSubCategory.id ? i.formatMessage("part_button_update_sub_category") : i.formatMessage("part_button_add_new_sub_category")), o(), r("dxTemplateOf", "content"))
                },
                dependencies: [fe, J, Y, X, ht, Me, Ie, Ee, ue, Ne, H, U, G, Q, W],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Fi(t, l) {
    t & 1 && c(0, "app-skeleton-loader", 0), t & 2 && r("rows", 8)("columns", 3)
}

function qi(t, l) {
    if (t & 1 && (s(0, "h3", 8), f(1), a()), t & 2) {
        let e = p(2);
        o(), S(e.formatMessage("inventory_add_part"))
    }
}

function Ui(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-save-cancel-footer", 56), v("cancelClick", function() {
            h(e);
            let i = p(3);
            return g(i.cancel())
        }), a()
    }
    if (t & 2) {
        let e = p(3);
        r("isOnPopup", !1)("gaEvent", "create_part_event")("isVisibleHr", !1)("saveText", e.part ? "common_save" : "common_create")
    }
}

function Gi(t, l) {
    if (t & 1 && D(0, Ui, 1, 4, "app-save-cancel-footer", 55), t & 2) {
        let e = p(2);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.PART_WRITE)
    }
}

function Hi(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-dx-outline-button", 59), v("onClickEvent", function() {
            h(e);
            let i = p(4);
            return g(i.setEditMode())
        }), a()
    }
}

function Wi(t, l) {
    if (t & 1 && D(0, Hi, 1, 0, "app-dx-outline-button", 58), t & 2) {
        let e = p(3);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.PART_WRITE)
    }
}

function Qi(t, l) {
    if (t & 1 && u(0, Wi, 1, 1, "app-dx-outline-button", 57), t & 2) {
        let e = p(2);
        _(e.userPermissionList.includes(e.PERMISSION_LIST.PART_WRITE) ? 0 : -1)
    }
}

function zi(t, l) {
    if (t & 1 && c(0, "app-server-error", 10), t & 2) {
        let e = p(2);
        r("errorResponse", e.errorResponse)
    }
}

function Yi(t, l) {
    if (t & 1 && c(0, "dxi-button", 19), t & 2) {
        let e = p(2);
        r("options", e.addCategoryOption)
    }
}

function $i(t, l) {
    if (t & 1 && c(0, "dxi-button", 22), t & 2) {
        let e = p(2);
        r("options", e.addSubCategoryOption)
    }
}

function Ji(t, l) {
    if (t & 1 && (s(0, "app-control-container", 33), c(1, "dx-text-box", 60), a()), t & 2) {
        let e = p(2);
        r("errorMsg", e.formatMessage("inventory_low_stock_units_error"))("label", e.formatMessage("common_low_stock_units")), o(), r("placeholder", e.formatMessage("inventory_low_stock_units_placeholder"))("readOnly", !e.isEditMode)
    }
}

function Ki(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "div", 62), v("click", function() {
            h(e);
            let i = p(3);
            return g(i.generateBarcode())
        }), s(1, "div", 63)(2, "span")(3, "span"), f(4), a(), c(5, "i", 64), a()()()
    }
    if (t & 2) {
        let e = p(3);
        o(4), S(e.formatMessage("inventory_generate_barcode"))
    }
}

function Xi(t, l) {
    if (t & 1 && u(0, Ki, 6, 1, "div", 61), t & 2) {
        let e = p(2);
        _(e.isEditMode ? 0 : -1)
    }
}

function Zi(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "div", 65), v("click", function() {
            h(e);
            let i = p(2);
            return g(i.ViewBarcode())
        }), s(1, "div", 63)(2, "span")(3, "span"), f(4), a(), c(5, "i", 64), a()()()
    }
    if (t & 2) {
        let e = p(2);
        o(4), S(e.formatMessage("inventory_view_barcode"))
    }
}

function eo(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-attachments", 66), v("afterSaving", function(i) {
            h(e);
            let C = p(2);
            return g(C.afterFileUpload(i))
        }), a()
    }
    if (t & 2) {
        let e = p(2);
        r("attachableType", e.ENTITIES.PART.name)("entity", e.part)("isEditMode", e.isEditMode)("isMultipleUploads", !0)
    }
}

function to(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-save-cancel-footer", 56), v("cancelClick", function() {
            h(e);
            let i = p(3);
            return g(i.cancel())
        }), a()
    }
    if (t & 2) {
        let e = p(3);
        r("isOnPopup", !0)("gaEvent", "create_part_event")("isVisibleHr", !1)("saveText", e.part ? "common_save" : "common_create")
    }
}

function io(t, l) {
    if (t & 1 && (s(0, "div", 54), D(1, to, 1, 4, "app-save-cancel-footer", 55), a()), t & 2) {
        let e = p(2);
        o(), r("ngxPermissionsOnly", e.PERMISSION_LIST.PART_WRITE)
    }
}

function oo(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "form", 5), v("ngSubmit", function() {
            h(e);
            let i = p();
            return g(i.onAddPart())
        }), s(1, "div", 6)(2, "div", 7)(3, "div"), u(4, qi, 2, 1, "h3", 8), u(5, Gi, 1, 1, "app-save-cancel-footer", 9), u(6, Qi, 1, 1), a(), u(7, zi, 1, 1, "app-server-error", 10), a()(), c(8, "app-section-title", 11), s(9, "div", 12)(10, "app-control-container", 13)(11, "dx-text-box", 14)(12, "dx-validator"), c(13, "dxi-validation-rule", 15), a()(), c(14, "app-error", 16), a(), s(15, "app-control-container", 17)(16, "dx-select-box", 18), v("onSelectionChanged", function(i) {
            h(e);
            let C = p();
            return g(C.onCategoryChange(i))
        }), u(17, Yi, 1, 1, "dxi-button", 19), a()(), s(18, "app-control-container", 20)(19, "dx-select-box", 21), u(20, $i, 1, 1, "dxi-button", 22), a()(), s(21, "app-control-container", 23), c(22, "dx-text-box", 24), a(), s(23, "app-control-container", 25), c(24, "dx-select-box", 26), a()(), c(25, "app-section-title", 11), s(26, "div", 12)(27, "app-control-container", 27), c(28, "dx-number-box", 28), a(), s(29, "app-control-container", 29), c(30, "dx-select-box", 30), L(31, "async"), a(), s(32, "app-control-container", 31), c(33, "dx-text-box", 32), a(), u(34, Ji, 2, 4, "app-control-container", 33), a(), c(35, "app-section-title", 11), s(36, "div", 12)(37, "app-control-container", 34), c(38, "dx-text-box", 35), a(), u(39, Xi, 1, 1)(40, Zi, 6, 1, "div", 36), a(), s(41, "div", 12)(42, "app-control-container", 37), c(43, "app-switch-btn", 38), a(), s(44, "app-control-container", 39), c(45, "app-switch-btn", 40), a(), s(46, "app-control-container", 41), c(47, "app-switch-btn", 42), a()(), c(48, "app-section-title", 11), s(49, "div", 12)(50, "app-control-container", 43), c(51, "dx-number-box", 44), a(), s(52, "app-control-container", 45), c(53, "dx-number-box", 46), a(), s(54, "app-control-container", 47), c(55, "dx-select-box", 48), L(56, "async"), a(), s(57, "app-control-container", 49), c(58, "dx-text-box", 50), a(), s(59, "app-control-container", 51), c(60, "app-textarea", 52), a()(), u(61, eo, 1, 4, "app-attachments", 53), u(62, io, 2, 1, "div", 54), a()
    }
    if (t & 2) {
        let e = p();
        r("formGroup", e.form), o(4), _(e.partId ? -1 : 4), o(), _(!e.isMobileDevice && e.isEditMode ? 5 : -1), o(), _(e.isEditMode ? -1 : 6), o(), _(e.errorResponse ? 7 : -1), o(), r("title", "basic_information"), o(2), r("errorMsg", e.formatMessage("common_error_messages_part_required"))("label", e.formatMessage("inventory_part_name")), o(), r("placeholder", e.formatMessage("inventory_example_parts")), o(2), r("ignoreEmptyValue", !0)("message", e.formatMessage("validation_part_name_exists"))("validationCallback", e.asyncUniqueNameValidation), o(), r("displayError", e.form.controls.name.hasError("invalidName")), o(), r("errorMsg", e.formatMessage("common_category_required"))("label", e.formatMessage("common_category")), o(), r("items", e.categories)("placeholder", e.formatMessage("placeholder_select_category"))("searchEnabled", !0), o(), _(e.isEditMode ? 17 : -1), o(), r("errorMsg", e.formatMessage("inventory_warranty_error"))("label", e.formatMessage("inventory_sub_category_label")), o(), r("items", e.subCategories)("placeholder", e.formatMessage("inventory_sub_category_placeholder"))("searchEnabled", !0), o(), _(e.isEditMode ? 20 : -1), o(), r("errorMsg", e.formatMessage("common_error_messages_warranty_required"))("label", e.formatMessage("payment_warranty")), o(), r("placeholder", e.formatMessage("common_placeholders_warranty"))("readOnly", !e.isEditMode), o(), r("errorMsg", e.formatMessage("inventory_storage_location_error"))("label", e.formatMessage("device_storage_location")), o(), r("items", e.storageLocationList)("placeholder", e.formatMessage("device_storage_location_placeholder")), o(), r("title", "inventory_stock_information"), o(2), r("errorMsg", e.formatMessage("common_error_messages_quantity_required"))("label", e.formatMessage("inventory_opening_stock_label")), o(), r("placeholder", e.formatMessage("inventory_opening_stock_placeholder"))("readOnly", !(e.partId || e.isEditMode)), o(), r("errorMsg", e.formatMessage("inventory_unit_type_error"))("label", e.formatMessage("common_unit_type")), o(), r("items", qe(31, 91, e.unitTypes$))("searchEnabled", !0)("placeholder", e.formatMessage("select_unit_type")), o(2), r("errorMsg", e.formatMessage("inventory_sku_error"))("label", e.formatMessage("inventory_sku")), o(), r("placeholder", e.formatMessage("inventory_sku_placeholder"))("readOnly", !e.isEditMode), o(), _(e.form.getRawValue().is_low_stock_alert ? 34 : -1), o(), r("title", "inventory_barcode_information"), o(2), r("errorMsg", e.formatMessage("inventory_barcode_number_error"))("label", e.formatMessage("inventory_barcode_number_label")), o(), r("placeholder", e.formatMessage("inventory_barcode_number_placeholder"))("readOnly", !0), o(), _(e.isViewBarcode ? 40 : 39), o(3), r("isLabelOnSameLine", !0), o(), r("isEditMode", e.isEditMode)("label", e.formatMessage("repair_services_rate_including_tax")), o(), r("isLabelOnSameLine", !0), o(), r("isEditMode", e.isEditMode)("label", e.formatMessage("common_manage_stock")), o(), r("isLabelOnSameLine", !0), o(), r("isEditMode", e.isEditMode)("label", e.formatMessage("inventory_low_stock_alert_label")), o(), r("title", "price_information"), o(2), r("errorMsg", e.formatMessage("inventory_purchase_price_error"))("label", e.formatMessage("common_purchase_price")), o(), r("min", 0)("placeholder", e.formatMessage("inventory_purchase_price_placeholder"))("readOnly", !e.isEditMode), o(), r("errorMsg", e.formatMessage("inventory_selling_price_error"))("label", e.formatMessage("payment_selling_price")), o(), r("min", 0)("placeholder", e.formatMessage("inventory_selling_price_placeholder"))("readOnly", !e.isEditMode), o(), r("errorMsg", e.formatMessage("common_error_messages_tax_required"))("label", e.formatMessage("common_tax")), o(), r("items", qe(56, 93, e.taxes$))("placeholder", e.formatMessage("common_placeholders_tax"))("readOnly", !e.isEditMode)("showClearButton", !0), o(2), r("errorMsg", e.formatMessage("common_placeholders_tax"))("label", e.formatMessage("inventory_tax_code_label")), o(), r("placeholder", e.formatMessage("inventory_tax_code_placeholder"))("readOnly", !e.isEditMode), o(), r("label", e.formatMessage("inventory_part_description_label")), o(), r("formControl", e.form.controls.description)("isEditMode", e.isEditMode)("maxLength", 500)("placeholder", "inventory_part_description_placeholder"), o(), _(e.part ? 61 : -1), o(), _(e.isMobileDevice && e.isEditMode ? 62 : -1)
    }
}

function no(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-part-category", 67), v("partCategoryCancelClick", function() {
            h(e);
            let i = p();
            return g(i.isVisibleAddCategoryPopup = !1)
        })("partCategorySaveClick", function(i) {
            h(e);
            let C = p();
            return g(C.onAddCategory(i))
        }), a()
    }
    if (t & 2) {
        let e = p();
        r("isCreate", !0)("isVisiblePopup", e.isVisibleAddCategoryPopup)
    }
}

function ro(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-part-sub-category", 68), v("partSubCategoryCancelClick", function() {
            h(e);
            let i = p();
            return g(i.isVisibleAddSubCategoryPopup = !1)
        })("partSubCategorySaveClick", function(i) {
            h(e);
            let C = p();
            return g(C.onAddSubCategory(i))
        }), a()
    }
    if (t & 2) {
        let e = p();
        r("isCreate", !0)("isVisiblePopup", e.isVisibleAddSubCategoryPopup)("partSubCategory", e.partSubCategory)
    }
}

function ao(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-barcode", 69), v("saveBarcodeNumber", function(i) {
            h(e);
            let C = p();
            return g(C.addBarcodeNumber(i))
        })("scannerToClose", function() {
            h(e);
            let i = p();
            return g(i.closeBarcodePopup())
        }), a()
    }
    if (t & 2) {
        let e = p();
        r("isViewBarcode", e.isViewBarcode)("isVisiblePopup", e.isVisibleBarcode)("oldBarcodeNumber", e.barcodeNumber)("part", e.form.value)
    }
}
var Je = (() => {
    class t {
        constructor(e, n, i, C, P, Si, yi, bi) {
            this.service = e, this.deviceTypeService = n, this.deviceBrandService = i, this.taxService = C, this.unitTypeService = P, this.partCategoryService = Si, this.partSubCategoryService = yi, this.applicationRef = bi, this.formatMessage = m, this.routerHelperService = d(Te), this.uuidService = d(Dt), this.formService = d($), this.dataService = d(Rt), this.router = d(V), this.commonService = d(we), this.userSessionService = d(O), this.activatedRouter = d(w), this.toastNotificationService = d(j), this.isMobileDevice = d(z).isMobileDevice(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = M, this.errorResponse = null, this.isSaving = !1, this.isEditMode = !1, this.isVisibleBarcode = !1, this.isViewBarcode = !1, this.partId = null, this.unitTypes = [], this.storageLocationList = [], this.isVisibleAddCategoryPopup = !1, this.isVisibleAddSubCategoryPopup = !1, this.PERMISSION_LIST = T, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.partId = +this.activatedRouter.snapshot.paramMap.get("part_id"), this.taxes$ = this.taxService.getAll(), this.unitTypes$ = this.unitTypeService.getAll(), this.dataService.getLookups().subscribe({
                next: e => {
                    this.storageLocationList = e.storage_locations
                },
                error: e => {
                    console.log("error while getting lookup ", e)
                }
            }), this.partSubCategoryService.getAll().subscribe({
                next: e => {
                    this.subCategories = e, this.subCategories.filter(n => n.part_category_id === this.form.getRawValue().category_id)
                },
                error: e => {
                    this.toastNotificationService.error("notification_get_part_sub_categories_failed")
                }
            }), this.partCategoryService.getAll().subscribe({
                next: e => {
                    this.categories = e
                },
                error: e => {
                    this.toastNotificationService.error("notification_get_part_categories_failed")
                }
            }), this.partId ? this.service.getById(this.partId).subscribe({
                next: e => {
                    this.part = new k(e), this.form = k.getForm(new k(this.part)), this.setFormReadOnly(), e.barcode_no && (this.isViewBarcode = !0, this.barcodeNumber = e.barcode_no)
                },
                error: e => {
                    this.toastNotificationService.error("notification_get_part_failed"), console.log("error fetching part by id ", e)
                }
            }) : (this.form = k.getForm(new k({})), this.part = new k({}), this.isEditMode = !0), this.addCategoryOption = {
                icon: "add",
                type: "default",
                hint: "Create New Category",
                onClick: () => {
                    this.isVisibleAddCategoryPopup = !0
                }
            }, this.addSubCategoryOption = {
                icon: "add",
                type: "default",
                hint: "Create New Sub Category",
                onClick: () => {
                    this.partSubCategory = new Z({
                        part_category_id: this.form.getRawValue().category_id
                    }), this.isVisibleAddSubCategoryPopup = !0
                }
            }, this.partId && this.barcodeNumber && (this.isViewBarcode = !0)
        }
        onAddPart() {
            this.errorResponse = null, this.form.valid ? (!this.part.id && !this.form.controls.barcode_no.value && this.generateRandomBarcodeNumberForPart(), this.isSaving = !0, (this.partId ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: n => {
                    this.part = new k(n), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.part)
                },
                error: n => {
                    this.isSaving = !1, this.errorResponse = n, this.toastNotificationService.showErrorInNotifier(n)
                }
            })) : this.formService.validateFormFields(this.form)
        }
        generateRandomBarcodeNumberForPart() {
            let e = this.uuidService.generateRandomUniqueNumber();
            this.form.patchValue({
                barcode_no: e
            })
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable()
        }
        cancel() {
            this.part ? .id ? (this.form = k.getForm(this.part), this.isEditMode = !1) : this.routerHelperService.goBack()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        afterFileUpload(e) {
            e || (this.activatedRouter.snapshot.parent.paramMap.has("part_id") ? this.toastNotificationService.success("notification_part_update_success") : this.toastNotificationService.success("notification_part_add_success"), this.router.navigate(["/parts"]))
        }
        onAddCategory(e) {
            this.isVisibleAddCategoryPopup = !1, this.categories.push(e), this.form.patchValue({
                category_id: e.id
            })
        }
        onAddSubCategory(e) {
            this.isVisibleAddSubCategoryPopup = !1, this.subCategories.push(e), this.form.patchValue({
                sub_category_id: e.id
            })
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.ENTITIES.PART.table,
                name: e.value,
                entity_id: this.partId
            }).pipe(ge(n => !!(n ? .success && n.success))).toPromise()
        }
        generateBarcode() {
            this.isVisibleBarcode = !0
        }
        ViewBarcode() {
            this.isVisibleBarcode = !0, this.isViewBarcode = !0
        }
        addBarcodeNumber(e) {
            this.barcodeNumber = e, this.isViewBarcode = !0, this.form.patchValue({
                barcode_no: this.barcodeNumber
            })
        }
        closeBarcodePopup() {
            this.isVisibleBarcode = !1
        }
        onCategoryChange(e) {
            let n = e.selectedItem ? .id;
            n && this.partSubCategoryService.getListByQuery({
                part_category_id: n
            }).subscribe({
                next: i => {
                    this.subCategories = i
                },
                error: i => {
                    this.toastNotificationService.error("notification_get_part_sub_categories_failed")
                }
            })
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(K), y(Lt), y(jt), y(Gt), y(ti), y(Re), y(Oe), y(Ze))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-basic-info"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && B(Ae, 5), n & 2) {
                        let C;
                        F(C = q()) && (i.attachmentInstance = C.first)
                    }
                },
                standalone: !1,
                decls: 5,
                vars: 5,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "isCreate", "isVisiblePopup"],
                    [3, "isCreate", "isVisiblePopup", "partSubCategory"],
                    [3, "isViewBarcode", "isVisiblePopup", "oldBarcodeNumber", "part"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start"],
                    [3, "isOnPopup", "gaEvent", "isVisibleHr", "saveText"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "mt-3", 3, "title"],
                    [1, "row"],
                    ["name", "name", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    [3, "displayError"],
                    ["name", "category_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "category_id", "searchMode", "contains", "valueExpr", "id", 3, "onSelectionChanged", "items", "placeholder", "searchEnabled"],
                    ["id", "job-basic-info-brand-btn", "location", "after", "name", "save", 3, "options"],
                    ["name", "sub_category_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "sub_category_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled"],
                    ["location", "after", "name", "save", 3, "options"],
                    ["name", "warranty", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "warranty", 3, "placeholder", "readOnly"],
                    ["name", "storage_location_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "storage_location_id", "id", "part-basic-info-storage_location", "valueExpr", "id", 3, "items", "placeholder"],
                    ["name", "quantity", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "quantity", 3, "placeholder", "readOnly"],
                    ["name", "unit", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "unit", "searchMode", "contains", 3, "items", "searchEnabled", "placeholder"],
                    ["name", "sku", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "sku", 3, "placeholder", "readOnly"],
                    ["name", "low_stock_unit", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "barcode_no", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "barcode_no", 3, "placeholder", "readOnly"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center", "justify-content-center"],
                    ["name", "is_rate_including_tax", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_rate_including_tax", 3, "isEditMode", "label"],
                    ["name", "is_manage_stock", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_manage_stock", 3, "isEditMode", "label"],
                    ["name", "is_low_stock_alert", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_low_stock_alert", 3, "isEditMode", "label"],
                    ["name", "purchase_price", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "purchase_price", 3, "min", "placeholder", "readOnly"],
                    ["name", "selling_price", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "selling_price", 3, "min", "placeholder", "readOnly"],
                    ["name", "tax_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "tax_id", "valueExpr", "id", 3, "items", "placeholder", "readOnly", "showClearButton"],
                    ["name", "tax_code", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "tax_code", 3, "placeholder", "readOnly"],
                    ["name", "description", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label"],
                    [3, "formControl", "isEditMode", "maxLength", "placeholder"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    [3, "isOnPopup", "gaEvent", "isVisibleHr", "saveText", "cancelClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "isOnPopup", "gaEvent", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    ["formControlName", "low_stock_unit", 3, "placeholder", "readOnly"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center", "justify-content-center", "pointer"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center", "justify-content-center", "pointer", 3, "click"],
                    [1, "d-flex", "border-1", "border", "rounded-2", "px-5", "py-3", "mt-1"],
                    [1, "fa-thin", "fa-barcode-read", "ms-3"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center", "justify-content-center", 3, "click"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "afterSaving", "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    [3, "partCategoryCancelClick", "partCategorySaveClick", "isCreate", "isVisiblePopup"],
                    [3, "partSubCategoryCancelClick", "partSubCategorySaveClick", "isCreate", "isVisiblePopup", "partSubCategory"],
                    [3, "saveBarcodeNumber", "scannerToClose", "isViewBarcode", "isVisiblePopup", "oldBarcodeNumber", "part"]
                ],
                template: function(n, i) {
                    n & 1 && (u(0, Fi, 1, 2, "app-skeleton-loader", 0), u(1, oo, 63, 95, "form", 1), u(2, no, 1, 2, "app-part-category", 2), u(3, ro, 1, 3, "app-part-sub-category", 3), u(4, ao, 1, 4, "app-barcode", 4)), n & 2 && (_(!i.form && i.partId ? 0 : -1), o(), _(i.form ? 1 : -1), o(), _(i.isVisibleAddCategoryPopup ? 2 : -1), o(), _(i.isVisibleAddSubCategoryPopup ? 3 : -1), o(), _(i.isVisibleBarcode ? 4 : -1))
                },
                dependencies: [_e, fe, J, Ae, Y, Nt, Ft, X, Ut, de, It, Ot, gt, Me, Ve, Ee, ue, Ne, H, U, G, xe, Q, W, le, ni, at],
                encapsulation: 2
            })
        }
    }
    return t
})();
var si = (() => {
    class t {
        constructor() {
            this.formatMessage = m, this.router = d(V), this.userSessionService = d(O), this.tenantService = d(ke), this.activatedRouter = d(w), this.plan = this.tenantService.plan(), this.userPermissionList = this.userSessionService.userPermissionList(), this.selectedTabIndex = null, this.partTabs = [], this.partId = null
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        ngOnInit() {
            this.partId = +this.activatedRouter.snapshot.paramMap.get("part_id"), this.selectedTabIndex = this.activatedRouter.firstChild.snapshot.data.tab_index, this.partTabs = [{
                id: 0,
                text: m("part_details"),
                path: `/parts/${this.partId}/details`,
                icon: "fa-thin fa-tools",
                visible: this.userPermissionList.includes(T.DEVICE_TYPE_LIST)
            }, {
                id: 1,
                text: m("part_transactions_label"),
                path: `/parts/${this.partId}/transactions`,
                icon: "fa-thin fa-file-contract",
                visible: this.userPermissionList.includes(T.DEVICE_TYPE_LIST)
            }, {
                id: 2,
                text: m("part_suppliers"),
                path: `/parts/${this.partId}/suppliers`,
                icon: "fa-thin fa-file-contract",
                disabled: [_t.LITE].includes(this.plan),
                visible: this.userPermissionList.includes(T.DEVICE_TYPE_LIST)
            }]
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-details"]
                ],
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [1, "container-fluid"],
                    ["mode", "route", "contentContainerClass", "content", "mobileMenuIcon", "fa-thin fa-gear", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "mobileMenuTitle"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "div", 0)(1, "app-responsive-tabs", 1), v("tabChange", function(P) {
                        return i.selectTab(P)
                    }), a()()), n & 2 && (o(), r("tabs", i.partTabs)("selectedIndex", i.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("mobileMenuTitle", i.formatMessage("part")))
                },
                dependencies: [De],
                encapsulation: 2
            })
        }
    }
    return t
})();
var po = (t, l) => l.id;

function co(t, l) {
    if (t & 1 && (s(0, "h3", 4), f(1), a()), t & 2) {
        let e = p();
        o(), S(e.part == null ? null : e.part.name)
    }
}

function mo(t, l) {
    if (t & 1 && (s(0, "h5", 4), f(1), a()), t & 2) {
        let e = p();
        o(), S(e.part == null ? null : e.part.name)
    }
}

function uo(t, l) {
    if (t & 1 && c(0, "app-dx-outline-button", 10), t & 2) {
        let e = p();
        r("routerLink", ve("/parts/", e.partId, "/edit"))
    }
}

function _o(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-dx-outline-button", 11), v("onClickEvent", function() {
            h(e);
            let i = p();
            return g(i.isVisibleAdjustStockPopup = !0)
        }), a()
    }
}

function fo(t, l) {
    if (t & 1 && (s(0, "div", 8)(1, "div", 12)(2, "h4")(3, "span"), f(4), a()(), s(5, "div")(6, "span", 13), f(7), a(), s(8, "span", 14), f(9), a()(), s(10, "div")(11, "span", 13), f(12), a(), s(13, "span", 14), f(14), a()(), s(15, "div")(16, "span", 13), f(17), a(), s(18, "span", 14), f(19), a()(), s(20, "div")(21, "span", 13), f(22), a(), s(23, "span", 14), f(24), a()()(), s(25, "div", 15)(26, "h4")(27, "span"), f(28), a()(), s(29, "div")(30, "span", 13), f(31), a(), s(32, "span", 14), f(33), a()(), s(34, "div")(35, "span", 13), f(36), a(), s(37, "span", 14), f(38), a()(), s(39, "div")(40, "span", 13), f(41), a(), s(42, "span", 14), f(43), a()(), s(44, "div")(45, "span", 13), f(46), a(), s(47, "span", 14), f(48), a()()(), s(49, "div", 15)(50, "h4")(51, "span"), f(52), a()(), s(53, "div")(54, "span", 13), f(55), a(), s(56, "span", 14), f(57), a()(), s(58, "div")(59, "span", 13), f(60), a(), s(61, "span", 14), f(62), a()(), s(63, "div")(64, "span", 13), f(65), a(), s(66, "span", 14), f(67), a()(), s(68, "div")(69, "span", 13), f(70), a(), s(71, "span", 14), f(72), a()()()()), t & 2) {
        let e = p();
        o(4), S(e.formatMessage("basic_information")), o(3), E("", e.formatMessage("common_name"), ":"), o(2), S(e.part.name), o(3), E("", e.formatMessage("common_category"), ":"), o(2), S(e.part.category == null ? null : e.part.category.name), o(3), E("", e.formatMessage("inventory_sub_category_label"), ":"), o(2), S(e.part.sub_category == null ? null : e.part.sub_category.name), o(3), E("", e.formatMessage("payment_warranty"), ":"), o(2), S(e.part.warranty), o(), r("ngClass", e.isMobileDevice ? "mt-3" : "part-group part-padding"), o(3), S(e.formatMessage("common_stock_information")), o(3), E("", e.formatMessage("common_current_stock"), ":"), o(2), S(e.part.quantity), o(3), E("", e.formatMessage("common_unit_type"), ":"), o(2), S(e.part.unit), o(3), S(e.formatMessage("common_low_stock_units")), o(2), S(e.part.low_stock_unit), o(3), E("", e.formatMessage("common_manage_stock"), ":"), o(2), S(e.part.is_manage_stock), o(), r("ngClass", e.isMobileDevice ? "mt-3" : "part-group part-padding"), o(3), S(e.formatMessage("common_pricing_information")), o(3), E("", e.formatMessage("common_sale_price"), ":"), o(2), S(e.part.selling_price), o(3), E("", e.formatMessage("common_purchase_price"), ":"), o(2), S(e.part.purchase_price), o(3), E("", e.formatMessage("common_tax_rate"), ":"), o(2), S(e.part.tax == null ? null : e.part.tax.rate), o(3), E("", e.formatMessage("common_hsn_code"), ":"), o(2), S(e.part.tax_code)
    }
}

function Co(t, l) {
    if (t & 1 && (s(0, "div", 2)(1, "div", 16)(2, "div", 17)(3, "div", 18), f(4), a(), s(5, "div"), f(6, ":"), a(), c(7, "div", 19), L(8, "safe"), a()()()), t & 2) {
        let e = p();
        o(4), E("", e.formatMessage("common_description"), ":"), o(3), r("innerHTML", he(8, 2, e.part == null ? null : e.part.description, "html"), Xe)
    }
}

function vo(t, l) {
    t & 1 && c(0, "hr")
}

function ho(t, l) {
    if (t & 1 && c(0, "app-image-gallery-popup", 22), t & 2) {
        let e = l.$implicit;
        r("attachment", e)("isOnTableListing", !1)
    }
}

function go(t, l) {
    if (t & 1 && (s(0, "div"), u(1, vo, 1, 0, "hr"), s(2, "h3"), f(3), a(), s(4, "div", 2)(5, "div", 20)(6, "div", 21), et(7, ho, 1, 2, "app-image-gallery-popup", 22, po), a()()()()), t & 2) {
        let e = p();
        o(), _(e.part != null && e.part.attachments.length ? 1 : -1), o(2), S(e.formatMessage("common_part_images")), o(4), tt(e.part == null ? null : e.part.attachments)
    }
}

function So(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-adjust-stock", 23), v("addAdjustStockClose", function() {
            h(e);
            let i = p();
            return g(i.isVisibleAdjustStockPopup = !1)
        }), a()
    }
    if (t & 2) {
        let e = p();
        r("isVisibleAdjustStockPopup", e.isVisibleAdjustStockPopup)("part", e.part)
    }
}
var li = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = m, this.activatedRouter = d(w), this.isMobileDevice = d(z).isMobileDevice(), this.isVisibleAdjustStockPopup = !1, this.PERMISSION_LIST = T
        }
        ngOnInit() {
            this.partId = +this.activatedRouter.parent.snapshot.paramMap.get("part_id"), this.service.getById(this.partId).subscribe({
                next: e => {
                    this.part = new k(e)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(K))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-info"]
                ],
                standalone: !1,
                decls: 15,
                vars: 8,
                consts: [
                    [1, "card"],
                    [1, "card-body"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "float-start", "fw-custom-450"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    ["buttonType", "default", "class", "me-1", "text", "common_edit", "title", "common_edit", 3, "routerLink", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "part_adjust_stock", "title", "part_adjust_stock", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    [1, "row", "mt-4", "part-detail"],
                    [3, "isVisibleAdjustStockPopup", "part"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "me-1", 3, "routerLink"],
                    ["buttonType", "default", "text", "part_adjust_stock", "title", "part_adjust_stock", 3, "onClickEvent"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "part-group"],
                    [1, "fw-bold", "lh-lg"],
                    [1, "ms-2"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", 3, "ngClass"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "part-description", "mt-4", "mb-2"],
                    [1, "d-flex"],
                    [1, "fw-bold", "part-desc"],
                    [1, "ms-2", 3, "innerHTML"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "m-5", "d-flex", "align-items-center", "flex-wrap", "gap-2"],
                    [3, "attachment", "isOnTableListing"],
                    [3, "addAdjustStockClose", "isVisibleAdjustStockPopup", "part"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), u(4, co, 2, 1, "h3", 4), u(5, mo, 2, 1, "h5", 4), a(), s(6, "div", 3)(7, "div", 5), c(8, "app-location-back"), D(9, uo, 1, 2, "app-dx-outline-button", 6)(10, _o, 1, 0, "app-dx-outline-button", 7), a()()(), u(11, fo, 73, 29, "div", 8), u(12, Co, 9, 5, "div", 2), u(13, go, 9, 2, "div"), a()(), u(14, So, 1, 2, "app-adjust-stock", 9)), n & 2 && (o(4), _(i.isMobileDevice ? -1 : 4), o(), _(i.isMobileDevice ? 5 : -1), o(4), r("ngxPermissionsOnly", i.PERMISSION_LIST.PART_WRITE), o(), r("ngxPermissionsOnly", i.PERMISSION_LIST.PART_WRITE), o(), _(i.part ? 11 : -1), o(), _(i.part != null && i.part.description ? 12 : -1), o(), _(i.part != null && i.part.attachments.length ? 13 : -1), o(), _(i.part ? 14 : -1))
                },
                dependencies: [rt, ct, Yt, At, de, le, je, Et],
                styles: [".part-group[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:1.25rem;margin-bottom:.5rem}.part-group[_ngcontent-%COMP%]{border-right:1px solid grey}.part-desc[_ngcontent-%COMP%]{width:11rem}.part-detail[_ngcontent-%COMP%]   .part-group[_ngcontent-%COMP%]:last-child{border:none}.part-group[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]:first-of-type{margin-top:2rem!important}h3[_ngcontent-%COMP%]{margin-bottom:2rem}.part-padding[_ngcontent-%COMP%]{padding-left:2.5rem}.attachments[_ngcontent-%COMP%]{gap:4rem}.attachment-container[_ngcontent-%COMP%]{width:30em;height:30em;transition:transform .4s;border:1px solid black;border-radius:5px}.attachment-container[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{width:100%;height:100%;object-fit:contain}.attachment-container[_ngcontent-%COMP%]:hover{overflow:visible;transform:scale(1.2);background-color:#fff}img[_ngcontent-%COMP%]{border-radius:5px}"]
            })
        }
    }
    return t
})();
var yo = (t, l, e, n) => [t, l, e, n],
    bo = (t, l, e) => ({
        icon: "dx-icon-box",
        title: t,
        description: l,
        primaryButtonText: "empty_state_part_primary_button",
        secondaryButtonText: "import_title",
        quickTips: e,
        tutorialUrl: "https://www.youtube.com/watch?v=9as9opymxhs",
        tutorialVisible: !0,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function xo(t, l) {
    if (t & 1 && c(0, "app-overview-report-card-on-list", 0), t & 2) {
        let e = p();
        r("entity", e.ENTITIES.PART.name)("label", e.formatMessage("overview_report_part_quick_overview_report"))
    }
}

function Po(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-adjust-stock", 4), v("addAdjustStockClose", function() {
            h(e);
            let i = p();
            return g(i.isVisibleAdjustStockPopup = !1)
        }), a()
    }
    if (t & 2) {
        let e = p();
        r("isVisibleAdjustStockPopup", e.isVisibleAdjustStockPopup)("part", e.currentPart)
    }
}
var pi = (() => {
    class t {
        get hasTenantParts() {
            return (this.tenantService.config() ? .entity_counts ? .parts || 0) > 0
        }
        constructor(e, n) {
            this.service = e, this.meta = n, this.formatMessage = m, this.ENTITIES = M, this.printService = d(Mt), this.router = d(V), this.userSessionService = d(O), this.isMobileDevice = d(z).isMobileDevice(), this.importService = d(Vt), this.isAdmin = this.userSessionService.isAdmin, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.toastNotificationService = d(j), this.tenantService = d(ke), this.currentContextMenuAction = null, this.partContextMenu = [], this.entity = M.PART, this.isVisibleArchiveDeletePopup = Be(!1), this.archiveDeleteMode = Be("delete"), this.isVisibleAdjustStockPopup = !1, this.columns = [{
                dataField: "name",
                caption: m("common_part"),
                width: this.isMobileDevice ? 100 : 130,
                allowSorting: !0
            }, {
                dataField: "category.name",
                caption: m("common_category"),
                hidingPriority: 11,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "purchase_price",
                caption: m("common_purchase_price"),
                hidingPriority: 6,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "selling_price",
                caption: m("payment_selling_price"),
                hidingPriority: 10,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "storage_location.name",
                caption: m("device_storage_location"),
                hidingPriority: 12,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "tax.name",
                caption: m("repair_services_tax"),
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "tax_code",
                caption: m("common_tax_code"),
                hidingPriority: 4,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "sku",
                caption: m("inventory_sku"),
                hidingPriority: 0,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "warranty",
                caption: m("payment_warranty"),
                hidingPriority: 8,
                allowSorting: !1
            }, {
                dataField: "low_stock_unit",
                caption: m("inventory_low_stock_unit"),
                hidingPriority: 1,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "is_manage_stock",
                caption: m("common_manage_stock"),
                hidingPriority: 9,
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                allowSorting: !1
            }, {
                dataField: "is_rate_including_tax",
                caption: m("inventory_rate_includes_tax"),
                hidingPriority: 7,
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                allowSorting: !1
            }, {
                dataField: "quantity",
                caption: m("common_qty"),
                width: this.isMobileDevice ? 100 : 130,
                allowSorting: !1,
                cellTemplate: "partUsageTemplate"
            }, {
                dataField: "barcode_no",
                caption: m("inventory_barcode_sr_no"),
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: m("common_updated_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: m("common_created_on"),
                hidingPriority: 3,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.PART_CONTEXT_MENU_LIST = N, this.meta.addTags([{
                name: "description",
                content: "List of Laptop-parts store in repair-business store"
            }, {
                name: "keywords",
                content: "cloud-based CRM, secure, Laptop, repair, services, parts , repairing-Business, recovery"
            }])
        }
        ngOnInit() {
            this.partContextMenu = [{
                name: N.PRINT_LABEL,
                icon: He.PRINT.light,
                visible: this.isEmployee,
                locale_key: m("part_action_print_label")
            }, {
                name: N.EDIT_PART,
                icon: He.PENCIL.light,
                visible: this.isEmployee && this.userPermissionList.includes(T.PART_WRITE),
                locale_key: m("part_action_edit_part")
            }, {
                name: N.ADJUST_STOCK,
                icon: vt.GENERAL.light,
                visible: this.isEmployee && this.userPermissionList.includes(T.PART_WRITE),
                locale_key: m("part_adjust_stock")
            }, {
                name: N.BARCODE,
                icon: "fa-thin fa-print",
                visible: this.isEmployee && this.userPermissionList.includes(T.PART_WRITE),
                locale_key: m("common_barcode")
            }, {
                name: N.DELETE,
                icon: "fa-thin fa-trash",
                visible: this.isEmployee && this.userPermissionList.includes(T.PART_DELETE),
                locale_key: m("part_action_delete_part")
            }]
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentPart = e.entity, this.currentContextMenuAction === N.PRINT_LABEL && (this.currentPart.barcode_no ? this.printService.getPrints(ut.THERMAL_PRINT, this.entity.name, this.currentPart ? .id) : this.toastNotificationService.error("notification_no_barcode_generated")), this.currentContextMenuAction === N.EDIT_PART && this.router.navigate([`/parts/${this.currentPart.id}/edit`]), this.currentContextMenuAction === N.ADJUST_STOCK && (this.isVisibleAdjustStockPopup = !0), this.currentContextMenuAction === N.DELETE && (this.archiveDeleteMode.set(this.currentPart.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup.set(!0)), this.currentContextMenuAction === N.BARCODE && (this.currentPart.barcode_no ? this.printService.getThermalPrint(this.ENTITIES.PART.name, this.currentPart ? .id, "barcode") : this.toastNotificationService.error("notification_no_barcode_generated"))
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentPart = null
        }
        create() {
            this.router.navigate(["/parts/add"])
        }
        handleArchiveDeleteSuccess(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(K), y(lt))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-list"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && B(A, 5), n & 2) {
                        let C;
                        F(C = q()) && (i.dataGrid = C.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 27,
                consts: [
                    [3, "entity", "label"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "columns", "contextMenuItems", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "searchPanelPlaceholderText", "isVisibleExportAction", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "isVisibleAdjustStockPopup", "part"],
                    [3, "addAdjustStockClose", "isVisibleAdjustStockPopup", "part"]
                ],
                template: function(n, i) {
                    n & 1 && (u(0, xo, 1, 2, "app-overview-report-card-on-list", 0), s(1, "app-data-grid", 1), v("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(P) {
                        return i.onContextMenuItemClick(P)
                    })("dataGridAddNewClick", function() {
                        return i.create()
                    }), a(), s(2, "app-archive-delete-popup", 2), ae("isVisibleChange", function(P) {
                        return re(i.isVisibleArchiveDeletePopup, P) || (i.isVisibleArchiveDeletePopup = P), P
                    }), v("onSuccess", function(P) {
                        return i.handleArchiveDeleteSuccess(P)
                    })("onCancel", function() {
                        return i.onCloseContextMenuOption()
                    }), a(), u(3, Po, 1, 2, "app-adjust-stock", 3)), n & 2 && (_(i.isAdmin() ? 0 : -1), o(), r("columns", i.columns)("contextMenuItems", i.partContextMenu)("entity", i.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("searchPanelPlaceholderText", "search_part")("isVisibleExportAction", i.isAdmin() && !i.isMobileDevice)("service", i.service)("hasTenantData", i.hasTenantParts)("emptyStateConfig", it(23, bo, i.formatMessage("empty_state_part_title"), i.formatMessage("empty_state_part_description"), ot(18, yo, i.formatMessage("empty_state_part_tip_1"), i.formatMessage("empty_state_part_tip_2"), i.formatMessage("empty_state_part_tip_3"), i.formatMessage("empty_state_part_import_tip")))), o(), ne("isVisible", i.isVisibleArchiveDeletePopup), r("service", i.service)("entity", i.currentPart)("entityName", i.entity == null ? null : i.entity.name)("entityDisplayName", i.entity == null ? null : i.entity.displayName)("mode", i.archiveDeleteMode()), o(), _(i.currentPart ? 3 : -1))
                },
                dependencies: [Bt, A, $t, je],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ci = (() => {
    class t extends ce {
        constructor(e) {
            super(e, mt), this.api = e
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(ie(me))
            }
        }
        static {
            this.\u0275prov = te({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Mo = t => ({
        part_id: t
    }),
    mi = (() => {
        class t {
            constructor(e) {
                this.service = e, this.formatMessage = m, this.activatedRouter = d(w), this.entity = M.PART_PART_SUPPLIERS, this.columns = [{
                    dataField: "part_supplier.name",
                    caption: m("purchase_part_supplier_name"),
                    width: 260,
                    allowSorting: !1
                }, {
                    dataField: "purchase_number",
                    caption: m("purchase_number"),
                    hidingPriority: 2,
                    allowSorting: !1,
                    cellTemplate: "idLinkTemplate"
                }, {
                    dataField: "created_user",
                    caption: m("common_created_by"),
                    hidingPriority: 1,
                    cellTemplate: "employeeTemplate",
                    allowSorting: !1
                }, {
                    dataField: "created_at",
                    caption: m("common_created_on"),
                    hidingPriority: 0,
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !1
                }], this.partId = null
            }
            ngOnInit() {
                this.partId = +this.activatedRouter.parent.snapshot.paramMap.get("part_id")
            }
            static {
                this.\u0275fac = function(n) {
                    return new(n || t)(y(ci))
                }
            }
            static {
                this.\u0275cmp = x({
                    type: t,
                    selectors: [
                        ["app-part-part-supplier-list"]
                    ],
                    standalone: !1,
                    decls: 1,
                    vars: 6,
                    consts: [
                        [3, "additionalParams", "columns", "entity", "service"]
                    ],
                    template: function(n, i) {
                        n & 1 && c(0, "app-data-grid", 0), n & 2 && r("additionalParams", be(4, Mo, i.partId))("columns", i.columns)("entity", i.entity)("service", i.service)
                    },
                    dependencies: [A],
                    encapsulation: 2
                })
            }
        }
        return t
    })();

function Eo(t, l) {
    t & 1 && c(0, "app-skeleton-loader", 0), t & 2 && r("rows", 8)("columns", 3)
}

function Io(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-save-cancel-footer", 21), v("cancelClick", function() {
            h(e);
            let i = p(2);
            return g(i.cancel())
        }), a()
    }
    if (t & 2) {
        let e = p(2);
        r("gaEvent", "create_update_part_supplier_event")("isVisibleHr", !1)("saveText", e.partSupplierId ? "common_save" : "common_create")
    }
}

function wo(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-dx-outline-button", 24), v("onClickEvent", function() {
            h(e);
            let i = p(4);
            return g(i.setEditMode())
        }), a()
    }
}

function ko(t, l) {
    if (t & 1 && D(0, wo, 1, 0, "app-dx-outline-button", 23), t & 2) {
        let e = p(3);
        r("ngxPermissionsOnly", e.PERMISSION_LIST.EMPLOYEE_WRITE)
    }
}

function Vo(t, l) {
    if (t & 1 && u(0, ko, 1, 1, "app-dx-outline-button", 22), t & 2) {
        let e = p(2);
        _(e.userPermissionList.includes(e.PERMISSION_LIST.EMPLOYEE_WRITE) ? 0 : -1)
    }
}

function No(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-server-error", 25), v("onConflictResolved", function(i) {
            h(e);
            let C = p(2);
            return g(C.onConflictResolved(i))
        }), a()
    }
    if (t & 2) {
        let e = p(2);
        r("errorResponse", e.errorResponse)("service", e.partSupplierService)("entityName", e.ENTITIES.PART_SUPPLIER.name)("entityDisplayName", e.formatMessage("purchase_part_supplier_name"))
    }
}

function Ao(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "form", 2), v("ngSubmit", function() {
            h(e);
            let i = p();
            return g(i.save())
        }), s(1, "div", 3)(2, "div", 4), u(3, Io, 1, 3, "app-save-cancel-footer", 5)(4, Vo, 1, 1), u(5, No, 1, 4, "app-server-error", 6), a()(), s(6, "h5"), f(7), a(), c(8, "hr"), s(9, "div", 7)(10, "app-control-container", 8), c(11, "dx-text-box", 9), a(), s(12, "app-control-container", 10), c(13, "app-mobile-number", 11)(14, "app-error", 12), a(), s(15, "app-control-container", 13), c(16, "app-phone-number", 14)(17, "app-error", 12), a(), s(18, "app-control-container", 15), c(19, "dx-text-box", 16)(20, "app-error", 12), a(), s(21, "app-control-container", 17), c(22, "app-email", 18), a()(), s(23, "div", 19), c(24, "app-address", 20), a()()
    }
    if (t & 2) {
        let e = p();
        r("formGroup", e.form), o(3), _(e.isEditMode ? 3 : 4), o(2), _(e.errorResponse ? 5 : -1), o(2), S(e.formatMessage("inventory_part_supplier_info")), o(3), r("errorMsg", e.formatMessage("purchase_error_messages_part_supplier_name"))("label", e.formatMessage("purchase_part_supplier_name")), o(), r("readOnly", !e.isEditMode), o(), r("errorMsg", e.formatMessage("common_mobile_number_required"))("label", e.formatMessage("common_mobile_number")), o(), r("entityId", e.form.value.id)("entity", e.ENTITIES.PART_SUPPLIER)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("form", e.form)("typeId", e.USER_TYPES.PART_SUPPLIER), o(), r("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), o(), r("errorMsg", e.formatMessage("common_phone_number_required"))("label", e.formatMessage("common_phone_number")), o(), r("isEditMode", e.isEditMode), o(), r("displayError", e.form.get("phone_number").invalid && e.form.get("phone_number").touched && e.form.get("phone_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), o(), r("errorMsg", e.formatMessage("common_tax_number_required"))("label", e.formatMessage("common_tax_number")), o(), r("readOnly", !e.isEditMode), o(), r("displayError", e.form.get("tax_number").invalid && e.form.get("tax_number").touched && e.form.get("tax_number").errors.invalidGST)("errorMsg", e.formatMessage("common_invalid_tax_number")), o(), r("errorMsg", e.formatMessage("common_email_required"))("label", e.formatMessage("common_email_id")), o(), r("entityId", e.form.value.id)("entity", e.ENTITIES.PART_SUPPLIER)("formControl", e.form.controls.email)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("typeId", e.USER_TYPES.PART_SUPPLIER), o(2), r("parentForm", e.form)
    }
}
var Le = (() => {
    class t {
        constructor(e, n) {
            this.partSupplierService = e, this.loaderService = n, this.formatMessage = m, this.ENTITIES = M, this.routerHelperService = d(Te), this.formService = d($), this.router = d(V), this.userSessionService = d(O), this.activatedRouter = d(w), this.USER_TYPES = Ct, this.userPermissionList = this.userSessionService.userPermissionList(), this.toastNotificationService = d(j), this.partSupplierId = null, this.errorResponse = null, this.isSaving = !1, this.isEditMode = !1, this.PERMISSION_LIST = T
        }
        ngOnInit() {
            this.partSupplierId = +this.activatedRouter.snapshot.parent.paramMap.get("part_supplier_id"), this.partSupplierId ? (this.loaderService.show(), this.partSupplierService.getById(this.partSupplierId).subscribe({
                next: e => {
                    this.partSupplier = new ee(e), this.form = ee.getForm(this.partSupplier), this.setFormReadOnly()
                },
                error: e => {
                    this.toastNotificationService.error("notification_supplier_load_error "), console.log("error while getting supplier by id ", e)
                }
            }).add(() => this.loaderService.hide())) : (this.partSupplier = new ee({}), this.form = ee.getForm(this.partSupplier), this.isEditMode = !0)
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable()
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.partSupplierId ? this.partSupplierService.update(this.form.value) : this.partSupplierService.create(this.form.value)).subscribe({
                next: n => {
                    this.activatedRouter.snapshot.parent.paramMap.has("part_supplier_id") ? (this.partSupplier = new ee(n), this.toastNotificationService.success("notification_part_supplier_update_success"), this.setFormReadOnly()) : (this.partSupplierId = n.id, this.toastNotificationService.success("notification_part_supplier_add_success"), this.router.navigateByUrl(`/parts/partSuppliers/${n.id}/profiles`), this.ngOnInit())
                },
                error: n => {
                    this.errorResponse = n
                }
            }).add(() => {
                this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form = ee.getForm(this.partSupplier), this.isEditMode = !1, this.routerHelperService.goBack()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.save()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(Ce), y(St))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-supplier-detail"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "gaEvent", "isVisibleHr", "saveText"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [1, "row"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", "placeholder", "Type supplier name", 3, "readOnly"],
                    ["name", "mobile_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "mobile_number", 3, "entityId", "entity", "isEditMode", "isUniqueValidation", "form", "typeId"],
                    [3, "displayError", "errorMsg"],
                    ["name", "phone_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "phone_number", 3, "isEditMode"],
                    ["name", "tax_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "tax_number", "placeholder", "Type Tax number", 3, "readOnly"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["id", "part-supplier-email", 3, "entityId", "entity", "formControl", "isEditMode", "isUniqueValidation", "typeId"],
                    [1, "mt-5"],
                    [3, "parentForm"],
                    [3, "cancelClick", "gaEvent", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"]
                ],
                template: function(n, i) {
                    n & 1 && (u(0, Eo, 1, 2, "app-skeleton-loader", 0), u(1, Ao, 25, 36, "form", 1)), n & 2 && (_(!i.form && i.partSupplierId ? 0 : -1), o(), _(i.form ? 1 : -1))
                },
                dependencies: [_e, fe, J, Y, zt, X, de, Ht, Wt, Qt, ue, H, U, G, xe, Q, W, le],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ro(t, l) {
    if (t & 1) {
        let e = b();
        s(0, "app-part-supplier", 2), v("partSupplierCancelClick", function() {
            h(e);
            let i = p();
            return g(i.isVisiblePartSupplierPopup = !1)
        })("partSupplierSave", function() {
            h(e);
            let i = p();
            return g(i.onPartSupplierSave())
        }), a()
    }
    if (t & 2) {
        let e = p();
        r("isCreate", e.isCreate)("isVisiblePopup", e.isVisiblePartSupplierPopup)("partSupplier", e.partSupplier)
    }
}
var ui = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = m, this.router = d(V), this.entity = M.PART_SUPPLIER, this.isCreate = !1, this.isVisiblePartSupplierPopup = !1, this.columns = [{
                dataField: "name",
                caption: m("common_supplier"),
                width: 160,
                allowSorting: !0
            }, {
                dataField: "mobile_number",
                caption: m("common_mobile"),
                width: 100,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "phone_number",
                caption: m("user_phone"),
                hidingPriority: 4,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "email",
                caption: m("common_email"),
                cellTemplate: "emailTemplate",
                hidingPriority: 5,
                allowSorting: !0
            }, {
                dataField: "tax_number",
                caption: m("common_tax_number"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "address.city",
                caption: m("common_city"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: m("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: m("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        onPartSupplierSave() {
            this.dataGrid.getData()
        }
        create() {
            this.router.navigate(["/parts/partSuppliers/add"])
        }
        edit(e) {
            this.router.navigate([`/parts/partSuppliers/${e.id}/profiles`])
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(Ce))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-supplier-list"]
                ],
                viewQuery: function(n, i) {
                    if (n & 1 && B(A, 5), n & 2) {
                        let C;
                        F(C = q()) && (i.dataGrid = C.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "service"],
                    [3, "isCreate", "isVisiblePopup", "partSupplier"],
                    [3, "partSupplierCancelClick", "partSupplierSave", "isCreate", "isVisiblePopup", "partSupplier"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "app-data-grid", 0), v("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(P) {
                        return i.edit(P)
                    }), a(), u(1, Ro, 1, 3, "app-part-supplier", 1)), n & 2 && (r("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !1)("service", i.service), o(), _(i.isVisiblePartSupplierPopup ? 1 : -1))
                },
                dependencies: [A, Jt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Do(t, l) {
    if (t & 1 && (c(0, "app-copy-to-clipboard", 16), L(1, "mobileDisplay")), t & 2) {
        let e = p(2);
        r("textToBeCopied", he(1, 1, e.partSupplier.mobile_number, e.partSupplier == null ? null : e.partSupplier.mobile_country_code))
    }
}

function Oo(t, l) {
    if (t & 1 && (s(0, "p", 12)(1, "strong")(2, "span", 13), c(3, "i", 18), a(), f(4), a(), f(5), a()), t & 2) {
        let e = p(2);
        o(4), E("", e.formatMessage("common_tax_number"), ": "), o(), E("", e.partSupplier.tax_number, " ")
    }
}

function jo(t, l) {
    if (t & 1 && c(0, "app-copy-to-clipboard", 16), t & 2) {
        let e = p(2);
        r("textToBeCopied", e.partSupplier.email)
    }
}

function Lo(t, l) {
    if (t & 1 && (s(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), c(4, "app-user-badge", 4), a(), s(5, "div", 5)(6, "div", 6)(7, "div", 7)(8, "h3", 8)(9, "label", 9), f(10), a()(), s(11, "div", 10)(12, "div", 11)(13, "p", 12)(14, "strong")(15, "span", 13), c(16, "i", 14), a(), f(17), a(), s(18, "a", 15), L(19, "mobileDisplay"), f(20), L(21, "mobileDisplay"), a(), u(22, Do, 2, 4, "app-copy-to-clipboard", 16), a(), u(23, Oo, 6, 2, "p", 12), s(24, "p", 12)(25, "strong")(26, "span", 13), c(27, "i", 17), a(), f(28), a(), s(29, "a", 15), f(30), a(), u(31, jo, 1, 1, "app-copy-to-clipboard", 16), a()()()()()()()()()), t & 2) {
        let e = p();
        o(4), r("iconOnly", !0)("size", e.iconSizes.LARGE)("user", e.partSupplier), o(6), S(e.partSupplier.name), o(7), E("", e.formatMessage("common_phone"), ": "), o(), r("href", ve("tel:", nt(19, 15, e.partSupplier.mobile_number, e.partSupplier == null ? null : e.partSupplier.mobile_country_code, "tel")), Fe), o(2), S(he(21, 19, e.partSupplier.mobile_number, e.partSupplier == null ? null : e.partSupplier.mobile_country_code)), o(2), _(e.partSupplier.mobile_number ? 22 : -1), o(), _(e.partSupplier.tax_number ? 23 : -1), o(5), E("", e.formatMessage("common_email"), " "), o(), r("href", ve("mailto:", e.partSupplier.email), Fe), o(), S(e.partSupplier.email), o(), _(e.partSupplier.email ? 31 : -1)
    }
}
var _i = (() => {
    class t {
        constructor() {
            this.formatMessage = m, this.iconSizes = ft
        }
        ngOnInit() {}
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-supplier-profile-info"]
                ],
                inputs: {
                    partSupplier: "partSupplier"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [1, "card"],
                    [1, "card-body"],
                    [1, "row"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "justify-content-center", "align-items-center"],
                    [3, "iconOnly", "size", "user"],
                    [1, "col-sm-5", "col-md-5", "col-lg-5"],
                    [1, "row", "mx-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "mb-0", "user-info-container"],
                    [1, "user-main-name"],
                    [1, "user-detail"],
                    [1, "d-flex", "flex-column", "user-basic-info"],
                    [1, "card-text"],
                    [1, "me-2"],
                    [1, "fa-thin", "fa-phone"],
                    [3, "href"],
                    [1, "mx-4", 3, "textToBeCopied"],
                    [1, "fa-thin", "fa-envelope"],
                    [1, "fa-thin", "fa-id-card"]
                ],
                template: function(n, i) {
                    n & 1 && u(0, Lo, 32, 22, "div", 0), n & 2 && _(i.partSupplier ? 0 : -1)
                },
                dependencies: [Pt, yt, xt],
                styles: [".user-basic-info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:.5rem}.badge[_ngcontent-%COMP%]{font-size:100%!important}.user-main-name[_ngcontent-%COMP%]{position:relative}.user-info-container[_ngcontent-%COMP%]{display:flex;padding:20px 0}.user-info-container[_ngcontent-%COMP%]   .user-main-name[_ngcontent-%COMP%]{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:70%;height:29px}.user-info-container[_ngcontent-%COMP%]   .user-title[_ngcontent-%COMP%]{font-size:12px;position:relative;top:25px;left:-20px}.fa-whatsapp[_ngcontent-%COMP%]{font-size:15px}"]
            })
        }
    }
    return t
})();

function Fo(t, l) {
    if (t & 1 && c(0, "app-part-supplier-profile-info", 0), t & 2) {
        let e = p();
        r("partSupplier", e.partSupplier)
    }
}
var fi = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = m, this.router = d(V), this.activatedRouter = d(w), this.tabs = [], this.partSupplier = null, this.partSupplierId = null, this.selectedTabIndex = 0, this.errorResponse = null, this.isEditMode = !1
        }
        ngOnInit() {
            this.partSupplierId = +this.activatedRouter.snapshot.paramMap.get("part_supplier_id"), this.partSupplierId && (this.tabs = [{
                id: 0,
                text: "Profile",
                path: `/parts/partSuppliers/${this.partSupplierId}/profiles`,
                icon: "fa-thin fa-id-card"
            }, {
                id: 1,
                text: "Purchases",
                path: `/partSupplierId/${this.partSupplierId}/profiles`,
                icon: "fa-thin fa-id-card",
                visible: !1
            }], this.initialize())
        }
        initialize() {
            this.service.getById(this.partSupplierId).subscribe({
                next: e => {
                    this.handleUserResponse(e)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        handleUserResponse(e) {
            this.partSupplier = e, this.partSupplierId = e.id
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(y(Ce))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part-supplier-profile"]
                ],
                standalone: !1,
                decls: 3,
                vars: 4,
                consts: [
                    [3, "partSupplier"],
                    [1, "mt-1", "mb-1"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-truck", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle"]
                ],
                template: function(n, i) {
                    n & 1 && (u(0, Fo, 1, 1, "app-part-supplier-profile-info", 0), s(1, "div", 1)(2, "app-responsive-tabs", 2), v("tabChange", function(P) {
                        return i.selectTab(P)
                    }), a()()), n & 2 && (_(i.partSupplier != null && i.partSupplier.id ? 0 : -1), o(2), r("tabs", i.tabs)("selectedIndex", i.selectedTabIndex)("mobileMenuTitle", i.partSupplier == null ? null : i.partSupplier.name))
                },
                dependencies: [De, _i],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ci = (() => {
    class t extends ce {
        constructor(e) {
            super(e, dt), this.api = e
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(ie(me))
            }
        }
        static {
            this.\u0275prov = te({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Uo = t => ({
        part_id: t
    }),
    vi = (() => {
        class t {
            constructor(e) {
                this.service = e, this.formatMessage = m, this.userSessionService = d(O), this.activatedRouter = d(w), this.isMobileDevice = d(z).isMobileDevice(), this.isAdmin = this.userSessionService.isAdmin(), this.entity = M.PART_TRANSACTION, this.columns = [{
                    dataField: "partable.user.name",
                    caption: m("common_name"),
                    allowSorting: !1
                }, {
                    dataField: "partable",
                    caption: m("part_transaction"),
                    cellTemplate: "usedForTemplate",
                    allowSorting: !1
                }, {
                    dataField: "quantity",
                    caption: m("common_qty"),
                    allowSorting: !1
                }, {
                    dataField: "closing_stock",
                    caption: m("inventory_closing_stock"),
                    allowSorting: !1
                }, {
                    dataField: "comment",
                    caption: m("common_remarks"),
                    allowSorting: !1,
                    cellTemplate: "commentTemplate"
                }, {
                    dataField: "created_at",
                    caption: m("common_created_on"),
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !0
                }], this.partId = null
            }
            ngOnInit() {
                this.partId = +this.activatedRouter.parent.snapshot.paramMap.get("part_id")
            }
            static {
                this.\u0275fac = function(n) {
                    return new(n || t)(y(Ci))
                }
            }
            static {
                this.\u0275cmp = x({
                    type: t,
                    selectors: [
                        ["app-part-transaction-list"]
                    ],
                    viewQuery: function(n, i) {
                        if (n & 1 && B(wt, 5), n & 2) {
                            let C;
                            F(C = q()) && (i.dataGrid = C.first)
                        }
                    },
                    standalone: !1,
                    decls: 1,
                    vars: 7,
                    consts: [
                        [3, "additionalParams", "columns", "entity", "isVisibleExportAction", "service"]
                    ],
                    template: function(n, i) {
                        n & 1 && c(0, "app-data-grid", 0), n & 2 && r("additionalParams", be(5, Uo, i.partId))("columns", i.columns)("entity", i.entity)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("service", i.service)
                    },
                    dependencies: [A],
                    encapsulation: 2
                })
            }
        }
        return t
    })();
var hi = (() => {
    class t {
        constructor() {
            this.formatMessage = m
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-part"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(n, i) {
                    n & 1 && (s(0, "div", 0), c(1, "router-outlet"), a())
                },
                dependencies: [pt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Go = [{
        path: "",
        component: hi,
        children: [{
            path: "list",
            component: pi,
            canActivate: [pe],
            data: {
                tab_index: 0,
                permissions: {
                    only: [T.PART_LIST]
                }
            },
            title: "BytePhase Inventory List"
        }, {
            path: "add",
            component: Je,
            canActivate: [pe],
            data: {
                permissions: {
                    only: [T.PART_WRITE]
                }
            },
            title: "BytePhase Inventory | Create Inventory"
        }, {
            path: ":part_id/edit",
            component: Je,
            canActivate: [pe],
            data: {
                permissions: {
                    only: [T.PART_WRITE]
                }
            },
            pathMatch: "full",
            title: "BytePhase Edit Inventory"
        }, {
            path: ":part_id",
            component: si,
            canActivate: [pe],
            data: {
                permissions: {
                    only: [T.PART_LIST]
                }
            },
            children: [{
                path: "details",
                component: li,
                data: {
                    tab_index: 0
                },
                pathMatch: "full",
                title: "BytePhase Part Details"
            }, {
                path: "transactions",
                component: vi,
                data: {
                    tab_index: 1
                },
                pathMatch: "full",
                title: "BytePhase Part Transaction History"
            }, {
                path: "suppliers",
                component: mi,
                data: {
                    tab_index: 2
                },
                pathMatch: "full",
                title: "BytePhase Part-Supplier List"
            }]
        }, {
            path: "partSuppliers/list",
            canActivate: [Pe, pe],
            component: ui,
            data: {
                entity: M.PURCHASE,
                permissions: {
                    only: [T.PART_SUPPLIER_LIST]
                }
            },
            title: "BytePhase Mange Part Suppliers"
        }, {
            path: "partSuppliers/add",
            canActivate: [Pe],
            component: Le,
            data: {
                entity: M.PURCHASE,
                permissions: {
                    only: [T.PART_SUPPLIER_WRITE]
                }
            },
            title: "BytePhase Create Part Suppliers"
        }, {
            path: "partSuppliers/:part_supplier_id",
            canActivate: [Pe],
            component: fi,
            data: {
                entity: M.PURCHASE,
                part_supplier_id: null
            },
            children: [{
                path: "profiles",
                component: Le,
                data: {
                    tab_index: 0
                },
                title: "BytePhase Part Suppliers Overview Page"
            }, {
                path: "purchases",
                component: Le,
                data: {
                    tab_index: 1,
                    permissions: {
                        only: [T.PART_SUPPLIER_WRITE]
                    }
                },
                title: "BytePhase Part Suppliers Purchases"
            }]
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }, {
            path: "**",
            redirectTo: "/errors/404"
        }]
    }],
    gi = (() => {
        class t {
            static {
                this.\u0275fac = function(n) {
                    return new(n || t)
                }
            }
            static {
                this.\u0275mod = ye({
                    type: t
                })
            }
            static {
                this.\u0275inj = Se({
                    imports: [Ue.forChild(Go), Ue]
                })
            }
        }
        return t
    })();
var Ts = (() => {
    class t {
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275mod = ye({
                type: t
            })
        }
        static {
            this.\u0275inj = Se({
                imports: [st, gi, Kt]
            })
        }
    }
    return t
})();
export {
    Ts as PartModule
};