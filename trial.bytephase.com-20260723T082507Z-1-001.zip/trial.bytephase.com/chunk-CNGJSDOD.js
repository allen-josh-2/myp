import {
    Ng as q,
    Og as Y,
    T as j,
    _d as v,
    ba as U,
    ca as G,
    jg as X,
    lb as W,
    qd as Q
} from "./chunk-DCKGQUHB.js";
import {
    $a as M,
    $b as L,
    Ab as O,
    Ai as B,
    Fa as C,
    Fh as b,
    Fi as J,
    Ka as f,
    Mh as l,
    Na as S,
    Pb as A,
    Qb as P,
    Rb as w,
    _a as g,
    bc as T,
    ea as a,
    eb as p,
    fb as u,
    fd as k,
    gb as m,
    ha as h,
    hi as E,
    ia as y,
    pd as F,
    qa as I,
    qb as D,
    sb as d,
    sd as R,
    ub as _,
    xk as t,
    yb as N,
    zb as V,
    zi as x
} from "./chunk-GOPIAW4V.js";
var z = n => ({
        customer_id: n
    }),
    H = (n, c, e) => [n, c, e],
    K = (n, c, e) => ({
        icon: "dx-icon-file",
        title: n,
        description: c,
        quickTips: e,
        quickTipsVisible: !0,
        primaryButtonVisible: !1
    });

function Z(n, c) {
    if (n & 1) {
        let e = D();
        u(0, "app-refund-popup", 3), d("saveClick", function(i) {
            h(e);
            let s = _();
            return y(s.onRefundSaveAction(i))
        })("cancelClick", function() {
            h(e);
            let i = _();
            return y(i.onCloseContextMenuOption())
        }), m()
    }
    if (n & 2) {
        let e = _();
        p("entityNumber", e.currentInvoice.invoice_number)("paymentReceived", e.currentInvoice == null || e.currentInvoice.job == null ? null : e.currentInvoice.job.payment_received)("entityType", e.ENTITIES.JOB_INVOICE.name)("entity", e.currentInvoice)("paymentEntityId", e.currentInvoice == null ? null : e.currentInvoice.job_id)("paymentEntityType", e.ENTITIES.JOB.name)("userId", e.currentInvoice == null || e.currentInvoice.job == null ? null : e.currentInvoice.job.user_id)("isVisiblePopup", (e.currentInvoice == null ? null : e.currentInvoice.id) && e.currentContextMenuAction === e.JOB_INVOICE_CONTEXT_MENU_LIST.REFUND)
    }
}
var Ie = (() => {
    class n {
        get hasTenantInvoices() {
            return (this.tenantService.config() ? .entity_counts ? .invoices || 0) > 0
        }
        constructor(e, o) {
            this.service = e, this.meta = o, this.formatMessage = t, this.ENTITIES = E, this.moduleDataService = a(X), this.router = a(R), this.userSessionService = a(U), this.activatedRouter = a(F), this.isMobileDevice = a(j).isMobileDevice(), this.toastNotificationService = a(G), this.tenantService = a(W), this.isAdmin = this.userSessionService.isAdmin, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.currentContextMenuAction = null, this.invoiceContextMenu = [], this.entity = E.JOB_INVOICE, this.customerId = null, this.isVisibleArchiveDeletePopup = I(!1), this.archiveDeleteMode = I("delete"), this.columns = [{
                dataField: "invoice_number",
                caption: t("invoice_number"),
                width: this.isMobileDevice ? 80 : 130,
                cellTemplate: "idLinkTemplate",
                allowSorting: !1
            }, {
                dataField: "job_id",
                caption: t("job_id"),
                hidingPriority: 7,
                alignment: "left",
                cellTemplate: "jobIdLinkTemplate",
                allowSorting: !1
            }, {
                dataField: "job.user",
                caption: t("user_customer_name"),
                width: (this.isMobileDevice, 130),
                cellTemplate: "userTemplate",
                allowSorting: !1
            }, {
                dataField: "status",
                caption: t("common_status"),
                hidingPriority: 5,
                cellTemplate: "invoiceStatusTemplate",
                allowSorting: !1
            }, {
                dataField: "revision",
                caption: t("revision"),
                hidingPriority: 4,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: t("common_created_by"),
                hidingPriority: 3,
                cellTemplate: "employeeTemplate",
                allowSorting: !1
            }, {
                dataField: "tax_amount",
                caption: t("tax_amt"),
                alignment: "left",
                hidingPriority: 2,
                dataType: "number",
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_amount",
                caption: t("common_amount"),
                alignment: "left",
                width: "100",
                hidingPriority: 6,
                dataType: "number",
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "updated_at",
                caption: t("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: t("common_created_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                visible: this.userPermissionList.includes(b.JOB_DELETE),
                alignment: "center"
            }], this.JOB_INVOICE_CONTEXT_MENU_LIST = l, this.meta.addTags([{
                name: "description",
                content: "Create Invoices of Services"
            }, {
                name: "keywords",
                content: "Cloud-based CRM, Secure, Laptop, Repair, Services, Parts , Repairing-Business, Recovery, billings"
            }])
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentInvoice = e.entity, this.currentContextMenuAction === l.DELETE_INVOICE && (this.archiveDeleteMode.set(this.currentInvoice.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup.set(!0))
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentInvoice = null
        }
        ngOnInit() {
            this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.invoiceContextMenu = [{
                name: l.REFUND,
                icon: x.INVOICE.light,
                visible: this.isEmployee && !this.isMobileDevice,
                locale_key: t("payment_status_refund")
            }, {
                name: l.DOWNLOAD,
                icon: J.DOWNLOAD.light,
                visible: this.isEmployee,
                locale_key: t("download"),
                handledByComponent: !0
            }, {
                name: l.DELETE_INVOICE,
                icon: B.DELETE.light,
                visible: this.userPermissionList.includes(b.JOB_INVOICE_DELETE) && this.moduleDataService.isModuleActive(this.ENTITIES.JOB_INVOICE.name),
                locale_key: t("job_invoice_action_delete_invoice")
            }]
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption()
        }
        handleArchiveDeleteSuccess(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        onRefundSaveAction(e) {
            this.router.navigate([`/jobs/${e.job_id}/invoices/${e.id}`])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || n)(f(q), f(k))
            }
        }
        static {
            this.\u0275cmp = S({
                type: n,
                selectors: [
                    ["app-invoice-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && N(v, 5), o & 2) {
                        let s;
                        V(s = O()) && (i.dataGrid = s.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 32,
                consts: [
                    ["dataGridId", "tabAndGridContainer", 3, "contextMenuItemCancelClick", "contextMenuItemClick", "additionalParams", "columns", "contextMenuItems", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleDownloadAction", "isVisibleEditAction", "isVisibleExportAction", "searchPanelPlaceholderText", "isVisibleReportDropdown", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "entityNumber", "paymentReceived", "entityType", "entity", "paymentEntityId", "paymentEntityType", "userId", "isVisiblePopup"],
                    [3, "saveClick", "cancelClick", "entityNumber", "paymentReceived", "entityType", "entity", "paymentEntityId", "paymentEntityType", "userId", "isVisiblePopup"]
                ],
                template: function(o, i) {
                    o & 1 && (u(0, "app-data-grid", 0), d("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(r) {
                        return i.onContextMenuItemClick(r)
                    }), m(), u(1, "app-archive-delete-popup", 1), w("isVisibleChange", function(r) {
                        return P(i.isVisibleArchiveDeletePopup, r) || (i.isVisibleArchiveDeletePopup = r), r
                    }), d("onSuccess", function(r) {
                        return i.handleArchiveDeleteSuccess(r)
                    })("onCancel", function() {
                        return i.onCloseContextMenuOption()
                    }), m(), g(2, Z, 1, 8, "app-refund-popup", 2)), o & 2 && (p("additionalParams", L(22, z, i.customerId))("columns", i.columns)("contextMenuItems", i.invoiceContextMenu)("entity", i.entity)("isVisibleAddAction", !1)("isVisibleDeleteAction", !1)("isVisibleDownloadAction", !1)("isVisibleEditAction", !1)("isVisibleExportAction", i.isAdmin() && !i.isMobileDevice)("searchPanelPlaceholderText", "search_panel_job_invoices_placeholder")("isVisibleReportDropdown", !0)("service", i.service)("hasTenantData", i.hasTenantInvoices)("emptyStateConfig", T(28, K, i.formatMessage("empty_state_invoice_title"), i.formatMessage("empty_state_invoice_description"), T(24, H, i.formatMessage("empty_state_invoice_tip_1"), i.formatMessage("empty_state_invoice_tip_2"), i.formatMessage("empty_state_invoice_tip_3")))), C(), A("isVisible", i.isVisibleArchiveDeletePopup), p("service", i.service)("entity", i.currentInvoice)("entityName", i.entity == null ? null : i.entity.name)("entityDisplayName", i.entity == null ? null : i.entity.displayName)("entityNumberField", "invoice_number")("mode", i.archiveDeleteMode()), C(), M(i.currentContextMenuAction === i.JOB_INVOICE_CONTEXT_MENU_LIST.REFUND ? 2 : -1))
                },
                dependencies: [Q, v, Y],
                encapsulation: 2
            })
        }
    }
    return n
})();
export {
    Ie as a
};