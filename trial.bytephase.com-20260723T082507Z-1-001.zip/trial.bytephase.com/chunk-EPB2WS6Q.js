import {
    ea as o,
    sd as a
} from "./chunk-GOPIAW4V.js";
var m = (d, s) => {
    let e = o(a),
        n = d.data.entity ? .name;
    if (!n) return console.error("Module name not provided in route data."), !1;
    try {
        let r = localStorage.getItem("tenant");
        if (!r) return console.error("Tenant data not found in localStorage."), e.navigate(["/errors/forbidden"]), !1;
        let t = JSON.parse(r) ? .active_modules;
        return !t || !Array.isArray(t) ? (console.error("Active modules not found or invalid in tenant data."), e.navigate(["/errors/forbidden"]), !1) : t.find(i => i ? .name === n) ? .is_active ? !0 : (e.navigate(["/errors/forbidden"]), !1)
    } catch (r) {
        return console.error("Error parsing tenant data in module-enabled guard:", r), e.navigate(["/errors/forbidden"]), !1
    }
};
export {
    m as a
};