import {
    a as M
} from "./chunk-36T2HUF3.js";
import {
    a as w
} from "./chunk-HUDETQT5.js";
import {
    $g as K,
    Cf as Fe,
    Ec as Be,
    Fe as j,
    Id as Pe,
    Ja as ge,
    L as ue,
    M as I,
    Pc as Me,
    Pd as Ne,
    Va as ye,
    Zd as q,
    _d as G,
    aa as ve,
    ba as fe,
    ca as be,
    cb as De,
    cd as Te,
    dd as Ie,
    e as T,
    eb as ke,
    ed as O,
    g as ne,
    h as re,
    id as we,
    j as se,
    ka as Ce,
    l as h,
    la as he,
    lb as xe,
    ld as Re,
    n as ce,
    pb as Se,
    ph as Le,
    q as le,
    rd as Ve,
    sb as Ee,
    t as pe,
    u as de
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    Ab as L,
    Ec as te,
    Fa as t,
    Fh as B,
    Ib as d,
    Jb as _,
    Ka as D,
    Kb as ie,
    Na as k,
    Oa as P,
    Sa as z,
    Tc as oe,
    Wa as X,
    Wh as _e,
    _a as m,
    ba as V,
    bc as Q,
    cb as Y,
    db as ee,
    ea as f,
    eb as c,
    fb as a,
    fd as ae,
    gb as n,
    ha as x,
    hb as p,
    hi as y,
    ia as S,
    pd as A,
    qa as Z,
    qb as E,
    qd as me,
    sb as g,
    sd as U,
    t as $,
    ub as l,
    vd as H,
    xk as v,
    yb as N,
    z as J,
    zb as F
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var Ae = (() => {
    class i {
        static {
            this.\u0275fac = function(o) {
                return new(o || i)
            }
        }
        static {
            this.\u0275cmp = k({
                type: i,
                selectors: [
                    ["app-backup-drive"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(o, r) {
                    o & 1 && (a(0, "div", 0), p(1, "router-outlet"), n())
                },
                dependencies: [me],
                encapsulation: 2
            })
        }
    }
    return i
})();
var C = class {
    constructor(s) {
        return Object.assign(this, s)
    }
    static getForm(s) {
        return new se({
            id: new h(s.id || null),
            name: new h(s.name || null, T.required),
            device_type_id: new h(s.device_type_id || null, T.required),
            device_brand_id: new h(s.device_brand_id || null, T.required),
            size: new h(s.size || null, T.required),
            device_color_id: new h(s.device_color_id || null),
            model_number: new h(s.model_number || null),
            serial_number: new h(s.serial_number || null),
            device_password: new h(s.device_password || null),
            attachments: new h(s.attachments || [])
        })
    }
};
var ze = (i, s) => s.id;

function Qe(i, s) {
    i & 1 && p(0, "app-skeleton-loader", 0), i & 2 && c("rows", 6)("columns", 3)
}

function He(i, s) {
    if (i & 1 && p(0, "app-image-gallery-popup", 11), i & 2) {
        let e = s.$implicit;
        c("attachment", e)("isOnTableListing", !1)
    }
}

function We(i, s) {
    if (i & 1 && (a(0, "div", 6), Y(1, He, 1, 2, "app-image-gallery-popup", 11, ze), n()), i & 2) {
        let e = l(2);
        t(), ee(e.backupDrive.attachments)
    }
}

function $e(i, s) {
    i & 1 && p(0, "i", 7)
}

function Je(i, s) {
    if (i & 1 && p(0, "app-backup-drive-progress-bar", 9), i & 2) {
        let e = l(2);
        c("backupDrive", e.backupDrive)("size", e.COMPONENT_SIZES.EXTRA_LARGE)
    }
}

function Ze(i, s) {
    if (i & 1 && (a(0, "div", 10)(1, "table", 12)(2, "tbody", 13)(3, "tr")(4, "th"), d(5), n(), a(6, "td"), d(7), n()(), a(8, "tr")(9, "th"), d(10), n(), a(11, "td"), d(12), n()(), a(13, "tr")(14, "th"), d(15), n(), a(16, "td"), d(17), n()(), a(18, "tr")(19, "th"), d(20), n(), a(21, "td"), d(22), a(23, "span"), d(24, "GB"), n()()(), a(25, "tr")(26, "th"), d(27), n(), a(28, "td"), d(29), a(30, "span", 14), d(31, "GB"), n()()(), a(32, "tr")(33, "th"), d(34), n(), a(35, "td"), d(36), n()()()()()), i & 2) {
        let e = l(2);
        t(5), _(e.formatMessage("device_name")), t(2), _(e.backupDrive.name), t(3), _(e.formatMessage("device_type_name")), t(2), _(e.backupDrive.device_type.name), t(3), _(e.formatMessage("device_brand_name")), t(2), _(e.backupDrive.device_brand.name), t(3), _(e.formatMessage("capacity")), t(2), ie("", e.backupDrive.size, " "), t(5), _(e.formatMessage("free_space")), t(2), _((e.backupDrive.size - e.backupDrive.backup_drive_jobs_sum_data_size).toFixed(2)), t(5), _(e.formatMessage("color")), t(2), _(e.backupDrive.device_color == null ? null : e.backupDrive.device_color.name)
    }
}

function Xe(i, s) {
    if (i & 1 && (a(0, "div", 1)(1, "div", 4)(2, "div", 5), m(3, We, 3, 0, "div", 6)(4, $e, 1, 0, "i", 7), n(), a(5, "div", 8), m(6, Je, 1, 2, "app-backup-drive-progress-bar", 9), n(), m(7, Ze, 37, 12, "div", 10), n()()), i & 2) {
        let e = l();
        t(3), u(e.backupDrive.attachments.length ? 3 : 4), t(3), u(e.backupDrive ? 6 : -1), t(), u(e.backupDrive ? 7 : -1)
    }
}
var Oe = (() => {
    class i {
        constructor(e) {
            this.service = e, this.formatMessage = v, this.activatedRouter = f(A), this.COMPONENT_SIZES = _e
        }
        ngOnInit() {
            this.backupDriveId = +this.activatedRouter.snapshot.paramMap.get("backup_drive_id"), this.backupDriveId && this.service.getById(this.backupDriveId).subscribe({
                next: e => {
                    this.backupDrive = new C(e)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || i)(D(M))
            }
        }
        static {
            this.\u0275cmp = k({
                type: i,
                selectors: [
                    ["app-backup-drive-detail"]
                ],
                standalone: !1,
                decls: 6,
                vars: 4,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    [1, "container-fluid", "rounded", "border", "p-3"],
                    [1, "row", "mt-5"],
                    [3, "backupDriveId"],
                    [1, "row", "g-5"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "justify-content-center", "align-items-center"],
                    [1, "d-flex", "align-items-center", "flex-wrap", "gap-2"],
                    [1, "fa-thin", "fa-hdd", "fa-10x", "backup-drive-big-icon"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "pt-3"],
                    [3, "backupDrive", "size"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3"],
                    [3, "attachment", "isOnTableListing"],
                    ["id", "backup-drive-table", 1, "table", "table-bordered", "theme-secondary-bg"],
                    [1, "fw-bold"],
                    [1, "ms-2"]
                ],
                template: function(o, r) {
                    o & 1 && (a(0, "h3"), d(1), n(), m(2, Qe, 1, 2, "app-skeleton-loader", 0), m(3, Xe, 8, 3, "div", 1), a(4, "div", 2), p(5, "app-backup-job-list-component", 3), n()), o & 2 && (t(), _(r.backupDrive == null ? null : r.backupDrive.name), t(), u(!r.backupDrive && r.backupDriveId ? 2 : -1), t(), u(r.backupDrive ? 3 : -1), t(2), c("backupDriveId", r.backupDriveId))
                },
                dependencies: [Pe, Fe, Ie, q],
                encapsulation: 2
            })
        }
    }
    return i
})();

function Ye(i, s) {
    i & 1 && p(0, "app-skeleton-loader", 0), i & 2 && c("rows", 6)("columns", 3)
}

function ei(i, s) {
    if (i & 1 && (a(0, "h5", 7), d(1), n()), i & 2) {
        let e = l(2);
        t(), _(e.formatMessage("create_backup_drive"))
    }
}

function ii(i, s) {
    if (i & 1) {
        let e = E();
        a(0, "app-save-cancel-footer", 34), g("cancelClick", function() {
            x(e);
            let r = l(3);
            return S(r.cancel())
        }), n()
    }
    if (i & 2) {
        let e = l(3);
        c("isVisibleHr", !1)("saveText", e.backupDriveId ? "common_save" : "create_button")
    }
}

function ti(i, s) {
    if (i & 1 && (a(0, "div", 8), z(1, ii, 1, 2, "app-save-cancel-footer", 33), n()), i & 2) {
        let e = l(2);
        t(), c("ngxPermissionsOnly", e.PERMISSION_LIST.BACKUP_DRIVE_WRITE)
    }
}

function oi(i, s) {
    if (i & 1) {
        let e = E();
        a(0, "app-dx-outline-button", 36), g("onClickEvent", function() {
            x(e);
            let r = l(4);
            return S(r.setEditMode())
        }), n()
    }
}

function ai(i, s) {
    if (i & 1 && (a(0, "div", 8), z(1, oi, 1, 0, "app-dx-outline-button", 35), n()), i & 2) {
        let e = l(3);
        t(), c("ngxPermissionsOnly", e.PERMISSION_LIST.BACKUP_DRIVE_WRITE)
    }
}

function ni(i, s) {
    if (i & 1 && m(0, ai, 2, 1, "div", 8), i & 2) {
        let e = l(2);
        u(e.userPermissionList.includes(e.PERMISSION_LIST.BACKUP_DRIVE_WRITE) ? 0 : -1)
    }
}

function ri(i, s) {
    if (i & 1) {
        let e = E();
        a(0, "app-server-error", 37), g("onConflictResolved", function(r) {
            x(e);
            let b = l(2);
            return S(b.onConflictResolved(r))
        }), n()
    }
    if (i & 2) {
        let e = l(2);
        c("errorResponse", e.errorResponse)("service", e.service)("entityName", e.ENTITIES.BACKUP_DRIVE.name)("entityDisplayName", e.formatMessage("backup_drive_name_label"))
    }
}

function si(i, s) {
    if (i & 1) {
        let e = E();
        a(0, "app-attachments", 38), g("afterSaving", function(r) {
            x(e);
            let b = l(2);
            return S(b.afterFileUpload(r))
        }), n()
    }
    if (i & 2) {
        let e = l(2);
        c("attachableType", e.ENTITIES.BACKUP_DRIVE.name)("entity", e.backupDrive)("isVisibleLabel", e.isEditMode)("isEditMode", e.isEditMode)("isMultipleUploads", !1)
    }
}

function ci(i, s) {
    if (i & 1) {
        let e = E();
        a(0, "form", 3), g("ngSubmit", function() {
            x(e);
            let r = l();
            return S(r.onAddBackupDrive())
        }), a(1, "div", 4)(2, "div", 5)(3, "div", 6), m(4, ei, 2, 1, "h5", 7), m(5, ti, 2, 1, "div", 8)(6, ni, 1, 1), n(), m(7, ri, 1, 4, "app-server-error", 9), n()(), p(8, "app-section-title", 10), a(9, "div", 11)(10, "app-control-container", 12)(11, "dx-text-box", 13)(12, "dx-validator"), p(13, "dxi-validation-rule", 14), n()()(), a(14, "app-control-container", 15), p(15, "app-select-box-with-images", 16), n(), a(16, "app-control-container", 17), p(17, "app-select-box-with-images", 18), n(), a(18, "app-control-container", 19), p(19, "dx-text-box", 20), n(), a(20, "app-control-container", 21)(21, "dx-text-box", 22), p(22, "dxi-button", 23), n()(), a(23, "app-control-container", 24)(24, "div", 25), p(25, "dx-number-box", 26), a(26, "div", 27), d(27, "GB"), n()()(), a(28, "app-control-container", 28), p(29, "app-password", 29), n(), a(30, "app-control-container", 30), p(31, "app-device-color-dropdown", 31), n()(), m(32, si, 1, 5, "app-attachments", 32), n()
    }
    if (i & 2) {
        let e = l();
        c("formGroup", e.form), t(3), c("ngClass", !e.backupDriveId && "d-flex justify-content-between align-items-center"), t(), u(e.backupDriveId ? -1 : 4), t(), u(e.isEditMode ? 5 : 6), t(2), u(e.errorResponse ? 7 : -1), t(), c("title", e.formatMessage("device_information")), t(2), c("errorMsg", e.formatMessage("backup_drive_required_error"))("label", e.formatMessage("backup_drive_name_label")), t(), c("placeholder", e.formatMessage("backup_drive_name_placeholder")), t(2), c("ignoreEmptyValue", !0)("message", e.formatMessage("backup_drive_exists_error"))("validationCallback", e.asyncUniqueNameValidation), t(), c("errorMsg", e.formatMessage("device_type_required_warning"))("label", e.formatMessage("device_type_name")), t(), c("dataSource", e.allDeviceTypeList)("placeholder", "select_device_type")("imageCategory", "device-type")("isDisabled", !e.isEditMode)("isReadOnly", !e.isEditMode)("showDropDownButton", !0), t(), c("errorMsg", e.formatMessage("device_brand_required_warning"))("label", e.formatMessage("device_brand_name")), t(), c("dataSource", e.deviceBrandList)("imageCategory", "device-brand")("isDisabled", !e.isEditMode)("isReadOnly", !e.isEditMode || !e.form.getRawValue().device_type_id)("placeholder", "device_brand_placeholder"), t(), c("errorMsg", e.formatMessage("model_number_required_error"))("label", e.formatMessage("model_number")), t(), c("placeholder", e.formatMessage("type_device_model_number")), t(), c("errorMsg", e.formatMessage("common_error_job_serial_number_required"))("label", e.formatMessage("serial_imei_number")), t(), c("placeholder", e.formatMessage("type_device_serial_number")), t(), c("options", e.addSerialBarcodeScan), t(), c("errorMsg", e.formatMessage("capacity_is_a_required_field"))("label", e.formatMessage("capacity")), t(2), c("placeholder", e.formatMessage("capacity_placeholder_label")), t(3), c("label", e.formatMessage("device_password")), t(), c("disableAutoFill", !0)("formControl", e.form.controls.device_password)("isEditMode", e.isEditMode)("placeholder", e.formatMessage("device_password")), t(), c("errorMsg", e.formatMessage("device_color_required"))("label", e.formatMessage("device_color_label")), t(), c("formControl", e.form.controls.device_color_id)("isEditMode", e.isEditMode), t(), u(e.backupDrive ? 32 : -1)
    }
}

function li(i, s) {
    if (i & 1) {
        let e = E();
        a(0, "app-qrcode-scanner", 39), g("scannerToSave", function(r) {
            x(e);
            let b = l();
            return S(b.addBarcodeNumberForSerialNumber(r))
        }), n()
    }
    if (i & 2) {
        let e = l();
        c("type", "get_barcode_number")("isVisiblePopup", e.isVisibleBarcodeScannerPopUp())
    }
}
var W = (() => {
    class i {
        constructor(e, o) {
            this.service = e, this.applicationRef = o, this.formatMessage = v, this.formService = f(Se), this.routerHelperService = f(ve), this.dataService = f(we), this.router = f(U), this.commonService = f(ke), this.userSessionService = f(fe), this.activatedRouter = f(A), this.toastNotificationService = f(be), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = y, this.errorResponse = null, this.isSaving = !1, this.isEditMode = !1, this.backupDriveId = null, this.allDeviceTypeList = [], this.PERMISSION_LIST = B, this.isVisibleBarcodeScannerPopUp = Z(!1), this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this), this.addSerialBarcodeScan = {
                icon: "fa-thin fa-barcode-read",
                type: "default",
                hint: v("scan_serial/_IMEI_number"),
                onClick: () => {
                    this.scanJob()
                }
            }
        }
        ngOnInit() {
            this.initialize(), this.backupDriveId = +this.activatedRouter.snapshot.paramMap.get("backup_drive_id"), this.backupDriveId ? this.service.getById(this.backupDriveId).subscribe({
                next: e => {
                    this.backupDrive = new C(e), this.form = C.getForm(this.backupDrive), this.subscribeToValueChangesOnDeviceId(), this.setFormReadOnly()
                },
                error: e => {
                    console.error(e)
                }
            }) : (this.form = C.getForm(new C({})), this.subscribeToValueChangesOnDeviceId(), this.backupDrive = new C({}), this.isEditMode = !0)
        }
        scanJob() {
            this.isVisibleBarcodeScannerPopUp() ? (this.isVisibleBarcodeScannerPopUp.set(!1), setTimeout(() => {
                this.isVisibleBarcodeScannerPopUp.set(!0)
            }, 0)) : this.isVisibleBarcodeScannerPopUp.set(!0)
        }
        subscribeToValueChangesOnDeviceId() {
            this.form.controls.device_type_id.valueChanges.subscribe(e => {
                this.onChangeDeviceType(e)
            })
        }
        onAddBackupDrive() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.backupDriveId ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.backupDrive = new C(o), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.backupDrive)
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => {
                this.isSaving = !1, this.router.navigate([`/backupDrives/${this.backupDrive.id}/details`])
            })) : this.formService.validateFormFields(this.form)
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable({
                emitEvent: !1
            })
        }
        cancel() {
            this.backupDrive ? .id ? (this.form = C.getForm(this.backupDrive), this.isEditMode = !1) : this.routerHelperService.goBack()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable({
                emitEvent: !1
            })
        }
        initialize() {
            J([this.dataService.getLookups()]).subscribe({
                next: ([e]) => {
                    this.allDeviceBrandList = e.device_brands, this.deviceBrandList = this.allDeviceBrandList, this.allDeviceTypeList = e.device_types
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        afterFileUpload(e) {
            e || (this.activatedRouter.snapshot.parent.paramMap.has("backup_drive_id") ? this.toastNotificationService.success("notification_backup_drive_update_success") : this.toastNotificationService.success("notification_backup_drive_add_success"), this.router.navigate([`/backupDrives/${this.backupDrive.id}/details`]))
        }
        onChangeDeviceType(e) {
            this.form.patchValue({
                device_brand_id: null
            }), this.deviceBrandList = this.allDeviceBrandList.filter(o => o.device_type_id === e)
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.ENTITIES.BACKUP_DRIVE.table,
                name: e.value,
                entity_id: this.backupDriveId
            }).pipe($(o => !!(o ? .success && o.success))).toPromise()
        }
        addBarcodeNumberForSerialNumber(e) {
            this.form.controls.serial_number.setValue(e)
        }
        onConflictResolved(e) {
            e === "permanent-delete" && this.onAddBackupDrive()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || i)(D(M), D(X))
            }
        }
        static {
            this.\u0275cmp = k({
                type: i,
                selectors: [
                    ["app-backup-drive-form"]
                ],
                viewQuery: function(o, r) {
                    if (o & 1 && N(O, 5), o & 2) {
                        let b;
                        F(b = L()) && (r.attachmentInstance = b.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 3,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "type", "isVisiblePopup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "ngClass"],
                    [1, "fw-bold", "m-0"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "mt-2", 3, "errorResponse", "service", "entityName", "entityDisplayName"],
                    [1, "mt-3", 3, "title"],
                    [1, "row"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    ["name", "device_type_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "device_type_id", 3, "dataSource", "placeholder", "imageCategory", "isDisabled", "isReadOnly", "showDropDownButton"],
                    ["name", "device_brand_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "device_brand_id", 3, "dataSource", "imageCategory", "isDisabled", "isReadOnly", "placeholder"],
                    ["name", "model_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "model_number", 3, "placeholder"],
                    ["name", "serial_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "serial_number", 3, "placeholder"],
                    ["location", "after", "name", "serialNumberBarcodeScan", 3, "options"],
                    ["name", "size", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    [1, "input-group", "p-0"],
                    ["formControlName", "size", 1, "form-control", "p-0", 3, "placeholder"],
                    [1, "input-group-text"],
                    ["name", "device_password", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "label"],
                    ["id", "job-basic-info-device-password", 3, "disableAutoFill", "formControl", "isEditMode", "placeholder"],
                    ["name", "device_color_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["id", "job-basic-info-device-color", 3, "formControl", "isEditMode"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", 3, "attachableType", "entity", "isVisibleLabel", "isEditMode", "isMultipleUploads"],
                    [3, "isVisibleHr", "saveText", "cancelClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 3, "onClickEvent"],
                    [1, "mt-2", 3, "onConflictResolved", "errorResponse", "service", "entityName", "entityDisplayName"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", 3, "afterSaving", "attachableType", "entity", "isVisibleLabel", "isEditMode", "isMultipleUploads"],
                    [3, "scannerToSave", "type", "isVisiblePopup"]
                ],
                template: function(o, r) {
                    o & 1 && (m(0, Ye, 1, 2, "app-skeleton-loader", 0), m(1, ci, 33, 47, "form", 1), m(2, li, 1, 2, "app-qrcode-scanner", 2)), o & 2 && (u(!r.form && r.backupDriveId ? 0 : -1), t(), u(r.form ? 1 : -1), t(), u(r.isVisibleBarcodeScannerPopUp() ? 2 : -1))
                },
                dependencies: [te, Ve, Ee, O, De, Te, Ne, q, Ce, j, K, Re, he, ge, Be, ye, Me, ce, ne, re, le, de, pe, ue],
                encapsulation: 2
            })
        }
    }
    return i
})();
var pi = (i, s, e) => [i, s, e],
    di = (i, s, e) => ({
        icon: "dx-icon-save",
        title: i,
        description: s,
        primaryButtonText: "empty_state_backup_drive_primary_button",
        quickTips: e,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    }),
    qe = (() => {
        class i {
            get hasTenantBackupDrives() {
                return (this.tenantService.config() ? .entity_counts ? .backup_drives || 0) > 0
            }
            constructor(e, o) {
                this.service = e, this.meta = o, this.formatMessage = v, this.router = f(U), this.tenantService = f(xe), this.entity = y.BACKUP_DRIVE, this.isCreate = !1, this.columns = [{
                    dataField: "name",
                    caption: v("common_name"),
                    cellTemplate: "idLinkTemplate",
                    width: 160,
                    allowSorting: !0
                }, {
                    dataField: "size",
                    caption: v("capacity"),
                    cellTemplate: "sizeTemplate",
                    width: 100,
                    allowSorting: !0
                }, {
                    dataField: "device_type.name",
                    caption: v("device_type_name"),
                    hidingPriority: 5,
                    allowSorting: !1
                }, {
                    dataField: "device_brand.name",
                    caption: v("device_brand_name"),
                    hidingPriority: 4,
                    allowSorting: !1
                }, {
                    dataField: "model_number",
                    caption: v("model_number"),
                    hidingPriority: 3
                }, {
                    dataField: "serial_number",
                    caption: v("serial_no"),
                    hidingPriority: 6,
                    allowSorting: !1
                }, {
                    dataField: "color",
                    caption: v("color"),
                    hidingPriority: 1,
                    cellTemplate: "colorTemplate",
                    visible: !1,
                    allowSorting: !1
                }, {
                    dataField: "created_at",
                    caption: v("common_created_on"),
                    hidingPriority: 2,
                    cellTemplate: "dateTimeTemplate",
                    visible: !1,
                    allowSorting: !0
                }, {
                    dataField: "",
                    caption: "",
                    hidingPriority: 0,
                    cellTemplate: "actionTemplate",
                    allowSorting: !1
                }], this.meta.addTags([{
                    name: "description",
                    content: "Backup Drive for Recovery-business to store Data in CloudBased CRM"
                }, {
                    name: "keywords",
                    content: "Cloud-based CRM, Secure, Laptop, Repair, Services, Parts , Repairing-Business, Recovery, Backup Drive"
                }])
            }
            create() {
                this.router.navigate(["/backupDrives/add"])
            }
            edit(e) {
                this.router.navigate([`/backupDrives/${e.id}/edit`])
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || i)(D(M), D(ae))
                }
            }
            static {
                this.\u0275cmp = k({
                    type: i,
                    selectors: [
                        ["app-backup-drive-list"]
                    ],
                    viewQuery: function(o, r) {
                        if (o & 1 && N(G, 5), o & 2) {
                            let b;
                            F(b = L()) && (r.dataGrid = b.first)
                        }
                    },
                    standalone: !1,
                    decls: 1,
                    vars: 15,
                    consts: [
                        [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "searchPanelPlaceholderText", "entity", "isVisibleDeleteAction", "service", "hasTenantData", "emptyStateConfig"]
                    ],
                    template: function(o, r) {
                        o & 1 && (a(0, "app-data-grid", 0), g("dataGridAddNewClick", function() {
                            return r.create()
                        })("dataGridEditClick", function(je) {
                            return r.edit(je)
                        }), n()), o & 2 && c("columns", r.columns)("searchPanelPlaceholderText", "search_panel_backup_drive_placeholder")("entity", r.entity)("isVisibleDeleteAction", !1)("service", r.service)("hasTenantData", r.hasTenantBackupDrives)("emptyStateConfig", Q(11, di, r.formatMessage("empty_state_backup_drive_title"), r.formatMessage("empty_state_backup_drive_description"), Q(7, pi, r.formatMessage("empty_state_backup_drive_tip_1"), r.formatMessage("empty_state_backup_drive_tip_2"), r.formatMessage("empty_state_backup_drive_tip_3"))))
                    },
                    dependencies: [G],
                    encapsulation: 2
                })
            }
        }
        return i
    })();
var mi = [{
        path: "",
        component: Ae,
        children: [{
            path: "list",
            title: "BytePhase Backup Drive list",
            canActivate: [I, w],
            component: qe,
            data: {
                tab_index: 1,
                entity: y.BACKUP_DRIVE,
                permissions: {
                    only: [B.BACKUP_DRIVE_LIST]
                }
            },
            pathMatch: "full"
        }, {
            path: "add",
            title: "BytePhase Add Backup Drive",
            canActivate: [I, w],
            component: W,
            data: {
                entity: y.BACKUP_DRIVE,
                permissions: {
                    only: [B.BACKUP_DRIVE_WRITE]
                }
            }
        }, {
            path: ":backup_drive_id/edit",
            title: "BytePhase Edit Backup Drive",
            component: W,
            canActivate: [I, w],
            data: {
                backup_drive_id: null,
                entity: y.BACKUP_DRIVE,
                permissions: {
                    only: [B.BACKUP_DRIVE_WRITE]
                }
            }
        }, {
            path: ":backup_drive_id/details",
            title: "BytePhase Backup Drive Details",
            component: Oe,
            canActivate: [I, w],
            data: {
                backup_drive_id: null,
                entity: y.BACKUP_DRIVE,
                permissions: {
                    only: [B.BACKUP_DRIVE_LIST]
                }
            }
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }, {
            path: "**",
            redirectTo: "/errors/404"
        }]
    }],
    Ge = (() => {
        class i {
            static {
                this.\u0275fac = function(o) {
                    return new(o || i)
                }
            }
            static {
                this.\u0275mod = P({
                    type: i
                })
            }
            static {
                this.\u0275inj = V({
                    imports: [H.forChild(mi), H]
                })
            }
        }
        return i
    })();
var Ot = (() => {
    class i {
        static {
            this.\u0275fac = function(o) {
                return new(o || i)
            }
        }
        static {
            this.\u0275mod = P({
                type: i
            })
        }
        static {
            this.\u0275inj = V({
                imports: [oe, Ge, Le, K, j]
            })
        }
    }
    return i
})();
export {
    Ot as BackupDriveModule
};