import {
    Pf as i,
    aa as r,
    da as o,
    ti as n,
    ui as s
} from "./chunk-GOPIAW4V.js";
var u = (() => {
    class t extends n {
        constructor(e) {
            super(e, i), this.api = e, this.endpoint = i
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(c) {
                return new(c || t)(o(s))
            }
        }
        static {
            this.\u0275prov = r({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
export {
    u as a
};