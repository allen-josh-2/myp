import {
    i as c
} from "./chunk-VSSNYSR2.js";
import {
    a as l,
    e as v,
    h as y,
    k as w
} from "./chunk-R5YFTT7F.js";
import {
    i as s
} from "./chunk-FBFWB55K.js";
var V = "ionViewWillEnter",
    k = "ionViewDidEnter",
    T = "ionViewWillLeave",
    _ = "ionViewDidLeave",
    N = "ionViewWillUnload",
    r = n => {
        n.tabIndex = -1, n.focus()
    },
    d = n => n.offsetParent !== null,
    p = () => ({
        saveViewFocus: i => {
            if (l.get("focusManagerPriority", !1)) {
                let a = document.activeElement;
                a !== null && i ? .contains(a) && a.setAttribute(b, "true")
            }
        },
        setViewFocus: i => {
            let t = l.get("focusManagerPriority", !1);
            if (Array.isArray(t) && !i.contains(document.activeElement)) {
                let a = i.querySelector(`[${b}]`);
                if (a && d(a)) {
                    r(a);
                    return
                }
                for (let o of t) switch (o) {
                    case "content":
                        let f = i.querySelector('main, [role="main"]');
                        if (f && d(f)) {
                            r(f);
                            return
                        }
                        break;
                    case "heading":
                        let g = i.querySelector('h1, [role="heading"][aria-level="1"]');
                        if (g && d(g)) {
                            r(g);
                            return
                        }
                        break;
                    case "banner":
                        let m = i.querySelector('header, [role="banner"]');
                        if (m && d(m)) {
                            r(m);
                            return
                        }
                        break;
                    default:
                        v(`Unrecognized focus manager priority value ${o}`);
                        break
                }
                r(i)
            }
        }
    }),
    b = "ion-last-focus",
    W = () =>
    import ("./chunk-PO4EVAFX.js"),
    S = () =>
    import ("./chunk-L6T5URUX.js"),
    F = p(),
    $ = n => new Promise((e, i) => {
        w(() => {
            let t = Y(n);
            B(n, t), D(n).then(a => {
                a.animation && a.animation.destroy(), L(n), e(a)
            }, a => {
                L(n), i(a)
            }).finally(() => {
                P(t, !1)
            })
        })
    }),
    B = (n, e) => {
        let i = n.enteringEl,
            t = n.leavingEl;
        F.saveViewFocus(t), O(i, t, n.direction), P(e, !0), n.showGoBack ? i.classList.add("can-go-back") : i.classList.remove("can-go-back"), C(i, !1), i.style.setProperty("pointer-events", "none"), t && (C(t, !1), t.style.setProperty("pointer-events", "none"))
    },
    D = n => s(null, null, function*() {
        let e = yield M(n);
        return e && y.isBrowser ? R(e, n) : q(n)
    }),
    L = n => {
        let e = n.enteringEl,
            i = n.leavingEl;
        e.classList.remove("ion-page-invisible"), e.style.removeProperty("pointer-events"), i !== void 0 && (i.classList.remove("ion-page-invisible"), i.style.removeProperty("pointer-events")), F.setViewFocus(e)
    },
    M = n => s(null, null, function*() {
        return !n.leavingEl || !n.animated || n.duration === 0 ? void 0 : n.animationBuilder ? n.animationBuilder : n.mode === "ios" ? (yield W()).iosTransitionAnimation : (yield S()).mdTransitionAnimation
    }),
    R = (n, e) => s(null, null, function*() {
        yield h(e, !0);
        let i = n(e.baseEl, e);
        I(e.enteringEl, e.leavingEl);
        let t = yield H(i, e);
        return e.progressCallback && e.progressCallback(void 0), t && A(e.enteringEl, e.leavingEl), {
            hasCompleted: t,
            animation: i
        }
    }),
    q = n => s(null, null, function*() {
        let e = n.enteringEl,
            i = n.leavingEl,
            t = l.get("focusManagerPriority", !1);
        return yield h(n, t), I(e, i), A(e, i), {
            hasCompleted: !0
        }
    }),
    h = (n, e) => s(null, null, function*() {
        (n.deepWait !== void 0 ? n.deepWait : e) && (yield Promise.all([E(n.enteringEl), E(n.leavingEl)])), yield x(n.viewIsReady, n.enteringEl)
    }),
    x = (n, e) => s(null, null, function*() {
        n && (yield n(e))
    }),
    H = (n, e) => {
        let i = e.progressCallback,
            t = new Promise(a => {
                n.onFinish(o => a(o === 1))
            });
        return i ? (n.progressStart(!0), i(n)) : n.play(), t
    },
    I = (n, e) => {
        u(e, T), u(n, V)
    },
    A = (n, e) => {
        u(n, k), u(e, _)
    },
    u = (n, e) => {
        if (n) {
            let i = new CustomEvent(e, {
                bubbles: !1,
                cancelable: !1
            });
            n.dispatchEvent(i)
        }
    },
    G = () => new Promise(n => c(() => c(() => n()))),
    E = n => s(null, null, function*() {
        let e = n;
        if (e) {
            if (e.componentOnReady != null) {
                if ((yield e.componentOnReady()) != null) return
            } else if (e.__registerHost != null) {
                yield new Promise(t => c(t));
                return
            }
            yield Promise.all(Array.from(e.children).map(E))
        }
    }),
    C = (n, e) => {
        e ? (n.setAttribute("aria-hidden", "true"), n.classList.add("ion-page-hidden")) : (n.hidden = !1, n.removeAttribute("aria-hidden"), n.classList.remove("ion-page-hidden"))
    },
    O = (n, e, i) => {
        n !== void 0 && (n.style.zIndex = i === "back" ? "99" : "101"), e !== void 0 && (e.style.zIndex = "100")
    },
    P = (n, e) => {
        if (!n) return;
        let i = "header-transitioning";
        e ? n.classList.add(i) : n.classList.remove(i)
    },
    Z = n => {
        if (n.classList.contains("ion-page")) return n;
        let e = n.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs");
        return e || n
    },
    Y = n => {
        let e = n.enteringEl,
            i = n.leavingEl,
            t = n.direction;
        if (n.mode !== "ios") return null;
        let o = t === "back" ? i : e;
        return o ? o.querySelector("ion-header") : null
    };
export {
    T as a, _ as b, N as c, $ as d, u as e, G as f, E as g, C as h, Z as i
};