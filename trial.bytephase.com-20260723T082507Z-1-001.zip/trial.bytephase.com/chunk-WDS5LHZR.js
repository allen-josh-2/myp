import {
    a as ps
} from "./chunk-36T2HUF3.js";
import {
    a as ms
} from "./chunk-OG4EABPU.js";
import {
    a as ji
} from "./chunk-HUDETQT5.js";
import {
    a as bo,
    b as _s
} from "./chunk-PGAHHPJ5.js";
import {
    a as tn
} from "./chunk-MBAKXBI4.js";
import {
    a as Cs,
    b as vs,
    c as fs,
    d as hs,
    e as bs,
    f as gs,
    g as xs,
    h as Ss,
    i as ys,
    j as Ts,
    k as Ms,
    l as Is
} from "./chunk-JWXBIPIQ.js";
import {
    a as Ps
} from "./chunk-FAP35UT3.js";
import {
    a as us
} from "./chunk-2KS5UOZO.js";
import {
    a as hn
} from "./chunk-KJCCJCIN.js";
import {
    $b as ye,
    $e as so,
    $g as en,
    Aa as nr,
    Ab as Vt,
    Ad as Ir,
    Ae as Yi,
    Af as $r,
    Ba as or,
    Bc as Xn,
    Bd as Er,
    Bf as Kr,
    Bg as Co,
    Cb as ki,
    Ce as Jr,
    Cf as Xr,
    Db as te,
    Dg as vo,
    Ea as ar,
    Eb as dr,
    Ec as Ji,
    Ed as ri,
    Eg as ss,
    Fb as Se,
    Fd as wr,
    Fe as $i,
    Gc as vr,
    Hb as pr,
    Hc as fr,
    Ib as mr,
    Id as Or,
    Jb as Xe,
    Kb as Ct,
    Kc as Li,
    Ke as Lr,
    Kf as Zr,
    L as Zt,
    Lb as Dt,
    Lg as Zi,
    M as z,
    Ma as ti,
    Mb as kt,
    Mc as hr,
    N as Aa,
    Nc as Bi,
    Ng as ls,
    O as Ja,
    Ob as _r,
    Pb as ur,
    Pd as Fi,
    Pf as es,
    Q as Mi,
    Qb as vt,
    Qe as xt,
    Rb as Nt,
    Rc as br,
    Re as Br,
    Rf as po,
    Sa as rr,
    Sb as Ni,
    Sc as oi,
    Sd as qi,
    T as A,
    Ta as xe,
    Tb as ft,
    Td as jr,
    Ub as Ze,
    Ud as Gi,
    Ue as Rr,
    Va as dt,
    Vb as ht,
    Vd as Vr,
    Xa as zn,
    Y as lt,
    Yd as Dr,
    Ye as Ur,
    Yg as fo,
    Z as Wn,
    Zc as U,
    Zd as ue,
    Zf as ts,
    _a as sr,
    _b as _e,
    _c as gr,
    _d as ce,
    _e as Fr,
    aa as Hn,
    ab as H,
    ac as et,
    b as Va,
    ba as L,
    bb as Vi,
    bc as Fe,
    bf as qr,
    c as Da,
    ca as D,
    cb as K,
    cc as $n,
    cd as Zn,
    cf as Gr,
    cg as is,
    db as ii,
    dd as Ri,
    dg as ns,
    dh as ho,
    e as de,
    eb as Di,
    ec as Ai,
    ed as gt,
    ee as oo,
    ef as Wr,
    eg as os,
    fb as Ke,
    fc as bt,
    fd as bn,
    fe as Wi,
    ff as lo,
    g as q,
    gd as Ui,
    ge as si,
    h as re,
    ha as W,
    hb as jt,
    he as Hi,
    hf as Ki,
    hg as as,
    hh as cs,
    ia as ct,
    ic as tt,
    id as qe,
    ie as ao,
    j as Xt,
    jb as pt,
    jc as it,
    jd as xr,
    jg as mo,
    ka as ge,
    kb as Yn,
    kd as Sr,
    kg as _o,
    l as k,
    la as Qn,
    lb as ve,
    ld as eo,
    le as kr,
    lg as rs,
    m as $e,
    ma as er,
    mb as mt,
    me as Qi,
    n as pe,
    nb as _t,
    nc as Cr,
    nf as Hr,
    ob as Re,
    of as co,
    p as ka,
    pb as me,
    pd as yr,
    ph as ds,
    q as st,
    qb as ut,
    qc as At,
    qd as to,
    rd as ai,
    re as zo,
    rg as Xi,
    sa as tr,
    sb as ee,
    sd as io,
    sg as uo,
    t as se,
    tb as Qo,
    td as no,
    te as Nr,
    tf as Qr,
    u as le,
    ub as lr,
    ue as Ar,
    va as ir,
    vb as Ee,
    vd as Tr,
    wb as cr,
    wd as Mr,
    we as ro,
    xb as ni,
    xc as Kn,
    xf as zr,
    y as Je,
    yb as Ue,
    yc as Jt,
    yf as Yr,
    zd as Pr,
    ze as zi
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    $b as fe,
    $g as Ha,
    Ab as ae,
    Ai as Ot,
    Ak as $,
    Ba as We,
    Bi as qn,
    C as Dn,
    Ca as It,
    Cf as Fa,
    Ci as be,
    Da as ba,
    Db as _n,
    Di as Oi,
    Ea as ga,
    Eb as mi,
    Ec as Q,
    Eh as ui,
    Ei as yt,
    Fa as n,
    Fb as Ae,
    Fc as Ta,
    Fg as qa,
    Fh as M,
    Fi as Gn,
    Gc as Ma,
    Gh as Ya,
    H as Jo,
    Hb as Si,
    Hg as Ga,
    Ib as d,
    Ig as ei,
    Jb as h,
    Jh as Ho,
    K as va,
    Ka as T,
    Kb as S,
    Kc as Pa,
    Kh as Ci,
    Lb as ze,
    Lc as Ia,
    Mb as Sa,
    Mc as Ea,
    Na as P,
    Nb as ya,
    Nc as Jn,
    Ng as Go,
    Oa as An,
    Od as Bo,
    Oe as Ro,
    Og as fn,
    Pb as w,
    Pc as Ln,
    Pg as Le,
    Qb as O,
    Qh as wt,
    Rb as j,
    Rc as Kt,
    Rd as La,
    Sa as E,
    Sd as Ba,
    Sh as $a,
    Tc as wa,
    Tg as Wa,
    U as fa,
    Uh as Ka,
    Vd as Ra,
    Vg as Rn,
    W as ha,
    Wa as $t,
    Wb as Ve,
    Wg as Un,
    Wh as Pi,
    Xb as un,
    Xh as Xa,
    Yf as Fo,
    Yh as he,
    Zg as Fn,
    _a as m,
    _b as Ye,
    aa as Pe,
    ab as xa,
    ac as yi,
    ai as Ii,
    ba as kn,
    bb as He,
    bc as ot,
    c as ua,
    cb as X,
    ch as Qa,
    ci as Ei,
    da as Qe,
    db as Z,
    ea as b,
    eb as l,
    eh as Wo,
    ei as wi,
    fb as r,
    fd as Oa,
    fi as at,
    gb as a,
    gc as V,
    ha as C,
    hb as u,
    hc as ie,
    hd as ja,
    hi as I,
    ia as v,
    ic as B,
    ii as Ce,
    jc as Cn,
    kc as _i,
    ki as Za,
    m as No,
    n as zt,
    na as Nn,
    nb as Lo,
    oa as J,
    og as qo,
    pd as R,
    qa as Y,
    qb as x,
    qd as Na,
    s as Ao,
    sa as Yt,
    sb as f,
    sd as G,
    sf as Ua,
    t as Ca,
    td as Ti,
    tf as Uo,
    th as F,
    ti as Be,
    ub as s,
    ug as Bn,
    ui as Ie,
    vd as vn,
    xd as Et,
    xk as g,
    yb as ne,
    z as Ne,
    zb as oe,
    zh as za,
    zi as Ut
} from "./chunk-GOPIAW4V.js";
import {
    a as Te,
    b as Ge,
    h as ma,
    i as _a
} from "./chunk-FBFWB55K.js";
var nn = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new Xt({
            backup_drive_id: new k(c.backup_drive_id || null),
            created_user_id: new k(c.created_user_id || null),
            job_id: new k(c.job_id || null, [de.required]),
            data_size: new k(c.data_size || null, [de.required]),
            comment: new k(c.comment || null)
        })
    }
};

function Al(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 5), t & 2 && l("rows", 4)("columns", 2)
}

function Jl(t, c) {
    if (t & 1 && u(0, "app-backup-drive-progress-bar", 21), t & 2) {
        let e = s().$implicit,
            o = s(3);
        l("backupDrive", e)("size", o.COMPONENT_SIZES.SMALL)
    }
}

function Ll(t, c) {
    if (t & 1 && (r(0, "div")(1, "h5"), d(2), a(), m(3, Jl, 1, 2, "app-backup-drive-progress-bar", 21), a()), t & 2) {
        let e = c.$implicit;
        n(2), h(e.name), n(), _(e ? 3 : -1)
    }
}

function Bl(t, c) {
    if (t & 1 && (r(0, "p", 15), d(1), a()), t & 2) {
        let e = s(3);
        n(), S("", e.formatMessage("not_enough_space_available_in_selected_drive"), " ")
    }
}

function Rl(t, c) {
    if (t & 1 && u(0, "app-backup-drive-progress-bar", 16), t & 2) {
        let e = s(3);
        l("backupDrive", e.selectedBackupDrive)
    }
}

function Ul(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 7), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.addBackup())
        }), r(1, "div", 8)(2, "div", 2)(3, "app-control-container", 9)(4, "dx-select-box", 10), V(5, "async"), f("onItemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.onBackupDriveSelect(i))
        }), E(6, Ll, 4, 2, "div", 1), a()(), r(7, "app-control-container", 11)(8, "div", 12), u(9, "dx-text-box", 13), r(10, "div", 14), d(11, "GB"), a()(), m(12, Bl, 2, 1, "p", 15), a(), m(13, Rl, 1, 1, "app-backup-drive-progress-bar", 16), r(14, "app-control-container", 17)(15, "app-quick-reply-dropdown", 18), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.quickReplyValue(i))
        }), a(), u(16, "app-textarea", 19), a()()(), r(17, "app-save-cancel-footer", 20), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.onCancel())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(3), l("errorMsg", e.formatMessage("backup_drive_is_required_field"))("label", e.formatMessage("select_backup_drive")), n(), l("items", ie(5, 17, e.backupDrives$))("placeholder", e.formatMessage("select_backup_drive")), n(2), l("dxTemplateOf", "item"), n(), l("errorMsg", e.formatMessage("data_size_is_a_required_field"))("label", e.formatMessage("data_size_label")), n(2), l("placeholder", e.formatMessage("enter_data_size_in_gb")), n(3), _(e.isNotEnoughSpaceError ? 12 : -1), n(), _(e.selectedBackupDrive ? 13 : -1), n(), l("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("comment")), n(2), l("quickReply", e.quickReply), n(), l("gaEvent", "add_backup_create_event")("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function Fl(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 2)(2, "div", 3), u(3, "app-job-current-info", 4), m(4, Al, 1, 2, "app-skeleton-loader", 5), m(5, Ul, 18, 19, "form", 6), a()()()), t & 2) {
        let e = s();
        n(3), l("job", e.job), n(), _(e.form ? -1 : 4), n(), _(e.form ? 5 : -1)
    }
}
var Es = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.isVisiblePopup = !1, this.addBackupSave = new J, this.addBackupClose = new J, this.formService = b(me), this.toastNotificationService = b(D), this.authService = b(Wn), this.userSessionService = b(L), this.isMobileDevice = b(A).isMobileDevice(), this.COMPONENT_SIZES = Pi, this.currentUser = this.userSessionService.currentUser(), this.selectedBackupDrive = null, this.isSaving = !1, this.isNotEnoughSpaceError = !1, this.destroyRef = b(Nn), this.service = b(Kr), this.backupDriveService = b(ps), this.loaderService = b($)
        }
        ngOnInit() {
            this.backupDrives$ = this.backupDriveService.getAll(), this.authService.currentUser.pipe(Mi(this.destroyRef)).subscribe({
                next: e => {
                    this.currentUser = e, this.form = nn.getForm(new nn({
                        job_id: this.job.id,
                        created_user_id: this.currentUser.id
                    }))
                },
                error: () => {
                    this.toastNotificationService.error("notification_error")
                }
            })
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form.reset(), this.addBackupClose.emit()
        }
        addBackup() {
            this.isNotEnoughSpaceError = !1;
            let e = this.selectedBackupDrive.size - this.selectedBackupDrive.backup_drive_jobs_sum_data_size;
            if (this.form.value.data_size > e) {
                this.isNotEnoughSpaceError = !0;
                return
            }
            this.form.valid ? (this.loaderService.show(), this.isSaving = !0, this.service.create(this.form.value).subscribe({
                next: o => {
                    this.isVisiblePopup = !1, this.toastNotificationService.success("notification_job_backup_add_success"), this.addBackupSave.emit(new nn(o))
                },
                error: () => {
                    this.toastNotificationService.error("notification_job_backup_add_error")
                }
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        onCancel() {
            this.isVisiblePopup = !1, this.form.reset(), this.addBackupClose.emit()
        }
        onBackupDriveSelect(e) {
            this.selectedBackupDrive = e.itemData
        }
        quickReplyValue(e) {
            this.quickReply = e.comment ? ? e.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-add-backup-popup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    job: "job"
                },
                outputs: {
                    addBackupSave: "addBackupSave",
                    addBackupClose: "addBackupClose"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    ["id", "assign-to-popup", 3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "job"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [2, "max-height", "calc(90vh - 260px)", "overflow-y", "auto"],
                    ["name", "backup_drive_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "backup_drive_id", "valueExpr", "id", 3, "onItemClick", "items", "placeholder"],
                    ["name", "data_size", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    [1, "input-group"],
                    ["formControlName", "data_size", "id", "backup_drive_data_size_id", 1, "form-control", "p-0", 3, "placeholder"],
                    [1, "input-group-text"],
                    [1, "text-danger"],
                    [3, "backupDrive"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["formControlName", "comment", "id", "backup_drive_Comment", 3, "quickReply"],
                    ["cancelBtnId", "add-job-backup-popup", "saveBtnId", "add-job-backup-popup", 3, "cancelClick", "gaEvent", "isOnPopup", "isSaving"],
                    [3, "backupDrive", "size"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onClosing()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, Fl, 6, 3, "div", 1), a()), o & 2 && (w("visible", i.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", i.formatMessage("add_backup")), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, Fe, K, Or, bt, ue, _e, W, H, xe, dt, pe, q, re, le, se, Ea],
                encapsulation: 2
            })
        }
    }
    return t
})();
var fi = class extends co {
    constructor(c) {
        return super(c), Object.assign(this, c)
    }
    static getForm(c, e) {
        return new Xt(Ge(Te({
            provider_id: new k(c.provider_id || null),
            delivered_by: new k(c.delivered_by || null),
            type_id: new k(c.type_id || null, [de.required]),
            job_id: new k(c.job_id || null, [de.required]),
            status_id: new k(c.status_id || null),
            assigned_user_id: new k(c.assigned_user_id || null),
            is_delivered: new k(c.is_delivered || !1),
            delivery_charges: new k(c.delivery_charges || null),
            tracking_id: new k(c.tracking_id || ""),
            term_and_condition: new k(c.term_and_condition || ""),
            comment: new k(c.comment || null),
            is_delivered_using_otp: new k(c.is_delivered_using_otp || !1),
            delivery_otp: new k(null)
        }, Wi(c, e)), {
            attachments: new k(c.attachments || [])
        }))
    }
};
var ci = (() => {
    class t extends Be {
        constructor(e) {
            super(e, Uo), this.api = e, this.endpoint = Uo
        }
        sendVerificationOtp(e) {
            return this.api.post(this.endpoint + "/sendDeliveryOtp", e)
        }
        getByJobId(e) {
            return this.api.post(this.endpoint + "/getByJobId", {
                job_id: e
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Qe(Ie))
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var ws = (() => {
    class t extends Be {
        constructor(e) {
            super(e, Ua), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Qe(Ie))
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Os = (() => {
    class t extends Be {
        constructor(e) {
            super(e, Fa), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Qe(Ie))
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Ql = (t, c) => [t, c],
    zl = (t, c) => c.courier_company_id;

function Yl(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 3), t & 2 && l("rows", 4)("columns", 2)
}

function $l(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 7), d(1), r(2, "a", 27), f("click", function() {
            C(e);
            let i = s(3);
            return v(i.redirectToJobDelivery())
        }), d(3), a(), u(4, "button", 28), a()
    }
    if (t & 2) {
        let e = s(3);
        n(), S(" ", e.formatMessage("job_already_delivered_confirmation"), " "), n(2), S(" ", e.formatMessage("click_here"))
    }
}

function Kl(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 29)(1, "div", 30)(2, "dx-switch", 31), f("onValueChanged", function() {
            C(e);
            let i = s(4);
            return v(i.toggleShippingProvider())
        }), a(), r(3, "span", 32), d(4), a()()()
    }
    if (t & 2) {
        let e = s(4);
        n(2), l("value", e.useShippingProvider), n(2), h(e.formatMessage("shipping_use_provider"))
    }
}

function Xl(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "tr", 50), f("click", function() {
            let i = C(e).$implicit,
                p = s(6);
            return v(p.selectCourier(i))
        }), r(1, "td"), u(2, "input", 51), a(), r(3, "td"), d(4), a(), r(5, "td"), d(6), a(), r(7, "td"), d(8), a()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = s(6);
        Ae("table-primary", o.selectedCourierId === e.courier_company_id), n(2), l("checked", o.selectedCourierId === e.courier_company_id), n(2), h(e.courier_name), n(2), h(e.rate), n(2), h(e.etd)
    }
}

function Zl(t, c) {
    if (t & 1 && (r(0, "div", 33)(1, "div", 34)(2, "h6", 35), d(3), a(), r(4, "div", 46)(5, "table", 47)(6, "thead", 48)(7, "tr"), u(8, "th"), r(9, "th"), d(10), a(), r(11, "th"), d(12), a(), r(13, "th"), d(14), a()()(), r(15, "tbody"), X(16, Xl, 9, 6, "tr", 49, zl), a()()()()()), t & 2) {
        let e = s(5);
        n(3), h(e.formatMessage("shipping_select_courier")), n(7), h(e.formatMessage("shipping_courier_name")), n(2), h(e.formatMessage("shipping_rate")), n(2), h(e.formatMessage("shipping_etd")), n(2), Z(e.availableCouriers)
    }
}

function ec(t, c) {
    t & 1 && (r(0, "div", 45), u(1, "dx-load-indicator", 52), a()), t & 2 && (n(), l("visible", !0))
}

function tc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 33)(1, "div", 34)(2, "h6", 35), d(3), a(), r(4, "div", 9)(5, "div", 36)(6, "label", 37), d(7), a(), r(8, "dx-number-box", 38), j("valueChange", function(i) {
            C(e);
            let p = s(4);
            return O(p.packageWeight, i) || (p.packageWeight = i), v(i)
        }), a()(), r(9, "div", 36)(10, "label", 37), d(11), a(), r(12, "dx-number-box", 39), j("valueChange", function(i) {
            C(e);
            let p = s(4);
            return O(p.packageLength, i) || (p.packageLength = i), v(i)
        }), a()(), r(13, "div", 36)(14, "label", 37), d(15), a(), r(16, "dx-number-box", 39), j("valueChange", function(i) {
            C(e);
            let p = s(4);
            return O(p.packageBreadth, i) || (p.packageBreadth = i), v(i)
        }), a()(), r(17, "div", 36)(18, "label", 37), d(19), a(), r(20, "dx-number-box", 39), j("valueChange", function(i) {
            C(e);
            let p = s(4);
            return O(p.packageHeight, i) || (p.packageHeight = i), v(i)
        }), a()()(), r(21, "div", 40)(22, "h6", 41), d(23), a(), u(24, "app-address", 42), a(), r(25, "div", 40)(26, "h6", 41), d(27), a(), u(28, "app-address", 43), a(), r(29, "dx-button", 44), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.checkServiceability())
        }), a()()(), m(30, Zl, 18, 4, "div", 33), m(31, ec, 2, 1, "div", 45)
    }
    if (t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("shipping_package_details")), n(4), h(e.formatMessage("shipping_weight_kg")), n(), w("value", e.packageWeight), l("min", .01)("max", 999)("step", .1), n(3), h(e.formatMessage("shipping_length_cm")), n(), w("value", e.packageLength), l("min", 1), n(3), h(e.formatMessage("shipping_breadth_cm")), n(), w("value", e.packageBreadth), l("min", 1), n(3), h(e.formatMessage("shipping_height_cm")), n(), w("value", e.packageHeight), l("min", 1), n(3), h(e.formatMessage("shipping_pickup_address")), n(), l("parentForm", e.pickupAddressForm)("isHrVisible", !1)("isAddressOptional", !1), n(3), h(e.formatMessage("shipping_delivery_address")), n(), l("parentForm", e.deliveryAddressForm)("isHrVisible", !1)("isAddressOptional", !1), n(), l("text", e.formatMessage("shipping_check_couriers"))("disabled", e.isCheckingServiceability), n(), _(e.availableCouriers.length > 0 ? 30 : -1), n(), _(e.isCheckingServiceability ? 31 : -1)
    }
}

function ic(t, c) {
    if (t & 1 && (r(0, "app-control-container", 53), u(1, "dx-select-box", 54), a(), r(2, "app-control-container", 55), u(3, "dx-text-box", 56), a(), r(4, "app-control-container", 57), u(5, "dx-number-box", 58), a()), t & 2) {
        let e = s(4);
        l("errorMsg", e.formatMessage("delivery_provider_required_error"))("label", e.formatMessage("delivery_provider_label")), n(), l("items", e.deliveryProviderList)("placeholder", e.formatMessage("delivery_provider_placeholder")), n(), l("errorMsg", e.formatMessage("delivery_tracking_id_required"))("label", e.formatMessage("delivery_label_tracking_id")), n(), l("placeholder", e.formatMessage("delivery_placeholder_tracking_id")), n(), l("label", e.formatMessage("delivery_label_charges")), n(), l("format", e.CURRENCY_FORMAT)("placeholder", e.formatMessage("delivery_placeholder_charges"))
    }
}

function nc(t, c) {
    if (t & 1 && (m(0, Kl, 5, 2, "div", 29), m(1, tc, 32, 27)(2, ic, 6, 10)), t & 2) {
        let e = s(3);
        _(e.isShippingActive ? 0 : -1), n(), _(e.useShippingProvider ? 1 : 2)
    }
}

function oc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-control-container", 62)(1, "app-otp-input", 63), f("otpComplete", function() {
            C(e);
            let i = s(4);
            return v(i.onDeliveryOtpComplete())
        }), a()()
    }
    if (t & 2) {
        let e, o = s(4);
        l("errorMsg", o.formatMessage("delivery_otp_required"))("label", o.formatMessage("delivery_label_verify_otp")), n(), l("hasError", ((e = o.form.get("delivery_otp")) == null ? null : e.invalid) && ((e = o.form.get("delivery_otp")) == null ? null : e.touched))
    }
}

function ac(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 21)(1, "div", 59)(2, "label", 60), d(3), a(), r(4, "app-dx-outline-button", 61), f("onClickEvent", function() {
            C(e);
            let i = s(3);
            return v(i.sendVerificationOtp())
        }), a()(), m(5, oc, 2, 3, "app-control-container", 62), a()
    }
    if (t & 2) {
        let e = s(3);
        n(3), S("", e.formatMessage("delivery_confirm_with_otp"), ":"), n(), l("disabled", e.isDisabledSendOtpBtn)("localeVariable", e.form.value.is_delivered_using_otp && e.disableSendOtpBtnTimer !== 0 && e.isDisabledSendOtpBtn ? e.disableSendOtpBtnTimer : "")("text", e.sendOtpAttempts === 0 ? "delivery_send_otp" : "delivery_resend_otp"), n(), _(e.form.getRawValue().is_delivered_using_otp ? 5 : -1)
    }
}

function rc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-attachments", 64), f("afterSaving", function(i) {
            C(e);
            let p = s(3);
            return v(p.afterFileUpload(i))
        }), a()
    }
    if (t & 2) {
        let e = s(3);
        l("attachableType", e.attachableType)("entity", e.delivery)("isEditMode", !0)("isMultipleUploads", !0)
    }
}

function sc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 5), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.useShippingProvider ? i.addDeliveryWithShipping() : i.addDelivery())
        }), r(1, "dx-scroll-view", 6), m(2, $l, 5, 2, "div", 7), u(3, "app-job-current-info", 8), r(4, "div", 9)(5, "app-control-container", 10), u(6, "dx-select-box", 11), a(), m(7, nc, 3, 2), r(8, "app-control-container", 12), u(9, "app-employee-dropdown", 13), a(), r(10, "app-control-container", 14), u(11, "app-status-dropdown", 15), a(), r(12, "app-control-container", 16), u(13, "app-employee-dropdown", 17), a(), r(14, "app-control-container", 18)(15, "app-quick-reply-dropdown", 19), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.quickReplyValue(i))
        }), a(), u(16, "app-textarea", 20), a()(), m(17, ac, 6, 5, "div", 21), m(18, rc, 1, 4, "app-attachments", 22), r(19, "app-control-container", 23), u(20, "app-textarea", 24), a(), u(21, "app-user-notification-channel", 25), a(), r(22, "app-save-cancel-footer", 26), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.onCancel())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(2), _(e.existingDelivery != null && e.existingDelivery.id ? 2 : -1), n(), l("job", e.job), n(2), l("errorMsg", e.formatMessage("delivery_mode_required_error"))("label", e.formatMessage("delivery_mode_label")), n(), l("items", e.deliveryTypes)("placeholder", e.formatMessage("delivery_mode_placeholder")), n(), _(e.form.value.type_id === 3 ? 7 : -1), n(), l("errorMsg", e.formatMessage("delivery_delivered_by_required"))("label", e.formatMessage("delivery_label_delivered_by")), n(), l("formControl", e.form.controls.delivered_by)("showClearButton", !1), n(), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status")), n(2), l("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("job_assignee_name"))("tooltipText", "job_assigned_user_id"), n(), l("showClearButton", !1), n(), l("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("comment")), n(2), l("quickReply", e.quickReply), n(), _(yi(29, Ql, e.TENANT_PLANS.STANDARD, e.TENANT_PLANS.ENTERPRISE).includes(e.plan) ? 17 : -1), n(), _(e.delivery ? 18 : -1), n(), l("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions")), n(2), l("form", e.form), n(), l("isDisabled", e.isDisableSave || e.useShippingProvider && !e.selectedCourierId)("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function lc(t, c) {
    if (t & 1 && (r(0, "div", 2), m(1, Yl, 1, 2, "app-skeleton-loader", 3), m(2, sc, 23, 32, "form", 4), a()), t & 2) {
        let e = s();
        n(), _(e.form ? -1 : 1), n(), _(e.form ? 2 : -1)
    }
}
var As = (() => {
    class t {
        constructor(e, o, i, p, y, je, Pt) {
            this.service = e, this.shippingService = o, this.deliveryTypeService = i, this.deliveryProviderService = p, this.termAndConditionService = y, this.applicationRef = je, this.loaderService = Pt, this.formatMessage = g, this.ENTITIES = I, this.isVisiblePopup = !1, this.addDeliverySave = new J, this.addDeliveryClose = new J, this.whatsappService = b(Ke), this.router = b(G), this.generalSettingDataService = b(te), this.formService = b(me), this.commonService = b(Di), this.userSessionService = b(L), this.tenantService = b(ve), this.activatedRouter = b(R), this.toastNotificationService = b(D), this.notifDefaults = b(si), this.CURRENCY_FORMAT = Ga, this.plan = this.tenantService.plan(), this.currentUser = this.userSessionService.currentUser(), this.disableSendOtpBtnTimer = 30, this.sendOtpAttempts = 0, this.intervalSubscription = null, this.intervalSource = null, this.isSaving = !1, this.isDisabledSendOtpBtn = !1, this.isDisableSave = !1, this.deliveryId = null, this.attachableType = this.ENTITIES.JOB_DELIVERY.name, this.TENANT_PLANS = Le, this.isShippingActive = !1, this.useShippingProvider = !1, this.isCheckingServiceability = !1, this.isCreatingShipment = !1, this.availableCouriers = [], this.selectedCourierId = null, this.packageWeight = .5, this.packageLength = 10, this.packageBreadth = 10, this.packageHeight = 10, this.fb = b(Je), this.asyncOtpValidation = this.asyncOtpValidation.bind(this)
        }
        ngOnInit() {
            this.deliveryId = +this.activatedRouter.snapshot.paramMap.get("delivery_id"), this.shippingService.getProviderStatus().subscribe({
                next: o => {
                    this.isShippingActive = o.connected && o.token_valid
                }
            });
            let e = this.job ? .user ? .address;
            this.pickupAddressForm = this.fb.group({
                address: this.fb.group({
                    address_line: [""],
                    city: [""],
                    state: [""],
                    zip_code: [""]
                })
            }), this.deliveryAddressForm = this.fb.group({
                address: this.fb.group({
                    address_line: [e ? .address_line || ""],
                    city: [e ? .city || ""],
                    state: [e ? .state || ""],
                    zip_code: [e ? .zip_code || ""]
                })
            }), Ne([this.deliveryTypeService.getListByQuery(), this.deliveryProviderService.getListByQuery(), this.termAndConditionService.getByTypeId({
                type_id: at.JOB_DELIVERY
            })]).subscribe({
                next: ([o, i, p]) => {
                    this.deliveryTypes = o, this.deliveryProviderList = i, this.delivery = new fi({
                        job_id: this.job.id,
                        assigned_user_id: this.job.assigned_user_id,
                        status_id: this.generalSettingDataService.getGeneralSettingByKey("adding_delivery_next_job_status") ? ? this.job.status_id,
                        term_and_condition: p ? .text ? ? "",
                        delivered_by: this.currentUser.id
                    }), this.form = fi.getForm(this.delivery, this.notifDefaults.getEntityDefaults(Et.DELIVERY))
                },
                error: o => {
                    this.toastNotificationService.error("notification_delivery_detail_fetch_error"), console.error(o)
                }
            })
        }
        asyncOtpValidation(e) {
            return this.commonService.validateOtp({
                otp: this.form.value.delivery_otp,
                verification_type: Ka.JOB_DELIVERY_OTP
            }).pipe(Ca(o => (o.hasOwnProperty("success") && o.success && (this.isDisableSave = !1), !!(o.hasOwnProperty("success") && o.success)))).toPromise()
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form.reset(), this.addDeliveryClose.emit()
        }
        addDelivery() {
            this.form.valid ? (this.loaderService.show(), this.isSaving = !0, this.service.create(this.form.value).subscribe({
                next: e => {
                    this.form.value.is_send_whatsapp && this.whatsappService.sendWhatsappMessage(this.ENTITIES.JOB_DELIVERY.name, e.id), this.isVisiblePopup = !1, this.delivery = new fi(e), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.delivery), this.addDeliverySave.emit(this.delivery), this.router.navigateByUrl(`/jobs/${e.job_id}/deliveryReceipts/${e.id}`)
                },
                error: () => {
                    this.toastNotificationService.error("notification_delivery_add_error")
                }
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        onCancel() {
            this.isVisiblePopup = !1, this.form.reset(), this.addDeliveryClose.emit()
        }
        sendVerificationOtp() {
            this.form.patchValue({
                is_delivered_using_otp: !0
            }), this.form.controls.delivery_otp.setValidators([de.required]), this.form.controls.delivery_otp.updateValueAndValidity(), this.isDisabledSendOtpBtn = !0, this.service.sendVerificationOtp({
                job_id: this.job.id
            }).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_otp_sent_sms_email_success"), this.disableSendOtpForDuration()
                },
                error: e => {
                    console.error(g("error_while_sending_otp") + " ", e)
                }
            })
        }
        disableSendOtpForDuration() {
            this.isDisableSave = !0, this.intervalSource = Dn(1e3), this.intervalSubscription = this.intervalSource.subscribe({
                next: () => {
                    this.disableSendOtpBtnTimer !== 0 ? this.disableSendOtpBtnTimer-- : this.unsubscribeIntervalAndEnableResendOtp()
                },
                error: e => {
                    console.error(g("error_in_internal_subscription") + " ", e)
                }
            })
        }
        unsubscribeIntervalAndEnableResendOtp() {
            this.isDisabledSendOtpBtn = !1, this.disableSendOtpBtnTimer = 30, this.sendOtpAttempts++, this.intervalSubscription && this.intervalSubscription.unsubscribe()
        }
        afterFileUpload(e) {
            e || (this.isSaving = !1, this.toastNotificationService.success(this.deliveryId ? "notification_delivery_create_success" : "notification_delivery_update_success"), this.isSaving = !1, this.redirectToJobDelivery())
        }
        redirectToJobDelivery() {
            this.router.navigateByUrl(`/jobs/${this.existingDelivery?.job_id}/deliveryReceipts/${this.existingDelivery?.id}`)
        }
        onDeliveryOtpComplete() {
            this.form.get("delivery_otp") ? .value ? .length === 6 && this.asyncOtpValidation({
                value: this.form.get("delivery_otp") ? .value
            }).then(e => {
                e || this.form.get("delivery_otp") ? .setErrors({
                    otpInvalid: !0
                })
            }).catch(() => {
                this.form.get("delivery_otp") ? .setErrors({
                    otpInvalid: !0
                })
            })
        }
        toggleShippingProvider() {
            this.useShippingProvider = !this.useShippingProvider, this.availableCouriers = [], this.selectedCourierId = null
        }
        checkServiceability() {
            let e = this.pickupAddressForm.get("address.zip_code") ? .value,
                o = this.deliveryAddressForm.get("address.zip_code") ? .value;
            if (!e || !o || !this.packageWeight) {
                this.toastNotificationService.error("shipping_fill_required_fields");
                return
            }
            this.isCheckingServiceability = !0, this.availableCouriers = [], this.shippingService.checkServiceability({
                pickup_pincode: e,
                delivery_pincode: o,
                weight: this.packageWeight
            }).subscribe({
                next: i => {
                    this.availableCouriers = i ? .data ? .available_courier_companies || [], this.availableCouriers.length === 0 && this.toastNotificationService.error("shipping_no_couriers_available")
                },
                error: () => {
                    this.toastNotificationService.error("shipping_serviceability_error")
                },
                complete: () => {
                    this.isCheckingServiceability = !1
                }
            })
        }
        selectCourier(e) {
            this.selectedCourierId = e.courier_company_id, this.form.patchValue({
                delivery_charges: e.rate,
                tracking_id: ""
            })
        }
        createShipment(e) {
            this.isCreatingShipment = !0;
            let o = this.pickupAddressForm.get("address") ? .value,
                i = this.deliveryAddressForm.get("address") ? .value,
                p = {
                    shipable_type: "job_delivery",
                    shipable_id: e,
                    courier_id: this.selectedCourierId,
                    package_weight: this.packageWeight,
                    package_dimensions: {
                        length: this.packageLength,
                        breadth: this.packageBreadth,
                        height: this.packageHeight
                    },
                    pickup_address: {
                        name: this.currentUser.name || "Business",
                        phone: this.currentUser.mobile_number || this.currentUser.phone_number || "",
                        address: o.address_line,
                        city: o.city,
                        state: o.state,
                        pincode: o.zip_code,
                        country: "India"
                    },
                    delivery_address: {
                        name: this.job ? .user ? .name || "",
                        phone: this.job ? .user ? .mobile_number || this.job ? .user ? .phone_number || "",
                        email: this.job ? .user ? .email || "",
                        address: i.address_line,
                        address_2: "",
                        city: i.city,
                        state: i.state,
                        pincode: i.zip_code,
                        country: "India"
                    },
                    payment_mode: "prepaid"
                };
            this.shippingService.createShipment(p).subscribe({
                next: y => {
                    this.toastNotificationService.success("shipping_shipment_created"), this.isCreatingShipment = !1
                },
                error: () => {
                    this.toastNotificationService.error("shipping_shipment_create_error"), this.isCreatingShipment = !1
                }
            })
        }
        addDeliveryWithShipping() {
            this.form.valid && this.selectedCourierId ? (this.loaderService.show(), this.isSaving = !0, this.service.create(this.form.value).subscribe({
                next: e => {
                    this.form.value.is_send_whatsapp && this.whatsappService.sendWhatsappMessage(this.ENTITIES.JOB_DELIVERY.name, e.id), this.delivery = new fi(e), this.createShipment(e.id), this.isVisiblePopup = !1, this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.delivery), this.addDeliverySave.emit(this.delivery), this.router.navigateByUrl(`/jobs/${e.job_id}/deliveryReceipts/${e.id}`)
                },
                error: () => {
                    this.toastNotificationService.error("notification_delivery_add_error")
                },
                complete: () => {
                    this.loaderService.hide(), this.isSaving = !1
                }
            })) : this.selectedCourierId ? this.formService.validateFormFields(this.form) : this.toastNotificationService.error("shipping_select_courier")
        }
        quickReplyValue(e) {
            this.quickReply = e.comment ? ? e.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ci), T(bo), T(ws), T(Os), T(Ct), T($t), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-add-delivery-popup"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(gt, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.attachmentInstance = p.first)
                    }
                },
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    job: "job",
                    existingDelivery: "existingDelivery"
                },
                outputs: {
                    addDeliverySave: "addDeliverySave",
                    addDeliveryClose: "addDeliveryClose"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    ["id", "assign-to-popup", 3, "onHidden", "visibleChange", "visible", "maxHeight", "maxWidth", "width", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "flex-column", "h-100"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    ["role", "alert", 1, "alert", "alert-dismissible", "fade", "show", "alert-warning"],
                    [3, "job"],
                    [1, "row"],
                    ["name", "type_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "type_id", "id", "add-delivery-popup-delivery-mode", "valueExpr", "id", 3, "items", "placeholder"],
                    ["name", "delivered_by", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["placeholder", "delivery_placeholder_delivered_by", 3, "formControl", "showClearButton"],
                    ["name", "status_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status_id"],
                    ["name", "assigned_user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label", "tooltipText"],
                    ["formControlName", "assigned_user_id", "id", "assign-to-popup-assignee", "placeholder", "delivery_placeholder_assignee", 3, "showClearButton"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["formControlName", "comment", "id", "add-delivery-popup-comment", 3, "quickReply"],
                    [1, "row", "mb-3"],
                    ["accept", "image/*,application/pdf,application/msword,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition"],
                    [3, "form"],
                    ["cancelBtnId", "add-delivery-popup", "saveBtnId", "add-delivery-popup", 3, "cancelClick", "isDisabled", "isOnPopup", "isSaving"],
                    [2, "color", "blue", 3, "click"],
                    ["aria-label", "Close", "data-bs-dismiss", "alert", "type", "button", 1, "btn-close"],
                    [1, "col-12", "mb-2"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [3, "onValueChanged", "value"],
                    [1, "fw-semibold"],
                    [1, "col-12"],
                    [1, "card", "border", "p-3", "mb-2"],
                    [1, "mb-2"],
                    [1, "col-6", "col-md-3", "mb-2"],
                    [1, "form-label", "small"],
                    [3, "valueChange", "value", "min", "max", "step"],
                    [3, "valueChange", "value", "min"],
                    [1, "border", "rounded", "p-2", "mb-2"],
                    [1, "mb-0"],
                    ["columnClass", "col-6 col-md-3", "id", "shipping-pickup-address", 3, "parentForm", "isHrVisible", "isAddressOptional"],
                    ["columnClass", "col-6 col-md-3", "id", "shipping-delivery-address", 3, "parentForm", "isHrVisible", "isAddressOptional"],
                    ["type", "default", "stylingMode", "outlined", 3, "onClick", "text", "disabled"],
                    [1, "col-12", "text-center", "mb-2"],
                    [1, "table-responsive", 2, "max-height", "200px", "overflow-y", "auto"],
                    [1, "table", "table-sm", "table-hover", "mb-0"],
                    [1, "table-light"],
                    [2, "cursor", "pointer", 3, "table-primary"],
                    [2, "cursor", "pointer", 3, "click"],
                    ["type", "radio", 3, "checked"],
                    ["height", "40", "width", "40", 3, "visible"],
                    ["name", "provider_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "provider_id", "id", "add-delivery-popup-provider-id", "valueExpr", "id", 3, "items", "placeholder"],
                    ["name", "tracking_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "tracking_id", "id", "add-delivery-popup-tracking_id", 3, "placeholder"],
                    ["name", "delivery_charges", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["formControlName", "delivery_charges", "id", "add-delivery-popup-delivery-charges", 3, "format", "placeholder"],
                    [1, "col-12", "col-md-4", "col-lg-4"],
                    [1, "me-2"],
                    ["buttonType", "default", 3, "onClickEvent", "disabled", "localeVariable", "text"],
                    ["name", "delivery_otp", 1, "col-12", "col-md-8", "col-lg-8", 3, "errorMsg", "label"],
                    ["formControlName", "delivery_otp", 3, "otpComplete", "hasError"],
                    ["accept", "image/*,application/pdf,application/msword,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "afterSaving", "attachableType", "entity", "isEditMode", "isMultipleUploads"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onClosing()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, lc, 3, 2, "div", 1), a()), o & 2 && (w("visible", i.isVisiblePopup), l("maxHeight", "90vh")("maxWidth", 600)("width", "95vw")("title", i.formatMessage("add_delivery")), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, gt, et, Fe, K, zi, Re, bt, cs, ue, ge, _e, Qi, W, ct, Xn, Ji, H, ye, xe, Li, dt, pe, q, re, st, le, se],
                encapsulation: 2
            })
        }
    }
    return t
})();

function hc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 6), u(1, "app-select-box-with-images", 25), a()), t & 2) {
        let e = s();
        l("errorMsg", e.formatMessage("device_model_required_error"))("label", e.formatMessage("device_model_name")), n(), l("dataSource", e.deviceModelList)("imageCategory", "device-model")("isReadOnly", !e.deviceForm.controls.device_brand_id.value)("isDxiButtonActive", !0)("hasUserPermissions", e.PERMISSION_LIST.DEVICE_MODEL_WRITE)("buttonOptions", e.addDeviceModelOption)("buttonId", "bulk-device-model-add")("buttonName", "deviceModel")("placeholder", "device_model_placeholder")
    }
}

function bc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 7)(1, "dx-text-box", 26), u(2, "dxi-button", 27), a()()), t & 2) {
        let e = s();
        l("errorMsg", e.formatMessage("common_error_job_serial_number_required"))("label", e.formatMessage("device_serial_imei_number")), n(), l("placeholder", e.formatMessage("device_serial_number_placeholder")), n(), l("options", e.addSerialBarcodeScan)
    }
}

function gc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 8), u(1, "app-tag-box-with-images", 28), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("accessories")), n(), l("products", e.deviceTypeAccessoriesList)("isDxiButtonActive", !0)("hasUserPermissions", e.PERMISSION_LIST.ACCESSORY_WRITE)("buttonOptions", e.addAccessoryOption)("buttonId", "bulk-device-accessory-add")("buttonName", "accessory")("isReadOnly", !e.deviceForm.controls.device_type_id.value)("placeholder", "device_accessories_placeholder")("imageCategory", "accessory")
    }
}

function xc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 9), u(1, "dx-select-box", 29), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("device_storage_location")), n(), l("items", e.storageLocations)("placeholder", e.formatMessage("device_storage_location_placeholder"))
    }
}

function Sc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 10), u(1, "app-device-color-dropdown", 30), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("device_color_label")), n(), l("formControl", e.deviceForm.controls.device_color_id)("isEditMode", !0)
    }
}

function yc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-control-container", 11)(1, "app-password", 31), f("onPatternLockClick", function() {
            C(e);
            let i = s();
            return v(i.onPatternLockClick())
        }), a()()
    }
    if (t & 2) {
        let e = s();
        l("label", e.formatMessage("device_password")), n(), l("disableAutoFill", !0)("formControl", e.deviceForm.controls.device_password)("isEditMode", !0)("placeholder", e.formatMessage("device_password"))("showPatternLockButton", !0)
    }
}

function Tc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-control-container", 15)(1, "dx-tag-box", 32), f("onCustomItemCreating", function(i) {
            C(e);
            let p = s();
            return v(p.createTag(i))
        }), a()()
    }
    if (t & 2) {
        let e = s();
        l("label", "Tags"), n(), l("acceptCustomValue", !0)("items", e.tags)("placeholder", e.formatMessage("tag_placeholder"))
    }
}

function Mc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 16), u(1, "dx-text-box", 33), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("initial_quotation_label"))
    }
}

function Pc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 17), u(1, "dx-text-box", 34), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("dealer_Job_id")), n(), l("placeholder", e.formatMessage("dealer_job_placeholder"))
    }
}

function Ic(t, c) {
    if (t & 1 && (r(0, "app-control-container", 18), u(1, "dx-text-area", 35), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("device_hardware_configuration")), n(), l("autoResizeEnabled", !0)("placeholder", e.formatMessage("device_hardware_configuration_placeholder"))
    }
}

function Ec(t, c) {
    if (t & 1 && (r(0, "app-control-container", 36), u(1, "app-textarea", 37), a(), r(2, "div", 38), u(3, "app-attachments", 39), a()), t & 2) {
        let e = s();
        l("label", e.formatMessage("job_service_assessment")), n(), l("formControl", e.deviceForm.controls.comment)("isEditMode", !0)("placeholder", e.formatMessage("job_service_assessment_placeholder")), n(2), l("attachableType", e.attachableType)("entity", e.stubEntity)("isEditMode", !0)("isMultipleUploads", !0)
    }
}

function wc(t, c) {
    if (t & 1 && (r(0, "div", 19), u(1, "app-attachments", 39), a()), t & 2) {
        let e = s();
        n(), l("attachableType", e.attachableType)("entity", e.stubEntity)("isEditMode", !0)("isMultipleUploads", !0)
    }
}

function Oc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-device-brand", 40), f("deviceBrandCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleDeviceBrandPopup = !1)
        })("deviceBrandSaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddDeviceBrand(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("deviceBrand", e.deviceBrand)("isCreate", !0)("isVisiblePopup", e.isVisibleDeviceBrandPopup)
    }
}

function jc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-device-model-popup", 41), f("deviceModelCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleDeviceModelPopup = !1)
        })("deviceModelSaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddDeviceModel(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("deviceModel", e.deviceModel)("isAddingFromJob", !0)("isCreate", !0)("isVisiblePopup", e.isVisibleDeviceModelPopup)
    }
}

function Vc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-accessory", 42), f("accessoryCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleAccessoryPopup = !1)
        })("accessorySaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddAccessory(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("deviceAccessory", e.accessory)("isCreate", !0)("isVisiblePopup", e.isVisibleAccessoryPopup)
    }
}

function Dc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "app-screen-pattern-lock", 45), f("onPatternLockSaveClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.onPatternLockSaveClick(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("isEditMode", !0)("lockPattern", e.lockPattern())
    }
}

function kc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-popup", 43), f("onHiding", function() {
            C(e);
            let i = s();
            return v(i.isPatternLockPopupOpen.set(!1))
        }), E(1, Dc, 2, 2, "div", 44), a()
    }
    if (t & 2) {
        let e = s();
        l("maxHeight", e.isMobileDevice ? 470 : 460)("width", "95vw")("maxWidth", 450)("title", e.formatMessage("pattern_lock"))("visible", e.isPatternLockPopupOpen()), n(), l("dxTemplateOf", "content")
    }
}

function Nc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-qrcode-scanner", 46), f("scannerToSave", function(i) {
            C(e);
            let p = s();
            return v(p.addBarcodeNumberForSerialNumber(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("type", "get_barcode_number")("isVisiblePopup", e.isVisibleBarcodeScannerPopUp())
    }
}
var So = (() => {
    class t {
        constructor() {
            this.jobFormFieldConfig = {}, this.allDeviceTypes = [], this.allDeviceBrands = [], this.allDeviceModels = [], this.allAccessories = [], this.allRepairServices = [], this.storageLocations = [], this.tags = [], this.isModelWiseServicePricing = !1, this.tagCreated = new J, this.deviceBrandCreated = new J, this.deviceModelCreated = new J, this.formatMessage = g, this.PERMISSION_LIST = M, this.attachableType = I.JOB.name, this.stubEntity = new Ee({}), this.deviceBrandList = [], this.deviceModelList = [], this.deviceTypeAccessoriesList = [], this.deviceTypeRepairServicesList = [], this.isVisibleDeviceBrandPopup = !1, this.isVisibleDeviceModelPopup = !1, this.isVisibleAccessoryPopup = !1, this.isVisibleBarcodeScannerPopUp = Y(!1), this.isPatternLockPopupOpen = Y(!1), this.lockPattern = Y(null), this.isMobileDevice = b(A).isMobileDevice(), this.addDeviceBrandOption = {
                icon: "add",
                type: "default",
                hint: "Add New Device Brand",
                onClick: () => {
                    this.deviceBrand = new bn({
                        device_type_id: this.deviceForm.getRawValue().device_type_id
                    }), this.isVisibleDeviceBrandPopup = !0
                }
            }, this.addDeviceModelOption = {
                icon: "add",
                type: "default",
                hint: "Add New Device Model",
                onClick: () => {
                    this.deviceModel = new Ui({
                        device_brand_id: this.deviceForm.getRawValue().device_brand_id,
                        device_type_id: this.deviceForm.getRawValue().device_type_id
                    }), this.isVisibleDeviceModelPopup = !0
                }
            }, this.addAccessoryOption = {
                icon: "add",
                type: "default",
                hint: "Add New Accessory",
                onClick: () => {
                    this.accessory = new Co({
                        device_type_id: this.deviceForm.getRawValue().device_type_id
                    }), this.isVisibleAccessoryPopup = !0
                }
            }, this.addSerialBarcodeScan = {
                icon: be.BARCODE_READ.light,
                type: "default",
                hint: g("scan_serial/_IMEI_number"),
                onClick: () => this.scanJob()
            }
        }
        ngOnInit() {
            this.applyDeviceTypeFilter(this.deviceForm.controls.device_type_id.value), this.applyDeviceBrandFilter(), this.applyDeviceModelFilter(this.deviceForm.controls.device_model_id ? .value), this.deviceForm.controls.device_type_id.valueChanges.subscribe(e => {
                this.deviceForm.controls.device_type_id.value !== this.deviceForm.value.device_type_id && (this.deviceForm.patchValue({
                    device_brand_id: null,
                    device_model_id: null,
                    accessories: [],
                    repairables: []
                }, {
                    emitEvent: !1
                }), this.applyDeviceTypeFilter(e))
            }), this.deviceForm.controls.device_brand_id.valueChanges.subscribe(() => {
                this.deviceForm.controls.device_brand_id.value !== this.deviceForm.value.device_brand_id && (this.deviceForm.patchValue({
                    device_model_id: null
                }, {
                    emitEvent: !1
                }), this.applyDeviceBrandFilter())
            }), this.isModelWiseServicePricing && this.deviceForm.controls.device_model_id.valueChanges.subscribe(e => {
                this.deviceForm.controls.device_model_id.value !== this.deviceForm.value.device_model_id && this.applyDeviceModelFilter(e)
            })
        }
        ngOnChanges(e) {
            (e.allDeviceBrands || e.allAccessories || e.allRepairServices) && this.applyDeviceTypeFilter(this.deviceForm ? .controls.device_type_id ? .value), e.allDeviceModels && this.applyDeviceBrandFilter()
        }
        isFieldVisible(e) {
            return this.jobFormFieldConfig[e] !== !1
        }
        createTag(e) {
            e.customItem = e.text, this.tagCreated.emit(e.text)
        }
        onAddDeviceBrand(e) {
            this.isVisibleDeviceBrandPopup = !1, this.deviceBrandCreated.emit(e), this.deviceForm.patchValue({
                device_brand_id: e.id
            })
        }
        onAddDeviceModel(e) {
            this.isVisibleDeviceModelPopup = !1, this.deviceModelCreated.emit(e), this.deviceForm.patchValue({
                device_model_id: e.id
            })
        }
        onAddAccessory(e) {
            this.isVisibleAccessoryPopup = !1, this.deviceTypeAccessoriesList = [...this.deviceTypeAccessoriesList, e];
            let o = this.deviceForm.get("accessories").value || [];
            this.deviceForm.patchValue({
                accessories: [...o, e.id]
            })
        }
        syncAttachments(e) {
            this.attachmentInstance ? .syncNotes(e)
        }
        scanJob() {
            this.isVisibleBarcodeScannerPopUp() ? (this.isVisibleBarcodeScannerPopUp.set(!1), setTimeout(() => this.isVisibleBarcodeScannerPopUp.set(!0), 0)) : this.isVisibleBarcodeScannerPopUp.set(!0)
        }
        addBarcodeNumberForSerialNumber(e) {
            this.deviceForm.controls.serial_number.setValue(e)
        }
        onPatternLockClick() {
            this.lockPattern.set(this.deviceForm.getRawValue().device_password ? ? ""), this.isPatternLockPopupOpen.set(!0)
        }
        onPatternLockSaveClick(e) {
            this.deviceForm.patchValue({
                device_password: e
            }), this.isPatternLockPopupOpen.set(!1)
        }
        applyDeviceTypeFilter(e) {
            if (!e) {
                this.deviceBrandList = [], this.deviceTypeAccessoriesList = [], this.deviceTypeRepairServicesList = [];
                return
            }
            this.deviceBrandList = this.allDeviceBrands.filter(o => o.device_type_id === e), this.deviceTypeAccessoriesList = this.allAccessories.filter(o => o.device_type_id === e), this.isModelWiseServicePricing || (this.deviceTypeRepairServicesList = this.allRepairServices.filter(o => o.device_type_id === e))
        }
        applyDeviceBrandFilter() {
            let e = this.deviceForm ? .controls.device_type_id ? .value,
                o = this.deviceForm ? .controls.device_brand_id ? .value;
            if (!e || !o) {
                this.deviceModelList = [];
                return
            }
            this.deviceModelList = this.allDeviceModels.filter(i => i.device_brand_id === o && i.device_type_id === e)
        }
        applyDeviceModelFilter(e) {
            this.isModelWiseServicePricing && (this.deviceTypeRepairServicesList = this.allRepairServices.filter(o => e != null && o.device_model_id === e))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-device-card"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(gt, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.attachmentInstance = p.first)
                    }
                },
                inputs: {
                    deviceForm: "deviceForm",
                    jobFormFieldConfig: "jobFormFieldConfig",
                    allDeviceTypes: "allDeviceTypes",
                    allDeviceBrands: "allDeviceBrands",
                    allDeviceModels: "allDeviceModels",
                    allAccessories: "allAccessories",
                    allRepairServices: "allRepairServices",
                    storageLocations: "storageLocations",
                    tags: "tags",
                    isModelWiseServicePricing: "isModelWiseServicePricing"
                },
                outputs: {
                    tagCreated: "tagCreated",
                    deviceBrandCreated: "deviceBrandCreated",
                    deviceModelCreated: "deviceModelCreated"
                },
                standalone: !1,
                features: [Yt],
                decls: 28,
                vars: 40,
                consts: [
                    [3, "formGroup"],
                    [1, "row"],
                    ["name", "device_type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_type_id", 3, "dataSource", "placeholder", "imageCategory"],
                    ["name", "device_brand_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_brand_id", 3, "dataSource", "imageCategory", "isReadOnly", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "placeholder"],
                    ["name", "device_model_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "serial_number", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "accessories", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "storage_location_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "device_color_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "device_password", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    [1, "row", "mt-2"],
                    ["name", "repairables", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "repairables", "valueExpr", "id", 3, "acceptCustomValue", "items", "placeholder", "readOnly", "showSelectionControls"],
                    ["name", "tags", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "label"],
                    ["name", "initial_quotation", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "vendor_job_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "hardware_configuration", 1, "col-sm-12", "col-md-12", "col-lg-6", 3, "label"],
                    [1, "col-12"],
                    [3, "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "deviceModel", "isAddingFromJob", "isCreate", "isVisiblePopup"],
                    [3, "deviceAccessory", "isCreate", "isVisiblePopup"],
                    [3, "maxHeight", "width", "maxWidth", "title", "visible"],
                    [3, "type", "isVisiblePopup"],
                    ["formControlName", "device_model_id", 3, "dataSource", "imageCategory", "isReadOnly", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "placeholder"],
                    ["formControlName", "serial_number", 3, "placeholder"],
                    ["location", "after", "name", "serialNumberBarcodeScan", 3, "options"],
                    ["formControlName", "accessories", 3, "products", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "isReadOnly", "placeholder", "imageCategory"],
                    ["displayExpr", "name", "formControlName", "storage_location_id", "valueExpr", "id", 3, "items", "placeholder"],
                    [3, "formControl", "isEditMode"],
                    [3, "onPatternLockClick", "disableAutoFill", "formControl", "isEditMode", "placeholder", "showPatternLockButton"],
                    ["formControlName", "tags", 3, "onCustomItemCreating", "acceptCustomValue", "items", "placeholder"],
                    ["formControlName", "initial_quotation", "placeholder", "2000-3000 etc"],
                    ["formControlName", "vendor_job_id", 3, "placeholder"],
                    ["formControlName", "hardware_configuration", "maxHeight", "100", "minHeight", "60", 3, "autoResizeEnabled", "placeholder"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-6", 3, "label"],
                    [3, "formControl", "isEditMode", "placeholder"],
                    [1, "col-sm-12", "col-md-12", "col-lg-6"],
                    ["accept", "image/*,.dsn", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    [3, "deviceBrandCancelClick", "deviceBrandSaveClick", "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "deviceModelCancelClick", "deviceModelSaveClick", "deviceModel", "isAddingFromJob", "isCreate", "isVisiblePopup"],
                    [3, "accessoryCancelClick", "accessorySaveClick", "deviceAccessory", "isCreate", "isVisiblePopup"],
                    [3, "onHiding", "maxHeight", "width", "maxWidth", "title", "visible"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "onPatternLockSaveClick", "isEditMode", "lockPattern"],
                    [3, "scannerToSave", "type", "isVisiblePopup"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1)(2, "app-control-container", 2), u(3, "app-select-box-with-images", 3), a(), r(4, "app-control-container", 4), u(5, "app-select-box-with-images", 5), a(), m(6, hc, 2, 11, "app-control-container", 6), m(7, bc, 3, 4, "app-control-container", 7), m(8, gc, 2, 10, "app-control-container", 8), m(9, xc, 2, 3, "app-control-container", 9), m(10, Sc, 2, 3, "app-control-container", 10), m(11, yc, 2, 6, "app-control-container", 11), a(), r(12, "div", 12)(13, "app-control-container", 13), u(14, "dx-tag-box", 14), a(), m(15, Tc, 2, 4, "app-control-container", 15), a(), r(16, "div", 12), m(17, Mc, 2, 1, "app-control-container", 16), m(18, Pc, 2, 2, "app-control-container", 17), m(19, Ic, 2, 3, "app-control-container", 18), a(), r(20, "div", 12), m(21, Ec, 4, 8)(22, wc, 2, 4, "div", 19), a()(), m(23, Oc, 1, 3, "app-device-brand", 20), m(24, jc, 1, 4, "app-device-model-popup", 21), m(25, Vc, 1, 3, "app-accessory", 22), m(26, kc, 2, 6, "dx-popup", 23), m(27, Nc, 1, 2, "app-qrcode-scanner", 24)), o & 2 && (l("formGroup", i.deviceForm), n(2), l("errorMsg", i.formatMessage("device_type_required_warning"))("label", i.formatMessage("device_type_name")), n(), l("dataSource", i.allDeviceTypes)("placeholder", "select_device_type")("imageCategory", "device-type"), n(), l("errorMsg", i.formatMessage("device_brand_required_warning"))("label", i.formatMessage("device_brand_name")), n(), l("dataSource", i.deviceBrandList)("imageCategory", "device-brand")("isReadOnly", !i.deviceForm.controls.device_type_id.value)("isDxiButtonActive", !0)("hasUserPermissions", i.PERMISSION_LIST.DEVICE_BRAND_LIST)("buttonOptions", i.addDeviceBrandOption)("buttonId", "bulk-device-brand-add")("buttonName", "deviceBrand")("placeholder", "device_brand_placeholder"), n(), _(i.isFieldVisible("job_form_device_model_id") ? 6 : -1), n(), _(i.isFieldVisible("job_form_serial_number") ? 7 : -1), n(), _(i.isFieldVisible("job_form_accessories") ? 8 : -1), n(), _(i.isFieldVisible("job_form_storage_location_id") ? 9 : -1), n(), _(i.isFieldVisible("job_form_device_color_id") ? 10 : -1), n(), _(i.isFieldVisible("job_form_device_password") ? 11 : -1), n(2), l("errorMsg", i.formatMessage("job_error_services_required"))("label", i.formatMessage("job_services")), n(), l("acceptCustomValue", !1)("items", i.deviceTypeRepairServicesList)("placeholder", i.formatMessage("job_services_placeholder"))("readOnly", !i.deviceForm.controls.device_type_id.value)("showSelectionControls", !0), n(), _(i.isFieldVisible("job_form_tags") ? 15 : -1), n(2), _(i.isFieldVisible("job_form_initial_quotation") ? 17 : -1), n(), _(i.isFieldVisible("job_form_vendor_job_id") ? 18 : -1), n(), _(i.isFieldVisible("job_form_hardware_configuration") ? 19 : -1), n(2), _(i.isFieldVisible("job_form_comment") ? 21 : 22), n(2), _(i.isVisibleDeviceBrandPopup ? 23 : -1), n(), _(i.isVisibleDeviceModelPopup ? 24 : -1), n(), _(i.isVisibleAccessoryPopup ? 25 : -1), n(), _(i.isPatternLockPopupOpen() ? 26 : -1), n(), _(i.isVisibleBarcodeScannerPopUp() ? 27 : -1))
                },
                dependencies: [ee, gt, io, no, Fi, vo, fo, $i, en, _e, eo, ho, W, Qn, H, xe, Bi, jt, dt, q, re, st, le, se],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Lc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-cancel-footer", 25), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.cancel())
        }), a()
    }
    if (t & 2) {
        let e = s(2);
        l("isOnPopup", !1)("isSaving", e.isSaving)("isDisabled", e.isSaving)("isVisibleHr", !1)("saveText", "common_create")("savingText", "common_creating")
    }
}

function Bc(t, c) {
    if (t & 1 && u(0, "app-server-error", 9), t & 2) {
        let e = s(2);
        l("errorResponse", e.errorResponse)
    }
}

function Rc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 15), u(1, "app-customer-dropdown", 26), a()), t & 2) {
        let e = s(2);
        l("label", e.formatMessage("user_customer_referred_by")), n(), l("formControl", e.sharedForm.controls.referred_by_id)("isEditMode", !0)("isVisibleAddAction", !1)("showCrateButton", !0)
    }
}

function Uc(t, c) {
    if (t & 1 && (r(0, "app-control-container", 22), u(1, "app-employee-dropdown", 27), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("job_assignee")), n(), l("formControl", e.sharedForm.controls.assigned_user_id)("isActiveOnly", !0)("isEditMode", !0)
    }
}

function Fc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 3), f("ngSubmit", function() {
            C(e);
            let i = s();
            return v(i.save())
        }), r(1, "div", 4)(2, "div", 5)(3, "h3", 6), d(4), a()(), r(5, "div", 5)(6, "div", 7), E(7, Lc, 1, 6, "app-save-cancel-footer", 8), a()()(), m(8, Bc, 1, 1, "app-server-error", 9), u(9, "app-section-title", 10), r(10, "div", 4)(11, "app-control-container", 11), u(12, "app-customer-dropdown", 12), a(), r(13, "app-control-container", 13), u(14, "dx-select-box", 14), a(), m(15, Rc, 2, 5, "app-control-container", 15), r(16, "app-control-container", 16), u(17, "dx-select-box", 17), a(), r(18, "app-control-container", 18), u(19, "dx-select-box", 19), a(), r(20, "app-control-container", 20), u(21, "app-priority-dropdown", 21), a(), m(22, Uc, 2, 5, "app-control-container", 22), r(23, "app-control-container", 23), u(24, "dx-date-box", 24), a()()()
    }
    if (t & 2) {
        let e = s();
        l("formGroup", e.sharedForm), n(4), h(e.formatMessage("bulk_job_title") || "Bulk Job"), n(3), l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_WRITE), n(), _(e.errorResponse ? 8 : -1), n(), l("title", "basic_information"), n(2), l("errorMsg", e.formatMessage("common_error_messages_customer_name_required"))("label", e.formatMessage("user_customer_name")), n(), l("formControl", e.sharedForm.controls.user_id)("isEditMode", !0)("showCrateButton", !0), n(), l("label", e.formatMessage("user_customer_source")), n(), l("items", e.jobSources)("searchEnabled", !0), n(), _(e.isEmployee ? 15 : -1), n(), l("errorMsg", e.formatMessage("common_error_job_service_type_required"))("label", e.formatMessage("job_service_type")), n(), l("items", e.serviceTypes)("searchEnabled", !0), n(), l("errorMsg", e.formatMessage("common_error_job_type_required"))("label", e.formatMessage("job_type")), n(), l("items", e.jobTypes)("searchEnabled", !0), n(), l("errorMsg", e.formatMessage("job_error_priority_required"))("label", e.formatMessage("priority")), n(), l("formControl", e.sharedForm.controls.priority_id)("isEditMode", !0)("placeholder", e.formatMessage("priority_placeholder")), n(), _(e.isEmployee ? 22 : -1), n(), l("label", e.formatMessage("job_due_date")), n(), l("placeholder", e.formatMessage("job_date_placeholder"))
    }
}

function qc(t, c) {
    t & 1 && (r(0, "span", 36), d(1), a()), t & 2 && (n(), h(c))
}

function Gc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 38)(1, "app-dx-outline-button", 40), f("onClickEvent", function() {
            C(e);
            let i = s().$implicit,
                p = s(2);
            return v(p.removeDevice(i))
        }), a()()
    }
    t & 2 && (n(), l("isVisibleIcon", !0))
}

function Wc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 29)(1, "div", 33), f("click", function() {
            let i = C(e).$index,
                p = s(2);
            return v(p.toggleDevice(i))
        }), r(2, "div", 34), u(3, "i", 35), r(4, "strong"), d(5), a(), m(6, qc, 2, 1, "span", 36), a()(), r(7, "div", 37), m(8, Gc, 2, 1, "div", 38), r(9, "app-device-card", 39), f("tagCreated", function(i) {
            C(e);
            let p = s(2);
            return v(p.onTagCreated(i))
        })("deviceBrandCreated", function(i) {
            C(e);
            let p = s(2);
            return v(p.onDeviceBrandCreated(i))
        })("deviceModelCreated", function(i) {
            C(e);
            let p = s(2);
            return v(p.onDeviceModelCreated(i))
        }), a()()()
    }
    if (t & 2) {
        let e, o = c.$implicit,
            i = c.$index,
            p = s(2);
        n(3), Ae("fa-chevron-down", p.expandedDeviceIndex === i)("fa-chevron-right", p.expandedDeviceIndex !== i), n(2), ze("", p.formatMessage("device"), " #", i + 1), n(), _((e = p.getDeviceSummary(o)) ? 6 : -1, e), n(), l("hidden", p.expandedDeviceIndex !== i), n(), _(p.deviceFormGroups.length > 1 ? 8 : -1), n(), l("deviceForm", o)("jobFormFieldConfig", p.jobFormFieldConfig)("allDeviceTypes", p.allDeviceTypes)("allDeviceBrands", p.allDeviceBrands)("allDeviceModels", p.allDeviceModels)("allAccessories", p.allAccessories)("allRepairServices", p.allRepairServices)("storageLocations", p.storageLocations)("tags", p.tags)("isModelWiseServicePricing", p.isModelWiseServicePricing)
    }
}

function Hc(t, c) {
    if (t & 1) {
        let e = x();
        u(0, "app-section-title", 10), r(1, "div", 28), X(2, Wc, 10, 19, "div", 29, He), a(), r(4, "div", 30)(5, "app-dx-outline-button", 31), f("onClickEvent", function() {
            C(e);
            let i = s();
            return v(i.addDevice())
        }), a(), r(6, "small", 32), d(7), a()()
    }
    if (t & 2) {
        let e = s();
        l("title", "device_information"), n(2), Z(e.deviceFormGroups), n(3), l("isVisibleIcon", !0)("disabled", e.devicesForm.length >= e.MAX_DEVICES_PER_BULK_JOB), n(2), ze(" ", e.devicesForm.length, " / ", e.MAX_DEVICES_PER_BULK_JOB, " ")
    }
}

function Qc(t, c) {
    if (t & 1 && (r(0, "form", 1), u(1, "app-section-title", 10), r(2, "app-control-container", 41), u(3, "app-textarea", 42), a()()), t & 2) {
        let e = s();
        l("formGroup", e.sharedForm), n(), l("title", "additional_information"), n(), l("label", e.formatMessage("common_terms_and_conditions")), n(), l("formControl", e.sharedForm.controls.term_and_condition)("isEditMode", !0)
    }
}

function zc(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-send-notification", 43), f("sendNotificationClose", function() {
            C(e);
            let i = s();
            return v(i.redirectToJobList())
        })("sendNotificationSave", function() {
            C(e);
            let i = s();
            return v(i.redirectToJobList())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entity", e.ENTITIES.BULK_JOB)("entityObj", e.firstCreatedJob)("jobIds", e.createdJobIds)("isVisiblePopup", e.isVisibleNotificationPopup)("isVisibleSendButton", !1)
    }
}
var Us = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.PERMISSION_LIST = M, this.MAX_DEVICES_PER_BULK_JOB = Bn, this.ENTITIES = I, this.isVisibleNotificationPopup = !1, this.createdJobIds = [], this.firstCreatedJob = null, this.jobService = b(U), this.dataService = b(qe), this.termAndConditionService = b(Ct), this.loaderService = b($), this.toastNotificationService = b(D), this.formService = b(me), this.router = b(G), this.activatedRoute = b(R), this.applicationRef = b($t), this.generalSettingDataService = b(te), this.userSessionService = b(L), this.isEmployee = this.userSessionService.isEmployee(), this.deviceFormGroups = [], this.isSaving = !1, this.errorResponse = null, this.allDeviceTypes = [], this.allDeviceBrands = [], this.allDeviceModels = [], this.allAccessories = [], this.allRepairServices = [], this.storageLocations = [], this.jobSources = [], this.serviceTypes = [], this.jobTypes = [], this.tags = [], this.jobFormFieldConfig = {}, this.isModelWiseServicePricing = !1, this.expandedDeviceIndex = 0
        }
        ngOnInit() {
            this.jobFormFieldConfig = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.JOB_FORM_FIELD_CONFIG) || {}, this.isModelWiseServicePricing = this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING);
            let e = this.activatedRoute.snapshot.queryParamMap.get("user_id"),
                o = this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.AUTO_ROUND_OFF) || !1;
            this.defaultJob = ni.getDefaultJobObj(this.generalSettingDataService.getGeneralSettingBySettingType(Ce.JOB_SETTING), e ? +e : null, null, null, null, !1, o), this.sharedForm = Ee.getBulkSharedForm(this.defaultJob), this.devicesForm = new ka([Ee.getBulkDeviceForm(this.defaultJob)]), this.refreshDeviceFormGroups(), this.initializeLookups()
        }
        addDevice() {
            if (this.devicesForm.length >= Bn) {
                this.toastNotificationService.warning(g("bulk_job_max_devices_warning", String(Bn)));
                return
            }
            this.devicesForm.push(Ee.getBulkDeviceForm(this.defaultJob)), this.refreshDeviceFormGroups(), this.expandedDeviceIndex = this.devicesForm.length - 1
        }
        removeDevice(e) {
            if (this.devicesForm.length <= 1) {
                this.toastNotificationService.warning("bulk_job_min_devices_warning");
                return
            }
            let o = this.deviceFormGroups.indexOf(e);
            o !== -1 && (this.devicesForm.removeAt(o), this.refreshDeviceFormGroups(), this.expandedDeviceIndex === o ? this.expandedDeviceIndex = Math.min(o, this.devicesForm.length - 1) : this.expandedDeviceIndex > o && (this.expandedDeviceIndex -= 1))
        }
        refreshDeviceFormGroups() {
            this.deviceFormGroups = [...this.devicesForm.controls]
        }
        toggleDevice(e) {
            this.expandedDeviceIndex = this.expandedDeviceIndex === e ? -1 : e
        }
        getDeviceSummary(e) {
            let o = e.controls.device_type_id ? .value,
                i = e.controls.device_brand_id ? .value,
                p = e.controls.device_model_id ? .value;
            return [o ? this.allDeviceTypes.find(je => je.id === o) ? .name : null, i ? this.allDeviceBrands.find(je => je.id === i) ? .name : null, p ? this.allDeviceModels.find(je => je.id === p) ? .name : null].filter(Boolean).join(" / ")
        }
        onTagCreated(e) {
            this.tags = [e, ...this.tags]
        }
        onDeviceBrandCreated(e) {
            this.allDeviceBrands = [...this.allDeviceBrands, e]
        }
        onDeviceModelCreated(e) {
            this.allDeviceModels = [...this.allDeviceModels, e]
        }
        save() {
            if (this.isSaving) return;
            if (this.errorResponse = null, !this.sharedForm.valid || !this.devicesForm.valid) {
                this.formService.validateFormFields(this.sharedForm), this.deviceFormGroups.forEach(o => this.formService.validateFormFields(o));
                return
            }
            this.isSaving = !0, this.loaderService.show();
            let e = {
                shared: this.sharedForm.getRawValue(),
                devices: this.deviceFormGroups.map(o => o.getRawValue())
            };
            this.jobService.createBulk(e).subscribe({
                next: o => {
                    this.applicationRef.tick(), this.syncBatchAttachments(o), this.toastNotificationService.success(o.length === 1 ? g("job_created_successfully") : g("bulk_jobs_created_success", String(o.length))), this.createdJobIds = o.map(i => i.id), this.firstCreatedJob = new Ee(o[0]), this.isVisibleNotificationPopup = !0
                },
                error: o => {
                    this.errorResponse = o, this.isSaving = !1, this.loaderService.hide()
                },
                complete: () => {
                    this.loaderService.hide(), this.isSaving = !1
                }
            })
        }
        cancel() {
            this.router.navigate(["/jobs/list"])
        }
        redirectToJobList() {
            this.isVisibleNotificationPopup = !1, this.router.navigate(["/jobs/list"])
        }
        initializeLookups() {
            this.loaderService.show(), Ne([this.dataService.getLookups(), this.termAndConditionService.getByTypeId({
                type_id: at.JOB_SHEET
            })]).subscribe({
                next: ([e, o]) => {
                    this.allDeviceTypes = e.device_types, this.allDeviceBrands = e.device_brands, this.allDeviceModels = e.device_models, this.allAccessories = e.accessories, this.allRepairServices = e.repair_services, this.storageLocations = e.storage_locations, this.jobSources = e.job_sources, this.serviceTypes = e.service_types, this.jobTypes = e.job_types, this.tags = e.tags.filter(i => i.type === I.JOB.name).map(i => i.tag_name), this.sharedForm.patchValue({
                        term_and_condition: o ? .text ? ? ""
                    })
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.error(e)
                }
            }).add(() => this.loaderService.hide())
        }
        syncBatchAttachments(e) {
            let o = this.deviceCards ? .toArray() ? ? [];
            e.forEach((i, p) => {
                o[p] ? .syncAttachments(new Ee(i))
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-bulk-job-form"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(So, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.deviceCards = p)
                    }
                },
                standalone: !1,
                decls: 5,
                vars: 4,
                consts: [
                    [1, "container-fluid", "p-0"],
                    [3, "formGroup"],
                    [3, "entity", "entityObj", "jobIds", "isVisiblePopup", "isVisibleSendButton"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "float-start"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    ["cancelBtnId", "bulk-job-cancel", "saveBtnId", "bulk-job-save", 3, "isOnPopup", "isSaving", "isDisabled", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    [3, "errorResponse"],
                    [1, "mt-3", 3, "title"],
                    ["name", "user_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    [3, "formControl", "isEditMode", "showCrateButton"],
                    ["name", "source_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["displayExpr", "name", "formControlName", "source_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled"],
                    ["name", "referred_by_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "service_type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "service_type_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled"],
                    ["name", "type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "type_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled"],
                    ["name", "priority_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    [3, "formControl", "isEditMode", "placeholder"],
                    ["name", "assigned_user_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "estimated_delivery", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["formControlName", "estimated_delivery", "type", "date", 3, "placeholder"],
                    ["cancelBtnId", "bulk-job-cancel", "saveBtnId", "bulk-job-save", 3, "cancelClick", "isOnPopup", "isSaving", "isDisabled", "isVisibleHr", "saveText", "savingText"],
                    [3, "formControl", "isEditMode", "isVisibleAddAction", "showCrateButton"],
                    ["placeholder", "job_assignee_placeholder", 3, "formControl", "isActiveOnly", "isEditMode"],
                    [1, "d-flex", "flex-column", "gap-2"],
                    [1, "card"],
                    [1, "d-flex", "justify-content-start", "mt-2", "mb-3"],
                    ["buttonType", "default", "icon", "fa-thin fa-plus", "text", "add_new_device", "title", "add_new_device", 3, "onClickEvent", "isVisibleIcon", "disabled"],
                    [1, "text-muted", "ms-2", "align-self-center"],
                    [1, "card-header", "d-flex", "justify-content-between", "align-items-center", 2, "cursor", "pointer", 3, "click"],
                    [1, "d-flex", "align-items-center", "gap-2", "flex-wrap"],
                    [1, "fa-thin"],
                    [1, "text-muted", "fs-9"],
                    [1, "card-body", 3, "hidden"],
                    [1, "d-flex", "justify-content-end", "mb-2"],
                    [3, "tagCreated", "deviceBrandCreated", "deviceModelCreated", "deviceForm", "jobFormFieldConfig", "allDeviceTypes", "allDeviceBrands", "allDeviceModels", "allAccessories", "allRepairServices", "storageLocations", "tags", "isModelWiseServicePricing"],
                    ["buttonType", "danger", "icon", "fa-thin fa-trash", "text", "common_remove", "title", "common_remove", 3, "onClickEvent", "isVisibleIcon"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label"],
                    ["height", "auto", 3, "formControl", "isEditMode"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entity", "entityObj", "jobIds", "isVisiblePopup", "isVisibleSendButton"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0), m(1, Fc, 25, 30, "form", 1), m(2, Hc, 8, 5), m(3, Qc, 4, 5, "form", 1), m(4, zc, 1, 5, "app-send-notification", 2), a()), o & 2 && (n(), _(i.sharedForm ? 1 : -1), n(), _(i.devicesForm ? 2 : -1), n(), _(i.sharedForm ? 3 : -1), n(), _(i.isVisibleNotificationPopup ? 4 : -1))
                },
                dependencies: [ai, ee, K, Re, Zn, Gi, tt, ge, _e, qi, Jt, xe, pe, q, re, st, le, se, Zt, So],
                encapsulation: 2
            })
        }
    }
    return t
})();
var yn = class extends co {
    constructor(c) {
        return super(c), Object.assign(this, c)
    }
    static getForm(c, e) {
        return new Je().group(Te({
            assigned_user_id: [c.assigned_user_id || null, [de.required]],
            job_id: [c.job_id || null, [de.required]],
            status_id: [c.status_id || null, [de.required]],
            comment: [c.comment || null]
        }, Wi(c, e)))
    }
};

function Yc(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 3), t & 2 && l("rows", 4)("columns", 2)
}

function $c(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 5), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.updateAssignee())
        }), r(1, "dx-scroll-view", 6), u(2, "app-job-current-info", 7), r(3, "div", 8)(4, "app-control-container", 9)(5, "button", 10), f("click", function() {
            C(e);
            let i = s(2);
            return v(i.assignToMe())
        }), u(6, "i", 11), d(7), a(), u(8, "app-employee-dropdown", 12), a(), r(9, "app-control-container", 13), u(10, "app-status-dropdown", 14), a(), r(11, "app-control-container", 15)(12, "app-quick-reply-dropdown", 16), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.quickReplyValue(i))
        }), a(), u(13, "app-textarea", 17), a()(), u(14, "app-user-notification-channel", 18), a(), u(15, "app-error", 19), r(16, "app-save-cancel-footer", 20), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.onClosing())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(2), l("job", e.job), n(2), l("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("job_assignee_name"))("tooltipText", "job_assigned_user_id"), n(3), S("", e.formatMessage("job_assign_to_me"), " "), n(), l("showClearButton", !1), n(), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status"))("ngClass", e.isMobileDevice ? "mt-2" : ""), n(4), l("quickReply", e.quickReply), n(), l("form", e.form)("label", e.isMobileDevice ? "Alerts" : "Notify Staff"), n(), l("displayError", e.statusErrorMessage !== "")("errorMsg", e.statusErrorMessage), n(), l("gaEvent", "assign_to_save_event")("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function Kc(t, c) {
    if (t & 1 && (r(0, "div", 2), m(1, Yc, 1, 2, "app-skeleton-loader", 3), m(2, $c, 17, 18, "form", 4), a()), t & 2) {
        let e = s();
        n(), _(e.form ? -1 : 1), n(), _(e.form ? 2 : -1)
    }
}
var Fs = (() => {
    class t {
        constructor(e) {
            this.jobService = e, this.formatMessage = g, this.isVisiblePopup = !1, this.assignToClose = new J, this.assignToSave = new J, this.formService = b(me), this.whatsappService = b(Ke), this.authService = b(Wn), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.notifDefaults = b(si), this.statusErrorMessage = "", this.isSaving = !1, this.currentUser = null, this.authService.currentUser.pipe(Mi()).subscribe({
                next: o => {
                    this.currentUser = o
                },
                error: o => {
                    console.log("error gettting current user")
                }
            })
        }
        ngOnInit() {
            this.form = yn.getForm(new yn({
                job_id: this.job.id,
                status_id: this.job.status_id,
                assigned_user_id: this.job ? .assigned_user_id
            }), this.notifDefaults.getEntityDefaults(Et.JOB_ASSIGNEE))
        }
        onClosing() {
            this.form.reset(), this.isVisiblePopup = !1, this.assignToClose.emit()
        }
        updateAssignee() {
            if (this.form.value.assigned_user_id === this.job.assigned_user_id) return this.statusErrorMessage = "Current assignee is same as new assignee", !1;
            this.form.valid ? (this.isSaving = !0, this.jobService.updateAssignee(this.job.id, this.form.value).subscribe({
                next: () => {
                    this.assignToSave.emit(this.form.value.assigned_user_id), this.form.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("job_assigned_user", this.job.id), this.toastNotificationService.success("notification_assignee_update_success"), this.isVisiblePopup = !1
                },
                error: () => {
                    this.toastNotificationService.error("notification_assignee_update_error")
                }
            }).add(() => {
                this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        quickReplyValue(e) {
            this.quickReply = e.comment ? ? e.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        assignToMe() {
            this.form.patchValue({
                assigned_user_id: this.currentUser.id
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-assign-to-popup"]
                ],
                inputs: {
                    job: "job",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    assignToClose: "assignToClose",
                    assignToSave: "assignToSave"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    ["id", "assign-to-popup", 3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "maxHeight", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "flex-column", "h-100"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [3, "job"],
                    [1, "row"],
                    ["name", "assigned_user_id", 1, "col-12", 3, "errorMsg", "label", "tooltipText"],
                    ["labelAction", "", "type", "button", "id", "assign-to-popup-assign-to-me", 1, "app-action-link", "flex-shrink-0", "text-nowrap", 3, "click"],
                    [1, "fa-thin", "fa-user"],
                    ["formControlName", "assigned_user_id", "id", "assign-to-popup-assignee", "placeholder", "job_assignee_placeholder", 3, "showClearButton"],
                    ["name", "status_id", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label", "ngClass"],
                    ["formControlName", "status_id"],
                    ["label", "Comment", "name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["labelAction", "", 3, "itemClick"],
                    ["formControlName", "comment", "id", "assign-to-popup-comment", 3, "quickReply"],
                    [3, "form", "label"],
                    [3, "displayError", "errorMsg"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onClosing()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, Kc, 3, 2, "div", 1), a()), o & 2 && (w("visible", i.isVisiblePopup), l("width", "95vw")("maxWidth", 600)("maxHeight", "90vh")("title", i.formatMessage("job_assignee_update")), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [Q, ut, ee, et, Fe, K, Re, bt, ue, _e, Qi, W, H, ye, pe, q, re, le, se],
                styles: [".btn-height[_ngcontent-%COMP%]{margin-top:6px}"]
            })
        }
    }
    return t
})();
var td = (t, c) => c.id;

function id(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "i", 9), f("click", function() {
            C(e);
            let i = s();
            return v(i.onDelete(i.comment))
        }), a()
    }
}

function nd(t, c) {
    if (t & 1 && u(0, "app-image-gallery-popup", 10), t & 2) {
        let e = c.$implicit;
        l("attachment", e)("isOnTableListing", !1)
    }
}

function od(t, c) {
    if (t & 1 && (r(0, "div", 7), X(1, nd, 1, 2, "app-image-gallery-popup", 10, td), a()), t & 2) {
        let e = s();
        n(), Z(e.comment.attachments)
    }
}

function ad(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-confirmation-popup", 11), f("confirmActionCallback", function() {
            C(e);
            let i = s();
            return v(i.delete())
        })("rejectActionCallback", function() {
            C(e);
            let i = s();
            return v(i.deleteComment = null)
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("confirmationMessage", e.formatMessage("comment_delete_confirm"))
    }
}
var Gs = (() => {
    class t {
        constructor(e) {
            this.jobCommentService = e, this.formatMessage = g, this.commentDelete = new J, this.userSessionService = b(L), this.toastNotificationService = b(D), this.currentUser = this.userSessionService.currentUser(), this.deleteComment = null
        }
        delete() {
            this.jobCommentService.delete(this.deleteComment.id).subscribe({
                next: () => {
                    this.commentDelete.emit(this.deleteComment.id), this.toastNotificationService.success("notification_comment_delete_success"), this.onCloseDeleteModal(), this.deleteComment = null
                },
                error: () => {
                    this.toastNotificationService.error("notification_comment_delete_error")
                }
            })
        }
        onDelete(e) {
            this.deleteComment = e
        }
        onCloseDeleteModal() {
            this.deleteComment = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(Hi))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-comment-box"]
                ],
                inputs: {
                    comment: "comment"
                },
                outputs: {
                    commentDelete: "commentDelete"
                },
                standalone: !1,
                decls: 13,
                vars: 14,
                consts: [
                    [1, "message", "dx-theme-background-color", 3, "ngClass"],
                    [1, "name", "d-flex", "justify-content-between"],
                    [1, "float-start", 3, "iconOnly", "isUserTextOnly", "user"],
                    [1, "fa-thin", "fa-trash", "float-end", "ms-4"],
                    [1, "margin-msg"],
                    [1, "text", 3, "innerHTML"],
                    [1, "date"],
                    [1, "d-flex", "align-items-center", "flex-wrap", "gap-1"],
                    [3, "confirmationMessage"],
                    [1, "fa-thin", "fa-trash", "float-end", "ms-4", 3, "click"],
                    [3, "attachment", "isOnTableListing"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmationMessage"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1), u(2, "app-user-badge", 2), m(3, id, 1, 0, "i", 3), a(), u(4, "hr", 4)(5, "div", 5), V(6, "safe"), r(7, "div", 6), d(8), V(9, "amTimeAgo"), a(), m(10, od, 3, 0, "div", 7), a(), u(11, "br"), m(12, ad, 1, 1, "app-confirmation-popup", 8)), o & 2 && (l("ngClass", i.currentUser.id === i.comment.user_id ? "float-end" : "float-start"), n(2), l("iconOnly", !1)("isUserTextOnly", !0)("user", i.comment.user), n(), _(i.currentUser.id === i.comment.user_id ? 3 : -1), n(2), l("innerHTML", B(6, 9, i.comment.comment, "html"), We), n(3), S(" ", ie(9, 12, i.comment.created_at), " "), n(2), _(i.comment.attachments.length ? 10 : -1), n(2), _(i.deleteComment ? 12 : -1))
                },
                dependencies: [Q, ii, _t, Ri, Dt, Hr],
                styles: [".message[_ngcontent-%COMP%]{display:inline-block;padding:10px 20px;box-shadow:0 2px 6px #0000001a;border-radius:5px;background-color:inherit}.name[_ngcontent-%COMP%]{font-weight:700}.date[_ngcontent-%COMP%]{float:right;opacity:.5}.margin-msg[_ngcontent-%COMP%]{margin:.3rem}"]
            })
        }
    }
    return t
})();
var ld = ["commentListScroll"];

function cd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 4)(1, "app-comment-box", 5), f("commentDelete", function(i) {
            C(e);
            let p = s(3);
            return v(p.onCommentDelete(i))
        }), a()()
    }
    if (t & 2) {
        let e = c.$implicit;
        n(), l("comment", e)
    }
}

function dd(t, c) {
    if (t & 1 && (r(0, "div", 3), X(1, cd, 2, 1, "div", 4, He), a()), t & 2) {
        let e = s(2);
        n(), Z(e.jobCommentList)
    }
}

function pd(t, c) {
    if (t & 1 && (r(0, "h3", 15), d(1), a()), t & 2) {
        let e = s(4);
        n(), h(e.formatMessage("chat_subtitle"))
    }
}

function md(t, c) {
    if (t & 1 && (r(0, "p", 14), d(1), a(), m(2, pd, 2, 1, "h3", 15)), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("chat_title")), n(), _(e.isMobileDevice ? -1 : 2)
    }
}

function _d(t, c) {
    if (t & 1 && (r(0, "h6", 8), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("chat_title"))
    }
}

function ud(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 0)(1, "div", 6)(2, "div", 7), m(3, md, 3, 2), m(4, _d, 2, 1, "h6", 8), a(), r(5, "div", 9)(6, "small"), d(7), a(), r(8, "app-dx-outline-button", 10), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.isVisibleAddCommentPopup = !0)
        }), a()()(), r(9, "div", 11)(10, "div", 12), u(11, "img", 13), a()()()
    }
    if (t & 2) {
        let e = s(2);
        n(2), l("ngClass", e.isMobileDevice ? "mx-5" : "ms-5"), n(), _(e.isMobileDevice ? -1 : 3), n(), _(e.isMobileDevice ? 4 : -1), n(3), h(e.formatMessage("chat_intro_text")), n(4), l("ngClass", e.isMobileDevice ? "img-fluid" : "")
    }
}

function Cd(t, c) {
    if (t & 1 && m(0, dd, 3, 0, "div", 3)(1, ud, 12, 5, "div", 0), t & 2) {
        let e = s();
        _(e.jobCommentList.length > 0 ? 0 : 1)
    }
}

function vd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-add-comment-popup", 16), f("addCommentClose", function() {
            C(e);
            let i = s();
            return v(i.isVisibleAddCommentPopup = !1)
        })("addCommentSave", function(i) {
            C(e);
            let p = s();
            return v(p.onSaveAddCommentPopup(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleAddCommentPopup)("jobId", e.jobId)
    }
}
var Ws = (() => {
    class t {
        constructor(e, o, i) {
            this.jobCommentService = e, this.jobService = o, this.applicationRef = i, this.formatMessage = g, this.activatedRouter = b(R), this.toastNotificationService = b(D), this.isMobileDevice = b(A).isMobileDevice(), this.isVisibleAddCommentPopup = !1, this.jobId = null, this.jobCommentList = [], this.isLoadingComments = !1
        }
        ngOnInit() {
            this.jobId = +this.activatedRouter.snapshot.parent.paramMap.get("job_id"), this.getJobComments()
        }
        onSaveAddCommentPopup(e) {
            this.getJobComments(), this.isVisibleAddCommentPopup = !1
        }
        getJobComments() {
            let e = {};
            this.jobId && (e.job_id = this.jobId), this.isLoadingComments = !0, this.jobCommentService.getListByQuery(e).subscribe({
                next: o => {
                    this.jobCommentList = o
                },
                error: o => {
                    this.toastNotificationService.success("notification_comment_fetch_error"), console.error("error fetching comments ")
                }
            }).add(() => this.isLoadingComments = !1)
        }
        onCommentDelete(e) {
            this.jobCommentList = this.jobCommentList.filter(o => o.id !== e)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(Hi), T(U), T($t))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-comment-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(ld, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.commentListScroll = p.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 2,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "isVisiblePopup", "jobId"],
                    ["id", "chat-window"],
                    [1, "list-group", "mt-3"],
                    [3, "commentDelete", "comment"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "d-flex", "flex-column", "justify-content-end"],
                    [1, "d-flex", "flex-column", 3, "ngClass"],
                    [1, "mb-4", "mt-1", "blockquote-footer", "quote-text"],
                    [1, "d-flex", "align-items-center", "justify-content-center", "flex-column", "gap-2"],
                    ["buttonType", "default", "text", "common_add_comment", "title", "common_add_comment", 3, "onClickEvent"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "d-flex", "justify-content-center"],
                    ["alt", "Lets Chat", "height", "380", "loading", "lazy", "src", "https://bytephase-public.s3.ap-south-1.amazonaws.com/assets/images/lets-chat.png", 3, "ngClass"],
                    [1, "no-comment-headline"],
                    [1, "mb-5", "mt-1", "blockquote-footer", "quote-text"],
                    [3, "addCommentClose", "addCommentSave", "isVisiblePopup", "jobId"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1), m(2, Cd, 2, 1), a()(), m(3, vd, 1, 2, "app-add-comment-popup", 2)), o & 2 && (n(2), _(i.isLoadingComments ? -1 : 2), n(), _(i.isVisibleAddCommentPopup ? 3 : -1))
                },
                dependencies: [Q, ao, ge, Gs],
                styles: ["#chat-window[_ngcontent-%COMP%]{padding:10px;background-color:#bfbfbf26}.button-margin[_ngcontent-%COMP%]{margin-top:-15px}  .dx-popup-content{padding:15px}  .dx-checkbox-container{margin-top:8px}  .dx-popup-bottom.dx-toolbar{padding:13px}.quote-text[_ngcontent-%COMP%]{font-size:20px}.add-comment-btn[_ngcontent-%COMP%]{font-size:20px;margin-top:6rem}.no-comment-headline[_ngcontent-%COMP%]{font-size:3rem}"]
            })
        }
    }
    return t
})();
var fd = t => ({
        job_id: t
    }),
    hd = (t, c, e) => [t, c, e],
    bd = (t, c, e) => ({
        icon: "dx-icon-box",
        title: t,
        description: c,
        quickTips: e
    });

function gd(t, c) {
    t & 1 && (r(0, "div", 7), u(1, "dx-load-indicator", 9), a()), t & 2 && (n(), l("visible", !0))
}

function xd(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "strong"), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(4);
        n(2), S("", e.formatMessage("shipping_awb"), ":"), n(2), h(e.trackingShipment.awb_code)
    }
}

function Sd(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "strong"), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(4);
        n(2), S("", e.formatMessage("shipping_courier_name"), ":"), n(2), h(e.trackingShipment.courier_name)
    }
}

function yd(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "strong"), d(2), a(), r(3, "span", 13), d(4), a()()), t & 2) {
        let e = s(4);
        n(2), S("", e.formatMessage("shipping_cancel_reason"), ":"), n(2), h(e.trackingShipment.cancellation_reason)
    }
}

function Td(t, c) {
    if (t & 1 && (r(0, "div", 12)(1, "a", 14), d(2), a()()), t & 2) {
        let e = s(4);
        n(), l("href", e.trackingShipment.tracking_url, It), n(), S(" ", e.formatMessage("shipping_track"), " ")
    }
}

function Md(t, c) {
    if (t & 1 && (r(0, "div", 8)(1, "div", 10)(2, "strong"), d(3), a(), r(4, "span", 11), d(5), V(6, "titlecase"), a()(), m(7, xd, 5, 2, "div", 10), m(8, Sd, 5, 2, "div", 10), m(9, yd, 5, 2, "div", 10), m(10, Td, 3, 2, "div", 12), a()), t & 2) {
        let e = s(3);
        n(3), S("", e.formatMessage("shipping_status"), ":"), n(), l("ngClass", e.getStatusClass(e.trackingShipment.status)), n(), S(" ", ie(6, 7, e.trackingShipment.status), " "), n(2), _(e.trackingShipment.awb_code ? 7 : -1), n(), _(e.trackingShipment.courier_name ? 8 : -1), n(), _(e.trackingShipment.cancellation_reason ? 9 : -1), n(), _(e.trackingShipment.tracking_url ? 10 : -1)
    }
}

function Pd(t, c) {
    if (t & 1 && (r(0, "div")(1, "dx-scroll-view", 6), m(2, gd, 2, 1, "div", 7)(3, Md, 11, 9, "div", 8), a()()), t & 2) {
        let e = s(2);
        n(2), _(e.isLoadingTracking ? 2 : e.trackingShipment ? 3 : -1)
    }
}

function Id(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-popup", 4), j("visibleChange", function(i) {
            C(e);
            let p = s();
            return O(p.isTrackingPopupVisible, i) || (p.isTrackingPopupVisible = i), v(i)
        }), E(1, Pd, 4, 1, "div", 5), a()
    }
    if (t & 2) {
        let e = s();
        w("visible", e.isTrackingPopupVisible), l("maxHeight", "80vh")("width", "95vw")("maxWidth", 500)("title", e.formatMessage("shipping_track")), n(), l("dxTemplateOf", "content")
    }
}

function Ed(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "div", 0)(2, "div", 16)(3, "app-control-container", 17)(4, "dx-text-area", 18), j("valueChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.cancelReason, i) || (p.cancelReason = i), v(i)
        }), a()()()(), r(5, "app-save-cancel-footer", 19), f("saveClick", function() {
            C(e);
            let i = s(2);
            return v(i.confirmCancelShipment())
        })("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.closeCancelPopup())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(3), l("label", e.formatMessage("shipping_cancel_reason")), n(), w("value", e.cancelReason), l("autoResizeEnabled", !0)("placeholder", e.formatMessage("shipping_cancel_reason_prompt")), n(), l("useSubmitBehavior", !1)("isOnPopup", !0)("isSaving", e.isCancelling)("saveText", "shipping_cancel")("gaEvent", "shipment_cancel_event")
    }
}

function wd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-popup", 15), f("onHidden", function() {
            C(e);
            let i = s();
            return v(i.closeCancelPopup())
        }), j("visibleChange", function(i) {
            C(e);
            let p = s();
            return O(p.isCancelPopupVisible, i) || (p.isCancelPopupVisible = i), v(i)
        }), E(1, Ed, 6, 9, "div", 5), a()
    }
    if (t & 2) {
        let e = s();
        w("visible", e.isCancelPopupVisible), l("maxHeight", 350)("width", "95vw")("maxWidth", 500)("title", e.formatMessage("shipping_cancel")), n(), l("dxTemplateOf", "content")
    }
}
var Od = {
        delivered: "bg-success",
        in_transit: "bg-primary",
        out_for_delivery: "bg-primary",
        pickup_scheduled: "bg-info",
        picked_up: "bg-info",
        cancelled: "bg-danger",
        failed: "bg-danger",
        rto_initiated: "bg-warning",
        rto_delivered: "bg-warning",
        pending: "bg-secondary"
    },
    Hs = (() => {
        class t {
            constructor(e, o) {
                this.service = e, this.jobService = o, this.formatMessage = g, this.activatedRouter = b(R), this.toastNotificationService = b(D), this.shippingService = b(bo), this.jobDeliveries = [], this.jobId = null, this.entity = I.JOB_DELIVERY, this.isTrackingPopupVisible = !1, this.trackingData = null, this.trackingShipment = null, this.isLoadingTracking = !1, this.isCancelPopupVisible = !1, this.cancelReason = "", this.cancelShipmentId = null, this.isCancelling = !1, this.columns = [{
                    dataField: "type.name",
                    caption: g("common_type"),
                    width: 150,
                    allowSorting: !1
                }, {
                    dataField: "delivered_by_user",
                    caption: g("common_delivered_by"),
                    cellTemplate: "employeeTemplate",
                    width: 110,
                    allowSorting: !1
                }, {
                    dataField: "delivery_provider.name",
                    caption: g("common_provider"),
                    hidingPriority: 3,
                    allowSorting: !1,
                    calculateCellValue: i => {
                        if (i.delivery_provider ? .name) return i.delivery_provider.name;
                        if (i.latest_shipment ? .provider) {
                            let p = i.latest_shipment.provider.charAt(0).toUpperCase() + i.latest_shipment.provider.slice(1);
                            return i.latest_shipment.courier_name ? `${p} (${i.latest_shipment.courier_name})` : p
                        }
                        return ""
                    }
                }, {
                    dataField: "tracking_id",
                    caption: g("common_tracking_id"),
                    hidingPriority: 1,
                    allowSorting: !1,
                    calculateCellValue: i => i.tracking_id || i.latest_shipment ? .awb_code || ""
                }, {
                    dataField: "latest_shipment.status",
                    caption: g("shipping_status"),
                    hidingPriority: 5,
                    cellTemplate: "shipmentStatusTemplate",
                    allowSorting: !1
                }, {
                    dataField: "comment",
                    caption: g("common_comment"),
                    hidingPriority: 2,
                    cellTemplate: "commentTemplate",
                    allowSorting: !1
                }, {
                    dataField: "created_at",
                    caption: g("common_created_on"),
                    hidingPriority: 0,
                    cellTemplate: "dateTimeTemplate",
                    allowSorting: !0
                }, {
                    dataField: "",
                    caption: "",
                    hidingPriority: 4,
                    cellTemplate: "actionTemplate",
                    allowSorting: !1
                }]
            }
            ngOnInit() {
                this.jobId = +this.activatedRouter.snapshot.parent.paramMap.get("job_id"), this.jobService.deliveryListReload$.subscribe({
                    next: () => {
                        this.initialize()
                    },
                    error: e => {
                        this.toastNotificationService.error("notification_error"), console.error("error", e)
                    }
                })
            }
            initialize() {
                this.jobService.statusListReload$.subscribe({
                    next: () => {
                        this.dataGrid && this.dataGrid.getData()
                    },
                    error: e => {
                        this.toastNotificationService.error("notification_error"), console.error("error ", e)
                    }
                })
            }
            trackShipment(e) {
                this.isLoadingTracking = !0, this.isTrackingPopupVisible = !0, this.shippingService.trackShipment(e).subscribe({
                    next: o => {
                        this.trackingShipment = o.shipment, this.trackingData = o.tracking, this.isLoadingTracking = !1
                    },
                    error: () => {
                        this.toastNotificationService.error("shipping_serviceability_error"), this.isLoadingTracking = !1
                    }
                })
            }
            openCancelPopup(e) {
                this.cancelShipmentId = e, this.cancelReason = "", this.isCancelPopupVisible = !0
            }
            closeCancelPopup() {
                this.isCancelPopupVisible = !1, this.cancelShipmentId = null, this.cancelReason = ""
            }
            confirmCancelShipment() {
                this.cancelShipmentId && (this.isCancelling = !0, this.shippingService.cancelShipment(this.cancelShipmentId, this.cancelReason).subscribe({
                    next: () => {
                        this.toastNotificationService.success("shipping_cancelled_success"), this.dataGrid && this.dataGrid.getData(), this.isCancelling = !1, this.closeCancelPopup()
                    },
                    error: () => {
                        this.toastNotificationService.error("shipping_cancel_error"), this.isCancelling = !1
                    }
                }))
            }
            getStatusClass(e) {
                return Od[e] ? ? "bg-secondary"
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)(T(ci), T(U))
                }
            }
            static {
                this.\u0275cmp = P({
                    type: t,
                    selectors: [
                        ["app-delivery-history"]
                    ],
                    viewQuery: function(o, i) {
                        if (o & 1 && ne(ce, 5), o & 2) {
                            let p;
                            oe(p = ae()) && (i.dataGrid = p.first)
                        }
                    },
                    standalone: !1,
                    decls: 5,
                    vars: 18,
                    consts: [
                        [1, "row"],
                        [1, "col-sm-12", "col-md-12", "col-lg-12"],
                        [3, "dataGridCancelShipmentClick", "additionalParams", "columns", "entity", "isVisibleTitle", "service", "emptyStateConfig"],
                        [3, "visible", "maxHeight", "width", "maxWidth", "title"],
                        [3, "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                        [4, "dxTemplate", "dxTemplateOf"],
                        ["height", "100%", "width", "100%"],
                        [1, "text-center", "p-4"],
                        [1, "mb-3"],
                        ["height", "40", "width", "40", 3, "visible"],
                        [1, "d-flex", "justify-content-between", "mb-2"],
                        [1, "badge", 3, "ngClass"],
                        [1, "text-center", "mt-3"],
                        [1, "text-danger"],
                        ["target", "_blank", 1, "btn", "btn-outline-primary", "btn-sm", 3, "href"],
                        [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                        [1, "col-sm-12"],
                        ["name", "cancel_reason", 3, "label"],
                        ["minHeight", "80", "maxHeight", "150", 3, "valueChange", "value", "autoResizeEnabled", "placeholder"],
                        [3, "saveClick", "cancelClick", "useSubmitBehavior", "isOnPopup", "isSaving", "saveText", "gaEvent"]
                    ],
                    template: function(o, i) {
                        o & 1 && (r(0, "div", 0)(1, "div", 1)(2, "app-data-grid", 2), f("dataGridCancelShipmentClick", function(y) {
                            return i.openCancelPopup(y)
                        }), a()()(), m(3, Id, 2, 6, "dx-popup", 3), m(4, wd, 2, 6, "dx-popup", 3)), o & 2 && (n(2), l("additionalParams", fe(8, fd, i.jobId))("columns", i.columns)("entity", i.entity)("isVisibleTitle", !1)("service", i.service)("emptyStateConfig", ot(14, bd, i.formatMessage("empty_state_delivery_title"), i.formatMessage("empty_state_delivery_description"), ot(10, hd, i.formatMessage("empty_state_delivery_tip_1"), i.formatMessage("empty_state_delivery_tip_2"), i.formatMessage("empty_state_delivery_tip_3")))), n(), _(i.isTrackingPopupVisible ? 3 : -1), n(), _(i.isCancelPopupVisible ? 4 : -1))
                    },
                    dependencies: [Q, ee, K, ce, W, Xn, H, ye, jt, Jn],
                    encapsulation: 2
                })
            }
        }
        return t
    })();

function jd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "p", 0), d(1), a(), r(2, "dx-text-area", 1), f("focusout", function() {
            C(e);
            let i = s();
            return v(i.onFocusOut())
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s();
            return O(p.noteData, i) || (p.noteData = i), v(i)
        }), a()
    }
    if (t & 2) {
        let e = s();
        n(), h(e.formatMessage("note")), n(), w("ngModel", e.noteData), l("placeholder", e.formatMessage("enter_any_note"))
    }
}

function Vd(t, c) {
    if (t & 1 && (r(0, "h6", 2), d(1), a()), t & 2) {
        let e = s(2);
        n(), h(e.formatMessage("note"))
    }
}

function Dd(t, c) {
    if (t & 1 && (m(0, Vd, 2, 1, "h6", 2), r(1, "p", 3), d(2), a()), t & 2) {
        let e = s();
        _(e.noteData ? 0 : -1), n(2), h(e.noteData)
    }
}
var Mo = (() => {
    class t {
        constructor() {
            this.isEditMode = !1, this.noteData = "", this.viewData = new J, this.formatMessage = g
        }
        onFocusOut() {
            this.viewData.emit(this.noteData)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-edit-input"]
                ],
                inputs: {
                    isEditMode: "isEditMode",
                    noteData: "noteData"
                },
                outputs: {
                    viewData: "viewData"
                },
                standalone: !1,
                decls: 2,
                vars: 1,
                consts: [
                    [1, "fw-custom-450", "section-header", "my-0", "fs-14"],
                    [1, "mb-3", 3, "focusout", "ngModelChange", "ngModel", "placeholder"],
                    [1, "fw-custom-450", "section-header", "my-0"],
                    [1, "mb-0"]
                ],
                template: function(o, i) {
                    o & 1 && m(0, jd, 3, 3)(1, Dd, 3, 2), o & 2 && _(i.isEditMode ? 0 : 1)
                },
                dependencies: [jt, q, $e],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function kd(t, c) {
    if (t & 1 && u(0, "app-activity-list", 3), t & 2) {
        let e = s();
        l("activities", e.activities)
    }
}
var zs = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = g, this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.activities = [], this.jobId = null
        }
        ngOnInit() {
            this.routeParamsSub = this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.jobId = null, this.jobId = +e.job_id, this.service.getWithParams({
                        job_id: this.jobId,
                        job_type: I.JOB.name
                    }).subscribe({
                        next: o => {
                            this.activities = o
                        },
                        error: o => {
                            this.toastNotificationService.error("notification_error"), console.error("error while fetching activities ", o)
                        }
                    })
                },
                error: e => {
                    console.error("error ", e)
                }
            })
        }
        ngOnDestroy() {
            this.routeParamsSub && this.routeParamsSub.unsubscribe()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ms))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-activity"]
                ],
                standalone: !1,
                decls: 6,
                vars: 3,
                consts: [
                    [1, "job-activities", 3, "ngClass"],
                    [1, "mb-1"],
                    [1, "activity-list-container"],
                    [3, "activities"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1)(2, "h6"), d(3), a()(), r(4, "div", 2), m(5, kd, 1, 1, "app-activity-list", 3), a()()), o & 2 && (l("ngClass", i.isMobileDevice ? "" : "ps-3"), n(3), h(i.formatMessage("activity_log")), n(2), _(i.activities != null && i.activities.length ? 5 : -1))
                },
                dependencies: [Q, Zr],
                styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%;min-height:0}.job-activities[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;min-height:0}.job-activities[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{margin-right:10px}.job-activities[_ngcontent-%COMP%]   .title-text[_ngcontent-%COMP%]{flex-shrink:0}.job-activities[_ngcontent-%COMP%]   .activity-list-container[_ngcontent-%COMP%]{flex:1;min-height:0;display:flex;flex-direction:column}"]
            })
        }
    }
    return t
})();
var tl = ma(cr());
var St = (() => {
    class t extends Be {
        constructor(e) {
            super(e, Fo), this.api = e, this.endpoint = Fo
        }
        createCustomer(e) {
            return this.api.post(this.endpoint + "/createCustomer/", e)
        }
        getOpenSelfCheckInRequestCount() {
            return this.api.get(this.endpoint + "/getOpenSelfCheckInRequestCount")
        }
        updateStatusAssignee(e) {
            return this.api.post(this.endpoint + `/updateStatusAssignee/${e.id}`, e)
        }
        checkUniqueName(e) {
            return this.api.post(this.endpoint + "/checkUniqueName", e)
        }
        convertToCustomer(e) {
            return this.api.put(this.endpoint + `/convertToCustomer/${e}`)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Qe(Ie))
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function Ad(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 2)(1, "dx-radio-group", 6), f("valueChange", function(i) {
            C(e);
            let p = s(2);
            return v(p.toggleConditionsType(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("disabled", !e.isEditMode)("items", e.prePostConditionTypes)
    }
}

function Jd(t, c) {
    if (t & 1 && (r(0, "div", 3)(1, "strong"), d(2), a()()), t & 2) {
        let e = s(2);
        n(2), h(e.isPreConditions ? "Pre Conditions" : "Post Conditions")
    }
}

function Ld(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 4)(1, "dx-switch", 7), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.isSelectAll, i) || (p.isSelectAll = i), v(i)
        }), f("valueChange", function(i) {
            C(e);
            let p = s(2);
            return v(p.selectDeselectAllConditions(i))
        }), a(), r(2, "label", 8), d(3), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("value", !1)("disabled", !e.isEditMode), w("ngModel", e.isSelectAll), n(2), h(e.formatMessage("job_pre_post_conditions_select_all"))
    }
}

function Bd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 9)(1, "dx-switch", 10), j("ngModelChange", function(i) {
            let p = C(e).$index,
                y = s(3);
            return O(y.preRepairConditions[p].value, i) || (y.preRepairConditions[p].value = i), v(i)
        }), f("onValueChanged", function() {
            C(e);
            let i = s(3);
            return v(i.getSelectedConditions())
        }), a(), r(2, "label", 8), d(3), a()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = c.$index,
            i = s(3);
        n(), l("value", !0)("disabled", !i.isEditMode), w("ngModel", i.preRepairConditions[o].value), n(2), h(e.name)
    }
}

function Rd(t, c) {
    if (t & 1 && X(0, Bd, 4, 4, "div", 9, He), t & 2) {
        let e = s(2);
        Z(e.prePostRepairConditions)
    }
}

function Ud(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 9)(1, "dx-switch", 10), j("ngModelChange", function(i) {
            let p = C(e).$index,
                y = s(3);
            return O(y.postRepairConditions[p].value, i) || (y.postRepairConditions[p].value = i), v(i)
        }), f("onValueChanged", function() {
            C(e);
            let i = s(3);
            return v(i.getSelectedConditions())
        }), a(), r(2, "label", 8), d(3), a()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = c.$index,
            i = s(3);
        n(), l("value", !0)("disabled", !i.isEditMode), w("ngModel", i.postRepairConditions[o].value), n(2), h(e.name)
    }
}

function Fd(t, c) {
    if (t & 1 && X(0, Ud, 4, 4, "div", 9, He), t & 2) {
        let e = s(2);
        Z(e.prePostRepairConditions)
    }
}

function qd(t, c) {
    if (t & 1 && (r(0, "div", 0), m(1, Ad, 2, 2, "div", 2)(2, Jd, 3, 1, "div", 3), m(3, Ld, 4, 4, "div", 4), r(4, "div", 5), m(5, Rd, 2, 0)(6, Fd, 2, 0), a()()), t & 2) {
        let e = s();
        n(), _(e.showTabs ? 1 : 2), n(2), _(e.allPrePostConditions.length > 1 ? 3 : -1), n(2), _(e.isPreConditions ? 5 : 6)
    }
}

function Gd(t, c) {
    if (t & 1 && (r(0, "div")(1, "h5"), d(2), a()()), t & 2) {
        let e = c.$implicit;
        n(2), h(e.title)
    }
}

function Wd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 2)(1, "dx-radio-group", 6), f("valueChange", function(i) {
            C(e);
            let p = s(3);
            return v(p.toggleConditionsType(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), l("disabled", !e.isEditMode)("items", e.prePostConditionTypes)
    }
}

function Hd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 5)(1, "div", 13)(2, "dx-switch", 7), j("ngModelChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.isSelectAll, i) || (p.isSelectAll = i), v(i)
        }), f("valueChange", function(i) {
            C(e);
            let p = s(3);
            return v(p.selectDeselectAllConditions(i))
        }), a(), r(3, "label", 14), d(4), a()()()
    }
    if (t & 2) {
        let e = s(3);
        n(2), l("value", !1)("disabled", !e.isEditMode), w("ngModel", e.isSelectAll), n(2), h(e.formatMessage("job_pre_post_conditions_select_all"))
    }
}

function Qd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 15)(1, "dx-switch", 10), j("ngModelChange", function(i) {
            let p = C(e).$index,
                y = s(4);
            return O(y.preRepairConditions[p].value, i) || (y.preRepairConditions[p].value = i), v(i)
        }), f("onValueChanged", function() {
            C(e);
            let i = s(4);
            return v(i.getSelectedConditions())
        }), a(), r(2, "label", 14), d(3), a()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = c.$index,
            i = s(4);
        n(), l("value", !0)("disabled", !i.isEditMode), w("ngModel", i.preRepairConditions[o].value), n(2), h(e.name)
    }
}

function zd(t, c) {
    if (t & 1 && (r(0, "div", 5), X(1, Qd, 4, 4, "div", 15, He), a()), t & 2) {
        let e = s(3);
        n(), Z(e.prePostRepairConditions)
    }
}

function Yd(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 15)(1, "dx-switch", 10), j("ngModelChange", function(i) {
            let p = C(e).$index,
                y = s(4);
            return O(y.postRepairConditions[p].value, i) || (y.postRepairConditions[p].value = i), v(i)
        }), f("onValueChanged", function() {
            C(e);
            let i = s(4);
            return v(i.getSelectedConditions())
        }), a(), r(2, "label", 14), d(3), a()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = c.$index,
            i = s(4);
        n(), l("value", !0)("disabled", !i.isEditMode), w("ngModel", i.postRepairConditions[o].value), n(2), h(e.name)
    }
}

function $d(t, c) {
    if (t & 1 && (r(0, "div", 5), X(1, Yd, 4, 4, "div", 15, He), a()), t & 2) {
        let e = s(3);
        n(), Z(e.prePostRepairConditions)
    }
}

function Kd(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 12), m(2, Wd, 2, 2, "div", 2), m(3, Hd, 5, 4, "div", 5), m(4, zd, 3, 0, "div", 5)(5, $d, 3, 0, "div", 5), a()()), t & 2) {
        let e = s(2);
        n(2), _(e.showTabs ? 2 : -1), n(), _(e.allPrePostConditions.length > 1 ? 3 : -1), n(), _(e.isPreConditions ? 4 : 5)
    }
}

function Xd(t, c) {
    if (t & 1 && (r(0, "dx-accordion", 1), E(1, Gd, 3, 1, "div", 11)(2, Kd, 6, 3, "div", 11), a()), t & 2) {
        let e = s();
        l("animationDuration", 300)("collapsible", !0)("dataSource", e.accordionData)("multiple", !0), n(), l("dxTemplateOf", "title"), n(), l("dxTemplateOf", "item")
    }
}
var sn = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.checkedPrePostConditions = [], this.allPrePostConditions = [], this.isEditMode = !0, this.conditionMode = "both", this.inlineMode = !1, this.prePostConditionChecklistSave = new J, this.prePostConditionChecklistClose = new J, this.accordionData = [{
                title: "Device Pre-Repair Condition Checklist"
            }], this.preRepairConditions = [], this.postRepairConditions = [], this.prePostRepairConditions = [], this.prePostConditionTypes = ["Pre Conditions", "Post Conditions"], this.isPreConditions = !0, this.showTabs = !0, this.isSelectAll = !1, this.isPostConditionsSelectAll = !1, this.isPreConditionsSelectAll = !1, this.FEATURE_BADGE_TYPES = Xa
        }
        ngOnInit() {
            this.preRepairConditions = this.filterConditionsByType(ui.PRE_CONDITION), this.postRepairConditions = this.filterConditionsByType(ui.POST_CONDITION), this.updateTabVisibility(), this.initializeConditionValues()
        }
        ngOnChanges(e) {
            (e.allPrePostConditions || e.checkedPrePostConditions || e.conditionMode) && (this.preRepairConditions = this.filterConditionsByType(ui.PRE_CONDITION), this.postRepairConditions = this.filterConditionsByType(ui.POST_CONDITION), this.updateTabVisibility(), this.initializeConditionValues())
        }
        filterConditionsByType(e) {
            return this.allPrePostConditions.filter(o => o.condition_type === e)
        }
        initializeConditionValues() {
            this.resetConditionValues(!1), this.setCheckedConditions()
        }
        selectDeselectAllConditions(e) {
            this.isPreConditions ? this.isPreConditionsSelectAll = e : this.isPostConditionsSelectAll = e, this.resetConditionValues(e)
        }
        toggleConditionsType(e) {
            this.isSelectAll = e === "Pre Conditions" ? this.isPreConditionsSelectAll : this.isPostConditionsSelectAll, this.isPreConditions = e === this.prePostConditionTypes[0], this.prePostRepairConditions = this.isPreConditions ? this.preRepairConditions.slice() : this.postRepairConditions.slice()
        }
        getSelectedConditions() {
            let e = this.getSelectedConditionsData();
            return this.prePostConditionChecklistSave.emit(e), e
        }
        getSelectedConditionsData() {
            return [{
                pre_conditions: this.preRepairConditions.filter(e => e.value === !0)
            }, {
                post_conditions: this.postRepairConditions.filter(e => e.value === !0)
            }]
        }
        updateTabVisibility() {
            this.conditionMode === "pre" ? (this.showTabs = !1, this.isPreConditions = !0, this.prePostRepairConditions = this.preRepairConditions.slice()) : this.conditionMode === "post" ? (this.showTabs = !1, this.isPreConditions = !1, this.prePostRepairConditions = this.postRepairConditions.slice()) : (this.showTabs = !0, this.isPreConditions = !0, this.prePostRepairConditions = this.preRepairConditions.slice())
        }
        resetConditionValues(e) {
            this.isPreConditions ? this.preRepairConditions = this.preRepairConditions.map(o => Ge(Te({}, o), {
                value: e
            })) : this.postRepairConditions = this.postRepairConditions.map(o => Ge(Te({}, o), {
                value: e
            })), this.isPreConditions ? this.prePostRepairConditions = this.preRepairConditions : this.prePostRepairConditions = this.postRepairConditions
        }
        setCheckedConditions() {
            if (this.checkedPrePostConditions) {
                let e = this.checkedPrePostConditions[0] ? .pre_conditions,
                    o = this.checkedPrePostConditions[1] ? .post_conditions;
                this.preRepairConditions.forEach((i, p) => {
                    e ? .find(y => y.name === i.name) && (this.preRepairConditions[p].value = !0)
                }), this.postRepairConditions.forEach((i, p) => {
                    o ? .find(y => y.name === i.name) && (this.postRepairConditions[p].value = !0)
                }), this.prePostRepairConditions = this.isPreConditions ? this.preRepairConditions : this.postRepairConditions
            }
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-pre-post-condition-check-list-pop-up"]
                ],
                inputs: {
                    checkedPrePostConditions: "checkedPrePostConditions",
                    allPrePostConditions: "allPrePostConditions",
                    isEditMode: "isEditMode",
                    conditionMode: "conditionMode",
                    inlineMode: "inlineMode"
                },
                outputs: {
                    prePostConditionChecklistSave: "prePostConditionChecklistSave",
                    prePostConditionChecklistClose: "prePostConditionChecklistClose"
                },
                standalone: !1,
                features: [Yt],
                decls: 2,
                vars: 1,
                consts: [
                    [1, "inline-conditions-body"],
                    [3, "animationDuration", "collapsible", "dataSource", "multiple"],
                    [1, "d-flex", "justify-content-center", "mb-3", "schedule-pickup-drop"],
                    [1, "mb-2"],
                    [1, "d-flex", "align-items-center", "mb-2"],
                    [1, "row"],
                    ["layout", "horizontal", "value", "Pre Conditions", 3, "valueChange", "disabled", "items"],
                    [3, "ngModelChange", "valueChange", "value", "disabled", "ngModel"],
                    [1, "ms-2"],
                    [1, "col-6", "col-md-4", "col-lg-4", "d-flex", "align-items-center", "mb-2"],
                    [3, "ngModelChange", "onValueChanged", "value", "disabled", "ngModel"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "accordion-body"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "d-flex", "align-items-center", "justify-content-center"],
                    [1, "p-3"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center"]
                ],
                template: function(o, i) {
                    o & 1 && m(0, qd, 7, 3, "div", 0)(1, Xd, 3, 6, "dx-accordion", 1), o & 2 && _(i.inlineMode ? 0 : 1)
                },
                dependencies: [At, W, fr, Li, q, $e],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ys = t => ({
        $implicit: t
    }),
    $s = (t, c) => c.key;

function Zd(t, c) {
    t & 1 && u(0, "i", 6)
}

function ep(t, c) {
    if (t & 1 && (r(0, "small", 8), d(1), a()), t & 2) {
        let e = s(2);
        n(), h(e.formatMessage("field_configuration_subtitle"))
    }
}

function tp(t, c) {
    if (t & 1 && (r(0, "div", 13), d(1), a()), t & 2) {
        let e = s(2);
        n(), h(e.formatMessage("field_config_description"))
    }
}

function ip(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-tabs", 17), f("onItemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.onTabChange(i))
        }), a()
    }
    if (t & 2) {
        let e = s(2);
        l("items", e.fieldConfigCategories)("selectedIndex", e.selectedTabIndex)("scrollByContent", !0)("showNavButtons", !0)
    }
}

function np(t, c) {
    t & 1 && Lo(0)
}

function op(t, c) {
    if (t & 1 && E(0, np, 1, 0, "ng-container", 19), t & 2) {
        let e = c.$implicit;
        s(2);
        let o = _n(21);
        l("ngTemplateOutlet", o)("ngTemplateOutletContext", fe(2, Ys, e))
    }
}

function ap(t, c) {
    if (t & 1 && (r(0, "dx-scroll-view", 15)(1, "div", 18), X(2, op, 1, 4, "ng-container", null, $s), a()()), t & 2) {
        let e = s(2);
        n(2), Z(e.filteredFields)
    }
}

function rp(t, c) {
    if (t & 1 && (r(0, "div")(1, "span", 23), d(2), a()()), t & 2) {
        let e = c.$implicit;
        n(2), h(e.text)
    }
}

function sp(t, c) {
    t & 1 && Lo(0)
}

function lp(t, c) {
    if (t & 1 && E(0, sp, 1, 0, "ng-container", 19), t & 2) {
        let e = c.$implicit;
        s(3);
        let o = _n(21);
        l("ngTemplateOutlet", o)("ngTemplateOutletContext", fe(2, Ys, e))
    }
}

function cp(t, c) {
    if (t & 1 && (r(0, "div", 24), X(1, lp, 1, 4, "ng-container", null, $s), a()), t & 2) {
        let e = c.$implicit,
            o = s(3);
        n(), Z(o.getFieldsByCategory(e.category))
    }
}

function dp(t, c) {
    if (t & 1 && (r(0, "dx-scroll-view", 15)(1, "dx-accordion", 20), E(2, rp, 3, 1, "div", 21)(3, cp, 3, 0, "div", 22), a()()), t & 2) {
        let e = s(2);
        n(), l("dataSource", e.fieldConfigCategories)("collapsible", !0)("multiple", !1)("animationDuration", 200)("selectedIndex", e.selectedTabIndex), n(), l("dxTemplateOf", "title"), n(), l("dxTemplateOf", "item")
    }
}

function pp(t, c) {
    if (t & 1 && (r(0, "span", 29), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("common_required"))
    }
}

function mp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 25)(1, "div", 26)(2, "div", 27)(3, "strong", 28), d(4), a(), m(5, pp, 2, 1, "span", 29), a(), r(6, "div", 16), d(7), a()(), r(8, "div", 30), u(9, "i", 31), r(10, "dx-switch", 32), f("onValueChanged", function(i) {
            let p = C(e).$implicit,
                y = s(2);
            return v(y.onFieldToggle(p, i))
        }), a()()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = s(2);
        n(4), h(e.label), n(), _(e.required ? 5 : -1), n(2), S(" ", e.visible ? o.formatMessage("field_config_visible_in_form") : o.formatMessage("field_config_hidden_in_form"), " "), n(2), l("ngClass", e.visible ? "fa-eye text-success" : "fa-eye-slash text-muted"), n(), l("value", e.visible)("disabled", e.required)
    }
}

function _p(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 3)(1, "div")(2, "div", 4)(3, "div", 5), m(4, Zd, 1, 0, "i", 6), r(5, "div")(6, "h5", 7), d(7), a(), m(8, ep, 2, 1, "small", 8), a()(), r(9, "dx-button", 9), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.onClosing())
        }), a()(), u(10, "hr"), r(11, "div", 10)(12, "span", 11), d(13), a(), r(14, "dx-button", 12), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.saveFieldConfig())
        }), a()(), m(15, tp, 2, 1, "div", 13), u(16, "hr"), m(17, ip, 1, 4, "dx-tabs", 14), a(), m(18, ap, 4, 0, "dx-scroll-view", 15), m(19, dp, 4, 7, "dx-scroll-view", 15), E(20, mp, 11, 6, "ng-template", null, 0, _i), r(22, "div"), u(23, "hr"), r(24, "div", 16), d(25), a()()()
    }
    if (t & 2) {
        let e = s();
        mi("font-size", e.isMobileDevice ? "0.8125rem" : ""), n(4), _(e.isMobileDevice ? -1 : 4), n(2), mi("font-size", e.isMobileDevice ? "0.875rem" : ""), n(), h(e.formatMessage("field_configuration")), n(), _(e.isMobileDevice ? -1 : 8), n(5), ya(" ", e.enabledFieldCount, " ", e.formatMessage("common_of"), " ", e.totalFieldCount, " ", e.formatMessage("field_config_fields_enabled"), " "), n(), l("text", e.isMobileDevice ? "" : e.formatMessage("field_config_save"))("disabled", e.isSaving)("hint", e.formatMessage("field_config_save")), n(), _(e.isMobileDevice ? -1 : 15), n(2), _(e.isMobileDevice ? -1 : 17), n(), _(e.isMobileDevice ? -1 : 18), n(), _(e.isMobileDevice ? 19 : -1), n(6), S(" ", e.formatMessage("field_config_tip"), " ")
    }
}
var Ks = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.isVisiblePopup = !1, this.isRecovery = !1, this.fieldConfigClose = new J, this.fieldConfigSave = new J, this.generalSettingDataService = b(te), this.generalSettingsService = b(ts), this.toastNotificationService = b(D), this.isMobileDevice = b(A).isMobileDevice(), this.fieldConfigItems = [], this.selectedTabIndex = 0, this.isSaving = !1, this.fieldConfigCategories = [{
                id: 0,
                text: g("basic_information"),
                category: "basic"
            }, {
                id: 1,
                text: g("device_information"),
                category: "device"
            }, {
                id: 2,
                text: g("service_information"),
                category: "service"
            }, {
                id: 3,
                text: g("additional_information"),
                category: "additional"
            }], this.FIELD_DEFINITIONS = [{
                key: "customer_name",
                label: g("user_customer_name"),
                required: !0,
                category: "basic"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.SOURCE_ID,
                label: g("user_customer_source"),
                required: !1,
                category: "basic"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.REFERRED_BY_ID,
                label: g("user_customer_referred_by"),
                required: !1,
                category: "basic"
            }, {
                key: "service_type",
                label: g("job_service_type"),
                required: !0,
                category: "basic"
            }, {
                key: "job_type",
                label: g("job_type"),
                required: !0,
                category: "basic"
            }, {
                key: "device_type",
                label: g("device_type_name"),
                required: !0,
                category: "device"
            }, {
                key: "device_brand",
                label: g("device_brand_name"),
                required: !0,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.DEVICE_MODEL_ID,
                label: g("device_model_name"),
                required: !1,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.SERIAL_NUMBER,
                label: g("device_serial_imei_number"),
                required: !1,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.PCB_NUMBER,
                label: g("pcb_number_serial_number_2"),
                required: !1,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.ACCESSORIES,
                label: g("accessories"),
                required: !1,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.STORAGE_LOCATION_ID,
                label: g("device_storage_location"),
                required: !1,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.DEVICE_COLOR_ID,
                label: g("device_color_label"),
                required: !1,
                category: "device"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.DEVICE_PASSWORD,
                label: g("device_password"),
                required: !1,
                category: "device"
            }, {
                key: "services",
                label: g("job_services"),
                required: !0,
                category: "service"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.TAGS,
                label: g("tags_label"),
                required: !1,
                category: "service"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.HARDWARE_CONFIGURATION,
                label: g("device_hardware_configuration"),
                required: !1,
                category: "service"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.COMMENT,
                label: g("job_service_assessment"),
                required: !1,
                category: "service"
            }, {
                key: "priority",
                label: g("priority"),
                required: !0,
                category: "additional"
            }, {
                key: "assignee",
                label: g("job_assignee"),
                required: !0,
                category: "additional"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.INITIAL_QUOTATION,
                label: g("initial_quotation_label"),
                required: !1,
                category: "additional"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.ESTIMATED_DELIVERY,
                label: g("job_due_date"),
                required: !1,
                category: "additional"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.VENDOR_JOB_ID,
                label: g("dealer_Job_id"),
                required: !1,
                category: "additional"
            }, {
                key: F.JOB_FORM_FIELD_CONFIG.TERM_AND_CONDITION,
                label: g("common_terms_and_conditions"),
                required: !1,
                category: "additional"
            }]
        }
        get enabledFieldCount() {
            return this.fieldConfigItems.filter(e => e.visible).length
        }
        get totalFieldCount() {
            return this.fieldConfigItems.length
        }
        get filteredFields() {
            return this.getFieldsByCategory(this.fieldConfigCategories[this.selectedTabIndex] ? .category)
        }
        getFieldsByCategory(e) {
            return this.fieldConfigItems.filter(o => o.category === e)
        }
        ngOnInit() {
            this.loadFieldConfig()
        }
        onClosing() {
            this.isVisiblePopup = !1, this.fieldConfigClose.emit()
        }
        onTabChange(e) {
            this.selectedTabIndex = e.itemIndex
        }
        onFieldToggle(e, o) {
            e.visible = o.value
        }
        saveFieldConfig() {
            if (this.isSaving) return;
            this.isSaving = !0;
            let e = {
                general_settings: this.fieldConfigItems.filter(o => !o.required).map(o => ({
                    setting_type: Ce.JOB_FORM_FIELD_CONFIG,
                    key: o.key,
                    value: o.visible
                }))
            };
            this.generalSettingsService.generalSettings(e).subscribe({
                next: () => {
                    this.toastNotificationService.success("field_config_save_success"), this.fieldConfigSave.emit(), this.onClosing(), window.location.reload()
                },
                error: () => {
                    this.toastNotificationService.error("field_config_save_error")
                }
            }).add(() => {
                this.isSaving = !1
            })
        }
        loadFieldConfig() {
            let e = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.JOB_FORM_FIELD_CONFIG) || {},
                o = this.isRecovery ? this.FIELD_DEFINITIONS : this.FIELD_DEFINITIONS.filter(i => i.key !== F.JOB_FORM_FIELD_CONFIG.PCB_NUMBER);
            this.fieldConfigItems = o.map(i => Ge(Te({}, i), {
                visible: i.required ? !0 : e[i.key] !== !1
            }))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-field-config-popup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isRecovery: "isRecovery"
                },
                outputs: {
                    fieldConfigClose: "fieldConfigClose",
                    fieldConfigSave: "fieldConfigSave"
                },
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    ["fieldItemTemplate", ""],
                    ["id", "field-config-popup", 3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "maxHeight", "showTitle", "hideOnOutsideClick"],
                    ["class", "d-flex flex-column h-100", 3, "fontSize", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "flex-column", "h-100"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-2"],
                    [1, "d-flex", "align-items-center"],
                    [1, "fa-thin", "fa-cog", "fa-2x", "me-3"],
                    [1, "mb-0", "fw-bold"],
                    [1, "text-muted"],
                    ["icon", "close", "stylingMode", "text", 3, "onClick"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-2", "gap-2", "flex-wrap"],
                    [1, "badge", "rounded-pill", "text-bg-secondary"],
                    ["icon", "save", "type", "default", "stylingMode", "outlined", 3, "onClick", "text", "disabled", "hint"],
                    [1, "text-muted", "small", "mb-3"],
                    [3, "items", "selectedIndex", "scrollByContent", "showNavButtons"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [1, "text-muted", "small"],
                    [3, "onItemClick", "items", "selectedIndex", "scrollByContent", "showNavButtons"],
                    [1, "mt-3"],
                    [4, "ngTemplateOutlet", "ngTemplateOutletContext"],
                    [3, "dataSource", "collapsible", "multiple", "animationDuration", "selectedIndex"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["class", "p-2", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "fw-medium"],
                    [1, "p-2"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "p-3", "mb-2", "rounded", "border", "gap-2"],
                    [1, "flex-grow-1", "min-width-0"],
                    [1, "d-flex", "align-items-center", "flex-wrap", "gap-1"],
                    [1, "text-truncate"],
                    [1, "badge", "text-warning", "border", "border-warning"],
                    [1, "d-flex", "align-items-center", "gap-2", "flex-shrink-0"],
                    [1, "fa-thin", 3, "ngClass"],
                    [3, "onValueChanged", "value", "disabled"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 1), f("onHidden", function() {
                        return i.onClosing()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, _p, 26, 19, "div", 2), a()), o & 2 && (w("visible", i.isVisiblePopup), l("width", "95vw")("maxWidth", 550)("maxHeight", "80vh")("showTitle", !1)("hideOnOutsideClick", !0), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [Q, Ia, At, W, ct, H, ye, Li, hr],
                encapsulation: 2
            })
        }
    }
    return t
})();

function vp(t, c) {
    t & 1 && d(0, " 1 ")
}

function fp(t, c) {
    t & 1 && u(0, "i", 9)
}

function hp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 13)(1, "h6", 14), u(2, "i", 15), d(3), a(), r(4, "p", 16), d(5), a()(), r(6, "div", 17)(7, "app-dx-outline-button", 18), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.onSkipPayment())
        }), a(), r(8, "app-dx-outline-button", 19), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.onCollectPayment())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(3), S("", e.formatMessage("common_advance_payment"), " "), n(2), h(e.formatMessage("collect_advance_payment_description"))
    }
}

function bp(t, c) {
    if (t & 1 && (r(0, "div", 20), u(1, "i", 26), r(2, "span", 27), d(3), a()()), t & 2) {
        let e = s(3);
        n(3), h(e.formatMessage("payment_added_successfully"))
    }
}

function gp(t, c) {
    if (t & 1) {
        let e = x();
        m(0, bp, 4, 1, "div", 20), r(1, "div", 5)(2, "h6", 21), u(3, "i", 22), d(4), a(), u(5, "app-user-notification-channel", 23), a(), r(6, "div", 17)(7, "app-dx-outline-button", 24), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.onSkipNotification())
        }), a(), r(8, "app-dx-outline-button", 25), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.onSendNotification())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        _(e.paymentCollected ? 0 : -1), n(4), S("", e.formatMessage("send_job_sheet"), " "), n(), l("form", e.notificationForm), n(2), l("disabled", e.isSending), n(), l("disabled", e.isSending)("text", e.isSending ? "common_sending" : "common_send")("title", e.isSending ? "common_sending" : "common_send")
    }
}

function xp(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 3)(2, "div", 4)(3, "div", 5), u(4, "app-job-current-info", 6), a(), r(5, "div", 7)(6, "span", 8), m(7, vp, 1, 0)(8, fp, 1, 0, "i", 9), a(), r(9, "span", 10), d(10), a(), u(11, "hr", 11), r(12, "span", 8), d(13, "2"), a(), r(14, "span", 12), d(15), a()(), m(16, hp, 9, 2), m(17, gp, 9, 7), a()()()), t & 2) {
        let e = s();
        n(4), l("job", e.job), n(2), l("ngClass", e.currentStep === 1 ? "bg-primary" : "bg-success"), n(), _(e.currentStep === 1 ? 7 : 8), n(2), Ae("fw-bold", e.currentStep === 1), n(), h(e.formatMessage("common_advance_payment")), n(2), l("ngClass", e.currentStep === 2 ? "bg-primary" : "bg-secondary bg-opacity-25"), n(2), Ae("fw-bold", e.currentStep === 2), n(), h(e.formatMessage("send_job_sheet")), n(), _(e.currentStep === 1 ? 16 : -1), n(), _(e.currentStep === 2 ? 17 : -1)
    }
}

function Sp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-unified-payment-modal", 28), f("paymentClose", function() {
            C(e);
            let i = s();
            return v(i.onPaymentClose())
        })("paymentSuccess", function(i) {
            C(e);
            let p = s();
            return v(p.onPaymentSave(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entity", e.job)("entityType", e.ENTITIES.JOB.name)("isVisiblePopup", e.isPaymentPopupVisible)("redirectAfterSave", !1)("isAdvancePayment", !0)
    }
}
var Xs = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.ENTITIES = I, this.job = null, this.isVisiblePopup = !1, this.modalClose = new J, this.router = b(G), this.commonService = b(Di), this.whatsappService = b(Ke), this.userSessionService = b(L), this.toastNotificationService = b(D), this.isMobileDevice = b(A).isMobileDevice(), this.userPermissionList = this.userSessionService.userPermissionList(), this.currentStep = 1, this.isSending = !1, this.isPaymentPopupVisible = !1, this.paymentCollected = !1
        }
        ngOnInit() {
            this.buildNotificationForm()
        }
        onCollectPayment() {
            this.isPaymentPopupVisible = !0
        }
        onSkipPayment() {
            this.currentStep = 2
        }
        onPaymentSave(e) {
            this.paymentCollected = !0, this.isPaymentPopupVisible = !1, this.currentStep = 2
        }
        onPaymentClose() {
            this.isPaymentPopupVisible = !1
        }
        onSendNotification() {
            this.isSending || (this.isSending = !0, this.commonService.sendCustomerNotification(this.notificationForm.value).subscribe({
                next: () => {
                    this.notificationForm.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("job_sheet", this.job ? .id), this.toastNotificationService.success("sent_successfully"), this.closeAndRedirect()
                },
                error: () => {
                    this.toastNotificationService.error("notification_send_error"), this.isSending = !1
                }
            }).add(() => {
                this.isSending = !1
            }))
        }
        onSkipNotification() {
            this.closeAndRedirect()
        }
        onClosing() {
            this.closeAndRedirect()
        }
        buildNotificationForm() {
            this.notificationForm = new Xt(Te({
                job_id: new k(this.job ? .id),
                notification_entity_type: new k(this.ENTITIES.JOB_SHEET.name),
                entity_id: new k(this.job ? .id),
                is_send_mail: new k(!1),
                is_send_sms: new k(!1),
                is_send_app: new k(!0)
            }, this.userPermissionList.includes(M.CUSTOMER_VIEW_CONTACT_INFORMATION) ? {
                is_send_whatsapp: new k(!1)
            } : {}))
        }
        closeAndRedirect() {
            this.isVisiblePopup = !1, this.modalClose.emit(), this.router.navigate([`/jobs/${this.job.id}/jobSheets`])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-success-modal"]
                ],
                inputs: {
                    job: "job",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    modalClose: "modalClose"
                },
                standalone: !1,
                decls: 3,
                vars: 8,
                consts: [
                    ["id", "job-success-modal", 3, "onHidden", "height", "maxHeight", "width", "maxWidth", "title", "visible"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "entity", "entityType", "isVisiblePopup", "redirectAfterSave", "isAdvancePayment"],
                    [1, "row"],
                    [1, "col-12"],
                    [1, "mb-3"],
                    [3, "job"],
                    [1, "d-flex", "align-items-center", "mb-3"],
                    [1, "badge", "rounded-pill", "me-2", 3, "ngClass"],
                    [1, "fa-thin", "fa-check"],
                    [1, "small", "me-3"],
                    [1, "flex-fill", "mx-2", "my-0"],
                    [1, "small"],
                    [1, "p-3", "border", "rounded", "mb-3"],
                    [1, "fw-bold", "mb-1"],
                    [1, "fa-thin", "fa-money-bill", "me-2"],
                    [1, "text-muted", "small", "mb-0"],
                    [1, "d-flex", "gap-2"],
                    ["buttonType", "normal", "cssClass", "w-100", "text", "common_skip", "title", "common_skip", 1, "flex-fill", 3, "onClickEvent"],
                    ["buttonType", "default", "cssClass", "w-100", "text", "common_collect_payment", "title", "common_collect_payment", 1, "flex-fill", 3, "onClickEvent"],
                    [1, "d-flex", "align-items-center", "mb-3", "p-2", "bg-success", "bg-opacity-10", "rounded"],
                    [1, "fw-bold", "mb-2"],
                    [1, "fa-thin", "fa-paper-plane", "me-2"],
                    [3, "form"],
                    ["buttonType", "normal", "cssClass", "w-100", "text", "common_skip", "title", "common_skip", 1, "flex-fill", 3, "onClickEvent", "disabled"],
                    ["buttonType", "default", "cssClass", "w-100", 1, "flex-fill", 3, "onClickEvent", "disabled", "text", "title"],
                    [1, "fa-thin", "fa-check-circle", "text-success", "me-2"],
                    [1, "small", "text-success", "fw-bold"],
                    [3, "paymentClose", "paymentSuccess", "entity", "entityType", "isVisiblePopup", "redirectAfterSave", "isAdvancePayment"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onClosing()
                    }), E(1, xp, 18, 12, "div", 1), a(), m(2, Sp, 1, 5, "app-unified-payment-modal", 2)), o & 2 && (l("height", "auto")("maxHeight", "90vh")("width", "95vw")("maxWidth", 550)("title", i.formatMessage("job_created_successfully"))("visible", i.isVisiblePopup), n(), l("dxTemplateOf", "content"), n(), _(i.isPaymentPopupVisible ? 2 : -1))
                },
                dependencies: [Q, et, Fe, po, ge, W, H],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Tp = () => ({
    autocomplete: "new-initial-quotation"
});

function Mp(t, c) {
    if (t & 1 && u(0, "app-alert-panel", 1), t & 2) {
        let e = s();
        l("message", e.formatMessage("job_already_created_confirmation"))
    }
}

function Pp(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 2), t & 2 && l("rows", 8)("columns", 3)
}

function Ip(t, c) {
    if (t & 1 && (r(0, "h3", 16), d(1), a()), t & 2) {
        let e = s(2);
        n(), ze("", e.formatMessage("jobSheet"), " : ", e.form.getRawValue().job_number)
    }
}

function Ep(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-dx-outline-button", 62), f("onClickEvent", function() {
            C(e);
            let i = s(3);
            return v(i.openFieldConfigPopup())
        }), a()
    }
    t & 2 && l("isVisibleIcon", !0)
}

function wp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-cancel-footer", 64), f("cancelClick", function() {
            C(e);
            let i = s(4);
            return v(i.onCancelEdit())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("isOnPopup", !1)("isSaving", e.isSaving)("isDisabled", e.isSaving)("isVisibleHr", !1)("saveText", e.job != null && e.job.id ? "common_update" : "common_create")("savingText", e.job != null && e.job.id ? "common_updating" : "common_creating")
    }
}

function Op(t, c) {
    if (t & 1 && E(0, wp, 1, 6, "app-save-cancel-footer", 63), t & 2) {
        let e = s(3);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_WRITE)
    }
}

function jp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-dx-outline-button", 67), f("click", function() {
            C(e);
            let i = s(4);
            return v(i.onEditMode())
        }), a()
    }
}

function Vp(t, c) {
    if (t & 1 && (u(0, "app-location-back", 65), E(1, jp, 1, 0, "app-dx-outline-button", 66)), t & 2) {
        let e = s(3);
        n(), l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_WRITE)
    }
}

function Dp(t, c) {
    if (t & 1 && (r(0, "div", 15)(1, "div", 59), E(2, Ep, 1, 1, "app-dx-outline-button", 60), m(3, Op, 1, 1, "app-save-cancel-footer", 61), m(4, Vp, 2, 1), a()()), t & 2) {
        let e = s(2);
        n(2), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE), n(), _(!e.isMobileDevice && e.isEditMode ? 3 : -1), n(), _(e.isEditMode ? -1 : 4)
    }
}

function kp(t, c) {
    if (t & 1 && u(0, "app-server-error", 17), t & 2) {
        let e = s(2);
        l("errorResponse", e.errorResponse)
    }
}

function Np(t, c) {
    if (t & 1 && (r(0, "app-control-container", 21), u(1, "dx-select-box", 68), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("common_error_job_source"))("label", e.formatMessage("user_customer_source")), n(), l("items", e.jobSources)("searchEnabled", !0)
    }
}

function Ap(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-control-container", 22)(1, "app-customer-dropdown", 69), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.onAddReferredBy(i))
        }), a()()
    }
    if (t & 2) {
        let e, o = s(2);
        l("errorMsg", o.formatMessage("common_error_messages_referred_by_required"))("label", o.formatMessage("user_customer_referred_by")), n(), l("customerId", o.form.getRawValue().id ? (e = o.form.getRawValue()) == null ? null : e.referred_by_id : null)("formControl", o.form.controls.referred_by_id)("isEditMode", o.isEditMode)("isVisibleAddAction", !1)("showCrateButton", !0)
    }
}

function Jp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 32), u(1, "app-select-box-with-images", 70), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("device_model_required_error"))("label", e.formatMessage("device_model_name")), n(), l("dataSource", e.deviceModelList)("isDxiButtonActive", e.isEditMode)("isDisabled", !e.isEditMode)("hasUserPermissions", e.PERMISSION_LIST.DEVICE_MODEL_WRITE)("buttonOptions", e.addDeviceModelOption)("buttonId", "job-basic-info-model-btn")("buttonName", "deviceModel")("imageCategory", "device-model")("isReadOnly", !e.form.getRawValue().device_brand_id || !e.isEditMode)("placeholder", "device_model_placeholder")
    }
}

function Lp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 33)(1, "dx-text-box", 71), u(2, "dxi-button", 72), a()()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("common_error_job_serial_number_required"))("label", e.formatMessage("device_serial_imei_number")), n(), l("placeholder", e.formatMessage("device_serial_number_placeholder")), n(), l("options", e.addSerialBarcodeScan)
    }
}

function Bp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 34), u(1, "dx-text-box", 73), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("common_error_job_serial_number_required"))("label", e.formatMessage("device_pcb_number")), n(), l("placeholder", e.formatMessage("device_pcb_number_placeholder"))
    }
}

function Rp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 35), u(1, "app-tag-box-with-images", 74), a()), t & 2) {
        let e = s(2);
        l("label", e.formatMessage("accessories")), n(), l("products", e.deviceTypeAccessoriesList)("isDxiButtonActive", e.isEditMode)("hasUserPermissions", e.PERMISSION_LIST.ACCESSORY_WRITE)("buttonOptions", e.addAccessoryOption)("buttonId", "job-basic-info-device-accessory")("buttonName", "accessory")("isDisabled", !e.isEditMode)("isReadOnly", !e.form.getRawValue().device_type_id || !e.isEditMode)("placeholder", "device_accessories_placeholder")("imageCategory", "accessory")
    }
}

function Up(t, c) {
    if (t & 1 && (r(0, "app-control-container", 36), u(1, "dx-select-box", 75), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("inventory_storage_location_error"))("label", e.formatMessage("device_storage_location")), n(), l("items", e.storageLocationList)("placeholder", e.formatMessage("device_storage_location_placeholder"))
    }
}

function Fp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 37), u(1, "app-device-color-dropdown", 76), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("device_color_required"))("label", e.formatMessage("device_color_label")), n(), l("formControl", e.form.controls.device_color_id)("isEditMode", e.isEditMode)
    }
}

function qp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-control-container", 38)(1, "app-password", 77), f("onPatternLockClick", function() {
            C(e);
            let i = s(2);
            return v(i.onPatternLockClick())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("label", e.formatMessage("device_password")), n(), l("disableAutoFill", !0)("formControl", e.form.controls.device_password)("isEditMode", e.isEditMode)("placeholder", e.formatMessage("device_password"))("showPatternLockButton", !0)
    }
}

function Gp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 39)(1, "app-pre-post-condition-check-list-pop-up", 78), f("prePostConditionChecklistSave", function(i) {
            C(e);
            let p = s(2);
            return v(p.prePostConditionChecklistSave(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("allPrePostConditions", e.prePostConditions)("isEditMode", e.isEditMode)("conditionMode", e.job != null && e.job.id ? "both" : "pre")("checkedPrePostConditions", e.job == null ? null : e.job.pre_post_conditions)
    }
}

function Wp(t, c) {
    if (t & 1 && u(0, "dxi-button", 79), t & 2) {
        let e = s(3);
        l("options", e.addRepairServiceOption)
    }
}

function Hp(t, c) {
    if (t & 1 && m(0, Wp, 1, 1, "dxi-button", 79), t & 2) {
        let e = s(2);
        _(e.isEditMode ? 0 : -1)
    }
}

function Qp(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-control-container", 44)(1, "dx-tag-box", 80), f("onCustomItemCreating", function(i) {
            C(e);
            let p = s(2);
            return v(p.createTag(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("ngClass", e.form.getRawValue().is_recovery ? "col-sm-3 col-md-3 col-lg-3" : "col-sm-6 col-md-6 col-lg-6")("tooltipText", "job_tags"), n(), l("acceptCustomValue", !0)("items", e.tags)("placeholder", e.formatMessage("tag_placeholder"))
    }
}

function zp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 45)(1, "div", 81), u(2, "dx-number-box", 82)(3, "dx-select-box", 83), a()()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("common_error_capacity_required"))("label", e.formatMessage("job_label_capacity")), n(3), l("items", e.CAPACITY_MEASURES)("searchEnabled", !1)
    }
}

function Yp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 46), u(1, "dx-text-area", 84), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("job_error_hardware_configuration_required"))("label", e.formatMessage("device_hardware_configuration")), n(), l("autoResizeEnabled", !0)("placeholder", e.formatMessage("device_hardware_configuration_placeholder"))
    }
}

function $p(t, c) {
    if (t & 1 && (r(0, "app-control-container", 47), u(1, "app-textarea", 85), a()), t & 2) {
        let e = s(2);
        l("label", e.formatMessage("job_service_assessment"))("tooltipText", "job_comment"), n(), l("formControl", e.form.controls.comment)("isEditMode", e.isEditMode)("placeholder", e.formatMessage("job_service_assessment_placeholder"))
    }
}

function Kp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 51), u(1, "app-employee-dropdown", 86), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("job_assignee"))("tooltipText", e.formatMessage("job_assigned_user_id"))("needTranslation", !1), n(), l("formControl", e.form.controls.assigned_user_id)("isActiveOnly", !e.jobId)("isEditMode", e.isEditMode)
    }
}

function Xp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 52), u(1, "dx-text-box", 87)(2, "app-error", 88), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("quotation_required"))("label", e.formatMessage("initial_quotation_label"))("tooltipText", "job_initial_quotation"), n(), l("inputAttr", Ye(6, Tp)), n(), l("displayError", e.form.get("initial_quotation").invalid && e.form.get("initial_quotation").touched && e.form.get("initial_quotation").errors.invalidNumberRange)("errorMsg", e.formatMessage("job_error_invalid_number_range"))
    }
}

function Zp(t, c) {
    if (t & 1 && (r(0, "app-control-container", 53), u(1, "dx-date-box", 89), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("common_error_messages_due_date"))("label", e.formatMessage("job_due_date")), n(), l("min", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("job_date_placeholder"))
    }
}

function em(t, c) {
    if (t & 1 && (r(0, "app-control-container", 54), u(1, "dx-text-box", 90), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("job_error_dealer_job_id_required"))("label", e.formatMessage("dealer_Job_id")), n(), l("placeholder", e.formatMessage("dealer_job_placeholder"))
    }
}

function tm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-attachments", 91), f("afterSaving", function(i) {
            C(e);
            let p = s(2);
            return v(p.afterFileUpload(i))
        }), a()
    }
    if (t & 2) {
        let e = s(2);
        l("attachableType", e.attachableType)("entity", e.job)("isEditMode", e.isEditMode)("isMultipleUploads", !0)
    }
}

function im(t, c) {
    if (t & 1 && (r(0, "app-control-container", 57), u(1, "app-textarea", 92), a()), t & 2) {
        let e = s(2);
        l("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions")), n(), l("isEditMode", e.isEditMode)
    }
}

function nm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-cancel-footer", 64), f("cancelClick", function() {
            C(e);
            let i = s(3);
            return v(i.onCancelEdit())
        }), a()
    }
    if (t & 2) {
        let e = s(3);
        l("isOnPopup", !0)("isSaving", e.isSaving)("isDisabled", e.isSaving)("isVisibleHr", !1)("saveText", e.job != null && e.job.id ? "common_update" : "common_create")("savingText", e.job != null && e.job.id ? "common_updating" : "common_creating")
    }
}

function om(t, c) {
    if (t & 1 && (r(0, "div", 58), E(1, nm, 1, 6, "app-save-cancel-footer", 63), a()), t & 2) {
        let e = s(2);
        n(), l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_WRITE)
    }
}

function am(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 13), f("ngSubmit", function() {
            C(e);
            let i = s();
            return v(i.saveJob())
        }), r(1, "div", 14)(2, "div", 15), m(3, Ip, 2, 2, "h3", 16), a(), m(4, Dp, 5, 3, "div", 15), a(), m(5, kp, 1, 1, "app-server-error", 17), u(6, "app-section-title", 18), r(7, "div", 14)(8, "app-control-container", 19)(9, "app-customer-dropdown", 20), f("itemClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddCustomer(i))
        }), a()(), m(10, Np, 2, 4, "app-control-container", 21), m(11, Ap, 2, 7, "app-control-container", 22), r(12, "app-control-container", 23), u(13, "dx-select-box", 24), a(), r(14, "app-control-container", 25), u(15, "dx-select-box", 26), a()(), u(16, "app-section-title", 27), r(17, "div", 14)(18, "app-control-container", 28), u(19, "app-select-box-with-images", 29), a(), r(20, "app-control-container", 30), u(21, "app-select-box-with-images", 31), a(), m(22, Jp, 2, 12, "app-control-container", 32), m(23, Lp, 3, 4, "app-control-container", 33), m(24, Bp, 2, 3, "app-control-container", 34), m(25, Rp, 2, 11, "app-control-container", 35), m(26, Up, 2, 4, "app-control-container", 36), m(27, Fp, 2, 4, "app-control-container", 37), m(28, qp, 2, 6, "app-control-container", 38), a(), m(29, Gp, 2, 4, "div", 39), u(30, "app-section-title", 40), r(31, "div", 14)(32, "app-control-container", 41)(33, "dx-tag-box", 42), E(34, Hp, 1, 1, "ng-template", 43), a()(), m(35, Qp, 2, 5, "app-control-container", 44), m(36, zp, 4, 4, "app-control-container", 45), m(37, Yp, 2, 4, "app-control-container", 46), m(38, $p, 2, 5, "app-control-container", 47), a(), u(39, "app-section-title", 48), r(40, "div", 14)(41, "app-control-container", 49), u(42, "app-priority-dropdown", 50), a(), m(43, Kp, 2, 7, "app-control-container", 51), m(44, Xp, 3, 7, "app-control-container", 52), m(45, Zp, 2, 5, "app-control-container", 53), m(46, em, 2, 3, "app-control-container", 54), u(47, "app-show-custom-fields", 55), a(), m(48, tm, 1, 4, "app-attachments", 56), m(49, im, 2, 3, "app-control-container", 57), m(50, om, 2, 1, "div", 58), a()
    }
    if (t & 2) {
        let e, o = s();
        l("formGroup", o.form), n(3), _(o.job != null && o.job.id ? -1 : 3), n(), _(o.isEmployee ? 4 : -1), n(), _(o.errorResponse ? 5 : -1), n(), l("title", "basic_information"), n(2), l("errorMsg", o.formatMessage("common_error_messages_customer_name_required"))("label", o.formatMessage("user_customer_name")), n(), l("customerId", o.form.getRawValue().id ? (e = o.form.getRawValue()) == null ? null : e.user_id : null)("formControl", o.form.controls.user_id)("isEditMode", o.isEditMode)("showCrateButton", !0), n(), _(o.isFieldVisible("job_form_source_id") ? 10 : -1), n(), _(o.isEmployee && o.isFieldVisible("job_form_referred_by_id") ? 11 : -1), n(), l("errorMsg", o.formatMessage("common_error_job_service_type_required"))("label", o.formatMessage("job_service_type")), n(), l("items", o.serviceTypes)("searchEnabled", !0), n(), l("errorMsg", o.formatMessage("common_error_job_type_required"))("label", o.formatMessage("job_type")), n(), l("items", o.jobTypes)("searchEnabled", !0), n(), l("title", "device_information"), n(2), l("errorMsg", o.formatMessage("device_type_required_warning"))("label", o.formatMessage("device_type_name")), n(), l("dataSource", o.allDeviceTypeList)("placeholder", "select_device_type")("imageCategory", "device-type")("isDisabled", !o.isEditMode)("isReadOnly", !o.isEditMode), n(), l("errorMsg", o.formatMessage("device_brand_required_warning"))("label", o.formatMessage("device_brand_name")), n(), l("dataSource", o.deviceBrandList)("isDisabled", !o.isEditMode)("isDxiButtonActive", o.isEditMode)("hasUserPermissions", o.PERMISSION_LIST.DEVICE_BRAND_LIST)("buttonOptions", o.addDeviceBrandOption)("buttonId", "job-basic-info-device-brand")("buttonName", "deviceBrand")("imageCategory", "device-brand")("isReadOnly", !o.isEditMode || !o.form.getRawValue().device_type_id)("placeholder", "device_brand_placeholder"), n(), _(o.isFieldVisible("job_form_device_model_id") ? 22 : -1), n(), _(o.isFieldVisible("job_form_serial_number") ? 23 : -1), n(), _(o.form.getRawValue().is_recovery ? 24 : -1), n(), _(o.isFieldVisible("job_form_accessories") ? 25 : -1), n(), _(o.isFieldVisible("job_form_storage_location_id") ? 26 : -1), n(), _(o.isFieldVisible("job_form_device_color_id") ? 27 : -1), n(), _(o.isFieldVisible("job_form_device_password") ? 28 : -1), n(), _(o.prePostConditions.length > 0 ? 29 : -1), n(), l("title", "service_information"), n(2), l("errorMsg", o.formatMessage("job_error_services_required"))("label", o.formatMessage("job_services")), n(), l("acceptCustomValue", !1)("items", o.deviceTypeRepairServicesList)("placeholder", o.formatMessage("job_services_placeholder"))("readOnly", !o.form.getRawValue().device_type_id)("showSelectionControls", !0), n(), l("ngxPermissionsOnly", o.PERMISSION_LIST.REPAIR_SERVICE_LIST), n(), _(o.isFieldVisible("job_form_tags") ? 35 : -1), n(), _(o.form.getRawValue().is_recovery ? 36 : -1), n(), _(o.isFieldVisible("job_form_hardware_configuration") ? 37 : -1), n(), _(o.isFieldVisible("job_form_comment") ? 38 : -1), n(), l("title", "additional_information"), n(2), l("errorMsg", o.formatMessage("job_error_priority_required"))("label", o.formatMessage("priority"))("tooltipText", "job_priority_id"), n(), l("formControl", o.form.controls.priority_id)("isEditMode", o.isEditMode)("placeholder", o.formatMessage("priority_placeholder")), n(), _(o.isEmployee ? 43 : -1), n(), _(o.isFieldVisible("job_form_initial_quotation") ? 44 : -1), n(), _(o.isFieldVisible("job_form_estimated_delivery") ? 45 : -1), n(), _(o.isFieldVisible("job_form_vendor_job_id") ? 46 : -1), n(), l("formType", o.FORM_TYPE_LIST.JOB)("form", o.form)("hasColumn", 3), n(), _(o.job ? 48 : -1), n(), _(o.isFieldVisible("job_form_term_and_condition") ? 49 : -1), n(), _(o.isEmployee && o.isMobileDevice && o.isEditMode ? 50 : -1)
    }
}

function rm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-device-model-popup", 93), f("deviceModelCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleDeviceModelPopup = !1)
        })("deviceModelSaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddDeviceModel(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("deviceModel", e.deviceModel)("isAddingFromJob", !0)("isCreate", !0)("isVisiblePopup", e.isVisibleDeviceModelPopup)
    }
}

function sm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-device-brand", 94), f("deviceBrandCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleDeviceBrandPopup = !1)
        })("deviceBrandSaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddDeviceBrand(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("deviceBrand", e.deviceBrand)("isCreate", !0)("isVisiblePopup", e.isVisibleDeviceBrandPopup)
    }
}

function lm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-accessory", 95), f("accessoryCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleAccessoryPopUp = !1)
        })("accessorySaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddAccessory(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("deviceAccessory", e.accessory)("isCreate", !0)("isVisiblePopup", e.isVisibleAccessoryPopUp)
    }
}

function cm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-repair-service", 96), f("repairServiceCancelClick", function() {
            C(e);
            let i = s();
            return v(i.isVisibleRepairServicePopup = !1)
        })("repairServiceSaveClick", function(i) {
            C(e);
            let p = s();
            return v(p.onAddRepairService(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isCreate", !0)("isVisiblePopup", e.isVisibleRepairServicePopup)("repairService", e.repairService)
    }
}

function dm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-send-notification", 97), f("sendNotificationClose", function() {
            C(e);
            let i = s();
            return v(i.redirectToJobSheet())
        })("sendNotificationSave", function() {
            C(e);
            let i = s();
            return v(i.redirectToJobSheet())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entityObj", e.job)("entity", e.ENTITIES.JOB_SHEET)("isVisiblePopup", e.isVisibleNotificationPopup)("isVisibleSendButton", !1)("job", e.job)
    }
}

function pm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "app-screen-pattern-lock", 100), f("onPatternLockSaveClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.onPatternLockSaveClick(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("isEditMode", e.isEditMode)("lockPattern", e.lockPattern())
    }
}

function mm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-popup", 98), f("onHiding", function() {
            C(e);
            let i = s();
            return v(i.isPatternLockPopupOpen.set(!1))
        }), E(1, pm, 2, 2, "div", 99), a()
    }
    if (t & 2) {
        let e = s();
        l("maxHeight", e.isMobileDevice ? 470 : 460)("width", "95vw")("maxWidth", 450)("title", e.formatMessage("pattern_lock"))("visible", e.isPatternLockPopupOpen()), n(), l("dxTemplateOf", "content")
    }
}

function _m(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-job-success-modal", 101), f("modalClose", function() {
            C(e);
            let i = s();
            return v(i.onJobSuccessModalClose())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleJobSuccessModal)("job", e.job)
    }
}

function um(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-qrcode-scanner", 102), f("scannerToSave", function(i) {
            C(e);
            let p = s();
            return v(p.addBarcodeNumberForSerialNumber(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("type", "get_barcode_number")("isVisiblePopup", e.isVisibleBarcodeScannerPopUp())
    }
}

function Cm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-job-field-config-popup", 103), f("fieldConfigClose", function() {
            C(e);
            let i = s();
            return v(i.isFieldConfigPopupVisible = !1)
        })("fieldConfigSave", function() {
            C(e);
            let i = s();
            return v(i.isFieldConfigPopupVisible = !1)
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isFieldConfigPopupVisible)("isRecovery", e.isRecovery)
    }
}
var Io = (() => {
    class t {
        constructor(e, o, i, p, y, je) {
            this.jobService = e, this.tableSequenceNumberService = o, this.termAndConditionService = i, this.contactUsService = p, this.applicationRef = y, this.loaderService = je, this.formatMessage = g, this.ENTITIES = I, this.formService = b(me), this.uuidService = b(xr), this.configService = b(lt), this.router = b(G), this.dataService = b(qe), this.activatedRouter = b(R), this.generalSettingDataService = b(te), this.userSessionService = b(L), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.tenantService = b(ve), this.today = tl.default.tz(this.tenantService.timezone()).toDate(), this.isEmployee = this.userSessionService.isEmployee(), this.isFieldConfigPopupVisible = !1, this.isPatternLockPopupOpen = Y(!1), this.lockPattern = Y(null), this.isVisibleBarcodeScannerPopUp = Y(!1), this.jobId = null, this.job = null, this.CAPACITY_MEASURES = Object.values(Wo), this.isVisibleNotificationPopup = !1, this.isVisibleJobSuccessModal = !1, this.isAdvancePaymentEnabled = !1, this.attachableType = I.JOB.name, this.routeUserId = null, this.allDeviceTypeList = [], this.allDeviceBrandList = [], this.deviceBrandList = [], this.allRepairServicesList = [], this.deviceModelList = [], this.allDeviceModelList = [], this.serviceTypes = [], this.jobTypes = [], this.tags = [], this.deviceTypeRepairServicesList = [], this.jobPriorityList = [], this.storageLocationList = [], this.deviceColorList = [], this.accessoriesList = [], this.allPrePostConditions = [], this.prePostConditions = [], this.deviceTypeAccessoriesList = [], this.isEditMode = !1, this.isSaving = !1, this.errorResponse = null, this.isRecovery = !1, this.isVisibleAccessoryPopUp = !1, this.isVisibleDeviceBrandPopup = !1, this.isVisibleRepairServicePopup = !1, this.isVisibleDeviceModelPopup = !1, this.isModelWiseServicePricing = !1, this.jobSources = [], this.jobFormFieldConfig = {}, this.FORM_TYPE_LIST = Qa, this.PERMISSION_LIST = M, this.addDeviceModelOption = {
                icon: "add",
                type: "default",
                hint: "Add New Device Model",
                onClick: () => {
                    this.deviceModel = new Ui({
                        device_brand_id: this.form.getRawValue().device_brand_id,
                        device_type_id: this.form.getRawValue().device_type_id
                    }), this.isVisibleDeviceModelPopup = !0
                }
            }, this.addDeviceBrandOption = {
                icon: "add",
                type: "default",
                hint: "Add New Device Brand",
                onClick: () => {
                    this.deviceBrand = new bn({
                        device_type_id: this.form.getRawValue().device_type_id
                    }), this.isVisibleDeviceBrandPopup = !0
                }
            }, this.addAccessoryOption = {
                icon: "add",
                type: "default",
                hint: "Add New Accessory",
                onClick: () => {
                    this.accessory = new Co({
                        device_type_id: this.form.getRawValue().device_type_id
                    }), this.isVisibleAccessoryPopUp = !0
                }
            }, this.addRepairServiceOption = {
                icon: "add",
                type: "default",
                hint: "Add New Repair Service",
                onClick: () => {
                    this.repairService = new Yr({
                        device_type_id: this.form.getRawValue().device_type_id
                    }), this.isVisibleRepairServicePopup = !0
                }
            }, this.addSerialBarcodeScan = {
                icon: be.BARCODE_READ.light,
                type: "default",
                hint: g("scan_serial/_IMEI_number"),
                onClick: () => {
                    this.scanJob()
                }
            }
        }
        scanJob() {
            this.isVisibleBarcodeScannerPopUp() ? (this.isVisibleBarcodeScannerPopUp.set(!1), setTimeout(() => {
                this.isVisibleBarcodeScannerPopUp.set(!0)
            }, 0)) : this.isVisibleBarcodeScannerPopUp.set(!0)
        }
        isFieldVisible(e) {
            return this.jobFormFieldConfig[e] !== !1
        }
        ngOnInit() {
            this.jobFormFieldConfig = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.JOB_FORM_FIELD_CONFIG) || {}, this.isAdvancePaymentEnabled = this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.ENABLE_ADVANCE_PAYMENT_ON_JOB_CREATION), this.isModelWiseServicePricing = this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING), this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.jobId = null, this.jobId = +e.job_id, this.activatedRouter.parent.snapshot.queryParamMap.has("is_recovery") && (this.isRecovery = this.activatedRouter.parent.snapshot.queryParamMap.get("is_recovery").toLocaleLowerCase() === "true"), this.activatedRouter.parent.snapshot.queryParamMap.has("user_id") && (this.routeUserId = +this.activatedRouter.parent.snapshot.queryParamMap.get("user_id")), this.initialize()
                },
                error: e => {}
            })
        }
        setForm() {
            this.jobId ? (this.loaderService.show(), this.jobService.getDetailById(this.jobId, !0).subscribe({
                next: e => {
                    this.job = e, this.form = Ee.getForm(this.job), this.setReadOnlyMode(), this.job.device_type_id && this.updateDeviceTypeChanges(this.job.device_type_id), this.job.device_brand_id && this.onChangeDeviceBrand(), this.job.device_model_id && this.updateDeviceModelChanges(this.job.device_model_id), this.subscribeToValueChangesOnDeviceId(), this.subscribeToValueChangesOnDeviceBrand(), this.subscribeToValueChangesOnDeviceModel(), this.lockPattern.set(this.form.value.device_password ? ? "")
                },
                error: e => {
                    this.toastNotificationService.error("notification_job_details_fetch_error"), console.error("error fetching job detail by id ", e)
                }
            }).add(() => {
                this.loaderService.hide(), this.activatedRouter.queryParams.subscribe({
                    next: e => {
                        e.isClonedJob && this.onEditMode()
                    },
                    error: e => {
                        console.error("error rendering loader")
                    }
                })
            })) : this.createNewJobForm()
        }
        subscribeToValueChangesOnDeviceBrand() {
            this.form.controls.device_brand_id.valueChanges.subscribe(() => {
                this.form.controls.device_brand_id.value !== this.form.value.device_brand_id && this.onChangeDeviceBrand()
            })
        }
        subscribeToValueChangesOnDeviceId() {
            this.form.controls.device_type_id.valueChanges.subscribe(e => {
                this.form.controls.device_type_id.value !== this.form.value.device_type_id && this.onChangeDeviceType(e)
            })
        }
        subscribeToValueChangesOnDeviceModel() {
            let e = this.form.controls.device_model_id ? .value;
            this.updateDeviceModelChanges(e)
        }
        onChangeDeviceBrand() {
            let e = this.form.controls.device_brand_id.value,
                o = this.form.controls.device_type_id.value;
            this.deviceModelList = this.allDeviceModelList.filter(i => i.device_brand_id === e && i.device_type_id === o)
        }
        onChangeDeviceType(e) {
            this.form.patchValue({
                device_brand_id: null,
                accessories: [],
                repairables: [],
                device_model_id: null
            }), this.updateDeviceTypeChanges(e)
        }
        updateDeviceTypeChanges(e) {
            this.deviceBrandList = this.allDeviceBrandList.filter(o => o.device_type_id === e), this.deviceTypeAccessoriesList = this.accessoriesList.filter(o => o.device_type_id === e), this.isModelWiseServicePricing || (this.deviceTypeRepairServicesList = this.allRepairServicesList.filter(o => o.device_type_id === e)), this.prePostConditions = this.allPrePostConditions ? this.allPrePostConditions.filter(o => o.device_type_id === e) : []
        }
        updateDeviceModelChanges(e) {
            this.isModelWiseServicePricing && (this.form.controls.device_model_id.valueChanges.subscribe(o => {
                this.form.controls.device_model_id.value !== this.form.value.device_model_id && this.updateDeviceModelChanges(o)
            }), this.deviceTypeRepairServicesList = this.allRepairServicesList.filter(o => e != null && o.device_model_id === e))
        }
        initialize() {
            this.loaderService.show(), this.dataService.getLookups().subscribe({
                next: e => {
                    this.allDeviceBrandList = e.device_brands, this.deviceBrandList = this.allDeviceBrandList, this.allPrePostConditions = e.pre_post_conditions, this.jobPriorityList = e.job_priorities, this.storageLocationList = e.storage_locations, this.deviceColorList = e.device_colors, this.accessoriesList = e.accessories, this.deviceModelList = e.device_models, this.allDeviceModelList = e.device_models, this.jobSources = e.job_sources, this.allRepairServicesList = e.repair_services, this.allDeviceTypeList = e.device_types, this.tags = e.tags.filter(o => o.type === this.ENTITIES.JOB.name).map(o => o.tag_name), this.serviceTypes = e.service_types, this.jobTypes = e.job_types, this.isModelWiseServicePricing || (this.deviceTypeRepairServicesList = this.allRepairServicesList), this.setForm()
                },
                error: e => {
                    console.log(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        saveJob() {
            if (this.isSaving) return;
            if (this.errorResponse = null, !this.form.valid) {
                this.formService.validateFormFields(this.form);
                return
            }
            this.isSaving = !0, this.loaderService.show();
            let e = this.form.getRawValue();
            (e.id ? this.jobService.update(e) : this.jobService.create(e)).subscribe({
                next: i => {
                    this.job = i, this.job = new Ee(i), this.applicationRef.tick(), this.attachmentInstance ? .syncNotes(this.job)
                },
                error: i => {
                    this.errorResponse = i
                }
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })
        }
        afterFileUpload(e) {
            e || this.handleSaveSuccess()
        }
        handleSaveSuccess() {
            this.isSaving = !1, this.loaderService.hide(), this.activatedRouter.snapshot.parent.paramMap.has("job_id") ? (this.toastNotificationService.success("notification_job_update_success"), this.setReadOnlyMode()) : (this.toastNotificationService.success("notification_job_create_success"), this.isAdvancePaymentEnabled ? this.isVisibleJobSuccessModal = !0 : this.isVisibleNotificationPopup = !0)
        }
        redirectToJobSheet() {
            this.isVisibleNotificationPopup = !1, this.router.navigate([`/jobs/${this.job.id}/jobSheets`])
        }
        onJobSuccessModalClose() {
            this.isVisibleJobSuccessModal = !1
        }
        onCancelEdit() {
            this.router.navigate(["/jobs"])
        }
        setReadOnlyMode() {
            this.isSaving = !1, this.isEditMode = !1, this.form.disable({
                emitEvent: !1
            })
        }
        onEditMode() {
            this.isEditMode = !0, this.form.enable({
                emitEvent: !1
            })
        }
        onAddDeviceModel(e) {
            this.isVisibleDeviceModelPopup = !1, this.deviceModelList.push(e), this.form.patchValue({
                device_model_id: e.id
            })
        }
        onAddDeviceBrand(e) {
            this.isVisibleDeviceBrandPopup = !1, this.deviceBrandList.push(e), this.form.patchValue({
                device_brand_id: e.id
            }), this.contactUs ? .custom_model_name && setTimeout(() => {
                this.deviceModel = new Ui({
                    name: this.contactUs.custom_model_name,
                    device_brand_id: e.id,
                    device_type_id: this.form.getRawValue().device_type_id
                }), this.isVisibleDeviceModelPopup = !0
            }, 300)
        }
        handleCustomBrandModel() {
            this.contactUs && (this.contactUs.custom_brand_name && !this.contactUs.device_brand_id ? setTimeout(() => {
                this.deviceBrand = new bn({
                    name: this.contactUs.custom_brand_name,
                    device_type_id: this.form.getRawValue().device_type_id
                }), this.isVisibleDeviceBrandPopup = !0
            }, 500) : this.contactUs.custom_model_name && !this.contactUs.device_model_id && setTimeout(() => {
                this.deviceModel = new Ui({
                    name: this.contactUs.custom_model_name,
                    device_brand_id: this.form.getRawValue().device_brand_id,
                    device_type_id: this.form.getRawValue().device_type_id
                }), this.isVisibleDeviceModelPopup = !0
            }, 500))
        }
        onAddAccessory(e) {
            this.deviceTypeAccessoriesList = [...this.deviceTypeAccessoriesList, e];
            let o = this.form.get("accessories").value || [];
            o.push(e.id), this.form.patchValue({
                accessories: o
            })
        }
        onAddRepairService(e) {
            this.isVisibleRepairServicePopup = !1, this.deviceTypeRepairServicesList.push(e);
            let o = this.form.get("repairables").value;
            o.unshift(e.id), this.form.patchValue({
                repairables: o
            })
        }
        onAddCustomer(e) {
            let o = {};
            e ? .referred_by_id && (o.referred_by_id = e.referred_by_id), e ? .source_id && (o.source_id = e.source_id), Object.keys(o).length && this.form.patchValue(o)
        }
        onAddReferredBy(e) {
            this.form.patchValue({
                referred_by_id: e ? .id
            })
        }
        createTag(e) {
            e.customItem = e.text, this.tags.unshift(e.text)
        }
        prePostConditionChecklistSave(e) {
            this.form.patchValue({
                pre_post_conditions: e
            })
        }
        onPatternLockSaveClick(e) {
            this.form.patchValue({
                device_password: e
            }), this.isPatternLockPopupOpen.set(!1)
        }
        onPatternLockClick() {
            this.isPatternLockPopupOpen.set(!0), this.lockPattern.set(this.form.getRawValue().device_password ? ? "")
        }
        createNewJobForm() {
            this.loaderService.show();
            let e = this.activatedRouter.snapshot ? .queryParams ? .state,
                o = this.activatedRouter.parent.snapshot.queryParamMap.has("is_lead");
            e && !o && (this.contactUs = JSON.parse(e)), Ne([this.tableSequenceNumberService.getListByQuery({
                name: Ii.JOB_SHEET.name
            }), this.termAndConditionService.getByTypeId({
                type_id: at.JOB_SHEET
            }), this.contactUs ? this.contactUsService.createCustomer(this.contactUs) : zt(null), this.contactUs && !this.contactUs.attachments ? this.contactUsService.getById(this.contactUs.id) : zt(null)]).subscribe({
                next: ([i, p, y, je]) => {
                    je && (this.contactUs = je), y && (this.routeUserId = y.id), this.job = ni.getDefaultJobObj(this.generalSettingDataService.getGeneralSettingBySettingType(Ce.JOB_SETTING), this.routeUserId, this.contactUs, i[0].current_value, this.jobSources.length ? this.jobSources[0].id : null, this.isRecovery, this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.AUTO_ROUND_OFF)), this.form = Ee.getForm(this.job);
                    let Pt = this.generalSettingDataService.getGeneralSettingByKey("default_job_due_day");
                    if (Pt) {
                        let Rt = parseInt(Pt, 10);
                        if (Rt > 0) {
                            let pi = ni.addDays(new Date, Rt, this.tenantService.timezone());
                            this.form.get("estimated_delivery") ? .setValue(pi)
                        }
                    }
                    this.form.patchValue({
                        capacity_measure: Wo.GB,
                        term_and_condition: p ? .text ? ? ""
                    }), this.form.value.device_type_id && this.updateDeviceTypeChanges(this.form.value.device_type_id), this.subscribeToValueChangesOnDeviceId(), this.subscribeToValueChangesOnDeviceBrand(), this.subscribeToValueChangesOnDeviceModel(), this.onEditMode(), this.handleCustomBrandModel()
                },
                error: i => {
                    this.toastNotificationService.error("notification_error"), console.error(i)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        openFieldConfigPopup() {
            this.isFieldConfigPopupVisible = !0
        }
        addBarcodeNumberForSerialNumber(e) {
            this.form.controls.serial_number.setValue(e)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T(tn), T(Ct), T(St), T($t), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-basic-info"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(gt, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.attachmentInstance = p.first)
                    }
                },
                standalone: !1,
                decls: 13,
                vars: 12,
                consts: [
                    [1, "container-fluid", "p-0"],
                    [3, "message"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "deviceModel", "isAddingFromJob", "isCreate", "isVisiblePopup"],
                    [3, "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "deviceAccessory", "isCreate", "isVisiblePopup"],
                    [3, "isCreate", "isVisiblePopup", "repairService"],
                    [3, "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton", "job"],
                    ["id", "pattern-lock-popup", 3, "maxHeight", "width", "maxWidth", "title", "visible"],
                    [3, "isVisiblePopup", "job"],
                    [3, "type", "isVisiblePopup"],
                    [3, "isVisiblePopup", "isRecovery"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "float-start"],
                    [3, "errorResponse"],
                    ["id", "job-basic-info-title", 1, "mt-3", 3, "title"],
                    ["name", "user_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "showCrateButton"],
                    ["name", "source_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "referred_by_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "service_type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "service_type_id", "id", "job-basic-info-service-type", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled"],
                    ["name", "type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "type_id", "id", "job-basic-info-job-type", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled"],
                    ["id", "job-basic-device-info-title", 1, "mt-3", 3, "title"],
                    ["name", "device_type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_type_id", 3, "dataSource", "placeholder", "imageCategory", "isDisabled", "isReadOnly"],
                    ["name", "device_brand_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_brand_id", 3, "dataSource", "isDisabled", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "imageCategory", "isReadOnly", "placeholder"],
                    ["name", "device_model_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "serial_number", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "serial_number_2", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "accessories", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    ["name", "storage_location_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "device_color_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "device_password", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "label"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["id", "job-basic-info-repair-section-title", 1, "mt-3", 3, "title"],
                    ["name", "repairables", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "repairables", "id", "job-basic-info-repairables", "valueExpr", "id", 3, "acceptCustomValue", "items", "placeholder", "readOnly", "showSelectionControls"],
                    [3, "ngxPermissionsOnly"],
                    ["label", "Tags", "name", "tags", 3, "ngClass", "tooltipText"],
                    ["name", "size", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "hardware_configuration", 1, "col-sm-12", "col-md-12", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label", "tooltipText"],
                    ["id", "job-basic-info-section-title", 1, "mt-3", 3, "title"],
                    ["name", "priority_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    [3, "formControl", "isEditMode", "placeholder"],
                    ["name", "assigned_user_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label", "tooltipText", "needTranslation"],
                    ["name", "initial_quotation", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    ["name", "estimated_delivery", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["name", "vendor_job_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    [1, "row", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    ["id", "job-basic-info-configure-fields", "buttonType", "default", "class", "me-2", "icon", "fa-thin fa-cog", "text", "field_config_button", "title", "field_config_button", 3, "isVisibleIcon", "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "isOnPopup", "isSaving", "isDisabled", "isVisibleHr", "saveText", "savingText"],
                    ["id", "job-basic-info-configure-fields", "buttonType", "default", "icon", "fa-thin fa-cog", "text", "field_config_button", "title", "field_config_button", 1, "me-2", 3, "onClickEvent", "isVisibleIcon"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "isOnPopup", "isSaving", "isDisabled", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "job-basic-info-cancel", "saveBtnId", "job-basic-info-save", 3, "cancelClick", "isOnPopup", "isSaving", "isDisabled", "isVisibleHr", "saveText", "savingText"],
                    ["id", "job-basic-info-back"],
                    ["buttonType", "default", "class", "ms-2", "text", "common_edit", "title", "common_edit", 3, "click", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "ms-2", 3, "click"],
                    ["displayExpr", "name", "formControlName", "source_id", "id", "job-basic-info-job-sources", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled"],
                    [3, "itemClick", "customerId", "formControl", "isEditMode", "isVisibleAddAction", "showCrateButton"],
                    ["formControlName", "device_model_id", 3, "dataSource", "isDxiButtonActive", "isDisabled", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "imageCategory", "isReadOnly", "placeholder"],
                    ["formControlName", "serial_number", "id", "job-basic-info-serial-number", 3, "placeholder"],
                    ["location", "after", "name", "serialNumberBarcodeScan", 3, "options"],
                    ["formControlName", "serial_number_2", "id", "job-basic-info-serial-number_2", 3, "placeholder"],
                    ["formControlName", "accessories", 3, "products", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "isDisabled", "isReadOnly", "placeholder", "imageCategory"],
                    ["displayExpr", "name", "formControlName", "storage_location_id", "id", "job-basic-info-storage_location", "valueExpr", "id", 3, "items", "placeholder"],
                    ["id", "job-basic-info-device-color", 3, "formControl", "isEditMode"],
                    ["id", "job-basic-info-device-password", 3, "onPatternLockClick", "disableAutoFill", "formControl", "isEditMode", "placeholder", "showPatternLockButton"],
                    [3, "prePostConditionChecklistSave", "allPrePostConditions", "isEditMode", "conditionMode", "checkedPrePostConditions"],
                    ["id", "job-basic-info-RepairService-btn", "location", "after", "name", "repairables", 3, "options"],
                    ["formControlName", "tags", "id", "job-basic-info-internal-details", 3, "onCustomItemCreating", "acceptCustomValue", "items", "placeholder"],
                    [1, "input-group"],
                    ["aria-label", "Size of Device", "formControlName", "size", "placeholder", "Ex: 512", 1, "w-75"],
                    ["formControlName", "capacity_measure", "searchMode", "startswith", 1, "form-control", "w-25", 3, "items", "searchEnabled"],
                    ["formControlName", "hardware_configuration", "id", "job-basic-info-hardware-configuration", "maxHeight", "100", "minHeight", "60", 1, "pt-1", 3, "autoResizeEnabled", "placeholder"],
                    ["id", "job-basic-info-repair-assessment", 3, "formControl", "isEditMode", "placeholder"],
                    ["placeholder", "job_assignee_placeholder", 3, "formControl", "isActiveOnly", "isEditMode"],
                    ["formControlName", "initial_quotation", "id", "job-basic-info-quotation", "placeholder", "2000-3000 etc", 3, "inputAttr"],
                    [3, "displayError", "errorMsg"],
                    ["formControlName", "estimated_delivery", "id", "job-basic-info-estimated_delivery", "type", "date", 3, "min", "pickerType", "placeholder"],
                    ["formControlName", "vendor_job_id", "id", "job-basic-info-vendor-job-id", 3, "placeholder"],
                    ["accept", "image/*,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "afterSaving", "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    ["height", "auto", "formControlName", "term_and_condition", 3, "isEditMode"],
                    [3, "deviceModelCancelClick", "deviceModelSaveClick", "deviceModel", "isAddingFromJob", "isCreate", "isVisiblePopup"],
                    [3, "deviceBrandCancelClick", "deviceBrandSaveClick", "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "accessoryCancelClick", "accessorySaveClick", "deviceAccessory", "isCreate", "isVisiblePopup"],
                    [3, "repairServiceCancelClick", "repairServiceSaveClick", "isCreate", "isVisiblePopup", "repairService"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton", "job"],
                    ["id", "pattern-lock-popup", 3, "onHiding", "maxHeight", "width", "maxWidth", "title", "visible"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "onPatternLockSaveClick", "isEditMode", "lockPattern"],
                    [3, "modalClose", "isVisiblePopup", "job"],
                    [3, "scannerToSave", "type", "isVisiblePopup"],
                    [3, "fieldConfigClose", "fieldConfigSave", "isVisiblePopup", "isRecovery"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0), m(1, Mp, 1, 1, "app-alert-panel", 1), m(2, Pp, 1, 2, "app-skeleton-loader", 2), m(3, am, 51, 79, "form", 3), a(), m(4, rm, 1, 4, "app-device-model-popup", 4), m(5, sm, 1, 3, "app-device-brand", 5), m(6, lm, 1, 3, "app-accessory", 6), m(7, cm, 1, 3, "app-repair-service", 7), m(8, dm, 1, 5, "app-send-notification", 8), m(9, mm, 2, 6, "dx-popup", 9), m(10, _m, 1, 2, "app-job-success-modal", 10), m(11, um, 1, 2, "app-qrcode-scanner", 11), m(12, Cm, 1, 2, "app-job-field-config-popup", 12)), o & 2 && (n(), _(i.contactUs && (i.contactUs != null && i.contactUs.id) && (i.contactUs == null ? null : i.contactUs.job_id) !== null ? 1 : -1), n(), _(!i.form && i.jobId ? 2 : -1), n(), _(i.form ? 3 : -1), n(), _(i.isVisibleDeviceModelPopup ? 4 : -1), n(), _(i.isVisibleDeviceBrandPopup ? 5 : -1), n(), _(i.isVisibleAccessoryPopUp ? 6 : -1), n(), _(i.isVisibleRepairServicePopup ? 7 : -1), n(), _(i.isVisibleNotificationPopup ? 8 : -1), n(), _(i.isPatternLockPopupOpen() ? 9 : -1), n(), _(i.isVisibleJobSuccessModal ? 10 : -1), n(), _(i.isVisibleBarcodeScannerPopUp() ? 11 : -1), n(), _(i.isFieldConfigPopupVisible ? 12 : -1))
                },
                dependencies: [Q, ut, Lr, ai, ee, gt, K, Re, Zn, io, no, Gi, $r, Fi, Tr, tt, vo, Yi, fo, ue, ge, $i, en, _e, qi, eo, ho, W, Qn, Jt, Ji, H, xe, Bi, jt, dt, pe, q, re, st, le, se, Zt, sn, Ks, Xs],
                encapsulation: 2
            })
        }
    }
    return t
})();
var fm = ["postConditionsFormRef"];

function hm(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 5), t & 2 && l("rows", 4)("columns", 2)
}

function bm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 15)(1, "div", 22)(2, "dx-accordion", 23), f("onItemClick", function(i) {
            C(e);
            let p = s(3);
            return v(p.onPostConditionsAccordionClick(i))
        }), r(3, "dxi-item", 24)(4, "div", 25)(5, "app-pre-post-condition-check-list-pop-up", 26, 0), f("prePostConditionChecklistSave", function(i) {
            C(e);
            let p = s(3);
            return v(p.onPostConditionsSave(i))
        }), a()()()()()()
    }
    if (t & 2) {
        let e = s(3);
        n(2), l("collapsible", !0)("animationDuration", 300)("multiple", !1)("selectedIndex", -1), n(), l("title", e.formatMessage("add_post_conditions")), n(2), l("allPrePostConditions", e.prePostConditions)("isEditMode", !0)("conditionMode", "post")("inlineMode", !0)("checkedPrePostConditions", e.job == null ? null : e.job.pre_post_conditions)
    }
}

function gm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 7), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.updateStatus())
        }), r(1, "dx-scroll-view", 8), u(2, "app-job-current-info", 9), r(3, "div", 10)(4, "app-control-container", 11), u(5, "app-status-dropdown", 12), a(), r(6, "app-control-container", 13), u(7, "app-employee-dropdown", 14), a(), m(8, bm, 7, 10, "div", 15), r(9, "app-control-container", 16)(10, "app-quick-reply-dropdown", 17), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.quickReplyValue(i))
        }), a(), u(11, "app-textarea", 18), a()(), u(12, "app-user-notification-channel", 19), a(), u(13, "app-error", 20), r(14, "app-save-cancel-footer", 21), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.onCancel())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(2), l("job", e.job), n(2), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status")), n(2), l("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("job_assignee_name"))("tooltipText", "job_assigned_user_id"), n(), l("isMobileDeviceAndRequiredHere", !1)("showClearButton", !1), n(), _(e.showPostConditionsSection && e.hasPostConditionItemsInLookup ? 8 : -1), n(), l("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("labels_comment")), n(2), l("quickReply", e.quickReply), n(), l("form", e.form), n(), l("displayError", e.statusErrorMessage !== "")("errorMsg", e.statusErrorMessage), n(), l("gaEvent", "job_status_update_event")("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function xm(t, c) {
    if (t & 1 && (r(0, "div", 4), m(1, hm, 1, 2, "app-skeleton-loader", 5), m(2, gm, 15, 19, "form", 6), a()), t & 2) {
        let e = s();
        n(), _(e.form ? -1 : 1), n(), _(e.form ? 2 : -1)
    }
}

function Sm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-confirmation-popup", 27), f("confirmActionCallback", function() {
            C(e);
            let i = s();
            return v(i.continueSaving())
        })("rejectActionCallback", function() {
            C(e);
            let i = s();
            return v(i.cancelSaving())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("confirmationMessage", e.formatMessage("job_status_update_confirmation"))
    }
}
var il = (() => {
    class t {
        constructor(e, o, i, p) {
            this.fb = e, this.jobService = o, this.jobStatusService = i, this.loaderService = p, this.formatMessage = g, this.isVisiblePopup = !1, this.jobStatusSave = new J, this.jobStatusClose = new J, this.formService = b(me), this.whatsappService = b(Ke), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.dataService = b(qe), this.hapticService = b(sr), this.statusErrorMessage = "", this.isSaving = !1, this.isVisibleUpdateServiceStatusPopup = !1, this.closedStatusIds = Y([]), this.prePostConditions = [], this.showPostConditionsSection = !1, this.addPostConditions = !1, this.postConditionsLoaded = !1, this.hasPostConditionItemsInLookup = !1
        }
        ngOnInit() {
            this.initialize()
        }
        initialize() {
            this.form = this.fb.group({
                status_id: new k(this.job.status_id),
                assigned_user_id: new k(this.job.assigned_user_id),
                comment: new k(null),
                is_send_mail: new k(!1),
                is_send_app: new k(!1),
                is_send_sms: new k(!1),
                is_send_whatsapp: new k(!1)
            }), this.loadJobDetailsAndStatuses(), this.form.controls.status_id.valueChanges.subscribe(e => {
                this.onStatusChange(e)
            })
        }
        loadJobDetailsAndStatuses() {
            this.jobService.getDetailById(this.job.id, !0).subscribe({
                next: e => {
                    this.job = e, this.loadStatusList()
                },
                error: () => {
                    this.loadStatusList()
                }
            })
        }
        loadStatusList() {
            this.jobStatusService.getAll().subscribe({
                next: e => {
                    this.closedStatusIds.set(e.filter(o => o.stage === "Closed").map(o => o.id))
                },
                error: () => {
                    this.closedStatusIds.set([])
                }
            })
        }
        onStatusChange(e) {
            let o = this.closedStatusIds().includes(e),
                i = e !== this.job ? .status_id,
                p = this.job ? .pre_post_conditions || [],
                y = Array.isArray(p) && p.length > 0 && p[0] ? .pre_conditions && Array.isArray(p[0].pre_conditions) && p[0].pre_conditions.length > 0;
            this.showPostConditionsSection = o && i && y, this.showPostConditionsSection || (this.addPostConditions = !1), this.showPostConditionsSection && !this.postConditionsLoaded && this.loadPostConditionsData()
        }
        loadPostConditionsData() {
            this.dataService.getLookups().subscribe({
                next: e => {
                    let o = e.pre_post_conditions || [];
                    this.prePostConditions = o.filter(i => Number(i.device_type_id) === Number(this.job.device_type_id)), this.hasPostConditionItemsInLookup = this.prePostConditions.some(i => i.condition_type === ui.POST_CONDITION), this.postConditionsLoaded = !0
                },
                error: () => {
                    this.prePostConditions = [], this.hasPostConditionItemsInLookup = !1
                }
            })
        }
        onCancel() {
            this.form.reset(), this.isVisiblePopup = !1, this.jobStatusClose.emit()
        }
        updateStatus() {
            if (this.form.value.status_id === this.job.status_id) return this.statusErrorMessage = "Current job-status is same as new job-status", !1;
            this.form.valid ? (this.loaderService.show(), this.isSaving = !0, this.closedStatusIds().includes(this.form.value.status_id) ? (this.isVisibleUpdateServiceStatusPopup = !0, this.loaderService.hide()) : this.saveWithPostConditions()) : this.formService.validateFormFields(this.form)
        }
        quickReplyValue(e) {
            this.quickReply = e.comment ? ? e.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        continueSaving() {
            this.isVisibleUpdateServiceStatusPopup = !1, this.loaderService.show(), this.saveWithPostConditions()
        }
        cancelSaving() {
            this.isVisibleUpdateServiceStatusPopup = !1, this.isSaving = !1, this.loaderService.hide()
        }
        saveWithPostConditions() {
            if (this.showPostConditionsSection && this.addPostConditions && this.postConditionsFormRef) {
                let e = this.postConditionsFormRef.getSelectedConditionsData(),
                    o = Ge(Te({}, this.job), {
                        pre_post_conditions: e
                    });
                this.jobService.update(o).subscribe({
                    next: () => {
                        this.save()
                    },
                    error: () => {
                        this.toastNotificationService.error("notification_error"), this.loaderService.hide(), this.isSaving = !1
                    }
                })
            } else this.save()
        }
        onPostConditionsSave(e) {}
        onPostConditionsAccordionClick(e) {
            setTimeout(() => {
                let o = e.component.option("selectedItems");
                this.addPostConditions = o && o.length > 0
            }, 50)
        }
        save() {
            this.jobService.updateStatus(this.job.id, this.form.value).subscribe({
                next: () => {
                    this.hapticService.notifySuccess(), this.job.status_id = this.form.value.status_id, this.toastNotificationService.success("notification_job_status_update_success"), this.jobStatusSave.emit(this.form.value.status_id), this.form.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("job_status_update", this.job.id), this.isVisiblePopup = !1, this.form.reset()
                },
                error: () => {
                    this.hapticService.notifyError(), this.toastNotificationService.error("notification_job_status_update_error")
                }
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(Je), T(U), T(kr), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-status-update-popup"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(fm, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.postConditionsFormRef = p.first)
                    }
                },
                inputs: {
                    job: "job",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    jobStatusSave: "jobStatusSave",
                    jobStatusClose: "jobStatusClose"
                },
                standalone: !1,
                decls: 3,
                vars: 7,
                consts: [
                    ["postConditionsFormRef", ""],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [3, "confirmationMessage"],
                    [1, "d-flex", "flex-column", "h-100"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [3, "job"],
                    [1, "row"],
                    ["name", "status_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status_id"],
                    ["name", "assigned_user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label", "tooltipText"],
                    ["formControlName", "assigned_user_id", "id", "assign-to-popup-assignee", "placeholder", "job_assignee_placeholder", 3, "isMobileDeviceAndRequiredHere", "showClearButton"],
                    [1, "col-12"],
                    ["name", "comment", 1, "col-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["formControlName", "comment", 3, "quickReply"],
                    [3, "form"],
                    [3, "displayError", "errorMsg"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving"],
                    [1, "post-conditions-inline-section", "my-2"],
                    [3, "onItemClick", "collapsible", "animationDuration", "multiple", "selectedIndex"],
                    [3, "title"],
                    [1, "p-2"],
                    [3, "prePostConditionChecklistSave", "allPrePostConditions", "isEditMode", "conditionMode", "inlineMode", "checkedPrePostConditions"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmationMessage"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 1), f("onHidden", function() {
                        return i.onCancel()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, xm, 3, 2, "div", 2), a(), m(2, Sm, 1, 1, "app-confirmation-popup", 3)), o & 2 && (w("visible", i.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 650)("title", i.formatMessage("job_update_status")), n(), l("dxTemplateOf", "content"), n(), _(i.isVisibleUpdateServiceStatusPopup ? 2 : -1))
                },
                dependencies: [ut, ee, ii, et, Fe, K, Re, bt, ue, _e, Qi, At, tr, W, H, ye, pe, q, re, le, se, sn],
                encapsulation: 2
            })
        }
    }
    return t
})();
var gi = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new Je().group({
            id: [c.id || null],
            vendor_id: [c.vendor_id || null, [de.required]],
            job_id: [c.job_id || null, [de.required]],
            status: [c.status || Rn.OPEN, de.required],
            price: [c.price || null],
            description: [c.description || null]
        })
    }
};
var ln = (() => {
    class t extends Be {
        constructor(e) {
            super(e, qo), this.api = e, this.endpoint = qo
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Qe(Ie))
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function Tm(t, c) {
    if (t & 1 && u(0, "app-job-current-info", 6), t & 2) {
        let e = s(3);
        l("job", e.entity)
    }
}

function Mm(t, c) {
    if (t & 1 && (r(0, "div"), m(1, Tm, 1, 1, "app-job-current-info", 6), a()), t & 2) {
        let e = s(2);
        n(), _(e.entity ? 1 : -1)
    }
}

function Pm(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 4), t & 2 && l("rows", 4)("columns", 2)
}

function Im(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 18)(1, "div", 19), u(2, "app-save-btn", 20), a(), r(3, "div", 19)(4, "app-save-btn", 21), f("saveBtnClick", function() {
            C(e);
            let i = s(3);
            return v(i.scheduleDrop())
        }), a()()()
    }
    if (t & 2) {
        let e = s(3);
        l("ngClass", e.isMobileDevice ? "flex-wrap" : ""), n(2), l("isOnPopup", !0)("useSubmitBehavior", !0)("width", "100%"), n(2), l("isOnPopup", !0)("useSubmitBehavior", !0)("width", "100%")
    }
}

function Em(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-cancel-footer", 23), f("cancelClick", function() {
            C(e);
            let i = s(4);
            return v(i.onClosing())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("gaEvent", "Create-update-Outsource")("isOnPopup", !0)("isSaving", e.outSourceIsInProgress)
    }
}

function wm(t, c) {
    if (t & 1 && m(0, Em, 1, 3, "app-save-cancel-footer", 22), t & 2) {
        let e = s(3);
        _(e.isFromOutsourceListing ? 0 : -1)
    }
}

function Om(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 7), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.outSourceTo())
        }), r(1, "div", 2)(2, "div", 8)(3, "app-control-container", 9), u(4, "dx-select-box", 10), a(), r(5, "app-control-container", 11), u(6, "dx-select-box", 12), a(), r(7, "app-control-container", 13), u(8, "dx-number-box", 14), a(), r(9, "app-control-container", 15), u(10, "app-textarea", 16), a(), u(11, "app-error", 17), a(), m(12, Im, 5, 7, "div", 18)(13, wm, 1, 1), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(3), l("errorMsg", e.formatMessage("job_outsource_vendor_required_error"))("label", e.formatMessage("outsource_to")), n(), l("items", e.outsourceVendorList)("searchEnabled", !0)("placeholder", e.formatMessage("job_outsource_vendor_name_placeholder")), n(), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status")), n(), l("items", e.statusList)("placeholder", e.formatMessage("common_select_status"))("showClearButton", !0), n(), l("errorMsg", e.formatMessage("common_error_messages_price_required"))("label", e.formatMessage("common_price")), n(2), l("errorMsg", e.formatMessage("text_required_error"))("label", e.formatMessage("repair_services_description")), n(2), l("displayError", e.outsourceErrorMessage !== "")("errorMsg", e.outsourceErrorMessage), n(), _(e.isFromOutsourceListing ? 13 : 12)
    }
}

function jm(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 2)(2, "div", 3), m(3, Mm, 2, 1, "div"), m(4, Pm, 1, 2, "app-skeleton-loader", 4), m(5, Om, 14, 18, "form", 5), a()()()), t & 2) {
        let e = s();
        n(3), _(e.entityType === e.ENTITIES.JOB.name ? 3 : -1), n(), _(e.form ? -1 : 4), n(), _(e.form ? 5 : -1)
    }
}
var Eo = (() => {
    class t {
        constructor(e, o, i) {
            this.outsourceToService = e, this.outsourceVendorService = o, this.loaderService = i, this.formatMessage = g, this.isVisiblePopup = !1, this.isFromOutsourceListing = !1, this.ENTITIES = I, this.formService = b(me), this.toastNotificationService = b(D), this.router = b(G), this.isMobileDevice = b(A).isMobileDevice(), this.isSaving = !1, this.outsourceErrorMessage = "", this.outsourceVendorList = [], this.isAlreadyOutsourcedJob = !1, this.isLoading = !1, this.isScheduleDrop = !1, this.statusList = Object.values(Rn), this.outSourceToSave = new J, this.outSourceToClose = new J
        }
        ngOnInit() {
            this.outsourceVendorService.getAll().subscribe({
                next: e => {
                    this.outsourceVendorList = e
                },
                error: e => {
                    console.error(e)
                }
            }), this.entity.outsourced_job || this.entity.job_id ? (this.isAlreadyOutsourcedJob = !0, this.setOutsourceForm()) : this.setNewOutsourceForm()
        }
        setNewOutsourceForm() {
            this.form = gi.getForm(new gi({}))
        }
        setOutsourceForm() {
            this.form = gi.getForm(new gi({
                id: this.entity.outsourced_job ? .id ? ? this.entity ? .id,
                job_id: this.entity.outsourced_job ? .job_id ? ? this.entity ? .job_id,
                status: this.entity.outsourced_job ? .status ? ? this.entity ? .status,
                price: this.entity.outsourced_job ? .price ? ? this.entity ? .price,
                vendor_id: this.entity.outsourced_job ? .vendor_id ? ? this.entity ? .vendor_id,
                description: this.entity.outsourced_job ? .description ? ? this.entity ? .description
            }))
        }
        outSourceTo() {
            this.form.patchValue({
                job_id: this.entity.id
            }), this.form.valid ? (this.loaderService.show(), this.isSaving = !0, (this.isAlreadyOutsourcedJob ? this.outsourceToService.update(this.form.value) : this.outsourceToService.create(this.form.value)).subscribe({
                next: o => {
                    let i = o.id;
                    this.entity.vendor_id = this.form.value.vendor_id, this.toastNotificationService.success("notification_outsource_update_success"), this.outSourceToSave.emit(Ge(Te({}, o), {
                        isScheduleDrop: this.isScheduleDrop
                    })), this.isVisiblePopup = !1, this.form.reset(), this.isScheduleDrop || this.router.navigate([`jobs/outsourceTo/outsourceDeliveryChallan/${i}`])
                },
                error: () => {
                    this.toastNotificationService.error("notification_outsource_update_error")
                }
            }).add(() => {
                this.loaderService.hide(), this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        scheduleDrop() {
            this.isScheduleDrop = !0
        }
        onAddCustomer(e) {
            this.form.patchValue({
                user_id: e.id
            })
        }
        onClosing() {
            this.form.reset(), this.isVisiblePopup = !1, this.outSourceToClose.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ln), T(ri), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-to-popup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    entityType: "entityType",
                    entityId: "entityId",
                    entity: "entity",
                    service: "service",
                    isFromOutsourceListing: "isFromOutsourceListing"
                },
                outputs: {
                    outSourceToSave: "outSourceToSave",
                    outSourceToClose: "outSourceToClose"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    ["id", "outsource-to-popup", 3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "job"],
                    [3, "ngSubmit", "formGroup"],
                    [2, "max-height", "calc(90vh - 320px)", "overflow-y", "auto"],
                    ["name", "vendor_id", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "vendor_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled", "placeholder"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status", 3, "items", "placeholder", "showClearButton"],
                    ["name", "price", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "price", "format", "#,##0.##", "id", "price", "placeholder", "00.00"],
                    ["name", "description", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "description"],
                    [3, "displayError", "errorMsg"],
                    [1, "d-flex", "justify-content-between", "gap-2", 3, "ngClass"],
                    [1, "col"],
                    ["saveText", "common_save", 3, "isOnPopup", "useSubmitBehavior", "width"],
                    ["saveText", "save_schedule_drop", 3, "saveBtnClick", "isOnPopup", "useSubmitBehavior", "width"],
                    ["cancelBtnId", "outsource-to-popup", "saveBtnId", "outsource-to-popup", "saveText", "common_save", "savingText", "saving", 3, "gaEvent", "isOnPopup", "isSaving"],
                    ["cancelBtnId", "outsource-to-popup", "saveBtnId", "outsource-to-popup", "saveText", "common_save", "savingText", "saving", 3, "cancelClick", "gaEvent", "isOnPopup", "isSaving"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onClosing()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, jm, 6, 3, "div", 1), a()), o & 2 && (w("visible", i.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", i.formatMessage("outsource_to")), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [Q, ut, Vi, ee, Fe, K, ue, _e, W, Ji, H, xe, pe, q, re, le, se],
                encapsulation: 2
            })
        }
    }
    return t
})();
var km = () => ({
        id: "jobContextMenuId"
    }),
    al = t => [t];

function Nm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-assign-to-popup", 11), f("assignToClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("assignToSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.ASSIGNED_TO)("job", e.job)
    }
}

function Am(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-add-comment-popup", 12), f("addCommentClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("addCommentSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.ADD_COMMENT)("job", e.job)
    }
}

function Jm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-unified-payment-modal", 13), f("paymentClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("paymentSuccess", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleUnifiedPaymentModal)("entity", e.job)("entityType", e.ENTITIES.JOB.name)
    }
}

function Lm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-job-status-update-popup", 14), f("jobStatusClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("jobStatusSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.UPDATE_STATUS)("job", e.job)
    }
}

function Bm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-add-delivery-popup", 15), f("addDeliveryClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("addDeliverySave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("existingDelivery", e.existingDelivery)("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.ADD_DELIVERY && e.isVisibleDeliveryPopup)("job", e.job)
    }
}

function Rm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-send-review-popup", 16), f("sendReviewClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("sendReviewSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.ADD_REVIEW)("job", e.job)
    }
}

function Um(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-send-payment-link-popup", 17), f("sendPaymentLinkClose", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        })("sendPaymentLinkSave", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entityId", e.job.id)("entityType", e.ENTITIES.JOB.name)("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.SEND_UPI_LINK)
    }
}

function Fm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-add-backup-popup", 18), f("addBackupClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("addBackupSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.ADD_BACKUP && e.isVisibleBackupPopup)("job", e.job)
    }
}

function qm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-outsource-to-popup", 19), f("outSourceToClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("outSourceToSave", function(i) {
            C(e);
            let p = s();
            return v(p.onOutsourceSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entityId", e.job.id)("entityType", e.ENTITIES.JOB.name)("entity", e.job)("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.OUTSOURCE_TO && e.isVisibleOutsourceTo)("service", e.jobService)
    }
}

function Gm(t, c) {
    if (t & 1 && u(0, "app-outsource-pickup-drop-popup", 6), t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleScheduleDropPopup)("job", e.job)("outsource", e.outsource)
    }
}

function Wm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-archive-delete-popup", 20), j("isVisibleChange", function(i) {
            C(e);
            let p = s();
            return O(p.isVisibleArchiveDeletePopup, i) || (p.isVisibleArchiveDeletePopup = i), v(i)
        }), f("onSuccess", function(i) {
            C(e);
            let p = s();
            return v(p.handleArchiveDeleteSuccess(i))
        })("onCancel", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = s();
        w("isVisible", e.isVisibleArchiveDeletePopup), l("service", e.jobService)("entity", e.job)("entityName", e.ENTITIES.JOB.name)("entityDisplayName", e.ENTITIES.JOB.displayName)("entityNumberField", "job_number")("mode", e.archiveDeleteMode())
    }
}

function Hm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-confirmation-popup", 21), f("confirmActionCallback", function() {
            C(e);
            let i = s();
            return v(i.redirect())
        })("rejectActionCallback", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("confirmButtonText", "common_add_service")("confirmationMessage", e.formatMessage("payment_warning_no_items"))
    }
}

function Qm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-clone-entity-popup", 22), f("onCloneCancel", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("onCloneSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPopupSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entity", e.job)("isVisiblePopup", e.selectedContextMenuItem === e.jobContextMenuList.CLONE_JOB)
    }
}

function zm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-popup", 23), f("onHiding", function() {
            C(e);
            let i = s();
            return v(i.cancelPrePostConditions())
        }), r(1, "div", 24)(2, "app-pre-post-condition-check-list-pop-up", 25), f("prePostConditionChecklistSave", function(i) {
            C(e);
            let p = s();
            return v(p.onPrePostConditionChange(i))
        }), a()(), r(3, "app-save-cancel-footer", 26), f("cancelClick", function() {
            C(e);
            let i = s();
            return v(i.cancelPrePostConditions())
        })("saveClick", function() {
            C(e);
            let i = s();
            return v(i.savePrePostConditions())
        }), a()()
    }
    if (t & 2) {
        let e = s();
        l("visible", e.isVisiblePrePostConditionPopup)("showTitle", !0)("title", e.formatMessage("pre_post_condition"))("dragEnabled", !1)("hideOnOutsideClick", !0)("showCloseButton", !0)("width", e.isMobileDevice ? "95%" : 600)("height", "auto"), n(2), l("allPrePostConditions", e.prePostConditions)("isEditMode", !0)("conditionMode", e.prePostConditionMode)("inlineMode", !0)("checkedPrePostConditions", e.job == null ? null : e.job.pre_post_conditions), n(), l("isOnPopup", !0)("isVisibleHr", !1)
    }
}
var cn = (() => {
    class t {
        constructor(e, o) {
            this.jobService = e, this.jobDeliveryService = o, this.formatMessage = g, this.jobContextMenuOnAction = new J, this.isIconOnly = !1, this.buttonText = "job_actions", this.isWizard = !1, this.authorizationService = b(ki), this.moduleDataService = b(mo), this.generalSettingDataService = b(te), this.dataService = b(qe), this.whatsappService = b(Ke), this.router = b(G), this.userSessionService = b(L), this.tenantService = b(ve), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.plan = this.tenantService.plan(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.jobContextMenuList = Ya, this.selectedContextMenuItem = null, this.isVisibleDeliveryPopup = !1, this.isVisibleBackupPopup = !1, this.isVisibleUnifiedPaymentModal = !1, this.isShowLessAmountConfirmationPopUp = !1, this.isVisibleOutsourceTo = !1, this.isVisibleScheduleDropPopup = !1, this.contextMenuItems = [], this.isVisiblePrePostConditionPopup = !1, this.prePostConditions = [], this.prePostConditionMode = "pre", this.pendingPrePostConditions = null, this.isVisibleArchiveDeletePopup = !1, this.archiveDeleteMode = Y("delete"), this.ENTITIES = I
        }
        ngOnChanges(e) {
            if (e.job && e.job.currentValue && (this.job = e.job.currentValue, this.job ? .id && this.contextMenuItems.length)) {
                let o = this.contextMenuItems.findIndex(i => i.name === this.jobContextMenuList.ADD_BACKUP);
                this.job.is_recovery ? this.contextMenuItems[o].visible = this.isEmployee : this.contextMenuItems[o].visible = !1
            }
        }
        ngOnInit() {
            this.contextMenuItems = [{
                name: this.jobContextMenuList.ASSIGNED_TO,
                icon: Ut.CUSTOMER.light,
                visible: this.isEmployee,
                locale_key: g("common_assigned_to")
            }, {
                name: this.jobContextMenuList.UPDATE_STATUS,
                icon: be.CIRCLE.light,
                visible: this.isEmployee,
                locale_key: g("update_status")
            }, {
                name: this.jobContextMenuList.OUTSOURCE_TO,
                icon: be.PEOPLE_CARRY_BOX.light,
                visible: this.isEmployee && this.moduleDataService.isModuleActive(this.ENTITIES.OUTSOURCED_JOB.name),
                locale_key: g("outsource_to")
            }, {
                name: this.jobContextMenuList.ADD_COMMENT,
                icon: Ot.COMMENT.light,
                visible: !0,
                locale_key: g("common_add_comment")
            }, {
                name: this.jobContextMenuList.ADD_PAYMENT,
                icon: Oi.PAYMENT_TYPE.light,
                visible: this.isEmployee && this.userPermissionList.includes(M.PAYMENT_WRITE),
                locale_key: g("common_add_payment")
            }, {
                name: this.jobContextMenuList.ADD_DELIVERY,
                icon: be.TRUCK.light,
                visible: this.isEmployee,
                locale_key: g("add_delivery")
            }, {
                name: this.jobContextMenuList.CLONE_JOB,
                icon: Ot.CLONE.light,
                visible: this.isEmployee,
                locale_key: g("clone_job")
            }, {
                name: this.jobContextMenuList.ADD_BACKUP,
                icon: yt.RECOVERY.light,
                visible: this.job.is_recovery && this.isEmployee && [Le.STANDARD, Le.ENTERPRISE].includes(this.plan),
                locale_key: g("add_backup")
            }, {
                name: this.jobContextMenuList.JOB_DIAGNOSIS,
                icon: yt.STETHOSCOPE.light,
                visible: this.isEmployee && this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.ENABLE_DIAGNOSIS_REPORT),
                locale_key: g("job_diagnosis")
            }, {
                name: this.jobContextMenuList.JOB_SHEET,
                icon: Ut.QUOTATION.light,
                visible: !0,
                locale_key: g("job_sheet")
            }, {
                name: this.jobContextMenuList.QUOTATION,
                icon: Gn.INVOICE.light,
                visible: this.authorizationService.canAccess(this.ENTITIES.QUOTATION) && this.moduleDataService.isModuleActive(this.ENTITIES.QUOTATION.name),
                locale_key: g("quotation")
            }, {
                name: this.jobContextMenuList.INVOICE,
                icon: Ut.INVOICE.light,
                visible: this.authorizationService.canAccess(this.ENTITIES.JOB_INVOICE) && this.moduleDataService.isModuleActive(this.ENTITIES.JOB_INVOICE.name),
                locale_key: g("invoice")
            }, {
                name: this.jobContextMenuList.ADD_REVIEW,
                icon: be.STAR.light,
                disabled: [Le.LITE].includes(this.plan),
                visible: this.isEmployee,
                locale_key: g("add_review")
            }, {
                name: this.jobContextMenuList.SEND_UPI_LINK,
                icon: be.QR_CODE.light,
                disabled: [Le.LITE].includes(this.plan),
                visible: this.isEmployee && this.authorizationService.canAccess(this.ENTITIES.UPI_LINK) && this.tenantService.isIndia() && (!this.job ? .user ? .mobile_country_code || this.job.user.mobile_country_code === "91"),
                locale_key: g("send_upi_link")
            }, {
                name: this.jobContextMenuList.PRE_POST_CONDITION,
                icon: yt.CONDITION.light,
                visible: this.isEmployee && this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.ENABLE_PRE_POST_CONDITION),
                locale_key: g("pre_post_condition")
            }, {
                name: this.jobContextMenuList.DATA_VALIDATION,
                icon: yt.DATA_VALIDATION.light,
                visible: this.job ? .is_recovery && this.isEmployee,
                locale_key: g("data_validation")
            }, {
                name: this.jobContextMenuList.DELETE_JOB,
                icon: Ot.DELETE.light,
                visible: this.userPermissionList.includes(M.JOB_DELETE),
                locale_key: g("delete_job")
            }]
        }
        onContextMenuItemClick(e) {
            if (this.selectedContextMenuItem = e.itemData.name, this.selectedContextMenuItem === this.jobContextMenuList.JOB_SHEET && this.router.navigate([`/jobs/${this.job.id}/jobSheets`]), this.selectedContextMenuItem === this.jobContextMenuList.JOB_DIAGNOSIS && this.router.navigate([`/jobs/${this.job.id}/diagnosis`]), this.selectedContextMenuItem === this.jobContextMenuList.QUOTATION && this.router.navigate([`/jobs/${this.job.id}/quotations`]), this.selectedContextMenuItem === this.jobContextMenuList.INVOICE) {
                let o = this.job ? .invoice ? .id;
                this.router.navigate(o ? [`/jobs/${this.job.id}/invoices/${o}`] : [`/jobs/${this.job.id}/invoices`])
            }
            this.selectedContextMenuItem === this.jobContextMenuList.SEND_WHATSAPP && this.whatsappService.sendWhatsappMessage(this.ENTITIES.JOB_SHEET.name, this.job.id), this.selectedContextMenuItem === this.jobContextMenuList.ADD_DELIVERY && this.jobDeliveryService.getByJobId(this.job.id).subscribe({
                next: o => {
                    this.existingDelivery = o, this.isVisibleDeliveryPopup = !0
                },
                error: o => {
                    console.error("error in getting job id for delivery ", o)
                }
            }), this.selectedContextMenuItem === this.jobContextMenuList.ADD_BACKUP && (this.isVisibleBackupPopup = !0), this.selectedContextMenuItem === this.jobContextMenuList.ADD_PAYMENT && (this.job.total_amount > 0 ? this.isVisibleUnifiedPaymentModal = !0 : this.isShowLessAmountConfirmationPopUp = !0), this.selectedContextMenuItem === this.jobContextMenuList.OUTSOURCE_TO && (this.isVisibleOutsourceTo = !0), this.selectedContextMenuItem === this.jobContextMenuList.PRE_POST_CONDITION && (this.prePostConditionMode = this.job ? .status ? .stage === za.CLOSED ? "both" : "pre", this.dataService.getLookups().subscribe({
                next: o => {
                    let i = o.pre_post_conditions || [];
                    this.prePostConditions = i.filter(p => Number(p.device_type_id) === Number(this.job.device_type_id)), this.jobService.getDetailById(this.job.id).subscribe({
                        next: p => {
                            this.job.pre_post_conditions = p.pre_post_conditions || [], this.isVisiblePrePostConditionPopup = !0
                        },
                        error: () => {
                            this.isVisiblePrePostConditionPopup = !0
                        }
                    })
                }
            })), this.selectedContextMenuItem === this.jobContextMenuList.DATA_VALIDATION && this.router.navigate([`/jobs/${this.job.id}/data-validation`]), this.selectedContextMenuItem === this.jobContextMenuList.DELETE_JOB && (this.archiveDeleteMode.set(this.job.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0)
        }
        handleArchiveDeleteSuccess(e) {
            this.isVisibleArchiveDeletePopup = !1, this.selectedContextMenuItem = null, this.jobContextMenuOnAction.emit(this.job)
        }
        onPopupSaveAction(e) {
            this.selectedContextMenuItem === this.jobContextMenuList.ADD_PAYMENT && (this.job.payable_amount = this.job.payable_amount - e.amount), this.selectedContextMenuItem === this.jobContextMenuList.ASSIGNED_TO && (this.job.assigned_user_id = e), this.selectedContextMenuItem === this.jobContextMenuList.UPDATE_STATUS && (this.job.status_id = e), this.selectedContextMenuItem === this.jobContextMenuList.ADD_DELIVERY && (this.isVisibleDeliveryPopup = !1), this.selectedContextMenuItem === this.jobContextMenuList.ADD_BACKUP && (this.isVisibleBackupPopup = !1), this.jobService.handleJobUpdateStatus(this.selectedContextMenuItem, this.job), this.onCloseContextMenuOption(), this.jobContextMenuOnAction.emit(this.job)
        }
        onCloseContextMenuOption() {
            this.selectedContextMenuItem = null
        }
        onOutsourceSaveAction(e) {
            this.isVisibleScheduleDropPopup = e.isScheduleDrop, this.outsource = e
        }
        redirect() {
            this.router.navigate(["/jobs/" + this.job.id + "/servicesAndParts"], {
                queryParams: {
                    key: "addAmountForServiceOrParts"
                }
            }), this.selectedContextMenuItem = null, this.isShowLessAmountConfirmationPopUp = !1
        }
        onPrePostConditionChange(e) {
            this.pendingPrePostConditions = e
        }
        savePrePostConditions() {
            let e = this.pendingPrePostConditions;
            if (!e) {
                this.cancelPrePostConditions();
                return
            }
            this.jobService.updatePrePostConditions(this.job.id, e).subscribe({
                next: () => {
                    this.job.pre_post_conditions = e, this.toastNotificationService.success("notification_success"), this.cancelPrePostConditions(), this.jobContextMenuOnAction.emit(this.job)
                },
                error: () => {
                    this.toastNotificationService.error("notification_error")
                }
            })
        }
        cancelPrePostConditions() {
            this.pendingPrePostConditions = null, this.isVisiblePrePostConditionPopup = !1, this.onCloseContextMenuOption()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T(ci))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-context-menu"]
                ],
                inputs: {
                    job: "job",
                    isIconOnly: "isIconOnly",
                    buttonText: "buttonText",
                    isWizard: "isWizard"
                },
                outputs: {
                    jobContextMenuOnAction: "jobContextMenuOnAction"
                },
                standalone: !1,
                features: [Yt],
                decls: 15,
                vars: 29,
                consts: [
                    ["displayExpr", "locale_key", "keyExpr", "name", 3, "onItemClick", "elementAttr", "hint", "items", "showArrowIcon", "stylingMode", "text", "icon", "type"],
                    [3, "isVisiblePopup", "job"],
                    [3, "isVisiblePopup", "entity", "entityType"],
                    [3, "existingDelivery", "isVisiblePopup", "job"],
                    [3, "entityId", "entityType", "isVisiblePopup"],
                    [3, "entityId", "entityType", "entity", "isVisiblePopup", "service"],
                    [3, "isVisiblePopup", "job", "outsource"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "confirmButtonText", "confirmationMessage"],
                    [3, "entity", "isVisiblePopup"],
                    [3, "visible", "showTitle", "title", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [3, "assignToClose", "assignToSave", "isVisiblePopup", "job"],
                    [3, "addCommentClose", "addCommentSave", "isVisiblePopup", "job"],
                    [3, "paymentClose", "paymentSuccess", "isVisiblePopup", "entity", "entityType"],
                    [3, "jobStatusClose", "jobStatusSave", "isVisiblePopup", "job"],
                    [3, "addDeliveryClose", "addDeliverySave", "existingDelivery", "isVisiblePopup", "job"],
                    [3, "sendReviewClose", "sendReviewSave", "isVisiblePopup", "job"],
                    [3, "sendPaymentLinkClose", "sendPaymentLinkSave", "entityId", "entityType", "isVisiblePopup"],
                    [3, "addBackupClose", "addBackupSave", "isVisiblePopup", "job"],
                    [3, "outSourceToClose", "outSourceToSave", "entityId", "entityType", "entity", "isVisiblePopup", "service"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage"],
                    [3, "onCloneCancel", "onCloneSave", "entity", "isVisiblePopup"],
                    [3, "onHiding", "visible", "showTitle", "title", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [1, "p-3"],
                    [3, "prePostConditionChecklistSave", "allPrePostConditions", "isEditMode", "conditionMode", "inlineMode", "checkedPrePostConditions"],
                    [3, "cancelClick", "saveClick", "isOnPopup", "isVisibleHr"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-drop-down-button", 0), f("onItemClick", function(y) {
                        return i.onContextMenuItemClick(y)
                    }), a(), m(1, Nm, 1, 2, "app-assign-to-popup", 1), m(2, Am, 1, 2, "app-add-comment-popup", 1), m(3, Jm, 1, 3, "app-unified-payment-modal", 2), m(4, Lm, 1, 2, "app-job-status-update-popup", 1), m(5, Bm, 1, 3, "app-add-delivery-popup", 3), m(6, Rm, 1, 2, "app-send-review-popup", 1), m(7, Um, 1, 3, "app-send-payment-link-popup", 4), m(8, Fm, 1, 2, "app-add-backup-popup", 1), m(9, qm, 1, 5, "app-outsource-to-popup", 5), m(10, Gm, 1, 3, "app-outsource-pickup-drop-popup", 6), m(11, Wm, 1, 7, "app-archive-delete-popup", 7), m(12, Hm, 1, 2, "app-confirmation-popup", 8), m(13, Qm, 1, 2, "app-clone-entity-popup", 9), m(14, zm, 4, 15, "dx-popup", 10)), o & 2 && (Si(i.isIconOnly || i.isMobileDevice ? "menu" : "text-icon"), l("elementAttr", Ye(24, km))("hint", i.formatMessage("perform_job_operations"))("items", i.contextMenuItems)("showArrowIcon", !(i.isIconOnly || i.isMobileDevice))("stylingMode", i.isIconOnly || i.isMobileDevice ? "text" : "outlined")("text", i.isIconOnly || i.isMobileDevice ? "" : i.formatMessage(i.buttonText))("icon", i.isIconOnly || i.isMobileDevice ? "fa-thin fa-gear" : "")("type", i.isIconOnly || i.isMobileDevice ? "normal" : "default"), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.ASSIGNED_TO ? 1 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.ADD_COMMENT ? 2 : -1), n(), _(i.job != null && i.job.id && fe(25, al, i.jobContextMenuList.ADD_PAYMENT).includes(i.selectedContextMenuItem) && i.isVisibleUnifiedPaymentModal ? 3 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.UPDATE_STATUS ? 4 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.ADD_DELIVERY && i.isVisibleDeliveryPopup ? 5 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.ADD_REVIEW ? 6 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.SEND_UPI_LINK ? 7 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.ADD_BACKUP && i.isVisibleBackupPopup ? 8 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.OUTSOURCE_TO && i.isVisibleOutsourceTo ? 9 : -1), n(), _(i.isVisibleScheduleDropPopup ? 10 : -1), n(), _(i.isVisibleArchiveDeletePopup ? 11 : -1), n(), _(i.isShowLessAmountConfirmationPopUp && fe(27, al, i.jobContextMenuList.ADD_PAYMENT).includes(i.selectedContextMenuItem) ? 12 : -1), n(), _(i.job != null && i.job.id && i.selectedContextMenuItem === i.jobContextMenuList.CLONE_JOB ? 13 : -1), n(), _(i.job != null && i.job.id && i.isVisiblePrePostConditionPopup && i.prePostConditions.length > 0 ? 14 : -1))
                },
                dependencies: [ii, to, ao, K, Gr, Qr, po, gr, Ai, H, uo, il, Fs, As, Es, sn, Eo],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ym(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 1), t & 2 && l("rows", 8)("columns", 3)
}

function $m(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 6)(1, "div", 3)(2, "div", 7)(3, "div", 8), u(4, "app-job-status-tag", 9), r(5, "span", 10), d(6), a()(), r(7, "div", 8)(8, "app-job-context-menu", 11), f("jobContextMenuOnAction", function(i) {
            C(e);
            let p = s(3);
            return v(p.onJobContextMenuAction(i))
        }), a()()()()()
    }
    if (t & 2) {
        let e = s(3);
        n(4), l("iconType", e.statusIconTypeList.TITLE)("status", e.job.status), n(2), h(e.job.job_number), n(2), l("job", e.job)
    }
}

function Km(t, c) {
    if (t & 1 && m(0, $m, 9, 4, "div", 6), t & 2) {
        let e = s(2);
        _(e.job && e.job.id ? 0 : -1)
    }
}

function Xm(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 4)(1, "app-responsive-tabs", 5), f("tabChange", function(i) {
            C(e);
            let p = s();
            return v(p.selectTab(i))
        }), E(2, Km, 1, 1, "ng-template", null, 0, _i), a()()
    }
    if (t & 2) {
        let e = s();
        n(), l("tabs", e.tabs)("selectedIndex", e.selectedTabIndex)("showMobileMenuOnInit", !0)("hideMobileMenuHeader", !0)("mobileMenuTitle", e.job == null ? null : e.job.job_number)
    }
}

function Zm(t, c) {
    t & 1 && (r(0, "div", 4), u(1, "app-job-basic-info"), a())
}
var oa = (() => {
    class t {
        constructor(e, o, i, p) {
            this.jobService = e, this.jobRepairServiceService = o, this.loaderService = i, this.meta = p, this.formatMessage = g, this.router = b(G), this.userSessionService = b(L), this.toastNotificationService = b(D), this.tenantService = b(ve), this.userDeviceService = b(A), this.activatedRouter = b(R), this.plan = this.tenantService.plan(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.job = null, this.jobId = null, this.selectedTabIndex = null, this.statusIconTypeList = he, this.isRedirectFromAddPayment = !1, this.tabs = [], this.meta.addTags([{
                name: "description",
                content: "View Service jobs details"
            }, {
                name: "keywords",
                content: "service-jobs, jobs"
            }])
        }
        ngOnInit() {
            this.activatedRouter.params.subscribe({
                next: e => {
                    this.jobId = null, this.jobId = +e.job_id, this.jobId && (this.activatedRouter.firstChild.data.subscribe({
                        next: o => {
                            this.selectedTabIndex = o.tab_index
                        },
                        error: o => {
                            this.toastNotificationService.error("notification_error"), console.error("error selecting tab index ", o)
                        }
                    }), this.tabs = [{
                        id: 0,
                        text: g("job_overview"),
                        path: `/jobs/${this.jobId}/overview`,
                        icon: be.FOLDER_SEARCH.light,
                        visible: !0
                    }, {
                        id: 1,
                        text: g("common_details"),
                        path: `/jobs/${this.jobId}/details`,
                        icon: qn.INFO.light,
                        visible: !0
                    }, {
                        id: 2,
                        text: g("comments"),
                        path: `/jobs/${this.jobId}/comments`,
                        icon: Ot.COMMENT.light,
                        visible: !0
                    }, {
                        id: 3,
                        text: g("payment"),
                        path: `/jobs/${this.jobId}/payments`,
                        icon: Oi.PAYMENT_TYPE.light,
                        visible: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_TAB)
                    }, {
                        id: 4,
                        text: g("job_delivery"),
                        path: `/jobs/${this.jobId}/deliveries`,
                        icon: be.TRUCK.light,
                        visible: !0
                    }, {
                        id: 5,
                        text: g("job_services_and_parts"),
                        path: `/jobs/${this.jobId}/servicesAndParts`,
                        icon: yt.SERVICE.light,
                        visible: !0
                    }, {
                        id: 6,
                        text: g("job_backups"),
                        path: `/jobs/${this.jobId}/backups`,
                        icon: yt.RECOVERY.light,
                        visible: !1
                    }, {
                        id: 7,
                        text: g("job_private_notes"),
                        path: `/jobs/${this.jobId}/notes`,
                        icon: be.STICKY_NOTE.light,
                        visible: this.isEmployee
                    }, {
                        id: 8,
                        text: g("job_pickup_drop"),
                        path: `/jobs/${this.jobId}/pickupDrop`,
                        icon: be.PERSON_CARRY_BOX.light,
                        disabled: [Le.LITE].includes(this.plan),
                        visible: this.isEmployee
                    }, {
                        id: 9,
                        text: g("data_validation"),
                        path: `/jobs/${this.jobId}/data-validation`,
                        icon: be.SHIELD_CHECK.light,
                        visible: !1,
                        hiddenOnMobile: !0
                    }], this.loaderService.show(), this.getJobDetail(), this.checkIsRedirectFromAddPaymentWithoutAnyAmount())
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.error("error")
                }
            })
        }
        getJobDetail() {
            this.jobService.getById(this.jobId).subscribe({
                next: e => {
                    this.jobService.setCurrentJob(new Ee(e))
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.log("error getting job details ", e)
                }
            }).add(() => this.loaderService.hide()), this.jobService.currentJob$.subscribe({
                next: e => {
                    if (e ? .id) {
                        this.job = e;
                        let o = this.tabs.findIndex(p => p.text === "Backups"),
                            i = this.tabs.findIndex(p => p.id === 9);
                        this.job.is_recovery ? (this.tabs[o].visible = this.isEmployee && [Le.STANDARD, Le.ENTERPRISE].includes(this.plan), this.tabs[i].visible = this.isEmployee) : (this.tabs[o].visible = !1, this.tabs[i].visible = !1), this.tabs = [...this.tabs]
                    }
                },
                error: e => {
                    console.log("error in rendering loader ", e)
                }
            })
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        onJobContextMenuAction(e) {
            this.job = e, this.userDeviceService.isMobileDevice() && this.router.navigate(["/jobs/list"])
        }
        checkIsRedirectFromAddPaymentWithoutAnyAmount() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    e.key === "addAmountForServiceOrParts" && (this.isRedirectFromAddPayment = !0, this.selectedTabIndex = 5)
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.error("error ", e)
                }
            }), this.jobRepairServiceService.dataChanged.subscribe({
                next: e => {
                    this.getJobDetail()
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T(Ur), T($), T(Oa))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-detail"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(lo, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.entityRepairServicesComponent = p.first)
                    }
                },
                standalone: !1,
                decls: 5,
                vars: 2,
                consts: [
                    ["subheader", ""],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "form-height-mobile-view"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-wrench", 3, "tabChange", "tabs", "selectedIndex", "showMobileMenuOnInit", "hideMobileMenuHeader", "mobileMenuTitle"],
                    [1, "row", "mb-3"],
                    [1, "d-flex", "justify-content-between", "align-items-center"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [3, "iconType", "status"],
                    [1, "title-text"],
                    [3, "jobContextMenuOnAction", "job"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, Ym, 1, 2, "app-skeleton-loader", 1), r(1, "div", 2)(2, "div", 3), m(3, Xm, 4, 5, "div", 4)(4, Zm, 2, 0, "div", 4), a()()), o & 2 && (_(!(i.job != null && i.job.id) && i.jobId ? 0 : -1), n(3), _(i.jobId ? 3 : 4))
                },
                dependencies: [Se, ue, Xi, Io, cn],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ll = (() => {
    class t {
        constructor() {
            this.refreshSubject = new ua, this.refresh$ = this.refreshSubject.asObservable()
        }
        triggerRefresh() {
            this.refreshSubject.next()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var In = ma(cr());
var e_ = (t, c, e) => ({
    paymentable_id: t,
    paymentable_type: c,
    customer_id: e
});

function t_(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-add-job-payment-popup", 3), f("addPaymentClose", function() {
            C(e);
            let i = s();
            return v(i.isVisiblePopup = !1)
        })("addPaymentSave", function() {
            C(e);
            let i = s();
            return v(i.onSavePayment())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isCreate", e.isCreate)("isVisiblePopup", e.isVisiblePopup)("jobId", e.jobId)("payment", e.payment)
    }
}
var wo = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.jobService = o, this.formatMessage = g, this.jobId = null, this.isiVisibleTitle = !1, this.isOnAside = !1, this.userSessionService = b(L), this.activatedRouter = b(R), this.toastNotificationService = b(D), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = I, this.isVisiblePopup = !1, this.isCreate = !1, this.entity = I.PAYMENT, this.columns = [{
                dataField: "paymentable",
                caption: g("payment_against"),
                cellTemplate: "paymentableLinkTemplate",
                width: 140,
                allowSorting: !1
            }, {
                dataField: "amount",
                caption: g("common_amount"),
                width: 120,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "payment_type.name",
                caption: g("payment_mode"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "transaction_id",
                caption: g("common_transaction_id"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "cheque_number",
                caption: g("sale_cheque_number"),
                hidingPriority: 1,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: g("common_created_by"),
                hidingPriority: 4,
                cellTemplate: "employeeTemplate",
                allowSorting: !1
            }, {
                dataField: "updated_user",
                caption: g("common_updated_by"),
                hidingPriority: 5,
                cellTemplate: "employeeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "comment",
                caption: g("common_comment"),
                hidingPriority: 2,
                cellTemplate: "commentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: g("common_created_on"),
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 7,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.PERMISSION_LIST = M
        }
        ngOnInit() {
            this.entity.isVisibleSearchPanel = !1, this.jobId || (this.jobId = +this.activatedRouter.snapshot.parent.paramMap.get("job_id")), this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.jobService.paymentListReload$.subscribe({
                next: () => {
                    this.dataGrid && this.dataGrid.getData()
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.error(e)
                }
            }), this.initialize()
        }
        initialize() {
            let e = {};
            this.jobId && (e.job_id = this.jobId), this.customerId && (e.customer_id = this.customerId)
        }
        create() {
            this.isVisiblePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.payment = e, this.isVisiblePopup = !0
        }
        onSavePayment() {
            this.isCreate = !1, this.dataGrid.getData(), this.payment = null, this.isVisiblePopup = !1
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(Rr), T(U))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-payment-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(ce, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.dataGrid = p.first)
                    }
                },
                inputs: {
                    jobId: "jobId",
                    isiVisibleTitle: "isiVisibleTitle",
                    isOnAside: "isOnAside"
                },
                standalone: !1,
                decls: 4,
                vars: 16,
                consts: [
                    [3, "ngClass"],
                    [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleTitle", "isOnAside", "service"],
                    [3, "isCreate", "isVisiblePopup", "jobId", "payment"],
                    [3, "addPaymentClose", "addPaymentSave", "isCreate", "isVisiblePopup", "jobId", "payment"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 0)(2, "app-data-grid", 1), f("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(y) {
                        return i.edit(y)
                    }), a()()(), m(3, t_, 1, 4, "app-add-job-payment-popup", 2)), o & 2 && (l("ngClass", i.customerId ? "card" : ""), n(), l("ngClass", i.customerId ? "card-body" : ""), n(), l("additionalParams", ot(12, e_, i.jobId, i.ENTITIES.JOB.name, i.customerId))("columns", i.columns)("entity", i.entity)("isVisibleAddAction", !1)("isVisibleDeleteAction", i.isAdmin || i.userPermissionList.includes(i.PERMISSION_LIST.PAYMENT_DELETE))("isVisibleEditAction", i.isEmployee)("isVisibleTitle", i.isiVisibleTitle)("isOnAside", !0)("service", i.service), n(), _(i.jobId && i.isVisiblePopup ? 3 : -1))
                },
                dependencies: [Q, ce, es],
                encapsulation: 2
            })
        }
    }
    return t
})();
var s_ = (t, c) => ({
        pin: t,
        open: c
    }),
    l_ = () => ({ of: ".panel"
    });

function c_(t, c) {
    if (t & 1 && u(0, "app-user-badge", 12), t & 2) {
        let e = s(2);
        l("entity", e.ENTITIES.CUSTOMER)("iconOnly", !0)("size", e.iconSizes.MEDIUM)("user", e.job.user)
    }
}

function d_(t, c) {
    if (t & 1 && u(0, "app-copy-to-clipboard", 25), t & 2) {
        let e = s(4);
        l("textToBeCopied", e.job == null || e.job.user == null ? null : e.job.user.email)
    }
}

function p_(t, c) {
    if (t & 1 && (r(0, "app-restricted-content", 23)(1, "a", 24), d(2), a(), m(3, d_, 1, 1, "app-copy-to-clipboard", 25), a()), t & 2) {
        let e = s(3);
        l("permission", e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION), n(), l("href", Ve("mailto:", e.job == null || e.job.user == null ? null : e.job.user.email), It), n(), h(e.job == null || e.job.user == null ? null : e.job.user.email), n(), _(!(e.job == null || e.job.user == null) && e.job.user.email ? 3 : -1)
    }
}

function m_(t, c) {
    if (t & 1 && u(0, "app-copy-to-clipboard", 25), t & 2) {
        let e = s(4);
        l("textToBeCopied", e.job == null || e.job.user == null ? null : e.job.user.email)
    }
}

function __(t, c) {
    if (t & 1 && (r(0, "a", 24), d(1), a(), m(2, m_, 1, 1, "app-copy-to-clipboard", 25)), t & 2) {
        let e = s(3);
        l("href", Ve("mailto:", e.job == null || e.job.user == null ? null : e.job.user.email), It), n(), h(e.job == null || e.job.user == null ? null : e.job.user.email), n(), _(!(e.job == null || e.job.user == null) && e.job.user.email ? 2 : -1)
    }
}

function u_(t, c) {
    if (t & 1 && (r(0, "div", 16), u(1, "i", 22), m(2, p_, 4, 5, "app-restricted-content", 23)(3, __, 3, 4), a()), t & 2) {
        let e = s(2);
        n(2), _(e.USER_TYPES.CUSTOMER === (e.job == null || e.job.user == null ? null : e.job.user.type_id) ? 2 : 3)
    }
}

function C_(t, c) {
    if (t & 1 && (u(0, "app-copy-to-clipboard", 25), V(1, "mobileDisplay")), t & 2) {
        let e = s(4);
        l("textToBeCopied", B(1, 1, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code))
    }
}

function v_(t, c) {
    if (t & 1 && (r(0, "app-restricted-content", 23)(1, "a", 24), V(2, "mobileDisplay"), d(3), V(4, "mobileDisplay"), a(), m(5, C_, 2, 4, "app-copy-to-clipboard", 25), a()), t & 2) {
        let e = s(3);
        l("permission", e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION), n(), l("href", Ve("tel:", Cn(2, 5, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code, "tel")), It), n(2), h(B(4, 9, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code)), n(2), _(!(e.job == null || e.job.user == null) && e.job.user.mobile_number ? 5 : -1)
    }
}

function f_(t, c) {
    if (t & 1 && (u(0, "app-copy-to-clipboard", 25), V(1, "mobileDisplay")), t & 2) {
        let e = s(4);
        l("textToBeCopied", B(1, 1, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code))
    }
}

function h_(t, c) {
    if (t & 1 && (r(0, "a", 24), V(1, "mobileDisplay"), d(2), V(3, "mobileDisplay"), a(), m(4, f_, 2, 4, "app-copy-to-clipboard", 25)), t & 2) {
        let e = s(3);
        l("href", Ve("tel:", Cn(1, 4, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code, "tel")), It), n(2), h(B(3, 8, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code)), n(2), _(!(e.job == null || e.job.user == null) && e.job.user.mobile_number ? 4 : -1)
    }
}

function b_(t, c) {
    if (t & 1 && (r(0, "div", 16), u(1, "i", 26), m(2, v_, 6, 12, "app-restricted-content", 23)(3, h_, 5, 11), a()), t & 2) {
        let e = s(2);
        n(2), _(e.USER_TYPES.CUSTOMER === (e.job == null || e.job.user == null ? null : e.job.user.type_id) ? 2 : 3)
    }
}

function g_(t, c) {
    if (t & 1 && (r(0, "div", 29)(1, "h6"), d(2), a()()), t & 2) {
        let e = c.$implicit;
        n(2), h(e.title)
    }
}

function x_(t, c) {
    if (t & 1 && u(0, "app-user-badge", 35), t & 2) {
        let e = s(4);
        l("size", e.iconSizes.SMALL)("user", e.job.assigned_user)
    }
}

function S_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 36), u(4, "app-currency-symbol"), d(5), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("payment_remaining")), n(3), S(" ", ((e.job == null ? null : e.job.total_amount) ? ? 0) - (e.job.payment_received ? ? 0), " ")
    }
}

function y_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 36), u(4, "app-currency-symbol"), d(5), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("payment_received")), n(3), S(" ", e.job == null ? null : e.job.payment_received, " ")
    }
}

function T_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 36), u(4, "app-payment-status", 39), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("payment_status")), n(2), l("status", e.job == null ? null : e.job.payment_status)
    }
}

function M_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 40), d(4), a()()), t & 2) {
        let e = s(5);
        n(2), h(e.formatMessage("quotation_status")), n(2), S(" ", e.job == null || e.job.quotation == null ? null : e.job.quotation.status, " ")
    }
}

function P_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 41), d(4), a()()), t & 2) {
        let e = s(5);
        n(2), h(e.formatMessage("quotation_status")), n(2), S(" ", e.job == null || e.job.quotation == null ? null : e.job.quotation.status, " ")
    }
}

function I_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 42), d(4), a()()), t & 2) {
        let e = s(5);
        n(2), h(e.formatMessage("quotation_status")), n(), l("ngClass", (e.job == null || e.job.quotation == null ? null : e.job.quotation.status) === e.quotationStatuses.MODIFIED ? "bg-info" : "bg-warning"), n(), S(" ", e.job == null || e.job.quotation == null ? null : e.job.quotation.status, " ")
    }
}

function E_(t, c) {
    if (t & 1 && (m(0, M_, 5, 2, "div", 32), m(1, P_, 5, 2, "div", 32), m(2, I_, 5, 3, "div", 32)), t & 2) {
        let e = s(4);
        _((e.job == null ? null : e.job.quotation.status) === e.quotationStatuses.APPROVED ? 0 : -1), n(), _((e.job == null ? null : e.job.quotation.status) === e.quotationStatuses.REJECTED ? 1 : -1), n(), _((e.job == null || e.job.quotation == null ? null : e.job.quotation.status) !== e.quotationStatuses.APPROVED && (e.quotation == null ? null : e.quotation.status) !== e.quotationStatuses.REJECTED ? 2 : -1)
    }
}

function w_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 36), d(4), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("delivery_type")), n(2), S(" ", (e.job == null || e.job.deliveries == null || e.job.deliveries[0] == null || e.job.deliveries[0].type == null ? null : e.job.deliveries[0].type.name) || "N/A", " ")
    }
}

function O_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 34), d(4), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("initial_quotation")), n(2), S(" ", e.job == null ? null : e.job.initial_quotation, " ")
    }
}

function j_(t, c) {
    if (t & 1 && (r(0, "div", 32)(1, "div", 33), d(2), a(), r(3, "div", 36), d(4), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("dealer_Job_id")), n(2), S(" ", e.job == null ? null : e.job.vendor_job_id, " ")
    }
}

function V_(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 30)(2, "div", 31)(3, "div", 32)(4, "div", 33), d(5), a(), r(6, "div", 34), m(7, x_, 1, 2, "app-user-badge", 35), d(8), a()(), r(9, "div", 32)(10, "div", 33), d(11), a(), r(12, "div", 36)(13, "div", 37), d(14), V(15, "timeDiff"), a()()(), m(16, S_, 6, 2, "div", 32), m(17, y_, 6, 2, "div", 32), m(18, T_, 5, 2, "div", 32), m(19, E_, 3, 3), m(20, w_, 5, 2, "div", 32), r(21, "div", 32)(22, "div", 33), d(23), a(), r(24, "div", 38), d(25), V(26, "dateFormat"), a()(), m(27, O_, 5, 2, "div", 32), m(28, j_, 5, 2, "div", 32), a()()()), t & 2) {
        let e = s(3);
        n(5), h(e.formatMessage("job_assignee")), n(2), _(e.job.assigned_user ? 7 : -1), n(), S(" ", (e.job.assigned_user == null ? null : e.job.assigned_user.name) || "Unassigned", " "), n(3), h(e.formatMessage("job_age")), n(2), l("ngClass", e.isOlderThanAWeek(e.job.age_in_seconds) ? "bg-danger" : "bg-warning"), n(), S(" ", ie(15, 15, e.job.age_in_seconds), " "), n(2), _(e.job.total_amount - e.job.payment_received !== 0 ? 16 : -1), n(), _((e.job == null ? null : e.job.payment_received) != null ? 17 : -1), n(), _(e.job.payment_status ? 18 : -1), n(), _(e.job.quotation ? 19 : -1), n(), _(e.job.deliveries.length > 0 ? 20 : -1), n(3), h(e.formatMessage("created_date")), n(2), S(" ", B(26, 17, e.job.created_at, "datetime"), " "), n(2), _(e.job != null && e.job.initial_quotation ? 27 : -1), n(), _(e.job != null && e.job.vendor_job_id ? 28 : -1)
    }
}

function D_(t, c) {
    if (t & 1 && u(0, "app-job-repair-services", 46), t & 2) {
        let e = s(4);
        l("isEditMode", e.isEditMode)("isJobView", e.isJobView)("isOnAside", !0)("repairableId", e.jobId)("repairableType", e.entityType)
    }
}

function k_(t, c) {
    if (t & 1 && u(0, "app-job-parts", 47), t & 2) {
        let e = s(4);
        l("isEditMode", e.isEditMode)("isJobView", e.isJobView)("isOnAside", !0)("partableId", e.jobId)("partableType", e.entityType)
    }
}

function N_(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 43), E(2, D_, 1, 5, "app-job-repair-services", 44)(3, k_, 1, 5, "app-job-parts", 45), a()()), t & 2) {
        let e = s(3);
        n(2), l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_REPAIR_SERVICE_LIST), n(), l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_PART_LIST)
    }
}

function A_(t, c) {
    if (t & 1 && (r(0, "div"), u(1, "app-job-payment-list", 48), a()), t & 2) {
        let e = s(3);
        n(), l("isOnAside", !0)("jobId", e.jobId)
    }
}

function J_(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_create"), " ")
    }
}

function L_(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_view"), " ")
    }
}

function B_(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_create"), " ")
    }
}

function R_(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_view"), " ")
    }
}

function U_(t, c) {
    if (t & 1 && (r(0, "ul", 51)(1, "li")(2, "div"), d(3), a(), r(4, "a", 50), d(5), a()()()), t & 2) {
        let e = c.$implicit,
            o = s(5);
        n(3), h(e.type == null ? null : e.type.name), n(), l("routerLink", un("/jobs/", o.job.id, "/deliveryReceipts/", e.id, "/")), n(), S(" ", o.formatMessage("button_view_receipt"), " ")
    }
}

function F_(t, c) {
    if (t & 1 && (r(0, "tr")(1, "td", 33), d(2), a(), r(3, "td"), X(4, U_, 6, 5, "ul", 51, He), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("deliveries")), n(2), Z(e.job == null ? null : e.job.deliveries)
    }
}

function q_(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 30)(2, "div", 31)(3, "table", 49)(4, "tbody")(5, "tr")(6, "td", 33), d(7), a(), r(8, "td")(9, "a", 50), d(10), a()()(), r(11, "tr")(12, "td", 33), d(13), a(), r(14, "td")(15, "a", 50), m(16, J_, 1, 1)(17, L_, 1, 1), d(18), a()()(), r(19, "tr")(20, "td", 33), d(21), a(), r(22, "td")(23, "a", 50), m(24, B_, 1, 1)(25, R_, 1, 1), d(26), a()()(), m(27, F_, 6, 1, "tr"), a()()()()()), t & 2) {
        let e = s(3);
        n(7), S(" ", e.formatMessage("job_sheet_label"), " "), n(2), l("routerLink", Ve("/jobs/", e.job.id, "/jobSheets")), n(), S(" ", e.formatMessage("view_job_sheet"), " "), n(3), h(e.formatMessage("quotation_with")), n(2), l("routerLink", Ve("/jobs/", e.job.id, "/quotations")), n(), _(e.isEmployee && !(!(e.job == null || e.job.quotation == null) && e.job.quotation.id) && e.authorizationService.canAccess(e.ENTITIES.QUOTATION) && e.userPermissionList.includes(e.PERMISSION_LIST.QUOTATION_WRITE) ? 16 : 17), n(2), S(" ", e.formatMessage("quotation_title"), " "), n(3), h(e.formatMessage("job_label_invoice")), n(2), l("routerLink", Ve("/jobs/", e.job.id, "/invoices")), n(), _(e.isEmployee && !(e.job.invoice != null && e.job.invoice.id) && e.authorizationService.canAccess(e.ENTITIES.JOB_INVOICE) ? 24 : 25), n(2), S(" ", e.formatMessage("invoice_number"), " "), n(), _((e.job == null ? null : e.job.deliveries.length) != 0 ? 27 : -1)
    }
}

function G_(t, c) {
    if (t & 1 && (r(0, "dx-accordion", 21), E(1, g_, 3, 1, "div", 27)(2, V_, 29, 20, "div", 28)(3, N_, 4, 2, "div", 28)(4, A_, 2, 2, "div", 28)(5, q_, 28, 15, "div", 28), a()), t & 2) {
        let e = s(2);
        l("collapsible", !0)("dataSource", e.accordionData)("multiple", !0)("selectedItem", e.openedItems), n(), l("dxTemplateOf", "title"), n(), l("dxTemplateOf", "job"), n(), l("dxTemplateOf", "parts_and_services"), n(), l("dxTemplateOf", "payments"), n(), l("dxTemplateOf", "documents")
    }
}

function W_(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 3)(1, "div", 4)(2, "div", 5), u(3, "app-job-status-tag", 6), r(4, "div", 7), d(5), a()(), r(6, "div", 8)(7, "app-dx-outline-button", 9), f("onClickEvent", function() {
            C(e);
            let i = s();
            return v(i.onClosePanel())
        }), a()()(), r(8, "div", 10)(9, "div", 11), m(10, c_, 1, 4, "app-user-badge", 12), r(11, "div", 13)(12, "h4", 14), d(13), a(), r(14, "div", 15), m(15, u_, 4, 1, "div", 16), m(16, b_, 4, 1, "div", 16), a()()()(), r(17, "div", 17)(18, "app-job-context-menu", 18), f("jobContextMenuOnAction", function(i) {
            C(e);
            let p = s();
            return v(p.onJobContextMenuAction(i))
        }), a(), r(19, "app-dx-outline-button", 19), f("onClickEvent", function() {
            C(e);
            let i = s();
            return v(i.onJobDetailClick())
        }), a()()(), r(20, "div", 20), m(21, G_, 6, 9, "dx-accordion", 21), a()
    }
    if (t & 2) {
        let e = s();
        n(3), l("iconType", e.statusIconTypeList.TITLE)("status", e.job == null ? null : e.job.status), n(2), S(" ", e.job.job_number, " "), n(2), l("isVisibleIcon", !0), n(3), _(e.job.user ? 10 : -1), n(3), h(e.job == null || e.job.user == null ? null : e.job.user.name), n(2), _(!(e.job == null || e.job.user == null) && e.job.user.email ? 15 : -1), n(), _(!(e.job == null || e.job.user == null) && e.job.user.mobile_number ? 16 : -1), n(2), l("job", e.job), n(), l("isVisibleIcon", !0), n(2), _(e.job && e.accordionData ? 21 : -1)
    }
}
var cl = (() => {
    class t {
        constructor() {
            this.isOpened = !1, this.entityType = I.JOB.name, this.isOpenedChange = new J, this.pinnedChange = new J, this.userSessionService = b(L), this.tenantService = b(ve), this.router = b(G), this.service = b(U), this.authorizationService = b(ki), this.themeService = b(br), this.isDarkTheme = this.themeService.isDarkTheme(), this.plan = this.tenantService.plan(), this.isEmployee = this.userSessionService.isEmployee(), this.pinned = !1, this.isLoading = !0, this.isEditing = !1, this.job = null, this.isEditMode = !0, this.isJobView = !0, this.tabs = [], this.formatMessage = g, this.selectedTabIndex = null, this.userPermissionList = this.userSessionService.userPermissionList(), this.PERMISSION_LIST = M, this.statusIconTypeList = he, this.ENTITIES = I, this.iconSizes = Pi, this.JSON = JSON, this.USER_TYPES = wi, this.quotationStatuses = Ei, this.accordionData = [{
                title: "Job Overview",
                template: "job"
            }, {
                title: "Documents",
                template: "documents"
            }, {
                title: "Parts & Services",
                template: "parts_and_services"
            }, {
                title: "Payments",
                template: "payments"
            }], this.openedItems = this.accordionData[0], this.loadJobById = e => {
                this.isLoading = !0, this.service.getOverviewById(e).subscribe(o => {
                    this.job = o, this.isLoading = !1
                })
            }, this.onClosePanel = () => {
                this.isOpened = !1, this.pinned = !1, this.isOpenedChange.emit(this.isOpened)
            }
        }
        ngOnInit() {
            this.tabs = [{
                id: 1,
                text: g("common_details"),
                path: `/jobs/${this.jobId}/overview`,
                icon: qn.INFO.light,
                visible: !0
            }, {
                id: 2,
                text: g("comments"),
                path: `/jobs/${this.jobId}/comments`,
                icon: Ot.COMMENT.light,
                visible: !0
            }, {
                id: 3,
                text: g("payment"),
                path: `/jobs/${this.jobId}/payments`,
                icon: Oi.PAYMENT_TYPE.light,
                visible: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_TAB)
            }, {
                id: 4,
                text: g("job_delivery"),
                path: `/jobs/${this.jobId}/deliveries`,
                icon: be.TRUCK.light,
                visible: !0
            }, {
                id: 5,
                text: g("job_services_and_parts"),
                path: `/jobs/${this.jobId}/servicesAndParts`,
                icon: yt.SERVICE.light,
                visible: !0
            }, {
                id: 6,
                text: g("job_backups"),
                path: `/jobs/${this.jobId}/backups`,
                icon: yt.RECOVERY.light,
                visible: !1
            }, {
                id: 7,
                text: g("job_private_notes"),
                path: `/jobs/${this.jobId}/notes`,
                icon: be.STICKY_NOTE.light,
                visible: this.isEmployee
            }, {
                id: 8,
                text: g("job_pickup_drop"),
                path: `/jobs/${this.jobId}/pickupDrop`,
                icon: be.PERSON_CARRY_BOX.light,
                disabled: [Le.LITE].includes(this.plan),
                visible: this.isEmployee
            }]
        }
        ngOnChanges(e) {
            let {
                jobId: o
            } = e;
            o ? .currentValue && this.loadJobById(o.currentValue)
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex, this.router.navigate([e.itemData.path])
        }
        onJobContextMenuAction(e) {
            this.job = e
        }
        onJobDetailClick() {
            this.router.navigate(["/jobs", this.jobId, "overview"])
        }
        isOlderThanAWeek(e) {
            return e >= 10080 * 60
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-panel"]
                ],
                inputs: {
                    isOpened: "isOpened",
                    jobId: "jobId"
                },
                outputs: {
                    isOpenedChange: "isOpenedChange",
                    pinnedChange: "pinnedChange"
                },
                standalone: !1,
                features: [Yt],
                decls: 5,
                vars: 10,
                consts: [
                    [1, "panel", 3, "ngClass"],
                    [1, "data-wrapper"],
                    ["container", ".panel", 3, "position", "showPane", "visible", "width"],
                    [1, "panel-header", "px-4", "mb-4"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mt-1", "pt-2"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "mt-1", 3, "iconType", "status"],
                    [1, "fs-5", "font-bold", "mt-1"],
                    [1, "d-flex", "gap-2", "mt-1"],
                    ["buttonType", "default", "icon", "fa-thin fa-xmark", "title", "close_button", 3, "onClickEvent", "isVisibleIcon"],
                    [1, "customer-profile", "mt-4"],
                    [1, "d-flex", "align-items-start", "gap-4"],
                    [1, "customer-avatar", 3, "entity", "iconOnly", "size", "user"],
                    [1, "customer-details"],
                    [1, "customer-name"],
                    [1, "customer-contact-info"],
                    [1, "contact-item"],
                    [1, "action-buttons", "mt-3", "px-1", "mb-2"],
                    [3, "jobContextMenuOnAction", "job"],
                    ["buttonType", "primary", "icon", "fa-thin fa-square-info", "text", "job_details", "title", "job_details", 3, "onClickEvent", "isVisibleIcon"],
                    [1, "mt-4", "data-part", "px-4"],
                    [3, "collapsible", "dataSource", "multiple", "selectedItem"],
                    [1, "fas", "fa-envelope"],
                    [3, "permission"],
                    [1, "me-2", 3, "href"],
                    [3, "textToBeCopied"],
                    [1, "fas", "fa-phone"],
                    ["class", "accordion-title d-flex flex-row-reverse justify-content-between align-items-center theme-secondary-bg", 4, "dxTemplate", "dxTemplateOf"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "accordion-title", "d-flex", "flex-row-reverse", "justify-content-between", "align-items-center", "theme-secondary-bg"],
                    [1, "info-card"],
                    [1, "card-body"],
                    [1, "info-row", "border-bottom", "border-primary"],
                    [1, "info-label"],
                    [1, "info-value", "d-flex", "gap-1"],
                    [1, "assignee-avatar", 3, "size", "user"],
                    [1, "info-value", "highlight"],
                    [1, "badge", 3, "ngClass"],
                    [1, "info-value"],
                    [3, "status"],
                    [1, "highlight", "badge", "bg-success"],
                    [1, "highlight", "badge", "bg-danger"],
                    [1, "highlight", "badge", 3, "ngClass"],
                    [1, "info-card", "mt-2"],
                    [3, "isEditMode", "isJobView", "isOnAside", "repairableId", "repairableType", 4, "ngxPermissionsOnly"],
                    [3, "isEditMode", "isJobView", "isOnAside", "partableId", "partableType", 4, "ngxPermissionsOnly"],
                    [3, "isEditMode", "isJobView", "isOnAside", "repairableId", "repairableType"],
                    [3, "isEditMode", "isJobView", "isOnAside", "partableId", "partableType"],
                    [3, "isOnAside", "jobId"],
                    [1, "table", "table-bordered", "theme-secondary-bg"],
                    [3, "routerLink"],
                    [1, "mb-0"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1)(2, "dx-scroll-view"), m(3, W_, 22, 11), a(), u(4, "dx-load-panel", 2), a()()), o & 2 && (l("ngClass", yi(6, s_, i.pinned, i.isOpened)), n(3), _(i.isLoading ? -1 : 3), n(), l("position", Ye(9, l_))("showPane", !1)("visible", i.isLoading)("width", 300))
                },
                dependencies: [Q, Se, _t, Wr, lo, $n, Yn, zn, oi, ge, At, W, ti, ye, Ti, Zt, cn, wo, oo, Ue, mt],
                styles: ["[_ngcontent-%COMP%]:root{--dx-component-color-bg: ;--dx-color-main-bg: ;--dx-color-primary: ;--dx-color-danger: #f44336;--dx-color-success: #8bc34a;--dx-color-warning: #ffc107;--dx-color-border: ;--dx-color-text: ;--dx-color-icon: ;--dx-color-spin-icon: ;--dx-color-link: ;--dx-color-shadow: ;--dx-color-separator: }[_ngcontent-%COMP%]:root{--dx-component-height: ;--dx-font-size: ;--dx-border-width: 1px;--dx-border-radius: ;--dx-font-size-icon: }[_nghost-%COMP%]{--contact-side-panel-width: 420px;--toolbar-vertical-padding: 16px;--toolbar-margin-bottom: 24px;--border-radius: 8px;--transition-speed: .3s;--panel-top-offset: 56px}.screen-x-small[_nghost-%COMP%], .screen-x-small   [_nghost-%COMP%]{--contact-side-panel-width: 100vw;--panel-top-offset: 56px}.panel[_ngcontent-%COMP%]{position:fixed;right:calc(-1 * var(--contact-side-panel-width));top:var(--panel-top-offset);bottom:0;background:var(--primary-bg);transition:right .4s ease;z-index:1000}.panel.open[_ngcontent-%COMP%]{right:0;box-shadow:0 0 20px #0000001a}.panel.pin[_ngcontent-%COMP%]{position:fixed;transition:none;box-shadow:none;border-left:1px solid var(--border-color)}.panel.pin.open[_ngcontent-%COMP%]{position:relative;height:100%}.panel[_ngcontent-%COMP%]   .data-wrapper[_ngcontent-%COMP%]{padding-bottom:16px;height:100%;width:var(--contact-side-panel-width)}.panel[_ngcontent-%COMP%]   .panel-header[_ngcontent-%COMP%]{position:sticky;top:0;background:var(--primary-bg);z-index:10}.panel[_ngcontent-%COMP%]   .scroll-content[_ngcontent-%COMP%]{flex:1;overflow-y:auto}.customer-profile[_ngcontent-%COMP%]   .customer-details[_ngcontent-%COMP%]{flex:1}.customer-profile[_ngcontent-%COMP%]   .customer-name[_ngcontent-%COMP%]{margin:0 0 8px;font-weight:600;color:var(--text-primary)}.customer-profile[_ngcontent-%COMP%]   .customer-contact-info[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px}.customer-profile[_ngcontent-%COMP%]   .contact-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;color:var(--text-secondary)}.customer-profile[_ngcontent-%COMP%]   .contact-item[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{width:16px;text-align:center}.customer-profile[_ngcontent-%COMP%]   .quick-actions[_ngcontent-%COMP%]{display:flex;gap:12px;margin-top:16px}.customer-profile[_ngcontent-%COMP%]   .quick-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]{flex:1;padding:8px 12px;border-radius:var(--border-radius);border:none;display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;transition:all var(--transition-speed) ease;font-weight:500}.customer-profile[_ngcontent-%COMP%]   .quick-actions[_ngcontent-%COMP%]   .action-btn.email[_ngcontent-%COMP%]{background:var(--accent-color-light);color:var(--accent-color)}.customer-profile[_ngcontent-%COMP%]   .quick-actions[_ngcontent-%COMP%]   .action-btn.email[_ngcontent-%COMP%]:hover{background:var(--accent-color-light-hover)}.customer-profile[_ngcontent-%COMP%]   .quick-actions[_ngcontent-%COMP%]   .action-btn.call[_ngcontent-%COMP%]{background:var(--success-color-light);color:var(--success-color)}.customer-profile[_ngcontent-%COMP%]   .quick-actions[_ngcontent-%COMP%]   .action-btn.call[_ngcontent-%COMP%]:hover{background:var(--success-color-light-hover)}.accordion-title[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;cursor:pointer;transition:background-color var(--transition-speed) ease}.accordion-title[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{margin:0;font-weight:500}.accordion-title[_ngcontent-%COMP%]:hover{background-color:var(--hover-bg)}.accordion-title[_ngcontent-%COMP%]   .dx-accordion-item-title[_ngcontent-%COMP%]:before{color:#adff2f!important}.info-card[_ngcontent-%COMP%]{background:var(--card-bg);border-radius:var(--border-radius);box-shadow:0 2px 4px #0000000d;margin-bottom:12px;overflow:hidden}.info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]{padding:16px}.info-card[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border-light)}.info-card[_ngcontent-%COMP%]   .info-row.border-primary[_ngcontent-%COMP%]{border-bottom-color:#0d6efd66!important}.info-card[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]:last-child{border-bottom:none}.info-card[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{color:var(--text-secondary);font-size:.68rem}.info-card[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{color:var(--text-primary);font-weight:500}.info-card[_ngcontent-%COMP%]   .info-value.highlight[_ngcontent-%COMP%]{color:var(--accent-color);font-weight:600}.section-divider[_ngcontent-%COMP%]{border:none;border-top:1px solid var(--border-color);margin:12px 0}.action-buttons[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;padding:7px 0}.tabs-section[_ngcontent-%COMP%]{padding:0 16px}.tabs-section[_ngcontent-%COMP%]   .custom-tabs[_ngcontent-%COMP%]   .dx-tab[_ngcontent-%COMP%]{padding:12px 16px;font-weight:500;color:var(--text-secondary)}.tabs-section[_ngcontent-%COMP%]   .custom-tabs[_ngcontent-%COMP%]   .dx-tab.dx-tab-selected[_ngcontent-%COMP%]{color:var(--accent-color);border-bottom:2px solid var(--accent-color)}.tabs-section[_ngcontent-%COMP%]   .custom-tabs[_ngcontent-%COMP%]   .dx-tab[_ngcontent-%COMP%]:hover{color:var(--text-primary)}.tabs-section[_ngcontent-%COMP%]   .tab-content[_ngcontent-%COMP%]{padding:16px 0}"]
            })
        }
    }
    return t
})();
var Q_ = (t, c, e) => [t, c, e],
    z_ = t => ({
        "max-height": t,
        "overflow-y": "auto"
    }),
    Oo = t => ({
        "background-color": t
    }),
    pl = t => ({
        color: t
    });

function Y_(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-empty-state", 6), f("primaryButtonClick", function() {
            C(e);
            let i = s();
            return v(i.onCreateJobFromEmptyState())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("icon", "dx-icon-box")("title", e.formatMessage("empty_state_job_title"))("description", e.formatMessage("empty_state_job_description"))("primaryButtonText", "empty_state_job_primary_button")("quickTipsVisible", !0)("quickTips", ot(9, Q_, e.formatMessage("empty_state_job_tip_1"), e.formatMessage("empty_state_job_tip_2"), e.formatMessage("empty_state_job_tip_3")))("tutorialText", e.formatMessage("empty_state_watch_tutorial"))("tutorialUrl", "https://www.youtube.com/watch?v=3-1Zc9AnXtg")("tutorialVisible", !0)
    }
}

function $_(t, c) {
    t & 1 && (r(0, "div", 7), u(1, "app-skeleton-loader", 17), a()), t & 2 && (n(), l("rows", 10)("columns", 3))
}

function K_(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "app-dx-outline-button", 18), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.clearAllFilters())
        }), a()()
    }
    t & 2 && (n(), l("isVisibleIcon", !0))
}

function X_(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "app-dx-outline-button", 19), f("onClickEvent", function() {
            C(e);
            let i = s(2);
            return v(i.scanJob())
        }), a()()
    }
    t & 2 && (n(), l("isVisibleIcon", !0))
}

function Z_(t, c) {
    if (t & 1 && u(0, "app-user-badge", 20), t & 2) {
        let e = s().$implicit,
            o = s(2);
        l("entity", o.ENTITIES.CUSTOMER)("iconOnly", !1)("user", e.value)
    }
}

function eu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, Z_, 1, 3, "app-user-badge", 20), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1)
    }
}

function tu(t, c) {
    if (t & 1 && (r(0, "div"), d(1), V(2, "mobileDisplay"), a()), t & 2) {
        let e = c.$implicit;
        n(), S(" ", B(2, 1, e.value, e.data == null || e.data.user == null ? null : e.data.user.mobile_country_code), " ")
    }
}

function iu(t, c) {
    if (t & 1 && (r(0, "div"), d(1), V(2, "timeDiff"), a()), t & 2) {
        let e = c.$implicit;
        n(), S(" ", ie(2, 1, e.value), " ")
    }
}

function nu(t, c) {
    if (t & 1 && u(0, "app-user-badge", 22), t & 2) {
        let e = s().$implicit,
            o = s(2);
        l("entity", o.ENTITIES.EMPLOYEE)("iconOnly", !1)("user", e.data.assigned_user)
    }
}

function ou(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 21), m(2, nu, 1, 3, "app-user-badge", 22), a()()), t & 2) {
        let e = c.$implicit;
        n(2), _(e.data.assigned_user ? 2 : -1)
    }
}

function au(t, c) {
    if (t & 1 && u(0, "app-user-badge", 25), t & 2) {
        let e = s(),
            o = e.$implicit,
            i = e.$index,
            p = s(4);
        mi("left", i * 16, "px"), l("entity", p.ENTITIES.EMPLOYEE)("iconOnly", !0)("user", o.assigned_user)
    }
}

function ru(t, c) {
    if (t & 1 && m(0, au, 1, 5, "app-user-badge", 24), t & 2) {
        let e = c.$implicit;
        _(e.assigned_user ? 0 : -1)
    }
}

function su(t, c) {
    if (t & 1 && X(0, ru, 1, 1, null, null, He), t & 2) {
        let e = s().$implicit;
        Z(e.data.repairables)
    }
}

function lu(t, c) {
    if (t & 1 && u(0, "app-user-badge", 22), t & 2) {
        let e = s(2).$implicit,
            o = s(2);
        l("entity", o.ENTITIES.EMPLOYEE)("iconOnly", !1)("user", e.data.assigned_user)
    }
}

function cu(t, c) {
    if (t & 1 && m(0, lu, 1, 3, "app-user-badge", 22), t & 2) {
        let e = s().$implicit;
        _(e.data.assigned_user ? 0 : -1)
    }
}

function du(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 23), m(2, su, 2, 0)(3, cu, 1, 1), a()()), t & 2) {
        let e = c.$implicit,
            o = s(2);
        n(2), _(o.hasAnyServiceAssignee(e.data.repairables) ? 2 : 3)
    }
}

function pu(t, c) {
    if (t & 1 && u(0, "app-user-badge", 20), t & 2) {
        let e = s().$implicit,
            o = s(2);
        l("entity", o.ENTITIES.OUTSOURCED_JOB)("iconOnly", !1)("user", e.value)
    }
}

function mu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, pu, 1, 3, "app-user-badge", 20), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1)
    }
}

function _u(t, c) {
    if (t & 1 && (r(0, "div"), u(1, "app-due-date-format", 26), a()), t & 2) {
        let e = c.$implicit,
            o = s(2);
        n(), l("dateTime", e.data.estimated_delivery)("entity", o.ENTITIES.JOB)("status", e.data.status)
    }
}

function uu(t, c) {
    if (t & 1 && u(0, "app-user-badge", 20), t & 2) {
        let e = s().$implicit,
            o = s(2);
        l("entity", o.ENTITIES.EMPLOYEE)("iconOnly", !1)("user", e.value)
    }
}

function Cu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, uu, 1, 3, "app-user-badge", 20), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1)
    }
}

function vu(t, c) {
    if (t & 1 && (r(0, "div"), u(1, "app-job-status-tag", 27), a()), t & 2) {
        let e = c.$implicit,
            o = s(2);
        n(), l("iconType", o.statusIconTypeList.BADGE_SMALL)("status", e.data.status)
    }
}

function fu(t, c) {
    if (t & 1 && (r(0, "span", 28), u(1, "i", 30), d(2), a()), t & 2) {
        let e = s(3);
        n(2), S("", e.formatMessage("common_yes"), " ")
    }
}

function hu(t, c) {
    if (t & 1 && (r(0, "span", 29), u(1, "i", 31), d(2), a()), t & 2) {
        let e = s(3);
        n(2), S("", e.formatMessage("common_no"), " ")
    }
}

function bu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, fu, 3, 1, "span", 28)(2, hu, 3, 1, "span", 29), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : 2)
    }
}

function gu(t, c) {
    if (t & 1 && (r(0, "div"), u(1, "app-payment-status", 32), a()), t & 2) {
        let e = c.$implicit;
        n(), l("status", e.value)
    }
}

function xu(t, c) {
    if (t & 1 && (r(0, "div")(1, "span"), d(2), r(3, "span"), d(4), a()()()), t & 2) {
        let e = s().$implicit;
        n(2), h(e.value), n(2), h(e.data == null ? null : e.data.capacity_measure)
    }
}

function Su(t, c) {
    if (t & 1 && (r(0, "div"), m(1, xu, 5, 2, "div"), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1)
    }
}

function yu(t, c) {
    t & 1 && u(0, "app-currency-symbol")
}

function Tu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, yu, 1, 0, "app-currency-symbol"), d(2), V(3, "number"), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1), n(), S(" ", B(3, 2, e.value, "1.2-2"), " ")
    }
}

function Mu(t, c) {
    t & 1 && u(0, "app-dx-outline-button", 34), t & 2 && l("isVisibleIcon", !0)
}

function Pu(t, c) {
    if (t & 1 && (r(0, "span", 50), d(1), a()), t & 2) {
        let e = s(5);
        n(), h(e.filterCount)
    }
}

function Iu(t, c) {
    if (t & 1 && (r(0, "div"), d(1), m(2, Pu, 2, 1, "span", 50), a()), t & 2) {
        let e = s(4);
        n(), S(" ", e.formatMessage("common_filters_all"), " "), n(), _(e.filterCount > 0 ? 2 : -1)
    }
}

function Eu(t, c) {
    t & 1 && (r(0, "dx-button", 35), E(1, Iu, 3, 2, "div", 14), a()), t & 2 && (n(), l("dxTemplateOf", "template"))
}

function wu(t, c) {
    if (t & 1 && (r(0, "div")(1, "div"), u(2, "i", 52), d(3), r(4, "span", 53), d(5), a()()()), t & 2) {
        let e = c.$implicit;
        n(3), S(" ", e.key, " "), n(), l("ngStyle", fe(3, Oo, e.hex_color)), n(), h(e.group_count)
    }
}

function Ou(t, c) {
    if (t & 1 && u(0, "i", 56), t & 2) {
        let e = s().$implicit;
        l("ngStyle", fe(1, pl, e && e.hex_color))
    }
}

function ju(t, c) {
    if (t & 1 && (r(0, "div")(1, "small", 54)(2, "div", 55), m(3, Ou, 1, 3, "i", 56), r(4, "span", 57), d(5), a()(), r(6, "div", 58), d(7), a()()()), t & 2) {
        let e = c.$implicit;
        n(3), _(e && e.hex_color ? 3 : -1), n(2), S(" ", e.name, " "), n(), l("ngStyle", fe(4, Oo, e.hex_color)), n(), S(" ", e.job_count, " ")
    }
}

function Vu(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 37)(1, "dx-tag-box", 51), f("onValueChanged", function(i) {
            C(e);
            let p = s(3);
            return v(p.statusChange(i))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.selectedStatusIds, i) || (p.selectedStatusIds = i), v(i)
        }), E(2, wu, 6, 5, "div", 14)(3, ju, 8, 6, "div", 14), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), w("ngModel", e.selectedStatusIds), l("acceptCustomValue", !1)("dataSource", e.statusDataSource)("grouped", !0)("maxDisplayedTags", 2)("multiline", !1)("ngClass", e.isMobileDevice ? "dropdown-filter" : "")("placeholder", e.formatMessage("job_status_placeholder"))("searchEnabled", !0)("showMultiTagOnly", !1)("showSelectionControls", !0)("width", e.isMobileDevice ? 243 : 229), n(), l("dxTemplateOf", "group"), n(), l("dxTemplateOf", "item")
    }
}

function Du(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 37)(1, "app-employee-dropdown", 59), f("ngModelChange", function(i) {
            C(e);
            let p = s(3);
            return v(p.updatesOnAssigneeId(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), l("ngModel", e.assigneeId)
    }
}

function ku(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 37)(1, "dx-select-box", 60), f("onValueChanged", function() {
            C(e);
            let i = s(3);
            return v(i.filterOnValueChange("job"))
        }), j("valueChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.selectedAging, i) || (p.selectedAging = i), v(i)
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), w("value", e.selectedAging), l("items", e.agingOptions)("showClearButton", !0)("placeholder", e.formatMessage("open_since_placeholder"))
    }
}

function Nu(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 37)(1, "dx-select-box", 60), f("onValueChanged", function() {
            C(e);
            let i = s(3);
            return v(i.filterOnValueChange("job"))
        }), j("valueChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.selectedJobServiceType, i) || (p.selectedJobServiceType = i), v(i)
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), w("value", e.selectedJobServiceType), l("items", e.jobServiceTypeOptions)("showClearButton", !0)("placeholder", e.formatMessage("job_service_type_placeholder"))
    }
}

function Au(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 37)(1, "dx-select-box", 61), f("onValueChanged", function() {
            C(e);
            let i = s(3);
            return v(i.fetchJobs())
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.selectedTaxFilter, i) || (p.selectedTaxFilter = i), v(i)
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), w("ngModel", e.selectedTaxFilter), l("items", e.TAX_FILTER_LIST)("showClearButton", !0)("width", e.isMobileDevice ? 243 : "")("placeholder", e.formatMessage("filter_by_tax"))
    }
}

function Ju(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "div", 33), m(2, Mu, 1, 1, "app-dx-outline-button", 34)(3, Eu, 2, 1, "dx-button", 35), r(4, "div", 36), m(5, Vu, 4, 14, "div", 37), m(6, Du, 2, 1, "div", 37), r(7, "div", 37)(8, "dx-select-box", 38), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.selectedStatus, i) || (p.selectedStatus = i), v(i)
        }), a()(), m(9, ku, 2, 4, "div", 37), m(10, Nu, 2, 4, "div", 37), r(11, "div", 37)(12, "dx-select-box", 39), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.selectedModel, i) || (p.selectedModel = i), v(i)
        }), a()(), m(13, Au, 2, 5, "div", 37), r(14, "div", 37)(15, "app-user-type-dropdown", 40), f("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return v(p.updatesOnRoleId(i))
        }), a()(), r(16, "div", 37)(17, "app-priority-dropdown", 41), f("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return v(p.onPriorityDropdownChange(i))
        }), a()(), r(18, "div", 37)(19, "dx-select-box", 42), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.selectedJobType, i) || (p.selectedJobType = i), v(i)
        }), a()(), r(20, "div", 37)(21, "app-device-type-dropdown", 43), f("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return v(p.updatesOnDeviceTypeId(i))
        }), a()(), r(22, "div", 37)(23, "dx-select-box", 44), f("onItemClick", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.deviceBrandId, i) || (p.deviceBrandId = i), v(i)
        }), a()(), r(24, "dx-tag-box", 45), f("onValueChanged", function(i) {
            C(e);
            let p = s(2);
            return v(p.repairServiceChange(i))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.selectedRepairServicesId, i) || (p.selectedRepairServicesId = i), v(i)
        }), a(), r(25, "div", 37)(26, "dx-date-box", 46), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("valueChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.fromDate, i) || (p.fromDate = i), v(i)
        }), a()(), r(27, "div", 37)(28, "dx-date-box", 47), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("valueChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.toDate, i) || (p.toDate = i), v(i)
        }), a()(), r(29, "div", 37)(30, "dx-select-box", 48), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.selectedArchiveStatus, i) || (p.selectedArchiveStatus = i), v(i)
        }), a()(), r(31, "div", 37)(32, "dx-select-box", 49), f("onValueChanged", function() {
            C(e);
            let i = s(2);
            return v(i.filterOnValueChange("job"))
        }), j("valueChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.closedWithoutInvoice, i) || (p.closedWithoutInvoice = i), v(i)
        }), a()()()()()
    }
    if (t & 2) {
        let e = s(2);
        n(2), _(e.isMobileDevice ? 2 : 3), n(2), l("ngStyle", fe(59, z_, e.isMobileDevice ? "50vh" : "60vh")), n(), _(e.isMobileDevice ? 5 : -1), n(), _(e.isMobileDevice ? 6 : -1), n(2), w("ngModel", e.selectedStatus), l("items", e.paymentStatusList)("placeholder", e.formatMessage("payment_status_placeholder"))("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), n(), _(e.isEmployee ? 9 : -1), n(), _(e.serviceOptions.length === 2 ? 10 : -1), n(2), w("ngModel", e.selectedModel), l("items", e.modelList)("placeholder", e.formatMessage("model_title"))("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), n(), _(e.isIndia ? 13 : -1), n(2), l("ngModel", e.roleId)("isFilter", !0), n(2), l("ngModel", e.priorityId)("isFilter", !0), n(2), w("ngModel", e.selectedJobType), l("items", e.jobTypeList)("placeholder", e.formatMessage("job_type_placeholder"))("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), n(2), l("ngModel", e.deviceTypeId)("isFilter", !0)("placeholder", e.formatMessage("device_type_placeholder_2")), n(2), w("ngModel", e.deviceBrandId), l("items", e.deviceBrandList)("placeholder", e.formatMessage("device_brand_placeholder_2"))("searchEnabled", !0)("showClearButton", !0), n(), w("ngModel", e.selectedRepairServicesId), l("acceptCustomValue", !1)("items", e.deviceTypeRepairServicesList)("placeholder", e.formatMessage("job_services_placeholder"))("showSelectionControls", !0), n(2), w("value", e.fromDate), l("max", e.today)("placeholder", e.formatMessage("from"))("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), n(2), w("value", e.toDate), l("max", e.today)("placeholder", e.formatMessage("to"))("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), n(2), w("ngModel", e.selectedArchiveStatus), l("items", e.archiveStatusOptions)("showClearButton", !1)("width", e.isMobileDevice ? 243 : "")("placeholder", e.formatMessage("archive_status")), n(2), w("value", e.closedWithoutInvoice), l("items", e.closedWithoutInvoiceOptions)("showClearButton", !0)("placeholder", "Invoice Created")("width", e.isMobileDevice ? 243 : "")
    }
}

function Lu(t, c) {
    t & 1 && u(0, "app-currency-symbol")
}

function Bu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, Lu, 1, 0, "app-currency-symbol"), d(2), V(3, "number"), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1), n(), S(" ", B(3, 2, e.value, "1.2-2"), " ")
    }
}

function Ru(t, c) {
    t & 1 && u(0, "app-currency-symbol")
}

function Uu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, Ru, 1, 0, "app-currency-symbol"), d(2), V(3, "number"), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.value ? 1 : -1), n(), S(" ", B(3, 2, e.value, "1.2-2"), " ")
    }
}

function Fu(t, c) {
    if (t & 1 && (r(0, "div")(1, "a", 62), d(2), a()()), t & 2) {
        let e = c.$implicit;
        n(), l("routerLink", Ve("/jobs/", e.data.id)), n(), h(e.data.job_number)
    }
}

function qu(t, c) {
    if (t & 1 && (r(0, "div"), d(1), V(2, "objToString"), a()), t & 2) {
        let e = c.$implicit;
        n(), S(" ", ie(2, 1, e.value), " ")
    }
}

function Gu(t, c) {
    if (t & 1 && (r(0, "div"), d(1), V(2, "dateFormat"), a()), t & 2) {
        let e = c.$implicit;
        n(), S(" ", B(2, 1, e.value, "datetime"), " ")
    }
}

function Wu(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-drop-down-button", 65), f("onItemClick", function(i) {
            C(e);
            let p = s(3);
            return v(p.onServiceOptionClick(i))
        }), a()
    }
    if (t & 2) {
        let e = s(3);
        l("items", e.serviceOptions)
    }
}

function Hu(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 67), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.routerHelperService.navigateAddRecoveryJob())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("hint", e.SERVICE_BUTTON_TEXT.RECOVERY_SERVICE)
    }
}

function Qu(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 67), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.routerHelperService.navigateAddRepairJob())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("hint", e.SERVICE_BUTTON_TEXT.REPAIR_SERVICE)
    }
}

function zu(t, c) {
    if (t & 1 && (m(0, Hu, 1, 1, "dx-button", 66), m(1, Qu, 1, 1, "dx-button", 66)), t & 2) {
        let e = s(3);
        _(e.jobDataService.isRecoveryJob ? 0 : -1), n(), _(e.jobDataService.isRepairJob ? 1 : -1)
    }
}

function Yu(t, c) {
    if (t & 1 && (r(0, "div", 63), m(1, Wu, 1, 1, "dx-drop-down-button", 64)(2, zu, 2, 2), a()), t & 2) {
        let e = s(2);
        n(), _(e.serviceOptions.length >= 2 ? 1 : 2)
    }
}

function $u(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "i", 70), f("click", function() {
            C(e);
            let i = s().$implicit,
                p = s(2);
            return v(p.openArchivedActionsPopup(i.data))
        }), a()
    }
    if (t & 2) {
        let e = s(3);
        l("title", e.formatMessage("archived_record_actions"))
    }
}

function Ku(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-job-context-menu", 71), f("jobContextMenuOnAction", function() {
            C(e);
            let i = s(3);
            return v(i.onJobContextMenuAction())
        }), a()
    }
    if (t & 2) {
        let e = s().$implicit;
        l("isIconOnly", !0)("job", e.data)
    }
}

function Xu(t, c) {
    if (t & 1 && (r(0, "div"), m(1, $u, 1, 1, "i", 68)(2, Ku, 1, 2, "app-job-context-menu", 69), a()), t & 2) {
        let e = c.$implicit;
        n(), _(e.data.deleted_at ? 1 : 2)
    }
}

function Zu(t, c) {
    if (t & 1 && (r(0, "div")(1, "span", 72), d(2), a()()), t & 2) {
        let e = s(2);
        n(), l("ngClass", e.isMobileDevice ? "h5" : "h4"), n(), h(e.formatMessage(e.entity.translationName))
    }
}

function e0(t, c) {
    if (t & 1 && (r(0, "div")(1, "div"), u(2, "i", 52), d(3), r(4, "span", 53), d(5), a()()()), t & 2) {
        let e = c.$implicit;
        n(3), S(" ", e.key, " "), n(), l("ngStyle", fe(3, Oo, e.hex_color)), n(), h(e.group_count)
    }
}

function t0(t, c) {
    if (t & 1 && u(0, "i", 56), t & 2) {
        let e = s().$implicit;
        l("ngStyle", fe(1, pl, e && e.hex_color))
    }
}

function i0(t, c) {
    if (t & 1 && (r(0, "div")(1, "small", 54)(2, "div", 55), m(3, t0, 1, 3, "i", 56), r(4, "span", 57), d(5), a()(), r(6, "div", 58), d(7), a()()()), t & 2) {
        let e = c.$implicit;
        n(3), _(e && e.hex_color ? 3 : -1), n(2), S(" ", e.name, " "), n(), l("ngStyle", fe(4, Oo, e.hex_color)), n(), S(" ", e.job_count, " ")
    }
}

function n0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 73)(1, "dx-tag-box", 74), f("onValueChanged", function(i) {
            C(e);
            let p = s(2);
            return v(p.statusChange(i))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.selectedStatusIds, i) || (p.selectedStatusIds = i), v(i)
        }), E(2, e0, 6, 5, "div", 14)(3, i0, 8, 6, "div", 14), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), w("ngModel", e.selectedStatusIds), l("acceptCustomValue", !1)("dataSource", e.statusDataSource)("grouped", !0)("maxDisplayedTags", 2)("multiline", !1)("placeholder", e.formatMessage("job_status_placeholder"))("searchEnabled", !0)("showMultiTagOnly", !1)("showSelectionControls", !0)("width", e.isMobileDevice ? 243 : 225), n(), l("dxTemplateOf", "group"), n(), l("dxTemplateOf", "item")
    }
}

function o0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "app-employee-dropdown", 59), f("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return v(p.updatesOnAssigneeId(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("ngModel", e.assigneeId)
    }
}

function a0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 1), m(1, $_, 2, 2, "div", 7), r(2, "dx-data-grid", 8), f("onRowClick", function(i) {
            C(e);
            let p = s();
            return v(p.isMobileDevice ? p.routerHelperService.onRowClick(i, p.entity) : p.onRowClick(i))
        })("onCellClick", function(i) {
            C(e);
            let p = s();
            return v(!p.isMobileDevice && p.onCellClick(i))
        })("onToolbarPreparing", function(i) {
            C(e);
            let p = s();
            return v(p.onToolbarPreparing(i))
        }), u(3, "dxo-state-storing", 9)(4, "dxo-load-panel", 10), r(5, "dxo-column-chooser", 11), u(6, "dxo-selection", 12), a(), r(7, "dxo-search-panel", 13), j("textChange", function(i) {
            C(e);
            let p = s();
            return O(p.searchText, i) || (p.searchText = i), v(i)
        }), a(), E(8, K_, 2, 1, "div", 14)(9, X_, 2, 1, "div", 14)(10, eu, 2, 1, "div", 14)(11, tu, 3, 4, "div", 14)(12, iu, 3, 3, "div", 14)(13, ou, 3, 1, "div", 14)(14, du, 4, 1, "div", 14)(15, mu, 2, 1, "div", 14)(16, _u, 2, 3, "div", 14)(17, Cu, 2, 1, "div", 14)(18, vu, 2, 2, "div", 14)(19, bu, 3, 1, "div", 14)(20, gu, 2, 1, "div", 14)(21, Su, 2, 1, "div", 14)(22, Tu, 4, 5, "div", 14)(23, Ju, 33, 61, "div", 14)(24, Bu, 4, 5, "div", 14)(25, Uu, 4, 5, "div", 14)(26, Fu, 3, 3, "div", 14)(27, qu, 3, 3, "div", 14)(28, Gu, 3, 4, "div", 14)(29, Yu, 3, 1, "div", 15)(30, Xu, 3, 1, "div", 14)(31, Zu, 3, 2, "div", 14)(32, n0, 4, 13, "div", 16)(33, o0, 2, 1, "div", 14), a()()
    }
    if (t & 2) {
        let e = s();
        n(), _(e.isLoading() ? 1 : -1), n(), l("columnAutoWidth", !e.isMobileDevice)("columns", e.columns)("dataSource", e.store)("width", "100%"), n(), l("customLoad", e.loadState)("customSave", e.saveState)("enabled", !0)("storageKey", e.entity.name), n(), l("enabled", !e.isMobileDevice)("indicatorSrc", e.loaderLogo)("showPane", !1), n(), l("enabled", !0)("title", e.isMobileDevice ? e.formatMessage("column_chooser_label") : e.formatMessage("sale_column_chooser_title"))("width", e.isMobileDevice ? 250 : 350), n(), l("allowSelectAll", !1)("recursive", !0)("selectByClick", !0), n(), w("text", e.searchText), l("placeholder", e.formatMessage(e.entity.translationString))("visible", !0)("width", e.searchPanelWidth), n(), l("dxTemplateOf", "clearAllFilters"), n(), l("dxTemplateOf", "scanBarcode"), n(), l("dxTemplateOf", "userTemplate"), n(), l("dxTemplateOf", "mobileNumberTemplate"), n(), l("dxTemplateOf", "ageTemplate"), n(), l("dxTemplateOf", "jobAssigneeTemplate"), n(), l("dxTemplateOf", "serviceAssigneeTemplate"), n(), l("dxTemplateOf", "outsourceVendorTemplate"), n(), l("dxTemplateOf", "dueDateTemplate"), n(), l("dxTemplateOf", "employeeTemplate"), n(), l("dxTemplateOf", "statusTemplate"), n(), l("dxTemplateOf", "diagnosisTemplate"), n(), l("dxTemplateOf", "paymentStatusTemplate"), n(), l("dxTemplateOf", "sizeTemplate"), n(), l("dxTemplateOf", "paymentReceivedTemplate"), n(), l("dxTemplateOf", "allFilters"), n(), l("dxTemplateOf", "paymentRemainingTemplate"), n(), l("dxTemplateOf", "paymentReceivedTemplate"), n(), l("dxTemplateOf", "idTemplate"), n(), l("dxTemplateOf", "repairableTemplate"), n(), l("dxTemplateOf", "dateTimeTemplate"), n(), l("dxTemplateOf", "addBtnTemplate"), n(), l("dxTemplateOf", "actionTemplate"), n(), l("dxTemplateOf", "tableHeaderTemplate"), n(), l("dxTemplateOf", "filterByStatusTemplate"), n(), l("dxTemplateOf", "filterByAssigneeTemplate")
    }
}

function r0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-job-panel", 75), j("isOpenedChange", function(i) {
            C(e);
            let p = s();
            return O(p.isPanelOpened, i) || (p.isPanelOpened = i), v(i)
        }), f("isOpenedChange", function(i) {
            C(e);
            let p = s();
            return v(p.onOpenedChange(i))
        })("pinnedChange", function() {
            C(e);
            let i = s();
            return v(i.onPinnedChange())
        }), a()
    }
    if (t & 2) {
        let e = s();
        w("isOpened", e.isPanelOpened), l("jobId", e.selectedJobId)
    }
}

function s0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-export-option-pop-up", 76), f("ClosePopupClick", function() {
            C(e);
            let i = s();
            return v(i.closeExportPopUp())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("assigneeId", e.employeeId)("customerId", e.customerId)("entity", e.entity)("isVisiblePopup", e.isVisibleExportPopUp)("jobTypeList", e.jobTypeList)("modelList", e.modelList)("service", e.service)("statusDataSource", e.statusDataSource)
    }
}

function l0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-qrcode-scanner", 77), f("scannerToSave", function(i) {
            C(e);
            let p = s();
            return v(p.getJobFromBarcode(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleBarcodeScannerPopUp)("type", "job")
    }
}

function c0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-archive-delete-popup", 78), j("isVisibleChange", function(i) {
            C(e);
            let p = s();
            return O(p.isVisibleArchiveDeletePopup, i) || (p.isVisibleArchiveDeletePopup = i), v(i)
        }), f("onSuccess", function(i) {
            C(e);
            let p = s();
            return v(p.handleArchiveDeleteSuccess(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        w("isVisible", e.isVisibleArchiveDeletePopup), l("service", e.service)("entity", e.selectedArchivedJob)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("entityNumberField", "job_number")("mode", e.archiveDeleteMode())
    }
}
var jo = (() => {
    class t {
        get hasTenantJobs() {
            return (this.tenantService.config() ? .entity_counts ? .jobs || 0) > 0
        }
        constructor(e) {
            this.service = e, this.formatMessage = g, this.assignedOnly = !1, this.routerHelperService = b(Hn), this.filterPersistService = b(Pr), this.dataGridStatePersistService = b(Ir), this.jobDataService = b(_o), this.dataGridService = b(Er), this.router = b(G), this.dataService = b(qe), this.userSessionService = b(L), this.tenantService = b(ve), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.SETTINGS = F, this.generalSettingDataService = b(te), this.toastNotificationService = b(D), this.refreshService = b(ll), this.destroyRef = b(Nn), this.guidedTourService = b(_s), this.today = new Date, this.serviceOptions = [...ni.getServiceOptionFromConfig(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SERVICE_OPTION)), ...this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.GENERAL_SETTINGS.ENABLE_BULK_JOB) ? [fn.BULK_JOB] : []], this.SERVICE_BUTTON_TEXT = fn, this.TAX_FILTER_LIST = qa, this.isIndia = this.tenantService.isIndia(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = I, this.customerId = null, this.deviceTypeId = null, this.deviceBrandId = null, this.employeeId = null, this.roleId = null, this.selectedStatusIds = [], this.selectedRepairServicesId = [], this.deviceBrandList = [], this.allDeviceBrandList = [], this.allRepairServicesList = [], this.deviceTypeRepairServicesList = [], this.assigneeId = null, this.priorityId = null, this.fromDate = null, this.toDate = null, this.selectedStatus = null, this.selectedJobType = null, this.selectedModel = null, this.selectedTaxFilter = null, this.entity = I.JOB, this.isPanelOpened = !1, this.selectedJobId = null, this.statusIconTypeList = he, this.searchPanelWidth = this.isMobileDevice && this.entity.searchPanelWidth ? this.entity.searchPanelWidth : 200, this.columns = [], this.paymentStatusList = Object.values(Fn), this.jobTypeList = [], this.modelList = [], this.isOpenJobsOnly = !0, this.isClosedJobsOnly = !1, this.closedWithoutInvoice = null, this.closedWithoutInvoiceOptions = [{
                label: "Invoice Not Created",
                value: !0
            }], this.isVisibleExportPopUp = !1, this.isVisibleBarcodeScannerPopUp = !1, this.filterStorageKey = "", this.agingOptions = [{
                label: "0\u20132 Days",
                value: "0-2"
            }, {
                label: "3\u20137 Days",
                value: "3-7"
            }, {
                label: "8\u201314 Days",
                value: "8-14"
            }, {
                label: "15\u201330 Days",
                value: "15-30"
            }, {
                label: ">30 Days",
                value: "30+"
            }], this.selectedAging = null, this.jobServiceTypeOptions = [{
                label: "Recovery Jobs",
                value: !0
            }, {
                label: "Repair Jobs",
                value: !1
            }], this.selectedJobServiceType = null, this.archiveStatusOptions = [{
                label: "Active",
                value: "active"
            }, {
                label: "All",
                value: "all"
            }, {
                label: "Archived",
                value: "archived"
            }], this.selectedArchiveStatus = "active", this.isLastColumnClicked = Y(!1), this.actionableDashboardTodayFilter = Y(null), this.isVisibleArchiveDeletePopup = Y(!1), this.archiveDeleteMode = Y("archived-actions"), this.selectedArchivedJob = null, this.isLoading = Y(!0), this.hasData = Y(!1), this.totalCount = 0, this.loaderLogo = ei, this.event = event, this.loadState = () => this.dataGridStatePersistService.createLoadStateCallback(this.entity.name, this.filterPersistService)(), this.saveState = o => {
                this.dataGridStatePersistService.createSaveStateCallback(this.entity.name)(o)
            }, this.onOpenedChange = o => {
                o || (this.selectedJobId = null)
            }, this.onPinnedChange = () => {
                this.dataGrid.instance.updateDimensions()
            }, this.filterStorageKey = this.entity.name + "_filters"
        }
        get storageKey() {
            return this.entity.name
        }
        statusChange(e) {
            this.selectedStatusIds = e.value, this.fetchJobs()
        }
        repairServiceChange(e) {
            this.selectedRepairServicesId = e.value, this.fetchJobs()
        }
        onToolbarPreparing(e) {
            if (e.component.option("multiline", !0), e.toolbarOptions.items.push({
                    template: "tableHeaderTemplate",
                    location: "before",
                    locateInMenu: "never"
                }, {
                    template: "filterByStatusTemplate",
                    location: "after",
                    options: {
                        elementAttr: {
                            id: "jobStatusDropdown"
                        }
                    },
                    locateInMenu: "auto",
                    visible: !this.isMobileDevice
                }, {
                    template: "filterByAssigneeTemplate",
                    location: "after",
                    locateInMenu: "auto",
                    visible: this.isEmployee && !this.assignedOnly && !this.employeeId && !this.isMobileDevice
                }, {
                    template: "allFilters",
                    location: "after",
                    locateInMenu: "never",
                    visible: this.isEmployee
                }, ...this.isMobileDevice ? [{
                    location: "after",
                    locateInMenu: "always",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-line-columns",
                        hint: g("column_chooser_label"),
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => this.dataGrid.instance.showColumnChooser()
                    },
                    visible: !0
                }, {
                    location: "after",
                    locateInMenu: "always",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-filter-circle-xmark",
                        hint: g("clear_all_filters"),
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => this.clearAllFilters()
                    },
                    visible: this.isEmployee
                }, {
                    location: "after",
                    locateInMenu: "always",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-barcode-read",
                        hint: g("scan_barcode_to_search_job"),
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => this.scanJob()
                    },
                    visible: this.isEmployee
                }] : [{
                    template: "clearAllFilters",
                    location: "after",
                    locateInMenu: "never",
                    visible: this.isEmployee
                }, {
                    template: "scanBarcode",
                    location: "after",
                    locateInMenu: "never",
                    visible: this.isEmployee
                }], {
                    location: "after",
                    locateInMenu: this.isMobileDevice ? "auto" : "never",
                    widget: "dxButton",
                    options: {
                        icon: Gn.EXCEL.light,
                        hint: "Export Jobs to Excel",
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => {
                            this.isVisibleExportPopUp = !0
                        }
                    },
                    visible: this.isEmployee && !this.isMobileDevice && this.userPermissionList.includes(M.JOB_EXPORT_EXL)
                }, {
                    location: "after",
                    locateInMenu: "never",
                    template: "addBtnTemplate",
                    visible: this.isEmployee && this.userPermissionList.includes(M.JOB_WRITE)
                }), this.dataGridService.arrangeToolbarItems(e.toolbarOptions.items), this.isMobileDevice) {
                let o = e.toolbarOptions.items.findIndex(i => i ? .name === "columnChooserButton");
                o !== -1 && (e.toolbarOptions.items[o].visible = !1)
            }
        }
        onCreateJobFromEmptyState() {
            this.routerHelperService.navigateAddRepairJob(), this.guidedTourService.runTourById("CREATE_JOB")
        }
        ngOnInit() {
            this.columns = [{
                dataField: "job_number",
                caption: g("job_sheet_label"),
                width: this.isMobileDevice ? 75 : 110,
                cellTemplate: "idTemplate",
                allowSorting: !0
            }, {
                dataField: "user",
                caption: g("user_customer"),
                width: this.isMobileDevice ? void 0 : 240,
                cellTemplate: "userTemplate",
                allowSorting: !1
            }, {
                dataField: "user.mobile_number",
                caption: g("common_mobile_number"),
                hidingPriority: 25,
                visible: !1,
                cellTemplate: "mobileNumberTemplate",
                allowSorting: !1
            }, {
                dataField: "vendor_job_id",
                caption: g("dealer_Job_id"),
                hidingPriority: 0,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "outsourced_job.vendor",
                caption: g("outsource_to"),
                hidingPriority: 20,
                visible: !1,
                allowSorting: !1,
                cellTemplate: "outsourceVendorTemplate"
            }, {
                dataField: "payment_received",
                caption: g("payment_received"),
                hidingPriority: 10,
                cellTemplate: "paymentReceivedTemplate",
                showInColumnChooser: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST),
                visible: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST),
                allowSorting: !1
            }, {
                dataField: "payment_remaining",
                caption: g("payment_remaining"),
                hidingPriority: 14,
                dataType: "number",
                showInColumnChooser: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST),
                cellTemplate: "paymentRemainingTemplate",
                visible: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST),
                allowSorting: !1
            }, {
                dataField: "payment_status",
                caption: g("payment_status"),
                hidingPriority: 13,
                cellTemplate: "paymentStatusTemplate",
                showInColumnChooser: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST),
                visible: this.userPermissionList.includes(M.JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST),
                allowSorting: !1
            }, {
                dataField: "priority.name",
                caption: g("task_priority_label"),
                hidingPriority: 9,
                visible: !1
            }, {
                dataField: "device_type.name",
                caption: g("device_type_name"),
                hidingPriority: 7,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "device_brand.name",
                caption: g("device_brand_name"),
                hidingPriority: 5,
                visible: !0,
                allowSorting: !1
            }, {
                dataField: "device_model.name",
                caption: g("device_model_name"),
                hidingPriority: 6,
                visible: !0,
                allowSorting: !1
            }, {
                dataField: "serial_number",
                caption: g("device_serial_number"),
                hidingPriority: 17,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "repairables",
                caption: g("job_services"),
                cellTemplate: "repairableTemplate",
                hidingPriority: 8,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "size",
                caption: g("job_label_capacity"),
                hidingPriority: 15,
                visible: !1,
                cellTemplate: "sizeTemplate",
                allowSorting: !1
            }, {
                dataField: "assigned_user",
                caption: g("job_assignee"),
                hidingPriority: 11,
                cellTemplate: "jobAssigneeTemplate",
                visible: this.isEmployee,
                showInColumnChooser: this.isEmployee,
                allowSorting: !1
            }, {
                dataField: "repairables.assigned_user",
                caption: g("job_service_assignee"),
                hidingPriority: 23,
                cellTemplate: "serviceAssigneeTemplate",
                visible: this.isEmployee,
                showInColumnChooser: this.isEmployee,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: g("common_created_by"),
                hidingPriority: 1,
                cellTemplate: "employeeTemplate",
                visible: !1,
                showInColumnChooser: this.isEmployee,
                allowSorting: !1
            }, {
                dataField: "estimated_delivery",
                caption: g("common_due_date"),
                cellTemplate: "dueDateTemplate",
                width: 155,
                hidingPriority: 4,
                allowSorting: !0,
                visible: !this.isEmployee
            }, {
                dataField: "created_at",
                caption: g("common_created_on"),
                hidingPriority: 2,
                visible: !1,
                allowSorting: !0,
                width: 155,
                cellTemplate: "dateTimeTemplate"
            }, {
                dataField: "updated_at",
                caption: g("common_updated_on"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !0,
                width: 155,
                cellTemplate: "dateTimeTemplate"
            }, {
                dataField: "delivered_at",
                caption: g("delivered_on"),
                hidingPriority: 12,
                visible: !1,
                allowSorting: !1,
                width: 155,
                cellTemplate: "dateTimeTemplate"
            }, {
                dataField: "status",
                caption: g("common_status"),
                cellTemplate: "statusTemplate",
                hidingPriority: 16,
                visible: !0,
                allowSorting: !1
            }, {
                dataField: "has_diagnosis",
                caption: g("job_diagnosis"),
                cellTemplate: "diagnosisTemplate",
                hidingPriority: 24,
                visible: !1,
                width: 100,
                allowSorting: !1
            }, {
                dataField: "type.name",
                caption: g("job_type"),
                hidingPriority: 18,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "service_type.name",
                caption: g("service_type"),
                hidingPriority: 21,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "source.name",
                caption: g("user_customer_source"),
                hidingPriority: 19,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "age_in_seconds",
                caption: g("age"),
                hidingPriority: 22,
                visible: !1,
                cellTemplate: "ageTemplate",
                allowSorting: !1
            }, {
                name: "actions",
                caption: "",
                width: 45,
                allowExporting: !1,
                showInColumnChooser: !1,
                cellTemplate: "actionTemplate",
                alignment: "center"
            }], ni.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice), this.isOpenJobsOnly = this.activatedRouter.snapshot.data.is_open_jobs_only, this.isClosedJobsOnly = this.activatedRouter.snapshot.data.is_closed_jobs_only, this.assignedOnly = this.activatedRouter.snapshot.data.assigned_only ? ? this.assignedOnly, this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.activatedRouter.queryParams.subscribe(e => {
                this.actionableDashboardTodayFilter.set(e.due_date || null)
            }), this.setSelectedJobIndex(), this.fetchJobs(), this.fetchStatuses(), this.fetchLookups(), this.getSavedFilterValues(), this.refreshService.refresh$.pipe(Mi(this.destroyRef)).subscribe(() => {
                this.fetchJobs()
            })
        }
        setSelectedJobIndex() {
            this.dataService.selectedJobIndexSource.next(this.activatedRouter.snapshot.data.tab_index)
        }
        fetchLookups() {
            this.dataService.getLookups().subscribe({
                next: e => {
                    this.jobTypeList = e.job_types, this.allDeviceBrandList = e.device_brands, this.deviceBrandList = this.deviceTypeId ? this.allDeviceBrandList.filter(o => o.device_type_id === this.deviceTypeId) : e.device_brands, this.modelList = e.device_models, this.allRepairServicesList = e.repair_services, this.deviceTypeRepairServicesList = this.allRepairServicesList
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.log(e)
                }
            })
        }
        getQueryParamsDataGrid(e) {
            let o = this.dataGridService.getDataQueryParams(e);
            return o.is_open_job_only = this.isOpenJobsOnly, o.is_closed_jobs_only = this.isClosedJobsOnly, this.searchText === "" && this.updateJobFilterValues(), this.searchText && (o.search_term = this.searchText, this.updateJobFilterValues()), this.customerId && (o.customer_id = this.customerId), this.deviceTypeId && typeof this.deviceTypeId == "number" && (o.device_type_id = this.deviceTypeId), this.deviceBrandId && (o.device_brand_id = this.deviceBrandId), this.selectedModel && (o.device_model_id = this.selectedModel), this.employeeId && (o.employee_id = this.employeeId, this.updateJobFilterValues()), this.assigneeId && (o.assignee_id = this.assigneeId), this.priorityId && (o.priority_id = this.priorityId), this.roleId && (o.role_id = this.roleId), this.assignedOnly && (o.assigned_only = !0), this.selectedStatusIds && this.selectedStatusIds.length && (o.status_ids = this.selectedStatusIds, this.updateJobFilterValues()), this.selectedRepairServicesId && this.selectedRepairServicesId.length && (o.repairables = this.selectedRepairServicesId, this.updateJobFilterValues()), this.fromDate && (o.from_date = (0, In.default)(this.fromDate).format("YYYY-MM-DD")), this.actionableDashboardTodayFilter() && (o.job_due_from = (0, In.default)(new Date).format("YYYY-MM-DD"), o.job_due_to = (0, In.default)(new Date).format("YYYY-MM-DD")), this.toDate && (o.to_date = (0, In.default)(this.toDate).format("YYYY-MM-DD")), this.selectedStatus && (o.payment_status = this.selectedStatus), this.selectedJobType && (o.type_id = this.selectedJobType), this.selectedTaxFilter && (o.tax_filter = this.selectedTaxFilter), this.selectedAging && (o.aging = this.selectedAging), this.selectedJobServiceType !== null && (o.is_recovery = this.selectedJobServiceType), this.selectedArchiveStatus && this.selectedArchiveStatus !== "active" && (o.archive_status = this.selectedArchiveStatus), this.closedWithoutInvoice !== null && (o.closed_without_invoice = this.closedWithoutInvoice), o
        }
        onJobContextMenuAction() {
            this.fetchJobs()
        }
        openArchivedActionsPopup(e) {
            this.selectedArchivedJob = e, this.archiveDeleteMode.set("archived-actions"), this.isVisibleArchiveDeletePopup.set(!0)
        }
        handleArchiveDeleteSuccess(e) {
            this.isVisibleArchiveDeletePopup.set(!1), this.selectedArchivedJob = null, this.fetchJobs()
        }
        onServiceOptionClick(e) {
            e.itemData === fn.REPAIR_SERVICE ? this.routerHelperService.navigateAddRepairJob() : e.itemData === fn.BULK_JOB ? this.routerHelperService.navigateAddBulkJob() : this.routerHelperService.navigateAddRecoveryJob()
        }
        filterOnValueChange(e) {
            e === I.JOB.name && this.fetchJobs(), this.updateJobFilterValues()
        }
        fetchJobs() {
            this.isLoading.set(!0), this.store = new Mr({
                key: "id",
                load: e => {
                    let o = this.getQueryParamsDataGrid(e);
                    return this.service.getJobListByQuery(o).toPromise().then(i => {
                        let p = i.data || [];
                        return this.totalCount = i.total || 0, this.hasData.set(this.totalCount > 0), this.isLoading.set(!1), {
                            data: p,
                            totalCount: this.totalCount
                        }
                    }).catch(i => {
                        throw this.isLoading.set(!1), this.hasData.set(!1), i
                    })
                }
            })
        }
        onDeviceTypeSelection(e) {
            this.deviceBrandId = null, this.updateDeviceTypeChanges(e = this.deviceTypeId), this.filterOnValueChange("job")
        }
        scanJob() {
            this.isVisibleBarcodeScannerPopUp ? (this.isVisibleBarcodeScannerPopUp = !1, setTimeout(() => {
                this.isVisibleBarcodeScannerPopUp = !0
            }, 0)) : this.isVisibleBarcodeScannerPopUp = !0
        }
        getJobFromBarcode(e) {
            this.router.navigate([`/jobs/${e.id}/overview`])
        }
        updateDeviceTypeChanges(e) {
            this.deviceBrandList = this.allDeviceBrandList.filter(o => o.device_type_id === e), this.deviceTypeRepairServicesList = this.allRepairServicesList.filter(o => o.device_type_id === e)
        }
        updateJobFilterValues() {
            this.jobFilters = {
                selectedStatus: this.selectedStatus,
                searchText: this.searchText,
                deviceTypeId: this.deviceTypeId,
                deviceBrandId: this.deviceBrandId,
                selectedModel: this.selectedModel,
                roleId: this.roleId,
                selectedStatusIds: this.selectedStatusIds,
                selectedRepairServicesId: this.selectedRepairServicesId,
                assigneeId: this.assigneeId,
                priorityId: this.priorityId,
                fromDate: this.fromDate,
                toDate: this.toDate,
                selectedJobType: this.selectedJobType,
                selectedTaxFilter: this.selectedTaxFilter,
                selectedAging: this.selectedAging,
                selectedJobServiceType: this.selectedJobServiceType,
                selectedArchiveStatus: this.selectedArchiveStatus !== "active" ? this.selectedArchiveStatus : null,
                closedWithoutInvoice: this.closedWithoutInvoice
            }, this.filterCount = this.filterPersistService.saveAllFiltersInStorage(this.filterStorageKey, this.jobFilters)
        }
        clearAllFilters() {
            this.filterPersistService.clearALlFilters(this.filterStorageKey), this.getSavedFilterValues(), this.dataGrid.instance.clearSorting()
        }
        getSavedFilterValues() {
            let e = this.filterPersistService.getAllSavedFilterValuesFromStorage(this.filterStorageKey);
            this.jobFilters = e.filters, this.filterCount = e.count, this.deviceTypeId = this.jobFilters.deviceTypeId ? ? null, this.deviceBrandId = this.jobFilters.deviceBrandId ? ? null, this.roleId = this.jobFilters.roleId ? ? null, this.selectedStatusIds = this.jobFilters.selectedStatusIds ? ? null, this.selectedRepairServicesId = this.jobFilters.selectedRepairServicesId ? ? null, this.assigneeId = this.jobFilters.assigneeId ? ? null, this.selectedModel = this.jobFilters.selectedModel ? ? null, this.priorityId = this.jobFilters.priorityId ? ? null, this.fromDate = this.jobFilters.fromDate ? ? null, this.toDate = this.jobFilters.toDate ? ? null, this.selectedJobType = this.jobFilters.selectedJobType ? ? null, this.selectedTaxFilter = this.jobFilters.selectedTaxFilter ? ? null, this.selectedStatus = this.jobFilters.selectedStatus ? ? null, this.selectedAging = this.jobFilters.selectedAging ? ? null, this.selectedJobServiceType = this.jobFilters.selectedJobServiceType ? ? null, this.selectedArchiveStatus = this.jobFilters.selectedArchiveStatus ? ? "active", this.closedWithoutInvoice = this.jobFilters.closedWithoutInvoice ? ? null, this.searchText = this.jobFilters.searchText ? ? ""
        }
        isIdPresent() {
            return document.getElementById("jobContextMenuId") ? document.getElementById("jobContextMenuId") : ""
        }
        closeExportPopUp() {
            this.isVisibleExportPopUp = !1
        }
        fetchStatuses() {
            this.service.fetchReport(this.getQueryParamsDataGrid({})).subscribe({
                next: e => {
                    this.statusDataSource = new rr(e), this.statusDataSource.items().sort((o, i) => o.key === "Open" || o.key === "Returned" && i.key === "Rejected" ? -1 : 1)
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.error("error in fetching status ", e)
                }
            })
        }
        onPriorityDropdownChange(e) {
            this.priorityId = e, this.filterOnValueChange("job")
        }
        updatesOnRoleId(e) {
            this.roleId = e, this.filterOnValueChange("job")
        }
        hasAnyServiceAssignee(e) {
            return Array.isArray(e) && e.some(o => !!o.assigned_user)
        }
        updatesOnDeviceTypeId(e) {
            this.deviceTypeId = e, this.onDeviceTypeSelection(e)
        }
        updatesOnAssigneeId(e) {
            this.assigneeId = e, this.filterOnValueChange("job")
        }
        onRowClick(e) {
            this.isLastColumnClicked() || (this.selectedJobId = e ? .data ? .id, this.isPanelOpened = !0), this.isLastColumnClicked.set(!1)
        }
        onCellClick(e) {
            e.rowType === "data" && e.column.cellTemplate === "actionTemplate" && this.isLastColumnClicked.set(!0)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(Kn, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.dataGrid = p.first)
                    }
                },
                inputs: {
                    assignedOnly: "assignedOnly"
                },
                standalone: !1,
                decls: 6,
                vars: 5,
                consts: [
                    [3, "icon", "title", "description", "primaryButtonText", "quickTipsVisible", "quickTips", "tutorialText", "tutorialUrl", "tutorialVisible"],
                    [2, "position", "relative"],
                    [3, "isOpened", "jobId"],
                    [3, "assigneeId", "customerId", "entity", "isVisiblePopup", "jobTypeList", "modelList", "service", "statusDataSource"],
                    [3, "isVisiblePopup", "type"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "primaryButtonClick", "icon", "title", "description", "primaryButtonText", "quickTipsVisible", "quickTips", "tutorialText", "tutorialUrl", "tutorialVisible"],
                    [1, "skeleton-overlay"],
                    ["id", "tabAndGridContainer", 3, "onRowClick", "onCellClick", "onToolbarPreparing", "columnAutoWidth", "columns", "dataSource", "width"],
                    ["type", "custom", 3, "customLoad", "customSave", "enabled", "storageKey"],
                    ["text", "", 3, "enabled", "indicatorSrc", "showPane"],
                    ["mode", "select", "type", "outline", 3, "enabled", "title", "width"],
                    [3, "allowSelectAll", "recursive", "selectByClick"],
                    [3, "textChange", "text", "placeholder", "visible", "width"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["id", "addJobDropdown", 4, "dxTemplate", "dxTemplateOf"],
                    ["id", "jobStatusDropdown", 4, "dxTemplate", "dxTemplateOf"],
                    ["type", "list", 3, "rows", "columns"],
                    ["buttonType", "default", "icon", "fa-thin fa-filter-circle-xmark", "title", "clear_all_filters", 3, "onClickEvent", "isVisibleIcon"],
                    ["buttonType", "default", "icon", "fa-thin fa-barcode-read", "title", "scan_barcode_to_search_job", 3, "onClickEvent", "isVisibleIcon"],
                    [1, "d-flex", "justify-content-start", 3, "entity", "iconOnly", "user"],
                    [1, "d-flex", "align-items-center"],
                    [3, "entity", "iconOnly", "user"],
                    [1, "d-flex", "align-items-center", "position-relative"],
                    [1, "position-absolute", 3, "entity", "iconOnly", "user", "left"],
                    [1, "position-absolute", 3, "entity", "iconOnly", "user"],
                    [3, "dateTime", "entity", "status"],
                    [3, "iconType", "status"],
                    [1, "badge", "bg-success-subtle", "text-success"],
                    [1, "badge", "bg-secondary-subtle", "text-secondary"],
                    [1, "fa-solid", "fa-check", "me-1"],
                    [1, "fa-solid", "fa-minus", "me-1"],
                    ["iconStyle", "outline", 3, "status"],
                    [1, "dropdown"],
                    ["aria-expanded", "false", "buttonType", "default", "cssClass", "px-1", "data-bs-auto-close", "outside", "data-bs-toggle", "dropdown", "icon", "fa-thin fa-filter-list", "title", "common_filters_all", 3, "isVisibleIcon"],
                    ["aria-expanded", "false", "data-bs-auto-close", "outside", "data-bs-toggle", "dropdown", "icon", "fa-thin fa-filter-list", "stylingMode", "outlined", "template", "template", "text", "All Filters", "title", "Approve", "type", "default", 1, "px-1"],
                    [1, "dropdown-menu", "p-2", "theme-secondary-bg", 3, "ngStyle"],
                    [1, "mb-3"],
                    ["id", "payment-status-dropdown", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "placeholder", "showClearButton", "width"],
                    ["displayExpr", "name", "id", "model-filter-dropdown", "valueExpr", "id", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "placeholder", "showClearButton", "width"],
                    ["placeholder", "user_customer_type_placeholder", 3, "ngModelChange", "ngModel", "isFilter"],
                    [3, "ngModelChange", "ngModel", "isFilter"],
                    ["displayExpr", "name", "id", "job-type-dropdown", "valueExpr", "id", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "placeholder", "showClearButton", "width"],
                    [3, "ngModelChange", "ngModel", "isFilter", "placeholder"],
                    ["displayExpr", "name", "id", "job-basic-info-device-brand", "searchMode", "contains", "valueExpr", "id", 1, "dropdown-filter", 3, "onItemClick", "ngModelChange", "ngModel", "items", "placeholder", "searchEnabled", "showClearButton"],
                    ["displayExpr", "name", "id", "job-basic-info-repairables", "valueExpr", "id", 1, "dropdown-filter", "mb-1", 3, "onValueChanged", "ngModelChange", "ngModel", "acceptCustomValue", "items", "placeholder", "showSelectionControls"],
                    ["id", "job-from-date-filter", "type", "date", 1, "dropdown-filter", 3, "onValueChanged", "valueChange", "value", "max", "placeholder", "showClearButton", "width"],
                    ["id", "job-to-date-filter", "type", "date", 1, "dropdown-filter", 3, "onValueChanged", "valueChange", "value", "max", "placeholder", "showClearButton", "width"],
                    ["displayExpr", "label", "valueExpr", "value", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "showClearButton", "width", "placeholder"],
                    ["displayExpr", "label", "valueExpr", "value", 1, "dropdown-filter", 3, "onValueChanged", "valueChange", "value", "items", "showClearButton", "placeholder", "width"],
                    [1, "badge", "fw-bold", "rounded-pill", "bg-danger", "ms-1"],
                    ["displayExpr", "name", "selectAllMode", "allPages", "valueExpr", "id", 3, "onValueChanged", "ngModelChange", "ngModel", "acceptCustomValue", "dataSource", "grouped", "maxDisplayedTags", "multiline", "ngClass", "placeholder", "searchEnabled", "showMultiTagOnly", "showSelectionControls", "width"],
                    [1, "fa-thin", "fa-grip-dots"],
                    [1, "float-end", "badge", "theme-badge", 3, "ngStyle"],
                    [1, "d-flex", "justify-content-between"],
                    [1, "d-flex", "justify-content-start"],
                    [1, "fas", "fa-circle", "me-1", "mt-2", 3, "ngStyle"],
                    [1, "status-name", "text-truncate", "mt-1"],
                    [1, "badge", "bg-theme", 3, "ngStyle"],
                    [3, "ngModelChange", "ngModel"],
                    ["displayExpr", "label", "valueExpr", "value", 3, "onValueChanged", "valueChange", "value", "items", "showClearButton", "placeholder"],
                    ["id", "tax-dropdown", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "showClearButton", "width", "placeholder"],
                    [1, "ms-2", 3, "routerLink"],
                    ["id", "addJobDropdown"],
                    ["icon", "fa-light fa-plus", "stylingMode", "outlined", "type", "default", 3, "items"],
                    ["icon", "fa-light fa-plus", "stylingMode", "outlined", "type", "default", 3, "onItemClick", "items"],
                    ["icon", "fa-light fa-plus", 3, "hint"],
                    ["icon", "fa-light fa-plus", 3, "onClick", "hint"],
                    [1, "fa-thin", "fa-box-archive", "fs-6", "cursor-pointer", 3, "title"],
                    [3, "isIconOnly", "job"],
                    [1, "fa-thin", "fa-box-archive", "fs-6", "cursor-pointer", 3, "click", "title"],
                    [3, "jobContextMenuOnAction", "isIconOnly", "job"],
                    [3, "ngClass"],
                    ["id", "jobStatusDropdown"],
                    ["displayExpr", "name", "selectAllMode", "allPages", "valueExpr", "id", 3, "onValueChanged", "ngModelChange", "ngModel", "acceptCustomValue", "dataSource", "grouped", "maxDisplayedTags", "multiline", "placeholder", "searchEnabled", "showMultiTagOnly", "showSelectionControls", "width"],
                    [3, "isOpenedChange", "pinnedChange", "isOpened", "jobId"],
                    [3, "ClosePopupClick", "assigneeId", "customerId", "entity", "isVisiblePopup", "jobTypeList", "modelList", "service", "statusDataSource"],
                    [3, "scannerToSave", "isVisiblePopup", "type"],
                    [3, "isVisibleChange", "onSuccess", "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, Y_, 1, 13, "app-empty-state", 0)(1, a0, 34, 48, "div", 1), m(2, r0, 1, 2, "app-job-panel", 2), m(3, s0, 1, 8, "app-export-option-pop-up", 3), m(4, l0, 1, 2, "app-qrcode-scanner", 4), m(5, c0, 1, 7, "app-archive-delete-popup", 5)), o & 2 && (_(!i.isLoading() && !i.hasTenantJobs && !i.hasData() ? 0 : 1), n(2), _(i.selectedJobId ? 2 : -1), n(), _(i.isVisibleExportPopUp ? 3 : -1), n(), _(i.isVisibleBarcodeScannerPopUp ? 4 : -1), n(), _(i.isVisibleArchiveDeletePopup() ? 5 : -1))
                },
                dependencies: [Q, Pa, Se, to, _t, wr, Re, $n, Fi, Vr, Dr, ue, oi, ge, qi, jr, yr, W, ct, Kn, er, or, ir, nr, ar, Jt, Ai, xe, Bi, q, $e, Ti, cn, cl, Kt, oo, Ue, Ni, mt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ml = (t, c) => c.name;

function d0(t, c) {
    if (t & 1 && (r(0, "div", 12)(1, "p", 13), d(2), a()()), t & 2) {
        let e = c.$implicit;
        n(2), h(e.title)
    }
}

function p0(t, c) {
    if (t & 1 && u(0, "app-user-badge", 21), t & 2) {
        let e = s(4);
        l("iconOnly", !1)("user", e.job.user)
    }
}

function m0(t, c) {
    if (t & 1 && u(0, "app-user-badge", 21), t & 2) {
        let e = s(5);
        l("iconOnly", !1)("user", e.job.assigned_user)
    }
}

function _0(t, c) {
    if (t & 1 && (r(0, "div", 17)(1, "p")(2, "strong", 22), d(3), a()(), E(4, m0, 1, 2, "app-user-badge", 19), a()), t & 2) {
        let e = s(4);
        n(3), S("", e.formatMessage("job_current_assignee"), ":"), n(), l("ngIf", e.job.assigned_user)
    }
}

function u0(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 14)(2, "div", 15)(3, "p")(4, "strong"), d(5), a(), r(6, "span"), u(7, "app-job-status-tag", 16), a()(), r(8, "div", 17)(9, "p")(10, "strong", 18), d(11), a()(), E(12, p0, 1, 2, "app-user-badge", 19), a(), E(13, _0, 5, 2, "div", 20), a()()()), t & 2) {
        let e = s(3);
        n(5), ze("", e.formatMessage("job_sheet_number"), ": ", e.job.job_number, " "), n(2), l("iconType", e.statusIconTypeList.EXTRA_SMALL)("status", e.job.status), n(4), S("", e.formatMessage("job_customer_detail"), ":"), n(), l("ngIf", e.job.user), n(), l("ngIf", e.isEmployee)
    }
}

function C0(t, c) {
    if (t & 1 && (r(0, "p")(1, "strong"), d(2), a(), d(3), a()), t & 2) {
        let e = s(4);
        n(2), S("", e.formatMessage("job_serial_number"), " :"), n(), h(e.job.serial_number)
    }
}

function v0(t, c) {
    if (t & 1 && (r(0, "span"), u(1, "app-image-gallery-popup", 26), a()), t & 2) {
        let e = c.$implicit;
        n(), l("attachment", e)("isOnTableListing", !1)
    }
}

function f0(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 14)(2, "div", 15)(3, "p")(4, "strong"), d(5), a(), d(6), a(), E(7, C0, 4, 2, "p", 23), r(8, "p")(9, "strong"), d(10), a(), d(11), V(12, "objToString"), a()(), r(13, "p")(14, "strong"), d(15), a()(), r(16, "div", 24), E(17, v0, 2, 2, "span", 25), a()()()), t & 2) {
        let e = s(3);
        n(5), S("", e.formatMessage("job_device_detail"), " :"), n(), h(e.job.device_information), n(), l("ngIf", e.job.serial_number), n(3), S("", e.formatMessage("job_service_information"), " : "), n(), h(ie(12, 8, e.job.repairables)), n(4), S("", e.formatMessage("job_device_images"), ": "), n(2), l("ngForOf", e.job.attachments)("ngForTrackBy", e.trackById)
    }
}

function h0(t, c) {
    if (t & 1 && (r(0, "span", 31), u(1, "i", 32), d(2), a()), t & 2) {
        let e = c.$implicit;
        n(2), S("", e.name, " ")
    }
}

function b0(t, c) {
    if (t & 1 && (r(0, "div", 28)(1, "p", 29)(2, "strong"), d(3, "Pre Conditions:"), a()(), r(4, "div", 30), X(5, h0, 3, 1, "span", 31, ml), a()()), t & 2) {
        let e = s(5);
        n(5), Z(e.job.pre_post_conditions[0].pre_conditions)
    }
}

function g0(t, c) {
    if (t & 1 && (r(0, "span", 33), u(1, "i", 32), d(2), a()), t & 2) {
        let e = c.$implicit;
        n(2), S("", e.name, " ")
    }
}

function x0(t, c) {
    if (t & 1 && (r(0, "div")(1, "p", 29)(2, "strong"), d(3, "Post Conditions:"), a()(), r(4, "div", 30), X(5, g0, 3, 1, "span", 33, ml), a()()), t & 2) {
        let e = s(5);
        n(5), Z(e.job.pre_post_conditions[1].post_conditions)
    }
}

function S0(t, c) {
    t & 1 && (r(0, "p", 27), d(1, "No conditions recorded"), a())
}

function y0(t, c) {
    if (t & 1 && (m(0, b0, 7, 0, "div", 28), m(1, x0, 7, 0, "div"), m(2, S0, 2, 0, "p", 27)), t & 2) {
        let e = s(4);
        _(!(e.job.pre_post_conditions[0] == null || e.job.pre_post_conditions[0].pre_conditions == null) && e.job.pre_post_conditions[0].pre_conditions.length ? 0 : -1), n(), _(!(e.job.pre_post_conditions[1] == null || e.job.pre_post_conditions[1].post_conditions == null) && e.job.pre_post_conditions[1].post_conditions.length ? 1 : -1), n(), _(!(!(e.job.pre_post_conditions[0] == null || e.job.pre_post_conditions[0].pre_conditions == null) && e.job.pre_post_conditions[0].pre_conditions.length) && !(!(e.job.pre_post_conditions[1] == null || e.job.pre_post_conditions[1].post_conditions == null) && e.job.pre_post_conditions[1].post_conditions.length) ? 2 : -1)
    }
}

function T0(t, c) {
    t & 1 && (r(0, "p", 27), d(1, "No conditions recorded"), a())
}

function M0(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 14)(2, "div", 15), m(3, y0, 3, 3)(4, T0, 2, 0, "p", 27), a()()()), t & 2) {
        let e = s(3);
        n(3), _(e.job.pre_post_conditions != null && e.job.pre_post_conditions.length ? 3 : 4)
    }
}

function P0(t, c) {
    t & 1 && u(0, "app-currency-symbol")
}

function I0(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 14)(2, "div", 15)(3, "p")(4, "strong"), d(5), a(), m(6, P0, 1, 0, "app-currency-symbol"), d(7), a(), r(8, "p")(9, "strong"), d(10), a(), d(11), V(12, "date"), a(), r(13, "p")(14, "strong"), d(15), a(), d(16), a()()()()), t & 2) {
        let e = s(3);
        n(5), S("", e.formatMessage("initial_quotation"), ": "), n(), _(e.job.initial_quotation ? 6 : -1), n(), S(" ", e.job.initial_quotation, " "), n(3), S("", e.formatMessage("job_due_date"), " : "), n(), h(ie(12, 7, e.job.estimated_delivery)), n(4), S("", e.formatMessage("dealer_Job_id"), " : "), n(), S("", e.job.vendor_job_id, " ")
    }
}

function E0(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_create"), " ")
    }
}

function w0(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_view"), " ")
    }
}

function O0(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_create"), " ")
    }
}

function j0(t, c) {
    if (t & 1 && d(0), t & 2) {
        let e = s(4);
        S(" ", e.formatMessage("common_view"), " ")
    }
}

function V0(t, c) {
    if (t & 1 && (r(0, "ul", 44)(1, "li")(2, "span", 45), d(3), a(), r(4, "span"), u(5, "app-currency-symbol"), d(6), a(), r(7, "a", 36), d(8), a()()()), t & 2) {
        let e = c.$implicit,
            o = s(4);
        n(3), h(e.payment_type == null ? null : e.payment_type.name), n(3), S(" ", e.amount, " "), n(), l("routerLink", un("/jobs/", o.job.id, "/paymentReceipts/", e.id, "/")), n(), S(" ", o.formatMessage("button_view_receipt"))
    }
}

function D0(t, c) {
    if (t & 1 && (r(0, "ul", 44)(1, "li"), d(2), r(3, "a", 36), d(4), a()()()), t & 2) {
        let e = c.$implicit,
            o = s(4);
        n(2), S(" ", e.type == null ? null : e.type.name, " "), n(), l("routerLink", un("/jobs/", o.job.id, "/deliveryReceipts/", e.id, "/")), n(), S(" ", o.formatMessage("button_view_receipt"))
    }
}

function k0(t, c) {
    if (t & 1 && (r(0, "div")(1, "div", 14)(2, "div", 15)(3, "div", 2)(4, "div", 34)(5, "div")(6, "p"), u(7, "i", 35), r(8, "strong"), d(9), a(), r(10, "a", 36), d(11), a()()(), r(12, "div")(13, "p"), u(14, "i", 37), r(15, "strong"), d(16), a(), r(17, "a", 36), E(18, E0, 1, 1, "ng-template", 38)(19, w0, 1, 1, "ng-template", null, 0, _i), d(21), a()()(), r(22, "div")(23, "p"), u(24, "i", 39), r(25, "strong"), d(26), a(), r(27, "a", 36), E(28, O0, 1, 1, "ng-template", 38)(29, j0, 1, 1, "ng-template", null, 0, _i), d(31), a()()()(), r(32, "div", 34)(33, "div")(34, "p", 6), u(35, "i", 40), r(36, "strong"), d(37), a()(), E(38, V0, 9, 6, "ul", 41), a(), r(39, "div", 42)(40, "p", 6), u(41, "i", 43), r(42, "strong"), d(43, "Deliveries: "), a()(), E(44, D0, 5, 5, "ul", 41), a()()()()()()), t & 2) {
        let e = _n(20),
            o = s(3);
        n(9), S("", o.formatMessage("job_sheet_label"), ": "), n(), l("routerLink", Ve("/jobs/", o.job.id, "/jobSheets")), n(), S("", o.formatMessage("view_job_sheet"), " "), n(5), S("", o.formatMessage("quotation_with"), ": "), n(), l("routerLink", Ve("/jobs/", o.job.id, "/quotations")), n(), l("ngIfElse", e)("ngIf", o.isEmployee && !(o.job.quotation != null && o.job.quotation.id) && o.authorizationService.canAccess(o.ENTITIES.QUOTATION) && o.userPermissionList.includes(o.PERMISSION_LIST.QUOTATION_WRITE)), n(3), S(" ", o.formatMessage("quotation_title"), " "), n(5), S("", o.formatMessage("job_label_invoice"), ": "), n(), l("routerLink", Ve("/jobs/", o.job.id, "/invoices")), n(), l("ngIfElse", e)("ngIf", o.isEmployee && !(o.job.invoice != null && o.job.invoice.id) && o.authorizationService.canAccess(o.ENTITIES.JOB_INVOICE)), n(3), S(" ", o.formatMessage("invoice_number")), n(6), S("", o.formatMessage("payment"), " "), n(), l("ngForOf", o.job.payments)("ngForTrackBy", o.trackById), n(6), l("ngForOf", o.job.deliveries)("ngForTrackBy", o.trackById)
    }
}

function N0(t, c) {
    if (t & 1 && (r(0, "dx-accordion", 9), E(1, d0, 3, 1, "div", 10)(2, u0, 14, 7, "div", 11)(3, f0, 18, 10, "div", 11)(4, M0, 5, 1, "div", 11)(5, I0, 17, 9, "div", 11)(6, k0, 45, 21, "div", 11), a()), t & 2) {
        let e = s(2);
        l("collapsible", !0)("dataSource", e.accordionData)("multiple", !0)("selectedItems", e.openedItems), n(), l("dxTemplateOf", "title"), n(), l("dxTemplateOf", "basic_information"), n(), l("dxTemplateOf", "device_information"), n(), l("dxTemplateOf", "pre_post_conditions"), n(), l("dxTemplateOf", "additional_information"), n(), l("dxTemplateOf", "common_documents")
    }
}

function A0(t, c) {
    if (t & 1 && (r(0, "div", 5)(1, "div", 6)(2, "h6"), d(3), a()(), r(4, "div", 7), E(5, N0, 7, 10, "dx-accordion", 8), a()()), t & 2) {
        let e = s();
        n(3), h(e.formatMessage("job_overview_label")), n(2), l("ngIf", e.job && e.accordionData)
    }
}
var _l = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = g, this.authorizationService = b(ki), this.userSessionService = b(L), this.activatedRouter = b(R), this.toastNotificationService = b(D), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.statusIconTypeList = he, this.ENTITIES = I, this.PERMISSION_LIST = M, this.trackById = (o, i) => i.id ? ? o, this.trackByIndex = o => o, this.accordionData = [{
                title: "Basic Information",
                template: "basic_information"
            }, {
                title: "Device Information",
                template: "device_information"
            }, {
                title: "Pre & Post Conditions",
                template: "pre_post_conditions"
            }, {
                title: "Additional Information",
                template: "additional_information"
            }, {
                title: "Documents",
                template: "common_documents"
            }], this.openedItems = [this.accordionData[0], this.accordionData[1], this.accordionData[2], this.accordionData[3], this.accordionData[4]]
        }
        ngOnInit() {
            this.activatedRouter.parent.params.subscribe({
                next: e => {
                    this.jobId = null, this.jobId = +e.job_id, this.service.getOverviewById(this.jobId).subscribe({
                        next: o => {
                            this.job = o
                        },
                        error: o => {
                            this.toastNotificationService.error("notification_error"), console.log("err in getting job overview ", o)
                        }
                    })
                },
                error: e => {
                    this.toastNotificationService.error("notification_error"), console.log(e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-overview"]
                ],
                standalone: !1,
                decls: 5,
                vars: 1,
                consts: [
                    ["viewQuotationTemplate", ""],
                    [1, "m-2", "job-overview"],
                    [1, "row"],
                    ["class", "col-sm-5 col-md-5 col-lg-5 overview-divider", 4, "ngIf"],
                    [1, "col-sm-7", "col-md-7", "col-lg-7"],
                    [1, "col-sm-5", "col-md-5", "col-lg-5", "overview-divider"],
                    [1, "mb-1"],
                    [1, "overview-content"],
                    [3, "collapsible", "dataSource", "multiple", "selectedItems", 4, "ngIf"],
                    [3, "collapsible", "dataSource", "multiple", "selectedItems"],
                    ["class", "accordion-title d-flex flex-row-reverse justify-content-between align-items-center", 4, "dxTemplate", "dxTemplateOf"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "accordion-title", "d-flex", "flex-row-reverse", "justify-content-between", "align-items-center"],
                    [1, "fs-7", "mb-0"],
                    [1, "row", "mb-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "iconType", "status"],
                    [1, "d-flex"],
                    [1, "me-3"],
                    ["class", "ms-2 fw-bold", 3, "iconOnly", "user", 4, "ngIf"],
                    ["class", "d-flex", 4, "ngIf"],
                    [1, "ms-2", "fw-bold", 3, "iconOnly", "user"],
                    [1, "me-2"],
                    [4, "ngIf"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "d-flex", "align-items-center", "justify-content-evenly", "flex-wrap"],
                    [4, "ngFor", "ngForOf", "ngForTrackBy"],
                    [3, "attachment", "isOnTableListing"],
                    [1, "text-muted"],
                    [1, "mb-3"],
                    [1, "mb-2"],
                    [1, "d-flex", "flex-wrap", "gap-2"],
                    [1, "badge", "rounded-pill", "bg-primary-subtle", "text-primary-emphasis", "border", "border-primary-subtle", "px-3", "py-2"],
                    [1, "fa-thin", "fa-check", "me-1"],
                    [1, "badge", "rounded-pill", "bg-success-subtle", "text-success-emphasis", "border", "border-success-subtle", "px-3", "py-2"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fa-thin", "fa-file-alt", "me-3"],
                    [3, "routerLink"],
                    [1, "fa-thin", "fa-file-invoice-dollar", "me-3"],
                    [3, "ngIfElse", "ngIf"],
                    [1, "fa-thin", "fa-file-invoice", "me-3"],
                    [1, "fa-thin", "fa-money-check-alt", "me-3"],
                    ["class", "ms-3 mb-0", 4, "ngFor", "ngForOf", "ngForTrackBy"],
                    [1, "mt-3"],
                    [1, "fa-thin", "fa-truck", "me-3"],
                    [1, "ms-3", "mb-0"],
                    [1, "me-1"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 1)(1, "div", 2), E(2, A0, 6, 2, "div", 3), r(3, "div", 4), u(4, "app-job-activity"), a()()()), o & 2 && (n(2), l("ngIf", i.job))
                },
                dependencies: [Ta, Ma, Se, _t, Ri, oi, At, W, Ti, zs, Ln, Ni],
                styles: [".job-overview[_ngcontent-%COMP%]{height:calc(100vh - 280px);display:flex;flex-direction:column}.job-overview[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{margin-right:2px}.job-overview[_ngcontent-%COMP%] > .row[_ngcontent-%COMP%]{flex:1;min-height:0}.job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]{border-right:1px solid #ecf0f1;height:100%;display:flex;flex-direction:column;min-height:0}.job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]   .title-text[_ngcontent-%COMP%]{flex-shrink:0}.job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]   .overview-content[_ngcontent-%COMP%]{flex:1;overflow-y:auto;min-height:0}.job-overview[_ngcontent-%COMP%]   .col-sm-7[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;min-height:0}@media screen and (max-width:960px){.job-overview[_ngcontent-%COMP%]{height:auto;display:block}.job-overview[_ngcontent-%COMP%] > .row[_ngcontent-%COMP%]{flex:none}.job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]{border-right:none;height:auto;display:block}.job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]   .overview-content[_ngcontent-%COMP%]{flex:none;overflow-y:visible;height:auto}.job-overview[_ngcontent-%COMP%]   .col-sm-7[_ngcontent-%COMP%]{height:auto;display:block}}.dark-theme[_nghost-%COMP%]   .job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .job-overview[_ngcontent-%COMP%]   .overview-divider[_ngcontent-%COMP%]{border-right:1px solid #334155}"]
            })
        }
    }
    return t
})();

function L0(t, c) {
    if (t & 1 && u(0, "app-send-whats-app-btn", 6), t & 2) {
        let e = s();
        l("entityId", e.delivery == null ? null : e.delivery.id)("entityName", e.ENTITIES.JOB_DELIVERY.name)
    }
}

function B0(t, c) {
    if (t & 1 && (r(0, "div")(1, "span", 18), d(2), a(), r(3, "span", 19), d(4, ":"), a(), d(5), a()), t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("delivery_label_charges")), n(3), S("", e.delivery.delivery_charges, " ")
    }
}

function R0(t, c) {
    if (t & 1 && (r(0, "div")(1, "span", 18), d(2), a(), r(3, "span", 19), d(4, ":"), a(), d(5), a()), t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("delivery_provider_label")), n(3), S("", e.delivery.delivery_provider.name, " ")
    }
}

function U0(t, c) {
    if (t & 1 && (r(0, "div", 21)(1, "span", 18), d(2), a(), r(3, "span", 19), d(4, ":"), a(), d(5), a()), t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("delivery_label_tracking_id")), n(3), S("", e.delivery.tracking_id, " ")
    }
}

function F0(t, c) {
    t & 1 && (r(0, "div", 22), u(1, "img", 27), a())
}

function q0(t, c) {
    if (t & 1 && (r(0, "div", 23)(1, "span", 18), d(2), a(), r(3, "span", 19), d(4, ":"), a(), u(5, "span", 28), V(6, "safe"), a()), t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("common_comment")), n(3), l("innerHTML", B(6, 2, e.delivery.comment, "html"), We)
    }
}

function G0(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2), u(5, "app-invoice-header", 11)(6, "app-invoice-title", 12)(7, "app-invoice-customer-detail", 13)(8, "app-invoice-job-details", 14), r(9, "div", 15)(10, "div", 2)(11, "h5", 16), d(12), a(), r(13, "div", 1)(14, "div", 17)(15, "div")(16, "span", 18), d(17), a(), r(18, "span", 19), d(19, ":"), a(), d(20), a(), m(21, B0, 6, 2, "div"), m(22, R0, 6, 2, "div"), a(), r(23, "div", 20), m(24, U0, 6, 2, "div", 21), r(25, "div", 21)(26, "span", 18), d(27), a(), r(28, "span", 19), d(29, ":"), a(), d(30), V(31, "dateFormat"), a(), r(32, "div", 21)(33, "span", 18), d(34), a(), r(35, "span", 19), d(36, ":"), a(), d(37), a()(), m(38, F0, 2, 0, "div", 22), m(39, q0, 7, 5, "div", 23), a()()(), u(40, "app-invoice-term-and-conditions", 24)(41, "hr", 25)(42, "app-invoice-signature", 26), a()()()()()), t & 2) {
        let e = s();
        n(5), l("account", e.account)("qrCode", (e.delivery == null ? null : e.delivery.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.delivery == null ? null : e.delivery.qr_code)), n(), l("dateTime", e.delivery.created_at)("title", (e.printSettings != null && e.printSettings.delivery_challan_title ? e.printSettings.delivery_challan_title + ": " : e.formatMessage("delivery_challan")) + e.delivery.id), n(), l("userId", e.job.user_id), n(), l("job", e.job), n(4), h(e.formatMessage("delivery_information")), n(5), h(e.formatMessage("delivery_mode_label")), n(3), S("", e.delivery.type.name, " "), n(), _(e.delivery.delivery_charges ? 21 : -1), n(), _(e.delivery.delivery_provider ? 22 : -1), n(2), _(e.delivery.tracking_id ? 24 : -1), n(3), h(e.formatMessage("delivered_on")), n(3), S("", B(31, 21, e.delivery.created_at, "datetime"), " "), n(4), h(e.formatMessage("common_delivered_by")), n(3), S("", (e.delivery.delivered_by_user == null ? null : e.delivery.delivered_by_user.display_name) ? ? (e.delivery.delivered_by_user == null ? null : e.delivery.delivered_by_user.name), " "), n(), _(e.delivery != null && e.delivery.is_delivered_using_otp ? 38 : -1), n(), _(e.delivery.comment ? 39 : -1), n(), l("termAndCondition", e.delivery.term_and_condition), n(2), l("entityId", e.delivery == null ? null : e.delivery.id)("entityType", e.entityType)
    }
}
var ul = (() => {
    class t {
        constructor(e, o, i) {
            this.jobService = e, this.service = o, this.loaderService = i, this.formatMessage = g, this.configService = b(lt), this.userSessionService = b(L), this.activatedRouter = b(R), this.toastNotificationService = b(D), this.generalSettingDataService = b(te), this.isEmployee = this.userSessionService.isEmployee(), this.statusIconTypeList = he, this.ENTITIES = I, this.entityType = this.ENTITIES.JOB_DELIVERY.name, this.dateTime = new Date, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.PRINT_SETTINGS) ? ? Vt.getEmptyObject()
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("job_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("job_id"),
                    o = +this.activatedRouter.snapshot.paramMap.get("delivery_id");
                this.loaderService.show(), Ne([this.jobService.getDetailById(e), this.service.getById(o)]).subscribe({
                    next: ([i, p]) => {
                        this.configService.appConfig$.subscribe({
                            next: y => {
                                this.account = y
                            },
                            error: y => {
                                console.error("error fetching job details ", y)
                            }
                        }), this.job = i, this.delivery = p
                    },
                    error: i => {
                        this.toastNotificationService.error("notification_receipt_create_error"), console.error("Error creating receipt ", i)
                    }
                }).add(() => {
                    this.loaderService.hide()
                })
            }
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T(ci), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-delivery-receipt"]
                ],
                standalone: !1,
                decls: 12,
                vars: 13,
                consts: [
                    [1, "container-fluid", "mt-2", "mb-3"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [3, "jobId"],
                    ["stickerEntityName", "job_delivery_sticker", 1, "mx-1", 3, "entityId", "entityName", "isVisiblePrintButton", "isVisibleThermalPrint", "isVisibleStickerPrint"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["id", "print-section", 1, "container-fluid"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4"],
                    [1, "ps-4"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "ps-5"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "ps-4"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    ["alt", "Watermark", "height", "500", "src", "../../../../../../assets/images/otp-verified.png", "width", "500", 1, "verified"],
                    [1, "d-inline-block", 3, "innerHTML"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), u(3, "app-job-status-tag", 3), r(4, "span", 4), d(5), a(), r(6, "div", 5), m(7, L0, 1, 2, "app-send-whats-app-btn", 6), u(8, "app-job-btn", 7)(9, "app-print-button", 8)(10, "app-share-btn", 9), a()()()(), m(11, G0, 43, 24, "div", 10)), o & 2 && (n(3), l("iconType", i.statusIconTypeList.TITLE)("status", i.job == null ? null : i.job.status), n(2), S(" ", i.job == null ? null : i.job.job_number, " "), n(2), _(i.isEmployee ? 7 : -1), n(), l("jobId", i.job == null ? null : i.job.id), n(), l("entityId", i.delivery == null ? null : i.delivery.id)("entityName", i.ENTITIES.JOB_DELIVERY.name)("isVisiblePrintButton", !!(i.delivery != null && i.delivery.id))("isVisibleThermalPrint", !1)("isVisibleStickerPrint", !0), n(), l("entityId", i.delivery == null ? null : i.delivery.id)("entityType", i.ENTITIES.JOB_DELIVERY.name), n(), _(i.job ? 11 : -1))
                },
                dependencies: [Se, Xe, kt, xt, vt, Nt, ft, pt, Ze, ht, it, Dt, Ue],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function H0(t, c) {
    if (t & 1 && (r(0, "div", 0)(1, "div", 3)(2, "div", 4), u(3, "app-alert-panel", 5), a()()()), t & 2) {
        let e = s(2);
        n(3), l("message", e.formatMessage("invoice_pending_msg"))
    }
}

function Q0(t, c) {
    if (t & 1 && u(0, "app-alert-panel", 6), t & 2) {
        let e = s(3);
        l("message", e.formatMessage("invoice_update_warning"))
    }
}

function z0(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 7), t & 2 && l("rows", 6)("columns", 3)
}

function Y0(t, c) {
    if (t & 1 && u(0, "app-send-whats-app-btn", 15), t & 2) {
        let e = s(4);
        l("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityName", e.ENTITIES.JOB_INVOICE.name)
    }
}

function $0(t, c) {
    if (t & 1 && u(0, "app-send-notification", 16), t & 2) {
        let e = s(4);
        l("entityObj", e.jobInvoice)("entity", e.ENTITIES.JOB_INVOICE)("job", e.job)
    }
}

function K0(t, c) {
    if (t & 1 && u(0, "app-job-btn", 19), t & 2) {
        let e = s(4);
        l("jobId", e.job == null ? null : e.job.id)
    }
}

function X0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-dx-outline-button", 25), f("onClickEvent", function() {
            C(e);
            let i = s(4);
            return v(i.onEditClick())
        }), a()
    }
}

function Z0(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-btn", 26), f("saveBtnClick", function() {
            C(e);
            let i = s(4);
            return v(i.syncInvoiceWithJob())
        }), a()
    }
}

function eC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-dx-outline-button", 27), f("onClickEvent", function() {
            C(e);
            let i = s(4);
            return v(i.isVisibleSaveConfirmPopup = !0)
        }), a()
    }
}

function tC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-btn", 28), f("saveBtnClick", function() {
            C(e);
            let i = s(4);
            return v(i.isVisibleSaveConfirmPopup = !0)
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        Si("button-indicator"), l("isSaving", e.isSaving)
    }
}

function iC(t, c) {
    if (t & 1 && (r(0, "div", 36)(1, "div", 4)(2, "p", 41)(3, "span", 42), d(4), a(), r(5, "span", 43), d(6), V(7, "dateFormat"), a()()()()), t & 2) {
        let e = s(5);
        n(4), S("", e.formatMessage("printed_on"), " :"), n(2), S(" ", B(7, 2, e.today, "datetime"), " ")
    }
}

function nC(t, c) {
    if (t & 1 && u(0, "app-invoice-term-and-conditions", 38), t & 2) {
        let e = s(5);
        l("termAndCondition", e.jobInvoice == null ? null : e.jobInvoice.term_and_condition)
    }
}

function oC(t, c) {
    if (t & 1 && (r(0, "div", 36)(1, "app-control-container", 44), u(2, "app-textarea", 45), a()()), t & 2) {
        let e = s(5);
        n(), l("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions"))
    }
}

function aC(t, c) {
    t & 1 && u(0, "hr", 39)
}

function rC(t, c) {
    if (t & 1 && u(0, "app-invoice-signature", 40), t & 2) {
        let e = s(5);
        l("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityType", e.entityType)
    }
}

function sC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 24)(1, "div", 3)(2, "div", 4)(3, "div", 3)(4, "div", 4), u(5, "app-invoice-header", 29)(6, "app-invoice-title", 30)(7, "app-invoice-customer-detail", 31)(8, "app-invoice-job-details", 32), r(9, "div", 33)(10, "div", 4)(11, "h5", 34), d(12), a(), r(13, "div", 3)(14, "div", 4), u(15, "app-services-and-parts", 35), a()()()(), m(16, iC, 8, 5, "div", 36), r(17, "app-edit-input", 37), f("viewData", function(i) {
            C(e);
            let p = s(4);
            return v(p.onSaveData(i))
        }), a(), m(18, nC, 1, 1, "app-invoice-term-and-conditions", 38), m(19, oC, 3, 2, "div", 36), m(20, aC, 1, 0, "hr", 39), m(21, rC, 1, 2, "app-invoice-signature", 40), a()()()()()
    }
    if (t & 2) {
        let e = s(4);
        l("ngClass", e.isMobileDevice ? "p-0" : ""), n(5), l("account", e.account)("qrCode", e.jobInvoice && (e.printSettings == null ? null : e.printSettings.qr_code) && !e.isEditMode && (e.jobInvoice == null ? null : e.jobInvoice.qr_code)), n(), l("dateTime", e.jobInvoice == null ? null : e.jobInvoice.created_at)("revision", e.jobInvoice == null ? null : e.jobInvoice.revision)("title", ((e.printOptions == null ? null : e.printOptions.job_invoice_title) || "Tax Invoice:") + " " + e.form.getRawValue().invoice_number), n(), l("userId", e.job.user_id), n(), l("job", e.job), n(4), h(e.formatMessage("invoice_details")), n(3), l("entityId", e.entityId)("entityType", e.entityType)("isBarcode", e.isBarcode)("isEditMode", !1)("isJobView", !1)("job", e.job)("qrString", e.qrString), n(), _(e.jobInvoice != null && e.jobInvoice.id ? 16 : -1), n(), l("noteData", e.noteData), n(), _(e.isEditMode ? -1 : 18), n(), _(e.isEditMode ? 19 : -1), n(), _(e.jobInvoice != null && e.jobInvoice.id && !e.isEditMode ? 20 : -1), n(), _(e.jobInvoice != null && e.jobInvoice.id && !e.isEditMode ? 21 : -1)
    }
}

function lC(t, c) {
    if (t & 1 && (r(0, "form", 8)(1, "div", 9)(2, "div", 3)(3, "div", 4)(4, "div", 10)(5, "div", 11), u(6, "app-job-status-tag", 12), r(7, "span", 13), d(8), a()(), r(9, "div", 14), m(10, Y0, 1, 2, "app-send-whats-app-btn", 15), m(11, $0, 1, 3, "app-send-notification", 16), u(12, "app-print-button", 17)(13, "app-share-btn", 18), m(14, K0, 1, 1, "app-job-btn", 19), m(15, X0, 1, 0, "app-dx-outline-button", 20), m(16, Z0, 1, 0, "app-save-btn", 21), m(17, eC, 1, 0, "app-dx-outline-button", 22), m(18, tC, 1, 3, "app-save-btn", 23), a()()()()(), m(19, sC, 22, 22, "div", 24), a()), t & 2) {
        let e = s(3);
        l("formGroup", e.form), n(), l("ngClass", e.isMobileDevice ? "p-0" : ""), n(3), l("ngClass", e.isMobileDevice ? "d-flex justify-content-between align-items-center flex-wrap" : ""), n(), l("ngClass", e.isMobileDevice && "mb-2"), n(), l("iconType", e.statusIconTypeList.TITLE)("status", e.job == null ? null : e.job.status), n(2), S(" ", e.job == null ? null : e.job.job_number, " "), n(2), _(e.jobInvoice != null && e.jobInvoice.id && e.isEmployee && e.userPermissionList.includes(e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION) ? 10 : -1), n(), _(e.jobInvoice != null && e.jobInvoice.id && e.isEmployee ? 11 : -1), n(), l("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityName", e.ENTITIES.JOB_INVOICE.name)("isVisiblePrintButton", !!(e.jobInvoice != null && e.jobInvoice.id)), n(), l("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityType", e.ENTITIES.JOB_INVOICE.name), n(), _(e.isMobileDevice ? -1 : 14), n(), _(!e.isInvoiceNeedsToUpdate() && (e.jobInvoice != null && e.jobInvoice.id) && e.isEmployee && !e.isEditMode ? 15 : -1), n(), _(e.isInvoiceNeedsToUpdate() && (e.jobInvoice != null && e.jobInvoice.id) && e.isEmployee && !e.isEditMode ? 16 : -1), n(), _(e.jobInvoice != null && e.jobInvoice.id && e.isEmployee && e.isEditMode ? 17 : -1), n(), _(e.isEmployee && !(e.jobInvoice != null && e.jobInvoice.id) ? 18 : -1), n(), _(e.job && e.form ? 19 : -1)
    }
}

function cC(t, c) {
    if (t & 1 && (m(0, Q0, 1, 1, "app-alert-panel", 6), m(1, z0, 1, 2, "app-skeleton-loader", 7), m(2, lC, 20, 20, "form", 8)), t & 2) {
        let e = s(2);
        _(e.job != null && e.job.is_invoice_outdated ? 0 : -1), n(), _(e.form ? -1 : 1), n(), _(e.form ? 2 : -1)
    }
}

function dC(t, c) {
    t & 1 && (r(0, "div", 52)(1, "span", 59), d(2, "Print Payment Qr"), a(), u(3, "app-switch-btn", 60), a()), t & 2 && (n(3), l("formControlName", "is_generate_qr"))
}

function pC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 48), f("ngSubmit", function() {
            C(e);
            let i = s(3);
            return v(i.save())
        }), r(1, "dx-scroll-view", 49), u(2, "app-job-current-info", 32), r(3, "app-control-container", 50), u(4, "dx-date-box", 51), a(), m(5, dC, 4, 1, "div", 52), r(6, "app-edit-input", 53), f("viewData", function(i) {
            C(e);
            let p = s(3);
            return v(p.onSaveData(i))
        }), a(), r(7, "app-control-container", 44), u(8, "app-textarea", 45), a(), r(9, "div", 3)(10, "app-control-container", 54), u(11, "app-textarea", 55), a()(), r(12, "div", 56), u(13, "app-user-notification-channel", 57), a()(), r(14, "app-save-cancel-footer", 58), f("cancelClick", function() {
            C(e);
            let i = s(3);
            return v(i.isVisibleSaveConfirmPopup = !1)
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        l("formGroup", e.form), n(2), l("job", e.job), n(), l("errorMsg", e.formatMessage("common_error_messages_due_date"))("label", e.formatMessage("common_due_date")), n(), l("min", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("select_from_calendar")), n(), _(e.isPrintPaymentQr ? 5 : -1), n(), l("noteData", e.noteData)("isEditMode", !0), n(), l("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions")), n(3), l("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("comment")), n(3), l("form", e.form), n(), l("gaEvent", "create_update_invoice_event")("isOnPopup", !0)("isSaving", e.isSaving)("saveText", e.jobInvoice != null && e.jobInvoice.id ? "update_invoice" : "create_invoice")
    }
}

function mC(t, c) {
    if (t & 1 && (r(0, "div", 46), m(1, pC, 15, 19, "form", 47), a()), t & 2) {
        let e = s(2);
        n(), _(e.form ? 1 : -1)
    }
}

function _C(t, c) {
    if (t & 1) {
        let e = x();
        m(0, H0, 4, 1, "div", 0)(1, cC, 3, 3), r(2, "dx-popup", 1), f("onHidden", function() {
            C(e);
            let i = s();
            return v(i.isVisibleSaveConfirmPopup = !1)
        }), j("visibleChange", function(i) {
            C(e);
            let p = s();
            return O(p.isVisibleSaveConfirmPopup, i) || (p.isVisibleSaveConfirmPopup = i), v(i)
        }), E(3, mC, 2, 1, "div", 2), a()
    }
    if (t & 2) {
        let e = s();
        _(!e.isEmployee && !(e.jobInvoice != null && e.jobInvoice.id) ? 0 : 1), n(2), w("visible", e.isVisibleSaveConfirmPopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 600)("title", e.formatMessage("invoice_confirmation")), n(), l("dxTemplateOf", "content")
    }
}
var la = (() => {
    class t {
        constructor(e, o, i, p, y) {
            this.service = e, this.jobService = o, this.tableSequenceNumberService = i, this.termAndConditionService = p, this.loaderService = y, this.formatMessage = g, this.formService = b(me), this.generalSettingDataService = b(te), this.dataService = b(qe), this.configService = b(lt), this.userSessionService = b(L), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.tenantService = b(ve), this.notifDefaults = b(si), this.today = new Date, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.SETTINGS = F, this.ENTITIES = I, this.isVisibleSaveConfirmPopup = !1, this.isSaving = !1, this.entityId = null, this.entityType = null, this.isEditMode = !1, this.isBarcode = !1, this.isPrintPaymentQr = !1, this.isVisibleRevisedConfirmationPopup = !1, this.isInvoiceNeedsToUpdate = Y(!1), this.isComponentVisible = Y(!0), this.printOptions = null, this.PERMISSION_LIST = M, this.statusIconTypeList = he, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.PRINT_SETTINGS) ? ? Vt.getEmptyObject()
        }
        ngOnInit() {
            this.printOptions = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.PRINT_SETTINGS) ? ? null, this.initializeJobData()
        }
        onSaveData(e) {
            this.noteData = e
        }
        showPaymentQrOption() {
            this.isPrintPaymentQr = this.job.payment_status === Fn.UNPAID, this.form.patchValue({
                is_generate_qr: this.isPrintPaymentQr && this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.PRINT_SETTINGS.PAYMENT_QR)
            })
        }
        save() {
            this.form.patchValue({
                total_amount: this.partSum.line_total + this.serviceSum.line_total,
                tax_amount: this.partSum.tax_amount + this.serviceSum.tax_amount,
                note: this.noteData,
                status: this.job ? .payment_status
            }), this.form.valid ? (this.isSaving = !0, (this.jobInvoice ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.toastNotificationService.success("notification_invoice_save_success"), this.jobInvoice = null, this.jobInvoice = o, this.entityType = this.ENTITIES.JOB_INVOICE.name, this.entityId = this.jobInvoice.id, this.form.patchValue(new Zi(this.jobInvoice)), this.isEditMode = !1, o.qr_string && this.saveQrString()
                },
                error: o => {
                    this.toastNotificationService.showErrorInNotifier(o)
                }
            }).add(() => {
                this.isSaving = !1, this.isVisibleSaveConfirmPopup = !1
            })) : (this.formService.validateFormFields(this.form), this.toastNotificationService.error("common_error_messages_status_required"))
        }
        onEditClick() {
            this.isEditMode = !0, this.isVisibleSaveConfirmPopup = !0
        }
        syncInvoiceWithJob() {
            this.service.syncInvoiceWithJob(this.jobInvoice.id).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_invoice_sync_success"), this.isVisibleRevisedConfirmationPopup = !1, this.jobInvoice = null, this.reloadTheComponent()
                },
                error: e => {
                    this.toastNotificationService.error("notification_invoice_sync_error"), console.error(e)
                }
            })
        }
        initializeJobData() {
            if (this.activatedRouter.snapshot.paramMap.has("job_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("job_id"),
                    o = +this.activatedRouter.snapshot.paramMap.get("invoice_id");
                this.loaderService.show();
                let i = [this.jobService.getDetailById(e)];
                this.isEmployee && i.push(this.tableSequenceNumberService.getListByQuery({
                    name: Ii.SERVICE_INVOICE.name
                }), this.termAndConditionService.getByTypeId({
                    type_id: at.JOB_INVOICE
                })), o ? i.push(this.service.getById(o)) : i.push(this.service.getByJobId(e)), Ne(i).subscribe({
                    next: p => {
                        let y = p[0],
                            je = null,
                            Pt = null,
                            Rt = null;
                        this.isEmployee ? (je = p[1], Pt = p[2], Rt = p[3]) : Rt = p[1], this.configService.appConfig$.subscribe({
                            next: pi => {
                                this.account = pi
                            },
                            error: pi => {
                                console.error(pi)
                            }
                        }), this.job = new Ee(y), this.jobService.currentJobSource.next(this.job), Rt && (this.jobInvoice = new Zi(Rt), this.noteData = this.jobInvoice ? .note), this.jobInvoice ? .id ? (this.entityId = this.jobInvoice ? .id, this.entityType = this.ENTITIES.JOB_INVOICE.name, this.form = Zi.getForm(this.jobInvoice, this.tenantService.timezone()), this.jobInvoice ? .qr_string && this.saveQrString(), this.isInvoiceNeedsToUpdate.set(this.job.is_invoice_outdated)) : this.isEmployee && this.prepareNewJobInvoiceForm(je, Pt)
                    },
                    error: p => {
                        console.error(p)
                    }
                }).add(() => {
                    this.loaderService.hide(), this.jobInvoice ? .id && this.job.is_invoice_outdated === !1 && this.isInvoiceNeedsToUpdate.set(!1)
                }), this.subscribeToDataChanges()
            }
        }
        prepareNewJobInvoiceForm(e, o) {
            this.entityId = this.job.id, this.entityType = this.ENTITIES.JOB.name, this.form = Zi.getForm(new Zi({
                invoice_number: e[0].current_value,
                job_id: this.job.id,
                term_and_condition: o ? .text,
                auto_round_off: this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.AUTO_ROUND_OFF)
            }), this.tenantService.timezone(), this.notifDefaults.getEntityDefaults(Et.JOB_INVOICE)), this.showPaymentQrOption()
        }
        subscribeToDataChanges() {
            this.dataService.currentJobPartTotal$.subscribe({
                next: e => this.partSum = e,
                error: e => console.error(e)
            }), this.dataService.currentJobServiceTotal$.subscribe({
                next: e => this.serviceSum = e,
                error: e => console.error(e)
            })
        }
        saveQrString() {
            this.isBarcode = !0, this.qrString = this.jobInvoice.qr_string
        }
        reloadTheComponent() {
            this.isComponentVisible.set(!1), this.initializeJobData(), setTimeout(() => {
                this.isComponentVisible.set(!0)
            }, 0)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ls), T(U), T(tn), T(Ct), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-invoice"]
                ],
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [1, "container-fluid"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "message"],
                    ["alertClass", "alert-warning", 3, "message"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "p-0", 3, "ngClass"],
                    [3, "ngClass"],
                    [1, "float-start", "m-1", "mb-md-1", "mb-0", 3, "iconType", "status"],
                    [1, "title-text", "float-start", "mt-1", "mb-1"],
                    [1, "print-actions-bar"],
                    [1, "me-1", 3, "entityId", "entityName"],
                    [3, "entityObj", "entity", "job"],
                    [1, "me-1", 3, "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    [1, "me-1", 3, "jobId"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "float-end", "me-1"],
                    ["saveText", "sync_with_job", 1, "me-1"],
                    ["buttonType", "default", "text", "common_update", "title", "common_update", 1, "float-end", "me-1"],
                    ["saveText", "create_invoice", "savingText", "creating_invoice", 1, "me-1", 3, "class", "isSaving"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "float-end", "me-1", 3, "onClickEvent"],
                    ["saveText", "sync_with_job", 1, "me-1", 3, "saveBtnClick"],
                    ["buttonType", "default", "text", "common_update", "title", "common_update", 1, "float-end", "me-1", 3, "onClickEvent"],
                    ["saveText", "create_invoice", "savingText", "creating_invoice", 1, "me-1", 3, "saveBtnClick", "isSaving"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "revision", "title"],
                    [3, "userId"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [3, "entityId", "entityType", "isBarcode", "isEditMode", "isJobView", "job", "qrString"],
                    [1, "row", "mt-3"],
                    [3, "viewData", "noteData"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "float-end"],
                    [1, "fw-bolder"],
                    [1, "px-1"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition"],
                    [1, "d-flex", "flex-column", "h-100"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    ["name", "due_date", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "due_date", "id", "job-invoice-due-date", "type", "date", 3, "min", "pickerType", "placeholder"],
                    [1, "mb-2", "d-flex"],
                    [3, "viewData", "noteData", "isEditMode"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "comment"],
                    [1, "mt-3"],
                    [3, "form"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving", "saveText"],
                    [1, "me-2"],
                    [3, "formControlName"]
                ],
                template: function(o, i) {
                    o & 1 && m(0, _C, 4, 7), o & 2 && _(i.isComponentVisible() ? 0 : -1)
                },
                dependencies: [Q, Se, Vi, Xe, ee, et, Fe, K, Ki, kt, xt, vt, Nt, ft, pt, Ze, ht, tt, Yi, it, ue, ge, _e, Sr, W, Jt, H, ye, pe, q, re, le, se, Mo, Ue],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var Bt = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c, e) {
        return new Je().group(Ge(Te({
            id: [c.id || null],
            quotation_number: [c.quotation_number || null],
            quotationable_type: [c.quotationable_type || null],
            quotationable_id: [c.quotationable_id || null],
            status: [c.status || Ei.AWAITING_APPROVAL],
            user_id: [c.user_id || null, [de.required]],
            approval_user_id: [c.approval_user_id || null],
            total_amount: [c.total_amount || null],
            tax_amount: [c.tax_amount || null],
            custom_fields: lr.getFormArray(c.custom_fields),
            notification_entity_type: [Za.QUOTATION]
        }, Wi(c, e)), {
            comment: new k(null),
            note: new k(null),
            auto_round_off: [c.auto_round_off || !1],
            term_and_condition: new k(c.term_and_condition || null),
            expired_at: new k(c.expired_at || null)
        }))
    }
};
var Cl = (() => {
    class t extends Be {
        constructor(e) {
            super(e, Ro), this.api = e, this.endpoint = Ro
        }
        getByQuery(e) {
            return this.api.getWithParams(this.endpoint + "/getByQuery", e)
        }
        getHistory(e) {
            return this.api.get(this.endpoint + `/${e}/history`)
        }
        approve(e, o) {
            return this.api.post(this.endpoint + `/${e}/approve`, o)
        }
        reject(e, o) {
            return this.api.post(this.endpoint + `/${e}/reject`, o)
        }
        reviseQuotation(e) {
            return this.api.post(this.endpoint + `/reviseQuotation/${e}`)
        }
        submitQuotation(e, o) {
            return this.api.post(this.endpoint + `/submitQuotation/${e}`, o)
        }
        exportToFile(e, o) {
            return this.api.exportToFile(this.endpoint + "/" + e, o)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Qe(Ie))
            }
        }
        static {
            this.\u0275prov = Pe({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var vl = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.buttonText = "Actions", this.quotationContextMenuOnAction = new J, this.ENTITIES = I, this.router = b(G), this.userSessionService = b(L), this.isMobileDevice = b(A).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.isVisibleSendPopup = !1, this.quotationContextMenuList = $a, this.selectedContextMenuItem = null, this.contextMenuItems = []
        }
        ngOnInit() {
            this.contextMenuItems = [{
                name: this.quotationContextMenuList.JOB_SHEET,
                icon: Ut.QUOTATION.light,
                visible: !0,
                text: g("job_sheet_label")
            }, {
                name: this.quotationContextMenuList.INVOICE,
                icon: Ut.INVOICE.light,
                visible: !0,
                text: g("job_label_invoice")
            }, {
                name: this.quotationContextMenuList.SEND,
                icon: Ot.SEND.light,
                visible: this.isEmployee,
                text: g("common_send_notification")
            }]
        }
        onContextMenuItemClick(e) {
            this.selectedContextMenuItem = e.itemData.name, this.selectedContextMenuItem === this.quotationContextMenuList.JOB_SHEET && this.router.navigate([`/jobs/${this.job.id}/jobSheets`]), this.selectedContextMenuItem === this.quotationContextMenuList.INVOICE && this.router.navigate([`/jobs/${this.job.id}/invoices`]), this.selectedContextMenuItem === this.quotationContextMenuList.VIEW_JOB && this.router.navigate([`/jobs/${this.job.id}/details`]), this.selectedContextMenuItem === this.quotationContextMenuList.SEND && (this.isVisibleSendPopup = !0)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-quotation-context-menu"]
                ],
                inputs: {
                    job: "job",
                    jobQuotation: "jobQuotation",
                    buttonText: "buttonText"
                },
                outputs: {
                    quotationContextMenuOnAction: "quotationContextMenuOnAction"
                },
                standalone: !1,
                decls: 2,
                vars: 11,
                consts: [
                    ["displayExpr", "text", "keyExpr", "name", 3, "onItemClick", "items", "text", "icon", "showArrowIcon", "stylingMode", "type"],
                    [3, "sendNotificationClose", "sendNotificationSave", "entityObj", "entity", "isVisiblePopup", "isVisibleSendButton", "job"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-drop-down-button", 0), f("onItemClick", function(y) {
                        return i.onContextMenuItemClick(y)
                    }), a(), r(1, "app-send-notification", 1), f("sendNotificationClose", function() {
                        return i.isVisibleSendPopup = !1
                    })("sendNotificationSave", function() {
                        return i.isVisibleSendPopup = !1
                    }), a()), o & 2 && (l("items", i.contextMenuItems)("text", i.isMobileDevice ? "" : i.buttonText)("icon", i.isMobileDevice ? "fa-thin fa-gear" : "")("showArrowIcon", !i.isMobileDevice)("stylingMode", i.isMobileDevice ? "text" : "outlined")("type", i.isMobileDevice ? "normal" : "default"), n(), l("entityObj", i.jobQuotation)("entity", i.ENTITIES.QUOTATION)("isVisiblePopup", i.isVisibleSendPopup)("isVisibleSendButton", !1)("job", i.job))
                },
                dependencies: [tt, Ai],
                encapsulation: 2
            })
        }
    }
    return t
})();
var vC = () => ({
        standalone: !0
    }),
    fl = t => [t],
    fC = (t, c) => [t, c];

function hC(t, c) {
    if (t & 1 && (r(0, "div", 0)(1, "div", 5)(2, "div", 6)(3, "div", 7), d(4), a()()()()), t & 2) {
        let e = s();
        n(4), S(" ", e.formatMessage("quotation_not_generated_message"), " ")
    }
}

function bC(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 8), t & 2 && l("rows", 6)("columns", 3)
}

function gC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-select-box", 21), f("onItemClick", function(i) {
            C(e);
            let p = s(3);
            return v(p.onQuotationRevisionChange(i))
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.currentQuotationId, i) || (p.currentQuotationId = i), v(i)
        }), a()
    }
    if (t & 2) {
        let e = s(3);
        w("ngModel", e.currentQuotationId), l("ngModelOptions", Ye(4, vC))("items", e.quotationList)("searchEnabled", !1)
    }
}

function xC(t, c) {
    if (t & 1 && u(0, "app-send-whats-app-btn", 15), t & 2) {
        let e = s(3);
        l("entityId", e.quotation == null ? null : e.quotation.id)("entityName", e.ENTITIES.QUOTATION.name)
    }
}

function SC(t, c) {
    if (t & 1 && u(0, "app-job-btn", 16), t & 2) {
        let e = s(3);
        l("jobId", e.job == null ? null : e.job.id)
    }
}

function yC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 25), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.showApprovalPopupUp(!1))
        }), a(), r(1, "dx-button", 26), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.showApprovalPopupUp(!0))
        }), a()
    }
    if (t & 2) {
        let e = s(5);
        l("title", e.formatMessage("reject"))("text", e.formatMessage("reject")), n(), l("title", e.formatMessage("approve"))("text", e.formatMessage("approve"))
    }
}

function TC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 27), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.showApprovalPopupUp(!1))
        }), a(), r(1, "dx-button", 28), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.showApprovalPopupUp(!0))
        }), a()
    }
    if (t & 2) {
        let e = s(5);
        l("title", e.formatMessage("reject")), n(), l("title", e.formatMessage("approve"))
    }
}

function MC(t, c) {
    if (t & 1 && (m(0, yC, 2, 4), m(1, TC, 2, 2)), t & 2) {
        let e = s(4);
        _(fe(2, fl, e.quotationStatuses.AWAITING_APPROVAL).includes(e.quotation == null ? null : e.quotation.status) && !e.isMobileDevice ? 0 : -1), n(), _(fe(4, fl, e.quotationStatuses.AWAITING_APPROVAL).includes(e.quotation == null ? null : e.quotation.status) && e.isMobileDevice ? 1 : -1)
    }
}

function PC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 26), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.isVisibleRevisedConfirmationPopup = !0)
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("title", e.formatMessage("common_edit"))("text", e.formatMessage("common_edit"))
    }
}

function IC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 26), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.showSaveConfirmationPopup())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("title", e.formatMessage("common_update"))("text", e.formatMessage("common_update"))
    }
}

function EC(t, c) {
    if (t & 1 && (u(0, "app-print-button", 22)(1, "app-share-btn", 23), m(2, MC, 2, 6), m(3, PC, 1, 2, "dx-button", 24), m(4, IC, 1, 2, "dx-button", 24)), t & 2) {
        let e = s(3);
        l("entityId", e.quotation == null ? null : e.quotation.id)("entityName", e.ENTITIES.JOB_QUOTATION.name)("isVisiblePrintButton", !!(e.quotation != null && e.quotation.id)), n(), l("entityId", e.quotation == null ? null : e.quotation.id)("entityType", e.ENTITIES.JOB_QUOTATION.name), n(), _(e.userPermissionList.includes(e.PERMISSION_LIST.QUOTATION_APPROVE_OR_REJECT) ? 2 : -1), n(), _(e.quotation != null && e.quotation.id && e.isEmployee && !e.isEditMode && e.userPermissionList.includes(e.PERMISSION_LIST.QUOTATION_WRITE) ? 3 : -1), n(), _(e.quotation != null && e.quotation.id && e.isEmployee && e.isEditMode && e.userPermissionList.includes(e.PERMISSION_LIST.QUOTATION_WRITE) ? 4 : -1)
    }
}

function wC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-btn", 30), f("saveBtnClick", function() {
            C(e);
            let i = s(4);
            return v(i.showSaveConfirmationPopup())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("isSaving", e.isSaving)
    }
}

function OC(t, c) {
    if (t & 1 && m(0, wC, 1, 1, "app-save-btn", 29), t & 2) {
        let e = s(3);
        _(e.isEmployee && !(e.quotation != null && e.quotation.id) && e.userPermissionList.includes(e.PERMISSION_LIST.QUOTATION_WRITE) ? 0 : -1)
    }
}

function jC(t, c) {
    if (t & 1 && u(0, "app-quotation-context-menu", 18), t & 2) {
        let e = s(3);
        l("jobQuotation", e.quotation)("job", e.job)
    }
}

function VC(t, c) {
    if (t & 1 && (r(0, "div", 31), d(1), r(2, "span", 32), d(3, ":"), a(), r(4, "span", 35), d(5), a()()), t & 2) {
        let e = s(4);
        n(), S(" ", e.formatMessage("quotation_status"), " "), n(4), h(e.quotation == null ? null : e.quotation.status)
    }
}

function DC(t, c) {
    if (t & 1 && u(0, "app-user-badge", 36), t & 2) {
        let e = s(5);
        l("iconOnly", !1)("user", e.quotation == null ? null : e.quotation.approved_user)
    }
}

function kC(t, c) {
    if (t & 1 && (r(0, "div", 33), d(1), m(2, DC, 1, 2, "app-user-badge", 36), a()), t & 2) {
        let e = s(4);
        n(), S(" ", e.quotation.status === e.quotationStatuses.APPROVED ? e.formatMessage("approved_by") : e.formatMessage("rejected_by"), " : "), n(), _(e.quotation.approved_user ? 2 : -1)
    }
}

function NC(t, c) {
    if (t & 1 && (r(0, "div", 31), d(1), r(2, "span", 32), d(3, ":"), a(), d(4), V(5, "dateFormat"), a()), t & 2) {
        let e = s(4);
        n(), S("", e.formatMessage("approved_on"), " "), n(3), S(" ", B(5, 2, e.quotation == null ? null : e.quotation.approved_at, "datetime"), " ")
    }
}

function AC(t, c) {
    if (t & 1 && (r(0, "div", 31), d(1), r(2, "span", 32), d(3, ":"), a(), d(4), V(5, "dateFormat"), a()), t & 2) {
        let e = s(4);
        n(), S(" ", e.formatMessage("rejected_on")), n(3), S(" ", B(5, 2, e.quotation == null ? null : e.quotation.approved_at, "datetime"), " ")
    }
}

function JC(t, c) {
    if (t & 1 && (r(0, "div", 31), d(1), r(2, "span", 32), d(3, ":"), a(), r(4, "span", 37), d(5), a()()), t & 2) {
        let e = s(4);
        n(), h(e.formatMessage("quotation_status")), n(4), h(e.quotation == null ? null : e.quotation.status)
    }
}

function LC(t, c) {
    if (t & 1 && (r(0, "div", 31), d(1), r(2, "span", 38), d(3), a()()), t & 2) {
        let e = s(4);
        n(), S(" ", e.formatMessage("quotation_status"), " : "), n(), l("ngClass", (e.quotation == null ? null : e.quotation.status) === e.quotationStatuses.MODIFIED ? "bg-info" : "bg-warning"), n(), h(e.quotation == null ? null : e.quotation.status)
    }
}

function BC(t, c) {
    t & 1 && u(0, "app-currency-symbol")
}

function RC(t, c) {
    if (t & 1 && (r(0, "div", 34)(1, "div", 39), d(2), r(3, "span", 32), d(4, ":"), a()(), u(5, "div", 40), V(6, "safe"), a()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("quotation_comment")), n(3), l("innerHTML", B(6, 2, e.quotation == null ? null : e.quotation.comment, "html"), We)
    }
}

function UC(t, c) {
    if (t & 1 && (r(0, "div", 34)(1, "div", 41), d(2), a(), u(3, "div", 40), V(4, "safe"), a()), t & 2) {
        let e = s(4);
        n(2), S("", (e.quotation == null ? null : e.quotation.status) === e.quotationStatuses.APPROVED ? e.formatMessage("quotation_approval_comment") : e.formatMessage("quotation_rejected_comment"), " : "), n(), l("innerHTML", B(4, 2, e.quotation == null ? null : e.quotation.approval_comment, "html"), We)
    }
}

function FC(t, c) {
    if (t & 1 && (r(0, "div", 19)(1, "div", 5)(2, "div", 31), d(3), r(4, "span", 32), d(5, ":"), a(), d(6), a(), r(7, "div", 31), d(8), r(9, "span", 32), d(10, ":"), a(), d(11), a(), m(12, VC, 6, 2, "div", 31), m(13, kC, 3, 2, "div", 33), m(14, NC, 6, 5, "div", 31), m(15, AC, 6, 5, "div", 31), m(16, JC, 6, 2, "div", 31), m(17, LC, 4, 3, "div", 31), r(18, "div", 31), d(19), m(20, BC, 1, 0, "app-currency-symbol"), d(21), V(22, "number"), a()(), m(23, RC, 7, 5, "div", 34), m(24, UC, 5, 5, "div", 34), a()), t & 2) {
        let e = s(3);
        l("ngClass", e.isMobileDevice ? "p-0" : ""), n(3), h(e.formatMessage("job_sheet_number")), n(3), S(" ", e.job == null ? null : e.job.job_number, " "), n(2), h(e.formatMessage("quotation_number")), n(3), S(" ", e.quotation == null ? null : e.quotation.quotation_number, " "), n(), _(e.quotation.status === e.quotationStatuses.APPROVED ? 12 : -1), n(), _(e.quotation.status === e.quotationStatuses.APPROVED || e.quotation.status === e.quotationStatuses.REJECTED ? 13 : -1), n(), _(e.quotation.status === e.quotationStatuses.APPROVED ? 14 : -1), n(), _(e.quotation.status === e.quotationStatuses.REJECTED ? 15 : -1), n(), _(e.quotation.status === e.quotationStatuses.REJECTED ? 16 : -1), n(), _((e.quotation == null ? null : e.quotation.status) !== e.quotationStatuses.APPROVED && (e.quotation == null ? null : e.quotation.status) !== e.quotationStatuses.REJECTED ? 17 : -1), n(2), S("", e.formatMessage("quotation_amount"), " : "), n(), _(e.quotation != null && e.quotation.total_amount ? 20 : -1), n(), S(" ", B(22, 16, e.quotation == null ? null : e.quotation.total_amount, "1.2-2"), " "), n(2), _(e.quotation != null && e.quotation.comment ? 23 : -1), n(), _(yi(19, fC, e.quotationStatuses.APPROVED, e.quotationStatuses.REJECTED).includes(e.quotation == null ? null : e.quotation.status) && (e.quotation != null && e.quotation.approval_comment) ? 24 : -1)
    }
}

function qC(t, c) {
    if (t & 1 && u(0, "app-invoice-term-and-conditions", 50), t & 2) {
        let e = s(4);
        l("termAndCondition", e.quotation == null ? null : e.quotation.term_and_condition)
    }
}

function GC(t, c) {
    if (t & 1 && (r(0, "div", 51)(1, "app-control-container", 54), u(2, "app-textarea", 55), a()()), t & 2) {
        let e = s(4);
        n(), l("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions"))
    }
}

function WC(t, c) {
    t & 1 && u(0, "hr", 52)
}

function HC(t, c) {
    if (t & 1 && u(0, "app-invoice-signature", 53), t & 2) {
        let e = s(4);
        l("entityId", e.quotation == null ? null : e.quotation.id)("entityType", e.entityType)
    }
}

function QC(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 20)(1, "div", 5)(2, "div", 6)(3, "div", 5)(4, "div", 6), u(5, "app-invoice-header", 42)(6, "app-invoice-title", 43), r(7, "div", 5)(8, "div", 6), u(9, "app-invoice-customer-detail", 44)(10, "app-invoice-job-details", 45), a()(), r(11, "div", 46)(12, "div", 6)(13, "h5", 47), d(14), a(), r(15, "div", 5)(16, "div", 6), u(17, "app-services-and-parts", 48), a()()()(), r(18, "app-edit-input", 49), f("viewData", function(i) {
            C(e);
            let p = s(3);
            return v(p.onSaveData(i))
        }), a(), m(19, qC, 1, 1, "app-invoice-term-and-conditions", 50), m(20, GC, 3, 2, "div", 51), m(21, WC, 1, 0, "hr", 52), m(22, HC, 1, 2, "app-invoice-signature", 53), a()()()()()
    }
    if (t & 2) {
        let e = s(3);
        l("ngClass", e.isMobileDevice ? "p-0" : ""), n(5), l("account", e.account)("qrCode", e.quotation && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.quotation == null ? null : e.quotation.qr_code)), n(), l("dateTime", e.quotation == null ? null : e.quotation.created_at)("revision", e.quotation == null ? null : e.quotation.revision)("title", e.formatMessage("quotation_name") + " : " + e.form.getRawValue().quotation_number), n(3), l("userId", e.job.user_id), n(), l("job", e.job), n(4), h(e.formatMessage("quotation_details")), n(3), l("entityId", e.entityId)("entityType", e.entityType)("isEditMode", e.isEditMode)("isJobView", !1), n(), l("isEditMode", e.isEditMode)("noteData", e.noteData), n(), _(e.isEditMode ? -1 : 19), n(), _(e.isEditMode ? 20 : -1), n(), _(e.quotation != null && e.quotation.id && !e.isEditMode ? 21 : -1), n(), _(e.quotation != null && e.quotation.id && !e.isEditMode ? 22 : -1)
    }
}

function zC(t, c) {
    if (t & 1 && (r(0, "form", 9)(1, "div", 0)(2, "div", 5)(3, "div", 10), u(4, "app-job-status-tag", 11), r(5, "span", 12), d(6), a()(), r(7, "div", 6)(8, "div", 13), m(9, gC, 1, 5, "dx-select-box", 14), m(10, xC, 1, 2, "app-send-whats-app-btn", 15), m(11, SC, 1, 1, "app-job-btn", 16), m(12, EC, 5, 8)(13, OC, 1, 1), r(14, "div", 17), m(15, jC, 1, 2, "app-quotation-context-menu", 18), a()()()()(), m(16, FC, 25, 22, "div", 19), m(17, QC, 23, 19, "div", 20), a()), t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(3), l("ngClass", e.isMobileDevice && "mb-2"), n(), l("iconType", e.statusIconTypeList.TITLE)("status", e.job == null ? null : e.job.status), n(2), S(" ", e.job == null ? null : e.job.job_number, " "), n(3), _(e.quotationList.length > 1 ? 9 : -1), n(), _(e.quotation != null && e.quotation.id && e.userPermissionList.includes(e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION) && (e.quotation == null ? null : e.quotation.status) !== e.quotationStatuses.MODIFIED && e.isEmployee ? 10 : -1), n(), _(e.isMobileDevice ? -1 : 11), n(), _(e.quotation != null && e.quotation.id ? 12 : 13), n(3), _(e.quotation != null && e.quotation.id ? 15 : -1), n(), _(e.quotation != null && e.quotation.id ? 16 : -1), n(), _(e.job && e.form ? 17 : -1)
    }
}

function YC(t, c) {
    if (t & 1 && (m(0, bC, 1, 2, "app-skeleton-loader", 8), m(1, zC, 18, 12, "form", 9)), t & 2) {
        let e = s();
        _(e.form ? -1 : 0), n(), _(e.form ? 1 : -1)
    }
}

function $C(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 58), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.save())
        }), r(1, "dx-scroll-view", 59), u(2, "app-job-current-info", 45), r(3, "div"), d(4), a(), r(5, "app-control-container", 60)(6, "app-quick-reply-dropdown", 61), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.quickReplyValue(i))
        }), a(), u(7, "app-textarea", 62), a(), r(8, "div", 63), u(9, "app-user-notification-channel", 64), a()(), r(10, "app-save-cancel-footer", 65), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.isClosingPopup())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.form), n(2), l("job", e.job), n(2), S(" ", e.quotation != null && e.quotation.id ? e.formatMessage("job_update_quotation_confirmation") : e.formatMessage("job_save_quotation_confirmation"), " "), n(), l("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("labels_comment")), n(2), l("quickReply", e.approvalComment), n(2), l("form", e.form), n(), l("gaEvent", "create_update_quotations_event")("isOnPopup", !0)("isSaving", e.isSaving)("saveText", e.quotation != null && e.quotation.id ? e.isMobileDevice ? "common_update" : "update_quotation" : e.isMobileDevice ? "common_create" : "create_quotation")
    }
}

function KC(t, c) {
    if (t & 1 && (r(0, "div", 56), m(1, $C, 11, 11, "form", 57), a()), t & 2) {
        let e = s();
        n(), _(e.form ? 1 : -1)
    }
}

function XC(t, c) {
    if (t & 1 && u(0, "app-user-notification-channel", 64), t & 2) {
        let e = s(3);
        l("form", e.approveRejectForm)
    }
}

function ZC(t, c) {
    if (t & 1 && u(0, "app-server-error", 67), t & 2) {
        let e = s(3);
        l("errorResponse", e.errorResponse)
    }
}

function ev(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 58), f("ngSubmit", function() {
            C(e);
            let i = s(2);
            return v(i.updateQuotationApproval())
        }), r(1, "dx-scroll-view", 59), u(2, "app-job-current-info", 45), r(3, "div", 39), d(4), a(), r(5, "app-control-container", 66)(6, "app-quick-reply-dropdown", 61), f("itemClick", function(i) {
            C(e);
            let p = s(2);
            return v(p.quickReplyValue(i))
        }), a(), u(7, "app-textarea", 62), a(), m(8, XC, 1, 1, "app-user-notification-channel", 64), m(9, ZC, 1, 1, "app-server-error", 67), a(), r(10, "app-save-cancel-footer", 68), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.isClosingPopup())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        l("formGroup", e.approveRejectForm), n(2), l("job", e.job), n(2), S(" ", e.isApproving ? e.formatMessage("approve_quotation_confirmation") : e.formatMessage("reject_quotation_confirmation"), " "), n(), l("errorMsg", e.formatMessage("common_error_messages_comment_required"))("label", e.formatMessage("comment")), n(2), l("quickReply", e.approvalComment), n(), _(e.isEmployee ? 8 : -1), n(), _(e.errorResponse ? 9 : -1), n(), l("gaEvent", "approve_reject_quotation_event")("isOnPopup", !0)("isSaving", e.isSaving)("saveText", e.isApproving ? "approve_quotation" : "reject_quotation")("savingText", e.isApproving ? "approving" : "rejecting")
    }
}

function tv(t, c) {
    if (t & 1 && (r(0, "div", 56), m(1, ev, 11, 13, "form", 57), a()), t & 2) {
        let e = s();
        n(), _(e.approveRejectForm ? 1 : -1)
    }
}

function iv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-confirmation-popup", 69), f("confirmActionCallback", function() {
            C(e);
            let i = s();
            return v(i.reviseQuotation())
        })("rejectActionCallback", function() {
            C(e);
            let i = s();
            return v(i.isVisibleRevisedConfirmationPopup = !1)
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("confirmationMessage", e.formatMessage("job_edit_quotation_confirmation"))
    }
}
var ca = (() => {
    class t {
        constructor(e, o, i, p, y) {
            this.service = e, this.jobService = o, this.tableSequenceNumberService = i, this.termAndConditionService = p, this.loaderService = y, this.formatMessage = g, this.formService = b(me), this.whatsappService = b(Ke), this.generalSettingDataService = b(te), this.dataService = b(qe), this.configService = b(lt), this.userSessionService = b(L), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.notifDefaults = b(si), this.fb = new Je, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.statusIconTypeList = he, this.ENTITIES = I, this.quotationStatuses = Ei, this.approvalComment = null, this.isVisibleSaveConfirmPopup = !1, this.isVisibleApprovalPopup = !1, this.isVisibleRevisedConfirmationPopup = !1, this.quotationList = [], this.isSaving = !1, this.isEditMode = !1, this.isApproving = !1, this.errorResponse = null, this.isLoading = !1, this.entityId = null, this.entityType = null, this.noteData = null, this.PERMISSION_LIST = M, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.PRINT_SETTINGS) ? ? Vt.getEmptyObject()
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("job_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("job_id"),
                    o = +this.activatedRouter.snapshot.paramMap.get("quotation_id");
                this.loaderService.show(), this.isLoading = !0;
                let i = {
                        job_id: e,
                        quotation_id: o
                    },
                    p = [this.jobService.getDetailById(e), this.service.getByQuery(i)];
                this.isEmployee && p.push(this.tableSequenceNumberService.getListByQuery({
                    name: Ii.QUOTATION.name
                })), Ne(p).subscribe({
                    next: y => {
                        let je = y[0],
                            Pt = y[1],
                            Rt = this.isEmployee ? y[2] : null;
                        this.configService.appConfig$.subscribe({
                            next: Qt => {
                                this.account = Qt
                            },
                            error: Qt => {
                                this.errorResponse = Qt, console.log(Qt)
                            }
                        }), this.job = new Ee(je), this.jobService.currentJobSource.next(this.job), Pt && (this.quotation = new Bt(Pt), this.noteData = this.quotation.note, this.currentQuotationId = this.quotation.id, this.quotation.quotation_number && this.service.getHistory(this.quotation.quotation_number).subscribe({
                            next: Qt => {
                                this.quotationList = Qt
                            },
                            error: Qt => {
                                this.toastNotificationService.error("notification_history_fetch_error"), console.error("error in fetching history ", Qt)
                            }
                        }));
                        let pi = Rt ? .[0] ? .current_value ? ? null;
                        this.initializeForm(pi)
                    },
                    error: y => {
                        console.error(y)
                    }
                }).add(() => {
                    this.loaderService.hide(), this.isLoading = !1
                }), this.dataService.currentJobPartTotal$.subscribe({
                    next: y => {
                        this.partSum = y
                    },
                    error: y => {
                        this.errorResponse = y
                    }
                }), this.dataService.currentJobServiceTotal$.subscribe({
                    next: y => {
                        this.serviceSum = y
                    },
                    error: y => {
                        this.errorResponse = y
                    }
                })
            }
        }
        initializeForm(e = null) {
            this.quotation ? .id && this.quotation.status !== this.quotationStatuses.MODIFIED ? (this.entityId = this.quotation ? .id, this.entityType = this.ENTITIES.QUOTATION.name) : (this.entityId = this.job ? .id, this.entityType = this.ENTITIES.JOB.name, this.isEditMode = !0), this.quotation ? .id ? this.form = Bt.getForm(this.quotation, this.notifDefaults.getEntityDefaults(Et.QUOTATION)) : this.termAndConditionService.getByTypeId({
                type_id: at.QUOTATION
            }).subscribe({
                next: o => {
                    this.form = Bt.getForm(new Bt({
                        quotation_number: e,
                        quotationable_id: this.job.id,
                        user_id: this.job.user_id,
                        quotationable_type: this.ENTITIES.JOB.name,
                        term_and_condition: o ? .text ? ? "",
                        auto_round_off: this.generalSettingDataService.getGeneralSettingByKey(F.GENERAL_SETTINGS.AUTO_ROUND_OFF) ? ? !1
                    }), this.notifDefaults.getEntityDefaults(Et.QUOTATION))
                },
                error: o => {
                    this.errorResponse = o, console.log("error while getting terms and conditions by id ", o)
                }
            })
        }
        onSaveData(e) {
            this.noteData = e
        }
        save() {
            this.form.patchValue({
                total_amount: this.partSum.line_total + this.serviceSum.line_total,
                tax_amount: this.partSum.tax_amount + this.serviceSum.tax_amount,
                note: this.noteData
            }), this.isSaving = !0, (this.quotation ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.toastNotificationService.success("notification_quotation_save_success"), this.quotation = null, this.quotation = o, this.entityType = this.ENTITIES.QUOTATION.name, this.entityId = this.quotation.id, this.form.patchValue(new Bt(this.quotation)), this.ngOnInit(), this.isEditMode = !1
                },
                error: o => {
                    let i = this.quotation ? .id ? "update" : "create";
                    this.toastNotificationService.showRaw({
                        message: `Can't ${i} quotation`,
                        type: Ha.ERROR
                    }), console.log("error while creating or updating qutations ", o)
                }
            }).add(() => {
                this.isSaving = !1, this.isVisibleSaveConfirmPopup = !1
            })
        }
        showApprovalPopupUp(e) {
            this.isApproving = e, this.setApproveRejectForm(), this.isVisibleApprovalPopup = !0, this.approvalComment = null
        }
        setApproveRejectForm() {
            this.approveRejectForm = this.fb.group({
                comment: new k(null),
                is_send_mail: new k(!1),
                is_send_app: new k(!1),
                is_send_whatsapp: new k(!1)
            })
        }
        updateQuotationApproval() {
            this.isSaving = !0, this.errorResponse = null, this.approveRejectForm.valid ? (this.isSaving = !0, (this.isApproving ? this.service.approve(this.quotation.id, this.approveRejectForm.value) : this.service.reject(this.quotation.id, this.approveRejectForm.value)).subscribe({
                next: o => {
                    this.isApproving ? (this.toastNotificationService.success("notification_quotation_approve_success"), this.approveRejectForm.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("quotation_approved", this.quotation.id)) : (this.toastNotificationService.success("notification_quotation_reject_success"), this.approveRejectForm.value.is_send_whatsapp === !0 && this.whatsappService.sendWhatsappMessage("quotation_rejected", this.quotation.id)), this.quotation = o, this.form = Bt.getForm(this.quotation, this.notifDefaults.getEntityDefaults(Et.QUOTATION))
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1, this.isVisibleApprovalPopup = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        reviseQuotation() {
            this.service.reviseQuotation(this.quotation.id).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_quotation_revision_create_success"), this.isVisibleRevisedConfirmationPopup = !1, this.quotation = null, this.ngOnInit()
                },
                error: e => {
                    this.errorResponse = e
                }
            })
        }
        showSaveConfirmationPopup() {
            this.isVisibleSaveConfirmPopup = !0, this.form.patchValue({
                comment: null
            })
        }
        onQuotationRevisionChange(e) {
            this.currentQuotationId = e.itemData.id, this.form = null, this.service.getById(this.currentQuotationId).subscribe({
                next: o => {
                    this.quotation = new Bt(o), this.currentQuotationId = this.quotation.id, this.initializeForm()
                },
                error: o => {
                    this.errorResponse = o
                }
            })
        }
        isClosingPopup() {
            this.form.patchValue({
                comment: null
            }), this.approvalComment = null, this.isVisibleSaveConfirmPopup = !1, this.isVisibleApprovalPopup = !1
        }
        quickReplyValue(e) {
            this.approvalComment = e.comment ? ? e.title, this.isVisibleSaveConfirmPopup && this.form.patchValue({
                comment: this.approvalComment
            }), this.isVisibleApprovalPopup && this.approveRejectForm.patchValue({
                comment: this.approvalComment
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(Cl), T(U), T(tn), T(Ct), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-quotation"]
                ],
                standalone: !1,
                decls: 7,
                vars: 15,
                consts: [
                    [1, "container-fluid"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "minWidth", "title"],
                    ["id", "revise-quotation-popup", 3, "confirmationMessage"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["role", "alert", 1, "alert", "alert-warning"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", 3, "ngClass"],
                    [1, "float-start", "m-1", "mb-md-1", "mb-0", 3, "iconType", "status"],
                    [1, "title-text", "float-start", "mt-1"],
                    [1, "print-actions-bar"],
                    ["displayExpr", "revision", "valueExpr", "id", 1, "mx-1", 3, "ngModel", "ngModelOptions", "items", "searchEnabled"],
                    [3, "entityId", "entityName"],
                    [1, "ms-2", 3, "jobId"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "ms-2", 3, "jobQuotation", "job"],
                    [1, "container-fluid", "mt-3", 3, "ngClass"],
                    ["id", "print-section", 1, "container-fluid", "mt-3", 3, "ngClass"],
                    ["displayExpr", "revision", "valueExpr", "id", 1, "mx-1", 3, "onItemClick", "ngModelChange", "ngModel", "ngModelOptions", "items", "searchEnabled"],
                    [1, "ms-2", 3, "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["stylingMode", "outlined", "type", "default", 1, "ms-2", 3, "title", "text"],
                    ["stylingMode", "outlined", "type", "danger", 1, "ms-2", 3, "onClick", "title", "text"],
                    ["stylingMode", "outlined", "type", "default", 1, "ms-2", 3, "onClick", "title", "text"],
                    ["stylingMode", "outlined", "type", "danger", "icon", "fa-solid fa-circle-xmark fa-xl", 1, "ms-2", 3, "onClick", "title"],
                    ["stylingMode", "outlined", "type", "success", "icon", "fa-solid fa-circle-check fa-xl", 1, "ms-2", 3, "onClick", "title"],
                    ["saveText", "create_quotation", "savingText", "saving_quotation", 1, "m-1", "order-last", 3, "isSaving"],
                    ["saveText", "create_quotation", "savingText", "saving_quotation", 1, "m-1", "order-last", 3, "saveBtnClick", "isSaving"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "fw-bold"],
                    [1, "mx-1"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "d-flex", "fw-bold"],
                    [1, "d-flex"],
                    [1, "badge", "bg-success"],
                    [1, "ms-2", "fw-bold", 3, "iconOnly", "user"],
                    [1, "badge", "bg-danger"],
                    [1, "badge", 3, "ngClass"],
                    [1, "fw-bold"],
                    [3, "innerHTML"],
                    [1, "fw-bold", "me-2"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "revision", "title"],
                    [3, "userId"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [3, "entityId", "entityType", "isEditMode", "isJobView"],
                    [3, "viewData", "isEditMode", "noteData"],
                    [3, "termAndCondition"],
                    [1, "row", "mt-3"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition"],
                    [1, "d-flex", "flex-column", "h-100"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    ["height", "auto", "formControlName", "comment", 3, "quickReply"],
                    [1, "mt-3"],
                    [3, "form"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving", "saveText"],
                    ["name", "comment", 3, "errorMsg", "label"],
                    [3, "errorResponse"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving", "saveText", "savingText"],
                    ["id", "revise-quotation-popup", 3, "confirmActionCallback", "rejectActionCallback", "confirmationMessage"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, hC, 5, 1, "div", 0)(1, YC, 2, 2), r(2, "dx-popup", 1), f("onHidden", function() {
                        return i.isVisibleSaveConfirmPopup = !1
                    }), j("visibleChange", function(y) {
                        return O(i.isVisibleSaveConfirmPopup, y) || (i.isVisibleSaveConfirmPopup = y), y
                    }), E(3, KC, 2, 1, "div", 2), a(), r(4, "dx-popup", 3), f("onHidden", function() {
                        return i.isVisibleApprovalPopup = !1
                    }), j("visibleChange", function(y) {
                        return O(i.isVisibleApprovalPopup, y) || (i.isVisibleApprovalPopup = y), y
                    }), E(5, tv, 2, 1, "div", 2), a(), m(6, iv, 1, 1, "app-confirmation-popup", 4)), o & 2 && (_(!i.isEmployee && !(i.quotation != null && i.quotation.id) ? 0 : 1), n(2), w("visible", i.isVisibleSaveConfirmPopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", i.formatMessage("quotation_confirmation")), n(), l("dxTemplateOf", "content"), n(), w("visible", i.isVisibleApprovalPopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("minWidth", 350)("title", i.isApproving ? i.formatMessage("approve_quotation") : i.formatMessage("reject_quotation")), n(), l("dxTemplateOf", "content"), n(), _(i.isVisibleRevisedConfirmationPopup ? 6 : -1))
                },
                dependencies: [Q, ai, Se, Vi, Xe, ee, ii, et, _t, Fe, K, Ki, kt, xt, vt, Nt, ft, pt, Ze, ht, bt, it, ue, oi, _e, W, ct, H, ye, xe, pe, q, re, $e, le, se, vl, Mo, Kt, Dt, Ue],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function nv(t, c) {
    if (t & 1 && (r(0, "div", 2)(1, "div", 4)(2, "div", 5), u(3, "app-job-btn", 6)(4, "app-print-button", 7)(5, "app-share-btn", 8), a()()()), t & 2) {
        let e = s();
        n(3), l("jobId", e.job == null ? null : e.job.id), n(), l("entityId", e.job == null ? null : e.job.id)("isVisiblePrintButton", !!(e.job != null && e.job.id))("isVisibleStickerPrint", !0)("isVisibleThermalPrint", !1)("remark", e.remark()), n(), l("entityId", e.job == null ? null : e.job.id)("entityType", "technician_copy")("remark", e.remark())
    }
}

function ov(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "small", 24), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("device_type_name")), n(2), h(e.job == null || e.job.device_type == null ? null : e.job.device_type.name)
    }
}

function av(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "small", 24), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("device_brand_name")), n(2), h(e.job == null || e.job.device_brand == null ? null : e.job.device_brand.name)
    }
}

function rv(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "small", 24), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("device_model_name")), n(2), h(e.job == null || e.job.device_model == null ? null : e.job.device_model.name)
    }
}

function sv(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "small", 24), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("device_serial_number")), n(2), h(e.job == null ? null : e.job.serial_number)
    }
}

function lv(t, c) {
    if (t & 1 && (r(0, "div", 21)(1, "small", 24), d(2), a(), r(3, "span"), d(4), V(5, "objToString"), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("job_services")), n(2), h(ie(5, 2, e.job == null ? null : e.job.repairables))
    }
}

function cv(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "small", 24), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("job_service_type")), n(2), h(e.job == null || e.job.service_type == null ? null : e.job.service_type.name)
    }
}

function dv(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "small", 24), d(2), a(), r(3, "span"), d(4), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("device_color_label")), n(2), h(e.job == null || e.job.device_color == null ? null : e.job.device_color.name)
    }
}

function pv(t, c) {
    if (t & 1 && (r(0, "div", 21)(1, "small", 24), d(2), a(), u(3, "span", 29), V(4, "safe"), a()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("job_service_assessment")), n(), l("innerHTML", B(4, 2, e.job == null ? null : e.job.comment, "html"), We)
    }
}

function mv(t, c) {
    if (t & 1 && (r(0, "div", 20)(1, "div", 23)(2, "small", 24), d(3), a(), r(4, "span", 18), d(5), V(6, "date"), a()()()), t & 2) {
        let e = s(3);
        n(3), h(e.formatMessage("job_due_date")), n(2), h(ie(6, 2, e.job == null ? null : e.job.estimated_delivery))
    }
}

function _v(t, c) {
    if (t & 1 && u(0, "app-qr-code", 30), t & 2) {
        let e = s(4);
        l("qrString", e.job == null ? null : e.job.qr_code)
    }
}

function uv(t, c) {
    if (t & 1 && (r(0, "div", 28), m(1, _v, 1, 1, "app-qr-code", 30), a()), t & 2) {
        let e = s(3);
        n(), _(e.job ? 1 : -1)
    }
}

function Cv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 11)(1, "small", 12), d(2), a(), r(3, "div", 13), d(4), a(), r(5, "small", 14), d(6), V(7, "dateFormat"), a()(), r(8, "div", 15)(9, "div", 16)(10, "span", 17), d(11), a()(), r(12, "div")(13, "div", 18), d(14), a(), r(15, "small", 14), d(16), V(17, "mobileDisplay"), a()()(), r(18, "div", 19), m(19, ov, 5, 2, "div", 20), m(20, av, 5, 2, "div", 20), m(21, rv, 5, 2, "div", 20), m(22, sv, 5, 2, "div", 20), m(23, lv, 6, 4, "div", 21), m(24, cv, 5, 2, "div", 20), m(25, dv, 5, 2, "div", 20), m(26, pv, 5, 5, "div", 21), a(), r(27, "div", 22)(28, "div", 20)(29, "div", 23)(30, "small", 24), d(31), a(), r(32, "span", 18), d(33), a()()(), m(34, mv, 7, 4, "div", 20), a(), r(35, "div", 25)(36, "small", 26), d(37), a(), r(38, "textarea", 27), f("focusout", function() {
            C(e);
            let i = s(2);
            return v(i.onRemarkFocusOut())
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.remark, i) || (p.remark = i), v(i)
        }), a()(), m(39, uv, 2, 1, "div", 28)
    }
    if (t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("job_sheet_number")), n(2), h(e.job == null ? null : e.job.job_number), n(2), h(B(7, 20, e.job == null ? null : e.job.created_at, "datetime")), n(5), h(e.job == null || e.job.user == null || e.job.user.name == null ? null : e.job.user.name.charAt(0)), n(3), h(e.job == null || e.job.user == null ? null : e.job.user.name), n(2), h(B(17, 23, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code)), n(3), _(e.technicianPrintOption != null && e.technicianPrintOption.device_type_id && (!(e.job == null || e.job.device_type == null) && e.job.device_type.name) ? 19 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_brand_id && (!(e.job == null || e.job.device_brand == null) && e.job.device_brand.name) ? 20 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_model_id && (!(e.job == null || e.job.device_model == null) && e.job.device_model.name) ? 21 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.serial_number_id && (e.job != null && e.job.serial_number) ? 22 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.repairables && (e.job != null && e.job.repairables) ? 23 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.service_type_id && (!(e.job == null || e.job.service_type == null) && e.job.service_type.name) ? 24 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_color_id && (!(e.job == null || e.job.device_color == null) && e.job.device_color.name) ? 25 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.comment && (e.job != null && e.job.comment) ? 26 : -1), n(5), h(e.formatMessage("job_assignee")), n(2), h((e.job == null ? null : e.job.assigned_user.display_name) ? ? (e.job == null ? null : e.job.assigned_user.name)), n(), _(e.job != null && e.job.estimated_delivery ? 34 : -1), n(3), h(e.formatMessage("job_remark")), n(), w("ngModel", e.remark), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.qr_code ? 39 : -1)
    }
}

function vv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("device_type_name"))
    }
}

function fv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("device_brand_name"))
    }
}

function hv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("device_model_name"))
    }
}

function bv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("job_services"))
    }
}

function gv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("device_serial_number"))
    }
}

function xv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("job_service_type"))
    }
}

function Sv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("device_color_label"))
    }
}

function yv(t, c) {
    if (t & 1 && (r(0, "th", 39), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.formatMessage("job_service_assessment"))
    }
}

function Tv(t, c) {
    if (t & 1 && (r(0, "td"), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.job == null || e.job.device_type == null ? null : e.job.device_type.name)
    }
}

function Mv(t, c) {
    if (t & 1 && (r(0, "td"), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.job == null || e.job.device_brand == null ? null : e.job.device_brand.name)
    }
}

function Pv(t, c) {
    if (t & 1 && (r(0, "td"), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.job == null || e.job.device_model == null ? null : e.job.device_model.name)
    }
}

function Iv(t, c) {
    if (t & 1 && (r(0, "td"), d(1), V(2, "objToString"), a()), t & 2) {
        let e = s(3);
        n(), h(ie(2, 1, e.job == null ? null : e.job.repairables))
    }
}

function Ev(t, c) {
    if (t & 1 && (r(0, "td"), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.job == null ? null : e.job.serial_number)
    }
}

function wv(t, c) {
    if (t & 1 && (r(0, "td"), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.job == null || e.job.service_type == null ? null : e.job.service_type.name)
    }
}

function Ov(t, c) {
    if (t & 1 && (r(0, "td"), d(1), a()), t & 2) {
        let e = s(3);
        n(), h(e.job == null || e.job.device_color == null ? null : e.job.device_color.name)
    }
}

function jv(t, c) {
    if (t & 1 && (u(0, "td", 29), V(1, "safe")), t & 2) {
        let e = s(3);
        l("innerHTML", B(1, 1, e.job == null ? null : e.job.comment, "html"), We)
    }
}

function Vv(t, c) {
    if (t & 1 && (r(0, "div", 43)(1, "h6"), d(2), a(), r(3, "p", 42), d(4), V(5, "date"), a()()), t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("job_due_date")), n(2), h(ie(5, 2, e.job == null ? null : e.job.estimated_delivery))
    }
}

function Dv(t, c) {
    if (t & 1 && u(0, "app-qr-code", 30), t & 2) {
        let e = s(4);
        l("qrString", e.job == null ? null : e.job.qr_code)
    }
}

function kv(t, c) {
    if (t & 1 && (r(0, "div", 46)(1, "div", 47), m(2, Dv, 1, 1, "app-qr-code", 30), a()()), t & 2) {
        let e = s(3);
        n(2), _(e.job ? 2 : -1)
    }
}

function Nv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 31)(1, "div", 32)(2, "p"), d(3), a(), r(4, "span", 33), d(5), a(), r(6, "span", 34), d(7), a(), r(8, "span"), d(9), V(10, "mobileDisplay"), a()(), r(11, "div", 35)(12, "p", 36), d(13), a(), r(14, "span"), d(15), V(16, "dateFormat"), a()()(), r(17, "div", 37)(18, "table", 38)(19, "thead")(20, "tr"), m(21, vv, 2, 1, "th", 39), m(22, fv, 2, 1, "th", 39), m(23, hv, 2, 1, "th", 39), m(24, bv, 2, 1, "th", 39), m(25, gv, 2, 1, "th", 39), m(26, xv, 2, 1, "th", 39), m(27, Sv, 2, 1, "th", 39), m(28, yv, 2, 1, "th", 39), a()(), r(29, "tbody")(30, "tr"), m(31, Tv, 2, 1, "td"), m(32, Mv, 2, 1, "td"), m(33, Pv, 2, 1, "td"), m(34, Iv, 3, 3, "td"), m(35, Ev, 2, 1, "td"), m(36, wv, 2, 1, "td"), m(37, Ov, 2, 1, "td"), m(38, jv, 2, 4, "td", 29), a()()()(), r(39, "div", 40)(40, "div", 41)(41, "h6"), d(42), a(), r(43, "p", 42), d(44), a()(), m(45, Vv, 6, 4, "div", 43), r(46, "div", 44)(47, "h6"), d(48), a(), r(49, "textarea", 45), f("focusout", function() {
            C(e);
            let i = s(2);
            return v(i.onRemarkFocusOut())
        }), j("ngModelChange", function(i) {
            C(e);
            let p = s(2);
            return O(p.remark, i) || (p.remark = i), v(i)
        }), a()()(), m(50, kv, 3, 1, "div", 46)
    }
    if (t & 2) {
        let e = s(2);
        n(3), S("", e.formatMessage("job_sheet_number"), " :"), n(2), S("", e.job == null ? null : e.job.job_number, " ,"), n(2), S("", e.job == null || e.job.user == null ? null : e.job.user.name, " ,"), n(2), h(B(10, 28, e.job == null || e.job.user == null ? null : e.job.user.mobile_number, e.job == null || e.job.user == null ? null : e.job.user.mobile_country_code)), n(4), S("", e.formatMessage("job_created_time_and_date"), " :-"), n(2), h(B(16, 31, e.job == null ? null : e.job.created_at, "datetime")), n(6), _(e.technicianPrintOption != null && e.technicianPrintOption.device_type_id && (!(e.job == null || e.job.device_type == null) && e.job.device_type.name) ? 21 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_brand_id && (!(e.job == null || e.job.device_brand == null) && e.job.device_brand.name) ? 22 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_model_id && (!(e.job == null || e.job.device_model == null) && e.job.device_model.name) ? 23 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.repairables && (e.job != null && e.job.repairables) ? 24 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.serial_number_id && (e.job != null && e.job.serial_number) ? 25 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.service_type_id && (!(e.job == null || e.job.service_type == null) && e.job.service_type.name) ? 26 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_color_id && (!(e.job == null || e.job.device_color == null) && e.job.device_color.name) ? 27 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.comment && (e.job != null && e.job.comment) ? 28 : -1), n(3), _(e.technicianPrintOption != null && e.technicianPrintOption.device_type_id && (!(e.job == null || e.job.device_type == null) && e.job.device_type.name) ? 31 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_brand_id && (!(e.job == null || e.job.device_brand == null) && e.job.device_brand.name) ? 32 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_model_id && (!(e.job == null || e.job.device_model == null) && e.job.device_model.name) ? 33 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.repairables && (e.job != null && e.job.repairables) ? 34 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.serial_number_id && (e.job != null && e.job.serial_number) ? 35 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.service_type_id && (!(e.job == null || e.job.service_type == null) && e.job.service_type.name) ? 36 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.device_color_id && (!(e.job == null || e.job.device_color == null) && e.job.device_color.name) ? 37 : -1), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.comment && (e.job != null && e.job.comment) ? 38 : -1), n(4), h(e.formatMessage("job_assignee")), n(2), h((e.job == null ? null : e.job.assigned_user.display_name) ? ? (e.job == null ? null : e.job.assigned_user.name)), n(), _(e.job != null && e.job.estimated_delivery ? 45 : -1), n(3), h(e.formatMessage("job_remark")), n(), w("ngModel", e.remark), n(), _(e.technicianPrintOption != null && e.technicianPrintOption.qr_code ? 50 : -1)
    }
}

function Av(t, c) {
    if (t & 1 && (r(0, "div", 3)(1, "div", 2)(2, "div", 4)(3, "div", 9)(4, "div", 10)(5, "div", 2)(6, "div", 4), m(7, Cv, 40, 26)(8, Nv, 51, 34), a()()()()()()()), t & 2) {
        let e = s();
        n(7), _(e.isMobileDevice ? 7 : 8)
    }
}
var ko = (() => {
    class t {
        constructor(e, o) {
            this.jobService = e, this.loaderService = o, this.formatMessage = g, this.isOnJobSheet = !0, this.onRemarkChange = new J, this.generalSettingDataService = b(te), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.remark = Y(""), this.technicianPrintOption = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.TECHNICIAN_COPY_SETTINGS)
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("job_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("job_id");
                this.loaderService.show(), this.jobService.getDetailById(e).subscribe({
                    next: o => {
                        this.job = o
                    },
                    error: o => {
                        console.log(o)
                    }
                }), this.loaderService.hide()
            }
        }
        onRemarkFocusOut() {
            this.onRemarkChange.emit(this.remark())
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-sheet-technician-copy"]
                ],
                inputs: {
                    job: "job",
                    isOnJobSheet: "isOnJobSheet"
                },
                outputs: {
                    onRemarkChange: "onRemarkChange"
                },
                standalone: !1,
                decls: 4,
                vars: 2,
                consts: [
                    [1, "card"],
                    [1, "container-fluid"],
                    [1, "row"],
                    ["id", "print-section"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-end", "d-flex", "mt-2"],
                    [1, "me-2", 3, "jobId"],
                    ["entityName", "technician_copy", "stickerEntityName", "technician_copy_sticker", 3, "entityId", "isVisiblePrintButton", "isVisibleStickerPrint", "isVisibleThermalPrint", "remark"],
                    [1, "ms-1", 3, "entityId", "entityType", "remark"],
                    [1, "card", "border-0"],
                    [1, "card-body", "m-1", "m-sm-3"],
                    [1, "text-center", "pb-3", "mb-3", "border-bottom", "border-secondary"],
                    [1, "text-uppercase", "fw-semibold", "opacity-50", "d-block"],
                    [1, "fw-bold", "fs-4", "my-1"],
                    [1, "opacity-50"],
                    [1, "d-flex", "align-items-center", "gap-3", "p-3", "mb-3", "rounded-3", "theme-secondary-bg"],
                    [1, "rounded-circle", "bg-primary", "bg-opacity-10", "d-flex", "align-items-center", "justify-content-center", "text-uppercase", "flex-shrink-0", 2, "width", "44px", "height", "44px"],
                    [1, "fw-bold", "text-primary", "fs-6"],
                    [1, "fw-semibold"],
                    [1, "row", "g-3", "pb-3", "mb-3", "border-bottom", "border-secondary"],
                    [1, "col-6"],
                    [1, "col-12"],
                    [1, "row", "g-2", "mb-3"],
                    [1, "p-3", "rounded-3", "border", "border-secondary"],
                    [1, "text-uppercase", "fw-semibold", "opacity-50", "d-block", "mb-1"],
                    [1, "mb-3"],
                    [1, "text-uppercase", "fw-semibold", "opacity-50", "d-block", "mb-2"],
                    ["placeholder", "Enter You Text Here", 1, "textarea-control", "theme-secondary-bg", "w-100", 3, "focusout", "ngModelChange", "ngModel"],
                    [1, "text-center", "py-2"],
                    [3, "innerHTML"],
                    [3, "qrString"],
                    [1, "basic-detail", "d-flex", "justify-content-between", "flex-wrap"],
                    [1, "d-flex", "gap-2"],
                    [1, "fw-bold", "me-2"],
                    [1, "me-2"],
                    [1, "d-flex"],
                    [1, "me-3", "fw-bold"],
                    [1, "job-detail", "table-responsive-sm"],
                    [1, "table", "table-bordered", "theme-secondary-bg", "bg-transparent", "text-body"],
                    ["scope", "col"],
                    [1, "row", "mt-2"],
                    [1, "assignee", "col-sm-3", "col-md-3", "col-lg-3"],
                    [1, "border", "border-dark", "px-5", "py-2", "rounded-2"],
                    [1, "due-date", "col-sm-3", "col-md-3", "col-lg-3"],
                    [1, "remark", "col-sm-6", "col-md-6", "col-lg-6"],
                    ["placeholder", "Enter You Text Here", 1, "textarea-control", "theme-secondary-bg", 3, "focusout", "ngModelChange", "ngModel"],
                    [1, "row", "mt-2", "d-flex", "justify-content-between", "flex-wrap"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1), m(2, nv, 6, 9, "div", 2), m(3, Av, 9, 1, "div", 3), a()()), o & 2 && (n(2), _(i.isOnJobSheet ? 2 : -1), n(), _(i.job ? 3 : -1))
                },
                dependencies: [Xe, Ze, it, _r, Da, q, $e, Ln, Dt, Ue, Ni, mt],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function Lv(t, c) {
    if (t & 1 && u(0, "app-send-whats-app-btn", 6), t & 2) {
        let e = s();
        l("entityId", e.job == null ? null : e.job.id)("entityName", e.ENTITIES.JOB_SHEET.name)
    }
}

function Bv(t, c) {
    if (t & 1 && (r(0, "div"), u(1, "app-job-btn", 12), a()), t & 2) {
        let e = s();
        n(), l("jobId", e.job == null ? null : e.job.id)
    }
}

function Rv(t, c) {
    if (t & 1 && u(0, "app-send-notification", 7), t & 2) {
        let e = s();
        l("entityObj", e.job)("entity", e.ENTITIES.JOB_SHEET)("job", e.job)
    }
}

function Uv(t, c) {
    if (t & 1 && (d(0), V(1, "dateFormat")), t & 2) {
        let e = c.$implicit,
            o = c.$index,
            i = c.$count;
        ze(" ", ie(1, 2, e), "", o !== i - 1 ? ", " : "", " ")
    }
}

function Fv(t, c) {
    if (t & 1 && (r(0, "div", 17)(1, "div", 2)(2, "h5", 22), d(3), a(), r(4, "div", 23)(5, "div", 24)(6, "span", 25), d(7), a(), r(8, "span", 26), d(9, ":"), a(), d(10), V(11, "number"), a(), r(12, "div", 24)(13, "span", 25), d(14), a(), r(15, "span", 26), d(16, ":"), a(), d(17), a(), r(18, "div", 24)(19, "span", 25), d(20), a(), r(21, "span", 26), d(22, ":"), a(), X(23, Uv, 2, 4, null, null, xa), a()()()()), t & 2) {
        let e = s(2);
        n(3), h(e.formatMessage("payment_information")), n(4), h(e.formatMessage("common_advance_payment")), n(3), ze("", e.account == null ? null : e.account.currency_code, " ", B(11, 7, e.advancePaymentTotal, "1.2-2"), " "), n(4), h(e.formatMessage("payment_mode")), n(3), S("", e.advancePaymentModes, " "), n(3), h(e.formatMessage("received_on")), n(3), Z(e.uniqueAdvanceDates)
    }
}

function qv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "span", 30), u(2, "hr", 31)(3, "i", 32), a(), r(4, "app-job-sheet-technician-copy", 33), f("onRemarkChange", function(i) {
            C(e);
            let p = s(3);
            return v(p.handleRemarkChange(i))
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(4), l("isOnJobSheet", !1)("job", e.job)
    }
}

function Gv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 21)(1, "div", 27)(2, "span", 28), d(3), a(), r(4, "input", 29), f("change", function() {
            C(e);
            let i = s(2);
            return v(i.toggle())
        }), a()(), m(5, qv, 5, 2, "div"), a()
    }
    if (t & 2) {
        let e = s(2);
        n(3), h(e.formatMessage("job_print_technician_copy")), n(), l("ngModel", e.wantTechnicianCopy), n(), _(e.wantTechnicianCopy ? 5 : -1)
    }
}

function Wv(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2), u(5, "app-invoice-header", 13)(6, "app-invoice-title", 14)(7, "app-invoice-customer-detail", 15)(8, "app-invoice-job-details", 16), m(9, Fv, 25, 10, "div", 17), u(10, "app-invoice-term-and-conditions", 18)(11, "hr", 19)(12, "app-invoice-signature", 20), a(), m(13, Gv, 6, 3, "div", 21), a()()()()), t & 2) {
        let e = s();
        l("ngClass", e.isMobileDevice ? "p-0" : ""), n(5), l("account", e.account)("qrCode", e.job && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.job == null ? null : e.job.qr_code)), n(), l("dateTime", e.job == null ? null : e.job.created_at)("title", e.formatMessage("common_job_sheet_no") + " : " + (e.job == null ? null : e.job.job_number)), n(), l("userId", e.job.user_id), n(), l("job", e.job), n(), _(e.hasAdvancePayments ? 9 : -1), n(), l("termAndCondition", e.job.term_and_condition), n(2), l("entityId", e.job == null ? null : e.job.id)("entityType", e.entityType), n(), _(e.isEmployee ? 13 : -1)
    }
}

function Hv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-popup", 34), f("onHiding", function() {
            C(e);
            let i = s();
            return v(i.isVisibleTechnicianCopyPopup = !1)
        }), r(1, "div", 35)(2, "dx-button", 36), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.onTechnicianCopyClick("print"))
        }), a(), r(3, "dx-button", 37), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.onTechnicianCopyClick("sticker_print"))
        }), a()()()
    }
    if (t & 2) {
        let e = s();
        l("visible", e.isVisibleTechnicianCopyPopup)("showTitle", !0)("title", e.formatMessage("technician_copy"))("dragEnabled", !1)("hideOnOutsideClick", !0)("showCloseButton", !0)("width", 300)("height", "auto"), n(2), l("text", e.formatMessage("print"))("width", "100%"), n(), l("text", e.formatMessage("sticker_print"))("width", "100%")
    }
}
var hl = (() => {
    class t {
        constructor(e, o) {
            this.jobService = e, this.loaderService = o, this.formatMessage = g, this.generalSettingDataService = b(te), this.configService = b(lt), this.userSessionService = b(L), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.printService = b(mr), this.isEmployee = this.userSessionService.isEmployee(), this.statusIconTypeList = he, this.ENTITIES = I, this.isEditMode = !0, this.isVisibleSaveConfirmPopup = !1, this.entityType = this.ENTITIES.JOB.name, this.dateTime = new Date, this.wantTechnicianCopy = !0, this.remark = Y(""), this.isVisibleTechnicianCopyPopup = !1, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.PRINT_SETTINGS) ? ? Vt.getEmptyObject()
        }
        ngOnInit() {
            if (this.activatedRouter.snapshot.paramMap.has("job_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("job_id");
                this.loaderService.show(), Ne([this.jobService.getDetailById(e), this.configService.appConfig$.pipe(va(1))]).subscribe({
                    next: ([o, i]) => {
                        this.account = i, this.job = o
                    },
                    error: o => {
                        console.error("error getting job by id ", o)
                    }
                }).add(() => {
                    this.loaderService.hide()
                })
            }
        }
        toggle() {
            this.wantTechnicianCopy = !this.wantTechnicianCopy
        }
        handleRemarkChange(e) {
            this.remark.set(e)
        }
        onTechnicianCopyClick(e) {
            this.isVisibleTechnicianCopyPopup = !1, e === "print" ? this.printService.print("technician_copy", this.job.id, null, !1, this.remark()) : e === "sticker_print" && this.printService.getThermalPrint("technician_copy_sticker", this.job.id, "Sticker", !1)
        }
        get hasAdvancePayments() {
            return this.printSettings ? .display_advance_payment === !0 && (this.job ? .advance_payments ? .length ? ? 0) > 0
        }
        get advancePaymentTotal() {
            return (this.job ? .advance_payments ? ? []).reduce((e, o) => e + Number(o.amount ? ? 0), 0)
        }
        get advancePaymentModes() {
            let e = (this.job ? .advance_payments ? ? []).map(o => o.payment_type ? .name).filter(Boolean);
            return Array.from(new Set(e)).join(", ")
        }
        get uniqueAdvanceDates() {
            let e = new Set;
            return (this.job ? .advance_payments ? ? []).map(o => o.received_at).filter(o => {
                if (!o) return !1;
                let i = new Date(o).toDateString();
                return e.has(i) ? !1 : (e.add(i), !0)
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-sheet"]
                ],
                standalone: !1,
                decls: 19,
                vars: 20,
                consts: [
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", "m-1", 3, "iconType", "status"],
                    [1, "title-text", "float-start", "m-1"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [3, "entityObj", "entity", "job"],
                    [3, "technicianCopyClick", "entityId", "entityName", "isVisiblePrintButton", "optional", "isVisibleDownload", "isVisibleTechnicianCopy", "buttonText", "remark"],
                    [3, "entityId", "entityType", "remark"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "visible", "showTitle", "title", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [3, "jobId"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "mt-4"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "row", "ps-3"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "job-detail-custom-margin"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "no-print", "d-flex", "justify-content-start", "align-items-center"],
                    [1, "slider", "me-2"],
                    ["type", "checkbox", 1, "mt-1", 3, "change", "ngModel"],
                    [1, "span-hr-dotted"],
                    [1, "invoice-hr-dotted"],
                    [1, "fa-thin", "fa-scissors"],
                    [3, "onRemarkChange", "isOnJobSheet", "job"],
                    [3, "onHiding", "visible", "showTitle", "title", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [1, "d-flex", "flex-column", "gap-3", "p-3"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-print", 3, "onClick", "text", "width"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-note-sticky", 3, "onClick", "text", "width"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div")(1, "div", 0)(2, "div", 1)(3, "div", 2), u(4, "app-job-status-tag", 3), r(5, "span", 4), d(6), a(), r(7, "div", 5)(8, "div"), m(9, Lv, 1, 2, "app-send-whats-app-btn", 6), a(), m(10, Bv, 2, 1, "div"), r(11, "div"), m(12, Rv, 1, 3, "app-send-notification", 7), a(), r(13, "div")(14, "app-print-button", 8), f("technicianCopyClick", function() {
                        return i.isVisibleTechnicianCopyPopup = !0
                    }), a()(), r(15, "div"), u(16, "app-share-btn", 9), a()()()()(), m(17, Wv, 14, 12, "div", 10), a(), m(18, Hv, 4, 12, "dx-popup", 11)), o & 2 && (n(), l("ngClass", i.isMobileDevice ? "p-0" : ""), n(3), l("iconType", i.statusIconTypeList.TITLE)("status", i.job == null ? null : i.job.status), n(2), S(" ", i.job == null ? null : i.job.job_number, " "), n(3), _(i.job && i.isEmployee ? 9 : -1), n(), _(i.isMobileDevice ? -1 : 10), n(2), _(i.job && i.isEmployee ? 12 : -1), n(2), l("entityId", i.job == null ? null : i.job.id)("entityName", i.ENTITIES.JOB_SHEET.name)("isVisiblePrintButton", !!(i.job != null && i.job.id))("optional", i.wantTechnicianCopy)("isVisibleDownload", !0)("isVisibleTechnicianCopy", i.isEmployee)("buttonText", i.formatMessage("print"))("remark", i.remark()), n(2), l("entityId", i.job == null ? null : i.job.id)("entityType", i.ENTITIES.JOB_SHEET.name)("remark", i.remark()), n(), _(i.job ? 17 : -1), n(), _(i.isVisibleTechnicianCopyPopup ? 18 : -1))
                },
                dependencies: [Q, Se, Xe, kt, xt, vt, Nt, ft, pt, Ze, ht, tt, it, ct, H, Va, q, $e, ko, Kt, Ue],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var di = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new Xt({
            job_id: new k(c ? .job_id || null),
            issue_observed: new k(c ? .issue_observed || "", [de.required]),
            diagnosis_notes: new k(c ? .diagnosis_notes || "", [de.required]),
            term_and_condition: new k(c ? .term_and_condition || ""),
            attachments: new k(c ? .attachments || [])
        })
    }
};
var Qv = "job-diagnoses",
    bl = (() => {
        class t extends Be {
            constructor(e) {
                super(e, Qv), this.api = e, this.jobEndpoint = Ra
            }
            getByJobId(e) {
                return this.api.get(`${this.jobEndpoint}/${e}/diagnosis`)
            }
            createDiagnosis(e, o) {
                return this.api.post(`${this.jobEndpoint}/${e}/diagnosis`, o)
            }
            updateDiagnosis(e, o) {
                return this.api.put(`${this.jobEndpoint}/${e}/diagnosis`, o)
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)(Qe(Ie))
                }
            }
            static {
                this.\u0275prov = Pe({
                    token: t,
                    factory: t.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return t
    })();

function zv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-cancel-footer", 10), f("cancelClick", function() {
            C(e);
            let i = s();
            return v(i.cancelDiagnosis())
        })("saveClick", function() {
            C(e);
            let i = s();
            return v(i.saveDiagnosis())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisibleHr", !1)("saveText", e.isEditMode ? "common_save" : "common_create")
    }
}

function Yv(t, c) {
    if (t & 1 && u(0, "app-send-whats-app-btn", 11), t & 2) {
        let e = s(2);
        l("entityId", e.diagnosis == null ? null : e.diagnosis.id)("entityName", e.ENTITIES.JOB_DIAGNOSIS.name)
    }
}

function $v(t, c) {
    if (t & 1 && (r(0, "div"), u(1, "app-job-btn", 15), a()), t & 2) {
        let e = s(2);
        n(), l("jobId", e.job == null ? null : e.job.id)
    }
}

function Kv(t, c) {
    if (t & 1 && u(0, "app-send-notification", 12), t & 2) {
        let e = s(2);
        l("entityObj", e.diagnosis)("entity", e.ENTITIES.JOB_DIAGNOSIS)("job", e.job)
    }
}

function Xv(t, c) {
    if (t & 1 && (r(0, "div"), m(1, Yv, 1, 2, "app-send-whats-app-btn", 11), a(), m(2, $v, 2, 1, "div"), r(3, "div"), m(4, Kv, 1, 3, "app-send-notification", 12), a(), r(5, "div"), u(6, "app-print-button", 13), a(), r(7, "div"), u(8, "app-share-btn", 14), a()), t & 2) {
        let e = s();
        n(), _(e.job && e.isEmployee && (e.diagnosis != null && e.diagnosis.id) ? 1 : -1), n(), _(e.isMobileDevice ? -1 : 2), n(2), _(e.job && e.isEmployee && (e.diagnosis != null && e.diagnosis.id) ? 4 : -1), n(2), l("entityId", e.job == null ? null : e.job.id)("entityName", e.ENTITIES.JOB_DIAGNOSIS.name)("isVisiblePrintButton", !!(e.diagnosis != null && e.diagnosis.id))("isVisibleThermalPrint", !1), n(2), l("entityId", e.job == null ? null : e.job.id)("entityType", e.ENTITIES.JOB_DIAGNOSIS.name)
    }
}

function Zv(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "app-dx-outline-button", 16), f("onClickEvent", function() {
            C(e);
            let i = s();
            return v(i.showEditForm())
        }), a()()
    }
    t & 2 && (n(), l("text", "common_edit")("title", "common_edit"))
}

function ef(t, c) {
    if (t & 1 && (r(0, "div", 27)(1, "label", 30), d(2), a(), u(3, "div", 31), a()), t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("issue_observed")), n(), l("innerHTML", e.diagnosis == null ? null : e.diagnosis.issue_observed, We)
    }
}

function tf(t, c) {
    if (t & 1 && (r(0, "div", 27)(1, "label", 30), d(2), a(), u(3, "div", 31), a()), t & 2) {
        let e = s(2);
        n(2), h(e.formatMessage("diagnosis_notes")), n(), l("innerHTML", e.diagnosis == null ? null : e.diagnosis.diagnosis_notes, We)
    }
}

function nf(t, c) {
    if (t & 1 && (r(0, "div", 7)(1, "div", 1)(2, "div", 2), u(3, "app-invoice-header", 17)(4, "app-invoice-title", 18)(5, "app-invoice-customer-detail", 19)(6, "app-invoice-job-details", 20), r(7, "div", 21)(8, "div", 22)(9, "div", 23)(10, "div", 24)(11, "h6", 25), d(12), a()(), r(13, "div", 26), m(14, ef, 4, 2, "div", 27), m(15, tf, 4, 2, "div", 27), a()()()(), u(16, "app-invoice-term-and-conditions", 28)(17, "hr", 29)(18, "app-invoice-signature", 14), a()()()), t & 2) {
        let e = s();
        l("ngClass", e.isMobileDevice ? "p-0" : ""), n(3), l("account", e.account)("qrCode", e.diagnosis == null ? null : e.diagnosis.qr_code), n(), l("dateTime", e.diagnosis == null ? null : e.diagnosis.created_at)("title", e.formatMessage("job_diagnosis") + " : " + (e.job == null ? null : e.job.job_number)), n(), l("userId", e.job == null ? null : e.job.user_id), n(), l("job", e.job), n(6), h(e.formatMessage("diagnosis_details")), n(2), _(e.diagnosis != null && e.diagnosis.issue_observed ? 14 : -1), n(), _(e.diagnosis != null && e.diagnosis.diagnosis_notes ? 15 : -1), n(), l("termAndCondition", e.diagnosis == null ? null : e.diagnosis.term_and_condition), n(2), l("entityId", e.job == null ? null : e.job.id)("entityType", e.ENTITIES.JOB_DIAGNOSIS.name)
    }
}

function of (t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 39)(1, "app-save-cancel-footer", 40), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.cancelDiagnosis())
        })("saveClick", function() {
            C(e);
            let i = s(2);
            return v(i.saveDiagnosis())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(), l("isOnPopup", !0)("isVisibleHr", !1)("saveText", e.isEditMode ? "common_save" : "common_create")
    }
}

function af(t, c) {
    if (t & 1 && (r(0, "div", 8)(1, "div", 1)(2, "div", 2)(3, "div", 23)(4, "div", 24)(5, "h5", 25), d(6), a()(), r(7, "div", 26)(8, "form", 32)(9, "div", 1)(10, "app-control-container", 33), u(11, "app-textarea", 34), a(), r(12, "app-control-container", 35), u(13, "app-textarea", 36), a(), r(14, "app-control-container", 37), u(15, "app-textarea", 38), a()()(), m(16, of , 2, 3, "div", 39), a()()()()()), t & 2) {
        let e = s();
        l("ngClass", e.isMobileDevice ? "p-0" : ""), n(6), h(e.formatMessage("job_diagnosis")), n(2), l("formGroup", e.form), n(2), l("label", e.formatMessage("issue_observed"))("errorMsg", e.formatMessage("issue_observed_required")), n(), l("placeholder", "issue_observed_placeholder"), n(), l("label", e.formatMessage("diagnosis_notes"))("errorMsg", e.formatMessage("diagnosis_notes_required")), n(), l("placeholder", "diagnosis_notes_placeholder"), n(), l("label", e.formatMessage("common_terms_and_conditions")), n(2), _(e.isMobileDevice ? 16 : -1)
    }
}

function rf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-send-notification", 41), f("sendNotificationClose", function() {
            C(e);
            let i = s();
            return v(i.closeSendNotificationPopup())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleSendNotificationPopup)("isVisibleSendButton", !1)("entityObj", e.diagnosis)("entity", e.ENTITIES.JOB_DIAGNOSIS)("job", e.job)
    }
}
var gl = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.userSessionService = b(L), this.configService = b(lt), this.activatedRouter = b(R), this.toastNotificationService = b(D), this.isMobileDevice = b(A).isMobileDevice(), this.jobService = b(U), this.jobDiagnosisService = b(bl), this.termAndConditionService = b(Ct), this.loaderService = b($), this.router = b(G), this.formService = b(me), this.isEmployee = this.userSessionService.isEmployee(), this.statusIconTypeList = he, this.ENTITIES = I, this.TERM_AND_CONDITION_TYPES = at, this.isEditMode = !1, this.isViewMode = !1, this.isVisibleSendNotificationPopup = !1
        }
        ngOnInit() {
            this.activatedRouter.snapshot.paramMap.has("job_id") && (this.jobId = +this.activatedRouter.snapshot.paramMap.get("job_id"), this.loadData())
        }
        loadData() {
            this.loaderService.show(), Ne([this.jobService.getDetailById(this.jobId), this.jobDiagnosisService.getByJobId(this.jobId), this.termAndConditionService.getByTypeId({
                type_id: at.JOB_DIAGNOSIS
            })]).subscribe({
                next: ([e, o, i]) => {
                    this.job = e, this.configService.appConfig$.subscribe({
                        next: p => {
                            this.account = p
                        }
                    }), o ? .data ? (this.diagnosis = new di(o.data), this.isEditMode = !0, this.isViewMode = !0) : (this.diagnosis = new di({
                        job_id: this.jobId,
                        term_and_condition: i ? .text ? ? ""
                    }), this.isViewMode = !1), this.form = di.getForm(this.diagnosis)
                },
                error: e => {
                    this.toastNotificationService.error("notification_diagnosis_fetch_error"), console.error("Error loading data", e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        saveDiagnosis() {
            this.form.valid ? (this.loaderService.show(), (this.isEditMode ? this.jobDiagnosisService.updateDiagnosis(this.jobId, this.form.value) : this.jobDiagnosisService.createDiagnosis(this.jobId, this.form.value)).subscribe({
                next: o => {
                    this.diagnosis = new di(o.data), this.isEditMode = !0, this.isViewMode = !0, this.toastNotificationService.success("notification_diagnosis_save_success"), this.isVisibleSendNotificationPopup = !0
                },
                error: o => {
                    this.toastNotificationService.error("notification_diagnosis_save_error"), console.error("Error saving diagnosis", o)
                }
            }).add(() => {
                this.loaderService.hide()
            })) : this.formService.validateFormFields(this.form)
        }
        closeSendNotificationPopup() {
            this.isVisibleSendNotificationPopup = !1
        }
        showEditForm() {
            this.isViewMode = !1, this.form = di.getForm(this.diagnosis)
        }
        cancelDiagnosis() {
            this.isEditMode ? this.isViewMode = !0 : this.router.navigate(["/jobs", this.jobId, "overview"])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-diagnosis"]
                ],
                standalone: !1,
                decls: 13,
                vars: 10,
                consts: [
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", "m-1", 3, "iconType", "status"],
                    [1, "title-text", "float-start", "m-1"],
                    [1, "print-actions-bar"],
                    [3, "isVisibleHr", "saveText"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [1, "container-fluid", 3, "ngClass"],
                    [3, "isVisiblePopup", "isVisibleSendButton", "entityObj", "entity", "job"],
                    [3, "cancelClick", "saveClick", "isVisibleHr", "saveText"],
                    [3, "entityId", "entityName"],
                    [3, "entityObj", "entity", "job"],
                    [3, "entityId", "entityName", "isVisiblePrintButton", "isVisibleThermalPrint"],
                    [3, "entityId", "entityType"],
                    [3, "jobId"],
                    ["buttonType", "default", 3, "onClickEvent", "text", "title"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "job"],
                    [1, "row", "mt-3"],
                    [1, "col-12"],
                    [1, "card"],
                    [1, "card-header"],
                    [1, "mb-0"],
                    [1, "card-body"],
                    [1, "mb-3"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [1, "form-label", "fw-bold"],
                    [1, "text-muted", 3, "innerHTML"],
                    [3, "formGroup"],
                    ["name", "issue_observed", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label", "errorMsg"],
                    ["formControlName", "issue_observed", 3, "placeholder"],
                    ["name", "diagnosis_notes", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label", "errorMsg"],
                    ["formControlName", "diagnosis_notes", 3, "placeholder"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label"],
                    ["height", "auto", "formControlName", "term_and_condition"],
                    [1, "w-100", "p-3"],
                    [3, "cancelClick", "saveClick", "isOnPopup", "isVisibleHr", "saveText"],
                    [3, "sendNotificationClose", "isVisiblePopup", "isVisibleSendButton", "entityObj", "entity", "job"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), u(3, "app-job-status-tag", 3), r(4, "span", 4), d(5), a(), r(6, "div", 5), m(7, zv, 1, 2, "app-save-cancel-footer", 6), m(8, Xv, 9, 9), m(9, Zv, 2, 2, "div"), a()()()(), m(10, nf, 19, 13, "div", 7), m(11, af, 17, 11, "div", 8), m(12, rf, 1, 5, "app-send-notification", 9)), o & 2 && (l("ngClass", i.isMobileDevice ? "p-0" : ""), n(3), l("iconType", i.statusIconTypeList.TITLE)("status", i.job == null ? null : i.job.status), n(2), S(" ", i.job == null ? null : i.job.job_number, " "), n(2), _(!i.isViewMode && i.job && i.form && !i.isMobileDevice ? 7 : -1), n(), _(i.isViewMode ? 8 : -1), n(), _(i.isViewMode && (i.diagnosis != null && i.diagnosis.id) && i.isEmployee ? 9 : -1), n(), _(i.isViewMode && (i.diagnosis != null && i.diagnosis.id) ? 10 : -1), n(), _(!i.isViewMode && i.job && i.form ? 11 : -1), n(), _(i.diagnosis ? 12 : -1))
                },
                dependencies: [Q, Se, Xe, ee, K, kt, xt, vt, Nt, ft, pt, Ze, ht, tt, it, ge, _e, pe, q, re, le, se],
                encapsulation: 2
            })
        }
    }
    return t
})();
var xl = (() => {
    class t {
        constructor(e) {
            this.contactUsService = e, this.formatMessage = g, this.jobDataService = b(_o), this.router = b(G), this.dataService = b(qe), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.selectedTabIndex = 0, this.openSelfCheckInRequestCount = Y(0), this.jobModuleTabs = [], this.ENTITY_ICONS = Ut
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        ngOnInit() {
            this.jobModuleTabs = [...this.jobDataService.jobModuleTabs()], this.selectedTabIndex = this.activatedRouter.firstChild.snapshot.data.tab_index, this.dataService.selectedJobIndexSource.next(this.selectedTabIndex), this.dataService.selectedJobIndex$.subscribe({
                next: e => this.selectedTabIndex = e,
                error: e => console.error(e)
            }), this.contactUsService.getOpenSelfCheckInRequestCount().subscribe({
                next: e => {
                    this.openSelfCheckInRequestCount.set(e), this.updateSelfCheckInBadge(e)
                },
                error: e => {}
            })
        }
        updateSelfCheckInBadge(e) {
            let o = this.jobModuleTabs.findIndex(i => i.path === "/jobs/selfCheckIn");
            o !== -1 && (this.jobModuleTabs = this.jobModuleTabs.map((i, p) => p === o ? Ge(Te({}, i), {
                badgeCount: e
            }) : i))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(St))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job"]
                ],
                standalone: !1,
                decls: 2,
                vars: 8,
                consts: [
                    [1, "container-fluid"],
                    ["mode", "route", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "hideContentHeader", "contentContainerClass", "mobileMenuTitle", "mobileMenuIcon"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "app-responsive-tabs", 1), f("tabChange", function(y) {
                        return i.selectTab(y)
                    }), a()()), o & 2 && (n(), l("tabs", i.jobModuleTabs)("selectedIndex", i.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("hideContentHeader", !0)("contentContainerClass", i.isMobileDevice ? "mb-5" : "")("mobileMenuTitle", i.formatMessage("job"))("mobileMenuIcon", i.ENTITY_ICONS.JOB.solid))
                },
                dependencies: [Xi],
                encapsulation: 2
            })
        }
    }
    return t
})();

function sf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div")(1, "div", 2)(2, "div", 3)(3, "app-employee-dropdown", 4), f("ngModelChange", function(i) {
            C(e);
            let p = s();
            return v(p.updatesOnAssigneeUserId(i))
        }), a()(), r(4, "div", 5)(5, "dx-select-box", 6), f("onValueChanged", function(i) {
            C(e);
            let p = s();
            return v(p.onValueChange(i))
        }), a()(), r(6, "app-save-cancel-footer", 7), f("cancelClick", function() {
            C(e);
            let i = s();
            return v(i.onCancelContactUsUpdate())
        })("saveClick", function() {
            C(e);
            let i = s();
            return v(i.onSaveContactUsUpdate())
        }), a()()()
    }
    if (t & 2) {
        let e = s();
        n(3), l("ngModel", e.assignedUserId)("showClearButton", !1), n(2), l("items", e.statusList)("value", e.contactUsStatus), n(), l("isOnPopup", !0)
    }
}
var Sl = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = g, this.isVisiblePopup = !1, this.contactUsUpdatePopUpClose = new J, this.contactUsUpdatePopUpSave = new J, this.toastNotificationService = b(D), this.statusList = Object.values(Un), this.updateData = {
                id: null,
                status: "",
                assigned_user_id: 0
            }, this.event = event
        }
        ngOnInit() {
            this.contactUsStatus = this.contactUs.status, this.assignedUserId = this.contactUs.assigned_user_id, this.updateData.id = this.contactUs.id
        }
        onValueChange(e) {
            this.updateData.status = e.value
        }
        onSaveContactUsUpdate() {
            this.service.updateStatusAssignee(this.updateData).subscribe({
                next: e => {
                    this.toastNotificationService.success("notification_update_success"), this.contactUsUpdatePopUpSave.emit(e), this.isVisiblePopup = !1
                },
                error: e => {
                    console.error("failed to update ", e)
                }
            })
        }
        onSelectAssignee(e) {
            console.log(this.updateData.status, "Update Data"), this.updateData.assigned_user_id = e, this.updateData.status = this.updateData.status.length ? this.updateData.status : this.contactUs.status
        }
        onCancelContactUsUpdate() {
            this.contactUsUpdatePopUpClose.emit(), this.isVisiblePopup = !1
        }
        updatesOnAssigneeUserId(e) {
            this.assignedUserId = e, this.onSelectAssignee(e)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(St))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-contact-us-update-popup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    contactUs: "contactUs"
                },
                outputs: {
                    contactUsUpdatePopUpClose: "contactUsUpdatePopUpClose",
                    contactUsUpdatePopUpSave: "contactUsUpdatePopUpSave"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    ["id", "update-assign-status", 3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "d-flex", "align-items-baseline", "mb-2"],
                    ["id", "assign-to-popup-assignee", "placeholder", "job_assignee_placeholder", 2, "width", "100%", 3, "ngModelChange", "ngModel", "showClearButton"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "d-flex", "align-items-baseline"],
                    ["placeholder", "'Status'", "width", "100%", 3, "onValueChanged", "items", "value"],
                    ["cancelBtnId", "Cancel", "cancelLabel", "cancel", "saveBtnId", "Update", "saveText", "common_update", "savingText", "common_updating", 3, "cancelClick", "saveClick", "isOnPopup"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onCancelContactUsUpdate()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, sf, 7, 5, "div", 1), a()), o & 2 && (w("visible", i.isVisiblePopup), l("width", "95vw")("maxWidth", 450)("title", i.formatMessage("label_update_status_assignee")), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [K, Re, W, H, xe, q, $e],
                encapsulation: 2
            })
        }
    }
    return t
})();
var df = () => ({ of: "#contact-us-pickup"
});

function pf(t, c) {
    if (t & 1 && u(0, "dx-load-panel", 3), t & 2) {
        let e = s(2);
        l("indicatorSrc", e.loaderLogo)("position", Ye(4, df))("showPane", !1)("visible", e.isLoading())
    }
}

function mf(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 4), t & 2 && l("rows", 4)("columns", 2)
}

function _f(t, c) {
    if (t & 1 && u(0, "app-alert-panel", 8), t & 2) {
        let e = s(4);
        l("message", e.formatMessage("pickup_already_created_for_contact"))
    }
}

function uf(t, c) {
    if (t & 1 && (r(0, "app-control-container", 10), u(1, "app-customer-dropdown", 25), a()), t & 2) {
        let e, o = s(4);
        l("errorMsg", o.formatMessage("customer_required_error"))("label", o.formatMessage("user_customer")), n(), l("customerId", o.form.getRawValue().id ? (e = o.form.getRawValue()) == null ? null : e.user_id : null)("formControl", o.form.controls.user_id)("isEditMode", !1)("isRequiredAddress", !0)("isVisibleAddAction", !1)
    }
}

function Cf(t, c) {
    if (t & 1 && (r(0, "app-control-container", 17), u(1, "app-employee-dropdown", 26), a()), t & 2) {
        let e = s(4);
        l("errorMsg", e.formatMessage("assignee_error"))("label", e.formatMessage("job_assignee"))("tooltipText", "job_assigned_user_id"), n(), l("entity", e.entity)
    }
}

function vf(t, c) {
    if (t & 1 && (r(0, "app-control-container", 18), u(1, "dx-select-box", 27), a()), t & 2) {
        let e = s(4);
        l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status")), n(), l("items", e.statusList)("placeholder", e.formatMessage("common_select_status"))("showClearButton", !0)
    }
}

function ff(t, c) {
    if (t & 1 && u(0, "app-address", 19), t & 2) {
        let e = s(4);
        l("parentForm", e.addressForm)("isAddressOptional", !0)("isHrVisible", !1)
    }
}

function hf(t, c) {
    if (t & 1 && u(0, "app-user-notification-channel", 23), t & 2) {
        let e = s(4);
        l("form", e.form)
    }
}

function bf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 6), f("ngSubmit", function() {
            C(e);
            let i = s(3);
            return v(i.save())
        }), r(1, "dx-scroll-view", 7), m(2, _f, 1, 1, "app-alert-panel", 8), r(3, "div", 9), m(4, uf, 2, 7, "app-control-container", 10), r(5, "app-control-container", 11)(6, "app-restricted-content", 12), u(7, "app-mobile-number", 13)(8, "app-error", 14), a()(), r(9, "app-control-container", 15), u(10, "dx-date-box", 16)(11, "app-error", 14), a(), m(12, Cf, 2, 4, "app-control-container", 17), m(13, vf, 2, 5, "app-control-container", 18), m(14, ff, 1, 3, "app-address", 19), r(15, "app-control-container", 20)(16, "app-quick-reply-dropdown", 21), f("itemClick", function(i) {
            C(e);
            let p = s(3);
            return v(p.quickReplyValue(i))
        }), a(), u(17, "app-textarea", 22), a()(), m(18, hf, 1, 1, "app-user-notification-channel", 23), a(), r(19, "app-save-cancel-footer", 24), f("cancelClick", function() {
            C(e);
            let i = s(3);
            return v(i.onClosing())
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        l("formGroup", e.form), n(2), _((e.contactUs == null ? null : e.contactUs.status) === e.CONTACT_US_STATUS_LIST.PICKUP_BOOKED ? 2 : -1), n(2), _(e.isEmployee ? 4 : -1), n(), l("errorMsg", e.formatMessage("mobile_number_required_error"))("label", e.formatMessage("common_mobile")), n(), l("applyLock", !1)("permission", e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION), n(), l("formControl", e.form.controls.mobile_number)("form", e.form), n(), l("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), n(), l("errorMsg", e.formatMessage("common_error_messages_date_required"))("label", e.formatMessage("common_schedule_on")), n(), l("dateSerializationFormat", e.DATETIME_SERIALIZATION_FORMAT)("displayFormat", e.DISPLAY_DATETIME_SERIALIZATION_FORMAT)("disabledDates", e.disabledDates)("min", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("date_of_birth_placeholder")), n(), l("displayError", e.form.get("scheduled_on").invalid && e.form.get("scheduled_on").touched && e.form.controls.scheduled_on.getError("outsideBusinessHours"))("errorMsg", e.form.controls.scheduled_on.getError("outsideBusinessHours")), n(), _(e.isEmployee ? 12 : -1), n(), _(e.form.getRawValue().id && e.isEmployee ? 13 : -1), n(), _(e.addressForm ? 14 : -1), n(), l("errorMsg", e.formatMessage("common_error_messages_description_required"))("label", e.formatMessage("description_label")), n(2), l("formControl", e.form.controls.comment)("quickReply", e.quickReply), n(), _(e.isEmployee ? 18 : -1), n(), l("gaEvent", "pickup_drop_save_event")("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function gf(t, c) {
    if (t & 1 && (m(0, mf, 1, 2, "app-skeleton-loader", 4), m(1, bf, 20, 32, "form", 5)), t & 2) {
        let e = s(2);
        _(e.form ? -1 : 0), n(), _(e.form ? 1 : -1)
    }
}

function xf(t, c) {
    if (t & 1 && (r(0, "div", 2), m(1, pf, 1, 5, "dx-load-panel", 3)(2, gf, 2, 2), a()), t & 2) {
        let e = s();
        n(), _(e.isLoading() ? 1 : 2)
    }
}
var yl = (() => {
    class t {
        constructor(e, o, i) {
            this.service = e, this.contactUsService = o, this.fb = i, this.formatMessage = g, this.isVisiblePopup = !1, this.contactUsUpdatePopUpClose = new J, this.contactUsUpdatePopUpSave = new J, this.formService = b(me), this.generalSettingDataService = b(te), this.router = b(G), this.userSessionService = b(L), this.tenantService = b(ve), this.isMobileDevice = b(A).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.toastNotificationService = b(D), this.today = new Date, this.DATETIME_SERIALIZATION_FORMAT = La, this.DISPLAY_DATETIME_SERIALIZATION_FORMAT = Ba, this.ENTITIES = I, this.entity = I.PICKUP_DROP, this.isSaving = !1, this.isLoading = Y(!1), this.statusList = Object.values(Wa), this.customerId = null, this.SETTINGS = F, this.isBusinessHourSet = Y(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.GENERAL_SETTINGS.ENABLE_BUSINESS_HOURS)), this.disabledDates = Fr.getDisabledDates(this.isBusinessHourSet(), this.tenantService ? .config() ? .business_hours), this.PERMISSION_LIST = M, this.loaderLogo = ei, this.CONTACT_US_STATUS_LIST = Un
        }
        ngOnInit() {
            this.isLoading.set(!0), this.contactUsService.createCustomer(this.contactUs).subscribe({
                next: e => {
                    this.customer = e, this.customerId = e ? .id, this.form = so.getForm(new so({
                        user_id: this.customerId,
                        type: "Pickup",
                        mobile_number: e ? .mobile_number,
                        mobile_country_code: e ? .mobile_country_code,
                        device_type_id: this.contactUs ? .device_type_id,
                        assigned_user_id: this.contactUs ? .assigned_user_id,
                        scheduled_on: this.contactUs ? .scheduled_on || new Date,
                        address: ""
                    }), this.isBusinessHourSet(), this.tenantService ? .config() ? .business_hours), this.form.get("user_id").disable(), this.addressForm = this.fb.group({
                        address: this.fb.group({
                            address_line: [e ? .address ? .address_line || ""],
                            city: [e ? .address ? .city || ""],
                            state: [e ? .address ? .state || ""],
                            zip_code: [e ? .address ? .zip_code || ""]
                        })
                    })
                },
                error: e => {
                    this.toastNotificationService.error(e.error.message)
                }
            }).add(() => {
                this.isLoading.set(!1)
            })
        }
        onClosing() {
            this.form.reset(), this.isVisiblePopup = !1, this.pickupDrop = null, this.contactUsUpdatePopUpClose.emit()
        }
        save() {
            let e = this.addressForm ? .get("address") ? .value,
                o = e ? [e.address_line, e.city, [e.state, e.zip_code].filter(Boolean).join(" ")].filter(Boolean).join(`
`) : "";
            this.form.patchValue({
                address: o,
                entityType: this.ENTITIES.CONTACT_US.name,
                entityId: this.contactUs ? .id
            }), this.form.valid ? (this.isSaving = !0, this.service.create(this.form.getRawValue()).subscribe({
                next: i => {
                    this.toastNotificationService.success("notification_pickup_schedule_success"), this.pickupDrop = new so(i), this.isVisiblePopup = !1, this.contactUsUpdatePopUpSave.emit(this.pickupDrop)
                },
                error: () => {
                    this.toastNotificationService.error("notification_pickup_schedule_error")
                },
                complete: () => {
                    this.isSaving = !1, this.router.navigate(["/pickupDrops"])
                }
            })) : this.formService.validateFormFields(this.form)
        }
        quickReplyValue(e) {
            this.quickReply = e.comment ? ? e.title, this.form.patchValue({
                comment: this.quickReply
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(dr), T(St), T(Je))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-contact-us-pickup-popup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    contactUs: "contactUs"
                },
                outputs: {
                    contactUsUpdatePopUpClose: "contactUsUpdatePopUpClose",
                    contactUsUpdatePopUpSave: "contactUsUpdatePopUpSave"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "maxHeight", "width", "maxWidth", "title", "visible"],
                    ["class", "d-flex flex-column h-100", "id", "contact-us-pickup", 4, "dxTemplate", "dxTemplateOf"],
                    ["id", "contact-us-pickup", 1, "d-flex", "flex-column", "h-100"],
                    [3, "indicatorSrc", "position", "showPane", "visible"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "d-flex", "flex-column", "h-100", 3, "formGroup"],
                    [1, "d-flex", "flex-column", "h-100", 3, "ngSubmit", "formGroup"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [3, "message"],
                    [1, "row"],
                    ["name", "user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "mobile_number", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    [3, "applyLock", "permission"],
                    [3, "formControl", "form"],
                    [3, "displayError", "errorMsg"],
                    ["name", "scheduled_on", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "scheduled_on", "type", "datetime", 3, "dateSerializationFormat", "displayFormat", "disabledDates", "min", "pickerType", "placeholder"],
                    ["name", "assigned_user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label", "tooltipText"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["columnClass", "col-sm-6 col-md-6 col-lg-6", 3, "parentForm", "isAddressOptional", "isHrVisible"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    [3, "formControl", "quickReply"],
                    [3, "form"],
                    ["saveText", "common_schedule", "savingText", "common_scheduling", 3, "cancelClick", "gaEvent", "isOnPopup", "isSaving"],
                    [3, "customerId", "formControl", "isEditMode", "isRequiredAddress", "isVisibleAddAction"],
                    ["formControlName", "assigned_user_id", "placeholder", "delivery_placeholder_assignee", 3, "entity"],
                    ["formControlName", "status", 3, "items", "placeholder", "showClearButton"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onClosing()
                    }), E(1, xf, 3, 1, "div", 1), a()), o & 2 && (l("maxHeight", "90vh")("width", "95vw")("maxWidth", 700)("title", i.formatMessage("schedule_pickup"))("visible", i.isVisiblePopup), n(), l("dxTemplateOf", "content"))
                },
                dependencies: [ut, ee, et, K, zi, Re, Gi, bt, Yn, Yi, ue, _e, ro, W, Jt, ti, H, ye, xe, pe, q, re, st, le, se],
                encapsulation: 2
            })
        }
    }
    return t
})();
var yf = () => ({ of: "#contactUsPreviewPopUp"
    }),
    Tf = (t, c) => c.id;

function Mf(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "div", 11)(2, "label", 12), d(3), a(), r(4, "p", 13), d(5), a()()()), t & 2) {
        let e = s(3);
        n(3), h(e.formatMessage("serial_number2")), n(2), h((e.contactUs == null ? null : e.contactUs.serial_number_2) || "Not Provided")
    }
}

function Pf(t, c) {
    if (t & 1 && (r(0, "div", 10)(1, "div", 11)(2, "label", 12), d(3), a(), r(4, "p", 13), d(5), a()()()), t & 2) {
        let e = s(3);
        n(3), h(e.formatMessage("size")), n(2), h((e.contactUs == null ? null : e.contactUs.size) + " " + (e.contactUs == null ? null : e.contactUs.capacity_measure) || "Not Provided")
    }
}

function If(t, c) {
    if (t & 1 && u(0, "app-image-gallery-popup", 21), t & 2) {
        let e = c.$implicit;
        l("attachment", e)("isOnTableListing", !1)
    }
}

function Ef(t, c) {
    if (t & 1 && (r(0, "div", 5)(1, "div", 6)(2, "h6", 7), u(3, "i", 19), d(4), a(), r(5, "div", 20), X(6, If, 1, 2, "app-image-gallery-popup", 21, Tf), a()()()), t & 2) {
        let e = s(3);
        n(4), S("", e.formatMessage("images"), " "), n(2), Z(e.contactUs == null ? null : e.contactUs.attachments)
    }
}

function wf(t, c) {
    if (t & 1 && (r(0, "div", 5)(1, "div", 6)(2, "h6", 7), u(3, "i", 8), d(4), a(), r(5, "div", 9)(6, "div", 10)(7, "div", 11)(8, "label", 12), d(9), a(), r(10, "p", 13), d(11), a()()(), r(12, "div", 10)(13, "div", 11)(14, "label", 12), d(15), a(), r(16, "p", 13), d(17), a()()(), r(18, "div", 10)(19, "div", 11)(20, "label", 12), d(21), a(), r(22, "p", 13), d(23), V(24, "mobileDisplay"), a()()(), r(25, "div", 10)(26, "div", 11)(27, "label", 12), d(28), a(), r(29, "p", 13)(30, "span", 14), d(31), a()()()(), r(32, "div", 15)(33, "div", 11)(34, "label", 12), d(35), a(), r(36, "p", 13), d(37), a()()()()()(), r(38, "div", 5)(39, "div", 6)(40, "h6", 7), u(41, "i", 16), d(42), a(), r(43, "div", 9)(44, "div", 10)(45, "div", 11)(46, "label", 12), d(47), a(), r(48, "p", 13), d(49), a()()(), r(50, "div", 10)(51, "div", 11)(52, "label", 12), d(53), a(), r(54, "p", 13), d(55), a()()(), r(56, "div", 10)(57, "div", 11)(58, "label", 12), d(59), a(), r(60, "p", 13), d(61), a()()(), r(62, "div", 10)(63, "div", 11)(64, "label", 12), d(65), a(), r(66, "p", 13), d(67), a()()(), m(68, Mf, 6, 2, "div", 10), r(69, "div", 10)(70, "div", 11)(71, "label", 12), d(72), a(), r(73, "p", 13), d(74), a()()(), m(75, Pf, 6, 2, "div", 10), r(76, "div", 10)(77, "div", 11)(78, "label", 12), d(79), a(), r(80, "p", 13), d(81), a()()()()()(), r(82, "div", 5)(83, "div", 6)(84, "h6", 7), u(85, "i", 17), d(86), a(), r(87, "div", 9)(88, "div", 15)(89, "div", 11)(90, "label", 12), d(91), a(), r(92, "p", 13), d(93), a()()(), r(94, "div", 15)(95, "div", 11)(96, "label", 12), d(97), a(), r(98, "div", 18), V(99, "safe"), d(100), a()()()()()(), m(101, Ef, 8, 1, "div", 5)), t & 2) {
        let e = s(2);
        n(4), S("", e.formatMessage("job_customer_detail"), " "), n(5), h(e.formatMessage("common_name")), n(2), h((e.contactUs == null ? null : e.contactUs.name) || "Not Provided"), n(4), h(e.formatMessage("common_email")), n(2), h((e.contactUs == null ? null : e.contactUs.email) || "Not Provided"), n(4), h(e.formatMessage("common_mobile_number")), n(2), h(B(24, 33, e.contactUs == null ? null : e.contactUs.mobile_number, e.contactUs == null ? null : e.contactUs.mobile_country_code) || "Not Provided"), n(5), h(e.formatMessage("common_status")), n(3), h((e.contactUs == null ? null : e.contactUs.status) || "Not Provided"), n(4), h(e.formatMessage("common_address")), n(2), h(e.contactUs != null && e.contactUs.address ? e.contactUs == null ? null : e.contactUs.fullAddress : "Not Provided"), n(5), S("", e.formatMessage("job_device_detail"), " "), n(5), h(e.formatMessage("device_type_name")), n(2), h((e.contactUs == null || e.contactUs.device_type == null ? null : e.contactUs.device_type.name) || "Not Provided"), n(4), h(e.formatMessage("device_brand_name")), n(2), S("", (e.contactUs == null || e.contactUs.device_brand == null ? null : e.contactUs.device_brand.name) || (e.contactUs == null ? null : e.contactUs.custom_brand_name) || "Not Provided", " "), n(4), h(e.formatMessage("device_model_name")), n(2), S("", (e.contactUs == null || e.contactUs.device_model == null ? null : e.contactUs.device_model.name) || (e.contactUs == null ? null : e.contactUs.custom_model_name) || "Not Provided", " "), n(4), h(e.formatMessage("serial_number_label")), n(2), h((e.contactUs == null ? null : e.contactUs.serial_number) || "Not Provided"), n(), _(e.contactUs != null && e.contactUs.is_recovery ? 68 : -1), n(4), h(e.formatMessage("device_password")), n(2), h((e.contactUs == null ? null : e.contactUs.device_password) || "Not Provided"), n(), _(e.contactUs != null && e.contactUs.is_recovery ? 75 : -1), n(4), h(e.formatMessage("accessory")), n(2), h((e.contactUs == null ? null : e.contactUs.accessoriesName) || "None"), n(5), S("", e.formatMessage("job_service_information"), " "), n(5), h(e.formatMessage("job_service")), n(2), h((e.contactUs == null ? null : e.contactUs.repairablesName) || "None"), n(4), h(e.formatMessage("comment")), n(), l("innerHTML", B(99, 36, e.contactUs == null ? null : e.contactUs.comment, "html"), We), n(2), S(" ", (e.contactUs == null ? null : e.contactUs.comment) || "Not Provided", " "), n(), _(e.galleryDataSource.length > 0 ? 101 : -1)
    }
}

function Of(t, c) {
    if (t & 1 && (r(0, "div")(1, "dx-scroll-view", 3)(2, "div", 4), m(3, wf, 102, 39), a()()()), t & 2) {
        let e = s();
        n(), l("height", "100%")("showScrollbar", "onScroll"), n(2), _(e.isLoading ? -1 : 3)
    }
}
var Tl = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = g, this.isVisiblePopup = !1, this.cancelPopUpClose = new J, this.isMobileDevice = b(A).isMobileDevice(), this.toastNotificationService = b(D), this.isLoading = !1, this.imageAttachments = [], this.galleryDataSource = [], this.loaderLogo = ei
        }
        ngOnInit() {
            this.isLoading = !0, this.service.getById(this.contactUsId).subscribe({
                next: e => {
                    this.contactUs = e, this.prepareImageGallery()
                },
                error: e => {
                    this.toastNotificationService.error("notification_contact_us_fetch_error")
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        prepareImageGallery() {
            this.contactUs ? .attachments && Array.isArray(this.contactUs.attachments) && (this.imageAttachments = this.contactUs.attachments.filter(e => this.isImage(e)), this.galleryDataSource = this.imageAttachments.map(e => ({
                imageSrc: e.link,
                imageAlt: e.name || "Attachment Image",
                name: e.name,
                id: e.id
            })))
        }
        isImage(e) {
            let o = ["jpg", "jpeg", "png", "gif", "bmp", "webp", "svg"],
                i = e.mime ? .startsWith("image/"),
                p = o.includes(e.extension ? .toLowerCase());
            return i || p
        }
        isPDF(e) {
            return e ? .mime === "application/pdf" || e.extension ? .toLowerCase() === "pdf"
        }
        onCancel() {
            this.cancelPopUpClose.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(St))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-contact-us-preview"]
                ],
                inputs: {
                    contactUsId: "contactUsId",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    cancelPopUpClose: "cancelPopUpClose"
                },
                standalone: !1,
                decls: 3,
                vars: 12,
                consts: [
                    ["id", "contact-us-preview", 3, "onHidden", "visibleChange", "visible", "height", "width", "maxWidth", "minHeight", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "visibleChange", "visible", "indicatorSrc", "position", "showPane"],
                    [3, "height", "showScrollbar"],
                    ["id", "contactUsPreviewPopUp", 1, "container-fluid"],
                    [1, "card", "border-0", "shadow-sm", "mb-3"],
                    [1, "card-body", "p-3"],
                    [1, "card-title", "text-primary", "fw-bold", "mb-3", "border-bottom", "pb-2"],
                    [1, "fa-thin", "fa-user", "me-2"],
                    [1, "row", "g-3"],
                    [1, "col-sm-12", "col-md-6"],
                    [1, "mb-2"],
                    [1, "form-label", "text-muted", "small", "mb-1"],
                    [1, "fw-semibold", "mb-0"],
                    [1, "badge", "bg-success"],
                    [1, "col-12"],
                    [1, "fa-thin", "fa-laptop", "me-2"],
                    [1, "fa-thin", "fa-tools", "me-2"],
                    [1, "fw-semibold", "comment-box", "p-2", "rounded", 3, "innerHTML"],
                    [1, "fa-thin", "fa-images", "me-2"],
                    [1, "d-flex", "align-items-center", "flex-wrap", "gap-2"],
                    [3, "attachment", "isOnTableListing"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "dx-popup", 0), f("onHidden", function() {
                        return i.onCancel()
                    }), j("visibleChange", function(y) {
                        return O(i.isVisiblePopup, y) || (i.isVisiblePopup = y), y
                    }), E(1, Of, 4, 3, "div", 1), a(), r(2, "dx-load-panel", 2), j("visibleChange", function(y) {
                        return O(i.isLoading, y) || (i.isLoading = y), y
                    }), a()), o & 2 && (w("visible", i.isVisiblePopup), l("height", "90vh")("width", "95vw")("maxWidth", i.isMobileDevice ? 400 : 900)("minHeight", 200)("title", i.formatMessage("self_checkin_preview")), n(), l("dxTemplateOf", "content"), n(), w("visible", i.isLoading), l("indicatorSrc", i.loaderLogo)("position", Ye(11, yf))("showPane", !1))
                },
                dependencies: [Ri, W, ti, H, ye, Dt, mt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Vf = (t, c, e) => [t, c, e],
    Df = (t, c, e) => ({
        icon: "dx-icon-checklist",
        title: t,
        description: c,
        quickTips: e,
        tutorialUrl: "https://www.youtube.com/watch?v=YOuncMr9czU",
        tutorialVisible: !0,
        primaryButtonVisible: !1
    }),
    kf = () => ({ of: "#contact-us"
    });

function Nf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-add-customer-popup", 6), f("addCustomerClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("addCustomerSave", function(i) {
            C(e);
            let p = s();
            return v(p.onConvertToCustomerSaveAction(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("customer", e.currentContactUs)("isAlreadyCustomer", e.isAlreadyCustomer)("isVisiblePopup", e.currentContextMenuAction === e.CONTACT_US_CONTEXT_MENU_LIST.CONVERT_TO_CUSTOMER && e.isVisibleCreateCustomerPopUp)("userId", e.userId)
    }
}

function Af(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-contact-us-update-popup", 7), f("contactUsUpdatePopUpClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("contactUsUpdatePopUpSave", function(i) {
            C(e);
            let p = s();
            return v(p.saveAndClose(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("contactUs", e.currentContactUs)("isVisiblePopup", e.isVisibleChangeStatusPopup)
    }
}

function Jf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-contact-us-pickup-popup", 7), f("contactUsUpdatePopUpClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("contactUsUpdatePopUpSave", function(i) {
            C(e);
            let p = s();
            return v(p.saveAndClose(i))
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("contactUs", e.currentContactUs)("isVisiblePopup", (e.currentContactUs == null ? null : e.currentContactUs.id) && e.currentContextMenuAction === e.CONTACT_US_CONTEXT_MENU_LIST.APPROVE_AND_BOOK_PICKUP)
    }
}

function Lf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-contact-us-preview", 8), f("cancelPopUpClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("contactUsId", e.currentContactUs == null ? null : e.currentContactUs.id)("isVisiblePopup", (e.currentContactUs == null ? null : e.currentContactUs.id) && e.currentContextMenuAction === e.CONTACT_US_CONTEXT_MENU_LIST.VIEW)
    }
}
var Ml = (() => {
    class t {
        get hasTenantContactUs() {
            return (this.tenantService.config() ? .entity_counts ? .contact_us || 0) > 0
        }
        constructor(e) {
            this.service = e, this.formatMessage = g, this.ENTITIES = I, this.moduleDataService = b(mo), this.generalSettingDataService = b(te), this.router = b(G), this.commonService = b(Di), this.toastNotificationService = b(D), this.userSessionService = b(L), this.tenantService = b(ve), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.SETTINGS = F, this.currentContextMenuAction = null, this.USER_TYPES = wi, this.isVisibleCreateCustomerPopUp = !1, this.isVisibleChangeStatusPopup = !1, this.entityId = null, this.isAlreadyCustomer = !1, this.isLoading = !1, this.contactUsContextMenu = [], this.entity = I.CONTACT_US, this.loaderLogo = ei, this.CONTACT_US_CONTEXT_MENU_LIST = wt
        }
        ngOnInit() {
            this.contactUsContextMenu = [{
                name: wt.VIEW,
                icon: "fa-thin fa-eye",
                visible: this.isEmployee && this.userPermissionList.includes(M.CONTACT_US_LIST),
                locale_key: g("common_view")
            }, {
                name: wt.CHANGE_STATUS,
                icon: "fa-thin fa-money-check-alt",
                visible: this.isEmployee && this.userPermissionList.includes(M.CONTACT_US_WRITE),
                locale_key: g("contact_us_action_change_status")
            }, {
                name: wt.APPROVE_AND_BOOK_PICKUP,
                icon: "fa-thin fa-person-carry-box",
                disabled: !this.moduleDataService.isModuleActive(this.ENTITIES.PICKUP_DROP.name),
                visible: this.isEmployee && this.userPermissionList.includes(M.PICKUP_DROP_WRITE),
                locale_key: g("contact_us_action_approve_and_book_pickup")
            }, {
                name: wt.APPROVE_AND_CREATE_JOB,
                icon: "fa-thin fa-ticket",
                disabled: !this.moduleDataService.isModuleActive(this.ENTITIES.JOB.name),
                visible: this.isEmployee && this.userPermissionList.includes(M.JOB_WRITE),
                locale_key: g("contact_us_action_approve_and_create_job")
            }, {
                name: wt.CONVERT_TO_CUSTOMER,
                icon: "fa-thin fa-file-invoice-dollar",
                visible: this.isEmployee && this.userPermissionList.includes(M.CONTACT_US_WRITE),
                locale_key: g("contact_us_action_convert_to_customer")
            }], this.columns = [{
                dataField: "name",
                caption: g("open_lead"),
                width: 130,
                allowSorting: !0
            }, {
                dataField: "mobile_number",
                caption: g("common_mobile"),
                width: 130,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "email",
                caption: g("common_email"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "assigned_user",
                caption: g("job_assignee"),
                cellTemplate: "employeeTemplate",
                hidingPriority: 2,
                allowSorting: !1
            }, {
                dataField: "status",
                caption: g("common_status"),
                alignment: "left",
                allowSorting: !1,
                cellTemplate: "contactUsStatusTemplate",
                hidingPriority: 7
            }, {
                dataField: "address",
                caption: g("common_address"),
                alignment: "left",
                allowSorting: !1,
                cellTemplate: "addressTemplate",
                visible: !1,
                hidingPriority: 12
            }, {
                dataField: "device_type.name",
                caption: g("device_type_name"),
                alignment: "left",
                allowSorting: !1,
                hidingPriority: 9
            }, {
                dataField: "accessoriesName",
                caption: g("accessory"),
                alignment: "left",
                allowSorting: !1,
                visible: !1,
                hidingPriority: 11
            }, {
                dataField: "repairablesName",
                caption: g("job_services"),
                alignment: "left",
                allowSorting: !1,
                hidingPriority: 10
            }, {
                dataField: "device_brand.name",
                caption: g("device_brand_name"),
                alignment: "left",
                allowSorting: !1,
                visible: !1,
                hidingPriority: 8,
                calculateCellValue: e => e.device_brand ? .name || e.custom_brand_name || ""
            }, {
                dataField: "device_model.name",
                caption: g("device_model_name"),
                alignment: "left",
                allowSorting: !1,
                visible: !1,
                hidingPriority: 7,
                calculateCellValue: e => e.device_model ? .name || e.custom_model_name || ""
            }, {
                dataField: "is_pickup_booked",
                caption: g("lead_is_pickup_booked"),
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                visible: !1,
                hidingPriority: 6
            }, {
                dataField: "scheduled_on",
                caption: g("lead_pick_up_time"),
                cellTemplate: "dueDateTimeTemplate",
                allowSorting: !1,
                visible: !1,
                hidingPriority: 5
            }, {
                dataField: "comment",
                caption: g("common_comment"),
                alignment: "left",
                allowSorting: !1,
                cellTemplate: "commentTemplate",
                hidingPriority: 5
            }, {
                dataField: "is_recovery",
                caption: g("is_recovery_job"),
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                hidingPriority: 4,
                visible: [Go.BOTH, Go.RECOVERY_SERVICE].includes(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.WORKFLOW_SETTINGS.SERVICE_OPTION))
            }, {
                dataField: "updated_at",
                caption: g("common_updated_on"),
                hidingPriority: 1,
                width: 155,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: g("common_created_on"),
                hidingPriority: 0,
                width: 155,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                caption: "",
                width: 45,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        onContextMenuItemClick(e) {
            if (this.currentContextMenuAction = e.action, this.currentContactUs = e.entity, this.checkUniqueEmailAndMobileNumber(), this.currentContextMenuAction === wt.CHANGE_STATUS && (this.isVisibleChangeStatusPopup = !0), this.currentContextMenuAction === wt.APPROVE_AND_CREATE_JOB) {
                this.isVisibleChangeStatusPopup = !0;
                let o = JSON.stringify(this.currentContactUs);
                this.router.navigate(["/jobs/add"], {
                    queryParams: {
                        is_recovery: this.currentContactUs ? .is_recovery ? ? !1,
                        state: o
                    }
                })
            }
        }
        onCloseContextMenuOption() {
            this.isAlreadyCustomer = !1, this.currentContextMenuAction = null, this.currentContactUs = null
        }
        onConvertToCustomerSaveAction(e) {
            this.service.convertToCustomer(this.currentContactUs ? .id).subscribe({
                next: o => {
                    console.log("response is", o)
                },
                error: o => {
                    this.toastNotificationService.error("failed_to_change_status")
                }
            }), this.saveAndClose(e)
        }
        saveAndClose(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        checkUniqueEmailAndMobileNumber() {
            this.currentContextMenuAction === wt.CONVERT_TO_CUSTOMER && (this.isLoading = !0, this.currentContactUs.mobile_number && this.commonService.checkUniqueMobileNumber({
                entity: "users",
                mobile_number: this.currentContactUs.mobile_number,
                entity_id: this.entityId,
                type_id: this.USER_TYPES.CUSTOMER
            }).subscribe({
                next: e => {
                    e.success ? (this.isLoading = !1, this.isVisibleCreateCustomerPopUp = !0) : (this.userId = e.user[0].id, this.isAlreadyCustomer = !0, this.isLoading = !1, this.isVisibleCreateCustomerPopUp = !0)
                },
                error: e => {
                    console.error(e)
                }
            }), this.currentContactUs.email && this.commonService.checkUniqueEmail({
                entity: "users",
                email: this.currentContactUs.email,
                entity_id: this.entityId,
                type_id: this.USER_TYPES.CUSTOMER
            }).subscribe({
                next: e => {
                    e.success ? (this.isLoading = !1, this.isVisibleCreateCustomerPopUp = !0) : (this.userId = e.user[0].id, this.isAlreadyCustomer = !0, this.isLoading = !1, this.isVisibleCreateCustomerPopUp = !0)
                },
                error: e => {
                    console.error(e)
                }
            }))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(St))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-contact-us-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(ce, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.dataGrid = p.first)
                    }
                },
                standalone: !1,
                decls: 7,
                vars: 27,
                consts: [
                    ["id", "contact-us", 1, "pb-3"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "columns", "contextMenuItems", "dataGridId", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "searchPanelPlaceholderText", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "customer", "isAlreadyCustomer", "isVisiblePopup", "userId"],
                    [3, "contactUs", "isVisiblePopup"],
                    [3, "contactUsId", "isVisiblePopup"],
                    [3, "visibleChange", "visible", "indicatorSrc", "position", "showPane"],
                    [3, "addCustomerClose", "addCustomerSave", "customer", "isAlreadyCustomer", "isVisiblePopup", "userId"],
                    [3, "contactUsUpdatePopUpClose", "contactUsUpdatePopUpSave", "contactUs", "isVisiblePopup"],
                    [3, "cancelPopUpClose", "contactUsId", "isVisiblePopup"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "div", 0)(1, "app-data-grid", 1), f("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(y) {
                        return i.onContextMenuItemClick(y)
                    }), a()(), m(2, Nf, 1, 4, "app-add-customer-popup", 2), m(3, Af, 1, 2, "app-contact-us-update-popup", 3), m(4, Jf, 1, 2, "app-contact-us-pickup-popup", 3), m(5, Lf, 1, 2, "app-contact-us-preview", 4), r(6, "dx-load-panel", 5), j("visibleChange", function(y) {
                        return O(i.isLoading, y) || (i.isLoading = y), y
                    }), a()), o & 2 && (n(), l("columns", i.columns)("contextMenuItems", i.contactUsContextMenu)("dataGridId", "tabAndGridContainer")("entity", i.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("searchPanelPlaceholderText", "search_panel_self_checkin_placeholder")("service", i.service)("hasTenantData", i.hasTenantContactUs)("emptyStateConfig", ot(22, Df, i.formatMessage("empty_state_self_checkin_title"), i.formatMessage("empty_state_self_checkin_description"), ot(18, Vf, i.formatMessage("empty_state_self_checkin_tip_1"), i.formatMessage("empty_state_self_checkin_tip_2"), i.formatMessage("empty_state_self_checkin_tip_3")))), n(), _(i.currentContactUs != null && i.currentContactUs.id && i.currentContextMenuAction === i.CONTACT_US_CONTEXT_MENU_LIST.CONVERT_TO_CUSTOMER && i.isVisibleCreateCustomerPopUp ? 2 : -1), n(), _(i.currentContactUs != null && i.currentContactUs.id && i.currentContextMenuAction === i.CONTACT_US_CONTEXT_MENU_LIST.CHANGE_STATUS && i.isVisibleChangeStatusPopup ? 3 : -1), n(), _(i.currentContactUs != null && i.currentContactUs.id && i.currentContextMenuAction === i.CONTACT_US_CONTEXT_MENU_LIST.APPROVE_AND_BOOK_PICKUP ? 4 : -1), n(), _(i.currentContactUs != null && i.currentContactUs.id && i.currentContextMenuAction === i.CONTACT_US_CONTEXT_MENU_LIST.VIEW ? 5 : -1), n(), w("visible", i.isLoading), l("indicatorSrc", i.loaderLogo)("position", Ye(26, kf))("showPane", !1))
                },
                dependencies: [Jr, ce, ti, Sl, yl, Tl],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Bf(t, c) {
    if (t & 1 && u(0, "app-send-whats-app-btn", 7), t & 2) {
        let e = s(2);
        l("entityId", e.outsourceJob == null ? null : e.outsourceJob.id)("entityName", e.ENTITIES.OUTSOURCED_JOB.name)
    }
}

function Rf(t, c) {
    if (t & 1 && (r(0, "div", 22)(1, "div")(2, "span", 24), d(3), a(), r(4, "span", 25), d(5, ":"), a(), d(6), a()()), t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("common_name")), n(3), S("", e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.name, " ")
    }
}

function Uf(t, c) {
    if (t & 1 && (r(0, "span"), d(1), a()), t & 2) {
        let e = s(5);
        n(), S("\xA0/\xA0", e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.phone_number)
    }
}

function Ff(t, c) {
    if (t & 1 && (r(0, "div", 22)(1, "div")(2, "span", 24), d(3), a(), r(4, "span", 25), d(5, ":"), a(), d(6), V(7, "mobileDisplay"), m(8, Uf, 2, 1, "span"), a()()), t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("common_phone")), n(3), S("", B(7, 3, e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.mobile_number, e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.mobile_country_code), " "), n(2), _(!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.phone_number ? 8 : -1)
    }
}

function qf(t, c) {
    if (t & 1 && (r(0, "div", 22)(1, "div")(2, "span", 24), d(3), a(), r(4, "span", 25), d(5, ":"), a(), d(6), a()()), t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("common_email")), n(3), S("", e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.email, " ")
    }
}

function Gf(t, c) {
    if (t & 1 && (r(0, "div", 23)(1, "div")(2, "span", 24), d(3), a(), r(4, "span", 25), d(5, ":"), a(), d(6), V(7, "address"), a()()), t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("common_address")), n(3), S("", ie(7, 2, e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.address), " ")
    }
}

function Wf(t, c) {
    if (t & 1 && (r(0, "div", 15)(1, "div", 3)(2, "h5", 19), d(3), a(), u(4, "div", 20), r(5, "div", 21), m(6, Rf, 7, 2, "div", 22), m(7, Ff, 9, 6, "div", 22), m(8, qf, 7, 2, "div", 22), m(9, Gf, 8, 4, "div", 23), a()()()), t & 2) {
        let e = s(3);
        n(3), h(e.formatMessage("vendor_details")), n(3), _(e.printOptions.name ? 6 : -1), n(), _(e.printOptions.phone_number || e.printOptions.mobile_number && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.mobile_number) && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.phone_number) ? 7 : -1), n(), _(e.printOptions.email && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.email) ? 8 : -1), n(), _(e.printOptions.address && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.address) ? 9 : -1)
    }
}

function Hf(t, c) {
    if (t & 1 && (r(0, "div", 11)(1, "div", 2)(2, "div", 3)(3, "div", 2)(4, "div", 12), u(5, "app-invoice-header", 13)(6, "app-invoice-title", 14), m(7, Wf, 10, 5, "div", 15), u(8, "app-invoice-job-details", 16)(9, "hr", 17)(10, "app-invoice-signature", 18), a()()()()()), t & 2) {
        let e = s(2);
        n(5), l("account", e.account)("qrCode", (e.outsourceJob == null ? null : e.outsourceJob.id) && e.printOptions.qr_code && (e.outsourceJob == null ? null : e.outsourceJob.qr_code)), n(), l("dateTime", e.outsourceJob.created_at)("title", e.formatMessage("outsource_delivery_challan") + (e.outsourceJob == null ? null : e.outsourceJob.id)), n(), _(e.outsourceJob != null && e.outsourceJob.vendor ? 7 : -1), n(), l("job", e.job), n(2), l("entityId", e.outsourceJob == null ? null : e.outsourceJob.id)("entityType", e.entityType)
    }
}

function Qf(t, c) {
    if (t & 1 && (r(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), u(5, "app-job-status-tag", 4), r(6, "span", 5), d(7), a(), r(8, "div", 6), m(9, Bf, 1, 2, "app-send-whats-app-btn", 7), u(10, "app-job-btn", 8)(11, "app-print-button", 9)(12, "app-share-btn", 10), a()()()(), m(13, Hf, 11, 8, "div", 11), a()()), t & 2) {
        let e = s();
        n(5), l("iconType", e.statusIconTypeList.TITLE)("statusId", e.job == null ? null : e.job.status_id), n(2), S(" ", e.job == null ? null : e.job.job_number, " "), n(2), _(e.isEmployee ? 9 : -1), n(), l("jobId", e.job == null ? null : e.job.id), n(), l("entityId", e.outsourceJob == null ? null : e.outsourceJob.id)("entityName", e.ENTITIES.OUTSOURCED_JOB.name)("isVisiblePrintButton", !!(e.outsourceJob != null && e.outsourceJob.id))("isVisibleThermalPrint", !1), n(), l("entityId", e.outsourceJob == null ? null : e.outsourceJob.id)("entityType", e.ENTITIES.OUTSOURCED_JOB.name), n(), _(e.job ? 13 : -1)
    }
}
var Pl = (() => {
    class t {
        constructor(e, o) {
            this.jobService = e, this.service = o, this.formatMessage = g, this.generalSettingDataService = b(te), this.userSessionService = b(L), this.activatedRouter = b(R), this.isEmployee = this.userSessionService.isEmployee(), this.statusIconTypeList = he, this.ENTITIES = I, this.entityType = this.ENTITIES.OUTSOURCED_JOB.name, this.dateTime = new Date, this.printOptions = null
        }
        ngOnInit() {
            if (this.printOptions = this.generalSettingDataService.getGeneralSettingBySettingType(Ce.PRINT_SETTINGS) ? ? Vt.getEmptyObject(), this.activatedRouter.snapshot.paramMap.has("id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("id");
                this.service.getById(e).subscribe({
                    next: o => {
                        this.job = o ? .job, this.outsourceJob = o
                    },
                    error: o => {
                        console.log(o)
                    }
                })
            }
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(U), T(ln))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-delivery-challan"]
                ],
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mt-2", "mb-3"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "statusId"],
                    [1, "title-text", "float-start"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    [1, "mx-1", 3, "jobId"],
                    [3, "entityId", "entityName", "isVisiblePrintButton", "isVisibleThermalPrint"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["id", "print-section", 1, "container-fluid"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "background-row"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [1, "row", "background-row", "mt-1"],
                    [3, "job"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "clearfix"],
                    [1, "row", "ps-3"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold"],
                    [1, "px-1"]
                ],
                template: function(o, i) {
                    o & 1 && m(0, Qf, 14, 12, "div", 0), o & 2 && _(i.outsourceJob ? 0 : -1)
                },
                dependencies: [Se, Xe, xt, vt, ft, pt, Ze, ht, it, ur, mt],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var Il = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = g, this.router = b(G), this.entity = I.OUTSOURCE_VENDOR, this.isCreate = !1, this.columns = [{
                dataField: "name",
                caption: g("job_outsource_vendor"),
                width: 130,
                cellTemplate: "vendorTemplate",
                allowSorting: !0
            }, {
                dataField: "mobile_number",
                caption: g("common_mobile"),
                width: 130,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "phone_number",
                caption: g("user_phone"),
                hidingPriority: 4,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "email",
                caption: g("common_email"),
                cellTemplate: "emailTemplate",
                hidingPriority: 5,
                allowSorting: !0
            }, {
                dataField: "tax_number",
                caption: g("common_tax_number"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "address.city",
                caption: g("common_city"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: g("common_updated_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: g("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        onOutsourceVendorSave() {
            this.dataGrid.getData()
        }
        create() {
            this.router.navigate(["/jobs/outsourceTo/vendors/add"])
        }
        edit(e) {
            this.router.navigate([`/jobs/outsourceTo/vendors/${e.id}/profiles`])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ri))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-vendor-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(ce, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.dataGrid = p.first)
                    }
                },
                standalone: !1,
                decls: 1,
                vars: 4,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "service"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "app-data-grid", 0), f("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(y) {
                        return i.edit(y)
                    }), a()), o & 2 && l("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !1)("service", i.service)
                },
                dependencies: [ce],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ht = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new Je().group({
            id: [c.id || null],
            name: [c.name || null, [de.required]],
            email: [c.email || null],
            mobile_number: [c.mobile_number || null, [de.required, Qo.phoneNumberValidator]],
            mobile_country_code: [c.mobile_country_code || null],
            phone_number: [c.phone_number || null, [Qo.phoneNumberValidator]],
            tax_number: [c.tax_number || null],
            address: zo.getForm(new zo(c.address)),
            roles: [c.roles || null]
        })
    }
};

function zf(t, c) {
    t & 1 && u(0, "app-skeleton-loader", 0), t & 2 && l("rows", 8)("columns", 3)
}

function Yf(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-save-cancel-footer", 21), f("cancelClick", function() {
            C(e);
            let i = s(2);
            return v(i.cancel())
        }), a()
    }
    if (t & 2) {
        let e = s(2);
        l("gaEvent", "create_update_outsource_vendor_event")("isVisibleHr", !1)("saveText", e.outsourceVendorId ? "common_save" : "common_create")
    }
}

function $f(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-dx-outline-button", 24), f("onClickEvent", function() {
            C(e);
            let i = s(4);
            return v(i.setEditMode())
        }), a()
    }
}

function Kf(t, c) {
    if (t & 1 && E(0, $f, 1, 0, "app-dx-outline-button", 23), t & 2) {
        let e = s(3);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.EMPLOYEE_WRITE)
    }
}

function Xf(t, c) {
    if (t & 1 && m(0, Kf, 1, 1, "app-dx-outline-button", 22), t & 2) {
        let e = s(2);
        _(e.userPermissionList.includes(e.PERMISSION_LIST.EMPLOYEE_WRITE) ? 0 : -1)
    }
}

function Zf(t, c) {
    if (t & 1 && u(0, "app-server-error", 6), t & 2) {
        let e = s(2);
        l("errorResponse", e.errorResponse)
    }
}

function eh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "form", 2), f("ngSubmit", function() {
            C(e);
            let i = s();
            return v(i.save())
        }), r(1, "div", 3)(2, "div", 4), m(3, Yf, 1, 3, "app-save-cancel-footer", 5)(4, Xf, 1, 1), m(5, Zf, 1, 1, "app-server-error", 6), a()(), r(6, "h5"), d(7), a(), u(8, "hr"), r(9, "div", 7)(10, "app-control-container", 8), u(11, "dx-text-box", 9), a(), r(12, "app-control-container", 10), u(13, "app-mobile-number", 11)(14, "app-error", 12), a(), r(15, "app-control-container", 13), u(16, "app-phone-number", 14)(17, "app-error", 12), a(), r(18, "app-control-container", 15), u(19, "dx-text-box", 16)(20, "app-error", 12), a(), r(21, "app-control-container", 17), u(22, "app-email", 18), a()(), r(23, "div", 19), u(24, "app-address", 20), a()()
    }
    if (t & 2) {
        let e = s();
        l("formGroup", e.form), n(3), _(e.isEditMode ? 3 : 4), n(2), _(e.errorResponse ? 5 : -1), n(2), h(e.formatMessage("outsource_vendor_information")), n(3), l("errorMsg", e.formatMessage("job_outsource_vendor_required_error"))("label", e.formatMessage("job_vendor_name_label")), n(), l("placeholder", e.formatMessage("job_vendor_name_placeholder"))("readOnly", !e.isEditMode), n(), l("errorMsg", e.formatMessage("mobile_number_required_error"))("label", e.formatMessage("common_mobile_number")), n(), l("entityId", e.form.value.id)("entity", e.ENTITIES.OUTSOURCE_VENDOR)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("form", e.form)("typeId", e.USER_TYPES.OUTSOURCE_VENDOR), n(), l("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), n(), l("errorMsg", e.formatMessage("common_phone_number_required"))("label", e.formatMessage("phone_number_label")), n(), l("isEditMode", e.isEditMode), n(), l("displayError", e.form.get("phone_number").invalid && e.form.get("phone_number").touched && e.form.get("phone_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), n(), l("errorMsg", e.formatMessage("common_tax_number_required"))("label", e.formatMessage("common_tax_number")), n(), l("placeholder", e.formatMessage("user_customer_tax_number_type"))("readOnly", !e.isEditMode), n(), l("displayError", e.form.get("tax_number").invalid && e.form.get("tax_number").touched && e.form.get("tax_number").errors.invalidGST)("errorMsg", e.formatMessage("common_invalid_tax_number")), n(), l("errorMsg", e.formatMessage("email_required_error"))("label", e.formatMessage("common_email_id")), n(), l("entityId", e.form.value.id)("entity", e.ENTITIES.OUTSOURCE_VENDOR)("formControl", e.form.controls.email)("isEditMode", e.isEditMode)("isUniqueValidation", !0)("typeId", e.USER_TYPES.OUTSOURCE_VENDOR), n(2), l("parentForm", e.form)
    }
}
var da = (() => {
    class t {
        constructor(e, o) {
            this.outsourceToService = e, this.loaderService = o, this.formatMessage = g, this.ENTITIES = I, this.routerHelperService = b(Hn), this.formService = b(me), this.router = b(G), this.activatedRouter = b(R), this.userSessionService = b(L), this.toastNotificationService = b(D), this.userPermissionList = this.userSessionService.userPermissionList(), this.USER_TYPES = wi, this.outsourceVendorId = null, this.errorResponse = null, this.isSaving = !1, this.isEditMode = !1, this.PERMISSION_LIST = M
        }
        ngOnInit() {
            this.outsourceVendorId = +this.activatedRouter.snapshot.parent.paramMap.get("vendor_id"), this.outsourceVendorId ? (this.loaderService.show(), this.outsourceToService.getById(this.outsourceVendorId).subscribe({
                next: e => {
                    this.outsourceVendor = new Ht(e), this.form = Ht.getForm(this.outsourceVendor), this.setFormReadOnly()
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => this.loaderService.hide())) : (this.outsourceVendor = new Ht({}), this.form = Ht.getForm(this.outsourceVendor), this.isEditMode = !0)
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable()
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.outsourceVendorId ? this.outsourceToService.update(this.form.value) : this.outsourceToService.create(this.form.value)).subscribe({
                next: o => {
                    this.activatedRouter.snapshot.parent.paramMap.has("vendor_id") ? (this.outsourceVendor = new Ht(o), this.toastNotificationService.success("notification_outsource_vendor_update_success"), this.setFormReadOnly()) : (this.outsourceVendorId = o.id, this.toastNotificationService.success("notification_outsource_vendor_add_success"), this.router.navigate([`jobs/outsourceTo/vendors/${o.id}/profiles`]), this.ngOnInit())
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => {
                this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form = Ht.getForm(this.outsourceVendor), this.isEditMode = !1, this.routerHelperService.goBack()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ri), T($))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-vendor-detail"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "gaEvent", "isVisibleHr", "saveText"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "row"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder", "readOnly"],
                    ["name", "mobile_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "mobile_number", 3, "entityId", "entity", "isEditMode", "isUniqueValidation", "form", "typeId"],
                    [3, "displayError", "errorMsg"],
                    ["name", "phone_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "phone_number", 3, "isEditMode"],
                    ["name", "tax_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "tax_number", "maxLength", "15", 3, "placeholder", "readOnly"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["id", "outsource-vendor-email", 3, "entityId", "entity", "formControl", "isEditMode", "isUniqueValidation", "typeId"],
                    [1, "mt-5"],
                    [3, "parentForm"],
                    [3, "cancelClick", "gaEvent", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, zf, 1, 2, "app-skeleton-loader", 0), m(1, eh, 25, 38, "form", 1)), o & 2 && (_(!i.form && i.outsourceVendorId ? 0 : -1), n(), _(i.form ? 1 : -1))
                },
                dependencies: [ut, ai, ee, K, zi, ue, ge, Nr, Ar, ro, dt, pe, q, re, st, le, se, Zt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function th(t, c) {
    if (t & 1 && (u(0, "app-copy-to-clipboard", 16), V(1, "mobileDisplay")), t & 2) {
        let e = s(2);
        l("textToBeCopied", B(1, 1, e.outsourceVendor.mobile_number, e.outsourceVendor == null ? null : e.outsourceVendor.mobile_country_code))
    }
}

function ih(t, c) {
    if (t & 1 && (r(0, "p", 12)(1, "strong")(2, "span", 13), u(3, "i", 18), a(), d(4), a(), d(5), a()), t & 2) {
        let e = s(2);
        n(4), S("", e.formatMessage("common_tax_number"), ": "), n(), h(e.outsourceVendor.tax_number)
    }
}

function nh(t, c) {
    if (t & 1 && u(0, "app-copy-to-clipboard", 16), t & 2) {
        let e = s(2);
        l("textToBeCopied", e.outsourceVendor.mobile_number)
    }
}

function oh(t, c) {
    if (t & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), u(4, "app-user-badge", 4), a(), r(5, "div", 5)(6, "div", 6)(7, "div", 7)(8, "h3", 8)(9, "label", 9), d(10), a()(), r(11, "div", 10)(12, "div", 11)(13, "p", 12)(14, "strong")(15, "span", 13), u(16, "i", 14), a(), d(17), a(), r(18, "a", 15), V(19, "mobileDisplay"), d(20), V(21, "mobileDisplay"), a(), m(22, th, 2, 4, "app-copy-to-clipboard", 16), a(), m(23, ih, 6, 2, "p", 12), r(24, "p", 12)(25, "strong")(26, "span", 13), u(27, "i", 17), a(), d(28), a(), r(29, "a", 15), d(30), a(), m(31, nh, 1, 1, "app-copy-to-clipboard", 16), a()()()()()()()()()), t & 2) {
        let e = s();
        n(4), l("iconOnly", !0)("size", e.iconSizes.LARGE)("user", e.outsourceVendor), n(6), h(e.outsourceVendor.name), n(7), S("", e.formatMessage("common_phone"), ": "), n(), l("href", Ve("tel:", Cn(19, 15, e.outsourceVendor.mobile_number, e.outsourceVendor == null ? null : e.outsourceVendor.mobile_country_code, "tel")), It), n(2), h(B(21, 19, e.outsourceVendor.mobile_number, e.outsourceVendor == null ? null : e.outsourceVendor.mobile_country_code)), n(2), _(e.outsourceVendor.mobile_number ? 22 : -1), n(), _(e.outsourceVendor.tax_number ? 23 : -1), n(5), S("", e.formatMessage("common_email"), " "), n(), l("href", Ve("mailto:", e.outsourceVendor.email), It), n(), h(e.outsourceVendor.email), n(), _(e.outsourceVendor.email ? 31 : -1)
    }
}
var El = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.iconSizes = Pi
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-vendor-profile-info"]
                ],
                inputs: {
                    outsourceVendor: "outsourceVendor"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [1, "card"],
                    [1, "card-body"],
                    [1, "row"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "justify-content-center", "align-items-center"],
                    [3, "iconOnly", "size", "user"],
                    [1, "col-sm-5", "col-md-5", "col-lg-5", "d-flex", "align-items-center"],
                    [1, "row", "mx-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "user-info-container"],
                    [1, "user-main-name"],
                    [1, "user-detail"],
                    [1, "d-flex", "flex-column", "user-basic-info"],
                    [1, "card-text"],
                    [1, "me-2"],
                    [1, "fa-thin", "fa-phone"],
                    [3, "href"],
                    [1, "mx-4", 3, "textToBeCopied"],
                    [1, "fa-thin", "fa-envelope"],
                    [1, "fa-thin", "fa-id-card"]
                ],
                template: function(o, i) {
                    o & 1 && m(0, oh, 32, 22, "div", 0), o & 2 && _(i.outsourceVendor ? 0 : -1)
                },
                dependencies: [_t, zn, mt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function rh(t, c) {
    if (t & 1 && u(0, "app-outsource-vendor-profile-info", 0), t & 2) {
        let e = s();
        l("outsourceVendor", e.outsourceVendor)
    }
}
var wl = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = g, this.router = b(G), this.activatedRouter = b(R), this.tabs = [], this.selectedTabIndex = 0
        }
        ngOnInit() {
            this.outsourceVendorId = +this.activatedRouter.snapshot.paramMap.get("vendor_id"), this.outsourceVendorId && (this.tabs = [{
                id: 0,
                text: "Profile",
                path: `/jobs/outsourceTo/vendors/${this.outsourceVendorId}/profiles`,
                icon: "fa-thin fa-id-card"
            }, {
                id: 1,
                text: "Jobs",
                path: `/jobs/outsourceTo/vendors/${this.outsourceVendorId}/jobs`,
                icon: "fa-thin fa-people-carry-box"
            }], this.initialize())
        }
        initialize() {
            this.service.getById(this.outsourceVendorId).subscribe({
                next: e => {
                    this.outsourceVendor = e, this.outsourceVendorId = e.id
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ri))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-vendor-profile"]
                ],
                standalone: !1,
                decls: 3,
                vars: 4,
                consts: [
                    [3, "outsourceVendor"],
                    [1, "mt-1", "mb-1"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-handshake", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, rh, 1, 1, "app-outsource-vendor-profile-info", 0), r(1, "div", 1)(2, "app-responsive-tabs", 2), f("tabChange", function(y) {
                        return i.selectTab(y)
                    }), a()()), o & 2 && (_(i.outsourceVendorId ? 0 : -1), n(2), l("tabs", i.tabs)("selectedIndex", i.selectedTabIndex)("mobileMenuTitle", i.outsourceVendor == null ? null : i.outsourceVendor.name))
                },
                dependencies: [Xi, El],
                encapsulation: 2
            })
        }
    }
    return t
})();
var sh = t => ({
        vendor_id: t
    }),
    lh = (t, c, e) => [t, c, e],
    ch = (t, c, e) => ({
        icon: "dx-icon-export",
        title: t,
        description: c,
        quickTips: e,
        secondaryButtonText: "empty_state_outsource_add_vendor_button",
        quickTipsVisible: !0,
        primaryButtonVisible: !1
    });

function dh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-outsource-to-popup", 3), f("outSourceToClose", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("outSourceToSave", function() {
            C(e);
            let i = s();
            return v(i.onOutsourcePopupSave())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("entityType", e.entityType)("entity", e.currentOutsourceJob)("isFromOutsourceListing", !0)("isVisiblePopup", e.currentContextMenuAction === e.OUTSOURCE_CONTEXT_MENU_LIST.EDIT_OUTSOURCE)
    }
}

function ph(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-outsource-pickup-drop-popup", 4), f("outsourcePickupDropCancelClick", function() {
            C(e);
            let i = s();
            return v(i.onCloseContextMenuOption())
        })("outsourcePickupDropSaveClick", function() {
            C(e);
            let i = s();
            return v(i.onOutsourcePopupSave())
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isOutsourceContext", !0)("isVisiblePopup", e.currentContextMenuAction === e.OUTSOURCE_CONTEXT_MENU_LIST.SCHEDULE_PICKUP_DROP)("job", e.currentOutsourceJob == null ? null : e.currentOutsourceJob.job)("outsource", e.currentOutsourceJob)
    }
}
var pa = (() => {
    class t {
        get hasTenantOutsourcedJobs() {
            return (this.tenantService.config() ? .entity_counts ? .outsourced_jobs || 0) > 0
        }
        constructor(e, o, i) {
            this.outsourceToService = e, this.geoLocationService = o, this.notifyService = i, this.formatMessage = g, this.router = b(G), this.userSessionService = b(L), this.tenantService = b(ve), this.activatedRouter = b(R), this.isMobileDevice = b(A).isMobileDevice(), this.isCapacitorNative = b(A).isCapacitorNative(), this.plan = this.tenantService.plan(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.entity = I.OUTSOURCED_JOB, this.entityType = I.OUTSOURCED_JOB.name, this.outsourceContextMenu = [], this.currentContextMenuAction = null, this.createPickupDrop = !0, this.vendorId = null, this.OUTSOURCE_CONTEXT_MENU_LIST = Ci
        }
        ngOnInit() {
            this.vendorId = +this.activatedRouter.snapshot.parent.paramMap.get("vendor_id"), this.outsourceContextMenu = [{
                name: Ci.VIEW_OUTSOURCE,
                icon: "fa-thin fa-file-pdf",
                visible: this.isEmployee && this.userPermissionList.includes(M.OUTSOURCED_JOB_LIST),
                locale_key: g("outsource_action_view_outsource")
            }, {
                name: Ci.EDIT_OUTSOURCE,
                icon: "fa-thin fa-pencil",
                visible: this.isEmployee && this.userPermissionList.includes(M.OUTSOURCED_JOB_WRITE) && [Le.STANDARD, Le.ENTERPRISE].includes(this.plan),
                locale_key: g("outsource_action_edit_outsource")
            }, {
                name: Ci.SCHEDULE_PICKUP_DROP,
                icon: "fa-thin fa-person-carry-box",
                visible: !0,
                locale_key: g("outsource_action_schedule_pickup_drop")
            }, {
                name: Ho.TRACK,
                icon: "fal fa-location",
                visible: this.userPermissionList.includes(M.PICKUP_DROP_LIST) && this.isEmployee && this.isCapacitorNative,
                locale_key: g("track_location")
            }], this.columns = [{
                dataField: "job_id",
                caption: g("job_sheet_label"),
                width: this.isMobileDevice ? 90 : 130,
                alignment: "left",
                cellTemplate: "jobIdLinkTemplate",
                allowSorting: !1
            }, {
                dataField: "vendor",
                caption: g("job_outsource_vendor"),
                width: this.isMobileDevice ? 110 : 130,
                cellTemplate: "userTemplate",
                allowSorting: !1
            }, {
                dataField: "job.user",
                caption: g("user_customer"),
                cellTemplate: "userTemplate",
                allowSorting: !1,
                hidingPriority: 7
            }, {
                dataField: "price",
                caption: g("common_price"),
                hidingPriority: 4,
                allowSorting: !1,
                alignment: "center",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "description",
                caption: g("job_outsource_comment"),
                hidingPriority: 3,
                cellTemplate: "commentTemplate",
                allowSorting: !1
            }, {
                dataField: "status",
                caption: g("job_status"),
                hidingPriority: 2,
                cellTemplate: "outsourceToStatusTemplate",
                allowSorting: !1,
                alignment: "center"
            }, {
                dataField: "is_drop_present",
                caption: g("job_outsource_drop_scheduled"),
                hidingPriority: 6,
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "is_pickup_present",
                caption: g("job_outsource_pickup_scheduled"),
                hidingPriority: 5,
                cellTemplate: "booleanTemplate",
                dataType: "boolean",
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "updated_at",
                caption: g("common_updated_on"),
                alignment: "center",
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: g("common_created_on"),
                alignment: "center",
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                width: 60
            }]
        }
        onOutsourcePopupSave() {
            this.outsourceTo = null, this.dataGrid.getData()
        }
        onContextMenuItemClick(e) {
            if (this.currentContextMenuAction = e.action, this.currentOutsourceJob = e.entity, this.currentContextMenuAction === Ci.VIEW_OUTSOURCE && this.router.navigate(["/jobs/outsourceTo/outsourceDeliveryChallan/" + e.entity.id]), this.currentContextMenuAction === Ci.SCHEDULE_PICKUP_DROP && this.currentOutsourceJob ? .pickup_drop ? .id && (this.createPickupDrop = !1), this.currentContextMenuAction === Ho.TRACK) {
                console.log(this.currentOutsourceJob.job.user);
                let o = this.currentOutsourceJob.vendor.address;
                o === null ? (console.log("no address"), this.notifyService.error(g("error_no_address_found"))) : this.geoLocationService.getAddressCoordinates(`${o.address_line} ${o.city} ${o.city}`).then(i => {
                    this.coordinates = {
                        lat: i.lat,
                        lng: i.lng
                    }, this.openMap()
                }).catch(i => {
                    i === "ZERO_RESULTS" && this.notifyService.error(g("error_no_address_found"))
                })
            }
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentOutsourceJob = null
        }
        openMap() {
            this.router.navigate(["pickupDrop/map"], {
                queryParams: {
                    lat: this.coordinates.lat,
                    lng: this.coordinates.lng,
                    customer_id: this.currentOutsourceJob.vendor_id
                }
            })
        }
        navigateToVendors() {
            this.router.navigate(["/jobs/outsourceTo/vendors/list"])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(T(ln), T(Cr), T(Ja))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-to-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && ne(ce, 5), o & 2) {
                        let p;
                        oe(p = ae()) && (i.dataGrid = p.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 24,
                consts: [
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridSecondaryButtonClick", "additionalParams", "columns", "contextMenuItems", "dataGridId", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "searchPanelPlaceholderText", "isVisibleExportAction", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "entityType", "entity", "isFromOutsourceListing", "isVisiblePopup"],
                    [3, "isOutsourceContext", "isVisiblePopup", "job", "outsource"],
                    [3, "outSourceToClose", "outSourceToSave", "entityType", "entity", "isFromOutsourceListing", "isVisiblePopup"],
                    [3, "outsourcePickupDropCancelClick", "outsourcePickupDropSaveClick", "isOutsourceContext", "isVisiblePopup", "job", "outsource"]
                ],
                template: function(o, i) {
                    o & 1 && (r(0, "app-data-grid", 0), f("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(y) {
                        return i.onContextMenuItemClick(y)
                    })("dataGridSecondaryButtonClick", function() {
                        return i.navigateToVendors()
                    }), a(), m(1, dh, 1, 4, "app-outsource-to-popup", 1), m(2, ph, 1, 4, "app-outsource-pickup-drop-popup", 2)), o & 2 && (l("additionalParams", fe(14, sh, i.vendorId))("columns", i.columns)("contextMenuItems", i.outsourceContextMenu)("dataGridId", "tabAndGridContainer")("entity", i.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("searchPanelPlaceholderText", "search_panel_outsource_to_list_placeholder")("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("service", i.outsourceToService)("hasTenantData", i.hasTenantOutsourcedJobs)("emptyStateConfig", ot(20, ch, i.formatMessage("empty_state_outsource_title"), i.formatMessage("empty_state_outsource_description"), ot(16, lh, i.formatMessage("empty_state_outsource_tip_1"), i.formatMessage("empty_state_outsource_tip_2"), i.formatMessage("empty_state_outsource_tip_3")))), n(), _(i.currentContextMenuAction === i.OUTSOURCE_CONTEXT_MENU_LIST.EDIT_OUTSOURCE ? 1 : -1), n(), _(i.currentContextMenuAction === i.OUTSOURCE_CONTEXT_MENU_LIST.SCHEDULE_PICKUP_DROP ? 2 : -1))
                },
                dependencies: [ce, uo, Eo],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ol = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-outsource-to"]
                ],
                standalone: !1,
                decls: 1,
                vars: 0,
                template: function(o, i) {
                    o & 1 && u(0, "router-outlet")
                },
                dependencies: [Na],
                encapsulation: 2
            })
        }
    }
    return t
})();
var jl = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.entity = I.JOB_COMMENT, this.service = b(Hi), this.columns = [{
                dataField: "job_id",
                caption: g("job_sheet_label"),
                cellTemplate: "idTemplate",
                allowSorting: !0,
                visibleIndex: 0
            }, {
                dataField: "user",
                caption: g("user_customer"),
                cellTemplate: "userTemplate",
                allowSorting: !1,
                visibleIndex: 1
            }, {
                dataField: "comment",
                caption: g("common_comment"),
                cellTemplate: "commentTemplate",
                allowSorting: !1,
                visibleIndex: 2
            }, {
                dataField: "created_at",
                caption: g("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                allowSorting: !1,
                visibleIndex: 3
            }]
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-job-comment-list"]
                ],
                standalone: !1,
                decls: 1,
                vars: 7,
                consts: [
                    [3, "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "searchPanelPlaceholderText", "isVisibleReportDropdown", "service"]
                ],
                template: function(o, i) {
                    o & 1 && u(0, "app-data-grid", 0), o & 2 && l("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("searchPanelPlaceholderText", "search_panel_tasks_placeholder")("isVisibleReportDropdown", !0)("service", i.service)
                },
                dependencies: [ce],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Vl = 19876,
    Dl = (() => {
        class t {
            constructor() {
                this.apiService = b(Ie), this.userDeviceService = b(A)
            }
            getListByQuery(e) {
                return this.apiService.getListByQuery(`jobs/${e.job_id}/directory-scans`, e)
            }
            initiateDirectoryScan(e) {
                return this.apiService.post(`jobs/${e}/directory-scans/initiate`, {})
            }
            getJobScans(e) {
                return this.apiService.get(`jobs/${e}/directory-scans`)
            }
            getScanDetails(e) {
                return this.apiService.get(`directory-scans/${e}`)
            }
            delete(e) {
                return this.apiService.delete(`directory-scans/${e}`)
            }
            openAgentDeepLink(e) {
                let o = this.detectPlatform();
                console.log("[DirectoryScanService] Opening deep link on platform:", o);
                let i = !1;
                try {
                    let y = document.createElement("a");
                    y.href = e, y.style.display = "none", document.body.appendChild(y), y.click(), setTimeout(() => {
                        y.parentNode && document.body.removeChild(y)
                    }, 100), i = !0, console.log("[DirectoryScanService] Opened via anchor click")
                } catch (y) {
                    console.warn("[DirectoryScanService] Anchor click failed:", y)
                }
                if (!i) try {
                    window.location.href = e, i = !0, console.log("[DirectoryScanService] Opened via window.location")
                } catch (y) {
                    console.warn("[DirectoryScanService] window.location failed:", y)
                }
                if (!i) try {
                    i = window.open(e, "_self") !== null, console.log("[DirectoryScanService] Opened via window.open")
                } catch (y) {
                    console.warn("[DirectoryScanService] window.open failed:", y)
                }
                return {
                    opened: i,
                    platform: o,
                    requiresManualAction: o === "linux"
                }
            }
            detectPlatform() {
                let e = navigator.userAgent.toLowerCase(),
                    o = navigator.platform ? .toLowerCase() || "";
                return e.includes("win") || o.includes("win") ? "windows" : e.includes("mac") || o.includes("mac") ? "macos" : e.includes("linux") || o.includes("linux") ? "linux" : "unknown"
            }
            getAgentSetupInstructions(e) {
                switch (e) {
                    case "linux":
                        return `On Linux, you may need to manually register the BytePhase Agent protocol:
1. Ensure BytePhase Agent is installed
2. Run: xdg-mime default bytephase-agent.desktop x-scheme-handler/bytephase
3. Or create ~/.local/share/applications/bytephase-agent.desktop with MimeType=x-scheme-handler/bytephase`;
                    case "windows":
                        return `On Windows:
1. Ensure BytePhase Agent is installed (not just running as portable)
2. Run the installer again if the agent doesn't open
3. Check if antivirus is blocking the application`;
                    default:
                        return "Please ensure BytePhase Agent is installed and running."
                }
            }
            getDownloadHtmlUrl(e) {
                return `${Bo}directory-scans/${e}/download-html`
            }
            getViewHtmlUrl(e) {
                return `${Bo}directory-scans/${e}/view-html`
            }
            getViewHtmlContent(e) {
                return this.apiService.getText(`directory-scans/${e}/view-html`)
            }
            getScanProgress(e) {
                return this.apiService.get(`directory-scans/job/${e}/progress`)
            }
            cancelScan(e) {
                return this.apiService.post(`directory-scans/${e}/cancel`, {})
            }
            pauseScan(e) {
                return this.apiService.post(`directory-scans/${e}/pause`, {})
            }
            resumeScan(e) {
                return this.apiService.post(`directory-scans/${e}/resume`, {})
            }
            generateVerificationLink(e) {
                return this.apiService.post(`directory-scans/${e}/generate-verification-link`, {})
            }
            sendVerificationNotification(e) {
                return this.apiService.post(`directory-scans/${e.scan_id}/send-notification`, e)
            }
            getValidationTimeline(e) {
                return this.apiService.get(`directory-scans/${e}/timeline`)
            }
            downloadValidationPdf(e) {
                return this.apiService.exportUsingGet(`directory-scans/${e}/validation-pdf`)
            }
            resendConfirmationEmail(e) {
                return this.apiService.post(`directory-scans/${e}/resend-confirmation`, {})
            }
            isAgentRunning() {
                if (this.userDeviceService.isCapacitorNative()) return zt(!1);
                let e = `http://127.0.0.1:${Vl}/health`;
                return No(fetch(e, {
                    method: "GET",
                    mode: "cors",
                    cache: "no-cache"
                }).then(o => o.ok).catch(() => !1)).pipe(Ao(3e3), Jo(() => zt(!1)))
            }
            getAgentStatus() {
                if (this.userDeviceService.isCapacitorNative()) return zt(null);
                let e = `http://127.0.0.1:${Vl}/health`;
                return No(fetch(e, {
                    method: "GET",
                    mode: "cors",
                    cache: "no-cache"
                }).then(o => o.ok ? o.json() : null).catch(() => null)).pipe(Ao(3e3), Jo(() => zt(null)))
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275prov = Pe({
                    token: t,
                    factory: t.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return t
    })();

function mh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 23)(1, "div", 24)(2, "div", 25)(3, "div")(4, "h4", 26), d(5), a(), r(6, "small", 14), d(7), V(8, "dateFormat"), a()(), r(9, "span", 27), u(10, "i", 28), d(11), a()(), r(12, "div", 29)(13, "div", 30)(14, "div", 31), u(15, "i", 32), r(16, "div")(17, "small", 14), d(18), a(), r(19, "span", 33), d(20), a()()()(), r(21, "div", 30)(22, "div", 31), u(23, "i", 34), r(24, "div")(25, "small", 14), d(26), a(), r(27, "span", 33), d(28), a()()()(), r(29, "div", 30)(30, "div", 31), u(31, "i", 35), r(32, "div")(33, "small", 14), d(34), a(), r(35, "span", 33), d(36), a()()()(), r(37, "div", 30)(38, "div", 31), u(39, "i", 36), r(40, "div")(41, "small", 14), d(42), a(), r(43, "span", 33), d(44), a()()()()()()(), r(45, "div", 37)(46, "div", 24)(47, "h5", 38), d(48), a(), r(49, "dx-button", 39), f("onClick", function() {
            C(e);
            let i = s(2);
            return v(i.onStartValidation())
        }), a()()()
    }
    if (t & 2) {
        let e = s(2);
        n(5), h(e.job.job_number), n(2), h(ie(8, 14, e.job.created_at)), n(4), S(" ", e.formatMessage("pending_validation"), " "), n(7), S("", e.formatMessage("customer"), ":"), n(2), h((e.job.user == null ? null : e.job.user.name) || "-"), n(6), S("", e.formatMessage("device"), ":"), n(2), h(e.getDeviceInfo()), n(6), S("", e.formatMessage("technician"), ":"), n(2), h((e.job.assigned_user == null ? null : e.job.assigned_user.name) || "-"), n(6), S("", e.formatMessage("issue"), ":"), n(2), h(e.getIssueDescription()), n(4), h(e.formatMessage("data_validation")), n(), l("text", e.formatMessage("start_data_validation"))("disabled", e.isLoading)
    }
}

function _h(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 2)(1, "div", 40)(2, "h2", 41), d(3), a(), r(4, "span", 42), u(5, "i", 43), d(6), a()(), r(7, "div", 44), u(8, "i", 45), r(9, "div", 46)(10, "p", 47), d(11), a(), r(12, "p", 48), d(13), a()()(), r(14, "div", 49)(15, "h4", 50), u(16, "i", 51), d(17), V(18, "titlecase"), a(), r(19, "pre", 52), d(20), a()(), r(21, "div", 53)(22, "dx-button", 54), f("onClick", function() {
            C(e);
            let i = s(2);
            return v(i.onShowDownloadPopup())
        }), a(), r(23, "dx-button", 55), f("onClick", function() {
            C(e);
            let i = s(2);
            return v(i.onCopyDeepLink())
        }), a(), r(24, "dx-button", 56), f("onClick", function() {
            C(e);
            let i = s(2);
            return v(i.onStartValidation())
        }), a(), r(25, "dx-button", 57), f("onClick", function() {
            C(e);
            let i = s(2);
            return v(i.onDismissAgentWarning())
        }), a()()()
    }
    if (t & 2) {
        let e = s(2);
        n(3), h(e.formatMessage("agent_not_responding_title")), n(3), S(" ", e.formatMessage("waiting_for_agent"), " "), n(5), h(e.formatMessage("bytephase_agent_not_detected")), n(2), h(e.formatMessage("agent_not_detected_message")), n(4), ze(" ", e.formatMessage("troubleshooting_steps"), " (", ie(18, 11, e.agentPlatform), ") "), n(3), h(e.agentTroubleshootingInfo), n(2), l("text", e.formatMessage("download_agent")), n(), l("text", e.formatMessage("copy_deep_link")), n(), l("text", e.formatMessage("retry")), n(), l("text", e.formatMessage("dismiss"))
    }
}

function uh(t, c) {
    if (t & 1 && (r(0, "span", 15), d(1), a()), t & 2) {
        let e = s(2);
        n(), h(e.formatMessage("recommended"))
    }
}

function Ch(t, c) {
    if (t & 1 && (r(0, "span", 15), d(1), a()), t & 2) {
        let e = s(2);
        n(), h(e.formatMessage("recommended"))
    }
}

function vh(t, c) {
    if (t & 1 && (r(0, "span", 15), d(1), a()), t & 2) {
        let e = s(2);
        n(), h(e.formatMessage("recommended"))
    }
}

function fh(t, c) {
    t & 1 && u(0, "i", 59)
}

function hh(t, c) {
    t & 1 && u(0, "i", 60)
}

function bh(t, c) {
    if (t & 1 && (r(0, "div", 66), u(1, "i", 72), r(2, "div")(3, "span", 70), d(4), a(), r(5, "span", 73), d(6), a()()()), t & 2) {
        let e = s(3);
        n(4), h(e.formatMessage("currently_scanning")), n(2), h(e.currentScan.current_folder)
    }
}

function gh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 77), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.onPauseScan())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("text", e.formatMessage("pause_scan"))
    }
}

function xh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 78), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.onResumeScan())
        }), a()
    }
    if (t & 2) {
        let e = s(4);
        l("text", e.formatMessage("resume_scan"))
    }
}

function Sh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 53), m(1, gh, 1, 1, "dx-button", 74), m(2, xh, 1, 1, "dx-button", 75), r(3, "dx-button", 76), f("onClick", function() {
            C(e);
            let i = s(3);
            return v(i.onCancelScan())
        }), a()()
    }
    if (t & 2) {
        let e = s(3);
        n(), _(e.currentScan.status === "scanning" ? 1 : -1), n(), _(e.currentScan.status === "paused" ? 2 : -1), n(), l("text", e.formatMessage("cancel_scan"))
    }
}

function yh(t, c) {
    if (t & 1 && (r(0, "div", 21)(1, "div", 40)(2, "h2", 41), d(3), a(), r(4, "span", 58), m(5, fh, 1, 0, "i", 59), m(6, hh, 1, 0, "i", 60), d(7), a()(), r(8, "div", 61)(9, "div", 62)(10, "span", 63), d(11), a(), r(12, "span", 64), d(13), a()(), u(14, "dx-progress-bar", 65), a(), m(15, bh, 7, 2, "div", 66), u(16, "hr", 67), r(17, "div", 68)(18, "div", 69)(19, "span", 70), d(20), a(), r(21, "span", 71), d(22), a()(), r(23, "div", 69)(24, "span", 70), d(25), a(), r(26, "span", 71), d(27), V(28, "number"), a()(), r(29, "div", 69)(30, "span", 70), d(31), a(), r(32, "span", 71), d(33), a()()(), m(34, Sh, 4, 3, "div", 53), a()), t & 2) {
        let e = s(2);
        n(3), h(e.formatMessage("data_validation_in_progress")), n(), l("ngClass", e.getStatusBadgeClass()), n(), _(e.currentScan.status === "scanning" || e.currentScan.status === "uploading" || e.currentScan.status === "processing" ? 5 : -1), n(), _(e.currentScan.status === "paused" ? 6 : -1), n(), S(" ", e.getStatusText(), " "), n(4), h(e.formatMessage("scanning_progress")), n(2), S("", e.currentScan.progress_percentage, "%"), n(), l("min", 0)("max", 100)("value", e.currentScan.progress_percentage)("showStatus", !1), n(), _(e.currentScan.current_folder ? 15 : -1), n(5), h(e.formatMessage("estimated_time")), n(2), h(e.formatEstimatedTime()), n(3), h(e.formatMessage("files_scanned")), n(2), h(ie(28, 19, e.currentScan.files_scanned)), n(4), h(e.formatMessage("initiated_by")), n(2), h(e.currentScan.initiated_by || "-"), n(), _(e.currentScan.status === "scanning" || e.currentScan.status === "paused" ? 34 : -1)
    }
}

function Th(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 87), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.onBackToTimeline())
        }), a()
    }
    if (t & 2) {
        let e = s(5);
        l("text", e.formatMessage("back_to_timeline"))
    }
}

function Mh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "dx-button", 88), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.onRerunScan())
        }), a(), r(1, "dx-button", 89), f("onClick", function() {
            C(e);
            let i = s(5);
            return v(i.onProceedToVerification())
        }), r(2, "span"), d(3), a(), u(4, "i", 90), a()
    }
    if (t & 2) {
        let e = s(5);
        l("text", e.formatMessage("re_run_scan")), n(3), h(e.formatMessage("proceed_to_customer_verification"))
    }
}

function Ph(t, c) {
    if (t & 1 && (r(0, "div", 81)(1, "p", 84), d(2), a(), r(3, "div", 85), m(4, Th, 1, 1, "dx-button", 86), m(5, Mh, 5, 2), a()()), t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("read_only_preview_note")), n(2), _(e.currentScan != null && e.currentScan.is_verified ? 4 : -1), n(), _(e.currentScan != null && e.currentScan.is_verified ? -1 : 5)
    }
}

function Ih(t, c) {
    if (t & 1 && u(0, "iframe", 91), t & 2) {
        let e = s(4);
        mi("height", e.iframeHeight, "px"), l("src", e.scanHtmlUrl, ba)
    }
}

function Eh(t, c) {
    if (t & 1 && (r(0, "div", 83), u(1, "i", 92), r(2, "span", 14), d(3), a()()), t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("loading_scan_results"))
    }
}

function wh(t, c) {
    if (t & 1 && (m(0, Ph, 6, 3, "div", 81), m(1, Ih, 1, 3, "iframe", 82), m(2, Eh, 4, 1, "div", 83)), t & 2) {
        let e = s(3);
        _(e.scanHtmlUrl && !e.isLoadingDetails ? 0 : -1), n(), _(e.scanHtmlUrl ? 1 : -1), n(), _(e.isLoadingDetails ? 2 : -1)
    }
}

function Oh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "button", 97), f("click", function() {
            C(e);
            let i = s(4);
            return v(i.onSelectChannel("sms"))
        }), u(1, "i", 110), d(2), a()
    }
    if (t & 2) {
        let e = s(4);
        Ae("active", e.selectedChannel === "sms"), n(2), S(" ", e.formatMessage("sms"), " ")
    }
}

function jh(t, c) {
    if (t & 1 && (r(0, "div", 105), u(1, "i", 111), r(2, "div", 112)(3, "span", 113), d(4), a(), r(5, "span", 114), d(6), V(7, "dateFormat"), a()()()), t & 2) {
        let e = s(4);
        n(4), h(e.formatMessage("link_valid_for_72_hours")), n(2), ze("", e.formatMessage("verification_link_expires_on"), " ", B(7, 3, e.linkExpiryDate, "full"))
    }
}

function Vh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 79)(1, "h2", 93), d(2), a(), r(3, "div", 94)(4, "label", 95), d(5), a(), r(6, "div", 96)(7, "button", 97), f("click", function() {
            C(e);
            let i = s(3);
            return v(i.onSelectChannel("email"))
        }), u(8, "i", 98), d(9), a(), m(10, Oh, 3, 3, "button", 99), r(11, "button", 97), f("click", function() {
            C(e);
            let i = s(3);
            return v(i.onSelectChannel("whatsapp"))
        }), u(12, "i", 100), d(13), a()()(), r(14, "div", 94)(15, "label", 95), d(16), a(), r(17, "dx-text-area", 101), j("valueChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.notificationMessage, i) || (p.notificationMessage = i), v(i)
        }), a()(), r(18, "div", 94)(19, "label", 95), d(20), a(), r(21, "div", 102)(22, "dx-text-box", 103), j("valueChange", function(i) {
            C(e);
            let p = s(3);
            return O(p.verificationLink, i) || (p.verificationLink = i), v(i)
        }), a(), r(23, "dx-button", 104), f("onClick", function() {
            C(e);
            let i = s(3);
            return v(i.onCopyLink())
        }), a()()(), m(24, jh, 8, 6, "div", 105), r(25, "div", 94)(26, "label", 95), d(27), a(), r(28, "div", 106)(29, "pre", 107), d(30), a()()(), r(31, "div", 108)(32, "dx-button", 57), f("onClick", function() {
            C(e);
            let i = s(3);
            return v(i.onBackToSummary())
        }), a(), r(33, "dx-button", 109), f("onClick", function() {
            C(e);
            let i = s(3);
            return v(i.onSendNotification())
        }), a()()()
    }
    if (t & 2) {
        let e = s(3);
        n(2), h(e.formatMessage("customer_notification_setup")), n(3), h(e.formatMessage("notification_channel")), n(2), Ae("active", e.selectedChannel === "email"), n(2), S(" ", e.formatMessage("email"), " "), n(), _(e.isIndia ? -1 : 10), n(), Ae("active", e.selectedChannel === "whatsapp"), n(2), S(" ", e.formatMessage("whatsapp"), " "), n(3), h(e.formatMessage("message")), n(), w("value", e.notificationMessage), l("height", 140)("placeholder", e.formatMessage("enter_notification_message")), n(3), h(e.formatMessage("customer_verification_link")), n(2), w("value", e.verificationLink), l("readOnly", !0), n(), l("text", e.formatMessage("copy")), n(), _(e.linkExpiryDate ? 24 : -1), n(3), Sa("", e.formatMessage("terms_and_conditions"), " (", e.formatMessage("version"), " ", e.termsVersion, ")"), n(3), h(e.termsContent), n(2), l("text", e.formatMessage("back_to_summary")), n(), l("text", e.formatMessage("send_notification"))("disabled", e.isSendingNotification || !e.verificationLink)
    }
}

function Dh(t, c) {
    if (t & 1 && (r(0, "div", 115), u(1, "i", 59), r(2, "span"), d(3), a()()), t & 2) {
        let e = s(4);
        n(3), h(e.formatMessage("loading_timeline"))
    }
}

function kh(t, c) {
    t & 1 && u(0, "i", 116)
}

function Nh(t, c) {
    t & 1 && u(0, "i", 28)
}

function Ah(t, c) {
    t & 1 && u(0, "i", 116)
}

function Jh(t, c) {
    t & 1 && u(0, "i", 116)
}

function Lh(t, c) {
    if (t & 1 && (r(0, "div", 121)(1, "div", 127), u(2, "i"), a(), r(3, "div", 128)(4, "div", 129)(5, "span", 130), d(6), a(), r(7, "span", 131), d(8), V(9, "dateFormat"), a()(), r(10, "p", 132), d(11), a()()()), t & 2) {
        let e = c.$implicit,
            o = s(5);
        n(2), Si(o.getEventIcon(e.type)), n(4), h(e.title), n(2), h(B(9, 5, e.timestamp, "full")), n(3), h(e.description)
    }
}

function Bh(t, c) {
    if (t & 1 && (r(0, "div", 122)(1, "div", 133), u(2, "i", 134), a(), r(3, "div", 135)(4, "span", 136), d(5), a(), r(6, "p", 137), d(7), a(), r(8, "span", 138), d(9), a()()()), t & 2) {
        let e = s(5);
        n(5), h(e.formatMessage("digital_signature_captured")), n(2), h(e.formatMessage("signature_captured_description")), n(2), ze("", e.formatMessage("reference_id"), ": ", e.timeline.signature_reference_id)
    }
}

function Rh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 40)(1, "h2", 41), d(2), a(), r(3, "span", 58), m(4, kh, 1, 0, "i", 116), m(5, Nh, 1, 0, "i", 28), d(6), a()(), r(7, "div", 117)(8, "div", 118)(9, "div", 119)(10, "span", 70), d(11), a(), r(12, "span", 71), d(13), a()(), r(14, "div", 119)(15, "span", 70), d(16), a(), r(17, "span", 71), d(18), a()()(), r(19, "div", 118)(20, "div", 119)(21, "span", 70), d(22), a(), r(23, "span", 71), m(24, Ah, 1, 0, "i", 116), d(25), a()(), r(26, "div", 119)(27, "span", 70), d(28), a(), r(29, "span", 71), m(30, Jh, 1, 0, "i", 116), d(31), a()()()(), r(32, "div", 120), X(33, Lh, 12, 8, "div", 121, He), a(), m(35, Bh, 10, 4, "div", 122), r(36, "div", 108)(37, "dx-button", 16), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.onDownloadValidationPdf())
        }), a(), r(38, "dx-button", 123), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.onPrintValidationPdf())
        }), a(), r(39, "dx-button", 124), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.onResendConfirmationEmail())
        }), a(), r(40, "dx-button", 125), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.isVisibleSendNotificationPopup = !0)
        }), a(), r(41, "dx-button", 126), f("onClick", function() {
            C(e);
            let i = s(4);
            return v(i.onViewScanData())
        }), a()()
    }
    if (t & 2) {
        let e = s(4);
        n(2), h(e.formatMessage("validation_timeline")), n(), l("ngClass", e.getTimelineStatusBadgeClass()), n(), _(e.timeline.verification_status === "verified" ? 4 : -1), n(), _(e.timeline.verification_status === "pending" ? 5 : -1), n(), S(" ", e.getTimelineStatusText(), " "), n(5), h(e.formatMessage("customer")), n(2), h(e.timeline.customer_name), n(3), h(e.formatMessage("job_reference")), n(2), h(e.timeline.job_number), n(4), h(e.formatMessage("verification_status")), n(), Ae("success-text", e.timeline.verification_status === "verified"), n(), _(e.timeline.verification_status === "verified" ? 24 : -1), n(), S(" ", e.timeline.verification_status === "verified" ? e.formatMessage("verified_and_signed") : e.formatMessage("awaiting_verification"), " "), n(3), h(e.formatMessage("otp_confirmation")), n(), Ae("success-text", e.timeline.otp_confirmed), n(), _(e.timeline.otp_confirmed ? 30 : -1), n(), S(" ", e.timeline.otp_confirmed ? e.formatMessage("confirmed") : e.formatMessage("pending"), " "), n(2), Z(e.timeline.events), n(2), _(e.timeline.verification_status === "verified" && e.timeline.signature_reference_id ? 35 : -1), n(2), l("text", e.formatMessage("download_validation_pdf")), n(), l("text", e.formatMessage("print_validation_pdf")), n(), l("text", e.formatMessage("resend_confirmation_email"))("disabled", e.isResendingEmail), n(), l("text", e.formatMessage("send_notification")), n(), l("text", e.formatMessage("view_scan_data"))
    }
}

function Uh(t, c) {
    if (t & 1 && (r(0, "div", 80), m(1, Dh, 4, 1, "div", 115), m(2, Rh, 42, 26), a()), t & 2) {
        let e = s(3);
        n(), _(e.isLoadingTimeline ? 1 : -1), n(), _(!e.isLoadingTimeline && e.timeline ? 2 : -1)
    }
}

function Fh(t, c) {
    if (t & 1 && (m(0, wh, 3, 3), m(1, Vh, 34, 25, "div", 79), m(2, Uh, 3, 2, "div", 80)), t & 2) {
        let e = s(2);
        _(e.currentView === "scan" ? 0 : -1), n(), _(e.currentView === "notification" ? 1 : -1), n(), _(e.currentView === "timeline" ? 2 : -1)
    }
}

function qh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 22)(1, "div", 40)(2, "h2", 41), d(3), a(), r(4, "span", 139), u(5, "i", 140), d(6), a()(), r(7, "div", 141), u(8, "i", 142), r(9, "div", 143)(10, "p", 144), d(11), a(), r(12, "p", 145), d(13), a()()(), r(14, "dx-button", 146), f("onClick", function() {
            C(e);
            let i = s(2);
            return v(i.onStartValidation())
        }), a()()
    }
    if (t & 2) {
        let e = s(2);
        n(3), h(e.formatMessage("data_validation")), n(3), S(" ", e.getStatusText(), " "), n(5), h(e.formatMessage("scan_failed_title")), n(2), h(e.currentScan.error_message || e.formatMessage("scan_failed_message")), n(), l("text", e.formatMessage("retry_scan"))
    }
}

function Gh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "div", 0), m(1, mh, 50, 16), m(2, _h, 26, 13, "div", 2), r(3, "dx-popup", 3), f("onHidden", function() {
            C(e);
            let i = s();
            return v(i.onCloseDownloadPopup())
        }), r(4, "div", 4)(5, "div", 5)(6, "div", 6), u(7, "i", 7), a(), r(8, "p", 8), d(9), a()(), r(10, "div", 9)(11, "div", 10)(12, "div", 11), u(13, "i", 12), r(14, "div")(15, "div", 13), d(16, "macOS"), a(), r(17, "small", 14), d(18, ".dmg"), a()(), m(19, uh, 2, 1, "span", 15), a(), r(20, "dx-button", 16), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.onDownloadAgent("macos"))
        }), a()(), r(21, "div", 10)(22, "div", 11), u(23, "i", 17), r(24, "div")(25, "div", 13), d(26, "Windows"), a(), r(27, "small", 14), d(28, ".exe"), a()(), m(29, Ch, 2, 1, "span", 15), a(), r(30, "dx-button", 16), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.onDownloadAgent("windows"))
        }), a()(), r(31, "div", 10)(32, "div", 11), u(33, "i", 18), r(34, "div")(35, "div", 13), d(36, "Linux"), a(), r(37, "small", 14), d(38, ".AppImage"), a()(), m(39, vh, 2, 1, "span", 15), a(), r(40, "dx-button", 16), f("onClick", function() {
            C(e);
            let i = s();
            return v(i.onDownloadAgent("linux"))
        }), a()()(), r(41, "div", 19), u(42, "i", 20), r(43, "small"), d(44), a()()()(), m(45, yh, 35, 21, "div", 21), m(46, Fh, 3, 3), m(47, qh, 15, 5, "div", 22), a()
    }
    if (t & 2) {
        let e = s();
        n(), _(!e.currentScan || e.currentScan.status === "pending" && e.currentScan.progress_percentage === 0 && !e.showAgentNotOpenWarning ? 1 : -1), n(), _((e.currentScan == null ? null : e.currentScan.status) === "pending" && e.showAgentNotOpenWarning ? 2 : -1), n(), l("visible", e.showDownloadPopup)("showTitle", !0)("title", e.formatMessage("download_bytephase_agent"))("dragEnabled", !1)("hideOnOutsideClick", !0)("showCloseButton", !0)("width", 480)("height", "auto"), n(6), h(e.formatMessage("download_agent_description")), n(2), Ae("border-primary", e.isCurrentOS("macos"))("bg-primary", e.isCurrentOS("macos"))("bg-opacity-10", e.isCurrentOS("macos")), n(8), _(e.isCurrentOS("macos") ? 19 : -1), n(), l("text", e.formatMessage("download")), n(), Ae("border-primary", e.isCurrentOS("windows"))("bg-primary", e.isCurrentOS("windows"))("bg-opacity-10", e.isCurrentOS("windows")), n(8), _(e.isCurrentOS("windows") ? 29 : -1), n(), l("text", e.formatMessage("download")), n(), Ae("border-primary", e.isCurrentOS("linux"))("bg-primary", e.isCurrentOS("linux"))("bg-opacity-10", e.isCurrentOS("linux")), n(8), _(e.isCurrentOS("linux") ? 39 : -1), n(), l("text", e.formatMessage("download")), n(4), h(e.formatMessage("download_agent_note")), n(), _(e.currentScan && (e.currentScan.status === "scanning" || e.currentScan.status === "paused" || e.currentScan.status === "uploading" || e.currentScan.status === "processing") ? 45 : -1), n(), _((e.currentScan == null ? null : e.currentScan.status) === "completed" ? 46 : -1), n(), _((e.currentScan == null ? null : e.currentScan.status) === "failed" || (e.currentScan == null ? null : e.currentScan.status) === "cancelled" ? 47 : -1)
    }
}

function Wh(t, c) {
    if (t & 1) {
        let e = x();
        r(0, "app-send-notification", 147), f("sendNotificationClose", function() {
            C(e);
            let i = s();
            return v(i.isVisibleSendNotificationPopup = !1)
        }), a()
    }
    if (t & 2) {
        let e = s();
        l("isVisiblePopup", e.isVisibleSendNotificationPopup)("isVisibleSendButton", !1)("entityObj", e.currentScan)("entity", e.ENTITIES.DIRECTORY_SCAN)("job", e.job)
    }
}
var kl = (() => {
    class t {
        constructor() {
            this.formatMessage = g, this.ENTITIES = I, this.jobService = b(U), this.directoryScanService = b(Dl), this.userSessionService = b(L), this.toastNotificationService = b(D), this.tenantService = b(ve), this.whatsappService = b(Ke), this.router = b(G), this.sanitizer = b(ja), this.nativeFileService = b(pr), this.loaderService = b($), this.job = null, this.isEmployee = this.userSessionService.isEmployee(), this.currentScan = null, this.isLoading = !1, this.isPolling = !1, this.isLoadingDetails = !1, this.scanHtmlUrl = null, this.iframeHeight = 600, this.currentView = "scan", this.timeline = null, this.isLoadingTimeline = !1, this.isResendingEmail = !1, this.isVisibleSendNotificationPopup = !1, this.isIndia = this.tenantService.isIndia(), this.selectedChannel = "email", this.notificationMessage = "", this.verificationLink = "", this.linkExpiryDate = null, this.isSendingNotification = !1, this.termsVersion = "1.2", this.termsContent = `By verifying this data recovery, you confirm that:
1. You have reviewed the recovered files
2. The data matches your expectations
3. You authorize BytePhase to proceed with final delivery
4. This verification is legally binding`, this.showAgentNotOpenWarning = !1, this.agentIsRunning = !1, this.agentPlatform = "", this.agentTroubleshootingInfo = "", this.agentTimeoutId = null, this.showDownloadPopup = !1, this.agentDownloadLinks = {
                macos: "https://bytephase-agent-public.s3.ap-south-1.amazonaws.com/BytePhase+Agent-1.0.0.dmg",
                windows: "https://bytephase-agent-public.s3.ap-south-1.amazonaws.com/BytePhase+Agent+Setup+1.0.0.exe",
                linux: "https://bytephase-agent-public.s3.ap-south-1.amazonaws.com/BytePhase+Agent-1.0.0.AppImage"
            }, this.POLLING_INTERVAL = 2e3, this.AGENT_STARTUP_MS = 5e3
        }
        ngOnInit() {
            this.jobSubscription = this.jobService.currentJob$.subscribe({
                next: e => {
                    e ? .id && (this.job = e, this.loadScanStatus())
                }
            }), this.themeObserver = new MutationObserver(e => {
                e.forEach(o => {
                    o.attributeName === "class" && this.sendThemeToIframe()
                })
            }), this.themeObserver.observe(document.body, {
                attributes: !0,
                attributeFilter: ["class"]
            })
        }
        ngOnDestroy() {
            this.stopPolling(), this.clearAgentTimeout(), this.jobSubscription && this.jobSubscription.unsubscribe(), this.themeObserver && this.themeObserver.disconnect()
        }
        loadScanStatus() {
            this.isLoading = !0, this.directoryScanService.getScanProgress(this.job.id).subscribe({
                next: e => {
                    if (this.isLoading = !1, e ? .data) {
                        if (this.currentScan = e.data, this.currentScan.status !== "pending" && (this.showAgentNotOpenWarning = !1, this.clearAgentTimeout()), this.currentScan.is_verified) {
                            this.currentView = "timeline", this.loadTimeline();
                            return
                        }
                        this.isScanning() && this.startPolling(), this.isCompleted() && this.currentScan.id && this.loadScanDetails(this.currentScan.id)
                    } else this.currentScan = null
                },
                error: () => {
                    this.isLoading = !1, this.currentScan = null
                }
            })
        }
        loadScanDetails(e) {
            this.isLoadingDetails = !0, this.directoryScanService.getViewHtmlContent(e).subscribe({
                next: o => {
                    let i = new Blob([o], {
                            type: "text/html"
                        }),
                        p = URL.createObjectURL(i);
                    this.scanHtmlUrl = this.sanitizer.bypassSecurityTrustResourceUrl(p), this.isLoadingDetails = !1
                },
                error: () => {
                    this.isLoadingDetails = !1, this.toastNotificationService.error("failed_to_load_scan_viewer")
                }
            })
        }
        onIframeMessage(e) {
            e.data ? .action === "resize" && e.data ? .height ? this.iframeHeight = e.data.height + 20 : e.data ? .action === "request-theme" && this.sendThemeToIframe()
        }
        sendThemeToIframe() {
            let e = document.querySelector(".scan-viewer-iframe");
            if (e ? .contentWindow) {
                let o = document.body.classList.contains("dark-theme");
                e.contentWindow.postMessage({
                    action: "set-theme",
                    isDark: o
                }, "*")
            }
        }
        startPolling() {
            this.isPolling || (this.isPolling = !0, this.pollingSubscription = Dn(this.POLLING_INTERVAL).pipe(ha(() => this.isPolling && this.isScanning()), fa(() => this.directoryScanService.getScanProgress(this.job.id))).subscribe({
                next: e => {
                    if (e ? .data) {
                        let o = this.currentScan ? .status;
                        this.currentScan = e.data, (this.currentScan.status === "agent_connected" || this.currentScan.status === "scanning") && (this.clearAgentTimeout(), o === "pending" && this.showAgentNotOpenWarning && this.toastNotificationService.success("agent_connected"), this.showAgentNotOpenWarning = !1), (this.currentScan.status === "completed" || this.currentScan.status === "failed") && (this.clearAgentTimeout(), this.showAgentNotOpenWarning = !1), this.isScanning() || (this.stopPolling(), this.clearAgentTimeout(), this.isCompleted() && this.currentScan.id && this.loadScanDetails(this.currentScan.id))
                    }
                },
                error: () => {
                    this.stopPolling()
                }
            }))
        }
        stopPolling() {
            this.isPolling = !1, this.pollingSubscription && (this.pollingSubscription.unsubscribe(), this.pollingSubscription = null)
        }
        onStartValidation() {
            this.isLoading = !0, this.showAgentNotOpenWarning = !1, this.clearAgentTimeout(), this.directoryScanService.initiateDirectoryScan(this.job.id).subscribe({
                next: e => {
                    if (this.isLoading = !1, e ? .data ? .deeplink) {
                        let o = this.directoryScanService.openAgentDeepLink(e.data.deeplink);
                        this.agentPlatform = o.platform, this.agentTroubleshootingInfo = this.directoryScanService.getAgentSetupInstructions(o.platform), this.toastNotificationService.info("directory_scan_initiated"), this.currentScan = {
                            status: "pending",
                            progress_percentage: 0,
                            current_folder: "",
                            files_scanned: 0,
                            folders_scanned: 0,
                            total_size: 0,
                            estimated_time_remaining: "",
                            initiated_by: this.userSessionService.getUser() ? .name || "",
                            started_at: new Date().toISOString()
                        }, this.startPolling(), this.startAgentTimeoutDetection(), o.requiresManualAction && this.toastNotificationService.warning(this.formatMessage("agent_may_require_manual_setup"))
                    }
                },
                error: e => {
                    this.isLoading = !1, this.toastNotificationService.error(e.error ? .message || this.formatMessage("directory_scan_init_failed"))
                }
            })
        }
        startAgentTimeoutDetection() {
            this.clearAgentTimeout(), this.agentTimeoutId = setTimeout(() => {
                this.currentScan ? .status === "pending" && !this.showAgentNotOpenWarning && this.checkAgentHealth()
            }, this.AGENT_STARTUP_MS)
        }
        checkAgentHealth() {
            this.directoryScanService.isAgentRunning().subscribe({
                next: e => {
                    this.agentIsRunning = e, e ? console.log("[DataValidation] Agent is running, waiting for folder selection...") : (this.showAgentNotOpenWarning = !0, this.toastNotificationService.warning(this.formatMessage("agent_not_responding")))
                },
                error: () => {
                    this.agentIsRunning = !1, this.showAgentNotOpenWarning = !0, this.toastNotificationService.warning(this.formatMessage("agent_not_responding"))
                }
            })
        }
        clearAgentTimeout() {
            this.agentTimeoutId && (clearTimeout(this.agentTimeoutId), this.agentTimeoutId = null)
        }
        onDismissAgentWarning() {
            this.showAgentNotOpenWarning = !1
        }
        onShowDownloadPopup() {
            this.showDownloadPopup = !0
        }
        onCloseDownloadPopup() {
            this.showDownloadPopup = !1
        }
        onDownloadAgent(e) {
            let o = this.agentDownloadLinks[e];
            o && window.open(o, "_blank")
        }
        getRecommendedOS() {
            let e = navigator.platform.toLowerCase();
            return e.includes("mac") ? "macos" : e.includes("win") ? "windows" : "linux"
        }
        isCurrentOS(e) {
            return this.getRecommendedOS() === e
        }
        onCopyDeepLink() {
            this.directoryScanService.initiateDirectoryScan(this.job.id).subscribe({
                next: e => {
                    e ? .data ? .deeplink && navigator.clipboard.writeText(e.data.deeplink).then(() => {
                        this.toastNotificationService.success("deeplink_copied")
                    }).catch(() => {
                        this.toastNotificationService.error("copy_failed")
                    })
                },
                error: () => {
                    this.toastNotificationService.error("failed_to_generate_deeplink")
                }
            })
        }
        onPauseScan() {
            this.currentScan ? .id && this.directoryScanService.pauseScan(this.currentScan.id).subscribe({
                next: () => {
                    this.currentScan.status = "paused", this.stopPolling(), this.toastNotificationService.success("scan_paused")
                },
                error: () => {
                    this.toastNotificationService.error("scan_pause_failed")
                }
            })
        }
        onResumeScan() {
            this.currentScan ? .id && this.directoryScanService.resumeScan(this.currentScan.id).subscribe({
                next: () => {
                    this.currentScan.status = "scanning", this.startPolling(), this.toastNotificationService.success("scan_resumed")
                },
                error: () => {
                    this.toastNotificationService.error("scan_resume_failed")
                }
            })
        }
        onCancelScan() {
            this.currentScan ? .id && this.directoryScanService.cancelScan(this.currentScan.id).subscribe({
                next: () => {
                    this.currentScan.status = "cancelled", this.stopPolling(), this.toastNotificationService.success("scan_cancelled")
                },
                error: () => {
                    this.toastNotificationService.error("scan_cancel_failed")
                }
            })
        }
        isPending() {
            return !this.currentScan || this.currentScan.status === "pending"
        }
        isScanning() {
            return this.currentScan ? .status === "scanning" || this.currentScan ? .status === "pending" || this.currentScan ? .status === "agent_connected" || this.currentScan ? .status === "uploading" || this.currentScan ? .status === "processing"
        }
        isPaused() {
            return this.currentScan ? .status === "paused"
        }
        isCompleted() {
            return this.currentScan ? .status === "completed"
        }
        isFailed() {
            return this.currentScan ? .status === "failed" || this.currentScan ? .status === "cancelled"
        }
        getStatusBadgeClass() {
            switch (this.currentScan ? .status) {
                case "scanning":
                case "uploading":
                case "processing":
                    return "badge-scanning";
                case "paused":
                    return "badge-paused";
                case "completed":
                    return "badge-success";
                case "failed":
                case "cancelled":
                    return "badge-danger";
                default:
                    return "badge-pending"
            }
        }
        getStatusText() {
            switch (this.currentScan ? .status) {
                case "scanning":
                    return this.formatMessage("scanning");
                case "agent_connected":
                    return this.formatMessage("agent_connected_status");
                case "uploading":
                case "processing":
                    return this.formatMessage("uploading_data");
                case "paused":
                    return this.formatMessage("paused");
                case "completed":
                    return this.formatMessage("validation_completed");
                case "failed":
                    return this.formatMessage("scan_failed");
                case "cancelled":
                    return this.formatMessage("scan_cancelled_status");
                case "pending":
                    return this.isPolling ? this.formatMessage("waiting_for_agent") : this.formatMessage("pending_validation");
                default:
                    return this.formatMessage("pending_validation")
            }
        }
        getDeviceInfo() {
            if (!this.job) return "";
            let e = [];
            return this.job.device_brand ? .name && e.push(this.job.device_brand.name), this.job.device_model ? .name && e.push(this.job.device_model.name), this.job.device_type ? .name && e.push(this.job.device_type.name), e.join(" ") || "-"
        }
        getIssueDescription() {
            return this.job ? this.job.repairables ? .length > 0 ? this.job.repairables.map(e => e.name).join(", ") : this.job.comment || "-" : ""
        }
        formatEstimatedTime() {
            return this.currentScan ? .estimated_time_remaining || "-"
        }
        onRerunScan() {
            this.currentScan = null, this.scanHtmlUrl = null, this.onStartValidation()
        }
        onProceedToVerification() {
            this.currentView = "notification", this.generateVerificationLink(), this.setDefaultNotificationMessage()
        }
        generateVerificationLink() {
            this.currentScan ? .id && this.directoryScanService.generateVerificationLink(this.currentScan.id).subscribe({
                next: e => {
                    e ? .data && (this.verificationLink = e.data.link, this.linkExpiryDate = new Date(e.data.expires_at))
                },
                error: () => {
                    this.toastNotificationService.error("failed_to_generate_link")
                }
            })
        }
        setDefaultNotificationMessage() {
            let e = this.job ? .user ? .name || this.formatMessage("customer"),
                o = this.job ? .job_number || "";
            this.notificationMessage = `Dear ${e}, your data recovery for job ${o} is complete. Please verify the recovered data using the link below.`
        }
        onSelectChannel(e) {
            this.selectedChannel = e
        }
        onCopyLink() {
            this.verificationLink && navigator.clipboard.writeText(this.verificationLink).then(() => {
                this.toastNotificationService.success("link_copied")
            }).catch(() => {
                this.toastNotificationService.error("copy_failed")
            })
        }
        onBackToSummary() {
            this.currentView = "scan"
        }
        onSendNotification() {
            if (!this.verificationLink || this.isSendingNotification) return;
            if (this.selectedChannel === "whatsapp") {
                this.whatsappService.sendWhatsappMessage("directory_scan_verification", this.currentScan.id), this.currentView = "timeline", this.loadTimeline();
                return
            }
            this.isSendingNotification = !0;
            let e = {
                scan_id: this.currentScan.id,
                channel: this.selectedChannel,
                message: this.notificationMessage,
                verification_link: this.verificationLink
            };
            this.directoryScanService.sendVerificationNotification(e).subscribe({
                next: () => {
                    this.isSendingNotification = !1, this.toastNotificationService.success("notification_sent"), this.currentView = "timeline", this.loadTimeline()
                },
                error: o => {
                    this.isSendingNotification = !1, this.toastNotificationService.error(o.error ? .message || this.formatMessage("notification_failed"))
                }
            })
        }
        loadTimeline() {
            this.currentScan ? .id && (this.isLoadingTimeline = !0, this.directoryScanService.getValidationTimeline(this.currentScan.id).subscribe({
                next: e => {
                    this.isLoadingTimeline = !1, e ? .data && (this.timeline = e.data)
                },
                error: () => {
                    this.isLoadingTimeline = !1, this.timeline = this.buildLocalTimeline()
                }
            }))
        }
        buildLocalTimeline() {
            let e = [];
            return this.currentScan ? .started_at && e.push({
                type: "scan_started",
                title: this.formatMessage("scan_started"),
                description: `Scan initiated by ${this.currentScan.initiated_by}`,
                timestamp: this.currentScan.started_at
            }), this.currentScan ? .completed_at && e.push({
                type: "scan_completed",
                title: this.formatMessage("scan_completed"),
                description: `Scanned ${this.currentScan.files_scanned} files in ${this.currentScan.folders_scanned} folders (${this.formatBytes(this.currentScan.total_size)})`,
                timestamp: this.currentScan.completed_at
            }), e.push({
                type: "notification_sent",
                title: this.formatMessage("notification_sent_title"),
                description: `Sent via ${this.selectedChannel} to ${this.getRecipientInfo()}`,
                timestamp: new Date().toISOString()
            }), {
                customer_name: this.job ? .user ? .name || "-",
                job_number: this.job ? .job_number || "-",
                verification_status: "pending",
                otp_confirmed: !1,
                signature_reference_id: "",
                events: e
            }
        }
        getRecipientInfo() {
            return this.selectedChannel === "email" ? this.job ? .user ? .email || "" : this.job ? .user ? .mobile_number || ""
        }
        formatBytes(e) {
            if (e === 0) return "0 B";
            let o = 1024,
                i = ["B", "KB", "MB", "GB", "TB"],
                p = Math.floor(Math.log(e) / Math.log(o));
            return parseFloat((e / Math.pow(o, p)).toFixed(2)) + " " + i[p]
        }
        onDownloadValidationPdf() {
            this.currentScan ? .id && this.directoryScanService.downloadValidationPdf(this.currentScan.id).subscribe({
                next: e => {
                    let o = e.body,
                        i = `validation-${this.job?.job_number||"scan"}-${new Date().toISOString().split("T")[0]}.pdf`,
                        p = window.URL.createObjectURL(o),
                        y = document.createElement("a");
                    y.href = p, y.download = i, y.click(), window.URL.revokeObjectURL(p)
                },
                error: e => {
                    this.toastNotificationService.error(e.error ? .message || this.formatMessage("pdf_download_failed"))
                }
            })
        }
        onPrintValidationPdf() {
            this.currentScan ? .id && (this.loaderService.show(), this.directoryScanService.downloadValidationPdf(this.currentScan.id).subscribe({
                next: e => _a(this, null, function*() {
                    try {
                        let o = e.body,
                            i = `validation-${this.job?.job_number||"scan"}-${new Date().toISOString().split("T")[0]}.pdf`;
                        yield this.nativeFileService.printPDF(o, i)
                    } catch (o) {
                        this.toastNotificationService.error("pdf_print_failed")
                    } finally {
                        this.loaderService.hide()
                    }
                }),
                error: e => {
                    this.loaderService.hide(), this.toastNotificationService.error(e.error ? .message || this.formatMessage("pdf_print_failed"))
                }
            }))
        }
        onResendConfirmationEmail() {
            !this.currentScan ? .id || this.isResendingEmail || (this.isResendingEmail = !0, this.directoryScanService.resendConfirmationEmail(this.currentScan.id).subscribe({
                next: () => {
                    this.isResendingEmail = !1, this.toastNotificationService.success("confirmation_email_resent")
                },
                error: e => {
                    this.isResendingEmail = !1, this.toastNotificationService.error(e.error ? .message || this.formatMessage("resend_email_failed"))
                }
            }))
        }
        getTimelineStatusBadgeClass() {
            switch (this.timeline ? .verification_status) {
                case "verified":
                    return "badge-success";
                case "pending":
                    return "badge-pending";
                case "expired":
                    return "badge-danger";
                default:
                    return "badge-pending"
            }
        }
        getTimelineStatusText() {
            switch (this.timeline ? .verification_status) {
                case "verified":
                    return this.formatMessage("customer_verified");
                case "pending":
                    return this.formatMessage("awaiting_verification");
                case "expired":
                    return this.formatMessage("link_expired");
                default:
                    return this.formatMessage("awaiting_verification")
            }
        }
        getEventIcon(e) {
            switch (e) {
                case "scan_started":
                    return "fa-thin fa-play-circle";
                case "scan_completed":
                    return "fa-thin fa-check-circle";
                case "notification_sent":
                    return "fa-thin fa-paper-plane";
                case "link_accessed":
                    return "fa-thin fa-eye";
                case "customer_verified":
                    return "fa-thin fa-shield-check";
                default:
                    return "fa-thin fa-circle"
            }
        }
        onViewScanData() {
            this.currentScan ? .id && (this.loadScanDetails(this.currentScan.id), this.currentView = "scan")
        }
        onBackToTimeline() {
            this.currentView = "timeline"
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-data-validation"]
                ],
                hostBindings: function(o, i) {
                    o & 1 && f("message", function(y) {
                        return i.onIframeMessage(y)
                    }, ga)
                },
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    [1, "validation-container"],
                    [3, "isVisiblePopup", "isVisibleSendButton", "entityObj", "entity", "job"],
                    [1, "dx-card", "warning-card"],
                    [3, "onHidden", "visible", "showTitle", "title", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [1, "p-3"],
                    [1, "text-center", "mb-4"],
                    [1, "bg-primary", "bg-opacity-10", "rounded-circle", "d-inline-flex", "align-items-center", "justify-content-center", "mb-3", 2, "width", "64px", "height", "64px"],
                    [1, "fa-thin", "fa-desktop", "fa-2x", "text-primary"],
                    [1, "text-muted", "mb-0"],
                    [1, "d-flex", "flex-column", "gap-2", "mb-4"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "p-3", "border", "rounded"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "fa-brands", "fa-apple", "fa-xl", "text-secondary"],
                    [1, "fw-semibold"],
                    [1, "text-muted"],
                    [1, "badge", "bg-primary", "ms-2"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-download", 3, "onClick", "text"],
                    [1, "fa-brands", "fa-windows", "fa-xl", "text-secondary"],
                    [1, "fa-brands", "fa-linux", "fa-xl", "text-secondary"],
                    [1, "alert", "alert-info", "d-flex", "align-items-start", "gap-2", "mb-0", "py-2"],
                    [1, "fa-thin", "fa-circle-info", "mt-1"],
                    [1, "dx-card", "validation-card"],
                    [1, "dx-card", "error-card"],
                    [1, "card", "mb-3"],
                    [1, "card-body"],
                    [1, "d-flex", "justify-content-between", "align-items-start", "flex-wrap", "gap-2", "mb-3"],
                    [1, "card-title", "mb-1"],
                    [1, "badge", "bg-secondary", "d-flex", "align-items-center", "gap-1", "px-3", "py-2"],
                    [1, "fa-thin", "fa-clock"],
                    [1, "row", "g-3"],
                    [1, "col-md-6"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fa-thin", "fa-user", "text-muted"],
                    [1, "ms-1"],
                    [1, "fa-thin", "fa-laptop", "text-muted"],
                    [1, "fa-thin", "fa-user-gear", "text-muted"],
                    [1, "fa-thin", "fa-circle-info", "text-muted"],
                    [1, "card"],
                    [1, "card-title", "mb-3"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-play", 3, "onClick", "text", "disabled"],
                    [1, "card-header-row"],
                    [1, "card-title"],
                    [1, "status-badge", "badge-warning"],
                    [1, "fa-thin", "fa-exclamation-triangle"],
                    [1, "warning-box", "warning-box-orange"],
                    [1, "fa-thin", "fa-desktop", "warning-icon"],
                    [1, "warning-content"],
                    [1, "warning-title"],
                    [1, "warning-description"],
                    [1, "troubleshooting-section"],
                    [1, "troubleshooting-title"],
                    [1, "fa-thin", "fa-wrench"],
                    [1, "troubleshooting-text"],
                    [1, "button-row"],
                    ["type", "success", "stylingMode", "contained", "icon", "fa-thin fa-download", 3, "onClick", "text"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-copy", 3, "onClick", "text"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-rotate", 3, "onClick", "text"],
                    ["type", "normal", "stylingMode", "text", 3, "onClick", "text"],
                    [1, "status-badge", 3, "ngClass"],
                    [1, "fa-thin", "fa-spinner", "fa-spin"],
                    [1, "fa-thin", "fa-pause"],
                    [1, "progress-section"],
                    [1, "progress-header"],
                    [1, "progress-label"],
                    [1, "progress-value"],
                    [1, "scan-progress-bar", 3, "min", "max", "value", "showStatus"],
                    [1, "detail-item"],
                    [1, "divider"],
                    [1, "stats-grid"],
                    [1, "stat-item"],
                    [1, "info-label"],
                    [1, "info-value"],
                    [1, "fa-thin", "fa-folder", "detail-icon"],
                    [1, "info-value", "mono"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-pause", 3, "text"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-play", 3, "text"],
                    ["type", "danger", "stylingMode", "outlined", "icon", "fa-thin fa-times-circle", 3, "onClick", "text"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-pause", 3, "onClick", "text"],
                    ["type", "default", "stylingMode", "outlined", "icon", "fa-thin fa-play", 3, "onClick", "text"],
                    [1, "dx-card", "notification-card"],
                    [1, "dx-card", "timeline-card"],
                    [1, "dx-card", "scan-action-card"],
                    ["frameborder", "0", "scrolling", "no", "allowfullscreen", "", 1, "scan-viewer-iframe", 3, "src", "height"],
                    [1, "text-center", "py-5"],
                    [1, "preview-note"],
                    [1, "action-button-row"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-arrow-left", 3, "text"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-arrow-left", 3, "onClick", "text"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-rotate", 3, "onClick", "text"],
                    ["type", "default", "stylingMode", "contained", 1, "proceed-btn", 3, "onClick"],
                    [1, "fa-thin", "fa-arrow-right", "ms-2"],
                    ["frameborder", "0", "scrolling", "no", "allowfullscreen", "", 1, "scan-viewer-iframe", 3, "src"],
                    [1, "fa-thin", "fa-spinner", "fa-spin", "fs-1", "text-muted", "mb-3", "d-block"],
                    [1, "notification-title"],
                    [1, "form-group"],
                    [1, "form-label"],
                    [1, "channel-buttons"],
                    [1, "channel-btn", 3, "click"],
                    [1, "fa-thin", "fa-envelope"],
                    [1, "channel-btn", 3, "active"],
                    [1, "fa-brands", "fa-whatsapp"],
                    [3, "valueChange", "value", "height", "placeholder"],
                    [1, "link-input-row"],
                    [1, "link-input", 3, "valueChange", "value", "readOnly"],
                    ["icon", "fa-thin fa-copy", "type", "normal", "stylingMode", "outlined", 3, "onClick", "text"],
                    [1, "info-box"],
                    [1, "terms-box"],
                    [1, "terms-text"],
                    [1, "action-footer"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-paper-plane", 3, "onClick", "text", "disabled"],
                    [1, "fa-thin", "fa-comment"],
                    [1, "fa-thin", "fa-clock", "info-icon"],
                    [1, "info-content"],
                    [1, "info-title"],
                    [1, "info-description"],
                    [1, "loading-state"],
                    [1, "fa-thin", "fa-check-circle"],
                    [1, "info-grid"],
                    [1, "info-grid-row"],
                    [1, "info-item"],
                    [1, "timeline-events"],
                    [1, "timeline-event"],
                    [1, "success-box"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-print", 3, "onClick", "text"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-paper-plane", 3, "onClick", "text", "disabled"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-envelope-open", 3, "onClick", "text"],
                    ["type", "normal", "stylingMode", "outlined", "icon", "fa-thin fa-folder-tree", 3, "onClick", "text"],
                    [1, "event-icon-wrapper"],
                    [1, "event-content"],
                    [1, "event-header"],
                    [1, "event-title"],
                    [1, "event-time"],
                    [1, "event-description"],
                    [1, "success-icon-wrapper"],
                    [1, "fa-thin", "fa-file-signature"],
                    [1, "success-content"],
                    [1, "success-title"],
                    [1, "success-description"],
                    [1, "success-reference"],
                    [1, "status-badge", "badge-danger"],
                    [1, "fa-thin", "fa-times-circle"],
                    [1, "error-box"],
                    [1, "fa-thin", "fa-circle-xmark", "error-icon"],
                    [1, "error-content"],
                    [1, "error-title"],
                    [1, "error-description"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-redo", 3, "onClick", "text"],
                    [3, "sendNotificationClose", "isVisiblePopup", "isVisibleSendButton", "entityObj", "entity", "job"]
                ],
                template: function(o, i) {
                    o & 1 && (m(0, Gh, 48, 39, "div", 0), m(1, Wh, 1, 5, "app-send-notification", 1)), o & 2 && (_(i.job ? 0 : -1), n(), _(i.currentScan ? 1 : -1))
                },
                dependencies: [Q, tt, ct, H, vr, jt, dt, Kt, Jn, Ue],
                styles: ['.validation-container[_ngcontent-%COMP%]{padding:16px}.validation-card[_ngcontent-%COMP%]{padding:24px;border-radius:12px;margin-bottom:16px;background:#fff;border:1px solid #ecf0f1}.dark-theme[_nghost-%COMP%]   .validation-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .validation-card[_ngcontent-%COMP%]{background:#1e293b;border-color:#334155}.card-subtitle[_ngcontent-%COMP%]{display:block;font-size:.8125rem;color:#95a5a6;margin-top:4px}.dark-theme[_nghost-%COMP%]   .card-subtitle[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .card-subtitle[_ngcontent-%COMP%]{color:#a0aec0}.detail-item[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;flex:1;min-width:200px}.detail-icon[_ngcontent-%COMP%]{font-size:1.125rem;color:#95a5a6;margin-top:2px}.dark-theme[_nghost-%COMP%]   .detail-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .detail-icon[_ngcontent-%COMP%]{color:#a0aec0}.warning-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;padding:16px;background:#fff3cd;border:1px solid rgba(255,193,7,.3);border-radius:10px;margin-bottom:20px}.warning-box[_ngcontent-%COMP%]   .warning-icon[_ngcontent-%COMP%]{font-size:1.25rem;color:#664d03;margin-top:2px}.warning-box[_ngcontent-%COMP%]   .warning-content[_ngcontent-%COMP%]{flex:1}.warning-box[_ngcontent-%COMP%]   .warning-title[_ngcontent-%COMP%]{font-weight:600;color:#664d03;margin:0 0 4px}.warning-box[_ngcontent-%COMP%]   .warning-description[_ngcontent-%COMP%]{font-size:.875rem;color:#664d03;margin:0}.dark-theme[_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]{background:#ffc10726;border-color:#ffc1074d}.dark-theme[_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]   .warning-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]   .warning-icon[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]   .warning-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]   .warning-title[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]   .warning-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .warning-box[_ngcontent-%COMP%]   .warning-description[_ngcontent-%COMP%]{color:#ffc107}.progress-section[_ngcontent-%COMP%]{margin-bottom:20px}.progress-header[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}.progress-label[_ngcontent-%COMP%]{font-size:.875rem;color:#95a5a6}.dark-theme[_nghost-%COMP%]   .progress-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .progress-label[_ngcontent-%COMP%]{color:#a0aec0}.progress-value[_ngcontent-%COMP%]{font-weight:600;color:#3498db}.dark-theme[_nghost-%COMP%]   .progress-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .progress-value[_ngcontent-%COMP%]{color:#3498db}.stats-grid[_ngcontent-%COMP%]{display:flex;gap:24px;flex-wrap:wrap;margin-bottom:20px}.stat-item[_ngcontent-%COMP%]{flex:1;min-width:150px}.stat-item[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{display:block;font-size:.75rem;text-transform:uppercase;color:#95a5a6;margin-bottom:4px}.stat-item[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{display:block;font-weight:600;color:#2c3e50}.dark-theme[_nghost-%COMP%]   .stat-item[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-item[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .stat-item[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-item[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{color:#fff}.divider[_ngcontent-%COMP%]{border:none;border-top:1px solid #ecf0f1;margin:20px 0}.dark-theme[_nghost-%COMP%]   .divider[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .divider[_ngcontent-%COMP%]{border-top-color:#334155}.button-row[_ngcontent-%COMP%]{display:flex;gap:12px;flex-wrap:wrap}.mono[_ngcontent-%COMP%]{font-family:monospace;font-size:.8125rem}.scan-viewer-iframe[_ngcontent-%COMP%]{width:100%;border:none;background:transparent;display:block}.scan-action-card[_ngcontent-%COMP%]{padding:16px 24px;border-radius:12px;margin-top:0;margin-bottom:12px;background:#fff;border:1px solid #ecf0f1}.scan-action-card[_ngcontent-%COMP%]   .preview-note[_ngcontent-%COMP%]{font-size:.875rem;color:#95a5a6;margin:0 0 16px}.scan-action-card[_ngcontent-%COMP%]   .action-button-row[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}.scan-action-card[_ngcontent-%COMP%]   .action-button-row[_ngcontent-%COMP%]   .proceed-btn[_ngcontent-%COMP%]     .dx-button-content{display:flex;align-items:center;gap:8px}.dark-theme[_nghost-%COMP%]   .scan-action-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .scan-action-card[_ngcontent-%COMP%]{background:#1e293b;border-color:#334155}.dark-theme[_nghost-%COMP%]   .scan-action-card[_ngcontent-%COMP%]   .preview-note[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .scan-action-card[_ngcontent-%COMP%]   .preview-note[_ngcontent-%COMP%]{color:#a0aec0}.notification-card[_ngcontent-%COMP%]{padding:24px;border-radius:12px;background:#fff;border:1px solid #ecf0f1}.dark-theme[_nghost-%COMP%]   .notification-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .notification-card[_ngcontent-%COMP%]{background:#1e293b;border-color:#334155}.notification-title[_ngcontent-%COMP%]{font-size:1.375rem;font-weight:600;margin:0 0 24px;color:#2c3e50}.dark-theme[_nghost-%COMP%]   .notification-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .notification-title[_ngcontent-%COMP%]{color:#fff}.form-group[_ngcontent-%COMP%]{margin-bottom:20px}.form-label[_ngcontent-%COMP%]{display:block;font-size:.875rem;font-weight:500;margin-bottom:8px;color:#95a5a6}.dark-theme[_nghost-%COMP%]   .form-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .form-label[_ngcontent-%COMP%]{color:#a0aec0}.channel-buttons[_ngcontent-%COMP%]{display:flex;gap:12px}@media(max-width:576px){.channel-buttons[_ngcontent-%COMP%]{flex-direction:column}}.channel-btn[_ngcontent-%COMP%]{flex:1;display:flex;align-items:center;justify-content:center;gap:8px;padding:14px 24px;border:2px solid #ecf0f1;border-radius:10px;background:transparent;font-size:.9375rem;font-weight:500;cursor:pointer;transition:all .2s ease;color:#2c3e50}.channel-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.125rem}.channel-btn[_ngcontent-%COMP%]:hover{border-color:#3498db;background:#3498db0d}.channel-btn.active[_ngcontent-%COMP%]{border-color:#3498db;background:#3498db1a;color:#3498db}.dark-theme[_nghost-%COMP%]   .channel-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .channel-btn[_ngcontent-%COMP%]{border-color:#334155;color:#fff}.dark-theme[_nghost-%COMP%]   .channel-btn[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .channel-btn[_ngcontent-%COMP%]:hover{border-color:#3498db;background:#3498db1a}.dark-theme[_nghost-%COMP%]   .channel-btn.active[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .channel-btn.active[_ngcontent-%COMP%]{border-color:#3498db;background:#3498db26;color:#3498db}.link-input-row[_ngcontent-%COMP%]{display:flex;gap:8px}.link-input-row[_ngcontent-%COMP%]   .link-input[_ngcontent-%COMP%]{flex:1}.info-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;padding:16px;background:#d8eaf0;border:1px solid rgba(52,152,219,.3);border-radius:10px;margin-bottom:20px}.info-box[_ngcontent-%COMP%]   .info-icon[_ngcontent-%COMP%]{font-size:1.25rem;color:#3498db;margin-top:2px}.info-box[_ngcontent-%COMP%]   .info-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2px}.info-box[_ngcontent-%COMP%]   .info-title[_ngcontent-%COMP%]{font-size:.9375rem;font-weight:600;color:#3498db}.info-box[_ngcontent-%COMP%]   .info-description[_ngcontent-%COMP%]{font-size:.8125rem;color:#3498db}.dark-theme[_nghost-%COMP%]   .info-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]{background:#3498db26;border-color:#3498db4d}.dark-theme[_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]   .info-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]   .info-icon[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]   .info-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]   .info-title[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]   .info-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-box[_ngcontent-%COMP%]   .info-description[_ngcontent-%COMP%]{color:#3498db}.terms-box[_ngcontent-%COMP%]{padding:16px;border:1px solid #ecf0f1;border-radius:10px;background:#f8f9fa}.dark-theme[_nghost-%COMP%]   .terms-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-box[_ngcontent-%COMP%]{border-color:#334155;background:#1e293b}.terms-text[_ngcontent-%COMP%]{margin:0;font-size:.875rem;line-height:1.7;white-space:pre-wrap;font-family:inherit;color:#95a5a6}.dark-theme[_nghost-%COMP%]   .terms-text[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-text[_ngcontent-%COMP%]{color:#a0aec0}.action-footer[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:12px;align-items:center;padding-top:24px;border-top:1px solid #ecf0f1;margin-top:8px}@media(max-width:480px){.action-footer[_ngcontent-%COMP%]{flex-direction:column}.action-footer[_ngcontent-%COMP%]   dx-button[_ngcontent-%COMP%]{width:100%}}.dark-theme[_nghost-%COMP%]   .action-footer[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .action-footer[_ngcontent-%COMP%]{border-top-color:#334155}.timeline-card[_ngcontent-%COMP%], .error-card[_ngcontent-%COMP%]{padding:24px;border-radius:12px;background:#fff;border:1px solid #ecf0f1}.dark-theme[_nghost-%COMP%]   .timeline-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .timeline-card[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .error-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .error-card[_ngcontent-%COMP%]{background:#1e293b;border-color:#334155}.card-header-row[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:24px}.card-title[_ngcontent-%COMP%]{font-size:1.25rem;font-weight:600;margin:0;color:#2c3e50}.dark-theme[_nghost-%COMP%]   .card-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .card-title[_ngcontent-%COMP%]{color:#fff}.status-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:.8125rem;font-weight:500}.loading-state[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 24px;gap:16px;color:#95a5a6}.loading-state[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:2rem}.dark-theme[_nghost-%COMP%]   .loading-state[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .loading-state[_ngcontent-%COMP%]{color:#a0aec0}.info-grid[_ngcontent-%COMP%]{background:#f8f9fa;border-radius:10px;padding:16px;margin-bottom:24px}.dark-theme[_nghost-%COMP%]   .info-grid[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-grid[_ngcontent-%COMP%]{background:#1e293b}.info-grid-row[_ngcontent-%COMP%]{display:flex;gap:24px;flex-wrap:wrap}.info-grid-row[_ngcontent-%COMP%]:not(:last-child){margin-bottom:16px}.info-item[_ngcontent-%COMP%]{flex:1;min-width:200px}.info-item[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{display:block;font-size:.75rem;text-transform:uppercase;color:#95a5a6;margin-bottom:4px}.info-item[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{display:flex;align-items:center;gap:6px;font-weight:600;color:#2c3e50}.info-item[_ngcontent-%COMP%]   .info-value.success-text[_ngcontent-%COMP%]{color:green}.dark-theme[_nghost-%COMP%]   .info-item[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-item[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .info-item[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-item[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .info-item[_ngcontent-%COMP%]   .info-value.success-text[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .info-item[_ngcontent-%COMP%]   .info-value.success-text[_ngcontent-%COMP%]{color:#198754}.event-header[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:4px}.event-title[_ngcontent-%COMP%]{font-weight:600;color:#2c3e50}.dark-theme[_nghost-%COMP%]   .event-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .event-title[_ngcontent-%COMP%]{color:#fff}.event-time[_ngcontent-%COMP%]{font-size:.8125rem;color:#95a5a6}.dark-theme[_nghost-%COMP%]   .event-time[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .event-time[_ngcontent-%COMP%]{color:#a0aec0}.event-description[_ngcontent-%COMP%]{font-size:.875rem;color:#95a5a6;margin:0}.dark-theme[_nghost-%COMP%]   .event-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .event-description[_ngcontent-%COMP%]{color:#a0aec0}.success-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;padding:16px;background:#d5ebd5;border:1px solid rgba(0,128,0,.3);border-radius:10px;margin-bottom:24px}.success-box[_ngcontent-%COMP%]   .success-icon-wrapper[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:40px;height:40px;background:#00800033;border-radius:8px}.success-box[_ngcontent-%COMP%]   .success-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem;color:green}.success-box[_ngcontent-%COMP%]   .success-content[_ngcontent-%COMP%]{flex:1}.success-box[_ngcontent-%COMP%]   .success-title[_ngcontent-%COMP%]{display:block;font-weight:600;color:green;margin-bottom:4px}.success-box[_ngcontent-%COMP%]   .success-description[_ngcontent-%COMP%]{font-size:.875rem;color:green;margin:0 0 4px}.success-box[_ngcontent-%COMP%]   .success-reference[_ngcontent-%COMP%]{font-size:.8125rem;color:green;opacity:.8}.dark-theme[_nghost-%COMP%]   .success-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]{background:#19875426;border-color:#1987544d}.dark-theme[_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-icon-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-icon-wrapper[_ngcontent-%COMP%]{background:#19875433}.dark-theme[_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#198754}.dark-theme[_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-title[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-description[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-reference[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-box[_ngcontent-%COMP%]   .success-reference[_ngcontent-%COMP%]{color:#198754}.error-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;padding:16px;background:#f8d7da;border:1px solid rgba(220,53,69,.3);border-radius:10px;margin-bottom:24px}.error-box[_ngcontent-%COMP%]   .error-icon[_ngcontent-%COMP%]{font-size:1.25rem;color:#842029;margin-top:2px}.error-box[_ngcontent-%COMP%]   .error-content[_ngcontent-%COMP%]{flex:1}.error-box[_ngcontent-%COMP%]   .error-title[_ngcontent-%COMP%]{font-weight:600;color:#842029;margin:0 0 4px}.error-box[_ngcontent-%COMP%]   .error-description[_ngcontent-%COMP%]{font-size:.875rem;color:#842029;margin:0}.dark-theme[_nghost-%COMP%]   .error-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]{background:#dc354526;border-color:#dc35454d}.dark-theme[_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]   .error-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]   .error-icon[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]   .error-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]   .error-title[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]   .error-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .error-box[_ngcontent-%COMP%]   .error-description[_ngcontent-%COMP%]{color:#dc3545}.scan-progress-bar[_ngcontent-%COMP%]     .dx-progressbar-container{height:8px;border-radius:4px;background-color:#ecf0f1}.scan-progress-bar[_ngcontent-%COMP%]     .dx-progressbar-range{background-color:#3498db;border-radius:4px}.dark-theme[_nghost-%COMP%]   .scan-progress-bar[_ngcontent-%COMP%]     .dx-progressbar-container, .dark-theme   [_nghost-%COMP%]   .scan-progress-bar[_ngcontent-%COMP%]     .dx-progressbar-container{background-color:#334155}.badge-pending[_ngcontent-%COMP%]{background-color:#ecf0f1!important;color:#2c3e50!important;border:1px solid #95a5a6!important}.dark-theme[_nghost-%COMP%]   .badge-pending[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .badge-pending[_ngcontent-%COMP%]{background-color:#1e293b!important;color:#fff!important;border-color:#334155!important}.badge-scanning[_ngcontent-%COMP%]{background-color:#d8eaf0!important;color:#3498db!important;border:1px solid #3498db!important}.dark-theme[_nghost-%COMP%]   .badge-scanning[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .badge-scanning[_ngcontent-%COMP%]{background-color:#3498db33!important;color:#3498db!important;border-color:#3498db!important}.badge-paused[_ngcontent-%COMP%]{background-color:#fff3cd!important;color:#664d03!important}.dark-theme[_nghost-%COMP%]   .badge-paused[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .badge-paused[_ngcontent-%COMP%]{background-color:#ffc10733!important;color:#ffc107!important}.badge-success[_ngcontent-%COMP%]{background-color:#d5ebd5!important;color:green!important}.dark-theme[_nghost-%COMP%]   .badge-success[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .badge-success[_ngcontent-%COMP%]{background-color:#19875433!important;color:#198754!important}.badge-danger[_ngcontent-%COMP%]{background-color:#f8d7da!important;color:#842029!important}.dark-theme[_nghost-%COMP%]   .badge-danger[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .badge-danger[_ngcontent-%COMP%]{background-color:#dc354533!important;color:#dc3545!important}.timeline-events[_ngcontent-%COMP%]{position:relative;padding-left:2rem;margin-bottom:24px}.timeline-events[_ngcontent-%COMP%]:before{content:"";position:absolute;left:.6875rem;top:0;bottom:0;width:2px;background-color:#ecf0f1}.dark-theme[_nghost-%COMP%]   .timeline-events[_ngcontent-%COMP%]:before, .dark-theme   [_nghost-%COMP%]   .timeline-events[_ngcontent-%COMP%]:before{background-color:#334155}.timeline-event[_ngcontent-%COMP%]{position:relative;display:flex;gap:1rem;padding-bottom:1.5rem}.timeline-event[_ngcontent-%COMP%]:last-child{padding-bottom:0}.event-icon-wrapper[_ngcontent-%COMP%]{position:absolute;left:-2rem;width:1.5rem;height:1.5rem;border-radius:50%;background-color:#fff;border:2px solid #008000;display:flex;align-items:center;justify-content:center;z-index:1}.event-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.75rem;color:green}.dark-theme[_nghost-%COMP%]   .event-icon-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .event-icon-wrapper[_ngcontent-%COMP%]{background-color:#1e293b;border-color:#198754}.dark-theme[_nghost-%COMP%]   .event-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .event-icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#198754}.event-content[_ngcontent-%COMP%]{flex:1;min-width:0}.cursor-pointer[_ngcontent-%COMP%]{cursor:pointer}']
            })
        }
    }
    return t
})();
var Hh = [{
        path: "",
        component: xl,
        title: "",
        children: [{
            path: "list",
            component: jo,
            canActivate: [z],
            data: {
                tab_index: 0,
                permissions: {
                    only: [M.JOB_LIST]
                },
                is_open_jobs_only: !0
            },
            pathMatch: "full",
            title: "BytePhase Service/Tickets List"
        }, {
            path: "all",
            component: jo,
            canActivate: [z],
            data: {
                tab_index: 1,
                permissions: {
                    only: [M.JOB_LIST]
                },
                is_open_jobs_only: !1,
                is_closed_jobs_only: !1
            },
            pathMatch: "full",
            title: "BytePhase Service/Tickets List"
        }, {
            path: "assigned",
            component: jo,
            canActivate: [hn, z, us],
            data: {
                permissions: {
                    only: [M.JOB_LIST]
                },
                assigned_only: !0
            },
            pathMatch: "full",
            title: "BytePhase Assigned Jobs"
        }, {
            path: "comments",
            component: jl,
            data: {
                has_replied: !1
            },
            pathMatch: "full",
            title: "BytePhase Service/Tickets List"
        }, {
            path: "outsourceTo",
            component: Ol,
            canActivate: [z, hn],
            data: {
                tab_index: 2,
                permissions: {
                    only: [M.OUTSOURCED_JOB_LIST]
                }
            },
            children: [{
                path: "list",
                component: pa,
                canActivate: [z],
                data: {
                    permissions: {
                        only: [M.OUTSOURCED_JOB_LIST]
                    }
                },
                title: "BytePhase Outsource To Management"
            }, {
                path: "outsourceDeliveryChallan/:id",
                component: Pl,
                canActivate: [z],
                data: {
                    permissions: {
                        only: [M.OUTSOURCED_JOB_LIST]
                    }
                },
                title: "BytePhase Outsource Delivery Challan"
            }, {
                path: "vendors/list",
                canActivate: [z],
                component: Il,
                data: {
                    permissions: {
                        only: [M.OUTSOURCE_VENDOR_LIST]
                    }
                },
                title: "BytePhase Mange Vendor"
            }, {
                path: "vendors/add",
                component: da,
                data: {
                    permissions: {
                        only: [M.OUTSOURCE_VENDOR_WRITE]
                    }
                },
                title: "BytePhase Create Vendors"
            }, {
                path: "vendors/:vendor_id",
                component: wl,
                data: {
                    vendor_id: null
                },
                children: [{
                    path: "profiles",
                    component: da,
                    data: {
                        tab_index: 0
                    },
                    title: "BytePhase Outsource Vendor Overview Page"
                }, {
                    path: "jobs",
                    component: pa,
                    data: {
                        tab_index: 2
                    },
                    title: "BytePhase Outsourced Jobs"
                }, {
                    path: "",
                    redirectTo: "profile",
                    pathMatch: "full"
                }],
                title: "BytePhase View Vendors"
            }, {
                path: "",
                redirectTo: "list",
                pathMatch: "full"
            }]
        }, {
            path: "selfCheckIn",
            component: Ml,
            data: {
                tab_index: 3,
                permissions: {
                    only: [M.CONTACT_US_LIST]
                }
            },
            title: "BytePhase Self Check-In | List"
        }, {
            path: "basicSettings",
            redirectTo: "jobSettings/basicSettings",
            pathMatch: "full"
        }, {
            path: "jobSettings",
            component: rs,
            canActivate: [z],
            data: {
                tab_index: 4,
                permissions: {
                    only: [M.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                redirectTo: "basicJobSettings",
                pathMatch: "full"
            }, {
                path: "basicJobSettings",
                component: is,
                canActivate: [z],
                data: {
                    tab_index: 0,
                    permissions: {
                        only: [M.BUSINESS_SETTING_VIEW]
                    }
                }
            }, {
                path: "deviceTypes",
                component: gs,
                canActivate: [z],
                data: {
                    tab_index: 1,
                    permissions: {
                        only: [M.DEVICE_TYPE_LIST]
                    }
                }
            }, {
                path: "deviceBrands",
                component: fs,
                canActivate: [z],
                data: {
                    tab_index: 2,
                    permissions: {
                        only: [M.DEVICE_BRAND_LIST]
                    }
                }
            }, {
                path: "deviceModels",
                component: bs,
                canActivate: [z],
                data: {
                    tab_index: 3,
                    permissions: {
                        only: [M.DEVICE_MODEL_LIST]
                    }
                }
            }, {
                path: "prePostConditions",
                component: Is,
                data: {
                    tab_index: 4
                }
            }, {
                path: "accessories",
                component: Cs,
                canActivate: [z],
                data: {
                    tab_index: 5,
                    permissions: {
                        only: [M.ACCESSORY_LIST]
                    }
                }
            }, {
                path: "repairServices",
                component: Ts,
                canActivate: [z],
                data: {
                    tab_index: 6,
                    permissions: {
                        only: [M.REPAIR_SERVICE_LIST]
                    }
                }
            }, {
                path: "statuses",
                component: Ss,
                canActivate: [z],
                data: {
                    tab_index: 7,
                    permissions: {
                        only: [M.JOB_STATUS_LIST]
                    }
                }
            }, {
                path: "quickReply",
                component: vs,
                canActivate: [z],
                data: {
                    tab_index: 8,
                    permissions: {
                        only: [M.QUICK_REPLY_LIST]
                    }
                }
            }, {
                path: "storageLocations",
                component: Ms,
                canActivate: [z],
                data: {
                    tab_index: 9,
                    permissions: {
                        only: [M.STORAGE_LOCATION_LIST]
                    }
                }
            }, {
                path: "deviceColors",
                component: hs,
                canActivate: [z],
                data: {
                    tab_index: 10,
                    permissions: {
                        only: [M.DEVICE_COLOR_LIST]
                    }
                }
            }, {
                path: "jobSources",
                component: xs,
                canActivate: [z],
                data: {
                    tab_index: 11,
                    permissions: {
                        only: [M.JOB_STATUS_LIST]
                    }
                }
            }, {
                path: "jobTypes",
                component: ys,
                canActivate: [z],
                data: {
                    tab_index: 12,
                    permissions: {
                        only: [M.JOB_TYPE_LIST]
                    }
                }
            }, {
                path: "technicianCopySettings",
                component: ns,
                canActivate: [z],
                data: {
                    tab_index: 13,
                    permissions: {
                        only: [M.BUSINESS_SETTING_VIEW]
                    }
                }
            }, {
                path: "printOptionSettings",
                component: os,
                canActivate: [z],
                data: {
                    tab_index: 14,
                    permissions: {
                        only: [M.BUSINESS_SETTING_VIEW]
                    }
                }
            }, {
                path: "basicSettings",
                component: as,
                canActivate: [z],
                data: {
                    tab_index: 15,
                    permissions: {
                        only: [M.BUSINESS_SETTING_VIEW]
                    }
                }
            }, {
                path: "serviceOptions",
                component: ss,
                canActivate: [z],
                data: {
                    tab_index: 16,
                    permissions: {
                        only: [M.BUSINESS_SETTING_VIEW]
                    }
                }
            }, {
                path: "",
                redirectTo: "basicJobSettings",
                pathMatch: "full"
            }]
        }, {
            path: "technicianCopySettings",
            redirectTo: "jobSettings/technicianCopySettings",
            pathMatch: "full"
        }, {
            path: "printOptionSettings",
            redirectTo: "jobSettings/printOptionSettings",
            pathMatch: "full"
        }, {
            path: "serviceOptions",
            redirectTo: "jobSettings/serviceOptions",
            pathMatch: "full"
        }, {
            path: "jobOverview",
            component: Ps,
            canActivate: [z],
            data: {
                tab_index: 5,
                permissions: {
                    only: [M.REPORT_VIEW]
                }
            }
        }, {
            path: "add",
            component: oa,
            canActivate: [z, hn],
            data: {
                user_id: null,
                isCreate: !0,
                permissions: {
                    only: [M.JOB_WRITE]
                }
            },
            pathMatch: "full",
            title: "BytePhase Add Jobs/services in repairing/recovery business"
        }, {
            path: "add/bulk",
            component: Us,
            canActivate: [z, hn],
            data: {
                isCreate: !0,
                permissions: {
                    only: [M.JOB_WRITE]
                }
            },
            pathMatch: "full",
            title: "BytePhase Bulk Job | Create Multiple Jobs"
        }, {
            path: ":job_id/jobSheets",
            component: hl,
            canActivate: [z],
            data: {
                permissions: {
                    only: [M.JOB_WRITE, M.JOB_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Service | Jobsheet"
        }, {
            path: ":job_id/diagnosis",
            component: gl,
            canActivate: [z],
            data: {
                permissions: {
                    only: [M.JOB_WRITE, M.JOB_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Service | Diagnosis"
        }, {
            path: ":job_id/quotations",
            component: ca,
            canActivate: [z, ji],
            data: {
                permissions: {
                    only: [M.QUOTATION_WRITE, M.QUOTATION_APPROVE_OR_REJECT]
                },
                entity: I.QUOTATION
            },
            pathMatch: "full",
            title: "BytePhase Service | Quotations"
        }, {
            path: ":job_id/quotations/:quotation_id",
            component: ca,
            canActivate: [z, ji],
            data: {
                permissions: {
                    only: [M.QUOTATION_WRITE, M.QUOTATION_APPROVE_OR_REJECT]
                },
                entity: I.QUOTATION
            },
            pathMatch: "full",
            title: "BytePhase Service | Quotations"
        }, {
            path: ":job_id/invoices",
            component: la,
            canActivate: [z, ji],
            data: {
                permissions: {
                    only: [M.JOB_WRITE, M.JOB_LIST]
                },
                entity: I.JOB_INVOICE
            },
            pathMatch: "full",
            title: "BytePhase Service | Invoice"
        }, {
            path: ":job_id/invoices/:invoice_id",
            component: la,
            canActivate: [z, ji],
            data: {
                permissions: {
                    only: [M.JOB_WRITE, M.JOB_LIST]
                },
                entity: I.JOB_INVOICE
            },
            pathMatch: "full",
            title: "BytePhase Service | Invoice"
        }, {
            path: ":job_id/paymentReceipts/:payment_id",
            component: zr,
            pathMatch: "full",
            title: "BytePhase Service | Payment"
        }, {
            path: ":job_id/technicianCopy",
            component: ko,
            pathMatch: "full",
            title: "BytePhase Service | Payment"
        }, {
            path: ":job_id/deliveryReceipts/:delivery_id",
            component: ul,
            pathMatch: "full",
            title: "BytePhase Service | Delivery Challan"
        }, {
            path: ":job_id",
            component: oa,
            data: {
                user_id: null
            },
            children: [{
                path: "overview",
                component: _l,
                data: {
                    tab_index: 0
                },
                pathMatch: "full",
                title: "BytePhase Service | Overview"
            }, {
                path: "details",
                component: Io,
                data: {
                    tab_index: 1
                },
                title: "BytePhase Service | Details"
            }, {
                path: "comments",
                component: Ws,
                data: {
                    tab_index: 2
                },
                title: "BytePhase Service | Comments"
            }, {
                path: "payments",
                component: wo,
                data: {
                    tab_index: 3
                },
                title: "BytePhase Service | Payment List"
            }, {
                path: "deliveries",
                component: Hs,
                data: {
                    tab_index: 4
                },
                title: "BytePhase Service | Deliveries"
            }, {
                path: "servicesAndParts",
                component: Ki,
                data: {
                    tab_index: 5
                },
                title: "BytePhase Service | And Parts"
            }, {
                path: "backups",
                canActivate: [ji],
                component: Xr,
                data: {
                    tab_index: 6,
                    entity: I.BACKUP_DRIVE
                },
                title: "BytePhase Service | Backups"
            }, {
                path: "notes",
                component: Br,
                data: {
                    tab_index: 7,
                    notable_type: I.JOB.name
                },
                title: "BytePhase Service | Private Notes"
            }, {
                path: "pickupDrop",
                component: qr,
                data: {
                    tab_index: 8,
                    entity: I.PICKUP_DROP
                },
                title: "BytePhase Service | Pickup Drop"
            }, {
                path: "data-validation",
                component: kl,
                data: {
                    tab_index: 9
                },
                title: "BytePhase Service | Data Validation"
            }, {
                path: "",
                redirectTo: "overview",
                pathMatch: "full"
            }]
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }, {
            path: "**",
            redirectTo: "/errors/404"
        }]
    }],
    Nl = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = An({
                    type: t
                })
            }
            static {
                this.\u0275inj = kn({
                    imports: [vn.forChild(Hh), vn]
                })
            }
        }
        return t
    })();
var hO = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = An({
                type: t
            })
        }
        static {
            this.\u0275inj = kn({
                imports: [wa, ds, vn, Nl, Aa, en, $i]
            })
        }
    }
    return t
})();
export {
    Mo as a, ll as b, jo as c, Bt as d, Cl as e, di as f, hO as g
};