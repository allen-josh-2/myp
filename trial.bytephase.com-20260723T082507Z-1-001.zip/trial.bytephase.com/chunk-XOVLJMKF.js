import {
    $b as Z,
    Ga as Ee,
    Ma as Se,
    O as j,
    Pg as De,
    T as be,
    Ta as we,
    Va as $,
    Yb as Le,
    ab as Me,
    ba as xe,
    cb as Pe,
    g as he,
    ha as Y,
    hb as Ve,
    ka as Te,
    lb as Ne,
    m as Ce,
    ph as Ae,
    sa as ye,
    we as ke
} from "./chunk-DCKGQUHB.js";
import {
    $a as y,
    Ab as B,
    Ba as ue,
    Fa as l,
    Fb as A,
    Hb as F,
    Ib as h,
    Jb as V,
    Kb as P,
    Na as D,
    Oa as J,
    Pb as ne,
    Qb as ae,
    Rb as oe,
    Sa as K,
    Tc as _e,
    _a as T,
    aa as me,
    ba as q,
    cb as I,
    da as ce,
    db as H,
    ea as M,
    eb as _,
    fb as r,
    gb as o,
    gi as u,
    ha as C,
    hb as x,
    ia as f,
    mc as N,
    oc as k,
    pc as w,
    pd as fe,
    qa as b,
    qb as E,
    ra as O,
    sb as g,
    sd as ge,
    ub as d,
    ui as ve,
    vd as le,
    xk as m,
    yb as X,
    zb as W
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as L,
    b as G
} from "./chunk-FBFWB55K.js";
var z = "messageTemplates",
    Q = (() => {
        class n {
            constructor(e) {
                this.apiService = e
            }
            getListByQuery(e) {
                return this.apiService.getListByQuery(z, e)
            }
            get(e) {
                return this.apiService.get(`${z}/${e}`)
            }
            update(e, i) {
                return this.apiService.put(`${z}/${e}`, i)
            }
            getAvailableVariables(e) {
                return this.apiService.get(`templateVariables/forTemplate/${e}`)
            }
            testTemplate(e, i) {
                return this.apiService.post(`${z}/${e}/sendTest`, i)
            }
            duplicate(e) {
                return this.apiService.post(`${z}/${e}/duplicate`, {})
            }
            static {
                this.\u0275fac = function(i) {
                    return new(i || n)(ce(ve))
                }
            }
            static {
                this.\u0275prov = me({
                    token: n,
                    factory: n.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return n
    })();
var je = (n, s) => s.key;

function $e(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "dx-text-box", 12), g("onValueChanged", function(t) {
            C(e);
            let a = d(2);
            return f(a.email.set(t.value))
        }), o()
    }
    if (n & 2) {
        let e = d(2);
        _("value", e.email())("placeholder", e.formatMessage("enter_email_address"))("showClearButton", !0)
    }
}

function Re(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "app-mobile-number", 13), g("ngModelChange", function(t) {
            C(e);
            let a = d(2);
            return f(a.phone.set(t))
        })("mobileCountryCodeChange", function(t) {
            C(e);
            let a = d(2);
            return f(a.mobileCountryCode.set(t))
        }), o()
    }
    if (n & 2) {
        let e = d(2);
        _("ngModel", e.phone())("isEditMode", !0)
    }
}

function We(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "div", 8)(1, "label", 14), h(2), o(), r(3, "dx-text-box", 12), g("onValueChanged", function(t) {
            let a = C(e).$index,
                c = d(2);
            return f(c.updateVariableValue(a, t.value))
        }), o()()
    }
    if (n & 2) {
        let e = s.$implicit;
        l(2), V(e.label || e.syntax), l(), _("value", e.example)("placeholder", "Enter value for " + e.label)("showClearButton", !0)
    }
}

function Be(n, s) {
    n & 1 && (r(0, "div", 9), h(1, "No variables found in this template"), o())
}

function Fe(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "div", 2)(1, "div", 3), T(2, $e, 1, 3, "dx-text-box", 4)(3, Re, 1, 2, "app-mobile-number", 5), o(), r(4, "div", 6)(5, "div", 7), I(6, We, 4, 4, "div", 8, je, !1, Be, 2, 0, "div", 9), o()(), r(9, "div", 10)(10, "app-save-cancel-footer", 11), g("saveClick", function() {
            C(e);
            let t = d();
            return f(t.onSendTest())
        })("cancelClick", function() {
            C(e);
            let t = d();
            return f(t.onCloseModal())
        }), o()()()
    }
    if (n & 2) {
        let e = d();
        l(2), y(e.isEmailChannel() ? 2 : 3), l(4), H(e.editedVariables()), l(4), _("isOnPopup", !0)("isSaving", e.isSending())("isDisabled", e.isEmailChannel() ? !e.email() : !e.phone())("saveText", "send")("savingText", "sending")("cancelLabel", "cancel")("isVisibleHr", !1)("height", 40)
    }
}
var Ie = (() => {
    class n {
        constructor() {
            this.formatMessage = m, this.toastr = M(j), this.isVisible = w(!1), this.channelType = w(u.EMAIL), this.currentUserEmail = w(""), this.currentUserPhone = w(""), this.currentUserMobileCountryCode = w(null), this.variablesWithValues = w([]), this.isSending = w(!1), this.closeModal = k(), this.sendTest = k(), this.email = b(""), this.phone = b(""), this.mobileCountryCode = b(null), this.editedVariables = b([]), this.isEmailChannel = N(() => this.channelType() === u.EMAIL), this.popupTitle = N(() => {
                let e = this.channelType();
                return e === u.SMS ? m("send_test_sms") : e === u.WHATSAPP ? m("send_test_whatsapp") : m("send_test_email")
            }), O(() => {
                let e = this.currentUserEmail();
                e && this.email.set(e)
            }), O(() => {
                let e = this.currentUserPhone();
                e && this.phone.set(e)
            }), O(() => {
                let e = this.currentUserMobileCountryCode();
                e && this.mobileCountryCode.set(e)
            }), O(() => {
                let e = this.variablesWithValues();
                e ? .length && this.editedVariables.set(JSON.parse(JSON.stringify(e)))
            })
        }
        onSendTest() {
            if (this.isEmailChannel()) {
                let e = this.email().trim();
                if (!e) {
                    this.toastr.error(m("email_required"));
                    return
                }
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) {
                    this.toastr.error(m("please_enter_valid_email"));
                    return
                }
                this.sendTest.emit({
                    email: e,
                    variables: this.editedVariables()
                })
            } else {
                let e = this.phone().trim();
                if (!e) {
                    this.toastr.error(m("phone_number_required"));
                    return
                }
                this.sendTest.emit({
                    phone: e,
                    mobileCountryCode: this.mobileCountryCode(),
                    variables: this.editedVariables()
                })
            }
        }
        updateVariableValue(e, i) {
            let t = [...this.editedVariables()];
            t[e] = G(L({}, t[e]), {
                example: i
            }), this.editedVariables.set(t)
        }
        onCloseModal() {
            this.closeModal.emit()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || n)
            }
        }
        static {
            this.\u0275cmp = D({
                type: n,
                selectors: [
                    ["app-send-test-email"]
                ],
                inputs: {
                    isVisible: [1, "isVisible"],
                    channelType: [1, "channelType"],
                    currentUserEmail: [1, "currentUserEmail"],
                    currentUserPhone: [1, "currentUserPhone"],
                    currentUserMobileCountryCode: [1, "currentUserMobileCountryCode"],
                    variablesWithValues: [1, "variablesWithValues"],
                    isSending: [1, "isSending"]
                },
                outputs: {
                    closeModal: "closeModal",
                    sendTest: "sendTest"
                },
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    ["contentClass", "p-0", 3, "onHidden", "visible", "hideOnOutsideClick", "showCloseButton", "width", "height", "title"],
                    ["class", "d-flex flex-column h-100", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "flex-column", "h-100"],
                    [1, "px-3", "pb-3", "pt-1", "border-bottom", "flex-shrink-0"],
                    ["stylingMode", "outlined", 3, "value", "placeholder", "showClearButton"],
                    [3, "ngModel", "isEditMode"],
                    [1, "flex-grow-1", "overflow-auto", 2, "min-height", "0"],
                    [1, "row", "g-3", "p-3"],
                    [1, "col-6"],
                    [1, "col-12", "text-muted", "text-center", "py-3"],
                    [1, "border-top", "flex-shrink-0"],
                    [3, "saveClick", "cancelClick", "isOnPopup", "isSaving", "isDisabled", "saveText", "savingText", "cancelLabel", "isVisibleHr", "height"],
                    ["stylingMode", "outlined", 3, "onValueChanged", "value", "placeholder", "showClearButton"],
                    [3, "ngModelChange", "mobileCountryCodeChange", "ngModel", "isEditMode"],
                    [1, "form-label", "fw-semibold", "mb-1"]
                ],
                template: function(i, t) {
                    i & 1 && (r(0, "dx-popup", 0), g("onHidden", function() {
                        return t.onCloseModal()
                    }), K(1, Fe, 11, 10, "div", 1), o()), i & 2 && (_("visible", t.isVisible())("hideOnOutsideClick", !1)("showCloseButton", !0)("width", 650)("height", 450)("title", t.popupTitle()), l(), _("dxTemplateOf", "content"))
                },
                dependencies: [Pe, ke, Y, Me, $, he, Ce],
                encapsulation: 2
            })
        }
    }
    return n
})();
var Ge = ["htmlEditor"],
    qe = ["textEditor"],
    Je = (n, s) => s.name,
    Ke = (n, s) => s.syntax;

function Xe(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "div", 6)(1, "button", 17), g("click", function() {
            C(e);
            let t = d();
            return f(t.setMode("edit"))
        }), x(2, "i", 18), h(3, "Edit "), o(), r(4, "button", 17), g("click", function() {
            C(e);
            let t = d();
            return f(t.setMode("preview"))
        }), x(5, "i", 19), h(6, "Preview "), o()()
    }
    if (n & 2) {
        let e = d();
        l(), A("active", e.currentEditMode() === "edit"), l(3), A("active", e.currentEditMode() === "preview")
    }
}

function Ye(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "div")(1, "label", 14), h(2), o(), r(3, "dx-text-box", 20), oe("valueChange", function(t) {
            C(e);
            let a = d();
            return ae(a.template().subject, t) || (a.template().subject = t), f(t)
        }), o()()
    }
    if (n & 2) {
        let e = d();
        l(2), P(" ", e.formatMessage("subject_line"), " "), l(), ne("value", e.template().subject), _("placeholder", e.formatMessage("template_subject_placeholder"))("readOnly", !e.isEditMode() || e.currentEditMode() === "preview" || e.isSmsReadOnly())
    }
}

function Ze(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "dx-html-editor", 23, 0), g("onValueChanged", function(t) {
            C(e);
            let a = d(2);
            return f(a.onEditorValueChanged(t))
        }), r(2, "dxo-toolbar"), x(3, "dxi-item", 24)(4, "dxi-item", 25)(5, "dxi-item", 26)(6, "dxi-item", 27)(7, "dxi-item", 28)(8, "dxi-item", 29)(9, "dxi-item", 30)(10, "dxi-item", 31)(11, "dxi-item", 28)(12, "dxi-item", 32)(13, "dxi-item", 33)(14, "dxi-item", 28)(15, "dxi-item", 34)(16, "dxi-item", 28)(17, "dxi-item", 35), o()()
    }
    if (n & 2) {
        let e = d(2);
        _("value", e.editorContent())("height", 350)("readOnly", !e.isEditMode() || e.isSmsReadOnly())
    }
}

function et(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "dx-text-area", 36, 1), oe("valueChange", function(t) {
            C(e);
            let a = d(2);
            return ae(a.plainTextContent, t) || (a.plainTextContent = t), f(t)
        }), g("onValueChanged", function(t) {
            C(e);
            let a = d(2);
            return f(a.onPlainTextChanged(t))
        }), o()
    }
    if (n & 2) {
        let e = d(2);
        ne("value", e.plainTextContent), _("height", 350)("readOnly", !e.isEditMode() || e.isSmsReadOnly())("autoResizeEnabled", !1)
    }
}

function tt(n, s) {
    if (n & 1 && T(0, Ze, 18, 3, "dx-html-editor", 21)(1, et, 2, 4, "dx-text-area", 22), n & 2) {
        let e, i = d();
        y(((e = i.template()) == null || e.channel_type == null ? null : e.channel_type.toLowerCase()) === i.CHANNEL_EMAIL ? 0 : 1)
    }
}

function it(n, s) {
    if (n & 1 && x(0, "div", 37), n & 2) {
        let e = d(2);
        _("innerHTML", e.editorContent(), ue)
    }
}

function nt(n, s) {
    if (n & 1 && (r(0, "div", 38), h(1), o()), n & 2) {
        let e = d(2);
        l(), V(e.editorContent())
    }
}

function at(n, s) {
    if (n & 1 && T(0, it, 1, 1, "div", 37)(1, nt, 2, 1, "div", 38), n & 2) {
        let e, i = d();
        y(((e = i.template()) == null || e.channel_type == null ? null : e.channel_type.toLowerCase()) === i.CHANNEL_EMAIL ? 0 : 1)
    }
}

function ot(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "button", 48), g("click", function() {
            let t = C(e).$implicit,
                a = d(3);
            return f(a.insertVariable(t))
        }), h(1), o()
    }
    if (n & 2) {
        let e = s.$implicit,
            i = d(3);
        A("opacity-50", !i.isEditMode() || i.isSmsReadOnly())("pe-none", !i.isEditMode() || i.isSmsReadOnly()), _("disabled", !i.isEditMode() || i.isSmsReadOnly())("title", e.description), l(), P(" ", e.syntax, " ")
    }
}

function lt(n, s) {
    if (n & 1 && (r(0, "div", 44)(1, "span", 45), h(2), o(), r(3, "div", 46), I(4, ot, 2, 7, "button", 47, Ke), o()()), n & 2) {
        let e = s.$implicit;
        l(2), P(" ", e.name, " "), l(2), H(e.variables)
    }
}

function rt(n, s) {
    if (n & 1 && (r(0, "div", 15)(1, "div", 39), x(2, "i", 40), r(3, "span", 41), h(4, "Quick Variables"), o()(), r(5, "dx-scroll-view", 42)(6, "div", 43), I(7, lt, 6, 1, "div", 44, Je), o()()()), n & 2) {
        let e = d();
        l(7), H(e.variableGroups())
    }
}
var ee = (() => {
    class n {
        constructor() {
            this.formatMessage = m, this.toastr = M(j), this.templateService = M(Q), this.tenantService = M(Ne), this.userSession = M(xe), this.template = w(null), this.availableVariables = w([]), this.variableGroups = w([]), this.templateSaved = k(), this.templateDuplicated = k(), this.panelClose = k(), this.CHANNEL_EMAIL = u.EMAIL, this.CHANNEL_SMS = u.SMS, this.CHANNEL_WHATSAPP = u.WHATSAPP, this.CHANNEL_PUSH = u.PUSH, this.isSaving = b(!1), this.isTesting = b(!1), this.isDuplicating = b(!1), this.isEditMode = b(!1), this.showSendTestPopup = b(!1), this.originalTemplate = null, this.currentEditMode = b("edit"), this.editorContent = b(""), this.plainTextContent = "", this.isSmsReadOnly = N(() => this.tenantService.isIndia() && this.template() ? .channel_type ? .toLowerCase() === this.CHANNEL_SMS), this.usedVariables = N(() => {
                let e = this.editorContent() || "",
                    i = this.template() ? .subject || "",
                    t = e + " " + i;
                return this.availableVariables().filter(a => t.includes(a.syntax))
            }), O(() => {
                let e = this.template();
                if (e) {
                    let i = e.body_template || "";
                    e.channel_type ? .toLowerCase() !== this.CHANNEL_EMAIL && (i = this.stripHtmlTags(i)), this.editorContent.set(i), this.plainTextContent = i, this.originalTemplate = JSON.parse(JSON.stringify(e)), this.isEditMode.set(!1)
                }
            })
        }
        setMode(e) {
            this.currentEditMode.set(e)
        }
        onEditorValueChanged(e) {
            this.editorContent.set(e.value || "")
        }
        onPlainTextChanged(e) {
            this.plainTextContent = e.value || "", this.editorContent.set(this.plainTextContent)
        }
        onEditMode() {
            this.isEditMode.set(!0), this.currentEditMode.set("edit")
        }
        onCancelEdit() {
            if (this.isEditMode.set(!1), this.originalTemplate) {
                let e = this.originalTemplate.body_template || "";
                this.originalTemplate.channel_type ? .toLowerCase() !== this.CHANNEL_EMAIL && (e = this.stripHtmlTags(e)), this.editorContent.set(e), this.plainTextContent = e
            }
        }
        onClose() {
            this.panelClose.emit()
        }
        insertVariable(e) {
            if (!this.isEditMode() || this.isSmsReadOnly()) return;
            if (this.template() ? .channel_type ? .toLowerCase() !== this.CHANNEL_EMAIL) {
                this.plainTextContent = (this.plainTextContent || "") + e.syntax + " ", this.editorContent.set(this.plainTextContent);
                return
            }
            let t = this.htmlEditor ? .instance;
            if (t && e.syntax) {
                let a = t.getSelection() ? .index || 0;
                t.insertText(a, e.syntax + " ", {})
            }
        }
        updateEditorContent(e) {
            if (this.template() ? .channel_type ? .toLowerCase() !== this.CHANNEL_EMAIL) {
                let t = this.stripHtmlTags(e || "");
                this.editorContent.set(t), this.plainTextContent = t
            } else this.editorContent.set(e || "")
        }
        getTemplateDisplayName(e) {
            if (!e) return m("untitled_template");
            for (let i of [e.event_name, e.name, e.subject, e.event])
                if (i ? .trim() && i.toLowerCase() !== "n/a") return i.trim();
            return m("untitled_template")
        }
        saveTemplate() {
            let e = this.template();
            if (!e) return;
            let i = this.editorContent(),
                t = e.subject || "",
                a = this.validateVariables(t, i);
            if (!a.valid) {
                let p = [];
                a.invalidInSubject.length && p.push(`${m("invalid_variables_in_subject")}: ${a.invalidInSubject.map(v=>`{{${v}}}`).join(", ")}`), a.invalidInBody.length && p.push(`${m("invalid_variables_in_body")}: ${a.invalidInBody.map(v=>`{{${v}}}`).join(", ")}`), this.toastr.error(p.join("<br><br>"), m("validation_error"), {
                    timeOut: 1e4,
                    enableHtml: !0
                });
                return
            }
            this.isSaving.set(!0);
            let c = {
                subject: e.subject,
                body_html: i,
                is_enabled: e.is_enabled
            };
            this.templateService.update(e.id, c).subscribe({
                next: p => {
                    this.toastr.success(p.message || m("template_updated_successfully")), this.originalTemplate = JSON.parse(JSON.stringify(e)), this.isSaving.set(!1), this.isEditMode.set(!1), this.templateSaved.emit(c)
                },
                error: p => {
                    this.toastr.error(p.error ? .message || m("error_updating_template")), this.isSaving.set(!1)
                }
            })
        }
        duplicateTemplate() {
            let e = this.template();
            e && (this.isDuplicating.set(!0), this.templateService.duplicate(e.id).subscribe({
                next: () => {
                    this.toastr.success(m("template_duplicated_successfully")), this.isDuplicating.set(!1), this.templateDuplicated.emit()
                },
                error: i => {
                    this.toastr.error(i.error ? .message || m("error_duplicating_template")), this.isDuplicating.set(!1)
                }
            }))
        }
        sendTest() {
            if (!this.template() ? .id) {
                this.toastr.error(m("please_save_template_first"));
                return
            }
            if (this.isSmsReadOnly()) {
                this.toastr.warning(m("sms_test_disabled_dlt"));
                return
            }
            this.showSendTestPopup.set(!0)
        }
        onSendTest(e) {
            let i = this.template();
            if (!i ? .id) return;
            let t = i.channel_type ? .toLowerCase(),
                a = null;
            t === this.CHANNEL_WHATSAPP && (a = window.open("", "_blank")), this.isTesting.set(!0);
            let c = {
                body_html: this.editorContent()
            };
            if (t === this.CHANNEL_EMAIL ? (c.subject = i.subject || "", c.email = e.email) : (c.phone = e.phone, c.mobile_country_code = e.mobileCountryCode), e.variables ? .length) {
                let p = {};
                for (let v of e.variables) {
                    let S = v.syntax ? .replace(/\{\{|\}\}/g, "").trim();
                    S && v.example != null && (p[S] = v.example)
                }
                c.variables = p
            }
            this.templateService.testTemplate(i.id, c).subscribe({
                next: p => {
                    if (this.isTesting.set(!1), this.showSendTestPopup.set(!1), t === this.CHANNEL_WHATSAPP) {
                        let v = p.phone || e.phone,
                            S = p.body || "",
                            U = `https://api.whatsapp.com/send?phone=${v}&text=${encodeURIComponent(S)}`;
                        a ? a.location.href = U : window.open(U, "_blank"), this.toastr.success(m("whatsapp_message_opened"))
                    } else {
                        let v = t === this.CHANNEL_SMS ? "test_sms_sent" : "test_email_sent",
                            S = p.sent_to ? `${m(v)} (${p.sent_to})` : p.message || m("template_test_successful");
                        this.toastr.success(S)
                    }
                },
                error: p => {
                    this.isTesting.set(!1), a && a.close(), this.toastr.error(p.error ? .message || m("error_testing_template"))
                }
            })
        }
        onSendTestPopupClose() {
            this.showSendTestPopup.set(!1)
        }
        extractVariables(e) {
            if (!e) return [];
            let i = [],
                t, a = /\{\{([^}]+)\}\}/g;
            for (;
                (t = a.exec(e)) !== null;) i.push(t[1].trim());
            return i
        }
        validateVariables(e, i) {
            let t = this.availableVariables().map(p => p.syntax.replace(/\{\{|\}\}/g, "").trim()),
                a = this.extractVariables(e).filter(p => !t.includes(p)),
                c = this.extractVariables(i).filter(p => !t.includes(p));
            return {
                valid: !a.length && !c.length,
                invalidInSubject: a,
                invalidInBody: c
            }
        }
        stripHtmlTags(e) {
            let i = e.replace(/<br\s*\/?>/gi, `
`);
            i = i.replace(/<\/p>/gi, `

`), i = i.replace(/<[^>]+>/g, "");
            let t = document.createElement("textarea");
            return t.innerHTML = i, i = t.value, i = i.replace(/\n{3,}/g, `

`), i.trim()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || n)
            }
        }
        static {
            this.\u0275cmp = D({
                type: n,
                selectors: [
                    ["app-editor-panel"]
                ],
                viewQuery: function(i, t) {
                    if (i & 1 && X(Ge, 5)(qe, 5), i & 2) {
                        let a;
                        W(a = B()) && (t.htmlEditor = a.first), W(a = B()) && (t.textEditor = a.first)
                    }
                },
                inputs: {
                    template: [1, "template"],
                    availableVariables: [1, "availableVariables"],
                    variableGroups: [1, "variableGroups"]
                },
                outputs: {
                    templateSaved: "templateSaved",
                    templateDuplicated: "templateDuplicated",
                    panelClose: "panelClose"
                },
                standalone: !1,
                decls: 23,
                vars: 22,
                consts: [
                    ["htmlEditor", ""],
                    ["textEditor", ""],
                    [1, "d-flex", "flex-column", "h-100", 2, "background", "var(--primary-bg)"],
                    [1, "d-flex", "align-items-center", "flex-shrink-0", 2, "padding", "8px 14px", "border-bottom", "1px solid var(--theme-border-color)"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fw-semibold", 2, "font-size", "13px", "color", "var(--primary-text)"],
                    [1, "d-flex", "align-items-center", "border", "rounded-1", "overflow-hidden", 2, "border-color", "var(--theme-border-color) !important"],
                    [1, "d-flex", "flex-grow-1", 2, "min-height", "0"],
                    [1, "flex-grow-1", 2, "min-height", "0", "min-width", "0"],
                    [1, "d-flex", "flex-column", "gap-3", "p-3"],
                    [1, "d-flex", "align-items-center", "gap-2", "rounded", "p-2", 2, "background", "var(--bg-secondary)", "border", "1px solid var(--theme-border-color)"],
                    [1, "channel-badge"],
                    [1, "vr", 2, "opacity", "0.2"],
                    [1, "text-truncate", 2, "font-size", "12px", "color", "var(--primary-text)", "opacity", "0.7"],
                    [1, "form-label", "fw-semibold", "mb-1", 2, "font-size", "12px", "color", "var(--primary-text)"],
                    [1, "flex-shrink-0", "d-flex", "flex-column", 2, "width", "220px", "border-left", "1px solid var(--theme-border-color)"],
                    [3, "sendTest", "closeModal", "isVisible", "channelType", "currentUserEmail", "currentUserPhone", "currentUserMobileCountryCode", "variablesWithValues", "isSending"],
                    [1, "mode-btn", 3, "click"],
                    [1, "dx-icon-edit", "me-1"],
                    [1, "dx-icon-find", "me-1"],
                    ["stylingMode", "outlined", 3, "valueChange", "value", "placeholder", "readOnly"],
                    [3, "value", "height", "readOnly"],
                    [3, "value", "height", "readOnly", "autoResizeEnabled"],
                    [3, "onValueChanged", "value", "height", "readOnly"],
                    ["name", "bold"],
                    ["name", "italic"],
                    ["name", "underline"],
                    ["name", "strike"],
                    ["name", "separator"],
                    ["name", "alignLeft"],
                    ["name", "alignCenter"],
                    ["name", "alignRight"],
                    ["name", "orderedList"],
                    ["name", "bulletList"],
                    ["name", "link"],
                    ["name", "clear"],
                    [3, "valueChange", "onValueChanged", "value", "height", "readOnly", "autoResizeEnabled"],
                    [1, "border", "rounded", "p-3", 2, "background", "var(--bg-secondary)", "color", "var(--primary-text)", "border-color", "var(--theme-border-color) !important", "overflow-y", "auto", 3, "innerHTML"],
                    [1, "border", "rounded", "p-3", 2, "background", "var(--bg-secondary)", "color", "var(--primary-text)", "border-color", "var(--theme-border-color) !important", "overflow-y", "auto", "white-space", "pre-wrap"],
                    [1, "d-flex", "align-items-center", "gap-1", "flex-shrink-0", 2, "padding", "8px 10px", "border-bottom", "1px solid var(--theme-border-color)"],
                    [1, "fa", "fa-code", 2, "font-size", "10px", "color", "var(--primary-text)"],
                    [1, "fw-semibold", 2, "font-size", "11px", "color", "var(--primary-text)"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [1, "d-flex", "flex-column", "gap-1", "p-2"],
                    [1, "mb-1"],
                    [1, "fw-semibold", "d-block", "mb-1", 2, "font-size", "10px", "color", "var(--primary-text)", "text-transform", "uppercase"],
                    [1, "d-flex", "flex-wrap", "gap-1"],
                    [1, "variable-chip", 3, "opacity-50", "pe-none", "disabled", "title"],
                    [1, "variable-chip", 3, "click", "disabled", "title"]
                ],
                template: function(i, t) {
                    if (i & 1 && (r(0, "div", 2)(1, "div", 3)(2, "div", 4)(3, "span", 5), h(4, "Edit Template"), o(), T(5, Xe, 7, 4, "div", 6), o()(), r(6, "div", 7)(7, "dx-scroll-view", 8)(8, "div", 9)(9, "div", 10)(10, "span", 11), h(11), o(), x(12, "div", 12), r(13, "span", 13), h(14), o()(), T(15, Ye, 4, 4, "div"), r(16, "div")(17, "label", 14), h(18), o(), T(19, tt, 2, 1)(20, at, 2, 1), o()()(), T(21, rt, 9, 0, "div", 15), o(), r(22, "app-send-test-email", 16), g("sendTest", function(c) {
                            return t.onSendTest(c)
                        })("closeModal", function() {
                            return t.onSendTestPopupClose()
                        }), o()()), i & 2) {
                        let a, c, p, v, S, U, ie, se, de, pe;
                        l(5), y(!t.isSmsReadOnly() && t.isEditMode() ? 5 : -1), l(5), A("email", ((a = t.template()) == null || a.channel_type == null ? null : a.channel_type.toLowerCase()) === t.CHANNEL_EMAIL)("sms", ((c = t.template()) == null || c.channel_type == null ? null : c.channel_type.toLowerCase()) === t.CHANNEL_SMS)("whatsapp", ((p = t.template()) == null || p.channel_type == null ? null : p.channel_type.toLowerCase()) === t.CHANNEL_WHATSAPP)("push", ((v = t.template()) == null || v.channel_type == null ? null : v.channel_type.toLowerCase()) === t.CHANNEL_PUSH), l(), P(" ", (S = t.template()) == null || S.channel_type == null ? null : S.channel_type.toUpperCase(), " "), l(3), P(" ", t.template() ? t.getTemplateDisplayName(t.template()) : "", " "), l(), y(((U = t.template()) == null || U.channel_type == null ? null : U.channel_type.toLowerCase()) === t.CHANNEL_EMAIL ? 15 : -1), l(3), P(" ", t.formatMessage("message_content"), " "), l(), y(t.currentEditMode() === "edit" ? 19 : 20), l(2), y(t.currentEditMode() === "edit" && t.variableGroups().length > 0 ? 21 : -1), l(), _("isVisible", t.showSendTestPopup())("channelType", ((ie = t.template()) == null || ie.channel_type == null ? null : ie.channel_type.toLowerCase()) || "email")("currentUserEmail", ((se = t.userSession.currentUser()) == null ? null : se.email) || "")("currentUserPhone", ((de = t.userSession.currentUser()) == null ? null : de.mobile_number) || "")("currentUserMobileCountryCode", (pe = t.userSession.currentUser()) == null ? null : pe.mobile_country_code)("variablesWithValues", t.usedVariables())("isSending", t.isTesting())
                    }
                },
                dependencies: [ye, Ee, Le, Z, Ve, $, Ie],
                styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}.mode-btn[_ngcontent-%COMP%]{display:inline-flex;align-items:center;padding:3px 10px;border:none;background:transparent;color:var(--primary-text);font-size:11px;cursor:pointer;transition:all .15s ease;opacity:.5}.mode-btn[_ngcontent-%COMP%]:not(:last-child){border-right:1px solid var(--theme-border-color)}.mode-btn.active[_ngcontent-%COMP%]{background-color:#3498db1a;color:#3498db;opacity:1;font-weight:600}.mode-btn[_ngcontent-%COMP%]:hover:not(.active){opacity:.8}.channel-badge[_ngcontent-%COMP%]{display:inline-block;padding:2px 8px;border-radius:3px;font-size:10px;font-weight:600;text-transform:uppercase}.channel-badge.email[_ngcontent-%COMP%]{background-color:#3498db1a;color:#3498db}.channel-badge.sms[_ngcontent-%COMP%]{background-color:#1987541a;color:#198754}.channel-badge.whatsapp[_ngcontent-%COMP%]{background-color:#479d7b1a;color:#479d7b}.channel-badge.push[_ngcontent-%COMP%]{background-color:#ffc10726;color:#ba8b00}.variable-chip[_ngcontent-%COMP%]{display:inline-block;padding:3px 8px;border:1px solid rgba(52,152,219,.4);border-radius:12px;background:#3498db14;color:#3498db;font-family:Courier New,monospace;font-size:11px;cursor:pointer;transition:all .15s ease}.variable-chip[_ngcontent-%COMP%]:hover{background-color:#3498db2e;border-color:#3498db}"]
            })
        }
    }
    return n
})();

function dt(n, s) {
    if (n & 1 && (r(0, "div", 4), h(1), o()), n & 2) {
        let e = d();
        l(), V(e.template().description)
    }
}
var te = class n {
    constructor() {
        this.formatMessage = m, this.template = w.required(), this.isSelected = w(!1), this.cardClicked = k(), this.CHANNEL_EMAIL = u.EMAIL, this.CHANNEL_SMS = u.SMS, this.CHANNEL_WHATSAPP = u.WHATSAPP, this.CHANNEL_PUSH = u.PUSH
    }
    static {
        this.CHANNEL_ICONS = {
            [u.EMAIL]: "fa fa-envelope",
            [u.SMS]: "fa fa-comment",
            [u.WHATSAPP]: "fab fa-whatsapp",
            [u.PUSH]: "fa fa-bell"
        }
    }
    onClick() {
        this.cardClicked.emit(this.template())
    }
    getChannelIcon() {
        return n.CHANNEL_ICONS[this.template() ? .channel_type ? .toLowerCase()] || "fa fa-file"
    }
    getChannelLabel() {
        return (this.template() ? .channel_type || "unknown").toUpperCase()
    }
    getDisplayName() {
        let s = this.template();
        if (!s) return m("untitled_template");
        for (let e of [s.event_name, s.name, s.subject, s.event])
            if (e ? .trim() && e.toLowerCase() !== "n/a") return e.trim();
        return m("untitled_template")
    }
    getBodyPreview() {
        let e = (this.template() ? .body_template || "").replace(/<[^>]*>/g, "").trim();
        return e.length > 80 ? e.substring(0, 80) + "..." : e
    }
    getModifiedDate() {
        let s = this.template() ? .updated_at;
        return s ? new Date(s).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric"
        }) : ""
    }
    static {
        this.\u0275fac = function(e) {
            return new(e || n)
        }
    }
    static {
        this.\u0275cmp = D({
            type: n,
            selectors: [
                ["app-template-card"]
            ],
            inputs: {
                template: [1, "template"],
                isSelected: [1, "isSelected"]
            },
            outputs: {
                cardClicked: "cardClicked"
            },
            standalone: !1,
            decls: 13,
            vars: 17,
            consts: [
                [1, "template-card", 3, "click"],
                [1, "d-flex", "align-items-center"],
                [1, "channel-badge"],
                [1, "fw-semibold", "text-truncate", "mt-1", 2, "font-size", "12px", "color", "var(--primary-text)", "line-height", "1.3"],
                [1, "text-muted", "text-truncate", 2, "font-size", "11px"],
                [1, "card-preview", "text-muted", "mt-1"],
                [1, "text-muted", 2, "font-size", "10px", "margin-top", "2px"],
                [1, "fa", "fa-clock-o", "me-1"]
            ],
            template: function(e, i) {
                if (e & 1 && (r(0, "div", 0), g("click", function() {
                        return i.onClick()
                    }), r(1, "div", 1)(2, "span", 2), x(3, "i"), h(4), o()(), r(5, "div", 3), h(6), o(), T(7, dt, 2, 1, "div", 4), r(8, "div", 5), h(9), o(), r(10, "div", 6), x(11, "i", 7), h(12), o()()), e & 2) {
                    let t, a, c, p, v;
                    A("selected", i.isSelected()), l(2), A("email", ((t = i.template()) == null || t.channel_type == null ? null : t.channel_type.toLowerCase()) === i.CHANNEL_EMAIL)("sms", ((a = i.template()) == null || a.channel_type == null ? null : a.channel_type.toLowerCase()) === i.CHANNEL_SMS)("whatsapp", ((c = i.template()) == null || c.channel_type == null ? null : c.channel_type.toLowerCase()) === i.CHANNEL_WHATSAPP)("push", ((p = i.template()) == null || p.channel_type == null ? null : p.channel_type.toLowerCase()) === i.CHANNEL_PUSH), l(), F(i.getChannelIcon()), l(), P(" ", i.getChannelLabel(), " "), l(2), V(i.getDisplayName()), l(), y((v = i.template()) != null && v.description ? 7 : -1), l(2), V(i.getBodyPreview()), l(3), P("", i.getModifiedDate(), " ")
                }
            },
            styles: ["[_nghost-%COMP%]{display:block}.template-card[_ngcontent-%COMP%]{background:var(--primary-bg);border:1px solid var(--theme-border-color);border-radius:5px;padding:8px 10px;cursor:pointer;transition:all .15s ease}.template-card[_ngcontent-%COMP%]:hover{border-color:#3498db;box-shadow:0 1px 3px #0000000f}.template-card.selected[_ngcontent-%COMP%]{border-color:#3498db;border-width:2px;padding:7px 9px;background:#3498db08}.template-card[_ngcontent-%COMP%]   .channel-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:3px;padding:1px 5px;border-radius:3px;font-size:9px;font-weight:600;text-transform:uppercase}.template-card[_ngcontent-%COMP%]   .channel-badge.email[_ngcontent-%COMP%]{background-color:#3498db1a;color:#3498db}.template-card[_ngcontent-%COMP%]   .channel-badge.sms[_ngcontent-%COMP%]{background-color:#1987541a;color:#198754}.template-card[_ngcontent-%COMP%]   .channel-badge.whatsapp[_ngcontent-%COMP%]{background-color:#479d7b1a;color:#479d7b}.template-card[_ngcontent-%COMP%]   .channel-badge.push[_ngcontent-%COMP%]{background-color:#ffc10726;color:#ba8b00}.template-card[_ngcontent-%COMP%]   .card-preview[_ngcontent-%COMP%]{font-size:11px;line-height:1.3;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}"]
        })
    }
};
var mt = (n, s) => s.id;

function ct(n, s) {
    if (n & 1 && (r(0, "div")(1, "div", 18), x(2, "i", 19), r(3, "span"), h(4), o()()()), n & 2) {
        let e = s.$implicit;
        l(2), F(e.icon), l(2), V(e.label)
    }
}

function ut(n, s) {
    if (n & 1 && (r(0, "div")(1, "div", 20), x(2, "i", 19)(3, "dx-text-box", 21), o()()), n & 2) {
        let e = s.$implicit;
        l(2), F(e == null ? null : e.icon), l(), _("value", e == null ? null : e.label)("readOnly", !0)
    }
}

function _t(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "app-dx-outline-button", 24), g("onClickEvent", function() {
            C(e);
            let t = d(2);
            return f(t.onTemplateCancelEdit())
        }), o(), r(1, "app-dx-outline-button", 25), g("onClickEvent", function() {
            C(e);
            let t = d(2);
            return f(t.editorPanel == null ? null : t.editorPanel.saveTemplate())
        }), o()
    }
    if (n & 2) {
        let e = d(2);
        _("disabled", e.editorPanel == null ? null : e.editorPanel.isSaving()), l(), _("isVisibleIcon", !0)("disabled", e.editorPanel == null ? null : e.editorPanel.isSaving())
    }
}

function ht(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "app-dx-outline-button", 26), g("onClickEvent", function() {
            C(e);
            let t = d(2);
            return f(t.editorPanel == null ? null : t.editorPanel.onEditMode())
        }), o()
    }
}

function Ct(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "div", 9)(1, "app-dx-outline-button", 22), g("onClickEvent", function() {
            C(e);
            let t = d();
            return f(t.editorPanel == null ? null : t.editorPanel.sendTest())
        }), o(), T(2, _t, 2, 3)(3, ht, 1, 0, "app-dx-outline-button", 23), o()
    }
    if (n & 2) {
        let e = d();
        l(), _("text", e.isMobileDevice() ? "send_test" : "send_test_message")("title", e.isMobileDevice() ? "send_test" : "send_test_message")("isVisibleIcon", !0), l(), y(e.editorPanel != null && e.editorPanel.isEditMode() ? 2 : e.editorPanel != null && e.editorPanel.isSmsReadOnly() ? -1 : 3)
    }
}

function ft(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "app-template-card", 27), g("cardClicked", function(t) {
            C(e);
            let a = d();
            return f(a.onCardClick(t))
        }), o()
    }
    if (n & 2) {
        let e, i = s.$implicit,
            t = d();
        _("template", i)("isSelected", ((e = t.selectedTemplate()) == null ? null : e.id) === i.id)
    }
}

function gt(n, s) {
    if (n & 1 && h(0), n & 2) {
        let e = d(2);
        P(' No templates matching "', e.searchQuery(), '" ')
    }
}

function bt(n, s) {
    n & 1 && h(0, " No templates found ")
}

function vt(n, s) {
    if (n & 1 && (r(0, "div", 15), x(1, "i", 28), r(2, "p", 29), T(3, gt, 1, 1)(4, bt, 1, 0), o()()), n & 2) {
        let e = d();
        l(3), y(e.searchQuery() ? 3 : 4)
    }
}

function xt(n, s) {
    if (n & 1) {
        let e = E();
        r(0, "div", 16)(1, "app-editor-panel", 30), g("templateSaved", function(t) {
            C(e);
            let a = d();
            return f(a.onTemplateSave(t))
        })("templateDuplicated", function() {
            C(e);
            let t = d();
            return f(t.onTemplateDuplicated())
        })("panelClose", function() {
            C(e);
            let t = d();
            return f(t.onPanelClose())
        }), o()()
    }
    if (n & 2) {
        let e = d();
        l(), _("template", e.selectedTemplate())("availableVariables", e.availableVariables())("variableGroups", e.variableGroups())
    }
}
var re = (() => {
    class n {
        constructor() {
            this.formatMessage = m, this.route = M(fe), this.router = M(ge), this.templateService = M(Q), this.toastr = M(j), this.sidebarService = M(De), this.previousSidebarState = !1, this.isMobileDevice = M(be).isMobileDevice, this.allTemplates = b([]), this.selectedTemplate = b(null), this.isLoading = b(!1), this.availableVariables = b([]), this.variableGroups = b([]), this.selectedCategory = b(u.EMAIL), this.searchQuery = b(""), this.editPanelOpen = b(!1), this.categories = [{
                key: u.EMAIL,
                label: "Email",
                icon: "fa-thin fa-envelope"
            }, {
                key: u.SMS,
                label: "SMS",
                icon: "fa-thin fa-comment"
            }, {
                key: u.WHATSAPP,
                label: "WhatsApp",
                icon: "fab fa-whatsapp"
            }, {
                key: u.PUSH,
                label: "Push",
                icon: "fa-thin fa-bell"
            }], this.filteredTemplates = N(() => {
                let e = this.allTemplates(),
                    i = this.selectedCategory(),
                    t = this.searchQuery().toLowerCase().trim();
                return e = e.filter(a => a.channel_type ? .toLowerCase() === i), t && (e = e.filter(a => (a.name || "").toLowerCase().includes(t) || (a.subject || "").toLowerCase().includes(t) || (a.event_name || "").toLowerCase().includes(t) || (a.description || "").toLowerCase().includes(t) || (a.body_template || "").toLowerCase().includes(t))), e
            }), this.categoryCounts = N(() => {
                let e = this.allTemplates();
                return {
                    email: e.filter(i => i.channel_type ? .toLowerCase() === u.EMAIL).length,
                    sms: e.filter(i => i.channel_type ? .toLowerCase() === u.SMS).length,
                    whatsapp: e.filter(i => i.channel_type ? .toLowerCase() === u.WHATSAPP).length,
                    push: e.filter(i => i.channel_type ? .toLowerCase() === u.PUSH).length
                }
            }), this.isSearching = N(() => this.searchQuery().length > 0)
        }
        ngOnInit() {
            this.previousSidebarState = this.sidebarService.sidebarExpanded.getValue(), this.previousSidebarState && this.sidebarService.sidebarExpanded.next(!1), this.loadData()
        }
        ngOnDestroy() {
            this.previousSidebarState && this.sidebarService.sidebarExpanded.next(!0)
        }
        loadData() {
            this.isLoading.set(!0);
            let e = this.route.snapshot.queryParams.template ? parseInt(this.route.snapshot.queryParams.template, 10) : null;
            this.templateService.getListByQuery({
                paginate: "false"
            }).subscribe({
                next: i => {
                    if (this.allTemplates.set(Array.isArray(i) ? i : i.data || []), e) {
                        let t = this.allTemplates().find(a => a.id === e);
                        t && this.onCardClick(t)
                    } else {
                        let t = this.filteredTemplates()[0];
                        t && this.onCardClick(t)
                    }
                    this.isLoading.set(!1)
                },
                error: i => {
                    this.toastr.error(i.error ? .message || m("error_loading_templates")), this.isLoading.set(!1)
                }
            })
        }
        onCardClick(e) {
            this.selectedTemplate.set(e), this.editPanelOpen.set(!0), this.loadAvailableVariables(e.id), this.router.navigate([], {
                relativeTo: this.route,
                queryParams: {
                    template: e.id
                },
                queryParamsHandling: "merge",
                replaceUrl: !0
            })
        }
        loadAvailableVariables(e) {
            this.templateService.getAvailableVariables(e).subscribe({
                next: i => {
                    let t = [],
                        a = [];
                    Object.entries(i).forEach(([c, p]) => {
                        if (Array.isArray(p) && p.length > 0) {
                            let v = p.map(S => ({
                                label: S.variable_label,
                                description: S.variable_description,
                                syntax: `{{${S.variable_key}}}`,
                                example: S.sample_value
                            }));
                            t.push(...v), a.push({
                                name: c,
                                variables: v
                            })
                        }
                    }), this.availableVariables.set(t), this.variableGroups.set(a)
                },
                error: () => {
                    this.toastr.error(m("error_loading_variables")), this.availableVariables.set([]), this.variableGroups.set([])
                }
            })
        }
        onCategoryClick(e) {
            this.selectedCategory.set(e);
            let i = this.filteredTemplates()[0];
            i ? this.onCardClick(i) : (this.selectedTemplate.set(null), this.editPanelOpen.set(!1))
        }
        onSearchChange(e) {
            this.searchQuery.set(e)
        }
        getCategoryCount(e) {
            return this.categoryCounts()[e] || 0
        }
        onPanelClose() {
            this.editPanelOpen.set(!1), this.selectedTemplate.set(null)
        }
        onTemplateCancelEdit() {
            this.editorPanel ? .onCancelEdit();
            let e = this.allTemplates().find(i => i.id === this.selectedTemplate() ? .id);
            e && this.selectedTemplate.set(L({}, e))
        }
        onTemplateSave(e) {
            let i = G(L({}, e), {
                    body_template: e.body_html
                }),
                t = this.allTemplates(),
                a = t.findIndex(c => c.id === this.selectedTemplate() ? .id);
            a !== -1 && (t[a] = L(L({}, t[a]), i), this.allTemplates.set([...t])), this.selectedTemplate() && this.selectedTemplate.set(L(L({}, this.selectedTemplate()), i))
        }
        onTemplateDuplicated() {
            this.loadData()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || n)
            }
        }
        static {
            this.\u0275cmp = D({
                type: n,
                selectors: [
                    ["app-template-editor"]
                ],
                viewQuery: function(i, t) {
                    if (i & 1 && X(ee, 5), i & 2) {
                        let a;
                        W(a = B()) && (t.editorPanel = a.first)
                    }
                },
                standalone: !1,
                decls: 21,
                vars: 16,
                consts: [
                    [1, "d-flex", "flex-column", "vh-100", 2, "background", "var(--bg-secondary)"],
                    [1, "d-flex", "align-items-center", "gap-2", "flex-shrink-0", 2, "padding", "6px 12px", "background", "var(--primary-bg)", "border-bottom", "1px solid var(--theme-border-color)", "position", "sticky", "top", "0", "z-index", "10"],
                    [1, "fa", "fa-bolt", "text-warning", 2, "font-size", "13px"],
                    [1, "fw-semibold", "flex-shrink-0", 2, "font-size", "13px"],
                    [1, "vr", "mx-1", 2, "opacity", "0.2"],
                    ["placeholder", "Search templates...", "mode", "search", "stylingMode", "outlined", "valueChangeEvent", "input", 2, "width", "200px", "min-width", "140px", 3, "onValueChanged", "showClearButton", "value"],
                    ["displayExpr", "label", "valueExpr", "key", "stylingMode", "outlined", "fieldTemplate", "fieldTpl", 2, "width", "170px", "min-width", "150px", 3, "onValueChanged", "items", "value", "searchEnabled", "showClearButton"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "flex-grow-1"],
                    [1, "d-flex", "align-items-center", "gap-1"],
                    [1, "d-flex", "flex-grow-1", 2, "min-height", "0"],
                    [1, "d-flex", "flex-column", "flex-shrink-0", 2, "width", "350px", "border-right", "1px solid var(--theme-border-color)"],
                    [1, "flex-grow-1", 2, "min-height", "0"],
                    [1, "d-flex", "flex-column", "gap-1", "p-2"],
                    [3, "template", "isSelected"],
                    [1, "d-flex", "flex-column", "align-items-center", "justify-content-center", "py-5"],
                    [1, "flex-grow-1", "overflow-hidden", 2, "min-width", "0"],
                    [3, "visible", "showIndicator", "showPane", "shading", "message"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [2, "font-size", "16px", "width", "20px", "text-align", "center"],
                    [1, "d-flex", "align-items-center", "gap-2", 2, "padding", "0 8px"],
                    ["stylingMode", "underlined", 1, "flex-grow-1", 2, "margin", "-1px 0", 3, "value", "readOnly"],
                    ["icon", "email", 3, "onClickEvent", "text", "title", "isVisibleIcon"],
                    ["text", "common_edit", "title", "common_edit", "buttonType", "default"],
                    ["text", "cancel", "title", "cancel", "buttonType", "danger", 3, "onClickEvent", "disabled"],
                    ["text", "common_save", "title", "common_save", "icon", "save", "buttonType", "default", 3, "onClickEvent", "isVisibleIcon", "disabled"],
                    ["text", "common_edit", "title", "common_edit", "buttonType", "default", 3, "onClickEvent"],
                    [3, "cardClicked", "template", "isSelected"],
                    [1, "fa", "fa-inbox", "text-muted", 2, "font-size", "36px"],
                    [1, "text-muted", "mt-2", "small", "mb-0"],
                    [3, "templateSaved", "templateDuplicated", "panelClose", "template", "availableVariables", "variableGroups"]
                ],
                template: function(i, t) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1), x(2, "i", 2), r(3, "span", 3), h(4, "Notification Templates"), o(), x(5, "div", 4), r(6, "dx-text-box", 5), g("onValueChanged", function(c) {
                        return t.onSearchChange(c.value)
                    }), o(), r(7, "dx-select-box", 6), g("onValueChanged", function(c) {
                        return t.onCategoryClick(c.value)
                    }), K(8, ct, 5, 3, "div", 7)(9, ut, 4, 4, "div", 7), o(), x(10, "div", 8), T(11, Ct, 4, 4, "div", 9), o(), r(12, "div", 10)(13, "div", 11)(14, "dx-scroll-view", 12)(15, "div", 13), I(16, ft, 1, 2, "app-template-card", 14, mt), T(18, vt, 5, 1, "div", 15), o()()(), T(19, xt, 2, 3, "div", 16), o(), x(20, "dx-load-panel", 17), o()), i & 2 && (l(6), _("showClearButton", !0)("value", t.searchQuery()), l(), _("items", t.categories)("value", t.selectedCategory())("searchEnabled", !1)("showClearButton", !1), l(), _("dxTemplateOf", "item"), l(), _("dxTemplateOf", "fieldTpl"), l(2), y(t.editPanelOpen() && t.selectedTemplate() ? 11 : -1), l(5), H(t.filteredTemplates()), l(2), y(t.filteredTemplates().length === 0 && !t.isLoading() ? 18 : -1), l(), y(t.editPanelOpen() && t.selectedTemplate() ? 19 : -1), l(), _("visible", t.isLoading())("showIndicator", !0)("showPane", !0)("shading", !0)("message", t.formatMessage("loading")))
                },
                dependencies: [Te, Y, Se, Z, we, $, ee, te],
                styles: ["[_nghost-%COMP%]{display:block;height:100%;width:100%}"]
            })
        }
    }
    return n
})();
var Tt = [{
        path: "",
        component: re
    }, {
        path: ":id",
        component: re
    }],
    He = (() => {
        class n {
            static {
                this.\u0275fac = function(i) {
                    return new(i || n)
                }
            }
            static {
                this.\u0275mod = J({
                    type: n
                })
            }
            static {
                this.\u0275inj = q({
                    imports: [le.forChild(Tt), le]
                })
            }
        }
        return n
    })();
var Hi = (() => {
    class n {
        static {
            this.\u0275fac = function(i) {
                return new(i || n)
            }
        }
        static {
            this.\u0275mod = J({
                type: n
            })
        }
        static {
            this.\u0275inj = q({
                imports: [_e, Ae, He]
            })
        }
    }
    return n
})();
export {
    Hi as TemplateModule
};