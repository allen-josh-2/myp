import {
    a as $t
} from "./chunk-MBAKXBI4.js";
import {
    Ab as _t,
    Db as le,
    Ec as xt,
    Fa as at,
    Fg as Qt,
    Gd as Vt,
    Gg as zt,
    Hc as bt,
    Hd as Nt,
    Ia as ot,
    Jb as ht,
    Je as Ut,
    Kb as Ct,
    Kd as wt,
    Ke as Gt,
    L as Ye,
    Lb as ft,
    M as W,
    Mb as yt,
    Md as Rt,
    Nd as Lt,
    Of as qt,
    Qb as vt,
    Qd as Ot,
    Qe as Ht,
    Qf as H,
    Sf as Yt,
    T as te,
    Ta as rt,
    Ue as Bt,
    Va as st,
    Vb as St,
    We as jt,
    Xa as lt,
    Y as ne,
    Zc as Et,
    Zd as kt,
    _b as Pt,
    _d as V,
    aa as tt,
    ba as G,
    ca as ae,
    cb as pt,
    cc as pe,
    cd as It,
    df as de,
    e as Y,
    ed as me,
    g as Le,
    gf as ue,
    h as Oe,
    ha as it,
    jb as ct,
    jc as Tt,
    jd as Mt,
    ka as oe,
    la as nt,
    lb as se,
    mb as mt,
    n as ke,
    pb as dt,
    pe as Ft,
    ph as Xt,
    qd as Dt,
    r as Fe,
    rd as At,
    sb as ut,
    t as Ue,
    u as Ge,
    x as He,
    xb as Se,
    xc as ce,
    xg as Wt,
    y as Be,
    yc as gt
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    Ab as w,
    Ak as re,
    Ba as z,
    Ca as he,
    Ec as we,
    Fa as n,
    Fh as g,
    Hg as ze,
    Hh as Xe,
    Ib as b,
    Jb as k,
    Ka as P,
    Kb as $,
    Lb as Ve,
    Lh as T,
    Na as x,
    Oa as X,
    Pb as Z,
    Qb as K,
    Rb as J,
    Rd as We,
    Sa as L,
    Sd as Qe,
    Tc as Re,
    Wa as Ie,
    Wb as j,
    Yh as ie,
    Zg as M,
    _a as d,
    _b as F,
    aa as be,
    af as fe,
    ai as $e,
    ba as Q,
    bb as Me,
    bc as q,
    bi as Ze,
    cb as De,
    da as Ee,
    db as Ae,
    ea as h,
    eb as o,
    fb as p,
    fi as Ke,
    gb as l,
    gc as I,
    ha as C,
    hb as m,
    hi as D,
    ia as f,
    ic as A,
    ii as ve,
    jc as Ne,
    n as ge,
    pd as U,
    qa as _e,
    qb as v,
    qd as je,
    sb as y,
    sd as ee,
    td as qe,
    th as ye,
    ti as Je,
    ub as s,
    ui as et,
    vd as Ce,
    xk as _,
    yb as O,
    z as xe,
    zb as N
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var E = class {
    constructor(r) {
        return Object.assign(this, r)
    }
    static getForm(r) {
        return new He().group({
            id: [r.id || null],
            purchase_number: [r.purchase_number || null],
            party_invoice_number: [r.party_invoice_number || null],
            part_supplier_id: [r.part_supplier_id || null, [Y.required]],
            purchase_date: [r.purchase_date || new Date],
            due_date: [r.due_date || null],
            status: [r.status || "Paid"],
            term_and_condition: [r.term_and_condition || null],
            attachments: [r.attachments || []],
            auto_round_off: [r.auto_round_off || !1]
        })
    }
};
var B = (() => {
    class t extends Je {
        constructor(e) {
            super(e, fe), this.api = e, this.endpoint = fe
        }
        exportToFile(e, a) {
            return this.api.exportToFile(this.endpoint + "/" + e, a)
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || t)(Ee(et))
            }
        }
        static {
            this.\u0275prov = be({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var si = (t, r, e) => ({
    paymentable_id: t,
    paymentable_type: r,
    customer_id: e
});

function li(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-add-payment-popup", 2), y("addPaymentClose", function() {
            C(e);
            let i = s();
            return f(i.isVisiblePopup = !1)
        })("addPaymentSave", function() {
            C(e);
            let i = s();
            return f(i.onSavePayment())
        }), l()
    }
    if (t & 2) {
        let e = s();
        o("amountRemaining", e.amountRemaining)("entityType", e.ENTITIES.PURCHASE.name)("isCreate", e.isCreate)("isVisiblePopup", e.isVisiblePopup)("payment", e.payment)
    }
}
var Kt = (() => {
    class t {
        constructor(e, a) {
            this.service = e, this.jobService = a, this.formatMessage = _, this.ENTITIES = D, this.paymentableId = null, this.paymentableType = this.ENTITIES.PURCHASE.name, this.isiVisibleTitle = !1, this.userSessionService = h(G), this.activatedRouter = h(U), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.isVisiblePopup = !1, this.isCreate = !1, this.entity = this.ENTITIES.PAYMENT, this.columns = [{
                dataField: "paymentable",
                caption: _("payment_against"),
                cellTemplate: "paymentableLinkTemplate",
                width: 140,
                allowSorting: !1
            }, {
                dataField: "amount",
                caption: _("common_amount"),
                width: 120,
                allowSorting: !1,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "payment_type.name",
                caption: _("payment_mode"),
                hidingPriority: 6,
                allowSorting: !1
            }, {
                dataField: "transaction_id",
                caption: _("common_transaction_id"),
                hidingPriority: 3,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "cheque_number",
                caption: _("payment_cheque_number"),
                hidingPriority: 1,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: _("common_created_by"),
                hidingPriority: 4,
                cellTemplate: "employeeTemplate",
                allowSorting: !1
            }, {
                dataField: "updated_user",
                caption: _("common_updated_by"),
                hidingPriority: 5,
                cellTemplate: "employeeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "comment",
                caption: _("common_comment"),
                hidingPriority: 2,
                cellTemplate: "commentTemplate",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: _("common_created_on"),
                hidingPriority: 0,
                allowSorting: !0,
                cellTemplate: "dateTimeTemplate"
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 7,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        ngOnInit() {
            this.entity.isVisibleSearchPanel = !1, this.paymentableId || (this.paymentableId = +this.activatedRouter.snapshot.parent.paramMap.get("purchase_id")), this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.jobService.paymentListReload$.subscribe({
                next: () => {
                    this.dataGrid && this.dataGrid.getData()
                },
                error: e => {
                    console.error("error fetching data ", e)
                }
            })
        }
        create() {
            this.isVisiblePopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.payment = e, this.isVisiblePopup = !0, this.amountRemaining = this.payment ? .paymentable ? .total_amount - this.payment ? .paymentable ? .paymentable_sum_amount
        }
        onSavePayment() {
            this.isCreate = !1, this.dataGrid.getData(), this.payment = null, this.isVisiblePopup = !1
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || t)(P(Bt), P(Et))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-purchase-payment-list"]
                ],
                viewQuery: function(a, i) {
                    if (a & 1 && O(V, 5), a & 2) {
                        let c;
                        N(c = w()) && (i.dataGrid = c.first)
                    }
                },
                inputs: {
                    paymentableId: "paymentableId",
                    paymentableType: "paymentableType",
                    isiVisibleTitle: "isiVisibleTitle"
                },
                standalone: !1,
                decls: 2,
                vars: 13,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleTitle", "service"],
                    [3, "amountRemaining", "entityType", "isCreate", "isVisiblePopup", "payment"],
                    [3, "addPaymentClose", "addPaymentSave", "amountRemaining", "entityType", "isCreate", "isVisiblePopup", "payment"]
                ],
                template: function(a, i) {
                    a & 1 && (p(0, "app-data-grid", 0), y("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(S) {
                        return i.edit(S)
                    }), l(), d(1, li, 1, 5, "app-add-payment-popup", 1)), a & 2 && (o("additionalParams", q(9, si, i.paymentableId, i.paymentableType, i.customerId))("columns", i.columns)("entity", i.entity)("isVisibleAddAction", !1)("isVisibleDeleteAction", i.isAdmin)("isVisibleEditAction", i.isEmployee)("isVisibleTitle", i.isiVisibleTitle)("service", i.service), n(), u(i.payment && i.isVisiblePopup ? 1 : -1))
                },
                dependencies: [V, H],
                encapsulation: 2
            })
        }
    }
    return t
})();
var _i = () => ({
        enabled: !1
    }),
    hi = () => ({
        groupPaging: !1
    }),
    Ci = () => ({
        mode: "standard"
    }),
    fi = () => ({
        type: "fixedPoint",
        precision: 2
    }),
    yi = () => [2, 4];

function vi(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-context-menu", 12), y("contextMenuItemCancelClick", function() {
            C(e);
            let i = s(2);
            return f(i.onCloseContextMenuOption())
        })("contextMenuItemClick", function(i) {
            C(e);
            let c = s(2);
            return f(c.onContextMenuItemClick(i))
        }), l()
    }
    if (t & 2) {
        let e = s(2);
        o("buttonText", e.formatMessage("purchase_actions"))("contextMenuItems", e.purchaseContextMenu)("entityName", e.ENTITIES.SALE.name)("entity", e.purchase)("isIconOnly", e.isMobileDevice)
    }
}

function Si(t, r) {
    if (t & 1 && (p(0, "div", 0)(1, "div", 2), m(2, "app-payment-status", 8), p(3, "span", 9), b(4), l(), p(5, "div", 10), d(6, vi, 1, 5, "app-context-menu", 11), l()()()), t & 2) {
        let e = s();
        n(2), o("iconType", e.statusIconTypeList.TITLE)("status", e.purchase == null ? null : e.purchase.status), n(2), $(" ", e.purchase == null ? null : e.purchase.purchase_number, " "), n(2), u(e.purchaseContextMenu.length ? 6 : -1)
    }
}

function Pi(t, r) {
    t & 1 && m(0, "app-skeleton-loader", 3), t & 2 && o("rows", 8)("columns", 3)
}

function Ti(t, r) {
    if (t & 1 && (p(0, "h3", 15), b(1), l()), t & 2) {
        let e = s(2);
        n(), Ve(" ", e.formatMessage("common_purchase"), " : ", e.form.getRawValue().purchase_number, " ")
    }
}

function gi(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-save-cancel-footer", 38), y("cancelClick", function() {
            C(e);
            let i = s(4);
            return f(i.routerHelperService.goBack())
        }), l()
    }
    if (t & 2) {
        let e = s(4);
        o("isOnPopup", !1)("gaEvent", "create_update_purchase_event")("isSaving", e.isSaving)("isVisibleHr", !1)("saveText", e.purchase != null && e.purchase.id ? "common_update" : "common_create")("savingText", e.purchase != null && e.purchase.id ? "common_updating" : "common_creating")
    }
}

function xi(t, r) {
    if (t & 1 && L(0, gi, 1, 6, "app-save-cancel-footer", 37), t & 2) {
        let e = s(3);
        o("ngxPermissionsOnly", e.PERMISSION_LIST.PURCHASE_WRITE)
    }
}

function bi(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-dx-outline-button", 42), y("onClickEvent", function() {
            C(e);
            let i = s(5);
            return f(i.setEditMode())
        }), l()
    }
}

function Ei(t, r) {
    if (t & 1 && L(0, bi, 1, 0, "app-dx-outline-button", 41), t & 2) {
        let e = s(4);
        o("ngxPermissionsOnly", e.PERMISSION_LIST.PURCHASE_WRITE)
    }
}

function Ii(t, r) {
    if (t & 1 && (m(0, "app-location-back", 39), d(1, Ei, 1, 1, "app-dx-outline-button", 40)), t & 2) {
        let e = s(3);
        n(), u(e.userPermissionList.includes(e.PERMISSION_LIST.PURCHASE_WRITE) ? 1 : -1)
    }
}

function Mi(t, r) {
    if (t & 1 && (p(0, "div", 14)(1, "div", 35), d(2, xi, 1, 1, "app-save-cancel-footer", 36), d(3, Ii, 2, 1), l()()), t & 2) {
        let e = s(2);
        n(2), u(!e.isMobileDevice && e.isEditMode ? 2 : -1), n(), u(e.isEditMode ? -1 : 3)
    }
}

function Di(t, r) {
    if (t & 1 && m(0, "app-server-error", 16), t & 2) {
        let e = s(2);
        o("errorResponse", e.errorResponse)
    }
}

function Ai(t, r) {
    if (t & 1 && m(0, "dxi-button", 43), t & 2) {
        let e = s(3);
        o("options", e.addSupplierNameOption)
    }
}

function Vi(t, r) {
    if (t & 1 && d(0, Ai, 1, 1, "dxi-button", 43), t & 2) {
        let e = s(2);
        u(e.isEditMode ? 0 : -1)
    }
}

function Ni(t, r) {
    if (t & 1 && (m(0, "app-copy-to-clipboard", 49), I(1, "mobileDisplay")), t & 2) {
        let e = s(3);
        o("textToBeCopied", A(1, 1, e.selectedPartSupplier.mobile_number, e.selectedPartSupplier == null ? null : e.selectedPartSupplier.mobile_country_code))
    }
}

function wi(t, r) {
    if (t & 1 && m(0, "app-copy-to-clipboard", 49), t & 2) {
        let e = s(3);
        o("textToBeCopied", e.selectedPartSupplier.email)
    }
}

function Ri(t, r) {
    if (t & 1 && (p(0, "div", 27)(1, "div", 44)(2, "p", 45)(3, "strong")(4, "span", 46), m(5, "i", 47), l(), b(6), l(), p(7, "a", 48), I(8, "mobileDisplay"), b(9), I(10, "mobileDisplay"), l(), d(11, Ni, 2, 4, "app-copy-to-clipboard", 49), l()(), p(12, "div", 44)(13, "p", 45)(14, "strong")(15, "span", 46), m(16, "i", 50), l(), b(17), l(), p(18, "a", 48), b(19), l(), d(20, wi, 1, 1, "app-copy-to-clipboard", 49), l()()()), t & 2) {
        let e = s(2);
        n(6), $(" ", e.formatMessage("user_phone"), ": "), n(), o("href", j("tel:", Ne(8, 10, e.selectedPartSupplier.mobile_number, e.selectedPartSupplier == null ? null : e.selectedPartSupplier.mobile_country_code, "tel")), he), n(2), k(A(10, 14, e.selectedPartSupplier.mobile_number, e.selectedPartSupplier == null ? null : e.selectedPartSupplier.mobile_country_code)), n(2), u(e.selectedPartSupplier.mobile_number ? 11 : -1), n(6), $("", e.formatMessage("common_email"), ": "), n(), o("href", j("mailto:", e.selectedPartSupplier.email), he), n(), k(e.selectedPartSupplier.email), n(), u(e.selectedPartSupplier.email ? 20 : -1)
    }
}

function Li(t, r) {
    if (t & 1 && (p(0, "div"), m(1, "span", 55), I(2, "taxSplit"), I(3, "safe"), l()), t & 2) {
        let e = r.$implicit;
        n(), o("innerHTML", A(3, 4, A(2, 1, e.data, "amount"), "html"), z)
    }
}

function Oi(t, r) {
    if (t & 1 && (p(0, "div"), m(1, "span", 55), I(2, "taxSplit"), I(3, "safe"), l()), t & 2) {
        let e = r.$implicit;
        n(), o("innerHTML", A(3, 4, A(2, 1, e.data, "name"), "html"), z)
    }
}

function ki(t, r) {
    if (t & 1 && (p(0, "div"), m(1, "span", 56), I(2, "safe"), l()), t & 2) {
        let e = r.$implicit;
        n(), o("innerHTML", A(2, 1, e.value, "html"), z)
    }
}

function Fi(t, r) {
    if (t & 1 && (p(0, "div"), m(1, "app-part-name", 57), l()), t & 2) {
        let e = r.$implicit;
        n(), o("part", e.data)
    }
}

function Ui(t, r) {
    if (t & 1 && (p(0, "div")(1, "span", 58), b(2), l()()), t & 2) {
        let e = s(3);
        n(), o("ngClass", e.isMobileDevice ? "h6" : "h4"), n(), k(e.formatMessage("common_parts"))
    }
}

function Gi(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-dx-outline-button", 60), y("onClickEvent", function() {
            C(e);
            let i = s(4);
            return f(i.addPart())
        }), l()
    }
    if (t & 2) {
        let e = s(4);
        o("text", e.isMobileDevice ? "" : "inventory_add_part")("isVisibleIcon", !0)
    }
}

function Hi(t, r) {
    if (t & 1 && (p(0, "div"), d(1, Gi, 1, 2, "app-dx-outline-button", 59), l()), t & 2) {
        let e = s(3);
        n(), u(e.isEditMode ? 1 : -1)
    }
}

function Bi(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "i", 63), y("click", function() {
            C(e);
            let i = s().$implicit,
                c = s(3);
            return f(c.edit(i))
        }), l()
    }
    if (t & 2) {
        let e = s(4);
        o("title", e.formatMessage("common_edit"))
    }
}

function ji(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "i", 64), y("click", function() {
            C(e);
            let i = s().$implicit,
                c = s(3);
            return f(c.delete(i.data))
        }), l()
    }
    if (t & 2) {
        let e = s(4);
        o("title", e.formatMessage("delete"))
    }
}

function qi(t, r) {
    if (t & 1 && (p(0, "div"), d(1, Bi, 1, 1, "i", 61), d(2, ji, 1, 1, "i", 62), l()), t & 2) {
        let e = s(3);
        n(), u(e.isEditMode && e.isEmployee ? 1 : -1), n(), u(e.isEditMode && e.isEmployee ? 2 : -1)
    }
}

function Yi(t, r) {
    if (t & 1 && m(0, "dxi-total-item", 54), t & 2) {
        let e = r.$implicit;
        o("alignment", e.alignment)("column", e.column)("name", e.column)("summaryType", e.summaryType)("valueFormat", F(5, fi))
    }
}

function Wi(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "dx-data-grid", 51), y("onToolbarPreparing", function(i) {
            C(e);
            let c = s(2);
            return f(c.onToolbarPreparing(i))
        }), J("dataSourceChange", function(i) {
            C(e);
            let c = s(2);
            return K(c.partDataSource, i) || (c.partDataSource = i), f(i)
        }), L(1, Li, 4, 7, "div", 52)(2, Oi, 4, 7, "div", 52)(3, ki, 3, 4, "div", 52)(4, Fi, 2, 1, "div", 52)(5, Ui, 3, 2, "div", 52)(6, Hi, 2, 1, "div", 52)(7, qi, 3, 2, "div", 52), p(8, "dxo-summary", 53), De(9, Yi, 1, 6, "dxi-total-item", 54, Me), l()()
    }
    if (t & 2) {
        let e = s(2);
        Z("dataSource", e.partDataSource), o("columnAutoWidth", !1)("columns", e.columns)("paging", F(14, _i))("remoteOperations", F(15, hi))("scrolling", F(16, Ci)), n(), o("dxTemplateOf", "taxAmountSplitSubClassTemplate"), n(), o("dxTemplateOf", "taxSplitSubClassTemplate"), n(), o("dxTemplateOf", "commentTemplate"), n(), o("dxTemplateOf", "partNameTemplate"), n(), o("dxTemplateOf", "tableHeaderTemplate"), n(), o("dxTemplateOf", "addBtnTemplate"), n(), o("dxTemplateOf", "actionTemplate"), n(), o("skipEmptyValues", !0), n(), Ae(e.summaryRows)
    }
}

function Qi(t, r) {
    if (t & 1 && (p(0, "div", 1), m(1, "app-summary-table", 65), l()), t & 2) {
        let e = s(2);
        n(), o("grandTotal", e.dataGrid.instance.getTotalSummaryValue("line_total"))("isPurchase", !0)("taxAmount", e.dataGrid.instance.getTotalSummaryValue("tax_amount"))("totalAmount", e.dataGrid.instance.getTotalSummaryValue("sub_total"))
    }
}

function zi(t, r) {
    if (t & 1 && m(0, "app-purchase-payment-list", 66), t & 2) {
        let e = s(3);
        o("paymentableId", e.purchaseId)
    }
}

function Xi(t, r) {
    if (t & 1 && (p(0, "app-control-container", 71), m(1, "dx-text-box", 75), l()), t & 2) {
        let e = s(5);
        o("errorMsg", e.formatMessage("common_error_messages_transaction_id_required"))("label", e.formatMessage("common_transaction_id")), n(), o("placeholder", e.formatMessage("common_type_transaction_id_number"))("readOnly", !e.isEditMode)
    }
}

function $i(t, r) {
    if (t & 1 && (p(0, "app-control-container", 72), m(1, "dx-text-box", 76), l()), t & 2) {
        let e = s(5);
        o("errorMsg", e.formatMessage("common_error_messages_cheque_number_required"))("label", e.formatMessage("payment_cheque_number")), n(), o("placeholder", e.formatMessage("common_type_cheque_number"))("readOnly", !e.isEditMode)
    }
}

function Zi(t, r) {
    if (t & 1 && (p(0, "div", 68)(1, "app-control-container", 69), m(2, "app-payment-type-dropdown", 70), l(), d(3, Xi, 2, 4, "app-control-container", 71), d(4, $i, 2, 4, "app-control-container", 72), p(5, "app-control-container", 73), m(6, "dx-number-box", 74), l()()), t & 2) {
        let e, a, i = s(4);
        n(), o("errorMsg", i.formatMessage("common_error_messages_payment_mode_required"))("label", i.formatMessage("payment_mode")), n(), o("isEditMode", i.isEditMode), n(), u(F(10, yi).includes((e = i.form.getRawValue()) == null || e.paymentable == null ? null : e.paymentable.payment_type_id) ? 3 : -1), n(), u(((a = i.form.getRawValue()) == null || a.paymentable == null ? null : a.paymentable.payment_type_id) === 3 ? 4 : -1), n(), o("errorMsg", i.formatMessage("common_amount_required"))("label", i.formatMessage("common_amount")), n(), o("format", i.CURRENCY_FORMAT)("min", 0)("readOnly", !i.isEditMode)
    }
}

function Ki(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "dx-radio-group", 67), y("onValueChanged", function(i) {
            C(e);
            let c = s(3);
            return f(c.setPaymentOption(i))
        }), l(), d(1, Zi, 7, 11, "div", 68)
    }
    if (t & 2) {
        let e = s(3);
        o("items", e.paymentOptions), n(), u(e.form.getRawValue().status !== e.PAYMENT_STATUS_LIST.UNPAID ? 1 : -1)
    }
}

function Ji(t, r) {
    if (t & 1 && (p(0, "div", 1)(1, "div", 2), d(2, zi, 1, 1, "app-purchase-payment-list", 66)(3, Ki, 2, 2), l()()), t & 2) {
        let e = s(2);
        n(2), u(e.purchaseId ? 2 : 3)
    }
}

function en(t, r) {
    if (t & 1 && m(0, "app-attachments", 33), t & 2) {
        let e = s(2);
        o("attachableType", e.attachableType)("entity", e.purchase)("isEditMode", e.isEditMode)("isMultipleUploads", !0)("isVisibleLabel", e.isEditMode)
    }
}

function tn(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-save-cancel-footer", 38), y("cancelClick", function() {
            C(e);
            let i = s(3);
            return f(i.routerHelperService.goBack())
        }), l()
    }
    if (t & 2) {
        let e = s(3);
        o("isOnPopup", !0)("gaEvent", "create_update_purchase_event")("isSaving", e.isSaving)("isVisibleHr", !1)("saveText", e.purchase != null && e.purchase.id ? "common_update" : "common_create")("savingText", e.purchase != null && e.purchase.id ? "common_updating" : "common_creating")
    }
}

function nn(t, r) {
    if (t & 1 && (p(0, "div", 34), L(1, tn, 1, 6, "app-save-cancel-footer", 37), l()), t & 2) {
        let e = s(2);
        n(), o("ngxPermissionsOnly", e.PERMISSION_LIST.PURCHASE_WRITE)
    }
}

function an(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "form", 13), y("ngSubmit", function() {
            C(e);
            let i = s();
            return f(i.save())
        }), p(1, "div", 1)(2, "div", 14), d(3, Ti, 2, 2, "h3", 15), l(), d(4, Mi, 4, 2, "div", 14), l(), d(5, Di, 1, 1, "app-server-error", 16), m(6, "app-section-title", 17), p(7, "div", 1)(8, "app-control-container", 18)(9, "dx-select-box", 19), L(10, Vi, 1, 1, "ng-template", 20), l()(), p(11, "app-control-container", 21), m(12, "dx-text-box", 22), l(), p(13, "app-control-container", 23), m(14, "app-date-picker", 24), l(), p(15, "app-control-container", 25), m(16, "dx-date-box", 26), l()(), d(17, Ri, 21, 17, "div", 27), m(18, "app-section-title", 28), p(19, "div", 1)(20, "div", 2), d(21, Wi, 11, 17, "dx-data-grid", 29), l()(), d(22, Qi, 2, 4, "div", 1), d(23, Ji, 4, 1, "div", 1), m(24, "app-section-title", 30), p(25, "app-control-container", 31), m(26, "app-textarea", 32), l(), d(27, en, 1, 5, "app-attachments", 33), d(28, nn, 2, 1, "div", 34), l()
    }
    if (t & 2) {
        let e = s();
        o("formGroup", e.form), n(3), u(e.purchaseId ? -1 : 3), n(), u(e.isEmployee ? 4 : -1), n(), u(e.errorResponse ? 5 : -1), n(), o("title", e.formatMessage("common_customer_information")), n(2), o("errorMsg", e.formatMessage("purchase_error_messages_part_supplier_name"))("label", e.formatMessage("purchase_part_supplier_name")), n(), o("items", e.partSupplierList)("searchEnabled", !0)("placeholder", e.formatMessage("purchase_part_select_or_create_supplier_placeholder")), n(), o("ngxPermissionsOnly", e.PERMISSION_LIST.PART_SUPPLIER_LIST), n(), o("errorMsg", e.formatMessage("purchase_error_messages_party_invoice_number"))("label", e.formatMessage("purchase_party_invoice_number")), n(2), o("errorMsg", e.formatMessage("purchase_error_messages_purchase_date"))("label", e.formatMessage("purchase_date")), n(), o("isEditMode", e.isEditMode)("placeholder", e.formatMessage("purchase_date")), n(), o("errorMsg", e.formatMessage("common_error_messages_due_date"))("label", e.formatMessage("common_due_date")), n(), o("dateSerializationFormat", e.DATETIME_SERIALIZATION_FORMAT)("displayFormat", e.DISPLAY_DATETIME_SERIALIZATION_FORMAT)("min", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("purchase_placeholder_due_date")), n(), u(e.selectedPartSupplier ? 17 : -1), n(), o("title", e.formatMessage("purchase_items")), n(3), u(e.isLoadingPart ? -1 : 21), n(), u(e.partDataSource.length && (e.dataGrid != null && e.dataGrid.instance) && !e.isLoadingPart ? 22 : -1), n(), u(e.hasAddPaymentPermission ? 23 : -1), n(), o("title", e.formatMessage("purchase_other_information")), n(), o("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions")), n(), o("isEditMode", e.isEditMode), n(), u(e.purchase ? 27 : -1), n(), u(e.isMobileDevice && e.isEditMode ? 28 : -1)
    }
}

function on(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-add-part-to-entity-popup", 77), y("addPartToEntityCancelClick", function() {
            C(e);
            let i = s();
            return f(i.isVisiblePurchasePartPopup = !1)
        })("addPartToEntitySaveClick", function(i) {
            C(e);
            let c = s();
            return f(c.onPartSave(i))
        }), l()
    }
    if (t & 2) {
        let e = s();
        o("isCreate", e.isCreate)("isPurchase", !0)("isVisiblePopup", e.isVisiblePurchasePartPopup)("partableType", e.ENTITIES.PURCHASE.name)("partable", e.currentPart)
    }
}

function rn(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-add-payment-popup", 78), y("addPaymentClose", function() {
            C(e);
            let i = s();
            return f(i.onCloseContextMenuOption())
        })("addPaymentSave", function(i) {
            C(e);
            let c = s();
            return f(c.onPopupSaveAction(i))
        }), l()
    }
    if (t & 2) {
        let e = s();
        o("entityType", e.ENTITIES.PURCHASE.name)("entity", e.purchase)("isVisiblePopup", e.currentContextMenuAction === e.SALE_CONTEXT_MENU_LIST.ADD_PAYMENT)
    }
}

function sn(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-part-supplier", 79), y("partSupplierCancelClick", function() {
            C(e);
            let i = s();
            return f(i.isVisiblePartSupplierNamePopup = !1)
        })("partSupplierSave", function(i) {
            C(e);
            let c = s();
            return f(c.onAddPartSupplier(i))
        }), l()
    }
    if (t & 2) {
        let e = s();
        o("isCreate", !0)("isVisiblePopup", e.isVisiblePartSupplierNamePopup)("partSupplier", e.partSupplier)
    }
}
var Te = (() => {
    class t {
        constructor(e, a, i, c, S, ni, ai) {
            this.tableSequenceNumberService = e, this.service = a, this.partService = i, this.partSupplierService = c, this.termAndConditionService = S, this.applicationRef = ni, this.loaderService = ai, this.formatMessage = _, this.uuidService = h(Mt), this.routerHelperService = h(tt), this.columns = h(de).partColumns, this.formService = h(dt), this.activatedRouter = h(U), this.configService = h(ne), this.router = h(ee), this.userSessionService = h(G), this.generalSettingDataService = h(le), this.isMobileDevice = h(te).isMobileDevice(), this.toastNotificationService = h(ae), this.tenantService = h(se), this.today = new Date, this.DATETIME_SERIALIZATION_FORMAT = We, this.DISPLAY_DATETIME_SERIALIZATION_FORMAT = Qe, this.PAYMENT_STATUS_LIST = M, this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.hasAddPaymentPermission = this.isEmployee && this.userPermissionList.includes(g.PAYMENT_WRITE), this.ENTITIES = D, this.SALE_CONTEXT_MENU_LIST = Xe, this.PURCHASE_CONTEXT_MENU_LIST = T, this.statusIconTypeList = ie, this.errorResponse = null, this.attachableType = this.ENTITIES.PURCHASE.name, this.CURRENCY_FORMAT = ze, this.purchase = null, this.currentPart = null, this.isEditMode = !1, this.summaryRows = Ze, this.isSaving = !1, this.paymentOptions = Object.values(M).filter(oi => [M.PAID, M.UNPAID, M.PARTIALLY_PAID].includes(oi)), this.isLoadingPart = !1, this.partDataSource = [], this.isVisiblePurchasePartPopup = !1, this.isCreate = !1, this.currentContextMenuAction = null, this.purchaseContextMenu = [], this.isVisiblePartSupplierNamePopup = !1, this.PERMISSION_LIST = g, this.addSupplierNameOption = {
                icon: "add",
                type: "default",
                hint: "Add New Supplier",
                onClick: () => {
                    this.partSupplier = new Qt({
                        device_type_id: this.form.getRawValue().part_supplier_id
                    }), this.isVisiblePartSupplierNamePopup = !0
                }
            }
        }
        ngOnInit() {
            this.purchaseId = +this.activatedRouter.snapshot.paramMap.get("purchase_id"), this.loadPurchaseDetails(), this.purchaseContextMenu = [{
                name: T.ADD_PAYMENT,
                icon: "fa-thin fa-money-check-alt",
                visible: this.hasAddPaymentPermission,
                locale_key: _("add_payment")
            }, {
                name: T.PURCHASE_INVOICE,
                icon: "fa-thin fa-file-invoice-dollar",
                visible: !0,
                locale_key: _("purchase_invoice")
            }]
        }
        initialize() {
            this.columns.push({
                dataField: "",
                caption: "",
                hidingPriority: 9,
                width: 45,
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                visible: this.isEditMode && this.isEmployee
            }), Se.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice)
        }
        setPaymentType() {
            qt.updateFormForPaymentType(this.form.get("paymentable")), this.form.updateValueAndValidity()
        }
        save() {
            if (this.errorResponse = null, this.form.valid) {
                let e = this.getData();
                (this.purchase ? .id ? this.service.update(e) : this.service.create(e)).subscribe({
                    next: i => this.handleSaveResponse(i),
                    error: i => this.handleErrorResponse(i)
                }).add(() => this.isSaving = !1)
            } else this.formService.validateFormFields(this.form)
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable(), this.columns[this.columns.findIndex(e => e.cellTemplate === "actionTemplate")].visible = !0, this.isLoadingPart = !0, setTimeout(() => {
                this.isLoadingPart = !1
            })
        }
        onToolbarPreparing(e) {
            e.toolbarOptions.items.push({
                template: "tableHeaderTemplate",
                location: "before",
                locateInMenu: "never"
            }, {
                template: "addBtnTemplate",
                location: "after",
                locateInMenu: "never"
            })
        }
        addPart() {
            this.isCreate = !0, this.isVisiblePurchasePartPopup = !0
        }
        edit(e) {
            this.isCreate = !1, this.currentPart = e.data, this.isVisiblePurchasePartPopup = !0
        }
        delete(e) {
            this.partDataSource = this.partDataSource.filter(a => a.id !== e.id), this.recalculatePaymentAmount()
        }
        recalculatePaymentAmount() {
            setTimeout(() => {
                this.form.patchValue({
                    paymentable: {
                        amount: this.getPaymentAmount()
                    }
                })
            }, 1e3)
        }
        getPaymentAmount() {
            return this.generalSettingDataService.getGeneralSettingByKey(ye.GENERAL_SETTINGS.AUTO_ROUND_OFF) === !0 ? Math.round(this.dataGrid.instance.getTotalSummaryValue("line_total")) : this.dataGrid.instance.getTotalSummaryValue("line_total")
        }
        onPartSave(e) {
            this.isCreate ? (e.part_id || (e.part_id = this.uuidService.getNumericUuid()), this.partDataSource.push(e)) : this.partDataSource[this.partDataSource.findIndex(a => a.part_id === e.part_id)] = e, this.recalculatePaymentAmount(), this.isCreate = !1, this.isVisiblePurchasePartPopup = !1, this.currentPart = null
        }
        getData() {
            let e = this.form.getRawValue();
            return e.partables = this.getPurchaseParts(), e.total_amount = this.dataGrid.instance.getTotalSummaryValue("line_total"), e.tax_amount = this.dataGrid.instance.getTotalSummaryValue("tax_amount"), e
        }
        getPurchaseParts() {
            return this.purchase ? .id ? this.partDataSource : this.partDataSource.map(e => (e.id = null, e))
        }
        setPaymentOption(e) {
            e.value === M.PAID ? (this.form.contains("paymentable") || this.addPaymentForm(), this.recalculatePaymentAmount(), this.form.get("paymentable").get("amount").disable()) : e.value === M.PARTIALLY_PAID ? (this.form.contains("paymentable") || this.addPaymentForm(), this.form.get("paymentable").get("amount").enable()) : e.value === M.UNPAID && this.form.removeControl("paymentable"), this.form.updateValueAndValidity()
        }
        addPaymentForm() {
            if (this.userPermissionList.includes(g.PAYMENT_WRITE)) {
                let e = this.dataGrid ? .instance ? .getTotalSummaryValue("line_total"),
                    a = this.form.value ? .auto_round_off === !0 ? Math.round(e) : e || null,
                    i = new Be().group({
                        id: [null],
                        payment_type_id: [1, Y.required],
                        amount: [a, Y.required],
                        transaction_id: [null],
                        cheque_number: [null]
                    });
                this.form.addControl("paymentable", i), this.subscribeToPaymentTypeChanges()
            }
        }
        subscribeToPaymentTypeChanges() {
            this.form.get("paymentable.payment_type_id") ? .valueChanges.subscribe(() => {
                this.setPaymentType()
            })
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.purchase = e.entity, this.currentContextMenuAction === T.VIEW_PURCHASE && this.router.navigate(["/purchases/" + e.entity.id]), this.currentContextMenuAction === T.PURCHASE_INVOICE && this.router.navigate(["/purchases/" + e.entity.id + "/invoices"])
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null
        }
        onPopupSaveAction(e) {
            this.onCloseContextMenuOption(), this.loadPurchaseDetails()
        }
        onAddPartSupplier(e) {
            this.isVisiblePartSupplierNamePopup = !1, this.partSupplierList.push(e), this.form.patchValue({
                part_supplier_id: e.id
            })
        }
        loadPurchaseDetails() {
            let e = this.getObservables();
            this.loaderService.show(), xe(e).subscribe({
                next: ([a, i, c, S]) => {
                    this.purchase = new E(S), this.partSupplierList = i, this.purchase ? .id ? this.setPurchaseEditForm() : this.setPurchaseCreateForm(a, c), this.initialize()
                },
                error: a => {
                    console.error("Cannot get purchase by id ", a)
                }
            }).add(() => this.loaderService.hide())
        }
        setPurchaseCreateForm(e, a) {
            this.form = E.getForm(new E({
                purchase_number: e[0].current_value,
                term_and_condition: a ? .text,
                auto_round_off: this.generalSettingDataService.getGeneralSettingByKey(ye.GENERAL_SETTINGS.AUTO_ROUND_OFF) ? ? !1
            }));
            let i = this.generalSettingDataService.getGeneralSettingByKey("default_purchase_due_day");
            if (i) {
                let c = parseInt(i, 10);
                if (c > 0) {
                    let S = Se.addDays(new Date, c, this.tenantService.timezone());
                    this.form.get("due_date") ? .setValue(S)
                }
            }
            this.addPaymentForm(), this.form.get("paymentable") ? .get("amount").disable(), this.isEditMode = !0
        }
        setPurchaseEditForm() {
            this.form = E.getForm(this.purchase), this.partDataSource = this.purchase.partables, this.selectedPartSupplier = this.purchase.part_supplier, this.isEditMode = !1, this.form.disable()
        }
        handleSaveResponse(e) {
            this.purchase ? .id ? (this.purchase = new E(e), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.purchase), this.toastNotificationService.success("notification_purchase_update_success"), this.form.patchValue(this.purchase), this.form.disable(), this.isEditMode = !1) : (this.purchase = new E(e), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.purchase), this.router.navigate([`/purchases/${e.id}`]), this.toastNotificationService.success("notification_purchase_add_success"))
        }
        handleErrorResponse(e) {
            this.errorResponse = e, "message" in this.errorResponse.error && this.toastNotificationService.error("notification_part_add_error", this.errorResponse.error.message, {
                disableTimeOut: !0
            })
        }
        getObservables() {
            let e = [this.tableSequenceNumberService.getListByQuery({
                name: $e.PURCHASE.name
            }), this.partSupplierService.getAll(), this.termAndConditionService.getByTypeId({
                type_id: Ke.PURCHASE
            })];
            return e.push(this.purchaseId ? this.service.getById(this.purchaseId) : ge(new E({}))), e
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || t)(P($t), P(B), P(Vt), P(Ot), P(Ct), P(Ie), P(re))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-purchase-detail"]
                ],
                viewQuery: function(a, i) {
                    if (a & 1 && O(ce, 5)(me, 5), a & 2) {
                        let c;
                        N(c = w()) && (i.dataGrid = c.first), N(c = w()) && (i.attachmentInstance = c.first)
                    }
                },
                standalone: !1,
                decls: 8,
                vars: 6,
                consts: [
                    [1, "row", "mb-3"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "isCreate", "isPurchase", "isVisiblePopup", "partableType", "partable"],
                    [3, "entityType", "entity", "isVisiblePopup"],
                    [3, "isCreate", "isVisiblePopup", "partSupplier"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "buttonText", "contextMenuItems", "entityName", "entity", "isIconOnly"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "buttonText", "contextMenuItems", "entityName", "entity", "isIconOnly"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "float-start"],
                    [3, "errorResponse"],
                    ["id", "job-basic-info-title", 1, "mt-3", 3, "title"],
                    ["name", "part_supplier_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "part_supplier_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "searchEnabled", "placeholder"],
                    [3, "ngxPermissionsOnly"],
                    ["name", "party_invoice_number", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "party_invoice_number", "id", "party_invoice_number_id", "placeholder", "IN-1001"],
                    ["name", "purchase_date", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "purchase_date", 3, "isEditMode", "placeholder"],
                    ["name", "due_date", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "due_date", "type", "datetime", 3, "dateSerializationFormat", "displayFormat", "min", "pickerType", "placeholder"],
                    [1, "row", "mt-3"],
                    ["id", "sale-items-title", 1, "mt-3", 3, "title"],
                    ["keyExpr", "id", 3, "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    ["id", "payment-information-title", 1, "mt-3", "mb-2", 3, "title"],
                    ["name", "term_and_condition", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["height", "auto", "formControlName", "term_and_condition", 3, "isEditMode"],
                    ["accept", "image/*,application/pdf,application/msword,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads", "isVisibleLabel"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    [3, "isOnPopup", "gaEvent", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    [3, "isOnPopup", "gaEvent", "isSaving", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "isOnPopup", "gaEvent", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["id", "job-basic-info-back"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    ["id", "part-supplier-btn", "location", "after", "name", "deviceBrand", 3, "options"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4"],
                    [1, "card-text"],
                    [1, "me-2"],
                    [1, "fa-thin", "fa-phone"],
                    [3, "href"],
                    [1, "mx-4", 3, "textToBeCopied"],
                    [1, "fa-thin", "fa-envelope"],
                    ["keyExpr", "id", 3, "onToolbarPreparing", "dataSourceChange", "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "skipEmptyValues"],
                    ["displayFormat", "{0}", 3, "alignment", "column", "name", "summaryType", "valueFormat"],
                    [1, "tax-split", 3, "innerHTML"],
                    [3, "innerHTML"],
                    [3, "part"],
                    [3, "ngClass"],
                    ["buttonType", "default", "title", "inventory_add_part", "icon", "fa-thin fa-plus", 1, "float-end", 3, "text", "isVisibleIcon"],
                    ["buttonType", "default", "title", "inventory_add_part", "icon", "fa-thin fa-plus", 1, "float-end", 3, "onClickEvent", "text", "isVisibleIcon"],
                    [1, "fa-thin", "fa-pencil", "me-2", 3, "title"],
                    [1, "fa-thin", "fa-trash", 3, "title"],
                    [1, "fa-thin", "fa-pencil", "me-2", 3, "click", "title"],
                    [1, "fa-thin", "fa-trash", 3, "click", "title"],
                    [3, "grandTotal", "isPurchase", "taxAmount", "totalAmount"],
                    [3, "paymentableId"],
                    ["formControlName", "status", "layout", "horizontal", 1, "mb-2", 3, "onValueChanged", "items"],
                    ["formGroupName", "paymentable", 1, "row"],
                    ["name", "payment_type_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "payment_type_id", 3, "isEditMode"],
                    ["name", "transaction_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "cheque_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "amount", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "amount", "id", "add-payment-popup-remaining-amount", 3, "format", "min", "readOnly"],
                    ["formControlName", "transaction_id", "id", "add-payment-popup-transaction_id", 3, "placeholder", "readOnly"],
                    ["formControlName", "cheque_number", "id", "add-payment-popup-cheque_number", 3, "placeholder", "readOnly"],
                    [3, "addPartToEntityCancelClick", "addPartToEntitySaveClick", "isCreate", "isPurchase", "isVisiblePopup", "partableType", "partable"],
                    [3, "addPaymentClose", "addPaymentSave", "entityType", "entity", "isVisiblePopup"],
                    [3, "partSupplierCancelClick", "partSupplierSave", "isCreate", "isVisiblePopup", "partSupplier"]
                ],
                template: function(a, i) {
                    a & 1 && (d(0, Si, 7, 4, "div", 0), p(1, "div", 1)(2, "div", 2), d(3, Pi, 1, 2, "app-skeleton-loader", 3), d(4, an, 29, 35, "form", 4), l()(), d(5, on, 1, 5, "app-add-part-to-entity-popup", 5), d(6, rn, 1, 3, "app-add-payment-popup", 6), d(7, sn, 1, 3, "app-part-supplier", 7)), a & 2 && (u(i.purchaseId ? 0 : -1), n(3), u(!i.form && i.purchaseId ? 3 : -1), n(), u(i.form ? 4 : -1), n(), u(i.isVisiblePurchasePartPopup ? 5 : -1), n(), u(i.currentContextMenuAction === i.PURCHASE_CONTEXT_MENU_LIST.ADD_PAYMENT ? 6 : -1), n(), u(i.isVisiblePartSupplierNamePopup ? 7 : -1))
                },
                dependencies: [we, Gt, At, ut, me, pt, It, Ft, Nt, pe, ue, wt, H, zt, kt, lt, oe, Pt, Ut, jt, it, nt, ce, at, ot, gt, xt, bt, rt, st, ke, Le, Oe, Ge, Ue, Fe, Ye, Kt, ft, Rt, mt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ln = (t, r, e) => [t, r, e],
    pn = (t, r, e) => ({
        icon: "dx-icon-cart",
        title: t,
        description: r,
        primaryButtonText: "empty_state_purchase_primary_button",
        quickTips: e,
        tutorialUrl: "https://www.youtube.com/watch?v=syyNOQMxCQg",
        tutorialVisible: !0,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function cn(t, r) {
    if (t & 1 && m(0, "app-overview-report-card-on-list", 0), t & 2) {
        let e = s();
        o("entity", e.ENTITIES.PURCHASE.name)("label", e.formatMessage("overview_report_purchase_quick_overview_report"))
    }
}

function mn(t, r) {
    if (t & 1) {
        let e = v();
        p(0, "app-add-payment-popup", 4), y("addPaymentClose", function() {
            C(e);
            let i = s();
            return f(i.onCloseContextMenuOption())
        })("addPaymentSave", function(i) {
            C(e);
            let c = s();
            return f(c.onPopupSaveAction(i))
        }), l()
    }
    if (t & 2) {
        let e = s();
        o("entityType", e.ENTITIES.PURCHASE.name)("entity", e.currentPurchase)("isVisiblePopup", e.currentContextMenuAction === e.PURCHASE_CONTEXT_MENU_LIST.ADD_PAYMENT)
    }
}
var Jt = (() => {
    class t {
        get hasTenantPurchases() {
            return (this.tenantService.config() ? .entity_counts ? .purchases || 0) > 0
        }
        constructor(e) {
            this.service = e, this.formatMessage = _, this.ENTITIES = D, this.router = h(ee), this.userSessionService = h(G), this.tenantService = h(se), this.isMobileDevice = h(te).isMobileDevice(), this.toastNotificationService = h(ae), this.plan = this.tenantService.plan(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.PURCHASE_CONTEXT_MENU_LIST = T, this.currentContextMenuAction = null, this.purchaseContextMenu = [], this.entity = D.PURCHASE, this.isVisibleArchiveDeletePopup = _e(!1), this.archiveDeleteMode = _e("delete"), this.columns = [{
                dataField: "purchase_number",
                caption: _("common_purchase"),
                width: this.isMobileDevice ? 90 : 130,
                allowSorting: !0,
                alignment: "center",
                cellTemplate: "idLinkTemplate"
            }, {
                dataField: "part_supplier.name",
                caption: _("common_supplier"),
                width: this.isMobileDevice ? 120 : 130,
                allowSorting: !1
            }, {
                dataField: "party_invoice_number",
                caption: _("purchase_party_invoice_number"),
                allowSorting: !1,
                alignment: "center",
                hidingPriority: 7
            }, {
                dataField: "total_amount",
                caption: _("common_amount"),
                alignment: "center",
                allowSorting: !1,
                hidingPriority: 6,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "",
                caption: _("remaining_amount"),
                calculateCellValue: a => Number(((a.total_amount ? ? 0) - (a.paymentable_sum_amount ? ? 0)).toFixed(2)),
                allowSorting: !1,
                alignment: "center",
                hidingPriority: 3,
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "status",
                caption: _("common_status"),
                cellTemplate: "saleStatusTemplate",
                allowSorting: !1,
                alignment: "center",
                hidingPriority: 4
            }, {
                dataField: "purchase_date",
                caption: _("purchased_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "due_date",
                caption: _("common_due_date"),
                cellTemplate: "dueDateTimeTemplate",
                hidingPriority: 2,
                allowSorting: !1
            }, {
                dataField: "updated_at",
                caption: _("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 1,
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "created_at",
                caption: _("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 0,
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                cssClass: "custom-action",
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }]
        }
        ngOnInit() {
            this.purchaseContextMenu = [{
                name: T.ADD_PAYMENT,
                icon: "fa-thin fa-money-check-alt",
                visible: this.isEmployee && this.userPermissionList.includes(g.PAYMENT_WRITE),
                locale_key: _("add_payment")
            }, {
                name: T.PURCHASE_INVOICE,
                icon: "fa-thin fa-file-invoice-dollar",
                visible: !0,
                locale_key: _("purchase_invoice")
            }, {
                name: T.DELETE_PURCHASE,
                icon: "fa-thin fa-trash",
                visible: this.userPermissionList.includes(g.PURCHASE_DELETE),
                locale_key: _("purchase_action_delete_purchase")
            }]
        }
        onContextMenuItemClick(e) {
            this.currentContextMenuAction = e.action, this.currentPurchase = e.entity, this.currentContextMenuAction === T.VIEW_PURCHASE && this.router.navigate(["/purchases/" + e.entity.id]), this.currentContextMenuAction === T.PURCHASE_INVOICE && this.router.navigate(["/purchases/" + e.entity.id + "/invoices"]), this.currentContextMenuAction === T.DELETE_PURCHASE && (this.archiveDeleteMode.set(this.currentPurchase.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup.set(!0))
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentPurchase = null
        }
        edit(e) {
            this.router.navigate([`/purchases/${e.id}`])
        }
        create() {
            this.router.navigate(["/purchases/add"])
        }
        onPopupSaveAction(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        handleArchiveDeleteSuccess(e) {
            this.dataGrid.getData(), this.onCloseContextMenuOption()
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || t)(P(B))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-purchase-list"]
                ],
                viewQuery: function(a, i) {
                    if (a & 1 && O(V, 5), a & 2) {
                        let c;
                        N(c = w()) && (i.dataGrid = c.first)
                    }
                },
                standalone: !1,
                decls: 4,
                vars: 27,
                consts: [
                    [3, "entity", "label"],
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "dataGridEditClick", "columns", "contextMenuItems", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleExportAction", "searchPanelPlaceholderText", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "entityType", "entity", "isVisiblePopup"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "addPaymentClose", "addPaymentSave", "entityType", "entity", "isVisiblePopup"]
                ],
                template: function(a, i) {
                    a & 1 && (d(0, cn, 1, 2, "app-overview-report-card-on-list", 0), p(1, "app-data-grid", 1), y("contextMenuItemCancelClick", function() {
                        return i.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(S) {
                        return i.onContextMenuItemClick(S)
                    })("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(S) {
                        return i.edit(S)
                    }), l(), d(2, mn, 1, 3, "app-add-payment-popup", 2), p(3, "app-archive-delete-popup", 3), J("isVisibleChange", function(S) {
                        return K(i.isVisibleArchiveDeletePopup, S) || (i.isVisibleArchiveDeletePopup = S), S
                    }), y("onSuccess", function(S) {
                        return i.handleArchiveDeleteSuccess(S)
                    })("onCancel", function() {
                        return i.onCloseContextMenuOption()
                    }), l()), a & 2 && (u(i.isAdmin ? 0 : -1), n(), o("columns", i.columns)("contextMenuItems", i.purchaseContextMenu)("entity", i.entity)("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("searchPanelPlaceholderText", "search_panel_purchase_placeholder")("service", i.service)("hasTenantData", i.hasTenantPurchases)("emptyStateConfig", q(23, pn, i.formatMessage("empty_state_purchase_title"), i.formatMessage("empty_state_purchase_description"), q(19, ln, i.formatMessage("empty_state_purchase_tip_1"), i.formatMessage("empty_state_purchase_tip_2"), i.formatMessage("empty_state_purchase_tip_3")))), n(), u(i.currentContextMenuAction === i.PURCHASE_CONTEXT_MENU_LIST.ADD_PAYMENT ? 2 : -1), n(), Z("isVisible", i.isVisibleArchiveDeletePopup), o("service", i.service)("entity", i.currentPurchase)("entityName", i.entity == null ? null : i.entity.name)("entityDisplayName", i.entity == null ? null : i.entity.displayName)("entityNumberField", "purchase_number")("mode", i.archiveDeleteMode()))
                },
                dependencies: [Dt, V, H, Wt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function un(t, r) {
    if (t & 1 && (p(0, "div", 11)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 12)(4, "app-invoice-title", 13)(5, "app-invoice-supplier-detail", 14), p(6, "div", 15)(7, "div", 3), m(8, "app-print-table", 16)(9, "app-summary-table", 17), l()(), m(10, "app-invoice-term-and-conditions", 18)(11, "hr", 19)(12, "app-invoice-signature", 20), l()()()), t & 2) {
        let e = s();
        n(3), o("account", e.account)("qrCode", e.purchase && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.purchase == null ? null : e.purchase.qr_code)), n(), o("dateTime", e.purchase == null ? null : e.purchase.purchase_date)("title", ((e.printOptions == null ? null : e.printOptions.purchase_invoice_title) || e.formatMessage("purchase_invoice_label")) + " " + (e.purchase == null ? null : e.purchase.purchase_number)), n(), o("userId", e.purchase == null ? null : e.purchase.part_supplier_id), n(3), o("columns", e.partColumns)("rows", e.purchase == null ? null : e.purchase.partables), n(), o("isPurchase", !0)("rows", e.purchase == null ? null : e.purchase.partables), n(), o("termAndCondition", e.purchase.term_and_condition), n(2), o("entityId", e.purchase == null ? null : e.purchase.id)("entityType", e.entityType)
    }
}
var ei = (() => {
    class t {
        constructor(e, a) {
            this.service = e, this.loaderService = a, this.formatMessage = _, this.partColumns = h(de).partColumns, this.configService = h(ne), this.generalSettingDataService = h(le), this.activatedRouter = h(U), this.statusIconTypeList = ie, this.ENTITIES = D, this.entityType = this.ENTITIES.PURCHASE.name, this.printOptions = null, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(ve.PRINT_SETTINGS) ? ? _t.getEmptyObject()
        }
        ngOnInit() {
            if (this.printOptions = this.generalSettingDataService.getGeneralSettingBySettingType(ve.PRINT_SETTINGS), this.activatedRouter.snapshot.paramMap.has("purchase_id")) {
                let e = +this.activatedRouter.snapshot.paramMap.get("purchase_id");
                this.loaderService.show(), this.service.getById(e).subscribe({
                    next: a => {
                        this.configService.appConfig$.subscribe({
                            next: i => {
                                this.account = i
                            },
                            error: i => {
                                console.error(i)
                            }
                        }), this.purchase = a
                    },
                    error: a => {
                        console.error(a)
                    }
                }).add(() => {
                    this.loaderService.hide()
                })
            }
        }
        static {
            this.\u0275fac = function(a) {
                return new(a || t)(P(B), P(re))
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-purchase-receipt"]
                ],
                standalone: !1,
                decls: 14,
                vars: 13,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mb-3", "mt-2"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text"],
                    [1, "print-actions-bar"],
                    [3, "entityId", "entityName"],
                    ["buttonType", "default", "text", "view_purchase", 1, "float-end", "mx-1", 3, "routerLink"],
                    [3, "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType"],
                    ["id", "print-section", 1, "container-fluid"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [1, "row", "mt-2"],
                    [3, "columns", "rows"],
                    [3, "isPurchase", "rows"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"]
                ],
                template: function(a, i) {
                    a & 1 && (p(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), m(5, "app-payment-status", 4), p(6, "span", 5), b(7), l(), p(8, "div", 6), m(9, "app-send-whats-app-btn", 7)(10, "app-dx-outline-button", 8)(11, "app-print-button", 9)(12, "app-share-btn", 10), l()()()(), d(13, un, 13, 12, "div", 11), l()()), a & 2 && (n(5), o("iconType", i.statusIconTypeList.TITLE)("status", i.purchase == null ? null : i.purchase.status), n(2), k(i.purchase == null ? null : i.purchase.purchase_number), n(2), o("entityId", i.purchase == null ? null : i.purchase.id)("entityName", i.ENTITIES.PURCHASE.name), n(), o("routerLink", j("/purchases/", i.purchase == null ? null : i.purchase.id)), n(), o("entityId", i.purchase == null ? null : i.purchase.id)("entityName", i.ENTITIES.PURCHASE.name)("isVisiblePrintButton", !0), n(), o("entityId", i.purchase == null ? null : i.purchase.id)("entityType", i.ENTITIES.PURCHASE.name), n(), u(i.purchase ? 13 : -1))
                },
                dependencies: [qe, ht, yt, Ht, vt, pe, ct, Lt, ue, St, Yt, Tt, oe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ti = (() => {
    class t {
        constructor() {
            this.formatMessage = _
        }
        ngOnInit() {}
        static {
            this.\u0275fac = function(a) {
                return new(a || t)
            }
        }
        static {
            this.\u0275cmp = x({
                type: t,
                selectors: [
                    ["app-purchase"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(a, i) {
                    a & 1 && (p(0, "div", 0), m(1, "router-outlet"), l())
                },
                dependencies: [je],
                encapsulation: 2
            })
        }
    }
    return t
})();
var _n = [{
        path: "",
        component: ti,
        children: [{
            path: "list",
            component: Jt,
            canActivate: [W],
            data: {
                tab_index: 0,
                permissions: {
                    only: [g.PURCHASE_LIST]
                }
            },
            title: "BytePhase Purchase | List"
        }, {
            path: "add",
            component: Te,
            canActivate: [W],
            data: {
                permissions: {
                    only: [g.PURCHASE_WRITE]
                }
            },
            title: "BytePhase Purchase | Add"
        }, {
            path: ":purchase_id",
            component: Te,
            canActivate: [W],
            data: {
                permissions: {
                    only: [g.PURCHASE_LIST]
                }
            },
            title: "BytePhase Purchase | Details"
        }, {
            path: ":purchase_id/invoices",
            component: ei,
            canActivate: [W],
            data: {
                permissions: {
                    only: [g.PURCHASE_LIST]
                }
            },
            title: "BytePhase Purchase | Invoice"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }, {
            path: "**",
            redirectTo: "/errors/404"
        }]
    }],
    ii = (() => {
        class t {
            static {
                this.\u0275fac = function(a) {
                    return new(a || t)
                }
            }
            static {
                this.\u0275mod = X({
                    type: t
                })
            }
            static {
                this.\u0275inj = Q({
                    imports: [Ce.forChild(_n), Ce]
                })
            }
        }
        return t
    })();
var Fo = (() => {
    class t {
        static {
            this.\u0275fac = function(a) {
                return new(a || t)
            }
        }
        static {
            this.\u0275mod = X({
                type: t
            })
        }
        static {
            this.\u0275inj = Q({
                imports: [Re, ii, Xt]
            })
        }
    }
    return t
})();
export {
    Fo as PurchaseModule
};