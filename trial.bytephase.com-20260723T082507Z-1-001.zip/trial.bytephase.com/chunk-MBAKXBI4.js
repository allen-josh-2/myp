import {
    We as o,
    aa as e,
    da as i,
    ti as c,
    ui as n
} from "./chunk-GOPIAW4V.js";
var u = (() => {
    class t extends c {
        constructor(r) {
            super(r, o), this.api = r
        }
        static {
            this.\u0275fac = function(s) {
                return new(s || t)(i(n))
            }
        }
        static {
            this.\u0275prov = e({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
export {
    u as a
};