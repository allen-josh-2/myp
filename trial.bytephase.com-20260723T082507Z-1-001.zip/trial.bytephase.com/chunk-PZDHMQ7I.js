import {
    a as C
} from "./chunk-RW3SLQZQ.js";
import {
    Od as h,
    Sf as A,
    Tf as d,
    Uf as P,
    Vf as n,
    Wf as o,
    Xf as s,
    aa as p,
    dd as u,
    ea as i,
    ui as l
} from "./chunk-GOPIAW4V.js";
var g = (() => {
    class r {
        constructor() {
            this.centralApi = i(C), this.tenantApi = i(l), this.http = i(u)
        }
        getPlans(t) {
            let e = {};
            return t && (e.country_id = t), this.centralApi.getWithParams(A, e)
        }
        detectCountry() {
            return this.centralApi.get(d)
        }
        validateCoupon(t, e, I, c) {
            let a = {
                code: t,
                plan_id: e,
                currency_code: I
            };
            return c && (a.tenant_id = c), this.centralApi.post(P, a)
        }
        createProspect(t) {
            return this.centralApi.post(o, t)
        }
        prospectCheckout(t, e) {
            return this.centralApi.post(`${o}/${t}/checkout`, e || {})
        }
        checkProspectStatus(t) {
            return this.centralApi.get(`${o}/${t}/status`)
        }
        checkOrderStatus(t) {
            return this.tenantApi.get(`${n}/${t}/status`)
        }
        checkout(t) {
            return this.tenantApi.post(n, t)
        }
        getInvoices() {
            return this.tenantApi.get(s)
        }
        downloadInvoice(t) {
            return this.http.get(h + `${s}/${t}/download`, {
                responseType: "blob"
            })
        }
        getAddOns() {
            return this.tenantApi.get(`${n}/add-ons`)
        }
        checkoutAddOn(t) {
            return this.tenantApi.post(`${n}/add-on`, t)
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || r)
            }
        }
        static {
            this.\u0275prov = p({
                token: r,
                factory: r.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return r
})();
export {
    g as a
};