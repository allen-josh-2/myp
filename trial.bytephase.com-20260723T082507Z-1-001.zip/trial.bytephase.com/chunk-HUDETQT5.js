import {
    O as f,
    Y as m
} from "./chunk-DCKGQUHB.js";
import {
    aa as a,
    da as o,
    li as u,
    sd as c,
    xk as n
} from "./chunk-GOPIAW4V.js";
var b = (() => {
    class i {
        constructor(t, e, r) {
            this.service = t, this.router = e, this.notifyService = r
        }
        canActivate(t, e) {
            return new Promise((r, p) => {
                this.service.appConfig$.subscribe({
                    next: s => this.hasAccessToEntity(t.data ? .entity, s ? .plan) ? r(!0) : (this.router.navigate(["/jobs"]), this.notifyService.error(n("notification_module_access_denied"), n("notification_unauthorized_access"), {
                        disableTimeOut: !0
                    }), r(!1)),
                    error: s => {
                        console.error(s)
                    }
                }).add(() => p(!1))
            })
        }
        hasAccessToEntity(t, e) {
            return !!u[e.toUpperCase()].includes(t.name)
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || i)(o(m), o(c), o(f))
            }
        }
        static {
            this.\u0275prov = a({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
export {
    b as a
};