import {
    e as s
} from "./chunk-LJZ7ZJF4.js";
import {
    i
} from "./chunk-FBFWB55K.js";

function a() {
    let t = window.navigator.connection || window.navigator.mozConnection || window.navigator.webkitConnection,
        n = "unknown",
        e = t ? t.type || t.effectiveType : null;
    if (e && typeof e == "string") switch (e) {
        case "bluetooth":
        case "cellular":
            n = "cellular";
            break;
        case "none":
            n = "none";
            break;
        case "ethernet":
        case "wifi":
        case "wimax":
            n = "wifi";
            break;
        case "other":
        case "unknown":
            n = "unknown";
            break;
        case "slow-2g":
        case "2g":
        case "3g":
            n = "cellular";
            break;
        case "4g":
            n = "wifi";
            break;
        default:
            break
    }
    return n
}
var o = class extends s {
        constructor() {
            super(), this.handleOnline = () => {
                let e = {
                    connected: !0,
                    connectionType: a()
                };
                this.notifyListeners("networkStatusChange", e)
            }, this.handleOffline = () => {
                let n = {
                    connected: !1,
                    connectionType: "none"
                };
                this.notifyListeners("networkStatusChange", n)
            }, typeof window < "u" && (window.addEventListener("online", this.handleOnline), window.addEventListener("offline", this.handleOffline))
        }
        getStatus() {
            return i(this, null, function*() {
                if (!window.navigator) throw this.unavailable("Browser does not support the Network Information API");
                let n = window.navigator.onLine,
                    e = a();
                return {
                    connected: n,
                    connectionType: n ? e : "none"
                }
            })
        }
    },
    l = new o;
export {
    l as Network, o as NetworkWeb
};