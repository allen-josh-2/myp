import {
    $c as je,
    Aa as Me,
    Ad as qe,
    Ba as Ie,
    Bd as Je,
    Ce as at,
    Ea as Ve,
    Fb as ke,
    Fd as ze,
    Lb as Ue,
    Nc as We,
    Sa as De,
    T as B,
    Ta as Ee,
    Td as Xe,
    Vd as Ze,
    Wc as Ge,
    Wd as et,
    Xa as Pe,
    Xd as N,
    Yd as tt,
    Zd as it,
    aa as ge,
    ba as k,
    ca as ye,
    ec as Ne,
    g as ae,
    ha as we,
    ia as Se,
    ka as Le,
    ke as nt,
    lb as Oe,
    m as le,
    ma as Te,
    nb as Ae,
    ne as ot,
    ob as Fe,
    qd as He,
    va as be,
    wb as _t,
    wd as $e,
    xb as Be,
    xc as U,
    xd as Qe,
    yb as Re,
    yd as Ke,
    zd as Ye
} from "./chunk-DCKGQUHB.js";
import {
    $a as C,
    $b as D,
    $g as _e,
    Ab as Z,
    Ba as J,
    Ca as G,
    Ec as ie,
    Fa as o,
    Fh as I,
    Hb as ee,
    Ib as v,
    Ig as ce,
    Jb as V,
    Ka as T,
    Kb as M,
    Kc as ne,
    Mc as oe,
    Na as A,
    Pb as y,
    Qb as w,
    Rb as S,
    Sa as b,
    Th as Ce,
    Ug as me,
    Wb as j,
    Yh as fe,
    Zd as de,
    _a as h,
    aa as K,
    bc as te,
    da as Y,
    ea as g,
    eb as a,
    fb as r,
    gb as p,
    gc as P,
    ha as c,
    hb as x,
    hc as F,
    hi as O,
    ia as m,
    ic as H,
    lh as ue,
    mh as he,
    oa as q,
    pd as se,
    qa as E,
    qb as f,
    sb as _,
    sd as re,
    ti as xe,
    ub as l,
    ui as ve,
    xi as R,
    xk as u,
    yb as z,
    yg as pe,
    zb as X,
    zg as $
} from "./chunk-GOPIAW4V.js";
import {
    h as mt
} from "./chunk-FBFWB55K.js";

function Ct(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-follow-up-popup", 5), _("followUpCancelClick", function() {
            c(e);
            let t = l();
            return m(t.onCloseContextMenuOption())
        })("followUpSaveClick", function() {
            c(e);
            let t = l();
            return m(t.onFollowupPopupSaveAction())
        }), p()
    }
    if (i & 2) {
        let e = l();
        a("isVisiblePopup", e.selectedContextMenuItem === e.followUpContextMenuList.FOLLOW_UP)("lead", e.lead)
    }
}

function ft(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-add-customer-popup", 6), _("addCustomerClose", function() {
            c(e);
            let t = l();
            return m(t.onCloseContextMenuOption())
        })("addCustomerSave", function(t) {
            c(e);
            let s = l();
            return m(s.onConvertToCustomerSaveAction(t))
        }), p()
    }
    if (i & 2) {
        let e = l();
        a("customer", e.lead)("isLead", !0)("isVisiblePopup", e.selectedContextMenuItem === e.followUpContextMenuList.CUSTOMER)("shouldRedirectToJob", !0)
    }
}

function xt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-subscribe-to-mailchimp-popup", 7), _("cancelClick", function() {
            c(e);
            let t = l();
            return m(t.onCloseContextMenuOption())
        })("saveClick", function() {
            c(e);
            let t = l();
            return m(t.onFollowupPopupSaveAction())
        }), p()
    }
    if (i & 2) {
        let e = l();
        a("isVisiblePopup", e.selectedContextMenuItem === e.followUpContextMenuList.SUBSCRIBE_TO_MAILCHIMP)("selectedRows", e.selectedRows)
    }
}
var st = (() => {
    class i {
        constructor(e) {
            this.service = e, this.formatMessage = u, this.buttonText = "Lead Actions", this.isIconOnly = !1, this.leadContextMenuOnAction = new q, this.userSessionService = g(k), this.isMobileDevice = g(B).isMobileDevice(), this.userPermissionList = this.userSessionService.userPermissionList(), this.followUpContextMenuList = Ce, this.selectedContextMenuItem = null, this.contextMenuItems = [], this.isVisibleArchiveDeletePopup = !1, this.archiveDeleteMode = E("delete"), this.entity = O.LEAD
        }
        ngOnInit() {
            this.contextMenuItems = [{
                name: this.followUpContextMenuList.FOLLOW_UP,
                icon: "arrowright",
                visible: this.userPermissionList.includes(I.FOLLOW_UP_WRITE)
            }, {
                name: this.followUpContextMenuList.CUSTOMER,
                icon: "user"
            }, {
                name: this.followUpContextMenuList.SUBSCRIBE_TO_MAILCHIMP,
                icon: "fab fa-mailchimp",
                visible: this.userPermissionList.includes(I.MAIL_MARKETING_WRITE)
            }, {
                name: this.followUpContextMenuList.DELETE,
                icon: "fa-thin fa-trash",
                visible: this.userPermissionList.includes(I.LEAD_DELETE)
            }]
        }
        onContextMenuItemClick(e) {
            this.selectedRows === void 0 && (this.selectedRows = [this.lead]), this.selectedContextMenuItem = e.itemData.name, this.selectedContextMenuItem === this.followUpContextMenuList.DELETE && (this.archiveDeleteMode.set(this.lead.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0)
        }
        handleArchiveDeleteSuccess(e) {
            this.isVisibleArchiveDeletePopup = !1, this.selectedContextMenuItem = null, this.leadContextMenuOnAction.emit(this.lead)
        }
        onFollowupPopupSaveAction() {
            this.leadContextMenuOnAction.emit(this.lead)
        }
        onConvertToCustomerSaveAction(e) {
            this.service.updateStatus(this.lead ? .id, {
                status_id: 3
            }).subscribe({
                next: () => {
                    this.leadContextMenuOnAction.emit(this.lead)
                },
                error: n => {
                    console.error(n)
                }
            })
        }
        onCloseContextMenuOption() {
            this.selectedContextMenuItem = null
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || i)(T(R))
            }
        }
        static {
            this.\u0275cmp = A({
                type: i,
                selectors: [
                    ["app-lead-context-menu"]
                ],
                inputs: {
                    lead: "lead",
                    buttonText: "buttonText",
                    isIconOnly: "isIconOnly",
                    selectedRows: "selectedRows"
                },
                outputs: {
                    leadContextMenuOnAction: "leadContextMenuOnAction"
                },
                standalone: !1,
                decls: 5,
                vars: 19,
                consts: [
                    ["displayExpr", "name", "hint", "Perform Lead Operations", "keyExpr", "name", 3, "onItemClick", "items", "showArrowIcon", "splitButton", "stylingMode", "text", "icon", "type"],
                    [3, "isVisiblePopup", "lead"],
                    [3, "customer", "isLead", "isVisiblePopup", "shouldRedirectToJob"],
                    [3, "isVisiblePopup", "selectedRows"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "entityNumberField", "mode"],
                    [3, "followUpCancelClick", "followUpSaveClick", "isVisiblePopup", "lead"],
                    [3, "addCustomerClose", "addCustomerSave", "customer", "isLead", "isVisiblePopup", "shouldRedirectToJob"],
                    [3, "cancelClick", "saveClick", "isVisiblePopup", "selectedRows"]
                ],
                template: function(n, t) {
                    n & 1 && (r(0, "dx-drop-down-button", 0), _("onItemClick", function(L) {
                        return t.onContextMenuItemClick(L)
                    }), p(), h(1, Ct, 1, 2, "app-follow-up-popup", 1), h(2, ft, 1, 4, "app-add-customer-popup", 2), h(3, xt, 1, 2, "app-subscribe-to-mailchimp-popup", 3), r(4, "app-archive-delete-popup", 4), S("isVisibleChange", function(L) {
                        return w(t.isVisibleArchiveDeletePopup, L) || (t.isVisibleArchiveDeletePopup = L), L
                    }), _("onSuccess", function(L) {
                        return t.handleArchiveDeleteSuccess(L)
                    })("onCancel", function() {
                        return t.onCloseContextMenuOption()
                    }), p()), n & 2 && (ee(t.isIconOnly ? "menu" : "text-icon"), a("items", t.contextMenuItems)("showArrowIcon", !(t.isIconOnly || t.isMobileDevice))("splitButton", !t.isIconOnly)("stylingMode", t.isIconOnly || t.isMobileDevice ? "text" : "outlined")("text", t.isIconOnly || t.isMobileDevice ? "" : t.buttonText)("icon", t.isIconOnly || t.isMobileDevice ? "fa-thin fa-gear" : "")("type", t.isIconOnly || t.isMobileDevice ? "normal" : "default"), o(), C(t.lead != null && t.lead.id && t.selectedContextMenuItem === t.followUpContextMenuList.FOLLOW_UP ? 1 : -1), o(), C(t.lead != null && t.lead.id && t.selectedContextMenuItem === t.followUpContextMenuList.CUSTOMER ? 2 : -1), o(), C(t.lead != null && t.lead.id && t.selectedContextMenuItem === t.followUpContextMenuList.SUBSCRIBE_TO_MAILCHIMP ? 3 : -1), o(), y("isVisible", t.isVisibleArchiveDeletePopup), a("service", t.service)("entity", t.lead)("entityName", t.entity == null ? null : t.entity.name)("entityDisplayName", t.entity == null ? null : t.entity.displayName)("entityNumberField", "name")("mode", t.archiveDeleteMode()))
                },
                dependencies: [He, at, ot, N, Ne],
                encapsulation: 2
            })
        }
    }
    return i
})();
var Q = mt(_t());
var rt = (() => {
    class i extends xe {
        constructor(e) {
            super(e, de), this.api = e
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || i)(Y(ve))
            }
        }
        static {
            this.\u0275prov = K({
                token: i,
                factory: i.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return i
})();
var yt = (i, d, e) => [i, d, e],
    W = i => ({
        "background-color": i
    }),
    dt = i => ({
        color: i
    });

function wt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-empty-state", 4), _("primaryButtonClick", function() {
            c(e);
            let t = l();
            return m(t.router.navigate(["/leads/add"]))
        })("secondaryButtonClick", function() {
            c(e);
            let t = l();
            return m(t.importService.navigateToImportsUrl())
        }), p()
    }
    if (i & 2) {
        let e = l();
        a("icon", "dx-icon-user")("title", e.formatMessage("empty_state_lead_title"))("description", e.formatMessage("empty_state_lead_description"))("primaryButtonText", "empty_state_lead_primary_button")("secondaryButtonText", "import_title")("secondaryButtonVisible", !0)("quickTipsVisible", !0)("quickTips", te(10, yt, e.formatMessage("empty_state_lead_tip_1"), e.formatMessage("empty_state_lead_tip_2"), e.formatMessage("empty_state_lead_tip_3")))("tutorialUrl", "https://www.youtube.com/watch?v=dNKq4PWU3f8")("tutorialVisible", !0)
    }
}

function St(i, d) {
    i & 1 && (r(0, "div", 5), x(1, "app-skeleton-loader", 14), p()), i & 2 && (o(), a("rows", 10)("columns", 3))
}

function Lt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "app-dx-outline-button", 16), _("onClickEvent", function() {
            c(e);
            let t = l(3);
            return m(t.subScribeToMailchimp())
        }), p()()
    }
    if (i & 2) {
        let e = l(3);
        o(), a("isVisibleIcon", !0)("text", e.isMobileDevice ? "" : "Mailchimp")
    }
}

function Tt(i, d) {
    i & 1 && (x(0, "dxo-selection", 15), b(1, Lt, 2, 2, "div", 9)), i & 2 && (a("allowSelectAll", !0), o(), a("dxTemplateOf", "subscribeToMailchimpButtonTemplate"))
}

function bt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "app-dx-outline-button", 17), _("onClickEvent", function() {
            c(e);
            let t = l(2);
            return m(t.importService.navigateToImportsUrl("lead"))
        }), p()()
    }
    if (i & 2) {
        let e = l(2);
        o(), a("isVisibleIcon", !0)("title", e.importBtnLabel)
    }
}

function Mt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "dx-button", 18), _("onClick", function() {
            c(e);
            let t = l(2);
            return m(t.clearAllFilters())
        }), p()()
    }
}

function It(i, d) {
    i & 1 && (r(0, "div", 20), x(1, "app-dx-outline-button", 33), p()), i & 2 && (o(), a("isVisibleIcon", !0))
}

function Vt(i, d) {
    if (i & 1 && (r(0, "span", 34), v(1), p()), i & 2) {
        let e = l(5);
        o(), V(e.filterCount)
    }
}

function Dt(i, d) {
    if (i & 1 && (r(0, "div"), v(1, " All Filters "), h(2, Vt, 2, 1, "span", 34), p()), i & 2) {
        let e = l(4);
        o(2), C(e.filterCount > 0 ? 2 : -1)
    }
}

function Et(i, d) {
    i & 1 && (r(0, "dx-button", 21), b(1, Dt, 3, 1, "div", 9), p()), i & 2 && (o(), a("dxTemplateOf", "template"))
}

function Pt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-employee-dropdown", 35), _("ngModelChange", function(t) {
            c(e);
            let s = l(3);
            return m(s.updatesOnAssigneeId(t))
        }), p()
    }
    if (i & 2) {
        let e = l(3);
        a("ngModel", e.assignedId)("entity", e.entity)
    }
}

function Ot(i, d) {
    if (i & 1 && (r(0, "div")(1, "div"), x(2, "i", 37), v(3), r(4, "span", 38), v(5), p()()()), i & 2) {
        let e = d.$implicit;
        o(3), M(" ", e.key, " "), o(), a("ngStyle", D(3, W, e.hex_color)), o(), V(e.group_count)
    }
}

function At(i, d) {
    if (i & 1 && x(0, "i", 41), i & 2) {
        let e = l().$implicit;
        a("ngStyle", D(1, dt, e && e.hex_color))
    }
}

function Ft(i, d) {
    if (i & 1 && (r(0, "div")(1, "small", 39)(2, "div", 40), h(3, At, 1, 3, "i", 41), r(4, "span", 42), v(5), p()(), r(6, "div", 43), v(7), p()()()), i & 2) {
        let e = d.$implicit;
        o(3), C(e && e.hex_color ? 3 : -1), o(2), M(" ", e.name, " "), o(), a("ngStyle", D(4, W, e.hex_color)), o(), M(" ", e.lead_count, " ")
    }
}

function Bt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "dx-tag-box", 36), _("onValueChanged", function(t) {
            c(e);
            let s = l(3);
            return m(s.statusChange(t))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(3);
            return w(s.selectedStatusIds, t) || (s.selectedStatusIds = t), m(t)
        }), b(1, Ot, 6, 5, "div", 9)(2, Ft, 8, 6, "div", 9), p()
    }
    if (i & 2) {
        let e = l(3);
        y("ngModel", e.selectedStatusIds), a("acceptCustomValue", !1)("dataSource", e.statusDataSource)("grouped", !0)("maxDisplayedTags", 2)("multiline", !1)("placeholder", e.formatMessage("lead_status_placeholder"))("searchEnabled", !0)("showMultiTagOnly", !1)("showSelectionControls", !0)("width", e.isMobileDevice ? 243 : 225), o(), a("dxTemplateOf", "group"), o(), a("dxTemplateOf", "item")
    }
}

function Rt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "div", 19), h(2, It, 2, 1, "div", 20)(3, Et, 2, 1, "dx-button", 21), r(4, "div", 22)(5, "div", 23)(6, "dx-select-box", 24), P(7, "async"), _("onValueChanged", function() {
            c(e);
            let t = l(2);
            return m(t.filterOnValueChange("lead"))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return w(s.sourceId, t) || (s.sourceId = t), m(t)
        }), p()(), r(8, "div", 23)(9, "dx-select-box", 25), _("onValueChanged", function() {
            c(e);
            let t = l(2);
            return m(t.filterOnValueChange("lead"))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return w(s.dateRange, t) || (s.dateRange = t), m(t)
        }), p()(), r(10, "div", 23)(11, "app-user-type-dropdown", 26), _("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return m(s.updatesOnRoleId(t))
        }), p()(), r(12, "div", 23)(13, "dx-select-box", 27), P(14, "async"), _("onSelectionChanged", function(t) {
            c(e);
            let s = l(2);
            return m(s.getCityListFromStateList(t))
        })("onValueChanged", function() {
            c(e);
            let t = l(2);
            return m(t.filterOnValueChange("lead"))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return w(s.stateName, t) || (s.stateName = t), m(t)
        }), p()(), r(15, "div", 23)(16, "dx-select-box", 28), P(17, "async"), _("onValueChanged", function() {
            c(e);
            let t = l(2);
            return m(t.filterOnValueChange("lead"))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return w(s.cityName, t) || (s.cityName = t), m(t)
        }), p()(), r(18, "div", 23), h(19, Pt, 1, 2, "app-employee-dropdown", 29), p(), r(20, "div", 23), h(21, Bt, 3, 13, "dx-tag-box", 30), p(), r(22, "div", 23)(23, "app-report-duration-dropdown", 31), _("durationDateChanges", function(t) {
            c(e);
            let s = l(2);
            return m(s.setReportForDuration(t))
        }), p()(), r(24, "div", 23)(25, "dx-select-box", 32), _("onValueChanged", function() {
            c(e);
            let t = l(2);
            return m(t.filterOnValueChange("lead"))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return w(s.selectedArchiveStatus, t) || (s.selectedArchiveStatus = t), m(t)
        }), p()()()()()
    }
    if (i & 2) {
        let e = l(2);
        o(2), C(e.isMobileDevice ? 2 : 3), o(4), y("ngModel", e.sourceId), a("items", F(7, 32, e.sources$))("showClearButton", !0)("width", e.isMobileDevice ? 243 : "")("placeholder", e.formatMessage("filter_by_source_placeholder")), o(3), y("ngModel", e.dateRange), a("items", e.followUpDateRangeFilter)("showClearButton", !0)("width", e.isMobileDevice ? 243 : "")("placeholder", e.formatMessage("filter_by_follow_up_date_placeholder")), o(2), a("ngModel", e.roleId)("isCustomerTypes", !0)("isFilter", !0), o(2), y("ngModel", e.stateName), a("items", F(14, 34, e.stateList$))("searchEnabled", !0)("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), o(3), y("ngModel", e.cityName), a("items", F(17, 36, e.cityList$))("searchEnabled", !0)("showClearButton", !0)("width", e.isMobileDevice ? 243 : ""), o(3), C(e.isMobileDevice ? 19 : -1), o(2), C(e.isMobileDevice ? 21 : -1), o(2), a("isInDropdown", !0), o(2), y("ngModel", e.selectedArchiveStatus), a("items", e.archiveStatusOptions)("showClearButton", !1)("width", e.isMobileDevice ? 243 : "")("placeholder", e.formatMessage("archive_status"))
    }
}

function kt(i, d) {
    if (i & 1 && (r(0, "div"), x(1, "app-user-badge", 44), p()), i & 2) {
        let e = d.$implicit,
            n = l(2);
        o(), a("entity", n.entity)("iconOnly", !1)("user", e.data)
    }
}

function Ut(i, d) {
    if (i & 1 && (r(0, "div"), x(1, "span", 45), P(2, "safe"), p()), i & 2) {
        let e = d.$implicit;
        o(), a("innerHTML", H(2, 1, e.value, "html"), J)
    }
}

function Nt(i, d) {
    if (i & 1 && x(0, "app-copy-to-clipboard", 48), i & 2) {
        let e = l().$implicit;
        a("textToBeCopied", e.value)
    }
}

function Wt(i, d) {
    if (i & 1 && (r(0, "div", 46)(1, "span")(2, "a", 47), v(3), p()(), h(4, Nt, 1, 1, "app-copy-to-clipboard", 48), p()), i & 2) {
        let e = d.$implicit;
        o(2), a("href", j("mailto:", e.value), G), o(), V(e.value), o(), C(e.value ? 4 : -1)
    }
}

function Gt(i, d) {
    if (i & 1 && x(0, "app-copy-to-clipboard", 48), i & 2) {
        let e = l().$implicit;
        a("textToBeCopied", e.value)
    }
}

function jt(i, d) {
    if (i & 1 && (r(0, "div")(1, "span")(2, "a", 47), v(3), p()(), h(4, Gt, 1, 1, "app-copy-to-clipboard", 48), p()), i & 2) {
        let e = d.$implicit;
        o(2), a("href", j("tel:", e.value), G), o(), V(e.value), o(), C(e.value ? 4 : -1)
    }
}

function Ht(i, d) {
    if (i & 1 && (r(0, "div"), x(1, "app-job-status-tag", 49), p()), i & 2) {
        let e = d.$implicit,
            n = l(2);
        o(), a("iconType", n.statusIconTypeList.BADGE_SMALL)("status", e.data.status)
    }
}

function $t(i, d) {
    if (i & 1 && (r(0, "div"), v(1), P(2, "dateFormat"), p()), i & 2) {
        let e = d.$implicit;
        o(), M(" ", H(2, 1, e.value, "datetime"), " ")
    }
}

function Qt(i, d) {
    if (i & 1 && (r(0, "div"), x(1, "app-due-date-format", 50), p()), i & 2) {
        let e = d.$implicit,
            n = l(2);
        o(), a("dateTime", e.value)("entity", n.ENTITIES.LEAD)("isDateTime", !0)("status", e.data.status)
    }
}

function Kt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "app-lead-context-menu", 51), _("leadContextMenuOnAction", function() {
            let t = c(e).$implicit,
                s = l(2);
            return m(s.onLeadContextMenuAction(t.data))
        }), p()()
    }
    if (i & 2) {
        let e = d.$implicit,
            n = l(2);
        o(), a("isIconOnly", !0)("lead", e.data)("selectedRows", n.selectedRows)
    }
}

function Yt(i, d) {
    i & 1 && (r(0, "span"), v(1, "Assigned "), p())
}

function qt(i, d) {
    if (i & 1 && (r(0, "div")(1, "span", 52), h(2, Yt, 2, 0, "span"), v(3), p()()), i & 2) {
        let e = l(2);
        o(), a("ngClass", e.isMobileDevice ? "h6" : "h4"), o(), C(e.assignedOnly ? 2 : -1), o(), V(e.formatMessage(e.entity.name))
    }
}

function Jt(i, d) {
    if (i & 1 && (r(0, "div"), x(1, "app-user-badge", 44), p()), i & 2) {
        let e = d.$implicit,
            n = l(2);
        o(), a("entity", n.ENTITIES.EMPLOYEE)("iconOnly", !1)("user", e.value)
    }
}

function zt(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "app-employee-dropdown", 35), _("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return m(s.updatesOnAssigneeId(t))
        }), p()()
    }
    if (i & 2) {
        let e = l(2);
        o(), a("ngModel", e.assignedId)("entity", e.entity)
    }
}

function Xt(i, d) {
    if (i & 1 && (r(0, "div")(1, "div"), x(2, "i", 37), v(3), r(4, "span", 38), v(5), p()()()), i & 2) {
        let e = d.$implicit;
        o(3), M(" ", e.key, " "), o(), a("ngStyle", D(3, W, e.hex_color)), o(), V(e.group_count)
    }
}

function Zt(i, d) {
    if (i & 1 && x(0, "i", 41), i & 2) {
        let e = l().$implicit;
        a("ngStyle", D(1, dt, e && e.hex_color))
    }
}

function ei(i, d) {
    if (i & 1 && (r(0, "div")(1, "small", 39)(2, "div", 40), h(3, Zt, 1, 3, "i", 41), r(4, "span", 42), v(5), p()(), r(6, "div", 43), v(7), p()()()), i & 2) {
        let e = d.$implicit;
        o(3), C(e && e.hex_color ? 3 : -1), o(2), M(" ", e.name, " "), o(), a("ngStyle", D(4, W, e.hex_color)), o(), M(" ", e.lead_count, " ")
    }
}

function ti(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div")(1, "dx-tag-box", 53), _("onValueChanged", function(t) {
            c(e);
            let s = l(2);
            return m(s.statusChange(t))
        }), S("ngModelChange", function(t) {
            c(e);
            let s = l(2);
            return w(s.selectedStatusIds, t) || (s.selectedStatusIds = t), m(t)
        }), b(2, Xt, 6, 5, "div", 9)(3, ei, 8, 6, "div", 9), p()()
    }
    if (i & 2) {
        let e = l(2);
        o(), y("ngModel", e.selectedStatusIds), a("acceptCustomValue", !1)("dataSource", e.statusDataSource)("grouped", !0)("maxDisplayedTags", 2)("multiline", !1)("placeholder", e.formatMessage("lead_status_placeholder"))("searchEnabled", !0)("showMultiTagOnly", !1)("showSelectionControls", !0)("width", e.isMobileDevice ? 243 : 225), o(), a("dxTemplateOf", "group"), o(), a("dxTemplateOf", "item")
    }
}

function ii(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "div", 1), h(1, St, 2, 2, "div", 5), r(2, "dx-data-grid", 6), _("onRowClick", function(t) {
            c(e);
            let s = l();
            return m(s.routerHelperService.onRowClick(t, s.entity))
        })("onSelectionChanged", function(t) {
            c(e);
            let s = l();
            return m(s.onSelectionChanged(t))
        })("onToolbarPreparing", function(t) {
            c(e);
            let s = l();
            return m(s.onToolbarPreparing(t))
        }), h(3, Tt, 2, 2), r(4, "dxo-search-panel", 7), S("textChange", function(t) {
            c(e);
            let s = l();
            return w(s.searchText, t) || (s.searchText = t), m(t)
        }), p(), x(5, "dxo-load-panel", 8), b(6, bt, 2, 2, "div", 9), x(7, "dxo-column-chooser", 10)(8, "dxo-state-storing", 11), b(9, Mt, 2, 0, "div", 9)(10, Rt, 26, 38, "div", 9)(11, kt, 2, 3, "div", 9)(12, Ut, 3, 4, "div", 9)(13, Wt, 5, 4, "div", 12)(14, jt, 5, 4, "div", 9)(15, Ht, 2, 2, "div", 9)(16, $t, 3, 4, "div", 9)(17, Qt, 2, 4, "div", 9)(18, Kt, 2, 3, "div", 9), r(19, "div", 13), b(20, qt, 4, 3, "div", 9), p(), b(21, Jt, 2, 3, "div", 9)(22, zt, 2, 2, "div", 9)(23, ti, 4, 13, "div", 9), p()()
    }
    if (i & 2) {
        let e = l();
        o(), C(e.isLoading() ? 1 : -1), o(), a("columnAutoWidth", !e.isMobileDevice)("columns", e.columns)("dataSource", e.leadStore), o(), C(e.isAnyActiveIntegration() ? 3 : -1), o(), y("text", e.searchText), a("placeholder", e.formatMessage("search_panel_lead_placeholder"))("visible", !0)("width", e.searchPanelWidth), o(), a("enabled", !e.isMobileDevice)("indicatorSrc", e.loaderLogo)("showPane", !1), o(), a("dxTemplateOf", "importPopupBtnTemplate"), o(), a("enabled", !0)("width", e.isMobileDevice ? 250 : 350)("title", e.isMobileDevice ? e.formatMessage("column_chooser_label") : e.formatMessage("sale_column_chooser_title")), o(), a("customLoad", e.loadState)("customSave", e.saveState)("enabled", !0)("storageKey", e.entity.name), o(), a("dxTemplateOf", "clearAllFilters"), o(), a("dxTemplateOf", "allFilters"), o(), a("dxTemplateOf", "leadTemplate"), o(), a("dxTemplateOf", "latestFollowUpCommentTemplate"), o(), a("dxTemplateOf", "emailTemplate"), o(), a("dxTemplateOf", "phoneTemplate"), o(), a("dxTemplateOf", "statusTemplate"), o(), a("dxTemplateOf", "dateTimeTemplate"), o(), a("dxTemplateOf", "dueDateTemplate"), o(), a("dxTemplateOf", "actionTemplate"), o(2), a("dxTemplateOf", "tableHeaderTemplate"), o(), a("dxTemplateOf", "employeeTemplate"), o(), a("dxTemplateOf", "filterByEmployeeTemplate"), o(), a("dxTemplateOf", "filterByStatusTemplate")
    }
}

function ni(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-export-option-pop-up", 54), _("ClosePopupClick", function() {
            c(e);
            let t = l();
            return m(t.closeExportPopUp())
        }), p()
    }
    if (i & 2) {
        let e = l();
        a("assigneeId", e.employeeId)("entity", e.entity)("isVisiblePopup", e.isVisibleExportPopUp)("service", e.service)("sources$", e.sources$)("stateList$", e.stateList$)("statusDataSource", e.statusDataSource)
    }
}

function oi(i, d) {
    if (i & 1) {
        let e = f();
        r(0, "app-subscribe-to-mailchimp-popup", 55), _("cancelClick", function() {
            c(e);
            let t = l();
            return m(t.isVisiblePopup = !1)
        })("saveClick", function() {
            c(e);
            let t = l();
            return m(t.isVisiblePopup = !1)
        }), p()
    }
    if (i & 2) {
        let e = l();
        a("isVisiblePopup", e.isVisiblePopup)("selectedRows", e.selectedRows)
    }
}
var _n = (() => {
    class i {
        get hasTenantLeads() {
            return (this.tenantService.config() ? .entity_counts ? .leads || 0) > 0
        }
        constructor(e, n, t, s, L, pt) {
            this.service = e, this.statusService = n, this.leadSourceService = t, this.stateService = s, this.cityService = L, this.mailchimpService = pt, this.formatMessage = u, this.assignedOnly = !1, this.importBtnLabel = "Import Lead", this.routerHelperService = g(ge), this.filterPersistService = g(Ye), this.dataGridStatePersistService = g(qe), this.userSessionService = g(k), this.dataGridService = g(Je), this.tenantService = g(Oe), this.activatedRouter = g(se), this.toastNotificationService = g(ye), this.importService = g(je), this.router = g(re), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.statusIconTypeList = fe, this.ENTITIES = O, this.isMobileDevice = g(B).isMobileDevice(), this.assignedId = null, this.roleId = null, this.employeeId = null, this.selectedStatusIds = [], this.fromDate = null, this.toDate = null, this.entity = O.LEAD, this.columns = [], this.filterStorageKey = "", this.isVisibleExportPopUp = !1, this.isVisiblePopup = !1, this.actionableDashboardTodayFollowUpsFilter = E(null), this.followUpDateRangeFilter = me, this.loaderLogo = ce, this.archiveStatusOptions = [{
                label: "Active",
                value: "active"
            }, {
                label: "All",
                value: "all"
            }, {
                label: "Archived",
                value: "archived"
            }], this.selectedArchiveStatus = "active", this.isLoading = E(!0), this.hasData = E(!1), this.totalCount = 0, this.loadState = () => this.dataGridStatePersistService.createLoadStateCallback(this.entity.name, this.filterPersistService)(), this.saveState = ct => {
                this.dataGridStatePersistService.createSaveStateCallback(this.entity.name)(ct)
            }, this.filterStorageKey = this.entity.name + "_filters"
        }
        get storageKey() {
            return this.entity.name
        }
        ngOnInit() {
            this.columns = [{
                dataField: "id",
                caption: u("common_id"),
                width: 40,
                visible: !1,
                hidingPriority: 11,
                allowSorting: !0
            }, {
                dataField: "name",
                caption: u("lead_name"),
                width: 140,
                cellTemplate: "leadTemplate",
                allowSorting: !0
            }, {
                dataField: "mobile_number",
                caption: u("common_mobile_number"),
                width: 130,
                cellTemplate: "phoneTemplate",
                allowSorting: !1
            }, {
                dataField: "email",
                caption: u("common_email"),
                hidingPriority: 5,
                cellTemplate: "emailTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "role.display_name",
                caption: u("common_type"),
                hidingPriority: 8,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "assigned_user",
                caption: u("common_assignee"),
                cellTemplate: "employeeTemplate",
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: u("common_created_by"),
                hidingPriority: 2,
                cellTemplate: "employeeTemplate",
                visible: !1,
                showInColumnChooser: this.isEmployee,
                allowSorting: !1
            }, {
                dataField: "source.name",
                caption: u("lead_source"),
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "next_follow_up",
                caption: u("lead_next_follow_up"),
                cellTemplate: "dueDateTemplate",
                width: 155,
                hidingPriority: 10,
                allowSorting: !0
            }, {
                dataField: "latest_follow_up.created_at",
                caption: u("lead_last_follow_up"),
                cellTemplate: "dateTimeTemplate",
                hidingPriority: 9,
                width: 155,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "latest_follow_up.comment",
                caption: u("lead_last_followup_comment"),
                cellTemplate: "latestFollowUpCommentTemplate",
                hidingPriority: 1,
                allowSorting: !1
            }, {
                dataField: "status_id",
                caption: u("common_status"),
                alignment: "left",
                allowSorting: !1,
                cellTemplate: "statusTemplate",
                hidingPriority: 6
            }, {
                dataField: "updated_at",
                caption: u("common_updated_on"),
                hidingPriority: 7,
                width: 155,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: u("common_created_at"),
                hidingPriority: 0,
                width: 155,
                cellTemplate: "dateTimeTemplate",
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "device_type.name",
                caption: u("device_type_name"),
                hidingPriority: 12,
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "device_brand.name",
                caption: u("device_brand_name"),
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "device_model.name",
                caption: u("device_model_name"),
                visible: !1,
                allowSorting: !1
            }, {
                caption: "",
                width: 35,
                hidingPriority: 13,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], Be.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice), this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.assignedOnly = this.activatedRouter.snapshot.data.assigned_only ? ? this.assignedOnly, this.activatedRouter.queryParams.subscribe(e => {
                this.actionableDashboardTodayFollowUpsFilter.set(e.followup_date || null)
            }), this.searchPanelWidth = this.isMobileDevice ? this.entity.searchPanelWidth ? this.entity.searchPanelWidth : 230 : 300, this.getLeads(), this.sources$ = this.leadSourceService.getListByQuery(), this.stateList$ = this.stateService.getListByQuery({
                country_id: this.tenantService ? .config() ? .country_id || pe
            }), this.fetchStatuses(), this.getSavedFilterValues()
        }
        onToolbarPreparing(e) {
            if (e.toolbarOptions.items.push({
                    template: "tableHeaderTemplate",
                    location: "before",
                    locateInMenu: "never"
                }, {
                    template: "filterByStatusTemplate",
                    location: "after",
                    locateInMenu: "auto",
                    visible: !this.isMobileDevice
                }, {
                    template: "filterByEmployeeTemplate",
                    location: "after",
                    locateInMenu: "auto",
                    visible: !this.assignedOnly && !this.employeeId && !this.isMobileDevice
                }, {
                    template: "allFilters",
                    location: "after",
                    locateInMenu: "never",
                    visible: this.isEmployee
                }, ...this.isMobileDevice ? [{
                    location: "after",
                    locateInMenu: "always",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-line-columns",
                        hint: u("column_chooser_label"),
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => this.dataGrid.instance.showColumnChooser()
                    },
                    visible: !0
                }, {
                    location: "after",
                    locateInMenu: "always",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-filter-circle-xmark",
                        hint: u("clear_all_filters"),
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => this.clearAllFilters()
                    },
                    visible: this.isEmployee
                }, {
                    location: "after",
                    locateInMenu: "always",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-file-import",
                        hint: u("import_leads"),
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => this.importService.navigateToImportsUrl("lead")
                    },
                    visible: this.isEmployee && this.userPermissionList.includes(I.LEAD_WRITE)
                }] : [{
                    template: "clearAllFilters",
                    location: "after",
                    locateInMenu: "never",
                    visible: this.isEmployee
                }, {
                    template: "importPopupBtnTemplate",
                    location: "after",
                    locateInMenu: "never",
                    visible: this.isEmployee && this.userPermissionList.includes(I.LEAD_WRITE)
                }], {
                    template: "subscribeToMailchimpButtonTemplate",
                    location: "after",
                    locateInMenu: "auto",
                    visible: !this.isMobileDevice && this.isAnyActiveIntegration()
                }, {
                    location: "after",
                    locateInMenu: "never",
                    widget: "dxButton",
                    options: {
                        icon: "fa-thin fa-file-excel",
                        hint: "Export Leads to Excel",
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => {
                            this.isVisibleExportPopUp = !0
                        }
                    },
                    visible: this.isAdmin && !this.isMobileDevice
                }, {
                    location: "after",
                    locateInMenu: "never",
                    widget: "dxButton",
                    options: {
                        icon: "fa-light fa-plus",
                        hint: "Add New Lead",
                        stylingMode: "outlined",
                        type: "default",
                        onClick: () => {
                            this.router.navigate(["/leads/add"])
                        },
                        visible: this.userPermissionList.includes(I.LEAD_WRITE)
                    }
                }), this.dataGridService.arrangeToolbarItems(e.toolbarOptions.items), this.isMobileDevice) {
                let n = e.toolbarOptions.items.findIndex(t => t ? .name === "columnChooserButton");
                n !== -1 && (e.toolbarOptions.items[n].visible = !1)
            }
        }
        getLeads() {
            this.isLoading.set(!0), this.leadStore = new $e({
                load: e => {
                    let n = this.getQueryParamsDataGrid(e);
                    return this.service.getLeadListByQuery(n).toPromise().then(t => {
                        let s = t.data || [];
                        return this.totalCount = t.total || 0, this.hasData.set(this.totalCount > 0), this.isLoading.set(!1), {
                            data: s,
                            totalCount: this.totalCount
                        }
                    }).catch(t => {
                        throw this.isLoading.set(!1), this.hasData.set(!1), t
                    })
                }
            })
        }
        getQueryParamsDataGrid(e) {
            let n = this.dataGridService.getDataQueryParams(e);
            return this.searchText === "" && this.updateLeadFilterValues(), this.searchText && (n.search_term = this.searchText, this.updateLeadFilterValues()), this.assignedOnly && (n.assigned_only = !0), this.dateRange && (n.date_range = this.dateRange), this.actionableDashboardTodayFollowUpsFilter() && (n.date_range = "Today"), this.assignedId && (n.assignee_id = this.assignedId), this.employeeId && (n.employee_id = this.employeeId), this.selectedStatusIds && this.selectedStatusIds.length && (n.status_ids = this.selectedStatusIds), this.sourceId && (n.source_id = this.sourceId), this.roleId && (n.role_id = this.roleId), this.stateName && (n.state = this.stateName), this.cityName && (n.city = this.cityName), this.fromDate && (n.from_date = this.fromDate), this.toDate && (n.to_date = this.toDate), this.selectedArchiveStatus && this.selectedArchiveStatus !== "active" && (n.archive_status = this.selectedArchiveStatus), n
        }
        onLeadContextMenuAction(e) {
            this.getLeads()
        }
        statusChange(e) {
            this.selectedStatusIds = e.value, this.updateLeadFilterValues(), this.getLeads()
        }
        getCityListFromStateList(e) {
            e ? .selectedItem && (this.cityList$ = this.cityService.getListByQuery({
                state_id: e.selectedItem.id
            }))
        }
        setReportForDuration(e) {
            (0, Q.default)(e.fromDate, "YYYY-MM-DD", !0).isValid() && (0, Q.default)(e.toDate, "YYYY-MM-DD", !0) ? (this.fromDate = e.fromDate, this.toDate = e.toDate) : (this.fromDate = null, this.toDate = null), this.getLeads()
        }
        filterOnValueChange(e) {
            e === O.LEAD.name && this.updateLeadFilterValues(), this.getLeads()
        }
        updateLeadFilterValues() {
            this.leadFilters = {
                searchText: this.searchText,
                roleId: this.roleId,
                sourceId: this.sourceId,
                dateRange: this.dateRange,
                stateName: this.stateName,
                cityName: this.cityName,
                assignedId: this.assignedId,
                selectedStatusIds: this.selectedStatusIds,
                fromDate: this.fromDate,
                toDate: this.toDate,
                selectedArchiveStatus: this.selectedArchiveStatus !== "active" ? this.selectedArchiveStatus : null
            }, this.filterCount = this.filterPersistService.saveAllFiltersInStorage(this.filterStorageKey, this.leadFilters)
        }
        clearAllFilters() {
            this.filterPersistService.clearALlFilters(this.filterStorageKey), this.getSavedFilterValues(), this.dataGrid.instance.clearSorting()
        }
        closeExportPopUp() {
            this.isVisibleExportPopUp = !1
        }
        getSavedFilterValues() {
            let e = this.filterPersistService.getAllSavedFilterValuesFromStorage(this.filterStorageKey);
            this.leadFilters = e.filters, this.filterCount = e.count, this.roleId = this.leadFilters.roleId ? ? null, this.sourceId = this.leadFilters.sourceId ? ? null, this.dateRange = this.leadFilters.dateRange ? ? null, this.stateName = this.leadFilters.stateName ? ? null, this.cityName = this.leadFilters.cityName ? ? null, this.assignedId = this.leadFilters.assignedId ? ? null, this.selectedStatusIds = this.leadFilters.selectedStatusIds ? ? null, this.fromDate = this.leadFilters.fromDate ? ? null, this.toDate = this.leadFilters.toDate ? ? null, this.selectedArchiveStatus = this.leadFilters.selectedArchiveStatus ? ? "active", this.searchText = this.leadFilters.searchText ? ? ""
        }
        onSelectionChanged(e) {
            let n = e.selectedRowsData;
            if (n.length > $) {
                let t = n[n.length - 1];
                this.dataGrid.instance.deselectRows(e.currentSelectedRowKeys), this.toastNotificationService.showRaw({
                    message: `notification_select_limit_exceeded ${$} rows.`,
                    type: _e.WARNING
                })
            }
            this.selectedRows = this.dataGrid.instance.getSelectedRowKeys()
        }
        isAnyActiveIntegration() {
            return !!this.tenantService ? .config() ? .active_integrations ? .some(e => e.service_name === he.MAILCHIMP && e.status === ue.ACTIVE) && !this.isMobileDevice
        }
        subScribeToMailchimp() {
            this.selectedRows ? .length > 0 ? this.isVisiblePopup = !0 : this.toastNotificationService.warning("notification_select_users_hint")
        }
        fetchStatuses() {
            this.service.fetchReport(this.getQueryParamsDataGrid({})).subscribe({
                next: e => {
                    this.statusDataSource = new De(e)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        updatesOnRoleId(e) {
            this.roleId = e, this.filterOnValueChange("lead")
        }
        updatesOnAssigneeId(e) {
            this.assignedId = e, this.filterOnValueChange("lead")
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || i)(T(R), T(nt), T(rt), T(Ke), T(Qe), T(et))
            }
        }
        static {
            this.\u0275cmp = A({
                type: i,
                selectors: [
                    ["app-lead-list"]
                ],
                viewQuery: function(n, t) {
                    if (n & 1 && z(U, 5), n & 2) {
                        let s;
                        X(s = Z()) && (t.dataGrid = s.first)
                    }
                },
                inputs: {
                    assignedOnly: "assignedOnly",
                    importBtnLabel: "importBtnLabel"
                },
                standalone: !1,
                decls: 4,
                vars: 3,
                consts: [
                    [3, "icon", "title", "description", "primaryButtonText", "secondaryButtonText", "secondaryButtonVisible", "quickTipsVisible", "quickTips", "tutorialUrl", "tutorialVisible"],
                    [2, "position", "relative"],
                    [3, "assigneeId", "entity", "isVisiblePopup", "service", "sources$", "stateList$", "statusDataSource"],
                    [3, "isVisiblePopup", "selectedRows"],
                    [3, "primaryButtonClick", "secondaryButtonClick", "icon", "title", "description", "primaryButtonText", "secondaryButtonText", "secondaryButtonVisible", "quickTipsVisible", "quickTips", "tutorialUrl", "tutorialVisible"],
                    [1, "skeleton-overlay"],
                    ["id", "leadGridContainer", 3, "onRowClick", "onSelectionChanged", "onToolbarPreparing", "columnAutoWidth", "columns", "dataSource"],
                    [3, "textChange", "text", "placeholder", "visible", "width"],
                    ["text", "", 3, "enabled", "indicatorSrc", "showPane"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["mode", "select", 3, "enabled", "width", "title"],
                    ["type", "custom", 3, "customLoad", "customSave", "enabled", "storageKey"],
                    ["class", "d-flex flex-row", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex"],
                    ["type", "list", 3, "rows", "columns"],
                    ["mode", "multiple", "selectAllMode", "page", "showCheckBoxesMode", "always", 3, "allowSelectAll"],
                    ["buttonType", "default", "icon", "fab fa-mailchimp", 3, "onClickEvent", "isVisibleIcon", "text"],
                    ["buttonType", "default", "icon", "fa-thin fa-file-import", 3, "onClickEvent", "isVisibleIcon", "title"],
                    ["icon", "fa-thin fa-filter-circle-xmark", "stylingMode", "outlined", "title", "Clear All Filters", "type", "default", 1, "px-1", 3, "onClick"],
                    [1, "dropdown"],
                    ["aria-expanded", "false", "data-bs-auto-close", "outside", "data-bs-toggle", "dropdown"],
                    ["aria-expanded", "false", "data-bs-auto-close", "outside", "data-bs-toggle", "dropdown", "icon", "fa-thin fa-filter-list", "stylingMode", "outlined", "template", "template", "text", "All Filters", "title", "All Filters", "type", "default", 1, "px-1"],
                    [1, "dropdown-menu", "p-2", "theme-secondary-bg"],
                    [1, "mb-3"],
                    ["displayExpr", "name", "valueExpr", "id", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "showClearButton", "width", "placeholder"],
                    [1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "showClearButton", "width", "placeholder"],
                    ["placeholder", "select_lead_type", 3, "ngModelChange", "ngModel", "isCustomerTypes", "isFilter"],
                    ["displayExpr", "name", "id", "address-state", "placeholder", "Select state", "searchMode", "contains", "valueExpr", "name", 1, "dropdown-filter", 3, "onSelectionChanged", "onValueChanged", "ngModelChange", "ngModel", "items", "searchEnabled", "showClearButton", "width"],
                    ["displayExpr", "name", "id", "address-city", "placeholder", "Select city", "searchMode", "contains", "valueExpr", "name", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "searchEnabled", "showClearButton", "width"],
                    ["placeholder", "job_assignee_placeholder", 3, "ngModel", "entity"],
                    ["displayExpr", "name", "selectAllMode", "allPages", "valueExpr", "id", 1, "dropdown-filter", 3, "ngModel", "acceptCustomValue", "dataSource", "grouped", "maxDisplayedTags", "multiline", "placeholder", "searchEnabled", "showMultiTagOnly", "showSelectionControls", "width"],
                    [3, "durationDateChanges", "isInDropdown"],
                    ["displayExpr", "label", "valueExpr", "value", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "items", "showClearButton", "width", "placeholder"],
                    ["buttonType", "default", "icon", "fa-thin fa-filter-list", "title", "common_filters_all", 3, "isVisibleIcon"],
                    [1, "badge", "fw-bold", "rounded-pill", "bg-danger", "ms-1"],
                    ["placeholder", "job_assignee_placeholder", 3, "ngModelChange", "ngModel", "entity"],
                    ["displayExpr", "name", "selectAllMode", "allPages", "valueExpr", "id", 1, "dropdown-filter", 3, "onValueChanged", "ngModelChange", "ngModel", "acceptCustomValue", "dataSource", "grouped", "maxDisplayedTags", "multiline", "placeholder", "searchEnabled", "showMultiTagOnly", "showSelectionControls", "width"],
                    [1, "fa-thin", "fa-grip-dots"],
                    [1, "float-end", "badge", "theme-badge", 3, "ngStyle"],
                    [1, "d-flex", "justify-content-between"],
                    [1, "d-flex", "justify-content-start"],
                    [1, "fas", "fa-circle", "me-1", "mt-2", 3, "ngStyle"],
                    [1, "status-name", "text-truncate", "mt-1"],
                    [1, "badge", "bg-theme", 3, "ngStyle"],
                    [1, "d-flex", "justify-content-start", 3, "entity", "iconOnly", "user"],
                    [3, "innerHTML"],
                    [1, "d-flex", "flex-row"],
                    [3, "href"],
                    [1, "ms-2", 3, "textToBeCopied"],
                    [3, "iconType", "status"],
                    [3, "dateTime", "entity", "isDateTime", "status"],
                    [3, "leadContextMenuOnAction", "isIconOnly", "lead", "selectedRows"],
                    [3, "ngClass"],
                    ["displayExpr", "name", "selectAllMode", "allPages", "valueExpr", "id", 3, "onValueChanged", "ngModelChange", "ngModel", "acceptCustomValue", "dataSource", "grouped", "maxDisplayedTags", "multiline", "placeholder", "searchEnabled", "showMultiTagOnly", "showSelectionControls", "width"],
                    [3, "ClosePopupClick", "assigneeId", "entity", "isVisiblePopup", "service", "sources$", "stateList$", "statusDataSource"],
                    [3, "cancelClick", "saveClick", "isVisiblePopup", "selectedRows"]
                ],
                template: function(n, t) {
                    n & 1 && (h(0, wt, 1, 14, "app-empty-state", 0)(1, ii, 24, 34, "div", 1), h(2, ni, 1, 7, "app-export-option-pop-up", 2), h(3, oi, 1, 2, "app-subscribe-to-mailchimp-popup", 3)), n & 2 && (C(!t.isLoading() && !t.hasTenantLeads && !t.hasData() ? 0 : 1), o(2), C(t.isVisibleExportPopUp ? 2 : -1), o(), C(t.isVisiblePopup ? 3 : -1))
                },
                dependencies: [ie, ne, ke, Ae, ze, Ge, Fe, Ze, N, tt, it, Pe, Le, Xe, we, Se, U, Te, Ie, be, Me, Ve, Ee, We, ae, le, st, oe, Ue, Re],
                encapsulation: 2
            })
        }
    }
    return i
})();
export {
    rt as a, _n as b
};