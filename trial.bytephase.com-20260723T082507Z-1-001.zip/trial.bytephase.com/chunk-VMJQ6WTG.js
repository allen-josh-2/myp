import {
    a as A
} from "./chunk-EPB2WS6Q.js";
import {
    a as x
} from "./chunk-HUDETQT5.js";
import {
    a as ze
} from "./chunk-2KS5UOZO.js";
import {
    a as ye
} from "./chunk-KJCCJCIN.js";
import {
    a as I
} from "./chunk-BLJF2YPR.js";
import {
    $e as E,
    Db as Ee,
    Eb as H,
    Hc as Fe,
    M as T,
    T as j,
    Ta as Se,
    Ud as qe,
    Zd as Ke,
    _b as Me,
    _d as Z,
    _e as Ze,
    ac as we,
    af as Qe,
    ba as B,
    ca as q,
    cb as ke,
    cd as Ue,
    fc as Ve,
    g as ce,
    h as le,
    hb as Pe,
    kb as be,
    lb as K,
    mc as Re,
    n as me,
    nc as Ne,
    ob as Te,
    oc as Le,
    od as je,
    pb as Ie,
    ph as We,
    q as de,
    qb as xe,
    qd as Ge,
    rd as Be,
    sb as Ae,
    t as ue,
    u as _e,
    we as He,
    yc as Oe
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    Ab as O,
    Fa as r,
    Fh as D,
    Jh as k,
    Ka as y,
    Na as P,
    Oa as R,
    Pb as ne,
    Pg as X,
    Qb as re,
    Rb as se,
    Rd as fe,
    Sd as Ce,
    Tc as pe,
    Tg as ge,
    _a as u,
    b as ee,
    ba as w,
    bc as ae,
    c as ie,
    cc as z,
    ea as d,
    eb as n,
    fb as c,
    gb as p,
    ha as f,
    hb as h,
    hi as v,
    ia as C,
    n as te,
    oa as W,
    pa as oe,
    pd as F,
    qa as V,
    qb as S,
    qd as he,
    sb as g,
    sd as U,
    th as ve,
    ub as a,
    vd as Y,
    vh as De,
    vi as G,
    xk as l,
    yb as N,
    zb as L
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    i as M
} from "./chunk-FBFWB55K.js";
var Ye = (() => {
    class i {
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275cmp = P({
                type: i,
                selectors: [
                    ["app-purchase"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(t, o) {
                    t & 1 && (c(0, "div", 0), h(1, "router-outlet"), p())
                },
                dependencies: [he],
                encapsulation: 2
            })
        }
    }
    return i
})();
var $e = ["addressInput"];

function ei(i, m) {
    i & 1 && h(0, "app-skeleton-loader", 3), i & 2 && n("rows", 8)("columns", 3)
}

function ii(i, m) {
    i & 1 && h(0, "app-section-title", 7), i & 2 && n("title", "create_new_pickup_drop")("isVisibleHr", !1)
}

function ti(i, m) {
    i & 1 && h(0, "app-section-title", 7), i & 2 && n("title", "create_new_pickup_drop")("isVisibleHr", !1)
}

function oi(i, m) {
    if (i & 1 && h(0, "app-section-title", 7), i & 2) {
        let e = a(3);
        n("title", e.formatMessage("common_update") + e.formatMessage("job_pickup_drop"))("isVisibleHr", !0)
    }
}

function ni(i, m) {
    if (i & 1 && u(0, ti, 1, 2, "app-section-title", 7)(1, oi, 1, 2, "app-section-title", 7), i & 2) {
        let e = a(2);
        _(e.isCreate ? 0 : 1)
    }
}

function ri(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "app-save-cancel-footer", 32), g("cancelClick", function() {
            f(e);
            let o = a(2);
            return C(o.onClosing())
        }), p()
    }
    if (i & 2) {
        let e = a(2);
        n("gaEvent", "pickup_drop_save_event")("isOnPopup", !1)("isVisibleHr", !1)("isSaving", e.isSaving)
    }
}

function si(i, m) {
    if (i & 1 && h(0, "app-server-error", 10), i & 2) {
        let e = a(2);
        n("errorResponse", e.errorResponse)
    }
}

function ai(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "app-control-container", 13)(1, "app-customer-dropdown", 33), g("itemClick", function(o) {
            f(e);
            let s = a(2);
            return C(s.onCustomerSelect(o))
        }), p()()
    }
    if (i & 2) {
        let e, t = a(2);
        n("errorMsg", t.formatMessage("common_error_messages_customer_required"))("label", t.formatMessage("common_customer")), r(), n("customerId", t.form.getRawValue().id ? (e = t.form.getRawValue()) == null ? null : e.user_id : null)("entity", t.ENTITIES.PICKUP_DROP.name)("formControl", t.form.controls.user_id)("isEditMode", !0)("isRequiredAddress", !0)("isVisibleAddAction", !0)
    }
}

function pi(i, m) {
    if (i & 1 && (c(0, "app-control-container", 22), h(1, "app-employee-dropdown", 34), p()), i & 2) {
        let e = a(2);
        n("errorMsg", e.formatMessage("common_assignee_required"))("label", e.formatMessage("common_assignee"))("tooltipText", "pickup_assigned_user_id"), r(), n("entity", e.entity)
    }
}

function ci(i, m) {
    if (i & 1 && (c(0, "app-control-container", 23), h(1, "dx-select-box", 35), p()), i & 2) {
        let e = a(2);
        n("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("common_status")), r(), n("items", e.statusList)("placeholder", e.formatMessage("common_select_status"))("showClearButton", !0)
    }
}

function li(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "dx-list", 36), g("onItemClick", function(o) {
            f(e);
            let s = a(2);
            return C(s.selectSuggestion(o.itemData))
        }), p()
    }
    if (i & 2) {
        let e = a(2);
        n("items", e.suggestions)
    }
}

function mi(i, m) {
    if (i & 1 && h(0, "app-user-notification-channel", 30), i & 2) {
        let e = a(2);
        n("form", e.form)
    }
}

function di(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "div", 31)(1, "app-save-cancel-footer", 32), g("cancelClick", function() {
            f(e);
            let o = a(2);
            return C(o.onClosing())
        }), p()()
    }
    if (i & 2) {
        let e = a(2);
        r(), n("gaEvent", "pickup_drop_save_event")("isOnPopup", !0)("isVisibleHr", !1)("isSaving", e.isSaving)
    }
}

function ui(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "form", 5), g("ngSubmit", function() {
            f(e);
            let o = a();
            return C(o.save())
        }), c(1, "div", 6)(2, "div", 2), u(3, ii, 1, 2, "app-section-title", 7), c(4, "div", 8)(5, "div"), u(6, ni, 2, 1), p(), u(7, ri, 1, 4, "app-save-cancel-footer", 9), p(), u(8, si, 1, 1, "app-server-error", 10), p()(), c(9, "div", 1)(10, "div", 11), h(11, "dx-radio-group", 12), p(), u(12, ai, 2, 8, "app-control-container", 13), c(13, "app-control-container", 14)(14, "app-restricted-content", 15), h(15, "app-mobile-number", 16)(16, "app-error", 17), p()(), c(17, "app-control-container", 18), h(18, "dx-select-box", 19), p(), c(19, "app-control-container", 20), h(20, "dx-date-box", 21)(21, "app-error", 17), p(), u(22, pi, 2, 4, "app-control-container", 22), u(23, ci, 2, 5, "app-control-container", 23), c(24, "app-control-container", 24)(25, "dx-text-area", 25, 0), g("input", function(o) {
            f(e);
            let s = a();
            return C(s.onInput(o))
        }), p(), u(27, li, 1, 1, "dx-list", 26), p(), c(28, "app-control-container", 27)(29, "app-quick-reply-dropdown", 28), g("itemClick", function(o) {
            f(e);
            let s = a();
            return C(s.quickReplyValue(o))
        }), p(), h(30, "app-textarea", 29), p()(), u(31, mi, 1, 1, "app-user-notification-channel", 30), u(32, di, 2, 4, "div", 31), p()
    }
    if (i & 2) {
        let e = a();
        n("formGroup", e.form), r(3), _(e.isMobileDevice ? 3 : -1), r(3), _(e.isMobileDevice ? -1 : 6), r(), _(e.isMobileDevice ? -1 : 7), r(), _(e.errorResponse ? 8 : -1), r(3), n("items", e.pickupDropList), r(), _(e.isEmployee ? 12 : -1), r(), n("errorMsg", e.formatMessage("common_mobile_required"))("label", e.formatMessage("common_mobile")), r(), n("applyLock", !1)("permission", e.PERMISSION_LIST.CUSTOMER_VIEW_CONTACT_INFORMATION), r(), n("formControl", e.form.controls.mobile_number)("form", e.form), r(), n("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile_number")), r(), n("errorMsg", e.formatMessage("device_type_required_warning"))("label", e.formatMessage("device_type_name")), r(), n("dataSource", e.deviceTypes)("placeholder", e.formatMessage("placeholder_select_device_type_pickup")), r(), n("errorMsg", e.formatMessage("common_error_messages_date_required"))("label", e.formatMessage("common_schedule_on")), r(), n("dateSerializationFormat", e.DATETIME_SERIALIZATION_FORMAT)("displayFormat", e.DISPLAY_DATETIME_SERIALIZATION_FORMAT)("disabledDates", e.disabledDates)("min", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("common_select_from_calendar")), r(), n("displayError", e.form.get("scheduled_on").invalid && e.form.get("scheduled_on").touched && e.form.controls.scheduled_on.getError("outsideBusinessHours"))("errorMsg", e.form.controls.scheduled_on.getError("outsideBusinessHours")), r(), _(e.isEmployee ? 22 : -1), r(), _(e.form.getRawValue().id && e.isEmployee ? 23 : -1), r(), n("errorMsg", e.formatMessage("common_error_messages_address_required"))("label", e.formatMessage("common_address")), r(), n("autoResizeEnabled", !0)("placeholder", e.formatMessage("common_type_address")), r(2), _(e.suggestions != null && e.suggestions.length ? 27 : -1), r(), n("errorMsg", e.formatMessage("common_error_messages_description_required"))("label", e.formatMessage("repair_services_description")), r(2), n("formControl", e.form.controls.comment)("quickReply", e.quickReply), r(), _(e.isEmployee ? 31 : -1), r(), _(e.isMobileDevice ? 32 : -1)
    }
}
var J = (() => {
    class i {
        constructor(e, t, o, s, b) {
            this.service = e, this.deviceTypeService = t, this.customerService = o, this.ngZone = s, this.mapsLoader = b, this.suggestions = [], this.input$ = new ie, this.selectedAddress = "", this.formatMessage = l, this.isVisiblePopup = !1, this.isCreate = !0, this.pickupDropSaveClick = new W, this.pickupDropCancelClick = new W, this.ENTITIES = v, this.generalSettingDataService = d(Ee), this.formService = d(Ie), this.router = d(U), this.userSessionService = d(B), this.tenantService = d(K), this.activatedRouter = d(F), this.isMobileDevice = d(j).isMobileDevice(), this.toastNotificationService = d(q), this.today = new Date, this.isEmployee = this.userSessionService.isEmployee(), this.currentUser = this.userSessionService.currentUser(), this.SETTINGS = ve, this.DATETIME_SERIALIZATION_FORMAT = fe, this.DISPLAY_DATETIME_SERIALIZATION_FORMAT = Ce, this.entity = v.PICKUP_DROP, this.pickupDropList = De, this.isSaving = !1, this.statusList = Object.values(ge), this.customerId = null, this.isBusinessHourSet = V(this.generalSettingDataService.getGeneralSettingByKey(this.SETTINGS.GENERAL_SETTINGS.ENABLE_BUSINESS_HOURS)), this.disabledDates = Ze.getDisabledDates(this.isBusinessHourSet(), this.tenantService ? .config() ? .business_hours), this.PERMISSION_LIST = D
        }
        ngOnInit() {
            this.initPlacesServices(), this.deviceTypeService.getList().subscribe({
                next: t => {
                    this.deviceTypes = t
                },
                error: t => {
                    console.error(t)
                }
            });
            let e = this.activatedRouter.snapshot.paramMap.get("id");
            e ? (this.isCreate = !1, this.service.getById(+e).subscribe({
                next: t => {
                    this.pickupDrop = new E(t), this.initForm()
                },
                error: t => {
                    this.toastNotificationService.error("notification_pickup_drop_not_found"), this.router.navigate(["/pickupDrops/list"])
                }
            })) : (this.isCreate = !0, this.initForm())
        }
        initForm() {
            this.customerId = +this.activatedRouter.snapshot.paramMap.get("customer_id"), !this.customerId && !this.isEmployee && (this.customerId = this.currentUser.id), this.form = E.getForm(new E(this.isCreate ? {} : this.pickupDrop), this.isBusinessHourSet(), this.tenantService ? .config() ? .business_hours), this.customerId && this.customerService.getById(this.customerId).subscribe({
                next: e => {
                    this.form.patchValue({
                        user_id: this.customerId,
                        mobile_number: e.mobile_number,
                        mobile_country_code: e.mobile_country_code
                    }), this.form.get("user_id").disable()
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        initPlacesServices() {
            return M(this, null, function*() {
                try {
                    yield this.mapsLoader.load(), google ? .maps ? .importLibrary && (yield google.maps.importLibrary("places")), this.autocompleteService = new google.maps.places.AutocompleteService;
                    let e = document.createElement("div");
                    this.placesService = new google.maps.places.PlacesService(e), this.sessionToken = new google.maps.places.AutocompleteSessionToken
                } catch (e) {
                    console.error("Error loading map:", e), this.toastNotificationService.error("error_loading_map_check_internet")
                }
            })
        }
        getPredictions(e) {
            return !e || !this.autocompleteService ? te([]) : new ee(t => {
                let o = {
                    input: e
                };
                this.sessionToken && (o.sessionToken = this.sessionToken), this.autocompleteService.getPlacePredictions(o, (s, b) => {
                    t.next(Array.isArray(s) ? s : []), t.complete()
                })
            })
        }
        onInput(e) {
            return M(this, null, function*() {
                let t = e.target.value;
                this.suggestions = yield this.getPredictionsAsync(t)
            })
        }
        getPredictionsAsync(e) {
            return M(this, null, function*() {
                return !e || !this.autocompleteService ? [] : new Promise(t => {
                    let o = {
                        input: e
                    };
                    this.sessionToken && (o.sessionToken = this.sessionToken), this.autocompleteService.getPlacePredictions(o, (s, b) => {
                        t(Array.isArray(s) ? s : [])
                    })
                })
            })
        }
        selectSuggestion(e) {
            this.ngZone.run(() => {
                this.suggestions = [], this.selectedAddress = e.description || "", this.form.patchValue({
                    address: this.selectedAddress
                });
                let t = {
                    placeId: e.place_id,
                    fields: ["formatted_address", "geometry"]
                };
                this.placesService.getDetails(t, (o, s) => {
                    this.ngZone.run(() => {
                        o ? .geometry ? .location ? this.coordinates = {
                            lat: o.geometry.location.lat(),
                            lng: o.geometry.location.lng()
                        } : this.coordinates = null
                    })
                })
            })
        }
        onClosing() {
            this.form.reset(), this.pickupDrop = null, this.router.navigate(["pickupDrops/list"])
        }
        save() {
            this.form.valid ? (this.isSaving = !0, (this.form.getRawValue().id ? this.service.update(this.form.getRawValue()) : this.service.create(this.form.getRawValue())).subscribe({
                next: t => {
                    this.form.getRawValue().id ? this.toastNotificationService.success("notification_pickup_drop_update_success") : this.toastNotificationService.success("notification_schedule_pickup_submit_success"), this.pickupDrop = new E(t), this.isVisiblePopup = !1, this.pickupDropSaveClick.emit(this.pickupDrop)
                },
                error: () => {
                    this.toastNotificationService.error("notification_schedule_pickup_submit_error")
                },
                complete: () => {
                    this.isSaving = !1, this.router.navigate(["/pickupDrops"])
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onCustomerSelect(e) {
            this.form.patchValue({
                mobile_number: e ? .mobile_number,
                mobile_country_code: e ? .mobile_country_code,
                address: e ? .address_line ? [e.address_line, e.city, [e.state, e.zip_code].filter(Boolean).join(" ")].filter(Boolean).join(`
`) : ""
            })
        }
        quickReplyValue(e) {
            this.quickReply = e ? e.comment ? ? e.title : "", this.form.patchValue({
                comment: this.quickReply
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(y(H), y(je), y(G), y(oe), y(Re))
            }
        }
        static {
            this.\u0275cmp = P({
                type: i,
                selectors: [
                    ["app-pickup-and-drop-detail"]
                ],
                viewQuery: function(t, o) {
                    if (t & 1 && N($e, 5), t & 2) {
                        let s;
                        L(s = O()) && (o.suggestions = s.first)
                    }
                },
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate",
                    pickupDrop: "pickupDrop"
                },
                outputs: {
                    pickupDropSaveClick: "pickupDropSaveClick",
                    pickupDropCancelClick: "pickupDropCancelClick"
                },
                standalone: !1,
                decls: 4,
                vars: 2,
                consts: [
                    ["addressInput", ""],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [3, "title", "isVisibleHr"],
                    [1, "d-flex", "justify-content-between"],
                    ["saveText", "common_schedule", "savingText", "common_scheduling", 3, "gaEvent", "isOnPopup", "isVisibleHr", "isSaving"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "d-flex", "justify-content-center", "mb-3", "schedule-pickup-drop"],
                    ["displayExpr", "text", "formControlName", "type", "layout", "horizontal", "valueExpr", "text", 3, "items"],
                    ["name", "user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "mobile_number", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    [3, "applyLock", "permission"],
                    [3, "formControl", "form"],
                    [3, "displayError", "errorMsg"],
                    ["name", "device_type_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "device_type_id", "valueExpr", "id", 3, "dataSource", "placeholder"],
                    ["name", "scheduled_on", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "scheduled_on", "type", "datetime", 3, "dateSerializationFormat", "displayFormat", "disabledDates", "min", "pickerType", "placeholder"],
                    ["name", "assigned_user_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label", "tooltipText"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "address", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "address", "minHeight", "60", 3, "input", "autoResizeEnabled", "placeholder"],
                    ["displayExpr", "description", "selectionMode", "single", 3, "items"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["labelAction", "", 3, "itemClick"],
                    [3, "formControl", "quickReply"],
                    [3, "form"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    ["saveText", "common_schedule", "savingText", "common_scheduling", 3, "cancelClick", "gaEvent", "isOnPopup", "isVisibleHr", "isSaving"],
                    [3, "itemClick", "customerId", "entity", "formControl", "isEditMode", "isRequiredAddress", "isVisibleAddAction"],
                    ["formControlName", "assigned_user_id", "placeholder", "job_assignee_placeholder", 3, "entity"],
                    ["formControlName", "status", 3, "items", "placeholder", "showClearButton"],
                    ["displayExpr", "description", "selectionMode", "single", 3, "onItemClick", "items"]
                ],
                template: function(t, o) {
                    t & 1 && (c(0, "div", 1)(1, "div", 2), u(2, ei, 1, 2, "app-skeleton-loader", 3), u(3, ui, 33, 42, "form", 4), p()()), t & 2 && (r(2), _(!o.form && !o.isCreate ? 2 : -1), r(), _(o.form ? 3 : -1))
                },
                dependencies: [xe, Be, Ae, we, ke, Te, Ue, qe, Ve, be, Ke, Me, He, Oe, Le, Fe, Se, Pe, me, ce, le, de, _e, ue],
                encapsulation: 2
            })
        }
    }
    return i
})();
var _i = (i, m, e, t) => ({
        customer_id: i,
        job_id: m,
        assigned_only: e,
        employee_id: t
    }),
    hi = (i, m, e) => [i, m, e],
    fi = (i, m, e, t) => ({
        icon: "dx-icon-car",
        title: i,
        description: m,
        primaryButtonVisible: !0,
        quickTipsVisible: !0,
        primaryButtonText: e,
        quickTips: t,
        tutorialUrl: "https://www.youtube.com/watch?v=QolIzmafjD8",
        tutorialVisible: !0
    });

function Ci(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "app-pickup-drop-popup", 3), g("pickupDropCancelClick", function() {
            f(e);
            let o = a();
            return C(o.isVisibleSchedulePickupPopup = !1)
        })("pickupDropSaveClick", function() {
            f(e);
            let o = a();
            return C(o.onSchedulePickUpSave())
        }), p()
    }
    if (i & 2) {
        let e = a();
        n("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleSchedulePickupPopup)("pickupDrop", e.schedulePickUp)
    }
}

function gi(i, m) {
    if (i & 1) {
        let e = S();
        c(0, "app-archive-delete-popup", 4), se("isVisibleChange", function(o) {
            f(e);
            let s = a();
            return re(s.isVisibleArchiveDeletePopup, o) || (s.isVisibleArchiveDeletePopup = o), C(o)
        }), g("onSuccess", function(o) {
            f(e);
            let s = a();
            return C(s.handleArchiveDeleteSuccess(o))
        })("onCancel", function() {
            f(e);
            let o = a();
            return C(o.onCloseContextMenuOption())
        }), p()
    }
    if (i & 2) {
        let e = a();
        ne("isVisible", e.isVisibleArchiveDeletePopup), n("service", e.service)("entity", e.currentPickupDrop)("entityName", e.entity.name)("entityDisplayName", e.entity.displayName)("mode", e.archiveDeleteMode())
    }
}
var $ = (() => {
    class i {
        get hasTenantPickupDrops() {
            return (this.tenantService.config() ? .entity_counts ? .pickup_drops || 0) > 0
        }
        constructor(e, t) {
            this.service = e, this.geoLocationService = t, this.formatMessage = l, this.assignedOnly = !1, this.router = d(U), this.userSessionService = d(B), this.activatedRouter = d(F), this.tenantService = d(K), this.isMobileDevice = d(j).isMobileDevice(), this.toastNotificationService = d(q), this.customerService = d(G), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.isVisibleSchedulePickupPopup = !1, this.isCreate = !1, this.employeeId = null, this.ENTITIES = v, this.entity = v.PICKUP_DROP, this.customerId = null, this.jobId = null, this.currentContextMenuAction = null, this.pickupDropContextMenu = [], this.isVisibleArchiveDeletePopup = !1, this.archiveDeleteMode = V("delete"), this.plan = this.tenantService.plan(), this.columns = [{
                dataField: "id",
                caption: l("common_id"),
                width: 40,
                hidingPriority: 7,
                allowSorting: !0,
                visible: !1
            }, {
                dataField: "job_id",
                caption: l("common_job_number"),
                width: this.isMobileDevice ? 110 : 130,
                hidingPriority: 8,
                cellTemplate: "jobIdLinkTemplate",
                allowSorting: !0,
                alignment: "center"
            }, {
                dataField: "type",
                caption: l("common_type"),
                allowSorting: !1,
                visible: !1,
                hidingPriority: 9
            }, {
                dataField: "user",
                caption: l("user_customer"),
                cellTemplate: "userTemplate",
                width: 130,
                allowSorting: !1
            }, {
                dataField: "mobile_number",
                caption: l("common_mobile"),
                cellTemplate: "phoneTemplate",
                hidingPriority: 6,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "device_type.name",
                caption: l("device_type_name"),
                hidingPriority: 5,
                allowSorting: !1
            }, {
                dataField: "address",
                caption: l("address"),
                calculateCellValue: o => o.address ? o.address.split(/\s+/).filter(s => s && s.toLowerCase() !== "null").join(" ").trim() : "",
                hidingPriority: 4,
                allowSorting: !1
            }, {
                dataField: "comment",
                caption: l("common_comment"),
                cellTemplate: "commentTemplate",
                hidingPriority: 3,
                allowSorting: !1,
                visible: !1
            }, {
                dataField: "assigned_user",
                caption: l("common_assignee"),
                cellTemplate: "employeeTemplate",
                hidingPriority: 2,
                allowSorting: !1
            }, {
                dataField: "status",
                caption: l("common_status"),
                cellTemplate: "entityStatusTemplate",
                hidingPriority: 1,
                allowSorting: !1,
                width: 130
            }, {
                dataField: "scheduled_on",
                caption: l("lead_pick_up_time"),
                width: 100,
                cellTemplate: "dueDateTimeTemplate",
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: l("common_created_on"),
                hidingPriority: 0,
                alignment: "center",
                visible: !1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                visible: this.isEmployee,
                alignment: "center",
                width: 50
            }]
        }
        ngOnInit() {
            this.pickupDropContextMenu = [{
                name: k.VIEW_RECEIPT,
                icon: "fa-thin fa-file-pdf",
                visible: !0,
                locale_key: l("view_receipt")
            }, {
                name: k.EDIT,
                icon: "fa-thin fa-pencil",
                visible: this.isEmployee,
                locale_key: l("common_edit")
            }, {
                name: k.DELETE,
                icon: "fa-thin fa-trash",
                visible: this.userPermissionList.includes(D.PICKUP_DROP_DELETE) && this.isEmployee,
                locale_key: l("delete")
            }, {
                name: k.TRACK,
                icon: "fal fa-location",
                visible: this.userPermissionList.includes(D.PICKUP_DROP_LIST) && this.isEmployee && [X.STANDARD, X.ENTERPRISE].includes(this.plan),
                locale_key: this.currentPickupDrop ? .type === "Pickup" ? l("start_pickup") : l("start_delivery"),
                disabled: !this.isMobileDevice,
                hint: this.isMobileDevice ? l("employee_tracking") : l("hint_employee_tracking_only_on_mobile")
            }], this.customerId = +this.activatedRouter.snapshot.parent.paramMap.get("customer_id"), this.employeeId = +this.activatedRouter.snapshot.parent.paramMap.get("employee_id"), this.assignedOnly = this.activatedRouter.snapshot.data.assigned_only ? ? this.assignedOnly, this.jobId || (this.jobId = +this.activatedRouter.snapshot.parent.paramMap.get("job_id"))
        }
        create() {
            this.router.navigate(["/pickupDrops/add"])
        }
        edit(e) {
            this.router.navigate(["/pickupDrops/edit", e.id])
        }
        onSchedulePickUpSave() {
            this.isCreate = !1, this.isVisibleSchedulePickupPopup = !1, this.schedulePickUp = null, this.dataGrid.getData()
        }
        onContextMenuItemClick(e) {
            if (this.currentContextMenuAction = e.action, this.currentPickupDrop = e.entity, this.currentContextMenuAction === k.VIEW_RECEIPT && this.router.navigate(["/pickupDrop/receipt", this.currentPickupDrop.id]), this.currentContextMenuAction === k.EDIT && this.edit(this.currentPickupDrop), this.currentContextMenuAction === k.DELETE && (this.archiveDeleteMode.set(this.currentPickupDrop.deleted_at ? "archived-actions" : "delete"), this.isVisibleArchiveDeletePopup = !0), this.currentContextMenuAction === k.TRACK) {
                if (!this.currentPickupDrop.address) {
                    this.toastNotificationService.error("error_address_not_found");
                    return
                }
                this.geoLocationService.getAddressCoordinates(this.currentPickupDrop.address).then(t => {
                    this.coordinates = {
                        lat: t.lat,
                        lng: t.lng
                    }, this.openMap(this.currentPickupDrop.user_id, this.currentPickupDrop.id, this.currentPickupDrop.mobile_number)
                }).catch(t => {
                    console.error("Error getting address coordinates:", t), t === "ZERO_RESULTS" ? this.toastNotificationService.error("error_address_not_found") : this.toastNotificationService.error("error_address_not_found")
                })
            }
        }
        onCloseContextMenuOption() {
            this.currentContextMenuAction = null, this.currentPickupDrop = null
        }
        handleArchiveDeleteSuccess(e) {
            this.isVisibleArchiveDeletePopup = !1, this.currentContextMenuAction = null, this.currentPickupDrop = null, this.dataGrid.getData()
        }
        openMap(e, t, o) {
            this.router.navigate(["pickupDrop/map"], {
                queryParams: {
                    lat: this.coordinates.lat,
                    lng: this.coordinates.lng,
                    customerId: e,
                    pickupDropId: t,
                    customerPhoneNumber: o
                }
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || i)(y(H), y(Ne))
            }
        }
        static {
            this.\u0275cmp = P({
                type: i,
                selectors: [
                    ["app-pickup-and-drop-list"]
                ],
                viewQuery: function(t, o) {
                    if (t & 1 && N(Z, 5), t & 2) {
                        let s;
                        L(s = O()) && (o.dataGrid = s.first)
                    }
                },
                inputs: {
                    assignedOnly: "assignedOnly"
                },
                standalone: !1,
                decls: 3,
                vars: 28,
                consts: [
                    [3, "contextMenuItemCancelClick", "contextMenuItemClick", "dataGridAddNewClick", "additionalParams", "columns", "contextMenuItems", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleReportDropdown", "searchPanelPlaceholderText", "service", "hasTenantData", "emptyStateConfig"],
                    [3, "isCreate", "isVisiblePopup", "pickupDrop"],
                    [3, "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"],
                    [3, "pickupDropCancelClick", "pickupDropSaveClick", "isCreate", "isVisiblePopup", "pickupDrop"],
                    [3, "isVisibleChange", "onSuccess", "onCancel", "isVisible", "service", "entity", "entityName", "entityDisplayName", "mode"]
                ],
                template: function(t, o) {
                    t & 1 && (c(0, "app-data-grid", 0), g("contextMenuItemCancelClick", function() {
                        return o.onCloseContextMenuOption()
                    })("contextMenuItemClick", function(b) {
                        return o.onContextMenuItemClick(b)
                    })("dataGridAddNewClick", function() {
                        return o.create()
                    }), p(), u(1, Ci, 1, 3, "app-pickup-drop-popup", 1), u(2, gi, 1, 6, "app-archive-delete-popup", 2)), t & 2 && (n("additionalParams", z(14, _i, o.customerId, o.jobId, o.assignedOnly, o.employeeId))("columns", o.columns)("contextMenuItems", o.pickupDropContextMenu)("entity", o.entity)("isVisibleAddAction", !(o.customerId || o.jobId))("isVisibleDeleteAction", !1)("isVisibleEditAction", !1)("isVisibleReportDropdown", !0)("searchPanelPlaceholderText", "search_panel_pickup-drop_placeholder")("service", o.service)("hasTenantData", o.hasTenantPickupDrops)("emptyStateConfig", z(23, fi, o.formatMessage("empty_state_pickupdrop_title"), o.formatMessage("empty_state_pickupdrop_description"), o.customerId || o.jobId ? "" : "empty_state_pickup_drop_primary_button", ae(19, hi, o.formatMessage("empty_state_pickup_drop_tip_1"), o.formatMessage("empty_state_pickup_drop_tip_2"), o.formatMessage("empty_state_pickup_drop_tip_3")))), r(), _(o.isVisibleSchedulePickupPopup ? 1 : -1), r(), _(o.isVisibleArchiveDeletePopup ? 2 : -1))
                },
                dependencies: [Ge, Z, Qe],
                encapsulation: 2
            })
        }
    }
    return i
})();
var vi = [{
        path: "",
        component: Ye,
        children: [{
            path: "list",
            component: $,
            canActivate: [I, x, T, A],
            data: {
                entity: v.PICKUP_DROP,
                permissions: {
                    only: [D.PICKUP_DROP_LIST]
                }
            },
            title: "BytePhase Manage Pickup Drops"
        }, {
            path: "assigned",
            component: $,
            canActivate: [I, ye, x, T, A, ze],
            data: {
                entity: v.PICKUP_DROP,
                permissions: {
                    only: [D.PICKUP_DROP_LIST]
                },
                assigned_only: !0
            },
            title: "BytePhase Assigned Pickup Drops"
        }, {
            path: "add",
            component: J,
            canActivate: [I, x, T, A],
            data: {
                entity: v.PICKUP_DROP,
                permissions: {
                    only: [D.PICKUP_DROP_WRITE]
                }
            },
            title: "BytePhase Pickup/Drops | Add"
        }, {
            path: "edit/:id",
            component: J,
            canActivate: [I, x, T, A],
            data: {
                entity: v.PICKUP_DROP,
                permissions: {
                    only: [D.PICKUP_DROP_WRITE]
                }
            },
            title: "BytePhase Pickup/Drops | Edit"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }, {
            path: "**",
            redirectTo: "/errors/404"
        }]
    }],
    Xe = (() => {
        class i {
            static {
                this.\u0275fac = function(t) {
                    return new(t || i)
                }
            }
            static {
                this.\u0275mod = R({
                    type: i
                })
            }
            static {
                this.\u0275inj = w({
                    imports: [Y.forChild(vi), Y]
                })
            }
        }
        return i
    })();
var Wt = (() => {
    class i {
        static {
            this.\u0275fac = function(t) {
                return new(t || i)
            }
        }
        static {
            this.\u0275mod = R({
                type: i
            })
        }
        static {
            this.\u0275inj = w({
                imports: [pe, Xe, We]
            })
        }
    }
    return i
})();
export {
    Wt as PickupAndDropModule
};