import {
    a as bt
} from "./chunk-2B6TWJ62.js";
import {
    a as pa
} from "./chunk-ZE4JIEWS.js";
import {
    a as la
} from "./chunk-PZDHMQ7I.js";
import {
    a as ca
} from "./chunk-XHP3KBJE.js";
import {
    a as da,
    b as ua,
    d as _a,
    f as fa
} from "./chunk-J36DGFIN.js";
import {
    a as ma
} from "./chunk-PGAHHPJ5.js";
import {
    a as Ji
} from "./chunk-MBAKXBI4.js";
import {
    $ as go,
    $b as Ce,
    $f as Zi,
    A as qt,
    Aa as bo,
    Ac as xt,
    Ae as pe,
    Bc as No,
    Bd as Oo,
    C as ft,
    Cb as ht,
    Cd as Fo,
    D as Ht,
    Db as To,
    Dd as ji,
    De as Ho,
    Ec as oi,
    Fe as jo,
    Ga as Fi,
    He as Cn,
    Ja as Ct,
    Kb as Eo,
    Kc as Be,
    Ke as Qi,
    Kg as oa,
    L as ne,
    Le as qe,
    M as J,
    Ma as Bi,
    N as jt,
    O as zt,
    Pc as St,
    Pe as zo,
    Q as Qt,
    T as se,
    Ta as le,
    Va as ae,
    X as _o,
    Xa as ei,
    Xg as Xi,
    Y as Xt,
    Yb as qi,
    Yf as Qo,
    Z as fo,
    Zb as wo,
    Zd as F,
    Zf as Ki,
    _ as be,
    _d as Re,
    _f as Ve,
    ab as re,
    ad as Po,
    ag as Yo,
    ba as tt,
    bd as ai,
    be as Bo,
    bg as Ko,
    bh as aa,
    c as On,
    ca as N,
    cb as O,
    cd as it,
    db as Ye,
    dg as Zo,
    e as k,
    eb as vt,
    eg as $o,
    fg as Xo,
    g as L,
    gg as Jo,
    h as P,
    ha as G,
    hb as ti,
    hg as ea,
    hh as ra,
    i as Wt,
    ia as _e,
    ib as Ri,
    ig as ta,
    ih as sa,
    j as ut,
    ja as Jt,
    k as _t,
    ka as we,
    l as Se,
    la as Co,
    lb as ie,
    ma as vo,
    n as V,
    na as ho,
    nc as Io,
    o as Fn,
    oc as ko,
    oe as zi,
    p as Pi,
    pb as B,
    pg as ia,
    ph as nt,
    q as Bn,
    qb as Gi,
    qc as ni,
    r as Vi,
    rb as ii,
    rd as ee,
    re as gn,
    rf as Yi,
    rg as $i,
    s as Rn,
    sa as Oi,
    sb as j,
    t as D,
    tb as Ui,
    te as Ro,
    u as A,
    uc as Mo,
    ue as Go,
    va as xo,
    ve as Uo,
    vg as na,
    wa as So,
    wd as Vo,
    we as Wo,
    xb as yo,
    xc as Hi,
    xd as Ao,
    y as z,
    yb as Wi,
    yd as Lo,
    zd as Do,
    ze as qo
} from "./chunk-DCKGQUHB.js";
import {
    $a as u,
    $b as $e,
    Ab as Pe,
    Ad as qn,
    Ai as uo,
    Ak as Qe,
    Bd as Hn,
    Ca as je,
    Cd as Ai,
    Ch as fn,
    Ci as $t,
    Db as pt,
    Dd as jn,
    Di as R,
    Eb as cn,
    Ec as Gt,
    Ed as zn,
    Ee as no,
    Eg as lo,
    F as kn,
    Fa as r,
    Fb as Ae,
    Fc as Ut,
    Fd as Qn,
    Fh as b,
    Gd as Yn,
    Gg as bi,
    Hb as Ze,
    Hd as Kn,
    Ib as s,
    Id as Zn,
    Ig as Kt,
    Jb as x,
    Jd as $n,
    Ka as I,
    Kb as E,
    Kc as Ni,
    Kd as Xn,
    Kg as co,
    Lb as dt,
    Lc as Vn,
    Ld as Jn,
    Mb as et,
    Md as eo,
    Na as y,
    Nc as An,
    Nd as to,
    Oa as hi,
    Ob as Nn,
    Od as Li,
    Pb as Z,
    Pg as H,
    Qb as $,
    Rb as X,
    Rc as Ln,
    Re as Yt,
    Rf as ro,
    Sa as T,
    Sg as mo,
    Tc as Dn,
    Ue as oo,
    Wb as ki,
    Xa as Ft,
    Xb as mn,
    _a as d,
    _b as Le,
    aa as ve,
    ac as Mi,
    ba as vi,
    bb as Ee,
    cb as U,
    da as Te,
    db as W,
    dg as dn,
    di as po,
    ea as v,
    eb as l,
    eg as un,
    fb as n,
    gb as i,
    gc as q,
    ha as g,
    hb as p,
    hc as Y,
    hi as Q,
    ia as C,
    ic as xi,
    if as ao,
    ii as gt,
    ji as It,
    kc as Bt,
    ld as Gn,
    lh as oe,
    ma as Mn,
    mc as Rt,
    mh as K,
    na as Ii,
    nb as mt,
    nh as ze,
    oa as ue,
    oc as Xe,
    pd as De,
    qa as ce,
    qb as S,
    qd as Oe,
    sb as _,
    sc as Pn,
    sd as ge,
    se as io,
    sg as _n,
    t as Ot,
    td as Un,
    th as Zt,
    ti as Fe,
    ub as m,
    ui as he,
    vd as pn,
    xk as f,
    yb as Me,
    yd as Si,
    yg as so,
    z as wi,
    zb as Ne,
    zd as Wn,
    zi as Di
} from "./chunk-GOPIAW4V.js";
import {
    a as lt,
    b as ct
} from "./chunk-FBFWB55K.js";

function Nr(t, c) {
    if (t & 1 && (n(0, "span", 12), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.formatMessage("upgrade"))
    }
}

function Pr(t, c) {
    if (t & 1 && (n(0, "div")(1, "div", 9), p(2, "i", 10), n(3, "span", 11), s(4), i(), d(5, Nr, 2, 1, "span", 12), i()()), t & 2) {
        let e = c.$implicit;
        r(), Ae("opacity-50", e.upgradeHint), r(), l("ngClass", e.icon), r(2), x(e.text), r(), u(e.disabled ? 5 : -1)
    }
}

function Vr(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-list", 7), _("onItemClick", function(a) {
            g(e);
            let h = m();
            return C(h.onItemClick(a.event, a.itemData))
        }), T(1, Pr, 6, 5, "div", 8), i()
    }
    if (t & 2) {
        let e = m();
        l("dataSource", e.searchResults())("hoverStateEnabled", !0), r(), l("dxTemplateOf", "item")
    }
}

function Ar(t, c) {
    if (t & 1 && (n(0, "div")(1, "div", 14), p(2, "i", 10), n(3, "span", 15), s(4), i(), n(5, "span", 16), s(6), i()()()), t & 2) {
        let e = c.$implicit;
        r(2), l("ngClass", e.icon), r(2), x(e.category), r(2), x(e.items.length)
    }
}

function Lr(t, c) {
    if (t & 1 && (n(0, "span", 12), s(1), i()), t & 2) {
        let e = m(5);
        r(), x(e.formatMessage("upgrade"))
    }
}

function Dr(t, c) {
    if (t & 1 && (n(0, "div", 9), p(1, "i", 10), n(2, "span", 11), s(3), i(), d(4, Lr, 2, 1, "span", 12), i()), t & 2) {
        let e = m().$implicit;
        Ae("opacity-50", e.upgradeHint), r(), l("ngClass", e.icon), r(2), x(e.text), r(), u(e.disabled ? 4 : -1)
    }
}

function Or(t, c) {
    if (t & 1 && (n(0, "div"), d(1, Dr, 5, 5, "div", 17), i()), t & 2) {
        let e = c.$implicit;
        r(), u(e.visible ? 1 : -1)
    }
}

function Fr(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "dx-list", 7), _("onItemClick", function(a) {
            g(e);
            let h = m(2);
            return C(h.onItemClick(a.event, a.itemData))
        }), T(2, Or, 2, 1, "div", 8), i()()
    }
    if (t & 2) {
        let e = c.$implicit;
        r(), l("dataSource", e.items)("hoverStateEnabled", !0), r(), l("dxTemplateOf", "item")
    }
}

function Br(t, c) {
    if (t & 1 && (n(0, "dx-accordion", 13), T(1, Ar, 7, 3, "div", 8)(2, Fr, 3, 3, "div", 8), i()), t & 2) {
        let e = m();
        l("dataSource", e.filteredCategories())("collapsible", !0)("multiple", !1)("animationDuration", 200)("selectedItems", e.defaultExpandedItems), r(), l("dxTemplateOf", "categoryTitle"), r(), l("dxTemplateOf", "categoryItems")
    }
}

function Rr(t, c) {
    if (t & 1 && (n(0, "div", 18), p(1, "i", 19), n(2, "p", 20), s(3), i()()), t & 2) {
        let e = m();
        r(3), x(e.formatMessage("common_no_results_found"))
    }
}

function Gr(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-text-box", 21), _("onValueChanged", function(a) {
            g(e);
            let h = m();
            return C(h.onSearchChange(a.value))
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("placeholder", e.formatMessage("common_search"))("value", e.searchQuery())("showClearButton", !0)
    }
}

function Ur(t, c) {
    t & 1 && mt(0)
}

function Wr(t, c) {
    if (t & 1 && (n(0, "div", 22), T(1, Ur, 1, 0, "ng-container", 23), i()), t & 2) {
        m(2);
        let e = pt(1);
        r(), l("ngTemplateOutlet", e)
    }
}

function qr(t, c) {
    t & 1 && mt(0)
}

function Hr(t, c) {
    if (t & 1 && T(0, qr, 1, 0, "ng-container", 23), t & 2) {
        m(2);
        let e = pt(3);
        l("ngTemplateOutlet", e)
    }
}

function jr(t, c) {
    t & 1 && mt(0)
}

function zr(t, c) {
    if (t & 1 && T(0, jr, 1, 0, "ng-container", 23), t & 2) {
        m(2);
        let e = pt(5);
        l("ngTemplateOutlet", e)
    }
}

function Qr(t, c) {
    if (t & 1 && (d(0, Wr, 2, 1, "div", 22), d(1, Hr, 1, 1, "ng-container"), d(2, zr, 1, 1, "ng-container")), t & 2) {
        let e = m();
        u(e.isSearching() && e.searchResults().length > 0 ? 0 : -1), r(), u(!e.isSearching() || e.filteredCategories().length > 0 ? 1 : -1), r(), u(e.isSearching() && e.searchResults().length === 0 && e.filteredCategories().length === 0 ? 2 : -1)
    }
}

function Yr(t, c) {
    t & 1 && mt(0)
}

function Kr(t, c) {
    t & 1 && mt(0)
}

function Zr(t, c) {
    if (t & 1 && (n(0, "div", 5)(1, "div", 24)(2, "div", 25)(3, "div", 26), T(4, Yr, 1, 0, "ng-container", 23), i(), T(5, Kr, 1, 0, "ng-container", 23), i(), n(6, "div", 27), p(7, "router-outlet"), i()()()), t & 2) {
        m();
        let e = pt(7),
            o = pt(9);
        r(4), l("ngTemplateOutlet", e), r(), l("ngTemplateOutlet", o)
    }
}

function $r(t, c) {
    t & 1 && mt(0)
}

function Xr(t, c) {
    t & 1 && mt(0)
}

function Jr(t, c) {
    if (t & 1 && (n(0, "div", 28)(1, "div", 29), s(2), i(), T(3, $r, 1, 0, "ng-container", 23), i(), n(4, "div", 30), T(5, Xr, 1, 0, "ng-container", 23), i()), t & 2) {
        let e = m(2),
            o = pt(7),
            a = pt(9);
        r(2), x(e.formatMessage("business_settings_group_name")), r(), l("ngTemplateOutlet", o), r(2), l("ngTemplateOutlet", a)
    }
}

function es(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 31)(1, "button", 32), _("click", function() {
            g(e);
            let a = m(2);
            return C(a.showSettingsMenu())
        }), p(2, "i", 33), i(), n(3, "span", 34), s(4), i()(), n(5, "div", 35), p(6, "router-outlet"), i()
    }
    if (t & 2) {
        let e = m(2);
        r(4), x(e.formatMessage("business_settings_group_name"))
    }
}

function ts(t, c) {
    if (t & 1 && (n(0, "div", 6), d(1, Jr, 6, 3)(2, es, 7, 1), i()), t & 2) {
        let e = m();
        r(), u(e.showMobileMenu() ? 1 : 2)
    }
}
var Ca = (() => {
    class t {
        constructor() {
            this.authorizationService = v(ht), this.router = v(ge), this.userDeviceService = v(se), this.tenantService = v(ie), this.destroyRef = v(Ii), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.plan = this.tenantService.plan(), this.searchQuery = ce(""), this.showMobileMenu = ce(!0), this.defaultExpandedItems = [], this.formatMessage = f, this.isSearching = Rt(() => this.searchQuery().length > 0), this.searchResults = Rt(() => {
                let e = this.searchQuery();
                return e ? this.settingsCategories.flatMap(o => o.items).filter(o => o.visible && o.text.toLowerCase().includes(e)) : []
            }), this.filteredCategories = Rt(() => {
                let e = this.searchQuery();
                return e ? this.settingsCategories.map(o => ct(lt({}, o), {
                    items: o.items.filter(a => a.visible && (a.text.toLowerCase().includes(e) || o.category.toLowerCase().includes(e)))
                })).filter(o => o.items.length > 0) : this.settingsCategories
            }), this.settingsCategories = [{
                category: f("business_information"),
                icon: R.BUSINESS_INFO.light,
                items: [{
                    id: 0,
                    text: f("business"),
                    path: "/settings/business",
                    icon: R.BUSINESS_INFO.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("common_bank"),
                    path: "/settings/businessBank",
                    icon: R.BANK.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 2,
                    text: f("logo"),
                    path: "/settings/businessLogo",
                    icon: R.LOGO.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 3,
                    text: f("business_signature"),
                    path: "/settings/businessSignature",
                    icon: R.SIGNATURE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 4,
                    text: f("important_links"),
                    path: "/settings/businessLinks",
                    icon: R.LINKS.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 5,
                    text: f("business_hours"),
                    path: "/settings/businessHours",
                    icon: R.BUSINESS_HOURS.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 6,
                    text: f("BUSINESS_TYPE"),
                    path: "/settings/business-type",
                    icon: R.BUSINESS_TYPE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("communication"),
                icon: R.COMMUNICATION.light,
                items: [{
                    id: 0,
                    text: f("email_settings"),
                    path: "/settings/email",
                    icon: R.EMAIL.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("sms"),
                    path: "/settings/sms-history",
                    icon: R.SMS.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 6,
                    text: f("message_logs"),
                    path: "/settings/message-logs",
                    icon: R.COMMUNICATION.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 2,
                    text: f("reminder_settings"),
                    path: "/settings/reminders",
                    icon: R.REMINDER.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 5,
                    text: f("self_check_in_settings"),
                    path: "/settings/self-checkin",
                    icon: R.REMINDER.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 6,
                    text: f("default_notification_settings_title"),
                    path: "/settings/default-notifications",
                    icon: Di.NOTIFICATION.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 3,
                    text: f("notification_signatures"),
                    path: "/settings/notification-signatures",
                    icon: R.SIGNATURE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 4,
                    text: f("notification_templates"),
                    path: "/templates",
                    icon: Di.TEMPLATE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW) && !this.isMobileDevice()
                }]
            }, {
                category: f("system_configuration"),
                icon: R.SYSTEM_CONFIG.light,
                items: [{
                    id: 0,
                    text: f("add_custom_fields"),
                    path: "/settings/custom-fields",
                    icon: R.CUSTOM_FIELDS.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("general_settings"),
                    path: "/settings/general",
                    icon: R.GENERAL.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 2,
                    text: f("module_settings"),
                    path: "/settings/modules",
                    icon: R.MODULES.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 3,
                    text: f("tax_settings"),
                    path: "/settings/taxes",
                    icon: R.TAX.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 4,
                    text: f("common_terms_and_conditions"),
                    path: "/settings/terms",
                    icon: R.TERMS.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 5,
                    text: f("sequence_settings"),
                    path: "/settings/sequences",
                    icon: R.SEQUENCE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("workflow_settings"),
                icon: R.WORKFLOW.light,
                items: [{
                    id: 0,
                    text: f("job_quotation_payment_workflow_settings"),
                    path: "/settings/workflow",
                    icon: $t.ADDRESS_BOOK.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("customer_address_settings"),
                    path: "/settings/workflowAddress",
                    icon: R.ADDRESS.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 2,
                    text: f("due_date_settings"),
                    path: "/settings/workflowDueDates",
                    icon: R.DUE_DATE.light,
                    disabled: [H.LITE].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("print_settings"),
                icon: R.PRINT.light,
                items: [{
                    id: 0,
                    text: f("printer_paper_size"),
                    path: "/settings/print",
                    icon: R.PRINT_SLASH.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("technician_print"),
                    path: "/settings/printTechnician",
                    icon: R.WORKFLOW.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 2,
                    text: f("print_options"),
                    path: "/settings/printOptions",
                    icon: R.PRINT.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 3,
                    text: f("amc_contract_print_options"),
                    path: "/settings/printAmc",
                    icon: R.PRINT_MAGNIFYING_GLASS.light,
                    disabled: [H.LITE, H.BASIC].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("theme_layout_settings"),
                icon: R.THEME.light,
                items: [{
                    id: 0,
                    text: f("table_settings"),
                    path: "/settings/themes",
                    icon: $t.TABLE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("scrolling_options"),
                    path: "/settings/themesScroll",
                    icon: R.MOUSE_ALT.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("operations"),
                icon: R.EXPENSE_CATEGORY.light,
                items: [{
                    id: 0,
                    text: f("expense_category"),
                    path: "/settings/expense-categories",
                    icon: R.EXPENSE_CATEGORY.light,
                    disabled: [H.LITE, H.BASIC].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("payment_types"),
                    path: "/settings/payment-types",
                    icon: R.PAYMENT_TYPE.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 2,
                    text: f("part_categories"),
                    path: "/settings/part-categories",
                    icon: Di.INVENTORY.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: "Security",
                icon: $t.SHIELD_CHECK.light,
                items: [{
                    id: 0,
                    text: "Two-Factor Authentication",
                    path: "/settings/security",
                    icon: $t.SHIELD_CHECK.light,
                    disabled: [H.LITE, H.BASIC].includes(this.plan),
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }, {
                    id: 1,
                    text: f("permissions"),
                    path: "/permissions",
                    queryParams: {
                        reason: "manual-from-settings"
                    },
                    icon: $t.SHIELD_CHECK.light,
                    visible: !0
                }]
            }, {
                category: f("subscription"),
                icon: R.SUBSCRIPTION.light,
                items: [{
                    id: 0,
                    text: f("subscription"),
                    path: "/settings/subscription",
                    icon: R.SUBSCRIPTION.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("integrations"),
                icon: R.INTEGRATIONS.light,
                items: [{
                    id: 0,
                    text: f("integrations"),
                    path: "/settings/integrations",
                    icon: R.INTEGRATIONS.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW)
                }]
            }, {
                category: f("white_label"),
                icon: R.WHITE_LABEL.light,
                items: [{
                    id: 0,
                    text: f("white_label_settings"),
                    path: "/settings/white-label",
                    icon: R.WHITE_LABEL.light,
                    visible: this.authorizationService.userPermissionList().includes(b.BUSINESS_SETTING_VIEW),
                    upgradeHint: !this.tenantService.config() ? .is_white_label
                }]
            }]
        }
        ngOnInit() {
            this.settingsCategories.length > 0 && (this.defaultExpandedItems = [this.settingsCategories[0]]), this.router.events.pipe(kn(e => e instanceof Gn), Qt(this.destroyRef)).subscribe(() => {
                this.isMobileDevice() && this.showMobileMenu.set(!1)
            })
        }
        onSearchChange(e) {
            this.searchQuery.set(e ? .toLowerCase() || "")
        }
        showSettingsMenu() {
            this.showMobileMenu.set(!0)
        }
        onItemClick(e, o) {
            e.stopPropagation(), e.preventDefault(), o.disabled || (this.isMobileDevice() && this.showMobileMenu.set(!1), this.router.navigate([o.path], o.queryParams ? {
                queryParams: o.queryParams
            } : {}))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-setting"]
                ],
                standalone: !1,
                decls: 12,
                vars: 2,
                consts: [
                    ["searchResultsList", ""],
                    ["settingsAccordion", ""],
                    ["noResults", ""],
                    ["searchBox", ""],
                    ["settingsContent", ""],
                    [1, "container-fluid", "pt-3"],
                    [1, "mobile-settings-wrapper", "d-flex", "flex-column", "min-vh-100"],
                    [3, "onItemClick", "dataSource", "hoverStateEnabled"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "align-items-center", "gap-2", "py-1"],
                    [1, "text-muted", 3, "ngClass"],
                    [1, "flex-grow-1"],
                    [1, "badge", "bg-warning", "text-dark"],
                    ["itemTitleTemplate", "categoryTitle", "itemTemplate", "categoryItems", 3, "dataSource", "collapsible", "multiple", "animationDuration", "selectedItems"],
                    [1, "d-flex", "align-items-center", "gap-2", "w-100"],
                    [1, "flex-grow-1", "fw-medium"],
                    [1, "text-muted", "small"],
                    [1, "d-flex", "align-items-center", "gap-2", "py-1", 3, "opacity-50"],
                    [1, "d-flex", "flex-column", "align-items-center", "justify-content-center", "p-5", "rounded-2", "text-center", "border", "text-muted"],
                    [1, "fa-thin", "fa-search", "fs-2", "mb-3"],
                    [1, "m-0", "small"],
                    ["mode", "search", "valueChangeEvent", "input", "stylingMode", "outlined", 3, "onValueChanged", "placeholder", "value", "showClearButton"],
                    [1, "border", "rounded-2", "overflow-hidden", "mb-3"],
                    [4, "ngTemplateOutlet"],
                    [1, "row"],
                    ["id", "settings-sidebar-nav", 1, "col-3", "desktop-settings-sidebar", "px-2"],
                    [1, "mb-3"],
                    ["id", "settings-content-area", 1, "col-9", "ps-4"],
                    [1, "mobile-settings-header", "flex-shrink-0"],
                    [1, "fw-semibold", "fs-6", "mb-3"],
                    [1, "mobile-settings-content", "px-3"],
                    [1, "mobile-content-header", "d-flex", "align-items-center", "gap-3", "border-bottom"],
                    ["type", "button", 1, "mobile-back-button", "btn", "p-0", "border-0", "rounded-2", "d-flex", "align-items-center", "justify-content-center", 3, "click"],
                    [1, "fa-thin", "fa-arrow-left", "fs-5"],
                    [1, "fw-semibold"],
                    [1, "mobile-router-content", "p-3"]
                ],
                template: function(o, a) {
                    o & 1 && (T(0, Vr, 2, 3, "ng-template", null, 0, Bt)(2, Br, 3, 7, "ng-template", null, 1, Bt)(4, Rr, 4, 1, "ng-template", null, 2, Bt)(6, Gr, 1, 3, "ng-template", null, 3, Bt)(8, Qr, 3, 3, "ng-template", null, 4, Bt), d(10, Zr, 8, 2, "div", 5), d(11, ts, 3, 1, "div", 6)), o & 2 && (r(10), u(a.isMobileDevice() ? -1 : 10), r(), u(a.isMobileDevice() ? 11 : -1))
                },
                dependencies: [Gt, Vn, ni, G, ko, ae, Oe],
                styles: [".mobile-settings-wrapper[_ngcontent-%COMP%]{margin:-30px -12px 0;padding-bottom:80px;background-color:var(--primary-bg)}.mobile-settings-header[_ngcontent-%COMP%], .mobile-content-header[_ngcontent-%COMP%]{position:sticky;top:-30px;z-index:100;padding:28px 16px 12px;background-color:var(--primary-bg)}.mobile-settings-content[_ngcontent-%COMP%]{background-color:var(--primary-bg)}.mobile-settings-content[_ngcontent-%COMP%]     .dx-list-item{background-color:transparent!important}.mobile-settings-content[_ngcontent-%COMP%]     .dx-list-item.dx-state-hover, .mobile-settings-content[_ngcontent-%COMP%]     .dx-list-item.dx-state-focused, .mobile-settings-content[_ngcontent-%COMP%]     .dx-list-item.dx-state-active{background-color:var(--theme-hover-color)!important}.mobile-back-button[_ngcontent-%COMP%]{width:36px;height:36px;color:var(--primary-text)}.mobile-back-button[_ngcontent-%COMP%]:hover{background-color:var(--theme-hover-color)}.mobile-router-content[_ngcontent-%COMP%]{background-color:var(--primary-bg)}.mobile-router-content[_ngcontent-%COMP%]   .container-fluid[_ngcontent-%COMP%], .mobile-router-content[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%], .mobile-router-content[_ngcontent-%COMP%]   .col-12[_ngcontent-%COMP%]{padding-left:0;padding-right:0;margin-left:0;margin-right:0}.desktop-settings-sidebar[_ngcontent-%COMP%]{border-right:1px solid var(--border-color);min-height:calc(100vh - 100px)}.desktop-settings-sidebar[_ngcontent-%COMP%]     .dx-list-item{background-color:transparent!important}.desktop-settings-sidebar[_ngcontent-%COMP%]     .dx-list-item.dx-state-hover, .desktop-settings-sidebar[_ngcontent-%COMP%]     .dx-list-item.dx-state-focused, .desktop-settings-sidebar[_ngcontent-%COMP%]     .dx-list-item.dx-state-active{background-color:var(--theme-hover-color)!important}"]
            })
        }
    }
    return t
})();
var Mt = (() => {
    class t {
        constructor(e, o) {
            this.accountService = e, this.loaderService = o, this.formatMessage = f, this.tenantService = v(ie), this.router = v(ge), this.activatedRoute = v(De), this.userDeviceService = v(se), this.plan = this.tenantService.plan(), this.isIndia = this.tenantService.isIndia(), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.selectedTabIndex = null, this.accountDetailSettings = [{
                id: 0,
                text: f("business"),
                path: "/settings/business",
                icon: "fa-thin fa-building",
                visible: !0
            }, {
                id: 1,
                text: f("common_bank"),
                path: "/settings/businessBank",
                icon: "fa-thin fa-money-check-pen",
                visible: !0
            }, {
                id: 2,
                text: f("logo"),
                path: "/settings/businessLogo",
                icon: "fa-thin fa-icons",
                visible: !0
            }, {
                id: 3,
                text: f("business_signature"),
                path: "/settings/businessSignature",
                icon: "fa-thin fa-signature",
                visible: !0
            }, {
                id: 4,
                text: f("important_links"),
                path: "/settings/businessLinks",
                icon: "fa-thin fa-link",
                disabled: [H.LITE].includes(this.plan),
                visible: !0
            }, {
                id: 5,
                text: f("business_hours"),
                path: "/settings/businessHours",
                icon: "fa-thin fa-calendar-clock",
                visible: !0
            }]
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex, this.router.navigate([e.itemData.path])
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0, this.loaderService.show(), this.accountService.getTenant().subscribe({
                next: e => {
                    this.account = e
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => this.loaderService.hide())
        }
        onAccountSave(e) {
            this.account = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(be), I(Qe))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-details"]
                ],
                standalone: !1,
                decls: 4,
                vars: 0,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-12"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "router-outlet"), i()()())
                },
                dependencies: [Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var si = class {
    constructor(c) {
        return this.bank = new bt({}), Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            name: [c.name || null, k.required],
            email: [c.email || null],
            support_number: [c.support_number],
            alternate_number: [c.alternate_number],
            support_email: [c.support_email, [k.email, k.required]],
            whats_app_number: [c.whats_app_number],
            gst_number: [c.gst_number || null],
            timezone: [c.timezone || (Intl.DateTimeFormat().resolvedOptions().timeZone ? ? null), k.required],
            locale: [c.locale || "en"],
            date_time_format: [c.date_time_format || null],
            currency_code: [c.currency_code || null, k.required],
            country_id: [c.country_id || null, k.required],
            msme_number: [c.msme_number || null],
            website: [c.website || null, Ui.isValidURL],
            address: gn.getForm(new gn(c.address)),
            employee_tracking_distance_unit: [c.employee_tracking_distance_unit || "km"]
        })
    }
};
var va = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, ro), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var os = () => ({
        autocomplete: "new-country"
    }),
    as = () => ({
        autocomplete: "new-currency"
    });

function rs(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 0)(1, "div", 4)(2, "app-business-readiness-widget", 5), _("openChecklist", function() {
            g(e);
            let a = m();
            return C(a.openBusinessReadinessChecklist())
        }), i()()()
    }
    t & 2 && (r(2), l("displayMode", "settings"))
}

function ss(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-checklist-modal", 6), _("closeModal", function() {
            g(e);
            let a = m();
            return C(a.closeBusinessReadinessChecklist())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("visible", e.isChecklistModalVisible())
    }
}

function ls(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 2), t & 2 && l("rows", 8)("columns", 3)
}

function cs(t, c) {
    if (t & 1 && p(0, "app-server-error", 8), t & 2) {
        let e = m(2);
        l("errorResponse", e.errorResponse)
    }
}

function ms(t, c) {}

function ps(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 50), _("cancelClick", function() {
            g(e);
            let a = m(4);
            return C(a.cancel())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function ds(t, c) {
    if (t & 1 && T(0, ps, 1, 1, "app-save-cancel-footer", 49), t & 2) {
        let e = m(3);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function us(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-edit-back-btn", 52), _("editClick", function() {
            g(e);
            let a = m(4);
            return C(a.setEditMode())
        }), i()
    }
}

function _s(t, c) {
    if (t & 1 && T(0, us, 1, 0, "app-edit-back-btn", 51), t & 2) {
        let e = m(3);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function fs(t, c) {
    if (t & 1 && d(0, ds, 1, 1, "app-save-cancel-footer", 47)(1, _s, 1, 1, "app-edit-back-btn", 48), t & 2) {
        let e = m(2);
        u(e.isEditMode ? 0 : 1)
    }
}

function gs(t, c) {
    if (t & 1 && (n(0, "div", 53)(1, "div", 54)(2, "div"), s(3), i(), n(4, "div"), s(5), i()(), n(6, "div", 55)(7, "div"), s(8), i(), n(9, "div"), s(10), i()()()), t & 2) {
        let e = c.$implicit;
        r(3), E(" Code: ", e.id, " "), r(2), E(" Country: ", e.countryName, " "), r(3), E(" Format : ", e.format, " "), r(2), E(" Example: ", e.example, " ")
    }
}

function Cs(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 7), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), d(1, cs, 1, 1, "app-server-error", 8), n(2, "app-actionable-page-subtitle", 9), d(3, ms, 0, 0)(4, fs, 2, 1), i(), p(5, "app-alert-panel", 10), n(6, "div", 11)(7, "app-control-container", 12), p(8, "dx-text-box", 13), i(), n(9, "app-control-container", 14), p(10, "app-email", 15), i(), n(11, "app-control-container", 16), p(12, "app-email", 17), i(), n(13, "app-control-container", 18), p(14, "app-phone-number", 19), i(), n(15, "app-control-container", 20), p(16, "app-phone-number", 21), i(), n(17, "app-control-container", 22), p(18, "app-mobile-number", 23), i(), n(19, "app-control-container", 24), p(20, "dx-text-box", 25)(21, "app-error", 26), i(), n(22, "app-control-container", 27), p(23, "dx-text-box", 28), i(), n(24, "app-control-container", 29), p(25, "dx-text-box", 30), i(), p(26, "app-section-title", 31)(27, "app-alert-panel", 10), n(28, "app-control-container", 32)(29, "dx-select-box", 33), _("onSelectionChanged", function(a) {
            g(e);
            let h = m();
            return C(h.getStateListFromCountryList(a))
        }), i()(), n(30, "app-control-container", 34), p(31, "dx-select-box", 35), i(), n(32, "app-control-container", 36)(33, "dx-select-box", 37), T(34, gs, 11, 4, "div", 38), i()(), n(35, "app-control-container", 39), p(36, "dx-select-box", 40), i(), n(37, "app-control-container", 41)(38, "dx-select-box", 42), _("onValueChanged", function(a) {
            g(e);
            let h = m();
            return C(h.changeLocale(a))
        }), i()(), n(39, "app-control-container", 43)(40, "dx-select-box", 44), _("onValueChanged", function(a) {
            g(e);
            let h = m();
            return C(h.changeDistanceUnit(a))
        }), i()()(), n(41, "div", 45), p(42, "app-address", 46), i()()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(), u(e.errorResponse ? 1 : -1), r(), l("title", "business_details_sub_title"), r(), u(e.isSetupMode ? 3 : 4), r(2), l("message", e.formatMessage("business_details_note")), r(2), l("errorMsg", e.formatMessage("register_business_name_required"))("label", e.formatMessage("register_business_name")), r(), l("placeholder", e.formatMessage("register_business_name")), r(), l("errorMsg", e.formatMessage("account_email_required"))("label", e.formatMessage("account_email_label"))("tooltipText", "account_email"), r(), l("formControl", e.form.controls.email)("isEditMode", !1), r(), l("errorMsg", e.formatMessage("account_support_email_required"))("label", e.formatMessage("accounts_support_email"))("tooltipText", "account_support_email"), r(), l("formControl", e.form.controls.support_email)("isEditMode", e.isEditMode), r(), l("errorMsg", e.formatMessage("accounts_support_number_required"))("label", e.formatMessage("accounts_support_number"))("tooltipText", "account_support_number"), r(), l("formControl", e.form.controls.support_number)("isEditMode", e.isEditMode), r(), l("errorMsg", e.formatMessage("accounts_alternate_number_required"))("label", e.formatMessage("accounts_alternate_number"))("tooltipText", "account_alternate_number"), r(), l("formControl", e.form.controls.alternate_number)("isEditMode", e.isEditMode), r(), l("errorMsg", e.formatMessage("accounts_whats_app_number_required"))("label", e.formatMessage("accounts_whats_app_number"))("tooltipText", "account_whats_app_number"), r(), l("formControl", e.form.controls.whats_app_number)("isEditMode", e.isEditMode)("countryId", e.selectedCountryId), r(), l("errorMsg", e.formatMessage("accounts_website_required"))("label", e.formatMessage("accounts_website"))("tooltipText", "account_website"), r(2), l("displayError", e.form.get("website").invalid && e.form.get("website").touched && e.form.get("website").errors.invalidUrl)("errorMsg", e.formatMessage("accounts_invalid_website")), r(), l("errorMsg", e.formatMessage("accounts_gst_number_required"))("label", e.formatMessage("common_tax_number")), r(), l("placeholder", e.formatMessage("common_tax_number")), r(), l("errorMsg", e.formatMessage("accounts_msme_number_required"))("label", e.formatMessage("common_msme_number")), r(), l("placeholder", e.formatMessage("account_msm_number_label")), r(), l("title", "account_region_currency"), r(), l("message", e.formatMessage("region_and_currency_details_note")), r(), l("errorMsg", e.formatMessage("register_country_required"))("label", e.formatMessage("register_country"))("tooltipText", "account_country_id"), r(), l("inputAttr", Le(89, os))("items", e.countryList)("placeholder", e.formatMessage("register_select_country"))("readOnly", !0)("searchEnabled", !0)("showClearButton", e.isEditMode), r(), l("errorMsg", e.formatMessage("currency_required"))("label", e.formatMessage("accounts_currency_code")), r(), l("inputAttr", Le(90, as))("items", e.countryList)("placeholder", e.formatMessage("select_currency"))("searchEnabled", !0)("showClearButton", e.isEditMode), r(), l("errorMsg", e.formatMessage("accounts_date_time_format_required"))("label", e.formatMessage("accounts_date_time_format")), r(), l("items", e.dateTimeFormatList)("placeholder", e.formatMessage("select_date_time_format"))("searchEnabled", !0)("showClearButton", e.isEditMode), r(), l("dxTemplateOf", "item"), r(), l("errorMsg", e.formatMessage("accounts_timezone_required"))("label", e.formatMessage("accounts_timezone")), r(), l("items", e.timezoneList)("placeholder", e.formatMessage("select_timezone"))("searchEnabled", !0)("showClearButton", e.isEditMode), r(), l("errorMsg", e.formatMessage("accounts_locale_required"))("label", e.formatMessage("accounts_locale")), r(), l("items", e.locales)("searchEnabled", !0)("showClearButton", e.isEditMode)("placeholder", e.formatMessage("select_language")), r(), l("errorMsg", e.formatMessage("error_distance_unit_required"))("label", e.formatMessage("account_distance_unit")), r(), l("items", e.distanceUnits)("searchEnabled", !0)("showClearButton", e.isEditMode)("placeholder", e.formatMessage("select_distance_unit")), r(2), l("parentForm", e.form)
    }
}
var ha = (() => {
    class t {
        constructor(e, o, a, h, w) {
            this.service = e, this.cityService = o, this.stateService = a, this.countryService = h, this.timezoneService = w, this.formatMessage = f, this.accountSave = new ue, this.formService = v(B), this.localizationService = v(_o), this.tenantService = v(ie), this.toastNotificationService = v(N), this.geoLocationService = v(Io), this.businessReadinessService = v(da), this.hasEarlyAccess = this.tenantService.hasEarlyAccess(), this.isChecklistModalVisible = ce(!1), this.errorResponse = null, this.countryList = [], this.stateList = [], this.cityList = [], this.timezoneList = [], this.locales = [], this.distanceUnits = [], this.isEditMode = !1, this.isSetupMode = !1, this.selectedCountryId = null, this.PERMISSION_LIST = b, this.dateTimeFormatList = co, this.event = event
        }
        ngOnInit() {
            this.locales = this.localizationService.locales, this.distanceUnits = this.geoLocationService.distanceUnits, this.getTimezones(), this.getCountries(), this.service.getTenant().subscribe({
                next: e => {
                    this.account = e, this.form = si.getForm(new si(this.account)), this.selectedCountryId = this.account.country_id, this.form.disable()
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        save() {
            if (this.errorResponse = "", this.form.valid) {
                let e = this.form.value;
                e.id = this.account.id, this.service.update(e).subscribe({
                    next: o => {
                        this.toastNotificationService.success("notification_account_info_update_success"), this.account = o, this.accountSave.emit(o), this.isEditMode = !1, this.form.patchValue(this.account), this.form.disable(), window.location.reload()
                    },
                    error: o => {
                        this.errorResponse = o
                    }
                })
            } else this.formService.validateFormFields(this.form)
        }
        getStateListFromCountryList(e) {
            this.stateList = [], e.selectedItem ? .id && (this.selectedCountryId = e.selectedItem.id, this.form.patchValue({
                currency_code: e.selectedItem ? .currency_code
            }), this.stateService.getListByQuery({
                country_id: (e.selectedItem ? .id ? ? this.tenantService ? .config() ? .country_id) || so
            }).subscribe({
                next: o => {
                    this.stateList = o
                },
                error: o => {
                    console.error(o)
                }
            }))
        }
        getCityListFromStateList(e) {
            this.cityList = [], e.selectedItem && this.cityService.getListByQuery({
                state_id: e.selectedItem.id
            }).subscribe({
                next: o => {
                    this.cityList = o
                },
                error: o => {
                    console.error(o)
                }
            })
        }
        cancel() {
            this.form.reset(new si(this.account)), this.form.disable(), this.isEditMode = !1
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        changeLocale(e) {
            this.localizationService.switchLanguage(e ? .value)
        }
        changeDistanceUnit(e) {
            this.geoLocationService.switchDistanceUnit(e ? .value)
        }
        getTimezones() {
            this.timezoneService.getListByQuery().subscribe({
                next: e => {
                    this.timezoneList = e
                },
                error: e => {
                    this.toastNotificationService.error("notification_timezone_fetch_error")
                }
            })
        }
        getCountries() {
            this.countryService.loadCountries().subscribe({
                next: e => {
                    this.countryList = e
                },
                error: e => {
                    this.toastNotificationService.error("notification_country_fetch_error")
                }
            })
        }
        openBusinessReadinessChecklist() {
            this.isChecklistModalVisible.set(!0)
        }
        closeBusinessReadinessChecklist() {
            this.isChecklistModalVisible.set(!1)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(be), I(Ao), I(Lo), I(Uo), I(va))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-basic-information"]
                ],
                inputs: {
                    account: "account"
                },
                outputs: {
                    accountSave: "accountSave"
                },
                standalone: !1,
                decls: 4,
                vars: 4,
                consts: [
                    [1, "row", "mb-4"],
                    [3, "visible"],
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    [1, "col-12"],
                    [3, "openChecklist", "displayMode"],
                    [3, "closeModal", "visible"],
                    ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                    [1, "mt-2", 3, "errorResponse"],
                    [3, "title"],
                    [3, "message"],
                    [1, "row"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", "id", "account-basic-info-business-name", 3, "placeholder"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["id", "account-basic-info-email", 3, "formControl", "isEditMode"],
                    ["name", "support_email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["id", "account-basic-info-support-email", 3, "formControl", "isEditMode"],
                    ["name", "support_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["id", "account-basic-info-support-number", 3, "formControl", "isEditMode"],
                    ["name", "alternate_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["id", "account-basic-info-alternate_number", 3, "formControl", "isEditMode"],
                    ["name", "whats_app_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["id", "account-basic-info-whatsapp-number", 3, "formControl", "isEditMode", "countryId"],
                    ["name", "website", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label", "tooltipText"],
                    ["formControlName", "website", "id", "account-basic-info-website", "placeholder", "Eg: https://www.bytephase.com"],
                    [3, "displayError", "errorMsg"],
                    ["name", "gst_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "gst_number", "id", "account-basic-info-gst-number", 3, "placeholder"],
                    ["name", "msme_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "msme_number", 3, "placeholder"],
                    ["id", "region-currency-settings", 1, "mt-1", 3, "title"],
                    ["name", "country_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label", "tooltipText"],
                    ["displayExpr", "name", "formControlName", "country_id", "id", "address-country", "searchMode", "contains", "valueExpr", "id", 3, "onSelectionChanged", "inputAttr", "items", "placeholder", "readOnly", "searchEnabled", "showClearButton"],
                    ["name", "currency_code", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "currency_code", "formControlName", "currency_code", "searchMode", "contains", "valueExpr", "currency_code", 3, "inputAttr", "items", "placeholder", "searchEnabled", "showClearButton"],
                    ["name", "date_time_format", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "format", "formControlName", "date_time_format", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled", "showClearButton"],
                    ["class", "p-3 border-bottom", 4, "dxTemplate", "dxTemplateOf"],
                    ["name", "timezone", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "timezone", "searchMode", "contains", 3, "items", "placeholder", "searchEnabled", "showClearButton"],
                    ["name", "locale", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "locale", "displayExpr", "Name", "valueExpr", "Value", "searchMode", "contains", 3, "onValueChanged", "items", "searchEnabled", "showClearButton", "placeholder"],
                    ["name", "employee_tracking_distance_unit", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "employee_tracking_distance_unit", "displayExpr", "Name", "valueExpr", "Value", "searchMode", "contains", 3, "onValueChanged", "items", "searchEnabled", "showClearButton", "placeholder"],
                    [1, "mt-3"],
                    [3, "parentForm"],
                    ["cancelBtnId", "account-basic-info-cancel", "saveBtnId", "account-basic-info-save", 3, "isVisibleHr"],
                    ["backBtnId", "account-basic-info-back", "editBtnId", "account-basic-info-edit"],
                    ["cancelBtnId", "account-basic-info-cancel", "saveBtnId", "account-basic-info-save", 3, "isVisibleHr", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "account-basic-info-cancel", "saveBtnId", "account-basic-info-save", 3, "cancelClick", "isVisibleHr"],
                    ["backBtnId", "account-basic-info-back", "editBtnId", "account-basic-info-edit", 3, "editClick", 4, "ngxPermissionsOnly"],
                    ["backBtnId", "account-basic-info-back", "editBtnId", "account-basic-info-edit", 3, "editClick"],
                    [1, "p-3", "border-bottom"],
                    [1, "d-flex", "justify-content-between", "mb-2", 2, "font-size", "12px"],
                    [1, "d-flex", "justify-content-between", 2, "font-size", "12px"]
                ],
                template: function(o, a) {
                    o & 1 && (d(0, rs, 3, 1, "div", 0), d(1, ss, 1, 1, "app-checklist-modal", 1), d(2, ls, 1, 2, "app-skeleton-loader", 2), d(3, Cs, 43, 91, "form", 3)), o & 2 && (u(a.businessReadinessService.shouldShowInSettings() ? 0 : -1), r(), u(a.isChecklistModalVisible() ? 1 : -1), r(), u(a.form ? -1 : 2), r(), u(a.form ? 3 : -1))
                },
                dependencies: [Gi, ee, j, O, qo, qe, it, pe, Ve, F, Ro, Go, Wo, G, le, ae, V, L, P, Bn, A, D, ne, ua, _a],
                encapsulation: 2
            })
        }
    }
    return t
})();
var xa = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, no), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var xs = () => ({ of: "#bankPanel"
});

function Ss(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 3), t & 2 && l("rows", 6)("columns", 3)
}

function bs(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 14), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.cancel())
        }), i()
    }
    if (t & 2) {
        let e = m(3);
        l("isSaving", e.isSaving)("isVisibleHr", !1)
    }
}

function ys(t, c) {
    if (t & 1 && T(0, bs, 1, 2, "app-save-cancel-footer", 13), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function Ts(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-edit-back-btn", 16), _("editClick", function() {
            g(e);
            let a = m(3);
            return C(a.setEditMode())
        }), i()
    }
}

function Es(t, c) {
    if (t & 1 && T(0, Ts, 1, 0, "app-edit-back-btn", 15), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function ws(t, c) {
    if (t & 1 && p(0, "app-server-error", 12), t & 2) {
        let e = m(2);
        l("errorResponse", e.errorResponse)
    }
}

function Is(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 6), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), n(1, "app-actionable-page-subtitle", 7), d(2, ys, 1, 1, "app-save-cancel-footer", 8)(3, Es, 1, 1, "app-edit-back-btn", 9), i(), p(4, "app-alert-panel", 10)(5, "app-bank", 11), d(6, ws, 1, 1, "app-server-error", 12), i()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(), l("title", "bank_account_details_subtitle"), r(), u(e.isEditMode ? 2 : 3), r(2), l("message", e.formatMessage("bank_details_note")), r(), l("isVisibleTitle", !1)("parentForm", e.form), r(), u(e.errorResponse ? 6 : -1)
    }
}
var Sa = (() => {
    class t {
        constructor(e) {
            this.bankService = e, this.formatMessage = f, this.formService = v(B), this.toastNotificationService = v(N), this.accountService = v(be), this.fb = new z, this.bank = new bt({}), this.errorResponse = null, this.isEditMode = !1, this.isLoading = !1, this.isSaving = !1, this.loaderLogo = Kt, this.PERMISSION_LIST = b
        }
        ngOnInit() {
            this.isLoading = !0, this.accountService.getTenant().subscribe({
                next: e => {
                    this.account = e, this.bankService.getListByQuery({
                        bankable_id: this.account.id,
                        bankable_type: fn.ACCOUNT
                    }).subscribe({
                        next: o => {
                            o.length && (this.bank = o[0]), this.form = this.fb.group({
                                bank: bt.getForm(new bt(this.bank))
                            }), this.form.disable()
                        },
                        error: o => {
                            console.log(o)
                        }
                    }).add(() => this.isLoading = !1)
                },
                error: e => {
                    console.error(e), this.isLoading = !1
                }
            })
        }
        save() {
            if (this.errorResponse = "", this.form.valid) {
                this.isSaving = !0;
                let e = this.form.value.bank;
                e.bankable_id = this.account.id, e.bankable_type = fn.ACCOUNT, (e ? .id ? this.bankService.update(e) : this.bankService.create(e)).subscribe({
                    next: a => {
                        this.toastNotificationService.success("notification_account_info_save_success"), this.isEditMode = !1, this.bank = a, this.form.patchValue(this.bank), this.form.disable(), window.location.reload()
                    },
                    error: a => {
                        this.errorResponse = a
                    }
                }).add(() => {
                    this.isSaving = !1
                })
            } else this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form.patchValue({
                bank: bt.getForm(new bt(this.bank))
            }), this.form.disable(), this.isEditMode = !1
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(xa))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-bank-information"]
                ],
                inputs: {
                    account: "account"
                },
                standalone: !1,
                decls: 6,
                vars: 8,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["id", "bankPanel"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "visibleChange", "visible", "indicatorSrc", "message", "position", "showPane"],
                    [3, "ngSubmit", "formGroup"],
                    [3, "title"],
                    ["cancelBtnId", "account-bank-cancel", "saveBtnId", "account-bank-save", "saveText", "common_save", "savingText", "saving", 3, "isSaving", "isVisibleHr"],
                    ["backBtnId", "account-bank-back", "editBtnId", "account-bank-edit"],
                    [3, "message"],
                    [3, "isVisibleTitle", "parentForm"],
                    [1, "mt-2", 3, "errorResponse"],
                    ["cancelBtnId", "account-bank-cancel", "saveBtnId", "account-bank-save", "saveText", "common_save", "savingText", "saving", 3, "isSaving", "isVisibleHr", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "account-bank-cancel", "saveBtnId", "account-bank-save", "saveText", "common_save", "savingText", "saving", 3, "cancelClick", "isSaving", "isVisibleHr"],
                    ["backBtnId", "account-bank-back", "editBtnId", "account-bank-edit", 3, "editClick", 4, "ngxPermissionsOnly"],
                    ["backBtnId", "account-bank-back", "editBtnId", "account-bank-edit", 3, "editClick"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), d(3, Ss, 1, 2, "app-skeleton-loader", 3), d(4, Is, 7, 7, "form", 4), i()()(), n(5, "dx-load-panel", 5), X("visibleChange", function(w) {
                        return $(a.isLoading, w) || (a.isLoading = w), w
                    }), i()), o & 2 && (r(3), u(a.form ? -1 : 3), r(), u(a.form ? 4 : -1), r(), Z("visible", a.isLoading), l("indicatorSrc", a.loaderLogo)("message", "")("position", Le(7, xs))("showPane", !1))
                },
                dependencies: [ee, O, Ho, qe, pe, Ve, F, Bi, V, P, A, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ks = ["logoUploader"];

function Ms(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-file-uploader", 6, 0), _("change", function(a) {
            g(e);
            let h = m();
            return C(h.onFileChange(a))
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("allowCanceling", !1)("maxFileSize", e.logoUploadLimit)("multiple", !1)
    }
}

function Ns(t, c) {
    if (t & 1 && (n(0, "div", 2)(1, "div", 4), p(2, "img", 7), i()()), t & 2) {
        let e = m();
        r(2), l("alt", e.account.attachments.name)("src", e.account.attachments.link, je)
    }
}
var ya = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.loaderService = o, this.formatMessage = f, this.toastNotificationService = v(N), this.accountService = v(be), this.logoUploadLimit = 102400, this.PERMISSION_LIST = b
        }
        ngOnInit() {
            this.accountService.getTenant().subscribe({
                next: e => {
                    this.account = e
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        onFileChange(e) {
            if (e.target.files[0].size > this.logoUploadLimit) {
                this.toastNotificationService.error("notification_file_upload_limit_100kb_exceeded", "", {
                    disableTimeOut: !0
                });
                return
            }
            this.loaderService.show(), this.service.uploadLogo(e.target.files[0]).subscribe({
                next: o => {
                    this.account = o, this.toastNotificationService.success("notification_logo_update_success"), this.logoUploader ? .instance ? .reset(), window.location.reload()
                },
                error: () => {
                    this.toastNotificationService.error("notification_logo_upload_error")
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        delete() {
            this.service.deleteLogo().subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_logo_delete_success")
                },
                error: e => {
                    this.toastNotificationService.error("notification_logo_delete_error"), console.log("Failed to delete logo ", e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(ai), I(Qe))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-logo"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(ks, 7), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.logoUploader = h.first)
                    }
                },
                inputs: {
                    account: "account"
                },
                standalone: !1,
                decls: 8,
                vars: 5,
                consts: [
                    ["logoUploader", ""],
                    [3, "title"],
                    [1, "row"],
                    [3, "message"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["accept", "image/png", "id", "account-logo", "uploadMode", "useForm", 3, "allowCanceling", "maxFileSize", "multiple", "change", 4, "ngxPermissionsOnly"],
                    ["accept", "image/png", "id", "account-logo", "uploadMode", "useForm", 3, "change", "allowCanceling", "maxFileSize", "multiple"],
                    ["height", "50", "width", "160", "loading", "lazy", 1, "img-fluid", 3, "alt", "src"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-actionable-page-subtitle", 1), n(1, "div", 2), p(2, "app-alert-panel", 3), n(3, "div", 4), T(4, Ms, 2, 3, "dx-file-uploader", 5), n(5, "p"), s(6), i()()(), d(7, Ns, 3, 2, "div", 2)), o & 2 && (l("title", "business_logo_details_subtitle"), r(2), l("message", a.formatMessage("business_logo_note")), r(2), l("ngxPermissionsOnly", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE), r(2), x(a.formatMessage("logo_validation")), r(), u(!(a.account == null || a.account.attachments == null) && a.account.attachments.id ? 7 : -1))
                },
                dependencies: [pe, Ve, xt, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ps = ["signatureUploader"];

function Vs(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-signature", 8), _("signatureSaveClick", function(a) {
            g(e);
            let h = m(2);
            return C(h.onAccountSignatureSave(a))
        }), i()
    }
    t & 2 && l("signatureName", "common_business_signature")
}

function As(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 5)(1, "dx-file-uploader", 9, 0), _("change", function(a) {
            g(e);
            let h = m(2);
            return C(h.onFileChange(a))
        }), i(), n(3, "p"), s(4), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(), l("allowCanceling", !1)("maxFileSize", e.signatureUploadLimit)("multiple", !1), r(3), x(e.formatMessage("signature_validation"))
    }
}

function Ls(t, c) {
    if (t & 1 && (n(0, "div", 3)(1, "div", 5), T(2, Vs, 1, 1, "app-signature", 6), i(), T(3, As, 5, 4, "div", 7), i()), t & 2) {
        let e = m();
        r(2), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE), r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function Ds(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "i", 14), _("click", function() {
            g(e);
            let a = m(3);
            return C(a.isVisibleDeletePopup = !0)
        }), i()
    }
}

function Os(t, c) {
    if (t & 1 && (n(0, "div", 11), T(1, Ds, 1, 0, "i", 12), p(2, "img", 13), i()), t & 2) {
        let e = m(2);
        r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE), r(), l("alt", e.account.signature)("src", e.account.signature, je)
    }
}

function Fs(t, c) {
    if (t & 1 && (n(0, "div", 3), T(1, Os, 3, 3, "div", 10), i()), t & 2) {
        let e = m();
        r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_VIEW)
    }
}

function Bs(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 15), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.delete())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.cancelDelete())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("confirmButtonText", "delete")("confirmationMessage", e.formatMessage("signature_delete_confirmation"))
    }
}
var Ta = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.loaderService = o, this.formatMessage = f, this.toastNotificationService = v(N), this.accountService = v(be), this.fileService = v(Po), this.signatureUploadLimit = 102400 * 5, this.isVisibleDeletePopup = !1, this.PERMISSION_LIST = b
        }
        onFileChange(e) {
            if (e.target.files[0].size > this.signatureUploadLimit) {
                this.toastNotificationService.success("notification_file_upload_limit_500kb_exceeded", "", {
                    disableTimeOut: !0
                });
                return
            }
            this.uploadSignatureFile(e.target.files[0])
        }
        uploadSignatureFile(e) {
            this.loaderService.show(), this.service.uploadSignature(e).subscribe({
                next: o => {
                    this.account = o, this.toastNotificationService.success("notification_signature_update_success"), this.signatureUploader.instance.reset()
                },
                error: () => {
                    this.toastNotificationService.error("notification_signature_upload_error")
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        onAccountSignatureSave(e) {
            let o = this.fileService.getFileFromDataUrl(e, "signature.png", "image/png");
            this.uploadSignatureFile(o)
        }
        ngOnInit() {
            this.accountService.getTenant().subscribe({
                next: e => {
                    this.account = e
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        delete() {
            this.service.deleteSignature().subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_signature_delete_success")
                },
                error: e => {
                    this.toastNotificationService.error("notification_signature_delete_error"), console.error("Failed to delete signature ", e)
                }
            }), this.account.signature = null, this.isVisibleDeletePopup = !1
        }
        cancelDelete() {
            this.isVisibleDeletePopup = !1
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(ai), I(Qe))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-signature"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(Ps, 7), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.signatureUploader = h.first)
                    }
                },
                inputs: {
                    account: "account"
                },
                standalone: !1,
                decls: 5,
                vars: 5,
                consts: [
                    ["signatureUploader", ""],
                    [3, "title"],
                    [3, "message"],
                    [1, "row"],
                    [3, "confirmButtonText", "confirmationMessage"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [3, "signatureName", "signatureSaveClick", 4, "ngxPermissionsOnly"],
                    ["class", "col-sm-6 col-md-6 col-lg-6", 4, "ngxPermissionsOnly"],
                    [3, "signatureSaveClick", "signatureName"],
                    ["accept", "image/png", "id", "account-signature", "uploadMode", "useButtons", 3, "change", "allowCanceling", "maxFileSize", "multiple"],
                    ["class", "col-sm-12 col-md-12 col-lg-12 account-signature-preview", 4, "ngxPermissionsOnly"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "account-signature-preview"],
                    ["class", "fa fa-times image-remove", 3, "click", 4, "ngxPermissionsOnly"],
                    ["height", "50", "width", "160", "loading", "lazy", 1, "img-fluid", "border", "border-primary", "p-3", 3, "alt", "src"],
                    [1, "fa", "fa-times", "image-remove", 3, "click"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-actionable-page-subtitle", 1)(1, "app-alert-panel", 2), d(2, Ls, 4, 2, "div", 3), d(3, Fs, 2, 1, "div", 3), d(4, Bs, 1, 2, "app-confirmation-popup", 4)), o & 2 && (l("title", "business_signature_details_subtitle"), r(), l("message", a.formatMessage("business_signature_note")), r(), u(a.account != null && a.account.signature ? -1 : 2), r(), u(a.account != null && a.account.signature ? 3 : -1), r(), u(a.isVisibleDeletePopup ? 4 : -1))
                },
                dependencies: [Ye, zo, pe, Ve, xt, ne],
                styles: [".account-signature-preview[_ngcontent-%COMP%]{position:relative}.account-signature-preview[_ngcontent-%COMP%]   .image-remove[_ngcontent-%COMP%]{font-size:20px;color:#fff;position:absolute;z-index:1;top:-8px;left:151px;padding:2px 7px;border-radius:50%;background:#000}"]
            })
        }
    }
    return t
})();
var ci = class {
    constructor(c) {
        return Object.assign(this, c)
    }
};
var Rs = () => ({
    "font-size": "12px"
});

function Gs(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 0), t & 2 && l("rows", 6)("columns", 3)
}

function Us(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 8), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.cancel())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function Ws(t, c) {
    if (t & 1 && T(0, Us, 1, 1, "app-save-cancel-footer", 7), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function qs(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-edit-back-btn", 10), _("editClick", function() {
            g(e);
            let a = m(3);
            return C(a.setEditMode())
        }), i()
    }
    if (t & 2) {
        let e = m(3);
        l("label", e.label)
    }
}

function Hs(t, c) {
    if (t & 1 && T(0, qs, 1, 1, "app-edit-back-btn", 9), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function js(t, c) {
    if (t & 1 && p(0, "app-copy-to-clipboard", 16), t & 2) {
        let e = m().$implicit,
            o = m(2);
        l("textToBeCopied", o.form.controls[e.name].value)
    }
}

function zs(t, c) {
    if (t & 1 && (n(0, "div", 5)(1, "div", 11)(2, "div", 12)(3, "div", 13), p(4, "i", 14), s(5), i(), p(6, "dx-text-box", 15), d(7, js, 1, 1, "app-copy-to-clipboard", 16), i()()()), t & 2) {
        let e = c.$implicit,
            o = m(2);
        r(3), l("ngStyle", Le(7, Rs)), r(), l("ngClass", e.icon), r(), E("", e.label, " "), r(), l("formControlName", e.name)("placeholder", e.placeholder)("readOnly", !o.isEditMode), r(), u(o.form.controls[e.name].value ? 7 : -1)
    }
}

function Qs(t, c) {
    if (t & 1 && p(0, "app-server-error", 6), t & 2) {
        let e = m(2);
        l("errorResponse", e.errorResponse)
    }
}

function Ys(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 2), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), n(1, "div"), d(2, Ws, 1, 1, "app-save-cancel-footer", 3)(3, Hs, 1, 1, "app-edit-back-btn", 4), i(), U(4, zs, 8, 8, "div", 5, Ee), d(6, Qs, 1, 1, "app-server-error", 6), i()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(2), u(e.isEditMode ? 2 : 3), r(2), W(e.communities), r(2), u(e.errorResponse ? 6 : -1)
    }
}
var wa = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isWizard = !1, this.formService = v(B), this.fb = new z, this.toastNotificationService = v(N), this.form = null, this.isSaving = !1, this.communities = [{
                name: "google",
                icon: "fa-brands fa-google",
                label: f("google_business_page"),
                placeholder: f("enter_google_page_link")
            }, {
                name: "website",
                icon: "fa-thin fa-link",
                label: f("common_website"),
                placeholder: f("enter_website_page_link_label")
            }], this.isEditMode = !1, this.PERMISSION_LIST = b
        }
        ngOnInit() {
            this.isWizard && this.setEditMode(), typeof this.account ? .review_links == "string" ? this.reviewLinkInfo = new ci(JSON.parse(this.account ? .review_links)) : this.reviewLinkInfo = new ci(this.account.review_links), this.form = this.fb.group({
                google: [this.reviewLinkInfo ? .google || null],
                website: [this.reviewLinkInfo ? .website || null]
            })
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, this.service.saveReviewLinks(this.form.value).subscribe({
                next: e => {
                    this.toastNotificationService.success("notification_review_link_info_update_success"), this.isEditMode = !1, this.reviewLinkInfo = new ci(e.info)
                },
                error: e => {
                    this.errorResponse = e
                }
            }).add(() => {
                this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form.reset(new Cn(this.reviewLinkInfo)), this.isEditMode = !1
        }
        setEditMode() {
            this.isEditMode = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(be))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-account-review-link-information"]
                ],
                inputs: {
                    account: "account",
                    label: "label",
                    isWizard: "isWizard"
                },
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["cancelBtnId", "account-basic-info-cancel", "saveBtnId", "account-social-info-save", 3, "isVisibleHr"],
                    ["backBtnId", "account-basic-info-back", "editBtnId", "account-social-info-read-only-mode", 3, "label"],
                    [1, "row", "my-3"],
                    [1, "mt-2", 3, "errorResponse"],
                    ["cancelBtnId", "account-basic-info-cancel", "saveBtnId", "account-social-info-save", 3, "isVisibleHr", "cancelClick", 4, "ngxPermissionsOnly"],
                    ["cancelBtnId", "account-basic-info-cancel", "saveBtnId", "account-social-info-save", 3, "cancelClick", "isVisibleHr"],
                    ["backBtnId", "account-basic-info-back", "editBtnId", "account-social-info-read-only-mode", 3, "label", "editClick", 4, "ngxPermissionsOnly"],
                    ["backBtnId", "account-basic-info-back", "editBtnId", "account-social-info-read-only-mode", 3, "editClick", "label"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "input-group", "flex-nowrap"],
                    ["id", "btnGroupAddon2", 1, "input-group-text", "theme-secondary-bg", 3, "ngStyle"],
                    [1, "me-2", 3, "ngClass"],
                    [1, "w-100", 3, "formControlName", "placeholder", "readOnly"],
                    [1, "mx-2", "align-content-center", 2, "position", "relative", "right", "2rem", 3, "textToBeCopied"]
                ],
                template: function(o, a) {
                    o & 1 && (d(0, Gs, 1, 2, "app-skeleton-loader", 0), d(1, Ys, 7, 3, "form", 1)), o & 2 && (u(a.form ? -1 : 0), r(), u(a.form ? 1 : -1))
                },
                dependencies: [Gt, Ni, ee, O, qe, F, ei, ae, V, L, P, A, D, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var mi = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            id: [c.id || null],
            name: [c.name || null, [k.required]],
            link: [c.link || null, [k.required, Ui.isValidUPILink]],
            is_default: [c.is_default || !1],
            attachments: [c.attachments || null, [k.required]]
        })
    }
};
var $s = () => ({
        at: "center",
        my: "center"
    }),
    Xs = () => ({
        x: 100,
        y: 100
    }),
    Js = t => ({
        at: "top",
        my: "top",
        offset: t
    });

function el(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 4), t & 2 && l("rows", 4)("columns", 2)
}

function tl(t, c) {
    if (t & 1 && p(0, "img", 15), t & 2) {
        let e = m(3);
        l("src", e.previewUrl, je)("alt", e.formatMessage("qr_code_image"))
    }
}

function il(t, c) {
    if (t & 1 && p(0, "app-server-error", 16), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function nl(t, c) {
    if (t & 1 && (n(0, "p", 17), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.errorMessage)
    }
}

function ol(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 6), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "dx-scroll-view", 7)(2, "div", 2)(3, "app-control-container", 8)(4, "dx-text-box", 9)(5, "dx-validator"), p(6, "dxi-validation-rule", 10), i()()(), n(7, "app-control-container", 11), p(8, "dx-text-box", 12)(9, "app-error", 13), i(), n(10, "dx-file-uploader", 14), _("onValueChanged", function(a) {
            g(e);
            let h = m(2);
            return C(h.onQRCodeUpload(a))
        }), i(), n(11, "div", 3), p(12, "app-error", 13), i(), d(13, tl, 1, 2, "img", 15), i()(), n(14, "div", 2)(15, "div", 3), d(16, il, 1, 1, "app-server-error", 16), d(17, nl, 2, 1, "p", 17), n(18, "app-save-cancel-footer", 18), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i()()()()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(3), l("errorMsg", e.formatMessage("upi_link_name_is_a_required_field"))("label", e.formatMessage("upi_link_name_label")), r(), l("placeholder", e.formatMessage("upi_link_example")), r(2), l("ignoreEmptyValue", !0)("validationCallback", e.asyncUniqueNameValidation)("message", e.formatMessage("upi_link_already_exists")), r(), l("errorMsg", e.formatMessage("upi_link_is_a_required_field"))("label", e.formatMessage("upi_link_label")), r(2), l("displayError", e.form.get("link").invalid && e.form.get("link").touched && e.form.get("link").errors.invalidUPILink)("errorMsg", e.formatMessage("upi_link_invalid")), r(), l("allowCanceling", !0), r(2), l("displayError", e.form.get("attachments").invalid && e.form.get("attachments").touched)("errorMsg", e.formatMessage("please_select_a_file_to_upload")), r(), u(e.previewUrl ? 13 : -1), r(3), u(e.errorResponse ? 16 : -1), r(), u(e.errorMessage ? 17 : -1), r(), l("isOnPopup", !0)
    }
}

function al(t, c) {
    if (t & 1 && (n(0, "div")(1, "div", 2)(2, "div", 3), d(3, el, 1, 2, "app-skeleton-loader", 4), d(4, ol, 19, 18, "form", 5), i()()()), t & 2) {
        let e = m();
        r(3), u(e.form ? -1 : 3), r(), u(e.form ? 4 : -1)
    }
}
var Ia = (() => {
    class t {
        constructor(e, o) {
            this.service = e, this.attachmentService = o, this.formatMessage = f, this.isVisiblePopup = !1, this.isCreate = !0, this.upiLinkSaveClick = new ue, this.upiLinkCancelClick = new ue, this.userDeviceService = v(se), this.isMobileDevice = this.userDeviceService.isMobileDevice(), this.ENTITIES = Q, this.formService = v(B), this.commonService = v(vt), this.toastNotificationService = v(N), this.errorResponse = null, this.attachableType = Q.UPI_LINK.name, this.previewUrl = null, this.entity = Q.UPI_LINK, this.errorMessage = "", this.isSaving = !1, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.entity.table,
                name: e.value,
                entity_id: this.upiLink ? .id
            }).pipe(Ot(o => !!(o ? .success && o.success))).toPromise()
        }
        ngOnInit() {
            this.form = mi.getForm(new mi(this.isCreate ? {} : this.upiLink)), this.form.get("link").valueChanges.subscribe({
                next: e => {
                    this.form.get("link").setValue(e.toLowerCase(), {
                        emitEvent: !1
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.upiLink = new mi(o), this.attachmentService.uploadFile(this.form.value.attachments, this.upiLink.id, this.attachableType, !0, this.attachableType, !0).subscribe({
                        next: () => {
                            this.toastNotificationService.success(this.isCreate ? "notification_upi_link_add_success" : "notification_upi_link_update_success"), this.upiLinkSaveClick.emit(this.upiLink), this.form = null, this.isVisiblePopup = !1
                        },
                        error: a => {
                            console.error(a)
                        }
                    })
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => {
                this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.upiLink = null, this.upiLinkCancelClick.emit()
        }
        onQRCodeUpload(e) {
            if (e.value.length) {
                let o = new FileReader;
                o.readAsDataURL(e.value[0]), o.onload = () => {
                    this.previewUrl = o.result, this.form.patchValue({
                        attachments: e.value[0]
                    })
                }
            } else this.previewUrl = null
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Yi), I(ai))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-upi-link"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate",
                    upiLink: "upiLink"
                },
                outputs: {
                    upiLinkSaveClick: "upiLinkSaveClick",
                    upiLinkCancelClick: "upiLinkCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 12,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "height", "maxHeight", "width", "maxWidth", "position", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["height", "100%", "width", "100%"],
                    ["name", "name", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "validationCallback", "message"],
                    ["name", "link", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "link", "placeholder", "eg. example@ybl"],
                    [3, "displayError", "errorMsg"],
                    ["accept", "image/*", "id", "attachment-uploader", "uploadMode", "useButtons", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "onValueChanged", "allowCanceling"],
                    ["height", "200", "width", "200", "loading", "lazy", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "src", "alt"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "text-danger"],
                    [3, "cancelClick", "isOnPopup"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, al, 5, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("height", "auto")("maxHeight", "90vh")("width", "95vw")("maxWidth", a.isMobileDevice ? "300" : "600")("position", a.isMobileDevice ? Le(8, $s) : $e(10, Js, Le(9, Xs)))("title", a.isCreate ? "Add New UPI Link" : "Update UPI Link"), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [Gi, ee, j, O, F, G, Ct, xt, re, Ce, ae, St, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function sl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-upi-link", 2), _("upiLinkCancelClick", function() {
            g(e);
            let a = m();
            return C(a.isVisibleUPILinkPopup = !1)
        })("upiLinkSaveClick", function(a) {
            g(e);
            let h = m();
            return C(h.onUPILinkSave(a))
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleUPILinkPopup)("upiLink", e.upiLink)
    }
}
var ka = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.userSessionService = v(tt), this.userPermissionList = this.userSessionService.userPermissionList(), this.ENTITIES = Q, this.entity = Q.UPI_LINK, this.isVisibleUPILinkPopup = !1, this.upiLink = null, this.isCreate = !1, this.columns = [{
                dataField: "name",
                caption: f("common_name"),
                width: 260,
                allowSorting: !1
            }, {
                dataField: "link",
                caption: f("link"),
                dataType: "string",
                alignment: "center",
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "attachments",
                caption: f("qr_code"),
                hidingPriority: 4,
                cellTemplate: "attachmentTemplate",
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: f("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                alignment: "center"
            }, {
                dataField: "updated_at",
                caption: f("common_updated_on"),
                hidingPriority: 1,
                alignment: "center",
                cellTemplate: "dateTimeTemplate",
                visible: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.PERMISSION_LIST = b
        }
        onToolbarPreparing(e) {
            e.toolbarOptions.items.push({
                template: "tableHeaderTemplate",
                location: "before",
                locateInMenu: "never"
            }, {
                template: "addBtnTemplate",
                location: "after",
                locateInMenu: "never"
            })
        }
        create() {
            this.isVisibleUPILinkPopup = !0, this.isCreate = !0
        }
        onUPILinkSave(e) {
            this.isCreate = !1, this.isVisibleUPILinkPopup = !1, this.upiLink = null, this.dataGrid.getData()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Yi))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-upi-list"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(Re, 5), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.dataGrid = h.first)
                    }
                },
                inputs: {
                    account: "account"
                },
                standalone: !1,
                decls: 2,
                vars: 9,
                consts: [
                    [3, "dataGridAddNewClick", "columns", "deleteAccessPermissionName", "entity", "isVisibleAddAction", "isVisibleEditAction", "service", "searchPanelPlaceholderText", "writeAccessPermissionName"],
                    [3, "isCreate", "isVisiblePopup", "upiLink"],
                    [3, "upiLinkCancelClick", "upiLinkSaveClick", "isCreate", "isVisiblePopup", "upiLink"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return a.create()
                    }), i(), d(1, sl, 1, 3, "app-upi-link", 1)), o & 2 && (l("columns", a.columns)("deleteAccessPermissionName", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE)("entity", a.entity)("isVisibleAddAction", a.userPermissionList.includes(a.PERMISSION_LIST.BUSINESS_SETTING_WRITE))("isVisibleEditAction", !1)("service", a.service)("searchPanelPlaceholderText", "search_panel_upi_link_placeholder")("writeAccessPermissionName", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE), r(), u(a.isVisibleUPILinkPopup ? 1 : -1))
                },
                dependencies: [Re, Ia],
                encapsulation: 2
            })
        }
    }
    return t
})();
var cl = (t, c) => [t, c];

function ml(t, c) {
    if (t & 1 && (n(0, "div", 5)(1, "h6"), s(2), i()()), t & 2) {
        let e = c.$implicit;
        r(2), x(e.title)
    }
}

function pl(t, c) {
    if (t & 1 && p(0, "app-account-review-link-information", 7), t & 2) {
        let e = m(2);
        l("account", e.account)
    }
}

function dl(t, c) {
    if (t & 1 && (n(0, "div"), p(1, "app-alert-panel", 6), d(2, pl, 1, 1, "app-account-review-link-information", 7), i()), t & 2) {
        let e = m();
        r(), l("message", e.formatMessage("review_link_note")), r(), u(e.account ? 2 : -1)
    }
}

function ul(t, c) {
    if (t & 1 && p(0, "app-copy-to-clipboard", 14), t & 2) {
        let e = m(3);
        l("textToBeCopied", e.selfCheckInUrl)
    }
}

function _l(t, c) {
    if (t & 1 && (p(0, "app-alert-panel", 6), n(1, "div", 8)(2, "div", 9)(3, "div", 10), p(4, "i", 11), n(5, "span", 12), s(6), i()(), p(7, "dx-text-box", 13), d(8, ul, 1, 1, "app-copy-to-clipboard", 14), i()()), t & 2) {
        let e = m(2);
        l("message", e.formatMessage("self_check_in_note")), r(6), x(e.formatMessage("job_self_check_in")), r(), l("placeholder", e.selfCheckInUrl)("readOnly", !0), r(), u(e.selfCheckInUrl ? 8 : -1)
    }
}

function fl(t, c) {
    if (t & 1 && (n(0, "div"), d(1, _l, 9, 5), i()), t & 2) {
        let e = m();
        r(), u(Mi(1, cl, e.TENANT_PLANS.STANDARD, e.TENANT_PLANS.ENTERPRISE).includes(e.plan) ? 1 : -1)
    }
}

function gl(t, c) {
    if (t & 1 && p(0, "app-alert-panel", 6)(1, "app-upi-list"), t & 2) {
        let e = m(2);
        l("message", e.formatMessage("upi_link_note"))
    }
}

function Cl(t, c) {
    if (t & 1 && (n(0, "div"), d(1, gl, 2, 1), i()), t & 2) {
        let e = m();
        r(), u(e.isIndia ? 1 : -1)
    }
}
var Ma = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tenantService = v(ie), this.accountService = v(be), this.isIndia = this.tenantService.isIndia(), this.plan = this.tenantService.plan(), this.selfCheckInUrl = "", this.items = [{
                id: 1,
                title: f("review_links"),
                visible: !0,
                template: "reviewLinksTemplate"
            }, {
                id: 2,
                title: f("job_self_check_in") + " " + f("common_link"),
                visible: [H.STANDARD, H.ENTERPRISE].includes(this.plan),
                template: "selfCheckInLinksTemplate"
            }, {
                id: 3,
                title: f("upi_link"),
                visible: this.isIndia,
                template: "upiLinksTemplate"
            }].filter(e => e.visible), this.TENANT_PLANS = H
        }
        ngOnInit() {
            this.selfCheckInUrl = window.location.origin + "/guest/lead", this.accountService.getTenant().subscribe({
                next: e => {
                    this.account = e
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-important-links"]
                ],
                inputs: {
                    account: "account"
                },
                standalone: !1,
                decls: 8,
                vars: 9,
                consts: [
                    ["importantLinksAccordion", ""],
                    [3, "title"],
                    ["id", "important-links-accordion-container", 3, "dataSource", "collapsible", "multiple", "selectedItems"],
                    ["class", "accordion-title d-flex flex-row-reverse justify-content-between align-items-center theme-secondary-bg", 4, "dxTemplate", "dxTemplateOf"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "accordion-title", "d-flex", "flex-row-reverse", "justify-content-between", "align-items-center", "theme-secondary-bg"],
                    [3, "message"],
                    [3, "account"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "input-group", "flex-nowrap"],
                    ["id", "btnGroupAddon2", 1, "input-group-text", "theme-secondary-bg"],
                    [1, "fa-solid", "fa-user-check", "me-2"],
                    [1, "fs-12"],
                    [1, "w-100", 3, "placeholder", "readOnly"],
                    [1, "mx-2", "align-content-center", 2, "position", "relative", "right", "2rem", 3, "textToBeCopied"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div"), p(1, "app-actionable-page-subtitle", 1), n(2, "dx-accordion", 2, 0), T(4, ml, 3, 1, "div", 3)(5, dl, 3, 2, "div", 4)(6, fl, 2, 4, "div", 4)(7, Cl, 2, 1, "div", 4), i()()), o & 2 && (r(), l("title", "important_links"), r(), l("dataSource", a.items)("collapsible", !0)("multiple", !0)("selectedItems", a.items), r(2), l("dxTemplateOf", "title"), r(), l("dxTemplateOf", "reviewLinksTemplate"), r(), l("dxTemplateOf", "selfCheckInLinksTemplate"), r(), l("dxTemplateOf", "upiLinksTemplate"))
                },
                dependencies: [pe, Ve, ei, ni, G, ae, wa, ka],
                encapsulation: 2
            })
        }
    }
    return t
})();
var bn = [{
        day: "Sunday",
        label: "Sunday"
    }, {
        day: "Monday",
        label: "Monday"
    }, {
        day: "Tuesday",
        label: "Tuesday"
    }, {
        day: "Wednesday",
        label: "Wednesday"
    }, {
        day: "Thursday",
        label: "Thursday"
    }, {
        day: "Friday",
        label: "Friday"
    }, {
        day: "Saturday",
        label: "Saturday"
    }],
    Ti = class t {
        constructor(c) {
            return Object.assign(this, c)
        }
        static getForm(c = []) {
            let e = new z,
                o = bn.map(a => {
                    let h = c.find(w => w.day === a.day);
                    return t.createDayForm(a, h)
                });
            return e.group({
                hours: e.array(o)
            })
        }
        static createDayForm(c, e = null) {
            let o = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].includes(c.day),
                a = e ? .is_open ? ? o,
                h = e ? .opening_at ? ? (o ? "09:00 am" : null),
                w = e ? .closing_at ? ? (o ? "06:00 pm" : null),
                Dt = new z().group({
                    day: [c.day],
                    is_open: [a],
                    opening_at: new Se({
                        value: h,
                        disabled: !a
                    }, a ? k.required : []),
                    closing_at: new Se({
                        value: w,
                        disabled: !a
                    }, a ? k.required : [])
                });
            return Dt.get("is_open") ? .valueChanges.subscribe(ln => {
                let gi = Dt.get("opening_at"),
                    Ci = Dt.get("closing_at");
                ln ? (gi ? .enable(), Ci ? .enable(), gi ? .setValidators(k.required), Ci ? .setValidators(k.required)) : (gi ? .disable(), Ci ? .disable(), gi ? .clearValidators(), Ci ? .clearValidators()), gi ? .updateValueAndValidity(), Ci ? .updateValueAndValidity()
            }), Dt
        }
    };

function hl(t, c) {
    if (t & 1 && p(0, "app-server-error", 2), t & 2) {
        let e = m();
        l("errorResponse", e.errorResponse)
    }
}

function xl(t, c) {
    if (t & 1 && (n(0, "p", 3), s(1), i()), t & 2) {
        let e = m();
        r(), x(e.errorMessage)
    }
}

function Sl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 11), _("cancelClick", function() {
            g(e);
            let a = m();
            return C(a.onCancel())
        })("saveClick", function() {
            g(e);
            let a = m();
            return C(a.submit())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function bl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 14), _("click", function() {
            g(e);
            let a = m(2);
            return C(a.onEditMode())
        }), i()
    }
}

function yl(t, c) {
    if (t & 1 && (n(0, "div", 6), p(1, "app-location-back", 12), T(2, bl, 1, 0, "app-dx-outline-button", 13), i()), t & 2) {
        let e = m();
        r(2), l("ngxPermissionsOnly", e.PERMISSION_LIST.JOB_WRITE)
    }
}

function Tl(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 9), t & 2 && l("rows", 7)("columns", 3)
}

function El(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "tr", 10)(1, "td", 19)(2, "strong"), s(3), i()(), n(4, "td", 20)(5, "dx-switch", 21), _("onValueChanged", function(a) {
            let h = g(e).$index,
                w = m(2);
            return C(w.onDayIsOpenChange(a, h))
        }), i()(), n(6, "td", 22)(7, "app-control-container", 23)(8, "dx-select-box", 24)(9, "dx-validator"), p(10, "dxi-validation-rule", 25), i()()()(), n(11, "td", 22)(12, "app-control-container", 26)(13, "dx-select-box", 27)(14, "dx-validator"), p(15, "dxi-validation-rule", 25), i()()()()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = m(2);
        l("formGroup", e), r(3), x(e.getRawValue().day), r(4), l("errorMsg", o.formatMessage("opening_time")), r(), l("dataSource", o.timeOptions)("disabled", !e.get("is_open").value)("searchEnabled", !0), r(2), l("message", o.formatMessage("Opening time is required")), r(2), l("errorMsg", o.formatMessage("closing_time")), r(), l("dataSource", o.timeOptions)("disabled", !e.get("is_open").value)("placeholder", o.formatMessage("common_to"))("searchEnabled", !0), r(2), l("message", o.formatMessage("closing_time"))
    }
}

function wl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 15), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.submit())
        }), n(1, "div", 16)(2, "div", 0)(3, "div", 17)(4, "table", 18), U(5, El, 16, 13, "tr", 10, Ee), i()()()()()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(5), W(e.form.get("hours").controls)
    }
}
var Na = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tenantService = v(ie), this.isMobileDevice = v(se).isMobileDevice(), this.toastNotificationService = v(N), this.days = bn, this.isEditMode = ce(!1), this.service = v(Xo), this.timeOptions = [], this.SETTINGS_TYPE = gt, this.PERMISSION_LIST = b, this.SETTINGS_SECTION_TYPE = It
        }
        ngOnInit() {
            this.timeOptions = this.generateTimeSlots();
            let e = this.tenantService ? .config() ? .business_hours ? ? [];
            e ? (this.form = Ti.getForm(e), this.form.disable()) : (this.form = Ti.getForm(), this.timeOptions = this.generateTimeSlots())
        }
        onCancel() {
            this.isEditMode.update(() => !1), this.form.disable(), this.businessHourSetting.cancel()
        }
        submit() {
            let e = this.form.value.hours.map(o => ct(lt({}, o), {
                opening_at: o.is_open ? o.opening_at : null,
                closing_at: o.is_open ? o.closing_at : null
            }));
            this.businessHourSetting.form.get("general_settings") ? .value ? .[0] ? .value ? this.service.saveBusinessHours(e).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_business_settings_save_success")
                },
                error: () => {
                    this.toastNotificationService.error("notification_business_hours_save_error")
                }
            }).add(() => {
                this.businessHourSetting.save()
            }) : this.businessHourSetting.save()
        }
        onDayIsOpenChange(e, o) {
            let a = this.form.get("hours").controls[o];
            e.value ? (a.get("opening_at").enable(), a.get("closing_at").enable()) : (a.get("opening_at").disable(), a.get("closing_at").disable())
        }
        generateTimeSlots() {
            let e = [];
            for (let a = 0; a < 1440; a += 30) {
                let h = Math.floor(a / 60),
                    w = a % 60,
                    Lt = h % 12 || 12,
                    Dt = h < 12 ? "am" : "pm",
                    ln = `${Lt.toString().padStart(2,"0")}:${w.toString().padStart(2,"0")} ${Dt}`;
                e.push(ln)
            }
            return e
        }
        onEditMode() {
            this.businessHourSetting.setEditMode(), this.businessHourSetting.form.get("general_settings") ? .value ? .[0] ? .value && this.form.enable(), this.isEditMode.update(() => !0)
        }
        toggle(e) {
            this.isEditMode() && e ? this.form.enable() : this.form.disable()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-business-hours-form"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(Xi, 5), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.businessHourSetting = h.first)
                    }
                },
                standalone: !1,
                decls: 11,
                vars: 6,
                consts: [
                    [1, "row"],
                    [3, "title"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "text-danger"],
                    [1, "d-flex", "flex-row", "justify-content-end"],
                    ["cancelBtnId", "business-hours-popup-cancel", "saveBtnId", "business-hours-popup-save", 3, "isVisibleHr"],
                    [1, "d-flex", "mobile-action-buttons"],
                    [3, "toggle"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    ["cancelBtnId", "business-hours-popup-cancel", "saveBtnId", "business-hours-popup-save", 3, "cancelClick", "saveClick", "isVisibleHr"],
                    ["id", "job-basic-info-back"],
                    ["buttonType", "default", "class", "ms-2", "text", "common_edit", "title", "common_edit", 3, "click", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "ms-2", 3, "click"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "section", "mb-4"],
                    [1, "col-sm-12"],
                    [1, "business-hours-table", "w-100"],
                    [1, "day-cell"],
                    [1, "action-cell"],
                    ["formControlName", "is_open", "switchedOffText", "Open", "switchedOnText", "Closed", 3, "onValueChanged"],
                    [1, "time-cell"],
                    ["name", "opening_at", 3, "errorMsg"],
                    ["formControlName", "opening_at", "placeholder", "From", 3, "dataSource", "disabled", "searchEnabled"],
                    ["type", "required", 3, "message"],
                    ["name", "closing_at", 3, "errorMsg"],
                    ["formControlName", "closing_at", 3, "dataSource", "disabled", "placeholder", "searchEnabled"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "app-actionable-page-subtitle", 1), d(2, hl, 1, 1, "app-server-error", 2), d(3, xl, 2, 1, "p", 3), n(4, "div", 4), d(5, Sl, 1, 1, "app-save-cancel-footer", 5)(6, yl, 3, 1, "div", 6), i()(), n(7, "app-business-hour-settings", 7), _("toggle", function(w) {
                        return a.toggle(w)
                    }), i(), n(8, "div", 8), d(9, Tl, 1, 2, "app-skeleton-loader", 9), d(10, wl, 7, 1, "form", 10), i()()), o & 2 && (r(), l("title", "standard_working_hours"), r(), u(a.errorResponse ? 2 : -1), r(), u(a.errorMessage ? 3 : -1), r(2), u(a.isEditMode() ? 5 : 6), r(4), u(a.form ? -1 : 9), r(), u(a.form ? 10 : -1))
                },
                dependencies: [Qi, ee, j, O, Xi, Ve, F, we, Ct, le, Be, St, V, L, P, A, D, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var nn = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tenantService = v(ie), this.router = v(ge), this.activatedRoute = v(De), this.userDeviceService = v(se), this.plan = this.tenantService.plan(), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.selectedTabIndex = null, this.listSettingsMenu = [{
                id: 0,
                text: f("add_custom_fields"),
                path: "/settings/custom-fields",
                icon: "fa-thin fa-pen-field",
                visible: !0
            }, {
                id: 1,
                text: f("general_settings"),
                path: "/settings/general",
                icon: "fa-thin fa-sliders",
                disabled: [H.LITE].includes(this.plan),
                visible: !0
            }, {
                id: 2,
                text: f("module_settings"),
                path: "/settings/modules",
                icon: "fa-thin fa-bars",
                disabled: [H.LITE].includes(this.plan),
                visible: !0
            }]
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex, this.router.navigate([e.itemData.path])
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-general-tabs"]
                ],
                standalone: !1,
                decls: 4,
                vars: 0,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-12"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "router-outlet"), i()()())
                },
                dependencies: [Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Il(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 2), t & 2 && l("rows", 8)("columns", 3)
}

function kl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 11), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.cancel())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function Ml(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-edit-back-btn", 13), _("editClick", function() {
            g(e);
            let a = m(3);
            return C(a.setEditMode())
        }), i()
    }
}

function Nl(t, c) {
    if (t & 1 && T(0, Ml, 1, 0, "app-edit-back-btn", 12), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function Pl(t, c) {
    if (t & 1 && (n(0, "div", 10)(1, "app-control-container", 15), p(2, "dx-switch", 16), n(3, "span", 17), s(4), i()(), p(5, "app-tooltip", 18), i()), t & 2) {
        let e = c.$implicit;
        l("formGroup", e), r(), l("isLabelOnSameLine", !0), r(3), x((e.controls.display_name == null ? null : e.controls.display_name.value) ? ? "Value"), r(), l("title", (e.controls.display_name == null ? null : e.controls.display_name.value) ? ? "")("target", (e.controls.key == null ? null : e.controls.key.value) ? ? "Value")("needTranslation", !1)("tooltipText", (e.controls.description == null ? null : e.controls.description.value) ? ? "Value")
    }
}

function Vl(t, c) {
    if (t & 1 && T(0, Pl, 6, 7, "div", 14), t & 2) {
        let e = m(2);
        l("ngForOf", e.form.get("general_settings").controls)
    }
}

function Al(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 4), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), n(1, "div", 5)(2, "div", 6), d(3, kl, 1, 1, "app-save-cancel-footer", 7)(4, Nl, 1, 1, "app-edit-back-btn", 8), i()(), n(5, "div", 9), d(6, Vl, 1, 1, "div", 10), i()()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(3), u(e.isEditMode ? 3 : 4), r(3), u(e.form.get("general_settings") ? 6 : -1)
    }
}
var Va = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.formService = v(B), this.configService = v(Xt), this.toastNotificationService = v(N), this.plan = v(ie).plan(), this.isEditMode = !1, this.PERMISSION_LIST = b
        }
        ngOnInit() {
            this.configService.appConfig$.subscribe({
                next: e => {
                    let o = [H.LITE, H.BASIC].includes(this.plan),
                        a = [Zt.GENERAL_SETTINGS.ENABLE_MODEL_WISE_SERVICE_PRICING, Zt.GENERAL_SETTINGS.NOTIFICATION_TEMPLATE_EMAIL_SIGNATURE, Zt.GENERAL_SETTINGS.NOTIFICATION_TEMPLATE_SMS_SIGNATURE, Zt.GENERAL_SETTINGS.NOTIFICATION_TEMPLATE_WHATSAPP_SIGNATURE];
                    this.generalSettings = e ? .general_settings.filter(h => h.setting_type === gt.GENERAL_SETTINGS && !a.includes(h.key) && !(o && h.key === Zt.GENERAL_SETTINGS.ENABLE_TWO_FACTOR_AUTHENTICATION) && ![It.BUSINESS_HOURS, It.DEFAULT_NOTIFICATIONS].includes(h.section)), this.form = Qo.getForm({
                        general_settings: this.generalSettings
                    }), this.form.disable()
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        save() {
            this.form.valid ? this.service.generalSettings(this.form.value).subscribe({
                next: e => {
                    this.toastNotificationService.success("notification_job_settings_update_success"), this.isEditMode = !1, this.form.disable(), window.location.reload()
                },
                error: e => {
                    this.toastNotificationService.error("notification_job_settings_update_error")
                }
            }) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form.reset({
                general_settings: this.generalSettings
            }), this.form.disable(), this.isEditMode = !1
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ki))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-general-setting"]
                ],
                standalone: !1,
                decls: 4,
                vars: 4,
                consts: [
                    [1, "mt-3", 3, "title"],
                    [3, "message"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mt-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["cancelBtnId", "settings-cancel", "saveBtnId", "settings-save", 3, "isVisibleHr"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit"],
                    [1, "row"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center", "gap-2", 3, "formGroup"],
                    ["cancelBtnId", "settings-cancel", "saveBtnId", "settings-save", 3, "cancelClick", "isVisibleHr"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit", 3, "editClick", 4, "ngxPermissionsOnly"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit", 3, "editClick"],
                    ["class", "col-sm-3 col-md-3 col-lg-3 d-flex align-items-center gap-2", 3, "formGroup", 4, "ngFor", "ngForOf"],
                    ["name", "value", 1, "d-flex", "align-items-center", "gap-2", 3, "isLabelOnSameLine"],
                    ["formControlName", "value", 1, "align-middle"],
                    [1, "ms-2"],
                    [1, "ms-1", "mb-1", "mt-4", 3, "title", "target", "needTranslation", "tooltipText"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-section-title", 0)(1, "app-alert-panel", 1), d(2, Il, 1, 2, "app-skeleton-loader", 2), d(3, Al, 7, 3, "form", 3)), o & 2 && (l("title", "general_settings"), r(), l("message", a.formatMessage("general_settings_description")), r(), u(a.form ? -1 : 2), r(), u(a.form ? 3 : -1))
                },
                dependencies: [Ut, j, O, qe, it, ii, pe, F, Be, V, L, P, A, D, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var on = class t {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new ut({
            display_name: new Se(c.display_name || null, [k.required]),
            name: new Se(c.name || null, [k.required]),
            description: new Se(c.description || null),
            tenant_id: new Se(c.tenant_id || null, [k.required]),
            is_active: new Se(c.is_active || null)
        })
    }
    static getFormArray(c) {
        let e = new Pi([]);
        return c && c.length && c.forEach(o => {
            e.push(t.getForm(o))
        }), e
    }
};
var an = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            modules: on.getFormArray(c.modules)
        })
    }
};
var Aa = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, _n), this.api = e, this.endpoint = _n
        }
        updateModuleSettings(e) {
            return this.api.put(this.endpoint, e)
        }
        getAllModuleSettings() {
            return this.api.get(this.endpoint + "/getAllModuleSettings")
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Dl = () => ({ of: "#module-settings"
});

function Ol(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 4), t & 2 && l("rows", 6)("columns", 3)
}

function Fl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 13), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.cancel())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function Bl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-edit-back-btn", 15), _("editClick", function() {
            g(e);
            let a = m(4);
            return C(a.setEditMode())
        }), i()
    }
}

function Rl(t, c) {
    if (t & 1 && T(0, Bl, 1, 0, "app-edit-back-btn", 14), t & 2) {
        let e = m(3);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function Gl(t, c) {
    if (t & 1 && (n(0, "div", 8)(1, "div", 1), d(2, Fl, 1, 1, "app-save-cancel-footer", 11)(3, Rl, 1, 1, "app-edit-back-btn", 12), i()()), t & 2) {
        let e = m(2);
        r(2), u(e.isEditMode() ? 2 : 3)
    }
}

function Ul(t, c) {
    if (t & 1 && (n(0, "div", 10)(1, "app-control-container", 17), p(2, "dx-switch", 18), n(3, "span", 19), s(4), i()(), p(5, "app-tooltip", 20), i()), t & 2) {
        let e = c.$implicit;
        l("formGroup", e), r(), l("isLabelOnSameLine", !0), r(), l("value", !0), r(2), x((e.controls.display_name == null ? null : e.controls.display_name.value) ? ? "Value"), r(), l("needTranslation", !1)("title", (e.controls.display_name == null ? null : e.controls.display_name.value) ? ? "")("target", (e.controls.name == null ? null : e.controls.name.value) ? ? "Value")("tooltipText", (e.controls.description == null ? null : e.controls.description.value) ? ? "Value")
    }
}

function Wl(t, c) {
    if (t & 1 && T(0, Ul, 6, 8, "div", 16), t & 2) {
        let e = m(2);
        l("ngForOf", e.form.get("modules").controls)
    }
}

function ql(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 7), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), d(1, Gl, 4, 1, "div", 8), n(2, "div", 9)(3, "div", 9), d(4, Wl, 1, 1, "div", 10), i()()()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(), u(e.isOnWizard ? -1 : 1), r(3), u(e.form.get("modules") ? 4 : -1)
    }
}
var La = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isOnWizard = !1, this.initialized = new ue, this.formService = v(B), this.toastNotificationService = v(N), this.isEditMode = ce(!1), this.isLoading = ce(!1), this.PERMISSION_LIST = b, this.loaderLogo = Kt
        }
        ngOnInit() {
            this.fetchModules()
        }
        save() {
            this.form.valid ? this.service.updateModuleSettings(this.form.value).subscribe({
                next: e => {
                    this.toastNotificationService.success("notification_module_settings_update_success"), this.isEditMode.set(!1), this.form.disable(), this.isOnWizard || window.location.reload()
                },
                error: e => {
                    this.toastNotificationService.error("notification_module_settings_update_error")
                }
            }) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form.reset({
                modules: this.modules
            }), this.form.disable(), this.isEditMode.set(!1)
        }
        setEditMode() {
            this.isEditMode.set(!0), this.form.enable()
        }
        fetchModules() {
            this.isLoading.set(!0), this.service.getAllModuleSettings().subscribe({
                next: e => {
                    this.modules = e, this.form = an.getForm({
                        modules: this.modules
                    }), this.form.disable()
                },
                error: e => {
                    this.toastNotificationService.error("notification_module_fetch_error")
                }
            }).add(() => {
                this.isLoading.set(!1), this.isOnWizard && this.setEditMode()
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Aa))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-module-setting"]
                ],
                inputs: {
                    isOnWizard: "isOnWizard"
                },
                outputs: {
                    initialized: "initialized"
                },
                standalone: !1,
                decls: 7,
                vars: 9,
                consts: [
                    ["id", "module-settings", 1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "mt-3", 3, "title"],
                    [3, "message"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "visibleChange", "visible", "indicatorSrc", "position", "showPane"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mt-4"],
                    [1, "row"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "d-flex", "align-items-center", "gap-2", 3, "formGroup"],
                    ["cancelBtnId", "module-settings-cancel", "saveBtnId", "module-settings-save", 3, "isVisibleHr"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit"],
                    ["cancelBtnId", "module-settings-cancel", "saveBtnId", "module-settings-save", 3, "cancelClick", "isVisibleHr"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit", 3, "editClick", 4, "ngxPermissionsOnly"],
                    ["backBtnId", "settings-back", "editBtnId", "settings-edit", 3, "editClick"],
                    ["class", "col-sm-3 col-md-3 col-lg-3 d-flex align-items-center gap-2", 3, "formGroup", 4, "ngFor", "ngForOf"],
                    ["name", "is_active", 1, "d-flex", "align-items-center", "gap-2", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_active", 1, "align-middle", 3, "value"],
                    [1, "ms-2"],
                    [1, "ms-1", "mb-1", "mt-4", 3, "needTranslation", "title", "target", "tooltipText"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1), p(2, "app-section-title", 2)(3, "app-alert-panel", 3), d(4, Ol, 1, 2, "app-skeleton-loader", 4), d(5, ql, 5, 3, "form", 5), i()(), n(6, "dx-load-panel", 6), X("visibleChange", function(w) {
                        return $(a.isLoading, w) || (a.isLoading = w), w
                    }), i()), o & 2 && (r(2), l("title", "activate_module_heading"), r(), l("message", a.formatMessage("module_settings_description")), r(), u(a.form ? -1 : 4), r(), u(a.form ? 5 : -1), r(), Z("visible", a.isLoading), l("indicatorSrc", a.loaderLogo)("position", Le(8, Dl))("showPane", !1))
                },
                dependencies: [Ut, j, O, qe, it, ii, pe, F, Bi, Be, V, L, P, A, D, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var at = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            provider: [c.provider || null, k.required],
            driver: [c.driver || null, k.required],
            port: [c.port || null, k.required],
            host: [c.host || null, k.required],
            username: [c.username || null, k.required],
            encryption: [c.encryption || null, k.required],
            from_address: [c.from_address || null, k.required],
            from_name: [c.from_name || null],
            password: [c.password || null, k.required]
        })
    }
};
var Hl = (t, c) => ({
    icon: t,
    type: "default",
    stylingMode: "text",
    onClick: c
});

function jl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 28), _("onClickEvent", function() {
            g(e);
            let a = m(3);
            return C(a.setEditMode())
        }), i()
    }
}

function zl(t, c) {
    if (t & 1 && T(0, jl, 1, 0, "app-dx-outline-button", 27), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function Ql(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 29), _("onClickEvent", function() {
            g(e);
            let a = m(2);
            return C(a.isVisibleDeleteConfirmation = !0)
        }), i(), n(1, "app-dx-outline-button", 30), _("onClickEvent", function() {
            g(e);
            let a = m(2);
            return C(a.isVisibleTestEmailSettingPopup = !0)
        }), i()
    }
}

function Yl(t, c) {
    if (t & 1 && (n(0, "div", 7), d(1, zl, 1, 1, "app-dx-outline-button", 26), d(2, Ql, 2, 0), i()), t & 2) {
        let e = m();
        r(), u(e.userPermissionList.includes(e.PERMISSION_LIST.BUSINESS_SETTING_WRITE) ? 1 : -1), r(), u(e.emailSettings != null && e.emailSettings.id ? 2 : -1)
    }
}

function Kl(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 9), t & 2 && l("rows", 6)("columns", 2)
}

function Zl(t, c) {
    if (t & 1 && (n(0, "div", 56), p(1, "input", 66), n(2, "label", 67), s(3), i()()), t & 2) {
        let e = c.$implicit,
            o = m(2);
        r(), l("id", "encryption-" + e)("value", e), Ft("disabled", o.isEditMode ? null : !0), r(), l("for", "encryption-" + e), r(), E(" ", e, " ")
    }
}

function $l(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 68), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.cancel())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function Xl(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 31), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), n(1, "div", 32)(2, "div", 33)(3, "div", 34), s(4, " 1 "), i(), n(5, "div")(6, "div", 35), s(7, "Sender Details"), i(), n(8, "div", 36), s(9, "Configure the email sender information"), i()()(), n(10, "div", 37)(11, "div", 38)(12, "div", 39)(13, "label", 40), p(14, "i", 41), s(15), i(), n(16, "dx-select-box", 42), _("onValueChanged", function(a) {
            g(e);
            let h = m();
            return C(h.setProvider(a))
        }), i()(), n(17, "div", 43)(18, "label", 40), p(19, "i", 44), s(20), i(), p(21, "dx-text-box", 45), n(22, "div", 46), s(23, "Name displayed in recipient's inbox"), i()(), n(24, "div", 43)(25, "label", 40), p(26, "i", 47), s(27), i(), p(28, "dx-text-box", 48), i()()()(), n(29, "div", 32)(30, "div", 33)(31, "div", 34), s(32, " 2 "), i(), n(33, "div")(34, "div", 35), s(35, "SMTP Configuration"), i(), n(36, "div", 36), s(37, "Server settings for sending emails"), i()()(), n(38, "div", 37)(39, "div", 38)(40, "div", 43)(41, "label", 40), p(42, "i", 49), s(43), p(44, "app-tooltip", 50), i(), p(45, "dx-text-box", 51), i(), n(46, "div", 43)(47, "label", 40), p(48, "i", 52), s(49), p(50, "app-tooltip", 50), i(), p(51, "dx-text-box", 53), i(), n(52, "div", 39)(53, "label", 40), p(54, "i", 54), s(55), i(), n(56, "div", 55), U(57, Zl, 4, 5, "div", 56, Ee), i()(), n(59, "div", 39)(60, "div", 57)(61, "div", 18), p(62, "i", 58), n(63, "div", 20), s(64, "Host, Port and Encryption are auto-filled based on selected provider."), i()()()()()()(), n(65, "div", 32)(66, "div", 33)(67, "div", 34), s(68, " 3 "), i(), n(69, "div")(70, "div", 35), s(71, "Security & Authentication"), i(), n(72, "div", 36), s(73, "Credentials for email authentication"), i()()(), n(74, "div", 37)(75, "div", 38)(76, "div", 43)(77, "label", 40), p(78, "i", 44), s(79), i(), p(80, "dx-text-box", 59), n(81, "div", 46), s(82, "Usually the same as your email address"), i()(), n(83, "div", 43)(84, "label", 40), p(85, "i", 60), s(86), p(87, "app-tooltip", 50), i(), n(88, "dx-text-box", 61), p(89, "dxi-button", 62), i()(), n(90, "div", 39)(91, "div", 63)(92, "div", 18), p(93, "i", 64), n(94, "div", 20), s(95, "Use an App Password, not your regular account password. Generate one from your email provider's security settings."), i()()()()()()(), d(96, $l, 1, 1, "app-save-cancel-footer", 65), i()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(15), E(" ", e.formatMessage("email_provider"), " "), r(), l("items", e.emailTypes)("placeholder", e.formatMessage("select_email_provider"))("disabled", !e.isEditMode), r(4), E(" ", e.formatMessage("from_name"), " "), r(), l("placeholder", e.formatMessage("from_name_placeholder"))("disabled", !e.isEditMode), r(6), E(" ", e.formatMessage("from_address"), " "), r(), l("placeholder", e.formatMessage("from_address_placeholder"))("disabled", !e.isEditMode), r(15), E(" ", e.formatMessage("email_host"), " "), r(), l("tooltipText", "smtp_host_tooltip"), r(), l("placeholder", e.formatMessage("email_host_placeholder"))("disabled", !e.isEditMode), r(4), E(" ", e.formatMessage("email_port"), " "), r(), l("tooltipText", "smtp_port_tooltip"), r(), l("placeholder", e.formatMessage("email_port_placeholder"))("disabled", !e.isEditMode), r(4), E(" ", e.formatMessage("encryption_type"), " "), r(2), W(e.smtpEncryption), r(22), E(" ", e.formatMessage("email_username"), " "), r(), l("placeholder", e.formatMessage("email_username_placeholder"))("disabled", !e.isEditMode), r(6), E(" ", e.formatMessage("app_password"), " "), r(), l("tooltipText", "app_password_tooltip"), r(), l("placeholder", e.formatMessage("app_password_placeholder"))("mode", e.showPassword ? "text" : "password")("disabled", !e.isEditMode), r(), l("options", Mi(30, Hl, e.showPassword ? "fa-thin fa-eye-slash" : "fa-thin fa-eye", e.togglePasswordVisibility.bind(e))), r(7), u(e.isEditMode ? 96 : -1)
    }
}

function Jl(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Gmail uses Google's SMTP servers. You must enable 2-Step Verification and generate an App Password to connect."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Enable 2-Step Verification"), i(), s(9, " \u2014 Go to your "), n(10, "a", 73), s(11, "Google Account Security"), i(), s(12, " page and turn on 2-Step Verification."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Generate App Password"), i(), s(19, " \u2014 Visit "), n(20, "a", 74), s(21, "App Passwords"), i(), s(22, ', select "Other", enter a name (e.g., "BytePhase"), and click Generate. Copy the 16-character password.'), i()(), n(23, "div", 18)(24, "div", 72), s(25, "3"), i(), n(26, "div", 20)(27, "strong"), s(28, "Fill in the form"), i(), s(29, " \u2014 Enter your Gmail address as both "), n(30, "em"), s(31, "From Address"), i(), s(32, " and "), n(33, "em"), s(34, "Username"), i(), s(35, ". Paste the App Password in the password field."), i()(), n(36, "div", 18)(37, "div", 72), s(38, "4"), i(), n(39, "div", 20)(40, "strong"), s(41, "Save & Test"), i(), s(42, ' \u2014 Save your settings and click "Test Email Settings" to verify everything works.'), i()(), n(43, "a", 75), p(44, "i", 76), s(45, " Google App Passwords Help "), i(), n(46, "div", 77)(47, "div", 18), p(48, "i", 64), n(49, "div", 20), s(50, "Google Workspace accounts may require admin approval for App Passwords. Contact your Workspace admin if the option is not visible."), i()()()())
}

function ec(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Yahoo Mail requires you to generate an App Password to allow third-party apps to send emails through your account."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Enable 2-Step Verification"), i(), s(9, " \u2014 Go to "), n(10, "a", 78), s(11, "Yahoo Account Security"), i(), s(12, " and enable two-step verification."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Generate App Password"), i(), s(19, ' \u2014 On the same security page, click "Generate app password", select "Other App", name it, and copy the generated password.'), i()(), n(20, "div", 18)(21, "div", 72), s(22, "3"), i(), n(23, "div", 20)(24, "strong"), s(25, "Fill in the form"), i(), s(26, " \u2014 Use your Yahoo email as "), n(27, "em"), s(28, "From Address"), i(), s(29, " and "), n(30, "em"), s(31, "Username"), i(), s(32, ". Paste the App Password in the password field."), i()(), n(33, "div", 18)(34, "div", 72), s(35, "4"), i(), n(36, "div", 20)(37, "strong"), s(38, "Save & Test"), i(), s(39, " \u2014 Save your settings and send a test email to confirm delivery."), i()(), n(40, "a", 79), p(41, "i", 76), s(42, " Yahoo App Passwords Help "), i()())
}

function tc(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "GoDaddy provides professional email hosting with SMTP access. Use your GoDaddy email credentials to connect."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Log in to GoDaddy"), i(), s(9, " \u2014 Go to your "), n(10, "a", 80), s(11, "GoDaddy Account"), i(), s(12, " and navigate to your Email & Office dashboard."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Confirm SMTP relay"), i(), s(19, " \u2014 GoDaddy uses "), n(20, "strong"), s(21, "smtpout.secureserver.net"), i(), s(22, " as the SMTP server. Ensure your email account is active and has SMTP access enabled."), i()(), n(23, "div", 18)(24, "div", 72), s(25, "3"), i(), n(26, "div", 20)(27, "strong"), s(28, "Fill in the form"), i(), s(29, " \u2014 Use your GoDaddy email address as "), n(30, "em"), s(31, "From Address"), i(), s(32, " and "), n(33, "em"), s(34, "Username"), i(), s(35, ". Use your GoDaddy email password in the password field."), i()(), n(36, "div", 18)(37, "div", 72), s(38, "4"), i(), n(39, "div", 20)(40, "strong"), s(41, "Save & Test"), i(), s(42, " \u2014 Save your settings and send a test email to verify."), i()(), n(43, "a", 81), p(44, "i", 76), s(45, " GoDaddy SMTP Setup Help "), i(), n(46, "div", 82)(47, "div", 18), p(48, "i", 58), n(49, "div", 20), s(50, "GoDaddy may have daily sending limits depending on your plan. Check your email plan details for limits."), i()()()())
}

function ic(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Microsoft 365, Outlook.com, Live.com, and Hotmail accounts all use Microsoft's SMTP servers. An App Password is required if 2-step verification is enabled."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Enable 2-Step Verification"), i(), s(9, " \u2014 Go to "), n(10, "a", 83), s(11, "Microsoft Account Security"), i(), s(12, " and enable two-step verification."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Generate App Password"), i(), s(19, ' \u2014 On the security page, go to "App passwords" section, click "Create a new app password", and copy the generated password.'), i()(), n(20, "div", 18)(21, "div", 72), s(22, "3"), i(), n(23, "div", 20)(24, "strong"), s(25, "Fill in the form"), i(), s(26, " \u2014 Use your Microsoft email as "), n(27, "em"), s(28, "From Address"), i(), s(29, " and "), n(30, "em"), s(31, "Username"), i(), s(32, ". Paste the App Password in the password field."), i()(), n(33, "div", 18)(34, "div", 72), s(35, "4"), i(), n(36, "div", 20)(37, "strong"), s(38, "Save & Test"), i(), s(39, " \u2014 Save and send a test email to confirm."), i()(), n(40, "a", 84), p(41, "i", 76), s(42, " Microsoft App Passwords Help "), i(), n(43, "div", 77)(44, "div", 18), p(45, "i", 64), n(46, "div", 20), s(47, "For Office 365 business accounts, your admin may need to enable SMTP AUTH for your mailbox in the Microsoft 365 admin center."), i()()()())
}

function nc(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Outlook.com and MSN email accounts use Microsoft's personal SMTP server. You need an App Password to connect securely."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Enable 2-Step Verification"), i(), s(9, " \u2014 Go to "), n(10, "a", 83), s(11, "Microsoft Account Security"), i(), s(12, " and turn on two-step verification."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Generate App Password"), i(), s(19, ' \u2014 Under "App passwords", create a new app password and copy it.'), i()(), n(20, "div", 18)(21, "div", 72), s(22, "3"), i(), n(23, "div", 20)(24, "strong"), s(25, "Fill in the form"), i(), s(26, " \u2014 Use your Outlook/MSN email as "), n(27, "em"), s(28, "From Address"), i(), s(29, " and "), n(30, "em"), s(31, "Username"), i(), s(32, ". Paste the App Password in the password field."), i()(), n(33, "div", 18)(34, "div", 72), s(35, "4"), i(), n(36, "div", 20)(37, "strong"), s(38, "Save & Test"), i(), s(39, " \u2014 Save and send a test email."), i()(), n(40, "a", 84), p(41, "i", 76), s(42, " Microsoft App Passwords Help "), i()())
}

function oc(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Zoho Mail provides business email with SMTP access. You need to generate an Application-Specific Password from Zoho's security settings."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Enable Two-Factor Authentication"), i(), s(9, " \u2014 Go to "), n(10, "a", 85), s(11, "Zoho Account Security"), i(), s(12, " and enable TFA (Two-Factor Authentication)."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Generate App Password"), i(), s(19, ' \u2014 In your Zoho account, go to Security \u2192 Application-Specific Passwords, click "Generate New Password", give it a name, and copy the password.'), i()(), n(20, "div", 18)(21, "div", 72), s(22, "3"), i(), n(23, "div", 20)(24, "strong"), s(25, "Fill in the form"), i(), s(26, " \u2014 Use your Zoho email as "), n(27, "em"), s(28, "From Address"), i(), s(29, " and "), n(30, "em"), s(31, "Username"), i(), s(32, ". Paste the App Password in the password field."), i()(), n(33, "div", 18)(34, "div", 72), s(35, "4"), i(), n(36, "div", 20)(37, "strong"), s(38, "Save & Test"), i(), s(39, " \u2014 Save and send a test email to verify."), i()(), n(40, "a", 86), p(41, "i", 76), s(42, " Zoho App-Specific Passwords Help "), i(), n(43, "div", 82)(44, "div", 18), p(45, "i", 58), n(46, "div", 20), s(47, "If you use a Zoho custom domain (e.g., you@yourcompany.com), make sure SMTP access is enabled in your Zoho Mail admin panel."), i()()()())
}

function ac(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Hostinger provides email hosting with your domain. Use the email credentials from your Hostinger control panel to connect via SMTP."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Log in to Hostinger"), i(), s(9, " \u2014 Go to your "), n(10, "a", 87), s(11, "Hostinger hPanel"), i(), s(12, " and navigate to Emails section for your domain."), i()(), n(13, "div", 18)(14, "div", 72), s(15, "2"), i(), n(16, "div", 20)(17, "strong"), s(18, "Find SMTP details"), i(), s(19, ' \u2014 In the email account settings, look for "Configuration Settings" or "SMTP Settings". The SMTP host is '), n(20, "strong"), s(21, "smtp.hostinger.com"), i(), s(22, "."), i()(), n(23, "div", 18)(24, "div", 72), s(25, "3"), i(), n(26, "div", 20)(27, "strong"), s(28, "Fill in the form"), i(), s(29, " \u2014 Use your Hostinger email as "), n(30, "em"), s(31, "From Address"), i(), s(32, " and "), n(33, "em"), s(34, "Username"), i(), s(35, ". Use the email account password you set during email creation."), i()(), n(36, "div", 18)(37, "div", 72), s(38, "4"), i(), n(39, "div", 20)(40, "strong"), s(41, "Save & Test"), i(), s(42, " \u2014 Save and send a test email to confirm delivery."), i()(), n(43, "a", 88), p(44, "i", 76), s(45, " Hostinger Email Setup Help "), i(), n(46, "div", 82)(47, "div", 18), p(48, "i", 58), n(49, "div", 20), s(50, "Hostinger does not require an App Password. Use the regular password you created for the email account in hPanel."), i()()()())
}

function rc(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Apple iCloud Mail uses Apple's SMTP servers. You must enable Two-Factor Authentication and generate an App-Specific Password."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Enable Two-Factor Authentication"), i(), s(9, " \u2014 On your Apple device, go to Settings \u2192 [Your Name] \u2192 Password & Security \u2192 Turn on Two-Factor Authentication."), i()(), n(10, "div", 18)(11, "div", 72), s(12, "2"), i(), n(13, "div", 20)(14, "strong"), s(15, "Generate App-Specific Password"), i(), s(16, " \u2014 Visit "), n(17, "a", 89), s(18, "Apple ID Account"), i(), s(19, ', go to "App-Specific Passwords" under the Sign-In and Security section, and generate a new password.'), i()(), n(20, "div", 18)(21, "div", 72), s(22, "3"), i(), n(23, "div", 20)(24, "strong"), s(25, "Fill in the form"), i(), s(26, " \u2014 Use your iCloud email (@icloud.com or @me.com) as "), n(27, "em"), s(28, "From Address"), i(), s(29, " and "), n(30, "em"), s(31, "Username"), i(), s(32, ". Paste the App-Specific Password in the password field."), i()(), n(33, "div", 18)(34, "div", 72), s(35, "4"), i(), n(36, "div", 20)(37, "strong"), s(38, "Save & Test"), i(), s(39, " \u2014 Save and send a test email."), i()(), n(40, "a", 90), p(41, "i", 76), s(42, " Apple App-Specific Passwords Help "), i()())
}

function sc(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Webmail / cPanel email is provided by your web hosting company (e.g., Bluehost, SiteGround, Namecheap, A2 Hosting). The SMTP host varies depending on your hosting provider."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Log in to cPanel"), i(), s(9, " \u2014 Access your hosting control panel (usually at yourdomain.com/cpanel or via your hosting provider's dashboard)."), i()(), n(10, "div", 18)(11, "div", 72), s(12, "2"), i(), n(13, "div", 20)(14, "strong"), s(15, "Find SMTP settings"), i(), s(16, ' \u2014 Go to Email Accounts \u2192 click "Connect Devices" or "Set Up Mail Client" next to your email account. Note down the SMTP server (usually '), n(17, "strong"), s(18, "mail.yourdomain.com"), i(), s(19, " or your server's hostname)."), i()(), n(20, "div", 18)(21, "div", 72), s(22, "3"), i(), n(23, "div", 20)(24, "strong"), s(25, "Fill in the form"), i(), s(26, " \u2014 Enter the SMTP host from step 2 in the "), n(27, "em"), s(28, "Email Host"), i(), s(29, " field. Use your full email address as "), n(30, "em"), s(31, "From Address"), i(), s(32, " and "), n(33, "em"), s(34, "Username"), i(), s(35, ". Use your email account password."), i()(), n(36, "div", 18)(37, "div", 72), s(38, "4"), i(), n(39, "div", 20)(40, "strong"), s(41, "Save & Test"), i(), s(42, " \u2014 Save and send a test email to verify."), i()(), n(43, "div", 77)(44, "div", 18), p(45, "i", 64), n(46, "div", 20), s(47, "The Email Host is "), n(48, "strong"), s(49, "not"), i(), s(50, ' auto-filled for Webmail. You must manually enter the SMTP server from your hosting provider. Check your cPanel "Connect Devices" page for the correct value.'), i()()()())
}

function lc(t, c) {
    t & 1 && (n(0, "div", 70)(1, "div", 36), s(2, "Use this option for any email provider not listed above. You will need to manually enter all SMTP details from your email provider's documentation."), i(), n(3, "div", 18)(4, "div", 72), s(5, "1"), i(), n(6, "div", 20)(7, "strong"), s(8, "Find your SMTP settings"), i(), s(9, ` \u2014 Check your email provider's help docs or support page for SMTP server, port, and encryption details. Search for "[your provider] SMTP settings".`), i()(), n(10, "div", 18)(11, "div", 72), s(12, "2"), i(), n(13, "div", 20)(14, "strong"), s(15, "Generate App Password (if required)"), i(), s(16, " \u2014 Most providers with 2-factor authentication require an App Password. Check your provider's security settings."), i()(), n(17, "div", 18)(18, "div", 72), s(19, "3"), i(), n(20, "div", 20)(21, "strong"), s(22, "Fill in all fields manually"), i(), s(23, " \u2014 Enter the "), n(24, "em"), s(25, "Email Host"), i(), s(26, ", "), n(27, "em"), s(28, "Port"), i(), s(29, ", "), n(30, "em"), s(31, "Encryption"), i(), s(32, ", "), n(33, "em"), s(34, "Username"), i(), s(35, ", and "), n(36, "em"), s(37, "Password"), i(), s(38, " from your provider's documentation."), i()(), n(39, "div", 18)(40, "div", 72), s(41, "4"), i(), n(42, "div", 20)(43, "strong"), s(44, "Save & Test"), i(), s(45, " \u2014 Save and send a test email. If it fails, double-check all values against your provider's documentation."), i()(), n(46, "div", 77)(47, "div", 18), p(48, "i", 64), n(49, "div", 20), s(50, "All fields must be filled manually for custom providers. No values are auto-filled. Common ports: "), n(51, "strong"), s(52, "587"), i(), s(53, " (TLS), "), n(54, "strong"), s(55, "465"), i(), s(56, " (SSL)."), i()()()())
}

function cc(t, c) {
    if (t & 1 && (n(0, "div", 71)(1, "div", 91), p(2, "i", 92), s(3), i(), n(4, "div", 17)(5, "div", 93)(6, "span", 94), s(7), i(), n(8, "span", 95), s(9), i()(), n(10, "div", 93)(11, "span", 94), s(12), i(), n(13, "span", 95), s(14), i()(), n(15, "div", 93)(16, "span", 94), s(17), i(), n(18, "span", 95), s(19), i()(), n(20, "div", 93)(21, "span", 94), s(22), i(), n(23, "span", 96), s(24), i()()()()), t & 2) {
        let e = m(2);
        r(3), E(" ", e.formatMessage("current_settings"), " "), r(4), x(e.formatMessage("email_provider")), r(2), x(e.emailSettings == null ? null : e.emailSettings.provider), r(3), x(e.formatMessage("email_host")), r(2), x(e.emailSettings == null ? null : e.emailSettings.host), r(3), x(e.formatMessage("email_port")), r(2), x(e.emailSettings == null ? null : e.emailSettings.port), r(3), x(e.formatMessage("encryption_type")), r(2), x(e.emailSettings == null ? null : e.emailSettings.encryption)
    }
}

function mc(t, c) {
    if (t & 1 && (n(0, "div", 12)(1, "div", 13)(2, "div", 14), p(3, "i", 69), s(4), i(), d(5, Jl, 51, 0, "div", 70)(6, ec, 43, 0, "div", 70)(7, tc, 51, 0, "div", 70)(8, ic, 48, 0, "div", 70)(9, nc, 43, 0, "div", 70)(10, oc, 48, 0, "div", 70)(11, ac, 51, 0, "div", 70)(12, rc, 43, 0, "div", 70)(13, sc, 51, 0, "div", 70)(14, lc, 57, 0, "div", 70), d(15, cc, 25, 9, "div", 71), i()()), t & 2) {
        let e, o = m();
        r(4), dt(" ", o.formatMessage("setup_guide"), " \u2014 ", o.form.get("provider").value, " "), r(), u(o.form.get("provider").value === "Google" ? 5 : o.form.get("provider").value === "Yahoo" ? 6 : o.form.get("provider").value === "Godaddy" ? 7 : (e = o.form.get("provider").value) != null && e.includes("Office365") || (e = o.form.get("provider").value) != null && e.includes("Outlook") || (e = o.form.get("provider").value) != null && e.includes("Hotmail") ? 8 : (e = o.form.get("provider").value) != null && e.includes("MSN") ? 9 : o.form.get("provider").value === "Zoho Mail" ? 10 : o.form.get("provider").value === "Hostinger" ? 11 : o.form.get("provider").value === "iCloud" ? 12 : (e = o.form.get("provider").value) != null && e.includes("Webmail") || (e = o.form.get("provider").value) != null && e.includes("cPanel") ? 13 : o.form.get("provider").value === "Other" ? 14 : -1), r(10), u(o.emailSettings != null && o.emailSettings.id ? 15 : -1)
    }
}

function pc(t, c) {
    t & 1 && (n(0, "div", 12)(1, "div", 97), p(2, "i", 98), n(3, "div", 36), s(4, "Select an "), n(5, "strong"), s(6, "Email Provider"), i(), s(7, " from the dropdown on the left to see the step-by-step setup guide with instructions specific to your provider."), i()()())
}

function dc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 99), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.testEmailSettings())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.isVisibleTestEmailSettingPopup = !1)
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("confirmButtonText", "send_test_email")("confirmationMessage", e.formatMessage("sending_test_email_to") + " " + e.testEmail)("isSaving", e.isTestingEmailSettings)
    }
}

function uc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 99), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.delete())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.isVisibleDeleteConfirmation = !1)
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("confirmButtonText", "delete")("confirmationMessage", e.formatMessage("confirm_delete_custom_email_settings"))("isSaving", e.isSaving)
    }
}
var _c = [{
        provider: "Google",
        driver: "smtp",
        host: "smtp.gmail.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Yahoo",
        driver: "smtp",
        host: "smtp.mail.yahoo.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Godaddy",
        driver: "smtp",
        host: "smtpout.secureserver.net",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Office365 / Live.com / Outlook / Hotmail",
        driver: "smtp",
        host: "smtp.office365.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Outlook Online / MSN",
        driver: "smtp",
        host: "smtp-mail.outlook.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Zoho Mail",
        driver: "smtp",
        host: "smtp.zoho.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Hostinger",
        driver: "smtp",
        host: "smtp.hostinger.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "iCloud",
        driver: "smtp",
        host: "smtp.mail.me.com",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Webmail (cPanel / Hosting Email)",
        driver: "smtp",
        host: "",
        port: 587,
        encryption: "tls",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }, {
        provider: "Other",
        driver: "smtp",
        host: "",
        port: null,
        encryption: "",
        from_name: "",
        from_address: "",
        username: "",
        password: ""
    }],
    Da = (() => {
        class t {
            constructor(e) {
                this.service = e, this.formatMessage = f, this.formService = v(B), this.authService = v(fo), this.userSessionService = v(tt), this.toastNotificationService = v(N), this.userPermissionList = this.userSessionService.userPermissionList(), this.isEditMode = !1, this.isTestingEmailSettings = !1, this.isVisibleDeleteConfirmation = !1, this.isSaving = !1, this.showPassword = !1, this.emailTypes = ["Google", "Yahoo", "Godaddy", "Office365 / Live.com / Outlook / Hotmail", "Outlook Online / MSN", "Zoho Mail", "Hostinger", "iCloud", "Webmail (cPanel / Hosting Email)", "Other"], this.smtpEncryption = ["ssl", "tls"], this.emailSettings = null, this.isVisibleTestEmailSettingPopup = !1, this.testEmail = null, this.PERMISSION_LIST = b, this.authService.currentUser.pipe(Qt()).subscribe({
                    next: o => {
                        this.testEmail = o.email
                    },
                    error: o => {
                        console.error(o)
                    }
                })
            }
            ngOnInit() {
                this.form = at.getForm(new at({})), this.form.disable(), this.service.getEmailSettings().subscribe({
                    next: e => {
                        this.emailSettings = e, e && this.form.patchValue(new at(e))
                    },
                    error: e => {
                        console.error(e)
                    }
                })
            }
            setProvider(e) {
                this.form.patchValue(new at(_c.find(o => o.provider === e.value)))
            }
            save() {
                this.form.valid ? (this.isSaving = !0, this.service.setEmailSettings(this.form.value).subscribe({
                    next: e => {
                        this.toastNotificationService.success("notification_account_email_settings_update_success"), this.isEditMode = !1, this.form.disable(), this.emailSettings = new at(e)
                    },
                    error: () => {
                        this.toastNotificationService.error("notification_account_email_settings_save_error")
                    }
                }).add(() => {
                    this.isSaving = !1
                })) : this.formService.validateFormFields(this.form)
            }
            setEditMode() {
                this.isEditMode = !0, this.form.enable()
            }
            cancel() {
                this.isEditMode = !1, this.form.patchValue(this.emailSettings), this.form.disable()
            }
            togglePasswordVisibility() {
                this.showPassword = !this.showPassword
            }
            testEmailSettings() {
                this.isTestingEmailSettings = !0, this.service.testEmailSettings().subscribe({
                    next: () => {
                        this.toastNotificationService.success("notification_email_settings_verify_success")
                    },
                    error: () => {
                        this.toastNotificationService.error("notification_email_config_send_error")
                    }
                }).add(() => {
                    this.isVisibleTestEmailSettingPopup = !1, this.isTestingEmailSettings = !1
                })
            }
            delete() {
                this.isSaving = !0, this.service.deleteEmailSetting().subscribe({
                    next: () => {
                        this.toastNotificationService.success("notification_email_settings_delete_success"), this.emailSettings = {}, this.form = at.getForm(new at({})), this.form.disable()
                    },
                    error: () => {
                        this.toastNotificationService.error("notification_email_settings_delete_error")
                    }
                }).add(() => {
                    this.isVisibleDeleteConfirmation = !1, this.isSaving = !1
                })
            }
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)(I(be))
                }
            }
            static {
                this.\u0275cmp = y({
                    type: t,
                    selectors: [
                        ["app-account-email-settings"]
                    ],
                    standalone: !1,
                    decls: 73,
                    vars: 7,
                    consts: [
                        [1, "container-fluid", "px-0"],
                        [1, "row", "g-4"],
                        [1, "col-12", "col-lg-8"],
                        [1, "card", "border", "rounded-3"],
                        [1, "card-header", "border-bottom", "p-3"],
                        [1, "d-flex", "flex-column", "flex-md-row", "justify-content-between", "align-items-start", "align-items-md-center", "gap-2"],
                        [1, "h5", "mb-0"],
                        [1, "d-flex", "flex-wrap", "gap-2", "mobile-action-buttons"],
                        [1, "card-body", "p-4"],
                        ["type", "form", 3, "rows", "columns"],
                        ["autocomplete", "off", 3, "formGroup"],
                        [1, "col-12", "col-lg-4"],
                        [1, "card", "border", "rounded-3", "mb-4"],
                        [1, "card-body", "p-3"],
                        [1, "fw-semibold", "mb-3", "d-flex", "align-items-center", "gap-2"],
                        [1, "fa-thin", "fa-circle-question", "text-primary"],
                        [1, "small", "text-muted", "mb-3"],
                        [1, "d-flex", "flex-column", "gap-2"],
                        [1, "d-flex", "align-items-start", "gap-2"],
                        [1, "fa-thin", "fa-server", "text-primary", "mt-1", 2, "min-width", "16px"],
                        [1, "small"],
                        [1, "fa-thin", "fa-hashtag", "text-primary", "mt-1", 2, "min-width", "16px"],
                        [1, "fa-thin", "fa-shield-halved", "text-primary", "mt-1", 2, "min-width", "16px"],
                        [1, "fa-thin", "fa-user", "text-primary", "mt-1", 2, "min-width", "16px"],
                        [1, "fa-thin", "fa-lock", "text-primary", "mt-1", 2, "min-width", "16px"],
                        [3, "confirmButtonText", "confirmationMessage", "isSaving"],
                        ["buttonType", "default", "text", "common_edit"],
                        ["buttonType", "default", "text", "common_edit", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                        ["buttonType", "default", "text", "common_edit", 3, "onClickEvent"],
                        ["buttonType", "danger", "text", "delete", 3, "onClickEvent"],
                        ["buttonType", "default", "text", "test_email_settings", 3, "onClickEvent"],
                        ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                        [1, "mb-4"],
                        [1, "d-flex", "align-items-center", "gap-3", "mb-3"],
                        [1, "rounded-circle", "bg-primary", "bg-opacity-10", "d-flex", "align-items-center", "justify-content-center", "text-primary", "fw-semibold", 2, "width", "32px", "height", "32px", "min-width", "32px"],
                        [1, "fw-semibold"],
                        [1, "small", "text-muted"],
                        [1, "ms-0", "ms-md-5", "p-3", "rounded-3", "border", "bg-opacity-10"],
                        [1, "row", "g-3"],
                        [1, "col-12"],
                        [1, "form-label", "small", "fw-medium", "d-flex", "align-items-center", "gap-2"],
                        [1, "fa-thin", "fa-envelope"],
                        ["formControlName", "provider", "id", "account-email-setting-email-provider", 3, "onValueChanged", "items", "placeholder", "disabled"],
                        [1, "col-12", "col-md-6"],
                        [1, "fa-thin", "fa-user"],
                        ["formControlName", "from_name", "id", "account-email-setting-form-name", 3, "placeholder", "disabled"],
                        [1, "small", "text-muted", "mt-1"],
                        [1, "fa-thin", "fa-at"],
                        ["formControlName", "from_address", "id", "account-email-setting-form-address", 3, "placeholder", "disabled"],
                        [1, "fa-thin", "fa-server"],
                        [3, "tooltipText"],
                        ["formControlName", "host", "id", "account-email-setting-email-host", 3, "placeholder", "disabled"],
                        [1, "fa-thin", "fa-hashtag"],
                        ["formControlName", "port", "id", "account-email-setting-email-port", 3, "placeholder", "disabled"],
                        [1, "fa-thin", "fa-shield-halved"],
                        [1, "d-flex", "gap-3"],
                        [1, "form-check"],
                        [1, "p-3", "rounded-3", "border", "border-primary", "border-opacity-25", "bg-primary", "bg-opacity-10"],
                        [1, "fa-thin", "fa-circle-info", "text-primary", "mt-1"],
                        ["formControlName", "username", "id", "account-email-setting-username", 3, "placeholder", "disabled"],
                        [1, "fa-thin", "fa-lock"],
                        ["formControlName", "password", "id", "account-email-setting-password", 3, "placeholder", "mode", "disabled"],
                        ["name", "password-toggle", "location", "after", 3, "options"],
                        [1, "p-3", "rounded-3", "border", "border-warning", "border-opacity-25", "bg-warning", "bg-opacity-10"],
                        [1, "fa-thin", "fa-triangle-exclamation", "text-warning", "mt-1"],
                        ["cancelBtnId", "account-email-setting-cancel", "saveBtnId", "account-email-setting-save", "saveText", "common_save", 3, "isVisibleHr"],
                        ["type", "radio", "formControlName", "encryption", 1, "form-check-input", 3, "id", "value"],
                        [1, "form-check-label", "text-uppercase", "small", "fw-medium", 3, "for"],
                        ["cancelBtnId", "account-email-setting-cancel", "saveBtnId", "account-email-setting-save", "saveText", "common_save", 3, "cancelClick", "isVisibleHr"],
                        [1, "fa-thin", "fa-book-open", "text-primary"],
                        [1, "d-flex", "flex-column", "gap-3"],
                        [1, "mt-3", "p-3", "rounded-3", "border", "border-success", "border-opacity-25", "bg-success", "bg-opacity-10"],
                        [1, "rounded-circle", "bg-primary", "bg-opacity-10", "d-flex", "align-items-center", "justify-content-center", "text-primary", "small", "fw-semibold", 2, "width", "24px", "height", "24px", "min-width", "24px"],
                        ["href", "https://myaccount.google.com/security", "target", "_blank", 1, "text-primary"],
                        ["href", "https://myaccount.google.com/apppasswords", "target", "_blank", 1, "text-primary"],
                        ["href", "https://support.google.com/mail/answer/185833?hl=en-GB", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        [1, "fa-thin", "fa-arrow-up-right-from-square"],
                        [1, "p-2", "rounded-3", "border", "border-warning", "border-opacity-25", "bg-warning", "bg-opacity-10"],
                        ["href", "https://login.yahoo.com/account/security", "target", "_blank", 1, "text-primary"],
                        ["href", "https://help.yahoo.com/kb/generate-manage-third-party-passwords-sln15241.html", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        ["href", "https://sso.godaddy.com", "target", "_blank", 1, "text-primary"],
                        ["href", "https://www.godaddy.com/help/send-form-mail-with-an-smtp-relay-server-953", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        [1, "p-2", "rounded-3", "border", "border-primary", "border-opacity-25", "bg-primary", "bg-opacity-10"],
                        ["href", "https://account.microsoft.com/security", "target", "_blank", 1, "text-primary"],
                        ["href", "https://support.microsoft.com/en-us/account-billing/using-app-passwords-with-apps-that-don-t-support-two-step-verification-5896ed9b-4263-e681-128a-a6f2979a7944", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        ["href", "https://accounts.zoho.com/home#security/security_pwd", "target", "_blank", 1, "text-primary"],
                        ["href", "https://www.zoho.com/mail/help/adminconsole/two-factor-authentication.html#alink5", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        ["href", "https://hpanel.hostinger.com", "target", "_blank", 1, "text-primary"],
                        ["href", "https://support.hostinger.com/en/articles/1583207-how-to-set-up-email-on-third-party-applications", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        ["href", "https://appleid.apple.com/account/manage", "target", "_blank", 1, "text-primary"],
                        ["href", "https://support.apple.com/en-us/HT204397", "target", "_blank", 1, "text-primary", "text-decoration-none", "small", "d-flex", "align-items-center", "gap-1", "mt-1"],
                        [1, "small", "fw-semibold", "mb-2", "d-flex", "align-items-center", "gap-2"],
                        [1, "fa-thin", "fa-circle-check", "text-success"],
                        [1, "d-flex", "justify-content-between", "small"],
                        [1, "text-muted"],
                        [1, "fw-medium"],
                        [1, "fw-medium", "text-uppercase"],
                        [1, "card-body", "p-3", "text-center"],
                        [1, "fa-thin", "fa-hand-pointer", "text-primary", "mb-2", 2, "font-size", "2rem"],
                        [3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage", "isSaving"]
                    ],
                    template: function(o, a) {
                        if (o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6), s(7), i(), d(8, Yl, 3, 2, "div", 7), i()(), n(9, "div", 8), d(10, Kl, 1, 2, "app-skeleton-loader", 9), d(11, Xl, 97, 33, "form", 10), i()()(), n(12, "div", 11)(13, "div", 12)(14, "div", 13)(15, "div", 14), p(16, "i", 15), s(17, " What is SMTP? "), i(), n(18, "div", 16), s(19, " SMTP (Simple Mail Transfer Protocol) is the standard protocol used to send emails from your application. To send emails (invoices, notifications, reports) to your customers, you need to connect your email account via SMTP. "), i(), n(20, "div", 17)(21, "div", 18), p(22, "i", 19), n(23, "div", 20)(24, "strong"), s(25, "Email Host"), i(), s(26, " \u2014 The SMTP server address of your email provider (e.g., smtp.gmail.com). This tells the app which server to use for sending emails."), i()(), n(27, "div", 18), p(28, "i", 21), n(29, "div", 20)(30, "strong"), s(31, "Email Port"), i(), s(32, " \u2014 The port number used by the SMTP server. Common ports: "), n(33, "strong"), s(34, "587"), i(), s(35, " (TLS, recommended), "), n(36, "strong"), s(37, "465"), i(), s(38, " (SSL), "), n(39, "strong"), s(40, "25"), i(), s(41, " (unencrypted, not recommended)."), i()(), n(42, "div", 18), p(43, "i", 22), n(44, "div", 20)(45, "strong"), s(46, "Encryption"), i(), s(47, " \u2014 Secures email data in transit. "), n(48, "strong"), s(49, "TLS"), i(), s(50, " (recommended) encrypts the connection after connecting. "), n(51, "strong"), s(52, "SSL"), i(), s(53, " encrypts from the start."), i()(), n(54, "div", 18), p(55, "i", 23), n(56, "div", 20)(57, "strong"), s(58, "Username"), i(), s(59, " \u2014 Usually your full email address. Used to authenticate with the SMTP server."), i()(), n(60, "div", 18), p(61, "i", 24), n(62, "div", 20)(63, "strong"), s(64, "App Password"), i(), s(65, " \u2014 A special password generated by your email provider for third-party apps. This is "), n(66, "strong"), s(67, "not"), i(), s(68, " your regular login password."), i()()()()(), d(69, mc, 16, 4, "div", 12)(70, pc, 8, 0, "div", 12), i()()(), d(71, dc, 1, 3, "app-confirmation-popup", 25), d(72, uc, 1, 3, "app-confirmation-popup", 25)), o & 2) {
                            let h;
                            r(7), x(a.formatMessage("email_settings")), r(), u(a.isEditMode ? -1 : 8), r(2), u(a.form ? -1 : 10), r(), u(a.form ? 11 : -1), r(58), u(!(a.form == null || (h = a.form.get("provider")) == null) && h.value ? 69 : 70), r(2), u(a.isVisibleTestEmailSettingPopup ? 71 : -1), r(), u(a.isVisibleDeleteConfirmation ? 72 : -1)
                        }
                    },
                    dependencies: [Ye, O, ii, F, we, Co, le, ae, V, On, Fn, L, P, A, D, ne],
                    encapsulation: 2
                })
            }
        }
        return t
    })();
var di = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            id: [c.id || null],
            name: [c.name || null, [k.required]]
        })
    }
};

function gc(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 4), t & 2 && l("rows", 3)("columns", 1)
}

function Cc(t, c) {
    if (t & 1 && p(0, "app-server-error", 10), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function vc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 6), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.saveExpenseCategory())
        }), n(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), p(5, "dxi-validation-rule", 9), i()()()(), d(6, Cc, 1, 1, "app-server-error", 10), n(7, "app-save-cancel-footer", 11), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i()()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("expense_category_required_field"))("label", e.formatMessage("common_category")), r(), l("placeholder", e.formatMessage("category_placeholder")), r(2), l("ignoreEmptyValue", !0)("message", e.formatMessage("category_name_already_exists"))("validationCallback", e.asyncUniqueNameValidation), r(), u(e.errorResponse ? 6 : -1), r(), l("isOnPopup", !0)
    }
}

function hc(t, c) {
    if (t & 1 && (n(0, "div")(1, "div", 2)(2, "div", 3), d(3, gc, 1, 2, "app-skeleton-loader", 4), d(4, vc, 8, 9, "form", 5), i()()()), t & 2) {
        let e = m();
        r(3), u(e.form ? -1 : 3), r(), u(e.form ? 4 : -1)
    }
}
var Oa = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isCreate = !0, this.isVisiblePopup = !1, this.expenseCategorySaveClick = new ue, this.expenseCategoryCancelClick = new ue, this.formService = v(B), this.commonService = v(vt), this.toastNotificationService = v(N), this.entity = Q.EXPENSE_CATEGORY, this.errorResponse = null, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.isVisiblePopup = !0, this.form = di.getForm(new di(this.isCreate ? {} : this.expenseCategory))
        }
        saveExpenseCategory() {
            this.errorResponse = null, this.form.valid ? (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.expenseCategory = new di(o), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "notification_expense_category_add_success" : "notification_expense_category_update_success"), this.expenseCategorySaveClick.emit(this.expenseCategory), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                }
            }) : this.formService.validateFormFields(this.form)
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.entity.table,
                name: e.value,
                entity_id: this.expenseCategory ? .id
            }).pipe(Ot(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        onClosing() {
            this.isVisiblePopup = !1, this.form = null, this.isCreate = !1, this.expenseCategoryCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(ji))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-expense-category"]
                ],
                inputs: {
                    expenseCategory: "expenseCategory",
                    isCreate: "isCreate",
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    expenseCategorySaveClick: "expenseCategorySaveClick",
                    expenseCategoryCancelClick: "expenseCategoryCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHiding", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    [1, "mt-2", 3, "errorResponse"],
                    [3, "cancelClick", "isOnPopup"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHiding", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, hc, 5, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("width", "95vw")("maxWidth", 400)("title", a.expenseCategory != null && a.expenseCategory.id ? a.formatMessage("update_expense_category_title") : a.formatMessage("add_new_expense_category_title")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, F, G, Ct, re, ae, St, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Sc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-expense-category", 3), _("expenseCategoryCancelClick", function() {
            g(e);
            let a = m();
            return C(a.isVisibleExpenseCategoryPopup = !1)
        })("expenseCategorySaveClick", function() {
            g(e);
            let a = m();
            return C(a.onExpenseCategorySave())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("expenseCategory", e.expenseCategory)("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleExpenseCategoryPopup)
    }
}
var Fa = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisibleExpenseCategoryPopup = !1, this.entity = Q.EXPENSE_CATEGORY, this.isCreate = !1, this.columns = [{
                dataField: "name",
                caption: f("common_category"),
                allowSorting: !0
            }, {
                dataField: "updated_at",
                caption: f("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: f("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                cellTemplate: "actionTemplate",
                alignment: "right"
            }], this.PERMISSION_LIST = b
        }
        ngOnInit() {}
        create() {
            this.isCreate = !0, this.isVisibleExpenseCategoryPopup = !0
        }
        onExpenseCategorySave() {
            this.isCreate = !1, this.isVisibleExpenseCategoryPopup = !1, this.expenseCategory = null, this.dataGrid.getData()
        }
        edit(e) {
            this.isCreate = !1, this.expenseCategory = e, this.isVisibleExpenseCategoryPopup = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(ji))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-expense-category-list"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(Re, 5), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.dataGrid = h.first)
                    }
                },
                standalone: !1,
                decls: 3,
                vars: 10,
                consts: [
                    [3, "message"],
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "deleteAccessPermissionName", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service", "searchPanelPlaceholderText", "writeAccessPermissionName"],
                    [3, "expenseCategory", "isCreate", "isVisiblePopup"],
                    [3, "expenseCategoryCancelClick", "expenseCategorySaveClick", "expenseCategory", "isCreate", "isVisiblePopup"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-alert-panel", 0), n(1, "app-data-grid", 1), _("dataGridAddNewClick", function() {
                        return a.create()
                    })("dataGridEditClick", function(w) {
                        return a.edit(w)
                    }), i(), d(2, Sc, 1, 3, "app-expense-category", 2)), o & 2 && (l("message", a.formatMessage("expense_category_settings_note")), r(), l("columns", a.columns)("deleteAccessPermissionName", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE)("entity", a.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", a.service)("searchPanelPlaceholderText", "search_panel_expense_category_placeholder")("writeAccessPermissionName", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE), r(), u(a.isVisibleExpenseCategoryPopup ? 2 : -1))
                },
                dependencies: [Re, pe, Oa],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Tc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 33), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.goToPricing())
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("text", e.formatMessage("renew_now"))
    }
}

function Ec(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 34), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.goToPricing())
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("text", e.formatMessage("upgrade_plan"))
    }
}

function wc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 4), d(1, Tc, 1, 1, "dx-button", 29)(2, Ec, 1, 1, "dx-button", 30), n(3, "dx-button", 31), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.goToPricing())
        }), i(), n(4, "dx-button", 32), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.goToSmsPacks())
        }), i()()
    }
    if (t & 2) {
        let e = m();
        r(), u(e.bannerType() === "warn" || e.bannerType() === "danger" ? 1 : 2)
    }
}

function Ic(t, c) {
    if (t & 1 && (n(0, "div", 19), s(1), i(), n(2, "small"), s(3), q(4, "dateFormat"), i()), t & 2) {
        let e = m();
        r(), et("", e.formatMessage("youre_on_plan"), " ", e.plan, " ", e.formatMessage("plan"), "."), r(2), et("", e.formatMessage("active_subscription"), " \xB7 ", e.formatMessage("account_expired_on"), " ", Y(4, 6, e.tenantConfig.trial_ends_at))
    }
}

function kc(t, c) {
    if (t & 1 && (n(0, "div", 19), s(1), i(), n(2, "small"), s(3), i()), t & 2) {
        let e = m();
        r(), Nn("", e.formatMessage("your"), " ", e.plan, " ", e.formatMessage("plan"), " ", e.formatMessage("plan_expiring_in"), " ", e.daysRemainingForExpiry, " ", e.formatMessage("days")), r(2), x(e.formatMessage("renew_to_avoid_interruption"))
    }
}

function Mc(t, c) {
    if (t & 1 && (n(0, "div", 19), s(1), i(), n(2, "small"), s(3), i()), t & 2) {
        let e = m();
        r(), x(e.formatMessage("subscription_expired")), r(2), x(e.formatMessage("renew_now_to_reclaim_premium_features"))
    }
}

function Nc(t, c) {
    if (t & 1 && (n(0, "div", 38)(1, "div", 39), p(2, "i", 40), n(3, "span", 41), s(4), i()()()), t & 2) {
        let e = c.$implicit;
        r(4), x(e)
    }
}

function Pc(t, c) {
    if (t & 1 && (n(0, "div", 9)(1, "div", 35), s(2), i(), n(3, "small", 36), s(4), i(), n(5, "div", 37), U(6, Nc, 5, 1, "div", 38, Ee), i()()), t & 2) {
        let e = m();
        r(2), x(e.formatMessage("what_youll_lose")), r(2), x(e.formatMessage("what_youll_lose_desc")), r(2), W(e.lostFeatures)
    }
}

function Vc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 51)(1, "dx-button", 54), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.goToPricing())
        }), i(), n(2, "dx-button", 55), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.goToPricing())
        }), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(), l("text", e.formatMessage("renew") + " " + e.plan), r(), l("text", e.formatMessage("upgrade_instead"))
    }
}

function Ac(t, c) {
    if (t & 1 && (n(0, "p", 52), s(1), i()), t & 2) {
        let e = m(2);
        r(), E(" ", e.formatMessage("manage_subscription_ios_message"), " ")
    }
}

function Lc(t, c) {
    if (t & 1 && (n(0, "div", 10)(1, "div", 42)(2, "div", 43), p(3, "i", 44), i()(), n(4, "h5", 45), s(5), i(), n(6, "p", 46), s(7), i(), n(8, "div", 47)(9, "div", 48)(10, "div", 49), s(11), i(), n(12, "div", 50), s(13), q(14, "dateFormat"), i()()(), d(15, Vc, 3, 2, "div", 51)(16, Ac, 2, 1, "p", 52), n(17, "small", 3), s(18), n(19, "a", 53), s(20), i()()()), t & 2) {
        let e = m();
        r(5), et("", e.formatMessage("your"), " ", e.plan, " ", e.formatMessage("plan_has_expired")), r(2), E(" ", e.formatMessage("expired_read_only_message"), " "), r(4), x(e.formatMessage("expired_on")), r(2), x(Y(14, 9, e.tenantConfig.trial_ends_at)), r(2), u(e.isIOSNative() ? 16 : 15), r(3), E(" ", e.formatMessage("need_help"), " "), r(2), x(e.formatMessage("talk_to_sales"))
    }
}

function Dc(t, c) {
    if (t & 1 && (n(0, "small", 56), p(1, "i", 57), s(2), q(3, "number"), i()), t & 2) {
        let e = m().$implicit,
            o = m();
        r(2), dt("-", xi(3, 2, e.data.discount_amount, "1.2-2"), " ", o.formatMessage("coupon"), " ")
    }
}

function Oc(t, c) {
    if (t & 1 && (n(0, "div")(1, "div"), s(2), q(3, "number"), i(), d(4, Dc, 4, 5, "small", 56), i()), t & 2) {
        let e = c.$implicit;
        r(2), x(xi(3, 2, e.data.total_amount, "1.2-2")), r(2), u(e.data.discount_amount > 0 ? 4 : -1)
    }
}

function Fc(t, c) {
    if (t & 1 && (n(0, "div")(1, "span", 58), s(2), q(3, "titlecase"), i()()), t & 2) {
        let e = c.$implicit;
        r(), Ae("bg-success", e.value === "paid")("bg-warning", e.value === "pending")("bg-danger", e.value === "failed"), r(), E(" ", Y(3, 7, e.value), " ")
    }
}

function Bc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "dx-button", 59), _("onClick", function() {
            let a = g(e).$implicit,
                h = m();
            return C(h.printInvoice(a.data.order_number))
        }), i(), n(2, "dx-button", 60), _("onClick", function() {
            let a = g(e).$implicit,
                h = m();
            return C(h.downloadInvoice(a.data.order_number, a.data.invoice_number))
        }), i()()
    }
    if (t & 2) {
        let e = m();
        r(2), l("hint", e.formatMessage("download"))
    }
}
var Ba = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tenantService = v(ie), this.subscriptionService = v(la), this.router = v(ge), this.isIOSNative = v(se).isIOS, this.TENANT_PLANS = H, this.plan = this.tenantService.plan(), this.tenantConfig = this.tenantService.config(), this.daysRemainingForExpiry = this.tenantService.daysRemainingForExpiry(), this.employeeLimits = {
                Lite: "2",
                Basic: "6",
                Standard: "12",
                Enterprise: f("unlimited")
            }, this.lostFeatures = ["Leads & email marketing", "AMC contracts", "Outsourced jobs", "Tasks & expenses", "Roles & permissions", "Pickup & drop", "UPI payment links", "Reports", "Bulk import"], this.invoices = ce([]), this.isLoadingInvoices = ce(!1)
        }
        planPeriodPercent() {
            let o = this.daysRemainingForExpiry || 0;
            return Math.max(0, Math.min(100, o / 365 * 100))
        }
        bannerType() {
            return this.daysRemainingForExpiry <= 0 ? "danger" : this.daysRemainingForExpiry <= 15 ? "warn" : "success"
        }
        ngOnInit() {
            this.loadInvoices()
        }
        loadInvoices() {
            this.isLoadingInvoices.set(!0), this.subscriptionService.getInvoices().subscribe({
                next: e => {
                    this.invoices.set(e), this.isLoadingInvoices.set(!1)
                },
                error: () => this.isLoadingInvoices.set(!1)
            })
        }
        printInvoice(e) {
            this.subscriptionService.downloadInvoice(e).subscribe({
                next: o => {
                    let a = window.URL.createObjectURL(o),
                        h = window.open(a);
                    h ? .addEventListener("load", () => {
                        h.print()
                    })
                }
            })
        }
        downloadInvoice(e, o) {
            this.subscriptionService.downloadInvoice(e).subscribe({
                next: a => {
                    let h = window.URL.createObjectURL(a),
                        w = document.createElement("a");
                    w.href = h;
                    let Lt = o.replace(/[/\\:*?"<>|]/g, "-");
                    w.download = `${Lt}.pdf`, w.click(), window.URL.revokeObjectURL(h)
                }
            })
        }
        goToPricing() {
            this.router.navigate(["/pricing"])
        }
        goToSmsPacks() {
            this.router.navigate(["/pricing"], {
                fragment: "sms-packs"
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-plan-listing"]
                ],
                standalone: !1,
                decls: 58,
                vars: 73,
                consts: [
                    [1, "container-fluid"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-3", "flex-wrap", "gap-2"],
                    [1, "fw-bold", "mb-0"],
                    [1, "text-muted"],
                    [1, "d-flex", "gap-2", "flex-wrap"],
                    [1, "alert", "d-flex", "align-items-center", "gap-3"],
                    [1, "rounded-circle", "d-flex", "align-items-center", "justify-content-center", "flex-shrink-0", 2, "width", "42px", "height", "42px"],
                    [1, "fa-solid", "fa-lg", "position-absolute", 2, "margin-left", "12px"],
                    [1, "flex-grow-1"],
                    [1, "dx-card", "p-3", "mb-3"],
                    [1, "dx-card", "p-4", "mb-3", "text-center", "border-danger"],
                    [1, "bp-plan-summary"],
                    [1, "text-muted", "small", "fw-semibold", "text-uppercase", "mb-1"],
                    [1, "badge", "bg-primary"],
                    [1, "fa-solid", "fa-crown", "me-1"],
                    [1, "fw-bold", "fs-5"],
                    [1, "bp-progress-bar", "bg-light"],
                    [1, "dx-card", "p-3"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-3"],
                    [1, "fw-semibold"],
                    [3, "dataSource", "showBorders", "showRowLines", "showColumnLines", "columnAutoWidth", "rowAlternationEnabled", "hoverStateEnabled", "noDataText"],
                    ["dataField", "invoice_number", 3, "caption"],
                    ["dataField", "plan.name", "caption", "Plan"],
                    ["dataField", "paid_at", "dataType", "date", "format", "dd-MMM-yyyy", 3, "caption"],
                    ["dataField", "total_amount", "alignment", "right", "cellTemplate", "amountTemplate", 3, "caption"],
                    ["dataField", "currency_code", "alignment", "center", 3, "caption", "width"],
                    ["dataField", "status", "alignment", "center", "cellTemplate", "statusTemplate", 3, "caption"],
                    ["caption", "Actions", "alignment", "center", "cellTemplate", "actionsTemplate", 3, "width"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["icon", "fa-solid fa-rotate-right", "type", "warning", "stylingMode", "contained", 3, "text"],
                    ["icon", "fa-solid fa-arrow-up", "type", "default", "stylingMode", "contained", 3, "text"],
                    ["text", "White Label", "icon", "fa-solid fa-globe", "type", "default", "stylingMode", "outlined", 3, "onClick"],
                    ["text", "SMS Credits", "icon", "fa-solid fa-message", "type", "default", "stylingMode", "outlined", 3, "onClick"],
                    ["icon", "fa-solid fa-rotate-right", "type", "warning", "stylingMode", "contained", 3, "onClick", "text"],
                    ["icon", "fa-solid fa-arrow-up", "type", "default", "stylingMode", "contained", 3, "onClick", "text"],
                    [1, "fw-semibold", "mb-1"],
                    [1, "text-muted", "mb-3", "d-block"],
                    [1, "row", "g-2"],
                    [1, "col-md-4"],
                    [1, "d-flex", "align-items-center", "gap-2", "border", "rounded", "p-2"],
                    [1, "fa-solid", "fa-circle-xmark", "text-danger"],
                    [1, "small"],
                    [1, "d-flex", "justify-content-center", "mb-3"],
                    [1, "rounded-circle", "d-flex", "align-items-center", "justify-content-center", 2, "width", "64px", "height", "64px", "background", "rgba(239, 68, 68, 0.1)"],
                    [1, "fa-solid", "fa-lock", "text-danger", 2, "font-size", "28px"],
                    [1, "fw-bold", "mb-2"],
                    [1, "text-muted", "small", "mb-4", 2, "max-width", "500px", "margin", "0 auto"],
                    [1, "d-flex", "justify-content-center", "gap-3", "mb-3", "flex-wrap"],
                    [1, "border", "rounded", "p-3", "text-start", 2, "min-width", "150px"],
                    [1, "text-muted", "small", "fw-semibold", "text-uppercase"],
                    [1, "fw-bold"],
                    [1, "d-flex", "justify-content-center", "gap-2", "mb-3"],
                    [1, "text-center", "text-muted", "small", "mb-3"],
                    ["href", "https://wa.me/919970022111", "target", "_blank", 1, "text-primary"],
                    ["icon", "fa-solid fa-rotate-right", "type", "danger", "stylingMode", "contained", 3, "onClick", "text"],
                    ["icon", "fa-solid fa-arrow-up", "type", "normal", "stylingMode", "outlined", 3, "onClick", "text"],
                    [1, "text-success"],
                    [1, "fa-solid", "fa-tag", "me-1"],
                    [1, "badge", "rounded-pill"],
                    ["icon", "fa-solid fa-print", "stylingMode", "text", "hint", "Print", 3, "onClick"],
                    ["icon", "fa-solid fa-download", "stylingMode", "text", 3, "onClick", "hint"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div")(3, "h5", 2), s(4), i(), n(5, "small", 3), s(6), i()(), d(7, wc, 5, 1, "div", 4), i(), n(8, "div", 5), p(9, "div", 6)(10, "i", 7), n(11, "div", 8), d(12, Ic, 5, 8)(13, kc, 4, 7)(14, Mc, 4, 2), i()(), d(15, Pc, 8, 2, "div", 9), d(16, Lc, 21, 11, "div", 10), n(17, "div", 9)(18, "div", 11)(19, "div")(20, "div", 12), s(21), i(), n(22, "span", 13), p(23, "i", 14), s(24), i()(), n(25, "div")(26, "div", 12), s(27), i(), n(28, "div", 15), s(29), i(), n(30, "div", 16), p(31, "span"), i(), n(32, "small", 3), s(33), q(34, "dateFormat"), i()(), n(35, "div")(36, "div", 12), s(37), i(), n(38, "div", 15), s(39), i()()()(), n(40, "div", 17)(41, "div", 18)(42, "div")(43, "div", 19), s(44), i(), n(45, "small", 3), s(46), i()()(), n(47, "dx-data-grid", 20), p(48, "dxi-column", 21)(49, "dxi-column", 22)(50, "dxi-column", 23)(51, "dxi-column", 24)(52, "dxi-column", 25)(53, "dxi-column", 26)(54, "dxi-column", 27), T(55, Oc, 5, 5, "div", 28)(56, Fc, 4, 9, "div", 28)(57, Bc, 3, 1, "div", 28), i()()()), o & 2 && (r(4), x(a.formatMessage("billing_and_plans")), r(2), x(a.bannerType() === "warn" ? a.formatMessage("renew_to_avoid_interruption") : a.formatMessage("billing_subtitle")), r(), u(a.isIOSNative() ? -1 : 7), r(), Ae("alert-success", a.bannerType() === "success")("alert-warning", a.bannerType() === "warn")("alert-danger", a.bannerType() === "danger"), r(), cn("opacity", .2), Ae("bg-success", a.bannerType() === "success")("bg-warning", a.bannerType() === "warn")("bg-danger", a.bannerType() === "danger"), r(), Ae("fa-circle-check", a.bannerType() === "success")("fa-clock", a.bannerType() === "warn")("fa-lock", a.bannerType() === "danger")("text-success", a.bannerType() === "success")("text-warning", a.bannerType() === "warn")("text-danger", a.bannerType() === "danger"), r(2), u(a.bannerType() === "success" ? 12 : a.bannerType() === "warn" ? 13 : 14), r(3), u(a.bannerType() === "warn" ? 15 : -1), r(), u(a.bannerType() === "danger" ? 16 : -1), r(), Ae("opacity-25", a.bannerType() === "danger"), r(4), x(a.formatMessage("current_plan")), r(3), E("", a.plan || "Free", " "), r(3), x(a.formatMessage("plan_period")), r(2), dt("", a.daysRemainingForExpiry > 0 ? a.daysRemainingForExpiry : 0, " ", a.formatMessage("days_left")), r(2), cn("width", a.planPeriodPercent(), "%"), Ae("bg-primary", a.daysRemainingForExpiry > 15)("bg-warning", a.daysRemainingForExpiry <= 15 && a.daysRemainingForExpiry > 0)("bg-danger", a.daysRemainingForExpiry <= 0), r(2), dt("", a.formatMessage("expires"), " ", Y(34, 71, a.tenantConfig.trial_ends_at)), r(4), x(a.formatMessage("employees")), r(2), x(a.employeeLimits[a.plan] || a.formatMessage("unlimited")), r(5), x(a.formatMessage("purchase_history")), r(2), x(a.formatMessage("purchase_history_subtitle")), r(), l("dataSource", a.invoices())("showBorders", !1)("showRowLines", !0)("showColumnLines", !1)("columnAutoWidth", !0)("rowAlternationEnabled", !1)("hoverStateEnabled", !0)("noDataText", a.formatMessage("no_purchase_history")), r(), l("caption", a.formatMessage("invoice_number")), r(2), l("caption", a.formatMessage("date")), r(), l("caption", a.formatMessage("amount")), r(), l("caption", a.formatMessage("currency"))("width", 70), r(), l("caption", a.formatMessage("status")), r(), l("width", 120), r(), l("dxTemplateOf", "amountTemplate"), r(), l("dxTemplateOf", "statusTemplate"), r(), l("dxTemplateOf", "actionsTemplate"))
                },
                dependencies: [G, _e, Hi, ho, Ln, An, Wi],
                styles: [".bp-plan-summary[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}@media(max-width:768px){.bp-plan-summary[_ngcontent-%COMP%]{grid-template-columns:1fr}}.bp-progress-bar[_ngcontent-%COMP%]{height:6px;border-radius:999px;overflow:hidden;margin:8px 0 4px}.bp-progress-bar[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block;height:100%;border-radius:999px;transition:width .3s ease}"]
            })
        }
    }
    return t
})();
var rn = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.router = v(ge), this.activatedRoute = v(De), this.userDeviceService = v(se), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.selectedTabIndex = null, this.listSettingsMenu = [{
                id: 0,
                text: f("job_quotation_payment_workflow_settings"),
                path: "/settings/workflow",
                icon: "fa-thin fa-address-book",
                visible: !0
            }, {
                id: 1,
                text: f("customer_address_settings"),
                path: "/settings/workflowAddress",
                icon: "fa-thin fa-map-location",
                visible: !0
            }, {
                id: 2,
                text: f("due_date_settings"),
                path: "/settings/workflowDueDates",
                icon: "fa-thin fa-calendar-days",
                visible: !0
            }]
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex, this.router.navigate([e.itemData.path])
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-workflow-tabs"]
                ],
                standalone: !1,
                decls: 4,
                vars: 0,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-12"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "router-outlet"), i()()())
                },
                dependencies: [Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ei = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tenantService = v(ie), this.router = v(ge), this.activatedRoute = v(De), this.userDeviceService = v(se), this.plan = this.tenantService.plan(), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.selectedTabIndex = null, this.listSettingsMenu = [{
                id: 0,
                text: f("printer_paper_size"),
                path: "/settings/print",
                icon: "fa-thin fa-print-slash",
                visible: !0
            }, {
                id: 1,
                text: f("technician_print"),
                path: "/settings/printTechnician",
                icon: "fa-thin fa-wrench",
                visible: !0
            }, {
                id: 2,
                text: f("print_options"),
                path: "/settings/printOptions",
                icon: "fa-thin fa-print",
                visible: !0
            }, {
                id: 3,
                text: f("amc_contract_print_options"),
                path: "/settings/printAmc",
                icon: "fa-thin fa-print-magnifying-glass",
                disabled: [H.LITE, H.BASIC].includes(this.plan),
                visible: !0
            }]
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex, this.router.navigate([e.itemData.path])
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-print-tabs"]
                ],
                standalone: !1,
                decls: 4,
                vars: 0,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-12"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "router-outlet"), i()()())
                },
                dependencies: [Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var yn = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.router = v(ge), this.activatedRoute = v(De), this.userDeviceService = v(se), this.isMobileDevice = this.userDeviceService.isMobileDevice, this.selectedTabIndex = null, this.listSettingsMenu = [{
                id: 0,
                text: f("table_settings"),
                path: "/settings/themes",
                icon: "fa-thin fa-table",
                visible: !0
            }, {
                id: 1,
                text: f("scrolling_options"),
                path: "/settings/themesScroll",
                icon: "fa-thin fa-mouse-alt",
                visible: !0
            }]
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex, this.router.navigate([e.itemData.path])
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-display-tabs"]
                ],
                standalone: !1,
                decls: 4,
                vars: 0,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-12"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "router-outlet"), i()()())
                },
                dependencies: [Oe],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ra = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, oo), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var Ga = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.entity = Q.SMS_HISTORY, this.columns = [{
                dataField: "sender_id",
                caption: f("sender_id"),
                visible: !1,
                allowSorting: !1,
                width: 80
            }, {
                dataField: "mobile_number",
                caption: f("mobile_number"),
                allowSorting: !1,
                width: 80
            }, {
                dataField: "message",
                alignment: "center",
                caption: f("message"),
                cellTemplate: "commentTemplate",
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "message_id",
                caption: f("message_id"),
                allowSorting: !1,
                hidingPriority: 5
            }, {
                dataField: "credits",
                caption: f("credits"),
                visible: !1,
                allowSorting: !1,
                hidingPriority: 1
            }, {
                dataField: "sent_status",
                caption: f("sent_status"),
                cellTemplate: "msgStatusTemplate",
                allowSorting: !1,
                hidingPriority: 3
            }, {
                dataField: "provider_name",
                caption: f("provider_name"),
                allowSorting: !1,
                hidingPriority: 0
            }, {
                dataField: "created_at",
                caption: f("sms_sent_on"),
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0,
                hidingPriority: 4
            }], this.router = v(ge), this.isIOSNative = v(se).isIOS
        }
        redirectToSMSBuy() {
            this.router.navigate(["/pricing"], {
                fragment: "sms-packs"
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ra))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-sms-history"]
                ],
                standalone: !1,
                decls: 3,
                vars: 5,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["id", "sms-history-list", 3, "dataGridAddNewClick", "columns", "entity", "isVisibleAddAction", "searchPanelPlaceholderText", "service"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "app-data-grid", 2), _("dataGridAddNewClick", function() {
                        return a.redirectToSMSBuy()
                    }), i()()()), o & 2 && (r(2), l("columns", a.columns)("entity", a.entity)("isVisibleAddAction", !a.isIOSNative())("searchPanelPlaceholderText", "search_panel_sms_history_placeholder")("service", a.service))
                },
                dependencies: [Re],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Vt = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            id: [c.id || null],
            name: [c.name || null],
            prefix: [c.prefix || null],
            starting_number: [c.starting_number || null],
            current_value: [c.current_value || null]
        })
    }
};

function Uc(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 0), t & 2 && l("rows", 3)("columns", 2)
}

function Wc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 15), _("onClickEvent", function() {
            g(e);
            let a = m(3);
            return C(a.setEditMode())
        }), i()
    }
    if (t & 2) {
        let e = m(3);
        l("disabled", e.isDisabled())
    }
}

function qc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 16), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.cancel())
        })("saveClick", function() {
            g(e);
            let a = m(3);
            return C(a.confirmSave())
        }), i()
    }
    if (t & 2) {
        let e = m(3);
        l("isSaving", e.isSaving)("isVisibleHr", !1)("useSubmitBehavior", !1)
    }
}

function Hc(t, c) {
    if (t & 1 && (n(0, "div", 12), d(1, Wc, 1, 1, "app-dx-outline-button", 13), d(2, qc, 1, 3, "app-save-cancel-footer", 14), i()), t & 2) {
        let e = m(2);
        r(), u(e.isEditMode ? -1 : 1), r(), u(e.isEditMode ? 2 : -1)
    }
}

function jc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 3), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), n(1, "div", 4)(2, "p", 5), s(3), i(), n(4, "app-control-container", 6), p(5, "dx-text-box", 7), i(), n(6, "app-control-container", 8), p(7, "dx-number-box", 9), i(), n(8, "app-control-container", 8)(9, "span", 10), s(10), i()(), T(11, Hc, 3, 2, "div", 11), i()()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(3), E(" ", e.tableSequenceNumber.display_name), r(), l("errorMsg", e.formatMessage("job_sheet_number_is_a_required_field"))("label", e.formatMessage("prefix")), r(), l("placeholder", e.formatMessage("type_prefix")), r(), l("errorMsg", e.formatMessage("quotation_number_is_a_required_field"))("label", e.formatMessage("starting_number")), r(), l("min", 0)("placeholder", e.formatMessage("starting_number")), r(), l("errorMsg", e.formatMessage("invoice_number_is_a_required_field"))("label", e.formatMessage("next") + " " + e.tableSequenceNumber.display_name), r(2), x(e.form.getRawValue().prefix + e.form.getRawValue().starting_number), r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function zc(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 17), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.save())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.isVisibleSaveConfirmPopup = !1)
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("confirmationMessage", e.formatMessage("sequence_number_changes"))
    }
}
var Wa = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.tableSequenceNumber = null, this.authorizationService = v(ht), this.generalSettingDataService = v(To), this.toastNotificationService = v(N), this.formService = v(B), this.ENTITIES = Q, this.isEditMode = !1, this.isSaving = !1, this.isVisibleSaveConfirmPopup = !1, this.isDisabled = ce(!0), this.PERMISSION_LIST = b
        }
        ngOnInit() {
            if (this.form = Vt.getForm(new Vt(this.tableSequenceNumber)), this.tableSequenceNumber ? .name === "service_invoice") this.isDisabled.set(!this.authorizationService.canAccess(this.ENTITIES.JOB_INVOICE));
            else if (this.tableSequenceNumber ? .name === "sale_number") this.isDisabled.set(!this.authorizationService.canAccess(this.ENTITIES.SALE) || this.generalSettingDataService.getGeneralSettingByKey("unified_invoice_number_for_sales_and_jobs"));
            else {
                let e = this.getEntityByName(this.tableSequenceNumber ? .name);
                this.isDisabled.set(!this.authorizationService.canAccess(e))
            }
            this.form.disable()
        }
        getEntityByName(e) {
            for (let o in this.ENTITIES)
                if (this.ENTITIES[o].name === e) return this.ENTITIES[o];
            return null
        }
        save() {
            this.isSaving = !0, this.isVisibleSaveConfirmPopup = !1, this.service.update(this.form.value).subscribe({
                next: e => {
                    this.tableSequenceNumber = new Vt(e), this.form.patchValue(this.tableSequenceNumber), this.form.disable(), this.isEditMode = !1, this.toastNotificationService.success("notification_table_sequence_update_success")
                },
                error: e => {
                    this.toastNotificationService.error("notification_table_sequence_update_error"), console.error(e)
                }
            }).add(() => this.isSaving = !1)
        }
        confirmSave() {
            this.form.valid ? this.isVisibleSaveConfirmPopup = !0 : this.formService.validateFormFields(this.form)
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        cancel() {
            this.isEditMode = !1, this.form.reset(new Vt(this.tableSequenceNumber)), this.form.disable()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ji))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-table-sequence-number"]
                ],
                inputs: {
                    tableSequenceNumber: "tableSequenceNumber"
                },
                standalone: !1,
                decls: 3,
                vars: 3,
                consts: [
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    ["id", "table-sequence-popup", 3, "confirmationMessage"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row"],
                    [1, "col-sm-2", "col-md-2", "col-lg-2", "d-flex", "align-items-center", "heading-name", "fw-bolder"],
                    ["name", "prefix", 1, "col-sm-2", "col-md-2", "col-lg-2", 3, "errorMsg", "label"],
                    ["formControlName", "prefix", "id", "table-sequence-number-prefix", 3, "placeholder"],
                    ["name", "starting_number", 1, "col-sm-2", "col-md-2", "col-lg-2", 3, "errorMsg", "label"],
                    ["formControlName", "starting_number", "id", "table-sequence-starting-number", 3, "min", "placeholder"],
                    [1, "badge", "theme-badge", "current-value", "text-white"],
                    ["class", "col-sm-4 col-md-4 col-lg-4 d-flex sequence-button justify-content-left", 4, "ngxPermissionsOnly"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "d-flex", "sequence-button", "justify-content-left"],
                    ["buttonType", "default", "text", "common_edit", "id", "table-sequence-edit-btn", 1, "float-end", "me-1", 3, "disabled"],
                    ["saveText", "common_update", "savingText", "common_updating", "cancelBtnId", "table-sequence-cancel", "saveBtnId", "table-sequence-save", 3, "isSaving", "isVisibleHr", "useSubmitBehavior"],
                    ["buttonType", "default", "text", "common_edit", "id", "table-sequence-edit-btn", 1, "float-end", "me-1", 3, "onClickEvent", "disabled"],
                    ["saveText", "common_update", "savingText", "common_updating", "cancelBtnId", "table-sequence-cancel", "saveBtnId", "table-sequence-save", 3, "cancelClick", "saveClick", "isSaving", "isVisibleHr", "useSubmitBehavior"],
                    ["id", "table-sequence-popup", 3, "confirmActionCallback", "rejectActionCallback", "confirmationMessage"]
                ],
                template: function(o, a) {
                    o & 1 && (d(0, Uc, 1, 2, "app-skeleton-loader", 0), d(1, jc, 12, 13, "form", 1), d(2, zc, 1, 1, "app-confirmation-popup", 2)), o & 2 && (u(a.form ? -1 : 0), r(), u(a.form ? 1 : -1), r(), u(a.isVisibleSaveConfirmPopup ? 2 : -1))
                },
                dependencies: [j, Ye, O, F, we, oi, ae, V, L, P, A, D, ne],
                styles: [".current-value[_ngcontent-%COMP%]{font-size:16px;vertical-align:bottom}.heading-name[_ngcontent-%COMP%]{position:relative;top:9px}.sequence-button[_ngcontent-%COMP%]{position:relative;top:20px}.btn-edit[_ngcontent-%COMP%]{margin-bottom:43px}@media(max-width:414px){.sequence-button[_ngcontent-%COMP%]{position:relative;top:0}}"]
            })
        }
    }
    return t
})();

function Yc(t, c) {
    if (t & 1 && (n(0, "div"), p(1, "app-table-sequence-number", 3), i()), t & 2) {
        let e = c.$implicit;
        r(), l("tableSequenceNumber", e)
    }
}
var qa = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.ENTITIES = Q
        }
        ngOnInit() {
            this.service.getListByQuery().subscribe({
                next: e => {
                    this.tableSequenceNumberList = e
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ji))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-table-sequence-number-list"]
                ],
                standalone: !1,
                decls: 5,
                vars: 2,
                consts: [
                    [1, "p-3", "sequence-setting"],
                    [3, "title"],
                    [3, "message"],
                    [3, "tableSequenceNumber"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0), p(1, "app-actionable-page-subtitle", 1)(2, "app-alert-panel", 2), U(3, Yc, 2, 1, "div", null, Ee), i()), o & 2 && (r(), l("title", "sequence_settings"), r(), l("message", a.formatMessage("sequence_setting_note")), r(), W(a.tableSequenceNumberList))
                },
                dependencies: [pe, Ve, Wa],
                styles: [".sequence-setting[_ngcontent-%COMP%]     .dx-button.dx-button-default.dx-state-disabled{color:#6b7280}"]
            })
        }
    }
    return t
})();
var At = class t {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new ut({
            name: new Se(c.name || null, [k.required]),
            rate: new Se(c.rate || null, [k.required])
        })
    }
    static getFormArray(c) {
        let e = new Pi([]);
        return c && c.length && c.forEach(o => {
            e.push(t.getForm(o))
        }), e
    }
};
var ui = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            id: [c.id || null],
            name: [c.name || null, [k.required]],
            rate: [c.rate || null, [k.required]],
            is_default: [c.is_default || !1],
            tax_sub_classes: At.getFormArray(c.tax_sub_classes)
        })
    }
};

function Zc(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 4), t & 2 && l("rows", 4)("columns", 2)
}

function $c(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 17)(1, "app-control-container", 18), p(2, "dx-text-box", 19), i(), n(3, "app-control-container", 20), p(4, "dx-number-box", 21), i(), n(5, "div", 22)(6, "i", 23), _("click", function() {
            let a = g(e).index,
                h = m(3);
            return C(h.removeTaxClass(a))
        }), i()()()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = m(3);
        l("formGroup", e), r(), l("errorMsg", o.formatMessage("sub_class_name_required"))("label", o.formatMessage("sub_class_name")), r(), l("placeholder", o.formatMessage("sub_class_name_placeholder")), r(), l("errorMsg", o.formatMessage("tax_rate_required"))("label", o.formatMessage("common_tax_rate")), r(), l("format", o.TAX_FORMAT)("min", 0)("placeholder", o.formatMessage("tax_percentage_placeholder"))
    }
}

function Xc(t, c) {
    if (t & 1 && p(0, "app-server-error", 14), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function Jc(t, c) {
    if (t & 1 && (n(0, "p", 15), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.errorMessage)
    }
}

function em(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 6), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "div", 2)(2, "app-control-container", 7)(3, "dx-text-box", 8)(4, "dx-validator"), p(5, "dxi-validation-rule", 9), i()()(), n(6, "app-control-container", 10), p(7, "dx-number-box", 11), i()(), n(8, "div", 2)(9, "div", 3)(10, "app-dx-outline-button", 12), _("onClickEvent", function() {
            g(e);
            let a = m(2);
            return C(a.addTaxClass())
        }), i()()(), T(11, $c, 7, 9, "div", 13), n(12, "div", 2)(13, "div", 3), d(14, Xc, 1, 1, "app-server-error", 14), d(15, Jc, 2, 1, "p", 15), n(16, "app-save-cancel-footer", 16), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i()()()()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("tax_name_required"))("label", e.formatMessage("tax_name")), r(), l("placeholder", e.formatMessage("tax_name_placeholder")), r(2), l("ignoreEmptyValue", !0)("message", e.formatMessage("tax_name_exists"))("validationCallback", e.asyncUniqueNameValidation), r(), l("errorMsg", e.formatMessage("tax_rate_required"))("label", e.formatMessage("common_tax_rate")), r(), l("format", e.TAX_FORMAT)("min", 0)("placeholder", e.formatMessage("tax_percentage_placeholder")), r(4), l("ngForOf", e.form.get("tax_sub_classes").controls), r(3), u(e.errorResponse ? 14 : -1), r(), u(e.errorMessage ? 15 : -1), r(), l("isOnPopup", !0)
    }
}

function tm(t, c) {
    if (t & 1 && (n(0, "div")(1, "div", 2)(2, "div", 3), d(3, Zc, 1, 2, "app-skeleton-loader", 4), d(4, em, 17, 16, "form", 5), i()()()), t & 2) {
        let e = m();
        r(3), u(e.form ? -1 : 3), r(), u(e.form ? 4 : -1)
    }
}
var Ha = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.isCreate = !0, this.taxSaveClick = new ue, this.taxCancelClick = new ue, this.formService = v(B), this.commonService = v(vt), this.toastNotificationService = v(N), this.errorResponse = null, this.entity = Q.TAX, this.TAX_FORMAT = bi, this.errorMessage = "", this.isSaving = !1, this.asyncUniqueNameValidation = this.asyncUniqueNameValidation.bind(this)
        }
        ngOnInit() {
            this.form = ui.getForm(new ui(this.isCreate ? {} : this.tax))
        }
        asyncUniqueNameValidation(e) {
            return this.commonService.checkUniqueName({
                entity: this.entity.table,
                name: e.value,
                entity_id: this.tax ? .id
            }).pipe(Ot(o => !!(o.hasOwnProperty("success") && o.success))).toPromise()
        }
        save() {
            this.errorResponse = null, this.form.valid && this.isValidSubClass() ? (this.isSaving = !0, (this.isCreate ? this.service.create(this.form.value) : this.service.update(this.form.value)).subscribe({
                next: o => {
                    this.tax = new ui(o), this.isVisiblePopup = !1, this.toastNotificationService.success(this.isCreate ? "tax_added_successfully" : "tax_updated_successfully"), this.taxSaveClick.emit(this.tax), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => {
                this.isSaving = !1
            })) : this.formService.validateFormFields(this.form)
        }
        isValidSubClass() {
            if (this.errorMessage = "", !this.form.value.tax_sub_classes.length) return !0;
            let e = this.form.value.tax_sub_classes.map(o => parseFloat(o.rate)).reduce((o, a) => o + a, 0);
            return parseFloat(e) !== parseFloat(this.form.value.rate) ? (this.errorMessage = this.formatMessage("tax_rate_sum_validation"), !1) : !0
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.tax = null, this.taxCancelClick.emit()
        }
        removeTaxClass(e) {
            this.form.get("tax_sub_classes").removeAt(e)
        }
        addTaxClass() {
            this.form.get("tax_sub_classes").push(At.getForm(new At({})))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(zi))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-tax"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    isCreate: "isCreate",
                    tax: "tax"
                },
                outputs: {
                    taxSaveClick: "taxSaveClick",
                    taxCancelClick: "taxCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    ["id", "tax-popup", 3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "name", "id", "tax-popup-tax-name", 3, "placeholder"],
                    ["type", "async", 3, "ignoreEmptyValue", "message", "validationCallback"],
                    ["name", "rate", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "rate", "id", "tax-popup-tax-rate", 3, "format", "min", "placeholder"],
                    ["buttonType", "default", "id", "tax-popup-add-sub-class-btn", "text", "add_sub_class", "title", "add_sub_class", 1, "float-end", 3, "onClickEvent"],
                    ["class", "row", 3, "formGroup", 4, "ngFor", "ngForOf"],
                    [1, "mt-2", 3, "errorResponse"],
                    [1, "text-danger"],
                    ["cancelBtnId", "tax-popup-cancel", "saveBtnId", "tax-popup-save", 3, "cancelClick", "isOnPopup"],
                    [1, "row", 3, "formGroup"],
                    ["name", "name", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "name", "id", "tax-popup-sub-class-name", 3, "placeholder"],
                    ["name", "rate", 1, "col-sm-5", "col-md-5", "col-lg-5", 3, "errorMsg", "label"],
                    ["formControlName", "rate", "id", "tax-popup-tax-percentage", 3, "format", "min", "placeholder"],
                    [1, "col-sm-2", "col-md-2", "col-lg-2"],
                    [1, "fa-thin", "fa-times", "close-icon", 3, "click"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, tm, 5, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("width", "95vw")("maxWidth", 600)("title", a.tax != null && a.tax.id ? a.formatMessage("update_tax") : a.formatMessage("add_new_tax")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [Ut, ee, j, O, F, we, G, Ct, oi, re, ae, St, V, L, P, A, D],
                styles: [".close-icon[_ngcontent-%COMP%]{font-size:large;margin-top:29px}"]
            })
        }
    }
    return t
})();

function nm(t, c) {
    if (t & 1 && (n(0, "tr")(1, "td"), s(2), i(), n(3, "td"), s(4), i()()), t & 2) {
        let e = c.$implicit;
        r(2), x(e.name), r(2), E("", e.rate, "%")
    }
}

function om(t, c) {
    if (t & 1 && (n(0, "div")(1, "table"), U(2, nm, 5, 2, "tr", null, Ee), i()()), t & 2) {
        let e = m().$implicit;
        r(2), W(e.value)
    }
}

function am(t, c) {
    if (t & 1 && (n(0, "div"), d(1, om, 4, 0, "div"), i()), t & 2) {
        let e = c.$implicit;
        r(), u(e.value.length ? 1 : -1)
    }
}

function rm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "dx-button", 8), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.clearAllFilters())
        }), i()()
    }
    if (t & 2) {
        let e = m();
        r(), l("hint", e.formatMessage("clear_all_filters"))("title", e.formatMessage("clear_all_filters"))
    }
}

function sm(t, c) {
    if (t & 1 && (n(0, "div"), s(1), q(2, "dateFormat"), i()), t & 2) {
        let e = c.$implicit;
        r(), E(" ", xi(2, 1, e.value, "datetime"), " ")
    }
}

function lm(t, c) {
    if (t & 1 && (n(0, "div")(1, "span", 9), s(2), i()()), t & 2) {
        let e = m();
        r(), l("ngClass", e.isMobileDevice ? "h5" : "h4"), r(), x(e.entity.displayName)
    }
}

function cm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "i", 10), _("click", function() {
            let a = g(e).$implicit,
                h = m();
            return C(h.edit(a.data))
        }), i()()
    }
}

function mm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-tax", 11), _("taxCancelClick", function() {
            g(e);
            let a = m();
            return C(a.isVisibleTaxPopup = !1)
        })("taxSaveClick", function() {
            g(e);
            let a = m();
            return C(a.onTaxSave())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isCreate", e.isCreate)("isVisiblePopup", e.isVisibleTaxPopup)("tax", e.tax)
    }
}

function pm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 12), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.delete())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.cancelDelete())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("confirmButtonText", "delete")("confirmationMessage", e.formatMessage("are_you_sure_you_want_to_delete_tax"))
    }
}
var ja = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.userSessionService = v(tt), this.isMobileDevice = v(se).isMobileDevice(), this.toastNotificationService = v(N), this.filterPersistService = v(Do), this.dataGridService = v(Oo), this.userPermissionList = this.userSessionService.userPermissionList(), this.entity = Q.TAX, this.isVisibleDeletePopup = !1, this.isVisibleTaxPopup = !1, this.tax = null, this.isCreate = !1, this.format = "#0%", this.columns = [{
                dataField: "name",
                caption: f("tax_name"),
                width: 130,
                allowSorting: !0,
                allowSearch: !0
            }, {
                dataField: "rate",
                caption: f("tax_rate_percent"),
                dataType: "number",
                width: 130,
                alignment: "center",
                format: bi,
                allowSorting: !1
            }, {
                dataField: "tax_sub_classes",
                caption: f("sub_classes"),
                hidingPriority: 3,
                format: bi,
                cellTemplate: "subClassTemplate",
                allowSorting: !1,
                allowSearch: !0
            }, {
                dataField: "created_at",
                caption: f("common_created_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                alignment: "center",
                allowSorting: !1,
                allowSearch: !1
            }, {
                dataField: "updated_at",
                caption: f("common_updated_on"),
                alignment: "center",
                hidingPriority: 0,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !1,
                allowSearch: !1
            }, {
                dataField: "",
                caption: "",
                alignment: "center",
                hidingPriority: 2,
                width: 45,
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                visible: this.userPermissionList.includes(b.BUSINESS_SETTING_WRITE)
            }], this.loaderLogo = Kt, this.filterStorageKey = this.entity.name + "_filters"
        }
        ngOnInit() {
            yo.removeHidingPriorityOnDesktop(this.columns, this.isMobileDevice), this.store = new Vo({
                load: e => {
                    let o = this.getQueryParamsDataGrid(e);
                    return this.service.getListByQuery(o).toPromise().then(a => ({
                        data: a.data || [],
                        totalCount: a.total
                    }))
                }
            })
        }
        onToolbarPreparing(e) {
            e.toolbarOptions.items.push({
                template: "tableHeaderTemplate",
                location: "before",
                locateInMenu: "never"
            }, {
                template: "clearAllFilters",
                location: "after",
                locateInMenu: this.isMobileDevice ? "auto" : "never",
                visible: !0
            }, {
                location: "after",
                locateInMenu: "never",
                widget: "dxButton",
                options: {
                    icon: "fa-light fa-plus",
                    stylingMode: "outlined",
                    type: "default",
                    elementAttr: {
                        id: "tax-add-btn"
                    },
                    hint: f(this.entity.createNewLabel),
                    onClick: () => {
                        this.create()
                    }
                },
                visible: this.userPermissionList.includes(b.BUSINESS_SETTING_WRITE)
            }), this.dataGridService.arrangeToolbarItems(e.toolbarOptions.items)
        }
        getQueryParamsDataGrid(e) {
            let a = {
                page: e.skip / e.take + 1,
                paginate: "True",
                per_page: e.take,
                status: po.ACTIVE
            };
            return this.searchText === "" && this.updateTaxFilterValues(), this.searchText && (a.search_term = this.searchText, this.updateTaxFilterValues()), e.sort && (a.order_by = e.sort[0].selector, a.order_by_direction = e.sort[0].desc ? "desc" : "asc"), a
        }
        updateTaxFilterValues() {
            this.taxFilters = {
                searchText: this.searchText
            }, this.filterCount = this.filterPersistService.saveAllFiltersInStorage(this.filterStorageKey, this.taxFilters)
        }
        create() {
            this.isVisibleTaxPopup = !0, this.isCreate = !0
        }
        edit(e) {
            this.isCreate = !1, this.tax = e, this.isVisibleTaxPopup = !0
        }
        onTaxSave() {
            this.isCreate = !1, this.isVisibleTaxPopup = !1, this.tax = null, this.ngOnInit()
        }
        confirmDelete(e) {
            this.deleteTax = e, this.isVisibleDeletePopup = !0
        }
        delete() {
            this.service.delete(this.deleteTax.id).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_tax_delete_success"), this.ngOnInit()
                },
                error: e => {
                    console.log(e)
                }
            }).add(() => {
                this.isVisibleDeletePopup = !1
            })
        }
        cancelDelete() {
            this.isVisibleDeletePopup = !1, this.deleteTax = null
        }
        clearAllFilters() {
            this.filterPersistService.clearALlFilters(this.filterStorageKey), this.getSavedFilterValues(), window.location.reload()
        }
        getSavedFilterValues() {
            let e = this.filterPersistService.getAllSavedFilterValuesFromStorage(this.filterStorageKey);
            this.taxFilters = e.filters ? .searchText ? ? "", this.filterCount = e.count, setTimeout(() => {
                this.searchText = this.taxFilters.searchText
            }, 300)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(zi))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-tax-list"]
                ],
                standalone: !1,
                decls: 12,
                vars: 20,
                consts: [
                    [1, "mt-3", 3, "message"],
                    ["id", "gridContainer", "keyExpr", "id", 3, "onToolbarPreparing", "columnAutoWidth", "columns", "dataSource"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "textChange", "text", "placeholder", "visible", "width"],
                    ["text", "", 3, "indicatorSrc", "showPane"],
                    ["mode", "select", "type", "outline", 3, "enabled", "width", "title"],
                    [3, "isCreate", "isVisiblePopup", "tax"],
                    [3, "confirmButtonText", "confirmationMessage"],
                    ["icon", "fa-thin fa-filter-circle-xmark", "stylingMode", "outlined", "type", "default", 1, "px-1", 3, "onClick", "hint", "title"],
                    [3, "ngClass"],
                    ["title", "Edit", 1, "fa-thin", "fa-pencil", "me-2", 3, "click"],
                    [3, "taxCancelClick", "taxSaveClick", "isCreate", "isVisiblePopup", "tax"],
                    [3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-alert-panel", 0), n(1, "dx-data-grid", 1), _("onToolbarPreparing", function(w) {
                        return a.onToolbarPreparing(w)
                    }), T(2, am, 2, 1, "div", 2), n(3, "dxo-search-panel", 3), X("textChange", function(w) {
                        return $(a.searchText, w) || (a.searchText = w), w
                    }), i(), T(4, rm, 2, 2, "div", 2), p(5, "dxo-load-panel", 4)(6, "dxo-column-chooser", 5), T(7, sm, 3, 4, "div", 2)(8, lm, 3, 2, "div", 2)(9, cm, 2, 0, "div", 2), i(), d(10, mm, 1, 3, "app-tax", 6), d(11, pm, 1, 2, "app-confirmation-popup", 7)), o & 2 && (l("message", a.formatMessage("tax_settings_note")), r(), l("columnAutoWidth", !a.isMobileDevice)("columns", a.columns)("dataSource", a.store), r(), l("dxTemplateOf", "subClassTemplate"), r(), Z("text", a.searchText), l("placeholder", a.formatMessage("search_panel_tax_placeholder"))("visible", a.entity.isVisibleSearchPanel)("width", a.isMobileDevice ? a.entity.searchPanelWidth ? a.entity.searchPanelWidth : 230 : 300), r(), l("dxTemplateOf", "clearAllFilters"), r(), l("indicatorSrc", a.loaderLogo)("showPane", !1), r(), l("enabled", !0)("width", a.isMobileDevice ? 250 : 350)("title", a.isMobileDevice ? a.formatMessage("column_chooser_label") : a.formatMessage("sale_column_chooser_title")), r(), l("dxTemplateOf", "dateTimeTemplate"), r(), l("dxTemplateOf", "tableHeaderTemplate"), r(), l("dxTemplateOf", "actionTemplate"), r(), u(a.isVisibleTaxPopup ? 10 : -1), r(), u(a.isVisibleDeletePopup ? 11 : -1))
                },
                dependencies: [Gt, Ye, pe, G, _e, Hi, vo, xo, bo, Ha, Wi],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Et = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new ut({
            id: new Se(c.id || null),
            type_id: new Se(c.type_id || null, [k.required]),
            text: new Se(c.text || null, [k.required])
        })
    }
};
var za = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, io), this.api = e
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var _m = () => [!1, 1, 2, 3, 4, 5];

function fm(t, c) {
    if (t & 1 && (n(0, "div"), p(1, "app-actionable-page-subtitle", 6)(2, "app-alert-panel", 7), i()), t & 2) {
        let e = m();
        Ze(e.isMobileDevice ? "text-center mt-3" : "float-start"), r(), l("title", "common_terms_and_conditions"), r(), l("message", e.formatMessage("terms_and_conditions_description"))
    }
}

function gm(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 4), t & 2 && l("rows", 6)("columns", 3)
}

function Cm(t, c) {
    if (t & 1 && p(0, "app-server-error", 12), t & 2) {
        let e = m(2);
        l("errorResponse", e.errorResponse)
    }
}

function vm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 16), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.cancel())
        }), i()
    }
    t & 2 && l("isVisibleHr", !1)
}

function hm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-edit-back-btn", 18), _("editClick", function() {
            g(e);
            let a = m(3);
            return C(a.setEditMode())
        }), i()
    }
}

function xm(t, c) {
    if (t & 1 && T(0, hm, 1, 0, "app-edit-back-btn", 17), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function Sm(t, c) {
    if (t & 1 && (n(0, "span"), s(1), i()), t & 2) {
        let e = m(3);
        r(), dt("", e.formatMessage("common_max_allowed_characters"), "", e.maxLength)
    }
}

function bm(t, c) {
    if (t & 1 && (n(0, "span", 45), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.maxLengthError)
    }
}

function ym(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-control-container", 15)(1, "dx-html-editor", 19), _("onValueChanged", function(a) {
            g(e);
            let h = m(2);
            return C(h.onChange(a))
        }), n(2, "dxo-toolbar", 20), p(3, "dxi-item", 21)(4, "dxi-item", 22)(5, "dxi-item", 23)(6, "dxi-item", 24)(7, "dxi-item", 25)(8, "dxi-item", 23)(9, "dxi-item", 26)(10, "dxi-item", 27)(11, "dxi-item", 28)(12, "dxi-item", 29)(13, "dxi-item", 23)(14, "dxi-item", 30)(15, "dxi-item", 31)(16, "dxi-item", 32)(17, "dxi-item", 33)(18, "dxi-item", 23)(19, "dxi-item", 34)(20, "dxi-item", 35)(21, "dxi-item", 23)(22, "dxi-item", 36)(23, "dxi-item", 23)(24, "dxi-item", 37)(25, "dxi-item", 38)(26, "dxi-item", 23)(27, "dxi-item", 39)(28, "dxi-item", 23)(29, "dxi-item", 40)(30, "dxi-item", 41)(31, "dxi-item", 42)(32, "dxi-item", 43), i(), p(33, "dxo-media-resizing", 44), i(), d(34, Sm, 2, 2, "span"), d(35, bm, 2, 1, "span", 45), i()
    }
    if (t & 2) {
        let e = m(2);
        l("errorMsg", e.formatMessage("common_error_messages_terms_required"))("label", e.formatMessage("common_terms_and_conditions")), r(), l("disabled", !e.isEditMode)("placeholder", e.formatMessage("common_terms_and_conditions")), r(), l("multiline", !1), r(4), l("acceptedValues", e.fontSizes), r(), l("acceptedValues", e.fontFamilies), r(15), l("acceptedValues", Le(11, _m)), r(11), l("enabled", !0), r(), u(e.isEditMode && !e.maxLengthError ? 34 : -1), r(), u(e.maxLengthError !== "" ? 35 : -1)
    }
}

function Tm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 8), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), n(1, "div")(2, "app-control-container", 9)(3, "dx-select-box", 10), _("onItemClick", function(a) {
            g(e);
            let h = m();
            return C(h.onChangeTermAndConditionType(a))
        }), i()(), n(4, "div", 11), d(5, Cm, 1, 1, "app-server-error", 12), d(6, vm, 1, 1, "app-save-cancel-footer", 13)(7, xm, 1, 1, "app-edit-back-btn", 14), i()(), d(8, ym, 36, 12, "app-control-container", 15), i()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(), Ze(e.isMobileDevice ? "row d-flex flex-column-reverse" : "row"), r(), l("errorMsg", e.formatMessage("selection_is_a_required_field"))("label", e.formatMessage("selection")), r(), l("items", e.termAndConditionTypes)("placeholder", e.formatMessage("select_terms_and_conditions_type"))("searchEnabled", !0), r(2), u(e.errorResponse ? 5 : -1), r(), u(e.isEditMode ? 6 : 7), r(2), u(e.form ? 8 : -1)
    }
}
var Qa = (() => {
    class t {
        constructor(e, o, a) {
            this.termAndConditionTypeService = e, this.termAndConditionService = o, this.loaderService = a, this.formatMessage = f, this.isWizard = !1, this.formService = v(B), this.authorizationService = v(ht), this.isMobileDevice = v(se).isMobileDevice(), this.toastNotificationService = v(N), this.maxLength = 5e4, this.errorResponse = null, this.isEditMode = !1, this.maxLengthError = "", this.fontSizes = lo, this.fontFamilies = mo, this.PERMISSION_LIST = b
        }
        ngOnInit() {
            this.initialize(), this.termAndConditionTypeService.getListByQuery().subscribe({
                next: e => {
                    this.termAndConditionTypes = e.map(o => {
                        let a = !1;
                        return o.name === Q.SALE.name ? a = !this.authorizationService.canAccess(Q.SALE) : o.name === Q.JOB_SHEET.name ? a = !this.authorizationService.canAccess(Q.JOB_SHEET) : o.name === Q.QUOTATION.name ? a = !this.authorizationService.canAccess(Q.QUOTATION) : o.name === Q.AMC_CONTRACT.name ? a = !this.authorizationService.canAccess(Q.AMC_CONTRACT) : o.name === Q.PURCHASE.name ? a = !this.authorizationService.canAccess(Q.PURCHASE) : o.name === Q.GDPR_COMPLIANCE.name && (a = !this.authorizationService.canAccess(Q.GDPR_COMPLIANCE)), ct(lt({}, o), {
                            disabled: a
                        })
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        initialize() {
            this.loaderService.show(), wi([this.termAndConditionTypeService.getListByQuery(), this.termAndConditionService.getListByQuery()]).subscribe({
                next: ([e, o]) => {
                    this.termAndConditionTypes = e, this.termAndConditions = o;
                    let a = this.termAndConditions.length ? new Et(this.termAndConditions[0]) : new Et({});
                    this.setForm(a), this.form.disable()
                },
                error: e => {
                    console.log(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        setForm(e) {
            this.form && this.form.reset({
                text: null
            }), this.form = Et.getForm(e)
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.loaderService.show(), (this.form.value.id ? this.termAndConditionService.update(this.form.value) : this.termAndConditionService.create(this.form.value)).subscribe({
                next: o => {
                    this.toastNotificationService.success("notification_terms_conditions_save_success");
                    let a = this.termAndConditions.findIndex(h => h.id === o.id);
                    a !== -1 ? this.termAndConditions[a] = o : this.termAndConditions.push(o), this.isEditMode = !1, this.form.disable()
                },
                error: o => {
                    this.errorResponse = o
                }
            }).add(() => this.loaderService.hide())) : this.formService.validateFormFields(this.form)
        }
        onChangeTermAndConditionType(e) {
            let o = e.itemData.id,
                a = this.termAndConditions.findIndex(h => h.type_id === o);
            a !== -1 ? this.setForm(new Et(this.termAndConditions[a])) : this.setForm(new Et({
                type_id: o
            }))
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        cancel() {
            this.form.disable(), this.isEditMode = !1
        }
        onChange(e) {
            this.maxLengthError = "", this.maxLength < e ? .value ? .length && (this.maxLengthError = `Character limit exceeded by ${e.value.length-this.maxLength} characters`)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(za), I(Eo), I(Qe))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-term-and-conditions"]
                ],
                inputs: {
                    isWizard: "isWizard"
                },
                standalone: !1,
                decls: 6,
                vars: 3,
                consts: [
                    [1, "p-3"],
                    [1, "row"],
                    [3, "class"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "mt-3"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "title"],
                    [3, "message"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["displayExpr", "display_name", "formControlName", "type_id", "id", "term-and-conditions-selection", "searchMode", "contains", "valueExpr", "id", 3, "onItemClick", "items", "placeholder", "searchEnabled"],
                    [1, "col-sm-9", "col-md-9", "col-lg-9", "mt-4"],
                    [1, "mt-2", 3, "errorResponse"],
                    ["cancelBtnId", "term-and-condition-cancel", "saveBtnId", "term-and-condition-save", 3, "isVisibleHr"],
                    ["backBtnId", "term-and-condition-back", "editBtnId", "term-and-condition-edit"],
                    ["name", "text", 3, "errorMsg", "label"],
                    ["cancelBtnId", "term-and-condition-cancel", "saveBtnId", "term-and-condition-save", 3, "cancelClick", "isVisibleHr"],
                    ["backBtnId", "term-and-condition-back", "editBtnId", "term-and-condition-edit", 3, "editClick", 4, "ngxPermissionsOnly"],
                    ["backBtnId", "term-and-condition-back", "editBtnId", "term-and-condition-edit", 3, "editClick"],
                    ["formControlName", "text", "height", "200px", "valueType", "html", 3, "onValueChanged", "disabled", "placeholder"],
                    ["id", "textarea-toolbar", 3, "multiline"],
                    ["name", "undo"],
                    ["name", "redo"],
                    ["name", "separator"],
                    ["name", "size", 3, "acceptedValues"],
                    ["name", "font", 3, "acceptedValues"],
                    ["name", "bold"],
                    ["name", "italic"],
                    ["name", "strike"],
                    ["name", "underline"],
                    ["name", "alignLeft"],
                    ["name", "alignCenter"],
                    ["name", "alignRight"],
                    ["name", "alignJustify"],
                    ["name", "orderedList"],
                    ["name", "bulletList"],
                    ["name", "header", 3, "acceptedValues"],
                    ["name", "color"],
                    ["name", "background"],
                    ["name", "link"],
                    ["name", "clear"],
                    ["name", "codeBlock"],
                    ["name", "blockquote"],
                    ["name", "insertTable"],
                    [3, "enabled"],
                    [1, "text-danger"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1), d(2, fm, 3, 4, "div", 2), n(3, "div", 3), d(4, gm, 1, 2, "app-skeleton-loader", 4), d(5, Tm, 9, 11, "form", 5), i()()()), o & 2 && (r(2), u(a.isWizard ? -1 : 2), r(2), u(a.form ? -1 : 4), r(), u(a.form ? 5 : -1))
                },
                dependencies: [ee, j, O, qe, pe, Ve, F, Oi, Fi, qi, So, le, V, L, P, A, D, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();

function wm(t, c) {
    if (t & 1 && p(0, "app-invoice-due-reminder-setting", 1), t & 2) {
        let e = m();
        l("settingType", e.SETTINGS_TYPE.REMINDER_SETTINGS)("title", e.formatMessage("invoice_due_reminder_settings"))("id", "invoice-reminder-settings")
    }
}
var Ya = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tenantService = v(ie), this.plan = this.tenantService.plan(), this.SETTINGS_TYPE = gt, this.TENANT_PLANS = H
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-reminder-settings"]
                ],
                decls: 2,
                vars: 3,
                consts: [
                    ["id", "reminders-title", 3, "settingType", "title"],
                    [3, "settingType", "title", "id"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-base-setting", 0), d(1, wm, 1, 3, "app-invoice-due-reminder-setting", 1)), o & 2 && (l("settingType", a.SETTINGS_TYPE.REMINDER_SETTINGS)("title", "reminders_settings"), r(), u(a.plan === a.TENANT_PLANS.STANDARD || a.plan === a.TENANT_PLANS.ENTERPRISE ? 1 : -1))
                },
                dependencies: [nt, Zi, oa],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ie = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, dn), this.api = e, this.endpoint = dn
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var te = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        let e = new z,
            o = {};
        return c.config && Object.entries(c.config).forEach(([a, h]) => {
            o[a] = new _t(h)
        }), new z().group({
            id: [c.id || null],
            service_name: [c.service_name || null, [k.required]],
            username: [c.username || null],
            api_key: [c.api_key || null],
            group: [c.group || null],
            is_primary: [c.is_primary || !1],
            status: [c.status || oe.ACTIVE, [k.required]],
            expires_at: [c.expires_at || null],
            config: e.group(o)
        })
    }
};

function Im(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 5), t & 2 && l("rows", 4)("columns", 2)
}

function km(t, c) {
    if (t & 1 && p(0, "app-server-error", 16), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function Mm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 7), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "div", 8)(2, "app-control-container", 9), p(3, "dx-text-box", 10), i(), n(4, "app-control-container", 11), p(5, "dx-select-box", 12), i(), n(6, "app-control-container", 13), p(7, "dx-text-box", 14), i()(), n(8, "app-save-cancel-footer", 15), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i(), d(9, km, 1, 1, "app-server-error", 16), i()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("server_required"))("label", e.formatMessage("server_label")), r(), l("placeholder", e.formatMessage("username_label")), r(), l("errorMsg", e.formatMessage("common_error_messages_status_required")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("errorMsg", e.formatMessage("api_key_required"))("label", e.formatMessage("api_key_label")), r(), l("placeholder", e.formatMessage("api_key_label")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 9 : -1)
    }
}

function Nm(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), d(4, Im, 1, 2, "app-skeleton-loader", 5), d(5, Mm, 10, 13, "form", 6), i()()()()), t & 2) {
        let e = m();
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}
var Ka = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configureMailChimpCancelClick = new ue, this.formService = v(B), this.toastNotificationService = v(N), this.isSaving = !1, this.disabled = !0, this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.MAILCHIMP,
                status: oe.ACTIVE
            }))
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.isVisiblePopup = !1, this.toastNotificationService.success("notification_mailchimp_config_save_success"), this.configureMailChimpCancelClick.emit(), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configureMailChimpCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-mailchimp"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureMailChimpCancelClick: "configureMailChimpCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-5"],
                    ["name", "username", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "username", 3, "placeholder", "readOnly"],
                    ["label", "Service Status", "name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "api_key", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "api_key", 3, "placeholder", "readOnly"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, Nm, 6, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 600)("title", a.formatMessage("configure_mailchimp")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, F, G, re, Ce, le, ae, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Vm(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 5), t & 2 && l("rows", 4)("columns", 1)
}

function Am(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 21)(1, "div", 3)(2, "div", 23)(3, "app-control-container", 24), p(4, "dx-text-box", 25), i()(), n(5, "div", 23)(6, "app-control-container", 26), p(7, "dx-text-box", 27), i()(), n(8, "div", 23)(9, "app-control-container", 28), p(10, "dx-text-box", 29), i()(), n(11, "div", 30), p(12, "dx-check-box", 31), i(), n(13, "div", 32)(14, "dx-button", 33), _("onClick", function() {
            let a = g(e).$index,
                h = m(4);
            return C(h.removeTerminal(a))
        }), i()()()()
    }
    if (t & 2) {
        let e = c.$index,
            o = m(4);
        l("formGroupName", e), r(3), l("errorMsg", o.formatMessage("terminal_id_required"))("label", o.formatMessage("terminal_id_label")), r(), l("placeholder", o.formatMessage("terminal_id_placeholder")), r(2), l("errorMsg", o.formatMessage("terminal_name_required"))("label", o.formatMessage("terminal_name_label")), r(), l("placeholder", o.formatMessage("terminal_name_placeholder")), r(2), l("label", o.formatMessage("terminal_location_label")), r(), l("placeholder", o.formatMessage("terminal_location_placeholder")), r(2), l("text", o.formatMessage("active")), r(2), l("hint", o.formatMessage("remove_terminal"))
    }
}

function Lm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 14)(1, "h6", 19), s(2), i(), n(3, "div", 20), U(4, Am, 15, 11, "div", 21, Ee), i(), n(6, "dx-button", 22), _("onClick", function() {
            g(e);
            let a = m(3);
            return C(a.addTerminal())
        }), i()()
    }
    if (t & 2) {
        let e = m(3);
        r(2), x(e.formatMessage("card_machine_terminals")), r(2), W(e.terminals.controls), r(2), l("text", e.formatMessage("add_terminal"))
    }
}

function Dm(t, c) {
    if (t & 1 && p(0, "app-server-error", 18), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function Om(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 7), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "div", 8)(2, "app-control-container", 9), p(3, "dx-text-box", 10), i(), n(4, "div", 11)(5, "app-control-container", 12), p(6, "dx-text-box", 13), i(), d(7, Lm, 7, 2, "div", 14), i(), n(8, "app-control-container", 15), p(9, "dx-select-box", 16), i()(), n(10, "app-save-cancel-footer", 17), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i(), d(11, Dm, 1, 1, "app-server-error", 18), i()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("merchant_id_required"))("label", e.formatMessage("merchant_id_label")), r(), l("placeholder", e.formatMessage("merchant_id_label")), r(2), l("label", e.formatMessage("store_id_label")), r(), l("placeholder", e.formatMessage("store_id_placeholder")), r(), u(e.hasStoreId ? 7 : -1), r(), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 11 : -1)
    }
}

function Fm(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), d(4, Vm, 1, 2, "app-skeleton-loader", 5), d(5, Om, 12, 14, "form", 6), i()()()()), t & 2) {
        let e = m();
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}
var Za = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configurePhonePeCancelClick = Xe(), this.formService = v(B), this.toastNotificationService = v(N), this.fb = new z, this.isSaving = !1, this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.PHONE_PE,
                group: ze.PAYMENT,
                status: oe.ACTIVE
            })), this.addPhonePeConfigFields()
        }
        get terminals() {
            return this.form.get("config.terminals")
        }
        get hasStoreId() {
            return !!this.form.get("config.storeId") ? .value
        }
        addPhonePeConfigFields() {
            let e = this.form.get("config"),
                o = this.integration ? .config || {};
            e.contains("storeId") || e.addControl("storeId", this.fb.control(o.storeId || "")), e.contains("terminals") && e.removeControl("terminals"), e.addControl("terminals", this.fb.array([])), this.loadTerminals(o.terminals || []), this.form.get("config.storeId").valueChanges.subscribe(a => {
                a && this.terminals.length === 0 && this.addTerminal(), this.updateTerminalValidation()
            })
        }
        loadTerminals(e) {
            e.forEach(o => {
                this.terminals.push(this.createTerminalFormGroup(o))
            })
        }
        createTerminalFormGroup(e = {}) {
            let o = this.hasStoreId;
            return this.fb.group({
                terminalId: [e.terminalId || "", o ? [k.required] : []],
                name: [e.name || "", o ? [k.required] : []],
                location: [e.location || ""],
                isActive: [e.isActive !== void 0 ? e.isActive : !0]
            })
        }
        addTerminal() {
            this.terminals.push(this.createTerminalFormGroup()), this.updateTerminalValidation()
        }
        removeTerminal(e) {
            this.terminals.removeAt(e)
        }
        updateTerminalValidation() {
            let e = this.hasStoreId;
            this.terminals.controls.forEach(o => {
                let a = o.get("terminalId"),
                    h = o.get("name");
                e ? (a.setValidators([k.required]), h.setValidators([k.required])) : (a.clearValidators(), h.clearValidators()), a.updateValueAndValidity(), h.updateValueAndValidity()
            })
        }
        isFormValid() {
            return !(!this.form.valid || this.hasStoreId && this.terminals.length === 0)
        }
        save() {
            this.errorResponse = null, this.isFormValid() ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.isVisiblePopup = !1, this.toastNotificationService.success("phonepe_config_saved"), this.configurePhonePeCancelClick.emit(), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1
                }
            })) : (this.hasStoreId && this.terminals.length === 0 && this.toastNotificationService.warning("at_least_one_terminal_required"), this.formService.validateFormFields(this.form))
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configurePhonePeCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-phone-pe"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configurePhonePeCancelClick: "configurePhonePeCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 7,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "height", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-2"],
                    ["name", "api_key", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "api_key", 3, "placeholder"],
                    ["formGroupName", "config", 1, "col-12"],
                    ["name", "storeId", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "label"],
                    ["formControlName", "storeId", 3, "placeholder"],
                    [1, "col-12", "mb-3"],
                    ["name", "status", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"],
                    [1, "mb-3"],
                    ["formArrayName", "terminals"],
                    [1, "card", "mb-3", "p-3", 3, "formGroupName"],
                    ["icon", "add", "type", "default", "stylingMode", "outlined", 3, "onClick", "text"],
                    [1, "col-md-6", "mb-2"],
                    ["name", "terminalId", 3, "errorMsg", "label"],
                    ["formControlName", "terminalId", 3, "placeholder"],
                    ["name", "name", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["name", "location", 3, "label"],
                    ["formControlName", "location", 3, "placeholder"],
                    [1, "col-md-4", "mb-2", "d-flex", "align-items-center"],
                    ["formControlName", "isActive", 3, "text"],
                    [1, "col-md-2", "mb-2", "d-flex", "align-items-end", "justify-content-end"],
                    ["icon", "trash", "type", "danger", "stylingMode", "outlined", 3, "onClick", "hint"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, Fm, 6, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 700)("height", "auto")("title", a.formatMessage("configure_phonepe")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, F, G, _e, Mo, re, Ce, le, ae, V, L, P, A, D, Vi, Rn],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Rm(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 6), t & 2 && l("rows", 3)("columns", 1)
}

function Gm(t, c) {
    if (t & 1 && p(0, "app-server-error", 13), t & 2) {
        let e = m(4);
        l("errorResponse", e.errorResponse)
    }
}

function Um(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 8), _("ngSubmit", function() {
            g(e);
            let a = m(3);
            return C(a.save())
        }), n(1, "div", 9)(2, "app-control-container", 10), p(3, "dx-select-box", 11), i()(), n(4, "app-save-cancel-footer", 12), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.onClosing())
        }), i(), d(5, Gm, 1, 1, "app-server-error", 13), i()
    }
    if (t & 2) {
        let e = m(3);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 5 : -1)
    }
}

function Wm(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 3)(2, "div", 4)(3, "div", 5), d(4, Rm, 1, 2, "app-skeleton-loader", 6), d(5, Um, 6, 8, "form", 7), i()()()()), t & 2) {
        let e = m(2);
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}

function qm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-popup", 1), _("onHidden", function() {
            g(e);
            let a = m();
            return C(a.onClosing())
        }), X("visibleChange", function(a) {
            g(e);
            let h = m();
            return $(h.isVisiblePopup, a) || (h.isVisiblePopup = a), C(a)
        }), T(1, Wm, 6, 2, "div", 2), i()
    }
    if (t & 2) {
        let e = m();
        Z("visible", e.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", e.formatMessage("configure_quick_book")), r(), l("dxTemplateOf", "content")
    }
}
var $a = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.formService = v(B), this.toastNotificationService = v(N), this.router = v(ge), this.configureQuickBookCancelClick = Xe(), this.isSaving = !1, this.disabled = !0, this.isNotConfigured = ce(!0), this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                username: "quickbook_username",
                api_key: "quickbook_username_api_key",
                service_name: K.QUICK_BOOK,
                status: oe.ACTIVE
            }))
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.toastNotificationService.success("notification_quickbook_config_save_success"), this.integration ? .id ? this.router.navigate(["accounts/integrations/quickBooksConfig"]) : (this.isVisiblePopup = !1, this.configureQuickBookCancelClick.emit(), this.form = null)
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.onClosing()
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configureQuickBookCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-quick-book"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureQuickBookCancelClick: "configureQuickBookCancelClick"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "visible", "maxHeight", "width", "maxWidth", "title"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-2"],
                    ["name", "status", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"]
                ],
                template: function(o, a) {
                    o & 1 && d(0, qm, 2, 6, "dx-popup", 0), o & 2 && u(a.isNotConfigured() ? 0 : -1)
                },
                dependencies: [ee, j, O, F, G, re, Ce, le, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function jm(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 6), t & 2 && l("rows", 3)("columns", 1)
}

function zm(t, c) {
    if (t & 1 && p(0, "app-server-error", 16), t & 2) {
        let e = m(4);
        l("errorResponse", e.errorResponse)
    }
}

function Qm(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 8), _("ngSubmit", function() {
            g(e);
            let a = m(3);
            return C(a.save())
        }), n(1, "div", 9)(2, "app-control-container", 10), p(3, "dx-select-box", 11), i(), n(4, "app-control-container", 12), p(5, "dx-switch", 13), n(6, "span", 14), s(7), i()()(), n(8, "app-save-cancel-footer", 15), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.onClosing())
        }), i(), d(9, zm, 1, 1, "app-server-error", 16), i()
    }
    if (t & 2) {
        let e = m(3);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("gupshup_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("isLabelOnSameLine", !0), r(), l("value", !0), r(2), x(e.formatMessage("make_primary")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 9 : -1)
    }
}

function Ym(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 3)(2, "div", 4)(3, "div", 5), d(4, jm, 1, 2, "app-skeleton-loader", 6), d(5, Qm, 10, 11, "form", 7), i()()()()), t & 2) {
        let e = m(2);
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}

function Km(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-popup", 1), _("onHidden", function() {
            g(e);
            let a = m();
            return C(a.onClosing())
        }), X("visibleChange", function(a) {
            g(e);
            let h = m();
            return $(h.isVisiblePopup, a) || (h.isVisiblePopup = a), C(a)
        }), T(1, Ym, 6, 2, "div", 2), i()
    }
    if (t & 2) {
        let e = m();
        Z("visible", e.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", e.formatMessage("configure_gupshup")), r(), l("dxTemplateOf", "content")
    }
}
var Xa = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.toastNotificationService = v(N), this.configureGupshupCancelClick = Xe(), this.formService = v(B), this.tenantService = v(ie), this.isIndia = this.tenantService.isIndia(), this.isSaving = !1, this.disabled = !0, this.isNotConfigured = ce(!0), this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.GUPSHUP,
                group: ze.SMS,
                status: this.isIndia ? oe.ACTIVE : oe.INACTIVE
            }))
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.toastNotificationService.success("notification_gupshup_activate_success"), this.isVisiblePopup = !1, this.configureGupshupCancelClick.emit(), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.onClosing(), window.location.reload()
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configureGupshupCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-gupshup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureGupshupCancelClick: "configureGupshupCancelClick"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "visible", "maxHeight", "width", "maxWidth", "title"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-2"],
                    ["name", "status", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "is_primary", 1, "d-flex", "align-items-center", "justify-content-center", "gap-2", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_primary", 1, "align-middle", 3, "value"],
                    [1, "ms-2"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"]
                ],
                template: function(o, a) {
                    o & 1 && d(0, Km, 2, 6, "dx-popup", 0), o & 2 && u(a.isNotConfigured() ? 0 : -1)
                },
                dependencies: [ee, j, O, F, G, re, Ce, le, Be, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function $m(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 5), t & 2 && l("rows", 4)("columns", 1)
}

function Xm(t, c) {
    if (t & 1 && (n(0, "app-control-container", 14), p(1, "dx-text-box", 22), i()), t & 2) {
        let e = c.$implicit,
            o = m(3);
        l("errorMsg", o.formatMessage("from_mobile_required"))("label", e === "from_mobile" ? o.formatMessage("from_mobile_label") : "")("name", e), r(), l("formControlName", e)("placeholder", e === "from_mobile" ? o.formatMessage("enter_from_mobile_number") : "")
    }
}

function Jm(t, c) {
    if (t & 1 && p(0, "app-server-error", 21), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function ep(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 7), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "div", 8)(2, "app-control-container", 9), p(3, "dx-text-box", 10), i(), n(4, "app-control-container", 11), p(5, "dx-text-box", 12), i(), n(6, "span", 13), U(7, Xm, 2, 5, "app-control-container", 14, Ee), i(), n(9, "app-control-container", 15), p(10, "dx-select-box", 16), i(), n(11, "app-control-container", 17), p(12, "dx-switch", 18), n(13, "span", 19), s(14), i()()(), n(15, "app-save-cancel-footer", 20), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i(), d(16, Jm, 1, 1, "app-server-error", 21), i()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("twilio_sid_required"))("label", e.formatMessage("twilio_sid_label")), r(), l("placeholder", e.formatMessage("twilio_sid_label")), r(), l("errorMsg", e.formatMessage("twilio_auth_token_required"))("label", e.formatMessage("twilio_auth_token_label")), r(), l("placeholder", e.formatMessage("twilio_auth_token_label")), r(2), W(e.configKeys), r(2), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("isLabelOnSameLine", !0), r(), l("value", !0), r(2), x(e.formatMessage("make_primary")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 16 : -1)
    }
}

function tp(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), d(4, $m, 1, 2, "app-skeleton-loader", 5), d(5, ep, 17, 17, "form", 6), i()()()()), t & 2) {
        let e = m();
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}
var Ja = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configureTwilioCancelClick = new ue, this.formService = v(B), this.toastNotificationService = v(N), this.fb = new z, this.isSaving = !1, this.disabled = !0, this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        get configKeys() {
            let e = this.form.get("config");
            return Object.keys(e.controls)
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.TWILIO,
                group: ze.SMS,
                status: oe.ACTIVE
            })), this.addTwilioConfigFields()
        }
        addTwilioConfigFields() {
            let e = this.form.get("config"),
                o = this.integration ? .config || {};
            e.contains("from_mobile") || e.addControl("from_mobile", this.fb.control(o.mobile_number || "", []))
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.isVisiblePopup = !1, this.toastNotificationService.success("notification_twilio_config_save_success"), this.configureTwilioCancelClick.emit(), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1, window.location.reload()
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configureTwilioCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-twilio"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureTwilioCancelClick: "configureTwilioCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-5"],
                    ["name", "username", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "username", 3, "placeholder", "readOnly"],
                    ["name", "api_key", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "api_key", 3, "placeholder", "readOnly"],
                    ["formGroupName", "config", 1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [3, "errorMsg", "label", "name"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "is_primary", 1, "d-flex", "align-items-center", "justify-content-center", "gap-2", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_primary", 1, "align-middle", 3, "value"],
                    [1, "ms-2"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"],
                    [3, "readOnly", "formControlName", "placeholder"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, tp, 6, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 600)("title", a.formatMessage("configure_twilio")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, F, G, re, Ce, le, Be, ae, V, L, P, A, D, Vi],
                encapsulation: 2
            })
        }
    }
    return t
})();

function np(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 6), t & 2 && l("rows", 3)("columns", 1)
}

function op(t, c) {
    if (t & 1 && p(0, "app-server-error", 21), t & 2) {
        let e = m(4);
        l("errorResponse", e.errorResponse)
    }
}

function ap(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 8), _("ngSubmit", function() {
            g(e);
            let a = m(3);
            return C(a.save())
        }), n(1, "div", 9)(2, "app-control-container", 10), p(3, "dx-text-box", 11), i(), n(4, "app-control-container", 12), p(5, "dx-text-box", 13), i(), n(6, "div", 14)(7, "app-control-container", 15), p(8, "dx-select-box", 16), i(), n(9, "app-control-container", 17), p(10, "dx-switch", 18), n(11, "span", 19), s(12), i()()()(), n(13, "app-save-cancel-footer", 20), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.onClosing())
        }), i(), d(14, op, 1, 1, "app-server-error", 21), i()
    }
    if (t & 2) {
        let e = m(3);
        l("formGroup", e.form), r(2), l("errorMsg", e.formatMessage("application_id_required"))("label", e.formatMessage("bulkgate_application_id")), r(), l("placeholder", e.formatMessage("bulkgate_application_id")), r(), l("errorMsg", e.formatMessage("application_token_required"))("label", e.formatMessage("bulkgate_application_token")), r(), l("placeholder", e.formatMessage("bulkgate_application_token")), r(2), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("isLabelOnSameLine", !0), r(), l("value", !0), r(2), x(e.formatMessage("make_primary")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 14 : -1)
    }
}

function rp(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 3)(2, "div", 4)(3, "div", 5), d(4, np, 1, 2, "app-skeleton-loader", 6), d(5, ap, 15, 17, "form", 7), i()()()()), t & 2) {
        let e = m(2);
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}

function sp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-popup", 1), _("onHidden", function() {
            g(e);
            let a = m();
            return C(a.onClosing())
        }), X("visibleChange", function(a) {
            g(e);
            let h = m();
            return $(h.isVisiblePopup, a) || (h.isVisiblePopup = a), C(a)
        }), T(1, rp, 6, 2, "div", 2), i()
    }
    if (t & 2) {
        let e = m();
        Z("visible", e.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", e.formatMessage("configure_bulkgate")), r(), l("dxTemplateOf", "content")
    }
}
var er = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configureBulkGateCancelClick = new ue, this.toastNotificationService = v(N), this.formService = v(B), this.tenantService = v(ie), this.isSaving = !1, this.isNotConfigured = ce(!0), this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.BULKGATE,
                group: ze.SMS,
                status: oe.ACTIVE
            }))
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.toastNotificationService.success("bulkgate_sms_success"), this.isVisiblePopup = !1, this.configureBulkGateCancelClick.emit(), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.onClosing(), window.location.reload()
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configureBulkGateCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-bulkgate"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureBulkGateCancelClick: "configureBulkGateCancelClick"
                },
                standalone: !1,
                decls: 1,
                vars: 1,
                consts: [
                    [3, "visible", "maxHeight", "width", "maxWidth", "title"],
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-2"],
                    ["name", "username", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "username", 3, "placeholder", "readOnly"],
                    ["name", "api_key", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "api_key", 3, "placeholder", "readOnly"],
                    [1, "d-flex", "justify-content-between", "align-items-start"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    ["name", "is_primary", 1, "d-flex", "align-items-center", "justify-content-center", "gap-2", "me-2", 3, "isLabelOnSameLine"],
                    ["formControlName", "is_primary", 1, "align-middle", 3, "value"],
                    [1, "ms-2"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"]
                ],
                template: function(o, a) {
                    o & 1 && d(0, sp, 2, 6, "dx-popup", 0), o & 2 && u(a.isNotConfigured() ? 0 : -1)
                },
                dependencies: [ee, j, O, F, G, re, Ce, le, Be, ae, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Tn = class {
        _document;
        _textarea;
        constructor(c, e) {
            this._document = e;
            let o = this._textarea = this._document.createElement("textarea"),
                a = o.style;
            a.position = "fixed", a.top = a.opacity = "0", a.left = "-999em", o.setAttribute("aria-hidden", "true"), o.value = c, o.readOnly = !0, (this._document.fullscreenElement || this._document.body).appendChild(o)
        }
        copy() {
            let c = this._textarea,
                e = !1;
            try {
                if (c) {
                    let o = this._document.activeElement;
                    c.select(), c.setSelectionRange(0, c.value.length), e = this._document.execCommand("copy"), o && o.focus()
                }
            } catch (o) {}
            return e
        }
        destroy() {
            let c = this._textarea;
            c && (c.remove(), this._textarea = void 0)
        }
    },
    tr = (() => {
        class t {
            _document = v(Mn);
            constructor() {}
            copy(e) {
                let o = this.beginCopy(e),
                    a = o.copy();
                return o.destroy(), a
            }
            beginCopy(e) {
                return new Tn(e, this._document)
            }
            static\ u0275fac = function(o) {
                return new(o || t)
            };
            static\ u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
        return t
    })();

function cp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 8)(1, "div", 14), p(2, "i", 15), n(3, "span"), s(4), i()(), n(5, "label", 16), s(6), i(), n(7, "div", 17), p(8, "input", 18), n(9, "button", 19), _("click", function() {
            g(e);
            let a = m(3);
            return C(a.copyToClipboard(a.plainApiKey, "zapier_api_key_copied"))
        }), p(10, "i", 20), i()()()
    }
    if (t & 2) {
        let e = m(3);
        r(4), x(e.formatMessage("zapier_api_key_warning")), r(2), x(e.formatMessage("zapier_api_key_label")), r(2), l("value", e.plainApiKey)
    }
}

function mp(t, c) {
    if (t & 1 && (n(0, "div", 8)(1, "label", 16), s(2), i(), n(3, "div", 21), s(4), i()()), t & 2) {
        let e = m(3);
        r(2), x(e.formatMessage("zapier_api_key_label")), r(2), E(" ", e.integration.masked_api_key || "************************************", " ")
    }
}

function pp(t, c) {
    if (t & 1 && (n(0, "div", 8)(1, "div", 22), p(2, "i", 23), s(3), i()()), t & 2) {
        let e = m(3);
        r(3), E(" ", e.formatMessage("zapier_key_not_generated"), " ")
    }
}

function dp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 8)(1, "label", 16), s(2), i(), n(3, "div", 17), p(4, "input", 24), n(5, "button", 19), _("click", function() {
            g(e);
            let a = m(3);
            return C(a.copyToClipboard(a.webhookUrl, "zapier_webhook_url_copied"))
        }), p(6, "i", 20), i()()()
    }
    if (t & 2) {
        let e = m(3);
        r(2), x(e.formatMessage("zapier_webhook_url_label")), r(2), l("value", e.webhookUrl)
    }
}

function up(t, c) {
    if (t & 1 && (n(0, "div", 8)(1, "label", 16), s(2), i(), n(3, "pre", 25), s(4), i()()), t & 2) {
        let e = m(3);
        r(2), x(e.formatMessage("zapier_example_payload")), r(2), x(e.examplePayload)
    }
}

function _p(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 26), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.onClosing())
        }), i()
    }
    if (t & 2) {
        let e = m(3);
        l("isOnPopup", !0)("isSaving", e.isSaving)
    }
}

function fp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 12)(1, "dx-button", 27), _("onClick", function() {
            g(e);
            let a = m(3);
            return C(a.onClosing())
        }), i()()
    }
    if (t & 2) {
        let e = m(3);
        r(), l("text", e.formatMessage("close"))
    }
}

function gp(t, c) {
    if (t & 1 && p(0, "app-server-error", 13), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function Cp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 6), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "div", 7), d(2, cp, 11, 3, "div", 8), d(3, mp, 5, 2, "div", 8), d(4, pp, 4, 1, "div", 8), d(5, dp, 7, 2, "div", 8), d(6, up, 5, 2, "div", 8), n(7, "app-control-container", 9), p(8, "dx-select-box", 10), i()(), d(9, _p, 1, 2, "app-save-cancel-footer", 11)(10, fp, 2, 1, "div", 12), d(11, gp, 1, 1, "app-server-error", 13), i()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(2), u(e.plainApiKey ? 2 : -1), r(), u(e.isExistingIntegration && !e.plainApiKey ? 3 : -1), r(), u(!e.isExistingIntegration && !e.plainApiKey ? 4 : -1), r(), u(e.isExistingIntegration || e.plainApiKey ? 5 : -1), r(), u(e.isExistingIntegration || e.plainApiKey ? 6 : -1), r(), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), u(e.plainApiKey ? 10 : 9), r(2), u(e.errorResponse ? 11 : -1)
    }
}

function vp(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), d(4, Cp, 12, 12, "form", 5), i()()()()), t & 2) {
        let e = m();
        r(4), u(e.form ? 4 : -1)
    }
}
var ir = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configureZapierCancelClick = new ue, this.formService = v(B), this.toastNotificationService = v(N), this.clipboard = v(tr), this.isSaving = !1, this.serviceStatusList = Object.values(oe), this.errorResponse = null, this.plainApiKey = null
        }
        ngOnInit() {
            let e = window.location.hostname.split(".")[0];
            this.webhookUrl = `${Li}${e}/zapier/self-checkin`, this.examplePayload = JSON.stringify({
                name: "John Doe",
                email: "john@example.com",
                mobile_number: "+1234567890",
                device_type: "Laptop",
                device_brand: "Dell",
                device_model: "XPS 15",
                serial_number: "ABC123",
                comment: "Screen not working",
                is_pickup_booked: !0,
                custom_fields: {
                    warranty_status: "Expired",
                    urgency: "High"
                }
            }, null, 2), this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.ZAPIER,
                group: ze.FORM,
                status: oe.ACTIVE
            }))
        }
        get isExistingIntegration() {
            return !!this.integration ? .id
        }
        save() {
            if (this.errorResponse = null, this.form.valid) {
                this.isSaving = !0;
                let e = this.isExistingIntegration;
                (e ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                    next: a => {
                        this.integration = new te(a), !e && a.plain_api_key ? (this.plainApiKey = a.plain_api_key, this.toastNotificationService.success("notification_zapier_config_save_success"), this.form.patchValue({
                            id: a.id
                        })) : (this.isVisiblePopup = !1, this.toastNotificationService.success("notification_zapier_config_save_success"), this.configureZapierCancelClick.emit(), this.form = null)
                    },
                    error: a => {
                        this.errorResponse = a
                    },
                    complete: () => {
                        this.isSaving = !1
                    }
                })
            } else this.formService.validateFormFields(this.form)
        }
        copyToClipboard(e, o) {
            this.clipboard.copy(e), this.toastNotificationService.success(o)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.plainApiKey = null, this.configureZapierCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-zapier"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureZapierCancelClick: "configureZapierCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-12", "mb-3"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    [3, "isOnPopup", "isSaving"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "errorResponse"],
                    ["role", "alert", 1, "alert", "alert-warning", "d-flex", "align-items-center"],
                    [1, "fa-solid", "fa-triangle-exclamation", "me-2"],
                    [1, "form-label", "fw-bold"],
                    [1, "input-group"],
                    ["type", "text", "readonly", "", 1, "form-control", "font-monospace", 3, "value"],
                    ["type", "button", 1, "btn", "btn-outline-secondary", 3, "click"],
                    [1, "fa-regular", "fa-copy"],
                    [1, "alert", "alert-secondary", "font-monospace", "mb-0"],
                    ["role", "alert", 1, "alert", "alert-info"],
                    [1, "fa-solid", "fa-circle-info", "me-2"],
                    ["type", "text", "readonly", "", 1, "form-control", "font-monospace", "small", 3, "value"],
                    [1, "bg-light", "p-3", "rounded", "border", "small", 2, "max-height", "200px", "overflow-y", "auto"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    ["type", "default", "stylingMode", "outlined", 3, "onClick", "text"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, vp, 5, 1, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("width", "95vw")("maxWidth", 650)("title", a.formatMessage("configure_zapier")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, G, _e, re, Ce, le, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function xp(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 5), t & 2 && l("rows", 4)("columns", 1)
}

function Sp(t, c) {
    if (t & 1 && (n(0, "div", 9)(1, "div", 17), p(2, "i", 18), n(3, "span"), s(4), n(5, "strong"), s(6), i()()()()), t & 2) {
        let e = m(3);
        r(4), E("", e.formatMessage("meta_lead_ads_connected_to"), " "), r(2), x(e.connectedPageName)
    }
}

function bp(t, c) {
    if (t & 1 && p(0, "app-server-error", 16), t & 2) {
        let e = m(3);
        l("errorResponse", e.errorResponse)
    }
}

function yp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 7), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), n(1, "div", 8)(2, "div", 9)(3, "div", 10), p(4, "i", 11), s(5), i()(), d(6, Sp, 7, 2, "div", 9), n(7, "div", 9)(8, "dx-button", 12), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.connectFacebook())
        }), i()(), n(9, "app-control-container", 13), p(10, "dx-select-box", 14), i()(), n(11, "app-save-cancel-footer", 15), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onClosing())
        }), i(), d(12, bp, 1, 1, "app-server-error", 16), i()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(5), E(" ", e.formatMessage("meta_lead_ads_description"), " "), r(), u(e.isConnected ? 6 : -1), r(2), l("text", e.isConnected ? e.formatMessage("meta_lead_ads_reconnect") : e.formatMessage("meta_lead_ads_connect_facebook"))("disabled", e.isConnecting), r(), l("errorMsg", e.formatMessage("common_error_messages_status_required"))("label", e.formatMessage("label_service_status")), r(), l("items", e.serviceStatusList)("placeholder", e.formatMessage("common_select_status")), r(), l("isOnPopup", !0)("isSaving", e.isSaving), r(), u(e.errorResponse ? 12 : -1)
    }
}

function Tp(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), d(4, xp, 1, 2, "app-skeleton-loader", 5), d(5, yp, 13, 12, "form", 6), i()()()()), t & 2) {
        let e = m();
        r(4), u(e.form ? -1 : 4), r(), u(e.form ? 5 : -1)
    }
}
var nr = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configureMetaLeadAdsCancelClick = new ue, this.formService = v(B), this.toastNotificationService = v(N), this.fb = new z, this.isSaving = !1, this.isConnecting = !1, this.serviceStatusList = Object.values(oe), this.errorResponse = null
        }
        ngOnInit() {
            this.form = te.getForm(new te(this.integration ? .id ? this.integration : {
                service_name: K.META_LEAD_ADS,
                group: ze.LEAD_GENERATION,
                status: oe.ACTIVE
            })), this.addMetaConfigFields()
        }
        addMetaConfigFields() {
            let e = this.form.get("config"),
                o = this.integration ? .config || {};
            e.contains("page_id") || e.addControl("page_id", this.fb.control(o.page_id || "", [])), e.contains("page_name") || e.addControl("page_name", this.fb.control(o.page_name || "", []))
        }
        get isConnected() {
            return !!this.integration ? .config ? .page_id
        }
        get connectedPageName() {
            return this.integration ? .config ? .page_name || ""
        }
        connectFacebook() {
            this.isConnecting = !0;
            let e = localStorage.getItem("token");
            if (!e) {
                this.toastNotificationService.error("please_login_first"), this.isConnecting = !1;
                return
            }
            let o = `${Li}auth/meta/redirect?token=${encodeURIComponent(e)}`;
            window.location.href = o
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.integration ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.integration = new te(o), this.isVisiblePopup = !1, this.toastNotificationService.success("meta_lead_ads_config_save_success"), this.configureMetaLeadAdsCancelClick.emit(), this.form = null
                },
                error: o => {
                    this.errorResponse = o
                },
                complete: () => {
                    this.isSaving = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.integration = null, this.configureMetaLeadAdsCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-meta-lead-ads"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup",
                    integration: "integration"
                },
                outputs: {
                    configureMetaLeadAdsCancelClick: "configureMetaLeadAdsCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-5"],
                    [1, "col-12", "mb-3"],
                    ["role", "alert", 1, "alert", "alert-info"],
                    [1, "fa-brands", "fa-facebook", "me-2"],
                    ["icon", "fa-brands fa-facebook", "type", "default", "stylingMode", "contained", 1, "w-100", 3, "onClick", "text", "disabled"],
                    ["name", "status", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "status", "searchMode", "contains", 3, "items", "placeholder"],
                    [3, "cancelClick", "isOnPopup", "isSaving"],
                    [3, "errorResponse"],
                    ["role", "alert", 1, "alert", "alert-success", "d-flex", "align-items-center"],
                    [1, "fa-solid", "fa-circle-check", "me-2"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, Tp, 6, 2, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 600)("title", a.formatMessage("configure_meta_lead_ads")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, F, G, _e, re, Ce, le, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function wp(t, c) {
    if (t & 1 && (n(0, "div", 8), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.formatMessage("token_valid"))
    }
}

function Ip(t, c) {
    if (t & 1 && (n(0, "div", 9), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.formatMessage("token_expired_will_refresh"))
    }
}

function kp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 5), p(1, "i", 6), n(2, "div")(3, "strong"), s(4), i(), n(5, "div", 7), s(6), i(), d(7, wp, 2, 1, "div", 8)(8, Ip, 2, 1, "div", 9), i()(), n(9, "div", 10)(10, "dx-button", 11), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.disconnect())
        }), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(4), x(e.formatMessage("connected")), r(2), x(e.connectedEmail), r(), u(e.tokenValid ? 7 : 8), r(3), l("text", e.formatMessage("disconnect"))("disabled", e.isDisconnecting)
    }
}

function Mp(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 12), t & 2 && l("rows", 3)("columns", 1)
}

function Np(t, c) {
    if (t & 1 && p(0, "app-server-error", 24), t & 2) {
        let e = m(4);
        l("errorResponse", e.errorResponse)
    }
}

function Pp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 14), _("ngSubmit", function() {
            g(e);
            let a = m(3);
            return C(a.connect())
        }), n(1, "div", 15), p(2, "img", 16), i(), n(3, "div", 17)(4, "app-control-container", 18), p(5, "dx-text-box", 19), i(), n(6, "app-control-container", 20), p(7, "dx-text-box", 21), i()(), n(8, "div", 22), s(9), i(), n(10, "app-save-cancel-footer", 23), _("cancelClick", function() {
            g(e);
            let a = m(3);
            return C(a.onClosing())
        }), i(), d(11, Np, 1, 1, "app-server-error", 24), i()
    }
    if (t & 2) {
        let e = m(3);
        l("formGroup", e.form), r(4), l("errorMsg", e.formatMessage("common_error_messages_email_required"))("label", e.formatMessage("common_email")), r(), l("placeholder", e.formatMessage("shiprocket_email_placeholder")), r(), l("errorMsg", e.formatMessage("common_error_messages_password_required"))("label", e.formatMessage("common_password")), r(), l("placeholder", e.formatMessage("shiprocket_password_placeholder")), r(2), E(" ", e.formatMessage("shiprocket_credentials_note"), " "), r(), l("isOnPopup", !0)("isSaving", e.isConnecting)("saveText", "connect"), r(), u(e.errorResponse ? 11 : -1)
    }
}

function Vp(t, c) {
    if (t & 1 && (d(0, Mp, 1, 2, "app-skeleton-loader", 12), d(1, Pp, 12, 12, "form", 13)), t & 2) {
        let e = m(2);
        u(e.form ? -1 : 0), r(), u(e.form ? 1 : -1)
    }
}

function Ap(t, c) {
    if (t & 1 && (n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "div", 4), d(4, kp, 11, 5)(5, Vp, 2, 2), i()()()()), t & 2) {
        let e = m();
        r(4), u(e.isConnected ? 4 : 5)
    }
}
var or = (() => {
    class t {
        constructor(e) {
            this.shippingService = e, this.formatMessage = f, this.isVisiblePopup = !1, this.configureShippingCancelClick = Xe(), this.toastNotificationService = v(N), this.formService = v(B), this.isConnecting = !1, this.isDisconnecting = !1, this.isConnected = !1, this.connectedEmail = null, this.tokenExpiresAt = null, this.tokenValid = !1, this.errorResponse = null, this.fb = v(z)
        }
        ngOnInit() {
            this.form = this.fb.group({
                provider: ["shiprocket"],
                email: ["", [k.required, k.email]],
                password: ["", [k.required]]
            }), this.fetchStatus()
        }
        fetchStatus() {
            this.shippingService.getProviderStatus().subscribe({
                next: e => {
                    this.isConnected = e.connected, this.connectedEmail = e.username, this.tokenExpiresAt = e.token_expires_at, this.tokenValid = e.token_valid
                }
            })
        }
        connect() {
            this.errorResponse = null, this.form.valid ? (this.isConnecting = !0, this.shippingService.connectProvider(this.form.value).subscribe({
                next: () => {
                    this.toastNotificationService.success("shipping_connected_success"), this.isConnected = !0, this.connectedEmail = this.form.get("email").value, this.tokenValid = !0, this.isConnecting = !1, this.fetchStatus()
                },
                error: e => {
                    this.errorResponse = e, this.isConnecting = !1
                }
            })) : this.formService.validateFormFields(this.form)
        }
        disconnect() {
            this.isDisconnecting = !0, this.shippingService.disconnectProvider().subscribe({
                next: () => {
                    this.toastNotificationService.success("shipping_disconnected_success"), this.isConnected = !1, this.connectedEmail = null, this.tokenExpiresAt = null, this.tokenValid = !1, this.isDisconnecting = !1
                },
                error: e => {
                    this.errorResponse = e, this.isDisconnecting = !1
                }
            })
        }
        onClosing() {
            this.form = null, this.isVisiblePopup = !1, this.configureShippingCancelClick.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(ma))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-configure-shipping"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    configureShippingCancelClick: "configureShippingCancelClick"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "row"],
                    [1, "col-12"],
                    ["role", "alert", 1, "alert", "alert-success", "d-flex", "align-items-center"],
                    [1, "fa-solid", "fa-circle-check", "me-2"],
                    [1, "small"],
                    [1, "small", "text-success"],
                    [1, "small", "text-warning"],
                    [1, "d-flex", "justify-content-end", "mt-3"],
                    ["type", "danger", "stylingMode", "outlined", 3, "onClick", "text", "disabled"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    [1, "mb-3", "text-center"],
                    ["src", "assets/integration-images/shiprocket-logo.jpg", "alt", "Shiprocket", "loading", "lazy", 1, "img-fluid", 2, "height", "40px"],
                    [1, "row", "mb-2"],
                    ["name", "email", 1, "col-12", 3, "errorMsg", "label"],
                    ["formControlName", "email", 3, "placeholder"],
                    ["name", "password", 1, "col-12", 3, "errorMsg", "label"],
                    ["formControlName", "password", "mode", "password", 3, "placeholder"],
                    [1, "small", "text-muted", "mb-3"],
                    [3, "cancelClick", "isOnPopup", "isSaving", "saveText"],
                    [3, "errorResponse"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, Ap, 6, 1, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", a.formatMessage("configure_shipping")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ee, j, O, F, G, _e, re, Ce, ae, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Dp(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 4), t & 2 && l("rows", 3)("columns", 1)
}

function Op(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 6), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.requestIntegrationAccess())
        }), n(1, "app-control-container", 7), p(2, "dx-text-area", 8), i(), n(3, "app-save-cancel-footer", 9), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.onPopupClosing())
        })("saveClick", function() {
            g(e);
            let a = m(2);
            return C(a.requestIntegrationAccess())
        }), i()()
    }
    if (t & 2) {
        let e = m(2);
        l("formGroup", e.form), r(), l("errorMsg", e.formatMessage("request_for_integrations_is_a_required_field"))("label", e.formatMessage("request_for_integrations_label")), r(), l("autoResizeEnabled", !0)("placeholder", e.formatMessage("type_text_here")), r(), l("isOnPopup", !0)("isSaving", e.isSaving())("saveText", "request_for_integrations_send_request")
    }
}

function Fp(t, c) {
    if (t & 1 && (n(0, "div")(1, "div", 2)(2, "div", 3), d(3, Dp, 1, 2, "app-skeleton-loader", 4), d(4, Op, 4, 8, "form", 5), i()()()), t & 2) {
        let e = m();
        r(3), u(e.form ? -1 : 3), r(), u(e.form ? 4 : -1)
    }
}
var rr = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.formService = v(B), this.commonService = v(vt), this.toastNotificationService = v(N), this.userSessionService = v(tt), this.currentUser = this.userSessionService.currentUser(), this.fb = new z, this.isSaving = ce(!1), this.requestIntegrationPopupDisplay = Pn(!1)
        }
        ngOnInit() {
            this.form = this.fb.group({
                user_id: this.currentUser ? .id,
                integrationName: this.integrationName
            })
        }
        requestIntegrationAccess() {
            this.isSaving.update(() => !0), this.commonService.requestIntegration(this.form.value).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_request_submit_success"), this.requestIntegrationPopupDisplay.set(!1)
                },
                error: e => {
                    console.error(e), this.toastNotificationService.error("error_integration_request")
                },
                complete: () => {
                    this.isSaving.set(!1)
                }
            })
        }
        updatePopupDisplay() {
            this.requestIntegrationPopupDisplay.set(!1)
        }
        onPopupClosing() {
            this.updatePopupDisplay(), this.form.reset()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-request-new-integration-popup"]
                ],
                inputs: {
                    requestIntegrationPopupDisplay: [1, "requestIntegrationPopupDisplay"]
                },
                outputs: {
                    requestIntegrationPopupDisplay: "requestIntegrationPopupDisplayChange"
                },
                standalone: !1,
                decls: 2,
                vars: 5,
                consts: [
                    [3, "onHidden", "visible", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "row"],
                    [1, "container"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "integrationName", 1, "col-sm-12", "col-md-12", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "integrationName", "id", "integrationName", "maxHeight", "100", "minHeight", "60", 1, "pt-1", 3, "autoResizeEnabled", "placeholder"],
                    ["icon", "email", 3, "cancelClick", "saveClick", "isOnPopup", "isSaving", "saveText"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onPopupClosing()
                    }), T(1, Fp, 5, 2, "div", 1), i()), o & 2 && (l("visible", a.requestIntegrationPopupDisplay())("width", "95vw")("maxWidth", 500)("title", a.formatMessage("request_for_integrations_popup_title")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [j, O, F, G, re, ti, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Rp = (t, c) => c.title;

function Gp(t, c) {
    if (t & 1 && (n(0, "span", 24), s(1), i()), t & 2) {
        let e = m(4);
        r(), x(e.formatMessage("is_active"))
    }
}

function Up(t, c) {
    if (t & 1 && (n(0, "span", 25), s(1), i()), t & 2) {
        let e = m(4);
        r(), x(e.formatMessage("inactive"))
    }
}

function Wp(t, c) {
    if (t & 1 && (n(0, "div", 27), p(1, "i", 28), n(2, "div"), s(3), i()()), t & 2) {
        let e = m(4);
        r(3), E(" ", e.formatMessage("common_primary"), " ")
    }
}

function qp(t, c) {
    if (t & 1 && (n(0, "div", 23), d(1, Gp, 2, 1, "span", 24)(2, Up, 2, 1, "span", 25), i(), n(3, "div", 26), d(4, Wp, 4, 1, "div", 27), i()), t & 2) {
        let e = m(2).$implicit,
            o = m();
        r(), u(o.checkIntegrationStatus(e.title) ? 1 : 2), r(3), u(o.checkPrimaryIntegration(e.title) ? 4 : -1)
    }
}

function Hp(t, c) {
    if (t & 1 && (n(0, "div", 17), s(1), i()), t & 2) {
        let e = m(3);
        l("title", e.selectedIntegrationForStatus.masked_api_key || e.formatMessage("connected")), r(), E(" ", e.selectedIntegrationForStatus.masked_api_key || e.formatMessage("connected"), " ")
    }
}

function jp(t, c) {
    if (t & 1 && (n(0, "div", 18), s(1), i()), t & 2) {
        let e = m(3);
        r(), E(" ", e.formatMessage("key_not_configured"), " ")
    }
}

function zp(t, c) {
    t & 1 && p(0, "app-dx-outline-button", 21)
}

function Qp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 10)(1, "div", 11)(2, "div", 12), d(3, qp, 5, 2), n(4, "div", 13), p(5, "img", 14), i(), n(6, "h5", 15), s(7), i(), n(8, "p", 16), s(9), i(), d(10, Hp, 2, 2, "div", 17)(11, jp, 2, 1, "div", 18), n(12, "div", 19)(13, "app-dx-outline-button", 20), _("onClickEvent", function() {
            g(e);
            let a = m().$implicit,
                h = m();
            return C(h.openIntegrationPopup(a.title))
        }), i(), d(14, zp, 1, 0, "app-dx-outline-button", 21), n(15, "app-dx-outline-button", 22), _("onClickEvent", function() {
            g(e);
            let a = m().$implicit,
                h = m();
            return C(h.openBlog(a.blogLink))
        }), i()()()()()
    }
    if (t & 2) {
        let e = m().$implicit,
            o = m();
        r(3), u(o.integrations.length > 0 ? 3 : -1), r(2), l("src", e.src, je)("alt", e.title)("ngStyle", e.cssStyle), r(2), x(e.title), r(2), x(o.formatMessage(e.text)), r(), u(o.checkIntegrationStatus(e.title) ? 10 : 11), r(3), l("text", e == null ? null : e.buttonTitle)("title", e == null ? null : e.buttonTitle)("disabled", e == null ? null : e.disabled), r(), u((o.selectedIntegrationForStatus == null ? null : o.selectedIntegrationForStatus.status) === o.INTEGRATION_STATUS_LIST.ACTIVE && e.title === o.INTEGRATION_LIST.QUICK_BOOK ? 14 : -1), r(), l("text", e == null ? null : e.blogButtonName)
    }
}

function Yp(t, c) {
    if (t & 1 && d(0, Qp, 16, 12, "div", 10), t & 2) {
        let e = c.$implicit;
        u(e.isVisible ? 0 : -1)
    }
}

function Kp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-request-new-integration-popup", 29), X("requestIntegrationPopupDisplayChange", function(a) {
            g(e);
            let h = m();
            return $(h.isVisibleRequestIntegrationPopup, a) || (h.isVisibleRequestIntegrationPopup = a), C(a)
        }), i()
    }
    if (t & 2) {
        let e = m();
        Z("requestIntegrationPopupDisplay", e.isVisibleRequestIntegrationPopup)
    }
}

function Zp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-mailchimp", 30), _("configureMailChimpCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleConfigureMailChimpPopup)("integration", e.selectedIntegration)
    }
}

function $p(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-phone-pe", 31), _("configurePhonePeCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleConfigurePhonePePopup)("integration", e.selectedIntegration)
    }
}

function Xp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-quick-book", 32), _("configureQuickBookCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleConfigureQuickBook)("integration", e.selectedIntegration)
    }
}

function Jp(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-gupshup", 33), _("configureGupshupCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleGupshupConfigPopup)("integration", e.selectedIntegration)
    }
}

function ed(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-twilio", 34), _("configureTwilioCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleTwilioConfigPopup)("integration", e.selectedIntegration)
    }
}

function td(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-bulkgate", 35), _("configureBulkGateCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleBulkGateConfigPopup)("integration", e.selectedIntegration)
    }
}

function id(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-zapier", 36), _("configureZapierCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleConfigureZapierPopup)("integration", e.selectedIntegration)
    }
}

function nd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-meta-lead-ads", 37), _("configureMetaLeadAdsCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleMetaLeadAdsConfigPopup)("integration", e.selectedIntegration)
    }
}

function od(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-configure-shipping", 38), _("configureShippingCancelClick", function() {
            g(e);
            let a = m();
            return C(a.closeIntegrationPopUp())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleShiprocketConfigPopup)
    }
}
var sr = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.ENTITIES = Q, this.authorizationService = v(ht), this.toastNotificationService = v(N), this.tenantService = v(ie), this.nativeLinkService = v(go), this.isIndia = this.tenantService.isIndia(), this.isVisibleConfigureMailChimpPopup = !1, this.isVisibleConfigureStripePopup = !1, this.isVisibleConfigurePhonePePopup = !1, this.isVisibleConfigureQuickBook = !1, this.isVisibleGupshupConfigPopup = !1, this.isVisibleTwilioConfigPopup = !1, this.isVisibleBulkGateConfigPopup = !1, this.isVisibleConfigureZapierPopup = !1, this.isVisibleMetaLeadAdsConfigPopup = !1, this.isVisibleShiprocketConfigPopup = !1, this.integrations = [], this.integrationsCards = [{
                src: "assets/integration-images/mailchimp-logo.svg",
                title: K.MAILCHIMP,
                text: "mailchimp_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !this.authorizationService.canAccess(this.ENTITIES.MAIL_MARKETING),
                isVisible: ![H.BASIC, H.LITE].includes(this.authorizationService.tenantPlan()),
                cssStyle: {},
                blogLink: "http://bytephase.com/blog/how-to-set-up-mailchimp-for-email-marketing-and-integrate-it-with-bytephase-crm/"
            }, {
                src: "assets/integration-images/phonepe-logo.svg",
                title: K.PHONE_PE,
                text: "phone_pe_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !this.authorizationService.canAccess(this.ENTITIES.COLLECT_PAYMENT),
                isVisible: ![H.BASIC, H.LITE].includes(this.authorizationService.tenantPlan()),
                cssStyle: {
                    height: "40px"
                },
                blogLink: "https://bytephase.com/blog/phonepe-bytephase-integration/"
            }, {
                src: "assets/integration-images/quickbook-logo.svg",
                title: K.QUICK_BOOK,
                text: "quick_book_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !this.authorizationService.canAccess(this.ENTITIES.COLLECT_PAYMENT),
                isVisible: ![H.BASIC, H.LITE].includes(this.authorizationService.tenantPlan()),
                cssStyle: {
                    height: "40px"
                },
                blogLink: "https://bytephase.com/blog/how-to-integrate-quickbook-in-bytephase-portal/"
            }, {
                src: "assets/integration-images/gupshup-logo.svg",
                title: K.GUPSHUP,
                text: "gupshup_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !this.isIndia,
                isVisible: !0,
                cssStyle: {
                    height: "40px"
                },
                blogLink: "https://bytephase.com/blog/integrate-gupshup-sms-bytephase/"
            }, {
                src: "assets/integration-images/twilio-logo.svg",
                title: K.TWILIO,
                text: "twilio_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !1,
                isVisible: !0,
                cssStyle: {
                    height: "40px"
                },
                blogLink: "https://bytephase.com/blog/integrate-twilio-sms-bytephase/"
            }, {
                src: "assets/integration-images/bulkgate-logo.jpg",
                title: K.BULKGATE,
                text: "bulkgate_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !1,
                isVisible: !0,
                cssStyle: {
                    height: "40px"
                },
                blogLink: ""
            }, {
                src: "assets/integration-images/zapier-logo.svg",
                title: K.ZAPIER,
                text: "zapier_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !1,
                isVisible: !0,
                cssStyle: {
                    height: "25px"
                },
                blogLink: ""
            }, {
                src: "assets/integration-images/meta-logo.svg",
                title: K.META_LEAD_ADS,
                text: "meta_lead_ads_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !1,
                isVisible: !0,
                cssStyle: {
                    height: "40px"
                },
                blogLink: ""
            }, {
                src: "assets/integration-images/shiprocket-logo.jpg",
                title: K.SHIPROCKET,
                text: "shiprocket_text",
                buttonTitle: "configure",
                blogButtonName: "view_blog",
                disabled: !1,
                isVisible: this.isIndia,
                cssStyle: {
                    height: "80px"
                },
                blogLink: ""
            }], this.INTEGRATION_STATUS_LIST = oe, this.INTEGRATION_LIST = K, this.isVisibleRequestIntegrationPopup = ce(!1), this.route = v(De), this.router = v(ge)
        }
        ngOnInit() {
            this.fetchIntegrations(), this.handleMetaOAuthCallback()
        }
        handleMetaOAuthCallback() {
            this.route.queryParams.subscribe(e => {
                if (e.meta_connected === "true") {
                    let o = e.page_name || "";
                    this.toastNotificationService.success("meta_lead_ads_connected_success"), this.fetchIntegrations(), this.cleanQueryParams()
                } else e.meta_error && (this.toastNotificationService.error(e.meta_error), this.cleanQueryParams())
            })
        }
        cleanQueryParams() {
            this.router.navigate([], {
                relativeTo: this.route,
                queryParams: {},
                replaceUrl: !0
            })
        }
        openIntegrationPopup(e) {
            switch (this.selectedIntegration = this.integrations.find(o => o.service_name === e), e) {
                case K.MAILCHIMP:
                    return this.isVisibleConfigureMailChimpPopup = !this.isVisibleConfigureMailChimpPopup;
                case K.STRIPE:
                    return this.isVisibleConfigureStripePopup = !this.isVisibleConfigureStripePopup;
                case K.PHONE_PE:
                    return this.isVisibleConfigurePhonePePopup = !this.isVisibleConfigurePhonePePopup;
                case K.QUICK_BOOK:
                    return this.isVisibleConfigureQuickBook = !this.isVisibleConfigureQuickBook;
                case K.GUPSHUP:
                    return this.isVisibleGupshupConfigPopup = !this.isVisibleGupshupConfigPopup;
                case K.TWILIO:
                    return this.isVisibleTwilioConfigPopup = !this.isVisibleTwilioConfigPopup;
                case K.BULKGATE:
                    return this.isVisibleBulkGateConfigPopup = !this.isVisibleBulkGateConfigPopup;
                case K.ZAPIER:
                    return this.isVisibleConfigureZapierPopup = !this.isVisibleConfigureZapierPopup;
                case K.META_LEAD_ADS:
                    return this.isVisibleMetaLeadAdsConfigPopup = !this.isVisibleMetaLeadAdsConfigPopup;
                case K.SHIPROCKET:
                    return this.isVisibleShiprocketConfigPopup = !this.isVisibleShiprocketConfigPopup;
                default:
                    return null
            }
        }
        checkIntegrationStatus(e) {
            return this.selectedIntegrationForStatus = this.integrations.find(o => o.service_name === e), this.selectedIntegrationForStatus ? .status === oe.ACTIVE
        }
        checkPrimaryIntegration(e) {
            return this.integrations.find(a => a.service_name === e) ? .is_primary
        }
        closeIntegrationPopUp() {
            this.isVisibleConfigureMailChimpPopup = !1, this.isVisibleConfigureQuickBook = !1, this.isVisibleConfigurePhonePePopup = !1, this.isVisibleGupshupConfigPopup = !1, this.isVisibleTwilioConfigPopup = !1, this.isVisibleBulkGateConfigPopup = !1, this.isVisibleConfigureZapierPopup = !1, this.isVisibleMetaLeadAdsConfigPopup = !1, this.isVisibleShiprocketConfigPopup = !1, this.fetchIntegrations()
        }
        openBlog(e) {
            this.nativeLinkService.openExternal(e)
        }
        fetchIntegrations() {
            this.service.getListByQuery().subscribe({
                next: e => {
                    this.integrations = e
                },
                error: e => {
                    this.toastNotificationService.error("error_fetching_integrations")
                }
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-integrations"]
                ],
                standalone: !1,
                decls: 20,
                vars: 14,
                consts: [
                    [1, "row"],
                    ["id", "integrations-title", 3, "title"],
                    [3, "message"],
                    [1, "container"],
                    [1, "d-flex", "ml-auto", "mb-3", "justify-content-end"],
                    ["icon", "fa-light fa-plus", "type", "default", "stylingMode", "outlined", 3, "onClick", "title", "text"],
                    [1, "row", "row-cols-1", "row-cols-md-3", "g-2", "flex-wrap"],
                    [3, "requestIntegrationPopupDisplay"],
                    [3, "isVisiblePopup", "integration"],
                    [3, "isVisiblePopup"],
                    [1, "col"],
                    [1, "card", "h-100", "text-center", "position-relative"],
                    [1, "card-body", "d-flex", "flex-column"],
                    [1, "mb-3"],
                    ["loading", "lazy", 1, "img-fluid", 3, "src", "alt", "ngStyle"],
                    [1, "card-title"],
                    [1, "card-text"],
                    ["role", "alert", 1, "alert", "alert-secondary", "mt-auto", "text-truncate", 3, "title"],
                    ["role", "alert", 1, "alert", "alert-secondary", "mt-auto", "text-truncate"],
                    [1, "pt-3", "d-flex", "gap-2"],
                    ["buttonType", "default", "cssClass", "w-100", 1, "flex-fill", "w-50", 3, "onClickEvent", "text", "title", "disabled"],
                    ["buttonType", "default", "routerLink", "/settings/integrations/quickBooksConfig", "cssClass", "w-100", "text", "connect", "title", "connect", 1, "flex-fill", "w-50"],
                    ["buttonType", "default", "cssClass", "w-100", 1, "flex-fill", "w-50", 3, "onClickEvent", "text"],
                    [1, "position-absolute", "top-0", "end-0", "m-2"],
                    [1, "badge", "bg-success"],
                    [1, "badge", "bg-danger"],
                    [1, "position-absolute", "top-0", "start-0", "m-2"],
                    ["role", "alert", 1, "badge", "bg-primary", "d-flex", "align-items-center", "fa-2x"],
                    [1, "fa-solid", "fa-circle-check", "me-1", "text-white"],
                    [3, "requestIntegrationPopupDisplayChange", "requestIntegrationPopupDisplay"],
                    [3, "configureMailChimpCancelClick", "isVisiblePopup", "integration"],
                    [3, "configurePhonePeCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureQuickBookCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureGupshupCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureTwilioCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureBulkGateCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureZapierCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureMetaLeadAdsCancelClick", "isVisiblePopup", "integration"],
                    [3, "configureShippingCancelClick", "isVisiblePopup"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0), p(1, "app-section-title", 1)(2, "app-alert-panel", 2), n(3, "div", 3)(4, "div", 4)(5, "dx-button", 5), _("onClick", function() {
                        return a.isVisibleRequestIntegrationPopup.set(!0)
                    }), i()(), n(6, "div", 6), U(7, Yp, 1, 1, null, null, Rp), i()()(), p(9, "router-outlet"), d(10, Kp, 1, 1, "app-request-new-integration-popup", 7), d(11, Zp, 1, 2, "app-configure-mailchimp", 8), d(12, $p, 1, 2, "app-configure-phone-pe", 8), d(13, Xp, 1, 2, "app-configure-quick-book", 8), d(14, Jp, 1, 2, "app-configure-gupshup", 8), d(15, ed, 1, 2, "app-configure-twilio", 8), d(16, td, 1, 2, "app-configure-bulkgate", 8), d(17, id, 1, 2, "app-configure-zapier", 8), d(18, nd, 1, 2, "app-configure-meta-lead-ads", 8), d(19, od, 1, 1, "app-configure-shipping", 9)), o & 2 && (r(), l("title", "integrations"), r(), l("message", a.formatMessage("integration_settings_note")), r(3), l("title", a.formatMessage("request_for_integrations_text"))("text", a.formatMessage("request_for_integrations_text")), r(2), W(a.integrationsCards), r(3), u(a.isVisibleRequestIntegrationPopup() ? 10 : -1), r(), u(a.isVisibleConfigureMailChimpPopup ? 11 : -1), r(), u(a.isVisibleConfigurePhonePePopup ? 12 : -1), r(), u(a.isVisibleConfigureQuickBook ? 13 : -1), r(), u(a.isVisibleGupshupConfigPopup ? 14 : -1), r(), u(a.isVisibleTwilioConfigPopup ? 15 : -1), r(), u(a.isVisibleBulkGateConfigPopup ? 16 : -1), r(), u(a.isVisibleConfigureZapierPopup ? 17 : -1), r(), u(a.isVisibleMetaLeadAdsConfigPopup ? 18 : -1), r(), u(a.isVisibleShiprocketConfigPopup ? 19 : -1))
                },
                dependencies: [Ni, it, pe, we, _e, Oe, Un, Ka, Za, $a, Xa, Ja, er, ir, nr, or, rr],
                styles: [".request-integration-button[_ngcontent-%COMP%]{display:flex;justify-self:self-end;margin-bottom:1rem}"]
            })
        }
    }
    return t
})();
var En = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.router = v(ge), this.activatedRoute = v(De), this.selectedTabIndex = null, this.listSettingsMenu = [{
                id: 0,
                text: f("job_overview"),
                path: "/settings/quickbooksOverview",
                icon: "fa-thin fa-pen-field",
                visible: !0
            }, {
                id: 1,
                text: f("account_configuration"),
                path: "/settings/quickbooksConfig",
                icon: "fa-thin fa-sliders",
                visible: !0
            }]
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-quick-books-config"]
                ],
                standalone: !1,
                decls: 4,
                vars: 5,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-12"],
                    ["iconPosition", "start", "stylingMode", "secondary", "mode", "route", "mobileMenuIcon", "fa-thin fa-gear", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "mobileMenuTitle"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "app-responsive-tabs", 3), _("tabChange", function(w) {
                        return a.selectTab(w)
                    }), i()()()()), o & 2 && (r(3), l("tabs", a.listSettingsMenu)("selectedIndex", a.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("mobileMenuTitle", a.formatMessage("quickbooks_integration_title")))
                },
                dependencies: [$i],
                encapsulation: 2
            })
        }
    }
    return t
})();
var sn = (() => {
    class t extends Fe {
        constructor(e) {
            super(e, un), this.api = e, this.endpoint = un
        }
        connect() {
            return this.api.get(this.endpoint + "/connect")
        }
        fetAccounts() {
            return this.api.get(this.endpoint + "/fetAccounts")
        }
        syncInventory() {
            return this.api.get(this.endpoint + "/syncInventory")
        }
        get() {
            return this.api.get(this.endpoint + "/getMapping")
        }
        getIncomeAccountList() {
            return this.api.get(this.endpoint + "/getIncomeAccountList")
        }
        getExpenseAccountList() {
            return this.api.get(this.endpoint + "/getExpenseAccountList")
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function rd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "dx-scroll-view", 2)(2, "div", 3)(3, "h6"), s(4), i(), n(5, "div", 4)(6, "div", 5), p(7, "img", 6), n(8, "p", 7), s(9), i()(), n(10, "div", 8)(11, "div", 9)(12, "span", 10), s(13), i()()(), n(14, "div", 5), p(15, "img", 11), n(16, "p", 7), s(17), i()()(), n(18, "div", 12), s(19), n(20, "a", 13), s(21), i(), s(22), n(23, "a", 13), s(24), i(), s(25), i(), n(26, "app-save-cancel-footer", 14), _("cancelClick", function() {
            g(e);
            let a = m();
            return C(a.onClosing())
        })("saveClick", function() {
            g(e);
            let a = m();
            return C(a.authorisedToQuickBook())
        }), i()()()()
    }
    if (t & 2) {
        let e = m();
        r(4), x(e.formatMessage("authorize_intuit_data_sharing")), r(5), x(e.formatMessage("quick_book_label")), r(4), x(e.formatMessage("connecting_to_label")), r(4), x(e.formatMessage("bytephase_app_label")), r(2), E(" ", e.formatMessage("connect_agreement_part1"), " "), r(2), E(" ", e.formatMessage("bytephase_app_label")), r(), E(" ", e.formatMessage("connect_agreement_part2"), " "), r(2), x(e.formatMessage("bytephase_app_label")), r(), E(" ", e.formatMessage("connect_agreement_part3"), " "), r(), l("isOnPopup", !0)("isSaving", e.isSaving)
    }
}
var lr = (() => {
    class t {
        constructor() {
            this.isVisiblePopup = !1, this.isSaving = !1, this.onCancel = Xe(), this.onSave = Xe(), this.service = v(sn), this.formatMessage = f
        }
        authorisedToQuickBook() {
            this.service.connect().subscribe({
                next: e => {
                    window.open(e.redirect_url)
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        onClosing() {
            this.isVisiblePopup = !1, this.onCancel.emit()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-quick-books-authorization-popup"]
                ],
                inputs: {
                    isVisiblePopup: "isVisiblePopup"
                },
                outputs: {
                    onCancel: "onCancel",
                    onSave: "onSave"
                },
                standalone: !1,
                decls: 2,
                vars: 6,
                consts: [
                    [3, "onHidden", "visibleChange", "visible", "maxHeight", "width", "maxWidth", "title"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    ["height", "100%", "width", "100%"],
                    [1, "container"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "flex-wrap", "gap-3", "my-4"],
                    [1, "app-logo", "text-center"],
                    ["alt", "QuickBooks", "src", "assets/integration-images/quickbook-logo.svg", "loading", "lazy", 1, "img-fluid"],
                    [1, "mt-2", "mb-0"],
                    [1, "connecting-text", "position-relative", "text-center"],
                    [1, "half-circle-border", "position-relative", "mx-auto"],
                    [1, "position-absolute"],
                    ["alt", "Bytephase", "src", "assets/icons/icon-96x96.png", "loading", "lazy", 1, "img-fluid"],
                    [1, "text-secondary"],
                    ["href", "https://bytephase.com", "target", "_blank"],
                    ["cancelLabel", "configure_keys", "saveText", "connect", "savingText", "common_connecting", 3, "cancelClick", "saveClick", "isOnPopup", "isSaving"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "dx-popup", 0), _("onHidden", function() {
                        return a.onClosing()
                    }), X("visibleChange", function(w) {
                        return $(a.isVisiblePopup, w) || (a.isVisiblePopup = w), w
                    }), T(1, rd, 27, 11, "div", 1), i()), o & 2 && (Z("visible", a.isVisiblePopup), l("maxHeight", "90vh")("width", "95vw")("maxWidth", 500)("title", a.formatMessage("configure_quick_book")), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [O, G, re, Ce],
                styles: [".half-circle-border[_ngcontent-%COMP%]{width:120px;height:120px;border:4px dashed #ccc;border-radius:50%}.half-circle-border[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{top:50%;left:50%;transform:translate(-50%,-50%);font-weight:500;color:#555}.app-logo[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{max-width:150px}"]
            })
        }
    }
    return t
})();

function ld(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-quick-books-authorization-popup", 12), _("onCancel", function() {
            g(e);
            let a = m();
            return C(a.isVisibleConfigureQuickBook = !1)
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("isVisiblePopup", e.isVisibleConfigureQuickBook)
    }
}
var cr = (() => {
    class t {
        constructor() {
            this.isVisibleConfigureQuickBook = !1, this.formatMessage = f
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-quick-books-overview"]
                ],
                standalone: !1,
                decls: 40,
                vars: 15,
                consts: [
                    [1, "container", "my-4", "p-4", "border", "rounded", "shadow-sm"],
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-3"],
                    [1, "d-flex", "align-items-center"],
                    ["height", "50", "src", "assets/integration-images/quickbook-logo.svg", "width", "50", 1, "me-3", 3, "alt"],
                    [1, "mb-0", "fw-bold"],
                    [1, "mb-0", "text-muted"],
                    ["buttonType", "success", "text", "connect", "title", "Authorized", 1, "ms-2", 3, "click"],
                    [1, "mb-3"],
                    [1, "mb-2"],
                    [1, "mb-1", "text-success", "fw-bold"],
                    [1, "mb-0"],
                    [3, "isVisiblePopup"],
                    [3, "onCancel", "isVisiblePopup"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, "img", 3), n(4, "div")(5, "h5", 4), s(6), i(), n(7, "p", 5), s(8), i()()(), n(9, "div")(10, "app-dx-outline-button", 6), _("click", function() {
                        return a.isVisibleConfigureQuickBook = !0
                    }), i()()(), n(11, "div")(12, "p", 7), s(13), i(), n(14, "div", 8)(15, "p", 9), s(16), i(), n(17, "p", 8), s(18), i()(), n(19, "div", 8)(20, "p", 9), s(21), i(), n(22, "p", 8), s(23), i()(), n(24, "div", 8)(25, "p", 9), s(26), i(), n(27, "p", 8), s(28), i()(), n(29, "div", 8)(30, "p", 9), s(31), i(), n(32, "p", 10), s(33), i()(), n(34, "div")(35, "p", 9), s(36), i(), n(37, "p", 10), s(38), i()()()(), d(39, ld, 1, 1, "app-quick-books-authorization-popup", 11)), o & 2 && (r(3), l("alt", a.formatMessage("quickbooks_logo")), r(3), x(a.formatMessage("quickbooks_integration_title")), r(2), x(a.formatMessage("quickbooks_integration_description")), r(5), x(a.formatMessage("connect_info")), r(3), x(a.formatMessage("step_1_title")), r(2), x(a.formatMessage("step_1_description")), r(3), x(a.formatMessage("step_2_title")), r(2), x(a.formatMessage("step_2_description")), r(3), x(a.formatMessage("step_3_title")), r(2), x(a.formatMessage("step_3_description")), r(3), E("", a.formatMessage("step_4_title"), " "), r(2), x(a.formatMessage("step_4_description")), r(3), x(a.formatMessage("step_5_title")), r(2), x(a.formatMessage("step_5_description")), r(), u(a.isVisibleConfigureQuickBook ? 39 : -1))
                },
                dependencies: [we, lr],
                encapsulation: 2
            })
        }
    }
    return t
})();
var wt = class {
    constructor(c) {
        return Object.assign(this, c)
    }
    static getForm(c) {
        return new z().group({
            id: [c.id || null],
            income_account_id: [c.income_account_id || [k.required]],
            expense_account_id: [c.expense_account_id || null],
            inventory_asset_account_id: [c.inventory_asset_account_id || null],
            created_at: [c.created_at || new Date]
        })
    }
};

function cd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 11), _("click", function() {
            g(e);
            let a = m();
            return C(a.syncInventory())
        }), i()
    }
    t & 2 && l("isVisibleIcon", !0)
}

function md(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 9), t & 2 && l("rows", 6)("columns", 2)
}

function pd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 22), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.isEditMode = !1)
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("isSaving", e.isSaving())("isVisibleHr", !1)
    }
}

function dd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 14), p(1, "app-location-back", 23), n(2, "app-dx-outline-button", 24), _("click", function() {
            g(e);
            let a = m(2);
            return C(a.setEditMode())
        }), i()()
    }
}

function ud(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "form", 12), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.save())
        }), d(1, pd, 1, 2, "app-save-cancel-footer", 13)(2, dd, 3, 0, "div", 14), n(3, "div", 15)(4, "div", 16), s(5, " Account for Inventory Assets "), i(), n(6, "app-control-container", 17), p(7, "dx-select-box", 18), i()(), n(8, "div", 19)(9, "div", 16), s(10, " Account for Sale "), i(), n(11, "app-control-container", 20), p(12, "dx-select-box", 21), i()()()
    }
    if (t & 2) {
        let e = m();
        l("formGroup", e.form), r(), u(e.isEditMode ? 1 : 2), r(5), l("errorMsg", e.formatMessage("expense_account_required")), r(), l("disabled", !e.isEditMode)("items", e.expenseAccountList)("placeholder", e.formatMessage("select_expense_account")), r(4), l("errorMsg", e.formatMessage("income_account_required")), r(), l("disabled", !e.isEditMode)("items", e.incomeAccountList)("placeholder", e.formatMessage("select_income_account"))
    }
}
var mr = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.formService = v(B), this.isMobileDevice = v(se).isMobileDevice(), this.toastNotificationService = v(N), this.isSaving = ce(!1), this.service = v(sn), this.isEditMode = !0
        }
        ngOnInit() {
            wi([this.service.get(), this.service.getIncomeAccountList(), this.service.getExpenseAccountList()]).subscribe({
                next: ([e, o, a]) => {
                    this.quickbooksAccountConfig = e, this.expenseAccountList = a, this.incomeAccountList = o, e ? (this.isEditMode = !1, this.form = wt.getForm(new wt(this.quickbooksAccountConfig)), this.form.disable()) : this.form = wt.getForm(new wt({}))
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        save() {
            this.form.valid ? (this.isSaving.update(() => !0), (this.quickbooksAccountConfig ? .id ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    this.quickbooksAccountConfig = new wt(o), this.toastNotificationService.success("notification_quickbook_config_save_success")
                },
                error: o => {
                    console.error(o), this.toastNotificationService.error("notification_account_mapping_error")
                },
                complete: () => {
                    this.isSaving.update(() => !1), this.isEditMode = !1, this.form.disable()
                }
            })) : this.formService.validateFormFields(this.form)
        }
        syncInventory() {
            this.service.syncInventory().subscribe({
                next: e => {
                    console.log(e), this.toastNotificationService.success("notification_inventory_sync_success")
                },
                error: () => {
                    console.error("Error Syncing Inventory")
                }
            })
        }
        fetchAccounts() {
            this.service.fetAccounts().subscribe({
                next: e => {
                    console.log(e), this.toastNotificationService.success("notification_account_fetch_success")
                },
                error: () => {
                    console.error("Error Fetching Accounts")
                }
            })
        }
        onClosing() {
            this.form = null, this.quickbooksAccountConfig = null
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-quick-books-account-config"]
                ],
                standalone: !1,
                decls: 15,
                vars: 7,
                consts: [
                    [1, "d-flex", "align-items-center", "justify-content-between", "mb-3"],
                    [1, "d-flex", "align-items-center"],
                    ["height", "50", "src", "assets/integration-images/quickbook-logo.svg", "width", "50", 1, "me-3", 3, "alt"],
                    [1, "mb-0", "fw-bold"],
                    [1, "mb-0", "text-muted"],
                    ["buttonType", "success", "icon", "fa-thin fa-circle-down", "text", "fetch_accounts", "title", "fetch_accounts", 1, "ms-2", 3, "click", "isVisibleIcon"],
                    ["buttonType", "success", "title", "sync_inventory", "text", "sync_inventory", "icon", "fa-thin fa-rotate", 1, "ms-2", 3, "isVisibleIcon"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    ["buttonType", "success", "title", "sync_inventory", "text", "sync_inventory", "icon", "fa-thin fa-rotate", 1, "ms-2", 3, "click", "isVisibleIcon"],
                    [3, "ngSubmit", "formGroup"],
                    [3, "isSaving", "isVisibleHr"],
                    [1, "d-flex", "align-items-center", "justify-content-end", "mobile-action-buttons"],
                    [1, "row", "my-2"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "fs-5"],
                    ["name", "expense_account_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg"],
                    ["displayExpr", "account_name", "formControlName", "expense_account_id", "searchMode", "contains", "valueExpr", "account_id", 3, "disabled", "items", "placeholder"],
                    [1, "row", "mb-2"],
                    ["name", "income_account_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg"],
                    ["displayExpr", "account_name", "formControlName", "income_account_id", "searchMode", "contains", "valueExpr", "account_id", 3, "disabled", "items", "placeholder"],
                    [3, "cancelClick", "isSaving", "isVisibleHr"],
                    ["id", "job-basic-info-back"],
                    ["buttonType", "default", "text", "common_edit", "title", "common_edit", 1, "ms-2", 3, "click"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1), p(2, "img", 2), n(3, "div")(4, "h5", 3), s(5), i(), n(6, "p", 4), s(7), i()()(), n(8, "div")(9, "app-dx-outline-button", 5), _("click", function() {
                        return a.fetchAccounts()
                    }), i(), d(10, cd, 1, 1, "app-dx-outline-button", 6), i()(), n(11, "div", 7)(12, "div", 8), d(13, md, 1, 2, "app-skeleton-loader", 9), d(14, ud, 13, 10, "form", 10), i()()), o & 2 && (r(2), l("alt", a.formatMessage("quickbooks_logo")), r(3), x(a.formatMessage("quickbooks_integration_title")), r(2), x(a.formatMessage("quickbooks_integration_description")), r(2), l("isVisibleIcon", !0), r(), u(a.incomeAccountList.length > 0 ? 10 : -1), r(3), u(a.form ? -1 : 13), r(), u(a.form ? 14 : -1))
                },
                dependencies: [Qi, j, O, F, we, le, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();
var pr = (() => {
    class t {
        constructor(e) {
            this.api = e, this.endpoint = ao
        }
        getAllBusinessTypes() {
            return this.api.get(this.endpoint)
        }
        getTenantBusinessType() {
            return this.api.get("businessType/current")
        }
        getTenantBusinessTypes() {
            return this.api.get("businessType/all")
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var _d = (t, c) => c.id;

function fd(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 5), t & 2 && l("rows", 3)("columns", 3)
}

function gd(t, c) {
    if (t & 1 && (n(0, "span", 14), s(1), i()), t & 2) {
        let e = m(3);
        r(), x(e.formatMessage("PRIMARY"))
    }
}

function Cd(t, c) {
    if (t & 1 && (n(0, "div", 9)(1, "div", 10)(2, "div", 11)(3, "div", 12)(4, "h5", 13), s(5), i(), d(6, gd, 2, 1, "span", 14), i(), n(7, "p", 15), s(8), i(), n(9, "div", 16)(10, "span", 17)(11, "span", 18), s(12), i(), s(13), i(), n(14, "span", 17)(15, "span", 18), s(16), i(), s(17), i(), n(18, "span", 17)(19, "span", 18), s(20), i(), s(21), i(), n(22, "span", 17)(23, "span", 18), s(24), i(), s(25), i(), n(26, "span", 17)(27, "span", 18), s(28), i(), s(29), i(), n(30, "span", 17)(31, "span", 18), s(32), i(), s(33), i()()()()()), t & 2) {
        let e = c.$implicit,
            o = m(2);
        r(5), x(e.business_type.name), r(), u(e.is_primary ? 6 : -1), r(2), x(e.business_type.description), r(4), x(e.device_types_count || 0), r(), E(" ", o.formatMessage("DEVICE_TYPES"), " "), r(3), x(e.brands_count || 0), r(), E(" ", o.formatMessage("BRANDS"), " "), r(3), x(e.models_count || 0), r(), E(" ", o.formatMessage("MODELS"), " "), r(3), x(e.accessories_count || 0), r(), E(" ", o.formatMessage("ACCESSORIES"), " "), r(3), x(e.pre_post_conditions_count || 0), r(), E(" ", o.formatMessage("pre_post_conditions"), " "), r(3), x(e.terms_and_conditions_count || 0), r(), E(" ", o.formatMessage("common_terms_and_conditions"), " ")
    }
}

function vd(t, c) {
    if (t & 1 && (n(0, "div", 6)(1, "div", 8), U(2, Cd, 34, 15, "div", 9, _d), i()()), t & 2) {
        let e = m();
        r(2), W(e.businessTypes)
    }
}

function hd(t, c) {
    if (t & 1 && (n(0, "div", 7), p(1, "i", 19), n(2, "h5", 20), s(3), i(), n(4, "p", 20), s(5), i()()), t & 2) {
        let e = m();
        r(3), x(e.formatMessage("NO_BUSINESS_TYPE_SELECTED")), r(2), E(" ", e.formatMessage("BUSINESS_TYPE_SET_DURING_SETUP"), " ")
    }
}
var dr = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.destroyRef = v(Ii), this.businessTypeService = v(pr), this.loaderService = v(Qe), this.toastNotificationService = v(N), this.businessTypes = [], this.isLoading = !1
        }
        ngOnInit() {
            this.loadBusinessTypes()
        }
        loadBusinessTypes() {
            this.isLoading = !0, this.loaderService.show(), this.businessTypeService.getTenantBusinessTypes().pipe(Qt(this.destroyRef)).subscribe({
                next: e => {
                    this.businessTypes = e.data || [], this.isLoading = !1, this.loaderService.hide()
                },
                error: () => {
                    this.toastNotificationService.error("notification_business_type_fetch_error"), this.isLoading = !1, this.loaderService.hide()
                }
            })
        }
        get hasBusinessTypes() {
            return this.businessTypes.length > 0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-business-type-management"]
                ],
                standalone: !1,
                decls: 10,
                vars: 5,
                consts: [
                    [1, "business-type-management-container"],
                    [1, "page-header", "mb-4"],
                    [1, "mb-2"],
                    [1, "fa-thin", "fa-briefcase", "me-2"],
                    [1, "text-muted", "mb-0"],
                    ["type", "card-grid", 3, "rows", "columns"],
                    [1, "business-type-display"],
                    [1, "empty-state", "text-center", "py-5"],
                    [1, "row", "g-3"],
                    [1, "col-12"],
                    [1, "card", "border-0", "shadow-sm"],
                    [1, "card-body", "p-4"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-2"],
                    [1, "mb-0", "fw-semibold"],
                    [1, "badge", "bg-primary-subtle", "text-primary", "border", "border-primary-subtle"],
                    [1, "text-muted", "small", "mb-3"],
                    [1, "d-flex", "flex-wrap", "gap-2"],
                    [1, "badge", "bg-primary-subtle", "text-primary", "border", "border-primary-subtle", "d-inline-flex", "align-items-center", "gap-1", "px-2", "py-2"],
                    [1, "fw-bold"],
                    [1, "fa-thin", "fa-briefcase", "fa-4x", "text-muted", "mb-3"],
                    [1, "text-muted"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "h4", 2), p(3, "i", 3), s(4), i(), n(5, "p", 4), s(6), i()(), d(7, fd, 1, 2, "app-skeleton-loader", 5), d(8, vd, 4, 0, "div", 6), d(9, hd, 6, 2, "div", 7), i()), o & 2 && (r(4), E(" ", a.formatMessage("BUSINESS_TYPE_MANAGEMENT"), " "), r(2), E(" ", a.formatMessage("VIEW_YOUR_CURRENT_BUSINESS_TYPE"), " "), r(), u(a.isLoading ? 7 : -1), r(), u(!a.isLoading && a.hasBusinessTypes ? 8 : -1), r(), u(!a.isLoading && !a.hasBusinessTypes ? 9 : -1))
                },
                dependencies: [F],
                styles: [".business-type-management-container[_ngcontent-%COMP%]{padding:1.5rem}.business-type-management-container[_ngcontent-%COMP%]   .page-header[_ngcontent-%COMP%]{border-bottom:1px solid #e0e0e0;padding-bottom:1rem}.business-type-management-container[_ngcontent-%COMP%]   .page-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%]{font-weight:600;color:#333}.business-type-management-container[_ngcontent-%COMP%]   .business-type-display[_ngcontent-%COMP%]   .business-type-icon[_ngcontent-%COMP%]{width:80px;height:80px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,rgba(var(--primary-rgb),.1),rgba(var(--primary-rgb),.05));border-radius:12px}.business-type-management-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]{background-color:#f8f9fa;border-radius:12px;padding:3rem 1.5rem}.dark-theme[_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .page-header[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .page-header[_ngcontent-%COMP%]{border-bottom-color:#444}.dark-theme[_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .page-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .page-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%]{color:var(--primary-text, #e0e0e0)}.dark-theme[_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]{background-color:var(--bg-secondary, #2d2d2d);border-color:#444!important}.dark-theme[_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{color:var(--primary-text, #e0e0e0)}.dark-theme[_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .business-type-management-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]{background-color:var(--bg-secondary, #2d2d2d)}"]
            })
        }
    }
    return t
})();
var ur = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.tabs = [{
                id: 0,
                text: "email_signature",
                path: "/settings/notification-signatures/email",
                icon: "fa-regular fa-envelope",
                visible: !0
            }, {
                id: 1,
                text: "sms_signature",
                path: "/settings/notification-signatures/sms",
                icon: "fa-regular fa-message",
                visible: !0
            }, {
                id: 2,
                text: "whatsapp_signature",
                path: "/settings/notification-signatures/whatsapp",
                icon: "fa-brands fa-whatsapp",
                visible: !0
            }]
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-notification-template-signatures"]
                ],
                decls: 3,
                vars: 10,
                consts: [
                    [3, "tabs", "mode", "title", "mobileMenuTitle", "mobileMenuIcon", "useAccordionOnMobile"]
                ],
                template: function(o, a) {
                    o & 1 && (p(0, "app-responsive-tabs", 0), q(1, "translate"), q(2, "translate")), o & 2 && l("tabs", a.tabs)("mode", "route")("title", Y(1, 6, "notification_signatures"))("mobileMenuTitle", Y(2, 8, "notification_signatures"))("mobileMenuIcon", "fa-solid fa-signature")("useAccordionOnMobile", !1)
                },
                dependencies: [nt, $i, ft],
                encapsulation: 2
            })
        }
    }
    return t
})();
var _i = [{
    displayName: "Business Name",
    technicalName: "name",
    syntax: "{{name}}"
}, {
    displayName: "Support Email",
    technicalName: "support_email",
    syntax: "{{support_email}}"
}, {
    displayName: "Support Number",
    technicalName: "support_number",
    syntax: "{{support_number}}"
}, {
    displayName: "Alternate Number",
    technicalName: "alternate_number",
    syntax: "{{alternate_number}}"
}, {
    displayName: "WhatsApp Number",
    technicalName: "whats_app_number",
    syntax: "{{whats_app_number}}"
}];
var fi = (() => {
    class t {
        constructor(e) {
            this.apiService = e
        }
        getSignatures() {
            return this.apiService.get(Yt)
        }
        updateEmailSignature(e) {
            return this.apiService.put(`${Yt}/email`, {
                email_signature: e
            })
        }
        updateSmsSignature(e) {
            return this.apiService.put(`${Yt}/sms`, {
                sms_signature: e
            })
        }
        updateWhatsAppSignature(e) {
            return this.apiService.put(`${Yt}/whatsapp`, {
                whatsapp_signature: e
            })
        }
        deleteSignatures() {
            return this.apiService.delete(Yt)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Te(he))
            }
        }
        static {
            this.\u0275prov = ve({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var xd = ["emailEditor"],
    fr = t => [t],
    Sd = (t, c) => c.syntax;

function bd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 29), _("onClickEvent", function() {
            g(e);
            let a = m(2);
            return C(a.toggleEditMode())
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("icon", e.ACTION_ICONS.PENCIL.solid)
    }
}

function yd(t, c) {
    if (t & 1 && (n(0, "div", 5), T(1, bd, 1, 1, "app-dx-outline-button", 28), i()), t & 2) {
        let e = m();
        r(), l("ngxPermissionsOnly", $e(1, fr, e.PERMISSION_LIST.BUSINESS_SETTING_WRITE))
    }
}

function Td(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-save-cancel-footer", 31), _("cancelClick", function() {
            g(e);
            let a = m(2);
            return C(a.toggleEditMode())
        })("saveClick", function() {
            g(e);
            let a = m(2);
            return C(a.onSave())
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("isVisibleHr", !1)("isDisabled", e.isLoading || !e.emailForm.valid)("icon", e.ACTION_ICONS.SAVE.solid)("saveText", "common_save")
    }
}

function Ed(t, c) {
    if (t & 1 && (n(0, "div", 5), T(1, Td, 1, 4, "app-save-cancel-footer", 30), i()), t & 2) {
        let e = m();
        r(), l("ngxPermissionsOnly", $e(1, fr, e.PERMISSION_LIST.BUSINESS_SETTING_WRITE))
    }
}

function wd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 32), q(1, "translate"), _("onClick", function() {
            let a = g(e).$implicit,
                h = m();
            return C(h.insertVariable(a))
        }), p(2, "i", 33), s(3), i()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = m();
        l("disabled", !o.isEditMode)("hint", Y(1, 3, "click_to_insert")), r(3), E("", e.displayName, " ")
    }
}
var gr = (() => {
    class t {
        constructor(e, o) {
            this.signatureService = e, this.toastr = o, this.isEditMode = !1, this.isLoading = !1, this.availableVariables = _i, this.PERMISSION_LIST = b, this.formatMessage = f, this.MAX_LENGTH = 1e4, this.ACTION_ICONS = uo
        }
        ngOnInit() {
            this.initForm(), this.loadSignature()
        }
        initForm() {
            this.emailForm = new Wt({
                email_signature: new _t(null, [k.maxLength(this.MAX_LENGTH)])
            })
        }
        loadSignature() {
            this.isLoading = !0, this.signatureService.getSignatures().subscribe({
                next: e => {
                    e.data && this.emailForm.patchValue({
                        email_signature: e.data.email_signature
                    }), this.isLoading = !1
                },
                error: e => {
                    console.error("Failed to load signature:", e), this.toastr.error(f("failed_to_load_signature")), this.isLoading = !1
                }
            })
        }
        toggleEditMode() {
            this.isEditMode && this.loadSignature(), this.isEditMode = !this.isEditMode
        }
        insertVariable(e) {
            if (!this.isEditMode) return;
            let o = this.emailEditor ? .instance;
            if (o) {
                let h = o.getSelection() ? .index || 0;
                o.insertText(h, e.syntax, {})
            }
        }
        onSave() {
            if (!this.emailForm.valid) {
                this.toastr.warning(f("please_fill_required_fields"));
                return
            }
            this.isLoading = !0;
            let e = this.emailForm.get("email_signature") ? .value;
            this.signatureService.updateEmailSignature(e).subscribe({
                next: () => {
                    this.toastr.success(f("signature_saved_successfully")), this.isEditMode = !1, this.isLoading = !1, this.loadSignature()
                },
                error: o => {
                    console.error("Failed to save signature:", o), this.toastr.error(f("failed_to_save_signature")), this.isLoading = !1
                }
            })
        }
        getCharacterCount() {
            return (this.emailForm.get("email_signature") ? .value || "").length
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(fi), I(zt))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-notification-template-email-signature"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(xd, 5), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.emailEditor = h.first)
                    }
                },
                decls: 45,
                vars: 21,
                consts: [
                    ["emailEditor", ""],
                    [1, "notification-template-email-signature-container"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-3"],
                    [1, "mb-0"],
                    [1, "d-flex", "gap-2"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "alert", "alert-info", "mb-3"],
                    [1, "fa-solid", "fa-info-circle", "me-2"],
                    [1, "mb-3"],
                    [1, "form-label", "fw-semibold"],
                    [1, "d-flex", "flex-wrap", "gap-2"],
                    ["type", "normal", "stylingMode", "outlined", 3, "disabled", "hint"],
                    [3, "formGroup"],
                    [1, "form-label"],
                    ["formControlName", "email_signature", 3, "height", "disabled"],
                    ["name", "undo"],
                    ["name", "redo"],
                    ["name", "separator"],
                    ["name", "bold"],
                    ["name", "italic"],
                    ["name", "underline"],
                    ["name", "strike"],
                    ["name", "alignLeft"],
                    ["name", "alignCenter"],
                    ["name", "alignRight"],
                    ["name", "link"],
                    ["name", "clear"],
                    [1, "text-muted"],
                    ["buttonType", "default", "text", "common_edit", 3, "icon", "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 3, "onClickEvent", "icon"],
                    [3, "isVisibleHr", "isDisabled", "icon", "saveText", "cancelClick", "saveClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "saveClick", "isVisibleHr", "isDisabled", "icon", "saveText"],
                    ["type", "normal", "stylingMode", "outlined", 3, "onClick", "disabled", "hint"],
                    [1, "fa-solid", "fa-plus", "me-1"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 1)(1, "div", 2)(2, "h5", 3), s(3), q(4, "translate"), i(), n(5, "div", 4), d(6, yd, 2, 3, "div", 5)(7, Ed, 2, 3, "div", 5), i()(), n(8, "div", 6), p(9, "i", 7), s(10), q(11, "translate"), i(), n(12, "div", 8)(13, "label", 9), s(14), q(15, "translate"), i(), n(16, "div", 10), U(17, wd, 4, 5, "dx-button", 11, Sd), i()(), n(19, "form", 12)(20, "div", 8)(21, "label", 13), s(22), q(23, "translate"), i(), n(24, "dx-html-editor", 14, 0)(26, "dxo-toolbar"), p(27, "dxi-item", 15)(28, "dxi-item", 16)(29, "dxi-item", 17)(30, "dxi-item", 18)(31, "dxi-item", 19)(32, "dxi-item", 20)(33, "dxi-item", 21)(34, "dxi-item", 17)(35, "dxi-item", 22)(36, "dxi-item", 23)(37, "dxi-item", 24)(38, "dxi-item", 17)(39, "dxi-item", 25)(40, "dxi-item", 17)(41, "dxi-item", 26), i()(), n(42, "small", 27), s(43), q(44, "translate"), i()()()()), o & 2 && (r(3), x(Y(4, 11, "email_signature")), r(3), u(a.isEditMode ? 7 : 6), r(4), E(" ", Y(11, 13, "email_signature_help"), " "), r(4), x(Y(15, 15, "available_variables")), r(3), W(a.availableVariables), r(2), l("formGroup", a.emailForm), r(3), x(Y(23, 17, "signature_content")), r(2), l("height", 300)("disabled", !a.isEditMode), r(19), et(" ", a.getCharacterCount(), " / ", a.MAX_LENGTH, " ", Y(44, 19, "characters"), " "))
                },
                dependencies: [qt, V, L, P, A, D, wo, qi, Oi, Fi, Jt, _e, jt, ne, Ht, we, nt, O, ft],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Cr = t => [t],
    Id = (t, c) => c.syntax;

function kd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 6), q(1, "translate"), q(2, "translate"), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.toggleEditMode())
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("text", e.isEditMode ? Y(1, 3, "cancel") : Y(2, 5, "edit"))("type", e.isEditMode ? "normal" : "default")("icon", e.isEditMode ? "close" : "edit")
    }
}

function Md(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 8), q(1, "translate"), _("onClick", function() {
            g(e);
            let a = m(3);
            return C(a.onSave())
        }), i()
    }
    if (t & 2) {
        let e = m(3);
        l("text", Y(1, 2, "save"))("disabled", e.isLoading || !e.smsForm.valid)
    }
}

function Nd(t, c) {
    if (t & 1 && T(0, Md, 2, 4, "dx-button", 7), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", $e(1, Cr, e.PERMISSION_LIST.BUSINESS_SETTING_WRITE))
    }
}

function Pd(t, c) {
    if (t & 1 && (n(0, "div", 3), T(1, kd, 3, 7, "dx-button", 4), d(2, Nd, 1, 3, "dx-button", 5), i()), t & 2) {
        let e = m();
        r(), l("ngxPermissionsOnly", $e(2, Cr, e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)), r(), u(e.isEditMode ? 2 : -1)
    }
}

function Vd(t, c) {
    if (t & 1 && (n(0, "div", 9), p(1, "i", 10), s(2), q(3, "translate"), i(), n(4, "form", 11)(5, "div", 12)(6, "label", 13), s(7), q(8, "translate"), i(), p(9, "dx-text-area", 14), i()()), t & 2) {
        let e = m();
        r(2), E(" ", Y(3, 5, "sms_signature_dlt_notice"), " "), r(2), l("formGroup", e.smsForm), r(3), x(Y(8, 7, "signature_content")), r(2), l("height", 200)("disabled", !0)
    }
}

function Ad(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 22), q(1, "translate"), _("onClick", function() {
            let a = g(e).$implicit,
                h = m(2);
            return C(h.insertVariable(a))
        }), p(2, "i", 23), s(3), i()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = m(2);
        l("disabled", !o.isEditMode)("hint", Y(1, 3, "click_to_insert")), r(3), E("", e.displayName, " ")
    }
}

function Ld(t, c) {
    if (t & 1 && (n(0, "div", 15), p(1, "i", 16), s(2), q(3, "translate"), i(), n(4, "div", 12)(5, "label", 17), s(6), q(7, "translate"), i(), n(8, "div", 18), U(9, Ad, 4, 5, "dx-button", 19, Id), i()(), n(11, "form", 11)(12, "div", 12)(13, "label", 13), s(14), q(15, "translate"), i(), p(16, "dx-text-area", 20), n(17, "small", 21), s(18), q(19, "translate"), i()()()), t & 2) {
        let e = m();
        r(2), E(" ", Y(3, 10, "sms_signature_help"), " "), r(4), x(Y(7, 12, "available_variables")), r(3), W(e.availableVariables), r(2), l("formGroup", e.smsForm), r(3), x(Y(15, 14, "signature_content")), r(2), l("height", 200)("maxLength", e.MAX_LENGTH)("disabled", !e.isEditMode), r(2), et(" ", e.getCharacterCount(), " / ", e.MAX_LENGTH, " ", Y(19, 16, "characters"), " ")
    }
}
var vr = (() => {
    class t {
        constructor(e, o, a) {
            this.signatureService = e, this.toastr = o, this.tenantService = a, this.isEditMode = !1, this.isLoading = !1, this.availableVariables = _i, this.PERMISSION_LIST = b, this.formatMessage = f, this.MAX_LENGTH = 500
        }
        ngOnInit() {
            this.initForm(), this.loadSignature(), this.tenantService.isIndia() && this.smsForm.get("sms_signature") ? .disable()
        }
        initForm() {
            this.smsForm = new Wt({
                sms_signature: new _t(null, [k.maxLength(this.MAX_LENGTH)])
            })
        }
        loadSignature() {
            this.isLoading = !0, this.signatureService.getSignatures().subscribe({
                next: e => {
                    e.data && this.smsForm.patchValue({
                        sms_signature: e.data.sms_signature
                    }), this.isLoading = !1
                },
                error: e => {
                    console.error("Failed to load signature:", e), this.toastr.error(f("failed_to_load_signature")), this.isLoading = !1
                }
            })
        }
        toggleEditMode() {
            this.isEditMode && this.loadSignature(), this.isEditMode = !this.isEditMode
        }
        insertVariable(e) {
            if (!this.isEditMode) return;
            let o = this.smsForm.get("sms_signature"),
                a = o ? .value || "";
            o ? .setValue(a + e.syntax)
        }
        onSave() {
            if (!this.smsForm.valid) {
                this.toastr.warning(f("please_fill_required_fields"));
                return
            }
            this.isLoading = !0;
            let e = this.smsForm.get("sms_signature") ? .value;
            this.signatureService.updateSmsSignature(e).subscribe({
                next: () => {
                    this.toastr.success(f("signature_saved_successfully")), this.isEditMode = !1, this.isLoading = !1, this.loadSignature()
                },
                error: o => {
                    console.error("Failed to save signature:", o), this.toastr.error(f("failed_to_save_signature")), this.isLoading = !1
                }
            })
        }
        getCharacterCount() {
            return (this.smsForm.get("sms_signature") ? .value || "").length
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(fi), I(zt), I(ie))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-notification-template-sms-signature"]
                ],
                decls: 8,
                vars: 5,
                consts: [
                    [1, "notification-template-sms-signature-container"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-3"],
                    [1, "mb-0"],
                    [1, "d-flex", "gap-2"],
                    [3, "text", "type", "icon", "onClick", 4, "ngxPermissionsOnly"],
                    ["type", "success", "icon", "save", 3, "text", "disabled"],
                    [3, "onClick", "text", "type", "icon"],
                    ["type", "success", "icon", "save", 3, "text", "disabled", "onClick", 4, "ngxPermissionsOnly"],
                    ["type", "success", "icon", "save", 3, "onClick", "text", "disabled"],
                    [1, "alert", "alert-warning", "mb-3"],
                    [1, "fa-solid", "fa-lock", "me-2"],
                    [3, "formGroup"],
                    [1, "mb-3"],
                    [1, "form-label"],
                    ["formControlName", "sms_signature", 3, "height", "disabled"],
                    [1, "alert", "alert-info", "mb-3"],
                    [1, "fa-solid", "fa-info-circle", "me-2"],
                    [1, "form-label", "fw-semibold"],
                    [1, "d-flex", "flex-wrap", "gap-2"],
                    ["type", "normal", "stylingMode", "outlined", 3, "disabled", "hint"],
                    ["formControlName", "sms_signature", 3, "height", "maxLength", "disabled"],
                    [1, "text-muted"],
                    ["type", "normal", "stylingMode", "outlined", 3, "onClick", "disabled", "hint"],
                    [1, "fa-solid", "fa-plus", "me-1"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "h5", 2), s(3), q(4, "translate"), i(), d(5, Pd, 3, 4, "div", 3), i(), d(6, Vd, 10, 9)(7, Ld, 20, 18), i()), o & 2 && (r(3), x(Y(4, 3, "sms_signature")), r(2), u(a.tenantService.isIndia() ? -1 : 5), r(), u(a.tenantService.isIndia() ? 6 : 7))
                },
                dependencies: [qt, V, L, P, A, D, Ri, ti, Jt, _e, jt, ne, Ht, ft],
                encapsulation: 2
            })
        }
    }
    return t
})();
var hr = t => [t],
    Dd = (t, c) => c.syntax;

function Od(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 16), q(1, "translate"), q(2, "translate"), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.toggleEditMode())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("text", e.isEditMode ? Y(1, 3, "cancel") : Y(2, 5, "edit"))("type", e.isEditMode ? "normal" : "default")("icon", e.isEditMode ? "close" : "edit")
    }
}

function Fd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 18), q(1, "translate"), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.onSave())
        }), i()
    }
    if (t & 2) {
        let e = m(2);
        l("text", Y(1, 2, "save"))("disabled", e.isLoading || !e.whatsappForm.valid)
    }
}

function Bd(t, c) {
    if (t & 1 && T(0, Fd, 2, 4, "dx-button", 17), t & 2) {
        let e = m();
        l("ngxPermissionsOnly", $e(1, hr, e.PERMISSION_LIST.BUSINESS_SETTING_WRITE))
    }
}

function Rd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "dx-button", 19), q(1, "translate"), _("onClick", function() {
            let a = g(e).$implicit,
                h = m();
            return C(h.insertVariable(a))
        }), p(2, "i", 20), s(3), i()
    }
    if (t & 2) {
        let e = c.$implicit,
            o = m();
        l("disabled", !o.isEditMode)("hint", Y(1, 3, "click_to_insert")), r(3), E("", e.displayName, " ")
    }
}
var xr = (() => {
    class t {
        constructor(e, o) {
            this.signatureService = e, this.toastr = o, this.isEditMode = !1, this.isLoading = !1, this.availableVariables = _i, this.PERMISSION_LIST = b, this.formatMessage = f, this.MAX_LENGTH = 1e3
        }
        ngOnInit() {
            this.initForm(), this.loadSignature()
        }
        initForm() {
            this.whatsappForm = new Wt({
                whatsapp_signature: new _t(null, [k.maxLength(this.MAX_LENGTH)])
            })
        }
        loadSignature() {
            this.isLoading = !0, this.signatureService.getSignatures().subscribe({
                next: e => {
                    e.data && this.whatsappForm.patchValue({
                        whatsapp_signature: e.data.whatsapp_signature
                    }), this.isLoading = !1
                },
                error: e => {
                    console.error("Failed to load signature:", e), this.toastr.error(f("failed_to_load_signature")), this.isLoading = !1
                }
            })
        }
        toggleEditMode() {
            this.isEditMode && this.loadSignature(), this.isEditMode = !this.isEditMode
        }
        insertVariable(e) {
            if (!this.isEditMode) return;
            let o = this.whatsappForm.get("whatsapp_signature"),
                a = o ? .value || "";
            o ? .setValue(a + e.syntax)
        }
        onSave() {
            if (!this.whatsappForm.valid) {
                this.toastr.warning(f("please_fill_required_fields"));
                return
            }
            this.isLoading = !0;
            let e = this.whatsappForm.get("whatsapp_signature") ? .value;
            this.signatureService.updateWhatsAppSignature(e).subscribe({
                next: () => {
                    this.toastr.success(f("signature_saved_successfully")), this.isEditMode = !1, this.isLoading = !1, this.loadSignature()
                },
                error: o => {
                    console.error("Failed to save signature:", o), this.toastr.error(f("failed_to_save_signature")), this.isLoading = !1
                }
            })
        }
        getCharacterCount() {
            return (this.whatsappForm.get("whatsapp_signature") ? .value || "").length
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(fi), I(zt))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-notification-template-whatsapp-signature"]
                ],
                decls: 28,
                vars: 25,
                consts: [
                    [1, "notification-template-whatsapp-signature-container"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-3"],
                    [1, "mb-0"],
                    [1, "d-flex", "gap-2"],
                    [3, "text", "type", "icon", "onClick", 4, "ngxPermissionsOnly"],
                    ["type", "success", "icon", "save", 3, "text", "disabled"],
                    [1, "alert", "alert-info", "mb-3"],
                    [1, "fa-solid", "fa-info-circle", "me-2"],
                    [1, "mb-3"],
                    [1, "form-label", "fw-semibold"],
                    [1, "d-flex", "flex-wrap", "gap-2"],
                    ["type", "normal", "stylingMode", "outlined", 3, "disabled", "hint"],
                    [3, "formGroup"],
                    [1, "form-label"],
                    ["formControlName", "whatsapp_signature", 3, "height", "maxLength", "disabled"],
                    [1, "text-muted"],
                    [3, "onClick", "text", "type", "icon"],
                    ["type", "success", "icon", "save", 3, "text", "disabled", "onClick", 4, "ngxPermissionsOnly"],
                    ["type", "success", "icon", "save", 3, "onClick", "text", "disabled"],
                    ["type", "normal", "stylingMode", "outlined", 3, "onClick", "disabled", "hint"],
                    [1, "fa-solid", "fa-plus", "me-1"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0)(1, "div", 1)(2, "h5", 2), s(3), q(4, "translate"), i(), n(5, "div", 3), T(6, Od, 3, 7, "dx-button", 4), d(7, Bd, 1, 3, "dx-button", 5), i()(), n(8, "div", 6), p(9, "i", 7), s(10), q(11, "translate"), i(), n(12, "div", 8)(13, "label", 9), s(14), q(15, "translate"), i(), n(16, "div", 10), U(17, Rd, 4, 5, "dx-button", 11, Dd), i()(), n(19, "form", 12)(20, "div", 8)(21, "label", 13), s(22), q(23, "translate"), i(), p(24, "dx-text-area", 14), n(25, "small", 15), s(26), q(27, "translate"), i()()()()), o & 2 && (r(3), x(Y(4, 13, "whatsapp_signature")), r(3), l("ngxPermissionsOnly", $e(23, hr, a.PERMISSION_LIST.BUSINESS_SETTING_WRITE)), r(), u(a.isEditMode ? 7 : -1), r(3), E(" ", Y(11, 15, "whatsapp_signature_help"), " "), r(4), x(Y(15, 17, "available_variables")), r(3), W(a.availableVariables), r(2), l("formGroup", a.whatsappForm), r(3), x(Y(23, 19, "signature_content")), r(2), l("height", 200)("maxLength", a.MAX_LENGTH)("disabled", !a.isEditMode), r(2), et(" ", a.getCharacterCount(), " / ", a.MAX_LENGTH, " ", Y(27, 21, "characters"), " "))
                },
                dependencies: [qt, V, L, P, A, D, Ri, ti, Jt, _e, jt, ne, Ht, ft],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Gd(t, c) {
    t & 1 && p(0, "dx-load-indicator", 1), t & 2 && l("visible", !0)
}

function Ud(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 10)(1, "div", 12)(2, "h6", 13), s(3, "Two-factor authentication is not enabled"), i(), n(4, "small", 14), s(5, "Enable 2FA to secure your account with an authenticator app."), i()(), n(6, "div", 15)(7, "dx-button", 16), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.onEnableClick())
        }), i()()()
    }
}

function Wd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 11)(1, "div", 12)(2, "h6", 17), p(3, "i", 18), s(4, "Two-factor authentication is enabled "), i(), n(5, "small", 14), s(6, " Remaining backup codes: "), n(7, "strong"), s(8), i()()(), n(9, "div", 19)(10, "dx-button", 20), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.onRegenerateClick())
        }), i(), n(11, "dx-button", 21), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.onDisableClick())
        }), i()()()
    }
    if (t & 2) {
        let e = m(2);
        r(8), x(e.remainingBackupCodes)
    }
}

function qd(t, c) {
    if (t & 1 && (n(0, "h5", 7), s(1, "Two-Factor Authentication"), i(), n(2, "div", 8), p(3, "i", 9), n(4, "span"), s(5, "Add an extra layer of security to your account by requiring a verification code from an authenticator app when signing in."), i()(), d(6, Ud, 8, 0, "div", 10)(7, Wd, 12, 1, "div", 11)), t & 2) {
        let e = m();
        r(6), u(e.isEnabled ? 7 : 6)
    }
}

function Hd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "p", 23), s(1, "Scan the QR code with your authenticator app, then enter the 6-digit verification code."), i(), n(2, "p", 24), s(3, "Supported apps: "), n(4, "strong"), s(5, "Google Authenticator"), i(), s(6, ", "), n(7, "strong"), s(8, "Microsoft Authenticator"), i(), s(9, ", "), n(10, "strong"), s(11, "Authy"), i(), s(12, ", or any TOTP-compatible app."), i(), n(13, "div", 25), p(14, "img", 26), n(15, "div", 27)(16, "small", 14), s(17, "Or enter this key manually:"), i(), n(18, "div", 28)(19, "code", 29), s(20), i()()()(), n(21, "form", 30), _("ngSubmit", function() {
            g(e);
            let a = m(2);
            return C(a.onConfirmSetup())
        }), n(22, "div", 25)(23, "app-otp-input", 31), _("otpComplete", function() {
            g(e);
            let a = m(2);
            return C(a.onConfirmSetup())
        }), i()(), p(24, "dx-button", 32), i()
    }
    if (t & 2) {
        let e = m(2);
        r(14), l("src", e.qrCode, je), r(6), x(e.secret), r(), l("formGroup", e.setupForm), r(3), l("width", "100%")("height", 40)("useSubmitBehavior", !0)
    }
}

function jd(t, c) {
    if (t & 1 && (n(0, "div", 22), d(1, Hd, 25, 6), i()), t & 2) {
        let e = m();
        r(), u(e.qrCode ? 1 : -1)
    }
}

function zd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 22)(1, "p", 33), s(2, "Enter your password to confirm disabling two-factor authentication."), i(), n(3, "form", 30), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.onConfirmDisable())
        }), n(4, "div", 34)(5, "label", 35), s(6, "Password"), i(), p(7, "app-password", 36), i(), p(8, "dx-button", 37), i()()
    }
    if (t & 2) {
        let e = m();
        r(3), l("formGroup", e.disableForm), r(4), l("isEditMode", !e.isDisabling), r(), l("width", "100%")("height", 40)("disabled", e.isDisabling)("useSubmitBehavior", !0)
    }
}

function Qd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 22)(1, "p", 33), s(2, "This will invalidate your existing backup codes and generate new ones. Enter your password to confirm."), i(), n(3, "form", 30), _("ngSubmit", function() {
            g(e);
            let a = m();
            return C(a.onConfirmRegenerate())
        }), n(4, "div", 34)(5, "label", 35), s(6, "Password"), i(), p(7, "app-password", 36), i(), p(8, "dx-button", 38), i()()
    }
    if (t & 2) {
        let e = m();
        r(3), l("formGroup", e.regenerateForm), r(4), l("isEditMode", !e.isRegenerating), r(), l("width", "100%")("height", 40)("disabled", e.isRegenerating)("useSubmitBehavior", !0)
    }
}

function Yd(t, c) {
    if (t & 1 && (n(0, "div", 41)(1, "code", 46), s(2), i()()), t & 2) {
        let e = c.$implicit;
        r(2), x(e)
    }
}

function Kd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 22)(1, "p", 39), s(2, "Save these codes in a safe place. Each code can only be used once."), i(), n(3, "div", 40), U(4, Yd, 3, 1, "div", 41, Ee), i(), n(6, "div", 42)(7, "dx-button", 43), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.copyBackupCodes())
        }), i(), n(8, "dx-button", 44), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.downloadBackupCodes())
        }), i()(), n(9, "dx-button", 45), _("onClick", function() {
            g(e);
            let a = m();
            return C(a.closeBackupCodes())
        }), i()()
    }
    if (t & 2) {
        let e = m();
        r(4), W(e.backupCodes), r(5), l("width", "100%")("height", 40)
    }
}
var Sr = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.twoFactorService = v(ca), this.loaderService = v(Qe), this.toastNotificationService = v(N), this.formService = v(B), this.fb = new z, this.isEnabled = !1, this.remainingBackupCodes = 0, this.isLoading = !0, this.showSetupDialog = !1, this.qrCode = "", this.secret = "", this.backupCodes = [], this.showBackupCodes = !1, this.showDisableDialog = !1, this.isDisabling = !1, this.showRegenerateDialog = !1, this.isRegenerating = !1
        }
        ngOnInit() {
            this.setupForm = this.fb.group({
                code: ["", [k.required]]
            }), this.disableForm = this.fb.group({
                password: ["", [k.required]]
            }), this.regenerateForm = this.fb.group({
                password: ["", [k.required]]
            }), this.loadStatus()
        }
        loadStatus() {
            this.isLoading = !0, this.twoFactorService.getStatus().subscribe({
                next: e => {
                    this.isEnabled = e.is_enabled, this.remainingBackupCodes = e.remaining_backup_codes, this.isLoading = !1
                },
                error: () => {
                    this.isLoading = !1
                }
            })
        }
        onEnableClick() {
            this.loaderService.show(), this.twoFactorService.setup().subscribe({
                next: e => {
                    this.qrCode = e.qr_code, this.secret = e.manual_entry_key, this.showSetupDialog = !0, this.loaderService.hide()
                },
                error: e => {
                    this.toastNotificationService.error(e.error ? .message || "Failed to start 2FA setup."), this.loaderService.hide()
                }
            })
        }
        onConfirmSetup() {
            if (!this.setupForm.valid) {
                this.formService.validateFormFields(this.setupForm);
                return
            }
            this.loaderService.show(), this.twoFactorService.confirm(this.setupForm.value.code).subscribe({
                next: e => {
                    this.backupCodes = e.backup_codes, this.showSetupDialog = !1, this.showBackupCodes = !0, this.isEnabled = !0, this.remainingBackupCodes = 8, this.setupForm.reset(), this.toastNotificationService.success("Two-factor authentication has been enabled."), this.loaderService.hide()
                },
                error: e => {
                    this.toastNotificationService.error(e.error ? .message || "Invalid verification code."), this.setupForm.get("code").reset(), this.loaderService.hide()
                }
            })
        }
        onDisableClick() {
            this.showDisableDialog = !0, this.disableForm.reset()
        }
        onConfirmDisable() {
            if (!this.disableForm.valid) {
                this.formService.validateFormFields(this.disableForm);
                return
            }
            this.isDisabling = !0, this.twoFactorService.disable(this.disableForm.value.password).subscribe({
                next: () => {
                    this.isEnabled = !1, this.remainingBackupCodes = 0, this.showDisableDialog = !1, this.disableForm.reset(), this.toastNotificationService.success("Two-factor authentication has been disabled."), this.isDisabling = !1
                },
                error: e => {
                    this.toastNotificationService.error(e.error ? .message || "Failed to disable 2FA."), this.isDisabling = !1
                }
            })
        }
        onRegenerateClick() {
            this.showRegenerateDialog = !0, this.regenerateForm.reset()
        }
        onConfirmRegenerate() {
            if (!this.regenerateForm.valid) {
                this.formService.validateFormFields(this.regenerateForm);
                return
            }
            this.isRegenerating = !0, this.twoFactorService.regenerateBackupCodes(this.regenerateForm.value.password).subscribe({
                next: e => {
                    this.backupCodes = e.backup_codes, this.remainingBackupCodes = 8, this.showRegenerateDialog = !1, this.showBackupCodes = !0, this.regenerateForm.reset(), this.toastNotificationService.success("Backup codes have been regenerated."), this.isRegenerating = !1
                },
                error: e => {
                    this.toastNotificationService.error(e.error ? .message || "Failed to regenerate backup codes."), this.isRegenerating = !1
                }
            })
        }
        copyBackupCodes() {
            let e = this.backupCodes.join(`
`);
            navigator.clipboard.writeText(e), this.toastNotificationService.success("Backup codes copied to clipboard.")
        }
        downloadBackupCodes() {
            let e = `BytePhase Two-Factor Authentication Backup Codes

` + this.backupCodes.join(`
`) + `

Keep these codes safe. Each code can only be used once.`,
                o = new Blob([e], {
                    type: "text/plain"
                }),
                a = window.URL.createObjectURL(o),
                h = document.createElement("a");
            h.href = a, h.download = "bytephase-2fa-backup-codes.txt", h.click(), window.URL.revokeObjectURL(a)
        }
        closeBackupCodes() {
            this.showBackupCodes = !1, this.backupCodes = []
        }
        closeSetupDialog() {
            this.showSetupDialog = !1, this.setupForm.reset()
        }
        closeDisableDialog() {
            this.showDisableDialog = !1, this.disableForm.reset()
        }
        closeRegenerateDialog() {
            this.showRegenerateDialog = !1, this.regenerateForm.reset()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-two-factor-settings"]
                ],
                standalone: !1,
                decls: 11,
                vars: 29,
                consts: [
                    [1, "container-fluid", "p-4"],
                    ["height", "40", "width", "40", 3, "visible"],
                    ["title", "Set Up Two-Factor Authentication", 3, "onHiding", "visible", "dragEnabled", "showCloseButton", "showTitle", "width", "height"],
                    ["class", "p-3", 4, "dxTemplate", "dxTemplateOf"],
                    ["title", "Disable Two-Factor Authentication", 3, "onHiding", "visible", "dragEnabled", "showCloseButton", "showTitle", "width", "height"],
                    ["title", "Regenerate Backup Codes", 3, "onHiding", "visible", "dragEnabled", "showCloseButton", "showTitle", "width", "height"],
                    ["title", "Your Backup Codes", 3, "onHiding", "visible", "dragEnabled", "showCloseButton", "showTitle", "width", "height"],
                    [1, "fw-semibold", "mb-3"],
                    ["role", "alert", 1, "alert", "alert-info", "d-flex", "align-items-start", "mb-4"],
                    [1, "fa-thin", "fa-circle-info", "me-2", "mt-1"],
                    [1, "d-flex", "flex-column", "flex-md-row", "align-items-md-center", "p-3", "border", "rounded", "mb-3", "gap-2"],
                    [1, "d-flex", "flex-column", "flex-md-row", "align-items-md-center", "p-3", "border", "rounded", "border-success", "mb-3", "gap-2"],
                    [1, "flex-grow-1"],
                    [1, "mb-1"],
                    [1, "text-muted"],
                    [1, "d-flex", "mobile-action-buttons"],
                    ["text", "Enable 2FA", "type", "default", "stylingMode", "contained", 3, "onClick"],
                    [1, "mb-1", "text-success"],
                    [1, "fa-thin", "fa-shield-check", "me-2"],
                    [1, "d-flex", "gap-2", "mobile-action-buttons"],
                    ["text", "Regenerate Backup Codes", "type", "normal", "stylingMode", "outlined", 3, "onClick"],
                    ["text", "Disable 2FA", "type", "danger", "stylingMode", "outlined", 3, "onClick"],
                    [1, "p-3"],
                    [1, "text-muted", "text-center", "mb-1"],
                    [1, "text-muted", "text-center", "small", "mb-3"],
                    [1, "text-center", "mb-3"],
                    ["alt", "QR Code", 1, "img-fluid", 2, "max-width", "200px", 3, "src"],
                    [1, "mt-2"],
                    [1, "mt-1"],
                    [1, "fs-6", "user-select-all", "p-1"],
                    [3, "ngSubmit", "formGroup"],
                    ["formControlName", "code", 3, "otpComplete"],
                    ["text", "Verify & Enable", "type", "default", "stylingMode", "contained", 3, "width", "height", "useSubmitBehavior"],
                    [1, "text-muted", "mb-3"],
                    [1, "mb-3"],
                    [1, "form-label", "mb-2"],
                    ["formControlName", "password", "placeholder", "Enter your password", 3, "isEditMode"],
                    ["text", "Disable 2FA", "type", "danger", "stylingMode", "contained", 3, "width", "height", "disabled", "useSubmitBehavior"],
                    ["text", "Regenerate Codes", "type", "default", "stylingMode", "contained", 3, "width", "height", "disabled", "useSubmitBehavior"],
                    [1, "text-muted", "text-center", "mb-3"],
                    [1, "row", "row-cols-2", "g-2", "mb-3"],
                    [1, "col", "text-center"],
                    [1, "d-flex", "gap-2", "justify-content-center", "mb-3"],
                    ["text", "Copy Codes", "type", "default", "stylingMode", "outlined", 3, "onClick"],
                    ["text", "Download", "type", "default", "stylingMode", "outlined", 3, "onClick"],
                    ["text", "Done", "type", "default", "stylingMode", "contained", 3, "onClick", "width", "height"],
                    [1, "fs-6", "fw-bold", "user-select-all"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 0), d(1, Gd, 1, 1, "dx-load-indicator", 1)(2, qd, 8, 1), i(), n(3, "dx-popup", 2), _("onHiding", function() {
                        return a.closeSetupDialog()
                    }), T(4, jd, 2, 1, "div", 3), i(), n(5, "dx-popup", 4), _("onHiding", function() {
                        return a.closeDisableDialog()
                    }), T(6, zd, 9, 6, "div", 3), i(), n(7, "dx-popup", 5), _("onHiding", function() {
                        return a.closeRegenerateDialog()
                    }), T(8, Qd, 9, 6, "div", 3), i(), n(9, "dx-popup", 6), _("onHiding", function() {
                        return a.closeBackupCodes()
                    }), T(10, Kd, 10, 2, "div", 3), i()), o & 2 && (r(), u(a.isLoading ? 1 : 2), r(2), l("visible", a.showSetupDialog)("dragEnabled", !1)("showCloseButton", !0)("showTitle", !0)("width", 450)("height", "auto"), r(), l("dxTemplateOf", "content"), r(), l("visible", a.showDisableDialog)("dragEnabled", !1)("showCloseButton", !0)("showTitle", !0)("width", 400)("height", "auto"), r(), l("dxTemplateOf", "content"), r(), l("visible", a.showRegenerateDialog)("dragEnabled", !1)("showCloseButton", !0)("showTitle", !0)("width", 400)("height", "auto"), r(), l("dxTemplateOf", "content"), r(), l("visible", a.showBackupCodes)("dragEnabled", !1)("showCloseButton", !0)("showTitle", !0)("width", 450)("height", "auto"), r(), l("dxTemplateOf", "content"))
                },
                dependencies: [ra, jo, G, _e, No, re, V, L, P, A, D],
                styles: ["code[_ngcontent-%COMP%]{padding:4px 8px;background-color:#0000000d;border-radius:4px}"]
            })
        }
    }
    return t
})();

function Zd(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-part-category", 2), _("partCategoryCancelClick", function() {
            g(e);
            let a = m();
            return C(a.isVisiblePartCategoryPopup = !1)
        })("partCategorySaveClick", function() {
            g(e);
            let a = m();
            return C(a.onPartCategorySave())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("partCategory", e.partCategory)("isCreate", e.isCreate)("isVisiblePopup", e.isVisiblePartCategoryPopup)
    }
}
var br = (() => {
    class t {
        constructor(e) {
            this.service = e, this.formatMessage = f, this.isVisiblePartCategoryPopup = !1, this.entity = Q.PART_CATEGORY, this.isCreate = !1, this.columns = [{
                dataField: "name",
                caption: f("common_category"),
                allowSorting: !0
            }, {
                dataField: "updated_at",
                caption: f("common_updated_on"),
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "created_at",
                caption: f("common_created_on"),
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "",
                caption: "",
                cellTemplate: "actionTemplate",
                alignment: "right"
            }], this.PERMISSION_LIST = b
        }
        ngOnInit() {}
        create() {
            this.isCreate = !0, this.isVisiblePartCategoryPopup = !0
        }
        onPartCategorySave() {
            this.isCreate = !1, this.isVisiblePartCategoryPopup = !1, this.partCategory = null, this.dataGrid.getData()
        }
        edit(e) {
            this.isCreate = !1, this.partCategory = e, this.isVisiblePartCategoryPopup = !0
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(I(Fo))
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-part-category-list"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me(Re, 5), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.dataGrid = h.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 9,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "deleteAccessPermissionName", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "service", "searchPanelPlaceholderText", "writeAccessPermissionName"],
                    [3, "partCategory", "isCreate", "isVisiblePopup"],
                    [3, "partCategoryCancelClick", "partCategorySaveClick", "partCategory", "isCreate", "isVisiblePopup"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "app-data-grid", 0), _("dataGridAddNewClick", function() {
                        return a.create()
                    })("dataGridEditClick", function(w) {
                        return a.edit(w)
                    }), i(), d(1, Zd, 1, 3, "app-part-category", 1)), o & 2 && (l("columns", a.columns)("deleteAccessPermissionName", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE)("entity", a.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", a.service)("searchPanelPlaceholderText", "search_panel_part_category_placeholder")("writeAccessPermissionName", a.PERMISSION_LIST.BUSINESS_SETTING_WRITE), r(), u(a.isVisiblePartCategoryPopup ? 1 : -1))
                },
                dependencies: [Re, Bo],
                encapsulation: 2
            })
        }
    }
    return t
})();
var $d = ["faviconUploader"];

function Xd(t, c) {
    t & 1 && (n(0, "div", 2), p(1, "i", 22), n(2, "span"), s(3, "White Label is not enabled for your account. Contact your administrator to unlock this feature."), i()())
}

function Jd(t, c) {
    if (t & 1 && p(0, "app-alert-panel", 3), t & 2) {
        let e = m();
        l("message", "Personalize your CRM experience with White Label. Connect a custom domain to replace your current URL (" + e.currentHostname + "/settings) with your own branded URL (e.g., crm.yourdomain.com/settings). Along with custom branding and logo \u2014 give your customers a fully professional, white-labeled experience.")("isVisibleCancelButton", !1)
    }
}

function e0(t, c) {
    t & 1 && p(0, "app-skeleton-loader", 11), t & 2 && l("rows", 2)("columns", 1)
}

function t0(t, c) {
    t & 1 && (n(0, "span", 28), p(1, "i", 32), s(2, "SSL Active "), i())
}

function i0(t, c) {
    t & 1 && (n(0, "span", 33), p(1, "i", 34), s(2, "Ownership Verified "), i(), n(3, "span", 35), p(4, "i", 36), s(5, "Pending DNS "), i())
}

function n0(t, c) {
    t & 1 && (n(0, "span", 33), p(1, "i", 34), s(2, "Ownership Verified "), i(), n(3, "span", 35), p(4, "i", 37), s(5, "Provisioning SSL... "), i())
}

function o0(t, c) {
    t & 1 && (n(0, "span", 29), p(1, "i", 38), s(2, "SSL Provisioning Failed "), i())
}

function a0(t, c) {
    t & 1 && (n(0, "span", 30), p(1, "i", 36), s(2, "Pending Ownership Verification "), i())
}

function r0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 40), _("onClickEvent", function() {
            g(e);
            let a = m(3);
            return C(a.isVisibleRemoveConfirmation = !0)
        }), i()
    }
}

function s0(t, c) {
    if (t & 1 && T(0, r0, 1, 0, "app-dx-outline-button", 39), t & 2) {
        let e = m(2);
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function l0(t, c) {
    t & 1 && (n(0, "div", 12), p(1, "i", 15), s(2, " To manage your custom domain, please access this page from your BytePhase URL. "), i())
}

function c0(t, c) {
    if (t & 1 && (n(0, "div", 19), p(1, "i", 57), s(2), i()), t & 2) {
        let e = m(4);
        r(2), E(" ", e.ownershipResult.message, " ")
    }
}

function m0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 58), _("onClickEvent", function() {
            g(e);
            let a = m(4);
            return C(a.verifyOwnership())
        }), i()
    }
    if (t & 2) {
        let e = m(4);
        l("disabled", e.isVerifyingOwnership)
    }
}

function p0(t, c) {
    if (t & 1 && (n(0, "div", 41)(1, "h6", 44)(2, "span", 45), s(3, "Step 1"), i(), s(4, "Verify Domain Ownership "), i(), n(5, "p", 46), s(6, "Add the following TXT record with your domain registrar to prove you own this domain:"), i(), n(7, "div", 47), p(8, "i", 48), n(9, "strong"), s(10, "How to:"), i(), s(11, " Log in to your domain registrar (e.g., GoDaddy, Namecheap, Cloudflare), go to DNS settings, and add a new TXT record with the Name and Value shown below. "), i(), n(12, "table", 49)(13, "thead")(14, "tr")(15, "th", 50), s(16, "Type"), i(), n(17, "th", 50), s(18, "Name / Host"), i(), n(19, "th", 50), s(20, "Value"), i()()(), n(21, "tbody")(22, "tr")(23, "td")(24, "span", 27), s(25, "TXT"), i()(), n(26, "td")(27, "div", 51)(28, "span", 52), s(29), i(), p(30, "app-copy-to-clipboard", 53), i()(), n(31, "td")(32, "div", 51)(33, "span", 52), s(34), i(), p(35, "app-copy-to-clipboard", 53), i()()()()(), n(36, "p", 54), p(37, "i", 55), s(38, ' DNS changes can take up to 48 hours to propagate. Click "Verify Ownership" once your TXT record is configured. '), i(), d(39, c0, 3, 1, "div", 19), T(40, m0, 1, 1, "app-dx-outline-button", 56), i()), t & 2) {
        let e = m(3);
        r(29), x(e.txtRecordHost), r(), l("textToBeCopied", e.txtRecordHost), r(4), E("bytephase-verify-", e.customDomain.verification_token), r(), l("textToBeCopied", "bytephase-verify-" + e.customDomain.verification_token), r(4), u(e.ownershipResult && !e.ownershipResult.verified ? 39 : -1), r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function d0(t, c) {
    if (t & 1 && (n(0, "table", 59)(1, "thead")(2, "tr")(3, "th", 62), s(4, "Type"), i(), n(5, "th", 63), s(6, "Name / Host"), i(), n(7, "th", 50), s(8, "Value"), i()()(), n(9, "tbody")(10, "tr")(11, "td")(12, "span", 27), s(13, "CNAME"), i()(), n(14, "td", 64)(15, "div", 51)(16, "span", 52), s(17), i(), p(18, "app-copy-to-clipboard", 53), i()(), n(19, "td", 64)(20, "div", 51)(21, "span", 52), s(22), i(), p(23, "app-copy-to-clipboard", 53), i()()()()()), t & 2) {
        let e = m(4);
        r(17), x(e.customDomain.acm_validation_cname_name), r(), l("textToBeCopied", e.customDomain.acm_validation_cname_name), r(4), x(e.customDomain.acm_validation_cname_value), r(), l("textToBeCopied", e.customDomain.acm_validation_cname_value)
    }
}

function u0(t, c) {
    if (t & 1 && (n(0, "div", 19), p(1, "i", 57), s(2), i()), t & 2) {
        let e = m(4);
        r(2), E(" ", e.dnsResult.message, " ")
    }
}

function _0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 65), _("onClickEvent", function() {
            g(e);
            let a = m(4);
            return C(a.verifyDns())
        }), i()
    }
    if (t & 2) {
        let e = m(4);
        l("disabled", e.isVerifyingDns)
    }
}

function f0(t, c) {
    if (t & 1 && (n(0, "div", 41)(1, "h6", 44)(2, "span", 45), s(3, "Step 2"), i(), s(4, "Add DNS Records "), i(), n(5, "p", 46), s(6, "Add the following CNAME record for SSL certificate validation:"), i(), n(7, "div", 47), p(8, "i", 48), n(9, "strong"), s(10, "How to:"), i(), s(11, " Add this CNAME record in your DNS settings. This is required by AWS to issue an SSL certificate for your domain. Do not remove this record. "), i(), d(12, d0, 24, 4, "table", 59), n(13, "div", 47), p(14, "i", 60), s(15, ' SSL certificate is being validated automatically. This usually takes 5-30 minutes after adding the CNAME record. You can also click "Check Status" to verify manually. '), i(), d(16, u0, 3, 1, "div", 19), T(17, _0, 1, 1, "app-dx-outline-button", 61), i()), t & 2) {
        let e = m(3);
        r(12), u(e.customDomain.acm_validation_cname_name ? 12 : -1), r(4), u(e.dnsResult && !e.dnsResult.verified ? 16 : -1), r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function g0(t, c) {
    if (t & 1 && (n(0, "div", 19), p(1, "i", 57), s(2), i()), t & 2) {
        let e = m(4);
        r(2), E(" ", e.dnsResult.message, " ")
    }
}

function C0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 65), _("onClickEvent", function() {
            g(e);
            let a = m(4);
            return C(a.verifyDns())
        }), i()
    }
    if (t & 2) {
        let e = m(4);
        l("disabled", e.isVerifyingDns)
    }
}

function v0(t, c) {
    if (t & 1 && (n(0, "div", 41)(1, "h6", 44)(2, "span", 45), s(3, "Step 3"), i(), s(4, "Point Your Domain "), i(), n(5, "p", 46), s(6, "Add the following CNAME record to point your domain to our CDN:"), i(), n(7, "div", 47), p(8, "i", 48), n(9, "strong"), s(10, "How to:"), i(), s(11, " Add this CNAME record in your DNS settings. This points your domain to our servers. If you have an existing A or CNAME record for this domain, remove it first. "), i(), n(12, "table", 49)(13, "thead")(14, "tr")(15, "th", 50), s(16, "Type"), i(), n(17, "th", 50), s(18, "Name / Host"), i(), n(19, "th", 50), s(20, "Value"), i()()(), n(21, "tbody")(22, "tr")(23, "td")(24, "span", 27), s(25, "CNAME"), i()(), n(26, "td")(27, "div", 51)(28, "span", 52), s(29), i(), p(30, "app-copy-to-clipboard", 53), i()(), n(31, "td")(32, "div", 51)(33, "span", 52), s(34), i(), p(35, "app-copy-to-clipboard", 53), i()()()()(), n(36, "div", 47), p(37, "i", 60), s(38, ' Waiting for DNS to propagate. This will be verified automatically. You can also click "Check Status" to verify manually. '), i(), d(39, g0, 3, 1, "div", 19), T(40, C0, 1, 1, "app-dx-outline-button", 61), i()), t & 2) {
        let e = m(3);
        r(29), x(e.cnameHost), r(), l("textToBeCopied", e.cnameHost), r(4), x(e.customDomain.cloudfront_domain_name), r(), l("textToBeCopied", e.customDomain.cloudfront_domain_name), r(4), u(e.dnsResult && !e.dnsResult.verified ? 39 : -1), r(), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function h0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-dx-outline-button", 69), _("onClickEvent", function() {
            g(e);
            let a = m(4);
            return C(a.verifyDns())
        }), i()
    }
    if (t & 2) {
        let e = m(4);
        l("disabled", e.isVerifyingDns)
    }
}

function x0(t, c) {
    if (t & 1 && (n(0, "div", 42)(1, "div", 66), p(2, "i", 67), s(3, " SSL provisioning failed. Please verify your DNS records are correct and try again. "), i(), T(4, h0, 1, 1, "app-dx-outline-button", 68), i()), t & 2) {
        let e = m(3);
        r(4), l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function S0(t, c) {
    if (t & 1 && (n(0, "div", 43), p(1, "i", 70), s(2, " Your custom domain is fully active with SSL. Users can access your application at "), n(3, "strong"), s(4), i(), s(5, ". "), i()), t & 2) {
        let e = m(3);
        r(4), E("https://", e.customDomain.domain)
    }
}

function b0(t, c) {
    if (t & 1 && (d(0, p0, 41, 6, "div", 41), d(1, f0, 18, 3, "div", 41), d(2, v0, 41, 6, "div", 41), d(3, x0, 5, 1, "div", 42), d(4, S0, 6, 1, "div", 43)), t & 2) {
        let e = m(2);
        u(e.customDomain.certificate_status === "pending_txt" ? 0 : -1), r(), u(e.customDomain.certificate_status === "pending_acm" ? 1 : -1), r(), u(e.customDomain.certificate_status === "pending_dns" ? 2 : -1), r(), u(e.customDomain.certificate_status === "provisioning_failed" ? 3 : -1), r(), u(e.customDomain.certificate_status === "ssl_active" ? 4 : -1)
    }
}

function y0(t, c) {
    if (t & 1 && (n(0, "div", 23)(1, "div", 24)(2, "div")(3, "div", 25), p(4, "i", 26), n(5, "span", 27), s(6), i()(), d(7, t0, 3, 0, "span", 28)(8, i0, 6, 0)(9, n0, 6, 0)(10, o0, 3, 0, "span", 29)(11, a0, 3, 0, "span", 30), i(), d(12, s0, 1, 1, "app-dx-outline-button", 31), i()(), d(13, l0, 3, 0, "div", 12), d(14, b0, 5, 5)), t & 2) {
        let e = m();
        r(6), x(e.customDomain.domain), r(), u(e.customDomain.certificate_status === "ssl_active" ? 7 : e.customDomain.certificate_status === "pending_dns" ? 8 : e.customDomain.certificate_status === "pending_acm" ? 9 : e.customDomain.certificate_status === "provisioning_failed" ? 10 : 11), r(5), u(e.isOnCustomDomain ? -1 : 12), r(), u(e.isOnCustomDomain ? 13 : -1), r(), u(e.isOnCustomDomain ? -1 : 14)
    }
}

function T0(t, c) {
    t & 1 && (n(0, "div", 12), p(1, "i", 15), s(2, " To manage your custom domain, please access this page from your BytePhase URL. "), i())
}

function E0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "label", 72), s(2, "Domain Name"), i(), n(3, "div", 73)(4, "dx-text-box", 74), X("valueChange", function(a) {
            g(e);
            let h = m(2);
            return $(h.newDomain, a) || (h.newDomain = a), C(a)
        }), i(), n(5, "app-dx-outline-button", 75), _("onClickEvent", function() {
            g(e);
            let a = m(2);
            return C(a.addDomain())
        }), i()(), n(6, "div", 76), s(7, " Enter the domain you want to connect. You'll need to verify ownership and configure DNS records. "), i(), n(8, "div", 77), p(9, "i", 48), n(10, "strong"), s(11, "Tip:"), i(), s(12, " We recommend using a subdomain like "), n(13, "strong"), s(14, "crm.yourdomain.com"), i(), s(15, ". Subdomains work with all DNS providers. Apex domains (e.g., yourdomain.com) require CNAME flattening support. "), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(4), Z("value", e.newDomain), r(), l("disabled", e.isAddingDomain || !(e.newDomain != null && e.newDomain.trim()))
    }
}

function w0(t, c) {
    if (t & 1 && T(0, E0, 16, 2, "div", 71), t & 2) {
        let e = m();
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function I0(t, c) {
    t & 1 && s(0, " Configure a custom domain above to unlock this feature. ")
}

function k0(t, c) {
    t & 1 && s(0, " Available once your custom domain is fully active with SSL. ")
}

function M0(t, c) {
    if (t & 1 && (n(0, "div", 19), p(1, "i", 57), d(2, I0, 1, 0)(3, k0, 1, 0), i()), t & 2) {
        let e = m();
        r(2), u(e.customDomain ? 3 : 2)
    }
}

function N0(t, c) {
    if (t & 1 && (n(0, "div", 20)(1, "div", 78), p(2, "img", 79), i()()), t & 2) {
        let e = m();
        r(2), l("alt", "favicon")("src", e.faviconUrl(), je)
    }
}

function P0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div")(1, "dx-file-uploader", 80, 0), _("change", function(a) {
            g(e);
            let h = m(2);
            return C(h.onFaviconChange(a))
        }), i(), n(3, "p", 81), s(4), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(), l("allowCanceling", !1)("disabled", e.isUploadingFavicon || (e.customDomain == null ? null : e.customDomain.certificate_status) !== "ssl_active")("maxFileSize", e.faviconUploadLimit)("multiple", !1), r(3), x(e.formatMessage("favicon_validation"))
    }
}

function V0(t, c) {
    if (t & 1 && T(0, P0, 5, 5, "div", 71), t & 2) {
        let e = m();
        l("ngxPermissionsOnly", e.PERMISSION_LIST.BUSINESS_SETTING_WRITE)
    }
}

function A0(t, c) {
    t & 1 && (n(0, "div", 12), p(1, "i", 15), s(2, " To manage your favicon, please access this page from your BytePhase URL. "), i())
}

function L0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 82), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.removeDomain())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.isVisibleRemoveConfirmation = !1)
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("confirmButtonText", "delete")("confirmationMessage", e.formatMessage("confirm_remove_custom_domain"))("isSaving", e.isRemovingDomain)
    }
}
var yr = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.PERMISSION_LIST = b, this.isOnCustomDomain = !to, this.currentHostname = window.location.hostname, this.isWhiteLabelEnabled = !1, this.api = v(he), this.accountService = v(be), this.tenantService = v(ie), this.toastNotificationService = v(N), this.configService = v(Xt), this.faviconUrl = Rt(() => this.tenantService.config() ? .favicon_url ? ? null), this.customDomain = null, this.newDomain = "", this.isAddingDomain = !1, this.isVerifyingOwnership = !1, this.isVerifyingDns = !1, this.isRemovingDomain = !1, this.isLoadingDomain = !0, this.isVisibleRemoveConfirmation = !1, this.ownershipResult = null, this.dnsResult = null, this.faviconUploadLimit = 102400, this.isUploadingFavicon = !1
        }
        get cnameHost() {
            let o = (this.customDomain ? .domain || "").split(".");
            return o.length > 2 ? o.slice(0, o.length - 2).join(".") : "@"
        }
        get txtRecordHost() {
            let o = (this.customDomain ? .domain || "").split(".");
            return o.length > 2 ? `_bytephase.${o.slice(0,o.length-2).join(".")}` : "_bytephase"
        }
        ngOnInit() {
            let e = this.tenantService.config();
            this.isWhiteLabelEnabled = !!e ? .is_white_label, this.isWhiteLabelEnabled ? this.loadCustomDomain() : this.isLoadingDomain = !1
        }
        loadCustomDomain() {
            this.isLoadingDomain = !0, this.api.get("accounts/custom-domain").subscribe({
                next: e => {
                    this.customDomain = e.custom_domain
                },
                error: () => {
                    this.toastNotificationService.error("notification_custom_domain_load_error")
                }
            }).add(() => {
                this.isLoadingDomain = !1
            })
        }
        addDomain() {
            this.newDomain ? .trim() && (this.isAddingDomain = !0, this.api.post("accounts/custom-domain", {
                domain: this.newDomain.trim().toLowerCase()
            }).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_custom_domain_added"), this.newDomain = "", this.loadCustomDomain()
                },
                error: e => {
                    let o = e ? .error ? .message || "notification_custom_domain_add_error";
                    this.toastNotificationService.error(o)
                }
            }).add(() => {
                this.isAddingDomain = !1
            }))
        }
        verifyOwnership() {
            this.isVerifyingOwnership = !0, this.ownershipResult = null, this.api.post("accounts/custom-domain/verify-ownership", {}).subscribe({
                next: e => {
                    this.ownershipResult = e, e.verified && (this.toastNotificationService.success("notification_ownership_verified"), this.loadCustomDomain())
                },
                error: () => {
                    this.toastNotificationService.error("notification_ownership_verify_error")
                }
            }).add(() => {
                this.isVerifyingOwnership = !1
            })
        }
        verifyDns() {
            this.isVerifyingDns = !0, this.dnsResult = null, this.api.post("accounts/custom-domain/verify-dns", {}).subscribe({
                next: e => {
                    this.dnsResult = e, e.verified && (this.toastNotificationService.success("notification_dns_verified"), this.loadCustomDomain())
                },
                error: () => {
                    this.toastNotificationService.error("notification_dns_verify_error")
                }
            }).add(() => {
                this.isVerifyingDns = !1
            })
        }
        onFaviconChange(e) {
            let o = e.target.files ? .[0];
            if (o) {
                if (o.size > this.faviconUploadLimit) {
                    this.toastNotificationService.error("notification_favicon_size_error"), this.faviconUploader ? .instance.reset();
                    return
                }
                this.uploadFavicon(o)
            }
        }
        uploadFavicon(e) {
            let o = new FormData;
            o.append("file", e, e.name), this.isUploadingFavicon = !0, this.api.post("accounts/custom-domain/favicon", o).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_favicon_upload_success"), this.faviconUploader ? .instance.reset(), this.refreshTenantConfig()
                },
                error: a => {
                    let h = a ? .error ? .message || "notification_favicon_upload_error";
                    this.toastNotificationService.error(h)
                }
            }).add(() => {
                this.isUploadingFavicon = !1
            })
        }
        refreshTenantConfig() {
            this.accountService.getTenant().subscribe({
                next: e => this.configService.setAppConfig(e)
            })
        }
        removeDomain() {
            this.isRemovingDomain = !0, this.api.delete("accounts/custom-domain").subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_custom_domain_removed"), this.customDomain = null, this.ownershipResult = null, this.dnsResult = null
                },
                error: () => {
                    this.toastNotificationService.error("notification_custom_domain_remove_error")
                }
            }).add(() => {
                this.isRemovingDomain = !1, this.isVisibleRemoveConfirmation = !1
            })
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-white-label-settings"]
                ],
                viewQuery: function(o, a) {
                    if (o & 1 && Me($d, 5), o & 2) {
                        let h;
                        Ne(h = Pe()) && (a.faviconUploader = h.first)
                    }
                },
                standalone: !1,
                decls: 56,
                vars: 12,
                consts: [
                    ["faviconUploader", ""],
                    [1, "container-fluid", "px-0"],
                    [1, "alert", "alert-warning", "d-flex", "align-items-center", "gap-2", "mb-3"],
                    [3, "message", "isVisibleCancelButton"],
                    [1, "row", "g-3"],
                    [1, "col-12", "col-lg-8"],
                    [1, "card", "border", "rounded-3", 2, "color", "var(--primary-text)"],
                    [1, "card-header", "border-bottom", "p-3"],
                    [1, "h5", "mb-0"],
                    [1, "text-muted", "small", "mb-0", "mt-1"],
                    [1, "card-body", "p-3"],
                    ["type", "form", 3, "rows", "columns"],
                    [1, "alert", "alert-info", "small", "mb-0"],
                    [1, "col-12", "col-lg-4"],
                    [1, "h6", "mb-0"],
                    [1, "fa-thin", "fa-circle-info", "me-2"],
                    [1, "list-unstyled", "mb-0", "small"],
                    [1, "mb-2"],
                    [1, "fa-thin", "fa-check", "text-success", "me-2"],
                    [1, "alert", "alert-warning", "small", "mb-3"],
                    [1, "row", "mb-3"],
                    ["title", "Remove Custom Domain", 3, "confirmButtonText", "confirmationMessage", "isSaving"],
                    [1, "fa-solid", "fa-lock", "text-warning"],
                    [1, "border", "rounded-3", "p-3", "mb-3"],
                    [1, "d-flex", "justify-content-between", "align-items-center"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-2"],
                    [1, "fa-thin", "fa-globe", "text-primary"],
                    [1, "fw-bold"],
                    [1, "badge", "bg-success"],
                    [1, "badge", "bg-danger"],
                    [1, "badge", "bg-warning", "text-dark"],
                    ["buttonType", "danger", "text", "delete"],
                    [1, "fa-thin", "fa-lock", "me-1"],
                    [1, "badge", "bg-info", "text-dark"],
                    [1, "fa-thin", "fa-check", "me-1"],
                    [1, "badge", "bg-warning", "text-dark", "ms-1"],
                    [1, "fa-thin", "fa-clock", "me-1"],
                    [1, "fa-thin", "fa-spinner-third", "fa-spin", "me-1"],
                    [1, "fa-thin", "fa-circle-xmark", "me-1"],
                    ["buttonType", "danger", "text", "delete", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "danger", "text", "delete", 3, "onClickEvent"],
                    [1, "border", "rounded-3", "p-3"],
                    [1, "border", "border-danger", "rounded-3", "p-3"],
                    [1, "alert", "alert-success", "small", "mb-0"],
                    [1, "fw-bold", "mb-1"],
                    [1, "badge", "bg-primary", "me-2"],
                    [1, "text-muted", "small", "mb-2"],
                    [1, "alert", "alert-info", "small", "mb-3"],
                    [1, "fa-solid", "fa-lightbulb", "me-2"],
                    [1, "table", "table-bordered", "mb-3", "align-middle", 2, "--bs-table-color", "var(--primary-text)", "--bs-table-bg", "var(--primary-bg)", "--bs-table-border-color", "var(--theme-border-color)"],
                    [1, "fw-semibold"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fw-bold", "font-monospace"],
                    [1, "flex-shrink-0", 3, "textToBeCopied"],
                    [1, "text-muted", "small", "mb-3"],
                    [1, "fa-thin", "fa-circle-info", "me-1"],
                    ["buttonType", "default", "text", "verify_ownership", 3, "disabled", "onClickEvent", 4, "ngxPermissionsOnly"],
                    [1, "fa-thin", "fa-triangle-exclamation", "me-2"],
                    ["buttonType", "default", "text", "verify_ownership", 3, "onClickEvent", "disabled"],
                    [1, "table", "table-bordered", "mb-3", "align-middle", 2, "--bs-table-color", "var(--primary-text)", "--bs-table-bg", "var(--primary-bg)", "--bs-table-border-color", "var(--theme-border-color)", "table-layout", "fixed"],
                    [1, "fa-thin", "fa-spinner-third", "fa-spin", "me-2"],
                    ["buttonType", "default", "text", "check_status", 3, "disabled", "onClickEvent", 4, "ngxPermissionsOnly"],
                    [1, "fw-semibold", 2, "width", "60px"],
                    [1, "fw-semibold", 2, "width", "45%"],
                    [2, "word-break", "break-all"],
                    ["buttonType", "default", "text", "check_status", 3, "onClickEvent", "disabled"],
                    [1, "alert", "alert-danger", "small", "mb-3"],
                    [1, "fa-thin", "fa-circle-xmark", "me-2"],
                    ["buttonType", "default", "text", "retry", 3, "disabled", "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "retry", 3, "onClickEvent", "disabled"],
                    [1, "fa-thin", "fa-lock", "me-2"],
                    [4, "ngxPermissionsOnly"],
                    [1, "form-label", "fw-medium", "small"],
                    [1, "d-flex", "gap-2"],
                    ["placeholder", "e.g., crm.yourbusiness.com", "stylingMode", "outlined", 1, "flex-grow-1", 3, "valueChange", "value"],
                    ["buttonType", "default", "text", "add_domain", 3, "onClickEvent", "disabled"],
                    [1, "text-muted", "small", "mt-2"],
                    [1, "alert", "alert-info", "small", "mt-3", "mb-0"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["height", "48", "width", "48", "loading", "lazy", 1, "img-fluid", 3, "alt", "src"],
                    ["accept", ".ico,.png,.svg,image/x-icon,image/vnd.microsoft.icon,image/png,image/svg+xml", "id", "custom-domain-favicon", "uploadMode", "useButtons", 3, "change", "allowCanceling", "disabled", "maxFileSize", "multiple"],
                    [1, "text-muted", "small", "mb-0"],
                    ["title", "Remove Custom Domain", 3, "confirmActionCallback", "rejectActionCallback", "confirmButtonText", "confirmationMessage", "isSaving"]
                ],
                template: function(o, a) {
                    o & 1 && (n(0, "div", 1), d(1, Xd, 4, 0, "div", 2), d(2, Jd, 1, 2, "app-alert-panel", 3), n(3, "div", 4)(4, "div", 5)(5, "div", 6)(6, "div", 7)(7, "div")(8, "span", 8), s(9, "Custom Domain"), i(), n(10, "p", 9), s(11, "Connect your own domain for a fully branded experience"), i()()(), n(12, "div", 10), d(13, e0, 1, 2, "app-skeleton-loader", 11)(14, y0, 15, 5)(15, T0, 3, 0, "div", 12)(16, w0, 1, 1, "div"), i()()(), n(17, "div", 13)(18, "div", 6)(19, "div", 7)(20, "span", 14), p(21, "i", 15), s(22, "How White Label Works "), i()(), n(23, "div", 10)(24, "ul", 16)(25, "li", 17), p(26, "i", 18), s(27, ' Your business name replaces "BytePhase" in emails and SMS '), i(), n(28, "li", 17), p(29, "i", 18), s(30, " Your logo appears instead of BytePhase logo "), i(), n(31, "li", 17), p(32, "i", 18), s(33, " Support email and phone use your business details "), i(), n(34, "li", 17), p(35, "i", 18), s(36, " Page titles show your brand name "), i(), n(37, "li", 17), p(38, "i", 18), s(39, " Connect a custom domain for full branding "), i(), n(40, "li"), p(41, "i", 18), s(42), i()()()()(), n(43, "div", 5)(44, "div", 6)(45, "div", 7)(46, "span", 8), s(47, "Custom Favicon"), i(), n(48, "p", 9), s(49, "Upload a .ico, .png, or .svg file shown in the browser tab on your custom domain"), i()(), n(50, "div", 10), d(51, M0, 4, 1, "div", 19), d(52, N0, 3, 2, "div", 20), d(53, V0, 1, 1, "div")(54, A0, 3, 0, "div", 12), i()()()()(), d(55, L0, 1, 3, "app-confirmation-popup", 21)), o & 2 && (r(), u(a.isWhiteLabelEnabled ? -1 : 1), r(), u(a.isWhiteLabelEnabled ? 2 : -1), r(), Ae("opacity-50", !a.isWhiteLabelEnabled)("pe-none", !a.isWhiteLabelEnabled), r(10), u(a.isLoadingDomain ? 13 : a.customDomain ? 14 : a.isOnCustomDomain ? 15 : 16), r(29), E(" Your URL changes from ", a.currentHostname, " to your own domain (e.g., crm.yourdomain.com) "), r(9), u((a.customDomain == null ? null : a.customDomain.certificate_status) !== "ssl_active" ? 51 : -1), r(), u(a.faviconUrl() ? 52 : -1), r(), u(a.isOnCustomDomain ? 54 : 53), r(2), u(a.isVisibleRemoveConfirmation ? 55 : -1))
                },
                dependencies: [Ye, pe, F, ei, we, xt, ae, ne],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Tr = (() => {
    class t {
        constructor() {
            this.SETTINGS_TYPE = gt
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-self-checkin-settings"]
                ],
                decls: 1,
                vars: 2,
                consts: [
                    ["id", "self-checkin-settings-title", 3, "settingType", "title"]
                ],
                template: function(o, a) {
                    o & 1 && p(0, "app-base-setting", 0), o & 2 && l("settingType", a.SETTINGS_TYPE.SELF_CHECK_IN_SETTINGS)("title", "self_check_in_settings")
                },
                dependencies: [nt, Zi],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Er = (t, c) => c.recipient,
    st = (t, c) => c.key,
    D0 = (t, c) => c.toggle;

function O0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 5)(1, "dx-button", 12), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.cancel())
        }), i(), n(2, "dx-button", 13), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(), l("text", e.formatMessage("common_cancel"))("disabled", !e.form.dirty || e.isSaving), r(), l("text", e.formatMessage("common_save"))("disabled", !e.form.dirty || e.isSaving)
    }
}

function F0(t, c) {
    if (t & 1 && (n(0, "div", 6), p(1, "i", 14), n(2, "span"), s(3), i()()), t & 2) {
        let e = m(2);
        r(3), x(e.formatMessage("notif_readonly_message"))
    }
}

function B0(t, c) {
    if (t & 1 && (n(0, "div", 15), p(1, "i"), n(2, "div")(3, "div", 16), s(4), i(), n(5, "div", 4), s(6), i()()()), t & 2) {
        let e = c.$implicit,
            o = m(2);
        r(), Ze(ki("", e.icon, " fs-5 text-primary")), r(3), x(o.formatMessage(e.title)), r(2), x(o.formatMessage(e.help))
    }
}

function R0(t, c) {
    if (t & 1 && p(0, "dx-switch", 27), t & 2) {
        let e = m().$implicit,
            o = m().$implicit,
            a = m(6);
        l("formControlName", a.matrixKey(o.key, e.key))
    }
}

function G0(t, c) {
    if (t & 1 && (n(0, "span", 28), s(1, "\u2014"), i()), t & 2) {
        let e = m(8);
        Ft("aria-label", e.formatMessage("notif_not_available"))
    }
}

function U0(t, c) {
    if (t & 1 && (n(0, "div", 25)(1, "span", 26), p(2, "i"), s(3), i(), d(4, R0, 1, 1, "dx-switch", 27)(5, G0, 2, 1, "span", 28), i()), t & 2) {
        let e = c.$implicit,
            o = c.$index,
            a = c.$count,
            h = m().$implicit,
            w = m(6);
        Ae("border-bottom", o !== a - 1), r(2), Ze(mn("", e.icon, " ", e.iconClass)), r(), E(" ", w.formatMessage(e.i18n), " "), r(), u(h.channels.includes(e.key) ? 4 : 5)
    }
}

function W0(t, c) {
    if (t & 1 && (n(0, "div", 22)(1, "div", 23), s(2), i(), U(3, U0, 6, 8, "div", 24, st), i()), t & 2) {
        let e = c.$implicit,
            o = m(6);
        r(2), x(o.formatMessage("notif_entity_" + e.key)), r(), W(o.CHANNELS)
    }
}

function q0(t, c) {
    if (t & 1 && (n(0, "div", 19)(1, "span", 20), p(2, "i"), s(3), i(), n(4, "div", 21), s(5), i()(), U(6, W0, 5, 1, "div", 22, st)), t & 2) {
        let e = c.$implicit,
            o = m(5);
        r(), Ze(ki("badge rounded-pill ", e.pillClass, " text-uppercase d-inline-flex align-items-center gap-2 px-3 py-1")), r(), Ze(e.icon), r(), E("", o.formatMessage(e.title), " "), r(2), x(o.formatMessage(e.help)), r(), W(e.entities)
    }
}

function H0(t, c) {
    if (t & 1 && U(0, q0, 8, 7, null, null, Er), t & 2) {
        let e = m(4);
        W(e.ENTITY_GROUPS)
    }
}

function j0(t, c) {
    if (t & 1 && (n(0, "th", 31), p(1, "i"), n(2, "span", 32), s(3), i()()), t & 2) {
        let e = c.$implicit,
            o = m(5);
        r(), Ze(mn("", e.icon, " ", e.iconClass, " d-block mb-1")), r(2), x(o.formatMessage(e.i18n))
    }
}

function z0(t, c) {
    if (t & 1 && p(0, "dx-switch", 27), t & 2) {
        let e = m().$implicit,
            o = m().$implicit,
            a = m(6);
        l("formControlName", a.matrixKey(o.key, e.key))
    }
}

function Q0(t, c) {
    if (t & 1 && (n(0, "span", 28), s(1, "\u2014"), i()), t & 2) {
        let e = m(8);
        Ft("aria-label", e.formatMessage("notif_not_available"))
    }
}

function Y0(t, c) {
    if (t & 1 && (n(0, "td"), d(1, z0, 1, 1, "dx-switch", 27)(2, Q0, 2, 1, "span", 28), i()), t & 2) {
        let e = c.$implicit,
            o = m().$implicit;
        r(), u(o.channels.includes(e.key) ? 1 : 2)
    }
}

function K0(t, c) {
    if (t & 1 && (n(0, "tr")(1, "th", 35), s(2), i(), U(3, Y0, 3, 1, "td", null, st), i()), t & 2) {
        let e = c.$implicit,
            o = m(6);
        r(2), x(o.formatMessage("notif_entity_" + e.key)), r(), W(o.CHANNELS)
    }
}

function Z0(t, c) {
    if (t & 1 && (n(0, "tr")(1, "td", 33)(2, "span", 20), p(3, "i"), s(4), i(), n(5, "span", 34), s(6), i()()(), U(7, K0, 5, 1, "tr", null, st)), t & 2) {
        let e = c.$implicit,
            o = m(5);
        r(), Ft("colspan", o.CHANNELS.length + 1), r(), Ze(ki("badge rounded-pill ", e.pillClass, " text-uppercase d-inline-flex align-items-center gap-2 px-3 py-1")), r(), Ze(e.icon), r(), E("", o.formatMessage(e.title), " "), r(2), x(o.formatMessage(e.help)), r(), W(e.entities)
    }
}

function $0(t, c) {
    if (t & 1 && (n(0, "div", 17)(1, "table", 29)(2, "thead")(3, "tr"), p(4, "th", 30), U(5, j0, 4, 5, "th", 31, st), i()(), n(7, "tbody"), U(8, Z0, 9, 8, null, null, Er), i()()()), t & 2) {
        let e = m(4);
        r(5), W(e.CHANNELS), r(3), W(e.ENTITY_GROUPS)
    }
}

function X0(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 18)(1, "dx-button", 36), _("onClick", function() {
            g(e);
            let a = m(4);
            return C(a.askReset())
        }), i()()
    }
    if (t & 2) {
        let e = m(4);
        r(), l("text", e.formatMessage("reset_all_to_off"))
    }
}

function J0(t, c) {
    if (t & 1 && (d(0, H0, 2, 0)(1, $0, 10, 0, "div", 17), d(2, X0, 2, 1, "div", 18)), t & 2) {
        let e = m(3);
        u(e.isMobileDevice ? 0 : 1), r(2), u(e.canEdit ? 2 : -1)
    }
}

function eu(t, c) {
    if (t & 1 && (n(0, "span", 42), s(1), i()), t & 2) {
        let e = m(5);
        r(), x(e.formatMessage("notif_high_leverage_tag"))
    }
}

function tu(t, c) {
    if (t & 1 && (n(0, "div", 38)(1, "span"), s(2), d(3, eu, 2, 1, "span", 42), i(), p(4, "dx-switch", 27), i()), t & 2) {
        let e = c.$implicit,
            o = m(4);
        r(2), E(" ", o.formatMessage("notif_label_" + e.key), " "), r(), u(e.tag ? 3 : -1), r(), l("formControlName", e.key)
    }
}

function iu(t, c) {
    if (t & 1 && (n(0, "span", 44), s(1), i(), p(2, "dx-number-box", 45)), t & 2) {
        let e = m().$implicit,
            o = m(4);
        r(), E("\u2265 ", o.currencySymbol), r(), l("width", 120)("min", 0)("showSpinButtons", !0)("step", 100)("disabled", !o.value(e.toggle))("formControlName", e.amount)
    }
}

function nu(t, c) {
    if (t & 1 && (n(0, "div", 40)(1, "span"), s(2), i(), n(3, "div", 43), d(4, iu, 3, 7), p(5, "dx-switch", 27), i()()), t & 2) {
        let e = c.$implicit,
            o = m(4);
        r(2), x(o.formatMessage("notif_label_" + e.toggle)), r(2), u(e.amount ? 4 : -1), r(), l("formControlName", e.toggle)
    }
}

function ou(t, c) {
    if (t & 1 && (n(0, "div", 38)(1, "span"), s(2), i(), p(3, "dx-switch", 27), i()), t & 2) {
        let e = c.$implicit,
            o = m(4);
        r(2), x(o.formatMessage("notif_label_" + e.key)), r(), l("formControlName", e.key)
    }
}

function au(t, c) {
    if (t & 1 && (n(0, "div", 38)(1, "span"), s(2), i(), p(3, "dx-switch", 27), i()), t & 2) {
        let e = c.$implicit,
            o = m(4);
        r(2), x(o.formatMessage("notif_label_" + e.key)), r(), l("formControlName", e.key)
    }
}

function ru(t, c) {
    if (t & 1 && (n(0, "div", 37), s(1), i(), U(2, tu, 5, 3, "div", 38, st), n(4, "div", 39), s(5), i(), U(6, nu, 6, 3, "div", 40, D0), n(8, "div", 39), s(9), i(), U(10, ou, 4, 2, "div", 38, st), n(12, "div", 39), s(13), i(), U(14, au, 4, 2, "div", 38, st), n(16, "div", 41)(17, "span"), s(18), i(), p(19, "dx-switch", 27), i(), n(20, "div", 21), s(21), i()), t & 2) {
        let e = m(3);
        r(), x(e.formatMessage("notif_group_buying_signals")), r(), W(e.BUYING_SIGNALS), r(3), x(e.formatMessage("notif_group_money")), r(), W(e.MONEY_ROWS), r(3), x(e.formatMessage("notif_group_operational")), r(), W(e.OPERATIONAL), r(3), x(e.formatMessage("notif_group_customer_actions")), r(), W(e.CUSTOMER_ACTIONS), r(4), x(e.formatMessage("notif_label_push_daily_report")), r(), l("formControlName", e.KEY.DAILY_REPORT), r(2), x(e.formatMessage("notif_daily_report_help"))
    }
}

function su(t, c) {
    if (t & 1 && (n(0, "div", 38)(1, "span"), s(2), i(), p(3, "dx-switch", 27), i()), t & 2) {
        let e = c.$implicit,
            o = m(4);
        r(2), x(o.formatMessage("notif_label_" + e.key)), r(), l("formControlName", e.key)
    }
}

function lu(t, c) {
    if (t & 1 && (U(0, su, 4, 2, "div", 38, st), n(2, "div", 40)(3, "span"), s(4), i(), n(5, "div", 43)(6, "span", 46), s(7), p(8, "dx-select-box", 47), s(9), i(), p(10, "dx-switch", 27), i()()), t & 2) {
        let e = m(3);
        W(e.EMPLOYEE_ROWS), r(4), x(e.formatMessage("notif_label_push_daily_queue")), r(3), E("", e.formatMessage("notif_at"), " "), r(), l("width", 110)("dataSource", e.HOURS)("disabled", !e.value(e.KEY.DAILY_QUEUE))("formControlName", e.KEY.DAILY_QUEUE_LOCAL_HOUR), r(), E(" ", e.formatMessage("notif_tenant_local_time")), r(), l("formControlName", e.KEY.DAILY_QUEUE)
    }
}

function cu(t, c) {
    if (t & 1 && (n(0, "div"), d(1, J0, 3, 2)(2, ru, 22, 7)(3, lu, 11, 8), i()), t & 2) {
        let e, o = c.$implicit;
        r(), u((e = o.id) === "action" ? 1 : e === "owner" ? 2 : e === "employee" ? 3 : -1)
    }
}

function mu(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "div", 11)(1, "dx-button", 48), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.cancel())
        }), i(), n(2, "dx-button", 49), _("onClick", function() {
            g(e);
            let a = m(2);
            return C(a.save())
        }), i()()
    }
    if (t & 2) {
        let e = m(2);
        r(), l("text", e.formatMessage("common_cancel"))("disabled", !e.form.dirty || e.isSaving), r(), l("text", e.formatMessage("common_save"))("disabled", !e.form.dirty || e.isSaving)
    }
}

function pu(t, c) {
    if (t & 1 && (n(0, "div", 0)(1, "div", 2)(2, "div"), p(3, "app-section-title", 3), n(4, "div", 4), s(5), i()(), d(6, O0, 3, 4, "div", 5), i(), d(7, F0, 4, 1, "div", 6), n(8, "form", 7)(9, "dx-accordion", 8), T(10, B0, 7, 5, "div", 9)(11, cu, 4, 1, "div", 10), i()(), d(12, mu, 3, 4, "div", 11), i()), t & 2) {
        let e = m();
        r(3), l("title", "default_notification_settings_title")("isVisibleHr", !1), r(2), x(e.formatMessage("default_notification_settings_subtitle")), r(), u(e.canEdit && !e.isMobileDevice ? 6 : -1), r(), u(e.canEdit ? -1 : 7), r(), l("formGroup", e.form), r(), l("dataSource", e.SECTIONS)("collapsible", !0)("multiple", !0)("selectedItems", e.SECTIONS)("animationDuration", 200), r(), l("dxTemplateOf", "title"), r(), l("dxTemplateOf", "item"), r(), u(e.canEdit && e.isMobileDevice ? 12 : -1)
    }
}

function du(t, c) {
    if (t & 1) {
        let e = S();
        n(0, "app-confirmation-popup", 50), _("confirmActionCallback", function() {
            g(e);
            let a = m();
            return C(a.onResetConfirmed())
        })("rejectActionCallback", function() {
            g(e);
            let a = m();
            return C(a.onResetRejected())
        }), i()
    }
    if (t & 2) {
        let e = m();
        l("title", e.formatMessage("reset_all_to_off"))("confirmationMessage", e.formatMessage("reset_confirm_all_off"))
    }
}
var wr = (() => {
    class t {
        constructor() {
            this.formatMessage = f, this.PERMISSION_LIST = b, this.configService = v(Xt), this.generalSettingsService = v(Ki), this.toastNotificationService = v(N), this.userSessionService = v(tt), this.isMobileDevice = v(se).isMobileDevice(), this.isSaving = !1, this.isResetConfirmVisible = !1, this.currencySymbol = v(ie).config() ? .currency_code ? ? "\u20B9", this.canEdit = this.userSessionService.userPermissionList().includes(b.BUSINESS_SETTING_WRITE), this.notificationRows = [], this.SECTIONS = [{
                id: "action",
                title: "notifications_action_defaults_title",
                help: "notifications_action_defaults_help",
                icon: "dx-icon-checklist"
            }, {
                id: "owner",
                title: "owner_alerts_title",
                help: "owner_alerts_help",
                icon: "dx-icon-user"
            }, {
                id: "employee",
                title: "employee_notifications_title",
                help: "employee_notifications_help",
                icon: "dx-icon-group"
            }], this.CHANNELS = Hn, this.ENTITIES = Ai, this.ENTITY_GROUPS = [{
                recipient: Si.CUSTOMER,
                title: "notification_group_customer_title",
                help: "notification_group_customer_help",
                pillClass: "bg-primary-subtle text-primary",
                icon: "fa-thin fa-user",
                entities: Ai.filter(e => e.recipient === Si.CUSTOMER)
            }, {
                recipient: Si.EMPLOYEE,
                title: "notification_group_employee_title",
                help: "notification_group_employee_help",
                pillClass: "bg-success-subtle text-success",
                icon: "fa-thin fa-users",
                entities: Ai.filter(e => e.recipient === Si.EMPLOYEE)
            }], this.BUYING_SIGNALS = jn, this.MONEY_ROWS = zn, this.OPERATIONAL = Qn, this.CUSTOMER_ACTIONS = Yn, this.EMPLOYEE_ROWS = Kn, this.HOURS = Zn, this.KEY = Wn, this.NUMBER_KEYS = Jn, this.HOUR_KEYS = Xn, this.NUMERIC_DEFAULTS = eo, this.booleanKeys = []
        }
        ngOnInit() {
            this.booleanKeys = [...this.ENTITIES.flatMap(e => e.channels.map(o => this.matrixKey(e.key, o))), ...$n], this.configService.appConfig$.subscribe({
                next: e => {
                    this.notificationRows = (e ? .general_settings ? ? []).filter(o => o.section === It.DEFAULT_NOTIFICATIONS), this.buildForm()
                },
                error: e => console.error(e)
            })
        }
        matrixKey(e, o) {
            return qn(e, o)
        }
        get allKeys() {
            return [...this.booleanKeys, ...this.NUMBER_KEYS, ...this.HOUR_KEYS]
        }
        storedValue(e) {
            let o = this.notificationRows.find(a => a.key === e);
            return o ? o.value : void 0
        }
        toBool(e) {
            return e === !0 || e === 1 || e === "1" || e === "true"
        }
        buildForm() {
            let e = {};
            this.booleanKeys.forEach(o => {
                e[o] = new Se(this.toBool(this.storedValue(o)))
            }), [...this.NUMBER_KEYS, ...this.HOUR_KEYS].forEach(o => {
                let a = this.storedValue(o),
                    h = a == null || a === "" ? this.NUMERIC_DEFAULTS[o] : Number(a);
                e[o] = new Se(h)
            }), this.form = new ut(e), this.canEdit || this.form.disable()
        }
        value(e) {
            return !!this.form ? .get(e) ? .value
        }
        askReset() {
            this.isResetConfirmVisible = !0
        }
        onResetConfirmed() {
            this.ENTITIES.forEach(e => {
                e.channels.forEach(o => {
                    this.form.get(this.matrixKey(e.key, o)) ? .setValue(!1)
                })
            }), this.form.markAsDirty(), this.isResetConfirmVisible = !1, this.toastNotificationService.info("notification_defaults_reset_applied")
        }
        onResetRejected() {
            this.isResetConfirmVisible = !1
        }
        save() {
            if (!this.form.dirty || this.isSaving) return;
            this.isSaving = !0;
            let e = new Set(this.allKeys),
                o = new Set(this.booleanKeys),
                a = this.notificationRows.map(h => {
                    if (!e.has(h.key)) return h;
                    let w = this.form.get(h.key) ? .value,
                        Lt = o.has(h.key) ? w ? "1" : "0" : Number(w);
                    return ct(lt({}, h), {
                        value: Lt
                    })
                });
            this.generalSettingsService.generalSettings({
                general_settings: a
            }).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_settings_saved"), this.form.markAsPristine(), this.isSaving = !1
                },
                error: () => {
                    this.toastNotificationService.error("notification_settings_save_error"), this.isSaving = !1
                }
            })
        }
        cancel() {
            this.buildForm()
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = y({
                type: t,
                selectors: [
                    ["app-default-notifications"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    [1, "px-3", "pb-4"],
                    [3, "title", "confirmationMessage"],
                    [1, "d-flex", "justify-content-between", "align-items-start", "gap-3", "py-2"],
                    [3, "title", "isVisibleHr"],
                    [1, "small", "text-muted"],
                    [1, "d-flex", "gap-2", "flex-shrink-0"],
                    [1, "d-flex", "align-items-center", "gap-2", "p-3", "mb-3", "rounded", "bg-light", "border", "small", "text-muted"],
                    [3, "formGroup"],
                    [1, "d-block", 3, "dataSource", "collapsible", "multiple", "selectedItems", "animationDuration"],
                    ["class", "d-flex align-items-center gap-3", 4, "dxTemplate", "dxTemplateOf"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "position-fixed", "bottom-0", "start-0", "end-0", "bg-body", "border-top", "p-3", "d-flex", "gap-2", "shadow"],
                    ["stylingMode", "outlined", 3, "onClick", "text", "disabled"],
                    ["id", "notif-save-btn", "stylingMode", "contained", "type", "default", 3, "onClick", "text", "disabled"],
                    [1, "dx-icon-lock", "text-warning"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "fs-6", "fw-semibold"],
                    [1, "table-responsive"],
                    [1, "d-flex", "justify-content-end", "gap-2", "mt-3", "flex-wrap"],
                    [1, "mt-3", "mb-2"],
                    [2, "font-size", "0.72rem", "letter-spacing", "0.02em"],
                    [1, "small", "text-muted", "mt-2"],
                    [1, "border", "rounded", "mb-2"],
                    [1, "bg-light", "px-3", "py-2", "fw-semibold", "border-bottom"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "px-3", "py-2", 3, "border-bottom"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "px-3", "py-2"],
                    [1, "d-inline-flex", "align-items-center", "gap-2"],
                    [3, "formControlName"],
                    [1, "text-muted"],
                    [1, "table", "table-sm", "align-middle", "text-center", "mb-0"],
                    [1, "text-start"],
                    [1, "text-center"],
                    [1, "text-uppercase", "small", "text-muted"],
                    [1, "text-start", "bg-light", "py-2"],
                    [1, "small", "text-muted", "ms-2"],
                    ["scope", "row", 1, "text-start", "fw-normal"],
                    ["stylingMode", "text", "type", "danger", 3, "onClick", "text"],
                    [1, "text-uppercase", "fw-bold", "small", "text-muted", "mb-2"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "py-2", "border-bottom"],
                    [1, "text-uppercase", "fw-bold", "small", "text-muted", "mt-3", "mb-2"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "py-2", "border-bottom", "flex-wrap", "gap-2"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "py-2", "border-bottom", "flex-wrap", "gap-2", "mt-3"],
                    [1, "badge", "text-bg-light", "text-primary", "ms-2"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "text-muted", "small"],
                    [3, "width", "min", "showSpinButtons", "step", "disabled", "formControlName"],
                    [1, "d-inline-flex", "align-items-center", "gap-1", "text-muted", "small"],
                    ["displayExpr", "label", "valueExpr", "value", 3, "width", "dataSource", "disabled", "formControlName"],
                    ["stylingMode", "outlined", 1, "flex-fill", 3, "onClick", "text", "disabled"],
                    ["stylingMode", "contained", "type", "default", 1, "flex-fill", 3, "onClick", "text", "disabled"],
                    [3, "confirmActionCallback", "rejectActionCallback", "title", "confirmationMessage"]
                ],
                template: function(o, a) {
                    o & 1 && (d(0, pu, 13, 14, "div", 0), d(1, du, 1, 2, "app-confirmation-popup", 1)), o & 2 && (u(a.form ? 0 : -1), r(), u(a.isResetConfirmVisible ? 1 : -1))
                },
                dependencies: [Ye, it, ni, G, _e, oi, le, Be, V, L, P, A, D],
                encapsulation: 2
            })
        }
    }
    return t
})();
var uu = [{
        path: "",
        component: Ca,
        children: [{
            path: "business",
            component: Mt,
            canActivate: [J],
            data: {
                tab_index: 0,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: ha,
                data: {
                    tab_index: 0
                }
            }]
        }, {
            path: "businessBank",
            component: Mt,
            canActivate: [J],
            data: {
                tab_index: 0,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Sa,
                data: {
                    tab_index: 1
                }
            }]
        }, {
            path: "businessLogo",
            component: Mt,
            canActivate: [J],
            data: {
                tab_index: 0,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: ya,
                data: {
                    tab_index: 2
                }
            }]
        }, {
            path: "businessSignature",
            component: Mt,
            canActivate: [J],
            data: {
                tab_index: 0,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Ta,
                data: {
                    tab_index: 3
                }
            }]
        }, {
            path: "businessLinks",
            component: Mt,
            canActivate: [J],
            data: {
                tab_index: 0,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Ma,
                data: {
                    tab_index: 4
                }
            }]
        }, {
            path: "businessHours",
            component: Mt,
            canActivate: [J],
            data: {
                tab_index: 0,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Na,
                data: {
                    tab_index: 5
                }
            }]
        }, {
            path: "custom-fields",
            component: nn,
            canActivate: [J],
            data: {
                tab_index: 1,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: ia,
                data: {
                    tab_index: 0
                }
            }]
        }, {
            path: "general",
            component: nn,
            canActivate: [J],
            data: {
                tab_index: 1,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Va,
                data: {
                    tab_index: 1
                }
            }]
        }, {
            path: "modules",
            component: nn,
            canActivate: [J],
            data: {
                tab_index: 1,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: La,
                data: {
                    tab_index: 2
                }
            }]
        }, {
            path: "terms",
            component: Qa,
            canActivate: [J],
            data: {
                tab_index: 2,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "sequences",
            component: qa,
            canActivate: [J],
            data: {
                tab_index: 3,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "reminders",
            component: Ya,
            canActivate: [J],
            data: {
                tab_index: 4,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "self-checkin",
            component: Tr,
            canActivate: [J],
            data: {
                tab_index: 4,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "default-notifications",
            component: wr,
            canActivate: [J],
            data: {
                tab_index: 4,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "email",
            component: Da,
            canActivate: [J],
            data: {
                tab_index: 5,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "taxes",
            component: ja,
            canActivate: [J],
            data: {
                tab_index: 6,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "workflow",
            component: rn,
            canActivate: [J],
            data: {
                tab_index: 7,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: ea,
                data: {
                    tab_index: 0
                }
            }]
        }, {
            path: "workflowAddress",
            component: rn,
            canActivate: [J],
            data: {
                tab_index: 7,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Ko,
                data: {
                    tab_index: 1
                }
            }]
        }, {
            path: "workflowDueDates",
            component: rn,
            canActivate: [J],
            data: {
                tab_index: 7,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: aa,
                data: {
                    tab_index: 2
                }
            }]
        }, {
            path: "print",
            component: Ei,
            canActivate: [J],
            data: {
                tab_index: 8,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Jo,
                data: {
                    tab_index: 0
                }
            }]
        }, {
            path: "printTechnician",
            component: Ei,
            canActivate: [J],
            data: {
                tab_index: 8,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Zo,
                data: {
                    tab_index: 1
                }
            }]
        }, {
            path: "printOptions",
            component: Ei,
            canActivate: [J],
            data: {
                tab_index: 8,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: $o,
                data: {
                    tab_index: 2
                }
            }]
        }, {
            path: "printAmc",
            component: Ei,
            canActivate: [J],
            data: {
                tab_index: 8,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: na,
                data: {
                    tab_index: 3
                }
            }]
        }, {
            path: "themes",
            component: yn,
            canActivate: [J],
            data: {
                tab_index: 9,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: Yo,
                data: {
                    tab_index: 0
                }
            }]
        }, {
            path: "themesScroll",
            component: yn,
            canActivate: [J],
            data: {
                tab_index: 9,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: ta,
                data: {
                    tab_index: 1
                }
            }]
        }, {
            path: "expense-categories",
            component: Fa,
            canActivate: [J],
            data: {
                tab_index: 10,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "part-categories",
            component: br,
            canActivate: [J],
            data: {
                tab_index: 10,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "payment-types",
            component: pa,
            canActivate: [J],
            data: {
                tab_index: 11,
                permissions: {
                    only: [b.PAYMENT_TYPE_LIST]
                }
            }
        }, {
            path: "subscription",
            component: Ba,
            canActivate: [J],
            data: {
                tab_index: 12,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "sms-history",
            component: Ga,
            data: {
                tab_index: 13,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "message-logs",
            component: sa,
            canActivate: [J],
            data: {
                tab_index: 18,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "integrations",
            component: sr,
            data: {
                tab_index: 14,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "business-type",
            component: dr,
            canActivate: [J],
            data: {
                tab_index: 15,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "quickbooksOverview",
            component: En,
            data: {
                tab_index: 14,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: cr,
                data: {
                    tab_index: 0
                }
            }]
        }, {
            path: "quickbooksConfig",
            component: En,
            data: {
                tab_index: 14,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "",
                component: mr,
                data: {
                    tab_index: 1
                }
            }]
        }, {
            path: "notification-signatures",
            component: ur,
            canActivate: [J],
            data: {
                tab_index: 15,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            },
            children: [{
                path: "email",
                component: gr
            }, {
                path: "sms",
                component: vr
            }, {
                path: "whatsapp",
                component: xr
            }, {
                path: "",
                redirectTo: "email",
                pathMatch: "full"
            }]
        }, {
            path: "templates",
            loadChildren: () =>
                import ("./chunk-XOVLJMKF.js").then(t => t.TemplateModule),
            canActivate: [J],
            data: {
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "security",
            component: Sr,
            canActivate: [J],
            data: {
                tab_index: 16,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "white-label",
            component: yr,
            canActivate: [J],
            data: {
                tab_index: 17,
                permissions: {
                    only: [b.BUSINESS_SETTING_VIEW]
                }
            }
        }, {
            path: "",
            redirectTo: "business",
            pathMatch: "full"
        }]
    }],
    Ir = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = hi({
                    type: t
                })
            }
            static {
                this.\u0275inj = vi({
                    imports: [pn.forChild(uu), pn]
                })
            }
        }
        return t
    })();
var UT = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = hi({
                type: t
            })
        }
        static {
            this.\u0275inj = vi({
                imports: [Dn, nt, Ir, fa]
            })
        }
    }
    return t
})();
export {
    si as a, va as b, pr as c, UT as d
};