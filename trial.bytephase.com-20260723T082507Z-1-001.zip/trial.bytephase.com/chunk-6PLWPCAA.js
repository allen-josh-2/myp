import {
    a as Ve
} from "./chunk-ZJPVWREV.js";
import {
    a as Ue
} from "./chunk-FAP35UT3.js";
import {
    Ca as oe,
    Cb as Ne,
    Da as Ie,
    Fc as Ye,
    Ha as re,
    Hb as Le,
    Ka as be,
    M as N,
    Rd as we,
    Ta as Ae,
    Ug as F,
    Vc as W,
    Wc as S,
    Xc as B,
    Ze as x,
    ca as Ce,
    g as fe,
    ka as De,
    m as ve,
    oa as Se,
    pa as Pe,
    ph as je,
    qa as Z,
    ra as xe,
    rb as w,
    rg as Fe,
    ta as ee,
    tc as Me,
    ua as te
} from "./chunk-DCKGQUHB.js";
import {
    $a as R,
    Ak as Oe,
    Fa as i,
    Fh as L,
    Ib as E,
    If as se,
    Jb as P,
    Jf as me,
    Ka as V,
    Mc as K,
    Mf as de,
    Na as y,
    Nf as ce,
    Oa as Q,
    Of as _e,
    Pb as Te,
    Qb as Re,
    Rb as he,
    Tc as ye,
    V as X,
    _a as T,
    _h as D,
    aa as A,
    ba as $,
    c as ue,
    da as O,
    ea as v,
    eb as n,
    fb as l,
    gb as a,
    gc as J,
    hb as s,
    hc as q,
    hi as k,
    pd as Ee,
    qh as j,
    sb as f,
    sd as ge,
    ti as M,
    ub as h,
    ui as Y,
    vd as le,
    wh as c,
    xk as p,
    z as b,
    zi as I
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as _,
    b as u,
    i as pe
} from "./chunk-FBFWB55K.js";

function rt(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 3), o & 2) {
        let e = h();
        n("tooltipId", e.REPORT_TYPE.EMPLOYEE_JOBS_COMPLETED_TREND)("toolTip", "tooltip_employee_jobs_completed_trend")("currentDateRangeValue", e.jobCountTrendReport == null ? null : e.jobCountTrendReport.current_period_total)("percentage", e.jobCountTrendReport == null ? null : e.jobCountTrendReport.percentage_change)("dateRange", e.dateRangeLabel)
    }
}

function it(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 4), o & 2) {
        let e = h();
        n("tooltipId", e.REPORT_TYPE.EMPLOYEE_REVENUE_TREND)("toolTip", "tooltip_employee_revenue_trend")("currentDateRangeValue", e.revenueTrendReport == null ? null : e.revenueTrendReport.current_period_total)("percentage", e.revenueTrendReport == null ? null : e.revenueTrendReport.percentage_change)("dateRange", e.dateRangeLabel)
    }
}

function nt(o, C) {
    if (o & 1 && s(0, "app-charts", 16), o & 2) {
        let e = h();
        n("entityData", e.jobDistributionData)("entityLabel", e.CHART_ENTITY_TYPES.EMPLOYEE_JOB_DISTRIBUTION)("graphType", e.graphType)("isNameWise", !0)
    }
}

function at(o, C) {
    if (o & 1 && s(0, "app-charts", 16), o & 2) {
        let e = h();
        n("entityData", e.revenueComparisonData)("entityLabel", e.CHART_ENTITY_TYPES.EMPLOYEE_REVENUE_COMPARISON)("graphType", e.graphType)("isNameWise", !0)
    }
}
var ke = (() => {
    class o {
        constructor() {
            this.formatMessage = p, this.CHART_ENTITY_TYPES = j, this.jobDistributionData = [], this.revenueComparisonData = [], this.graphType = "bar", this.reportTypes = [{
                displayName: "Bar",
                value: "bar"
            }, {
                displayName: "Line",
                value: "line"
            }], this.isLoading = !0, this.dateRangeLabel = "", this.performanceSummaryColumns = [{
                dataField: "employee_name",
                caption: p("employee_name")
            }, {
                dataField: "total_jobs_completed",
                caption: p("employee_report_jobs_completed"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_jobs_completed"
            }, {
                dataField: "repairs_completed",
                caption: p("employee_report_repairs_completed"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_repairs_completed"
            }, {
                dataField: "total_payment_collected",
                caption: p("employee_report_payment_collected"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_payment_collected",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_travel_distance",
                caption: p("employee_report_travel_distance"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_travel_distance"
            }, {
                dataField: "total_revenue",
                caption: p("employee_report_total_revenue"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_total_revenue",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }], this.taskSummaryColumns = [{
                dataField: "employee_name",
                caption: p("employee_name")
            }, {
                dataField: "total_sales_revenue",
                caption: p("employee_report_sales_revenue"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_sales_revenue",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_amc_revenue",
                caption: p("employee_report_amc_revenue"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_amc_revenue",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "total_sales_count",
                caption: p("employee_report_sales_count"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_sales_count"
            }, {
                dataField: "total_amc_services_completed",
                caption: p("employee_report_amc_services_completed"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_amc_services"
            }, {
                dataField: "completed_tasks",
                caption: p("employee_report_completed_tasks"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_tasks_completed"
            }, {
                dataField: "total_tasks",
                caption: p("employee_report_total_tasks"),
                headerCellTemplate: "headerWithHelp",
                helpText: "tooltip_employee_total_tasks"
            }], this.employeeReportService = v(Ve), this.loaderService = v(Oe), this.toastNotificationService = v(Ce), this.exportService = v(we), this.nativeFileService = v(Le), this.destroy$ = new ue, this.REPORT_TYPE = c, this.REPORT_DURATION_LIST = D
        }
        setReportForDuration(e) {
            let r = {
                from_date: e.fromDate,
                to_date: e.toDate
            };
            this.dateDuration = r, this.dateRangeLabel = e.fromDate && e.toDate ? e.fromDate + " - " + e.toDate : p("all"), this.isLoading = !0, b([this.employeeReportService.getReport(u(_({}, r), {
                type: c.EMPLOYEE_JOBS_COMPLETED_TREND
            })), this.employeeReportService.getReport(u(_({}, r), {
                type: c.EMPLOYEE_REVENUE_TREND
            })), this.employeeReportService.getReport(u(_({}, r), {
                type: c.EMPLOYEE_JOB_DISTRIBUTION
            })), this.employeeReportService.getReport(u(_({}, r), {
                type: c.EMPLOYEE_REVENUE_COMPARISON
            }))]).pipe(X(this.destroy$)).subscribe({
                next: ([t, d, m, U]) => {
                    this.jobCountTrendReport = t, this.revenueTrendReport = d, this.jobDistributionData = (m || []).map(H => u(_({}, H), {
                        total: H.count
                    })), this.revenueComparisonData = U || []
                },
                error: t => {
                    console.error("Employee report error:", t), this.toastNotificationService.error("notification_something_went_wrong")
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        exportPerformanceSummary() {
            this.loaderService.show();
            let e = {
                type: "xlsx",
                entity_type: "employee_performance_summary",
                from_date: this.dateDuration ? .from_date,
                to_date: this.dateDuration ? .to_date
            };
            this.exportService.exportToFile("normalExport", e).pipe(X(this.destroy$)).subscribe({
                next: r => pe(this, null, function*() {
                    return yield this.nativeFileService.downloadFile(r.body, "employee_performance_summary.xlsx")
                }),
                error: r => this.toastNotificationService.error(r.message)
            }).add(() => this.loaderService.hide())
        }
        exportTaskSummary() {
            this.loaderService.show();
            let e = {
                type: "xlsx",
                entity_type: "employee_task_summary",
                from_date: this.dateDuration ? .from_date,
                to_date: this.dateDuration ? .to_date
            };
            this.exportService.exportToFile("normalExport", e).pipe(X(this.destroy$)).subscribe({
                next: r => pe(this, null, function*() {
                    return yield this.nativeFileService.downloadFile(r.body, "employee_task_summary.xlsx")
                }),
                error: r => this.toastNotificationService.error(r.message)
            }).add(() => this.loaderService.hide())
        }
        ngOnDestroy() {
            this.destroy$.next(), this.destroy$.complete()
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-employee-report"]
                ],
                standalone: !1,
                decls: 29,
                vars: 23,
                consts: [
                    [3, "durationDateChanges", "selectedDuration"],
                    [1, "row", "mt-3"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["icon", "fa-thin fa-ticket", "title", "employee_report_jobs_completed", 3, "tooltipId", "toolTip", "currentDateRangeValue", "percentage", "dateRange"],
                    ["icon", "fa-thin fa-wallet", "title", "employee_report_revenue_generated", 3, "tooltipId", "toolTip", "currentDateRangeValue", "percentage", "dateRange"],
                    [1, "row", "pt-2"],
                    [1, "col-12", "mt-2"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-3", "gap-2", "flex-wrap"],
                    [1, "d-flex", "align-items-center", "gap-1"],
                    ["id", "employee_performance_summary", 1, "m-0"],
                    ["target", "employee_performance_summary", 3, "tooltipText"],
                    ["buttonType", "default", "icon", "fa-thin fa-file-excel", "text", "export", 3, "onClickEvent", "isVisibleIcon"],
                    [3, "columns", "dateDuration", "reportType", "service"],
                    [1, "col-12", "d-flex", "justify-content-end", "mt-5"],
                    ["displayExpr", "displayName", "valueExpr", "value", 3, "ngModelChange", "ngModel", "items", "searchEnabled", "width"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [3, "entityData", "entityLabel", "graphType", "isNameWise"],
                    [1, "col-12", "mt-5"],
                    ["id", "employee_task_summary", 1, "m-0"],
                    ["target", "employee_task_summary", 3, "tooltipText"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    }), a(), l(1, "div", 1)(2, "div", 2), T(3, rt, 1, 5, "app-trend-matrix-card", 3), a(), l(4, "div", 2), T(5, it, 1, 5, "app-trend-matrix-card", 4), a()(), l(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "div", 8)(10, "h5", 9), E(11), a(), s(12, "app-tooltip", 10), a(), l(13, "app-dx-outline-button", 11), f("onClickEvent", function() {
                        return t.exportPerformanceSummary()
                    }), a()(), s(14, "app-report-data-grid", 12), a(), l(15, "div", 13)(16, "dx-select-box", 14), he("ngModelChange", function(m) {
                        return Re(t.graphType, m) || (t.graphType = m), m
                    }), a()(), l(17, "div", 15), T(18, nt, 1, 4, "app-charts", 16), a(), l(19, "div", 15), T(20, at, 1, 4, "app-charts", 16), a(), l(21, "div", 17)(22, "div", 7)(23, "div", 8)(24, "h5", 18), E(25), a(), s(26, "app-tooltip", 19), a(), l(27, "app-dx-outline-button", 11), f("onClickEvent", function() {
                        return t.exportTaskSummary()
                    }), a()(), s(28, "app-report-data-grid", 12), a()()), r & 2 && (n("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), R(t.jobCountTrendReport ? 3 : -1), i(2), R(t.revenueTrendReport ? 5 : -1), i(6), P(t.formatMessage("employee_report_performance_summary")), i(), n("tooltipText", "tooltip_employee_performance_summary"), i(), n("isVisibleIcon", !0), i(), n("columns", t.performanceSummaryColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.EMPLOYEE_PERFORMANCE_SUMMARY)("service", t.employeeReportService), i(2), Te("ngModel", t.graphType), n("items", t.reportTypes)("searchEnabled", !1)("width", 110), i(2), R(t.isLoading ? -1 : 18), i(2), R(t.isLoading ? -1 : 20), i(5), P(t.formatMessage("employee_report_activity_summary")), i(), n("tooltipText", "tooltip_employee_activity_summary"), i(), n("isVisibleIcon", !0), i(), n("columns", t.taskSummaryColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.EMPLOYEE_TASK_SUMMARY)("service", t.employeeReportService))
                },
                dependencies: [S, x, w, B, F, De, Ae, fe, ve],
                encapsulation: 2
            })
        }
    }
    return o
})();
var We = (() => {
    class o extends M {
        constructor(e) {
            super(e, de), this.api = e, this.endpoint = de
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(O(Y))
            }
        }
        static {
            this.\u0275prov = A({
                token: o,
                factory: o.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return o
})();

function st(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 3), o & 2) {
        let e = h();
        n("currentDateRangeValue", e.expenseTrendReport == null ? null : e.expenseTrendReport.current_period_total)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))("percentage", e.expenseTrendReport == null ? null : e.expenseTrendReport.percentage_change)("toolTip", "total_expense_count_tooltip")("tooltipId", e.REPORT_TYPE.EXPENSE_TREND)
    }
}

function mt(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 4), o & 2) {
        let e = h();
        n("currentDateRangeValue", e.expenseTotalAmountTrendReport == null ? null : e.expenseTotalAmountTrendReport.current_period_total)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))("percentage", e.expenseTotalAmountTrendReport == null ? null : e.expenseTotalAmountTrendReport.percentage_change)("toolTip", "total_expense_amount_tooltip")("tooltipId", e.REPORT_TYPE.EXPENSE_TOTAL_AMOUNT_TREND)
    }
}
var Be = (() => {
    class o {
        constructor() {
            this.formatMessage = p, this.isLoading = !0, this.expenseReportService = v(We), this.categoryWiseExpenseReportColumns = [{
                dataField: "category_name",
                caption: p("common_category")
            }, {
                dataField: "total_amount",
                caption: p("total_amount"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }], this.REPORT_TYPE = c, this.REPORT_DURATION_LIST = D, this.service = v(W)
        }
        setReportForDuration(e) {
            let r = {
                from_date: e.fromDate ? ? null,
                to_date: e.toDate ? ? null,
                type: ""
            };
            this.dateDuration = r, this.expenseReport$ = this.service.getExpenseReport(r), this.expenseCategoryReport$ = this.service.getCategoryWiseExpenseReport(r), b([this.expenseReportService.getReport(u(_({}, r), {
                type: c.EXPENSE_TREND
            })), this.expenseReportService.getReport(u(_({}, r), {
                type: c.EXPENSE_TOTAL_AMOUNT_TREND
            }))]).subscribe({
                next: ([t, d]) => {
                    this.expenseTrendReport = t, this.expenseTotalAmountTrendReport = d
                },
                error: ([t, d]) => {
                    console.error("Expense TrendReportErr", t), console.error("Expense TOTAL_AMOUNT_TREND", d)
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-expense-report"]
                ],
                standalone: !1,
                decls: 31,
                vars: 23,
                consts: [
                    [3, "durationDateChanges", "selectedDuration"],
                    [1, "row", "mt-3"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["icon", "fa-thin fa-store-alt", "title", "total_expense_count_title", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "tooltipId"],
                    ["icon", "fa-thin fa-wallet", "title", "total_expense_amount_title", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "tooltipId"],
                    [1, "row", "pt-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "mt-2"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "mb-2"],
                    ["id", "category_wise_report", 1, "m-0"],
                    ["target", "category_wise_report", 3, "tooltipText"],
                    [3, "columns", "dateDuration", "reportType", "service"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [3, "dataSource", "title"],
                    [3, "enabled"],
                    ["argumentField", "name", "type", "bar", "valueField", "amount"],
                    ["position", "columns", 3, "visible"],
                    ["nameField", "name"],
                    ["horizontalAlignment", "center", "itemTextPosition", "right", "verticalAlignment", "bottom"],
                    ["name", "amount", "type", "continuous", "valueType", "numeric"],
                    ["argumentField", "date", "color", "#2f304a", "name", "Expense Report", "type", "bar", "valueField", "amount"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    }), a(), l(1, "div", 1)(2, "div", 2), T(3, st, 1, 5, "app-trend-matrix-card", 3), a(), l(4, "div", 2), T(5, mt, 1, 5, "app-trend-matrix-card", 4), a()(), l(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "h5", 8), E(10), a(), s(11, "app-tooltip", 9), a(), s(12, "app-report-data-grid", 10), a()(), l(13, "div", 5)(14, "div", 11)(15, "dx-chart", 12), J(16, "async"), s(17, "dxo-export", 13)(18, "dxo-tooltip", 13), l(19, "dxo-common-series-settings", 14), s(20, "dxo-label", 15), a(), s(21, "dxo-series-template", 16), a()(), l(22, "div", 11)(23, "dx-chart", 12), J(24, "async"), s(25, "dxo-legend", 17)(26, "dxo-export", 13)(27, "dxo-tooltip", 13)(28, "dxi-value-axis", 18), l(29, "dxi-series", 19), s(30, "dxo-label", 15), a()()()()), r & 2 && (n("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), R(t.expenseTrendReport ? 3 : -1), i(2), R(t.expenseTotalAmountTrendReport ? 5 : -1), i(5), P(t.formatMessage("category_wise_report_title")), i(), n("tooltipText", "category_wise_report_tooltip"), i(), n("columns", t.categoryWiseExpenseReportColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.CATEGORY_WISE_EXPENSE_REPORT)("service", t.expenseReportService), i(3), n("dataSource", q(16, 19, t.expenseCategoryReport$))("title", t.formatMessage("category_wise_expenses_chart_title")), i(2), n("enabled", !0), i(), n("enabled", !0), i(2), n("visible", !0), i(3), n("dataSource", q(24, 21, t.expenseReport$))("title", t.formatMessage("expense_report_chart_title")), i(3), n("enabled", !0), i(), n("enabled", !0), i(3), n("visible", !0))
                },
                dependencies: [S, x, w, F, Me, ee, Se, Z, te, oe, Ie, re, be, K],
                encapsulation: 2
            })
        }
    }
    return o
})();

function ct(o, C) {
    if (o & 1 && s(0, "app-charts", 3), o & 2) {
        let e = h();
        n("entityData", e.earningReport)("entityLabel", e.CHART_ENTITY_TYPES.REPORTS_REVENUES_EXPENSE)("graphType", e.graphType)
    }
}

function _t(o, C) {
    if (o & 1 && s(0, "app-charts", 4), o & 2) {
        let e = h();
        n("entityData", e.paymentTypeRevenueReport)("entityLabel", e.CHART_ENTITY_TYPES.PAYMENT_TYPE_WISE_REVENUE_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}

function ut(o, C) {
    if (o & 1 && s(0, "app-charts", 4), o & 2) {
        let e = h();
        n("entityData", e.serviceTypeRevenueReport)("entityLabel", e.CHART_ENTITY_TYPES.SERVICE_TYPE_WISE_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}
var Ge = (() => {
    class o {
        constructor(e) {
            this.service = e, this.formatMessage = p, this.CHART_ENTITY_TYPES = j, this.isLoading = !0, this.graphType = "bar", this.event = event, this.REPORT_DURATION_LIST = D
        }
        setGraphType(e) {
            this.graphType = e
        }
        setReportForDuration(e) {
            let r = {
                from_date: e.fromDate,
                to_date: e.toDate
            };
            this.deviceTypeRevenueReport$ = this.service.getDeviceTypeRevenueReport(r), this.service.getPaymentTypeWiseRevenueReport(r).subscribe({
                next: t => {
                    this.paymentTypeRevenueReport = t, this.isLoading = !1
                },
                error: t => {
                    console.log(t)
                }
            }), this.service.getServiceTypeRevenueReport(r).subscribe({
                next: t => {
                    this.serviceTypeRevenueReport = t, this.isLoading = !1
                },
                error: t => {
                    console.log(t)
                }
            }), this.service.getEarningReport(r).subscribe({
                next: t => {
                    this.earningReport = t, this.isLoading = !1
                },
                error: t => {
                    console.log(t)
                }
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(V(W))
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-revenue-report"]
                ],
                standalone: !1,
                decls: 18,
                vars: 16,
                consts: [
                    [3, "durationDateChanges", "selectedGraphType", "isForGraph", "selectedDuration"],
                    [1, "row", "pt-2"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [3, "entityData", "entityLabel", "graphType"],
                    [3, "entityData", "entityLabel", "graphType", "isNameWise"],
                    ["id", "device_type_pie", "palette", "Bright", 3, "dataSource", "title"],
                    ["horizontalAlignment", "center", "itemTextPosition", "right", "orientation", "horizontal", "verticalAlignment", "bottom", 3, "columnCount"],
                    [3, "enabled"],
                    ["argumentField", "name", "name", "Device Type Wise Revenue Report", "valueField", "amount"],
                    ["position", "columns", 3, "visible"],
                    [3, "size"],
                    [3, "visible", "width"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    })("selectedGraphType", function(m) {
                        return t.setGraphType(m)
                    }), a(), l(1, "div", 1)(2, "div", 2), T(3, ct, 1, 3, "app-charts", 3), a(), l(4, "div", 2), T(5, _t, 1, 4, "app-charts", 4), a(), l(6, "div", 2)(7, "dx-pie-chart", 5), J(8, "async"), s(9, "dxo-legend", 6)(10, "dxo-export", 7)(11, "dxo-tooltip", 7), l(12, "dxi-series", 8)(13, "dxo-label", 9), s(14, "dxo-font", 10)(15, "dxo-connector", 11), a()()()(), l(16, "div", 2), T(17, ut, 1, 4, "app-charts", 4), a()()), r & 2 && (n("isForGraph", !0)("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), R(t.isLoading ? -1 : 3), i(2), R(t.isLoading ? -1 : 5), i(2), n("dataSource", q(8, 14, t.deviceTypeRevenueReport$))("title", "Device Type Wise Revenue Report"), i(2), n("columnCount", 4), i(), n("enabled", !0), i(), n("enabled", !0), i(2), n("visible", !0), i(), n("size", 16), i(), n("visible", !0)("width", .5), i(2), R(t.isLoading ? -1 : 17))
                },
                dependencies: [S, B, xe, ee, Pe, Z, te, oe, re, Ye, K],
                encapsulation: 2
            })
        }
    }
    return o
})();
var Je = (() => {
    class o extends M {
        constructor(e) {
            super(e, se), this.api = e, this.endpoint = se
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(O(Y))
            }
        }
        static {
            this.\u0275prov = A({
                token: o,
                factory: o.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return o
})();

function Rt(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 3), o & 2) {
        let e = h();
        n("currentDateRangeValue", e.saleTrendReport == null ? null : e.saleTrendReport.current_period_total)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))("percentage", e.saleTrendReport == null ? null : e.saleTrendReport.percentage_change)("toolTip", "total_sales_count_tooltip")("tooltipId", e.REPORT_TYPE.SALE_TREND)
    }
}

function ht(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 4), o & 2) {
        let e = h();
        n("currentDateRangeValue", e.saleTotalAmountTrendReport == null ? null : e.saleTotalAmountTrendReport.current_period_total)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))("percentage", e.saleTotalAmountTrendReport == null ? null : e.saleTotalAmountTrendReport.percentage_change)("toolTip", "total_sales_amount_tooltip")("tooltipId", e.REPORT_TYPE.SALE_TOTAL_AMOUNT_TREND)
    }
}

function yt(o, C) {
    if (o & 1 && s(0, "app-charts", 14), o & 2) {
        let e = h();
        n("entityData", e.earningReport)("entityLabel", e.CHART_ENTITY_TYPES.SALES_EARNINGS_OVERVIEW)("graphType", e.graphType)
    }
}

function ft(o, C) {
    if (o & 1 && s(0, "app-charts", 15), o & 2) {
        let e = h();
        n("entityData", e.saleCountReport)("entityLabel", e.CHART_ENTITY_TYPES.SALES_COUNT_REPORT)("graphType", e.graphType)("isNameWise", !0)
    }
}
var qe = (() => {
    class o {
        constructor(e, r) {
            this.service = e, this.saleReportService = r, this.formatMessage = p, this.CHART_ENTITY_TYPES = j, this.graphType = "bar", this.isLoading = !0, this.saleDailyReportSalesColumn = [{
                dataField: "sale_date",
                caption: p("common_placeholders_sale_date"),
                width: 160,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "total_sales_amount",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("total_sale")
            }, {
                dataField: "total_tax_amount",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("total_tax_amount")
            }, {
                dataField: "total_expense",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("total_purchase")
            }, {
                dataField: "total_received_payment",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("total_payment_received"),
                visible: !0
            }, {
                dataField: "net_profit",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("net_profit"),
                visible: !0
            }, {
                dataField: "net_profit_margin",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("net_profit_margin"),
                visible: !0
            }], this.saleDailySaleSummaryColumns = [{
                name: "Total Sales",
                field: "total_sales_amount"
            }, {
                name: "Total Tax",
                field: "total_tax_amount"
            }, {
                name: "Total Received Payment",
                field: "total_received_payment"
            }], this.mostPopularRepairAndPartColumns = [{
                dataField: "name",
                caption: p("common_name")
            }, {
                dataField: "count",
                caption: p("report_columns_repair_service_count")
            }, {
                dataField: "total_revenue",
                caption: p("report_columns_total_revenue")
            }, {
                dataField: "total_quantity",
                caption: p("report_columns_total_quantity")
            }], this.REPORT_TYPE = c, this.REPORT_DURATION_LIST = D
        }
        setGraphType(e) {
            this.graphType = e
        }
        setReportForDuration(e) {
            let r = {
                from_date: e.fromDate ? ? null,
                to_date: e.toDate ? ? null,
                type: ""
            };
            this.dateDuration = r, b([this.service.getSaleEarningReport(r), this.service.getSaleCountReport(r), this.saleReportService.getReport(u(_({}, r), {
                type: c.SALE_SUMMARY_REPORT
            })), this.saleReportService.getReport(u(_({}, r), {
                type: c.SALE_TREND
            })), this.saleReportService.getReport(u(_({}, r), {
                type: c.SALE_TOTAL_AMOUNT_TREND
            }))]).subscribe({
                next: ([t, d, m, U, H]) => {
                    this.earningReport = t, this.saleCountReport = d, this.saleSummaryReport = m, this.saleTrendReport = U, this.saleTotalAmountTrendReport = H
                },
                error: ([t, d, m, U, H]) => {
                    console.error("EARNING_REPORT_ERR", t), console.error("SALE_COUNT_REPORT_ERR", d), console.error("SALE_SUMMARY_REPORT_ERR", m), console.error("saleTrendReportErr", U), console.error("SALE_TOTAL_AMOUNT_TREND", H)
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(V(W), V(Je))
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-sale-report"]
                ],
                standalone: !1,
                decls: 24,
                vars: 18,
                consts: [
                    [3, "durationDateChanges", "selectedGraphType", "isForGraph", "selectedDuration"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["icon", "fa-thin fa-store-alt", "title", "total_sale_count", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "tooltipId"],
                    ["icon", "fa-thin fa-wallet", "title", "total_sale_amount", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "tooltipId"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "mt-2"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "mb-2"],
                    ["id", "sale_daily_sales", 1, "m-0"],
                    ["target", "sale_daily_sales", 3, "tooltipText"],
                    [3, "columns", "dateDuration", "reportType", "service"],
                    [1, "row", "pt-2"],
                    ["id", "most_popular_part_wise_sales_report", 1, "m-0"],
                    ["target", "most_popular_part_wise_sales_report", 3, "tooltipText"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [3, "entityData", "entityLabel", "graphType"],
                    [3, "entityData", "entityLabel", "graphType", "isNameWise"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    })("selectedGraphType", function(m) {
                        return t.setGraphType(m)
                    }), a(), l(1, "div", 1)(2, "div", 2), T(3, Rt, 1, 5, "app-trend-matrix-card", 3), a(), l(4, "div", 2), T(5, ht, 1, 5, "app-trend-matrix-card", 4), a()(), l(6, "div", 1)(7, "div", 5)(8, "div", 6)(9, "h5", 7), E(10), a(), s(11, "app-tooltip", 8), a(), s(12, "app-report-data-grid", 9), a()(), l(13, "div", 10)(14, "div", 5)(15, "div", 6)(16, "h5", 11), E(17), a(), s(18, "app-tooltip", 12), a(), s(19, "app-report-data-grid", 9), a(), l(20, "div", 13), T(21, yt, 1, 3, "app-charts", 14), a(), l(22, "div", 13), T(23, ft, 1, 4, "app-charts", 15), a()()), r & 2 && (n("isForGraph", !0)("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), R(t.saleTrendReport ? 3 : -1), i(2), R(t.saleTotalAmountTrendReport ? 5 : -1), i(5), P(t.formatMessage("daily_sales_report")), i(), n("tooltipText", "daily_sales_report_tooltip"), i(), n("columns", t.saleDailyReportSalesColumn)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.SALE_DAILY_SALES)("service", t.saleReportService), i(5), P(t.formatMessage("most_popular_part_wise_sales_report")), i(), n("tooltipText", "most_popular_part_wise_sales_report_tooltip"), i(), n("columns", t.mostPopularRepairAndPartColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.MOST_POPULAR_PART_WISE_SALES_REPORT)("service", t.saleReportService), i(2), R(t.isLoading ? -1 : 21), i(2), R(t.isLoading ? -1 : 23))
                },
                dependencies: [S, x, w, B, F],
                encapsulation: 2
            })
        }
    }
    return o
})();
var ze = (() => {
    class o {
        constructor() {
            this.formatMessage = p
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-task-report"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                template: function(r, t) {
                    r & 1 && (l(0, "p"), E(1, "task-report works!"), a())
                },
                encapsulation: 2
            })
        }
    }
    return o
})();
var Xe = (() => {
    class o {
        constructor() {
            this.formatMessage = p, this.router = v(ge), this.authorizationService = v(Ne), this.activatedRouter = v(Ee), this.tabs = [{
                id: 0,
                text: p("jobs"),
                path: "/reports/jobs",
                icon: I.JOB.light,
                visible: !0
            }, {
                id: 1,
                text: p("sales"),
                icon: I.SALE.light,
                path: "/reports/sales",
                visible: this.authorizationService.canAccess(k.SALE)
            }, {
                id: 2,
                text: p("common_purchase"),
                icon: I.PURCHASE.light,
                path: "/reports/purchase",
                visible: this.authorizationService.canAccess(k.PURCHASE)
            }, {
                id: 3,
                text: p("expenses"),
                icon: I.EXPENSE.light,
                path: "/reports/expenses",
                visible: this.authorizationService.canAccess(k.EXPENSE)
            }, {
                id: 4,
                text: p("tasks"),
                icon: I.TASK.light,
                path: "/reports/tasks",
                visible: !1
            }, {
                id: 5,
                text: p("inventory"),
                icon: I.INVENTORY.light,
                path: "/reports/inventory",
                visible: !0
            }, {
                id: 6,
                text: p("payment"),
                icon: I.BILLING.light,
                path: "/reports/payment",
                visible: !0
            }, {
                id: 7,
                text: p("revenues"),
                path: "/reports/revenues",
                icon: I.REPORT.light,
                visible: !0
            }, {
                id: 8,
                text: p("employees"),
                icon: I.EMPLOYEE.light,
                path: "/reports/employees",
                visible: !0
            }], this.selectedTabIndex = 0, this.ENTITY_ICONS = I
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRouter.firstChild.snapshot.data.tab_index
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-report"]
                ],
                standalone: !1,
                decls: 4,
                vars: 4,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["mode", "route", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle", "mobileMenuIcon"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "app-responsive-tabs", 3), f("tabChange", function(m) {
                        return t.selectTab(m)
                    }), a()()()()), r & 2 && (i(3), n("tabs", t.tabs)("selectedIndex", t.selectedTabIndex)("mobileMenuTitle", t.formatMessage("reports"))("mobileMenuIcon", t.ENTITY_ICONS.REPORT.solid))
                },
                dependencies: [Fe],
                encapsulation: 2
            })
        }
    }
    return o
})();
var $e = (() => {
    class o extends M {
        constructor(e) {
            super(e, _e), this.api = e, this.endpoint = _e
        }
        getReport(e) {
            return this.getListByQuery(e)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(O(Y))
            }
        }
        static {
            this.\u0275prov = A({
                token: o,
                factory: o.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return o
})();
var Qe = (() => {
    class o {
        constructor(e) {
            this.inventoryReportService = e, this.isLoading = !0, this.ENTITIES = k, this.lowStockInventoryColumn = [{
                dataField: "name",
                caption: p("part_name_label"),
                width: 160
            }, {
                dataField: "low_stock_unit",
                caption: p("min_quantity_label")
            }, {
                dataField: "quantity",
                caption: p("in_stock_label")
            }, {
                dataField: "required_quantity",
                caption: p("required_quantity_label")
            }], this.REPORT_TYPE = c, this.REPORT_DURATION_LIST = D
        }
        setReportForDuration(e) {
            this.dateDuration = {
                from_date: e.fromDate,
                to_date: e.toDate,
                type: "sale_summary_report"
            }
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(V($e))
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-inventory-report"]
                ],
                standalone: !1,
                decls: 5,
                vars: 7,
                consts: [
                    [3, "durationDateChanges", "isForGraph", "selectedDuration"],
                    [1, "row", "pt-2"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "mt-2"],
                    [3, "columns", "dateDuration", "entity", "reportType", "service"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    }), a(), l(1, "div", 1)(2, "div", 2)(3, "div"), s(4, "app-report-data-grid", 3), a()()()), r & 2 && (n("isForGraph", !0)("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(4), n("columns", t.lowStockInventoryColumn)("dateDuration", t.dateDuration)("entity", t.ENTITIES.PART)("reportType", t.REPORT_TYPE.LOW_STOCK_INVENTORY_LIST)("service", t.inventoryReportService))
                },
                dependencies: [S, x],
                encapsulation: 2
            })
        }
    }
    return o
})();
var Ke = (() => {
    class o extends M {
        constructor(e) {
            super(e, ce), this.api = e, this.endpoint = ce
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(O(Y))
            }
        }
        static {
            this.\u0275prov = A({
                token: o,
                factory: o.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return o
})();
var Ze = (() => {
    class o {
        constructor() {
            this.isLoading = !0, this.formatMessage = p, this.paymentTypeWiseReportColumns = [{
                dataField: "payment_type",
                caption: p("payment_type"),
                width: 160
            }, {
                dataField: "total_payment_received",
                caption: p("total_payment_received"),
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }], this.paymentReportService = v(Ke), this.REPORT_TYPE = c, this.REPORT_DURATION_LIST = D
        }
        setReportForDuration(e) {
            let r = {
                from_date: e.fromDate,
                to_date: e.toDate,
                type: ""
            };
            this.dateDuration = r, b([this.paymentReportService.getReport(u(_({}, r), {
                type: c.PAYMENT_RECEIVED_TREND
            })), this.paymentReportService.getReport(u(_({}, r), {
                type: c.JOB_PAYMENT_RECEIVED_TREND
            })), this.paymentReportService.getReport(u(_({}, r), {
                type: c.SALE_PAYMENT_RECEIVED_TREND
            })), this.paymentReportService.getReport(u(_({}, r), {
                type: c.PURCHASE_PAYMENT_RECEIVED_TREND
            }))]).subscribe({
                next: ([t, d, m, U]) => {
                    this.paymentReceivedTrendReport = t, this.jobPaymentReceivedTrendReport = d, this.salePaymentReceivedTrendReport = m, this.purchasePaymentReceivedTrendReport = U
                },
                error: t => {
                    console.error("Payment Report Error", t)
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-payment-report"]
                ],
                standalone: !1,
                decls: 17,
                vars: 28,
                consts: [
                    [3, "durationDateChanges", "isForGraph", "selectedDuration"],
                    [1, "row"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3"],
                    ["icon", "fa-thin fa-wallet", "tooltipId", "tooltip_total_received_amount", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "title"],
                    ["icon", "fa-thin fa-ticket", "tooltipId", "tooltip_job_received_amount", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "title"],
                    ["icon", "fa-thin fa-store-alt", "tooltipId", "tooltip_sale_received_amount", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "title"],
                    ["icon", "fa-thin fa-shopping-cart", "tooltipId", "tooltip_purchase_amount", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "title"],
                    [1, "row", "pt-2"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "mb-2"],
                    ["id", "payment-type-wise-report", 1, "m-0"],
                    ["target", "payment-type-wise-report", 3, "tooltipText"],
                    [3, "columns", "dateDuration", "reportType", "service"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    }), a(), l(1, "div", 1)(2, "div", 2), s(3, "app-trend-matrix-card", 3), a(), l(4, "div", 2), s(5, "app-trend-matrix-card", 4), a(), l(6, "div", 2), s(7, "app-trend-matrix-card", 5), a(), l(8, "div", 2), s(9, "app-trend-matrix-card", 6), a()(), l(10, "div", 7)(11, "div", 8)(12, "div", 9)(13, "h5", 10), E(14), a(), s(15, "app-tooltip", 11), a(), s(16, "app-report-data-grid", 12), a()()), r & 2 && (n("isForGraph", !0)("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), n("currentDateRangeValue", t.paymentReceivedTrendReport == null ? null : t.paymentReceivedTrendReport.current_period_total)("dateRange", (t.dateDuration == null ? null : t.dateDuration.from_date) + " - " + (t.dateDuration == null ? null : t.dateDuration.to_date))("percentage", t.paymentReceivedTrendReport == null ? null : t.paymentReceivedTrendReport.percentage_change)("toolTip", "tooltip_total_received_amount")("title", "total_received_amount"), i(2), n("currentDateRangeValue", t.jobPaymentReceivedTrendReport == null ? null : t.jobPaymentReceivedTrendReport.current_period_total)("dateRange", (t.dateDuration == null ? null : t.dateDuration.from_date) + " - " + (t.dateDuration == null ? null : t.dateDuration.to_date))("percentage", t.jobPaymentReceivedTrendReport == null ? null : t.jobPaymentReceivedTrendReport.percentage_change)("toolTip", "tooltip_job_received_amount")("title", "job_received_amount"), i(2), n("currentDateRangeValue", t.salePaymentReceivedTrendReport == null ? null : t.salePaymentReceivedTrendReport.current_period_total)("dateRange", (t.dateDuration == null ? null : t.dateDuration.from_date) + " - " + (t.dateDuration == null ? null : t.dateDuration.to_date))("percentage", t.salePaymentReceivedTrendReport == null ? null : t.salePaymentReceivedTrendReport.percentage_change)("toolTip", "tooltip_sale_received_amount")("title", "sale_received_amount"), i(2), n("currentDateRangeValue", t.purchasePaymentReceivedTrendReport == null ? null : t.purchasePaymentReceivedTrendReport.current_period_total)("dateRange", (t.dateDuration == null ? null : t.dateDuration.from_date) + " - " + (t.dateDuration == null ? null : t.dateDuration.to_date))("percentage", t.purchasePaymentReceivedTrendReport == null ? null : t.purchasePaymentReceivedTrendReport.percentage_change)("toolTip", "tooltip_purchase_amount")("title", "purchase_amount"), i(5), P(t.formatMessage("payment_type_wise_report")), i(), n("tooltipText", "tooltip_payment_type_wise_report"), i(), n("columns", t.paymentTypeWiseReportColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.PAYMENT_TYPE_WISE_AMOUNT)("service", t.paymentReportService))
                },
                dependencies: [S, x, w, F],
                encapsulation: 2
            })
        }
    }
    return o
})();
var et = (() => {
    class o extends M {
        constructor(e) {
            super(e, me), this.api = e, this.endpoint = me
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)(O(Y))
            }
        }
        static {
            this.\u0275prov = A({
                token: o,
                factory: o.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return o
})();

function Et(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 3), o & 2) {
        let e = h();
        n("currentDateRangeValue", e.purchaseTrendReport == null ? null : e.purchaseTrendReport.current_period_total)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))("percentage", e.purchaseTrendReport == null ? null : e.purchaseTrendReport.percentage_change)("toolTip", "tooltip_total_purchase_count")("tooltipId", e.REPORT_TYPE.PURCHASE_TREND)
    }
}

function gt(o, C) {
    if (o & 1 && s(0, "app-trend-matrix-card", 4), o & 2) {
        let e = h();
        n("currentDateRangeValue", e.purchaseTotalAmountTrendReport == null ? null : e.purchaseTotalAmountTrendReport.current_period_total)("dateRange", (e.dateDuration == null ? null : e.dateDuration.from_date) + " - " + (e.dateDuration == null ? null : e.dateDuration.to_date))("percentage", e.purchaseTotalAmountTrendReport == null ? null : e.purchaseTotalAmountTrendReport.percentage_change)("toolTip", "tooltip_total_purchase_amount")("tooltipId", e.REPORT_TYPE.PURCHASE_TOTAL_AMOUNT_TREND)
    }
}
var tt = (() => {
    class o {
        constructor() {
            this.formatMessage = p, this.CHART_ENTITY_TYPES = j, this.graphType = "bar", this.isLoading = !0, this.purchaseReportService = v(et), this.purchaseDailyReportColumn = [{
                dataField: "purchase_date",
                caption: p("purchase_date"),
                width: 160,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "total_purchase_amount",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("total_purchase")
            }, {
                dataField: "total_tax_amount",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("common_total_tax_amount")
            }, {
                dataField: "total_spent_payment",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                caption: p("total_spent")
            }], this.mostPopularRepairAndPartColumns = [{
                dataField: "name",
                caption: p("common_name")
            }, {
                dataField: "count",
                caption: p("report_columns_repair_service_count")
            }, {
                dataField: "total_spent",
                caption: p("total_spent")
            }, {
                dataField: "total_quantity",
                caption: p("report_columns_total_quantity")
            }], this.REPORT_TYPE = c, this.REPORT_DURATION_LIST = D
        }
        setGraphType(e) {
            this.graphType = e
        }
        setReportForDuration(e) {
            let r = {
                from_date: e.fromDate ? ? null,
                to_date: e.toDate ? ? null,
                type: ""
            };
            this.dateDuration = r, b([this.purchaseReportService.getReport(u(_({}, r), {
                type: c.PURCHASE_TREND
            })), this.purchaseReportService.getReport(u(_({}, r), {
                type: c.PURCHASE_TOTAL_AMOUNT_TREND
            }))]).subscribe({
                next: ([t, d]) => {
                    this.purchaseTrendReport = t, this.purchaseTotalAmountTrendReport = d
                },
                error: ([t, d]) => {
                    console.error("Purchase TrendReportErr", t), console.error("PURCHASE_TOTAL_AMOUNT_TREND", d)
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275cmp = y({
                type: o,
                selectors: [
                    ["app-purchase-report"]
                ],
                standalone: !1,
                decls: 20,
                vars: 16,
                consts: [
                    [3, "durationDateChanges", "selectedGraphType", "isForGraph", "selectedDuration"],
                    [1, "row"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    ["icon", "fa-thin fa-store-alt", "title", "total_purchase_count", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "tooltipId"],
                    ["icon", "fa-thin fa-wallet", "title", "total_purchase_amount", 3, "currentDateRangeValue", "dateRange", "percentage", "toolTip", "tooltipId"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "mt-2"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "mb-2"],
                    ["id", "daily_purchases", 1, "m-0"],
                    ["target", "daily_purchases", 3, "tooltipText"],
                    [3, "columns", "dateDuration", "reportType", "service"],
                    ["id", "most_popular_part_wise_sales_report", 1, "m-0"],
                    ["target", "most_popular_part_wise_sales_report", 3, "tooltipText"],
                    [1, "row", "pt-2"]
                ],
                template: function(r, t) {
                    r & 1 && (l(0, "app-report-duration-dropdown", 0), f("durationDateChanges", function(m) {
                        return t.setReportForDuration(m)
                    })("selectedGraphType", function(m) {
                        return t.setGraphType(m)
                    }), a(), l(1, "div", 1)(2, "div", 2), T(3, Et, 1, 5, "app-trend-matrix-card", 3), a(), l(4, "div", 2), T(5, gt, 1, 5, "app-trend-matrix-card", 4), a()(), l(6, "div", 1)(7, "div", 5)(8, "div", 6)(9, "h5", 7), E(10), a(), s(11, "app-tooltip", 8), a(), s(12, "app-report-data-grid", 9), a(), l(13, "div", 5)(14, "div", 6)(15, "h5", 10), E(16), a(), s(17, "app-tooltip", 11), a(), s(18, "app-report-data-grid", 9), a()(), s(19, "div", 12)), r & 2 && (n("isForGraph", !0)("selectedDuration", t.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), i(3), R(t.purchaseTrendReport ? 3 : -1), i(2), R(t.purchaseTotalAmountTrendReport ? 5 : -1), i(5), P(t.formatMessage("daily_purchase_report")), i(), n("tooltipText", "tooltip_daily_purchase_report"), i(), n("columns", t.purchaseDailyReportColumn)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.PURCHASE_DAILY_EXPENSE)("service", t.purchaseReportService), i(4), P(t.formatMessage("most_popular_part_wise_purchase_report")), i(), n("tooltipText", "tooltip_most_popular_part_wise_purchase_report"), i(), n("columns", t.mostPopularRepairAndPartColumns)("dateDuration", t.dateDuration)("reportType", t.REPORT_TYPE.MOST_POPULAR_PART_WISE_PURCHASE_REPORT)("service", t.purchaseReportService))
                },
                dependencies: [S, x, w, F],
                encapsulation: 2
            })
        }
    }
    return o
})();
var Ct = [{
        path: "",
        component: Xe,
        children: [{
            path: "jobs",
            component: Ue,
            canActivate: [N],
            data: {
                tab_index: 0,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Reports |  Jobs"
        }, {
            path: "sales",
            component: qe,
            canActivate: [N],
            data: {
                tab_index: 1,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Reports | Sales"
        }, {
            path: "purchase",
            component: tt,
            canActivate: [N],
            data: {
                tab_index: 2,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Reports | Purchase"
        }, {
            path: "expenses",
            component: Be,
            canActivate: [N],
            data: {
                tab_index: 3,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Reports | Expenses"
        }, {
            path: "tasks",
            component: ze,
            canActivate: [N],
            data: {
                tab_index: 4,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Reports | Tasks"
        }, {
            path: "inventory",
            component: Qe,
            canActivate: [N],
            data: {
                tab_index: 5,
                permissions: {
                    only: [L.PART_LIST]
                }
            },
            title: "BytePhase Reports | Inventory"
        }, {
            path: "payment",
            component: Ze,
            canActivate: [N],
            data: {
                tab_index: 6,
                permissions: {
                    only: [L.PAYMENT_WRITE]
                }
            },
            title: "BytePhase Reports | Payments"
        }, {
            path: "revenues",
            component: Ge,
            canActivate: [N],
            data: {
                tab_index: 7,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Revenues Management"
        }, {
            path: "employees",
            component: ke,
            canActivate: [N],
            data: {
                tab_index: 8,
                permissions: {
                    only: [L.REPORT_VIEW]
                }
            },
            title: "BytePhase Reports | Employees"
        }, {
            path: "",
            redirectTo: "jobs",
            pathMatch: "full"
        }]
    }],
    ot = (() => {
        class o {
            static {
                this.\u0275fac = function(r) {
                    return new(r || o)
                }
            }
            static {
                this.\u0275mod = Q({
                    type: o
                })
            }
            static {
                this.\u0275inj = $({
                    imports: [le.forChild(Ct), le]
                })
            }
        }
        return o
    })();
var Mr = (() => {
    class o {
        static {
            this.\u0275fac = function(r) {
                return new(r || o)
            }
        }
        static {
            this.\u0275mod = Q({
                type: o
            })
        }
        static {
            this.\u0275inj = $({
                imports: [ye, ot, je]
            })
        }
    }
    return o
})();
export {
    Mr as ReportModule
};