import {
    T as r
} from "./chunk-DCKGQUHB.js";
import {
    aa as i,
    ea as a,
    mc as o,
    xk as e
} from "./chunk-GOPIAW4V.js";
var f = (() => {
    class t {
        constructor() {
            this.userDeviceService = a(r), this.servicesColumns = o(() => [{
                dataField: "name",
                caption: e("service_name"),
                cellTemplate: "serviceNameTemplate",
                width: this.userDeviceService.isMobileDevice() ? 180 : 280,
                allowSorting: !0
            }, {
                dataField: "price",
                caption: e("job_price"),
                hidingPriority: 2,
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                allowSorting: !1
            }, {
                dataField: "discount",
                caption: e("disc"),
                hidingPriority: 4,
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                allowSorting: !1
            }, {
                dataField: "sub_total",
                caption: e("common_sub_total"),
                hidingPriority: 5,
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                allowSorting: !1
            }, {
                dataField: "tax_code",
                caption: e("common_tax_code"),
                hidingPriority: 3,
                allowSorting: !1
            }, {
                dataField: "tax",
                caption: e("tax_label"),
                hidingPriority: 1,
                cellTemplate: "taxSplitSubClassTemplate",
                allowSorting: !1
            }, {
                dataField: "tax_amount",
                caption: e("tax_amt"),
                hidingPriority: 0,
                dataType: "number",
                cellTemplate: "taxAmountSplitSubClassTemplate",
                allowSorting: !1
            }, {
                dataField: "line_total",
                caption: e("total_name"),
                width: 80,
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                },
                allowSorting: !1
            }])
        }
        static {
            this.\u0275fac = function(l) {
                return new(l || t)
            }
        }
        static {
            this.\u0275prov = i({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
export {
    f as a
};