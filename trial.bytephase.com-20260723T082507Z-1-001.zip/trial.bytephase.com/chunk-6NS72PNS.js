import {
    Ae as L,
    Bc as oi,
    C as Ke,
    Ec as U,
    Kc as ni,
    Le as ai,
    M as H,
    Sc as si,
    Ta as z,
    Va as ei,
    _d as g,
    ab as K,
    ba as Xe,
    ca as W,
    cb as R,
    g as Le,
    h as Ge,
    ha as q,
    hb as ne,
    ia as Ze,
    lb as ii,
    n as Qe,
    ph as li,
    rb as ti,
    rg as ri,
    t as He,
    u as Je,
    uc as se,
    y as Ye,
    yc as ae
} from "./chunk-DCKGQUHB.js";
import {
    $a as V,
    Ab as j,
    Eb as B,
    Fa as l,
    Fb as x,
    Fh as w,
    Ib as r,
    Jb as Y,
    Ka as A,
    Kb as oe,
    Lb as Ne,
    Na as E,
    Oa as te,
    Pb as h,
    Qb as y,
    Rb as C,
    Rc as We,
    Sa as J,
    Tc as Re,
    _a as T,
    aa as G,
    ba as ie,
    da as Q,
    ea as S,
    eb as d,
    fb as o,
    gb as n,
    gc as N,
    ha as f,
    hb as c,
    hc as re,
    hi as I,
    ia as v,
    ic as X,
    pd as qe,
    qb as P,
    qd as ze,
    sb as u,
    t as $,
    ub as _,
    ui as Ue,
    vd as le,
    xk as $e,
    yb as F,
    zb as D
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as Oe
} from "./chunk-FBFWB55K.js";

function Ti(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "app-responsive-tabs", 2), u("tabChange", function(i) {
            f(e);
            let s = _();
            return v(s.selectTab(i))
        }), n()
    }
    if (a & 2) {
        let e = _();
        d("tabs", e.commissionModuleTabs)("selectedIndex", e.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("hideContentHeader", !0)
    }
}

function Vi(a, k) {
    a & 1 && c(0, "router-outlet")
}
var mi = (() => {
    class a {
        constructor() {
            this.userSessionService = S(Xe), this.activatedRoute = S(qe), this.permissions = this.userSessionService.userPermissionList(), this.selectedTabIndex = 0, this.commissionModuleTabs = [{
                id: 0,
                text: "Dashboard",
                path: "/commission/dashboard",
                visible: this.permissions.includes(w.COMMISSION_VIEW_ALL)
            }, {
                id: 1,
                text: "My Commission",
                path: "/commission/my-commission",
                visible: this.permissions.includes(w.COMMISSION_VIEW_OWN)
            }, {
                id: 2,
                text: "Breakdown Report",
                path: "/commission/breakdown",
                visible: this.permissions.includes(w.COMMISSION_VIEW_ALL)
            }, {
                id: 3,
                text: "Periods",
                path: "/commission/periods",
                visible: this.permissions.includes(w.COMMISSION_MANAGE_PERIODS)
            }, {
                id: 4,
                text: "Employee Commission",
                path: "/commission/profiles",
                visible: this.permissions.includes(w.COMMISSION_MANAGE_PROFILES)
            }, {
                id: 5,
                text: "Setup Commission",
                path: "/commission/settings",
                visible: this.permissions.includes(w.COMMISSION_MANAGE_SETTINGS)
            }]
        }
        ngOnInit() {
            this.selectedTabIndex = this.activatedRoute.firstChild ? .snapshot.data.tab_index ? ? 0
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        get visibleTabs() {
            return this.commissionModuleTabs.filter(e => e.visible !== !1)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-commission"]
                ],
                standalone: !1,
                decls: 3,
                vars: 2,
                consts: [
                    [1, "container-fluid"],
                    ["mode", "route", 3, "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "hideContentHeader"],
                    ["mode", "route", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "hideContentHeader"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0), T(1, Ti, 1, 5, "app-responsive-tabs", 1), T(2, Vi, 1, 0, "router-outlet"), n()), t & 2 && (l(), V(i.visibleTabs.length > 1 ? 1 : -1), l(), V(i.visibleTabs.length <= 1 ? 2 : -1))
                },
                dependencies: [ze, ri],
                encapsulation: 2
            })
        }
    }
    return a
})();
var b = "commission",
    M = (() => {
        class a {
            constructor(e) {
                this.api = e
            }
            getSettings() {
                return this.api.get(`${b}/settings`)
            }
            updateSettings(e) {
                return this.api.put(`${b}/settings`, e)
            }
            getProfiles() {
                return this.api.get(`${b}/profiles`)
            }
            getListByQuery(e = {}) {
                return this.api.getListByQuery(`${b}/profiles`, e)
            }
            getProfile(e) {
                return this.api.get(`${b}/profiles/${e}`)
            }
            upsertProfile(e) {
                return this.api.post(`${b}/profiles`, e)
            }
            deleteProfile(e) {
                return this.api.delete(`${b}/profiles/${e}`)
            }
            getEntries(e = {}) {
                return this.api.getListByQuery(`${b}/entries`, e)
            }
            getMyEntries(e = {}) {
                return this.api.getListByQuery(`${b}/entries/my`, e)
            }
            getEntry(e) {
                return this.api.get(`${b}/entries/${e}`)
            }
            approveEntry(e) {
                return this.api.post(`${b}/entries/${e}/approve`)
            }
            voidEntry(e, t) {
                return this.api.post(`${b}/entries/${e}/void`, {
                    void_reason: t
                })
            }
            bulkApprove(e) {
                return this.api.post(`${b}/entries/bulk-approve`, {
                    ids: e
                })
            }
            bulkVoid(e, t) {
                return this.api.post(`${b}/entries/bulk-void`, {
                    ids: e,
                    void_reason: t
                })
            }
            getAdjustments(e = {}) {
                return this.api.getListByQuery(`${b}/adjustments`, e)
            }
            createAdjustment(e) {
                return this.api.post(`${b}/adjustments`, e)
            }
            approveAdjustment(e) {
                return this.api.post(`${b}/adjustments/${e}/approve`)
            }
            rejectAdjustment(e) {
                return this.api.post(`${b}/adjustments/${e}/reject`)
            }
            getPeriods(e = {}) {
                return this.api.getListByQuery(`${b}/periods`, e)
            }
            getPeriod(e) {
                return this.api.get(`${b}/periods/${e}`)
            }
            lockPeriod(e) {
                return this.api.post(`${b}/periods/${e}/lock`)
            }
            unlockPeriod(e) {
                return this.api.post(`${b}/periods/${e}/unlock`)
            }
            markPeriodPaid(e, t = {}) {
                return this.api.post(`${b}/periods/${e}/mark-paid`, t)
            }
            getBreakdown(e = {}) {
                return this.api.getListByQuery(`${b}/reports/breakdown`, e)
            }
            getMyCommission(e = {}) {
                return this.api.get(`${b}/reports/my-commission`)
            }
            getSummary(e = {}) {
                return this.api.getListByQuery(`${b}/reports/summary`, e)
            }
            getLiveDashboard(e = {}) {
                return this.api.getListByQuery(`${b}/reports/live`, e)
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || a)(Q(Ue))
                }
            }
            static {
                this.\u0275prov = G({
                    token: a,
                    factory: a.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return a
    })();
var ci = (() => {
    class a {
        constructor(e) {
            this.commission = e, this.filters = {}
        }
        getListByQuery(e = {}) {
            let t = Oe({}, e);
            return this.filters.status && (t.status = this.filters.status), this.filters.commissionable_type && (t.commissionable_type = this.filters.commissionable_type), this.filters.date_from && (t.date_from = this.filters.date_from), this.filters.date_to && (t.date_to = this.filters.date_to), this.commission.getEntries(t).pipe($(i => ({
                data: i ? .data ? ? i ? ? [],
                total: i ? .total ? ? (i ? .data ? ? i ? ? []).length
            })))
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)(Q(M))
            }
        }
        static {
            this.\u0275prov = G({
                token: a,
                factory: a.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return a
})();
var pi = (() => {
        class a {
            constructor(e) {
                this.commission = e, this.filters = {
                    year: new Date().getFullYear()
                }
            }
            getListByQuery(e = {}) {
                let t = {};
                return this.filters.year && (t.year = this.filters.year), this.filters.month && (t.month = this.filters.month), this.filters.status && (t.status = this.filters.status), this.commission.getPeriods(t).pipe($(i => ({
                    data: i ? .data ? ? i ? ? [],
                    total: i ? .total ? ? (i ? .data ? ? i ? ? []).length
                })))
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || a)(Q(M))
                }
            }
            static {
                this.\u0275prov = G({
                    token: a,
                    factory: a.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return a
    })(),
    ui = (() => {
        class a {
            constructor(e) {
                this.commission = e, this.latest = null, this.filters = {
                    year: new Date().getFullYear(),
                    month: new Date().getMonth() + 1
                }
            }
            get dashboard() {
                return this.latest
            }
            getListByQuery(e = {}) {
                return this.commission.getLiveDashboard({
                    year: this.filters.year,
                    month: this.filters.month
                }).pipe($(t => {
                    this.latest = t;
                    let i = t ? .employees ? ? [];
                    return {
                        data: i,
                        total: i.length
                    }
                }))
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || a)(Q(M))
                }
            }
            static {
                this.\u0275prov = G({
                    token: a,
                    factory: a.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return a
    })(),
    _i = (() => {
        class a {
            constructor(e) {
                this.commission = e, this.latest = null, this.filters = {}
            }
            get summary() {
                return this.latest
            }
            setFilters(e) {
                this.filters = e
            }
            getListByQuery(e = {}) {
                let t = {};
                return this.filters.date_from && (t.date_from = this.filters.date_from), this.filters.date_to && (t.date_to = this.filters.date_to), this.commission.getMyCommission(t).pipe($(i => {
                    this.latest = i;
                    let s = i ? [{
                        category: "Jobs",
                        commission: +i.jobs_commission,
                        count: i.jobs_count,
                        bold: !1,
                        danger: !1
                    }, {
                        category: "Sales",
                        commission: +i.sales_commission,
                        count: i.sales_count,
                        bold: !1,
                        danger: !1
                    }, {
                        category: "Total Earned",
                        commission: +i.total_earned,
                        count: (i.jobs_count || 0) + (i.sales_count || 0),
                        bold: !0,
                        danger: !1
                    }, {
                        category: "Adjustments",
                        commission: +i.total_adjustments,
                        count: null,
                        bold: !1,
                        danger: +i.total_adjustments < 0
                    }, {
                        category: "Net Total",
                        commission: +i.net_total,
                        count: null,
                        bold: !0,
                        danger: !1
                    }] : [];
                    return {
                        data: s,
                        total: s.length
                    }
                }))
            }
            static {
                this.\u0275fac = function(t) {
                    return new(t || a)(Q(M))
                }
            }
            static {
                this.\u0275prov = G({
                    token: a,
                    factory: a.\u0275fac,
                    providedIn: "root"
                })
            }
        }
        return a
    })();

function Mi(a, k) {
    if (a & 1 && (o(0, "div")(1, "div", 12)(2, "div", 13)(3, "div", 14)(4, "div", 15)(5, "div", 16)(6, "div", 17), c(7, "i", 18), n(), o(8, "div", 19)(9, "span", 20), r(10, " Jobs Commission "), c(11, "app-tooltip", 21), n(), o(12, "small", 22), r(13, "From job assignments"), n(), o(14, "div", 23)(15, "span", 24), c(16, "app-currency-symbol"), r(17), N(18, "number"), n(), o(19, "small", 25), r(20, "this month"), n()()()()()()(), o(21, "div", 13)(22, "div", 26)(23, "div", 15)(24, "div", 16)(25, "div", 27), c(26, "i", 28), n(), o(27, "div", 19)(28, "span", 20), r(29, " Sales Commission "), c(30, "app-tooltip", 29), n(), o(31, "small", 22), r(32, "From sales transactions"), n(), o(33, "div", 23)(34, "span", 30), c(35, "app-currency-symbol"), r(36), N(37, "number"), n(), o(38, "small", 25), r(39, "this month"), n()()()()()()(), o(40, "div", 13)(41, "div", 31)(42, "div", 15)(43, "div", 16)(44, "div", 32), c(45, "i", 33), n(), o(46, "div", 19)(47, "span", 20), r(48, " Refunds & Adjustments "), c(49, "app-tooltip", 34), n(), o(50, "small", 22), r(51, "Deductions this month"), n(), o(52, "div", 23)(53, "span", 35), r(54), c(55, "app-currency-symbol"), r(56), N(57, "number"), n(), o(58, "small", 25), r(59, "this month"), n()()()()()()(), o(60, "div", 13)(61, "div", 36)(62, "div", 15)(63, "div", 16)(64, "div", 37), c(65, "i", 38), n(), o(66, "div", 19)(67, "span", 20), r(68, " Net Total "), c(69, "app-tooltip", 39), n(), o(70, "small", 22), r(71, "Total payable this period"), n(), o(72, "div", 23)(73, "span", 40), c(74, "app-currency-symbol"), r(75), N(76, "number"), n(), o(77, "small", 25), r(78, "this period"), n()()()()()()()()()), a & 2) {
        let e = _();
        l(11), d("needTranslation", !1), l(6), Y(X(18, 9, e.dashboard.stats.total_jobs, "1.0-0")), l(13), d("needTranslation", !1), l(6), Y(X(37, 12, e.dashboard.stats.total_sales, "1.0-0")), l(13), d("needTranslation", !1), l(5), Y(e.dashboard.stats.total_adjustments < 0 ? "-" : ""), l(2), Y(X(57, 15, e.dashboard.stats.total_adjustments < 0 ? -e.dashboard.stats.total_adjustments : e.dashboard.stats.total_adjustments, "1.0-0")), l(13), d("needTranslation", !1), l(6), Y(X(76, 18, e.dashboard.stats.net_total, "1.0-0"))
    }
}
var hi = (() => {
    class a {
        constructor(e) {
            this.service = e, this.entity = I.COMMISSION_DASHBOARD, this.selectedYear = new Date().getFullYear(), this.selectedMonth = new Date().getMonth() + 1, this.months = [{
                value: 1,
                label: "January"
            }, {
                value: 2,
                label: "February"
            }, {
                value: 3,
                label: "March"
            }, {
                value: 4,
                label: "April"
            }, {
                value: 5,
                label: "May"
            }, {
                value: 6,
                label: "June"
            }, {
                value: 7,
                label: "July"
            }, {
                value: 8,
                label: "August"
            }, {
                value: 9,
                label: "September"
            }, {
                value: 10,
                label: "October"
            }, {
                value: 11,
                label: "November"
            }, {
                value: 12,
                label: "December"
            }], this.netTotalCellValue = t => +t.jobs_commission + +t.sales_commission + (+t.adjustments || 0), this.columns = [{
                caption: "Employee",
                cellTemplate: "commissionEmployeeNameTemplate"
            }, {
                dataField: "jobs_commission",
                caption: "Jobs Commission",
                alignment: "right",
                cellTemplate: "commissionCurrencyTemplate"
            }, {
                dataField: "sales_commission",
                caption: "Sales Commission",
                alignment: "right",
                cellTemplate: "commissionCurrencyTemplate"
            }, {
                dataField: "adjustments",
                caption: "Adjustments",
                alignment: "right",
                cellTemplate: "commissionAdjustmentTemplate"
            }, {
                caption: "Net Total",
                alignment: "right",
                calculateCellValue: this.netTotalCellValue,
                cellTemplate: "commissionCurrencyTemplate"
            }]
        }
        get dashboard() {
            return this.service.dashboard
        }
        onPeriodChange() {
            this.service.filters = {
                year: this.selectedYear,
                month: this.selectedMonth
            }, this.dataGrid ? .getData()
        }
        get monthLabel() {
            return this.months.find(e => e.value === this.selectedMonth) ? .label || ""
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)(A(ui))
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-commission-dashboard"]
                ],
                viewQuery: function(t, i) {
                    if (t & 1 && F(g, 5), t & 2) {
                        let s;
                        D(s = j()) && (i.dataGrid = s.first)
                    }
                },
                standalone: !1,
                decls: 21,
                vars: 17,
                consts: [
                    [1, "p-4"],
                    [1, "d-flex", "justify-content-between", "align-items-start", "mb-4"],
                    [1, "fw-bold", "mb-1"],
                    [1, "text-secondary"],
                    [1, "d-flex", "gap-2"],
                    ["valueExpr", "value", "displayExpr", "label", 3, "valueChange", "onValueChanged", "dataSource", "value", "width"],
                    [3, "valueChange", "onValueChanged", "value", "width", "showSpinButtons"],
                    [1, "dx-card", "mb-4", "p-3"],
                    [1, "text-danger", "fw-semibold"],
                    [1, "dx-card", "p-3"],
                    [1, "fw-bold", "mb-3"],
                    [3, "service", "entity", "columns", "isVisibleAddAction", "isVisibleEditAction", "isVisibleDeleteAction", "isVisibleClearFilterButton", "isVisibleTitle"],
                    [1, "row", "g-3", "mb-4"],
                    [1, "col-md-3"],
                    [1, "card", "border-0", "border-start", "border-4", "border-success", "shadow-sm", "h-100"],
                    [1, "card-body", "p-3"],
                    [1, "d-flex", "align-items-start", "gap-3"],
                    [1, "bg-success", "bg-opacity-10", "rounded-3", "d-flex", "align-items-center", "justify-content-center", "flex-shrink-0", 2, "width", "40px", "height", "40px"],
                    [1, "fa-thin", "fa-arrow-trend-up", "text-success", "fs-5"],
                    [1, "flex-grow-1", "min-w-0"],
                    [1, "fw-semibold", "d-inline-flex", "align-items-center"],
                    ["title", "Jobs Commission", "target", "tooltip-jobs-commission", "tooltipText", "Total commission earned from job assignments in the selected month. Includes Pending and Approved entries; Voided and Recalculated entries are excluded.", 3, "needTranslation"],
                    [1, "text-muted", "d-block", "mb-2"],
                    [1, "d-flex", "flex-nowrap", "align-items-end", "justify-content-between", "gap-2"],
                    [1, "fs-4", "fw-bold", "text-success", "text-nowrap", 2, "line-height", "1"],
                    [1, "text-muted", "text-lowercase", "text-nowrap"],
                    [1, "card", "border-0", "border-start", "border-4", "border-info", "shadow-sm", "h-100"],
                    [1, "bg-info", "bg-opacity-10", "rounded-3", "d-flex", "align-items-center", "justify-content-center", "flex-shrink-0", 2, "width", "40px", "height", "40px"],
                    [1, "fa-thin", "fa-dollar-sign", "text-info", "fs-5"],
                    ["title", "Sales Commission", "target", "tooltip-sales-commission", "tooltipText", "Total commission earned from sale transactions in the selected month. Includes Pending and Approved entries; Voided and Recalculated entries are excluded.", 3, "needTranslation"],
                    [1, "fs-4", "fw-bold", "text-info", "text-nowrap", 2, "line-height", "1"],
                    [1, "card", "border-0", "border-start", "border-4", "border-danger", "shadow-sm", "h-100"],
                    [1, "bg-danger", "bg-opacity-10", "rounded-3", "d-flex", "align-items-center", "justify-content-center", "flex-shrink-0", 2, "width", "40px", "height", "40px"],
                    [1, "fa-thin", "fa-arrow-trend-down", "text-danger", "fs-5"],
                    ["title", "Refunds & Adjustments", "target", "tooltip-refunds-adjustments", "tooltipText", "Net of all approved adjustments posted to this month \u2014 corrections from amount changes on locked periods, refunds, and manual adjustments. Negative values reduce the final payable amount.", 3, "needTranslation"],
                    [1, "fs-4", "fw-bold", "text-danger", "text-nowrap", 2, "line-height", "1"],
                    [1, "card", "border-0", "border-start", "border-4", "border-primary", "shadow-sm", "h-100"],
                    [1, "bg-primary", "bg-opacity-10", "rounded-3", "d-flex", "align-items-center", "justify-content-center", "flex-shrink-0", 2, "width", "40px", "height", "40px"],
                    [1, "fa-thin", "fa-users", "text-primary", "fs-5"],
                    ["title", "Net Total", "target", "tooltip-net-total", "tooltipText", "Final payable amount for this period: Jobs Commission + Sales Commission + Refunds & Adjustments. This is what will actually be paid once the period is locked and marked Paid.", 3, "needTranslation"],
                    [1, "fs-4", "fw-bold", "text-primary", "text-nowrap", 2, "line-height", "1"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0)(1, "div", 1)(2, "div")(3, "h4", 2), r(4, "Commission Dashboard"), n(), o(5, "span", 3), r(6), n()(), o(7, "div", 4)(8, "dx-select-box", 5), C("valueChange", function(m) {
                        return y(i.selectedMonth, m) || (i.selectedMonth = m), m
                    }), u("onValueChanged", function() {
                        return i.onPeriodChange()
                    }), n(), o(9, "dx-number-box", 6), C("valueChange", function(m) {
                        return y(i.selectedYear, m) || (i.selectedYear = m), m
                    }), u("onValueChanged", function() {
                        return i.onPeriodChange()
                    }), n()()(), o(10, "div", 7)(11, "small")(12, "span", 8), r(13, "Note:"), n(), o(14, "span", 3), r(15, " This dashboard shows real-time commission data for the current period. Amounts are calculated based on your configured settings and automatically updated when payments are received or refunds are processed."), n()()(), T(16, Mi, 79, 21, "div"), o(17, "div", 9)(18, "h6", 10), r(19, "All Employees"), n(), c(20, "app-data-grid", 11), n()()), t & 2 && (l(6), Ne("", i.monthLabel, " ", i.selectedYear, " \u2014 Real-time overview"), l(2), d("dataSource", i.months), h("value", i.selectedMonth), d("width", 140), l(), h("value", i.selectedYear), d("width", 90)("showSpinButtons", !1), l(7), V(i.dashboard ? 16 : -1), l(4), d("service", i.service)("entity", i.entity)("columns", i.columns)("isVisibleAddAction", !1)("isVisibleEditAction", !1)("isVisibleDeleteAction", !1)("isVisibleClearFilterButton", !1)("isVisibleTitle", !1))
                },
                dependencies: [g, ti, si, U, z, We],
                encapsulation: 2
            })
        }
    }
    return a
})();

function Bi(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "div")(1, "label", 17), r(2, "Reason for voiding"), n(), o(3, "dx-text-area", 18), C("valueChange", function(i) {
            f(e);
            let s = _();
            return y(s.voidReason, i) || (s.voidReason = i), v(i)
        }), n(), o(4, "div", 19)(5, "app-save-cancel-footer", 20), u("cancelClick", function() {
            f(e);
            let i = _();
            return v(i.closeVoidModal())
        })("saveClick", function() {
            f(e);
            let i = _();
            return v(i.confirmVoid())
        }), n()()()
    }
    if (a & 2) {
        let e = _();
        l(3), h("value", e.voidReason), d("height", 100), l(2), d("isDisabled", !e.voidReason.trim())("isVisibleHr", !1)("useSubmitBehavior", !1)
    }
}
var bi = (() => {
    class a {
        isTerminalStatus(e) {
            return e === "paid" || e === "voided" || e === "recalculated"
        }
        get hasApprovableSelected() {
            return this.selectedRows.some(e => e.status === "pending")
        }
        get hasVoidableSelected() {
            return this.selectedRows.some(e => e.status === "pending" || e.status === "approved")
        }
        constructor(e) {
            this.service = e, this.commissionService = S(M), this.toastService = S(W), this.entity = I.COMMISSION_ENTRY, this.filterStatus = "", this.filterType = "", this.filterDateFrom = "", this.filterDateTo = "", this.selectedIds = [], this.selectedRows = [], this.voidModalVisible = !1, this.voidReason = "", this.voidTargetId = null, this.isBulkVoid = !1, this.statusOptions = [{
                value: "",
                label: "All Status"
            }, {
                value: "pending",
                label: "Pending"
            }, {
                value: "approved",
                label: "Approved"
            }, {
                value: "paid",
                label: "Paid"
            }, {
                value: "voided",
                label: "Voided"
            }], this.typeOptions = [{
                value: "",
                label: "All Types"
            }, {
                value: "job",
                label: "Jobs"
            }, {
                value: "sale",
                label: "Sales"
            }], this.commissionTotalValue = t => +t.commission_amount + (+t.adjustments_sum || 0), this.columns = [{
                dataField: "created_at",
                caption: "Date",
                dataType: "date",
                format: "dd MMM yy",
                width: 100
            }, {
                caption: "Ref #",
                cellTemplate: "commissionRefTemplate",
                width: 90,
                allowSorting: !1
            }, {
                caption: "Employee",
                cellTemplate: "commissionEmployeeNameTemplate",
                allowSorting: !1
            }, {
                dataField: "base_amount",
                caption: "Amount",
                alignment: "right",
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                caption: "Commission",
                alignment: "right",
                calculateCellValue: this.commissionTotalValue,
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "status",
                caption: "Status",
                alignment: "center",
                cellTemplate: "commissionStatusTemplate"
            }, {
                caption: "Action",
                allowSorting: !1,
                cellTemplate: "commissionEntryActionsTemplate"
            }], this.onCellPrepared = t => {
                t.rowType === "data" && t.column ? .command === "select" && this.isTerminalStatus(t.data ? .status) && (t.cellElement.querySelector(".dx-select-checkbox") ? .classList.add("dx-state-disabled"), t.cellElement.style.pointerEvents = "none")
            }
        }
        onSelectionChanged(e) {
            this.selectedRows = e, this.selectedIds = e.map(t => t.id)
        }
        onFilter() {
            this.service.filters = {
                status: this.filterStatus || void 0,
                commissionable_type: this.filterType || void 0,
                date_from: this.filterDateFrom || void 0,
                date_to: this.filterDateTo || void 0
            }, this.dataGrid ? .getData()
        }
        onCommissionAction(e) {
            e.action === "approve" ? this.approveEntry(e.row) : e.action === "void" && this.openVoidModal(e.row.id)
        }
        approveEntry(e) {
            this.commissionService.approveEntry(e.id).subscribe({
                next: () => {
                    this.toastService.success("Entry approved."), this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to approve.")
            })
        }
        openVoidModal(e) {
            this.voidTargetId = e, this.isBulkVoid = !1, this.voidReason = "", this.voidModalVisible = !0
        }
        openBulkVoidModal() {
            let e = this.selectedRows.filter(t => t.status === "pending" || t.status === "approved").map(t => t.id);
            e.length && (this.selectedIds = e, this.isBulkVoid = !0, this.voidReason = "", this.voidModalVisible = !0)
        }
        closeVoidModal() {
            this.voidModalVisible = !1
        }
        confirmVoid() {
            this.voidReason.trim() && (this.isBulkVoid ? this.commissionService.bulkVoid(this.selectedIds, this.voidReason).subscribe({
                next: e => {
                    this.toastService.success(e.message || "Entries voided."), this.selectedIds = [], this.selectedRows = [], this.voidModalVisible = !1, this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to void.")
            }) : this.voidTargetId && this.commissionService.voidEntry(this.voidTargetId, this.voidReason).subscribe({
                next: () => {
                    this.toastService.success("Entry voided."), this.voidModalVisible = !1, this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to void.")
            }))
        }
        bulkApprove() {
            let e = this.selectedRows.filter(t => t.status === "pending").map(t => t.id);
            e.length && this.commissionService.bulkApprove(e).subscribe({
                next: t => {
                    this.toastService.success(t.message || "Entries approved."), this.selectedIds = [], this.selectedRows = [], this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to approve.")
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)(A(ci))
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-commission-breakdown"]
                ],
                viewQuery: function(t, i) {
                    if (t & 1 && F(g, 5), t & 2) {
                        let s;
                        D(s = j()) && (i.dataGrid = s.first)
                    }
                },
                standalone: !1,
                decls: 24,
                vars: 39,
                consts: [
                    [1, "container-fluid", "py-3"],
                    ["message", "Statuses: Pending awaits approval, Approved is finalized for payment, Paid is settled, Voided is excluded, Recalculated was replaced by a newer entry after a Job/Sale change. Only Pending and Approved rows can be selected for bulk Approve or Void \u2014 terminal-status rows are locked.", 3, "isVisibleCancelButton"],
                    [1, "dx-card"],
                    [1, "p-3", "border-bottom", "d-flex", "justify-content-between", "align-items-center"],
                    [1, "mb-0"],
                    [1, "d-flex", "gap-2"],
                    ["type", "success", "stylingMode", "outlined", 3, "onClick", "text", "disabled"],
                    ["type", "danger", "stylingMode", "outlined", 3, "onClick", "text", "disabled"],
                    [1, "p-3"],
                    [1, "row", "g-2", "mb-3"],
                    [1, "col-auto"],
                    ["valueExpr", "value", "displayExpr", "label", 3, "valueChange", "onValueChanged", "dataSource", "value", "width"],
                    ["type", "date", "displayFormat", "dd/MM/yyyy", "placeholder", "From", 3, "valueChange", "onValueChanged", "value", "dateSerializationFormat", "showClearButton"],
                    ["type", "date", "displayFormat", "dd/MM/yyyy", "placeholder", "To", 3, "valueChange", "onValueChanged", "value", "dateSerializationFormat", "showClearButton"],
                    ["keyExpr", "id", "selectionMode", "multiple", 3, "selectedRowKeysChange", "selectionChanged", "cellPrepared", "commissionAction", "service", "entity", "columns", "selectedRowKeys", "isVisibleAddAction", "isVisibleEditAction", "isVisibleDeleteAction", "isVisibleClearFilterButton", "isVisibleTitle"],
                    [3, "visibleChange", "onHiding", "visible", "showTitle", "title", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "form-label"],
                    ["placeholder", "Enter reason...", 3, "valueChange", "value", "height"],
                    [1, "d-flex", "justify-content-end", "mt-3"],
                    ["saveText", "void", "type", "danger", 3, "cancelClick", "saveClick", "isDisabled", "isVisibleHr", "useSubmitBehavior"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0), c(1, "app-alert-panel", 1), o(2, "div", 2)(3, "div", 3)(4, "h5", 4), r(5, "Employee Commission Breakdown Report"), n(), o(6, "div", 5)(7, "dx-button", 6), N(8, "translate"), u("onClick", function() {
                        return i.bulkApprove()
                    }), n(), o(9, "dx-button", 7), N(10, "translate"), u("onClick", function() {
                        return i.openBulkVoidModal()
                    }), n()()(), o(11, "div", 8)(12, "div", 9)(13, "div", 10)(14, "dx-select-box", 11), C("valueChange", function(m) {
                        return y(i.filterStatus, m) || (i.filterStatus = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()(), o(15, "div", 10)(16, "dx-select-box", 11), C("valueChange", function(m) {
                        return y(i.filterType, m) || (i.filterType = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()(), o(17, "div", 10)(18, "dx-date-box", 12), C("valueChange", function(m) {
                        return y(i.filterDateFrom, m) || (i.filterDateFrom = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()(), o(19, "div", 10)(20, "dx-date-box", 13), C("valueChange", function(m) {
                        return y(i.filterDateTo, m) || (i.filterDateTo = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()()(), o(21, "app-data-grid", 14), C("selectedRowKeysChange", function(m) {
                        return y(i.selectedIds, m) || (i.selectedIds = m), m
                    }), u("selectionChanged", function(m) {
                        return i.onSelectionChanged(m)
                    })("cellPrepared", function(m) {
                        return i.onCellPrepared(m)
                    })("commissionAction", function(m) {
                        return i.onCommissionAction(m)
                    }), n()()(), o(22, "dx-popup", 15), C("visibleChange", function(m) {
                        return y(i.voidModalVisible, m) || (i.voidModalVisible = m), m
                    }), u("onHiding", function() {
                        return i.closeVoidModal()
                    }), J(23, Bi, 6, 5, "div", 16), n()()), t & 2 && (l(), d("isVisibleCancelButton", !1), l(6), d("text", re(8, 35, "approve_selected"))("disabled", !i.hasApprovableSelected), l(2), d("text", re(10, 37, "void_selected"))("disabled", !i.hasVoidableSelected), l(5), d("dataSource", i.statusOptions), h("value", i.filterStatus), d("width", 160), l(2), d("dataSource", i.typeOptions), h("value", i.filterType), d("width", 160), l(2), h("value", i.filterDateFrom), d("dateSerializationFormat", "yyyy-MM-dd")("showClearButton", !0), l(2), h("value", i.filterDateTo), d("dateSerializationFormat", "yyyy-MM-dd")("showClearButton", !0), l(), d("service", i.service)("entity", i.entity)("columns", i.columns), h("selectedRowKeys", i.selectedIds), d("isVisibleAddAction", !1)("isVisibleEditAction", !1)("isVisibleDeleteAction", !1)("isVisibleClearFilterButton", !1)("isVisibleTitle", !1), l(), h("visible", i.voidModalVisible), d("showTitle", !0)("title", i.isBulkVoid ? "Void Selected Entries" : "Void Entry")("dragEnabled", !1)("hideOnOutsideClick", !1)("showCloseButton", !0)("width", 420)("height", "auto"), l(), d("dxTemplateOf", "content"))
                },
                dependencies: [R, g, L, q, Ze, ae, K, z, ne, Ke],
                encapsulation: 2
            })
        }
    }
    return a
})();
var gi = (() => {
    class a {
        constructor(e) {
            this.service = e, this.entity = I.MY_COMMISSION, this.filterDateFrom = "", this.filterDateTo = "", this.columns = [{
                dataField: "category",
                caption: "Category",
                cellTemplate: "commissionSummaryCategoryTemplate",
                allowSorting: !1
            }, {
                dataField: "commission",
                caption: "Commission",
                alignment: "right",
                cellTemplate: "commissionSummaryValueTemplate",
                allowSorting: !1
            }, {
                dataField: "count",
                caption: "Count",
                alignment: "right",
                cellTemplate: "commissionSummaryCountTemplate",
                allowSorting: !1
            }]
        }
        onFilter() {
            this.service.setFilters({
                date_from: this.filterDateFrom,
                date_to: this.filterDateTo
            }), this.dataGrid ? .getData()
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)(A(_i))
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-my-commission"]
                ],
                viewQuery: function(t, i) {
                    if (t & 1 && F(g, 5), t & 2) {
                        let s;
                        D(s = j()) && (i.dataGrid = s.first)
                    }
                },
                standalone: !1,
                decls: 13,
                vars: 15,
                consts: [
                    [1, "container-fluid", "py-3"],
                    ["message", "Your commissions are grouped by month. Entries start as Pending, then move to Approved once your manager confirms them. When the month's period is locked and marked Paid by admin, all approved entries here move to Paid status.", 3, "isVisibleCancelButton"],
                    [1, "dx-card"],
                    [1, "p-3", "border-bottom"],
                    [1, "mb-0"],
                    [1, "p-3"],
                    [1, "row", "g-2", "mb-3"],
                    [1, "col-auto"],
                    ["type", "date", "displayFormat", "dd/MM/yyyy", "placeholder", "From", 3, "valueChange", "onValueChanged", "value", "dateSerializationFormat", "showClearButton"],
                    ["type", "date", "displayFormat", "dd/MM/yyyy", "placeholder", "To", 3, "valueChange", "onValueChanged", "value", "dateSerializationFormat", "showClearButton"],
                    [3, "service", "entity", "columns", "isVisibleAddAction", "isVisibleEditAction", "isVisibleDeleteAction", "isVisibleClearFilterButton", "isVisibleTitle"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0), c(1, "app-alert-panel", 1), o(2, "div", 2)(3, "div", 3)(4, "h5", 4), r(5, "My Commission Report"), n()(), o(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "dx-date-box", 8), C("valueChange", function(m) {
                        return y(i.filterDateFrom, m) || (i.filterDateFrom = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()(), o(10, "div", 7)(11, "dx-date-box", 9), C("valueChange", function(m) {
                        return y(i.filterDateTo, m) || (i.filterDateTo = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()()(), c(12, "app-data-grid", 10), n()()()), t & 2 && (l(), d("isVisibleCancelButton", !1), l(8), h("value", i.filterDateFrom), d("dateSerializationFormat", "yyyy-MM-dd")("showClearButton", !0), l(2), h("value", i.filterDateTo), d("dateSerializationFormat", "yyyy-MM-dd")("showClearButton", !0), l(), d("service", i.service)("entity", i.entity)("columns", i.columns)("isVisibleAddAction", !1)("isVisibleEditAction", !1)("isVisibleDeleteAction", !1)("isVisibleClearFilterButton", !1)("isVisibleTitle", !1))
                },
                dependencies: [g, L, ae],
                encapsulation: 2
            })
        }
    }
    return a
})();

function Ai(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "app-edit-back-btn", 8), u("editClick", function() {
            f(e);
            let i = _();
            return v(i.onEdit())
        }), n()
    }
}

function Fi(a, k) {
    a & 1 && (o(0, "div", 6), c(1, "i", 9), o(2, "div", 10)(3, "span", 11), r(4, "Note:"), n(), r(5, " If commission setup is updated/revised it will be applied on new transactions only. "), n()())
}

function Di(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "app-save-cancel-footer", 53), u("saveClick", function() {
            f(e);
            let i = _(2);
            return v(i.onSave())
        })("cancelClick", function() {
            f(e);
            let i = _(2);
            return v(i.onCancel())
        }), n()
    }
    if (a & 2) {
        let e = _(2);
        d("isSaving", e.isSaving)("useSubmitBehavior", !1)("isVisibleHr", !1)
    }
}

function ji(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "div")(1, "form", 12)(2, "div", 13)(3, "div", 14)(4, "div", 15)(5, "div", 16)(6, "div", 17), c(7, "i", 18), n(), o(8, "div")(9, "div", 2)(10, "span", 19), r(11, "\u24EA"), n(), o(12, "h6", 4), r(13, "Enable Commission Module"), n(), o(14, "span", 20), r(15, "Required"), n()(), o(16, "small", 21), r(17, "Master switch \u2014 when disabled, no commission entries are created for any transaction."), n()()(), o(18, "div", 22), c(19, "dx-switch", 23), o(20, "label", 24), r(21), n()()()()(), o(22, "div", 13)(23, "div", 14)(24, "div", 25)(25, "div", 17), c(26, "i", 26), n(), o(27, "div")(28, "div", 2)(29, "span", 19), r(30, "\u2460"), n(), o(31, "h6", 4), r(32, "Commission Trigger"), n(), o(33, "span", 20), r(34, "Required"), n()(), o(35, "small", 21), r(36, "When should commission be calculated and recorded?"), n()()(), o(37, "div", 27)(38, "div", 28)(39, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("commission_trigger")) == null ? null : i.setValue("payment")))
        }), o(40, "div", 30)(41, "div", 16)(42, "div", 31), c(43, "i", 32), n(), o(44, "div")(45, "div", 33), c(46, "i", 34), o(47, "span", 11), r(48, "Commission triggers when payment is received"), n()(), o(49, "small", 35), r(50, "\u2713 Recommended for most businesses"), n(), o(51, "small", 21), r(52, "Commission is earned immediately when payment clears"), n()()()()()(), o(53, "div", 28)(54, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("commission_trigger")) == null ? null : i.setValue("invoice")))
        }), o(55, "div", 30)(56, "div", 16)(57, "div", 31), c(58, "i", 32), n(), o(59, "div")(60, "div", 33), c(61, "i", 36), o(62, "span", 11), r(63, "Commission triggers when invoice is fully paid"), n()(), o(64, "small", 37), r(65, "For businesses that always create invoices"), n(), o(66, "small", 21), r(67, "Commission is earned only after full invoice payment"), n()()()()()()()()(), o(68, "div", 13)(69, "div", 14)(70, "div", 25)(71, "div", 17), c(72, "i", 38), n(), o(73, "div")(74, "div", 2)(75, "span", 19), r(76, "\u2461"), n(), o(77, "h6", 4), r(78, "Refund Commission"), n()(), o(79, "small", 21), r(80, "If a job/sale is refunded, auto-deduct commission?"), n()()(), o(81, "div", 27)(82, "div", 28)(83, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("refund_deduct_commission")) == null ? null : i.setValue(!0)))
        }), o(84, "div", 30)(85, "div", 39), c(86, "i", 32), o(87, "div")(88, "span", 11), r(89, "Yes \u2014 automatically deduct commission on refund"), n(), o(90, "small", 37), r(91, "Proportional commission is reversed in the current period"), n()()()()()(), o(92, "div", 28)(93, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("refund_deduct_commission")) == null ? null : i.setValue(!1)))
        }), o(94, "div", 30)(95, "div", 39), c(96, "i", 32), o(97, "div")(98, "span", 11), r(99, "No \u2014 keep commission even after refund"), n(), o(100, "small", 37), r(101, "Admin can manually void entries if needed"), n()()()()()()()()(), o(102, "div", 13)(103, "div", 14)(104, "div", 25)(105, "div", 17), c(106, "i", 40), n(), o(107, "div")(108, "div", 2)(109, "span", 19), r(110, "\u2462"), n(), o(111, "h6", 4), r(112, "Calculate Commission On"), n(), o(113, "span", 20), r(114, "Required"), n()(), o(115, "small", 21), r(116, "What amount should commission be calculated on?"), n()()(), o(117, "div", 27)(118, "div", 28)(119, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("commission_basis")) == null ? null : i.setValue("revenue")))
        }), o(120, "div", 30)(121, "div", 16), c(122, "i", 41), o(123, "div")(124, "span", 11), r(125, "Revenue (Selling Price)"), n(), o(126, "small", 37), r(127, "Commission calculated on total amount customer pays"), n()()()()()(), o(128, "div", 28)(129, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("commission_basis")) == null ? null : i.setValue("profit")))
        }), o(130, "div", 30)(131, "div", 16), c(132, "i", 41), o(133, "div")(134, "span", 11), r(135, "Profit (Selling Price \u2212 Cost Price)"), n(), o(136, "small", 37), r(137, "Commission calculated on margin after deducting cost"), n()()()()()()()()(), o(138, "div", 13)(139, "div", 14)(140, "div", 25)(141, "div", 17), c(142, "i", 42), n(), o(143, "div")(144, "div", 2)(145, "span", 19), r(146, "\u2463"), n(), o(147, "h6", 4), r(148, "Approval"), n()(), o(149, "small", 21), r(150, "Auto-approve commission entries or require manual review?"), n()()(), o(151, "div", 27)(152, "div", 28)(153, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("auto_approve_commission")) == null ? null : i.setValue(!0)))
        }), o(154, "div", 30)(155, "div", 39), c(156, "i", 32), o(157, "div")(158, "span", 11), r(159, "Yes \u2014 auto-approve all entries"), n(), o(160, "small", 37), r(161, "Commission is approved instantly when calculated"), n()()()()()(), o(162, "div", 28)(163, "div", 29), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("auto_approve_commission")) == null ? null : i.setValue(!1)))
        }), o(164, "div", 30)(165, "div", 39), c(166, "i", 32), o(167, "div")(168, "span", 11), r(169, "No \u2014 require manual approval"), n(), o(170, "small", 37), r(171, "Admin/Manager must approve entries before they count"), n()()()()()()()()(), o(172, "div", 13)(173, "div", 14)(174, "div", 25)(175, "div", 17), c(176, "i", 43), n(), o(177, "div")(178, "div", 2)(179, "span", 19), r(180, "\u2464"), n(), o(181, "h6", 4), r(182, "Commission Categories"), n()(), o(183, "small", 21), r(184, "Which entity types earn commission?"), n()()(), o(185, "div", 44)(186, "div", 45), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("job_commission_enabled")) == null ? null : i.setValue(!((i = s.form.get("job_commission_enabled")) != null && i.value))))
        }), o(187, "div", 46), c(188, "dx-check-box", 47), o(189, "div")(190, "span", 11), r(191, "Jobs"), n(), o(192, "small", 37), r(193, "Earn commission on job payments"), n()()()(), o(194, "div", 45), u("click", function() {
            let i;
            f(e);
            let s = _();
            return v(s.isEditMode && ((i = s.form.get("sale_commission_enabled")) == null ? null : i.setValue(!((i = s.form.get("sale_commission_enabled")) != null && i.value))))
        }), o(195, "div", 46), c(196, "dx-check-box", 47), o(197, "div")(198, "span", 11), r(199, "Sales"), n(), o(200, "small", 37), r(201, "Earn commission on sale transactions"), n()()()()()()(), o(202, "div", 13)(203, "div", 14)(204, "div", 25)(205, "div", 17), c(206, "i", 48), n(), o(207, "div")(208, "div", 2)(209, "span", 19), r(210, "\u2465"), n(), o(211, "h6", 4), r(212, "Assign Job Commission"), n(), o(213, "span", 20), r(214, "Required"), n()(), o(215, "small", 21), r(216, "Who receives commission for completed jobs?"), n()()(), o(217, "div", 49)(218, "div", 30)(219, "div", 16)(220, "div", 31), c(221, "i", 50), n(), o(222, "div")(223, "div", 33), c(224, "i", 51), o(225, "span", 11), r(226, "Job Assignee only"), n()(), o(227, "small", 21), r(228, "Commission goes to the main job assignee"), n()()()()()()(), T(229, Di, 1, 3, "app-save-cancel-footer", 52), n()()
    }
    if (a & 2) {
        let e, t, i, s, m, ce, pe, ue, _e, fe, ve, he, ye, Ce, be, ge, xe, Se, we, Ee, Te, Ve, Me, Pe, ke, Be, Ie, Ae, Fe, De, je, p = _();
        l(), d("formGroup", p.form), l(19), x("text-success", (e = p.form.get("commission_enabled")) == null ? null : e.value)("text-secondary", !((t = p.form.get("commission_enabled")) != null && t.value)), l(), oe(" ", (i = p.form.get("commission_enabled")) != null && i.value ? "Enabled" : "Disabled", " "), l(18), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((s = p.form.get("commission_trigger")) == null ? null : s.value) === "payment"), l(4), x("text-secondary", ((m = p.form.get("commission_trigger")) == null ? null : m.value) === "payment")("text-secondary", ((ce = p.form.get("commission_trigger")) == null ? null : ce.value) !== "payment"), l(11), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((pe = p.form.get("commission_trigger")) == null ? null : pe.value) === "invoice"), l(4), x("text-secondary", ((ue = p.form.get("commission_trigger")) == null ? null : ue.value) === "invoice")("text-secondary", ((_e = p.form.get("commission_trigger")) == null ? null : _e.value) !== "invoice"), l(25), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((fe = p.form.get("refund_deduct_commission")) == null ? null : fe.value) === !0), l(3), x("text-secondary", ((ve = p.form.get("refund_deduct_commission")) == null ? null : ve.value) === !0)("text-secondary", ((he = p.form.get("refund_deduct_commission")) == null ? null : he.value) !== !0), l(7), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((ye = p.form.get("refund_deduct_commission")) == null ? null : ye.value) === !1), l(3), x("text-secondary", ((Ce = p.form.get("refund_deduct_commission")) == null ? null : Ce.value) === !1)("text-secondary", ((be = p.form.get("refund_deduct_commission")) == null ? null : be.value) !== !1), l(23), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((ge = p.form.get("commission_basis")) == null ? null : ge.value) === "revenue"), l(3), x("text-secondary", ((xe = p.form.get("commission_basis")) == null ? null : xe.value) === "revenue")("text-secondary", ((Se = p.form.get("commission_basis")) == null ? null : Se.value) !== "revenue"), l(7), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((we = p.form.get("commission_basis")) == null ? null : we.value) === "profit"), l(3), x("text-secondary", ((Ee = p.form.get("commission_basis")) == null ? null : Ee.value) === "profit")("text-secondary", ((Te = p.form.get("commission_basis")) == null ? null : Te.value) !== "profit"), l(21), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((Ve = p.form.get("auto_approve_commission")) == null ? null : Ve.value) === !0), l(3), x("text-secondary", ((Me = p.form.get("auto_approve_commission")) == null ? null : Me.value) === !0)("text-secondary", ((Pe = p.form.get("auto_approve_commission")) == null ? null : Pe.value) !== !0), l(7), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", ((ke = p.form.get("auto_approve_commission")) == null ? null : ke.value) === !1), l(3), x("text-secondary", ((Be = p.form.get("auto_approve_commission")) == null ? null : Be.value) === !1)("text-secondary", ((Ie = p.form.get("auto_approve_commission")) == null ? null : Ie.value) !== !1), l(20), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", (Ae = p.form.get("job_commission_enabled")) == null ? null : Ae.value), l(2), d("value", (Fe = p.form.get("job_commission_enabled")) == null ? null : Fe.value)("readOnly", !0), l(6), B("cursor", p.isEditMode ? "pointer" : "default"), x("border-primary", (De = p.form.get("sale_commission_enabled")) == null ? null : De.value), l(2), d("value", (je = p.form.get("sale_commission_enabled")) == null ? null : je.value)("readOnly", !0), l(33), V(p.isEditMode ? 229 : -1)
    }
}

function Oi(a, k) {
    a & 1 && (o(0, "div", 7), c(1, "dx-load-indicator", 54), n()), a & 2 && (l(), d("visible", !0))
}
var xi = (() => {
    class a {
        constructor() {
            this.commissionService = S(M), this.toastService = S(W), this.fb = S(Ye), this.isLoading = !0, this.isSaving = !1, this.isEditMode = !1, this.originalValues = null
        }
        ngOnInit() {
            this.initForm(), this.loadSettings()
        }
        initForm() {
            this.form = this.fb.group({
                commission_enabled: [!1],
                commission_trigger: ["payment"],
                commission_basis: ["revenue"],
                refund_deduct_commission: [!0],
                job_commission_enabled: [!0],
                sale_commission_enabled: [!0],
                job_assignment_mode: ["job_assignee"],
                auto_approve_commission: [!1],
                commission_lock_day: [5]
            })
        }
        loadSettings() {
            this.commissionService.getSettings().subscribe({
                next: e => {
                    e && Object.keys(e).length && this.form.patchValue({
                        commission_enabled: this.toBool(e.commission_enabled),
                        commission_trigger: e.commission_trigger || "payment",
                        commission_basis: e.commission_basis || "revenue",
                        refund_deduct_commission: this.toBool(e.refund_deduct_commission),
                        job_commission_enabled: this.toBool(e.job_commission_enabled),
                        sale_commission_enabled: this.toBool(e.sale_commission_enabled),
                        job_assignment_mode: e.job_assignment_mode || "job_assignee",
                        auto_approve_commission: this.toBool(e.auto_approve_commission),
                        commission_lock_day: +e.commission_lock_day || 5
                    }), this.form.disable({
                        emitEvent: !1
                    }), this.isLoading = !1
                },
                error: () => {
                    this.form.disable({
                        emitEvent: !1
                    }), this.isLoading = !1
                }
            })
        }
        onEdit() {
            this.originalValues = this.form.getRawValue(), this.form.enable({
                emitEvent: !1
            }), this.isEditMode = !0
        }
        onCancel() {
            this.originalValues && this.form.patchValue(this.originalValues, {
                emitEvent: !1
            }), this.form.disable({
                emitEvent: !1
            }), this.isEditMode = !1
        }
        onSave() {
            this.isSaving || (this.isSaving = !0, this.commissionService.updateSettings(this.form.getRawValue()).subscribe({
                next: () => {
                    this.toastService.success("Commission settings updated successfully."), this.isSaving = !1, this.form.disable({
                        emitEvent: !1
                    }), this.isEditMode = !1
                },
                error: () => {
                    this.toastService.error("Failed to update commission settings."), this.isSaving = !1
                }
            }))
        }
        toBool(e) {
            return typeof e == "boolean" ? e : e === "1" || e === "true" || e === !0
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-commission-settings"]
                ],
                standalone: !1,
                decls: 13,
                vars: 4,
                consts: [
                    [1, "p-4"],
                    [1, "d-flex", "justify-content-between", "align-items-start", "mb-4"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fa-thin", "fa-gear", "fs-4", "text-secondary"],
                    [1, "fw-bold", "mb-0"],
                    [1, "text-secondary", 2, "font-size", "14px"],
                    ["role", "alert", 1, "alert", "alert-info", "d-flex", "align-items-center", "mb-4"],
                    [1, "text-center", "py-5"],
                    [3, "editClick"],
                    [1, "fa-thin", "fa-info-circle", "fa-lg", "me-3"],
                    [1, "small"],
                    [1, "fw-semibold"],
                    [3, "formGroup"],
                    [1, "dx-card", "p-0", "mb-4"],
                    [1, "card-body", "p-4"],
                    [1, "d-flex", "align-items-start", "justify-content-between", "gap-3"],
                    [1, "d-flex", "align-items-start", "gap-3"],
                    [1, "rounded-circle", "d-flex", "align-items-center", "justify-content-center", 2, "width", "40px", "height", "40px", "min-width", "40px"],
                    [1, "fa-thin", "fa-power-off", "text-secondary"],
                    [1, "text-secondary", 2, "font-size", "12px"],
                    [1, "badge", "bg-secondary", 2, "font-size", "10px"],
                    [1, "text-secondary"],
                    [1, "d-flex", "align-items-center", "mb-0"],
                    ["formControlName", "commission_enabled", 1, "align-middle"],
                    [1, "ms-2", "fw-semibold"],
                    [1, "d-flex", "align-items-start", "gap-3", "mb-3"],
                    [1, "fa-thin", "fa-bolt", "text-secondary"],
                    [1, "row", "g-3"],
                    [1, "col-md-6"],
                    [1, "card", "h-100", 3, "click"],
                    [1, "card-body", "py-3", "px-4"],
                    [1, "mt-1"],
                    [1, "fa-solid", "fa-circle", 2, "font-size", "8px"],
                    [1, "d-flex", "align-items-center", "gap-2", "mb-1"],
                    [1, "fa-thin", "fa-credit-card", "text-secondary"],
                    [1, "text-success", "d-block"],
                    [1, "fa-thin", "fa-file-invoice", "text-secondary"],
                    [1, "text-secondary", "d-block"],
                    [1, "fa-thin", "fa-rotate-left", "text-secondary"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "fa-thin", "fa-calculator", "text-secondary"],
                    [1, "fa-solid", "fa-circle", "mt-1", 2, "font-size", "8px"],
                    [1, "fa-thin", "fa-check-double", "text-secondary"],
                    [1, "fa-thin", "fa-tags", "text-secondary"],
                    [1, "d-flex", "gap-3"],
                    [1, "card", "flex-fill", 3, "click"],
                    [1, "card-body", "py-3", "px-4", "d-flex", "align-items-center", "gap-3"],
                    [3, "value", "readOnly"],
                    [1, "fa-thin", "fa-users", "text-secondary"],
                    [1, "card", "mb-0", "border-primary"],
                    [1, "fa-solid", "fa-circle", "text-secondary", 2, "font-size", "8px"],
                    [1, "fa-thin", "fa-user", "text-secondary"],
                    [3, "isSaving", "useSubmitBehavior", "isVisibleHr"],
                    [3, "saveClick", "cancelClick", "isSaving", "useSubmitBehavior", "isVisibleHr"],
                    [3, "visible"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0)(1, "div", 1)(2, "div", 2), c(3, "i", 3), o(4, "div")(5, "h4", 4), r(6, "Setup Commission"), n(), o(7, "span", 5), r(8, "Configure how commissions are calculated and assigned across your organization"), n()()(), T(9, Ai, 1, 0, "app-edit-back-btn"), n(), T(10, Fi, 6, 0, "div", 6), T(11, ji, 230, 83, "div"), T(12, Oi, 2, 1, "div", 7), n()), t & 2 && (l(9), V(!i.isLoading && !i.isEditMode ? 9 : -1), l(), V(i.isLoading ? -1 : 10), l(), V(i.isLoading ? -1 : 11), l(), V(i.isLoading ? 12 : -1))
                },
                dependencies: [R, ai, se, oi, ni, Qe, Le, Ge, Je, He],
                encapsulation: 2
            })
        }
    }
    return a
})();

function Ni(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "p", 5)(1, "strong"), r(2, "Employee:"), n(), r(3), n(), c(4, "app-alert-panel", 6), o(5, "div", 7), c(6, "div", 8), o(7, "div", 9)(8, "strong"), r(9, "Percentage"), n()(), o(10, "div", 9)(11, "strong"), r(12, "Fixed Amount"), n()()(), o(13, "div", 10)(14, "div", 8)(15, "strong"), r(16, "Jobs:"), n()(), o(17, "div", 11)(18, "dx-number-box", 12), C("valueChange", function(i) {
            f(e);
            let s = _(2);
            return y(s.editForm.job_commission_pct, i) || (s.editForm.job_commission_pct = i), v(i)
        }), n()(), o(19, "div", 11)(20, "dx-number-box", 13), C("valueChange", function(i) {
            f(e);
            let s = _(2);
            return y(s.editForm.job_commission_fixed, i) || (s.editForm.job_commission_fixed = i), v(i)
        }), n()()(), o(21, "div", 10)(22, "div", 8)(23, "strong"), r(24, "Sales:"), n()(), o(25, "div", 11)(26, "dx-number-box", 12), C("valueChange", function(i) {
            f(e);
            let s = _(2);
            return y(s.editForm.sale_commission_pct, i) || (s.editForm.sale_commission_pct = i), v(i)
        }), n()(), o(27, "div", 11)(28, "dx-number-box", 13), C("valueChange", function(i) {
            f(e);
            let s = _(2);
            return y(s.editForm.sale_commission_fixed, i) || (s.editForm.sale_commission_fixed = i), v(i)
        }), n()()(), o(29, "dx-check-box", 14), C("valueChange", function(i) {
            f(e);
            let s = _(2);
            return y(s.editForm.is_active, i) || (s.editForm.is_active = i), v(i)
        }), n(), o(30, "div", 15)(31, "app-save-cancel-footer", 16), u("cancelClick", function() {
            f(e);
            let i = _(2);
            return v(i.closeEditModal())
        })("saveClick", function() {
            f(e);
            let i = _(2);
            return v(i.saveProfile())
        }), n()()
    }
    if (a & 2) {
        let e = _(2);
        l(3), oe(" ", e.editEmployee.display_name || e.editEmployee.name), l(), d("isVisibleCancelButton", !1), l(14), h("value", e.editForm.job_commission_pct), d("min", 0)("max", 100)("disabled", e.editForm.job_commission_fixed > 0 && e.editForm.job_commission_pct === 0), l(2), h("value", e.editForm.job_commission_fixed), d("min", 0)("disabled", e.editForm.job_commission_pct > 0 && e.editForm.job_commission_fixed === 0), l(6), h("value", e.editForm.sale_commission_pct), d("min", 0)("max", 100)("disabled", e.editForm.sale_commission_fixed > 0 && e.editForm.sale_commission_pct === 0), l(2), h("value", e.editForm.sale_commission_fixed), d("min", 0)("disabled", e.editForm.sale_commission_pct > 0 && e.editForm.sale_commission_fixed === 0), l(), h("value", e.editForm.is_active), l(2), d("isSaving", e.isSaving)("isVisibleHr", !1)("useSubmitBehavior", !1)
    }
}

function Wi(a, k) {
    if (a & 1 && (o(0, "div"), T(1, Ni, 32, 20), n()), a & 2) {
        let e = _();
        l(), V(e.editEmployee ? 1 : -1)
    }
}
var Si = (() => {
    class a {
        constructor(e) {
            this.service = e, this.toastService = S(W), this.tenantService = S(ii), this.currencySymbol = this.tenantService.config() ? .currency_code ? ? "\u20B9", this.entity = I.EMPLOYEE_COMMISSION, this.PERMISSION_LIST = w, this.columns = [{
                dataField: "display_name",
                caption: $e("employee"),
                calculateCellValue: t => t ? .display_name || t ? .name,
                allowSorting: !0
            }, {
                name: "jobs_display",
                caption: "Jobs (% / Fixed)",
                calculateCellValue: t => this.getJobDisplay(t),
                allowSorting: !1
            }, {
                name: "sales_display",
                caption: "Sales (% / Fixed)",
                calculateCellValue: t => this.getSaleDisplay(t),
                allowSorting: !1
            }, {
                dataField: "",
                caption: "",
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                width: 100
            }], this.editModalVisible = !1, this.editEmployee = null, this.editForm = {
                user_id: 0,
                job_commission_pct: 0,
                job_commission_fixed: 0,
                sale_commission_pct: 0,
                sale_commission_fixed: 0,
                is_active: !0
            }, this.isSaving = !1
        }
        openEditModal(e) {
            this.editEmployee = e;
            let t = e.commission_profile;
            this.editForm = {
                user_id: e.id,
                job_commission_pct: t ? .job_commission_pct || 0,
                job_commission_fixed: t ? .job_commission_fixed || 0,
                sale_commission_pct: t ? .sale_commission_pct || 0,
                sale_commission_fixed: t ? .sale_commission_fixed || 0,
                is_active: t ? .is_active ? ? !0
            }, this.editModalVisible = !0
        }
        closeEditModal() {
            this.editModalVisible = !1, this.editEmployee = null
        }
        saveProfile() {
            this.isSaving || (this.isSaving = !0, this.service.upsertProfile(this.editForm).subscribe({
                next: () => {
                    this.toastService.success("Commission profile updated."), this.isSaving = !1, this.closeEditModal(), this.dataGrid ? .getData()
                },
                error: () => {
                    this.toastService.error("Failed to update profile."), this.isSaving = !1
                }
            }))
        }
        getJobDisplay(e) {
            let t = e ? .commission_profile;
            if (!t || !t.is_active) return "\xD7";
            let i = `${this.currencySymbol}${(+t.job_commission_fixed).toFixed(2)}`;
            return t.job_commission_pct > 0 && t.job_commission_fixed > 0 ? `${t.job_commission_pct}% + ${i}` : t.job_commission_pct > 0 ? `${t.job_commission_pct}%` : t.job_commission_fixed > 0 ? i : "\xD7"
        }
        getSaleDisplay(e) {
            let t = e ? .commission_profile;
            if (!t || !t.is_active) return "\xD7";
            let i = `${this.currencySymbol}${(+t.sale_commission_fixed).toFixed(2)}`;
            return t.sale_commission_pct > 0 && t.sale_commission_fixed > 0 ? `${t.sale_commission_pct}% + ${i}` : t.sale_commission_pct > 0 ? `${t.sale_commission_pct}%` : t.sale_commission_fixed > 0 ? i : "\xD7"
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)(A(M))
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-employee-profiles"]
                ],
                viewQuery: function(t, i) {
                    if (t & 1 && F(g, 5), t & 2) {
                        let s;
                        D(s = j()) && (i.dataGrid = s.first)
                    }
                },
                standalone: !1,
                decls: 5,
                vars: 17,
                consts: [
                    [1, "container-fluid", "py-3"],
                    ["message", "Each employee has a commission profile that defines their earning rules: a percentage or fixed amount for Jobs and Sales (one per type, not both). Edit a profile to update the rates, or toggle Active to stop accruing commission for that employee on new entries.", 3, "isVisibleCancelButton"],
                    [3, "dataGridEditClick", "columns", "entity", "service", "isVisibleEditAction", "isVisibleDeleteAction", "isVisibleAddAction", "writeAccessPermissionName", "searchPanelPlaceholderText"],
                    ["title", "Employee Commission", 3, "visibleChange", "onHiding", "visible", "showTitle", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "mb-3"],
                    ["message", "Enter either Percentage or Fixed Amount, not both.", 3, "isVisibleCancelButton"],
                    [1, "row", "mb-3"],
                    [1, "col-3"],
                    [1, "col-4", "text-center"],
                    [1, "row", "mb-3", "align-items-center"],
                    [1, "col-4"],
                    ["format", "#0'%'", "valueChangeEvent", "keyup", 3, "valueChange", "value", "min", "max", "disabled"],
                    ["valueChangeEvent", "keyup", 3, "valueChange", "value", "min", "disabled"],
                    ["text", "Active", 3, "valueChange", "value"],
                    [1, "d-flex", "justify-content-end", "mt-3"],
                    [3, "cancelClick", "saveClick", "isSaving", "isVisibleHr", "useSubmitBehavior"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0), c(1, "app-alert-panel", 1), o(2, "app-data-grid", 2), u("dataGridEditClick", function(m) {
                        return i.openEditModal(m)
                    }), n(), o(3, "dx-popup", 3), C("visibleChange", function(m) {
                        return y(i.editModalVisible, m) || (i.editModalVisible = m), m
                    }), u("onHiding", function() {
                        return i.closeEditModal()
                    }), J(4, Wi, 2, 1, "div", 4), n()()), t & 2 && (l(), d("isVisibleCancelButton", !1), l(), d("columns", i.columns)("entity", i.entity)("service", i.service)("isVisibleEditAction", !0)("isVisibleDeleteAction", !1)("isVisibleAddAction", !1)("writeAccessPermissionName", i.PERMISSION_LIST.COMMISSION_MANAGE_PROFILES)("searchPanelPlaceholderText", "search_panel_employee_placeholder"), l(), h("visible", i.editModalVisible), d("showTitle", !0)("dragEnabled", !1)("hideOnOutsideClick", !1)("showCloseButton", !0)("width", 600)("height", "auto"), l(), d("dxTemplateOf", "content"))
                },
                dependencies: [R, g, L, q, se, U, K],
                encapsulation: 2
            })
        }
    }
    return a
})();

function Ri(a, k) {
    if (a & 1) {
        let e = P();
        o(0, "div")(1, "div", 14)(2, "label", 15), r(3, "Payment Reference"), n(), o(4, "dx-text-box", 16), C("valueChange", function(i) {
            f(e);
            let s = _();
            return y(s.paymentReference, i) || (s.paymentReference = i), v(i)
        }), n()(), o(5, "div", 14)(6, "label", 15), r(7, "Notes"), n(), o(8, "dx-text-area", 17), C("valueChange", function(i) {
            f(e);
            let s = _();
            return y(s.paymentNotes, i) || (s.paymentNotes = i), v(i)
        }), n()(), o(9, "div", 18)(10, "app-save-cancel-footer", 19), u("cancelClick", function() {
            f(e);
            let i = _();
            return v(i.closeMarkPaidModal())
        })("saveClick", function() {
            f(e);
            let i = _();
            return v(i.confirmMarkPaid())
        }), n()()()
    }
    if (a & 2) {
        let e = _();
        l(4), h("value", e.paymentReference), l(4), h("value", e.paymentNotes), d("height", 80), l(2), d("isVisibleHr", !1)("useSubmitBehavior", !1)
    }
}
var wi = (() => {
    class a {
        constructor(e) {
            this.service = e, this.commissionService = S(M), this.toastService = S(W), this.entity = I.COMMISSION_PERIOD, this.filterYear = new Date().getFullYear(), this.filterMonth = null, this.filterStatus = "", this.markPaidVisible = !1, this.markPaidPeriodId = null, this.paymentReference = "", this.paymentNotes = "", this.months = [{
                value: 1,
                label: "January"
            }, {
                value: 2,
                label: "February"
            }, {
                value: 3,
                label: "March"
            }, {
                value: 4,
                label: "April"
            }, {
                value: 5,
                label: "May"
            }, {
                value: 6,
                label: "June"
            }, {
                value: 7,
                label: "July"
            }, {
                value: 8,
                label: "August"
            }, {
                value: 9,
                label: "September"
            }, {
                value: 10,
                label: "October"
            }, {
                value: 11,
                label: "November"
            }, {
                value: 12,
                label: "December"
            }], this.monthOptions = this.months, this.statusOptions = [{
                value: "",
                label: "All Status"
            }, {
                value: "open",
                label: "Open"
            }, {
                value: "locked",
                label: "Locked"
            }, {
                value: "paid",
                label: "Paid"
            }], this.columns = [{
                caption: "Employee",
                cellTemplate: "commissionEmployeeNameTemplate",
                allowSorting: !1
            }, {
                caption: "Period",
                cellTemplate: "commissionPeriodLabelTemplate",
                allowSorting: !1
            }, {
                dataField: "status",
                caption: "Status",
                alignment: "center",
                cellTemplate: "commissionStatusTemplate"
            }, {
                dataField: "paid_at",
                caption: "Paid At",
                dataType: "date",
                format: "dd MMM yy"
            }, {
                dataField: "payment_reference",
                caption: "Reference"
            }, {
                caption: "Actions",
                allowSorting: !1,
                cellTemplate: "commissionPeriodActionsTemplate"
            }]
        }
        onFilter() {
            this.service.filters = {
                year: this.filterYear,
                month: this.filterMonth || void 0,
                status: this.filterStatus || void 0
            }, this.dataGrid ? .getData()
        }
        onCommissionAction(e) {
            let t = e.row;
            e.action === "lock" ? this.lockPeriod(t) : e.action === "unlock" ? this.unlockPeriod(t) : e.action === "markPaid" && this.openMarkPaidModal(t)
        }
        lockPeriod(e) {
            this.commissionService.lockPeriod(e.id).subscribe({
                next: () => {
                    this.toastService.success("Period locked."), this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to lock period.")
            })
        }
        unlockPeriod(e) {
            this.commissionService.unlockPeriod(e.id).subscribe({
                next: () => {
                    this.toastService.success("Period unlocked."), this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to unlock period.")
            })
        }
        openMarkPaidModal(e) {
            this.markPaidPeriodId = e.id, this.paymentReference = "", this.paymentNotes = "", this.markPaidVisible = !0
        }
        closeMarkPaidModal() {
            this.markPaidVisible = !1
        }
        confirmMarkPaid() {
            this.markPaidPeriodId && this.commissionService.markPeriodPaid(this.markPaidPeriodId, {
                payment_reference: this.paymentReference,
                payment_notes: this.paymentNotes
            }).subscribe({
                next: () => {
                    this.toastService.success("Period marked as paid."), this.markPaidVisible = !1, this.dataGrid ? .getData()
                },
                error: () => this.toastService.error("Failed to mark paid.")
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || a)(A(pi))
            }
        }
        static {
            this.\u0275cmp = E({
                type: a,
                selectors: [
                    ["app-commission-periods"]
                ],
                viewQuery: function(t, i) {
                    if (t & 1 && F(g, 5), t & 2) {
                        let s;
                        D(s = j()) && (i.dataGrid = s.first)
                    }
                },
                standalone: !1,
                decls: 17,
                vars: 27,
                consts: [
                    [1, "container-fluid", "py-3"],
                    ["message", "Periods move through Open \u2192 Locked \u2192 Paid. Locking freezes the month's commission amounts so they can't be edited \u2014 any later change to a Job/Sale creates an adjustment in the next open period instead of modifying past entries. Only locked periods can be marked as Paid.", 3, "isVisibleCancelButton"],
                    [1, "dx-card"],
                    [1, "p-3", "border-bottom"],
                    [1, "mb-0"],
                    [1, "p-3"],
                    [1, "row", "g-2", "mb-3"],
                    [1, "col-auto"],
                    [3, "valueChange", "onValueChanged", "value", "width", "showSpinButtons"],
                    ["valueExpr", "value", "displayExpr", "label", "placeholder", "All Months", 3, "valueChange", "onValueChanged", "dataSource", "value", "width", "showClearButton"],
                    ["valueExpr", "value", "displayExpr", "label", 3, "valueChange", "onValueChanged", "dataSource", "value", "width"],
                    [3, "commissionAction", "service", "entity", "columns", "isVisibleAddAction", "isVisibleEditAction", "isVisibleDeleteAction", "isVisibleClearFilterButton", "isVisibleTitle"],
                    ["title", "Mark Period as Paid", 3, "visibleChange", "onHiding", "visible", "showTitle", "dragEnabled", "hideOnOutsideClick", "showCloseButton", "width", "height"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [1, "mb-3"],
                    [1, "form-label"],
                    ["placeholder", "Cheque #, Transfer ID...", 3, "valueChange", "value"],
                    [3, "valueChange", "value", "height"],
                    [1, "d-flex", "justify-content-end"],
                    ["cancelLabel", "cancel", "saveText", "mark_paid", "type", "success", 3, "cancelClick", "saveClick", "isVisibleHr", "useSubmitBehavior"]
                ],
                template: function(t, i) {
                    t & 1 && (o(0, "div", 0), c(1, "app-alert-panel", 1), o(2, "div", 2)(3, "div", 3)(4, "h5", 4), r(5, "Monthly Commission Periods"), n()(), o(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "dx-number-box", 8), C("valueChange", function(m) {
                        return y(i.filterYear, m) || (i.filterYear = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()(), o(10, "div", 7)(11, "dx-select-box", 9), C("valueChange", function(m) {
                        return y(i.filterMonth, m) || (i.filterMonth = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()(), o(12, "div", 7)(13, "dx-select-box", 10), C("valueChange", function(m) {
                        return y(i.filterStatus, m) || (i.filterStatus = m), m
                    }), u("onValueChanged", function() {
                        return i.onFilter()
                    }), n()()(), o(14, "app-data-grid", 11), u("commissionAction", function(m) {
                        return i.onCommissionAction(m)
                    }), n()()(), o(15, "dx-popup", 12), C("visibleChange", function(m) {
                        return y(i.markPaidVisible, m) || (i.markPaidVisible = m), m
                    }), u("onHiding", function() {
                        return i.closeMarkPaidModal()
                    }), J(16, Ri, 11, 5, "div", 13), n()()), t & 2 && (l(), d("isVisibleCancelButton", !1), l(8), h("value", i.filterYear), d("width", 100)("showSpinButtons", !1), l(2), d("dataSource", i.monthOptions), h("value", i.filterMonth), d("width", 160)("showClearButton", !0), l(2), d("dataSource", i.statusOptions), h("value", i.filterStatus), d("width", 160), l(), d("service", i.service)("entity", i.entity)("columns", i.columns)("isVisibleAddAction", !1)("isVisibleEditAction", !1)("isVisibleDeleteAction", !1)("isVisibleClearFilterButton", !1)("isVisibleTitle", !1), l(), h("visible", i.markPaidVisible), d("showTitle", !0)("dragEnabled", !1)("hideOnOutsideClick", !1)("showCloseButton", !0)("width", 420)("height", "auto"), l(), d("dxTemplateOf", "content"))
                },
                dependencies: [R, g, L, q, U, K, z, ne, ei],
                encapsulation: 2
            })
        }
    }
    return a
})();
var Li = [{
        path: "",
        component: mi,
        children: [{
            path: "",
            redirectTo: "my-commission",
            pathMatch: "full"
        }, {
            path: "dashboard",
            component: hi,
            canActivate: [H],
            data: {
                tab_index: 0,
                permissions: {
                    only: [w.COMMISSION_VIEW_ALL]
                }
            }
        }, {
            path: "my-commission",
            component: gi,
            canActivate: [H],
            data: {
                tab_index: 1,
                permissions: {
                    only: [w.COMMISSION_VIEW_OWN]
                }
            }
        }, {
            path: "breakdown",
            component: bi,
            canActivate: [H],
            data: {
                tab_index: 2,
                permissions: {
                    only: [w.COMMISSION_VIEW_ALL]
                }
            }
        }, {
            path: "periods",
            component: wi,
            canActivate: [H],
            data: {
                tab_index: 3,
                permissions: {
                    only: [w.COMMISSION_MANAGE_PERIODS]
                }
            }
        }, {
            path: "settings",
            component: xi,
            canActivate: [H],
            data: {
                tab_index: 5,
                permissions: {
                    only: [w.COMMISSION_MANAGE_SETTINGS]
                }
            }
        }, {
            path: "profiles",
            component: Si,
            canActivate: [H],
            data: {
                tab_index: 4,
                permissions: {
                    only: [w.COMMISSION_MANAGE_PROFILES]
                }
            }
        }]
    }],
    Ei = (() => {
        class a {
            static {
                this.\u0275fac = function(t) {
                    return new(t || a)
                }
            }
            static {
                this.\u0275mod = te({
                    type: a
                })
            }
            static {
                this.\u0275inj = ie({
                    imports: [le.forChild(Li), le]
                })
            }
        }
        return a
    })();
var Mo = (() => {
    class a {
        static {
            this.\u0275fac = function(t) {
                return new(t || a)
            }
        }
        static {
            this.\u0275mod = te({
                type: a
            })
        }
        static {
            this.\u0275inj = ie({
                imports: [Re, Ei, li]
            })
        }
    }
    return a
})();
export {
    Mo as CommissionModule
};