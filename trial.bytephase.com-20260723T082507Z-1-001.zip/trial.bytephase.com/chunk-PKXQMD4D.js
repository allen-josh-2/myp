import {
    a as Ye
} from "./chunk-WNEBY3WS.js";
import {
    a as Ge,
    d as jt,
    f as Dt,
    g as At
} from "./chunk-WDS5LHZR.js";
import "./chunk-36T2HUF3.js";
import "./chunk-OG4EABPU.js";
import "./chunk-HUDETQT5.js";
import "./chunk-PGAHHPJ5.js";
import "./chunk-MBAKXBI4.js";
import "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import "./chunk-FAP35UT3.js";
import "./chunk-2KS5UOZO.js";
import "./chunk-KJCCJCIN.js";
import {
    Ab as E,
    Ae as Qe,
    Db as B,
    Fa as gt,
    Fb as Z,
    Gb as y,
    Ia as ut,
    Jb as A,
    Jd as Fe,
    Kd as Mt,
    Lb as W,
    Mb as L,
    Md as Ot,
    Nd as ye,
    Oe as St,
    Pb as xt,
    Qb as N,
    Qe as z,
    Rb as R,
    Sc as ae,
    Sf as wt,
    T as J,
    Tb as $,
    Ub as Pt,
    Vb as V,
    Xe as yt,
    ba as dt,
    bb as _t,
    ca as fe,
    cc as Me,
    cd as Le,
    db as Ct,
    df as ve,
    gf as be,
    ha as mt,
    hb as ft,
    hh as kt,
    ia as pt,
    jb as ht,
    jc as q,
    ka as oe,
    mb as vt,
    mg as Et,
    nb as bt,
    ng as It,
    ph as Te,
    uc as Oe,
    ug as He,
    wf as Tt,
    xc as Se,
    yb as he
} from "./chunk-DCKGQUHB.js";
import {
    $a as g,
    $b as at,
    Ab as ge,
    Ak as S,
    Ba as F,
    Da as it,
    Ec as H,
    Fa as n,
    Fb as Be,
    Ib as c,
    Jb as u,
    Ka as h,
    Kb as _,
    Lb as ue,
    Na as P,
    Nc as ze,
    Oa as qe,
    Pb as Ie,
    Qb as ke,
    Qc as Je,
    Rb as je,
    Sa as ot,
    Tc as ct,
    Wb as Re,
    Yh as U,
    _a as p,
    _b as De,
    ac as rt,
    ba as Ve,
    bb as le,
    bi as Ce,
    cb as de,
    ci as lt,
    db as me,
    ea as f,
    eb as s,
    fb as r,
    gb as a,
    gc as M,
    ha as v,
    hb as m,
    hc as _e,
    hi as k,
    ia as b,
    ic as I,
    ii as D,
    pd as O,
    qb as j,
    qd as st,
    sb as T,
    td as Ue,
    ub as l,
    vd as Ze,
    xk as x,
    yb as Pe,
    zb as pe
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as re,
    b as Xe
} from "./chunk-FBFWB55K.js";

function nn(t, d) {
    t & 1 && m(0, "app-currency-symbol")
}

function on(t, d) {
    if (t & 1 && (r(0, "div", 18)(1, "span", 20), c(2), a(), r(3, "span", 21), c(4, ":"), a(), p(5, nn, 1, 0, "app-currency-symbol"), c(6), a()), t & 2) {
        let e = l(3);
        n(2), u(e.formatMessage("payment_payable_amount")), n(3), g(e.amcContract != null && e.amcContract.total_amount ? 5 : -1), n(), _(" ", e.amcContract.total_amount, " ")
    }
}

function an(t, d) {
    if (t & 1 && (r(0, "div", 19)(1, "span", 20), c(2), a(), r(3, "span", 21), c(4, ":"), a(), m(5, "app-currency-symbol"), c(6), a()), t & 2) {
        let e = l(3);
        n(2), _("", e.formatMessage("payment_received"), " "), n(4), _(" ", e.amcContract.payment_received, " ")
    }
}

function rn(t, d) {
    if (t & 1 && (r(0, "div", 19)(1, "span", 20), c(2), a(), r(3, "span", 21), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(3);
        n(2), u(e.formatMessage("payment_frequency")), n(3), _("", e.amcContract.payment_frequency, " ")
    }
}

function cn(t, d) {
    if (t & 1 && (r(0, "div", 18)(1, "span", 22), c(2), a(), r(3, "span", 21), c(4, ": "), m(5, "app-status-tag", 23), a()()), t & 2) {
        let e = l(3);
        n(2), _("", e.formatMessage("payment_status"), ":"), n(3), s("status", e.amcContract.payment_status)
    }
}

function sn(t, d) {
    if (t & 1 && (r(0, "div", 13)(1, "div", 3)(2, "h5", 17), c(3), a(), r(4, "div", 2), p(5, on, 7, 3, "div", 18), p(6, an, 7, 2, "div", 19), p(7, rn, 6, 2, "div", 19), p(8, cn, 6, 2, "div", 18), a()()()), t & 2) {
        let e = l(2);
        n(3), _(" ", e.formatMessage("payment_information"), " "), n(2), g(e.amcContract.total_amount ? 5 : -1), n(), g(e.amcContract.payment_received ? 6 : -1), n(), g(e.amcContract.payment_frequency ? 7 : -1), n(), g(e.amcContract.payment_status ? 8 : -1)
    }
}

function ln(t, d) {
    if (t & 1 && m(0, "app-invoice-term-and-conditions", 14), t & 2) {
        let e = l(2);
        s("termAndCondition", e.amcContract.term_and_condition)
    }
}

function dn(t, d) {
    if (t & 1 && (r(0, "div", 8)(1, "div", 2)(2, "div", 3)(3, "div", 2)(4, "div", 3), m(5, "app-invoice-header", 9)(6, "app-invoice-title", 10)(7, "app-invoice-customer-detail", 11)(8, "app-invoice-amc-contract-details", 12), p(9, sn, 9, 5, "div", 13), p(10, ln, 1, 1, "app-invoice-term-and-conditions", 14), m(11, "hr", 15)(12, "app-invoice-signature", 16), a()()()()()), t & 2) {
        let e = l();
        s("ngClass", e.isMobileDevice ? "p-0" : ""), n(5), s("account", e.account)("qrCode", (e.amcContract == null ? null : e.amcContract.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.amcContract == null ? null : e.amcContract.qr_code)), n(), s("dateTime", e.amcContract == null ? null : e.amcContract.created_at)("title", e.formatMessage("amc_contract_no") + " : " + (e.amcContract == null ? null : e.amcContract.contract_number)), n(), s("user", e.amcContract.user), n(), s("amcContract", e.amcContract), n(), g(e.amcContract.total_amount ? 9 : -1), n(), g(e.amcContract.term_and_condition ? 10 : -1), n(2), s("entityId", e.amcContract == null ? null : e.amcContract.id)("entityType", e.entityType)
    }
}
var $e = (() => {
    class t {
        constructor(e, i) {
            this.loaderService = e, this.service = i, this.formatMessage = x, this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.ENTITIES = k, this.entityType = this.ENTITIES.AMC_CONTRACT.name, this.dateTime = new Date
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getAmcContract(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.printSettings = this.extractPrintSettings(i.tenant ? .general_settings), this.amcContract = i.amc_contract
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        extractPrintSettings(e) {
            if (!e) return E.getEmptyObject();
            let i = e.filter(C => C.setting_type === D.PRINT_SETTINGS),
                o = {};
            return i.forEach(C => {
                o[C.key] = C.value
            }), Object.keys(o).length > 0 ? o : E.getEmptyObject()
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(S), h(y))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-amc-contract"]
                ],
                decls: 10,
                vars: 10,
                consts: [
                    [1, "card", "p-2"],
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "title-text", "float-start", "m-1"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "ms-1", 3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [3, "amcContract"],
                    [1, "row", "background-row"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "ps-4"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "fw-bolder"],
                    [3, "status"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "span", 4), c(5), a(), r(6, "div", 5), m(7, "app-print-button", 6)(8, "app-share-btn", 7), a()()()(), p(9, dn, 13, 11, "div", 8), a()), i & 2 && (n(), s("ngClass", o.isMobileDevice ? "p-0" : ""), n(4), _(" ", o.amcContract == null ? null : o.amcContract.contract_number, " "), n(2), s("entityId", o.amcContract == null ? null : o.amcContract.id)("entityName", o.ENTITIES.AMC_CONTRACT.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.amcContract != null && o.amcContract.id)), n(), s("entityId", o.amcContract == null ? null : o.amcContract.id)("entityType", o.ENTITIES.AMC_CONTRACT.name)("isSignedApi", !0), n(), g(o.amcContract ? 9 : -1))
                },
                dependencies: [H, Te, A, L, z, N, R, Fe, V, He, q, ae],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function mn(t, d) {
    if (t & 1 && (r(0, "div", 19)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("delivery_provider_label")), n(3), _("", e.delivery.delivery_provider.name, " ")
    }
}

function pn(t, d) {
    if (t & 1 && (r(0, "div", 16)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("common_tracking_id")), n(3), _("", e.delivery.tracking_id, " ")
    }
}

function gn(t, d) {
    if (t & 1 && (r(0, "div", 20)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), m(5, "span", 24), M(6, "safe"), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("comment")), n(3), s("innerHTML", I(6, 2, e.delivery.comment, "html"), F)
    }
}

function un(t, d) {
    if (t & 1 && (r(0, "div", 9)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11)(5, "app-invoice-customer-detail", 12)(6, "app-invoice-job-details", 13), r(7, "div", 14)(8, "div", 3)(9, "h5", 15), c(10), a(), r(11, "div", 2)(12, "div", 16)(13, "span", 17), c(14), a(), r(15, "span", 18), c(16, ":"), a(), c(17), a(), p(18, mn, 6, 2, "div", 19), p(19, pn, 6, 2, "div", 16), r(20, "div", 19)(21, "span", 17), c(22), a(), r(23, "span", 18), c(24, ":"), a(), c(25), M(26, "dateFormat"), a(), r(27, "div", 16)(28, "span", 17), c(29), a(), r(30, "span", 18), c(31, ":"), a(), c(32), a(), p(33, gn, 7, 5, "div", 20), a()()(), m(34, "app-invoice-term-and-conditions", 21)(35, "hr", 22)(36, "app-invoice-signature", 23), a()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.delivery == null ? null : e.delivery.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.delivery == null ? null : e.delivery.qr_code)), n(), s("dateTime", e.delivery == null ? null : e.delivery.created_at)("title", (e.printSettings != null && e.printSettings.delivery_challan_title ? e.printSettings.delivery_challan_title + ": " : e.formatMessage("delivery_challan")) + e.delivery.id), n(), s("userId", e.job.user_id), n(), s("job", e.job), n(4), u(e.formatMessage("delivery_information")), n(4), u(e.formatMessage("delivery_mode_label")), n(3), _("", e.delivery.type.name, " "), n(), g(e.delivery.delivery_provider ? 18 : -1), n(), g(e.delivery.tracking_id ? 19 : -1), n(3), u(e.formatMessage("delivered_on")), n(3), _("", I(26, 19, e.delivery.created_at, "datetime"), " "), n(4), u(e.formatMessage("common_delivered_by")), n(3), _("", e.delivery.delivered_by_user == null ? null : e.delivery.delivered_by_user.name, " "), n(), g(e.delivery.comment ? 33 : -1), n(), s("termAndCondition", e.delivery.term_and_condition), n(2), s("entityId", e.delivery == null ? null : e.delivery.id)("entityType", e.entityType)
    }
}
var Nt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.generalSettingDataService = f(B), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.JOB_DELIVERY.name, this.dateTime = new Date, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getJobDelivery(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.job = i.job, this.delivery = i.job_delivery
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-job-delivery"]
                ],
                standalone: !1,
                decls: 12,
                vars: 11,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mb-3", "mt-2"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "ms-1", 3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "ps-4"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "d-inline-block", 3, "innerHTML"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), m(5, "app-job-status-tag", 4), r(6, "span", 5), c(7), a(), r(8, "div", 6), m(9, "app-print-button", 7)(10, "app-share-btn", 8), a()()()(), p(11, un, 37, 22, "div", 9), a()()), i & 2 && (n(5), s("iconType", o.statusIconTypeList.TITLE)("status", o.job == null ? null : o.job.status), n(2), _(" ", o.job == null ? null : o.job.job_number, " "), n(2), s("entityId", o.delivery == null ? null : o.delivery.id)("entityName", o.ENTITIES.JOB_DELIVERY.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.delivery != null && o.delivery.id)), n(), s("entityId", o.delivery == null ? null : o.delivery.id)("entityType", o.ENTITIES.JOB_DELIVERY.name)("isSignedApi", !0), n(), g(o.job ? 11 : -1))
                },
                dependencies: [Z, A, L, z, N, R, $, V, q, W, he],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function _n(t, d) {
    if (t & 1 && (r(0, "div", 20)(1, "label", 24), c(2), a(), m(3, "div", 25), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("issue_observed")), n(), s("innerHTML", e.diagnosis == null ? null : e.diagnosis.issue_observed, F)
    }
}

function Cn(t, d) {
    if (t & 1 && (r(0, "div", 20)(1, "label", 24), c(2), a(), m(3, "div", 25), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("diagnosis_notes")), n(), s("innerHTML", e.diagnosis == null ? null : e.diagnosis.diagnosis_notes, F)
    }
}

function fn(t, d) {
    if (t & 1 && (r(0, "div", 9)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11)(5, "app-invoice-customer-detail", 12)(6, "app-invoice-job-details", 13), r(7, "div", 14)(8, "div", 15)(9, "div", 16)(10, "div", 17)(11, "h6", 18), c(12), a()(), r(13, "div", 19), p(14, _n, 4, 2, "div", 20), p(15, Cn, 4, 2, "div", 20), a()()()(), m(16, "app-invoice-term-and-conditions", 21)(17, "hr", 22)(18, "app-invoice-signature", 23), a()()()), t & 2) {
        let e = l();
        s("ngClass", e.isMobileDevice ? "p-0" : ""), n(3), s("account", e.account)("qrCode", (e.diagnosis == null ? null : e.diagnosis.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.diagnosis == null ? null : e.diagnosis.qr_code)), n(), s("dateTime", e.diagnosis == null ? null : e.diagnosis.created_at)("title", e.formatMessage("job_diagnosis") + " : " + (e.job == null ? null : e.job.job_number)), n(), s("user", e.user), n(), s("job", e.job), n(6), u(e.formatMessage("diagnosis_details")), n(2), g(e.diagnosis != null && e.diagnosis.issue_observed ? 14 : -1), n(), g(e.diagnosis != null && e.diagnosis.diagnosis_notes ? 15 : -1), n(), s("termAndCondition", e.diagnosis == null ? null : e.diagnosis.term_and_condition), n(2), s("entityId", e.job == null ? null : e.job.id)("entityType", e.entityType)
    }
}
var Vt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.generalSettingDataService = f(B), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.JOB_DIAGNOSIS.name, this.dateTime = new Date, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getJobDiagnosis(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.job = i.job, this.user = this.job.user, this.job.diagnosis && (this.diagnosis = new Dt(this.job.diagnosis))
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-job-diagnosis"]
                ],
                standalone: !1,
                decls: 12,
                vars: 13,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mb-3", "mt-2", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "ms-1", 3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton", "isVisibleThermalPrint"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [3, "job"],
                    [1, "row", "mt-3"],
                    [1, "col-12"],
                    [1, "card"],
                    [1, "card-header"],
                    [1, "mb-0"],
                    [1, "card-body"],
                    [1, "mb-3"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "form-label", "fw-bold"],
                    [1, "text-muted", 3, "innerHTML"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), m(5, "app-job-status-tag", 4), r(6, "span", 5), c(7), a(), r(8, "div", 6), m(9, "app-print-button", 7)(10, "app-share-btn", 8), a()()()(), p(11, fn, 19, 13, "div", 9), a()()), i & 2 && (n(2), s("ngClass", o.isMobileDevice ? "p-0" : ""), n(3), s("iconType", o.statusIconTypeList.TITLE)("status", o.job == null ? null : o.job.status), n(2), _(" ", o.job == null ? null : o.job.job_number, " "), n(2), s("entityId", o.job == null ? null : o.job.id)("entityName", o.ENTITIES.JOB_DIAGNOSIS.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.diagnosis != null && o.diagnosis.id))("isVisibleThermalPrint", !1), n(), s("entityId", o.job == null ? null : o.job.id)("entityType", o.ENTITIES.JOB_DIAGNOSIS.name)("isSignedApi", !0), n(), g(o.job && o.diagnosis ? 11 : -1))
                },
                dependencies: [H, Z, A, L, z, N, R, $, V, q],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function vn(t, d) {
    if (t & 1 && m(0, "app-print-button", 8)(1, "app-share-btn", 9), t & 2) {
        let e = l();
        s("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityName", e.ENTITIES.JOB_INVOICE.name)("isSignedApi", !0)("isVisiblePrintButton", !!(e.jobInvoice != null && e.jobInvoice.id)), n(), s("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityType", e.ENTITIES.JOB_INVOICE.name)("isSignedApi", !0)
    }
}

function bn(t, d) {
    if (t & 1 && m(0, "app-print-table", 16), t & 2) {
        let e = l(2);
        s("columns", e.servicesColumns)("rows", e.repairServices)
    }
}

function xn(t, d) {
    if (t & 1 && m(0, "app-print-table", 16), t & 2) {
        let e = l(2);
        s("columns", e.partColumns)("rows", e.parts)
    }
}

function Pn(t, d) {
    if (t & 1 && m(0, "app-invoice-signature", 21), t & 2) {
        let e = l(2);
        s("entityId", e.jobInvoice == null ? null : e.jobInvoice.id)("entityType", e.entityType)
    }
}

function Mn(t, d) {
    if (t & 1 && (r(0, "div", 7)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11), r(5, "div", 2)(6, "div", 3), m(7, "app-invoice-customer-detail", 12)(8, "app-invoice-job-details", 13), a()(), r(9, "div", 14)(10, "div", 3)(11, "h5", 15), c(12), a(), r(13, "div", 2)(14, "div", 3), p(15, bn, 1, 2, "app-print-table", 16), p(16, xn, 1, 2, "app-print-table", 16), m(17, "app-summary-table", 17), a()()()(), m(18, "app-edit-input", 18)(19, "app-invoice-term-and-conditions", 19)(20, "hr", 20), p(21, Pn, 1, 2, "app-invoice-signature", 21), a()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.jobInvoice == null ? null : e.jobInvoice.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.jobInvoice == null ? null : e.jobInvoice.qr_code)), n(), s("dateTime", e.jobInvoice == null ? null : e.jobInvoice.created_at)("revision", e.jobInvoice == null ? null : e.jobInvoice.revision)("title", ((e.printSettings == null ? null : e.printSettings.job_invoice_title) || "Tax Invoice:") + " " + (e.jobInvoice == null ? null : e.jobInvoice.invoice_number)), n(3), s("user", e.job.user), n(), s("job", e.job), n(4), u(e.formatMessage("invoice_details")), n(3), g(e.repairServices.length ? 15 : -1), n(), g(e.parts.length ? 16 : -1), n(), s("grandTotal", e.grandTotal)("taxAmount", e.taxAmount)("totalAmount", e.totalAmount), n(), s("noteData", e.jobInvoice == null ? null : e.jobInvoice.note), n(), s("termAndCondition", e.jobInvoice.term_and_condition), n(2), g(e.jobInvoice != null && e.jobInvoice.id ? 21 : -1)
    }
}
var Bt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.ENTITIES = k, this.activatedRouter = f(O), this.partColumns = f(ve).partColumns, this.servicesColumns = f(Ye).servicesColumns(), this.generalSettingDataService = f(B), this.statusIconTypeList = U, this.entityType = k.JOB_INVOICE.name, this.dateTime = new Date, this.summaryRows = Ce, this.repairServiceEntity = this.ENTITIES.JOB_REPAIR_SERVICE, this.partEntity = this.ENTITIES.JOB_PART, this.repairServices = [], this.parts = [], this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getJobInvoice(e).subscribe({
                        next: i => {
                            this.initialize(i)
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        initialize(e) {
            this.account = e.tenant, this.jobInvoice = e.job_invoice, this.job = e.job, this.user = this.job.user, this.repairServices = this.jobInvoice.repairables, this.parts = this.jobInvoice.partables, this.totalAmount = this.repairServices.reduce((i, {
                sub_total: o
            }) => i + Number(o), 0) + this.parts.reduce((i, {
                sub_total: o
            }) => i + Number(o), 0), this.taxAmount = this.repairServices.reduce((i, {
                tax_amount: o
            }) => i + Number(o), 0) + this.parts.reduce((i, {
                tax_amount: o
            }) => i + Number(o), 0), this.grandTotal = this.repairServices.reduce((i, {
                line_total: o
            }) => i + Number(o), 0) + this.parts.reduce((i, {
                line_total: o
            }) => i + Number(o), 0)
        }
        onToolbarPreparing(e) {
            e.toolbarOptions.items.push({
                template: "tableTitleTemplate",
                location: "before",
                locateInMenu: "never"
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-job-invoice"]
                ],
                standalone: !1,
                decls: 10,
                vars: 5,
                consts: [
                    [1, "p-2"],
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    ["id", "print-section", 1, "container-fluid", "mt-3"],
                    [3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "revision", "title"],
                    [3, "user"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [3, "columns", "rows"],
                    [3, "grandTotal", "taxAmount", "totalAmount"],
                    [3, "noteData"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr", "mt-3"],
                    [3, "entityId", "entityType"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), m(4, "app-job-status-tag", 4), r(5, "span", 5), c(6), a(), r(7, "div", 6), p(8, vn, 2, 7), a()()()(), p(9, Mn, 22, 16, "div", 7), a()), i & 2 && (n(4), s("iconType", o.statusIconTypeList.TITLE)("status", o.job == null ? null : o.job.status), n(2), _(" ", o.job == null ? null : o.job.job_number, " "), n(2), g(o.jobInvoice != null && o.jobInvoice.id ? 8 : -1), n(), g(o.job ? 9 : -1))
                },
                dependencies: [Z, A, L, z, N, R, $, ye, be, V, q, Ge],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var On = t => [t],
    Sn = (t, d) => [t, d];

function yn(t, d) {
    if (t & 1 && m(0, "app-print-button", 11)(1, "app-share-btn", 12), t & 2) {
        let e = l(3);
        s("isSignedApi", !0)("entityId", e.quotation == null ? null : e.quotation.id)("entityName", e.ENTITIES.JOB_QUOTATION.name)("isVisiblePrintButton", !!(e.quotation != null && e.quotation.id)), n(), s("entityId", e.quotation == null ? null : e.quotation.id)("entityType", e.ENTITIES.JOB_QUOTATION.name)("isSignedApi", !0)
    }
}

function Tn(t, d) {
    if (t & 1 && m(0, "app-print-button", 11)(1, "app-share-btn", 12), t & 2) {
        let e = l(3);
        s("isSignedApi", !0)("entityId", e.quotation == null ? null : e.quotation.id)("entityName", e.ENTITIES.QUOTATION.name)("isVisiblePrintButton", !!(e.quotation != null && e.quotation.id)), n(), s("entityId", e.quotation == null ? null : e.quotation.id)("entityType", e.ENTITIES.QUOTATION.name)("isSignedApi", !0)
    }
}

function wn(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "app-dx-outline-button", 13), T("onClickEvent", function() {
            v(e);
            let o = l(3);
            return b(o.showApprovalPopupUp(!1))
        }), a(), r(1, "app-dx-outline-button", 14), T("onClickEvent", function() {
            v(e);
            let o = l(3);
            return b(o.showApprovalPopupUp(!0))
        }), a()
    }
}

function En(t, d) {
    if (t & 1 && (p(0, yn, 2, 7)(1, Tn, 2, 7), p(2, wn, 2, 0)), t & 2) {
        let e = l(2);
        g((e.quotation == null ? null : e.quotation.quotationable_type) === e.ENTITIES.JOB.name ? 0 : 1), n(2), g(at(2, On, e.quotationStatuses.AWAITING_APPROVAL).includes(e.quotation == null ? null : e.quotation.status) ? 2 : -1)
    }
}

function In(t, d) {
    if (t & 1 && (r(0, "div", 1)(1, "div", 5)(2, "div", 6)(3, "div")(4, "div", 7), m(5, "app-quotation-status-tag", 8), r(6, "span", 9), c(7), a()(), r(8, "div")(9, "div", 10), p(10, En, 3, 4), a()()()()()()), t & 2) {
        let e = l();
        n(4), s("ngClass", e.isMobileDevice ? "d-flex justify-content-between align-items-center flex-wrap" : ""), n(), s("iconType", e.statusIconTypeList.TITLE)("status", e.quotation.status), n(2), _(" ", e.quotation == null ? null : e.quotation.quotation_number, " "), n(3), g(e.quotation != null && e.quotation.id ? 10 : -1)
    }
}

function kn(t, d) {
    if (t & 1 && (r(0, "p", 16), c(1), a()), t & 2) {
        let e = l(2);
        n(), ue("", e.formatMessage("job_sheet_number"), " ", e.quotationable == null ? null : e.quotationable.job_number)
    }
}

function jn(t, d) {
    if (t & 1 && (r(0, "p", 18), c(1), a()), t & 2) {
        let e = l(2);
        n(), u(e.quotation.status === e.quotationStatuses.APPROVED ? e.formatMessage("approved_by") : e.formatMessage("rejected_by"))
    }
}

function Dn(t, d) {
    if (t & 1 && m(0, "app-user-badge", 19), t & 2) {
        let e = l(2);
        s("iconOnly", !1)("user", e.quotation == null ? null : e.quotation.approved_user)
    }
}

function An(t, d) {
    t & 1 && m(0, "app-currency-symbol")
}

function Nn(t, d) {
    if (t & 1 && (r(0, "div")(1, "p", 16), c(2), M(3, "dateFormat"), a(), r(4, "p", 16), c(5), r(6, "span", 20), c(7), a()(), r(8, "p", 16), c(9), p(10, An, 1, 0, "app-currency-symbol"), c(11), a()()), t & 2) {
        let e = l(2);
        n(2), ue("", e.formatMessage("approved_on"), " ", I(3, 7, e.quotation == null ? null : e.quotation.approved_at, "datetime")), n(3), _("", e.formatMessage("quotation_status"), ": "), n(2), u(e.quotation == null ? null : e.quotation.status), n(2), _("", e.formatMessage("approved_quotation_amount"), ": "), n(), g(e.quotation != null && e.quotation.total_amount ? 10 : -1), n(), _(" ", e.quotation == null ? null : e.quotation.total_amount, " ")
    }
}

function Vn(t, d) {
    t & 1 && m(0, "app-currency-symbol")
}

function qn(t, d) {
    if (t & 1 && (r(0, "div")(1, "p", 16), c(2), M(3, "dateFormat"), a(), r(4, "p", 16), c(5), r(6, "span", 21), c(7), a()(), r(8, "p", 16), c(9), p(10, Vn, 1, 0, "app-currency-symbol"), c(11), a()()), t & 2) {
        let e = l(2);
        n(2), ue(" ", e.formatMessage("rejected_on"), " ", I(3, 7, e.quotation == null ? null : e.quotation.approved_at, "datetime")), n(3), _(" ", e.formatMessage("quotation_status"), ": "), n(2), u(e.quotation == null ? null : e.quotation.status), n(2), _("", e.formatMessage("rejected_quotation_amount"), ": "), n(), g(e.quotation != null && e.quotation.total_amount ? 10 : -1), n(), _(" ", e.quotation == null ? null : e.quotation.total_amount, " ")
    }
}

function Bn(t, d) {
    t & 1 && m(0, "app-currency-symbol")
}

function Rn(t, d) {
    if (t & 1 && (r(0, "div")(1, "p", 16), c(2), r(3, "span", 22), c(4), a()(), r(5, "p", 16), c(6), p(7, Bn, 1, 0, "app-currency-symbol"), c(8), a()()), t & 2) {
        let e = l(2);
        n(2), _("", e.formatMessage("quotation_status"), ": "), n(2), u(e.quotation == null ? null : e.quotation.status), n(2), _("", e.formatMessage("quotation_amount"), ": "), n(), g(e.quotation != null && e.quotation.total_amount ? 7 : -1), n(), _(" ", e.quotation == null ? null : e.quotation.total_amount, " ")
    }
}

function zn(t, d) {
    if (t & 1 && (r(0, "p")(1, "span", 16), c(2), a(), m(3, "span", 23), M(4, "safe"), a()), t & 2) {
        let e = l(2);
        n(2), _("", e.formatMessage("quotation_comment"), " :"), n(), s("innerHTML", I(4, 2, e.quotation == null ? null : e.quotation.comment, "html"), F)
    }
}

function Jn(t, d) {
    if (t & 1 && (r(0, "p")(1, "span", 16), c(2), a(), m(3, "span", 23), M(4, "safe"), a()), t & 2) {
        let e = l(2);
        n(2), _("", (e.quotation == null ? null : e.quotation.status) === e.quotationStatuses.APPROVED ? e.formatMessage("quotation_approval_comment") : e.formatMessage("quotation_rejected_comment"), " :"), n(), s("innerHTML", I(4, 2, e.quotation == null ? null : e.quotation.approval_comment, "html"), F)
    }
}

function Un(t, d) {
    if (t & 1 && (r(0, "div", 2)(1, "div", 5)(2, "div", 15), p(3, kn, 2, 2, "p", 16), r(4, "p", 16), c(5), a(), r(6, "div", 17), p(7, jn, 2, 1, "p", 18), p(8, Dn, 1, 2, "app-user-badge", 19), a()(), r(9, "div", 15)(10, "div"), p(11, Nn, 12, 10, "div")(12, qn, 12, 10, "div")(13, Rn, 9, 5, "div"), a()(), r(14, "div", 6), p(15, zn, 5, 5, "p"), p(16, Jn, 5, 5, "p"), a()()()), t & 2) {
        let e, i = l();
        n(3), g((i.quotation == null ? null : i.quotation.quotationable_type) === i.ENTITIES.JOB.name ? 3 : -1), n(2), ue("", i.formatMessage("quotation_number"), " : ", i.quotation == null ? null : i.quotation.quotation_number), n(2), g(i.quotation.status === i.quotationStatuses.APPROVED || i.quotation.status === i.quotationStatuses.REJECTED ? 7 : -1), n(), g(i.quotation.approved_user ? 8 : -1), n(3), g((e = i.quotation == null ? null : i.quotation.status) === i.quotationStatuses.APPROVED ? 11 : e === i.quotationStatuses.REJECTED ? 12 : 13), n(4), g(i.quotation != null && i.quotation.comment ? 15 : -1), n(), g(rt(8, Sn, i.quotationStatuses.APPROVED, i.quotationStatuses.REJECTED).includes(i.quotation == null ? null : i.quotation.status) && (i.quotation != null && i.quotation.approval_comment) ? 16 : -1)
    }
}

function Ln(t, d) {
    if (t & 1 && m(0, "app-invoice-job-details", 27), t & 2) {
        let e = l(2);
        s("job", e.quotationable)
    }
}

function Fn(t, d) {
    if (t & 1 && m(0, "app-print-table", 30), t & 2) {
        let e = l(2);
        s("columns", e.servicesColumns)("rows", e.repairServices)
    }
}

function Qn(t, d) {
    if (t & 1 && m(0, "app-print-table", 30), t & 2) {
        let e = l(2);
        s("columns", e.partColumns)("rows", e.parts)
    }
}

function Hn(t, d) {
    if (t & 1 && m(0, "app-invoice-signature", 35), t & 2) {
        let e = l(2);
        s("entityId", e.quotation == null ? null : e.quotation.id)("entityType", e.entityType)
    }
}

function Gn(t, d) {
    if (t & 1 && (r(0, "div", 3)(1, "div", 5)(2, "div", 6), m(3, "app-invoice-header", 24)(4, "app-invoice-title", 25), r(5, "div", 5)(6, "div", 6), m(7, "app-invoice-customer-detail", 26), p(8, Ln, 1, 1, "app-invoice-job-details", 27), a()(), r(9, "div", 28)(10, "div", 6)(11, "h5", 29), c(12), a(), r(13, "div", 5)(14, "div", 6), p(15, Fn, 1, 2, "app-print-table", 30), p(16, Qn, 1, 2, "app-print-table", 30), m(17, "app-summary-table", 31), a()()()(), m(18, "app-edit-input", 32)(19, "app-invoice-term-and-conditions", 33)(20, "hr", 34), p(21, Hn, 1, 2, "app-invoice-signature", 35), a()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", e.quotation && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.quotation == null ? null : e.quotation.qr_code)), n(), s("dateTime", e.quotation == null ? null : e.quotation.created_at)("revision", e.quotation == null ? null : e.quotation.revision)("title", e.formatMessage("quotation_with") + " : " + (e.quotation == null ? null : e.quotation.quotation_number)), n(3), s("user", e.user), n(), g((e.quotation == null ? null : e.quotation.quotationable_type) === e.ENTITIES.JOB.name ? 8 : -1), n(4), u(e.formatMessage("quotation_details")), n(3), g(e.repairServices.length ? 15 : -1), n(), g(e.parts.length ? 16 : -1), n(), s("grandTotal", e.grandTotal)("taxAmount", e.taxAmount)("totalAmount", e.totalAmount), n(), s("noteData", e.quotation == null ? null : e.quotation.note), n(), s("termAndCondition", e.quotation.term_and_condition), n(2), g(e.quotation != null && e.quotation.id ? 21 : -1)
    }
}

function Yn(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "app-confirmation-popup", 36), T("confirmActionCallback", function() {
            v(e);
            let o = l();
            return b(o.updateQuotationApproval())
        })("rejectActionCallback", function() {
            v(e);
            let o = l();
            return b(o.isVisibleApprovalPopup = !1)
        }), a()
    }
    if (t & 2) {
        let e = l();
        s("confirmationMessage", e.confirmationMsg)("isSaving", e.isSaving)
    }
}
var nt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.partColumns = f(ve).partColumns, this.servicesColumns = f(Ye).servicesColumns(), this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.toastNotificationService = f(fe), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.QUOTATION.name, this.confirmationMsg = "", this.quotationStatuses = lt, this.dateTime = new Date, this.summaryRows = Ce, this.repairServices = [], this.isVisibleApprovalPopup = !1, this.isSaving = !1, this.isApproving = !1, this.approveSignature = null, this.rejectSignature = null, this.parts = []
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getQuotation(e).subscribe({
                        next: i => {
                            this.initialize(i)
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                }
            })
        }
        initialize(e) {
            this.account = e.tenant, this.printSettings = this.extractPrintSettings(e.tenant ? .general_settings), this.quotation = e.quotation, this.quotationable = e.quotationable, this.user = this.quotation.user, this.repairServices = this.quotation.repairables, this.parts = this.quotation.partables, this.form = jt.getForm(this.quotation), this.approveSignature = new URL(e.approval_signature).searchParams.get("signature"), this.rejectSignature = new URL(e.rejection_signature).searchParams.get("signature"), this.totalAmount = this.repairServices.reduce((i, {
                sub_total: o
            }) => i + Number(o), 0) + this.parts.reduce((i, {
                sub_total: o
            }) => i + Number(o), 0), this.taxAmount = this.repairServices.reduce((i, {
                tax_amount: o
            }) => i + Number(o), 0) + this.parts.reduce((i, {
                tax_amount: o
            }) => i + Number(o), 0), this.grandTotal = this.repairServices.reduce((i, {
                line_total: o
            }) => i + Number(o), 0) + this.parts.reduce((i, {
                line_total: o
            }) => i + Number(o), 0)
        }
        onToolbarPreparing(e) {
            e.toolbarOptions.items.push({
                template: "tableTitleTemplate",
                location: "before",
                locateInMenu: "never"
            })
        }
        showApprovalPopupUp(e) {
            this.isApproving = e, this.confirmationMsg = `Are you sure you want to ${this.isApproving?"approve":"reject"}  the Quotation?`, this.isVisibleApprovalPopup = !0
        }
        extractPrintSettings(e) {
            if (!e) return E.getEmptyObject();
            let i = e.filter(C => C.setting_type === D.PRINT_SETTINGS),
                o = {};
            return i.forEach(C => {
                o[C.key] = C.value
            }), Object.keys(o).length > 0 ? o : E.getEmptyObject()
        }
        updateQuotationApproval() {
            this.isSaving = !0;
            let e = {
                id: this.quotation ? .id,
                signature: this.isApproving ? this.approveSignature : this.rejectSignature
            };
            (this.isApproving ? this.service.approveQuotation(e) : this.service.rejectQuotation(e)).subscribe({
                next: o => {
                    this.isApproving ? this.toastNotificationService.success("notification_quotation_approve_success") : this.toastNotificationService.success("notification_quotation_reject_success"), this.quotation = o
                },
                error: o => {
                    console.error(o)
                }
            }).add(() => {
                this.isSaving = !1, this.isVisibleApprovalPopup = !1
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-job-quotation"]
                ],
                standalone: !1,
                decls: 5,
                vars: 4,
                consts: [
                    [1, "p-2"],
                    [1, "container-fluid"],
                    [1, "container-fluid", "mt-3"],
                    ["id", "print-section", 1, "container-fluid", "mt-3"],
                    ["id", "approval-quotation-popup", 3, "confirmationMessage", "isSaving"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "ngClass"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "isSignedApi", "entityId", "entityName", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["buttonType", "danger", "text", "reject", 1, "mx-1", 3, "onClickEvent"],
                    ["buttonType", "success", "text", "approve", 3, "onClickEvent"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold"],
                    [1, "d-flex", "flex-row"],
                    [1, "fw-bold", "d-inline-block"],
                    [1, "ms-2", "fw-bold", 3, "iconOnly", "user"],
                    [1, "badge", "bg-success"],
                    [1, "badge", "bg-danger"],
                    [1, "badge", "bg-warning"],
                    [3, "innerHTML"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "revision", "title"],
                    [3, "user"],
                    [3, "job"],
                    [1, "row", "background-row"],
                    [1, "fw-bolder", "p-2", "section-header"],
                    [3, "columns", "rows"],
                    [3, "grandTotal", "taxAmount", "totalAmount"],
                    [3, "noteData"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr", "mt-3"],
                    [3, "entityId", "entityType"],
                    ["id", "approval-quotation-popup", 3, "confirmActionCallback", "rejectActionCallback", "confirmationMessage", "isSaving"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0), p(1, In, 11, 5, "div", 1), p(2, Un, 17, 11, "div", 2), p(3, Gn, 22, 16, "div", 3), a(), p(4, Yn, 1, 2, "app-confirmation-popup", 4)), i & 2 && (n(), g(o.quotation ? 1 : -1), n(), g(o.quotation != null && o.quotation.id ? 2 : -1), n(), g(o.quotation && o.form ? 3 : -1), n(), g(o.isVisibleApprovalPopup ? 4 : -1))
                },
                dependencies: [H, A, Ct, bt, L, z, N, R, yt, $, ye, be, V, q, ae, oe, Ge, W, he],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function Wn(t, d) {
    if (t & 1 && (r(0, "div", 9)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11)(5, "app-invoice-customer-detail", 12)(6, "app-invoice-job-details", 13)(7, "app-invoice-term-and-conditions", 14)(8, "hr", 15)(9, "app-invoice-signature", 16), a()()()), t & 2) {
        let e = l();
        s("ngClass", e.isMobileDevice ? "p-0" : ""), n(3), s("account", e.account)("qrCode", (e.job == null ? null : e.job.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.job == null ? null : e.job.qr_code)), n(), s("dateTime", e.job == null ? null : e.job.created_at)("title", e.formatMessage("common_job_sheet_no") + " : " + (e.job == null ? null : e.job.job_number)), n(), s("user", e.user), n(), s("job", e.job), n(), s("termAndCondition", e.job.term_and_condition), n(2), s("entityId", e.job == null ? null : e.job.id)("entityType", e.entityType)
    }
}
var Rt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.generalSettingDataService = f(B), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.JOB.name, this.dateTime = new Date, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getJobSheet(e).subscribe(i => {
                        this.account = i.tenant, this.job = i.job, this.user = this.job.user
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-job-sheet"]
                ],
                standalone: !1,
                decls: 12,
                vars: 12,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mb-3", "mt-2", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [1, "ms-1", 3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [3, "job"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), m(5, "app-job-status-tag", 4), r(6, "span", 5), c(7), a(), r(8, "div", 6), m(9, "app-print-button", 7)(10, "app-share-btn", 8), a()()()(), p(11, Wn, 10, 10, "div", 9), a()()), i & 2 && (n(2), s("ngClass", o.isMobileDevice ? "p-0" : ""), n(3), s("iconType", o.statusIconTypeList.TITLE)("status", o.job == null ? null : o.job.status), n(2), _(" ", o.job == null ? null : o.job.job_number, " "), n(2), s("entityId", o.job == null ? null : o.job.id)("entityName", o.ENTITIES.JOB_SHEET.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.job != null && o.job.id)), n(), s("entityId", o.job == null ? null : o.job.id)("entityType", o.ENTITIES.JOB_SHEET.name)("isSignedApi", !0), n(), g(o.job ? 11 : -1))
                },
                dependencies: [H, Z, A, L, z, N, R, $, V, q],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function $n(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "app-payment-status", 8), r(2, "span", 9), c(3), a()()), t & 2) {
        let e = l();
        n(), s("iconType", e.statusIconTypeList.TITLE)("status", e.sale == null ? null : e.sale.status), n(2), _(" ", e.sale == null ? null : e.sale.sale_number, " ")
    }
}

function Kn(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "app-job-status-tag", 8), r(2, "span", 9), c(3), a()()), t & 2) {
        let e = l();
        n(), s("iconType", e.statusIconTypeList.TITLE)("status", e.job == null ? null : e.job.status), n(2), _(" ", e.job == null ? null : e.job.job_number, " ")
    }
}

function Xn(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "app-invoice-sale-details", 24), a()), t & 2) {
        let e = l(2);
        n(), s("sale", e.sale)
    }
}

function Zn(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "app-invoice-job-details", 25), a()), t & 2) {
        let e = l(2);
        n(), s("job", e.job)
    }
}

function ei(t, d) {
    t & 1 && m(0, "app-currency-symbol")
}

function ti(t, d) {
    if (t & 1 && (r(0, "div", 7)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11)(5, "app-invoice-customer-detail", 12), p(6, Xn, 2, 1, "div"), p(7, Zn, 2, 1, "div"), r(8, "div", 13)(9, "div", 3)(10, "h5", 14), c(11), a(), r(12, "div", 2)(13, "div", 15)(14, "span", 16), c(15), a(), r(16, "span", 17), c(17, ":"), a(), c(18), a(), r(19, "div", 18)(20, "span", 16), c(21), a(), r(22, "span", 17), c(23, ":"), a(), c(24), a(), r(25, "div", 15)(26, "span", 16), c(27), a(), r(28, "span", 17), c(29, ":"), a(), p(30, ei, 1, 0, "app-currency-symbol"), c(31), a(), r(32, "div", 18)(33, "span", 16), c(34), a(), r(35, "span", 17), c(36, ":"), a(), c(37), M(38, "dateFormat"), a(), r(39, "div", 19)(40, "span", 16), c(41), a(), r(42, "span", 17), c(43, ":"), a(), c(44), a(), r(45, "div", 19)(46, "span", 16), c(47), a(), r(48, "span", 17), c(49, ":"), a(), m(50, "span", 20), M(51, "safe"), a()()()(), m(52, "app-invoice-term-and-conditions", 21)(53, "hr", 22)(54, "app-invoice-signature", 23), a()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.payment == null ? null : e.payment.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.payment == null ? null : e.payment.qr_code)), n(), s("dateTime", e.payment == null ? null : e.payment.created_at)("title", e.formatMessage("payment_receipt_title") + " : " + (e.payment == null ? null : e.payment.id)), n(), s("user", e.user), n(), g(e.sale ? 6 : -1), n(), g(e.job ? 7 : -1), n(4), u(e.formatMessage("payment_information")), n(4), u(e.formatMessage("payment_mode")), n(3), _("", e.payment.payment_type.name, " "), n(3), u(e.payment.cheque_number ? e.formatMessage("payment_cheque_number") : e.formatMessage("common_transaction_id")), n(3), _("", e.payment.cheque_number ? e.payment.cheque_number : e.payment.transaction_id, " "), n(3), u(e.formatMessage("amount")), n(3), g(e.payment.amount ? 30 : -1), n(), _(" ", e.payment.amount, " "), n(3), u(e.formatMessage("received_on")), n(3), _("", I(38, 24, e.payment.created_at, "datetime"), " "), n(4), u(e.formatMessage("received_by")), n(3), _("", e.payment.created_user.name, " "), n(3), u(e.formatMessage("comment")), n(3), s("innerHTML", I(51, 27, e.payment.comment, "html"), F), n(2), s("termAndCondition", e.payment.term_and_condition), n(2), s("entityId", e.payment == null ? null : e.payment.id)("entityType", e.entityType)
    }
}
var Jt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.generalSettingDataService = f(B), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.PAYMENT.name, this.dateTime = new Date, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getPayment(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.job = i.job ? ? null, this.sale = i.sale ? ? null, this.payment = i.payment, this.user = i.user
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-payment"]
                ],
                standalone: !1,
                decls: 11,
                vars: 10,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mt-2", "mb-3"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "d-flex", "justify-content-end", "me-2"],
                    [3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text", "float-start"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "ps-4"],
                    [3, "innerHTML"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [3, "sale"],
                    [3, "job"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), p(5, $n, 4, 3, "div"), p(6, Kn, 4, 3, "div"), r(7, "div", 4), m(8, "app-print-button", 5)(9, "app-share-btn", 6), a()()()(), p(10, ti, 55, 30, "div", 7), a()()), i & 2 && (n(5), g(o.sale ? 5 : -1), n(), g(o.job ? 6 : -1), n(2), s("entityId", o.payment == null ? null : o.payment.id)("entityName", o.ENTITIES.PAYMENT.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.payment != null && o.payment.id)), n(), s("entityId", o.payment == null ? null : o.payment.id)("entityType", o.ENTITIES.PAYMENT.name)("isSignedApi", !0), n(), g(o.job || o.sale ? 10 : -1))
                },
                dependencies: [Z, A, L, z, N, R, Me, Tt, $, V, q, ae, W, he],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function ni(t, d) {
    if (t & 1 && (r(0, "div", 9)(1, "div", 1)(2, "div", 2), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11)(5, "app-invoice-supplier-detail", 12), r(6, "div", 13)(7, "div", 2), m(8, "app-print-table", 14)(9, "app-summary-table", 15), a()(), m(10, "app-invoice-term-and-conditions", 16)(11, "hr", 17)(12, "app-invoice-signature", 18), a()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.purchase == null ? null : e.purchase.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.purchase == null ? null : e.purchase.qr_code)), n(), s("dateTime", e.purchase == null ? null : e.purchase.created_at)("title", ((e.printSettings == null ? null : e.printSettings.purchase_invoice_title) || e.formatMessage("purchase_invoice_label")) + " " + (e.purchase == null ? null : e.purchase.purchase_number)), n(), s("user", e.purchase == null ? null : e.purchase.part_supplier), n(3), s("columns", e.partColumns)("rows", e.purchase == null ? null : e.purchase.partables), n(), s("isPurchase", !0)("rows", e.purchase == null ? null : e.purchase.partables), n(), s("termAndCondition", e.purchase.term_and_condition), n(2), s("entityId", e.purchase == null ? null : e.purchase.id)("entityType", e.entityType)
    }
}
var Lt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.generalSettingDataService = f(B), this.ENTITIES = k, this.partColumns = f(ve).partColumns, this.activatedRouter = f(O), this.statusIconTypeList = U, this.entityType = this.ENTITIES.PURCHASE.name, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getPurchase(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.purchase = i.purchase, this.supplier = this.purchase.part_supplier
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-purchase-receipt"]
                ],
                viewQuery: function(i, o) {
                    if (i & 1 && Pe(Se, 5), i & 2) {
                        let C;
                        pe(C = ge()) && (o.dataGrid = C.first)
                    }
                },
                standalone: !1,
                decls: 11,
                vars: 13,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text"],
                    [1, "float-end", "d-flex", "justify-content-end"],
                    ["buttonType", "default", "text", "view_purchase", 1, "me-1", 3, "routerLink"],
                    [1, "ms-1", 3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [1, "row", "mt-2"],
                    [3, "columns", "rows"],
                    [3, "isPurchase", "rows"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), m(3, "app-payment-status", 3), r(4, "span", 4), c(5), a(), r(6, "div", 5), m(7, "app-dx-outline-button", 6)(8, "app-print-button", 7)(9, "app-share-btn", 8), a()()()(), p(10, ni, 13, 12, "div", 9)), i & 2 && (n(3), s("iconType", o.statusIconTypeList.TITLE)("status", o.purchase == null ? null : o.purchase.status), n(2), u(o.purchase == null ? null : o.purchase.purchase_number), n(2), s("routerLink", Re("/purchases/", o.purchase == null ? null : o.purchase.id, "/details")), n(), s("entityId", o.purchase == null ? null : o.purchase.id)("entityName", o.ENTITIES.PURCHASE.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.purchase != null && o.purchase.id)), n(), s("entityId", o.purchase == null ? null : o.purchase.id)("entityType", o.ENTITIES.PURCHASE.name)("isSignedApi", !0), n(), g(o.purchase ? 10 : -1))
                },
                dependencies: [Ue, A, L, z, N, Me, ye, be, V, wt, q, oe],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var ii = () => ({
        enabled: !1
    }),
    oi = () => ({
        groupPaging: !1
    }),
    ai = () => ({
        mode: "standard"
    }),
    ri = () => ({
        type: "fixedPoint",
        precision: 2
    });

function ci(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "span", 28), M(2, "taxSplit"), M(3, "safe"), a()), t & 2) {
        let e = d.$implicit;
        n(), s("innerHTML", I(3, 4, I(2, 1, e.data, "amount"), "html"), F)
    }
}

function si(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "app-part-name", 29), a()), t & 2) {
        let e = d.$implicit;
        n(), s("part", e.data)
    }
}

function li(t, d) {
    if (t & 1 && (r(0, "div"), m(1, "span", 28), M(2, "taxSplit"), M(3, "safe"), a()), t & 2) {
        let e = d.$implicit;
        n(), s("innerHTML", I(3, 4, I(2, 1, e.data, "name"), "html"), F)
    }
}

function di(t, d) {
    if (t & 1 && m(0, "dxi-total-item", 18), t & 2) {
        let e = d.$implicit;
        s("alignment", e.alignment)("column", e.column)("name", e.column)("summaryType", e.summaryType)("valueFormat", De(5, ri))
    }
}

function mi(t, d) {
    if (t & 1 && (r(0, "div", 1), m(1, "app-summary-table", 30), a()), t & 2) {
        let e = l(2);
        n(), s("grandTotal", e.dataGrid.instance.getTotalSummaryValue("line_total"))("taxAmount", e.dataGrid.instance.getTotalSummaryValue("tax_amount"))("totalAmount", e.dataGrid.instance.getTotalSummaryValue("sub_total"))
    }
}

function pi(t, d) {
    t & 1 && m(0, "app-currency-symbol")
}

function gi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "div", 9)(1, "div", 1)(2, "div", 2), m(3, "app-invoice-header", 10)(4, "app-invoice-title", 11)(5, "app-invoice-customer-detail", 12), r(6, "div", 13)(7, "div", 2)(8, "h5", 14), c(9), a(), r(10, "div", 1)(11, "div", 2)(12, "dx-data-grid", 15), je("dataSourceChange", function(o) {
            v(e);
            let C = l();
            return ke(C.sale.partables, o) || (C.sale.partables = o), b(o)
        }), ot(13, ci, 4, 7, "div", 16)(14, si, 2, 1, "div", 16)(15, li, 4, 7, "div", 16), r(16, "dxo-summary", 17), de(17, di, 1, 6, "dxi-total-item", 18, le), a()(), p(19, mi, 2, 3, "div", 1), a()()()(), r(20, "div", 19)(21, "div", 2)(22, "h5", 14), c(23), a(), r(24, "div", 1)(25, "div", 20)(26, "span", 21), c(27), a(), r(28, "span", 22), c(29, ":"), a(), p(30, pi, 1, 0, "app-currency-symbol"), c(31), a(), r(32, "div", 23)(33, "span", 21), c(34), a(), r(35, "span", 22), c(36, ":"), a(), m(37, "app-currency-symbol"), c(38), a(), r(39, "div", 20)(40, "span", 21), c(41), a(), r(42, "span", 22), c(43, ": "), m(44, "app-payment-status", 24), a()()()()(), m(45, "app-invoice-term-and-conditions", 25)(46, "hr", 26)(47, "app-invoice-signature", 27), a()()()
    }
    if (t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.sale == null ? null : e.sale.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.sale == null ? null : e.sale.qr_code)), n(), s("dateTime", e.sale == null ? null : e.sale.created_at)("title", e.printSettings != null && e.printSettings.sale_invoice_title ? e.printSettings.sale_invoice_title + " " + ((e.sale == null ? null : e.sale.sale_number) ? ? "") : e.formatMessage("sale_invoice") + " " + ((e.sale == null ? null : e.sale.sale_number) ? ? "")), n(), s("user", e.sale == null ? null : e.sale.user), n(4), u(e.formatMessage("common_parts")), n(3), Ie("dataSource", e.sale.partables), s("columnAutoWidth", !1)("columns", e.partColumns)("paging", De(28, ii))("remoteOperations", De(29, oi))("scrolling", De(30, ai)), n(), s("dxTemplateOf", "taxAmountSplitSubClassTemplate"), n(), s("dxTemplateOf", "partNameTemplate"), n(), s("dxTemplateOf", "taxSplitSubClassTemplate"), n(), s("skipEmptyValues", !0), n(), me(e.summaryRows), n(2), g(e.sale != null && e.sale.partables.length && (e.dataGrid != null && e.dataGrid.instance) ? 19 : -1), n(4), u(e.formatMessage("payment_information")), n(4), u(e.formatMessage("payment_payable_amount")), n(3), g(e.sale.total_amount ? 30 : -1), n(), _(" ", e.sale.total_amount, " "), n(3), _("", e.formatMessage("payment_received"), " "), n(4), _(" ", e.sale.paymentable_sum_amount, " "), n(3), u(e.formatMessage("payment_status")), n(3), s("status", e.sale.status), n(), s("termAndCondition", e.sale.term_and_condition), n(2), s("entityId", e.sale == null ? null : e.sale.id)("entityType", e.entityType)
    }
}
var Ft = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.generalSettingDataService = f(B), this.partColumns = f(ve).partColumns, this.activatedRouter = f(O), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.SALE.name, this.summaryRows = Ce, this.dateTime = new Date, this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getSale(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.sale = i.sale, this.user = this.sale.user
                        },
                        error: i => {
                            console.log(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-sale"]
                ],
                viewQuery: function(i, o) {
                    if (i & 1 && Pe(Se, 5), i & 2) {
                        let C;
                        pe(C = ge()) && (o.dataGrid = C.first)
                    }
                },
                standalone: !1,
                decls: 11,
                vars: 13,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "status"],
                    [1, "title-text"],
                    [1, "float-end", "d-flex", "justify-content-end"],
                    ["buttonType", "default", "text", "view_sale", 1, "me-1", 3, "routerLink"],
                    [3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    ["keyExpr", "id", 3, "dataSourceChange", "dataSource", "columnAutoWidth", "columns", "paging", "remoteOperations", "scrolling"],
                    [4, "dxTemplate", "dxTemplateOf"],
                    [3, "skipEmptyValues"],
                    ["displayFormat", "{0}", 3, "alignment", "column", "name", "summaryType", "valueFormat"],
                    [1, "row", "background-row", "mb-2"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [3, "status"],
                    [3, "termAndCondition"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "tax-split", 3, "innerHTML"],
                    [3, "part"],
                    [3, "grandTotal", "taxAmount", "totalAmount"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), m(3, "app-payment-status", 3), r(4, "span", 4), c(5), a(), r(6, "div", 5), m(7, "app-dx-outline-button", 6)(8, "app-print-button", 7)(9, "app-share-btn", 8), a()()()(), p(10, gi, 48, 31, "div", 9)), i & 2 && (n(3), s("iconType", o.statusIconTypeList.TITLE)("status", o.sale == null ? null : o.sale.status), n(2), u(o.sale == null ? null : o.sale.sale_number), n(2), s("routerLink", Re("/sales/", o.sale == null ? null : o.sale.id)), n(), s("entityId", o.sale == null ? null : o.sale.id)("entityName", o.ENTITIES.SALE.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.sale != null && o.sale.id)), n(), s("entityId", o.sale == null ? null : o.sale.id)("entityType", o.ENTITIES.SALE.name)("isSignedApi", !0), n(), g(o.sale ? 10 : -1))
                },
                dependencies: [Ue, A, L, z, N, R, Me, be, V, Mt, q, ae, oe, mt, Se, gt, ut, W, Ot],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function ui(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("service_done_by")), n(3), _("", (e.amcService.assigned_user == null ? null : e.amcService.assigned_user.display_name) ? ? (e.amcService.assigned_user == null ? null : e.amcService.assigned_user.name), " ")
    }
}

function _i(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("job_service_type")), n(3), _("", e.amcService.service_type, " ")
    }
}

function Ci(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), m(5, "app-status-tag", 19), a()), t & 2) {
        let e = l(2);
        n(2), _("", e.formatMessage("common_status"), " "), n(3), s("status", e.amcService == null ? null : e.amcService.status)
    }
}

function fi(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("service_charge")), n(3), _("", e.amcService.service_charge, " ")
    }
}

function hi(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("service_expenditure")), n(3), _("", e.amcService.service_expenditure, " ")
    }
}

function vi(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("travel_expenditure")), n(3), _("", e.amcService.travel_expenditure, " ")
    }
}

function bi(t, d) {
    if (t & 1 && (r(0, "div", 16)(1, "span", 17), c(2), a(), r(3, "span", 18), c(4, ":"), a(), m(5, "span", 20), M(6, "safe"), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("comment")), n(3), s("innerHTML", I(6, 2, e.amcService.service_remark, "html"), F)
    }
}

function xi(t, d) {
    if (t & 1 && (r(0, "div", 8)(1, "div", 2)(2, "div", 3)(3, "div", 2)(4, "div", 3), m(5, "app-invoice-header", 9)(6, "app-invoice-title", 10)(7, "app-invoice-customer-detail", 11)(8, "app-invoice-amc-contract-details", 12), r(9, "div", 13)(10, "div", 3)(11, "h5", 14), c(12), a(), r(13, "div", 2), p(14, ui, 6, 2, "div", 15), p(15, _i, 6, 2, "div", 15), p(16, Ci, 6, 2, "div", 15), p(17, fi, 6, 2, "div", 15), p(18, hi, 6, 2, "div", 15), p(19, vi, 6, 2, "div", 15), p(20, bi, 7, 5, "div", 16), a()()()()()()()()), t & 2) {
        let e = l();
        s("ngClass", e.isMobileDevice ? "p-0" : ""), n(5), s("account", e.account)("qrCode", (e.amcService == null ? null : e.amcService.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.amcService == null ? null : e.amcService.qr_code)), n(), s("dateTime", e.amcService == null || e.amcService.amc_contract == null ? null : e.amcService.amc_contract.created_at)("title", e.formatMessage("service_receipt")), n(), s("userId", e.amcService == null || e.amcService.amc_contract == null ? null : e.amcService.amc_contract.user_id), n(), s("amcContract", e.amcService == null ? null : e.amcService.amc_contract), n(4), u(e.formatMessage("amc_service_detail")), n(2), g(e.amcService != null && e.amcService.assigned_user ? 14 : -1), n(), g(e.amcService != null && e.amcService.service_type ? 15 : -1), n(), g(e.amcService != null && e.amcService.status ? 16 : -1), n(), g(e.amcService != null && e.amcService.service_charge ? 17 : -1), n(), g(e.amcService != null && e.amcService.service_expenditure ? 18 : -1), n(), g(e.amcService != null && e.amcService.travel_expenditure ? 19 : -1), n(), g(e.amcService != null && e.amcService.service_remark ? 20 : -1)
    }
}
var Qt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.ENTITIES = k, this.generalSettingDataService = f(B), this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getAmcService(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.amcService = i.amc_service
                        },
                        error: i => {
                            console.log(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-amc-service"]
                ],
                decls: 10,
                vars: 10,
                consts: [
                    [1, "card", "p-2"],
                    [1, "container-fluid", "mt-2", "mb-3", 3, "ngClass"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "title-text", "float-start", "m-1"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid", 3, "ngClass"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "userId"],
                    [3, "amcContract"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4", "ps-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "ps-4"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [3, "status"],
                    [1, "d-inline-block", 3, "innerHTML"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "span", 4), c(5), a(), r(6, "div", 5), m(7, "app-print-button", 6)(8, "app-share-btn", 7), a()()()(), p(9, xi, 21, 15, "div", 8), a()), i & 2 && (n(), s("ngClass", o.isMobileDevice ? "p-0" : ""), n(4), _(" ", o.amcService == null || o.amcService.amc_contract == null ? null : o.amcService.amc_contract.contract_number, " "), n(2), s("entityId", o.amcService == null ? null : o.amcService.id)("entityName", o.ENTITIES.AMC_SERVICE.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.amcService != null && o.amcService.id)), n(), s("entityId", o.amcService == null ? null : o.amcService.id)("entityType", o.ENTITIES.AMC_SERVICE.name)("isSignedApi", !0), n(), g(o.amcService ? 9 : -1))
                },
                dependencies: [Te, A, N, R, Fe, V, He, q, H, W],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function Pi(t, d) {
    if (t & 1 && m(0, "app-send-whats-app-btn", 7), t & 2) {
        let e = l();
        s("entityId", e.outsourceJob == null ? null : e.outsourceJob.id)("entityName", e.ENTITIES.OUTSOURCED_JOB.name)
    }
}

function Mi(t, d) {
    if (t & 1 && (r(0, "div", 22)(1, "div")(2, "span", 24), c(3), a(), r(4, "span", 25), c(5, ":"), a(), c(6), a()()), t & 2) {
        let e = l(3);
        n(3), u(e.formatMessage("common_name")), n(3), _("", e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.name, " ")
    }
}

function Oi(t, d) {
    if (t & 1 && (r(0, "span"), c(1), a()), t & 2) {
        let e = l(4);
        n(), _("\xA0/\xA0", e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.phone_number)
    }
}

function Si(t, d) {
    if (t & 1 && (r(0, "div", 22)(1, "div")(2, "span", 24), c(3), a(), r(4, "span", 25), c(5, ":"), a(), c(6), M(7, "mobileDisplay"), p(8, Oi, 2, 1, "span"), a()()), t & 2) {
        let e = l(3);
        n(3), u(e.formatMessage("user_phone")), n(3), _("", I(7, 3, e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.mobile_number, e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.mobile_country_code), " "), n(2), g(!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.phone_number ? 8 : -1)
    }
}

function yi(t, d) {
    if (t & 1 && (r(0, "div", 22)(1, "div")(2, "span", 24), c(3), a(), r(4, "span", 25), c(5, ":"), a(), c(6), a()()), t & 2) {
        let e = l(3);
        n(3), u(e.formatMessage("common_email")), n(3), _("", e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.email, " ")
    }
}

function Ti(t, d) {
    if (t & 1 && (r(0, "div", 23)(1, "div")(2, "span", 24), c(3), a(), r(4, "span", 25), c(5, ":"), a(), c(6), M(7, "address"), a()()), t & 2) {
        let e = l(3);
        n(3), u(e.formatMessage("common_address")), n(3), _("", _e(7, 2, e.outsourceJob == null || e.outsourceJob.vendor == null ? null : e.outsourceJob.vendor.address), " ")
    }
}

function wi(t, d) {
    if (t & 1 && (r(0, "div", 15)(1, "div", 3)(2, "h5", 19), c(3), a(), m(4, "div", 20), r(5, "div", 21), p(6, Mi, 7, 2, "div", 22), p(7, Si, 9, 6, "div", 22), p(8, yi, 7, 2, "div", 22), p(9, Ti, 8, 4, "div", 23), a()()()), t & 2) {
        let e = l(2);
        n(3), u(e.formatMessage("vendor_details")), n(3), g(e.printOptions.name ? 6 : -1), n(), g(e.printOptions.phone_number || e.printOptions.mobile_number && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.mobile_number) && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.phone_number) ? 7 : -1), n(), g(e.printOptions.email && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.email) ? 8 : -1), n(), g(e.printOptions.address && (!(e.outsourceJob == null || e.outsourceJob.vendor == null) && e.outsourceJob.vendor.address) ? 9 : -1)
    }
}

function Ei(t, d) {
    if (t & 1 && (r(0, "div", 11)(1, "div", 2)(2, "div", 12), m(3, "app-invoice-header", 13)(4, "app-invoice-title", 14), p(5, wi, 10, 5, "div", 15), m(6, "app-invoice-job-details", 16)(7, "hr", 17)(8, "app-invoice-signature", 18), a()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.outsourceJob == null ? null : e.outsourceJob.id) && (e.printOptions == null ? null : e.printOptions.qr_code) && (e.outsourceJob == null ? null : e.outsourceJob.qr_code)), n(), s("dateTime", e.outsourceJob.created_at)("title", e.formatMessage("outsource_delivery_challan") + " : " + (e.outsourceJob == null ? null : e.outsourceJob.id)), n(), g(e.outsourceJob != null && e.outsourceJob.vendor ? 5 : -1), n(), s("job", e.job), n(2), s("entityId", e.outsourceJob == null ? null : e.outsourceJob.id)("entityType", e.entityType)
    }
}
var Ht = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.generalSettingDataService = f(B), this.userSessionService = f(dt), this.activatedRouter = f(O), this.isEmployee = this.userSessionService.isEmployee(), this.statusIconTypeList = U, this.ENTITIES = k, this.entityType = this.ENTITIES.OUTSOURCED_JOB.name, this.printOptions = null
        }
        ngOnInit() {
            this.printOptions = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject(), this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.outsourceJobDeliveryChallan(e).subscribe({
                        next: i => {
                            this.account = i.tenant, console.log(this.account), this.outsourceJob = i.outsource_job, this.job = i.outsource_job.job
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-outsource-delivery-challan"]
                ],
                standalone: !1,
                decls: 14,
                vars: 14,
                consts: [
                    [1, "container-fluid"],
                    [1, "container-fluid", "mt-2", "mb-3"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-start", 3, "iconType", "statusId"],
                    [1, "title-text", "float-start"],
                    [1, "d-flex", "justify-content-end"],
                    [3, "entityId", "entityName"],
                    [1, "mx-1", 3, "jobId"],
                    [3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton", "isVisibleThermalPrint"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", "background-row"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [1, "row", "background-row", "mt-1"],
                    [3, "job"],
                    [1, "invoice-hr"],
                    [3, "entityId", "entityType"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "clearfix"],
                    [1, "row", "ps-3"],
                    [1, "col-sm-4", "col-md-4", "col-lg-4"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold"],
                    [1, "px-1"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div")(2, "div", 1)(3, "div", 2)(4, "div", 3), m(5, "app-job-status-tag", 4), r(6, "span", 5), c(7), a(), r(8, "div", 6), p(9, Pi, 1, 2, "app-send-whats-app-btn", 7), m(10, "app-job-btn", 8)(11, "app-print-button", 9)(12, "app-share-btn", 10), a()()()(), p(13, Ei, 9, 8, "div", 11), a()()), i & 2 && (n(5), s("iconType", o.statusIconTypeList.TITLE)("statusId", o.job == null ? null : o.job.status_id), n(2), _(" ", o.job == null ? null : o.job.job_number, " "), n(2), g(o.isEmployee ? 9 : -1), n(), s("jobId", o.job == null ? null : o.job.id), n(), s("entityId", o.outsourceJob == null ? null : o.outsourceJob.id)("entityName", o.ENTITIES.OUTSOURCED_JOB.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.outsourceJob != null && o.outsourceJob.id))("isVisibleThermalPrint", !1), n(), s("entityId", o.outsourceJob == null ? null : o.outsourceJob.id)("entityType", o.ENTITIES.OUTSOURCED_JOB.name)("isSignedApi", !0), n(), g(o.job ? 13 : -1))
                },
                dependencies: [Z, A, z, N, $, ht, Pt, V, q, xt, vt],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Ii(t, d) {
    if (t & 1 && (r(0, "div", 14)(1, "span", 15), c(2), a(), r(3, "span", 16), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("payment_mode")), n(3), _("", e.bulkPayment.payment_type.name, " ")
    }
}

function ki(t, d) {
    if (t & 1 && (r(0, "div", 14)(1, "span", 15), c(2), a(), r(3, "span", 16), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.bulkPayment.cheque_number ? e.formatMessage("payment_cheque_number") : e.formatMessage("common_transaction_id")), n(3), _("", e.bulkPayment.cheque_number ? e.bulkPayment.cheque_number : e.bulkPayment.transaction_id, " ")
    }
}

function ji(t, d) {
    if (t & 1 && (m(0, "app-currency-symbol"), c(1)), t & 2) {
        let e = l(2);
        n(), _(" ", e.bulkPayment.amount, " ")
    }
}

function Di(t, d) {
    if (t & 1 && (r(0, "div", 14)(1, "span", 15), c(2), a(), r(3, "span", 16), c(4, ":"), a(), c(5), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("received_by")), n(3), _("", e.bulkPayment.created_by.name, " ")
    }
}

function Ai(t, d) {
    if (t & 1 && (r(0, "div", 3)(1, "span", 15), c(2), a(), r(3, "span", 16), c(4, ":"), a(), m(5, "span", 20), M(6, "safe"), a()), t & 2) {
        let e = l(2);
        n(2), u(e.formatMessage("common_comment")), n(3), s("innerHTML", I(6, 2, e.bulkPayment.comment, "html"), F)
    }
}

function Ni(t, d) {
    if (t & 1 && (r(0, "div", 7)(1, "div", 2)(2, "div", 3), m(3, "app-invoice-header", 8)(4, "app-invoice-title", 9)(5, "app-invoice-customer-detail", 10), r(6, "div", 11)(7, "div", 3)(8, "h5", 12), c(9), a(), r(10, "div", 13), p(11, Ii, 6, 2, "div", 14), p(12, ki, 6, 2, "div", 14), r(13, "div", 14)(14, "span", 15), c(15), a(), r(16, "span", 16), c(17, ":"), a(), p(18, ji, 2, 1), a(), r(19, "div", 14)(20, "span", 15), c(21), a(), r(22, "span", 16), c(23, ":"), a(), c(24), M(25, "dateFormat"), a(), p(26, Di, 6, 2, "div", 14), p(27, Ai, 7, 5, "div", 3), a()()(), r(28, "div", 17)(29, "div", 3), m(30, "app-payment-entity-print-table", 18)(31, "app-payment-summary-table", 19), a()()()()()), t & 2) {
        let e = l();
        n(3), s("account", e.account)("qrCode", (e.bulkPayment == null ? null : e.bulkPayment.id) && (e.printSettings == null ? null : e.printSettings.qr_code) && (e.bulkPayment == null ? null : e.bulkPayment.qr_code)), n(), s("dateTime", e.bulkPayment == null ? null : e.bulkPayment.created_at)("title", e.formatMessage("bulk_payment_invoice")), n(), s("user", e.bulkPayment.user), n(4), u(e.formatMessage("payment_mode")), n(2), g(e.bulkPayment.payment_type.name ? 11 : -1), n(), g(e.bulkPayment.transaction_id ? 12 : -1), n(3), u(e.formatMessage("amount")), n(3), g(e.bulkPayment.amount ? 18 : -1), n(3), u(e.formatMessage("received_on")), n(3), _("", I(25, 17, e.bulkPayment.created_at, "datetime"), " "), n(2), g(e.bulkPayment.created_by.name ? 26 : -1), n(), g(e.bulkPayment.comment ? 27 : -1), n(3), s("bulkPayment", e.bulkPayment)("columns", e.paymentEntityTableColumns), n(), s("bulkPayment", e.bulkPayment)
    }
}
var Gt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.generalSettingDataService = f(B), this.ENTITIES = k, this.entityType = this.ENTITIES.BULK_PAYMENT.name, this.isEditMode = !0, this.dateTime = new Date, this.summaryRows = Ce, this.paymentEntityTableColumns = [{
                dataField: "paymentable.paymentable",
                caption: x("entity_number")
            }, {
                dataField: "paymentable_type",
                caption: x("entity_type")
            }, {
                dataField: "amount",
                caption: x("amount_paid"),
                dataType: "number",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }], this.printSettings = this.generalSettingDataService.getGeneralSettingBySettingType(D.PRINT_SETTINGS) ? ? E.getEmptyObject()
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.bulkPaymentReceipt(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.bulkPayment = i.bulk_payment
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.log(e)
                }
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-bulk-payment-receipt"]
                ],
                standalone: !1,
                decls: 8,
                vars: 9,
                consts: [
                    [1, "container-fluid", "px-1", 3, "ngClass"],
                    [1, "container-fluid", "mb-2", "px-1"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "float-end", "d-flex", "justify-content-end"],
                    [3, "entityId", "entityName", "isSignedApi", "isVisiblePrintButton"],
                    [1, "ms-1", 3, "entityId", "entityType", "isSignedApi"],
                    ["id", "print-section", 1, "container-fluid", "px-1"],
                    [3, "account", "qrCode"],
                    [3, "dateTime", "title"],
                    [3, "user"],
                    [1, "row", "background-row"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "row", "ps-3"],
                    [1, "col-sm-6", "col-md-6", "col-lg-6"],
                    [1, "fw-bold"],
                    [1, "px-1"],
                    [1, "row", "mt-2"],
                    [3, "bulkPayment", "columns"],
                    [3, "bulkPayment"],
                    [1, "d-inline-block", 3, "innerHTML"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4), m(5, "app-print-button", 5)(6, "app-share-btn", 6), a()()()(), p(7, Ni, 32, 20, "div", 7), a()), i & 2 && (s("ngClass", o.isMobileDevice ? "vh-100" : ""), n(5), s("entityId", o.bulkPayment == null ? null : o.bulkPayment.id)("entityName", o.ENTITIES.BULK_PAYMENT.name)("isSignedApi", !0)("isVisiblePrintButton", !!(o.bulkPayment != null && o.bulkPayment.id)), n(), s("entityId", o.bulkPayment == null ? null : o.bulkPayment.id)("entityType", o.ENTITIES.BULK_PAYMENT.name)("isSignedApi", !0), n(), g(o.bulkPayment ? 7 : -1))
                },
                dependencies: [H, A, N, R, V, Et, It, q, ae, W, he],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();
var Yt = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-routes"]
                ],
                standalone: !1,
                decls: 1,
                vars: 0,
                template: function(i, o) {
                    i & 1 && m(0, "router-outlet")
                },
                dependencies: [st],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Bi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "app-dx-outline-button", 9), T("onClickEvent", function() {
            v(e);
            let o = l();
            return b(o.save())
        }), a()
    }
}

function Ri(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "app-dx-outline-button", 10), T("onClickEvent", function() {
            v(e);
            let o = l();
            return b(o.setEditMode())
        }), a()
    }
}

function zi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "dx-check-box", 20), T("onValueChanged", function(o) {
            v(e);
            let C = l().$implicit,
                w = l(2);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a()
    }
    if (t & 2) {
        let e = l().$implicit,
            i = l(2);
        s("disabled", !i.isEditMode)("value", e.sms)
    }
}

function Ji(t, d) {
    if (t & 1 && (r(0, "div"), c(1), a()), t & 2) {
        let e = l(3);
        n(), _(" ", e.formatMessage("notification_preferences_na"), " ")
    }
}

function Ui(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "dx-check-box", 21), T("onValueChanged", function(o) {
            v(e);
            let C = l().$implicit,
                w = l(2);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a()
    }
    if (t & 2) {
        let e = l().$implicit,
            i = l(2);
        s("disabled", !i.isEditMode)("text", i.formatMessage("common_in_app"))("value", e.in_app)
    }
}

function Li(t, d) {
    if (t & 1 && (r(0, "div"), c(1), a()), t & 2) {
        let e = l(3);
        n(), _(" ", e.formatMessage("notification_preferences_na"), " ")
    }
}

function Fi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "dx-check-box", 22), T("onValueChanged", function(o) {
            v(e);
            let C = l().$implicit,
                w = l(2);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a()
    }
    if (t & 2) {
        let e = l().$implicit,
            i = l(2);
        s("disabled", !i.isEditMode)("value", e.whats_app)
    }
}

function Qi(t, d) {
    if (t & 1 && (r(0, "div"), c(1), a()), t & 2) {
        let e = l(3);
        n(), _(" ", e.formatMessage("notification_preferences_na"), " ")
    }
}

function Hi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "div", 13)(1, "div", 14)(2, "strong"), c(3), a()(), r(4, "div", 15), p(5, zi, 1, 2, "dx-check-box", 16)(6, Ji, 2, 1, "div"), r(7, "dx-check-box", 17), T("onValueChanged", function(o) {
            let C = v(e).$implicit,
                w = l(2);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a(), p(8, Ui, 1, 3, "dx-check-box", 18)(9, Li, 2, 1, "div"), p(10, Fi, 1, 2, "dx-check-box", 19)(11, Qi, 2, 1, "div"), a()()
    }
    if (t & 2) {
        let e = d.$implicit,
            i = l().$implicit,
            o = l();
        s("ngClass", o.isMobileDevice ? "gap-4" : ""), n(3), u(e.notification_event.display_name), n(2), g(i.key !== "Reports" ? 5 : 6), n(2), s("disabled", !o.isEditMode)("value", e.email), n(), g(i.key !== "Reports" ? 8 : 9), n(2), g(i.key !== "Reports" ? 10 : 11)
    }
}

function Gi(t, d) {
    if (t & 1 && (r(0, "div", 8)(1, "h5", 11), c(2), M(3, "titlecase"), a(), r(4, "div", 12), de(5, Hi, 12, 7, "div", 13, le), a()()), t & 2) {
        let e = d.$implicit;
        n(2), _(" ", _e(3, 1, e.key)), n(3), me(e.value)
    }
}
var $t = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRouter = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.toastNotificationService = f(fe), this.changedPreferences = [], this.originalPreferences = [], this.isEditMode = !0
        }
        ngOnInit() {
            this.activatedRouter.queryParams.subscribe({
                next: e => {
                    this.loaderService.show(), this.service.getNotificationPreferences(e).subscribe({
                        next: i => {
                            this.account = i.tenant, this.notificationPreferences = i.notification_preference, this.saveNotificationPreferencesSignature = new URL(i.save_notification_preferences).searchParams.get("signature")
                        },
                        error: i => {
                            console.error(i)
                        }
                    }).add(() => {
                        this.loaderService.hide()
                    })
                },
                error: e => {
                    console.error(e)
                }
            })
        }
        save() {
            if (this.changedPreferences.length > 0) {
                let e = {
                    signature: this.saveNotificationPreferencesSignature,
                    notification_preferences: this.changedPreferences
                };
                console.log("Payload being sent:", e), this.service.saveNotificationPreferences(e).subscribe({
                    next: i => {
                        this.toastNotificationService.success("notification_preferences_save_success")
                    },
                    error: i => {
                        this.toastNotificationService.error("notification_save_changes_error", i.error.message, {
                            disableTimeOut: !0
                        })
                    }
                }).add(() => {
                    this.changedPreferences = [], this.isEditMode = !1
                })
            } else this.toastNotificationService.success("notification_no_changes"), this.isEditMode = !1
        }
        cancel() {
            this.isEditMode = !1
        }
        setEditMode() {
            this.isEditMode = !0
        }
        onNotificationPreferenceChange(e, i) {
            let o = e.value,
                C = re({}, i);
            e.component.option("text") === "Sms" ? i.sms = o : e.component.option("text") === "Mail" ? i.email = o : e.component.option("text") === "In App" ? i.in_app = o : e.component.option("text") === "Whats App" && (i.whats_app = o), this.trackChanges(C, i)
        }
        trackChanges(e, i) {
            this.originalPreferences.findIndex(Y => Y.id === i.id) === -1 && this.originalPreferences.push(re({}, e));
            let C = this.originalPreferences.find(Y => Y.id === i.id) || e,
                w = C.sms !== i.sms || C.email !== i.email || C.in_app !== i.in_app || C.whats_app !== i.whats_app,
                G = this.changedPreferences.findIndex(Y => Y.id === i.id);
            if (!w && G !== -1) {
                this.changedPreferences.splice(G, 1);
                return
            }
            w && (G !== -1 ? this.changedPreferences[G] = {
                id: i.id,
                sms: i.sms,
                email: i.email,
                in_app: i.in_app,
                whats_app: i.whats_app
            } : this.changedPreferences.push({
                id: i.id,
                sms: i.sms,
                email: i.email,
                in_app: i.in_app,
                whats_app: i.whats_app
            }))
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-notification-preferences"]
                ],
                standalone: !1,
                decls: 12,
                vars: 5,
                consts: [
                    [1, "card", "m-2"],
                    [1, "row", "mt-2", "card-body"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["buttonType", "default", "text", "common_save", 1, "float-end"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    [3, "title"],
                    [3, "message"],
                    [1, "row"],
                    [1, "background-row"],
                    ["buttonType", "default", "text", "common_save", 1, "float-end", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "accordion-body"],
                    [1, "row", "my-4", 3, "ngClass"],
                    [1, "col-sm-5", "col-md-5", "col-lg-5"],
                    [1, "col-sm-7", "col-md-7", "col-lg-7", "d-flex", "justify-content-between"],
                    ["text", "SMS", 3, "disabled", "value"],
                    ["text", "Mail", 3, "onValueChanged", "disabled", "value"],
                    [3, "disabled", "text", "value"],
                    ["text", "WhatsApp", 3, "disabled", "value"],
                    ["text", "SMS", 3, "onValueChanged", "disabled", "value"],
                    [3, "onValueChanged", "disabled", "text", "value"],
                    ["text", "WhatsApp", 3, "onValueChanged", "disabled", "value"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), p(3, Bi, 1, 0, "app-dx-outline-button", 3)(4, Ri, 1, 0, "app-dx-outline-button", 4), a(), m(5, "app-section-title", 5)(6, "app-alert-panel", 6), r(7, "div", 7)(8, "div", 2), de(9, Gi, 7, 3, "div", 8, le), M(11, "keyvalue"), a()()()()), i & 2 && (n(3), g(o.isEditMode ? 3 : 4), n(2), s("title", o.formatMessage("notification_preferences_title")), n(), s("message", o.formatMessage("notification_preferences_description")), n(3), me(_e(11, 3, o.notificationPreferences)))
                },
                dependencies: [H, Le, Qe, oe, Oe, ze, Je],
                styles: ["p[_ngcontent-%COMP%]{font-size:13px}.business-invoice-info[_ngcontent-%COMP%]{max-width:40%;min-width:0;overflow-wrap:anywhere;word-break:break-word}@media screen and (min-width:960px){.business-invoice-info[_ngcontent-%COMP%]{max-width:40%}}@media screen and (max-width:600px){.business-invoice-info[_ngcontent-%COMP%]{max-width:100%}}.title-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.title-section[_ngcontent-%COMP%]{padding:0 1rem}.signature-container[_ngcontent-%COMP%]{margin-top:2rem}.label-align[_ngcontent-%COMP%]{font-size:larger}.background-row[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]{margin-top:1rem;border-radius:2px;background-color:var(--section-header-color);font-size:1rem!important}.background-row[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-bottom:0}.background-row[_ngcontent-%COMP%]   ol[_ngcontent-%COMP%]{padding-left:1rem}.border-box[_ngcontent-%COMP%]{border:1px solid #3498db;border-radius:5px}.border-box[_ngcontent-%COMP%]   .customer-signature[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{text-decoration:underline;padding-right:1rem}.invoice-hr[_ngcontent-%COMP%]{height:2px;margin-top:0;background-color:gray}.invoice-hr-dotted[_ngcontent-%COMP%]{border-top:4px dashed #808080}.span-hr-dotted[_ngcontent-%COMP%]   .fa-scissors[_ngcontent-%COMP%]{font-size:22px;position:relative;top:-25px;left:6px}.invoice-header-hr[_ngcontent-%COMP%]{height:2px;margin-bottom:25px;background-color:gray}.invoice-logo[_ngcontent-%COMP%]{max-width:350px;max-height:104px;object-fit:contain}.fs-custom-12[_ngcontent-%COMP%], table[_ngcontent-%COMP%]{font-size:12px}.print[_ngcontent-%COMP%]{display:none}.disable-signature[_ngcontent-%COMP%]{pointer-events:none}.signature-pad-container[_ngcontent-%COMP%]{flex-direction:row}@media screen and (max-width:768px){.signature-pad-container[_ngcontent-%COMP%]{flex-direction:column}}.table-content[_ngcontent-%COMP%]{word-break:break-word;width:100%;line-break:anywhere}@media print{.card[_ngcontent-%COMP%]{border:none}.print[_ngcontent-%COMP%]{display:block}.no-print[_ngcontent-%COMP%]{display:none}a[_ngcontent-%COMP%]{color:#000}}.fw-custom-450[_ngcontent-%COMP%]{font-weight:450}.job-detail-custom-margin[_ngcontent-%COMP%]{margin-bottom:.5px}.signature-name-height[_ngcontent-%COMP%]{height:8em!important}.verified[_ngcontent-%COMP%]{width:5em;height:5em}"]
            })
        }
    }
    return t
})();

function Yi(t, d) {
    if (t & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3), c(4), a()()()()), t & 2) {
        let e = l();
        n(4), u(e.errorMessage)
    }
}

function Wi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "app-dx-outline-button", 13), T("onClickEvent", function() {
            v(e);
            let o = l(3);
            return b(o.save())
        }), a()
    }
}

function $i(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "app-dx-outline-button", 14), T("onClickEvent", function() {
            v(e);
            let o = l(3);
            return b(o.setEditMode())
        }), a()
    }
}

function Ki(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "dx-check-box", 24), T("onValueChanged", function(o) {
            v(e);
            let C = l().$implicit,
                w = l(4);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a()
    }
    if (t & 2) {
        let e = l().$implicit,
            i = l(4);
        s("disabled", !i.isEditMode)("value", e.sms)
    }
}

function Xi(t, d) {
    if (t & 1 && (r(0, "div"), c(1), a()), t & 2) {
        let e = l(5);
        n(), _(" ", e.formatMessage("notification_preferences_na"), " ")
    }
}

function Zi(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "dx-check-box", 25), T("onValueChanged", function(o) {
            v(e);
            let C = l().$implicit,
                w = l(4);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a()
    }
    if (t & 2) {
        let e = l().$implicit,
            i = l(4);
        s("disabled", !i.isEditMode)("text", i.formatMessage("common_in_app"))("value", e.in_app)
    }
}

function eo(t, d) {
    if (t & 1 && (r(0, "div"), c(1), a()), t & 2) {
        let e = l(5);
        n(), _(" ", e.formatMessage("notification_preferences_na"), " ")
    }
}

function to(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "dx-check-box", 26), T("onValueChanged", function(o) {
            v(e);
            let C = l().$implicit,
                w = l(4);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a()
    }
    if (t & 2) {
        let e = l().$implicit,
            i = l(4);
        s("disabled", !i.isEditMode)("value", e.whats_app)
    }
}

function no(t, d) {
    if (t & 1 && (r(0, "div"), c(1), a()), t & 2) {
        let e = l(5);
        n(), _(" ", e.formatMessage("notification_preferences_na"), " ")
    }
}

function io(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "div", 17)(1, "div", 18)(2, "strong"), c(3), a()(), r(4, "div", 19), p(5, Ki, 1, 2, "dx-check-box", 20)(6, Xi, 2, 1, "div"), r(7, "dx-check-box", 21), T("onValueChanged", function(o) {
            let C = v(e).$implicit,
                w = l(4);
            return b(w.onNotificationPreferenceChange(o, C))
        }), a(), p(8, Zi, 1, 3, "dx-check-box", 22)(9, eo, 2, 1, "div"), p(10, to, 1, 2, "dx-check-box", 23)(11, no, 2, 1, "div"), a()()
    }
    if (t & 2) {
        let e = d.$implicit,
            i = l().$implicit,
            o = l(3);
        s("ngClass", o.isMobileDevice ? "gap-4" : ""), n(3), u(e.notification_event.display_name), n(2), g(i.key !== "Reports" ? 5 : 6), n(2), s("disabled", !o.isEditMode)("value", e.email), n(), g(i.key !== "Reports" ? 8 : 9), n(2), g(i.key !== "Reports" ? 10 : 11)
    }
}

function oo(t, d) {
    if (t & 1 && (r(0, "div", 12)(1, "h5", 15), c(2), M(3, "titlecase"), a(), r(4, "div", 16), de(5, io, 12, 7, "div", 17, le), a()()), t & 2) {
        let e = d.$implicit;
        n(2), _(" ", _e(3, 1, e.key)), n(3), me(e.value)
    }
}

function ao(t, d) {
    if (t & 1 && (r(0, "div", 4)(1, "div", 5)(2, "div", 6), p(3, Wi, 1, 0, "app-dx-outline-button", 7)(4, $i, 1, 0, "app-dx-outline-button", 8), a(), m(5, "app-section-title", 9)(6, "app-alert-panel", 10), r(7, "div", 11)(8, "div", 6), de(9, oo, 7, 3, "div", 12, le), M(11, "keyvalue"), a()()()()), t & 2) {
        let e = l(2);
        n(3), g(e.isEditMode ? 3 : 4), n(2), s("title", e.formatMessage("notification_preferences_title")), n(), s("message", e.formatMessage("notification_preferences_description")), n(3), me(_e(11, 3, e.notificationPreferences))
    }
}

function ro(t, d) {
    if (t & 1 && (r(0, "div", 30), m(1, "i", 31), c(2, " You have been successfully unsubscribed from our emails. "), a(), r(3, "p", 32), c(4, "Email: "), r(5, "strong"), c(6), a()()), t & 2) {
        let e = l(3);
        n(6), u(e.email)
    }
}

function co(t, d) {
    if (t & 1 && (r(0, "p", 33), c(1, "You are already unsubscribed from our emails."), a(), r(2, "p", 32), c(3, "Email: "), r(4, "strong"), c(5), a()()), t & 2) {
        let e = l(3);
        n(5), u(e.email)
    }
}

function so(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "p", 34), c(1, " Click the button below to unsubscribe from emails by "), r(2, "strong"), c(3), a(), c(4, ". "), a(), r(5, "p", 35), c(6, "Email: "), r(7, "strong"), c(8), a()(), r(9, "app-save-btn", 36), T("saveBtnClick", function() {
            v(e);
            let o = l(3);
            return b(o.unsubscribeAll())
        }), a()
    }
    if (t & 2) {
        let e = l(3);
        n(3), u(e.tenantName), n(5), u(e.email), n(), s("useSubmitBehavior", !1)
    }
}

function lo(t, d) {
    if (t & 1 && (r(0, "div", 0)(1, "div", 1)(2, "div", 2), m(3, "i", 27), r(4, "h4", 28), c(5, "Email Unsubscribe"), a(), p(6, ro, 7, 1), p(7, co, 6, 1), p(8, so, 10, 3), a(), r(9, "div", 29), c(10), a()()()), t & 2) {
        let e = l(2);
        n(6), g(e.saveSuccess ? 6 : -1), n(), g(e.alreadyUnsubscribed && !e.saveSuccess ? 7 : -1), n(), g(!e.alreadyUnsubscribed && !e.saveSuccess ? 8 : -1), n(2), _(" \xA9 ", e.tenantName, " ")
    }
}

function mo(t, d) {
    if (t & 1 && (p(0, ao, 12, 5, "div", 4), p(1, lo, 11, 4, "div", 0)), t & 2) {
        let e = l();
        g(e.notificationPreferences ? 0 : -1), n(), g(e.notificationPreferences ? -1 : 1)
    }
}
var Kt = (() => {
    class t {
        constructor(e, i) {
            this.service = e, this.loaderService = i, this.formatMessage = x, this.activatedRoute = f(O), this.isMobileDevice = f(J).isMobileDevice(), this.toastNotificationService = f(fe), this.email = "", this.token = "", this.tenantName = "", this.alreadyUnsubscribed = !1, this.errorMessage = "", this.loaded = !1, this.isEditMode = !0, this.saveSuccess = !1, this.changedPreferences = [], this.originalPreferences = []
        }
        ngOnInit() {
            this.activatedRoute.queryParams.subscribe({
                next: e => {
                    this.email = e.email || "", this.token = e.token || "", this.loadStatus()
                }
            })
        }
        loadStatus() {
            this.loaderService.show(), this.service.getEmailUnsubscribeStatus({
                email: this.email,
                token: this.token
            }).subscribe({
                next: e => {
                    this.tenantName = e.tenant_name, this.alreadyUnsubscribed = e.already_unsubscribed, e.notification_preferences && (this.notificationPreferences = e.notification_preferences), this.loaded = !0
                },
                error: e => {
                    this.errorMessage = e ? .error ? .error || "Invalid unsubscribe link.", this.loaded = !0
                }
            }).add(() => this.loaderService.hide())
        }
        save() {
            this.changedPreferences.length > 0 ? (this.loaderService.show(), this.service.processEmailUnsubscribe({
                email: this.email,
                token: this.token,
                notification_preferences: this.changedPreferences
            }).subscribe({
                next: () => {
                    this.toastNotificationService.success("notification_preferences_save_success"), this.saveSuccess = !0
                },
                error: e => {
                    this.toastNotificationService.error("notification_save_changes_error", e.error ? .message || e.error ? .error, {
                        disableTimeOut: !0
                    })
                }
            }).add(() => {
                this.changedPreferences = [], this.isEditMode = !1, this.loaderService.hide()
            })) : (this.toastNotificationService.success("notification_no_changes"), this.isEditMode = !1)
        }
        unsubscribeAll() {
            this.loaderService.show(), this.service.processEmailUnsubscribe({
                email: this.email,
                token: this.token
            }).subscribe({
                next: () => {
                    this.saveSuccess = !0, this.alreadyUnsubscribed = !0
                },
                error: e => {
                    this.errorMessage = e ? .error ? .error || "Something went wrong. Please try again."
                }
            }).add(() => this.loaderService.hide())
        }
        setEditMode() {
            this.isEditMode = !0
        }
        onNotificationPreferenceChange(e, i) {
            let o = e.value,
                C = re({}, i);
            e.component.option("text") === "Sms" ? i.sms = o : e.component.option("text") === "Mail" ? i.email = o : e.component.option("text") === "In App" ? i.in_app = o : e.component.option("text") === "Whats App" && (i.whats_app = o), this.trackChanges(C, i)
        }
        trackChanges(e, i) {
            this.originalPreferences.findIndex(Y => Y.id === i.id) === -1 && this.originalPreferences.push(re({}, e));
            let C = this.originalPreferences.find(Y => Y.id === i.id) || e,
                w = C.sms !== i.sms || C.email !== i.email || C.in_app !== i.in_app || C.whats_app !== i.whats_app,
                G = this.changedPreferences.findIndex(Y => Y.id === i.id);
            if (!w && G !== -1) {
                this.changedPreferences.splice(G, 1);
                return
            }
            if (w) {
                let Y = {
                    id: i.id,
                    sms: i.sms,
                    email: i.email,
                    in_app: i.in_app,
                    whats_app: i.whats_app
                };
                G !== -1 ? this.changedPreferences[G] = Y : this.changedPreferences.push(Y)
            }
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)(h(y), h(S))
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-email-unsubscribe"]
                ],
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    [1, "d-flex", "justify-content-center", "align-items-center", 2, "min-height", "80vh"],
                    [1, "card", "shadow", 2, "max-width", "450px", "width", "100%"],
                    [1, "card-body", "p-4", "text-center"],
                    [1, "alert", "alert-danger"],
                    [1, "card", "m-2"],
                    [1, "row", "mt-2", "card-body"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["buttonType", "default", "text", "common_save", 1, "float-end"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    [3, "title"],
                    [3, "message"],
                    [1, "row"],
                    [1, "background-row"],
                    ["buttonType", "default", "text", "common_save", 1, "float-end", 3, "onClickEvent"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [1, "fw-custom-450", "p-2", "section-header"],
                    [1, "accordion-body"],
                    [1, "row", "my-4", 3, "ngClass"],
                    [1, "col-sm-5", "col-md-5", "col-lg-5"],
                    [1, "col-sm-7", "col-md-7", "col-lg-7", "d-flex", "justify-content-between"],
                    ["text", "SMS", 3, "disabled", "value"],
                    ["text", "Mail", 3, "onValueChanged", "disabled", "value"],
                    [3, "disabled", "text", "value"],
                    ["text", "WhatsApp", 3, "disabled", "value"],
                    ["text", "SMS", 3, "onValueChanged", "disabled", "value"],
                    [3, "onValueChanged", "disabled", "text", "value"],
                    ["text", "WhatsApp", 3, "onValueChanged", "disabled", "value"],
                    [1, "fa", "fa-envelope-open", 2, "font-size", "3rem", "color", "#6c757d"],
                    [1, "mt-3", "mb-3"],
                    [1, "card-footer", "text-center", "text-muted", "small"],
                    [1, "alert", "alert-success"],
                    [1, "fa", "fa-check-circle", "me-1"],
                    [1, "text-muted", "small"],
                    [1, "text-muted", "mb-3"],
                    [1, "text-muted", "mb-2"],
                    [1, "text-muted", "small", "mb-3"],
                    ["saveText", "Unsubscribe from All Emails", "stylingMode", "contained", "type", "danger", 1, "w-100", 3, "saveBtnClick", "useSubmitBehavior"]
                ],
                template: function(i, o) {
                    i & 1 && (p(0, Yi, 5, 1, "div", 0), p(1, mo, 2, 2)), i & 2 && (g(o.errorMessage ? 0 : -1), n(), g(o.loaded && !o.errorMessage ? 1 : -1))
                },
                dependencies: [H, _t, Le, Qe, oe, Oe, ze, Je],
                encapsulation: 2
            })
        }
    }
    return t
})();
var po = ["signaturePad"],
    go = ["otpInput"],
    uo = ["confirmationOtpInput"];

function _o(t, d) {
    if (t & 1 && (r(0, "p", 20), c(1), a()), t & 2) {
        let e = l(2);
        n(), u(e.otpError)
    }
}

function Co(t, d) {
    t & 1 && m(0, "i", 27)
}

function fo(t, d) {
    t & 1 && m(0, "i", 28)
}

function ho(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "div", 4)(1, "div", 9)(2, "div", 10), m(3, "i", 11), a(), r(4, "h1", 12), c(5), a(), r(6, "p", 13), c(7), a(), r(8, "div", 14)(9, "span", 15), c(10), a(), r(11, "span", 16), c(12), a()(), r(13, "div", 17)(14, "label", 18), c(15), a(), r(16, "app-otp-input", 19, 0), T("otpChange", function(o) {
            v(e);
            let C = l();
            return b(C.onOtpChange(o))
        })("otpComplete", function(o) {
            v(e);
            let C = l();
            return b(C.onOtpComplete(o))
        }), a(), p(18, _o, 2, 1, "p", 20), a(), r(19, "div", 21), m(20, "i", 22), r(21, "div", 23)(22, "span", 24), c(23), a(), r(24, "span", 25), c(25), a()()(), r(26, "dx-button", 26), T("onClick", function() {
            v(e);
            let o = l();
            return b(o.verifyOtp())
        }), p(27, Co, 1, 0, "i", 27), p(28, fo, 1, 0, "i", 28), a(), r(29, "p", 29), c(30), r(31, "a", 30), T("click", function() {
            v(e);
            let o = l();
            return b(o.resendOtp())
        }), c(32), a()()(), r(33, "p", 31), c(34), a()()
    }
    if (t & 2) {
        let e = l();
        n(5), u(e.formatMessage("secure_access")), n(2), u(e.formatMessage("enter_6_digit_code")), n(3), u(e.formatMessage("job_reference")), n(2), u((e.verificationData == null ? null : e.verificationData.job_number) || "-"), n(3), u(e.formatMessage("verification_code")), n(), s("hasError", !!e.otpError)("autoSubmit", !0), n(2), g(e.otpError ? 18 : -1), n(5), u(e.formatMessage("link_secure_time_limited")), n(2), ue("", e.formatMessage("expires_in"), " ", e.expiresIn), n(), s("text", e.formatMessage("verify_and_continue"))("disabled", e.isVerifyingOtp || e.getOtpCode().length !== 6), n(), g(e.isVerifyingOtp ? -1 : 27), n(), g(e.isVerifyingOtp ? 28 : -1), n(2), _(" ", e.formatMessage("didnt_receive_code"), " "), n(), Be("disabled", e.isResendingOtp), n(), _(" ", e.formatMessage("resend"), " "), n(2), u(e.formatMessage("protected_by_encryption"))
    }
}

function vo(t, d) {
    if (t & 1 && (m(0, "iframe", 39), M(1, "safe")), t & 2) {
        let e = l(2);
        s("src", I(1, 1, e.scanHtmlBlobUrl, "resourceUrl"), it)
    }
}

function bo(t, d) {
    if (t & 1 && (r(0, "div", 40), m(1, "i", 41), r(2, "span"), c(3), a()()), t & 2) {
        let e = l(2);
        n(3), _("", e.formatMessage("loading"), "...")
    }
}

function xo(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "div", 5)(1, "div", 9)(2, "div", 32)(3, "div", 33), m(4, "i", 34), r(5, "span"), c(6, "This is a read-only preview. Please review your recovered data carefully before proceeding."), a()(), r(7, "div", 35)(8, "p", 36), c(9), a(), r(10, "dx-button", 37), T("onClick", function() {
            v(e);
            let o = l();
            return b(o.proceedToConfirmation())
        }), m(11, "i", 27), a()()(), r(12, "div", 38), p(13, vo, 2, 4, "iframe", 39), p(14, bo, 4, 1, "div", 40), a()()()
    }
    if (t & 2) {
        let e = l();
        n(9), u(e.formatMessage("review_data_proceed")), n(), s("text", e.formatMessage("continue_to_confirmation")), n(3), g(e.scanHtmlBlobUrl && !e.isLoadingScanHtml ? 13 : -1), n(), g(e.isLoadingScanHtml || !e.scanHtmlBlobUrl ? 14 : -1)
    }
}

function Po(t, d) {
    if (t & 1 && (r(0, "p", 20), c(1), a()), t & 2) {
        let e = l(2);
        n(), u(e.confirmationOtpError)
    }
}

function Mo(t, d) {
    if (t & 1 && (r(0, "div", 63)(1, "pre"), c(2), a()()), t & 2) {
        let e = l(2);
        n(2), u(e.termsContent)
    }
}

function Oo(t, d) {
    if (t & 1) {
        let e = j();
        r(0, "div", 6)(1, "div", 9)(2, "h1", 12), c(3), a(), r(4, "p", 13), c(5), a(), r(6, "div", 42)(7, "dx-check-box", 43), je("valueChange", function(o) {
            v(e);
            let C = l();
            return ke(C.hasVerifiedData, o) || (C.hasVerifiedData = o), b(o)
        }), a(), r(8, "p", 44), c(9), a()(), r(10, "div", 45)(11, "label", 46), c(12), a(), r(13, "dx-text-area", 47), je("valueChange", function(o) {
            v(e);
            let C = l();
            return ke(C.comments, o) || (C.comments = o), b(o)
        }), a()(), r(14, "div", 48)(15, "label", 49), c(16), a(), r(17, "div", 50), m(18, "app-signature-pad", 51, 1), a(), r(20, "div", 52)(21, "span", 53), c(22), a(), r(23, "a", 54), T("click", function() {
            v(e);
            let o = l();
            return b(o.clearSignature())
        }), m(24, "i", 55), c(25), a()()(), r(26, "div", 56)(27, "label", 49), c(28), a(), r(29, "app-otp-input", 57, 2), T("otpChange", function(o) {
            v(e);
            let C = l();
            return b(C.onConfirmationOtpChange(o))
        }), a(), r(31, "p", 58), c(32), a(), p(33, Po, 2, 1, "p", 20), a(), r(34, "div", 59)(35, "div", 60), T("click", function() {
            v(e);
            let o = l();
            return b(o.toggleTerms())
        }), m(36, "i", 61), r(37, "span"), c(38), a(), m(39, "i", 62), a(), p(40, Mo, 3, 1, "div", 63), a(), r(41, "div", 64), m(42, "i", 11), r(43, "div", 65)(44, "span", 66), c(45), a(), r(46, "p", 67), c(47), a()()(), r(48, "div", 68)(49, "a", 69), T("click", function() {
            v(e);
            let o = l();
            return b(o.backToReview())
        }), c(50), a(), r(51, "dx-button", 70), T("onClick", function() {
            v(e);
            let o = l();
            return b(o.submitVerification())
        }), a()()()()
    }
    if (t & 2) {
        let e = l();
        n(3), u(e.formatMessage("confirmation_signature")), n(2), u(e.formatMessage("review_confirm_verification")), n(2), Ie("value", e.hasVerifiedData), s("text", e.formatMessage("i_have_verified_data")), n(2), u(e.formatMessage("i_confirm_reviewed_files")), n(3), u(e.formatMessage("comments_optional")), n(), Ie("value", e.comments), s("height", 100)("placeholder", e.formatMessage("add_notes_feedback")), n(3), u(e.formatMessage("digital_signature")), n(2), s("options", e.signaturePadOptions), n(4), u(e.formatMessage("sign_using_mouse_touch")), n(3), _(" ", e.formatMessage("clear"), " "), n(3), u(e.formatMessage("verification_code")), n(), s("hasError", !!e.confirmationOtpError)("autoSubmit", !1), n(3), u(e.formatMessage("enter_code_sent_email")), n(), g(e.confirmationOtpError ? 33 : -1), n(5), u(e.formatMessage("view_terms_conditions")), n(), Be("fa-chevron-down", !e.showTerms)("fa-chevron-up", e.showTerms), n(), g(e.showTerms ? 40 : -1), n(5), u(e.formatMessage("secure_and_binding")), n(2), u(e.formatMessage("signature_encrypted_stored")), n(3), _(" ", e.formatMessage("back_to_data"), " "), n(), s("text", e.formatMessage("submit_verification"))("disabled", e.isSubmitting || !e.canSubmit())
    }
}

function So(t, d) {
    if (t & 1 && (r(0, "div", 7)(1, "div", 71)(2, "div", 72), m(3, "i", 73), a(), r(4, "h1", 12), c(5), a(), r(6, "p", 13), c(7), a(), r(8, "div", 74)(9, "div", 75)(10, "span", 76), c(11), a(), r(12, "span", 77), c(13), a()(), r(14, "div", 75)(15, "span", 76), c(16), a(), r(17, "span", 78), m(18, "i", 79), c(19), a()()(), r(20, "p", 80), c(21), a()()()), t & 2) {
        let e = l();
        n(5), u(e.formatMessage("verification_complete")), n(2), u(e.formatMessage("verification_success_message")), n(4), u(e.formatMessage("job_reference")), n(2), u(e.verificationData == null ? null : e.verificationData.job_number), n(3), u(e.formatMessage("verification_status")), n(3), _(" ", e.formatMessage("verified"), " "), n(2), u(e.formatMessage("confirmation_email_will_be_sent"))
    }
}
var Xt = (() => {
    class t {
        constructor() {
            this.formatMessage = x, this.activatedRoute = f(O), this.loaderService = f(S), this.toastService = f(fe), this.signedApiService = f(y), this.isMobileDevice = f(J).isMobileDevice(), this.currentStep = "otp", this.token = "", this.sessionToken = "", this.verificationData = null, this.scanHtmlContent = "", this.scanHtmlBlobUrl = null, this.isLoadingScanHtml = !1, this.otpValue = "", this.isVerifyingOtp = !1, this.isResendingOtp = !1, this.otpError = "", this.expiresIn = "", this.searchQuery = "", this.filteredScanData = [], this.hasVerifiedData = !1, this.comments = "", this.confirmationOtpValue = "", this.confirmationOtpError = "", this.showTerms = !1, this.isSubmitting = !1, this.signaturePadOptions = {
                maxWidth: 2,
                canvasWidth: this.isMobileDevice ? 290 : 400,
                canvasHeight: this.isMobileDevice ? 150 : 200,
                penColor: "#0000FF"
            }, this.termsContent = `By verifying this data recovery, you confirm that:
1. You have reviewed the recovered files and folders
2. The data matches your expectations
3. You authorize BytePhase to proceed with final delivery
4. This verification is legally binding`, this.currentYear = new Date().getFullYear()
        }
        ngOnInit() {
            this.activatedRoute.queryParams.subscribe({
                next: e => {
                    this.token = e.token || "", this.token && this.loadVerificationInfo()
                }
            })
        }
        loadVerificationInfo() {
            this.loaderService.show(), this.signedApiService.getDataVerificationInfo({
                token: this.token
            }).subscribe({
                next: e => {
                    if (this.loaderService.hide(), e ? .data) {
                        if (this.verificationData = e.data, this.filteredScanData = this.verificationData.scan_data || [], this.startExpiryCountdown(), this.verificationData.is_verified) {
                            this.currentStep = "success";
                            return
                        }
                        this.sendOtp()
                    }
                },
                error: e => {
                    this.loaderService.hide(), this.toastService.error(e.error ? .message || "verification_link_invalid")
                }
            })
        }
        startExpiryCountdown() {
            if (!this.verificationData ? .expires_at) return;
            let e = () => {
                let i = new Date().getTime(),
                    C = new Date(this.verificationData.expires_at).getTime() - i;
                if (C <= 0) {
                    this.expiresIn = this.formatMessage("link_expired"), clearInterval(this.expiryInterval);
                    return
                }
                let w = Math.floor(C / (1e3 * 60 * 60)),
                    G = Math.floor(C % (1e3 * 60 * 60) / (1e3 * 60));
                this.expiresIn = `${w} ${this.formatMessage("hours")}, ${G} ${this.formatMessage("minutes")}`
            };
            e(), this.expiryInterval = setInterval(e, 6e4)
        }
        onOtpChange(e) {
            this.otpValue = e, this.otpError = ""
        }
        onOtpComplete(e) {
            this.otpValue = e, this.otpError = "", this.verifyOtp()
        }
        getOtpCode() {
            return this.otpValue
        }
        sendOtp() {
            this.isResendingOtp = !0, this.signedApiService.sendVerificationOtp({
                token: this.token
            }).subscribe({
                next: () => {
                    this.isResendingOtp = !1, this.toastService.success(this.formatMessage("otp_sent_to_email"))
                },
                error: e => {
                    this.isResendingOtp = !1, this.toastService.error(e.error ? .message || this.formatMessage("otp_send_failed"))
                }
            })
        }
        resendOtp() {
            this.otpValue = "", this.otpError = "", this.otpInputComponent ? .clear(), this.sendOtp()
        }
        verifyOtp() {
            let e = this.getOtpCode();
            if (e.length !== 6) {
                this.otpError = this.formatMessage("enter_complete_otp");
                return
            }
            this.isVerifyingOtp = !0, this.signedApiService.verifyDataVerificationOtp({
                token: this.token,
                otp: e
            }).subscribe({
                next: i => {
                    this.isVerifyingOtp = !1, i ? .data ? .session_token ? (this.sessionToken = i.data.session_token, i.data.scan_data && (this.verificationData.scan_data = i.data.scan_data, this.filteredScanData = i.data.scan_data), i.data.statistics && (this.verificationData.statistics = i.data.statistics), this.currentStep = "review", this.loadScanHtml()) : this.otpError = this.formatMessage("invalid_otp")
                },
                error: i => {
                    this.isVerifyingOtp = !1, this.otpError = i.error ? .message || this.formatMessage("invalid_otp")
                }
            })
        }
        loadScanHtml() {
            this.isLoadingScanHtml = !0, this.signedApiService.getScanHtml(this.token, this.sessionToken).subscribe({
                next: e => {
                    this.scanHtmlContent = e;
                    let i = new Blob([e], {
                        type: "text/html"
                    });
                    this.scanHtmlBlobUrl = URL.createObjectURL(i), this.isLoadingScanHtml = !1
                },
                error: () => {
                    this.isLoadingScanHtml = !1, this.toastService.error(this.formatMessage("failed_to_load_scan_data"))
                }
            })
        }
        onSearchChange() {
            if (!this.searchQuery.trim()) {
                this.filteredScanData = this.verificationData ? .scan_data || [];
                return
            }
            let e = this.searchQuery.toLowerCase();
            this.filteredScanData = this.filterItems(this.verificationData ? .scan_data || [], e)
        }
        filterItems(e, i) {
            let o = [];
            for (let C of e) {
                let w = C.items || C.children;
                if (C.name.toLowerCase().includes(i)) o.push(Xe(re({}, C), {
                    expanded: !0
                }));
                else if (w) {
                    let G = this.filterItems(w, i);
                    G.length > 0 && o.push(Xe(re({}, C), {
                        items: G,
                        expanded: !0
                    }))
                }
            }
            return o
        }
        toggleFolder(e) {
            e.expanded = !e.expanded
        }
        expandAll() {
            this.setExpandedState(this.filteredScanData, !0)
        }
        collapseAll() {
            this.setExpandedState(this.filteredScanData, !1)
        }
        setExpandedState(e, i) {
            for (let o of e) {
                (o.isDirectory || o.type === "folder") && (o.expanded = i);
                let C = o.items || o.children;
                C && this.setExpandedState(C, i)
            }
        }
        formatBytes(e) {
            if (e === 0) return "0 B";
            let i = 1024,
                o = ["B", "KB", "MB", "GB", "TB"],
                C = Math.floor(Math.log(e) / Math.log(i));
            return parseFloat((e / Math.pow(i, C)).toFixed(2)) + " " + o[C]
        }
        proceedToConfirmation() {
            this.currentStep = "confirmation", this.sendConfirmationOtp()
        }
        backToReview() {
            this.currentStep = "review"
        }
        onConfirmationOtpChange(e) {
            this.confirmationOtpValue = e, this.confirmationOtpError = ""
        }
        getConfirmationOtpCode() {
            return this.confirmationOtpValue
        }
        sendConfirmationOtp() {
            this.signedApiService.sendConfirmationOtp({
                token: this.token,
                session_token: this.sessionToken
            }).subscribe({
                next: () => {
                    this.toastService.success(this.formatMessage("confirmation_otp_sent"))
                },
                error: e => {
                    this.toastService.error(e.error ? .message || this.formatMessage("otp_send_failed"))
                }
            })
        }
        clearSignature() {
            this.signaturePad ? .clear()
        }
        isSignatureEmpty() {
            return this.signaturePad ? .isEmpty() ? ? !0
        }
        toggleTerms() {
            this.showTerms = !this.showTerms
        }
        canSubmit() {
            return this.hasVerifiedData && !this.isSignatureEmpty() && this.getConfirmationOtpCode().length === 6
        }
        submitVerification() {
            if (!this.canSubmit()) {
                if (!this.hasVerifiedData) {
                    this.toastService.error(this.formatMessage("please_confirm_data_verification"));
                    return
                }
                if (this.isSignatureEmpty()) {
                    this.toastService.error(this.formatMessage("please_add_signature"));
                    return
                }
                if (this.getConfirmationOtpCode().length !== 6) {
                    this.confirmationOtpError = this.formatMessage("enter_complete_otp");
                    return
                }
                return
            }
            this.isSubmitting = !0;
            let e = {
                token: this.token,
                session_token: this.sessionToken,
                otp: this.getConfirmationOtpCode(),
                signature: this.signaturePad.toDataURL(),
                comments: this.comments,
                confirmed: this.hasVerifiedData
            };
            this.signedApiService.submitDataVerification(e).subscribe({
                next: () => {
                    this.isSubmitting = !1, this.currentStep = "success"
                },
                error: i => {
                    this.isSubmitting = !1, i.error ? .message ? .includes("OTP") ? this.confirmationOtpError = i.error.message : this.toastService.error(i.error ? .message || this.formatMessage("verification_submit_failed"))
                }
            })
        }
        ngOnDestroy() {
            this.expiryInterval && clearInterval(this.expiryInterval), this.scanHtmlBlobUrl && URL.revokeObjectURL(this.scanHtmlBlobUrl)
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275cmp = P({
                type: t,
                selectors: [
                    ["app-signed-data-verification"]
                ],
                viewQuery: function(i, o) {
                    if (i & 1 && Pe(po, 5)(go, 5)(uo, 5), i & 2) {
                        let C;
                        pe(C = ge()) && (o.signaturePad = C.first), pe(C = ge()) && (o.otpInputComponent = C.first), pe(C = ge()) && (o.confirmationOtpInputComponent = C.first)
                    }
                },
                standalone: !1,
                decls: 10,
                vars: 9,
                consts: [
                    ["otpInput", ""],
                    ["signaturePad", ""],
                    ["confirmationOtpInput", ""],
                    [1, "verification-container"],
                    [1, "verification-card"],
                    [1, "verification-card", "data-review-card"],
                    [1, "verification-card", "confirmation-card"],
                    [1, "verification-card", "success-card"],
                    [1, "page-footer"],
                    [1, "card-content"],
                    [1, "lock-icon"],
                    [1, "fa-thin", "fa-lock"],
                    [1, "card-title"],
                    [1, "card-subtitle"],
                    [1, "job-reference-box"],
                    [1, "reference-label"],
                    [1, "reference-value"],
                    [1, "otp-section"],
                    [1, "otp-label"],
                    [3, "otpChange", "otpComplete", "hasError", "autoSubmit"],
                    [1, "error-text"],
                    [1, "security-info-box"],
                    [1, "fa-thin", "fa-shield-check"],
                    [1, "security-content"],
                    [1, "security-title"],
                    [1, "security-expiry"],
                    ["type", "default", "stylingMode", "contained", 1, "verify-btn", 3, "onClick", "text", "disabled"],
                    [1, "fa-thin", "fa-arrow-right", "ms-2"],
                    [1, "fa-thin", "fa-spinner", "fa-spin", "ms-2"],
                    [1, "resend-link"],
                    ["href", "javascript:void(0)", 3, "click"],
                    [1, "encryption-notice"],
                    [1, "card-header-actions"],
                    [1, "readonly-notice"],
                    [1, "fa-thin", "fa-eye"],
                    [1, "card-footer"],
                    [1, "footer-text"],
                    ["type", "default", "stylingMode", "contained", 1, "continue-btn", 3, "onClick", "text"],
                    [1, "scan-viewer-container"],
                    ["frameborder", "0", "title", "Directory Scan Viewer", 1, "scan-viewer-iframe", 3, "src"],
                    [1, "scan-viewer-loading"],
                    [1, "fa-thin", "fa-spinner", "fa-spin"],
                    [1, "confirmation-checkbox"],
                    [3, "valueChange", "value", "text"],
                    [1, "checkbox-description"],
                    [1, "comments-section"],
                    [1, "section-label"],
                    [3, "valueChange", "value", "height", "placeholder"],
                    [1, "signature-section"],
                    [1, "section-label", "required"],
                    [1, "signature-pad-wrapper"],
                    [3, "options"],
                    [1, "signature-footer"],
                    [1, "signature-hint"],
                    ["href", "javascript:void(0)", 1, "clear-link", 3, "click"],
                    [1, "fa-thin", "fa-times"],
                    [1, "confirmation-otp-section"],
                    [3, "otpChange", "hasError", "autoSubmit"],
                    [1, "otp-hint"],
                    [1, "terms-section"],
                    [1, "terms-header", 3, "click"],
                    [1, "fa-thin", "fa-file-lines"],
                    [1, "fa-thin"],
                    [1, "terms-content"],
                    [1, "security-notice"],
                    [1, "notice-content"],
                    [1, "notice-title"],
                    [1, "notice-description"],
                    [1, "card-footer", "confirmation-footer"],
                    ["href", "javascript:void(0)", 1, "back-link", 3, "click"],
                    ["type", "default", "stylingMode", "contained", "icon", "fa-thin fa-check", 1, "submit-btn", 3, "onClick", "text", "disabled"],
                    [1, "card-content", "text-center"],
                    [1, "success-icon"],
                    [1, "fa-thin", "fa-circle-check"],
                    [1, "success-info-box"],
                    [1, "info-row"],
                    [1, "info-label"],
                    [1, "info-value"],
                    [1, "info-value", "verified"],
                    [1, "fa-thin", "fa-check-circle"],
                    [1, "success-note"]
                ],
                template: function(i, o) {
                    i & 1 && (r(0, "div", 3), p(1, ho, 35, 20, "div", 4), p(2, xo, 15, 4, "div", 5), p(3, Oo, 52, 29, "div", 6), p(4, So, 22, 7, "div", 7), r(5, "footer", 8)(6, "p"), c(7), a(), r(8, "p"), c(9), a()()()), i & 2 && (Be("review-mode", o.currentStep === "review"), n(), g(o.currentStep === "otp" ? 1 : -1), n(), g(o.currentStep === "review" ? 2 : -1), n(), g(o.currentStep === "confirmation" ? 3 : -1), n(), g(o.currentStep === "success" ? 4 : -1), n(3), ue("\xA9 ", o.currentYear, " BytePhase. ", o.formatMessage("all_rights_reserved")), n(2), u(o.formatMessage("secure_verification_portal")))
                },
                dependencies: [St, kt, pt, Oe, ft, W],
                styles: ['.verification-container[_ngcontent-%COMP%]{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem 1rem;background-color:#f8fafc;transition:background-color .2s ease}.verification-container[_ngcontent-%COMP%]:has(.data-review-card){justify-content:flex-start;padding:.5rem;gap:0}.dark-theme[_nghost-%COMP%]   .verification-container[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .verification-container[_ngcontent-%COMP%]{background-color:#10172a}.verification-container.review-mode[_ngcontent-%COMP%]{justify-content:flex-start;padding:.5rem;gap:0}.verification-card[_ngcontent-%COMP%]{width:100%;max-width:500px;background-color:#fff;border-radius:16px;box-shadow:0 4px 24px #00000014;overflow:hidden;transition:background-color .2s ease,box-shadow .2s ease}.verification-card.data-review-card[_ngcontent-%COMP%]{max-width:98vw;width:100%;border-radius:12px;flex:1;display:flex;flex-direction:column}@media(max-width:768px){.verification-card.data-review-card[_ngcontent-%COMP%]{max-width:100%;border-radius:0}}@media(min-width:1400px){.verification-card.data-review-card[_ngcontent-%COMP%]{max-width:1400px}}.verification-card.confirmation-card[_ngcontent-%COMP%]{max-width:700px}.dark-theme[_nghost-%COMP%]   .verification-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .verification-card[_ngcontent-%COMP%]{background-color:#1e293b;box-shadow:0 4px 24px #0000004d}.card-content[_ngcontent-%COMP%]{padding:2.5rem 2rem}@media(max-width:480px){.card-content[_ngcontent-%COMP%]{padding:1.5rem 1rem}}.data-review-card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%]{padding:1rem;display:flex;flex-direction:column;height:calc(100vh - 100px);max-height:none}@media(max-width:768px){.data-review-card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%]{padding:.75rem;height:calc(100vh - 80px)}}.lock-icon[_ngcontent-%COMP%]{width:80px;height:80px;margin:0 auto 1.5rem;background-color:#e0e7ff;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background-color .2s ease}.lock-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:2rem;color:#4f46e5}.dark-theme[_nghost-%COMP%]   .lock-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .lock-icon[_ngcontent-%COMP%]{background-color:#4f46e533}.dark-theme[_nghost-%COMP%]   .lock-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .lock-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#818cf8}.success-icon[_ngcontent-%COMP%]{width:100px;height:100px;margin:0 auto 1.5rem;background-color:#dcfce7;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background-color .2s ease}.success-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:3rem;color:#16a34a}.dark-theme[_nghost-%COMP%]   .success-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-icon[_ngcontent-%COMP%]{background-color:#16a34a33}.dark-theme[_nghost-%COMP%]   .success-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#4ade80}.card-title[_ngcontent-%COMP%]{font-size:1.5rem;font-weight:700;color:#1f2937;text-align:center;margin:0 0 .5rem;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .card-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .card-title[_ngcontent-%COMP%]{color:#fff}.card-subtitle[_ngcontent-%COMP%]{font-size:.9375rem;color:#6b7280;text-align:center;margin:0 0 2rem;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .card-subtitle[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .card-subtitle[_ngcontent-%COMP%]{color:#a0aec0}.job-reference-box[_ngcontent-%COMP%]{background-color:#f3f4f6;border-radius:12px;padding:1.25rem;text-align:center;margin-bottom:2rem;transition:background-color .2s ease}.job-reference-box[_ngcontent-%COMP%]   .reference-label[_ngcontent-%COMP%]{display:block;font-size:.8125rem;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.25rem;transition:color .2s ease}.job-reference-box[_ngcontent-%COMP%]   .reference-value[_ngcontent-%COMP%]{display:block;font-size:1.25rem;font-weight:700;color:#1f2937;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .job-reference-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .job-reference-box[_ngcontent-%COMP%]{background-color:#1e293b}.dark-theme[_nghost-%COMP%]   .job-reference-box[_ngcontent-%COMP%]   .reference-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .job-reference-box[_ngcontent-%COMP%]   .reference-label[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .job-reference-box[_ngcontent-%COMP%]   .reference-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .job-reference-box[_ngcontent-%COMP%]   .reference-value[_ngcontent-%COMP%]{color:#fff}.otp-section[_ngcontent-%COMP%]{margin-bottom:1.5rem}.otp-label[_ngcontent-%COMP%]{display:block;font-size:.875rem;font-weight:500;color:#374151;text-align:center;margin-bottom:.75rem;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .otp-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .otp-label[_ngcontent-%COMP%]{color:#a0aec0}.otp-inputs[_ngcontent-%COMP%]{display:flex;justify-content:center;gap:.625rem}.otp-inputs.small[_ngcontent-%COMP%]{justify-content:flex-start}.otp-inputs.small[_ngcontent-%COMP%]   .otp-input[_ngcontent-%COMP%]{width:40px;height:48px;font-size:1.125rem}.otp-input[_ngcontent-%COMP%]{width:50px;height:60px;border:2px solid #e5e7eb;border-radius:12px;font-size:1.5rem;font-weight:600;text-align:center;color:#1f2937;background-color:#fff;outline:none;transition:border-color .2s,box-shadow .2s,background-color .2s,color .2s}.otp-input[_ngcontent-%COMP%]:focus{border-color:#4f46e5;box-shadow:0 0 0 3px #4f46e51a}.otp-input.error[_ngcontent-%COMP%]{border-color:#ef4444}@media(max-width:480px){.otp-input[_ngcontent-%COMP%]{width:42px;height:52px;font-size:1.25rem}}.dark-theme[_nghost-%COMP%]   .otp-input[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .otp-input[_ngcontent-%COMP%]{background-color:#1e293b;border-color:#334155;color:#fff}.dark-theme[_nghost-%COMP%]   .otp-input[_ngcontent-%COMP%]:focus, .dark-theme   [_nghost-%COMP%]   .otp-input[_ngcontent-%COMP%]:focus{border-color:#818cf8;box-shadow:0 0 0 3px #818cf833}.otp-hint[_ngcontent-%COMP%]{font-size:.8125rem;color:#6b7280;margin-top:.5rem;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .otp-hint[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .otp-hint[_ngcontent-%COMP%]{color:#a0aec0}.error-text[_ngcontent-%COMP%]{font-size:.8125rem;color:#ef4444;text-align:center;margin-top:.5rem}.security-info-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:.75rem;background-color:#eff6ff;border-radius:12px;padding:1rem;margin-bottom:1.5rem;transition:background-color .2s ease}.security-info-box[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]{font-size:1.25rem;color:#3b82f6;flex-shrink:0}.security-info-box[_ngcontent-%COMP%]   .security-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.125rem}.security-info-box[_ngcontent-%COMP%]   .security-title[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600;color:#1e40af;transition:color .2s ease}.security-info-box[_ngcontent-%COMP%]   .security-expiry[_ngcontent-%COMP%]{font-size:.8125rem;color:#3b82f6;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%]{background-color:#3b82f626}.dark-theme[_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%] > i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%]   .security-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%]   .security-title[_ngcontent-%COMP%]{color:#93c5fd}.dark-theme[_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%]   .security-expiry[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-info-box[_ngcontent-%COMP%]   .security-expiry[_ngcontent-%COMP%]{color:#60a5fa}.verify-btn[_ngcontent-%COMP%], .continue-btn[_ngcontent-%COMP%], .submit-btn[_ngcontent-%COMP%]{width:100%;margin-bottom:1rem}.verify-btn[_ngcontent-%COMP%]     .dx-button, .continue-btn[_ngcontent-%COMP%]     .dx-button, .submit-btn[_ngcontent-%COMP%]     .dx-button{height:52px;border-radius:12px;font-size:1rem;font-weight:600;background-color:#4f46e5;border-color:#4f46e5}.verify-btn[_ngcontent-%COMP%]     .dx-button:hover:not(.dx-state-disabled), .continue-btn[_ngcontent-%COMP%]     .dx-button:hover:not(.dx-state-disabled), .submit-btn[_ngcontent-%COMP%]     .dx-button:hover:not(.dx-state-disabled){background-color:#4338ca}.verify-btn[_ngcontent-%COMP%]     .dx-button.dx-state-disabled, .continue-btn[_ngcontent-%COMP%]     .dx-button.dx-state-disabled, .submit-btn[_ngcontent-%COMP%]     .dx-button.dx-state-disabled{background-color:#e5e7eb;border-color:#e5e7eb;color:#9ca3af}.resend-link[_ngcontent-%COMP%]{text-align:center;font-size:.875rem;color:#6b7280;transition:color .2s ease}.resend-link[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]{color:#4f46e5;text-decoration:none;font-weight:500}.resend-link[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover{text-decoration:underline}.resend-link[_ngcontent-%COMP%]   a.disabled[_ngcontent-%COMP%]{color:#9ca3af;pointer-events:none}.dark-theme[_nghost-%COMP%]   .resend-link[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .resend-link[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .resend-link[_ngcontent-%COMP%]   a[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .resend-link[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]{color:#818cf8}.dark-theme[_nghost-%COMP%]   .resend-link[_ngcontent-%COMP%]   a.disabled[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .resend-link[_ngcontent-%COMP%]   a.disabled[_ngcontent-%COMP%]{color:#6b7280}.encryption-notice[_ngcontent-%COMP%]{text-align:center;font-size:.8125rem;color:#9ca3af;padding:1rem;border-top:1px solid #f3f4f6;margin:0;transition:color .2s ease,border-color .2s ease}.dark-theme[_nghost-%COMP%]   .encryption-notice[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .encryption-notice[_ngcontent-%COMP%]{color:#a0aec0;border-top-color:#334155}.stats-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.5rem}@media(max-width:480px){.stats-grid[_ngcontent-%COMP%]{grid-template-columns:1fr}}.stat-card[_ngcontent-%COMP%]{padding:1.25rem;border-radius:12px;text-align:center;transition:background-color .2s ease}.stat-card.stat-folders[_ngcontent-%COMP%]{background-color:#eff6ff}.stat-card.stat-folders[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#1d4ed8}.stat-card.stat-folders[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#3b82f6}.stat-card.stat-files[_ngcontent-%COMP%]{background-color:#f0fdf4}.stat-card.stat-files[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#15803d}.stat-card.stat-files[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#22c55e}.stat-card.stat-size[_ngcontent-%COMP%]{background-color:#faf5ff}.stat-card.stat-size[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#7e22ce}.stat-card.stat-size[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#a855f7}.stat-card[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{display:block;font-size:1.5rem;font-weight:700;margin-bottom:.25rem}.stat-card[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{font-size:.8125rem;font-weight:500;text-transform:uppercase;letter-spacing:.5px}.dark-theme[_nghost-%COMP%]   .stat-card.stat-folders[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-folders[_ngcontent-%COMP%]{background-color:#3b82f626}.dark-theme[_nghost-%COMP%]   .stat-card.stat-folders[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-folders[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .stat-card.stat-folders[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-folders[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#93c5fd}.dark-theme[_nghost-%COMP%]   .stat-card.stat-files[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-files[_ngcontent-%COMP%]{background-color:#22c55e26}.dark-theme[_nghost-%COMP%]   .stat-card.stat-files[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-files[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#4ade80}.dark-theme[_nghost-%COMP%]   .stat-card.stat-files[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-files[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#86efac}.dark-theme[_nghost-%COMP%]   .stat-card.stat-size[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-size[_ngcontent-%COMP%]{background-color:#a855f726}.dark-theme[_nghost-%COMP%]   .stat-card.stat-size[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-size[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%]{color:#c084fc}.dark-theme[_nghost-%COMP%]   .stat-card.stat-size[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .stat-card.stat-size[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%]{color:#d8b4fe}.scan-viewer-container[_ngcontent-%COMP%]{border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;margin-bottom:1rem;background-color:#fff;flex:1;display:flex;flex-direction:column;transition:border-color .2s ease,background-color .2s ease}.dark-theme[_nghost-%COMP%]   .scan-viewer-container[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .scan-viewer-container[_ngcontent-%COMP%]{border-color:#334155;background-color:#1e293b}.scan-viewer-iframe[_ngcontent-%COMP%]{width:100%;height:calc(100vh - 220px);min-height:500px;border:none;display:block;flex:1}@media(max-width:768px){.scan-viewer-iframe[_ngcontent-%COMP%]{height:calc(100vh - 180px);min-height:400px}}.scan-viewer-loading[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;height:300px;color:#6b7280;gap:.75rem;transition:color .2s ease}.scan-viewer-loading[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.5rem;color:#4f46e5}.scan-viewer-loading[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.9375rem}.dark-theme[_nghost-%COMP%]   .scan-viewer-loading[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .scan-viewer-loading[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .scan-viewer-loading[_ngcontent-%COMP%]   i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .scan-viewer-loading[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:#818cf8}.search-box[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem;padding:.875rem 1rem;background-color:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;margin-bottom:1rem;transition:background-color .2s ease,border-color .2s ease}.search-box[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]{font-size:1rem;color:#9ca3af}.search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{flex:1;border:none;background:transparent;font-size:.9375rem;color:#1f2937;outline:none;transition:color .2s ease}.search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder{color:#9ca3af}.dark-theme[_nghost-%COMP%]   .search-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-box[_ngcontent-%COMP%]{background-color:#1e293b;border-color:#334155}.dark-theme[_nghost-%COMP%]   .search-box[_ngcontent-%COMP%] > i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-box[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]{color:#6b7280}.dark-theme[_nghost-%COMP%]   .search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder, .dark-theme   [_nghost-%COMP%]   .search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder{color:#6b7280}.tree-actions[_ngcontent-%COMP%]{display:flex;gap:.5rem;margin-bottom:.75rem}.tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.35rem;padding:.5rem .75rem;background-color:#f3f4f6;border:1px solid #e5e7eb;border-radius:6px;font-size:.75rem;color:#374151;cursor:pointer;transition:all .15s}.tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]:hover{background-color:#e5e7eb}.tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.75rem}.dark-theme[_nghost-%COMP%]   .tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]{background-color:#1e293b;border-color:#334155;color:#a0aec0}.dark-theme[_nghost-%COMP%]   .tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .tree-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]:hover{background-color:#ffffff1a;color:#fff}.readonly-notice[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.5rem;padding:.625rem 1rem;background-color:#fef3c7;border-radius:8px;margin-top:.75rem;margin-bottom:0;font-size:.8125rem;color:#92400e;flex-shrink:0;transition:background-color .2s ease,color .2s ease}.readonly-notice[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{flex-shrink:0}.readonly-notice[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-weight:600}.dark-theme[_nghost-%COMP%]   .readonly-notice[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .readonly-notice[_ngcontent-%COMP%]{background-color:#fbbf2426;color:#fbbf24}.folder-tree[_ngcontent-%COMP%]{background-color:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;padding:1rem;max-height:350px;overflow-y:auto;margin-bottom:1.5rem;transition:background-color .2s ease,border-color .2s ease}.dark-theme[_nghost-%COMP%]   .folder-tree[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .folder-tree[_ngcontent-%COMP%]{background-color:#1e293b;border-color:#334155}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.5rem;padding:.5rem .25rem;cursor:pointer;border-radius:6px;transition:background-color .15s}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]:hover{background-color:#f3f4f6}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .expand-icon[_ngcontent-%COMP%]{font-size:.75rem;color:#9ca3af;transition:transform .2s;width:12px}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .expand-icon.expanded[_ngcontent-%COMP%]{transform:rotate(90deg)}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .fa-folder[_ngcontent-%COMP%]{color:#fbbf24}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .fa-file[_ngcontent-%COMP%]{color:#9ca3af}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .item-name[_ngcontent-%COMP%]{flex:1;font-size:.875rem;color:#374151;transition:color .2s ease}.tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .item-size[_ngcontent-%COMP%]{font-size:.75rem;color:#9ca3af}.dark-theme[_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]:hover{background-color:#ffffff0d}.dark-theme[_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .expand-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .expand-icon[_ngcontent-%COMP%]{color:#6b7280}.dark-theme[_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .item-name[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .item-name[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .item-size[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .tree-item[_ngcontent-%COMP%]   .tree-row[_ngcontent-%COMP%]   .item-size[_ngcontent-%COMP%]{color:#6b7280}.card-header-actions[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.5rem;margin-bottom:.5rem;flex-shrink:0}.card-header-actions[_ngcontent-%COMP%]   .readonly-notice[_ngcontent-%COMP%]{margin-top:0;margin-bottom:0}.card-header-actions[_ngcontent-%COMP%]   .card-footer[_ngcontent-%COMP%]{margin-top:0;padding-top:.5rem;border-top:none}.card-footer[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;padding-top:1rem;margin-top:.75rem;border-top:1px dashed #e5e7eb;gap:1rem;flex-shrink:0;transition:border-color .2s ease}@media(max-width:480px){.card-footer[_ngcontent-%COMP%]{flex-direction:column;text-align:center;padding-top:.75rem}}.card-footer[_ngcontent-%COMP%]   .footer-text[_ngcontent-%COMP%]{font-size:.8125rem;color:#6b7280;margin:0;transition:color .2s ease}.card-footer[_ngcontent-%COMP%]   .continue-btn[_ngcontent-%COMP%], .card-footer[_ngcontent-%COMP%]   .submit-btn[_ngcontent-%COMP%]{width:auto;margin:0}.card-footer[_ngcontent-%COMP%]   .continue-btn[_ngcontent-%COMP%]     .dx-button, .card-footer[_ngcontent-%COMP%]   .submit-btn[_ngcontent-%COMP%]     .dx-button{padding:0 1.5rem;height:44px}.dark-theme[_nghost-%COMP%]   .card-footer[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .card-footer[_ngcontent-%COMP%]{border-top-color:#334155}.dark-theme[_nghost-%COMP%]   .card-footer[_ngcontent-%COMP%]   .footer-text[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .card-footer[_ngcontent-%COMP%]   .footer-text[_ngcontent-%COMP%]{color:#a0aec0}.confirmation-checkbox[_ngcontent-%COMP%]{background-color:#f9fafb;border-radius:12px;padding:1rem;margin-bottom:1.5rem;transition:background-color .2s ease}.confirmation-checkbox[_ngcontent-%COMP%]     .dx-checkbox .dx-checkbox-text{font-size:.9375rem;font-weight:600;color:#1f2937;transition:color .2s ease}.confirmation-checkbox[_ngcontent-%COMP%]   .checkbox-description[_ngcontent-%COMP%]{font-size:.8125rem;color:#6b7280;margin:.5rem 0 0 1.75rem;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .confirmation-checkbox[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .confirmation-checkbox[_ngcontent-%COMP%]{background-color:#1e293b}.dark-theme[_nghost-%COMP%]   .confirmation-checkbox[_ngcontent-%COMP%]     .dx-checkbox .dx-checkbox-text, .dark-theme   [_nghost-%COMP%]   .confirmation-checkbox[_ngcontent-%COMP%]     .dx-checkbox .dx-checkbox-text{color:#fff}.dark-theme[_nghost-%COMP%]   .confirmation-checkbox[_ngcontent-%COMP%]   .checkbox-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .confirmation-checkbox[_ngcontent-%COMP%]   .checkbox-description[_ngcontent-%COMP%]{color:#a0aec0}.comments-section[_ngcontent-%COMP%], .signature-section[_ngcontent-%COMP%], .confirmation-otp-section[_ngcontent-%COMP%]{margin-bottom:1.5rem}.section-label[_ngcontent-%COMP%]{display:block;font-size:.875rem;font-weight:500;color:#374151;margin-bottom:.5rem;transition:color .2s ease}.section-label.required[_ngcontent-%COMP%]:after{content:" *";color:#ef4444}.dark-theme[_nghost-%COMP%]   .section-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .section-label[_ngcontent-%COMP%]{color:#a0aec0}.signature-pad-wrapper[_ngcontent-%COMP%]{border:2px solid #e5e7eb;border-radius:12px;overflow:hidden;background-color:#fff;transition:border-color .2s ease,background-color .2s ease;display:flex;justify-content:center;align-items:center}.signature-pad-wrapper[_ngcontent-%COMP%]     canvas{display:block}.dark-theme[_nghost-%COMP%]   .signature-pad-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .signature-pad-wrapper[_ngcontent-%COMP%]{border-color:#334155;background-color:#1e293b}.signature-footer[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;margin-top:.5rem}.signature-footer[_ngcontent-%COMP%]   .signature-hint[_ngcontent-%COMP%]{font-size:.8125rem;color:#6b7280;transition:color .2s ease}.signature-footer[_ngcontent-%COMP%]   .clear-link[_ngcontent-%COMP%]{font-size:.875rem;color:#4f46e5;text-decoration:none;display:flex;align-items:center;gap:.25rem}.signature-footer[_ngcontent-%COMP%]   .clear-link[_ngcontent-%COMP%]:hover{text-decoration:underline}.dark-theme[_nghost-%COMP%]   .signature-footer[_ngcontent-%COMP%]   .signature-hint[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .signature-footer[_ngcontent-%COMP%]   .signature-hint[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .signature-footer[_ngcontent-%COMP%]   .clear-link[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .signature-footer[_ngcontent-%COMP%]   .clear-link[_ngcontent-%COMP%]{color:#818cf8}.terms-section[_ngcontent-%COMP%]{border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;margin-bottom:1.5rem;transition:border-color .2s ease}.terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem;padding:1rem;background-color:#f9fafb;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color .2s ease}.terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]:first-child{color:#6b7280}.terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{flex:1;font-size:.9375rem;font-weight:500;color:#374151;transition:color .2s ease}.terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]:last-child{color:#9ca3af}.terms-section[_ngcontent-%COMP%]   .terms-content[_ngcontent-%COMP%]{padding:1rem;background-color:#fff;border-top:1px solid #e5e7eb;transition:background-color .2s ease,border-color .2s ease}.terms-section[_ngcontent-%COMP%]   .terms-content[_ngcontent-%COMP%]   pre[_ngcontent-%COMP%]{margin:0;font-family:inherit;font-size:.8125rem;color:#6b7280;white-space:pre-wrap;line-height:1.6;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]{border-color:#334155}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%]{background-color:#1e293b}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]:first-child, .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]:first-child{color:#9ca3af}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > span[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]:last-child, .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-header[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]:last-child{color:#6b7280}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-content[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-content[_ngcontent-%COMP%]{background-color:#1e293b;border-top-color:#334155}.dark-theme[_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-content[_ngcontent-%COMP%]   pre[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .terms-section[_ngcontent-%COMP%]   .terms-content[_ngcontent-%COMP%]   pre[_ngcontent-%COMP%]{color:#a0aec0}.security-notice[_ngcontent-%COMP%]{display:flex;gap:.75rem;padding:1rem;background-color:#eff6ff;border-radius:12px;margin-bottom:1.5rem;transition:background-color .2s ease}.security-notice[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]{font-size:1.25rem;color:#3b82f6;flex-shrink:0}.security-notice[_ngcontent-%COMP%]   .notice-content[_ngcontent-%COMP%]   .notice-title[_ngcontent-%COMP%]{display:block;font-size:.9375rem;font-weight:600;color:#1e40af;margin-bottom:.25rem;transition:color .2s ease}.security-notice[_ngcontent-%COMP%]   .notice-content[_ngcontent-%COMP%]   .notice-description[_ngcontent-%COMP%]{font-size:.8125rem;color:#3b82f6;margin:0;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%]{background-color:#3b82f626}.dark-theme[_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%] > i[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%] > i[_ngcontent-%COMP%]{color:#60a5fa}.dark-theme[_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%]   .notice-content[_ngcontent-%COMP%]   .notice-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%]   .notice-content[_ngcontent-%COMP%]   .notice-title[_ngcontent-%COMP%]{color:#93c5fd}.dark-theme[_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%]   .notice-content[_ngcontent-%COMP%]   .notice-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .security-notice[_ngcontent-%COMP%]   .notice-content[_ngcontent-%COMP%]   .notice-description[_ngcontent-%COMP%]{color:#60a5fa}.confirmation-footer[_ngcontent-%COMP%]   .back-link[_ngcontent-%COMP%]{font-size:.9375rem;font-weight:500;color:#374151;text-decoration:none;transition:color .2s ease}.confirmation-footer[_ngcontent-%COMP%]   .back-link[_ngcontent-%COMP%]:hover{text-decoration:underline}.dark-theme[_nghost-%COMP%]   .confirmation-footer[_ngcontent-%COMP%]   .back-link[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .confirmation-footer[_ngcontent-%COMP%]   .back-link[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .confirmation-footer[_ngcontent-%COMP%]   .back-link[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .confirmation-footer[_ngcontent-%COMP%]   .back-link[_ngcontent-%COMP%]:hover{color:#fff}.success-card[_ngcontent-%COMP%]   .card-content[_ngcontent-%COMP%]{text-align:center}.success-info-box[_ngcontent-%COMP%]{background-color:#f9fafb;border-radius:12px;padding:1.25rem;margin:2rem auto;max-width:300px;transition:background-color .2s ease}.success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]{display:flex;justify-content:space-between;padding:.5rem 0}.success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]:not(:last-child){border-bottom:1px solid #e5e7eb}.success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{font-size:.875rem;color:#6b7280;transition:color .2s ease}.success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600;color:#1f2937;transition:color .2s ease}.success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-value.verified[_ngcontent-%COMP%]{color:#16a34a;display:flex;align-items:center;gap:.375rem}.dark-theme[_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]{background-color:#1e293b}.dark-theme[_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]:not(:last-child), .dark-theme   [_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]:not(:last-child){border-bottom-color:#334155}.dark-theme[_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-label[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-value[_ngcontent-%COMP%]{color:#fff}.dark-theme[_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-value.verified[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-info-box[_ngcontent-%COMP%]   .info-row[_ngcontent-%COMP%]   .info-value.verified[_ngcontent-%COMP%]{color:#4ade80}.success-note[_ngcontent-%COMP%]{font-size:.875rem;color:#6b7280;margin-top:1.5rem;transition:color .2s ease}.dark-theme[_nghost-%COMP%]   .success-note[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .success-note[_ngcontent-%COMP%]{color:#a0aec0}.page-footer[_ngcontent-%COMP%]{margin-top:1rem;text-align:center;flex-shrink:0}.page-footer[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.75rem;color:#9ca3af;margin:.125rem 0;transition:color .2s ease}.data-review-card[_ngcontent-%COMP%] ~ .page-footer[_ngcontent-%COMP%]{margin-top:.5rem}.dark-theme[_nghost-%COMP%]   .page-footer[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .page-footer[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#6b7280}.text-center[_ngcontent-%COMP%]{text-align:center}[_nghost-%COMP%]{--current-year: "2024"}']
            })
        }
    }
    return t
})();
var yo = [{
        path: "",
        component: Yt,
        children: [{
            path: "jobsheet",
            component: Rt,
            title: "BytePhase Service | Job Sheet"
        }, {
            path: "jobQuotation",
            component: nt,
            title: "BytePhase Service | Service Quotations"
        }, {
            path: "quotation",
            component: nt,
            title: "BytePhase | Quotations"
        }, {
            path: "jobInvoice",
            component: Bt,
            title: "BytePhase Service | Invoices"
        }, {
            path: "payment",
            component: Jt,
            title: "BytePhase Payments | Receipt"
        }, {
            path: "sale",
            component: Ft,
            title: "BytePhase Sale | Invoice"
        }, {
            path: "purchase",
            component: Lt,
            title: "BytePhase Purchase | Invoice"
        }, {
            path: "jobDelivery",
            component: Nt,
            title: "BytePhase Services | Delivery"
        }, {
            path: "jobDiagnosis",
            component: Vt,
            title: "BytePhase Services | Diagnosis Report"
        }, {
            path: "bulkPaymentReceipt",
            component: Gt,
            title: "BytePhase Services | Bulk Payment Receipt"
        }, {
            path: "outsourceJobDeliveryChallan",
            component: Ht,
            title: "BytePhase Services | OutsourceJob Delivery Challan"
        }, {
            path: "amcContract",
            component: $e,
            title: "BytePhase Services | Signed AMC Contract"
        }, {
            path: "amcService",
            component: Qt,
            title: "BytePhase Services | Signed AMC Contract"
        }, {
            path: "notificationPreference",
            component: $t,
            title: "BytePhase Notification | Signed Notification Preferences"
        }, {
            path: "emailUnsubscribe",
            component: Kt,
            title: "BytePhase | Email Unsubscribe"
        }, {
            path: "verifyData",
            component: Xt,
            title: "BytePhase | Data Verification"
        }]
    }],
    Zt = (() => {
        class t {
            static {
                this.\u0275fac = function(i) {
                    return new(i || t)
                }
            }
            static {
                this.\u0275mod = qe({
                    type: t
                })
            }
            static {
                this.\u0275inj = Ve({
                    imports: [Ze.forChild(yo), Ze]
                })
            }
        }
        return t
    })();
var Es = (() => {
    class t {
        static {
            this.\u0275fac = function(i) {
                return new(i || t)
            }
        }
        static {
            this.\u0275mod = qe({
                type: t
            })
        }
        static {
            this.\u0275inj = Ve({
                imports: [ct, Zt, Te, At, $e]
            })
        }
    }
    return t
})();
export {
    Es as SignedRoutesModule
};