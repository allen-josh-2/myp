import {
    Dd as Pe,
    Ec as Me,
    L as se,
    M as R,
    Of as Fe,
    T as A,
    Ta as he,
    Va as xe,
    We as De,
    Zd as Ne,
    _b as Te,
    _d as L,
    aa as _e,
    ba as O,
    ca as fe,
    cb as ve,
    cd as Ie,
    e as E,
    ed as k,
    g as K,
    h as ee,
    ka as ue,
    lb as Ce,
    n as te,
    pb as ge,
    ph as Ae,
    r as ie,
    sb as Ee,
    t as oe,
    u as ne,
    ub as Se,
    vd as we,
    xg as Re,
    y as G,
    yc as be
} from "./chunk-DCKGQUHB.js";
import {
    $a as f,
    Ab as D,
    Ak as ye,
    Ec as J,
    Fa as r,
    Fh as S,
    Hg as pe,
    Ka as v,
    Na as g,
    Oa as I,
    Rd as le,
    Sa as w,
    Tc as $,
    Wa as Z,
    _a as _,
    _b as z,
    aa as W,
    ba as M,
    bc as j,
    ch as me,
    da as Y,
    ea as d,
    eb as a,
    fb as s,
    gb as l,
    ha as x,
    hb as c,
    hi as V,
    ia as y,
    je as U,
    n as H,
    pd as ae,
    qb as T,
    qd as re,
    sb as C,
    sd as F,
    ti as ce,
    ub as p,
    ui as de,
    vd as B,
    xk as m,
    yb as P,
    z as Q,
    zb as N
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import "./chunk-FBFWB55K.js";
var h = class {
    constructor(n) {
        return Object.assign(this, n)
    }
    static getForm(n) {
        return new G().group({
            id: [n.id || null],
            expense_date: [n.expense_date || new Date, [E.required]],
            category_id: [n.category_id || null, [E.required]],
            name: [n.name || null, [E.required]],
            description: [n.description || null],
            created_by: [n.created_by || null],
            custom_fields: Se.getFormArray(n.custom_fields),
            paymentable: new G().group({
                id: [n ? .paymentable ? .id || null],
                payment_type_id: [n ? .paymentable ? .payment_type_id || 1, E.required],
                amount: [n ? .paymentable ? .amount, E.required],
                transaction_id: [n ? .paymentable ? .transaction_id],
                cheque_number: [n ? .paymentable ? .cheque_number]
            }),
            attachments: [n.attachments || []]
        })
    }
};
var q = (() => {
    class t extends ce {
        constructor(e) {
            super(e, U), this.api = e, this.endpoint = U
        }
        exportToFile(e, o) {
            return this.api.exportToFile(this.endpoint + "/" + e, o)
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(Y(de))
            }
        }
        static {
            this.\u0275prov = W({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();
var je = () => [2, 4];

function Ge(t, n) {
    if (t & 1) {
        let e = T();
        s(0, "app-save-cancel-footer", 8), C("cancelClick", function() {
            x(e);
            let i = p(2);
            return y(i.cancel())
        })("saveClick", function() {
            x(e);
            let i = p(2);
            return y(i.save())
        }), l()
    }
    if (t & 2) {
        let e = p(2);
        a("isOnPopup", !1)("isVisibleHr", !1)("saveText", e.expenseId ? "common_save" : "common_create")
    }
}

function Be(t, n) {
    if (t & 1 && w(0, Ge, 1, 3, "app-save-cancel-footer", 7), t & 2) {
        let e = p();
        a("ngxPermissionsOnly", e.PERMISSION_LIST.EXPENSES_WRITE)
    }
}

function Ue(t, n) {
    if (t & 1) {
        let e = T();
        s(0, "app-dx-outline-button", 11), C("onClickEvent", function() {
            x(e);
            let i = p(3);
            return y(i.setEditMode())
        }), l()
    }
}

function Xe(t, n) {
    if (t & 1 && w(0, Ue, 1, 0, "app-dx-outline-button", 10), t & 2) {
        let e = p(2);
        a("ngxPermissionsOnly", e.PERMISSION_LIST.EXPENSES_WRITE)
    }
}

function He(t, n) {
    if (t & 1 && _(0, Xe, 1, 1, "app-dx-outline-button", 9), t & 2) {
        let e = p();
        f(e.userPermissionList.includes(e.PERMISSION_LIST.EXPENSES_WRITE) ? 0 : -1)
    }
}

function Qe(t, n) {
    t & 1 && c(0, "app-skeleton-loader", 5), t & 2 && a("rows", 8)("columns", 3)
}

function We(t, n) {
    if (t & 1 && (s(0, "app-control-container", 26), c(1, "dx-text-box", 32), l()), t & 2) {
        let e = p(2);
        a("errorMsg", e.formatMessage("common_error_messages_transaction_id_required"))("label", e.formatMessage("sale_transaction_id")), r(), a("placeholder", e.formatMessage("common_type_transaction_id_number"))
    }
}

function Ye(t, n) {
    if (t & 1 && (s(0, "app-control-container", 27), c(1, "dx-text-box", 33), l()), t & 2) {
        let e = p(2);
        a("errorMsg", e.formatMessage("common_error_messages_cheque_number_required"))("label", e.formatMessage("sale_cheque_number")), r(), a("placeholder", e.formatMessage("common_type_cheque_number"))
    }
}

function Ze(t, n) {
    if (t & 1) {
        let e = T();
        s(0, "app-attachments", 34), C("afterSaving", function(i) {
            x(e);
            let u = p(2);
            return y(u.afterFileUpload(i))
        }), l()
    }
    if (t & 2) {
        let e = p(2);
        a("attachableType", e.attachableType)("entity", e.expense)("isEditMode", e.isEditMode)("isMultipleUploads", !0)
    }
}

function ze(t, n) {
    if (t & 1) {
        let e = T();
        s(0, "app-save-cancel-footer", 8), C("cancelClick", function() {
            x(e);
            let i = p(3);
            return y(i.cancel())
        })("saveClick", function() {
            x(e);
            let i = p(3);
            return y(i.save())
        }), l()
    }
    if (t & 2) {
        let e = p(3);
        a("isOnPopup", !0)("isVisibleHr", !1)("saveText", e.expenseId ? "common_save" : "common_create")
    }
}

function Je(t, n) {
    if (t & 1 && (s(0, "div", 31), w(1, ze, 1, 3, "app-save-cancel-footer", 7), l()), t & 2) {
        let e = p(2);
        r(), a("ngxPermissionsOnly", e.PERMISSION_LIST.EXPENSES_WRITE)
    }
}

function $e(t, n) {
    if (t & 1 && (s(0, "form", 6), c(1, "app-section-title", 12), s(2, "div", 0)(3, "app-control-container", 13), c(4, "dx-text-box", 14), l(), s(5, "app-control-container", 15), c(6, "dx-select-box", 16), l(), s(7, "app-control-container", 17), c(8, "dx-date-box", 18), l(), c(9, "app-show-custom-fields", 19), s(10, "app-control-container", 20), c(11, "app-textarea", 21), l()(), s(12, "div", 0)(13, "div", 4), c(14, "app-section-title", 22), l(), s(15, "div", 4)(16, "div", 23)(17, "app-control-container", 24), c(18, "app-payment-type-dropdown", 25), l(), _(19, We, 2, 3, "app-control-container", 26), _(20, Ye, 2, 3, "app-control-container", 27), s(21, "app-control-container", 28), c(22, "dx-number-box", 29), l()()()(), _(23, Ze, 1, 4, "app-attachments", 30), _(24, Je, 2, 1, "div", 31), l()), t & 2) {
        let e, o, i = p();
        a("formGroup", i.form), r(), a("title", "common_expense_information"), r(2), a("errorMsg", i.formatMessage("expense_name_required"))("label", i.formatMessage("expense_name")), r(), a("placeholder", i.formatMessage("placeholder_expense_name")), r(), a("errorMsg", i.formatMessage("common_category_required"))("label", i.formatMessage("common_category")), r(), a("items", i.expenseCategories)("placeholder", i.formatMessage("placeholder_select_category")), r(), a("errorMsg", i.formatMessage("expense_date_required"))("label", i.formatMessage("expense_date")), r(), a("dateSerializationFormat", i.DATETIME_SERIALIZATION_FORMAT)("displayFormat", "dd-MMM-yyyy")("max", i.today)("pickerType", i.isMobileDevice ? "rollers" : "calendar")("placeholder", i.formatMessage("placeholder_expense_date")), r(), a("formType", i.FORM_TYPE_LIST.EXPENSE)("form", i.form)("hasColumn", 4), r(), a("errorMsg", i.formatMessage("expense_description_required"))("label", i.formatMessage("expense_description")), r(), a("isEditMode", i.isEditMode)("placeholder", "placeholder_expense_description"), r(3), a("title", "payment_information"), r(3), a("errorMsg", i.formatMessage("common_error_messages_payment_type_id"))("label", i.formatMessage("payment_mode")), r(), a("isEditMode", i.isEditMode), r(), f(z(35, je).includes((e = i.form.getRawValue()) == null || e.paymentable == null ? null : e.paymentable.payment_type_id) ? 19 : -1), r(), f(((o = i.form.getRawValue()) == null || o.paymentable == null ? null : o.paymentable.payment_type_id) === 3 ? 20 : -1), r(), a("errorMsg", i.formatMessage("common_error_messages_amount_required"))("label", i.formatMessage("sale_amount")), r(), a("format", i.CURRENCY_FORMAT)("min", 0), r(), f(i.expense ? 23 : -1), r(), f(i.isMobileDevice && i.isEditMode ? 24 : -1)
    }
}
var X = (() => {
    class t {
        constructor(e, o, i, u) {
            this.service = e, this.expenseCategoryService = o, this.applicationRef = i, this.loaderService = u, this.formatMessage = m, this.formService = d(ge), this.routerHelperService = d(_e), this.router = d(F), this.userSessionService = d(O), this.activatedRouter = d(ae), this.isMobileDevice = d(A).isMobileDevice(), this.toastNotificationService = d(fe), this.today = new Date, this.userPermissionList = this.userSessionService.userPermissionList(), this.DATETIME_SERIALIZATION_FORMAT = le, this.ENTITIES = V, this.CURRENCY_FORMAT = pe, this.expenseId = null, this.expense = null, this.isEditMode = !0, this.form = null, this.isSaving = !1, this.errorResponse = null, this.attachableType = this.ENTITIES.EXPENSE.name, this.PERMISSION_LIST = S, this.FORM_TYPE_LIST = me
        }
        ngOnInit() {
            this.expenseId = +this.activatedRouter.snapshot.paramMap.get("expense_id"), this.loaderService.show(), Q([this.expenseCategoryService.getList(), this.expenseId ? this.service.getById(this.expenseId) : H(new h({}))]).subscribe({
                next: ([e, o]) => {
                    this.expenseCategories = e, this.expense = new h(o), this.form = h.getForm(o), this.subscribeToPaymentTypeChanges(), this.expenseId && (this.form.disable(), this.isEditMode = !1)
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        subscribeToPaymentTypeChanges() {
            this.form.get("paymentable.payment_type_id") ? .valueChanges.subscribe(() => {
                this.setPaymentType()
            })
        }
        save() {
            this.errorResponse = null, this.form.valid ? (this.isSaving = !0, (this.expenseId ? this.service.update(this.form.value) : this.service.create(this.form.value)).subscribe({
                next: o => {
                    console.log("Response", o), this.expense = new h(o), this.applicationRef.tick(), this.attachmentInstance.syncNotes(this.expense)
                },
                error: o => {
                    this.isSaving = !1, this.errorResponse = o
                }
            })) : this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.form = h.getForm(this.expense), this.isEditMode = !1, this.routerHelperService.goBack()
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable()
        }
        setPaymentType() {
            Fe.updateFormForPaymentType(this.form.get("paymentable")), this.form.updateValueAndValidity()
        }
        onClosing() {
            this.form = null, this.expense = null
        }
        afterFileUpload(e) {
            e || (this.isSaving = !1, this.toastNotificationService.success(this.expenseId ? "notification_expense_update_success" : "notification_expense_add_success"), this.isSaving = !1, this.router.navigate(["/expenses"]))
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(v(q), v(Pe), v(Z), v(ye))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-expense-detail"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(k, 5), o & 2) {
                        let u;
                        N(u = D()) && (i.attachmentInstance = u.first)
                    }
                },
                standalone: !1,
                decls: 8,
                vars: 5,
                consts: [
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12", 3, "ngClass"],
                    [3, "isOnPopup", "isVisibleHr", "saveText"],
                    [1, "row", "mt-4"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    ["type", "form", 3, "rows", "columns"],
                    [3, "formGroup"],
                    [3, "isOnPopup", "isVisibleHr", "saveText", "cancelClick", "saveClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "saveClick", "isOnPopup", "isVisibleHr", "saveText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [1, "mb-3", 3, "title"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["name", "category_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "category_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder"],
                    ["name", "expense_date", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "expense_date", "type", "date", 3, "dateSerializationFormat", "displayFormat", "max", "pickerType", "placeholder"],
                    [1, "row", "d-flex", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    ["name", "description", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    ["formControlName", "description", "id", "add-delivery-popup-comment", 3, "isEditMode", "placeholder"],
                    ["id", "payment-information-title", 1, "mt-3", 3, "title"],
                    ["formGroupName", "paymentable", 1, "row"],
                    ["name", "payment_type_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "payment_type_id", 3, "isEditMode"],
                    ["name", "transaction_id", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "cheque_number", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["name", "amount", 1, "col-sm-6", "col-md-6", "col-lg-6", 3, "errorMsg", "label"],
                    ["formControlName", "amount", "id", "add-payment-popup-remaining-amount", 3, "format", "min"],
                    ["accept", "image/*,application/pdf,application/msword,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "attachableType", "entity", "isEditMode", "isMultipleUploads"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    ["formControlName", "transaction_id", "id", "add-payment-popup-transaction_id", 3, "placeholder"],
                    ["formControlName", "cheque_number", "id", "add-payment-popup-cheque_number", 3, "placeholder"],
                    ["accept", "image/*,application/pdf,application/msword,.dsn", "formControlName", "attachments", "id", "job-basic-info-attachment", 3, "afterSaving", "attachableType", "entity", "isEditMode", "isMultipleUploads"]
                ],
                template: function(o, i) {
                    o & 1 && (s(0, "div", 0)(1, "div", 1), _(2, Be, 1, 1, "app-save-cancel-footer", 2), _(3, He, 1, 1), l()(), s(4, "div", 3)(5, "div", 4), _(6, Qe, 1, 2, "app-skeleton-loader", 5), _(7, $e, 25, 36, "form", 6), l()()), o & 2 && (r(), a("ngClass", i.isMobileDevice && "mt-3"), r(), f(!i.isMobileDevice && i.isEditMode ? 2 : -1), r(), f(i.isEditMode ? -1 : 3), r(3), f(!i.form && i.expenseId ? 6 : -1), r(), f(i.form ? 7 : -1))
                },
                dependencies: [J, Ee, k, ve, Ie, we, Ne, ue, Te, De, be, Me, he, xe, te, K, ee, ne, oe, ie, se],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Ke = (t, n, e) => [t, n, e],
    et = (t, n, e) => ({
        icon: "dx-icon-money",
        title: t,
        description: n,
        primaryButtonText: "empty_state_expense_primary_button",
        quickTips: e,
        quickTipsVisible: !0,
        primaryButtonVisible: !0
    });

function tt(t, n) {
    if (t & 1 && c(0, "app-overview-report-card-on-list", 0), t & 2) {
        let e = p();
        a("entity", e.ENTITIES.EXPENSE.name)("label", e.formatMessage("overview_report_expense_quick_overview_report"))
    }
}
var Oe = (() => {
    class t {
        get hasTenantExpenses() {
            return (this.tenantService.config() ? .entity_counts ? .expenses || 0) > 0
        }
        constructor(e) {
            this.service = e, this.formatMessage = m, this.router = d(F), this.userSessionService = d(O), this.tenantService = d(Ce), this.isMobileDevice = d(A).isMobileDevice(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.ENTITIES = V, this.entity = this.ENTITIES.EXPENSE, this.isCreate = !1, this.isVisibleExpensePopup = !1, this.columns = [{
                dataField: "id",
                caption: m("common_id"),
                width: 40,
                hidingPriority: 12,
                visible: !1,
                allowSorting: !0
            }, {
                dataField: "name",
                caption: m("common_name"),
                width: 160,
                allowSorting: !0
            }, {
                dataField: "category.name",
                caption: m("common_category"),
                width: 100,
                allowSorting: !1
            }, {
                dataField: "created_user",
                caption: m("common_created_by"),
                hidingPriority: 9,
                cellTemplate: "employeeTemplate",
                visible: !1,
                showInColumnChooser: this.isEmployee,
                allowSorting: !1
            }, {
                dataField: "description",
                caption: m("common_description"),
                hidingPriority: 7,
                cellTemplate: "commentTemplate",
                allowSorting: !1
            }, {
                dataField: "paymentable.amount",
                caption: m("common_amount"),
                hidingPriority: 8,
                allowSorting: !1,
                alignment: "center",
                format: {
                    type: "fixedPoint",
                    precision: 2
                }
            }, {
                dataField: "paymentable.transaction_id",
                caption: m("sale_transaction_id"),
                hidingPriority: 5,
                alignment: "center",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "paymentable.cheque_number",
                caption: m("sale_cheque_number"),
                hidingPriority: 3,
                alignment: "center",
                visible: !1,
                allowSorting: !1
            }, {
                dataField: "paymentable.payment_type.name",
                caption: m("common_payment_type"),
                hidingPriority: 4,
                allowSorting: !1,
                alignment: "center"
            }, {
                dataField: "expense_date",
                caption: m("common_expense_date"),
                cellTemplate: "dateTemplate",
                hidingPriority: 6,
                allowSorting: !0,
                alignment: "center"
            }, {
                dataField: "created_at",
                caption: m("common_created_on"),
                hidingPriority: 2,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !0
            }, {
                dataField: "updated_at",
                caption: m("common_updated_on"),
                hidingPriority: 1,
                allowSorting: !0,
                cellTemplate: "dateTimeTemplate",
                visible: !1
            }, {
                dataField: "",
                caption: "",
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1,
                alignment: "right"
            }]
        }
        create() {
            this.router.navigate(["/expenses/add"])
        }
        edit(e) {
            this.router.navigate([`/expenses/${e.id}/details`])
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)(v(q))
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-expense-list"]
                ],
                viewQuery: function(o, i) {
                    if (o & 1 && P(L, 5), o & 2) {
                        let u;
                        N(u = D()) && (i.dataGrid = u.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 19,
                consts: [
                    [3, "entity", "label"],
                    [3, "dataGridAddNewClick", "dataGridEditClick", "columns", "entity", "isVisibleDeleteAction", "isVisibleEditAction", "isVisibleExportAction", "isVisibleReportDropdown", "searchPanelPlaceholderText", "service", "hasTenantData", "emptyStateConfig"]
                ],
                template: function(o, i) {
                    o & 1 && (_(0, tt, 1, 2, "app-overview-report-card-on-list", 0), s(1, "app-data-grid", 1), C("dataGridAddNewClick", function() {
                        return i.create()
                    })("dataGridEditClick", function(qe) {
                        return i.edit(qe)
                    }), l()), o & 2 && (f(i.isAdmin ? 0 : -1), r(), a("columns", i.columns)("entity", i.entity)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("isVisibleExportAction", i.isAdmin && !i.isMobileDevice)("isVisibleReportDropdown", !0)("searchPanelPlaceholderText", "search_panel_expense_placeholder")("service", i.service)("hasTenantData", i.hasTenantExpenses)("emptyStateConfig", j(15, et, i.formatMessage("empty_state_expense_title"), i.formatMessage("empty_state_expense_description"), j(11, Ke, i.formatMessage("empty_state_expense_tip_1"), i.formatMessage("empty_state_expense_tip_2"), i.formatMessage("empty_state_expense_tip_3")))))
                },
                dependencies: [L, Re],
                encapsulation: 2
            })
        }
    }
    return t
})();
var ke = (() => {
    class t {
        constructor() {
            this.formatMessage = m
        }
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275cmp = g({
                type: t,
                selectors: [
                    ["app-expense"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(o, i) {
                    o & 1 && (s(0, "div", 0), c(1, "router-outlet"), l())
                },
                dependencies: [re],
                encapsulation: 2
            })
        }
    }
    return t
})();
var it = [{
        path: "",
        component: ke,
        children: [{
            path: "list",
            component: Oe,
            canActivate: [R],
            data: {
                permissions: {
                    only: [S.EXPENSES_LIST]
                }
            },
            title: "BytePhase | Expenses List"
        }, {
            path: "add",
            component: X,
            canActivate: [R],
            data: {
                permissions: {
                    only: [S.EXPENSES_WRITE]
                }
            },
            title: "BytePhase | Add Expenses"
        }, {
            path: ":expense_id/details",
            component: X,
            canActivate: [R],
            data: {
                permissions: {
                    only: [S.EXPENSES_WRITE]
                }
            },
            title: "BytePhase | Expenses Details"
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    Le = (() => {
        class t {
            static {
                this.\u0275fac = function(o) {
                    return new(o || t)
                }
            }
            static {
                this.\u0275mod = I({
                    type: t
                })
            }
            static {
                this.\u0275inj = M({
                    imports: [B.forChild(it), B]
                })
            }
        }
        return t
    })();
var gi = (() => {
    class t {
        static {
            this.\u0275fac = function(o) {
                return new(o || t)
            }
        }
        static {
            this.\u0275mod = I({
                type: t
            })
        }
        static {
            this.\u0275inj = M({
                imports: [$, Le, Ae]
            })
        }
    }
    return t
})();
export {
    gi as ExpenseModule
};