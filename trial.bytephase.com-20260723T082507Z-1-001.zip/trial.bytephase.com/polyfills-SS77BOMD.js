function gt(t, e) {
    for (let a = 1, n = 1; a < t.length; a++, n++)
        if (e[n] === "\\") n++;
        else if (t[a] === ":") return a;
    throw new Error(`Unterminated $localize metadata block in "${e}".`)
}
var Pe = function(t, ...e) {
        if (Pe.translate) {
            let n = Pe.translate(t, e);
            t = n[0], e = n[1]
        }
        let a = Ke(t[0], t.raw[0]);
        for (let n = 1; n < t.length; n++) a += e[n - 1] + Ke(t[n], t.raw[n]);
        return a
    },
    pt = ":";

function Ke(t, e) {
    return e.charAt(0) === pt ? t.substring(gt(t, e) + 1) : t
}
globalThis.$localize = Pe;
var mt = Object.defineProperty,
    yt = Object.defineProperties,
    kt = Object.getOwnPropertyDescriptors,
    Je = Object.getOwnPropertySymbols,
    vt = Object.prototype.hasOwnProperty,
    bt = Object.prototype.propertyIsEnumerable,
    Me = (t, e, a) => e in t ? mt(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : t[e] = a,
    Qe = (t, e) => {
        for (var a in e || (e = {})) vt.call(e, a) && Me(t, a, e[a]);
        if (Je)
            for (var a of Je(e)) bt.call(e, a) && Me(t, a, e[a]);
        return t
    },
    Rt = (t, e) => yt(t, kt(e)),
    C = (t, e, a) => (Me(t, typeof e != "symbol" ? e + "" : e, a), a),
    te = globalThis;

function ne(t) {
    return (te.__Zone_symbol_prefix || "__zone_symbol__") + t
}

function Pt() {
    let t = te.performance;

    function e(F) {
        t && t.mark && t.mark(F)
    }

    function a(F, r) {
        t && t.measure && t.measure(F, r)
    }
    e("Zone");
    let n = class Ae {
        constructor(r, o) {
            C(this, "_parent"), C(this, "_name"), C(this, "_properties"), C(this, "_zoneDelegate"), this._parent = r, this._name = o ? o.name || "unnamed" : "<root>", this._properties = o && o.properties || {}, this._zoneDelegate = new v(this, this._parent && this._parent._zoneDelegate, o)
        }
        static assertZonePatched() {
            if (te.Promise !== M.ZoneAwarePromise) throw new Error("Zone.js has detected that ZoneAwarePromise `(window|global).Promise` has been overwritten.\nMost likely cause is that a Promise polyfill has been loaded after Zone.js (Polyfilling Promise api is not necessary when zone.js is loaded. If you must load one, do so before loading zone.js.)")
        }
        static get root() {
            let r = Ae.current;
            for (; r.parent;) r = r.parent;
            return r
        }
        static get current() {
            return z.zone
        }
        static get currentTask() {
            return ee
        }
        static __load_patch(r, o, i = !1) {
            if (M.hasOwnProperty(r)) {
                let p = te[ne("forceDuplicateZoneCheck")] === !0;
                if (!i && p) throw Error("Already loaded patch: " + r)
            } else if (!te["__Zone_disable_" + r]) {
                let p = "Zone:" + r;
                e(p), M[r] = o(te, Ae, O), a(p, p)
            }
        }
        get parent() {
            return this._parent
        }
        get name() {
            return this._name
        }
        get(r) {
            let o = this.getZoneWith(r);
            if (o) return o._properties[r]
        }
        getZoneWith(r) {
            let o = this;
            for (; o;) {
                if (o._properties.hasOwnProperty(r)) return o;
                o = o._parent
            }
            return null
        }
        fork(r) {
            if (!r) throw new Error("ZoneSpec required!");
            return this._zoneDelegate.fork(this, r)
        }
        wrap(r, o) {
            if (typeof r != "function") throw new Error("Expecting function got: " + r);
            let i = this._zoneDelegate.intercept(this, r, o),
                p = this;
            return function() {
                return p.runGuarded(i, this, arguments, o)
            }
        }
        run(r, o, i, p) {
            z = {
                parent: z,
                zone: this
            };
            try {
                return this._zoneDelegate.invoke(this, r, o, i, p)
            } finally {
                z = z.parent
            }
        }
        runGuarded(r, o = null, i, p) {
            z = {
                parent: z,
                zone: this
            };
            try {
                try {
                    return this._zoneDelegate.invoke(this, r, o, i, p)
                } catch (k) {
                    if (this._zoneDelegate.handleError(this, k)) throw k
                }
            } finally {
                z = z.parent
            }
        }
        runTask(r, o, i) {
            if (r.zone != this) throw new Error("A task can only be run in the zone of creation! (Creation: " + (r.zone || R).name + "; Execution: " + this.name + ")");
            let p = r,
                {
                    type: k,
                    data: {
                        isPeriodic: re = !1,
                        isRefreshable: se = !1
                    } = {}
                } = r;
            if (r.state === d && (k === P || k === w)) return;
            let ie = r.state != x;
            ie && p._transitionTo(x, B);
            let ge = ee;
            ee = p, z = {
                parent: z,
                zone: this
            };
            try {
                k == w && r.data && !re && !se && (r.cancelFn = void 0);
                try {
                    return this._zoneDelegate.invokeTask(this, p, o, i)
                } catch (f) {
                    if (this._zoneDelegate.handleError(this, f)) throw f
                }
            } finally {
                let f = r.state;
                if (f !== d && f !== E)
                    if (k == P || re || se && f === H) ie && p._transitionTo(B, x, H);
                    else {
                        let l = p._zoneDelegates;
                        this._updateTaskCount(p, -1), ie && p._transitionTo(d, x, d), se && (p._zoneDelegates = l)
                    }
                z = z.parent, ee = ge
            }
        }
        scheduleTask(r) {
            if (r.zone && r.zone !== this) {
                let i = this;
                for (; i;) {
                    if (i === r.zone) throw Error(`can not reschedule task to ${this.name} which is descendants of the original zone ${r.zone.name}`);
                    i = i.parent
                }
            }
            r._transitionTo(H, d);
            let o = [];
            r._zoneDelegates = o, r._zone = this;
            try {
                r = this._zoneDelegate.scheduleTask(this, r)
            } catch (i) {
                throw r._transitionTo(E, H, d), this._zoneDelegate.handleError(this, i), i
            }
            return r._zoneDelegates === o && this._updateTaskCount(r, 1), r.state == H && r._transitionTo(B, H), r
        }
        scheduleMicroTask(r, o, i, p) {
            return this.scheduleTask(new _(q, r, o, i, p, void 0))
        }
        scheduleMacroTask(r, o, i, p, k) {
            return this.scheduleTask(new _(w, r, o, i, p, k))
        }
        scheduleEventTask(r, o, i, p, k) {
            return this.scheduleTask(new _(P, r, o, i, p, k))
        }
        cancelTask(r) {
            if (r.zone != this) throw new Error("A task can only be cancelled in the zone of creation! (Creation: " + (r.zone || R).name + "; Execution: " + this.name + ")");
            if (!(r.state !== B && r.state !== x)) {
                r._transitionTo(U, B, x);
                try {
                    this._zoneDelegate.cancelTask(this, r)
                } catch (o) {
                    throw r._transitionTo(E, U), this._zoneDelegate.handleError(this, o), o
                }
                return this._updateTaskCount(r, -1), r._transitionTo(d, U), r.runCount = -1, r
            }
        }
        _updateTaskCount(r, o) {
            let i = r._zoneDelegates;
            o == -1 && (r._zoneDelegates = null);
            for (let p = 0; p < i.length; p++) i[p]._updateTaskCount(r.type, o)
        }
    };
    C(n, "__symbol__", ne);
    let c = n,
        u = {
            name: "",
            onHasTask: (F, r, o, i) => F.hasTask(o, i),
            onScheduleTask: (F, r, o, i) => F.scheduleTask(o, i),
            onInvokeTask: (F, r, o, i, p, k) => F.invokeTask(o, i, p, k),
            onCancelTask: (F, r, o, i) => F.cancelTask(o, i)
        };
    class v {
        constructor(r, o, i) {
            C(this, "_zone"), C(this, "_taskCounts", {
                microTask: 0,
                macroTask: 0,
                eventTask: 0
            }), C(this, "_forkDlgt"), C(this, "_forkZS"), C(this, "_forkCurrZone"), C(this, "_interceptDlgt"), C(this, "_interceptZS"), C(this, "_interceptCurrZone"), C(this, "_invokeDlgt"), C(this, "_invokeZS"), C(this, "_invokeCurrZone"), C(this, "_handleErrorDlgt"), C(this, "_handleErrorZS"), C(this, "_handleErrorCurrZone"), C(this, "_scheduleTaskDlgt"), C(this, "_scheduleTaskZS"), C(this, "_scheduleTaskCurrZone"), C(this, "_invokeTaskDlgt"), C(this, "_invokeTaskZS"), C(this, "_invokeTaskCurrZone"), C(this, "_cancelTaskDlgt"), C(this, "_cancelTaskZS"), C(this, "_cancelTaskCurrZone"), C(this, "_hasTaskDlgt"), C(this, "_hasTaskDlgtOwner"), C(this, "_hasTaskZS"), C(this, "_hasTaskCurrZone"), this._zone = r, this._forkZS = i && (i && i.onFork ? i : o._forkZS), this._forkDlgt = i && (i.onFork ? o : o._forkDlgt), this._forkCurrZone = i && (i.onFork ? this._zone : o._forkCurrZone), this._interceptZS = i && (i.onIntercept ? i : o._interceptZS), this._interceptDlgt = i && (i.onIntercept ? o : o._interceptDlgt), this._interceptCurrZone = i && (i.onIntercept ? this._zone : o._interceptCurrZone), this._invokeZS = i && (i.onInvoke ? i : o._invokeZS), this._invokeDlgt = i && (i.onInvoke ? o : o._invokeDlgt), this._invokeCurrZone = i && (i.onInvoke ? this._zone : o._invokeCurrZone), this._handleErrorZS = i && (i.onHandleError ? i : o._handleErrorZS), this._handleErrorDlgt = i && (i.onHandleError ? o : o._handleErrorDlgt), this._handleErrorCurrZone = i && (i.onHandleError ? this._zone : o._handleErrorCurrZone), this._scheduleTaskZS = i && (i.onScheduleTask ? i : o._scheduleTaskZS), this._scheduleTaskDlgt = i && (i.onScheduleTask ? o : o._scheduleTaskDlgt), this._scheduleTaskCurrZone = i && (i.onScheduleTask ? this._zone : o._scheduleTaskCurrZone), this._invokeTaskZS = i && (i.onInvokeTask ? i : o._invokeTaskZS), this._invokeTaskDlgt = i && (i.onInvokeTask ? o : o._invokeTaskDlgt), this._invokeTaskCurrZone = i && (i.onInvokeTask ? this._zone : o._invokeTaskCurrZone), this._cancelTaskZS = i && (i.onCancelTask ? i : o._cancelTaskZS), this._cancelTaskDlgt = i && (i.onCancelTask ? o : o._cancelTaskDlgt), this._cancelTaskCurrZone = i && (i.onCancelTask ? this._zone : o._cancelTaskCurrZone), this._hasTaskZS = null, this._hasTaskDlgt = null, this._hasTaskDlgtOwner = null, this._hasTaskCurrZone = null;
            let p = i && i.onHasTask,
                k = o && o._hasTaskZS;
            (p || k) && (this._hasTaskZS = p ? i : u, this._hasTaskDlgt = o, this._hasTaskDlgtOwner = this, this._hasTaskCurrZone = this._zone, i.onScheduleTask || (this._scheduleTaskZS = u, this._scheduleTaskDlgt = o, this._scheduleTaskCurrZone = this._zone), i.onInvokeTask || (this._invokeTaskZS = u, this._invokeTaskDlgt = o, this._invokeTaskCurrZone = this._zone), i.onCancelTask || (this._cancelTaskZS = u, this._cancelTaskDlgt = o, this._cancelTaskCurrZone = this._zone))
        }
        get zone() {
            return this._zone
        }
        fork(r, o) {
            return this._forkZS ? this._forkZS.onFork(this._forkDlgt, this.zone, r, o) : new c(r, o)
        }
        intercept(r, o, i) {
            return this._interceptZS ? this._interceptZS.onIntercept(this._interceptDlgt, this._interceptCurrZone, r, o, i) : o
        }
        invoke(r, o, i, p, k) {
            return this._invokeZS ? this._invokeZS.onInvoke(this._invokeDlgt, this._invokeCurrZone, r, o, i, p, k) : o.apply(i, p)
        }
        handleError(r, o) {
            return this._handleErrorZS ? this._handleErrorZS.onHandleError(this._handleErrorDlgt, this._handleErrorCurrZone, r, o) : !0
        }
        scheduleTask(r, o) {
            let i = o;
            if (this._scheduleTaskZS) this._hasTaskZS && i._zoneDelegates.push(this._hasTaskDlgtOwner), i = this._scheduleTaskZS.onScheduleTask(this._scheduleTaskDlgt, this._scheduleTaskCurrZone, r, o), i || (i = o);
            else if (o.scheduleFn) o.scheduleFn(o);
            else if (o.type == q) Q(o);
            else throw new Error("Task is missing scheduleFn.");
            return i
        }
        invokeTask(r, o, i, p) {
            return this._invokeTaskZS ? this._invokeTaskZS.onInvokeTask(this._invokeTaskDlgt, this._invokeTaskCurrZone, r, o, i, p) : o.callback.apply(i, p)
        }
        cancelTask(r, o) {
            let i;
            if (this._cancelTaskZS) i = this._cancelTaskZS.onCancelTask(this._cancelTaskDlgt, this._cancelTaskCurrZone, r, o);
            else {
                if (!o.cancelFn) throw Error("Task is not cancelable");
                i = o.cancelFn(o)
            }
            return i
        }
        hasTask(r, o) {
            try {
                this._hasTaskZS && this._hasTaskZS.onHasTask(this._hasTaskDlgt, this._hasTaskCurrZone, r, o)
            } catch (i) {
                this.handleError(r, i)
            }
        }
        _updateTaskCount(r, o) {
            let i = this._taskCounts,
                p = i[r],
                k = i[r] = p + o;
            if (k < 0) throw new Error("More tasks executed then were scheduled.");
            if (p == 0 || k == 0) {
                let re = {
                    microTask: i.microTask > 0,
                    macroTask: i.macroTask > 0,
                    eventTask: i.eventTask > 0,
                    change: r
                };
                this.hasTask(this._zone, re)
            }
        }
    }
    class _ {
        constructor(r, o, i, p, k, re) {
            if (C(this, "type"), C(this, "source"), C(this, "invoke"), C(this, "callback"), C(this, "data"), C(this, "scheduleFn"), C(this, "cancelFn"), C(this, "_zone", null), C(this, "runCount", 0), C(this, "_zoneDelegates", null), C(this, "_state", "notScheduled"), this.type = r, this.source = o, this.data = p, this.scheduleFn = k, this.cancelFn = re, !i) throw new Error("callback is not defined");
            this.callback = i;
            let se = this;
            r === P && p && p.useG ? this.invoke = _.invokeTask : this.invoke = function() {
                return _.invokeTask.call(te, se, this, arguments)
            }
        }
        static invokeTask(r, o, i) {
            r || (r = this), J++;
            try {
                return r.runCount++, r.zone.runTask(r, o, i)
            } finally {
                J === 1 && !te[S] && Y(), J--
            }
        }
        get zone() {
            return this._zone
        }
        get state() {
            return this._state
        }
        cancelScheduleRequest() {
            this._transitionTo(d, H)
        }
        _transitionTo(r, o, i) {
            if (this._state === o || this._state === i) this._state = r, r == d && (this._zoneDelegates = null);
            else throw new Error(`${this.type} '${this.source}': can not transition to '${r}', expecting state '${o}'${i?" or '"+i+"'":""}, was '${this._state}'.`)
        }
        toString() {
            return this.data && typeof this.data.handleId < "u" ? this.data.handleId.toString() : Object.prototype.toString.call(this)
        }
        toJSON() {
            return {
                type: this.type,
                state: this.state,
                source: this.source,
                zone: this.zone.name,
                runCount: this.runCount
            }
        }
    }
    let y = ne("setTimeout"),
        D = ne("Promise"),
        g = ne("then"),
        S = ne("enable_native_microtask_draining"),
        I = [],
        A = !1,
        $;

    function W(F) {
        var r;
        !$ && te[D] && ($ = te[D].resolve(0)), $ ? ((r = $[g]) != null ? r : $.then).call($, F) : te[y](F, 0)
    }

    function Q(F) {
        let r = te[S],
            o = r && I.length === 0 && !A,
            i = !r && J === 0 && I.length === 0;
        (o || i) && W(Y), F && I.push(F)
    }

    function Y() {
        if (!A) {
            for (A = !0; I.length;) {
                let F = I;
                I = [];
                for (let r of F) try {
                    r.zone.runTask(r, null, null)
                } catch (o) {
                    O.onUnhandledError(o)
                }
            }
            te[S] ? (A = !1, O.microtaskDrainDone()) : (O.microtaskDrainDone(), A = !1)
        }
    }
    let R = {
            name: "NO ZONE"
        },
        d = "notScheduled",
        H = "scheduling",
        B = "scheduled",
        x = "running",
        U = "canceling",
        E = "unknown",
        q = "microTask",
        w = "macroTask",
        P = "eventTask",
        M = {},
        O = {
            symbol: ne,
            currentZoneFrame: () => z,
            onUnhandledError: X,
            microtaskDrainDone: X,
            scheduleMicroTask: Q,
            showUncaughtError: () => !c[ne("ignoreConsoleErrorUncaughtError")],
            patchEventTarget: () => [],
            patchOnProperties: X,
            patchMethod: () => X,
            bindArguments: () => [],
            patchThen: () => X,
            patchMacroTask: () => X,
            patchEventPrototype: () => X,
            getGlobalObjects: () => {},
            ObjectDefineProperty: () => X,
            ObjectGetOwnPropertyDescriptor: () => {},
            ObjectCreate: () => {},
            ArraySlice: () => [],
            patchClass: () => X,
            wrapWithCurrentZone: () => X,
            filterProperties: () => [],
            attachOriginToPatched: () => X,
            _redefineProperty: () => X,
            patchCallbacks: () => X,
            nativeScheduleMicroTask: W
        },
        z = {
            parent: null,
            zone: new c(null, null)
        },
        ee = null,
        J = 0;

    function X() {}
    return a("Zone", "Zone"), c
}

function Dt() {
    var t;
    let e = globalThis,
        a = e[ne("forceDuplicateZoneCheck")] === !0;
    if (e.Zone && (a || typeof e.Zone.__symbol__ != "function")) throw new Error("Zone already loaded.");
    return (t = e.Zone) != null || (e.Zone = Pt()), e.Zone
}
var ve = Object.getOwnPropertyDescriptor,
    He = Object.defineProperty,
    Be = Object.getPrototypeOf,
    St = Object.create,
    Ct = Array.prototype.slice,
    xe = "addEventListener",
    Ue = "removeEventListener",
    Le = ne(xe),
    Ze = ne(Ue),
    fe = "true",
    he = "false",
    be = ne("");

function Fe(t, e) {
    return Zone.current.wrap(t, e)
}

function Ge(t, e, a, n, c) {
    return Zone.current.scheduleMacroTask(t, e, a, n, c)
}
var j = ne,
    Ce = typeof window < "u",
    Oe = Ce ? window : void 0,
    K = Ce && Oe || globalThis,
    Ot = "removeAttribute";

function Ve(t, e) {
    for (let a = t.length - 1; a >= 0; a--) typeof t[a] == "function" && (t[a] = Fe(t[a], e + "_" + a));
    return t
}

function wt(t, e) {
    let a = t.constructor.name;
    for (let n = 0; n < e.length; n++) {
        let c = e[n],
            u = t[c];
        if (u) {
            let v = ve(t, c);
            if (!st(v)) continue;
            t[c] = (_ => {
                let y = function() {
                    return _.apply(this, Ve(arguments, a + "." + c))
                };
                return _e(y, _), y
            })(u)
        }
    }
}

function st(t) {
    return t ? t.writable === !1 ? !1 : !(typeof t.get == "function" && typeof t.set > "u") : !0
}
var it = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope,
    we = !("nw" in K) && typeof K.process < "u" && K.process.toString() === "[object process]",
    ze = !we && !it && !!(Ce && Oe.HTMLElement),
    ct = typeof K.process < "u" && K.process.toString() === "[object process]" && !it && !!(Ce && Oe.HTMLElement),
    Se = {},
    Nt = j("enable_beforeunload"),
    et = function(t) {
        if (t = t || K.event, !t) return;
        let e = Se[t.type];
        e || (e = Se[t.type] = j("ON_PROPERTY" + t.type));
        let a = this || t.target || K,
            n = a[e],
            c;
        if (ze && a === Oe && t.type === "error") {
            let u = t;
            c = n && n.call(this, u.message, u.filename, u.lineno, u.colno, u.error), c === !0 && t.preventDefault()
        } else c = n && n.apply(this, arguments), t.type === "beforeunload" && K[Nt] && typeof c == "string" ? t.returnValue = c : c != null && !c && t.preventDefault();
        return c
    };

function tt(t, e, a) {
    let n = ve(t, e);
    if (!n && a && ve(a, e) && (n = {
            enumerable: !0,
            configurable: !0
        }), !n || !n.configurable) return;
    let c = j("on" + e + "patched");
    if (t.hasOwnProperty(c) && t[c]) return;
    delete n.writable, delete n.value;
    let u = n.get,
        v = n.set,
        _ = e.slice(2),
        y = Se[_];
    y || (y = Se[_] = j("ON_PROPERTY" + _)), n.set = function(D) {
        let g = this;
        if (!g && t === K && (g = K), !g) return;
        typeof g[y] == "function" && g.removeEventListener(_, et), v ? .call(g, null), g[y] = D, typeof D == "function" && g.addEventListener(_, et, !1)
    }, n.get = function() {
        let D = this;
        if (!D && t === K && (D = K), !D) return null;
        let g = D[y];
        if (g) return g;
        if (u) {
            let S = u.call(this);
            if (S) return n.set.call(this, S), typeof D[Ot] == "function" && D.removeAttribute(e), S
        }
        return null
    }, He(t, e, n), t[c] = !0
}

function at(t, e, a) {
    if (e)
        for (let n = 0; n < e.length; n++) tt(t, "on" + e[n], a);
    else {
        let n = [];
        for (let c in t) c.slice(0, 2) == "on" && n.push(c);
        for (let c = 0; c < n.length; c++) tt(t, n[c], a)
    }
}
var le = j("originalInstance");

function ke(t) {
    let e = K[t];
    if (!e) return;
    K[j(t)] = e, K[t] = function() {
        let c = Ve(arguments, t);
        switch (c.length) {
            case 0:
                this[le] = new e;
                break;
            case 1:
                this[le] = new e(c[0]);
                break;
            case 2:
                this[le] = new e(c[0], c[1]);
                break;
            case 3:
                this[le] = new e(c[0], c[1], c[2]);
                break;
            case 4:
                this[le] = new e(c[0], c[1], c[2], c[3]);
                break;
            default:
                throw new Error("Arg list too long.")
        }
    }, _e(K[t], e);
    let a = new e(function() {}),
        n;
    for (n in a) t === "XMLHttpRequest" && n === "responseBlob" || (function(c) {
        typeof a[c] == "function" ? K[t].prototype[c] = function() {
            return this[le][c].apply(this[le], arguments)
        } : He(K[t].prototype, c, {
            set: function(u) {
                typeof u == "function" ? (this[le][c] = Fe(u, t + "." + c), _e(this[le][c], u)) : this[le][c] = u
            },
            get: function() {
                return this[le][c]
            }
        })
    })(n);
    for (n in e) n !== "prototype" && e.hasOwnProperty(n) && (K[t][n] = e[n])
}

function It(t, e) {
    if (typeof Object.getOwnPropertySymbols != "function") return;
    Object.getOwnPropertySymbols(t).forEach(n => {
        let c = Object.getOwnPropertyDescriptor(t, n);
        Object.defineProperty(e, n, {
            get: function() {
                return t[n]
            },
            set: function(u) {
                c && (!c.writable || typeof c.set != "function") || (t[n] = u)
            },
            enumerable: c ? c.enumerable : !0,
            configurable: c ? c.configurable : !0
        })
    })
}
var Lt = !1;

function de(t, e, a) {
    let n = t;
    for (; n && !n.hasOwnProperty(e);) n = Be(n);
    !n && t[e] && (n = t);
    let c = j(e),
        u = null;
    if (n && (!(u = n[c]) || !n.hasOwnProperty(c))) {
        u = n[c] = n[e];
        let v = n && ve(n, e);
        if (st(v)) {
            let _ = a(u, c, e);
            n[e] = function() {
                return _(this, arguments)
            }, _e(n[e], u), Lt && It(u, n[e])
        }
    }
    return u
}

function Zt(t, e, a) {
    let n = null;

    function c(u) {
        let v = u.data;
        return v.args[v.cbIdx] = function() {
            u.invoke.apply(this, arguments)
        }, n.apply(v.target, v.args), u
    }
    n = de(t, e, u => function(v, _) {
        let y = a(v, _);
        return y.cbIdx >= 0 && typeof _[y.cbIdx] == "function" ? Ge(y.name, _[y.cbIdx], y, c) : u.apply(v, _)
    })
}

function _e(t, e) {
    t[j("OriginalDelegate")] = e
}

function nt(t) {
    return typeof t == "function"
}

function rt(t) {
    return typeof t == "number"
}
var Mt = {
        useG: !0
    },
    oe = {},
    lt = {},
    ut = new RegExp("^" + be + "(\\w+)(true|false)$"),
    ft = j("propagationStopped");

function ht(t, e) {
    let a = (e ? e(t) : t) + he,
        n = (e ? e(t) : t) + fe,
        c = be + a,
        u = be + n;
    oe[t] = {}, oe[t][he] = c, oe[t][fe] = u
}

function At(t, e, a, n) {
    let c = n && n.add || xe,
        u = n && n.rm || Ue,
        v = n && n.listeners || "eventListeners",
        _ = n && n.rmAll || "removeAllListeners",
        y = j(c),
        D = "." + c + ":",
        g = "prependListener",
        S = "." + g + ":",
        I = function(R, d, H) {
            if (R.isRemoved) return;
            let B = R.callback;
            typeof B == "object" && B.handleEvent && (R.callback = E => B.handleEvent(E), R.originalDelegate = B);
            let x;
            try {
                R.invoke(R, d, [H])
            } catch (E) {
                x = E
            }
            let U = R.options;
            if (U && typeof U == "object" && U.once) {
                let E = R.originalDelegate ? R.originalDelegate : R.callback;
                d[u].call(d, H.type, E, U)
            }
            return x
        };

    function A(R, d, H) {
        if (d = d || t.event, !d) return;
        let B = R || d.target || t,
            x = B[oe[d.type][H ? fe : he]];
        if (x) {
            let U = [];
            if (x.length === 1) {
                let E = I(x[0], B, d);
                E && U.push(E)
            } else {
                let E = x.slice();
                for (let q = 0; q < E.length && !(d && d[ft] === !0); q++) {
                    let w = I(E[q], B, d);
                    w && U.push(w)
                }
            }
            if (U.length === 1) throw U[0];
            for (let E = 0; E < U.length; E++) {
                let q = U[E];
                e.nativeScheduleMicroTask(() => {
                    throw q
                })
            }
        }
    }
    let $ = function(R) {
            return A(this, R, !1)
        },
        W = function(R) {
            return A(this, R, !0)
        };

    function Q(R, d) {
        if (!R) return !1;
        let H = !0;
        d && d.useG !== void 0 && (H = d.useG);
        let B = d && d.vh,
            x = !0;
        d && d.chkDup !== void 0 && (x = d.chkDup);
        let U = !1;
        d && d.rt !== void 0 && (U = d.rt);
        let E = R;
        for (; E && !E.hasOwnProperty(c);) E = Be(E);
        if (!E && R[c] && (E = R), !E || E[y]) return !1;
        let q = d && d.eventNameToString,
            w = {},
            P = E[y] = E[c],
            M = E[j(u)] = E[u],
            O = E[j(v)] = E[v],
            z = E[j(_)] = E[_],
            ee;
        d && d.prepend && (ee = E[j(d.prepend)] = E[d.prepend]);

        function J(s, h) {
            return h ? typeof s == "boolean" ? {
                capture: s,
                passive: !0
            } : s ? typeof s == "object" && s.passive !== !1 ? Rt(Qe({}, s), {
                passive: !0
            }) : s : {
                passive: !0
            } : s
        }
        let X = function(s) {
                if (!w.isExisting) return P.call(w.target, w.eventName, w.capture ? W : $, w.options)
            },
            F = function(s) {
                if (!s.isRemoved) {
                    let h = oe[s.eventName],
                        m;
                    h && (m = h[s.capture ? fe : he]);
                    let b = m && s.target[m];
                    if (b) {
                        for (let T = 0; T < b.length; T++)
                            if (b[T] === s) {
                                b.splice(T, 1), s.isRemoved = !0, s.removeAbortListener && (s.removeAbortListener(), s.removeAbortListener = null), b.length === 0 && (s.allRemoved = !0, s.target[m] = null);
                                break
                            }
                    }
                }
                if (s.allRemoved) return M.call(s.target, s.eventName, s.capture ? W : $, s.options)
            },
            r = function(s) {
                return P.call(w.target, w.eventName, s.invoke, w.options)
            },
            o = function(s) {
                return ee.call(w.target, w.eventName, s.invoke, w.options)
            },
            i = function(s) {
                return M.call(s.target, s.eventName, s.invoke, s.options)
            },
            p = H ? X : r,
            k = H ? F : i,
            re = function(s, h) {
                let m = typeof h;
                return m === "function" && s.callback === h || m === "object" && s.originalDelegate === h
            },
            se = d ? .diff || re,
            ie = Zone[j("UNPATCHED_EVENTS")],
            ge = t[j("PASSIVE_EVENTS")];

        function f(s) {
            if (typeof s == "object" && s !== null) {
                let h = Qe({}, s);
                return s.signal && (h.signal = s.signal), h
            }
            return s
        }
        let l = function(s, h, m, b, T = !1, N = !1) {
            return function() {
                let L = this || t,
                    Z = arguments[0];
                d && d.transferEventName && (Z = d.transferEventName(Z));
                let G = arguments[1];
                if (!G) return s.apply(this, arguments);
                if (we && Z === "uncaughtException") return s.apply(this, arguments);
                let V = !1;
                if (typeof G != "function") {
                    if (!G.handleEvent) return s.apply(this, arguments);
                    V = !0
                }
                if (B && !B(s, G, L, arguments)) return;
                let Te = !!ge && ge.indexOf(Z) !== -1,
                    ce = f(J(arguments[2], Te)),
                    Ee = ce ? .signal;
                if (Ee ? .aborted) return;
                if (ie) {
                    for (let ue = 0; ue < ie.length; ue++)
                        if (Z === ie[ue]) return Te ? s.call(L, Z, G, ce) : s.apply(this, arguments)
                }
                let Ne = ce ? typeof ce == "boolean" ? !0 : ce.capture : !1,
                    We = ce && typeof ce == "object" ? ce.once : !1,
                    Et = Zone.current,
                    Ie = oe[Z];
                Ie || (ht(Z, q), Ie = oe[Z]);
                let qe = Ie[Ne ? fe : he],
                    pe = L[qe],
                    Xe = !1;
                if (pe) {
                    if (Xe = !0, x) {
                        for (let ue = 0; ue < pe.length; ue++)
                            if (se(pe[ue], G)) return
                    }
                } else pe = L[qe] = [];
                let Re, $e = L.constructor.name,
                    Ye = lt[$e];
                Ye && (Re = Ye[Z]), Re || (Re = $e + h + (q ? q(Z) : Z)), w.options = ce, We && (w.options.once = !1), w.target = L, w.capture = Ne, w.eventName = Z, w.isExisting = Xe;
                let ye = H ? Mt : void 0;
                ye && (ye.taskData = w), Ee && (w.options.signal = void 0);
                let ae = Et.scheduleEventTask(Re, G, ye, m, b);
                if (Ee) {
                    w.options.signal = Ee;
                    let ue = () => ae.zone.cancelTask(ae);
                    s.call(Ee, "abort", ue, {
                        once: !0
                    }), ae.removeAbortListener = () => Ee.removeEventListener("abort", ue)
                }
                if (w.target = null, ye && (ye.taskData = null), We && (w.options.once = !0), typeof ae.options != "boolean" && (ae.options = ce), ae.target = L, ae.capture = Ne, ae.eventName = Z, V && (ae.originalDelegate = G), N ? pe.unshift(ae) : pe.push(ae), T) return L
            }
        };
        return E[c] = l(P, D, p, k, U), ee && (E[g] = l(ee, S, o, k, U, !0)), E[u] = function() {
            let s = this || t,
                h = arguments[0];
            d && d.transferEventName && (h = d.transferEventName(h));
            let m = arguments[2],
                b = m ? typeof m == "boolean" ? !0 : m.capture : !1,
                T = arguments[1];
            if (!T) return M.apply(this, arguments);
            if (B && !B(M, T, s, arguments)) return;
            let N = oe[h],
                L;
            N && (L = N[b ? fe : he]);
            let Z = L && s[L];
            if (Z)
                for (let G = 0; G < Z.length; G++) {
                    let V = Z[G];
                    if (se(V, T)) {
                        if (Z.splice(G, 1), V.isRemoved = !0, Z.length === 0 && (V.allRemoved = !0, s[L] = null, !b && typeof h == "string")) {
                            let Te = be + "ON_PROPERTY" + h;
                            s[Te] = null
                        }
                        return V.zone.cancelTask(V), U ? s : void 0
                    }
                }
            return M.apply(this, arguments)
        }, E[v] = function() {
            let s = this || t,
                h = arguments[0];
            d && d.transferEventName && (h = d.transferEventName(h));
            let m = [],
                b = dt(s, q ? q(h) : h);
            for (let T = 0; T < b.length; T++) {
                let N = b[T],
                    L = N.originalDelegate ? N.originalDelegate : N.callback;
                m.push(L)
            }
            return m
        }, E[_] = function() {
            let s = this || t,
                h = arguments[0];
            if (h) {
                d && d.transferEventName && (h = d.transferEventName(h));
                let m = oe[h];
                if (m) {
                    let b = m[he],
                        T = m[fe],
                        N = s[b],
                        L = s[T];
                    if (N) {
                        let Z = N.slice();
                        for (let G = 0; G < Z.length; G++) {
                            let V = Z[G],
                                Te = V.originalDelegate ? V.originalDelegate : V.callback;
                            this[u].call(this, h, Te, V.options)
                        }
                    }
                    if (L) {
                        let Z = L.slice();
                        for (let G = 0; G < Z.length; G++) {
                            let V = Z[G],
                                Te = V.originalDelegate ? V.originalDelegate : V.callback;
                            this[u].call(this, h, Te, V.options)
                        }
                    }
                }
            } else {
                let m = Object.keys(s);
                for (let b = 0; b < m.length; b++) {
                    let T = m[b],
                        N = ut.exec(T),
                        L = N && N[1];
                    L && L !== "removeListener" && this[_].call(this, L)
                }
                this[_].call(this, "removeListener")
            }
            if (U) return this
        }, _e(E[c], P), _e(E[u], M), z && _e(E[_], z), O && _e(E[v], O), !0
    }
    let Y = [];
    for (let R = 0; R < a.length; R++) Y[R] = Q(a[R], n);
    return Y
}

function dt(t, e) {
    if (!e) {
        let u = [];
        for (let v in t) {
            let _ = ut.exec(v),
                y = _ && _[1];
            if (y && (!e || y === e)) {
                let D = t[v];
                if (D)
                    for (let g = 0; g < D.length; g++) u.push(D[g])
            }
        }
        return u
    }
    let a = oe[e];
    a || (ht(e), a = oe[e]);
    let n = t[a[he]],
        c = t[a[fe]];
    return n ? c ? n.concat(c) : n.slice() : c ? c.slice() : []
}

function jt(t, e) {
    let a = t.Event;
    a && a.prototype && e.patchMethod(a.prototype, "stopImmediatePropagation", n => function(c, u) {
        c[ft] = !0, n && n.apply(c, u)
    })
}

function Ht(t, e) {
    e.patchMethod(t, "queueMicrotask", a => function(n, c) {
        Zone.current.scheduleMicroTask("queueMicrotask", c[0])
    })
}
var De = j("zoneTask");

function me(t, e, a, n) {
    let c = null,
        u = null;
    e += n, a += n;
    let v = {};

    function _(D) {
        let g = D.data;
        g.args[0] = function() {
            return D.invoke.apply(this, arguments)
        };
        let S = c.apply(t, g.args);
        return rt(S) ? g.handleId = S : (g.handle = S, g.isRefreshable = nt(S.refresh)), D
    }

    function y(D) {
        let {
            handle: g,
            handleId: S
        } = D.data;
        return u.call(t, g ? ? S)
    }
    c = de(t, e, D => function(g, S) {
        var I;
        if (nt(S[0])) {
            let A = {
                    isRefreshable: !1,
                    isPeriodic: n === "Interval",
                    delay: n === "Timeout" || n === "Interval" ? S[1] || 0 : void 0,
                    args: S
                },
                $ = S[0];
            S[0] = function() {
                try {
                    return $.apply(this, arguments)
                } finally {
                    let {
                        handle: B,
                        handleId: x,
                        isPeriodic: U,
                        isRefreshable: E
                    } = A;
                    !U && !E && (x ? delete v[x] : B && (B[De] = null))
                }
            };
            let W = Ge(e, S[0], A, _, y);
            if (!W) return W;
            let {
                handleId: Q,
                handle: Y,
                isRefreshable: R,
                isPeriodic: d
            } = W.data;
            if (Q) v[Q] = W;
            else if (Y && (Y[De] = W, R && !d)) {
                let H = Y.refresh;
                Y.refresh = function() {
                    let {
                        zone: B,
                        state: x
                    } = W;
                    return x === "notScheduled" ? (W._state = "scheduled", B._updateTaskCount(W, 1)) : x === "running" && (W._state = "scheduling"), H.call(this)
                }
            }
            return (I = Y ? ? Q) != null ? I : W
        } else return D.apply(t, S)
    }), u = de(t, a, D => function(g, S) {
        let I = S[0],
            A;
        rt(I) ? (A = v[I], delete v[I]) : (A = I ? .[De], A ? I[De] = null : A = I), A ? .type ? A.cancelFn && A.zone.cancelTask(A) : D.apply(t, S)
    })
}

function Bt(t, e) {
    let {
        isBrowser: a,
        isMix: n
    } = e.getGlobalObjects();
    if (!a && !n || !t.customElements || !("customElements" in t)) return;
    let c = ["connectedCallback", "disconnectedCallback", "adoptedCallback", "attributeChangedCallback", "formAssociatedCallback", "formDisabledCallback", "formResetCallback", "formStateRestoreCallback"];
    e.patchCallbacks(e, t.customElements, "customElements", "define", c)
}

function xt(t, e) {
    if (Zone[e.symbol("patchEventTarget")]) return;
    let {
        eventNames: a,
        zoneSymbolEventNames: n,
        TRUE_STR: c,
        FALSE_STR: u,
        ZONE_SYMBOL_PREFIX: v
    } = e.getGlobalObjects();
    for (let y = 0; y < a.length; y++) {
        let D = a[y],
            g = D + u,
            S = D + c,
            I = v + g,
            A = v + S;
        n[D] = {}, n[D][u] = I, n[D][c] = A
    }
    let _ = t.EventTarget;
    if (!(!_ || !_.prototype)) return e.patchEventTarget(t, e, [_ && _.prototype]), !0
}

function Ut(t, e) {
    e.patchEventPrototype(t, e)
}

function _t(t, e, a) {
    if (!a || a.length === 0) return e;
    let n = a.filter(u => u.target === t);
    if (n.length === 0) return e;
    let c = n[0].ignoreProperties;
    return e.filter(u => c.indexOf(u) === -1)
}

function ot(t, e, a, n) {
    if (!t) return;
    let c = _t(t, e, a);
    at(t, c, n)
}

function je(t) {
    return Object.getOwnPropertyNames(t).filter(e => e.startsWith("on") && e.length > 2).map(e => e.substring(2))
}

function Ft(t, e) {
    if (we && !ct || Zone[t.symbol("patchEvents")]) return;
    let a = e.__Zone_ignore_on_properties,
        n = [];
    if (ze) {
        let c = window;
        n = n.concat(["Document", "SVGElement", "Element", "HTMLElement", "HTMLBodyElement", "HTMLMediaElement", "HTMLFrameSetElement", "HTMLFrameElement", "HTMLIFrameElement", "HTMLMarqueeElement", "Worker"]), ot(c, je(c), a, Be(c))
    }
    n = n.concat(["XMLHttpRequest", "XMLHttpRequestEventTarget", "IDBIndex", "IDBRequest", "IDBOpenDBRequest", "IDBDatabase", "IDBTransaction", "IDBCursor", "WebSocket"]);
    for (let c = 0; c < n.length; c++) {
        let u = e[n[c]];
        u ? .prototype && ot(u.prototype, je(u.prototype), a)
    }
}

function Gt(t) {
    t.__load_patch("timers", e => {
        let n = "clear";
        me(e, "set", n, "Timeout"), me(e, "set", n, "Interval"), me(e, "set", n, "Immediate")
    }), t.__load_patch("requestAnimationFrame", e => {
        me(e, "request", "cancel", "AnimationFrame"), me(e, "mozRequest", "mozCancel", "AnimationFrame"), me(e, "webkitRequest", "webkitCancel", "AnimationFrame")
    }), t.__load_patch("blocking", (e, a) => {
        let n = ["alert", "prompt", "confirm"];
        for (let c = 0; c < n.length; c++) {
            let u = n[c];
            de(e, u, (v, _, y) => function(D, g) {
                return a.current.run(v, e, g, y)
            })
        }
    }), t.__load_patch("EventTarget", (e, a, n) => {
        Ut(e, n), xt(e, n);
        let c = e.XMLHttpRequestEventTarget;
        c && c.prototype && n.patchEventTarget(e, n, [c.prototype])
    }), t.__load_patch("MutationObserver", (e, a, n) => {
        ke("MutationObserver"), ke("WebKitMutationObserver")
    }), t.__load_patch("IntersectionObserver", (e, a, n) => {
        ke("IntersectionObserver")
    }), t.__load_patch("FileReader", (e, a, n) => {
        ke("FileReader")
    }), t.__load_patch("on_property", (e, a, n) => {
        Ft(n, e)
    }), t.__load_patch("customElements", (e, a, n) => {
        Bt(e, n)
    }), t.__load_patch("XHR", (e, a) => {
        D(e);
        let n = j("xhrTask"),
            c = j("xhrSync"),
            u = j("xhrListener"),
            v = j("xhrScheduled"),
            _ = j("xhrURL"),
            y = j("xhrErrorBeforeScheduled");

        function D(g) {
            let S = g.XMLHttpRequest;
            if (!S) return;
            let I = S.prototype;

            function A(P) {
                return P[n]
            }
            let $ = I[Le],
                W = I[Ze];
            if (!$) {
                let P = g.XMLHttpRequestEventTarget;
                if (P) {
                    let M = P.prototype;
                    $ = M[Le], W = M[Ze]
                }
            }
            let Q = "readystatechange",
                Y = "scheduled";

            function R(P) {
                let M = P.data,
                    O = M.target;
                O[v] = !1, O[y] = !1;
                let z = O[u];
                $ || ($ = O[Le], W = O[Ze]), z && W.call(O, Q, z);
                let ee = O[u] = () => {
                    if (O.readyState === O.DONE)
                        if (!M.aborted && O[v] && P.state === Y) {
                            let X = O[a.__symbol__("loadfalse")];
                            if (O.status !== 0 && X && X.length > 0) {
                                let F = P.invoke;
                                P.invoke = function() {
                                    let r = O[a.__symbol__("loadfalse")];
                                    for (let o = 0; o < r.length; o++) r[o] === P && r.splice(o, 1);
                                    !M.aborted && P.state === Y && F.call(P)
                                }, X.push(P)
                            } else P.invoke()
                        } else !M.aborted && O[v] === !1 && (O[y] = !0)
                };
                return $.call(O, Q, ee), O[n] || (O[n] = P), q.apply(O, M.args), O[v] = !0, P
            }

            function d() {}

            function H(P) {
                let M = P.data;
                return M.aborted = !0, w.apply(M.target, M.args)
            }
            let B = de(I, "open", () => function(P, M) {
                    return P[c] = M[2] == !1, P[_] = M[1], B.apply(P, M)
                }),
                x = "XMLHttpRequest.send",
                U = j("fetchTaskAborting"),
                E = j("fetchTaskScheduling"),
                q = de(I, "send", () => function(P, M) {
                    if (a.current[E] === !0 || P[c]) return q.apply(P, M); {
                        let O = {
                                target: P,
                                url: P[_],
                                isPeriodic: !1,
                                args: M,
                                aborted: !1
                            },
                            z = Ge(x, d, O, R, H);
                        P && P[y] === !0 && !O.aborted && z.state === Y && z.invoke()
                    }
                }),
                w = de(I, "abort", () => function(P, M) {
                    let O = A(P);
                    if (O && typeof O.type == "string") {
                        if (O.cancelFn == null || O.data && O.data.aborted) return;
                        O.zone.cancelTask(O)
                    } else if (a.current[U] === !0) return w.apply(P, M)
                })
        }
    }), t.__load_patch("geolocation", e => {
        e.navigator && e.navigator.geolocation && wt(e.navigator.geolocation, ["getCurrentPosition", "watchPosition"])
    }), t.__load_patch("PromiseRejectionEvent", (e, a) => {
        function n(c) {
            return function(u) {
                dt(e, c).forEach(_ => {
                    let y = e.PromiseRejectionEvent;
                    if (y) {
                        let D = new y(c, {
                            promise: u.promise,
                            reason: u.rejection
                        });
                        _.invoke(D)
                    }
                })
            }
        }
        e.PromiseRejectionEvent && (a[j("unhandledPromiseRejectionHandler")] = n("unhandledrejection"), a[j("rejectionHandledHandler")] = n("rejectionhandled"))
    }), t.__load_patch("queueMicrotask", (e, a, n) => {
        Ht(e, n)
    })
}

function Vt(t) {
    t.__load_patch("ZoneAwarePromise", (e, a, n) => {
        let c = Object.getOwnPropertyDescriptor,
            u = Object.defineProperty;

        function v(f) {
            if (f && f.toString === Object.prototype.toString) {
                let l = f.constructor && f.constructor.name;
                return (l || "") + ": " + JSON.stringify(f)
            }
            return f ? f.toString() : Object.prototype.toString.call(f)
        }
        let _ = n.symbol,
            y = [],
            D = e[_("DISABLE_WRAPPING_UNCAUGHT_PROMISE_REJECTION")] !== !1,
            g = _("Promise"),
            S = _("then"),
            I = "__creationTrace__";
        n.onUnhandledError = f => {
            if (n.showUncaughtError()) {
                let l = f && f.rejection;
                l ? console.error("Unhandled Promise rejection:", l instanceof Error ? l.message : l, "; Zone:", f.zone.name, "; Task:", f.task && f.task.source, "; Value:", l, l instanceof Error ? l.stack : void 0) : console.error(f)
            }
        }, n.microtaskDrainDone = () => {
            for (; y.length;) {
                let f = y.shift();
                try {
                    f.zone.runGuarded(() => {
                        throw f.throwOriginal ? f.rejection : f
                    })
                } catch (l) {
                    $(l)
                }
            }
        };
        let A = _("unhandledPromiseRejectionHandler");

        function $(f) {
            n.onUnhandledError(f);
            try {
                let l = a[A];
                typeof l == "function" && l.call(this, f)
            } catch {}
        }

        function W(f) {
            return f && typeof f.then == "function"
        }

        function Q(f) {
            return f
        }

        function Y(f) {
            return k.reject(f)
        }
        let R = _("state"),
            d = _("value"),
            H = _("finally"),
            B = _("parentPromiseValue"),
            x = _("parentPromiseState"),
            U = "Promise.then",
            E = null,
            q = !0,
            w = !1,
            P = 0;

        function M(f, l) {
            return s => {
                try {
                    J(f, l, s)
                } catch (h) {
                    J(f, !1, h)
                }
            }
        }
        let O = function() {
                let f = !1;
                return function(s) {
                    return function() {
                        f || (f = !0, s.apply(null, arguments))
                    }
                }
            },
            z = "Promise resolved with itself",
            ee = _("currentTaskTrace");

        function J(f, l, s) {
            let h = O();
            if (f === s) throw new TypeError(z);
            if (f[R] === E) {
                let m = null;
                try {
                    (typeof s == "object" || typeof s == "function") && (m = s && s.then)
                } catch (b) {
                    return h(() => {
                        J(f, !1, b)
                    })(), f
                }
                if (l !== w && s instanceof k && s.hasOwnProperty(R) && s.hasOwnProperty(d) && s[R] !== E) F(s), J(f, s[R], s[d]);
                else if (l !== w && typeof m == "function") try {
                    m.call(s, h(M(f, l)), h(M(f, !1)))
                } catch (b) {
                    h(() => {
                        J(f, !1, b)
                    })()
                } else {
                    f[R] = l;
                    let b = f[d];
                    if (f[d] = s, f[H] === H && l === q && (f[R] = f[x], f[d] = f[B]), l === w && s instanceof Error) {
                        let T = a.currentTask && a.currentTask.data && a.currentTask.data[I];
                        T && u(s, ee, {
                            configurable: !0,
                            enumerable: !1,
                            writable: !0,
                            value: T
                        })
                    }
                    for (let T = 0; T < b.length;) r(f, b[T++], b[T++], b[T++], b[T++]);
                    if (b.length == 0 && l == w) {
                        f[R] = P;
                        let T = s;
                        try {
                            throw new Error("Uncaught (in promise): " + v(s) + (s && s.stack ? `
` + s.stack : ""))
                        } catch (N) {
                            T = N
                        }
                        D && (T.throwOriginal = !0), T.rejection = s, T.promise = f, T.zone = a.current, T.task = a.currentTask, y.push(T), n.scheduleMicroTask()
                    }
                }
            }
            return f
        }
        let X = _("rejectionHandledHandler");

        function F(f) {
            if (f[R] === P) {
                try {
                    let l = a[X];
                    l && typeof l == "function" && l.call(this, {
                        rejection: f[d],
                        promise: f
                    })
                } catch {}
                f[R] = w;
                for (let l = 0; l < y.length; l++) f === y[l].promise && y.splice(l, 1)
            }
        }

        function r(f, l, s, h, m) {
            F(f);
            let b = f[R],
                T = b ? typeof h == "function" ? h : Q : typeof m == "function" ? m : Y;
            l.scheduleMicroTask(U, () => {
                try {
                    let N = f[d],
                        L = !!s && H === s[H];
                    L && (s[B] = N, s[x] = b);
                    let Z = l.run(T, void 0, L && T !== Y && T !== Q ? [] : [N]);
                    J(s, !0, Z)
                } catch (N) {
                    J(s, !1, N)
                }
            }, s)
        }
        let o = "function ZoneAwarePromise() { [native code] }",
            i = function() {},
            p = e.AggregateError;
        class k {
            static toString() {
                return o
            }
            static resolve(l) {
                return l instanceof k ? l : J(new this(null), q, l)
            }
            static reject(l) {
                return J(new this(null), w, l)
            }
            static withResolvers() {
                let l = {};
                return l.promise = new k((s, h) => {
                    l.resolve = s, l.reject = h
                }), l
            }
            static any(l) {
                if (!l || typeof l[Symbol.iterator] != "function") return Promise.reject(new p([], "All promises were rejected"));
                let s = [],
                    h = 0;
                try {
                    for (let T of l) h++, s.push(k.resolve(T))
                } catch {
                    return Promise.reject(new p([], "All promises were rejected"))
                }
                if (h === 0) return Promise.reject(new p([], "All promises were rejected"));
                let m = !1,
                    b = [];
                return new k((T, N) => {
                    for (let L = 0; L < s.length; L++) s[L].then(Z => {
                        m || (m = !0, T(Z))
                    }, Z => {
                        b.push(Z), h--, h === 0 && (m = !0, N(new p(b, "All promises were rejected")))
                    })
                })
            }
            static race(l) {
                let s, h, m = new this((N, L) => {
                    s = N, h = L
                });

                function b(N) {
                    s(N)
                }

                function T(N) {
                    h(N)
                }
                for (let N of l) W(N) || (N = this.resolve(N)), N.then(b, T);
                return m
            }
            static all(l) {
                return k.allWithCallback(l)
            }
            static allSettled(l) {
                return (this && this.prototype instanceof k ? this : k).allWithCallback(l, {
                    thenCallback: h => ({
                        status: "fulfilled",
                        value: h
                    }),
                    errorCallback: h => ({
                        status: "rejected",
                        reason: h
                    })
                })
            }
            static allWithCallback(l, s) {
                let h, m, b = new this((Z, G) => {
                        h = Z, m = G
                    }),
                    T = 2,
                    N = 0,
                    L = [];
                for (let Z of l) {
                    W(Z) || (Z = this.resolve(Z));
                    let G = N;
                    try {
                        Z.then(V => {
                            L[G] = s ? s.thenCallback(V) : V, T--, T === 0 && h(L)
                        }, V => {
                            s ? (L[G] = s.errorCallback(V), T--, T === 0 && h(L)) : m(V)
                        })
                    } catch (V) {
                        m(V)
                    }
                    T++, N++
                }
                return T -= 2, T === 0 && h(L), b
            }
            constructor(l) {
                let s = this;
                if (!(s instanceof k)) throw new Error("Must be an instanceof Promise.");
                s[R] = E, s[d] = [];
                try {
                    let h = O();
                    l && l(h(M(s, q)), h(M(s, w)))
                } catch (h) {
                    J(s, !1, h)
                }
            }
            get[Symbol.toStringTag]() {
                return "Promise"
            }
            get[Symbol.species]() {
                return k
            }
            then(l, s) {
                var h;
                let m = (h = this.constructor) == null ? void 0 : h[Symbol.species];
                (!m || typeof m != "function") && (m = this.constructor || k);
                let b = new m(i),
                    T = a.current;
                return this[R] == E ? this[d].push(T, b, l, s) : r(this, T, b, l, s), b
            } catch (l) {
                return this.then(null, l)
            } finally(l) {
                var s;
                let h = (s = this.constructor) == null ? void 0 : s[Symbol.species];
                (!h || typeof h != "function") && (h = k);
                let m = new h(i);
                m[H] = H;
                let b = a.current;
                return this[R] == E ? this[d].push(b, m, l, l) : r(this, b, m, l, l), m
            }
        }
        k.resolve = k.resolve, k.reject = k.reject, k.race = k.race, k.all = k.all;
        let re = e[g] = e.Promise;
        e.Promise = k;
        let se = _("thenPatched");

        function ie(f) {
            let l = f.prototype,
                s = c(l, "then");
            if (s && (s.writable === !1 || !s.configurable)) return;
            let h = l.then;
            l[S] = h, f.prototype.then = function(m, b) {
                return new k((N, L) => {
                    h.call(this, N, L)
                }).then(m, b)
            }, f[se] = !0
        }
        n.patchThen = ie;

        function ge(f) {
            return function(l, s) {
                let h = f.apply(l, s);
                if (h instanceof k) return h;
                let m = h.constructor;
                return m[se] || ie(m), h
            }
        }
        if (re) {
            ie(re);
            let f = re.try;
            f && typeof f == "function" && (k.try = f), de(e, "fetch", l => ge(l))
        }
        return Promise[a.__symbol__("uncaughtPromiseErrors")] = y, k
    })
}

function zt(t) {
    t.__load_patch("toString", e => {
        let a = Function.prototype.toString,
            n = j("OriginalDelegate"),
            c = j("Promise"),
            u = j("Error"),
            v = function() {
                if (typeof this == "function") {
                    let g = this[n];
                    if (g) return typeof g == "function" ? a.call(g) : Object.prototype.toString.call(g);
                    if (this === Promise) {
                        let S = e[c];
                        if (S) return a.call(S)
                    }
                    if (this === Error) {
                        let S = e[u];
                        if (S) return a.call(S)
                    }
                }
                return a.call(this)
            };
        v[n] = a, Function.prototype.toString = v;
        let _ = Object.prototype.toString,
            y = "[object Promise]";
        Object.prototype.toString = function() {
            return typeof Promise == "function" && this instanceof Promise ? y : _.call(this)
        }
    })
}

function Wt(t, e, a, n, c) {
    let u = Zone.__symbol__(n);
    if (e[u]) return;
    let v = e[u] = e[n];
    e[n] = function(_, y, D) {
        return y && y.prototype && c.forEach(function(g) {
            let S = `${a}.${n}::` + g,
                I = y.prototype;
            try {
                if (I.hasOwnProperty(g)) {
                    let A = t.ObjectGetOwnPropertyDescriptor(I, g);
                    A && A.value ? (A.value = t.wrapWithCurrentZone(A.value, S), t._redefineProperty(y.prototype, g, A)) : I[g] && (I[g] = t.wrapWithCurrentZone(I[g], S))
                } else I[g] && (I[g] = t.wrapWithCurrentZone(I[g], S))
            } catch {}
        }), v.call(e, _, y, D)
    }, t.attachOriginToPatched(e[n], v)
}

function qt(t) {
    t.__load_patch("util", (e, a, n) => {
        let c = je(e);
        n.patchOnProperties = at, n.patchMethod = de, n.bindArguments = Ve, n.patchMacroTask = Zt;
        let u = a.__symbol__("BLACK_LISTED_EVENTS"),
            v = a.__symbol__("UNPATCHED_EVENTS");
        e[v] && (e[u] = e[v]), e[u] && (a[u] = a[v] = e[u]), n.patchEventPrototype = jt, n.patchEventTarget = At, n.ObjectDefineProperty = He, n.ObjectGetOwnPropertyDescriptor = ve, n.ObjectCreate = St, n.ArraySlice = Ct, n.patchClass = ke, n.wrapWithCurrentZone = Fe, n.filterProperties = _t, n.attachOriginToPatched = _e, n._redefineProperty = Object.defineProperty, n.patchCallbacks = Wt, n.getGlobalObjects = () => ({
            globalSources: lt,
            zoneSymbolEventNames: oe,
            eventNames: c,
            isBrowser: ze,
            isMix: ct,
            isNode: we,
            TRUE_STR: fe,
            FALSE_STR: he,
            ZONE_SYMBOL_PREFIX: be,
            ADD_EVENT_LISTENER_STR: xe,
            REMOVE_EVENT_LISTENER_STR: Ue
        })
    })
}

function Xt(t) {
    Vt(t), zt(t), qt(t)
}
var Tt = Dt();
Xt(Tt);
Gt(Tt);