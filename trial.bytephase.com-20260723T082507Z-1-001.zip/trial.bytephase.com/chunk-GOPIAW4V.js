import {
    a as E,
    b as B,
    i as G
} from "./chunk-FBFWB55K.js";
var Ae = null,
    da = !1,
    Gu = 1,
    xI = null,
    ue = Symbol("SIGNAL");

function S(e) {
    let t = Ae;
    return Ae = e, t
}

function fa() {
    return Ae
}
var Hn = {
    version: 0,
    lastCleanEpoch: 0,
    dirty: !1,
    producers: void 0,
    producersTail: void 0,
    consumers: void 0,
    consumersTail: void 0,
    recomputing: !1,
    consumerAllowSignalWrites: !1,
    consumerIsAlwaysLive: !1,
    kind: "unknown",
    producerMustRecompute: () => !1,
    producerRecomputeValue: () => {},
    consumerMarkedDirty: () => {},
    consumerOnSignalRead: () => {}
};

function Vn(e) {
    if (da) throw new Error("");
    if (Ae === null) return;
    Ae.consumerOnSignalRead(e);
    let t = Ae.producersTail;
    if (t !== void 0 && t.producer === e) return;
    let n, r = Ae.recomputing;
    if (r && (n = t !== void 0 ? t.nextProducer : Ae.producers, n !== void 0 && n.producer === e)) {
        Ae.producersTail = n, n.lastReadVersion = e.version;
        return
    }
    let o = e.consumersTail;
    if (o !== void 0 && o.consumer === Ae && (!r || II(o, Ae))) return;
    let i = lo(Ae),
        s = {
            producer: e,
            consumer: Ae,
            nextProducer: n,
            prevConsumer: o,
            lastReadVersion: e.version,
            nextConsumer: void 0
        };
    Ae.producersTail = s, t !== void 0 ? t.nextProducer = s : Ae.producers = s, i && Dg(e, s)
}

function Eg() {
    Gu++
}

function yr(e) {
    if (!(lo(e) && !e.dirty) && !(!e.dirty && e.lastCleanEpoch === Gu)) {
        if (!e.producerMustRecompute(e) && !Di(e)) {
            co(e);
            return
        }
        e.producerRecomputeValue(e), co(e)
    }
}

function Wu(e) {
    if (e.consumers === void 0) return;
    let t = da;
    da = !0;
    try {
        for (let n = e.consumers; n !== void 0; n = n.nextConsumer) {
            let r = n.consumer;
            r.dirty || CI(r)
        }
    } finally {
        da = t
    }
}

function zu() {
    return Ae ? .consumerAllowSignalWrites !== !1
}

function CI(e) {
    e.dirty = !0, Wu(e), e.consumerMarkedDirty ? .(e)
}

function co(e) {
    e.dirty = !1, e.lastCleanEpoch = Gu
}

function $n(e) {
    return e && yg(e), S(e)
}

function yg(e) {
    e.producersTail = void 0, e.recomputing = !0
}

function vr(e, t) {
    S(t), e && vg(e)
}

function vg(e) {
    e.recomputing = !1;
    let t = e.producersTail,
        n = t !== void 0 ? t.nextProducer : e.producers;
    if (n !== void 0) {
        if (lo(e))
            do n = qu(n); while (n !== void 0);
        t !== void 0 ? t.nextProducer = void 0 : e.producers = void 0
    }
}

function Di(e) {
    for (let t = e.producers; t !== void 0; t = t.nextProducer) {
        let n = t.producer,
            r = t.lastReadVersion;
        if (r !== n.version || (yr(n), r !== n.version)) return !0
    }
    return !1
}

function Dr(e) {
    if (lo(e)) {
        let t = e.producers;
        for (; t !== void 0;) t = qu(t)
    }
    e.producers = void 0, e.producersTail = void 0, e.consumers = void 0, e.consumersTail = void 0
}

function Dg(e, t) {
    let n = e.consumersTail,
        r = lo(e);
    if (n !== void 0 ? (t.nextConsumer = n.nextConsumer, n.nextConsumer = t) : (t.nextConsumer = void 0, e.consumers = t), t.prevConsumer = n, e.consumersTail = t, !r)
        for (let o = e.producers; o !== void 0; o = o.nextProducer) Dg(o.producer, o)
}

function qu(e) {
    let t = e.producer,
        n = e.nextProducer,
        r = e.nextConsumer,
        o = e.prevConsumer;
    if (e.nextConsumer = void 0, e.prevConsumer = void 0, r !== void 0 ? r.prevConsumer = o : t.consumersTail = o, o !== void 0) o.nextConsumer = r;
    else if (t.consumers = r, !lo(t)) {
        let i = t.producers;
        for (; i !== void 0;) i = qu(i)
    }
    return n
}

function lo(e) {
    return e.consumerIsAlwaysLive || e.consumers !== void 0
}

function _i(e) {
    xI ? .(e)
}

function II(e, t) {
    let n = t.producersTail;
    if (n !== void 0) {
        let r = t.producers;
        do {
            if (r === e) return !0;
            if (r === n) break;
            r = r.nextProducer
        } while (r !== void 0)
    }
    return !1
}

function xi(e, t) {
    return Object.is(e, t)
}

function Ci(e, t) {
    let n = Object.create(TI);
    n.computation = e, t !== void 0 && (n.equal = t);
    let r = () => {
        if (yr(n), Vn(n), n.value === zt) throw n.error;
        return n.value
    };
    return r[ue] = n, _i(n), r
}
var gr = Symbol("UNSET"),
    Er = Symbol("COMPUTING"),
    zt = Symbol("ERRORED"),
    TI = B(E({}, Hn), {
        value: gr,
        dirty: !0,
        error: null,
        equal: xi,
        kind: "computed",
        producerMustRecompute(e) {
            return e.value === gr || e.value === Er
        },
        producerRecomputeValue(e) {
            if (e.value === Er) throw new Error("");
            let t = e.value;
            e.value = Er;
            let n = $n(e),
                r, o = !1;
            try {
                r = e.computation(), S(null), o = t !== gr && t !== zt && r !== zt && e.equal(t, r)
            } catch (i) {
                r = zt, e.error = i
            } finally {
                vr(e, n)
            }
            if (o) {
                e.value = t;
                return
            }
            e.value = r, e.version++
        }
    });

function SI() {
    throw new Error
}
var _g = SI;

function xg(e) {
    _g(e)
}

function Ku(e) {
    _g = e
}
var bI = null;

function Yu(e, t) {
    let n = Object.create(ha);
    n.value = e, t !== void 0 && (n.equal = t);
    let r = () => Cg(n);
    return r[ue] = n, _i(n), [r, s => Gn(n, s), s => pa(n, s)]
}

function Cg(e) {
    return Vn(e), e.value
}

function Gn(e, t) {
    zu() || xg(e), e.equal(e.value, t) || (e.value = t, wI(e))
}

function pa(e, t) {
    zu() || xg(e), Gn(e, t(e.value))
}
var ha = B(E({}, Hn), {
    equal: xi,
    value: void 0,
    kind: "signal"
});

function wI(e) {
    e.version++, Eg(), Wu(e), bI ? .(e)
}
var Ju = B(E({}, Hn), {
    consumerIsAlwaysLive: !0,
    consumerAllowSignalWrites: !0,
    dirty: !0,
    kind: "effect"
});

function Qu(e) {
    if (e.dirty = !1, e.version > 0 && !Di(e)) return;
    e.version++;
    let t = $n(e);
    try {
        e.cleanup(), e.fn()
    } finally {
        vr(e, t)
    }
}

function w(e) {
    return typeof e == "function"
}

function Wn(e) {
    let n = e(r => {
        Error.call(r), r.stack = new Error().stack
    });
    return n.prototype = Object.create(Error.prototype), n.prototype.constructor = n, n
}
var ma = Wn(e => function(n) {
    e(this), this.message = n ? `${n.length} errors occurred during unsubscription:
${n.map((r,o)=>`${o+1}) ${r.toString()}`).join(`
  `)}` : "", this.name = "UnsubscriptionError", this.errors = n
});

function _r(e, t) {
    if (e) {
        let n = e.indexOf(t);
        0 <= n && e.splice(n, 1)
    }
}
var oe = class e {
    constructor(t) {
        this.initialTeardown = t, this.closed = !1, this._parentage = null, this._finalizers = null
    }
    unsubscribe() {
        let t;
        if (!this.closed) {
            this.closed = !0;
            let {
                _parentage: n
            } = this;
            if (n)
                if (this._parentage = null, Array.isArray(n))
                    for (let i of n) i.remove(this);
                else n.remove(this);
            let {
                initialTeardown: r
            } = this;
            if (w(r)) try {
                r()
            } catch (i) {
                t = i instanceof ma ? i.errors : [i]
            }
            let {
                _finalizers: o
            } = this;
            if (o) {
                this._finalizers = null;
                for (let i of o) try {
                    Ig(i)
                } catch (s) {
                    t = t ? ? [], s instanceof ma ? t = [...t, ...s.errors] : t.push(s)
                }
            }
            if (t) throw new ma(t)
        }
    }
    add(t) {
        var n;
        if (t && t !== this)
            if (this.closed) Ig(t);
            else {
                if (t instanceof e) {
                    if (t.closed || t._hasParent(this)) return;
                    t._addParent(this)
                }(this._finalizers = (n = this._finalizers) !== null && n !== void 0 ? n : []).push(t)
            }
    }
    _hasParent(t) {
        let {
            _parentage: n
        } = this;
        return n === t || Array.isArray(n) && n.includes(t)
    }
    _addParent(t) {
        let {
            _parentage: n
        } = this;
        this._parentage = Array.isArray(n) ? (n.push(t), n) : n ? [n, t] : t
    }
    _removeParent(t) {
        let {
            _parentage: n
        } = this;
        n === t ? this._parentage = null : Array.isArray(n) && _r(n, t)
    }
    remove(t) {
        let {
            _finalizers: n
        } = this;
        n && _r(n, t), t instanceof e && t._removeParent(this)
    }
};
oe.EMPTY = (() => {
    let e = new oe;
    return e.closed = !0, e
})();
var Zu = oe.EMPTY;

function ga(e) {
    return e instanceof oe || e && "closed" in e && w(e.remove) && w(e.add) && w(e.unsubscribe)
}

function Ig(e) {
    w(e) ? e() : e.unsubscribe()
}
var wt = {
    onUnhandledError: null,
    onStoppedNotification: null,
    Promise: void 0,
    useDeprecatedSynchronousErrorHandling: !1,
    useDeprecatedNextContext: !1
};
var uo = {
    setTimeout(e, t, ...n) {
        let {
            delegate: r
        } = uo;
        return r ? .setTimeout ? r.setTimeout(e, t, ...n) : setTimeout(e, t, ...n)
    },
    clearTimeout(e) {
        let {
            delegate: t
        } = uo;
        return (t ? .clearTimeout || clearTimeout)(e)
    },
    delegate: void 0
};

function Ea(e) {
    uo.setTimeout(() => {
        let {
            onUnhandledError: t
        } = wt;
        if (t) t(e);
        else throw e
    })
}

function pn() {}
var Tg = Xu("C", void 0, void 0);

function Sg(e) {
    return Xu("E", void 0, e)
}

function bg(e) {
    return Xu("N", e, void 0)
}

function Xu(e, t, n) {
    return {
        kind: e,
        value: t,
        error: n
    }
}
var xr = null;

function fo(e) {
    if (wt.useDeprecatedSynchronousErrorHandling) {
        let t = !xr;
        if (t && (xr = {
                errorThrown: !1,
                error: null
            }), e(), t) {
            let {
                errorThrown: n,
                error: r
            } = xr;
            if (xr = null, n) throw r
        }
    } else e()
}

function wg(e) {
    wt.useDeprecatedSynchronousErrorHandling && xr && (xr.errorThrown = !0, xr.error = e)
}
var Cr = class extends oe {
        constructor(t) {
            super(), this.isStopped = !1, t ? (this.destination = t, ga(t) && t.add(this)) : this.destination = NI
        }
        static create(t, n, r) {
            return new At(t, n, r)
        }
        next(t) {
            this.isStopped ? td(bg(t), this) : this._next(t)
        }
        error(t) {
            this.isStopped ? td(Sg(t), this) : (this.isStopped = !0, this._error(t))
        }
        complete() {
            this.isStopped ? td(Tg, this) : (this.isStopped = !0, this._complete())
        }
        unsubscribe() {
            this.closed || (this.isStopped = !0, super.unsubscribe(), this.destination = null)
        }
        _next(t) {
            this.destination.next(t)
        }
        _error(t) {
            try {
                this.destination.error(t)
            } finally {
                this.unsubscribe()
            }
        }
        _complete() {
            try {
                this.destination.complete()
            } finally {
                this.unsubscribe()
            }
        }
    },
    AI = Function.prototype.bind;

function ed(e, t) {
    return AI.call(e, t)
}
var nd = class {
        constructor(t) {
            this.partialObserver = t
        }
        next(t) {
            let {
                partialObserver: n
            } = this;
            if (n.next) try {
                n.next(t)
            } catch (r) {
                ya(r)
            }
        }
        error(t) {
            let {
                partialObserver: n
            } = this;
            if (n.error) try {
                n.error(t)
            } catch (r) {
                ya(r)
            } else ya(t)
        }
        complete() {
            let {
                partialObserver: t
            } = this;
            if (t.complete) try {
                t.complete()
            } catch (n) {
                ya(n)
            }
        }
    },
    At = class extends Cr {
        constructor(t, n, r) {
            super();
            let o;
            if (w(t) || !t) o = {
                next: t ? ? void 0,
                error: n ? ? void 0,
                complete: r ? ? void 0
            };
            else {
                let i;
                this && wt.useDeprecatedNextContext ? (i = Object.create(t), i.unsubscribe = () => this.unsubscribe(), o = {
                    next: t.next && ed(t.next, i),
                    error: t.error && ed(t.error, i),
                    complete: t.complete && ed(t.complete, i)
                }) : o = t
            }
            this.destination = new nd(o)
        }
    };

function ya(e) {
    wt.useDeprecatedSynchronousErrorHandling ? wg(e) : Ea(e)
}

function MI(e) {
    throw e
}

function td(e, t) {
    let {
        onStoppedNotification: n
    } = wt;
    n && uo.setTimeout(() => n(e, t))
}
var NI = {
    closed: !0,
    next: pn,
    error: MI,
    complete: pn
};
var po = typeof Symbol == "function" && Symbol.observable || "@@observable";

function et(e) {
    return e
}

function rd(...e) {
    return od(e)
}

function od(e) {
    return e.length === 0 ? et : e.length === 1 ? e[0] : function(n) {
        return e.reduce((r, o) => o(r), n)
    }
}
var P = (() => {
    class e {
        constructor(n) {
            n && (this._subscribe = n)
        }
        lift(n) {
            let r = new e;
            return r.source = this, r.operator = n, r
        }
        subscribe(n, r, o) {
            let i = OI(n) ? n : new At(n, r, o);
            return fo(() => {
                let {
                    operator: s,
                    source: a
                } = this;
                i.add(s ? s.call(i, a) : a ? this._subscribe(i) : this._trySubscribe(i))
            }), i
        }
        _trySubscribe(n) {
            try {
                return this._subscribe(n)
            } catch (r) {
                n.error(r)
            }
        }
        forEach(n, r) {
            return r = Ag(r), new r((o, i) => {
                let s = new At({
                    next: a => {
                        try {
                            n(a)
                        } catch (c) {
                            i(c), s.unsubscribe()
                        }
                    },
                    error: i,
                    complete: o
                });
                this.subscribe(s)
            })
        }
        _subscribe(n) {
            var r;
            return (r = this.source) === null || r === void 0 ? void 0 : r.subscribe(n)
        }[po]() {
            return this
        }
        pipe(...n) {
            return od(n)(this)
        }
        toPromise(n) {
            return n = Ag(n), new n((r, o) => {
                let i;
                this.subscribe(s => i = s, s => o(s), () => r(i))
            })
        }
    }
    return e.create = t => new e(t), e
})();

function Ag(e) {
    var t;
    return (t = e ? ? wt.Promise) !== null && t !== void 0 ? t : Promise
}

function RI(e) {
    return e && w(e.next) && w(e.error) && w(e.complete)
}

function OI(e) {
    return e && e instanceof Cr || RI(e) && ga(e)
}

function PI(e) {
    return w(e ? .lift)
}

function A(e) {
    return t => {
        if (PI(t)) return t.lift(function(n) {
            try {
                return e(n, this)
            } catch (r) {
                this.error(r)
            }
        });
        throw new TypeError("Unable to lift unknown Observable type")
    }
}

function M(e, t, n, r, o) {
    return new id(e, t, n, r, o)
}
var id = class extends Cr {
    constructor(t, n, r, o, i, s) {
        super(t), this.onFinalize = i, this.shouldUnsubscribe = s, this._next = n ? function(a) {
            try {
                n(a)
            } catch (c) {
                t.error(c)
            }
        } : super._next, this._error = o ? function(a) {
            try {
                o(a)
            } catch (c) {
                t.error(c)
            } finally {
                this.unsubscribe()
            }
        } : super._error, this._complete = r ? function() {
            try {
                r()
            } catch (a) {
                t.error(a)
            } finally {
                this.unsubscribe()
            }
        } : super._complete
    }
    unsubscribe() {
        var t;
        if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
            let {
                closed: n
            } = this;
            super.unsubscribe(), !n && ((t = this.onFinalize) === null || t === void 0 || t.call(this))
        }
    }
};
var ho = {
    schedule(e) {
        let t = requestAnimationFrame,
            n = cancelAnimationFrame,
            {
                delegate: r
            } = ho;
        r && (t = r.requestAnimationFrame, n = r.cancelAnimationFrame);
        let o = t(i => {
            n = void 0, e(i)
        });
        return new oe(() => n ? .(o))
    },
    requestAnimationFrame(...e) {
        let {
            delegate: t
        } = ho;
        return (t ? .requestAnimationFrame || requestAnimationFrame)(...e)
    },
    cancelAnimationFrame(...e) {
        let {
            delegate: t
        } = ho;
        return (t ? .cancelAnimationFrame || cancelAnimationFrame)(...e)
    },
    delegate: void 0
};
var Mg = Wn(e => function() {
    e(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed"
});
var ne = (() => {
        class e extends P {
            constructor() {
                super(), this.closed = !1, this.currentObservers = null, this.observers = [], this.isStopped = !1, this.hasError = !1, this.thrownError = null
            }
            lift(n) {
                let r = new va(this, this);
                return r.operator = n, r
            }
            _throwIfClosed() {
                if (this.closed) throw new Mg
            }
            next(n) {
                fo(() => {
                    if (this._throwIfClosed(), !this.isStopped) {
                        this.currentObservers || (this.currentObservers = Array.from(this.observers));
                        for (let r of this.currentObservers) r.next(n)
                    }
                })
            }
            error(n) {
                fo(() => {
                    if (this._throwIfClosed(), !this.isStopped) {
                        this.hasError = this.isStopped = !0, this.thrownError = n;
                        let {
                            observers: r
                        } = this;
                        for (; r.length;) r.shift().error(n)
                    }
                })
            }
            complete() {
                fo(() => {
                    if (this._throwIfClosed(), !this.isStopped) {
                        this.isStopped = !0;
                        let {
                            observers: n
                        } = this;
                        for (; n.length;) n.shift().complete()
                    }
                })
            }
            unsubscribe() {
                this.isStopped = this.closed = !0, this.observers = this.currentObservers = null
            }
            get observed() {
                var n;
                return ((n = this.observers) === null || n === void 0 ? void 0 : n.length) > 0
            }
            _trySubscribe(n) {
                return this._throwIfClosed(), super._trySubscribe(n)
            }
            _subscribe(n) {
                return this._throwIfClosed(), this._checkFinalizedStatuses(n), this._innerSubscribe(n)
            }
            _innerSubscribe(n) {
                let {
                    hasError: r,
                    isStopped: o,
                    observers: i
                } = this;
                return r || o ? Zu : (this.currentObservers = null, i.push(n), new oe(() => {
                    this.currentObservers = null, _r(i, n)
                }))
            }
            _checkFinalizedStatuses(n) {
                let {
                    hasError: r,
                    thrownError: o,
                    isStopped: i
                } = this;
                r ? n.error(o) : i && n.complete()
            }
            asObservable() {
                let n = new P;
                return n.source = this, n
            }
        }
        return e.create = (t, n) => new va(t, n), e
    })(),
    va = class extends ne {
        constructor(t, n) {
            super(), this.destination = t, this.source = n
        }
        next(t) {
            var n, r;
            (r = (n = this.destination) === null || n === void 0 ? void 0 : n.next) === null || r === void 0 || r.call(n, t)
        }
        error(t) {
            var n, r;
            (r = (n = this.destination) === null || n === void 0 ? void 0 : n.error) === null || r === void 0 || r.call(n, t)
        }
        complete() {
            var t, n;
            (n = (t = this.destination) === null || t === void 0 ? void 0 : t.complete) === null || n === void 0 || n.call(t)
        }
        _subscribe(t) {
            var n, r;
            return (r = (n = this.source) === null || n === void 0 ? void 0 : n.subscribe(t)) !== null && r !== void 0 ? r : Zu
        }
    };
var ye = class extends ne {
    constructor(t) {
        super(), this._value = t
    }
    get value() {
        return this.getValue()
    }
    _subscribe(t) {
        let n = super._subscribe(t);
        return !n.closed && t.next(this._value), n
    }
    getValue() {
        let {
            hasError: t,
            thrownError: n,
            _value: r
        } = this;
        if (t) throw n;
        return this._throwIfClosed(), r
    }
    next(t) {
        super.next(this._value = t)
    }
};
var Ii = {
    now() {
        return (Ii.delegate || Date).now()
    },
    delegate: void 0
};
var Ti = class extends ne {
    constructor(t = 1 / 0, n = 1 / 0, r = Ii) {
        super(), this._bufferSize = t, this._windowTime = n, this._timestampProvider = r, this._buffer = [], this._infiniteTimeWindow = !0, this._infiniteTimeWindow = n === 1 / 0, this._bufferSize = Math.max(1, t), this._windowTime = Math.max(1, n)
    }
    next(t) {
        let {
            isStopped: n,
            _buffer: r,
            _infiniteTimeWindow: o,
            _timestampProvider: i,
            _windowTime: s
        } = this;
        n || (r.push(t), !o && r.push(i.now() + s)), this._trimBuffer(), super.next(t)
    }
    _subscribe(t) {
        this._throwIfClosed(), this._trimBuffer();
        let n = this._innerSubscribe(t),
            {
                _infiniteTimeWindow: r,
                _buffer: o
            } = this,
            i = o.slice();
        for (let s = 0; s < i.length && !t.closed; s += r ? 1 : 2) t.next(i[s]);
        return this._checkFinalizedStatuses(t), n
    }
    _trimBuffer() {
        let {
            _bufferSize: t,
            _timestampProvider: n,
            _buffer: r,
            _infiniteTimeWindow: o
        } = this, i = (o ? 1 : 2) * t;
        if (t < 1 / 0 && i < r.length && r.splice(0, r.length - i), !o) {
            let s = n.now(),
                a = 0;
            for (let c = 1; c < r.length && r[c] <= s; c += 2) a = c;
            a && r.splice(0, a + 1)
        }
    }
};
var sd = class extends ne {
    constructor() {
        super(...arguments), this._value = null, this._hasValue = !1, this._isComplete = !1
    }
    _checkFinalizedStatuses(t) {
        let {
            hasError: n,
            _hasValue: r,
            _value: o,
            thrownError: i,
            isStopped: s,
            _isComplete: a
        } = this;
        n ? t.error(i) : (s || a) && (r && t.next(o), t.complete())
    }
    next(t) {
        this.isStopped || (this._value = t, this._hasValue = !0)
    }
    complete() {
        let {
            _hasValue: t,
            _value: n,
            _isComplete: r
        } = this;
        r || (this._isComplete = !0, t && super.next(n), super.complete())
    }
};
var Da = class extends oe {
    constructor(t, n) {
        super()
    }
    schedule(t, n = 0) {
        return this
    }
};
var Si = {
    setInterval(e, t, ...n) {
        let {
            delegate: r
        } = Si;
        return r ? .setInterval ? r.setInterval(e, t, ...n) : setInterval(e, t, ...n)
    },
    clearInterval(e) {
        let {
            delegate: t
        } = Si;
        return (t ? .clearInterval || clearInterval)(e)
    },
    delegate: void 0
};
var mo = class extends Da {
    constructor(t, n) {
        super(t, n), this.scheduler = t, this.work = n, this.pending = !1
    }
    schedule(t, n = 0) {
        var r;
        if (this.closed) return this;
        this.state = t;
        let o = this.id,
            i = this.scheduler;
        return o != null && (this.id = this.recycleAsyncId(i, o, n)), this.pending = !0, this.delay = n, this.id = (r = this.id) !== null && r !== void 0 ? r : this.requestAsyncId(i, this.id, n), this
    }
    requestAsyncId(t, n, r = 0) {
        return Si.setInterval(t.flush.bind(t, this), r)
    }
    recycleAsyncId(t, n, r = 0) {
        if (r != null && this.delay === r && this.pending === !1) return n;
        n != null && Si.clearInterval(n)
    }
    execute(t, n) {
        if (this.closed) return new Error("executing a cancelled action");
        this.pending = !1;
        let r = this._execute(t, n);
        if (r) return r;
        this.pending === !1 && this.id != null && (this.id = this.recycleAsyncId(this.scheduler, this.id, null))
    }
    _execute(t, n) {
        let r = !1,
            o;
        try {
            this.work(t)
        } catch (i) {
            r = !0, o = i || new Error("Scheduled action threw falsy error")
        }
        if (r) return this.unsubscribe(), o
    }
    unsubscribe() {
        if (!this.closed) {
            let {
                id: t,
                scheduler: n
            } = this, {
                actions: r
            } = n;
            this.work = this.state = this.scheduler = null, this.pending = !1, _r(r, this), t != null && (this.id = this.recycleAsyncId(n, t, null)), this.delay = null, super.unsubscribe()
        }
    }
};
var go = class e {
    constructor(t, n = e.now) {
        this.schedulerActionCtor = t, this.now = n
    }
    schedule(t, n = 0, r) {
        return new this.schedulerActionCtor(this, t).schedule(r, n)
    }
};
go.now = Ii.now;
var Eo = class extends go {
    constructor(t, n = go.now) {
        super(t, n), this.actions = [], this._active = !1
    }
    flush(t) {
        let {
            actions: n
        } = this;
        if (this._active) {
            n.push(t);
            return
        }
        let r;
        this._active = !0;
        do
            if (r = t.execute(t.state, t.delay)) break; while (t = n.shift());
        if (this._active = !1, r) {
            for (; t = n.shift();) t.unsubscribe();
            throw r
        }
    }
};
var Mt = new Eo(mo),
    Ng = Mt;
var _a = class extends mo {
    constructor(t, n) {
        super(t, n), this.scheduler = t, this.work = n
    }
    requestAsyncId(t, n, r = 0) {
        return r !== null && r > 0 ? super.requestAsyncId(t, n, r) : (t.actions.push(this), t._scheduled || (t._scheduled = ho.requestAnimationFrame(() => t.flush(void 0))))
    }
    recycleAsyncId(t, n, r = 0) {
        var o;
        if (r != null ? r > 0 : this.delay > 0) return super.recycleAsyncId(t, n, r);
        let {
            actions: i
        } = t;
        n != null && n === t._scheduled && ((o = i[i.length - 1]) === null || o === void 0 ? void 0 : o.id) !== n && (ho.cancelAnimationFrame(n), t._scheduled = void 0)
    }
};
var xa = class extends Eo {
    flush(t) {
        this._active = !0;
        let n;
        t ? n = t.id : (n = this._scheduled, this._scheduled = void 0);
        let {
            actions: r
        } = this, o;
        t = t || r.shift();
        do
            if (o = t.execute(t.state, t.delay)) break; while ((t = r[0]) && t.id === n && r.shift());
        if (this._active = !1, o) {
            for (;
                (t = r[0]) && t.id === n && r.shift();) t.unsubscribe();
            throw o
        }
    }
};
var LI = new xa(_a);
var ve = new P(e => e.complete());

function Ca(e) {
    return e && w(e.schedule)
}

function ad(e) {
    return e[e.length - 1]
}

function Ia(e) {
    return w(ad(e)) ? e.pop() : void 0
}

function qt(e) {
    return Ca(ad(e)) ? e.pop() : void 0
}

function Rg(e, t) {
    return typeof ad(e) == "number" ? e.pop() : t
}
var cd = function(e, t) {
    return cd = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(n, r) {
        n.__proto__ = r
    } || function(n, r) {
        for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (n[o] = r[o])
    }, cd(e, t)
};

function ZU(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
    cd(e, t);

    function n() {
        this.constructor = e
    }
    e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n)
}
var Og = function() {
    return Og = Object.assign || function(t) {
        for (var n, r = 1, o = arguments.length; r < o; r++) {
            n = arguments[r];
            for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
        }
        return t
    }, Og.apply(this, arguments)
};

function XU(e, t, n, r) {
    var o = arguments.length,
        i = o < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, n) : r,
        s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(e, t, n, r);
    else
        for (var a = e.length - 1; a >= 0; a--)(s = e[a]) && (i = (o < 3 ? s(i) : o > 3 ? s(t, n, i) : s(t, n)) || i);
    return o > 3 && i && Object.defineProperty(t, n, i), i
}

function Lg(e, t, n, r) {
    function o(i) {
        return i instanceof n ? i : new n(function(s) {
            s(i)
        })
    }
    return new(n || (n = Promise))(function(i, s) {
        function a(u) {
            try {
                l(r.next(u))
            } catch (d) {
                s(d)
            }
        }

        function c(u) {
            try {
                l(r.throw(u))
            } catch (d) {
                s(d)
            }
        }

        function l(u) {
            u.done ? i(u.value) : o(u.value).then(a, c)
        }
        l((r = r.apply(e, t || [])).next())
    })
}

function Pg(e) {
    var t = typeof Symbol == "function" && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && typeof e.length == "number") return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function eB(e, t, n) {
    if (n || arguments.length === 2)
        for (var r = 0, o = t.length, i; r < o; r++)(i || !(r in t)) && (i || (i = Array.prototype.slice.call(t, 0, r)), i[r] = t[r]);
    return e.concat(i || Array.prototype.slice.call(t))
}

function Ir(e) {
    return this instanceof Ir ? (this.v = e, this) : new Ir(e)
}

function kg(e, t, n) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var r = n.apply(e, t || []),
        o, i = [];
    return o = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), a("next"), a("throw"), a("return", s), o[Symbol.asyncIterator] = function() {
        return this
    }, o;

    function s(p) {
        return function(m) {
            return Promise.resolve(m).then(p, d)
        }
    }

    function a(p, m) {
        r[p] && (o[p] = function(x) {
            return new Promise(function(D, I) {
                i.push([p, x, D, I]) > 1 || c(p, x)
            })
        }, m && (o[p] = m(o[p])))
    }

    function c(p, m) {
        try {
            l(r[p](m))
        } catch (x) {
            f(i[0][3], x)
        }
    }

    function l(p) {
        p.value instanceof Ir ? Promise.resolve(p.value.v).then(u, d) : f(i[0][2], p)
    }

    function u(p) {
        c("next", p)
    }

    function d(p) {
        c("throw", p)
    }

    function f(p, m) {
        p(m), i.shift(), i.length && c(i[0][0], i[0][1])
    }
}

function Fg(e) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var t = e[Symbol.asyncIterator],
        n;
    return t ? t.call(e) : (e = typeof Pg == "function" ? Pg(e) : e[Symbol.iterator](), n = {}, r("next"), r("throw"), r("return"), n[Symbol.asyncIterator] = function() {
        return this
    }, n);

    function r(i) {
        n[i] = e[i] && function(s) {
            return new Promise(function(a, c) {
                s = e[i](s), o(a, c, s.done, s.value)
            })
        }
    }

    function o(i, s, a, c) {
        Promise.resolve(c).then(function(l) {
            i({
                value: l,
                done: a
            })
        }, s)
    }
}
var yo = e => e && typeof e.length == "number" && typeof e != "function";

function Ta(e) {
    return w(e ? .then)
}

function Sa(e) {
    return w(e[po])
}

function ba(e) {
    return Symbol.asyncIterator && w(e ? .[Symbol.asyncIterator])
}

function wa(e) {
    return new TypeError(`You provided ${e!==null&&typeof e=="object"?"an invalid object":`'${e}'`} where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.`)
}

function kI() {
    return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator
}
var Aa = kI();

function Ma(e) {
    return w(e ? .[Aa])
}

function Na(e) {
    return kg(this, arguments, function*() {
        let n = e.getReader();
        try {
            for (;;) {
                let {
                    value: r,
                    done: o
                } = yield Ir(n.read());
                if (o) return yield Ir(void 0);
                yield yield Ir(r)
            }
        } finally {
            n.releaseLock()
        }
    })
}

function Ra(e) {
    return w(e ? .getReader)
}

function U(e) {
    if (e instanceof P) return e;
    if (e != null) {
        if (Sa(e)) return FI(e);
        if (yo(e)) return UI(e);
        if (Ta(e)) return BI(e);
        if (ba(e)) return Ug(e);
        if (Ma(e)) return jI(e);
        if (Ra(e)) return HI(e)
    }
    throw wa(e)
}

function FI(e) {
    return new P(t => {
        let n = e[po]();
        if (w(n.subscribe)) return n.subscribe(t);
        throw new TypeError("Provided object does not correctly implement Symbol.observable")
    })
}

function UI(e) {
    return new P(t => {
        for (let n = 0; n < e.length && !t.closed; n++) t.next(e[n]);
        t.complete()
    })
}

function BI(e) {
    return new P(t => {
        e.then(n => {
            t.closed || (t.next(n), t.complete())
        }, n => t.error(n)).then(null, Ea)
    })
}

function jI(e) {
    return new P(t => {
        for (let n of e)
            if (t.next(n), t.closed) return;
        t.complete()
    })
}

function Ug(e) {
    return new P(t => {
        VI(e, t).catch(n => t.error(n))
    })
}

function HI(e) {
    return Ug(Na(e))
}

function VI(e, t) {
    var n, r, o, i;
    return Lg(this, void 0, void 0, function*() {
        try {
            for (n = Fg(e); r = yield n.next(), !r.done;) {
                let s = r.value;
                if (t.next(s), t.closed) return
            }
        } catch (s) {
            o = {
                error: s
            }
        } finally {
            try {
                r && !r.done && (i = n.return) && (yield i.call(n))
            } finally {
                if (o) throw o.error
            }
        }
        t.complete()
    })
}

function Me(e, t, n, r = 0, o = !1) {
    let i = t.schedule(function() {
        n(), o ? e.add(this.schedule(null, r)) : this.unsubscribe()
    }, r);
    if (e.add(i), !o) return i
}

function Oa(e, t = 0) {
    return A((n, r) => {
        n.subscribe(M(r, o => Me(r, e, () => r.next(o), t), () => Me(r, e, () => r.complete(), t), o => Me(r, e, () => r.error(o), t)))
    })
}

function Pa(e, t = 0) {
    return A((n, r) => {
        r.add(e.schedule(() => n.subscribe(r), t))
    })
}

function Bg(e, t) {
    return U(e).pipe(Pa(t), Oa(t))
}

function jg(e, t) {
    return U(e).pipe(Pa(t), Oa(t))
}

function Hg(e, t) {
    return new P(n => {
        let r = 0;
        return t.schedule(function() {
            r === e.length ? n.complete() : (n.next(e[r++]), n.closed || this.schedule())
        })
    })
}

function Vg(e, t) {
    return new P(n => {
        let r;
        return Me(n, t, () => {
            r = e[Aa](), Me(n, t, () => {
                let o, i;
                try {
                    ({
                        value: o,
                        done: i
                    } = r.next())
                } catch (s) {
                    n.error(s);
                    return
                }
                i ? n.complete() : n.next(o)
            }, 0, !0)
        }), () => w(r ? .return) && r.return()
    })
}

function La(e, t) {
    if (!e) throw new Error("Iterable cannot be null");
    return new P(n => {
        Me(n, t, () => {
            let r = e[Symbol.asyncIterator]();
            Me(n, t, () => {
                r.next().then(o => {
                    o.done ? n.complete() : n.next(o.value)
                })
            }, 0, !0)
        })
    })
}

function $g(e, t) {
    return La(Na(e), t)
}

function Gg(e, t) {
    if (e != null) {
        if (Sa(e)) return Bg(e, t);
        if (yo(e)) return Hg(e, t);
        if (Ta(e)) return jg(e, t);
        if (ba(e)) return La(e, t);
        if (Ma(e)) return Vg(e, t);
        if (Ra(e)) return $g(e, t)
    }
    throw wa(e)
}

function J(e, t) {
    return t ? Gg(e, t) : U(e)
}

function R(...e) {
    let t = qt(e);
    return J(e, t)
}

function bi(e, t) {
    let n = w(e) ? e : () => e,
        r = o => o.error(n());
    return new P(t ? o => t.schedule(r, 0, o) : r)
}

function ka(e) {
    return !!e && (e instanceof P || w(e.lift) && w(e.subscribe))
}
var Nt = Wn(e => function() {
    e(this), this.name = "EmptyError", this.message = "no elements in sequence"
});

function $I(e, t) {
    let n = typeof t == "object";
    return new Promise((r, o) => {
        let i = !1,
            s;
        e.subscribe({
            next: a => {
                s = a, i = !0
            },
            error: o,
            complete: () => {
                i ? r(s) : n ? r(t.defaultValue) : o(new Nt)
            }
        })
    })
}

function GI(e, t) {
    let n = typeof t == "object";
    return new Promise((r, o) => {
        let i = new At({
            next: s => {
                r(s), i.unsubscribe()
            },
            error: o,
            complete: () => {
                n ? r(t.defaultValue) : o(new Nt)
            }
        });
        e.subscribe(i)
    })
}

function Fa(e) {
    return e instanceof Date && !isNaN(e)
}
var WI = Wn(e => function(n = null) {
    e(this), this.message = "Timeout has occurred", this.name = "TimeoutError", this.info = n
});

function zI(e, t) {
    let {
        first: n,
        each: r,
        with: o = qI,
        scheduler: i = t ? ? Mt,
        meta: s = null
    } = Fa(e) ? {
        first: e
    } : typeof e == "number" ? {
        each: e
    } : e;
    if (n == null && r == null) throw new TypeError("No timeout provided.");
    return A((a, c) => {
        let l, u, d = null,
            f = 0,
            p = m => {
                u = Me(c, i, () => {
                    try {
                        l.unsubscribe(), U(o({
                            meta: s,
                            lastValue: d,
                            seen: f
                        })).subscribe(c)
                    } catch (x) {
                        c.error(x)
                    }
                }, m)
            };
        l = a.subscribe(M(c, m => {
            u ? .unsubscribe(), f++, c.next(d = m), r > 0 && p(r)
        }, void 0, void 0, () => {
            u ? .closed || u ? .unsubscribe(), d = null
        })), !f && p(n != null ? typeof n == "number" ? n : +n - i.now() : r)
    })
}

function qI(e) {
    throw new WI(e)
}

function j(e, t) {
    return A((n, r) => {
        let o = 0;
        n.subscribe(M(r, i => {
            r.next(e.call(t, i, o++))
        }))
    })
}
var {
    isArray: KI
} = Array;

function YI(e, t) {
    return KI(t) ? e(...t) : e(t)
}

function vo(e) {
    return j(t => YI(e, t))
}
var {
    isArray: JI
} = Array, {
    getPrototypeOf: QI,
    prototype: ZI,
    keys: XI
} = Object;

function Ua(e) {
    if (e.length === 1) {
        let t = e[0];
        if (JI(t)) return {
            args: t,
            keys: null
        };
        if (eT(t)) {
            let n = XI(t);
            return {
                args: n.map(r => t[r]),
                keys: n
            }
        }
    }
    return {
        args: e,
        keys: null
    }
}

function eT(e) {
    return e && typeof e == "object" && QI(e) === ZI
}

function Ba(e, t) {
    return e.reduce((n, r, o) => (n[r] = t[o], n), {})
}

function ja(...e) {
    let t = qt(e),
        n = Ia(e),
        {
            args: r,
            keys: o
        } = Ua(e);
    if (r.length === 0) return J([], t);
    let i = new P(tT(r, t, o ? s => Ba(o, s) : et));
    return n ? i.pipe(vo(n)) : i
}

function tT(e, t, n = et) {
    return r => {
        Wg(t, () => {
            let {
                length: o
            } = e, i = new Array(o), s = o, a = o;
            for (let c = 0; c < o; c++) Wg(t, () => {
                let l = J(e[c], t),
                    u = !1;
                l.subscribe(M(r, d => {
                    i[c] = d, u || (u = !0, a--), a || r.next(n(i.slice()))
                }, () => {
                    --s || r.complete()
                }))
            }, r)
        }, r)
    }
}

function Wg(e, t, n) {
    e ? Me(n, e, t) : t()
}

function zg(e, t, n, r, o, i, s, a) {
    let c = [],
        l = 0,
        u = 0,
        d = !1,
        f = () => {
            d && !c.length && !l && t.complete()
        },
        p = x => l < r ? m(x) : c.push(x),
        m = x => {
            i && t.next(x), l++;
            let D = !1;
            U(n(x, u++)).subscribe(M(t, I => {
                o ? .(I), i ? p(I) : t.next(I)
            }, () => {
                D = !0
            }, void 0, () => {
                if (D) try {
                    for (l--; c.length && l < r;) {
                        let I = c.shift();
                        s ? Me(t, s, () => m(I)) : m(I)
                    }
                    f()
                } catch (I) {
                    t.error(I)
                }
            }))
        };
    return e.subscribe(M(t, p, () => {
        d = !0, f()
    })), () => {
        a ? .()
    }
}

function de(e, t, n = 1 / 0) {
    return w(t) ? de((r, o) => j((i, s) => t(r, i, o, s))(U(e(r, o))), n) : (typeof t == "number" && (n = t), A((r, o) => zg(r, o, e, n)))
}

function Kt(e = 1 / 0) {
    return de(et, e)
}

function qg() {
    return Kt(1)
}

function zn(...e) {
    return qg()(J(e, qt(e)))
}

function wi(e) {
    return new P(t => {
        U(e()).subscribe(t)
    })
}

function nT(...e) {
    let t = Ia(e),
        {
            args: n,
            keys: r
        } = Ua(e),
        o = new P(i => {
            let {
                length: s
            } = n;
            if (!s) {
                i.complete();
                return
            }
            let a = new Array(s),
                c = s,
                l = s;
            for (let u = 0; u < s; u++) {
                let d = !1;
                U(n[u]).subscribe(M(i, f => {
                    d || (d = !0, l--), a[u] = f
                }, () => c--, void 0, () => {
                    (!c || !d) && (l || i.next(r ? Ba(r, a) : a), i.complete())
                }))
            }
        });
    return t ? o.pipe(vo(t)) : o
}
var rT = ["addListener", "removeListener"],
    oT = ["addEventListener", "removeEventListener"],
    iT = ["on", "off"];

function ld(e, t, n, r) {
    if (w(n) && (r = n, n = void 0), r) return ld(e, t, n).pipe(vo(r));
    let [o, i] = cT(e) ? oT.map(s => a => e[s](t, a, n)) : sT(e) ? rT.map(Kg(e, t)) : aT(e) ? iT.map(Kg(e, t)) : [];
    if (!o && yo(e)) return de(s => ld(s, t, n))(U(e));
    if (!o) throw new TypeError("Invalid event target");
    return new P(s => {
        let a = (...c) => s.next(1 < c.length ? c : c[0]);
        return o(a), () => i(a)
    })
}

function Kg(e, t) {
    return n => r => e[n](t, r)
}

function sT(e) {
    return w(e.addListener) && w(e.removeListener)
}

function aT(e) {
    return w(e.on) && w(e.off)
}

function cT(e) {
    return w(e.addEventListener) && w(e.removeEventListener)
}

function Tr(e = 0, t, n = Ng) {
    let r = -1;
    return t != null && (Ca(t) ? n = t : r = t), new P(o => {
        let i = Fa(e) ? +e - n.now() : e;
        i < 0 && (i = 0);
        let s = 0;
        return n.schedule(function() {
            o.closed || (o.next(s++), 0 <= r ? this.schedule(void 0, r) : o.complete())
        }, i)
    })
}

function lT(e = 0, t = Mt) {
    return e < 0 && (e = 0), Tr(e, e, t)
}

function uT(...e) {
    let t = qt(e),
        n = Rg(e, 1 / 0),
        r = e;
    return r.length ? r.length === 1 ? U(r[0]) : Kt(n)(J(r, t)) : ve
}
var dT = new P(pn);

function Ne(e, t) {
    return A((n, r) => {
        let o = 0;
        n.subscribe(M(r, i => e.call(t, i, o++) && r.next(i)))
    })
}

function Yg(e) {
    return A((t, n) => {
        let r = !1,
            o = null,
            i = null,
            s = !1,
            a = () => {
                if (i ? .unsubscribe(), i = null, r) {
                    r = !1;
                    let l = o;
                    o = null, n.next(l)
                }
                s && n.complete()
            },
            c = () => {
                i = null, s && n.complete()
            };
        t.subscribe(M(n, l => {
            r = !0, o = l, i || U(e(l)).subscribe(i = M(n, a, c))
        }, () => {
            s = !0, (!r || !i || i.closed) && n.complete()
        }))
    })
}

function fT(e, t = Mt) {
    return Yg(() => Tr(e, t))
}

function hn(e) {
    return A((t, n) => {
        let r = null,
            o = !1,
            i;
        r = t.subscribe(M(n, void 0, void 0, s => {
            i = U(e(s, hn(e)(t))), r ? (r.unsubscribe(), r = null, i.subscribe(n)) : o = !0
        })), o && (r.unsubscribe(), r = null, i.subscribe(n))
    })
}

function qn(e, t) {
    return w(t) ? de(e, t, 1) : de(e, 1)
}

function Jg(e, t = Mt) {
    return A((n, r) => {
        let o = null,
            i = null,
            s = null,
            a = () => {
                if (o) {
                    o.unsubscribe(), o = null;
                    let l = i;
                    i = null, r.next(l)
                }
            };

        function c() {
            let l = s + e,
                u = t.now();
            if (u < l) {
                o = this.schedule(void 0, l - u), r.add(o);
                return
            }
            a()
        }
        n.subscribe(M(r, l => {
            i = l, s = t.now(), o || (o = t.schedule(c, e), r.add(o))
        }, () => {
            a(), r.complete()
        }, void 0, () => {
            i = o = null
        }))
    })
}

function Qg(e) {
    return A((t, n) => {
        let r = !1;
        t.subscribe(M(n, o => {
            r = !0, n.next(o)
        }, () => {
            r || n.next(e), n.complete()
        }))
    })
}

function tt(e) {
    return e <= 0 ? () => ve : A((t, n) => {
        let r = 0;
        t.subscribe(M(n, o => {
            ++r <= e && (n.next(o), e <= r && n.complete())
        }))
    })
}

function Zg() {
    return A((e, t) => {
        e.subscribe(M(t, pn))
    })
}

function Xg(e) {
    return j(() => e)
}

function ud(e, t) {
    return t ? n => zn(t.pipe(tt(1), Zg()), n.pipe(ud(e))) : de((n, r) => U(e(n, r)).pipe(tt(1), Xg(n)))
}

function pT(e, t = Mt) {
    let n = Tr(e, t);
    return ud(() => n)
}

function dd(e, t = et) {
    return e = e ? ? hT, A((n, r) => {
        let o, i = !0;
        n.subscribe(M(r, s => {
            let a = t(s);
            (i || !e(o, a)) && (i = !1, o = a, r.next(s))
        }))
    })
}

function hT(e, t) {
    return e === t
}

function eE(e = mT) {
    return A((t, n) => {
        let r = !1;
        t.subscribe(M(n, o => {
            r = !0, n.next(o)
        }, () => r ? n.complete() : n.error(e())))
    })
}

function mT() {
    return new Nt
}

function gT(e, t) {
    return A((n, r) => {
        let o = 0;
        n.subscribe(M(r, i => {
            e.call(t, i, o++, n) || (r.next(!1), r.complete())
        }, () => {
            r.next(!0), r.complete()
        }))
    })
}

function tE(e, t) {
    return t ? n => n.pipe(tE((r, o) => U(e(r, o)).pipe(j((i, s) => t(r, i, o, s))))) : A((n, r) => {
        let o = 0,
            i = null,
            s = !1;
        n.subscribe(M(r, a => {
            i || (i = M(r, void 0, () => {
                i = null, s && r.complete()
            }), U(e(a, o++)).subscribe(i))
        }, () => {
            s = !0, !i && r.complete()
        }))
    })
}

function Do(e) {
    return A((t, n) => {
        try {
            t.subscribe(n)
        } finally {
            n.add(e)
        }
    })
}

function mn(e, t) {
    let n = arguments.length >= 2;
    return r => r.pipe(e ? Ne((o, i) => e(o, i, r)) : et, tt(1), n ? Qg(t) : eE(() => new Nt))
}

function Ha(e) {
    return e <= 0 ? () => ve : A((t, n) => {
        let r = [];
        t.subscribe(M(n, o => {
            r.push(o), e < r.length && r.shift()
        }, () => {
            for (let o of r) n.next(o);
            n.complete()
        }, void 0, () => {
            r = null
        }))
    })
}

function nE(e = {}) {
    let {
        connector: t = () => new ne,
        resetOnError: n = !0,
        resetOnComplete: r = !0,
        resetOnRefCountZero: o = !0
    } = e;
    return i => {
        let s, a, c, l = 0,
            u = !1,
            d = !1,
            f = () => {
                a ? .unsubscribe(), a = void 0
            },
            p = () => {
                f(), s = c = void 0, u = d = !1
            },
            m = () => {
                let x = s;
                p(), x ? .unsubscribe()
            };
        return A((x, D) => {
            l++, !d && !u && f();
            let I = c = c ? ? t();
            D.add(() => {
                l--, l === 0 && !d && !u && (a = fd(m, o))
            }), I.subscribe(D), !s && l > 0 && (s = new At({
                next: F => I.next(F),
                error: F => {
                    d = !0, f(), a = fd(p, n, F), I.error(F)
                },
                complete: () => {
                    u = !0, f(), a = fd(p, r), I.complete()
                }
            }), U(x).subscribe(s))
        })(i)
    }
}

function fd(e, t, ...n) {
    if (t === !0) {
        e();
        return
    }
    if (t === !1) return;
    let r = new At({
        next: () => {
            r.unsubscribe(), e()
        }
    });
    return U(t(...n)).subscribe(r)
}

function rE(e, t, n) {
    let r, o = !1;
    return e && typeof e == "object" ? {
        bufferSize: r = 1 / 0,
        windowTime: t = 1 / 0,
        refCount: o = !1,
        scheduler: n
    } = e : r = e ? ? 1 / 0, nE({
        connector: () => new Ti(r, t, n),
        resetOnError: !0,
        resetOnComplete: !1,
        resetOnRefCountZero: o
    })
}

function ET(e) {
    return Ne((t, n) => e <= n)
}

function pd(...e) {
    let t = qt(e);
    return A((n, r) => {
        (t ? zn(e, n, t) : zn(e, n)).subscribe(r)
    })
}

function Ue(e, t) {
    return A((n, r) => {
        let o = null,
            i = 0,
            s = !1,
            a = () => s && !o && r.complete();
        n.subscribe(M(r, c => {
            o ? .unsubscribe();
            let l = 0,
                u = i++;
            U(e(c, u)).subscribe(o = M(r, d => r.next(t ? t(c, d, u, l++) : d), () => {
                o = null, a()
            }))
        }, () => {
            s = !0, a()
        }))
    })
}

function _o(e) {
    return A((t, n) => {
        U(e).subscribe(M(n, () => n.complete(), pn)), !n.closed && t.subscribe(n)
    })
}

function yT(e, t = !1) {
    return A((n, r) => {
        let o = 0;
        n.subscribe(M(r, i => {
            let s = e(i, o++);
            (s || t) && r.next(i), !s && r.complete()
        }))
    })
}

function nt(e, t, n) {
    let r = w(e) || t || n ? {
        next: e,
        error: t,
        complete: n
    } : e;
    return r ? A((o, i) => {
        var s;
        (s = r.subscribe) === null || s === void 0 || s.call(r);
        let a = !0;
        o.subscribe(M(i, c => {
            var l;
            (l = r.next) === null || l === void 0 || l.call(r, c), i.next(c)
        }, () => {
            var c;
            a = !1, (c = r.complete) === null || c === void 0 || c.call(r), i.complete()
        }, c => {
            var l;
            a = !1, (l = r.error) === null || l === void 0 || l.call(r, c), i.error(c)
        }, () => {
            var c, l;
            a && ((c = r.unsubscribe) === null || c === void 0 || c.call(r)), (l = r.finalize) === null || l === void 0 || l.call(r)
        }))
    }) : et
}
var hd;

function Va() {
    return hd
}

function Yt(e) {
    let t = hd;
    return hd = e, t
}
var oE = Symbol("NotFound");

function xo(e) {
    return e === oE || e ? .name === "\u0275NotFound"
}

function md(e, t, n) {
    let r = Object.create(vT);
    r.source = e, r.computation = t, n != null && (r.equal = n);
    let i = () => {
        if (yr(r), Vn(r), r.value === zt) throw r.error;
        return r.value
    };
    return i[ue] = r, _i(r), i
}

function iE(e, t) {
    yr(e), Gn(e, t), co(e)
}

function sE(e, t) {
    if (yr(e), e.value === zt) throw e.error;
    pa(e, t), co(e)
}
var vT = B(E({}, Hn), {
    value: gr,
    dirty: !0,
    error: null,
    equal: xi,
    kind: "linkedSignal",
    producerMustRecompute(e) {
        return e.value === gr || e.value === Er
    },
    producerRecomputeValue(e) {
        if (e.value === Er) throw new Error("");
        let t = e.value;
        e.value = Er;
        let n = $n(e),
            r, o = !1;
        try {
            let i = e.source(),
                s = t !== gr && t !== zt,
                a = s ? {
                    source: e.sourceValue,
                    value: t
                } : void 0;
            r = e.computation(i, a), e.sourceValue = i, S(null), o = s && r !== zt && e.equal(t, r)
        } catch (i) {
            r = zt, e.error = i
        } finally {
            vr(e, n)
        }
        if (o) {
            e.value = t;
            return
        }
        e.value = r, e.version++
    }
});

function aE(e) {
    let t = S(null);
    try {
        return e()
    } finally {
        S(t)
    }
}
var Io = class {
        full;
        major;
        minor;
        patch;
        constructor(t) {
            this.full = t;
            let n = t.split(".");
            this.major = n[0], this.minor = n[1], this.patch = n.slice(2).join(".")
        }
    },
    DT = new Io("21.2.14");
var Ya = "https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss",
    g = class extends Error {
        code;
        constructor(t, n) {
            super(dt(t, n)), this.code = t
        }
    };

function _T(e) {
    return `NG0${Math.abs(e)}`
}

function dt(e, t) {
    return `${_T(e)}${t?": "+t:""}`
}
var ge = globalThis;

function $(e) {
    for (let t in e)
        if (e[t] === $) return t;
    throw Error("")
}

function fE(e, t) {
    for (let n in t) t.hasOwnProperty(n) && !e.hasOwnProperty(n) && (e[n] = t[n])
}

function Li(e) {
    if (typeof e == "string") return e;
    if (Array.isArray(e)) return `[${e.map(Li).join(", ")}]`;
    if (e == null) return "" + e;
    let t = e.overriddenName || e.name;
    if (t) return `${t}`;
    let n = e.toString();
    if (n == null) return "" + n;
    let r = n.indexOf(`
`);
    return r >= 0 ? n.slice(0, r) : n
}

function Ja(e, t) {
    return e ? t ? `${e} ${t}` : e : t || ""
}
var xT = $({
    __forward_ref__: $
});

function Qa(e) {
    return e.__forward_ref__ = Qa, e
}

function Se(e) {
    return wd(e) ? e() : e
}

function wd(e) {
    return typeof e == "function" && e.hasOwnProperty(xT) && e.__forward_ref__ === Qa
}

function y(e) {
    return {
        token: e.token,
        providedIn: e.providedIn || null,
        factory: e.factory,
        value: void 0
    }
}

function ft(e) {
    return {
        providers: e.providers || [],
        imports: e.imports || []
    }
}

function ki(e) {
    return CT(e, Za)
}

function Ad(e) {
    return ki(e) !== null
}

function CT(e, t) {
    return e.hasOwnProperty(t) && e[t] || null
}

function IT(e) {
    let t = e ? .[Za] ? ? null;
    return t || null
}

function Ed(e) {
    return e && e.hasOwnProperty(Ga) ? e[Ga] : null
}
var Za = $({\
        u0275prov: $
    }),
    Ga = $({\
        u0275inj: $
    }),
    v = class {
        _desc;
        ngMetadataName = "InjectionToken";\
        u0275prov;
        constructor(t, n) {
            this._desc = t, this.\u0275prov = void 0, typeof n == "number" ? this.__NG_ELEMENT_ID__ = n : n !== void 0 && (this.\u0275prov = y({
                token: this,
                providedIn: n.providedIn || "root",
                factory: n.factory
            }))
        }
        get multi() {
            return this
        }
        toString() {
            return `InjectionToken ${this._desc}`
        }
    };

function Md(e) {
    return e && !!e.\u0275providers
}
var Nd = $({\
        u0275cmp: $
    }),
    Rd = $({\
        u0275dir: $
    }),
    Od = $({\
        u0275pipe: $
    }),
    Pd = $({\
        u0275mod: $
    }),
    Mi = $({\
        u0275fac: $
    }),
    Mr = $({
        __NG_ELEMENT_ID__: $
    }),
    cE = $({
        __NG_ENV_ID__: $
    });

function Ld(e) {
    return Xa(e, "@NgModule"), e[Pd] || null
}

function Qt(e) {
    return Xa(e, "@Component"), e[Nd] || null
}

function kd(e) {
    return Xa(e, "@Directive"), e[Rd] || null
}

function Fd(e) {
    return Xa(e, "@Pipe"), e[Od] || null
}

function Xa(e, t) {
    if (e == null) throw new g(-919, !1)
}

function pe(e) {
    return typeof e == "string" ? e : e == null ? "" : String(e)
}
var pE = $({
        ngErrorCode: $
    }),
    TT = $({
        ngErrorMessage: $
    }),
    ST = $({
        ngTokenPath: $
    });

function Ud(e, t) {
    return hE("", -200, t)
}

function ec(e, t) {
    throw new g(-201, !1)
}

function hE(e, t, n) {
    let r = new g(t, e);
    return r[pE] = t, r[TT] = e, n && (r[ST] = n), r
}

function bT(e) {
    return e[pE]
}
var yd;

function mE() {
    return yd
}

function Be(e) {
    let t = yd;
    return yd = e, t
}

function Bd(e, t, n) {
    let r = ki(e);
    if (r && r.providedIn == "root") return r.value === void 0 ? r.value = r.factory() : r.value;
    if (n & 8) return null;
    if (t !== void 0) return t;
    ec(e, "")
}
var wT = {},
    Sr = wT,
    AT = "__NG_DI_FLAG__",
    vd = class {
        injector;
        constructor(t) {
            this.injector = t
        }
        retrieve(t, n) {
            let r = br(n) || 0;
            try {
                return this.injector.get(t, r & 8 ? null : Sr, r)
            } catch (o) {
                if (xo(o)) return o;
                throw o
            }
        }
    };

function MT(e, t = 0) {
    let n = Va();
    if (n === void 0) throw new g(-203, !1);
    if (n === null) return Bd(e, void 0, t); {
        let r = NT(t),
            o = n.retrieve(e, r);
        if (xo(o)) {
            if (r.optional) return null;
            throw o
        }
        return o
    }
}

function _(e, t = 0) {
    return (mE() || MT)(Se(e), t)
}

function h(e, t) {
    return _(e, br(t))
}

function br(e) {
    return typeof e > "u" || typeof e == "number" ? e : 0 | (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e.skipSelf && 4)
}

function NT(e) {
    return {
        optional: !!(e & 8),
        host: !!(e & 1),
        self: !!(e & 2),
        skipSelf: !!(e & 4)
    }
}

function Dd(e) {
    let t = [];
    for (let n = 0; n < e.length; n++) {
        let r = Se(e[n]);
        if (Array.isArray(r)) {
            if (r.length === 0) throw new g(900, !1);
            let o, i = 0;
            for (let s = 0; s < r.length; s++) {
                let a = r[s],
                    c = RT(a);
                typeof c == "number" ? c === -1 ? o = a.token : i |= c : o = a
            }
            t.push(_(o, i))
        } else t.push(_(r))
    }
    return t
}

function RT(e) {
    return e[AT]
}

function Kn(e, t) {
    let n = e.hasOwnProperty(Mi);
    return n ? e[Mi] : null
}

function gE(e, t, n) {
    if (e.length !== t.length) return !1;
    for (let r = 0; r < e.length; r++) {
        let o = e[r],
            i = t[r];
        if (n && (o = n(o), i = n(i)), i !== o) return !1
    }
    return !0
}

function EE(e) {
    return e.flat(Number.POSITIVE_INFINITY)
}

function tc(e, t) {
    e.forEach(n => Array.isArray(n) ? tc(n, t) : t(n))
}

function jd(e, t, n) {
    t >= e.length ? e.push(n) : e.splice(t, 0, n)
}

function Fi(e, t) {
    return t >= e.length - 1 ? e.pop() : e.splice(t, 1)[0]
}

function yE(e, t) {
    let n = [];
    for (let r = 0; r < e; r++) n.push(t);
    return n
}

function vE(e, t, n, r) {
    let o = e.length;
    if (o == t) e.push(n, r);
    else if (o === 1) e.push(r, e[0]), e[0] = n;
    else {
        for (o--, e.push(e[o - 1], e[o]); o > t;) {
            let i = o - 2;
            e[o] = e[i], o--
        }
        e[t] = n, e[t + 1] = r
    }
}

function Ui(e, t, n) {
    let r = To(e, t);
    return r >= 0 ? e[r | 1] = n : (r = ~r, vE(e, r, t, n)), r
}

function nc(e, t) {
    let n = To(e, t);
    if (n >= 0) return e[n | 1]
}

function To(e, t) {
    return OT(e, t, 1)
}

function OT(e, t, n) {
    let r = 0,
        o = e.length >> n;
    for (; o !== r;) {
        let i = r + (o - r >> 1),
            s = e[i << n];
        if (t === s) return i << n;
        s > t ? o = i : r = i + 1
    }
    return ~(o << n)
}
var Qn = {},
    Oe = [],
    En = new v(""),
    Hd = new v("", -1),
    Vd = new v(""),
    Ni = class {
        get(t, n = Sr) {
            if (n === Sr) {
                let o = hE("", -201);
                throw o.name = "\u0275NotFound", o
            }
            return n
        }
    };

function Zn(e) {
    return {\
        u0275providers: e
    }
}

function DE(...e) {
    return {\
        u0275providers: $d(!0, e),
        \u0275fromNgModule: !0
    }
}

function $d(e, ...t) {
    let n = [],
        r = new Set,
        o, i = s => {
            n.push(s)
        };
    return tc(t, s => {
        let a = s;
        Wa(a, i, [], r) && (o || = [], o.push(a))
    }), o !== void 0 && _E(o, i), n
}

function _E(e, t) {
    for (let n = 0; n < e.length; n++) {
        let {
            ngModule: r,
            providers: o
        } = e[n];
        Gd(o, i => {
            t(i, r)
        })
    }
}

function Wa(e, t, n, r) {
    if (e = Se(e), !e) return !1;
    let o = null,
        i = Ed(e),
        s = !i && Qt(e);
    if (!i && !s) {
        let c = e.ngModule;
        if (i = Ed(c), i) o = c;
        else return !1
    } else {
        if (s && !s.standalone) return !1;
        o = e
    }
    let a = r.has(o);
    if (s) {
        if (a) return !1;
        if (r.add(o), s.dependencies) {
            let c = typeof s.dependencies == "function" ? s.dependencies() : s.dependencies;
            for (let l of c) Wa(l, t, n, r)
        }
    } else if (i) {
        if (i.imports != null && !a) {
            r.add(o);
            let l;
            tc(i.imports, u => {
                Wa(u, t, n, r) && (l || = [], l.push(u))
            }), l !== void 0 && _E(l, t)
        }
        if (!a) {
            let l = Kn(o) || (() => new o);
            t({
                provide: o,
                useFactory: l,
                deps: Oe
            }, o), t({
                provide: Vd,
                useValue: o,
                multi: !0
            }, o), t({
                provide: En,
                useValue: () => _(o),
                multi: !0
            }, o)
        }
        let c = i.providers;
        if (c != null && !a) {
            let l = e;
            Gd(c, u => {
                t(u, l)
            })
        }
    } else return !1;
    return o !== e && e.providers !== void 0
}

function Gd(e, t) {
    for (let n of e) Md(n) && (n = n.\u0275providers), Array.isArray(n) ? Gd(n, t) : t(n)
}
var PT = $({
    provide: String,
    useValue: $
});

function xE(e) {
    return e !== null && typeof e == "object" && PT in e
}

function LT(e) {
    return !!(e && e.useExisting)
}

function kT(e) {
    return !!(e && e.useFactory)
}

function wr(e) {
    return typeof e == "function"
}

function CE(e) {
    return !!e.useClass
}
var Bi = new v(""),
    $a = {},
    lE = {},
    gd;

function So() {
    return gd === void 0 && (gd = new Ni), gd
}
var re = class {},
    Ar = class extends re {
        parent;
        source;
        scopes;
        records = new Map;
        _ngOnDestroyHooks = new Set;
        _onDestroyHooks = [];
        get destroyed() {
            return this._destroyed
        }
        _destroyed = !1;
        injectorDefTypes;
        constructor(t, n, r, o) {
            super(), this.parent = n, this.source = r, this.scopes = o, xd(t, s => this.processProvider(s)), this.records.set(Hd, Co(void 0, this)), o.has("environment") && this.records.set(re, Co(void 0, this));
            let i = this.records.get(Bi);
            i != null && typeof i.value == "string" && this.scopes.add(i.value), this.injectorDefTypes = new Set(this.get(Vd, Oe, {
                self: !0
            }))
        }
        retrieve(t, n) {
            let r = br(n) || 0;
            try {
                return this.get(t, Sr, r)
            } catch (o) {
                if (xo(o)) return o;
                throw o
            }
        }
        destroy() {
            Ai(this), this._destroyed = !0;
            let t = S(null);
            try {
                for (let r of this._ngOnDestroyHooks) r.ngOnDestroy();
                let n = this._onDestroyHooks;
                this._onDestroyHooks = [];
                for (let r of n) r()
            } finally {
                this.records.clear(), this._ngOnDestroyHooks.clear(), this.injectorDefTypes.clear(), S(t)
            }
        }
        onDestroy(t) {
            return Ai(this), this._onDestroyHooks.push(t), () => this.removeOnDestroy(t)
        }
        runInContext(t) {
            Ai(this);
            let n = Yt(this),
                r = Be(void 0),
                o;
            try {
                return t()
            } finally {
                Yt(n), Be(r)
            }
        }
        get(t, n = Sr, r) {
            if (Ai(this), t.hasOwnProperty(cE)) return t[cE](this);
            let o = br(r),
                i, s = Yt(this),
                a = Be(void 0);
            try {
                if (!(o & 4)) {
                    let l = this.records.get(t);
                    if (l === void 0) {
                        let u = HT(t) && ki(t);
                        u && this.injectableDefInScope(u) ? l = Co(_d(t), $a) : l = null, this.records.set(t, l)
                    }
                    if (l != null) return this.hydrate(t, l, o)
                }
                let c = o & 2 ? So() : this.parent;
                return n = o & 8 && n === Sr ? null : n, c.get(t, n)
            } catch (c) {
                let l = bT(c);
                throw l === -200 || l === -201 ? new g(l, null) : c
            } finally {
                Be(a), Yt(s)
            }
        }
        resolveInjectorInitializers() {
            let t = S(null),
                n = Yt(this),
                r = Be(void 0),
                o;
            try {
                let i = this.get(En, Oe, {
                    self: !0
                });
                for (let s of i) s()
            } finally {
                Yt(n), Be(r), S(t)
            }
        }
        toString() {
            return "R3Injector[...]"
        }
        processProvider(t) {
            t = Se(t);
            let n = wr(t) ? t : Se(t && t.provide),
                r = UT(t);
            if (!wr(t) && t.multi === !0) {
                let o = this.records.get(n);
                o || (o = Co(void 0, $a, !0), o.factory = () => Dd(o.multi), this.records.set(n, o)), n = t, o.multi.push(t)
            }
            this.records.set(n, r)
        }
        hydrate(t, n, r) {
            let o = S(null);
            try {
                if (n.value === lE) throw Ud("");
                return n.value === $a && (n.value = lE, n.value = n.factory(void 0, r)), typeof n.value == "object" && n.value && jT(n.value) && this._ngOnDestroyHooks.add(n.value), n.value
            } finally {
                S(o)
            }
        }
        injectableDefInScope(t) {
            if (!t.providedIn) return !1;
            let n = Se(t.providedIn);
            return typeof n == "string" ? n === "any" || this.scopes.has(n) : this.injectorDefTypes.has(n)
        }
        removeOnDestroy(t) {
            let n = this._onDestroyHooks.indexOf(t);
            n !== -1 && this._onDestroyHooks.splice(n, 1)
        }
    };

function _d(e) {
    let t = ki(e),
        n = t !== null ? t.factory : Kn(e);
    if (n !== null) return n;
    if (e instanceof v) throw new g(-204, !1);
    if (e instanceof Function) return FT(e);
    throw new g(-204, !1)
}

function FT(e) {
    if (e.length > 0) throw new g(-204, !1);
    let n = IT(e);
    return n !== null ? () => n.factory(e) : () => new e
}

function UT(e) {
    if (xE(e)) return Co(void 0, e.useValue); {
        let t = Wd(e);
        return Co(t, $a)
    }
}

function Wd(e, t, n) {
    let r;
    if (wr(e)) {
        let o = Se(e);
        return Kn(o) || _d(o)
    } else if (xE(e)) r = () => Se(e.useValue);
    else if (kT(e)) r = () => e.useFactory(...Dd(e.deps || []));
    else if (LT(e)) r = (o, i) => _(Se(e.useExisting), i !== void 0 && i & 8 ? 8 : void 0);
    else {
        let o = Se(e && (e.useClass || e.provide));
        if (BT(e)) r = () => new o(...Dd(e.deps));
        else return Kn(o) || _d(o)
    }
    return r
}

function Ai(e) {
    if (e.destroyed) throw new g(-205, !1)
}

function Co(e, t, n = !1) {
    return {
        factory: e,
        value: t,
        multi: n ? [] : void 0
    }
}

function BT(e) {
    return !!e.deps
}

function jT(e) {
    return e !== null && typeof e == "object" && typeof e.ngOnDestroy == "function"
}

function HT(e) {
    return typeof e == "function" || typeof e == "object" && e.ngMetadataName === "InjectionToken"
}

function xd(e, t) {
    for (let n of e) Array.isArray(n) ? xd(n, t) : n && Md(n) ? xd(n.\u0275providers, t) : t(n)
}

function _e(e, t) {
    let n;
    e instanceof Ar ? (Ai(e), n = e) : n = new vd(e);
    let r, o = Yt(n),
        i = Be(void 0);
    try {
        return t()
    } finally {
        Yt(o), Be(i)
    }
}

function zd() {
    return mE() !== void 0 || Va() != null
}
var Rt = 0,
    b = 1,
    N = 2,
    De = 3,
    pt = 4,
    je = 5,
    Nr = 6,
    bo = 7,
    ie = 8,
    rt = 9,
    Ot = 10,
    W = 11,
    wo = 12,
    qd = 13,
    Rr = 14,
    Pe = 15,
    Xn = 16,
    Or = 17,
    Zt = 18,
    yn = 19,
    Kd = 20,
    gn = 21,
    rc = 22,
    Yn = 23,
    ot = 24,
    Pr = 25,
    vn = 26,
    z = 27,
    IE = 1,
    Yd = 6,
    er = 7,
    ji = 8,
    Lr = 9,
    se = 10;

function Dn(e) {
    return Array.isArray(e) && typeof e[IE] == "object"
}

function Pt(e) {
    return Array.isArray(e) && e[IE] === !0
}

function Jd(e) {
    return (e.flags & 4) !== 0
}

function _n(e) {
    return e.componentOffset > -1
}

function Ao(e) {
    return (e.flags & 1) === 1
}

function Xt(e) {
    return !!e.template
}

function Mo(e) {
    return (e[N] & 512) !== 0
}

function kr(e) {
    return (e[N] & 256) === 256
}
var Qd = "svg",
    TE = "math";

function ht(e) {
    for (; Array.isArray(e);) e = e[Rt];
    return e
}

function Zd(e, t) {
    return ht(t[e])
}

function mt(e, t) {
    return ht(t[e.index])
}

function oc(e, t) {
    return e.data[t]
}

function No(e, t) {
    return e[t]
}

function Hi(e, t, n, r) {
    n >= e.data.length && (e.data[n] = null, e.blueprint[n] = null), t[n] = r
}

function gt(e, t) {
    let n = t[e];
    return Dn(n) ? n : n[Rt]
}

function SE(e) {
    return (e[N] & 4) === 4
}

function ic(e) {
    return (e[N] & 128) === 128
}

function bE(e) {
    return Pt(e[De])
}

function Et(e, t) {
    return t == null ? null : e[t]
}

function Xd(e) {
    e[Or] = 0
}

function ef(e) {
    e[N] & 1024 || (e[N] |= 1024, ic(e) && Fr(e))
}

function wE(e, t) {
    for (; e > 0;) t = t[Rr], e--;
    return t
}

function Vi(e) {
    return !!(e[N] & 9216 || e[ot] ? .dirty)
}

function sc(e) {
    e[Ot].changeDetectionScheduler ? .notify(8), e[N] & 64 && (e[N] |= 1024), Vi(e) && Fr(e)
}

function Fr(e) {
    e[Ot].changeDetectionScheduler ? .notify(0);
    let t = Jn(e);
    for (; t !== null && !(t[N] & 8192 || (t[N] |= 8192, !ic(t)));) t = Jn(t)
}

function tf(e, t) {
    if (kr(e)) throw new g(911, !1);
    e[gn] === null && (e[gn] = []), e[gn].push(t)
}

function AE(e, t) {
    if (e[gn] === null) return;
    let n = e[gn].indexOf(t);
    n !== -1 && e[gn].splice(n, 1)
}

function Jn(e) {
    let t = e[De];
    return Pt(t) ? t[De] : t
}

function nf(e) {
    return e[bo] ? ? = []
}

function rf(e) {
    return e.cleanup ? ? = []
}

function ME(e, t, n, r) {
    let o = nf(t);
    o.push(n), e.firstCreatePass && rf(e).push(r, o.length - 1)
}
var L = {
    lFrame: VE(null),
    bindingsEnabled: !0,
    skipHydrationRootTNode: null
};
var Cd = !1;

function NE() {
    return L.lFrame.elementDepthCount
}

function RE() {
    L.lFrame.elementDepthCount++
}

function of () {
    L.lFrame.elementDepthCount--
}

function ac() {
    return L.bindingsEnabled
}

function sf() {
    return L.skipHydrationRootTNode !== null
}

function af(e) {
    return L.skipHydrationRootTNode === e
}

function cf() {
    L.skipHydrationRootTNode = null
}

function C() {
    return L.lFrame.lView
}

function Y() {
    return L.lFrame.tView
}

function OE(e) {
    return L.lFrame.contextLView = e, e[ie]
}

function PE(e) {
    return L.lFrame.contextLView = null, e
}

function he() {
    let e = lf();
    for (; e !== null && e.type === 64;) e = e.parent;
    return e
}

function lf() {
    return L.lFrame.currentTNode
}

function LE() {
    let e = L.lFrame,
        t = e.currentTNode;
    return e.isParent ? t : t.parent
}

function Ur(e, t) {
    let n = L.lFrame;
    n.currentTNode = e, n.isParent = t
}

function uf() {
    return L.lFrame.isParent
}

function df() {
    L.lFrame.isParent = !1
}

function ff() {
    return L.lFrame.contextLView
}

function pf() {
    return Cd
}

function Ri(e) {
    let t = Cd;
    return Cd = e, t
}

function yt() {
    let e = L.lFrame,
        t = e.bindingRootIndex;
    return t === -1 && (t = e.bindingRootIndex = e.tView.bindingStartIndex), t
}

function $i() {
    return L.lFrame.bindingIndex
}

function kE(e) {
    return L.lFrame.bindingIndex = e
}

function xn() {
    return L.lFrame.bindingIndex++
}

function Br(e) {
    let t = L.lFrame,
        n = t.bindingIndex;
    return t.bindingIndex = t.bindingIndex + e, n
}

function FE() {
    return L.lFrame.inI18n
}

function UE(e, t) {
    let n = L.lFrame;
    n.bindingIndex = n.bindingRootIndex = e, cc(t)
}

function BE() {
    return L.lFrame.currentDirectiveIndex
}

function cc(e) {
    L.lFrame.currentDirectiveIndex = e
}

function jE(e) {
    let t = L.lFrame.currentDirectiveIndex;
    return t === -1 ? null : e[t]
}

function lc() {
    return L.lFrame.currentQueryIndex
}

function Gi(e) {
    L.lFrame.currentQueryIndex = e
}

function VT(e) {
    let t = e[b];
    return t.type === 2 ? t.declTNode : t.type === 1 ? e[je] : null
}

function hf(e, t, n) {
    if (n & 4) {
        let o = t,
            i = e;
        for (; o = o.parent, o === null && !(n & 1);)
            if (o = VT(i), o === null || (i = i[Rr], o.type & 10)) break;
        if (o === null) return !1;
        t = o, e = i
    }
    let r = L.lFrame = HE();
    return r.currentTNode = t, r.lView = e, !0
}

function uc(e) {
    let t = HE(),
        n = e[b];
    L.lFrame = t, t.currentTNode = n.firstChild, t.lView = e, t.tView = n, t.contextLView = e, t.bindingIndex = n.bindingStartIndex, t.inI18n = !1
}

function HE() {
    let e = L.lFrame,
        t = e === null ? null : e.child;
    return t === null ? VE(e) : t
}

function VE(e) {
    let t = {
        currentTNode: null,
        isParent: !0,
        lView: null,
        tView: null,
        selectedIndex: -1,
        contextLView: null,
        elementDepthCount: 0,
        currentNamespace: null,
        currentDirectiveIndex: -1,
        bindingRootIndex: -1,
        bindingIndex: -1,
        currentQueryIndex: 0,
        parent: e,
        child: null,
        inI18n: !1
    };
    return e !== null && (e.child = t), t
}

function $E() {
    let e = L.lFrame;
    return L.lFrame = e.parent, e.currentTNode = null, e.lView = null, e
}
var mf = $E;

function dc() {
    let e = $E();
    e.isParent = !0, e.tView = null, e.selectedIndex = -1, e.contextLView = null, e.elementDepthCount = 0, e.currentDirectiveIndex = -1, e.currentNamespace = null, e.bindingRootIndex = -1, e.bindingIndex = -1, e.currentQueryIndex = 0
}

function GE(e) {
    return (L.lFrame.contextLView = wE(e, L.lFrame.contextLView))[ie]
}

function qe() {
    return L.lFrame.selectedIndex
}

function tr(e) {
    L.lFrame.selectedIndex = e
}

function Wi() {
    let e = L.lFrame;
    return oc(e.tView, e.selectedIndex)
}

function WE() {
    L.lFrame.currentNamespace = Qd
}

function zE() {
    $T()
}

function $T() {
    L.lFrame.currentNamespace = null
}

function gf() {
    return L.lFrame.currentNamespace
}
var qE = !0;

function fc() {
    return qE
}

function zi(e) {
    qE = e
}

function Id(e, t = null, n = null, r) {
    let o = Ef(e, t, n, r);
    return o.resolveInjectorInitializers(), o
}

function Ef(e, t = null, n = null, r, o = new Set) {
    let i = [n || Oe, DE(e)],
        s;
    return new Ar(i, t || So(), s || null, o)
}
var fe = class e {
        static THROW_IF_NOT_FOUND = Sr;
        static NULL = new Ni;
        static create(t, n) {
            if (Array.isArray(t)) return Id({
                name: ""
            }, n, t, ""); {
                let r = t.name ? ? "";
                return Id({
                    name: r
                }, t.parent, t.providers, r)
            }
        }
        static\ u0275prov = y({
            token: e,
            providedIn: "any",
            factory: () => _(Hd)
        });
        static __NG_ELEMENT_ID__ = -1
    },
    Z = new v(""),
    He = (() => {
        class e {
            static __NG_ELEMENT_ID__ = GT;
            static __NG_ENV_ID__ = n => n
        }
        return e
    })(),
    za = class extends He {
        _lView;
        constructor(t) {
            super(), this._lView = t
        }
        get destroyed() {
            return kr(this._lView)
        }
        onDestroy(t) {
            let n = this._lView;
            return tf(n, t), () => AE(n, t)
        }
    };

function GT() {
    return new za(C())
}
var yf = !1,
    KE = new v(""),
    en = (() => {
        class e {
            taskId = 0;
            pendingTasks = new Set;
            destroyed = !1;
            pendingTask = new ye(!1);
            debugTaskTracker = h(KE, {
                optional: !0
            });
            get hasPendingTasks() {
                return this.destroyed ? !1 : this.pendingTask.value
            }
            get hasPendingTasksObservable() {
                return this.destroyed ? new P(n => {
                    n.next(!1), n.complete()
                }) : this.pendingTask
            }
            add() {
                !this.hasPendingTasks && !this.destroyed && this.pendingTask.next(!0);
                let n = this.taskId++;
                return this.pendingTasks.add(n), this.debugTaskTracker ? .add(n), n
            }
            has(n) {
                return this.pendingTasks.has(n)
            }
            remove(n) {
                this.pendingTasks.delete(n), this.debugTaskTracker ? .remove(n), this.pendingTasks.size === 0 && this.hasPendingTasks && this.pendingTask.next(!1)
            }
            ngOnDestroy() {
                this.pendingTasks.clear(), this.hasPendingTasks && this.pendingTask.next(!1), this.destroyed = !0, this.pendingTask.unsubscribe()
            }
            static\ u0275prov = y({
                token: e,
                providedIn: "root",
                factory: () => new e
            })
        }
        return e
    })(),
    Td = class extends ne {
        __isAsync;
        destroyRef = void 0;
        pendingTasks = void 0;
        constructor(t = !1) {
            super(), this.__isAsync = t, zd() && (this.destroyRef = h(He, {
                optional: !0
            }) ? ? void 0, this.pendingTasks = h(en, {
                optional: !0
            }) ? ? void 0)
        }
        emit(t) {
            let n = S(null);
            try {
                super.next(t)
            } finally {
                S(n)
            }
        }
        subscribe(t, n, r) {
            let o = t,
                i = n || (() => null),
                s = r;
            if (t && typeof t == "object") {
                let c = t;
                o = c.next ? .bind(c), i = c.error ? .bind(c), s = c.complete ? .bind(c)
            }
            this.__isAsync && (i = this.wrapInTimeout(i), o && (o = this.wrapInTimeout(o)), s && (s = this.wrapInTimeout(s)));
            let a = super.subscribe({
                next: o,
                error: i,
                complete: s
            });
            return t instanceof oe && t.add(a), a
        }
        wrapInTimeout(t) {
            return n => {
                let r = this.pendingTasks ? .add();
                setTimeout(() => {
                    try {
                        t(n)
                    } finally {
                        r !== void 0 && this.pendingTasks ? .remove(r)
                    }
                })
            }
        }
    },
    Re = Td;

function qa(...e) {}

function vf(e) {
    let t, n;

    function r() {
        e = qa;
        try {
            n !== void 0 && typeof cancelAnimationFrame == "function" && cancelAnimationFrame(n), t !== void 0 && clearTimeout(t)
        } catch (o) {}
    }
    return t = setTimeout(() => {
        e(), r()
    }), typeof requestAnimationFrame == "function" && (n = requestAnimationFrame(() => {
        e(), r()
    })), () => r()
}

function YE(e) {
    return queueMicrotask(() => e()), () => {
        e = qa
    }
}
var Df = "isAngularZone",
    Oi = Df + "_ID",
    WT = 0,
    Q = class e {
        hasPendingMacrotasks = !1;
        hasPendingMicrotasks = !1;
        isStable = !0;
        onUnstable = new Re(!1);
        onMicrotaskEmpty = new Re(!1);
        onStable = new Re(!1);
        onError = new Re(!1);
        constructor(t) {
            let {
                enableLongStackTrace: n = !1,
                shouldCoalesceEventChangeDetection: r = !1,
                shouldCoalesceRunChangeDetection: o = !1,
                scheduleInRootZone: i = yf
            } = t;
            if (typeof Zone > "u") throw new g(908, !1);
            Zone.assertZonePatched();
            let s = this;
            s._nesting = 0, s._outer = s._inner = Zone.current, Zone.TaskTrackingZoneSpec && (s._inner = s._inner.fork(new Zone.TaskTrackingZoneSpec)), n && Zone.longStackTraceZoneSpec && (s._inner = s._inner.fork(Zone.longStackTraceZoneSpec)), s.shouldCoalesceEventChangeDetection = !o && r, s.shouldCoalesceRunChangeDetection = o, s.callbackScheduled = !1, s.scheduleInRootZone = i, KT(s)
        }
        static isInAngularZone() {
            return typeof Zone < "u" && Zone.current.get(Df) === !0
        }
        static assertInAngularZone() {
            if (!e.isInAngularZone()) throw new g(909, !1)
        }
        static assertNotInAngularZone() {
            if (e.isInAngularZone()) throw new g(909, !1)
        }
        run(t, n, r) {
            return this._inner.run(t, n, r)
        }
        runTask(t, n, r, o) {
            let i = this._inner,
                s = i.scheduleEventTask("NgZoneEvent: " + o, t, zT, qa, qa);
            try {
                return i.runTask(s, n, r)
            } finally {
                i.cancelTask(s)
            }
        }
        runGuarded(t, n, r) {
            return this._inner.runGuarded(t, n, r)
        }
        runOutsideAngular(t) {
            return this._outer.run(t)
        }
    },
    zT = {};

function _f(e) {
    if (e._nesting == 0 && !e.hasPendingMicrotasks && !e.isStable) try {
        e._nesting++, e.onMicrotaskEmpty.emit(null)
    } finally {
        if (e._nesting--, !e.hasPendingMicrotasks) try {
            e.runOutsideAngular(() => e.onStable.emit(null))
        } finally {
            e.isStable = !0
        }
    }
}

function qT(e) {
    if (e.isCheckStableRunning || e.callbackScheduled) return;
    e.callbackScheduled = !0;

    function t() {
        vf(() => {
            e.callbackScheduled = !1, Sd(e), e.isCheckStableRunning = !0, _f(e), e.isCheckStableRunning = !1
        })
    }
    e.scheduleInRootZone ? Zone.root.run(() => {
        t()
    }) : e._outer.run(() => {
        t()
    }), Sd(e)
}

function KT(e) {
    let t = () => {
            qT(e)
        },
        n = WT++;
    e._inner = e._inner.fork({
        name: "angular",
        properties: {
            [Df]: !0,
            [Oi]: n,
            [Oi + n]: !0
        },
        onInvokeTask: (r, o, i, s, a, c) => {
            if (YT(c)) return r.invokeTask(i, s, a, c);
            try {
                return uE(e), r.invokeTask(i, s, a, c)
            } finally {
                (e.shouldCoalesceEventChangeDetection && s.type === "eventTask" || e.shouldCoalesceRunChangeDetection) && t(), dE(e)
            }
        },
        onInvoke: (r, o, i, s, a, c, l) => {
            try {
                return uE(e), r.invoke(i, s, a, c, l)
            } finally {
                e.shouldCoalesceRunChangeDetection && !e.callbackScheduled && !JT(c) && t(), dE(e)
            }
        },
        onHasTask: (r, o, i, s) => {
            r.hasTask(i, s), o === i && (s.change == "microTask" ? (e._hasPendingMicrotasks = s.microTask, Sd(e), _f(e)) : s.change == "macroTask" && (e.hasPendingMacrotasks = s.macroTask))
        },
        onHandleError: (r, o, i, s) => (r.handleError(i, s), e.runOutsideAngular(() => e.onError.emit(s)), !1)
    })
}

function Sd(e) {
    e._hasPendingMicrotasks || (e.shouldCoalesceEventChangeDetection || e.shouldCoalesceRunChangeDetection) && e.callbackScheduled === !0 ? e.hasPendingMicrotasks = !0 : e.hasPendingMicrotasks = !1
}

function uE(e) {
    e._nesting++, e.isStable && (e.isStable = !1, e.onUnstable.emit(null))
}

function dE(e) {
    e._nesting--, _f(e)
}
var Pi = class {
    hasPendingMicrotasks = !1;
    hasPendingMacrotasks = !1;
    isStable = !0;
    onUnstable = new Re;
    onMicrotaskEmpty = new Re;
    onStable = new Re;
    onError = new Re;
    run(t, n, r) {
        return t.apply(n, r)
    }
    runGuarded(t, n, r) {
        return t.apply(n, r)
    }
    runOutsideAngular(t) {
        return t()
    }
    runTask(t, n, r, o) {
        return t.apply(n, r)
    }
};

function YT(e) {
    return JE(e, "__ignore_ng_zone__")
}

function JT(e) {
    return JE(e, "__scheduler_tick__")
}

function JE(e, t) {
    return !Array.isArray(e) || e.length !== 1 ? !1 : e[0] ? .data ? .[t] === !0
}
var ut = class {
        _console = console;
        handleError(t) {
            this._console.error("ERROR", t)
        }
    },
    Ke = new v("", {
        factory: () => {
            let e = h(Q),
                t = h(re),
                n;
            return r => {
                e.runOutsideAngular(() => {
                    t.destroyed && !n ? setTimeout(() => {
                        throw r
                    }) : (n ? ? = t.get(ut), n.handleError(r))
                })
            }
        }
    }),
    QE = {
        provide: En,
        useValue: () => {
            let e = h(ut, {
                optional: !0
            })
        },
        multi: !0
    };

function ae(e, t) {
    let [n, r, o] = Yu(e, t ? .equal), i = n, s = i[ue];
    return i.set = r, i.update = o, i.asReadonly = qi.bind(i), i
}

function qi() {
    let e = this[ue];
    if (e.readonlyFn === void 0) {
        let t = () => this();
        t[ue] = e, e.readonlyFn = t
    }
    return e.readonlyFn
}
var Ki = (() => {
    class e {
        view;
        node;
        constructor(n, r) {
            this.view = n, this.node = r
        }
        static __NG_ELEMENT_ID__ = QT
    }
    return e
})();

function QT() {
    return new Ki(C(), he())
}
var Jt = class {},
    Ro = new v("", {
        factory: () => !0
    });
var pc = new v(""),
    Oo = (() => {
        class e {
            internalPendingTasks = h(en);
            scheduler = h(Jt);
            errorHandler = h(Ke);
            add() {
                let n = this.internalPendingTasks.add();
                return () => {
                    this.internalPendingTasks.has(n) && (this.scheduler.notify(11), this.internalPendingTasks.remove(n))
                }
            }
            run(n) {
                let r = this.add();
                n().catch(this.errorHandler).finally(r)
            }
            static\ u0275prov = y({
                token: e,
                providedIn: "root",
                factory: () => new e
            })
        }
        return e
    })(),
    hc = (() => {
        class e {
            static\ u0275prov = y({
                token: e,
                providedIn: "root",
                factory: () => new bd
            })
        }
        return e
    })(),
    bd = class {
        dirtyEffectCount = 0;
        queues = new Map;
        add(t) {
            this.enqueue(t), this.schedule(t)
        }
        schedule(t) {
            t.dirty && this.dirtyEffectCount++
        }
        remove(t) {
            let n = t.zone,
                r = this.queues.get(n);
            r.has(t) && (r.delete(t), t.dirty && this.dirtyEffectCount--)
        }
        enqueue(t) {
            let n = t.zone;
            this.queues.has(n) || this.queues.set(n, new Set);
            let r = this.queues.get(n);
            r.has(t) || r.add(t)
        }
        flush() {
            for (; this.dirtyEffectCount > 0;) {
                let t = !1;
                for (let [n, r] of this.queues) n === null ? t || = this.flushQueue(r) : t || = n.run(() => this.flushQueue(r));
                t || (this.dirtyEffectCount = 0)
            }
        }
        flushQueue(t) {
            let n = !1;
            for (let r of t) r.dirty && (this.dirtyEffectCount--, n = !0, r.run());
            return n
        }
    },
    Ka = class {
        [ue];
        constructor(t) {
            this[ue] = t
        }
        destroy() {
            this[ue].destroy()
        }
    };

function ZE(e, t) {
    let n = t ? .injector ? ? h(fe),
        r = t ? .manualCleanup !== !0 ? n.get(He) : null,
        o, i = n.get(Ki, null, {
            optional: !0
        }),
        s = n.get(Jt);
    return i !== null ? (o = eS(i.view, s, e), r instanceof za && r._lView === i.view && (r = null)) : o = tS(e, n.get(hc), s), o.injector = n, r !== null && (o.onDestroyFns = [r.onDestroy(() => o.destroy())]), new Ka(o)
}
var XE = B(E({}, Ju), {
        cleanupFns: void 0,
        zone: null,
        onDestroyFns: null,
        run() {
            let e = Ri(!1);
            try {
                Qu(this)
            } finally {
                Ri(e)
            }
        },
        cleanup() {
            if (!this.cleanupFns ? .length) return;
            let e = S(null);
            try {
                for (; this.cleanupFns.length;) this.cleanupFns.pop()()
            } finally {
                this.cleanupFns = [], S(e)
            }
        }
    }),
    ZT = B(E({}, XE), {
        consumerMarkedDirty() {
            this.scheduler.schedule(this), this.notifier.notify(12)
        },
        destroy() {
            if (Dr(this), this.onDestroyFns !== null)
                for (let e of this.onDestroyFns) e();
            this.cleanup(), this.scheduler.remove(this)
        }
    }),
    XT = B(E({}, XE), {
        consumerMarkedDirty() {
            this.view[N] |= 8192, Fr(this.view), this.notifier.notify(13)
        },
        destroy() {
            if (Dr(this), this.onDestroyFns !== null)
                for (let e of this.onDestroyFns) e();
            this.cleanup(), this.view[Yn] ? .delete(this)
        }
    });

function eS(e, t, n) {
    let r = Object.create(XT);
    return r.view = e, r.zone = typeof Zone < "u" ? Zone.current : null, r.notifier = t, r.fn = ey(r, n), e[Yn] ? ? = new Set, e[Yn].add(r), r.consumerMarkedDirty(r), r
}

function tS(e, t, n) {
    let r = Object.create(ZT);
    return r.fn = ey(r, e), r.scheduler = t, r.notifier = n, r.zone = typeof Zone < "u" ? Zone.current : null, r.scheduler.add(r), r.notifier.notify(12), r
}

function ey(e, t) {
    return () => {
        t(n => (e.cleanupFns ? ? = []).push(n))
    }
}

function ss(e) {
    return {
        toString: e
    }.toString()
}

function Uy(e) {
    let t = ge.ng;
    if (t && t.\u0275compilerFacade) return t.\u0275compilerFacade;
    throw new Error("JIT compiler unavailable")
}

function cS(e) {
    return typeof e == "function"
}

function By(e, t, n, r) {
    t !== null ? t.applyValueToInputSignal(t, r) : e[n] = r
}
var Sc = class {
        previousValue;
        currentValue;
        firstChange;
        constructor(t, n, r) {
            this.previousValue = t, this.currentValue = n, this.firstChange = r
        }
        isFirstChange() {
            return this.firstChange
        }
    },
    rn = (() => {
        let e = () => jy;
        return e.ngInherit = !0, e
    })();

function jy(e) {
    return e.type.prototype.ngOnChanges && (e.setInput = uS), lS
}

function lS() {
    let e = Vy(this),
        t = e ? .current;
    if (t) {
        let n = e.previous;
        if (n === Qn) e.previous = t;
        else
            for (let r in t) n[r] = t[r];
        e.current = null, this.ngOnChanges(t)
    }
}

function uS(e, t, n, r, o) {
    let i = this.declaredInputs[r],
        s = Vy(e) || dS(e, {
            previous: Qn,
            current: null
        }),
        a = s.current || (s.current = {}),
        c = s.previous,
        l = c[i];
    a[i] = new Sc(l && l.currentValue, n, c === Qn), By(e, t, o, n)
}
var Hy = "__ngSimpleChanges__";

function Vy(e) {
    return e[Hy] || null
}

function dS(e, t) {
    return e[Hy] = t
}
var ty = [];
var q = function(e, t = null, n) {
        for (let r = 0; r < ty.length; r++) {
            let o = ty[r];
            o(e, t, n)
        }
    },
    H = (function(e) {
        return e[e.TemplateCreateStart = 0] = "TemplateCreateStart", e[e.TemplateCreateEnd = 1] = "TemplateCreateEnd", e[e.TemplateUpdateStart = 2] = "TemplateUpdateStart", e[e.TemplateUpdateEnd = 3] = "TemplateUpdateEnd", e[e.LifecycleHookStart = 4] = "LifecycleHookStart", e[e.LifecycleHookEnd = 5] = "LifecycleHookEnd", e[e.OutputStart = 6] = "OutputStart", e[e.OutputEnd = 7] = "OutputEnd", e[e.BootstrapApplicationStart = 8] = "BootstrapApplicationStart", e[e.BootstrapApplicationEnd = 9] = "BootstrapApplicationEnd", e[e.BootstrapComponentStart = 10] = "BootstrapComponentStart", e[e.BootstrapComponentEnd = 11] = "BootstrapComponentEnd", e[e.ChangeDetectionStart = 12] = "ChangeDetectionStart", e[e.ChangeDetectionEnd = 13] = "ChangeDetectionEnd", e[e.ChangeDetectionSyncStart = 14] = "ChangeDetectionSyncStart", e[e.ChangeDetectionSyncEnd = 15] = "ChangeDetectionSyncEnd", e[e.AfterRenderHooksStart = 16] = "AfterRenderHooksStart", e[e.AfterRenderHooksEnd = 17] = "AfterRenderHooksEnd", e[e.ComponentStart = 18] = "ComponentStart", e[e.ComponentEnd = 19] = "ComponentEnd", e[e.DeferBlockStateStart = 20] = "DeferBlockStateStart", e[e.DeferBlockStateEnd = 21] = "DeferBlockStateEnd", e[e.DynamicComponentStart = 22] = "DynamicComponentStart", e[e.DynamicComponentEnd = 23] = "DynamicComponentEnd", e[e.HostBindingsUpdateStart = 24] = "HostBindingsUpdateStart", e[e.HostBindingsUpdateEnd = 25] = "HostBindingsUpdateEnd", e
    })(H || {});

function fS(e, t, n) {
    let {
        ngOnChanges: r,
        ngOnInit: o,
        ngDoCheck: i
    } = t.type.prototype;
    if (r) {
        let s = jy(t);
        (n.preOrderHooks ? ? = []).push(e, s), (n.preOrderCheckHooks ? ? = []).push(e, s)
    }
    o && (n.preOrderHooks ? ? = []).push(0 - e, o), i && ((n.preOrderHooks ? ? = []).push(e, i), (n.preOrderCheckHooks ? ? = []).push(e, i))
}

function $y(e, t) {
    for (let n = t.directiveStart, r = t.directiveEnd; n < r; n++) {
        let i = e.data[n].type.prototype,
            {
                ngAfterContentInit: s,
                ngAfterContentChecked: a,
                ngAfterViewInit: c,
                ngAfterViewChecked: l,
                ngOnDestroy: u
            } = i;
        s && (e.contentHooks ? ? = []).push(-n, s), a && ((e.contentHooks ? ? = []).push(n, a), (e.contentCheckHooks ? ? = []).push(n, a)), c && (e.viewHooks ? ? = []).push(-n, c), l && ((e.viewHooks ? ? = []).push(n, l), (e.viewCheckHooks ? ? = []).push(n, l)), u != null && (e.destroyHooks ? ? = []).push(n, u)
    }
}

function Dc(e, t, n) {
    Gy(e, t, 3, n)
}

function _c(e, t, n, r) {
    (e[N] & 3) === n && Gy(e, t, n, r)
}

function xf(e, t) {
    let n = e[N];
    (n & 3) === t && (n &= 16383, n += 1, e[N] = n)
}

function Gy(e, t, n, r) {
    let o = r !== void 0 ? e[Or] & 65535 : 0,
        i = r ? ? -1,
        s = t.length - 1,
        a = 0;
    for (let c = o; c < s; c++)
        if (typeof t[c + 1] == "number") {
            if (a = t[c], r != null && a >= r) break
        } else t[c] < 0 && (e[Or] += 65536), (a < i || i == -1) && (pS(e, n, t, c), e[Or] = (e[Or] & 4294901760) + c + 2), c++
}

function ny(e, t) {
    q(H.LifecycleHookStart, e, t);
    let n = S(null);
    try {
        t.call(e)
    } finally {
        S(n), q(H.LifecycleHookEnd, e, t)
    }
}

function pS(e, t, n, r) {
    let o = n[r] < 0,
        i = n[r + 1],
        s = o ? -n[r] : n[r],
        a = e[s];
    o ? e[N] >> 14 < e[Or] >> 16 && (e[N] & 3) === t && (e[N] += 16384, ny(a, i)) : ny(a, i)
}
var Lo = -1,
    Vr = class {
        factory;
        name;
        injectImpl;
        resolving = !1;
        canSeeViewProviders;
        multi;
        componentProviders;
        index;
        providerFactory;
        constructor(t, n, r, o) {
            this.factory = t, this.name = o, this.canSeeViewProviders = n, this.injectImpl = r
        }
    };

function hS(e) {
    return (e.flags & 8) !== 0
}

function mS(e) {
    return (e.flags & 16) !== 0
}

function gS(e, t, n) {
    let r = 0;
    for (; r < n.length;) {
        let o = n[r];
        if (typeof o == "number") {
            if (o !== 0) break;
            r++;
            let i = n[r++],
                s = n[r++],
                a = n[r++];
            e.setAttribute(t, s, a, i)
        } else {
            let i = o,
                s = n[++r];
            ES(i) ? e.setProperty(t, i, s) : e.setAttribute(t, i, s), r++
        }
    }
    return r
}

function Wy(e) {
    return e === 3 || e === 4 || e === 6
}

function ES(e) {
    return e.charCodeAt(0) === 64
}

function ko(e, t) {
    if (!(t === null || t.length === 0))
        if (e === null || e.length === 0) e = t.slice();
        else {
            let n = -1;
            for (let r = 0; r < t.length; r++) {
                let o = t[r];
                typeof o == "number" ? n = o : n === 0 || (n === -1 || n === 2 ? ry(e, n, o, null, t[++r]) : ry(e, n, o, null, null))
            }
        }
    return e
}

function ry(e, t, n, r, o) {
    let i = 0,
        s = e.length;
    if (t === -1) s = -1;
    else
        for (; i < e.length;) {
            let a = e[i++];
            if (typeof a == "number") {
                if (a === t) {
                    s = -1;
                    break
                } else if (a > t) {
                    s = i - 1;
                    break
                }
            }
        }
    for (; i < e.length;) {
        let a = e[i];
        if (typeof a == "number") break;
        if (a === n) {
            o !== null && (e[i + 1] = o);
            return
        }
        i++, o !== null && i++
    }
    s !== -1 && (e.splice(s, 0, t), i = s + 1), e.splice(i++, 0, n), o !== null && e.splice(i++, 0, o)
}

function zy(e) {
    return e !== Lo
}

function bc(e) {
    return e & 32767
}

function yS(e) {
    return e >> 16
}

function wc(e, t) {
    let n = yS(e),
        r = t;
    for (; n > 0;) r = r[Rr], n--;
    return r
}
var Of = !0;

function Ac(e) {
    let t = Of;
    return Of = e, t
}
var vS = 256,
    qy = vS - 1,
    Ky = 5,
    DS = 0,
    tn = {};

function _S(e, t, n) {
    let r;
    typeof n == "string" ? r = n.charCodeAt(0) || 0 : n.hasOwnProperty(Mr) && (r = n[Mr]), r == null && (r = n[Mr] = DS++);
    let o = r & qy,
        i = 1 << o;
    t.data[e + (o >> Ky)] |= i
}

function Mc(e, t) {
    let n = Yy(e, t);
    if (n !== -1) return n;
    let r = t[b];
    r.firstCreatePass && (e.injectorIndex = t.length, Cf(r.data, e), Cf(t, null), Cf(r.blueprint, null));
    let o = Ep(e, t),
        i = e.injectorIndex;
    if (zy(o)) {
        let s = bc(o),
            a = wc(o, t),
            c = a[b].data;
        for (let l = 0; l < 8; l++) t[i + l] = a[s + l] | c[s + l]
    }
    return t[i + 8] = o, i
}

function Cf(e, t) {
    e.push(0, 0, 0, 0, 0, 0, 0, 0, t)
}

function Yy(e, t) {
    return e.injectorIndex === -1 || e.parent && e.parent.injectorIndex === e.injectorIndex || t[e.injectorIndex + 8] === null ? -1 : e.injectorIndex
}

function Ep(e, t) {
    if (e.parent && e.parent.injectorIndex !== -1) return e.parent.injectorIndex;
    let n = 0,
        r = null,
        o = t;
    for (; o !== null;) {
        if (r = e0(o), r === null) return Lo;
        if (n++, o = o[Rr], r.injectorIndex !== -1) return r.injectorIndex | n << 16
    }
    return Lo
}

function Pf(e, t, n) {
    _S(e, t, n)
}

function xS(e, t) {
    if (t === "class") return e.classes;
    if (t === "style") return e.styles;
    let n = e.attrs;
    if (n) {
        let r = n.length,
            o = 0;
        for (; o < r;) {
            let i = n[o];
            if (Wy(i)) break;
            if (i === 0) o = o + 2;
            else if (typeof i == "number")
                for (o++; o < r && typeof n[o] == "string";) o++;
            else {
                if (i === t) return n[o + 1];
                o = o + 2
            }
        }
    }
    return null
}

function Jy(e, t, n) {
    if (n & 8 || e !== void 0) return e;
    ec(t, "NodeInjector")
}

function Qy(e, t, n, r) {
    if (n & 8 && r === void 0 && (r = null), (n & 3) === 0) {
        let o = e[rt],
            i = Be(void 0);
        try {
            return o ? o.get(t, r, n & 8) : Bd(t, r, n & 8)
        } finally {
            Be(i)
        }
    }
    return Jy(r, t, n)
}

function Zy(e, t, n, r = 0, o) {
    if (e !== null) {
        if (t[N] & 2048 && !(r & 2)) {
            let s = SS(e, t, n, r, tn);
            if (s !== tn) return s
        }
        let i = Xy(e, t, n, r, tn);
        if (i !== tn) return i
    }
    return Qy(t, n, r, o)
}

function Xy(e, t, n, r, o) {
    let i = IS(n);
    if (typeof i == "function") {
        if (!hf(t, e, r)) return r & 1 ? Jy(o, n, r) : Qy(t, n, r, o);
        try {
            let s;
            if (s = i(r), s == null && !(r & 8)) ec(n);
            else return s
        } finally {
            mf()
        }
    } else if (typeof i == "number") {
        let s = null,
            a = Yy(e, t),
            c = Lo,
            l = r & 1 ? t[Pe][je] : null;
        for ((a === -1 || r & 4) && (c = a === -1 ? Ep(e, t) : t[a + 8], c === Lo || !iy(r, !1) ? a = -1 : (s = t[b], a = bc(c), t = wc(c, t))); a !== -1;) {
            let u = t[b];
            if (oy(i, a, u.data)) {
                let d = CS(a, t, n, s, r, l);
                if (d !== tn) return d
            }
            c = t[a + 8], c !== Lo && iy(r, t[b].data[a + 8] === l) && oy(i, a, t) ? (s = u, a = bc(c), t = wc(c, t)) : a = -1
        }
    }
    return o
}

function CS(e, t, n, r, o, i) {
    let s = t[b],
        a = s.data[e + 8],
        c = r == null ? _n(a) && Of : r != s && (a.type & 3) !== 0,
        l = o & 1 && i === a,
        u = xc(a, s, n, c, l);
    return u !== null ? Xi(t, s, u, a, o) : tn
}

function xc(e, t, n, r, o) {
    let i = e.providerIndexes,
        s = t.data,
        a = i & 1048575,
        c = e.directiveStart,
        l = e.directiveEnd,
        u = i >> 20,
        d = r ? a : a + u,
        f = o ? a + u : l;
    for (let p = d; p < f; p++) {
        let m = s[p];
        if (p < c && n === m || p >= c && m.type === n) return p
    }
    if (o) {
        let p = s[c];
        if (p && Xt(p) && p.type === n) return c
    }
    return null
}

function Xi(e, t, n, r, o) {
    let i = e[n],
        s = t.data;
    if (i instanceof Vr) {
        let a = i;
        if (a.resolving) throw Ud("");
        let c = Ac(a.canSeeViewProviders);
        a.resolving = !0;
        let l = s[n].type || s[n],
            u, d = a.injectImpl ? Be(a.injectImpl) : null,
            f = hf(e, r, 0);
        try {
            i = e[n] = a.factory(void 0, o, s, e, r), t.firstCreatePass && n >= r.directiveStart && fS(n, s[n], t)
        } finally {
            d !== null && Be(d), Ac(c), a.resolving = !1, mf()
        }
    }
    return i
}

function IS(e) {
    if (typeof e == "string") return e.charCodeAt(0) || 0;
    let t = e.hasOwnProperty(Mr) ? e[Mr] : void 0;
    return typeof t == "number" ? t >= 0 ? t & qy : TS : t
}

function oy(e, t, n) {
    let r = 1 << e;
    return !!(n[t + (e >> Ky)] & r)
}

function iy(e, t) {
    return !(e & 2) && !(e & 1 && t)
}
var Hr = class {
    _tNode;
    _lView;
    constructor(t, n) {
        this._tNode = t, this._lView = n
    }
    get(t, n, r) {
        return Zy(this._tNode, this._lView, t, br(r), n)
    }
};

function TS() {
    return new Hr(he(), C())
}

function as(e) {
    return ss(() => {
        let t = e.prototype.constructor,
            n = t[Mi] || Lf(t),
            r = Object.prototype,
            o = Object.getPrototypeOf(e.prototype).constructor;
        for (; o && o !== r;) {
            let i = o[Mi] || Lf(o);
            if (i && i !== n) return i;
            o = Object.getPrototypeOf(o)
        }
        return i => new i
    })
}

function Lf(e) {
    return wd(e) ? () => {
        let t = Lf(Se(e));
        return t && t()
    } : Kn(e)
}

function SS(e, t, n, r, o) {
    let i = e,
        s = t;
    for (; i !== null && s !== null && s[N] & 2048 && !Mo(s);) {
        let a = Xy(i, s, n, r | 2, tn);
        if (a !== tn) return a;
        let c = i.parent;
        if (!c) {
            let l = s[Kd];
            if (l) {
                let u = l.get(n, tn, r & -5);
                if (u !== tn) return u
            }
            c = e0(s), s = s[Rr]
        }
        i = c
    }
    return o
}

function e0(e) {
    let t = e[b],
        n = t.type;
    return n === 2 ? t.declTNode : n === 1 ? e[je] : null
}

function cs(e) {
    return xS(he(), e)
}

function bS() {
    return Vo(he(), C())
}

function Vo(e, t) {
    return new it(mt(e, t))
}
var it = (() => {
    class e {
        nativeElement;
        constructor(n) {
            this.nativeElement = n
        }
        static __NG_ELEMENT_ID__ = bS
    }
    return e
})();

function t0(e) {
    return e instanceof it ? e.nativeElement : e
}

function wS() {
    return this._results[Symbol.iterator]()
}
var Nc = class {
    _emitDistinctChangesOnly;
    dirty = !0;
    _onDirty = void 0;
    _results = [];
    _changesDetected = !1;
    _changes = void 0;
    length = 0;
    first = void 0;
    last = void 0;
    get changes() {
        return this._changes ? ? = new ne
    }
    constructor(t = !1) {
        this._emitDistinctChangesOnly = t
    }
    get(t) {
        return this._results[t]
    }
    map(t) {
        return this._results.map(t)
    }
    filter(t) {
        return this._results.filter(t)
    }
    find(t) {
        return this._results.find(t)
    }
    reduce(t, n) {
        return this._results.reduce(t, n)
    }
    forEach(t) {
        this._results.forEach(t)
    }
    some(t) {
        return this._results.some(t)
    }
    toArray() {
        return this._results.slice()
    }
    toString() {
        return this._results.toString()
    }
    reset(t, n) {
        this.dirty = !1;
        let r = EE(t);
        (this._changesDetected = !gE(this._results, r, n)) && (this._results = r, this.length = r.length, this.last = r[this.length - 1], this.first = r[0])
    }
    notifyOnChanges() {
        this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes.next(this)
    }
    onDirty(t) {
        this._onDirty = t
    }
    setDirty() {
        this.dirty = !0, this._onDirty ? .()
    }
    destroy() {
        this._changes !== void 0 && (this._changes.complete(), this._changes.unsubscribe())
    }[Symbol.iterator] = wS
};

function n0(e) {
    return (e.flags & 128) === 128
}
var yp = (function(e) {
        return e[e.OnPush = 0] = "OnPush", e[e.Eager = 1] = "Eager", e[e.Default = 1] = "Default", e
    })(yp || {}),
    r0 = new Map,
    AS = 0;

function MS() {
    return AS++
}

function NS(e) {
    r0.set(e[yn], e)
}

function kf(e) {
    r0.delete(e[yn])
}
var sy = "__ngContext__";

function Fo(e, t) {
    Dn(t) ? (e[sy] = t[yn], NS(t)) : e[sy] = t
}

function o0(e) {
    return s0(e[wo])
}

function i0(e) {
    return s0(e[pt])
}

function s0(e) {
    for (; e !== null && !Pt(e);) e = e[pt];
    return e
}
var Ff;

function vp(e) {
    Ff = e
}

function a0() {
    if (Ff !== void 0) return Ff;
    if (typeof document < "u") return document;
    throw new g(210, !1)
}
var ls = new v("", {
        factory: () => RS
    }),
    RS = "ng";
var Yc = new v(""),
    us = new v("", {
        providedIn: "platform",
        factory: () => "unknown"
    }),
    OS = new v(""),
    ds = new v("", {
        factory: () => h(Z).body ? .querySelector("[ngCspNonce]") ? .getAttribute("ngCspNonce") || null
    }),
    Jc = {
        breakpoints: [16, 32, 48, 64, 96, 128, 256, 384, 640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        placeholderResolution: 30,
        disableImageSizeWarning: !1,
        disableImageLazyLoadWarning: !1
    },
    Qc = new v("", {
        factory: () => Jc
    });
var PS = (() => {
    class e {
        static\ u0275prov = y({
            token: e,
            providedIn: "root",
            factory: () => {
                let n = new e;
                return n.store = LS(h(Z), h(ls)), n
            }
        });
        store = {};
        onSerializeCallbacks = {};
        get(n, r) {
            return this.store[n] !== void 0 ? this.store[n] : r
        }
        set(n, r) {
            this.store[n] = r
        }
        remove(n) {
            delete this.store[n]
        }
        hasKey(n) {
            return this.store.hasOwnProperty(n)
        }
        get isEmpty() {
            return Object.keys(this.store).length === 0
        }
        onSerialize(n, r) {
            this.onSerializeCallbacks[n] = r
        }
        toJson() {
            for (let n in this.onSerializeCallbacks)
                if (this.onSerializeCallbacks.hasOwnProperty(n)) try {
                    this.store[n] = this.onSerializeCallbacks[n]()
                } catch (r) {
                    console.warn("Exception in onSerialize callback: ", r)
                }
            return JSON.stringify(this.store).replace(/</g, "\\u003C").replace(/\//g, "\\u002F")
        }
    }
    return e
})();

function LS(e, t) {
    let n = e.getElementById(t + "-state");
    if (n ? .textContent) try {
        return JSON.parse(n.textContent)
    } catch (r) {
        console.warn("Exception while restoring TransferState for app " + t, r)
    }
    return {}
}
var c0 = "r";
var l0 = "di";
var Dp = new v(""),
    u0 = !1,
    d0 = new v("", {
        factory: () => u0
    });
var Zc = new v("");
var ay = new WeakMap;

function kS(e, t) {
    if (e == null || typeof e != "object") return;
    let n = ay.get(e);
    n || (n = new WeakSet, ay.set(e, n)), n.add(t)
}
var FS = (e, t, n, r) => {};

function US(e, t, n, r) {
    FS(e, t, n, r)
}

function Xc(e) {
    return (e.flags & 32) === 32
}
var BS = () => null;

function f0(e, t, n = !1) {
    return BS(e, t, n)
}

function p0(e, t) {
    let n = e.contentQueries;
    if (n !== null) {
        let r = S(null);
        try {
            for (let o = 0; o < n.length; o += 2) {
                let i = n[o],
                    s = n[o + 1];
                if (s !== -1) {
                    let a = e.data[s];
                    Gi(i), a.contentQueries(2, t[s], s)
                }
            }
        } finally {
            S(r)
        }
    }
}

function Uf(e, t, n) {
    Gi(0);
    let r = S(null);
    try {
        t(e, n)
    } finally {
        S(r)
    }
}

function _p(e, t, n) {
    if (Jd(t)) {
        let r = S(null);
        try {
            let o = t.directiveStart,
                i = t.directiveEnd;
            for (let s = o; s < i; s++) {
                let a = e.data[s];
                if (a.contentQueries) {
                    let c = n[s];
                    a.contentQueries(1, c, s)
                }
            }
        } finally {
            S(r)
        }
    }
}
var kt = (function(e) {
    return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e[e.ExperimentalIsolatedShadowDom = 4] = "ExperimentalIsolatedShadowDom", e
})(kt || {});
var mc;

function jS() {
    if (mc === void 0 && (mc = null, ge.trustedTypes)) try {
        mc = ge.trustedTypes.createPolicy("angular", {
            createHTML: e => e,
            createScript: e => e,
            createScriptURL: e => e
        })
    } catch (e) {}
    return mc
}

function el(e) {
    return jS() ? .createHTML(e) || e
}
var gc;

function h0() {
    if (gc === void 0 && (gc = null, ge.trustedTypes)) try {
        gc = ge.trustedTypes.createPolicy("angular#unsafe-bypass", {
            createHTML: e => e,
            createScript: e => e,
            createScriptURL: e => e
        })
    } catch (e) {}
    return gc
}

function cy(e) {
    return h0() ? .createHTML(e) || e
}

function ly(e) {
    return h0() ? .createScriptURL(e) || e
}
var Cn = class {
        changingThisBreaksApplicationSecurity;
        constructor(t) {
            this.changingThisBreaksApplicationSecurity = t
        }
        toString() {
            return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${Ya})`
        }
    },
    Bf = class extends Cn {
        getTypeName() {
            return "HTML"
        }
    },
    jf = class extends Cn {
        getTypeName() {
            return "Style"
        }
    },
    Hf = class extends Cn {
        getTypeName() {
            return "Script"
        }
    },
    Vf = class extends Cn {
        getTypeName() {
            return "URL"
        }
    },
    $f = class extends Cn {
        getTypeName() {
            return "ResourceURL"
        }
    };

function Ve(e) {
    return e instanceof Cn ? e.changingThisBreaksApplicationSecurity : e
}

function on(e, t) {
    let n = m0(e);
    if (n != null && n !== t) {
        if (n === "ResourceURL" && t === "URL") return !0;
        throw new Error(`Required a safe ${t}, got a ${n} (see ${Ya})`)
    }
    return n === t
}

function m0(e) {
    return e instanceof Cn && e.getTypeName() || null
}

function xp(e) {
    return new Bf(e)
}

function Cp(e) {
    return new jf(e)
}

function Ip(e) {
    return new Hf(e)
}

function Tp(e) {
    return new Vf(e)
}

function Sp(e) {
    return new $f(e)
}

function HS(e) {
    let t = new Wf(e);
    return VS() ? new Gf(t) : t
}
var Gf = class {
        inertDocumentHelper;
        constructor(t) {
            this.inertDocumentHelper = t
        }
        getInertBodyElement(t) {
            t = "<body><remove></remove>" + t;
            try {
                let n = new window.DOMParser().parseFromString(el(t), "text/html").body;
                return n === null ? this.inertDocumentHelper.getInertBodyElement(t) : (n.firstChild ? .remove(), n)
            } catch (n) {
                return null
            }
        }
    },
    Wf = class {
        defaultDoc;
        inertDocument;
        constructor(t) {
            this.defaultDoc = t, this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert")
        }
        getInertBodyElement(t) {
            let n = this.inertDocument.createElement("template");
            return n.innerHTML = el(t), n
        }
    };

function VS() {
    try {
        return !!new window.DOMParser().parseFromString(el(""), "text/html")
    } catch (e) {
        return !1
    }
}
var $S = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;

function fs(e) {
    return e = String(e), e.match($S) ? e : "unsafe:" + e
}

function In(e) {
    let t = {};
    for (let n of e.split(",")) t[n] = !0;
    return t
}

function ps(...e) {
    let t = {};
    for (let n of e)
        for (let r in n) n.hasOwnProperty(r) && (t[r] = !0);
    return t
}
var g0 = In("area,br,col,hr,img,wbr"),
    E0 = In("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"),
    y0 = In("rp,rt"),
    GS = ps(y0, E0),
    WS = ps(E0, In("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")),
    zS = ps(y0, In("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")),
    uy = ps(g0, WS, zS, GS),
    v0 = In("background,cite,href,itemtype,longdesc,poster,src,xlink:href"),
    qS = In("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"),
    KS = In("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"),
    YS = ps(v0, qS, KS),
    JS = In("script,style,template");
var zf = class {
    sanitizedSomething = !1;
    buf = [];
    sanitizeChildren(t) {
        let n = t.firstChild,
            r = !0,
            o = [];
        for (; n;) {
            if (n.nodeType === Node.ELEMENT_NODE ? r = this.startElement(n) : n.nodeType === Node.TEXT_NODE ? this.chars(n.nodeValue) : this.sanitizedSomething = !0, r && n.firstChild) {
                o.push(n), n = XS(n);
                continue
            }
            for (; n;) {
                n.nodeType === Node.ELEMENT_NODE && this.endElement(n);
                let i = ZS(n);
                if (i) {
                    n = i;
                    break
                }
                n = o.pop()
            }
        }
        return this.buf.join("")
    }
    startElement(t) {
        let n = dy(t).toLowerCase();
        if (!uy.hasOwnProperty(n)) return this.sanitizedSomething = !0, !JS.hasOwnProperty(n);
        this.buf.push("<"), this.buf.push(n);
        let r = t.attributes;
        for (let o = 0; o < r.length; o++) {
            let i = r.item(o),
                s = i.name,
                a = s.toLowerCase();
            if (!YS.hasOwnProperty(a)) {
                this.sanitizedSomething = !0;
                continue
            }
            let c = i.value;
            v0[a] && (c = fs(c)), this.buf.push(" ", s, '="', fy(c), '"')
        }
        return this.buf.push(">"), !0
    }
    endElement(t) {
        let n = dy(t).toLowerCase();
        uy.hasOwnProperty(n) && !g0.hasOwnProperty(n) && (this.buf.push("</"), this.buf.push(n), this.buf.push(">"))
    }
    chars(t) {
        this.buf.push(fy(t))
    }
};

function QS(e, t) {
    return (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node.DOCUMENT_POSITION_CONTAINED_BY
}

function ZS(e) {
    let t = e.nextSibling;
    if (t && e !== t.previousSibling) throw D0(t);
    return t
}

function XS(e) {
    let t = e.firstChild;
    if (t && QS(e, t)) throw D0(t);
    return t
}

function dy(e) {
    let t = e.nodeName;
    return typeof t == "string" ? t : "FORM"
}

function D0(e) {
    return new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`)
}
var eb = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g,
    tb = /([^\#-~ |!])/g;

function fy(e) {
    return e.replace(/&/g, "&amp;").replace(eb, function(t) {
        let n = t.charCodeAt(0),
            r = t.charCodeAt(1);
        return "&#" + ((n - 55296) * 1024 + (r - 56320) + 65536) + ";"
    }).replace(tb, function(t) {
        return "&#" + t.charCodeAt(0) + ";"
    }).replace(/</g, "&lt;").replace(/>/g, "&gt;")
}
var Ec;

function tl(e, t) {
    let n = null;
    try {
        Ec = Ec || HS(e);
        let r = t ? String(t) : "";
        n = Ec.getInertBodyElement(r);
        let o = 5,
            i = r;
        do {
            if (o === 0) throw new Error("Failed to sanitize html because the input is unstable");
            o--, r = i, i = n.innerHTML, n = Ec.getInertBodyElement(r)
        } while (r !== i);
        let a = new zf().sanitizeChildren(py(n) || n);
        return el(a)
    } finally {
        if (n) {
            let r = py(n) || n;
            for (; r.firstChild;) r.firstChild.remove()
        }
    }
}

function py(e) {
    return "content" in e && nb(e) ? e.content : null
}

function nb(e) {
    return e.nodeType === Node.ELEMENT_NODE && e.nodeName === "TEMPLATE"
}
var rb = /^>|^->|<!--|-->|--!>|<!-$/g,
    ob = /(<|>)/g,
    ib = "\u200B$1\u200B";

function sb(e) {
    return e.replace(rb, t => t.replace(ob, ib))
}

function ab(e, t) {
    return e.createText(t)
}

function cb(e, t, n) {
    e.setValue(t, n)
}

function lb(e, t) {
    return e.createComment(sb(t))
}

function _0(e, t, n) {
    return e.createElement(t, n)
}

function Rc(e, t, n, r, o) {
    e.insertBefore(t, n, r, o)
}

function x0(e, t, n) {
    e.appendChild(t, n)
}

function hy(e, t, n, r, o) {
    r !== null ? Rc(e, t, n, r, o) : x0(e, t, n)
}

function C0(e, t, n, r) {
    e.removeChild(null, t, n, r)
}

function ub(e, t, n) {
    e.setAttribute(t, "style", n)
}

function db(e, t, n) {
    n === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n)
}

function I0(e, t, n) {
    let {
        mergedAttrs: r,
        classes: o,
        styles: i
    } = n;
    r !== null && gS(e, t, r), o !== null && db(e, t, o), i !== null && ub(e, t, i)
}
var vt = (function(e) {
    return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] = "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e
})(vt || {});

function fb(e) {
    let t = wp();
    return t ? cy(t.sanitize(vt.HTML, e) || "") : on(e, "HTML") ? cy(Ve(e)) : tl(a0(), pe(e))
}

function T0(e) {
    let t = wp();
    return t ? t.sanitize(vt.URL, e) || "" : on(e, "URL") ? Ve(e) : fs(pe(e))
}

function S0(e) {
    let t = wp();
    if (t) return ly(t.sanitize(vt.RESOURCE_URL, e) || "");
    if (on(e, "ResourceURL")) return ly(Ve(e));
    throw new g(904, !1)
}
var pb = {
    embed: {
        src: !0
    },
    frame: {
        src: !0
    },
    iframe: {
        src: !0
    },
    media: {
        src: !0
    },
    base: {
        href: !0
    },
    link: {
        href: !0
    },
    object: {
        data: !0,
        codebase: !0
    }
};

function hb(e, t) {
    return pb[e.toLowerCase()] ? .[t.toLowerCase()] === !0 ? S0 : T0
}

function bp(e, t, n) {
    return hb(t, n)(e)
}

function wp() {
    let e = C();
    return e && e[Ot].sanitizer
}

function mb(e) {
    return e.ownerDocument.defaultView
}

function b0(e) {
    return e instanceof Function ? e() : e
}

function gb(e, t, n) {
    let r = e.length;
    for (;;) {
        let o = e.indexOf(t, n);
        if (o === -1) return o;
        if (o === 0 || e.charCodeAt(o - 1) <= 32) {
            let i = t.length;
            if (o + i === r || e.charCodeAt(o + i) <= 32) return o
        }
        n = o + 1
    }
}
var w0 = "ng-template";

function Eb(e, t, n, r) {
    let o = 0;
    if (r) {
        for (; o < t.length && typeof t[o] == "string"; o += 2)
            if (t[o] === "class" && gb(t[o + 1].toLowerCase(), n, 0) !== -1) return !0
    } else if (Ap(e)) return !1;
    if (o = t.indexOf(1, o), o > -1) {
        let i;
        for (; ++o < t.length && typeof(i = t[o]) == "string";)
            if (i.toLowerCase() === n) return !0
    }
    return !1
}

function Ap(e) {
    return e.type === 4 && e.value !== w0
}

function yb(e, t, n) {
    let r = e.type === 4 && !n ? w0 : e.value;
    return t === r
}

function vb(e, t, n) {
    let r = 4,
        o = e.attrs,
        i = o !== null ? xb(o) : 0,
        s = !1;
    for (let a = 0; a < t.length; a++) {
        let c = t[a];
        if (typeof c == "number") {
            if (!s && !Lt(r) && !Lt(c)) return !1;
            if (s && Lt(c)) continue;
            s = !1, r = c | r & 1;
            continue
        }
        if (!s)
            if (r & 4) {
                if (r = 2 | r & 1, c !== "" && !yb(e, c, n) || c === "" && t.length === 1) {
                    if (Lt(r)) return !1;
                    s = !0
                }
            } else if (r & 8) {
            if (o === null || !Eb(e, o, c, n)) {
                if (Lt(r)) return !1;
                s = !0
            }
        } else {
            let l = t[++a],
                u = Db(c, o, Ap(e), n);
            if (u === -1) {
                if (Lt(r)) return !1;
                s = !0;
                continue
            }
            if (l !== "") {
                let d;
                if (u > i ? d = "" : d = o[u + 1].toLowerCase(), r & 2 && l !== d) {
                    if (Lt(r)) return !1;
                    s = !0
                }
            }
        }
    }
    return Lt(r) || s
}

function Lt(e) {
    return (e & 1) === 0
}

function Db(e, t, n, r) {
    if (t === null) return -1;
    let o = 0;
    if (r || !n) {
        let i = !1;
        for (; o < t.length;) {
            let s = t[o];
            if (s === e) return o;
            if (s === 3 || s === 6) i = !0;
            else if (s === 1 || s === 2) {
                let a = t[++o];
                for (; typeof a == "string";) a = t[++o];
                continue
            } else {
                if (s === 4) break;
                if (s === 0) {
                    o += 4;
                    continue
                }
            }
            o += i ? 1 : 2
        }
        return -1
    } else return Cb(t, e)
}

function A0(e, t, n = !1) {
    for (let r = 0; r < t.length; r++)
        if (vb(e, t[r], n)) return !0;
    return !1
}

function _b(e) {
    let t = e.attrs;
    if (t != null) {
        let n = t.indexOf(5);
        if ((n & 1) === 0) return t[n + 1]
    }
    return null
}

function xb(e) {
    for (let t = 0; t < e.length; t++) {
        let n = e[t];
        if (Wy(n)) return t
    }
    return e.length
}

function Cb(e, t) {
    let n = e.indexOf(4);
    if (n > -1)
        for (n++; n < e.length;) {
            let r = e[n];
            if (typeof r == "number") return -1;
            if (r === t) return n;
            n++
        }
    return -1
}

function Ib(e, t) {
    e: for (let n = 0; n < t.length; n++) {
        let r = t[n];
        if (e.length === r.length) {
            for (let o = 0; o < e.length; o++)
                if (e[o] !== r[o]) continue e;
            return !0
        }
    }
    return !1
}

function my(e, t) {
    return e ? ":not(" + t.trim() + ")" : t
}

function Tb(e) {
    let t = e[0],
        n = 1,
        r = 2,
        o = "",
        i = !1;
    for (; n < e.length;) {
        let s = e[n];
        if (typeof s == "string")
            if (r & 2) {
                let a = e[++n];
                o += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]"
            } else r & 8 ? o += "." + s : r & 4 && (o += " " + s);
        else o !== "" && !Lt(s) && (t += my(i, o), o = ""), r = s, i = i || !Lt(r);
        n++
    }
    return o !== "" && (t += my(i, o)), t
}

function Sb(e) {
    return e.map(Tb).join(",")
}

function bb(e) {
    let t = [],
        n = [],
        r = 1,
        o = 2;
    for (; r < e.length;) {
        let i = e[r];
        if (typeof i == "string") o === 2 ? i !== "" && t.push(i, e[++r]) : o === 8 && n.push(i);
        else {
            if (!Lt(o)) break;
            o = i
        }
        r++
    }
    return n.length && t.push(1, ...n), t
}
var ce = {};

function Mp(e, t, n, r, o, i, s, a, c, l, u) {
    let d = z + r,
        f = d + o,
        p = wb(d, f),
        m = typeof l == "function" ? l() : l;
    return p[b] = {
        type: e,
        blueprint: p,
        template: n,
        queries: null,
        viewQuery: a,
        declTNode: t,
        data: p.slice().fill(null, d),
        bindingStartIndex: d,
        expandoStartIndex: f,
        hostBindingOpCodes: null,
        firstCreatePass: !0,
        firstUpdatePass: !0,
        staticViewQueries: !1,
        staticContentQueries: !1,
        preOrderHooks: null,
        preOrderCheckHooks: null,
        contentHooks: null,
        contentCheckHooks: null,
        viewHooks: null,
        viewCheckHooks: null,
        destroyHooks: null,
        cleanup: null,
        contentQueries: null,
        components: null,
        directiveRegistry: typeof i == "function" ? i() : i,
        pipeRegistry: typeof s == "function" ? s() : s,
        firstChild: null,
        schemas: c,
        consts: m,
        incompleteFirstPass: !1,
        ssrId: u
    }
}

function wb(e, t) {
    let n = [];
    for (let r = 0; r < t; r++) n.push(r < e ? null : ce);
    return n
}

function Ab(e) {
    let t = e.tView;
    return t === null || t.incompleteFirstPass ? e.tView = Mp(1, null, e.template, e.decls, e.vars, e.directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t
}

function Np(e, t, n, r, o, i, s, a, c, l, u) {
    let d = t.blueprint.slice();
    return d[Rt] = o, d[N] = r | 4 | 128 | 8 | 64 | 1024, (l !== null || e && e[N] & 2048) && (d[N] |= 2048), Xd(d), d[De] = d[Rr] = e, d[ie] = n, d[Ot] = s || e && e[Ot], d[W] = a || e && e[W], d[rt] = c || e && e[rt] || null, d[je] = i, d[yn] = MS(), d[Nr] = u, d[Kd] = l, d[Pe] = t.type == 2 ? e[Pe] : d, d
}

function Mb(e, t, n) {
    let r = mt(t, e),
        o = Ab(n),
        i = e[Ot].rendererFactory,
        s = Rp(e, Np(e, o, null, M0(n), r, t, null, i.createRenderer(r, n), null, null, null));
    return e[t.index] = s
}

function M0(e) {
    let t = 16;
    return e.signals ? t = 4096 : e.onPush && (t = 64), t
}

function N0(e, t, n, r) {
    if (n === 0) return -1;
    let o = t.length;
    for (let i = 0; i < n; i++) t.push(r), e.blueprint.push(r), e.data.push(null);
    return o
}

function Rp(e, t) {
    return e[wo] ? e[qd][pt] = t : e[wo] = t, e[qd] = t, t
}

function Nb(e = 1) {
    R0(Y(), C(), qe() + e, !1)
}

function R0(e, t, n, r) {
    if (!r)
        if ((t[N] & 3) === 3) {
            let i = e.preOrderCheckHooks;
            i !== null && Dc(t, i, n)
        } else {
            let i = e.preOrderHooks;
            i !== null && _c(t, i, 0, n)
        }
    tr(n)
}
var nl = (function(e) {
    return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", e
})(nl || {});

function qf(e, t, n, r) {
    let o = S(null);
    try {
        let [i, s, a] = e.inputs[n], c = null;
        (s & nl.SignalBased) !== 0 && (c = t[i][ue]), c !== null && c.transformFn !== void 0 ? r = c.transformFn(r) : a !== null && (r = a.call(t, r)), e.setInput !== null ? e.setInput(t, c, r, n, i) : By(t, c, i, r)
    } finally {
        S(o)
    }
}
var Ft = (function(e) {
        return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e
    })(Ft || {}),
    Rb;

function Op(e, t) {
    return Rb(e, t)
}
var O0 = new v("", {
    factory: () => !1
});
var Ob = !1,
    P0 = typeof document < "u" && typeof document ? .documentElement ? .getAnimations == "function";

function Pb(e) {
    return e[rt].get(O0, Ob)
}

function Lb(e, t, n) {
    let r = es.get(e);
    if (r) {
        for (let o of t) r.classList.push(o);
        for (let o of n) r.cleanupFns.push(o)
    } else es.set(e, {
        classList: t,
        cleanupFns: n
    })
}

function L0(e) {
    let t = es.get(e);
    if (t) {
        for (let n of t.cleanupFns) n();
        es.delete(e)
    }
    Oc.delete(e)
}
var es = new WeakMap,
    Oc = new WeakMap,
    Kf = new WeakMap,
    Ji = new WeakSet;

function kb(e, t) {
    let n = Kf.get(e);
    if (!n || n.length === 0) return;
    let r = t.parentNode,
        o = t.previousSibling;
    for (let i = n.length - 1; i >= 0; i--) {
        let s = n[i],
            a = s.parentNode;
        s === t ? (n.splice(i, 1), Ji.add(s), s.dispatchEvent(new CustomEvent("animationend", {
            detail: {
                cancel: !0
            }
        }))) : (o && s === o || a && r && a !== r) && (n.splice(i, 1), s.dispatchEvent(new CustomEvent("animationend", {
            detail: {
                cancel: !0
            }
        })), s.parentNode ? .removeChild(s))
    }
}

function Fb(e, t) {
    let n = Kf.get(e);
    n ? n.includes(t) || n.push(t) : Kf.set(e, [t])
}

function gy(e) {
    let t = e[vn] ? ? = {};
    return t.enter ? ? = new Map
}

function Ub(e) {
    let t = typeof e == "function" ? e() : e,
        n = Array.isArray(t) ? t : null;
    return typeof t == "string" && (n = t.trim().split(/\s+/).filter(r => r)), n
}

function Pc(e) {
    return e.composedPath ? e.composedPath()[0] : e.target
}

function k0(e, t) {
    let n = Oc.get(t);
    return n === void 0 ? !0 : t === Pc(e) && (n.animationName !== void 0 && e.animationName === n.animationName || n.propertyName !== void 0 && (n.propertyName === "all" || e.propertyName === n.propertyName))
}

function Bb(e, t, n) {
    let r = e.get(t.index) ? ? {
        animateFns: []
    };
    r.animateFns.push(n), e.set(t.index, r)
}

function Lc(e) {
    if (!e) return 0;
    let t = e.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3;
    return parseFloat(e) * t
}

function jr(e, t) {
    return e.getPropertyValue(t).split(",").map(r => r.trim())
}

function jb(e) {
    let t = jr(e, "transition-property"),
        n = jr(e, "transition-duration"),
        r = jr(e, "transition-delay"),
        o = {
            propertyName: "",
            duration: 0,
            animationName: void 0
        };
    for (let i = 0; i < t.length; i++) {
        let s = Lc(r[i]) + Lc(n[i]);
        s > o.duration && (o.propertyName = t[i], o.duration = s)
    }
    return o
}

function Hb(e) {
    let t = jr(e, "animation-name"),
        n = jr(e, "animation-delay"),
        r = jr(e, "animation-duration"),
        o = jr(e, "animation-iteration-count"),
        i = {
            animationName: "",
            propertyName: void 0,
            duration: 0
        };
    for (let s = 0; s < t.length; s++) {
        let a = Lc(n[s]) + Lc(r[s]),
            c = o[s];
        a > i.duration && c !== "infinite" && (i.animationName = t[s], i.duration = a)
    }
    return i
}

function F0(e, t) {
    return e !== void 0 && e.duration > t.duration
}

function U0(e) {
    return (e.animationName != null || e.propertyName != null) && e.duration > 0
}

function Vb(e, t) {
    let n = getComputedStyle(e),
        r = Hb(n),
        o = jb(n),
        i = r.duration > o.duration ? r : o;
    F0(t.get(e), i) || U0(i) && t.set(e, i)
}

function $b(e, t, n) {
    if (!n) return;
    let r = e.getAnimations();
    return r.length === 0 ? Vb(e, t) : Gb(e, t, r)
}

function Gb(e, t, n) {
    let r = {
        animationName: void 0,
        propertyName: void 0,
        duration: 0
    };
    for (let o of n) {
        let i = o.effect ? .getTiming();
        if (i ? .iterations === 1 / 0) continue;
        let s = typeof i ? .duration == "number" ? i.duration : 0,
            a = (i ? .delay ? ? 0) + s,
            c = o.playbackRate;
        c !== void 0 && c !== 0 && c !== 1 && (a /= Math.abs(c));
        let l, u;
        o.animationName ? u = o.animationName : l = o.transitionProperty, a >= r.duration && (r = {
            animationName: u,
            propertyName: l,
            duration: a
        })
    }
    F0(t.get(e), r) || U0(r) && t.set(e, r)
}
var $r = new Set,
    rl = (function(e) {
        return e[e.CHANGE_DETECTION = 0] = "CHANGE_DETECTION", e[e.AFTER_NEXT_RENDER = 1] = "AFTER_NEXT_RENDER", e
    })(rl || {}),
    sn = new v(""),
    Ey = new Set;

function Ye(e) {
    Ey.has(e) || (Ey.add(e), performance ? .mark ? .("mark_feature_usage", {
        detail: {
            feature: e
        }
    }))
}
var Pp = (() => {
        class e {
            impl = null;
            execute() {
                this.impl ? .execute()
            }
            static\ u0275prov = y({
                token: e,
                providedIn: "root",
                factory: () => new e
            })
        }
        return e
    })(),
    B0 = [0, 1, 2, 3],
    j0 = (() => {
        class e {
            ngZone = h(Q);
            scheduler = h(Jt);
            errorHandler = h(ut, {
                optional: !0
            });
            sequences = new Set;
            deferredRegistrations = new Set;
            executing = !1;
            constructor() {
                h(sn, {
                    optional: !0
                })
            }
            execute() {
                let n = this.sequences.size > 0;
                n && q(H.AfterRenderHooksStart), this.executing = !0;
                for (let r of B0)
                    for (let o of this.sequences)
                        if (!(o.erroredOrDestroyed || !o.hooks[r])) try {
                            o.pipelinedValue = this.ngZone.runOutsideAngular(() => this.maybeTrace(() => {
                                let i = o.hooks[r];
                                return i(o.pipelinedValue)
                            }, o.snapshot))
                        } catch (i) {
                            o.erroredOrDestroyed = !0, this.errorHandler ? .handleError(i)
                        }
                this.executing = !1;
                for (let r of this.sequences) r.afterRun(), r.once && (this.sequences.delete(r), r.destroy());
                for (let r of this.deferredRegistrations) this.sequences.add(r);
                this.deferredRegistrations.size > 0 && this.scheduler.notify(7), this.deferredRegistrations.clear(), n && q(H.AfterRenderHooksEnd)
            }
            register(n) {
                let {
                    view: r
                } = n;
                r !== void 0 ? ((r[Pr] ? ? = []).push(n), Fr(r), r[N] |= 8192) : this.executing ? this.deferredRegistrations.add(n) : this.addSequence(n)
            }
            addSequence(n) {
                this.sequences.add(n), this.scheduler.notify(7)
            }
            unregister(n) {
                this.executing && this.sequences.has(n) ? (n.erroredOrDestroyed = !0, n.pipelinedValue = void 0, n.once = !0) : (this.sequences.delete(n), this.deferredRegistrations.delete(n))
            }
            maybeTrace(n, r) {
                return r ? r.run(rl.AFTER_NEXT_RENDER, n) : n()
            }
            static\ u0275prov = y({
                token: e,
                providedIn: "root",
                factory: () => new e
            })
        }
        return e
    })(),
    kc = class {
        impl;
        hooks;
        view;
        once;
        snapshot;
        erroredOrDestroyed = !1;
        pipelinedValue = void 0;
        unregisterOnDestroy;
        constructor(t, n, r, o, i, s = null) {
            this.impl = t, this.hooks = n, this.view = r, this.once = o, this.snapshot = s, this.unregisterOnDestroy = i ? .onDestroy(() => this.destroy())
        }
        afterRun() {
            this.erroredOrDestroyed = !1, this.pipelinedValue = void 0, this.snapshot ? .dispose(), this.snapshot = null
        }
        destroy() {
            this.impl.unregister(this), this.unregisterOnDestroy ? .();
            let t = this.view ? .[Pr];
            t && (this.view[Pr] = t.filter(n => n !== this))
        }
    };

function hs(e, t) {
    let n = t ? .injector ? ? h(fe);
    return Ye("NgAfterNextRender"), zb(e, n, t, !0)
}

function Wb(e) {
    return e instanceof Function ? [void 0, void 0, e, void 0] : [e.earlyRead, e.write, e.mixedReadWrite, e.read]
}

function zb(e, t, n, r) {
    let o = t.get(Pp);
    o.impl ? ? = t.get(j0);
    let i = t.get(sn, null, {
            optional: !0
        }),
        s = n ? .manualCleanup !== !0 ? t.get(He) : null,
        a = t.get(Ki, null, {
            optional: !0
        }),
        c = new kc(o.impl, Wb(e), a ? .view, r, s, i ? .snapshot(null));
    return o.impl.register(c), c
}
var ol = new v("", {
    factory: () => ({
        queue: new Set,
        isScheduled: !1,
        scheduler: null,
        injector: h(re)
    })
});

function H0(e, t, n) {
    let r = e.get(ol);
    if (Array.isArray(t))
        for (let o of t) r.queue.add(o), n ? .detachedLeaveAnimationFns ? .push(o);
    else r.queue.add(t), n ? .detachedLeaveAnimationFns ? .push(t);
    r.scheduler && r.scheduler(e)
}

function qb(e, t) {
    let n = e.get(ol);
    if (t.detachedLeaveAnimationFns) {
        for (let r of t.detachedLeaveAnimationFns) n.queue.delete(r);
        t.detachedLeaveAnimationFns = void 0
    }
}

function Kb(e) {
    let t = e.get(ol);
    t.isScheduled || (hs(() => {
        t.isScheduled = !1;
        for (let n of t.queue) n();
        t.queue.clear()
    }, {
        injector: t.injector
    }), t.isScheduled = !0)
}

function Yb(e) {
    let t = e.get(ol);
    t.scheduler = Kb, t.scheduler(e)
}

function V0(e, t) {
    for (let [n, r] of t) H0(e, r.animateFns)
}

function yy(e, t, n, r) {
    let o = e ? .[vn] ? .enter;
    t !== null && o && o.has(n.index) && V0(r, o)
}

function Po(e, t, n, r, o, i, s, a) {
    if (o != null) {
        let c, l = !1;
        Pt(o) ? c = o : Dn(o) && (l = !0, o = o[Rt]);
        let u = ht(o);
        e === 0 && r !== null ? (yy(a, r, i, n), s == null ? x0(t, r, u) : Rc(t, r, u, s || null, !0)) : e === 1 && r !== null ? (yy(a, r, i, n), Rc(t, r, u, s || null, !0), kb(i, u)) : e === 2 ? (a ? .[vn] ? .leave ? .has(i.index) && Fb(i, u), Ji.delete(u), vy(a, i, n, d => {
            if (Ji.has(u)) {
                Ji.delete(u);
                return
            }
            C0(t, u, l, d)
        })) : e === 3 && (Ji.delete(u), vy(a, i, n, () => {
            t.destroyNode(u)
        })), c != null && sw(t, e, n, c, i, r, s)
    }
}

function Jb(e, t) {
    $0(e, t), t[Rt] = null, t[je] = null
}

function Qb(e, t, n, r, o, i) {
    r[Rt] = o, r[je] = t, sl(e, r, n, 1, o, i)
}

function $0(e, t) {
    t[Ot].changeDetectionScheduler ? .notify(9), sl(e, t, t[W], 2, null, null)
}

function Zb(e) {
    let t = e[wo];
    if (!t) return If(e[b], e);
    for (; t;) {
        let n = null;
        if (Dn(t)) n = t[wo];
        else {
            let r = t[se];
            r && (n = r)
        }
        if (!n) {
            for (; t && !t[pt] && t !== e;) Dn(t) && If(t[b], t), t = t[De];
            t === null && (t = e), Dn(t) && If(t[b], t), n = t && t[pt]
        }
        t = n
    }
}

function Lp(e, t) {
    let n = e[Lr],
        r = n.indexOf(t);
    n.splice(r, 1)
}

function il(e, t) {
    if (kr(t)) return;
    let n = t[W];
    n.destroyNode && sl(e, t, n, 3, null, null), Zb(t)
}

function If(e, t) {
    if (kr(t)) return;
    let n = S(null);
    try {
        t[N] &= -129, t[N] |= 256, t[ot] && Dr(t[ot]), tw(e, t), ew(e, t), t[b].type === 1 && t[W].destroy();
        let r = t[Xn];
        if (r !== null && Pt(t[De])) {
            r !== t[De] && Lp(r, t);
            let o = t[Zt];
            o !== null && o.detachView(e)
        }
        kf(t)
    } finally {
        S(n)
    }
}

function vy(e, t, n, r) {
    let o = e ? .[vn];
    if (o == null || o.leave == null || !o.leave.has(t.index)) return r(!1);
    e && $r.add(e[yn]), H0(n, () => {
        if (o.leave && o.leave.has(t.index)) {
            let s = o.leave.get(t.index),
                a = [];
            if (s) {
                for (let c = 0; c < s.animateFns.length; c++) {
                    let l = s.animateFns[c],
                        {
                            promise: u
                        } = l();
                    a.push(u)
                }
                o.detachedLeaveAnimationFns = void 0
            }
            o.running = Promise.allSettled(a), Xb(e, r)
        } else e && $r.delete(e[yn]), r(!1)
    }, o)
}

function Xb(e, t) {
    let n = e[vn] ? .running;
    if (n) {
        n.then(() => {
            e[vn].running = void 0, $r.delete(e[yn]), t(!0)
        });
        return
    }
    t(!1)
}

function ew(e, t) {
    let n = e.cleanup,
        r = t[bo];
    if (n !== null)
        for (let s = 0; s < n.length - 1; s += 2)
            if (typeof n[s] == "string") {
                let a = n[s + 3];
                a >= 0 ? r[a]() : r[-a].unsubscribe(), s += 2
            } else {
                let a = r[n[s + 1]];
                n[s].call(a)
            }
    r !== null && (t[bo] = null);
    let o = t[gn];
    if (o !== null) {
        t[gn] = null;
        for (let s = 0; s < o.length; s++) {
            let a = o[s];
            a()
        }
    }
    let i = t[Yn];
    if (i !== null) {
        t[Yn] = null;
        for (let s of i) s.destroy()
    }
}

function tw(e, t) {
    let n;
    if (e != null && (n = e.destroyHooks) != null)
        for (let r = 0; r < n.length; r += 2) {
            let o = t[n[r]];
            if (!(o instanceof Vr)) {
                let i = n[r + 1];
                if (Array.isArray(i))
                    for (let s = 0; s < i.length; s += 2) {
                        let a = o[i[s]],
                            c = i[s + 1];
                        q(H.LifecycleHookStart, a, c);
                        try {
                            c.call(a)
                        } finally {
                            q(H.LifecycleHookEnd, a, c)
                        }
                    } else {
                        q(H.LifecycleHookStart, o, i);
                        try {
                            i.call(o)
                        } finally {
                            q(H.LifecycleHookEnd, o, i)
                        }
                    }
            }
        }
}

function G0(e, t, n) {
    return nw(e, t.parent, n)
}

function nw(e, t, n) {
    let r = t;
    for (; r !== null && r.type & 168;) t = r, r = t.parent;
    if (r === null) return n[Rt];
    if (_n(r)) {
        let {
            encapsulation: o
        } = e.data[r.directiveStart + r.componentOffset];
        if (o === kt.None || o === kt.Emulated) return null
    }
    return mt(r, n)
}

function W0(e, t, n) {
    return ow(e, t, n)
}

function rw(e, t, n) {
    return e.type & 40 ? mt(e, n) : null
}
var ow = rw,
    Dy;

function kp(e, t, n, r) {
    let o = G0(e, r, t),
        i = t[W],
        s = r.parent || t[je],
        a = W0(s, r, t);
    if (o != null)
        if (Array.isArray(n))
            for (let c = 0; c < n.length; c++) hy(i, o, n[c], a, !1);
        else hy(i, o, n, a, !1);
    Dy !== void 0 && Dy(i, r, t, n, o)
}

function Qi(e, t) {
    if (t !== null) {
        let n = t.type;
        if (n & 3) return mt(t, e);
        if (n & 4) return Yf(-1, e[t.index]);
        if (n & 8) {
            let r = t.child;
            if (r !== null) return Qi(e, r); {
                let o = e[t.index];
                return Pt(o) ? Yf(-1, o) : ht(o)
            }
        } else {
            if (n & 128) return Qi(e, t.next);
            if (n & 32) return Op(t, e)() || ht(e[t.index]); {
                let r = z0(e, t);
                if (r !== null) {
                    if (Array.isArray(r)) return r[0];
                    let o = Jn(e[Pe]);
                    return Qi(o, r)
                } else return Qi(e, t.next)
            }
        }
    }
    return null
}

function z0(e, t) {
    if (t !== null) {
        let r = e[Pe][je],
            o = t.projection;
        return r.projection[o]
    }
    return null
}

function Yf(e, t) {
    let n = se + e + 1;
    if (n < t.length) {
        let r = t[n],
            o = r[b].firstChild;
        if (o !== null) return Qi(r, o)
    }
    return t[er]
}

function Fp(e, t, n, r, o, i, s) {
    for (; n != null;) {
        let a = r[rt];
        if (n.type === 128) {
            n = n.next;
            continue
        }
        let c = r[n.index],
            l = n.type;
        if (s && t === 0 && (c && Fo(ht(c), r), n.flags |= 2), !Xc(n))
            if (l & 8) Fp(e, t, n.child, r, o, i, !1), Po(t, e, a, o, c, n, i, r);
            else if (l & 32) {
            let u = Op(n, r),
                d;
            for (; d = u();) Po(t, e, a, o, d, n, i, r);
            Po(t, e, a, o, c, n, i, r)
        } else l & 16 ? q0(e, t, r, n, o, i) : Po(t, e, a, o, c, n, i, r);
        n = s ? n.projectionNext : n.next
    }
}

function sl(e, t, n, r, o, i) {
    Fp(n, r, e.firstChild, t, o, i, !1)
}

function iw(e, t, n) {
    let r = t[W],
        o = G0(e, n, t),
        i = n.parent || t[je],
        s = W0(i, n, t);
    q0(r, 0, t, n, o, s)
}

function q0(e, t, n, r, o, i) {
    let s = n[Pe],
        c = s[je].projection[r.projection];
    if (Array.isArray(c))
        for (let l = 0; l < c.length; l++) {
            let u = c[l];
            Po(t, e, n[rt], o, u, r, i, n)
        } else {
            let l = c,
                u = s[De];
            n0(r) && (l.flags |= 128), Fp(e, t, l, u, o, i, !0)
        }
}

function sw(e, t, n, r, o, i, s) {
    let a = r[er],
        c = ht(r);
    a !== c && Po(t, e, n, i, a, o, s);
    for (let l = se; l < r.length; l++) {
        let u = r[l];
        sl(u[b], u, e, t, i, a)
    }
}

function aw(e, t, n, r, o) {
    if (t) o ? e.addClass(n, r) : e.removeClass(n, r);
    else {
        let i = r.indexOf("-") === -1 ? void 0 : Ft.DashCase;
        o == null ? e.removeStyle(n, r, i) : (typeof o == "string" && o.endsWith("!important") && (o = o.slice(0, -10), i |= Ft.Important), e.setStyle(n, r, o, i))
    }
}

function K0(e, t, n, r, o) {
    let i = qe(),
        s = r & 2;
    try {
        tr(-1), s && t.length > z && R0(e, t, z, !1);
        let a = s ? H.TemplateUpdateStart : H.TemplateCreateStart;
        q(a, o, n), n(r, o)
    } finally {
        tr(i);
        let a = s ? H.TemplateUpdateEnd : H.TemplateCreateEnd;
        q(a, o, n)
    }
}

function al(e, t, n) {
    pw(e, t, n), (n.flags & 64) === 64 && hw(e, t, n)
}

function $o(e, t, n = mt) {
    let r = t.localNames;
    if (r !== null) {
        let o = t.index + 1;
        for (let i = 0; i < r.length; i += 2) {
            let s = r[i + 1],
                a = s === -1 ? n(t, e) : e[s];
            e[o++] = a
        }
    }
}

function cw(e, t, n, r) {
    let i = r.get(d0, u0) || n === kt.ShadowDom || n === kt.ExperimentalIsolatedShadowDom,
        s = e.selectRootElement(t, i);
    if (s.tagName.toLowerCase() === "script") throw new g(905, !1);
    return lw(s), s
}

function lw(e) {
    uw(e)
}
var uw = () => null;

function dw(e) {
    return e === "class" ? "className" : e === "for" ? "htmlFor" : e === "formaction" ? "formAction" : e === "innerHtml" ? "innerHTML" : e === "readonly" ? "readOnly" : e === "tabindex" ? "tabIndex" : e
}

function Y0(e, t, n, r, o, i) {
    let s = t[b];
    if (Bp(e, s, t, n, r)) {
        _n(e) && fw(t, e.index);
        return
    }
    e.type & 3 && (n = dw(n)), J0(e, t, n, r, o, i)
}

function J0(e, t, n, r, o, i) {
    if (e.type & 3) {
        let s = mt(e, t);
        r = i != null ? i(r, e.value || "", n) : r, o.setProperty(s, n, r)
    } else e.type & 12
}

function fw(e, t) {
    let n = gt(t, e);
    n[N] & 16 || (n[N] |= 64)
}

function pw(e, t, n) {
    let r = n.directiveStart,
        o = n.directiveEnd;
    _n(n) && Mb(t, n, e.data[r + n.componentOffset]), e.firstCreatePass || Mc(n, t);
    let i = n.initialInputs;
    for (let s = r; s < o; s++) {
        let a = e.data[s],
            c = Xi(t, e, s, n);
        if (Fo(c, t), i !== null && yw(t, s - r, c, a, n, i), Xt(a)) {
            let l = gt(n.index, t);
            l[ie] = Xi(t, e, s, n)
        }
    }
}

function hw(e, t, n) {
    let r = n.directiveStart,
        o = n.directiveEnd,
        i = n.index,
        s = BE();
    try {
        tr(i);
        for (let a = r; a < o; a++) {
            let c = e.data[a],
                l = t[a];
            cc(a), (c.hostBindings !== null || c.hostVars !== 0 || c.hostAttrs !== null) && mw(c, l)
        }
    } finally {
        tr(-1), cc(s)
    }
}

function mw(e, t) {
    e.hostBindings !== null && e.hostBindings(1, t)
}

function Up(e, t) {
    let n = e.directiveRegistry,
        r = null;
    if (n)
        for (let o = 0; o < n.length; o++) {
            let i = n[o];
            A0(t, i.selectors, !1) && (r ? ? = [], Xt(i) ? r.unshift(i) : r.push(i))
        }
    return r
}

function gw(e, t, n, r, o, i) {
    let s = mt(e, t);
    Ew(t[W], s, i, e.value, n, r, o)
}

function Ew(e, t, n, r, o, i, s) {
    if (i == null) e.removeAttribute(t, o, n);
    else {
        let a = s == null ? pe(i) : s(i, r || "", o);
        e.setAttribute(t, o, a, n)
    }
}

function yw(e, t, n, r, o, i) {
    let s = i[t];
    if (s !== null)
        for (let a = 0; a < s.length; a += 2) {
            let c = s[a],
                l = s[a + 1];
            qf(r, n, c, l)
        }
}

function cl(e, t, n, r, o) {
    let i = z + n,
        s = t[b],
        a = o(s, t, e, r, n);
    t[i] = a, Ur(e, !0);
    let c = e.type === 2;
    return c ? (I0(t[W], a, e), (NE() === 0 || Ao(e)) && Fo(a, t), RE()) : Fo(a, t), fc() && (!c || !Xc(e)) && kp(s, t, a, e), e
}

function ll(e) {
    let t = e;
    return uf() ? df() : (t = t.parent, Ur(t, !1)), t
}

function vw(e, t) {
    let n = e[rt];
    if (!n) return;
    let r;
    try {
        r = n.get(Ke, null)
    } catch (o) {
        r = null
    }
    r ? .(t)
}

function Bp(e, t, n, r, o) {
    let i = e.inputs ? .[r],
        s = e.hostDirectiveInputs ? .[r],
        a = !1;
    if (s)
        for (let c = 0; c < s.length; c += 2) {
            let l = s[c],
                u = s[c + 1],
                d = t.data[l];
            qf(d, n[l], u, o), a = !0
        }
    if (i)
        for (let c of i) {
            let l = n[c],
                u = t.data[c];
            qf(u, l, r, o), a = !0
        }
    return a
}

function Dw(e, t) {
    let n = gt(t, e),
        r = n[b];
    _w(r, n);
    let o = n[Rt];
    o !== null && n[Nr] === null && (n[Nr] = f0(o, n[rt])), q(H.ComponentStart);
    try {
        jp(r, n, n[ie])
    } finally {
        q(H.ComponentEnd, n[ie])
    }
}

function _w(e, t) {
    for (let n = t.length; n < e.blueprint.length; n++) t.push(e.blueprint[n])
}

function jp(e, t, n) {
    uc(t);
    try {
        let r = e.viewQuery;
        r !== null && Uf(1, r, n);
        let o = e.template;
        o !== null && K0(e, t, o, 1, n), e.firstCreatePass && (e.firstCreatePass = !1), t[Zt] ? .finishViewCreation(e), e.staticContentQueries && p0(e, t), e.staticViewQueries && Uf(2, e.viewQuery, n);
        let i = e.components;
        i !== null && xw(t, i)
    } catch (r) {
        throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), r
    } finally {
        t[N] &= -5, dc()
    }
}

function xw(e, t) {
    for (let n = 0; n < t.length; n++) Dw(e, t[n])
}

function ms(e, t, n, r) {
    let o = S(null);
    try {
        let i = t.tView,
            a = e[N] & 4096 ? 4096 : 16,
            c = Np(e, i, n, a, null, t, null, null, r ? .injector ? ? null, r ? .embeddedViewInjector ? ? null, r ? .dehydratedView ? ? null),
            l = e[t.index];
        c[Xn] = l;
        let u = e[Zt];
        return u !== null && (c[Zt] = u.createEmbeddedView(i)), jp(i, c, n), c
    } finally {
        S(o)
    }
}

function Uo(e, t) {
    return !t || t.firstChild === null || n0(e)
}

function ts(e, t, n, r, o = !1) {
    for (; n !== null;) {
        if (n.type === 128) {
            n = o ? n.projectionNext : n.next;
            continue
        }
        let i = t[n.index];
        i !== null && r.push(ht(i)), Pt(i) && Q0(i, r);
        let s = n.type;
        if (s & 8) ts(e, t, n.child, r);
        else if (s & 32) {
            let a = Op(n, t),
                c;
            for (; c = a();) r.push(c)
        } else if (s & 16) {
            let a = z0(t, n);
            if (Array.isArray(a)) r.push(...a);
            else {
                let c = Jn(t[Pe]);
                ts(c[b], c, a, r, !0)
            }
        }
        n = o ? n.projectionNext : n.next
    }
    return r
}

function Q0(e, t) {
    for (let n = se; n < e.length; n++) {
        let r = e[n],
            o = r[b].firstChild;
        o !== null && ts(r[b], r, o, t)
    }
    e[er] !== e[Rt] && t.push(e[er])
}

function Z0(e) {
    if (e[Pr] !== null) {
        for (let t of e[Pr]) t.impl.addSequence(t);
        e[Pr].length = 0
    }
}
var X0 = [];

function Cw(e) {
    return e[ot] ? ? Iw(e)
}

function Iw(e) {
    let t = X0.pop() ? ? Object.create(Sw);
    return t.lView = e, t
}

function Tw(e) {
    e.lView[ot] !== e && (e.lView = null, X0.push(e))
}
var Sw = B(E({}, Hn), {
    consumerIsAlwaysLive: !0,
    kind: "template",
    consumerMarkedDirty: e => {
        Fr(e.lView)
    },
    consumerOnSignalRead() {
        this.lView[ot] = this
    }
});

function bw(e) {
    let t = e[ot] ? ? Object.create(ww);
    return t.lView = e, t
}
var ww = B(E({}, Hn), {
    consumerIsAlwaysLive: !0,
    kind: "template",
    consumerMarkedDirty: e => {
        let t = Jn(e.lView);
        for (; t && !ev(t[b]);) t = Jn(t);
        t && ef(t)
    },
    consumerOnSignalRead() {
        this.lView[ot] = this
    }
});

function ev(e) {
    return e.type !== 2
}

function tv(e) {
    if (e[Yn] === null) return;
    let t = !0;
    for (; t;) {
        let n = !1;
        for (let r of e[Yn]) r.dirty && (n = !0, r.zone === null || Zone.current === r.zone ? r.run() : r.zone.run(() => r.run()));
        t = n && !!(e[N] & 8192)
    }
}
var Aw = 100;

function nv(e, t = 0) {
    let r = e[Ot].rendererFactory,
        o = !1;
    o || r.begin ? .();
    try {
        Mw(e, t)
    } finally {
        o || r.end ? .()
    }
}

function Mw(e, t) {
    let n = pf();
    try {
        Ri(!0), Jf(e, t);
        let r = 0;
        for (; Vi(e);) {
            if (r === Aw) throw new g(103, !1);
            r++, Jf(e, 1)
        }
    } finally {
        Ri(n)
    }
}

function Nw(e, t, n, r) {
    if (kr(t)) return;
    let o = t[N],
        i = !1,
        s = !1;
    uc(t);
    let a = !0,
        c = null,
        l = null;
    i || (ev(e) ? (l = Cw(t), c = $n(l)) : fa() === null ? (a = !1, l = bw(t), c = $n(l)) : t[ot] && (Dr(t[ot]), t[ot] = null));
    try {
        Xd(t), kE(e.bindingStartIndex), n !== null && K0(e, t, n, 2, r);
        let u = (o & 3) === 3;
        if (!i)
            if (u) {
                let p = e.preOrderCheckHooks;
                p !== null && Dc(t, p, null)
            } else {
                let p = e.preOrderHooks;
                p !== null && _c(t, p, 0, null), xf(t, 0)
            }
        if (s || Rw(t), tv(t), rv(t, 0), e.contentQueries !== null && p0(e, t), !i)
            if (u) {
                let p = e.contentCheckHooks;
                p !== null && Dc(t, p)
            } else {
                let p = e.contentHooks;
                p !== null && _c(t, p, 1), xf(t, 1)
            }
        Pw(e, t);
        let d = e.components;
        d !== null && iv(t, d, 0);
        let f = e.viewQuery;
        if (f !== null && Uf(2, f, r), !i)
            if (u) {
                let p = e.viewCheckHooks;
                p !== null && Dc(t, p)
            } else {
                let p = e.viewHooks;
                p !== null && _c(t, p, 2), xf(t, 2)
            }
        if (e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[rc]) {
            for (let p of t[rc]) p();
            t[rc] = null
        }
        i || (Z0(t), t[N] &= -73)
    } catch (u) {
        throw i || Fr(t), u
    } finally {
        l !== null && (vr(l, c), a && Tw(l)), dc()
    }
}

function rv(e, t) {
    for (let n = o0(e); n !== null; n = i0(n))
        for (let r = se; r < n.length; r++) {
            let o = n[r];
            ov(o, t)
        }
}

function Rw(e) {
    for (let t = o0(e); t !== null; t = i0(t)) {
        if (!(t[N] & 2)) continue;
        let n = t[Lr];
        for (let r = 0; r < n.length; r++) {
            let o = n[r];
            ef(o)
        }
    }
}

function Ow(e, t, n) {
    q(H.ComponentStart);
    let r = gt(t, e);
    try {
        ov(r, n)
    } finally {
        q(H.ComponentEnd, r[ie])
    }
}

function ov(e, t) {
    ic(e) && Jf(e, t)
}

function Jf(e, t) {
    let r = e[b],
        o = e[N],
        i = e[ot],
        s = !!(t === 0 && o & 16);
    if (s || = !!(o & 64 && t === 0), s || = !!(o & 1024), s || = !!(i ? .dirty && Di(i)), s || = !1, i && (i.dirty = !1), e[N] &= -9217, s) Nw(r, e, r.template, e[ie]);
    else if (o & 8192) {
        let a = S(null);
        try {
            tv(e), rv(e, 1);
            let c = r.components;
            c !== null && iv(e, c, 1), Z0(e)
        } finally {
            S(a)
        }
    }
}

function iv(e, t, n) {
    for (let r = 0; r < t.length; r++) Ow(e, t[r], n)
}

function Pw(e, t) {
    let n = e.hostBindingOpCodes;
    if (n !== null) try {
        for (let r = 0; r < n.length; r++) {
            let o = n[r];
            if (o < 0) tr(~o);
            else {
                let i = o,
                    s = n[++r],
                    a = n[++r];
                UE(s, i);
                let c = t[i];
                q(H.HostBindingsUpdateStart, c);
                try {
                    a(2, c)
                } finally {
                    q(H.HostBindingsUpdateEnd, c)
                }
            }
        }
    } finally {
        tr(-1)
    }
}

function Hp(e, t) {
    let n = pf() ? 64 : 1088;
    for (e[Ot].changeDetectionScheduler ? .notify(t); e;) {
        e[N] |= n;
        let r = Jn(e);
        if (Mo(e) && !r) return e;
        e = r
    }
    return null
}

function sv(e, t, n, r) {
    return [e, !0, 0, t, null, r, null, n, null, null]
}

function av(e, t) {
    let n = se + t;
    if (n < e.length) return e[n]
}

function gs(e, t, n, r = !0) {
    let o = t[b];
    if (Lw(o, t, e, n), r) {
        let s = Yf(n, e),
            a = t[W],
            c = a.parentNode(e[er]);
        c !== null && Qb(o, e[je], a, t, c, s)
    }
    let i = t[Nr];
    i !== null && i.firstChild !== null && (i.firstChild = null)
}

function cv(e, t) {
    let n = ns(e, t);
    return n !== void 0 && il(n[b], n), n
}

function ns(e, t) {
    if (e.length <= se) return;
    let n = se + t,
        r = e[n];
    if (r) {
        let o = r[Xn];
        o !== null && o !== e && Lp(o, r), t > 0 && (e[n - 1][pt] = r[pt]);
        let i = Fi(e, se + t);
        Jb(r[b], r);
        let s = i[Zt];
        s !== null && s.detachView(i[b]), r[De] = null, r[pt] = null, r[N] &= -129
    }
    return r
}

function Lw(e, t, n, r) {
    let o = se + r,
        i = n.length;
    r > 0 && (n[o - 1][pt] = t), r < i - se ? (t[pt] = n[o], jd(n, se + r, t)) : (n.push(t), t[pt] = null), t[De] = n;
    let s = t[Xn];
    s !== null && n !== s && lv(s, t);
    let a = t[Zt];
    a !== null && a.insertView(e), sc(t), t[N] |= 128
}

function lv(e, t) {
    let n = e[Lr],
        r = t[De];
    if (Dn(r)) e[N] |= 2;
    else {
        let o = r[De][Pe];
        t[Pe] !== o && (e[N] |= 2)
    }
    n === null ? e[Lr] = [t] : n.push(t)
}
var nr = class {
    _lView;
    _cdRefInjectingView;
    _appRef = null;
    _attachedToViewContainer = !1;
    exhaustive;
    get rootNodes() {
        let t = this._lView,
            n = t[b];
        return ts(n, t, n.firstChild, [])
    }
    constructor(t, n) {
        this._lView = t, this._cdRefInjectingView = n
    }
    get context() {
        return this._lView[ie]
    }
    set context(t) {
        this._lView[ie] = t
    }
    get destroyed() {
        return kr(this._lView)
    }
    destroy() {
        if (this._appRef) this._appRef.detachView(this);
        else if (this._attachedToViewContainer) {
            let t = this._lView[De];
            if (Pt(t)) {
                let n = t[ji],
                    r = n ? n.indexOf(this) : -1;
                r > -1 && (ns(t, r), Fi(n, r))
            }
            this._attachedToViewContainer = !1
        }
        il(this._lView[b], this._lView)
    }
    onDestroy(t) {
        tf(this._lView, t)
    }
    markForCheck() {
        Hp(this._cdRefInjectingView || this._lView, 4)
    }
    detach() {
        this._lView[N] &= -129
    }
    reattach() {
        sc(this._lView), this._lView[N] |= 128
    }
    detectChanges() {
        this._lView[N] |= 1024, nv(this._lView)
    }
    checkNoChanges() {}
    attachToViewContainerRef() {
        if (this._appRef) throw new g(902, !1);
        this._attachedToViewContainer = !0
    }
    detachFromAppRef() {
        this._appRef = null;
        let t = Mo(this._lView),
            n = this._lView[Xn];
        n !== null && !t && Lp(n, this._lView), $0(this._lView[b], this._lView)
    }
    attachToAppRef(t) {
        if (this._attachedToViewContainer) throw new g(902, !1);
        this._appRef = t;
        let n = Mo(this._lView),
            r = this._lView[Xn];
        r !== null && !n && lv(r, this._lView), sc(this._lView)
    }
};
var nn = (() => {
    class e {
        _declarationLView;
        _declarationTContainer;
        elementRef;
        static __NG_ELEMENT_ID__ = kw;
        constructor(n, r, o) {
            this._declarationLView = n, this._declarationTContainer = r, this.elementRef = o
        }
        get ssrId() {
            return this._declarationTContainer.tView ? .ssrId || null
        }
        createEmbeddedView(n, r) {
            return this.createEmbeddedViewImpl(n, r)
        }
        createEmbeddedViewImpl(n, r, o) {
            let i = ms(this._declarationLView, this._declarationTContainer, n, {
                embeddedViewInjector: r,
                dehydratedView: o
            });
            return new nr(i)
        }
    }
    return e
})();

function kw() {
    return ul(he(), C())
}

function ul(e, t) {
    return e.type & 4 ? new nn(t, e, Vo(e, t)) : null
}

function Kr(e, t, n, r, o) {
    let i = e.data[t];
    if (i === null) i = Fw(e, t, n, r, o), FE() && (i.flags |= 32);
    else if (i.type & 64) {
        i.type = n, i.value = r, i.attrs = o;
        let s = LE();
        i.injectorIndex = s === null ? -1 : s.injectorIndex
    }
    return Ur(i, !0), i
}

function Fw(e, t, n, r, o) {
    let i = lf(),
        s = uf(),
        a = s ? i : i && i.parent,
        c = e.data[t] = Bw(e, a, n, t, r, o);
    return Uw(e, c, i, s), c
}

function Uw(e, t, n, r) {
    e.firstChild === null && (e.firstChild = t), n !== null && (r ? n.child == null && t.parent !== null && (n.child = t) : n.next === null && (n.next = t, t.prev = n))
}

function Bw(e, t, n, r, o, i) {
    let s = t ? t.injectorIndex : -1,
        a = 0;
    return sf() && (a |= 128), {
        type: n,
        index: r,
        insertBeforeIndex: null,
        injectorIndex: s,
        directiveStart: -1,
        directiveEnd: -1,
        directiveStylingLast: -1,
        componentOffset: -1,
        controlDirectiveIndex: -1,
        customControlIndex: -1,
        propertyBindings: null,
        flags: a,
        providerIndexes: 0,
        value: o,
        namespace: gf(),
        attrs: i,
        mergedAttrs: null,
        localNames: null,
        initialInputs: null,
        inputs: null,
        hostDirectiveInputs: null,
        outputs: null,
        hostDirectiveOutputs: null,
        directiveToIndex: null,
        tView: null,
        next: null,
        prev: null,
        projectionNext: null,
        child: null,
        parent: t,
        projection: null,
        styles: null,
        stylesWithoutHost: null,
        residualStyles: void 0,
        classes: null,
        classesWithoutHost: null,
        residualClasses: void 0,
        classBindings: 0,
        styleBindings: 0
    }
}

function jw(e) {
    let t = e[Yd] ? ? [],
        r = e[De][W],
        o = [];
    for (let i of t) i.data[l0] !== void 0 ? o.push(i) : Hw(i, r);
    e[Yd] = o
}

function Hw(e, t) {
    let n = 0,
        r = e.firstChild;
    if (r) {
        let o = e.data[c0];
        for (; n < o;) {
            let i = r.nextSibling;
            C0(t, r, !1), r = i, n++
        }
    }
}
var Vw = () => null,
    $w = () => null;

function Fc(e, t) {
    return Vw(e, t)
}

function uv(e, t, n) {
    return $w(e, t, n)
}
var dv = class {},
    dl = class {},
    Qf = class {
        resolveComponentFactory(t) {
            throw new g(917, !1)
        }
    },
    Es = class {
        static NULL = new Qf
    },
    Gr = class {},
    Tn = (() => {
        class e {
            destroyNode = null;
            static __NG_ELEMENT_ID__ = () => Gw()
        }
        return e
    })();

function Gw() {
    let e = C(),
        t = he(),
        n = gt(t.index, e);
    return (Dn(n) ? n : e)[W]
}
var fv = (() => {
    class e {
        static\ u0275prov = y({
            token: e,
            providedIn: "root",
            factory: () => null
        })
    }
    return e
})();
var Cc = {},
    Zf = class {
        injector;
        parentInjector;
        constructor(t, n) {
            this.injector = t, this.parentInjector = n
        }
        get(t, n, r) {
            let o = this.injector.get(t, Cc, r);
            return o !== Cc || n === Cc ? o : this.parentInjector.get(t, n, r)
        }
    };

function Uc(e, t, n) {
    let r = n ? e.styles : null,
        o = n ? e.classes : null,
        i = 0;
    if (t !== null)
        for (let s = 0; s < t.length; s++) {
            let a = t[s];
            if (typeof a == "number") i = a;
            else if (i == 1) o = Ja(o, a);
            else if (i == 2) {
                let c = a,
                    l = t[++s];
                r = Ja(r, c + ": " + l + ";")
            }
        }
    n ? e.styles = r : e.stylesWithoutHost = r, n ? e.classes = o : e.classesWithoutHost = o
}

function k(e, t = 0) {
    let n = C();
    if (n === null) return _(e, t);
    let r = he();
    return Zy(r, n, Se(e), t)
}

function Vp() {
    let e = "invalid";
    throw new Error(e)
}

function pv(e, t, n, r, o) {
    let i = r === null ? null : {
            "": -1
        },
        s = o(e, n);
    if (s !== null) {
        let a = s,
            c = null,
            l = null;
        for (let u of s)
            if (u.resolveHostDirectives !== null) {
                [a, c, l] = u.resolveHostDirectives(s);
                break
            }
        qw(e, t, n, a, i, c, l)
    }
    i !== null && r !== null && Ww(n, r, i)
}

function Ww(e, t, n) {
    let r = e.localNames = [];
    for (let o = 0; o < t.length; o += 2) {
        let i = n[t[o + 1]];
        if (i == null) throw new g(-301, !1);
        r.push(t[o], i)
    }
}

function zw(e, t, n) {
    t.componentOffset = n, (e.components ? ? = []).push(t.index)
}

function qw(e, t, n, r, o, i, s) {
    let a = r.length,
        c = null;
    for (let f = 0; f < a; f++) {
        let p = r[f];
        c === null && Xt(p) && (c = p, zw(e, n, f)), Pf(Mc(n, t), e, p.type)
    }
    Xw(n, e.data.length, a), c ? .viewProvidersResolver && c.viewProvidersResolver(c);
    for (let f = 0; f < a; f++) {
        let p = r[f];
        p.providersResolver && p.providersResolver(p)
    }
    let l = !1,
        u = !1,
        d = N0(e, t, a, null);
    a > 0 && (n.directiveToIndex = new Map);
    for (let f = 0; f < a; f++) {
        let p = r[f];
        if (n.mergedAttrs = ko(n.mergedAttrs, p.hostAttrs), Yw(e, n, t, d, p), Zw(d, p, o), s !== null && s.has(p)) {
            let [x, D] = s.get(p);
            n.directiveToIndex.set(p.type, [d, x + n.directiveStart, D + n.directiveStart])
        } else(i === null || !i.has(p)) && n.directiveToIndex.set(p.type, d);
        p.contentQueries !== null && (n.flags |= 4), (p.hostBindings !== null || p.hostAttrs !== null || p.hostVars !== 0) && (n.flags |= 64);
        let m = p.type.prototype;
        !l && (m.ngOnChanges || m.ngOnInit || m.ngDoCheck) && ((e.preOrderHooks ? ? = []).push(n.index), l = !0), !u && (m.ngOnChanges || m.ngDoCheck) && ((e.preOrderCheckHooks ? ? = []).push(n.index), u = !0), d++
    }
    Kw(e, n, i)
}

function Kw(e, t, n) {
    for (let r = t.directiveStart; r < t.directiveEnd; r++) {
        let o = e.data[r];
        if (n === null || !n.has(o)) _y(0, t, o, r), _y(1, t, o, r), Cy(t, r, !1);
        else {
            let i = n.get(o);
            xy(0, t, i, r), xy(1, t, i, r), Cy(t, r, !0)
        }
    }
}

function _y(e, t, n, r) {
    let o = e === 0 ? n.inputs : n.outputs;
    for (let i in o)
        if (o.hasOwnProperty(i)) {
            let s;
            e === 0 ? s = t.inputs ? ? = {} : s = t.outputs ? ? = {}, s[i] ? ? = [], s[i].push(r), hv(t, i)
        }
}

function xy(e, t, n, r) {
    let o = e === 0 ? n.inputs : n.outputs;
    for (let i in o)
        if (o.hasOwnProperty(i)) {
            let s = o[i],
                a;
            e === 0 ? a = t.hostDirectiveInputs ? ? = {} : a = t.hostDirectiveOutputs ? ? = {}, a[s] ? ? = [], a[s].push(r, i), hv(t, s)
        }
}

function hv(e, t) {
    t === "class" ? e.flags |= 8 : t === "style" && (e.flags |= 16)
}

function Cy(e, t, n) {
    let {
        attrs: r,
        inputs: o,
        hostDirectiveInputs: i
    } = e;
    if (r === null || !n && o === null || n && i === null || Ap(e)) {
        e.initialInputs ? ? = [], e.initialInputs.push(null);
        return
    }
    let s = null,
        a = 0;
    for (; a < r.length;) {
        let c = r[a];
        if (c === 0) {
            a += 4;
            continue
        } else if (c === 5) {
            a += 2;
            continue
        } else if (typeof c == "number") break;
        if (!n && o.hasOwnProperty(c)) {
            let l = o[c];
            for (let u of l)
                if (u === t) {
                    s ? ? = [], s.push(c, r[a + 1]);
                    break
                }
        } else if (n && i.hasOwnProperty(c)) {
            let l = i[c];
            for (let u = 0; u < l.length; u += 2)
                if (l[u] === t) {
                    s ? ? = [], s.push(l[u + 1], r[a + 1]);
                    break
                }
        }
        a += 2
    }
    e.initialInputs ? ? = [], e.initialInputs.push(s)
}

function Yw(e, t, n, r, o) {
    e.data[r] = o;
    let i = o.factory || (o.factory = Kn(o.type, !0)),
        s = new Vr(i, Xt(o), k, null);
    e.blueprint[r] = s, n[r] = s, Jw(e, t, r, N0(e, n, o.hostVars, ce), o)
}

function Jw(e, t, n, r, o) {
    let i = o.hostBindings;
    if (i) {
        let s = e.hostBindingOpCodes;
        s === null && (s = e.hostBindingOpCodes = []);
        let a = ~t.index;
        Qw(s) != a && s.push(a), s.push(n, r, i)
    }
}

function Qw(e) {
    let t = e.length;
    for (; t > 0;) {
        let n = e[--t];
        if (typeof n == "number" && n < 0) return n
    }
    return 0
}

function Zw(e, t, n) {
    if (n) {
        if (t.exportAs)
            for (let r = 0; r < t.exportAs.length; r++) n[t.exportAs[r]] = e;
        Xt(t) && (n[""] = e)
    }
}

function Xw(e, t, n) {
    e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + n, e.providerIndexes = t
}

function $p(e, t, n, r, o, i, s, a) {
    let c = t[b],
        l = c.consts,
        u = Et(l, s),
        d = Kr(c, e, n, r, u);
    return i && pv(c, t, d, Et(l, a), o), d.mergedAttrs = ko(d.mergedAttrs, d.attrs), d.attrs !== null && Uc(d, d.attrs, !1), d.mergedAttrs !== null && Uc(d, d.mergedAttrs, !0), c.queries !== null && c.queries.elementStart(c, d), d
}

function Gp(e, t) {
    $y(e, t), Jd(t) && e.queries.elementEnd(t)
}

function mv(e, t, n, r, o, i) {
    let s = t.consts,
        a = Et(s, o),
        c = Kr(t, e, n, r, a);
    if (c.mergedAttrs = ko(c.mergedAttrs, c.attrs), i != null) {
        let l = Et(s, i);
        c.localNames = [];
        for (let u = 0; u < l.length; u += 2) c.localNames.push(l[u], -1)
    }
    return c.attrs !== null && Uc(c, c.attrs, !1), c.mergedAttrs !== null && Uc(c, c.mergedAttrs, !0), t.queries !== null && t.queries.elementStart(t, c), c
}

function Wp(e) {
    return fl(e) ? Array.isArray(e) || !(e instanceof Map) && Symbol.iterator in e : !1
}

function gv(e, t) {
    if (Array.isArray(e))
        for (let n = 0; n < e.length; n++) t(e[n]);
    else {
        let n = e[Symbol.iterator](),
            r;
        for (; !(r = n.next()).done;) t(r.value)
    }
}

function fl(e) {
    return e !== null && (typeof e == "function" || typeof e == "object")
}

function or(e, t, n) {
    return e[t] = n
}

function zp(e, t) {
    return e[t]
}

function Le(e, t, n) {
    if (n === ce) return !1;
    let r = e[t];
    return Object.is(r, n) ? !1 : (e[t] = n, !0)
}

function Wr(e, t, n, r) {
    let o = Le(e, t, n);
    return Le(e, t + 1, r) || o
}

function Ev(e, t, n, r, o) {
    let i = Wr(e, t, n, r);
    return Le(e, t + 2, o) || i
}

function ys(e, t, n, r, o, i) {
    let s = Wr(e, t, n, r);
    return Wr(e, t + 2, o, i) || s
}

function Ic(e, t, n) {
    return function r(o) {
        let i = r.__ngNativeEl__;
        i !== void 0 && kS(o, i);
        let s = _n(e) ? gt(e.index, t) : t;
        Hp(s, 5);
        let a = t[ie],
            c = Iy(t, a, n, o),
            l = r.__ngNextListenerFn__;
        for (; l;) c = Iy(t, a, l, o) && c, l = l.__ngNextListenerFn__;
        return c
    }
}

function Iy(e, t, n, r) {
    let o = S(null);
    try {
        return q(H.OutputStart, t, n), n(r) !== !1
    } catch (i) {
        return vw(e, i), !1
    } finally {
        q(H.OutputEnd, t, n), S(o)
    }
}

function yv(e, t, n, r, o, i, s, a) {
    let c = Ao(e),
        l = !1,
        u = null;
    if (!r && c && (u = tA(t, n, i, e.index)), u !== null) {
        let d = u.__ngLastListenerFn__ || u;
        d.__ngNextListenerFn__ = s, u.__ngLastListenerFn__ = s, l = !0
    } else {
        let d = mt(e, n),
            f = r ? r(d) : d;
        US(n, f, i, a), r || (a.__ngNativeEl__ = d);
        let p = o.listen(f, i, a);
        if (!eA(i)) {
            let m = r ? x => r(ht(x[e.index])) : e.index;
            vv(m, t, n, i, a, p, !1)
        }
    }
    return l
}

function eA(e) {
    return e.startsWith("animation") || e.startsWith("transition")
}

function tA(e, t, n, r) {
    let o = e.cleanup;
    if (o != null)
        for (let i = 0; i < o.length - 1; i += 2) {
            let s = o[i];
            if (s === n && o[i + 1] === r) {
                let a = t[bo],
                    c = o[i + 2];
                return a && a.length > c ? a[c] : null
            }
            typeof s == "string" && (i += 2)
        }
    return null
}

function vv(e, t, n, r, o, i, s) {
    let a = t.firstCreatePass ? rf(t) : null,
        c = nf(n),
        l = c.length;
    c.push(o, i), a && a.push(r, e, l, (l + 1) * (s ? -1 : 1))
}

function Ty(e, t, n, r, o, i) {
    let s = t[n],
        a = t[b],
        l = a.data[n].outputs[r],
        d = s[l].subscribe(i);
    vv(e.index, a, t, o, i, d, !0)
}
var Xf = Symbol("BINDING");

function Dv(e) {
    return e.debugInfo ? .className || e.type.name || null
}
var Bc = class extends Es {
    ngModule;
    constructor(t) {
        super(), this.ngModule = t
    }
    resolveComponentFactory(t) {
        let n = Qt(t);
        return new rr(n, this.ngModule)
    }
};

function nA(e) {
    return Object.keys(e).map(t => {
        let [n, r, o] = e[t], i = {
            propName: n,
            templateName: t,
            isSignal: (r & nl.SignalBased) !== 0
        };
        return o && (i.transform = o), i
    })
}

function rA(e) {
    return Object.keys(e).map(t => ({
        propName: e[t],
        templateName: t
    }))
}

function oA(e, t, n) {
    let r = t instanceof re ? t : t ? .injector;
    return r && e.getStandaloneInjector !== null && (r = e.getStandaloneInjector(r) || r), r ? new Zf(n, r) : n
}

function iA(e) {
    let t = e.get(Gr, null);
    if (t === null) throw new g(407, !1);
    let n = e.get(fv, null),
        r = e.get(Jt, null),
        o = e.get(sn, null, {
            optional: !0
        });
    return {
        rendererFactory: t,
        sanitizer: n,
        changeDetectionScheduler: r,
        ngReflect: !1,
        tracingService: o
    }
}

function sA(e, t) {
    let n = _v(e);
    return _0(t, n, n === "svg" ? Qd : n === "math" ? TE : null)
}

function _v(e) {
    return (e.selectors[0][0] || "div").toLowerCase()
}
var rr = class extends dl {
    componentDef;
    ngModule;
    selector;
    componentType;
    ngContentSelectors;
    isBoundToModule;
    cachedInputs = null;
    cachedOutputs = null;
    get inputs() {
        return this.cachedInputs ? ? = nA(this.componentDef.inputs), this.cachedInputs
    }
    get outputs() {
        return this.cachedOutputs ? ? = rA(this.componentDef.outputs), this.cachedOutputs
    }
    constructor(t, n) {
        super(), this.componentDef = t, this.ngModule = n, this.componentType = t.type, this.selector = Sb(t.selectors), this.ngContentSelectors = t.ngContentSelectors ? ? [], this.isBoundToModule = !!n
    }
    create(t, n, r, o, i, s) {
        q(H.DynamicComponentStart);
        let a = S(null);
        try {
            let c = this.componentDef,
                l = oA(c, o || this.ngModule, t),
                u = iA(l),
                d = u.tracingService;
            return d && d.componentCreate ? d.componentCreate(Dv(c), () => this.createComponentRef(u, l, n, r, i, s)) : this.createComponentRef(u, l, n, r, i, s)
        } finally {
            S(a)
        }
    }
    createComponentRef(t, n, r, o, i, s) {
        let a = this.componentDef,
            c = aA(o, a, s, i),
            l = t.rendererFactory.createRenderer(null, a),
            u = o ? cw(l, o, a.encapsulation, n) : sA(a, l),
            d = s ? .some(Sy) || i ? .some(m => typeof m != "function" && m.bindings.some(Sy)),
            f = Np(null, c, null, 512 | M0(a), null, null, t, l, n, null, f0(u, n, !0));
        f[z] = u, uc(f);
        let p = null;
        try {
            let m = $p(z, f, 2, "#host", () => c.directiveRegistry, !0, 0);
            I0(l, u, m), Fo(u, f), al(c, f, m), _p(c, m, f), Gp(c, m), r !== void 0 && lA(m, this.ngContentSelectors, r), p = gt(m.index, f), f[ie] = p[ie], jp(c, f, null)
        } catch (m) {
            throw p !== null && kf(p), kf(f), m
        } finally {
            q(H.DynamicComponentEnd), dc()
        }
        return new jc(this.componentType, f, !!d)
    }
};

function aA(e, t, n, r) {
    let o = e ? ["ng-version", "21.2.14"] : bb(t.selectors[0]),
        i = null,
        s = null,
        a = 0;
    if (n)
        for (let u of n) a += u[Xf].requiredVars, u.create && (u.targetIdx = 0, (i ? ? = []).push(u)), u.update && (u.targetIdx = 0, (s ? ? = []).push(u));
    if (r)
        for (let u = 0; u < r.length; u++) {
            let d = r[u];
            if (typeof d != "function")
                for (let f of d.bindings) {
                    a += f[Xf].requiredVars;
                    let p = u + 1;
                    f.create && (f.targetIdx = p, (i ? ? = []).push(f)), f.update && (f.targetIdx = p, (s ? ? = []).push(f))
                }
        }
    let c = [t];
    if (r)
        for (let u of r) {
            let d = typeof u == "function" ? u : u.type,
                f = kd(d);
            c.push(f)
        }
    return Mp(0, null, cA(i, s), 1, a, c, null, null, null, [o], null)
}

function cA(e, t) {
    return !e && !t ? null : n => {
        if (n & 1 && e)
            for (let r of e) r.create();
        if (n & 2 && t)
            for (let r of t) r.update()
    }
}

function Sy(e) {
    let t = e[Xf].kind;
    return t === "input" || t === "twoWay"
}
var jc = class extends dv {
    _rootLView;
    _hasInputBindings;
    instance;
    hostView;
    changeDetectorRef;
    componentType;
    location;
    previousInputValues = null;
    _tNode;
    constructor(t, n, r) {
        super(), this._rootLView = n, this._hasInputBindings = r, this._tNode = oc(n[b], z), this.location = Vo(this._tNode, n), this.instance = gt(this._tNode.index, n)[ie], this.hostView = this.changeDetectorRef = new nr(n, void 0), this.componentType = t
    }
    setInput(t, n) {
        this._hasInputBindings;
        let r = this._tNode;
        if (this.previousInputValues ? ? = new Map, this.previousInputValues.has(t) && Object.is(this.previousInputValues.get(t), n)) return;
        let o = this._rootLView,
            i = Bp(r, o[b], o, t, n);
        this.previousInputValues.set(t, n);
        let s = gt(r.index, o);
        Hp(s, 1)
    }
    get injector() {
        return new Hr(this._tNode, this._rootLView)
    }
    destroy() {
        this.hostView.destroy()
    }
    onDestroy(t) {
        this.hostView.onDestroy(t)
    }
};

function lA(e, t, n) {
    let r = e.projection = [];
    for (let o = 0; o < t.length; o++) {
        let i = n[o];
        r.push(i != null && i.length ? Array.from(i) : null)
    }
}
var Dt = (() => {
    class e {
        static __NG_ELEMENT_ID__ = uA
    }
    return e
})();

function uA() {
    let e = he();
    return xv(e, C())
}
var ep = class e extends Dt {
    _lContainer;
    _hostTNode;
    _hostLView;
    constructor(t, n, r) {
        super(), this._lContainer = t, this._hostTNode = n, this._hostLView = r
    }
    get element() {
        return Vo(this._hostTNode, this._hostLView)
    }
    get injector() {
        return new Hr(this._hostTNode, this._hostLView)
    }
    get parentInjector() {
        let t = Ep(this._hostTNode, this._hostLView);
        if (zy(t)) {
            let n = wc(t, this._hostLView),
                r = bc(t),
                o = n[b].data[r + 8];
            return new Hr(o, n)
        } else return new Hr(null, this._hostLView)
    }
    clear() {
        for (; this.length > 0;) this.remove(this.length - 1)
    }
    get(t) {
        let n = by(this._lContainer);
        return n !== null && n[t] || null
    }
    get length() {
        return this._lContainer.length - se
    }
    createEmbeddedView(t, n, r) {
        let o, i;
        typeof r == "number" ? o = r : r != null && (o = r.index, i = r.injector);
        let s = Fc(this._lContainer, t.ssrId),
            a = t.createEmbeddedViewImpl(n || {}, i, s);
        return this.insertImpl(a, o, Uo(this._hostTNode, s)), a
    }
    createComponent(t, n, r, o, i, s, a) {
        let c = t && !cS(t),
            l;
        if (c) l = n;
        else {
            let D = n || {};
            l = D.index, r = D.injector, o = D.projectableNodes, i = D.environmentInjector || D.ngModuleRef, s = D.directives, a = D.bindings
        }
        let u = c ? t : new rr(Qt(t)),
            d = r || this.parentInjector;
        if (!i && u.ngModule == null) {
            let I = (c ? d : this.parentInjector).get(re, null);
            I && (i = I)
        }
        let f = Qt(u.componentType ? ? {}),
            p = Fc(this._lContainer, f ? .id ? ? null),
            m = p ? .firstChild ? ? null,
            x = u.create(d, o, m, i, s, a);
        return this.insertImpl(x.hostView, l, Uo(this._hostTNode, p)), x
    }
    insert(t, n) {
        return this.insertImpl(t, n, !0)
    }
    insertImpl(t, n, r) {
        let o = t._lView;
        if (bE(o)) {
            let a = this.indexOf(t);
            if (a !== -1) this.detach(a);
            else {
                let c = o[De],
                    l = new e(c, c[je], c[De]);
                l.detach(l.indexOf(t))
            }
        }
        let i = this._adjustIndex(n),
            s = this._lContainer;
        return gs(s, o, i, r), t.attachToViewContainerRef(), jd(Tf(s), i, t), t
    }
    move(t, n) {
        return this.insert(t, n)
    }
    indexOf(t) {
        let n = by(this._lContainer);
        return n !== null ? n.indexOf(t) : -1
    }
    remove(t) {
        let n = this._adjustIndex(t, -1),
            r = ns(this._lContainer, n);
        r && (Fi(Tf(this._lContainer), n), il(r[b], r))
    }
    detach(t) {
        let n = this._adjustIndex(t, -1),
            r = ns(this._lContainer, n);
        return r && Fi(Tf(this._lContainer), n) != null ? new nr(r) : null
    }
    _adjustIndex(t, n = 0) {
        return t ? ? this.length + n
    }
};

function by(e) {
    return e[ji]
}

function Tf(e) {
    return e[ji] || (e[ji] = [])
}

function xv(e, t) {
    let n, r = t[e.index];
    return Pt(r) ? n = r : (n = sv(r, t, null, e), t[e.index] = n, Rp(t, n)), fA(n, t, e, r), new ep(n, e, t)
}

function dA(e, t) {
    let n = e[W],
        r = n.createComment(""),
        o = mt(t, e),
        i = n.parentNode(o);
    return Rc(n, i, r, n.nextSibling(o), !1), r
}
var fA = mA,
    pA = () => !1;

function hA(e, t, n) {
    return pA(e, t, n)
}

function mA(e, t, n, r) {
    if (e[er]) return;
    let o;
    n.type & 8 ? o = ht(r) : o = dA(t, n), e[er] = o
}
var tp = class e {
        queryList;
        matches = null;
        constructor(t) {
            this.queryList = t
        }
        clone() {
            return new e(this.queryList)
        }
        setDirty() {
            this.queryList.setDirty()
        }
    },
    np = class e {
        queries;
        constructor(t = []) {
            this.queries = t
        }
        createEmbeddedView(t) {
            let n = t.queries;
            if (n !== null) {
                let r = t.contentQueries !== null ? t.contentQueries[0] : n.length,
                    o = [];
                for (let i = 0; i < r; i++) {
                    let s = n.getByIndex(i),
                        a = this.queries[s.indexInDeclarationView];
                    o.push(a.clone())
                }
                return new e(o)
            }
            return null
        }
        insertView(t) {
            this.dirtyQueriesWithMatches(t)
        }
        detachView(t) {
            this.dirtyQueriesWithMatches(t)
        }
        finishViewCreation(t) {
            this.dirtyQueriesWithMatches(t)
        }
        dirtyQueriesWithMatches(t) {
            for (let n = 0; n < this.queries.length; n++) Kp(t, n).matches !== null && this.queries[n].setDirty()
        }
    },
    Hc = class {
        flags;
        read;
        predicate;
        constructor(t, n, r = null) {
            this.flags = n, this.read = r, typeof t == "string" ? this.predicate = _A(t) : this.predicate = t
        }
    },
    rp = class e {
        queries;
        constructor(t = []) {
            this.queries = t
        }
        elementStart(t, n) {
            for (let r = 0; r < this.queries.length; r++) this.queries[r].elementStart(t, n)
        }
        elementEnd(t) {
            for (let n = 0; n < this.queries.length; n++) this.queries[n].elementEnd(t)
        }
        embeddedTView(t) {
            let n = null;
            for (let r = 0; r < this.length; r++) {
                let o = n !== null ? n.length : 0,
                    i = this.getByIndex(r).embeddedTView(t, o);
                i && (i.indexInDeclarationView = r, n !== null ? n.push(i) : n = [i])
            }
            return n !== null ? new e(n) : null
        }
        template(t, n) {
            for (let r = 0; r < this.queries.length; r++) this.queries[r].template(t, n)
        }
        getByIndex(t) {
            return this.queries[t]
        }
        get length() {
            return this.queries.length
        }
        track(t) {
            this.queries.push(t)
        }
    },
    op = class e {
        metadata;
        matches = null;
        indexInDeclarationView = -1;
        crossesNgTemplate = !1;
        _declarationNodeIndex;
        _appliesToNextNode = !0;
        constructor(t, n = -1) {
            this.metadata = t, this._declarationNodeIndex = n
        }
        elementStart(t, n) {
            this.isApplyingToNode(n) && this.matchTNode(t, n)
        }
        elementEnd(t) {
            this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1)
        }
        template(t, n) {
            this.elementStart(t, n)
        }
        embeddedTView(t, n) {
            return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, n), new e(this.metadata)) : null
        }
        isApplyingToNode(t) {
            if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
                let n = this._declarationNodeIndex,
                    r = t.parent;
                for (; r !== null && r.type & 8 && r.index !== n;) r = r.parent;
                return n === (r !== null ? r.index : -1)
            }
            return this._appliesToNextNode
        }
        matchTNode(t, n) {
            let r = this.metadata.predicate;
            if (Array.isArray(r))
                for (let o = 0; o < r.length; o++) {
                    let i = r[o];
                    this.matchTNodeWithReadOption(t, n, gA(n, i)), this.matchTNodeWithReadOption(t, n, xc(n, t, i, !1, !1))
                } else r === nn ? n.type & 4 && this.matchTNodeWithReadOption(t, n, -1) : this.matchTNodeWithReadOption(t, n, xc(n, t, r, !1, !1))
        }
        matchTNodeWithReadOption(t, n, r) {
            if (r !== null) {
                let o = this.metadata.read;
                if (o !== null)
                    if (o === it || o === Dt || o === nn && n.type & 4) this.addMatch(n.index, -2);
                    else {
                        let i = xc(n, t, o, !1, !1);
                        i !== null && this.addMatch(n.index, i)
                    }
                else this.addMatch(n.index, r)
            }
        }
        addMatch(t, n) {
            this.matches === null ? this.matches = [t, n] : this.matches.push(t, n)
        }
    };

function gA(e, t) {
    let n = e.localNames;
    if (n !== null) {
        for (let r = 0; r < n.length; r += 2)
            if (n[r] === t) return n[r + 1]
    }
    return null
}

function EA(e, t) {
    return e.type & 11 ? Vo(e, t) : e.type & 4 ? ul(e, t) : null
}

function yA(e, t, n, r) {
    return n === -1 ? EA(t, e) : n === -2 ? vA(e, t, r) : Xi(e, e[b], n, t)
}

function vA(e, t, n) {
    if (n === it) return Vo(t, e);
    if (n === nn) return ul(t, e);
    if (n === Dt) return xv(t, e)
}

function Cv(e, t, n, r) {
    let o = t[Zt].queries[r];
    if (o.matches === null) {
        let i = e.data,
            s = n.matches,
            a = [];
        for (let c = 0; s !== null && c < s.length; c += 2) {
            let l = s[c];
            if (l < 0) a.push(null);
            else {
                let u = i[l];
                a.push(yA(t, u, s[c + 1], n.metadata.read))
            }
        }
        o.matches = a
    }
    return o.matches
}

function ip(e, t, n, r) {
    let o = e.queries.getByIndex(n),
        i = o.matches;
    if (i !== null) {
        let s = Cv(e, t, o, n);
        for (let a = 0; a < i.length; a += 2) {
            let c = i[a];
            if (c > 0) r.push(s[a / 2]);
            else {
                let l = i[a + 1],
                    u = t[-c];
                for (let d = se; d < u.length; d++) {
                    let f = u[d];
                    f[Xn] === f[De] && ip(f[b], f, l, r)
                }
                if (u[Lr] !== null) {
                    let d = u[Lr];
                    for (let f = 0; f < d.length; f++) {
                        let p = d[f];
                        ip(p[b], p, l, r)
                    }
                }
            }
        }
    }
    return r
}

function qp(e, t) {
    return e[Zt].queries[t].queryList
}

function Iv(e, t, n) {
    let r = new Nc((n & 4) === 4);
    return ME(e, t, r, r.destroy), (t[Zt] ? ? = new np).queries.push(new tp(r)) - 1
}

function Tv(e, t, n) {
    let r = Y();
    return r.firstCreatePass && (Sv(r, new Hc(e, t, n), -1), (t & 2) === 2 && (r.staticViewQueries = !0)), Iv(r, C(), t)
}

function DA(e, t, n, r) {
    let o = Y();
    if (o.firstCreatePass) {
        let i = he();
        Sv(o, new Hc(t, n, r), i.index), xA(o, e), (n & 2) === 2 && (o.staticContentQueries = !0)
    }
    return Iv(o, C(), n)
}

function _A(e) {
    return e.split(",").map(t => t.trim())
}

function Sv(e, t, n) {
    e.queries === null && (e.queries = new rp), e.queries.track(new op(t, n))
}

function xA(e, t) {
    let n = e.contentQueries || (e.contentQueries = []),
        r = n.length ? n[n.length - 1] : -1;
    t !== r && n.push(e.queries.length - 1, t)
}

function Kp(e, t) {
    return e.queries.getByIndex(t)
}

function bv(e, t) {
    let n = e[b],
        r = Kp(n, t);
    return r.crossesNgTemplate ? ip(n, e, t, []) : Cv(n, e, r, t)
}

function Yp(e, t, n) {
    let r, o = Ci(() => {
        r._dirtyCounter();
        let i = IA(r, e);
        if (t && i === void 0) throw new g(-951, !1);
        return i
    });
    return r = o[ue], r._dirtyCounter = ae(0), r._flatValue = void 0, o
}

function wv(e) {
    return Yp(!0, !1, e)
}

function Av(e) {
    return Yp(!0, !0, e)
}

function Mv(e) {
    return Yp(!1, !1, e)
}

function CA(e, t) {
    let n = e[ue];
    n._lView = C(), n._queryIndex = t, n._queryList = qp(n._lView, t), n._queryList.onDirty(() => n._dirtyCounter.update(r => r + 1))
}

function IA(e, t) {
    let n = e._lView,
        r = e._queryIndex;
    if (n === void 0 || r === void 0 || n[N] & 4) return t ? void 0 : Oe;
    let o = qp(n, r),
        i = bv(n, r);
    return o.reset(i, t0), t ? o.first : o._changesDetected || e._flatValue === void 0 ? e._flatValue = o.toArray() : e._flatValue
}
var sp = new Map,
    TA = new Set;

function Jp(e) {
    return G(this, null, function*() {
        let t = sp;
        sp = new Map;
        let n = new Map;

        function r(i) {
            let s = n.get(i);
            if (s) return s;
            let a = e(i).then(c => SA(i, c));
            return n.set(i, a), a
        }
        let o = Array.from(t).map(a => G(null, [a], function*([i, s]) {
            if (s.styleUrl && s.styleUrls ? .length) throw new Error("@Component cannot define both `styleUrl` and `styleUrls`. Use `styleUrl` if the component has one stylesheet, or `styleUrls` if it has multiple");
            let c = [];
            s.templateUrl && c.push(r(s.templateUrl).then(f => {
                s.template = f
            }));
            let l = typeof s.styles == "string" ? [s.styles] : s.styles ? ? [];
            s.styles = l;
            let {
                styleUrl: u,
                styleUrls: d
            } = s;
            if (u && (d = [u], s.styleUrl = void 0), d ? .length) {
                let f = Promise.all(d.map(p => r(p))).then(p => {
                    l.push(...p), s.styleUrls = void 0
                });
                c.push(f)
            }
            yield Promise.all(c), TA.delete(i)
        }));
        yield Promise.all(o)
    })
}

function Nv() {
    return sp.size === 0
}

function SA(e, t) {
    return G(this, null, function*() {
        if (typeof t == "string") return t;
        if (t.status !== void 0 && t.status !== 200) throw new g(918, !1);
        return t.text()
    })
}
var zr = class {},
    pl = class {};

function Rv(e, t) {
    return new Bo(e, t ? ? null, [])
}
var Bo = class extends zr {
        ngModuleType;
        _parent;
        _bootstrapComponents = [];
        _r3Injector;
        instance;
        destroyCbs = [];
        componentFactoryResolver = new Bc(this);
        constructor(t, n, r, o = !0) {
            super(), this.ngModuleType = t, this._parent = n;
            let i = Ld(t);
            this._bootstrapComponents = b0(i.bootstrap), this._r3Injector = Ef(t, n, [{
                provide: zr,
                useValue: this
            }, {
                provide: Es,
                useValue: this.componentFactoryResolver
            }, ...r], Li(t), new Set(["environment"])), o && this.resolveInjectorInitializers()
        }
        resolveInjectorInitializers() {
            this._r3Injector.resolveInjectorInitializers(), this.instance = this._r3Injector.get(this.ngModuleType)
        }
        get injector() {
            return this._r3Injector
        }
        destroy() {
            let t = this._r3Injector;
            !t.destroyed && t.destroy(), this.destroyCbs.forEach(n => n()), this.destroyCbs = null
        }
        onDestroy(t) {
            this.destroyCbs.push(t)
        }
    },
    rs = class extends pl {
        moduleType;
        constructor(t) {
            super(), this.moduleType = t
        }
        create(t) {
            return new Bo(this.moduleType, t, [])
        }
    };

function Ov(e, t, n) {
    return new Bo(e, t, n, !1)
}
var Vc = class extends zr {
    injector;
    componentFactoryResolver = new Bc(this);
    instance = null;
    constructor(t) {
        super();
        let n = new Ar([...t.providers, {
            provide: zr,
            useValue: this
        }, {
            provide: Es,
            useValue: this.componentFactoryResolver
        }], t.parent || So(), t.debugName, new Set(["environment"]));
        this.injector = n, t.runEnvironmentInitializers && n.resolveInjectorInitializers()
    }
    destroy() {
        this.injector.destroy()
    }
    onDestroy(t) {
        this.injector.onDestroy(t)
    }
};

function Go(e, t, n = null) {
    return new Vc({
        providers: e,
        parent: t,
        debugName: n,
        runEnvironmentInitializers: !0
    }).injector
}
var bA = (() => {
    class e {
        _injector;
        cachedInjectors = new Map;
        constructor(n) {
            this._injector = n
        }
        getOrCreateStandaloneInjector(n) {
            if (!n.standalone) return null;
            if (!this.cachedInjectors.has(n)) {
                let r = $d(!1, n.type),
                    o = r.length > 0 ? Go([r], this._injector, "") : null;
                this.cachedInjectors.set(n, o)
            }
            return this.cachedInjectors.get(n)
        }
        ngOnDestroy() {
            try {
                for (let n of this.cachedInjectors.values()) n !== null && n.destroy()
            } finally {
                this.cachedInjectors.clear()
            }
        }
        static\ u0275prov = y({
            token: e,
            providedIn: "environment",
            factory: () => new e(_(re))
        })
    }
    return e
})();

function Qp(e) {
    return ss(() => {
        let t = Lv(e),
            n = B(E({}, t), {
                decls: e.decls,
                vars: e.vars,
                template: e.template,
                consts: e.consts || null,
                ngContentSelectors: e.ngContentSelectors,
                onPush: e.changeDetection === yp.OnPush,
                directiveDefs: null,
                pipeDefs: null,
                dependencies: t.standalone && e.dependencies || null,
                getStandaloneInjector: t.standalone ? o => o.get(bA).getOrCreateStandaloneInjector(n) : null,
                getExternalStyles: null,
                signals: e.signals ? ? !1,
                data: e.data || {},
                encapsulation: e.encapsulation || kt.Emulated,
                styles: e.styles || Oe,
                _: null,
                schemas: e.schemas || null,
                tView: null,
                id: ""
            });
        t.standalone && Ye("NgStandalone"), kv(n);
        let r = e.dependencies;
        return n.directiveDefs = $c(r, Pv), n.pipeDefs = $c(r, Fd), n.id = MA(n), n
    })
}

function Pv(e) {
    return Qt(e) || kd(e)
}

function Ut(e) {
    return ss(() => ({
        type: e.type,
        bootstrap: e.bootstrap || Oe,
        declarations: e.declarations || Oe,
        imports: e.imports || Oe,
        exports: e.exports || Oe,
        transitiveCompileScopes: null,
        schemas: e.schemas || null,
        id: e.id || null
    }))
}

function wA(e, t) {
    if (e == null) return Qn;
    let n = {};
    for (let r in e)
        if (e.hasOwnProperty(r)) {
            let o = e[r],
                i, s, a, c;
            Array.isArray(o) ? (a = o[0], i = o[1], s = o[2] ? ? i, c = o[3] || null) : (i = o, s = o, a = nl.None, c = null), n[i] = [r, a, c], t[i] = s
        }
    return n
}

function AA(e) {
    if (e == null) return Qn;
    let t = {};
    for (let n in e) e.hasOwnProperty(n) && (t[e[n]] = n);
    return t
}

function be(e) {
    return ss(() => {
        let t = Lv(e);
        return kv(t), t
    })
}

function Sn(e) {
    return {
        type: e.type,
        name: e.name,
        factory: null,
        pure: e.pure !== !1,
        standalone: e.standalone ? ? !0,
        onDestroy: e.type.prototype.ngOnDestroy || null
    }
}

function Lv(e) {
    let t = {};
    return {
        type: e.type,
        providersResolver: null,
        viewProvidersResolver: null,
        factory: null,
        hostBindings: e.hostBindings || null,
        hostVars: e.hostVars || 0,
        hostAttrs: e.hostAttrs || null,
        contentQueries: e.contentQueries || null,
        declaredInputs: t,
        inputConfig: e.inputs || Qn,
        exportAs: e.exportAs || null,
        standalone: e.standalone ? ? !0,
        signals: e.signals === !0,
        selectors: e.selectors || Oe,
        viewQuery: e.viewQuery || null,
        features: e.features || null,
        setInput: null,
        resolveHostDirectives: null,
        hostDirectives: null,
        controlDef: null,
        inputs: wA(e.inputs, t),
        outputs: AA(e.outputs),
        debugInfo: null
    }
}

function kv(e) {
    e.features ? .forEach(t => t(e))
}

function $c(e, t) {
    return e ? () => {
        let n = typeof e == "function" ? e() : e,
            r = [];
        for (let o of n) {
            let i = t(o);
            i !== null && r.push(i)
        }
        return r
    } : null
}

function MA(e) {
    let t = 0,
        n = typeof e.consts == "function" ? "" : e.consts,
        r = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, n, e.vars, e.decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON.stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e.viewQuery];
    for (let i of r.join("|")) t = Math.imul(31, t) + i.charCodeAt(0) << 0;
    return t += 2147483648, "c" + t
}

function NA(e) {
    return Object.getPrototypeOf(e.prototype).constructor
}

function Fv(e) {
    let t = NA(e.type),
        n = !0,
        r = [e];
    for (; t;) {
        let o;
        if (Xt(e)) o = t.\u0275cmp || t.\u0275dir;
        else {
            if (t.\u0275cmp) throw new g(903, !1);
            o = t.\u0275dir
        }
        if (o) {
            if (n) {
                r.push(o);
                let s = e;
                s.inputs = Sf(e.inputs), s.declaredInputs = Sf(e.declaredInputs), s.outputs = Sf(e.outputs);
                let a = o.hostBindings;
                a && kA(e, a);
                let c = o.viewQuery,
                    l = o.contentQueries;
                if (c && PA(e, c), l && LA(e, l), RA(e, o), fE(e.outputs, o.outputs), Xt(o) && o.data.animation) {
                    let u = e.data;
                    u.animation = (u.animation || []).concat(o.data.animation)
                }
            }
            let i = o.features;
            if (i)
                for (let s = 0; s < i.length; s++) {
                    let a = i[s];
                    a && a.ngInherit && a(e), a === Fv && (n = !1)
                }
        }
        t = Object.getPrototypeOf(t)
    }
    OA(r)
}

function RA(e, t) {
    for (let n in t.inputs) {
        if (!t.inputs.hasOwnProperty(n) || e.inputs.hasOwnProperty(n)) continue;
        let r = t.inputs[n];
        r !== void 0 && (e.inputs[n] = r, e.declaredInputs[n] = t.declaredInputs[n])
    }
}

function OA(e) {
    let t = 0,
        n = null;
    for (let r = e.length - 1; r >= 0; r--) {
        let o = e[r];
        o.hostVars = t += o.hostVars, o.hostAttrs = ko(o.hostAttrs, n = ko(n, o.hostAttrs))
    }
}

function Sf(e) {
    return e === Qn ? {} : e === Oe ? [] : e
}

function PA(e, t) {
    let n = e.viewQuery;
    n ? e.viewQuery = (r, o) => {
        t(r, o), n(r, o)
    } : e.viewQuery = t
}

function LA(e, t) {
    let n = e.contentQueries;
    n ? e.contentQueries = (r, o, i) => {
        t(r, o, i), n(r, o, i)
    } : e.contentQueries = t
}

function kA(e, t) {
    let n = e.hostBindings;
    n ? e.hostBindings = (r, o) => {
        t(r, o), n(r, o)
    } : e.hostBindings = t
}

function Uv(e, t, n, r, o, i, s, a) {
    if (n.firstCreatePass) {
        e.mergedAttrs = ko(e.mergedAttrs, e.attrs);
        let u = e.tView = Mp(2, e, o, i, s, n.directiveRegistry, n.pipeRegistry, null, n.schemas, n.consts, null);
        n.queries !== null && (n.queries.template(n, e), u.queries = n.queries.embeddedTView(e))
    }
    a && (e.flags |= a), Ur(e, !1);
    let c = UA(n, t, e, r);
    fc() && kp(n, t, c, e), Fo(c, t);
    let l = sv(c, t, c, e);
    t[r + z] = l, Rp(t, l), hA(l, e, t)
}

function FA(e, t, n, r, o, i, s, a, c, l, u) {
    let d = n + z,
        f;
    return t.firstCreatePass ? (f = Kr(t, d, 4, s || null, a || null), ac() && pv(t, e, f, Et(t.consts, l), Up), $y(t, f)) : f = t.data[d], Uv(f, e, t, n, r, o, i, c), Ao(f) && al(t, e, f), l != null && $o(e, f, u), f
}

function os(e, t, n, r, o, i, s, a, c, l, u) {
    let d = n + z,
        f;
    if (t.firstCreatePass) {
        if (f = Kr(t, d, 4, s || null, a || null), l != null) {
            let p = Et(t.consts, l);
            f.localNames = [];
            for (let m = 0; m < p.length; m += 2) f.localNames.push(p[m], -1)
        }
    } else f = t.data[d];
    return Uv(f, e, t, n, r, o, i, c), l != null && $o(e, f, u), f
}

function Bv(e, t, n, r, o, i, s, a) {
    let c = C(),
        l = Y(),
        u = Et(l.consts, i);
    return FA(c, l, e, t, n, r, o, u, void 0, s, a), Bv
}
var UA = BA;

function BA(e, t, n, r) {
    return zi(!0), t[W].createComment("")
}
var hl = (() => {
    class e {
        log(n) {
            console.log(n)
        }
        warn(n) {
            console.warn(n)
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "platform"
        })
    }
    return e
})();

function Zp(e) {
    return typeof e == "function" && e[ue] !== void 0
}

function Xp(e) {
    return Zp(e) && typeof e.set == "function"
}
var ml = new v(""),
    gl = new v(""),
    vs = (() => {
        class e {
            _ngZone;
            registry;
            _isZoneStable = !0;
            _callbacks = [];
            _taskTrackingZone = null;
            _destroyRef;
            constructor(n, r, o) {
                this._ngZone = n, this.registry = r, zd() && (this._destroyRef = h(He, {
                    optional: !0
                }) ? ? void 0), eh || (Hv(o), o.addToWindow(r)), this._watchAngularEvents(), n.run(() => {
                    this._taskTrackingZone = typeof Zone > "u" ? null : Zone.current.get("TaskTrackingZone")
                })
            }
            _watchAngularEvents() {
                let n = this._ngZone.onUnstable.subscribe({
                        next: () => {
                            this._isZoneStable = !1
                        }
                    }),
                    r = this._ngZone.runOutsideAngular(() => this._ngZone.onStable.subscribe({
                        next: () => {
                            Q.assertNotInAngularZone(), queueMicrotask(() => {
                                this._isZoneStable = !0, this._runCallbacksIfReady()
                            })
                        }
                    }));
                this._destroyRef ? .onDestroy(() => {
                    n.unsubscribe(), r.unsubscribe()
                })
            }
            isStable() {
                return this._isZoneStable && !this._ngZone.hasPendingMacrotasks
            }
            _runCallbacksIfReady() {
                if (this.isStable()) queueMicrotask(() => {
                    for (; this._callbacks.length !== 0;) {
                        let n = this._callbacks.pop();
                        clearTimeout(n.timeoutId), n.doneCb()
                    }
                });
                else {
                    let n = this.getPendingTasks();
                    this._callbacks = this._callbacks.filter(r => r.updateCb && r.updateCb(n) ? (clearTimeout(r.timeoutId), !1) : !0)
                }
            }
            getPendingTasks() {
                return this._taskTrackingZone ? this._taskTrackingZone.macroTasks.map(n => ({
                    source: n.source,
                    creationLocation: n.creationLocation,
                    data: n.data
                })) : []
            }
            addCallback(n, r, o) {
                let i = -1;
                r && r > 0 && (i = setTimeout(() => {
                    this._callbacks = this._callbacks.filter(s => s.timeoutId !== i), n()
                }, r)), this._callbacks.push({
                    doneCb: n,
                    timeoutId: i,
                    updateCb: o
                })
            }
            whenStable(n, r, o) {
                if (o && !this._taskTrackingZone) throw new Error('Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/plugins/task-tracking" loaded?');
                this.addCallback(n, r, o), this._runCallbacksIfReady()
            }
            registerApplication(n) {
                this.registry.registerApplication(n, this)
            }
            unregisterApplication(n) {
                this.registry.unregisterApplication(n)
            }
            findProviders(n, r, o) {
                return []
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Q), _(jv), _(gl))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    jv = (() => {
        class e {
            _applications = new Map;
            registerApplication(n, r) {
                this._applications.set(n, r)
            }
            unregisterApplication(n) {
                this._applications.delete(n)
            }
            unregisterAllApplications() {
                this._applications.clear()
            }
            getTestability(n) {
                return this._applications.get(n) || null
            }
            getAllTestabilities() {
                return Array.from(this._applications.values())
            }
            getAllRootElements() {
                return Array.from(this._applications.keys())
            }
            findTestabilityInTree(n, r = !0) {
                return eh ? .findTestabilityInTree(this, n, r) ? ? null
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "platform"
            })
        }
        return e
    })();

function Hv(e) {
    eh = e
}
var eh;

function Yr(e) {
    return !!e && typeof e.then == "function"
}

function El(e) {
    return !!e && typeof e.subscribe == "function"
}
var th = new v("");

function yl(e) {
    return Zn([{
        provide: th,
        multi: !0,
        useValue: e
    }])
}
var nh = (() => {
        class e {
            resolve;
            reject;
            initialized = !1;
            done = !1;
            donePromise = new Promise((n, r) => {
                this.resolve = n, this.reject = r
            });
            appInits = h(th, {
                optional: !0
            }) ? ? [];
            injector = h(fe);
            constructor() {}
            runInitializers() {
                if (this.initialized) return;
                let n = [];
                for (let o of this.appInits) {
                    let i = _e(this.injector, o);
                    if (Yr(i)) n.push(i);
                    else if (El(i)) {
                        let s = new Promise((a, c) => {
                            i.subscribe({
                                complete: a,
                                error: c
                            })
                        });
                        n.push(s)
                    }
                }
                let r = () => {
                    this.done = !0, this.resolve()
                };
                Promise.all(n).then(() => {
                    r()
                }).catch(o => {
                    this.reject(o)
                }), n.length === 0 && r(), this.initialized = !0
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    vl = new v("");

function Vv() {
    Ku(() => {
        let e = "";
        throw new g(600, e)
    })
}

function $v(e) {
    return e.isBoundToModule
}
var jA = 10;

function rh(e, t) {
    return Array.isArray(t) ? t.reduce(rh, e) : E(E({}, e), t)
}
var Bt = (() => {
    class e {
        _runningTick = !1;
        _destroyed = !1;
        _destroyListeners = [];
        _views = [];
        internalErrorHandler = h(Ke);
        afterRenderManager = h(Pp);
        zonelessEnabled = h(Ro);
        rootEffectScheduler = h(hc);
        dirtyFlags = 0;
        tracingSnapshot = null;
        allTestViews = new Set;
        autoDetectTestViews = new Set;
        includeAllTestViews = !1;
        afterTick = new ne;
        get allViews() {
            return [...(this.includeAllTestViews ? this.allTestViews : this.autoDetectTestViews).keys(), ...this._views]
        }
        get destroyed() {
            return this._destroyed
        }
        componentTypes = [];
        components = [];
        internalPendingTask = h(en);
        get isStable() {
            return this.internalPendingTask.hasPendingTasksObservable.pipe(j(n => !n))
        }
        constructor() {
            h(sn, {
                optional: !0
            })
        }
        whenStable() {
            let n;
            return new Promise(r => {
                n = this.isStable.subscribe({
                    next: o => {
                        o && r()
                    }
                })
            }).finally(() => {
                n.unsubscribe()
            })
        }
        _injector = h(re);
        _rendererFactory = null;
        get injector() {
            return this._injector
        }
        bootstrap(n, r) {
            return this.bootstrapImpl(n, r)
        }
        bootstrapImpl(n, r, o = fe.NULL) {
            return this._injector.get(Q).run(() => {
                q(H.BootstrapComponentStart);
                let s = n instanceof dl;
                if (!this._injector.get(nh).done) {
                    let m = "";
                    throw new g(405, m)
                }
                let c;
                s ? c = n : c = this._injector.get(Es).resolveComponentFactory(n), this.componentTypes.push(c.componentType);
                let l = $v(c) ? void 0 : this._injector.get(zr),
                    u = r || c.selector,
                    d = c.create(o, [], u, l),
                    f = d.location.nativeElement,
                    p = d.injector.get(ml, null);
                return p ? .registerApplication(f), d.onDestroy(() => {
                    this.detachView(d.hostView), Zi(this.components, d), p ? .unregisterApplication(f)
                }), this._loadComponent(d), q(H.BootstrapComponentEnd, d), d
            })
        }
        tick() {
            this.zonelessEnabled || (this.dirtyFlags |= 1), this._tick()
        }
        _tick() {
            q(H.ChangeDetectionStart), this.tracingSnapshot !== null ? this.tracingSnapshot.run(rl.CHANGE_DETECTION, this.tickImpl) : this.tickImpl()
        }
        tickImpl = () => {
            if (this._runningTick) throw q(H.ChangeDetectionEnd), new g(101, !1);
            let n = S(null);
            try {
                this._runningTick = !0, this.synchronize()
            } finally {
                this._runningTick = !1, this.tracingSnapshot ? .dispose(), this.tracingSnapshot = null, S(n), this.afterTick.next(), q(H.ChangeDetectionEnd)
            }
        };
        synchronize() {
            this._rendererFactory === null && !this._injector.destroyed && (this._rendererFactory = this._injector.get(Gr, null, {
                optional: !0
            }));
            let n = 0;
            for (; this.dirtyFlags !== 0 && n++ < jA;) {
                q(H.ChangeDetectionSyncStart);
                try {
                    this.synchronizeOnce()
                } finally {
                    q(H.ChangeDetectionSyncEnd)
                }
            }
        }
        synchronizeOnce() {
            this.dirtyFlags & 16 && (this.dirtyFlags &= -17, this.rootEffectScheduler.flush());
            let n = !1;
            if (this.dirtyFlags & 7) {
                let r = !!(this.dirtyFlags & 1);
                this.dirtyFlags &= -8, this.dirtyFlags |= 8;
                for (let {
                        _lView: o
                    } of this.allViews) {
                    if (!r && !Vi(o)) continue;
                    let i = r && !this.zonelessEnabled ? 0 : 1;
                    nv(o, i), n = !0
                }
                if (this.dirtyFlags &= -5, this.syncDirtyFlagsWithViews(), this.dirtyFlags & 23) return
            }
            n || (this._rendererFactory ? .begin ? .(), this._rendererFactory ? .end ? .()), this.dirtyFlags & 8 && (this.dirtyFlags &= -9, this.afterRenderManager.execute()), this.syncDirtyFlagsWithViews()
        }
        syncDirtyFlagsWithViews() {
            if (this.allViews.some(({
                    _lView: n
                }) => Vi(n))) {
                this.dirtyFlags |= 2;
                return
            } else this.dirtyFlags &= -8
        }
        attachView(n) {
            let r = n;
            this._views.push(r), r.attachToAppRef(this)
        }
        detachView(n) {
            let r = n;
            Zi(this._views, r), r.detachFromAppRef()
        }
        _loadComponent(n) {
            this.attachView(n.hostView);
            try {
                this.tick()
            } catch (o) {
                this.internalErrorHandler(o)
            }
            this.components.push(n), this._injector.get(vl, []).forEach(o => o(n))
        }
        ngOnDestroy() {
            if (!this._destroyed) try {
                this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy())
            } finally {
                this._destroyed = !0, this._views = [], this._destroyListeners = []
            }
        }
        onDestroy(n) {
            return this._destroyListeners.push(n), () => Zi(this._destroyListeners, n)
        }
        destroy() {
            if (this._destroyed) throw new g(406, !1);
            let n = this._injector;
            n.destroy && !n.destroyed && n.destroy()
        }
        get viewCount() {
            return this._views.length
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
        })
    }
    return e
})();

function Zi(e, t) {
    let n = e.indexOf(t);
    n > -1 && e.splice(n, 1)
}

function Dl(e, t, n, r) {
    let o = C(),
        i = xn();
    if (Le(o, i, t)) {
        let s = Y(),
            a = Wi();
        gw(a, o, e, t, n, r)
    }
    return Dl
}

function Tc(e) {
    if (Ye("NgAnimateEnter"), !P0) return Tc;
    let t = C();
    if (Pb(t)) return Tc;
    let n = he(),
        r = t[rt].get(Q);
    return Bb(gy(t), n, () => HA(t, n, e, r)), Yb(t[rt]), V0(t[rt], gy(t)), Tc
}

function HA(e, t, n, r) {
    let o = mt(t, e),
        i = e[W],
        s = Ub(n),
        a = [],
        c = !1,
        l = d => {
            if (Pc(d) !== o) return;
            let f = d instanceof AnimationEvent ? "animationend" : "transitionend";
            r.runOutsideAngular(() => {
                i.listen(o, f, u)
            })
        },
        u = d => {
            Pc(d) === o && (k0(d, o) && (c = !0), VA(d, o, i))
        };
    if (s && s.length > 0) {
        r.runOutsideAngular(() => {
            a.push(i.listen(o, "animationstart", l)), a.push(i.listen(o, "transitionstart", l))
        }), Lb(o, s, a);
        for (let d of s) i.addClass(o, d);
        r.runOutsideAngular(() => {
            requestAnimationFrame(() => {
                if (!c && ($b(o, Oc, P0), !Oc.has(o))) {
                    for (let d of s) i.removeClass(o, d);
                    L0(o)
                }
            })
        })
    }
}

function VA(e, t, n) {
    let r = es.get(t);
    if (!(Pc(e) !== t || !r) && k0(e, t)) {
        e.stopPropagation();
        for (let o of r.classList) n.removeClass(t, o);
        L0(t)
    }
}

function $A() {
    return C()[Pe][ie]
}
var ap = class {
    destroy(t) {}
    updateValue(t, n) {}
    swap(t, n) {
        let r = Math.min(t, n),
            o = Math.max(t, n),
            i = this.detach(o);
        if (o - r > 1) {
            let s = this.detach(r);
            this.attach(r, i), this.attach(o, s)
        } else this.attach(r, i)
    }
    move(t, n) {
        this.attach(n, this.detach(t))
    }
};

function bf(e, t, n, r, o) {
    return e === n && Object.is(t, r) ? 1 : Object.is(o(e, t), o(n, r)) ? -1 : 0
}

function GA(e, t, n, r) {
    let o, i, s = 0,
        a = e.length - 1,
        c = void 0;
    if (Array.isArray(t)) {
        S(r);
        let l = t.length - 1;
        for (S(null); s <= a && s <= l;) {
            let u = e.at(s),
                d = t[s],
                f = bf(s, u, s, d, n);
            if (f !== 0) {
                f < 0 && e.updateValue(s, d), s++;
                continue
            }
            let p = e.at(a),
                m = t[l],
                x = bf(a, p, l, m, n);
            if (x !== 0) {
                x < 0 && e.updateValue(a, m), a--, l--;
                continue
            }
            let D = n(s, u),
                I = n(a, p),
                F = n(s, d);
            if (Object.is(F, I)) {
                let me = n(l, m);
                Object.is(me, D) ? (e.swap(s, a), e.updateValue(a, m), l--, a--) : e.move(a, s), e.updateValue(s, d), s++;
                continue
            }
            if (o ? ? = new Gc, i ? ? = Ay(e, s, a, n), cp(e, o, s, F)) e.updateValue(s, d), s++, a++;
            else if (i.has(F)) o.set(D, e.detach(s)), a--;
            else {
                let me = e.create(s, t[s]);
                e.attach(s, me), s++, a++
            }
        }
        for (; s <= l;) wy(e, o, n, s, t[s]), s++
    } else if (t != null) {
        S(r);
        let l = t[Symbol.iterator]();
        S(null);
        let u = l.next();
        for (; !u.done && s <= a;) {
            let d = e.at(s),
                f = u.value,
                p = bf(s, d, s, f, n);
            if (p !== 0) p < 0 && e.updateValue(s, f), s++, u = l.next();
            else {
                o ? ? = new Gc, i ? ? = Ay(e, s, a, n);
                let m = n(s, f);
                if (cp(e, o, s, m)) e.updateValue(s, f), s++, a++, u = l.next();
                else if (!i.has(m)) e.attach(s, e.create(s, f)), s++, a++, u = l.next();
                else {
                    let x = n(s, d);
                    o.set(x, e.detach(s)), a--
                }
            }
        }
        for (; !u.done;) wy(e, o, n, e.length, u.value), u = l.next()
    }
    for (; s <= a;) e.destroy(e.detach(a--));
    o ? .forEach(l => {
        e.destroy(l)
    })
}

function cp(e, t, n, r) {
    return t !== void 0 && t.has(r) ? (e.attach(n, t.get(r)), t.delete(r), !0) : !1
}

function wy(e, t, n, r, o) {
    if (cp(e, t, r, n(r, o))) e.updateValue(r, o);
    else {
        let i = e.create(r, o);
        e.attach(r, i)
    }
}

function Ay(e, t, n, r) {
    let o = new Set;
    for (let i = t; i <= n; i++) o.add(r(i, e.at(i)));
    return o
}
var Gc = class {
    kvMap = new Map;
    _vMap = void 0;
    has(t) {
        return this.kvMap.has(t)
    }
    delete(t) {
        if (!this.has(t)) return !1;
        let n = this.kvMap.get(t);
        return this._vMap !== void 0 && this._vMap.has(n) ? (this.kvMap.set(t, this._vMap.get(n)), this._vMap.delete(n)) : this.kvMap.delete(t), !0
    }
    get(t) {
        return this.kvMap.get(t)
    }
    set(t, n) {
        if (this.kvMap.has(t)) {
            let r = this.kvMap.get(t);
            this._vMap === void 0 && (this._vMap = new Map);
            let o = this._vMap;
            for (; o.has(r);) r = o.get(r);
            o.set(r, n)
        } else this.kvMap.set(t, n)
    }
    forEach(t) {
        for (let [n, r] of this.kvMap)
            if (t(r, n), this._vMap !== void 0) {
                let o = this._vMap;
                for (; o.has(r);) r = o.get(r), t(r, n)
            }
    }
};

function WA(e, t, n, r, o, i, s, a) {
    Ye("NgControlFlow");
    let c = C(),
        l = Y(),
        u = Et(l.consts, i);
    return os(c, l, e, t, n, r, o, u, 256, s, a), oh
}

function oh(e, t, n, r, o, i, s, a) {
    Ye("NgControlFlow");
    let c = C(),
        l = Y(),
        u = Et(l.consts, i);
    return os(c, l, e, t, n, r, o, u, 512, s, a), oh
}

function zA(e, t) {
    Ye("NgControlFlow");
    let n = C(),
        r = xn(),
        o = n[r] !== ce ? n[r] : -1,
        i = o !== -1 ? Wc(n, z + o) : void 0,
        s = 0;
    if (Le(n, r, e)) {
        let a = S(null);
        try {
            if (i !== void 0 && cv(i, s), e !== -1) {
                let c = z + e,
                    l = Wc(n, c),
                    u = fp(n[b], c),
                    d = uv(l, u, n),
                    f = ms(n, u, t, {
                        dehydratedView: d
                    });
                gs(l, f, s, Uo(u, d))
            }
        } finally {
            S(a)
        }
    } else if (i !== void 0) {
        let a = av(i, s);
        a !== void 0 && (a[ie] = t)
    }
}
var lp = class {
    lContainer;
    $implicit;
    $index;
    constructor(t, n, r) {
        this.lContainer = t, this.$implicit = n, this.$index = r
    }
    get $count() {
        return this.lContainer.length - se
    }
};

function qA(e) {
    return e
}

function KA(e, t) {
    return t
}
var up = class {
    hasEmptyBlock;
    trackByFn;
    liveCollection;
    constructor(t, n, r) {
        this.hasEmptyBlock = t, this.trackByFn = n, this.liveCollection = r
    }
};

function YA(e, t, n, r, o, i, s, a, c, l, u, d, f) {
    Ye("NgControlFlow");
    let p = C(),
        m = Y(),
        x = c !== void 0,
        D = C(),
        I = a ? s.bind(D[Pe][ie]) : s,
        F = new up(x, I);
    D[z + e] = F, os(p, m, e + 1, t, n, r, o, Et(m.consts, i), 256), x && os(p, m, e + 2, c, l, u, d, Et(m.consts, f), 512)
}
var dp = class extends ap {
    lContainer;
    hostLView;
    templateTNode;
    operationsCounter = void 0;
    needsIndexUpdate = !1;
    constructor(t, n, r) {
        super(), this.lContainer = t, this.hostLView = n, this.templateTNode = r
    }
    get length() {
        return this.lContainer.length - se
    }
    at(t) {
        return this.getLView(t)[ie].$implicit
    }
    attach(t, n) {
        let r = n[Nr];
        this.needsIndexUpdate || = t !== this.length, gs(this.lContainer, n, t, Uo(this.templateTNode, r)), QA(this.lContainer, t)
    }
    detach(t) {
        return this.needsIndexUpdate || = t !== this.length - 1, ZA(this.lContainer, t), XA(this.lContainer, t)
    }
    create(t, n) {
        let r = Fc(this.lContainer, this.templateTNode.tView.ssrId);
        return ms(this.hostLView, this.templateTNode, new lp(this.lContainer, n, t), {
            dehydratedView: r
        })
    }
    destroy(t) {
        il(t[b], t)
    }
    updateValue(t, n) {
        this.getLView(t)[ie].$implicit = n
    }
    reset() {
        this.needsIndexUpdate = !1
    }
    updateIndexes() {
        if (this.needsIndexUpdate)
            for (let t = 0; t < this.length; t++) this.getLView(t)[ie].$index = t
    }
    getLView(t) {
        return eM(this.lContainer, t)
    }
};

function JA(e) {
    let t = S(null),
        n = qe();
    try {
        let r = C(),
            o = r[b],
            i = r[n],
            s = n + 1,
            a = Wc(r, s);
        if (i.liveCollection === void 0) {
            let l = fp(o, s);
            i.liveCollection = new dp(a, r, l)
        } else i.liveCollection.reset();
        let c = i.liveCollection;
        if (GA(c, e, i.trackByFn, t), c.updateIndexes(), i.hasEmptyBlock) {
            let l = xn(),
                u = c.length === 0;
            if (Le(r, l, u)) {
                let d = n + 2,
                    f = Wc(r, d);
                if (u) {
                    let p = fp(o, d),
                        m = uv(f, p, r),
                        x = ms(r, p, void 0, {
                            dehydratedView: m
                        });
                    gs(f, x, 0, Uo(p, m))
                } else o.firstUpdatePass && jw(f), cv(f, 0)
            }
        }
    } finally {
        S(t)
    }
}

function Wc(e, t) {
    return e[t]
}

function QA(e, t) {
    if (e.length <= se) return;
    let n = se + t,
        r = e[n],
        o = r ? r[vn] : void 0;
    if (r && o && o.detachedLeaveAnimationFns && o.detachedLeaveAnimationFns.length > 0) {
        let i = r[rt];
        qb(i, o), $r.delete(r[yn]), o.detachedLeaveAnimationFns = void 0
    }
}

function ZA(e, t) {
    if (e.length <= se) return;
    let n = se + t,
        r = e[n],
        o = r ? r[vn] : void 0;
    o && o.leave && o.leave.size > 0 && (o.detachedLeaveAnimationFns = [])
}

function XA(e, t) {
    return ns(e, t)
}

function eM(e, t) {
    return av(e, t)
}

function fp(e, t) {
    return oc(e, t)
}

function Gv(e, t, n) {
    let r = C(),
        o = xn();
    if (Le(r, o, t)) {
        let i = Y(),
            s = Wi();
        Y0(s, r, e, t, r[W], n)
    }
    return Gv
}

function pp(e, t, n, r, o) {
    Bp(t, e, n, o ? "class" : "style", r)
}

function zc(e, t, n, r) {
    let o = C(),
        i = o[b],
        s = e + z,
        a = i.firstCreatePass ? $p(s, o, 2, t, Up, ac(), n, r) : i.data[s];
    if (_n(a)) {
        let c = o[Ot].tracingService;
        if (c && c.componentCreate) {
            let l = i.data[a.directiveStart + a.componentOffset];
            return c.componentCreate(Dv(l), () => (My(e, t, o, a, r), zc))
        }
    }
    return My(e, t, o, a, r), zc
}

function My(e, t, n, r, o) {
    if (cl(r, n, e, t, zv), Ao(r)) {
        let i = n[b];
        al(i, n, r), _p(i, r, n)
    }
    o != null && $o(n, r)
}

function ih() {
    let e = Y(),
        t = he(),
        n = ll(t);
    return e.firstCreatePass && Gp(e, n), af(n) && cf(), of (), n.classesWithoutHost != null && hS(n) && pp(e, n, C(), n.classesWithoutHost, !0), n.stylesWithoutHost != null && mS(n) && pp(e, n, C(), n.stylesWithoutHost, !1), ih
}

function _l(e, t, n, r) {
    return zc(e, t, n, r), ih(), _l
}

function sh(e, t, n, r) {
    let o = C(),
        i = o[b],
        s = e + z,
        a = i.firstCreatePass ? mv(s, i, 2, t, n, r) : i.data[s];
    return cl(a, o, e, t, zv), r != null && $o(o, a), sh
}

function ah() {
    let e = he(),
        t = ll(e);
    return af(t) && cf(), of (), ah
}

function Wv(e, t, n, r) {
    return sh(e, t, n, r), ah(), Wv
}
var zv = (e, t, n, r, o) => (zi(!0), _0(t[W], r, gf()));

function ch(e, t, n) {
    let r = C(),
        o = r[b],
        i = e + z,
        s = o.firstCreatePass ? $p(i, r, 8, "ng-container", Up, ac(), t, n) : o.data[i];
    if (cl(s, r, e, "ng-container", Yv), Ao(s)) {
        let a = r[b];
        al(a, r, s), _p(a, s, r)
    }
    return n != null && $o(r, s), ch
}

function xl() {
    let e = Y(),
        t = he(),
        n = ll(t);
    return e.firstCreatePass && Gp(e, n), xl
}

function qv(e, t, n) {
    return ch(e, t, n), xl(), qv
}

function Kv(e, t, n) {
    let r = C(),
        o = r[b],
        i = e + z,
        s = o.firstCreatePass ? mv(i, o, 8, "ng-container", t, n) : o.data[i];
    return cl(s, r, e, "ng-container", Yv), n != null && $o(r, s), Kv
}

function tM() {
    let e = he(),
        t = ll(e);
    return xl
}
var Yv = (e, t, n, r, o) => (zi(!0), lb(t[W], ""));

function nM() {
    return C()
}

function Jv(e, t, n) {
    let r = C(),
        o = xn();
    if (Le(r, o, t)) {
        let i = Y(),
            s = Wi();
        J0(s, r, e, t, r[W], n)
    }
    return Jv
}
var Yi = void 0;

function rM(e) {
    let t = Math.floor(Math.abs(e)),
        n = e.toString().replace(/^[^.]*\.?/, "").length;
    return t === 1 && n === 0 ? 1 : 5
}
var oM = ["en", [
            ["a", "p"],
            ["AM", "PM"]
        ],
        [
            ["AM", "PM"]
        ],
        [
            ["S", "M", "T", "W", "T", "F", "S"],
            ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
        ], Yi, [
            ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
            ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        ], Yi, [
            ["B", "A"],
            ["BC", "AD"],
            ["Before Christ", "Anno Domini"]
        ], 0, [6, 0],
        ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"],
        ["h:mm\u202Fa", "h:mm:ss\u202Fa", "h:mm:ss\u202Fa z", "h:mm:ss\u202Fa zzzz"],
        ["{1}, {0}", Yi, Yi, Yi],
        [".", ",", ";", "%", "+", "-", "E", "\xD7", "\u2030", "\u221E", "NaN", ":"],
        ["#,##0.###", "#,##0%", "\xA4#,##0.00", "#E0"], "USD", "$", "US Dollar", {}, "ltr", rM
    ],
    wf = {};

function Je(e) {
    let t = iM(e),
        n = Ny(t);
    if (n) return n;
    let r = t.split("-")[0];
    if (n = Ny(r), n) return n;
    if (r === "en") return oM;
    throw new g(701, !1)
}

function Ny(e) {
    return e in wf || (wf[e] = ge.ng && ge.ng.common && ge.ng.common.locales && ge.ng.common.locales[e]), wf[e]
}
var le = (function(e) {
    return e[e.LocaleId = 0] = "LocaleId", e[e.DayPeriodsFormat = 1] = "DayPeriodsFormat", e[e.DayPeriodsStandalone = 2] = "DayPeriodsStandalone", e[e.DaysFormat = 3] = "DaysFormat", e[e.DaysStandalone = 4] = "DaysStandalone", e[e.MonthsFormat = 5] = "MonthsFormat", e[e.MonthsStandalone = 6] = "MonthsStandalone", e[e.Eras = 7] = "Eras", e[e.FirstDayOfWeek = 8] = "FirstDayOfWeek", e[e.WeekendRange = 9] = "WeekendRange", e[e.DateFormat = 10] = "DateFormat", e[e.TimeFormat = 11] = "TimeFormat", e[e.DateTimeFormat = 12] = "DateTimeFormat", e[e.NumberSymbols = 13] = "NumberSymbols", e[e.NumberFormats = 14] = "NumberFormats", e[e.CurrencyCode = 15] = "CurrencyCode", e[e.CurrencySymbol = 16] = "CurrencySymbol", e[e.CurrencyName = 17] = "CurrencyName", e[e.Currencies = 18] = "Currencies", e[e.Directionality = 19] = "Directionality", e[e.PluralCase = 20] = "PluralCase", e[e.ExtraData = 21] = "ExtraData", e
})(le || {});

function iM(e) {
    return e.toLowerCase().replace(/_/g, "-")
}
var Ds = "en-US";
var sM = Ds;

function Qv(e) {
    typeof e == "string" && (sM = e.toLowerCase().replace(/_/g, "-"))
}

function Cl(e, t, n) {
    let r = C(),
        o = Y(),
        i = he();
    return Xv(o, r, r[W], i, e, t, n), Cl
}

function Zv(e, t, n) {
    let r = C(),
        o = Y(),
        i = he();
    return (i.type & 3 || n) && yv(i, o, r, n, r[W], e, t, Ic(i, r, t)), Zv
}

function Xv(e, t, n, r, o, i, s) {
    let a = !0,
        c = null;
    if ((r.type & 3 || s) && (c ? ? = Ic(r, t, i), yv(r, e, t, s, n, o, i, c) && (a = !1)), a) {
        let l = r.outputs ? .[o],
            u = r.hostDirectiveOutputs ? .[o];
        if (u && u.length)
            for (let d = 0; d < u.length; d += 2) {
                let f = u[d],
                    p = u[d + 1];
                c ? ? = Ic(r, t, i), Ty(r, t, f, p, o, c)
            }
        if (l && l.length)
            for (let d of l) c ? ? = Ic(r, t, i), Ty(r, t, d, o, o, c)
    }
}

function aM(e = 1) {
    return GE(e)
}

function cM(e, t) {
    let n = null,
        r = _b(e);
    for (let o = 0; o < t.length; o++) {
        let i = t[o];
        if (i === "*") {
            n = o;
            continue
        }
        if (r === null ? A0(e, i, !0) : Ib(r, i)) return o
    }
    return n
}

function lM(e) {
    let t = C()[Pe][je];
    if (!t.projection) {
        let n = e ? e.length : 1,
            r = t.projection = yE(n, null),
            o = r.slice(),
            i = t.child;
        for (; i !== null;) {
            if (i.type !== 128) {
                let s = e ? cM(i, e) : 0;
                s !== null && (o[s] ? o[s].projectionNext = i : r[s] = i, o[s] = i)
            }
            i = i.next
        }
    }
}

function uM(e, t = 0, n, r, o, i) {
    let s = C(),
        a = Y(),
        c = r ? e + 1 : null;
    c !== null && os(s, a, c, r, o, i, null, n);
    let l = Kr(a, z + e, 16, null, n || null);
    l.projection === null && (l.projection = t), df();
    let d = !s[Nr] || sf();
    s[Pe][je].projection[l.projection] === null && c !== null ? dM(s, a, c) : d && !Xc(l) && iw(a, s, l)
}

function dM(e, t, n) {
    let r = z + n,
        o = t.data[r],
        i = e[r],
        s = Fc(i, o.tView.ssrId),
        a = ms(e, o, void 0, {
            dehydratedView: s
        });
    gs(i, a, 0, Uo(o, s))
}

function Il(e, t, n, r) {
    return DA(e, t, n, r), Il
}

function eD(e, t, n) {
    return Tv(e, t, n), eD
}

function lh(e) {
    let t = C(),
        n = Y(),
        r = lc();
    Gi(r + 1);
    let o = Kp(n, r);
    if (e.dirty && SE(t) === ((o.metadata.flags & 2) === 2)) {
        if (o.matches === null) e.reset([]);
        else {
            let i = bv(t, r);
            e.reset(i, t0), e.notifyOnChanges()
        }
        return !0
    }
    return !1
}

function uh() {
    return qp(C(), lc())
}

function tD(e, t, n, r) {
    return CA(e, Tv(t, n, r)), tD
}

function fM(e = 1) {
    Gi(lc() + e)
}

function pM(e) {
    let t = ff();
    return No(t, z + e)
}

function yc(e, t) {
    return e << 17 | t << 2
}

function qr(e) {
    return e >> 17 & 32767
}

function hM(e) {
    return (e & 2) == 2
}

function mM(e, t) {
    return e & 131071 | t << 17
}

function hp(e) {
    return e | 2
}

function jo(e) {
    return (e & 131068) >> 2
}

function Af(e, t) {
    return e & -131069 | t << 2
}

function gM(e) {
    return (e & 1) === 1
}

function mp(e) {
    return e | 1
}

function EM(e, t, n, r, o, i) {
    let s = i ? t.classBindings : t.styleBindings,
        a = qr(s),
        c = jo(s);
    e[r] = n;
    let l = !1,
        u;
    if (Array.isArray(n)) {
        let d = n;
        u = d[1], (u === null || To(d, u) > 0) && (l = !0)
    } else u = n;
    if (o)
        if (c !== 0) {
            let f = qr(e[a + 1]);
            e[r + 1] = yc(f, a), f !== 0 && (e[f + 1] = Af(e[f + 1], r)), e[a + 1] = mM(e[a + 1], r)
        } else e[r + 1] = yc(a, 0), a !== 0 && (e[a + 1] = Af(e[a + 1], r)), a = r;
    else e[r + 1] = yc(c, 0), a === 0 ? a = r : e[c + 1] = Af(e[c + 1], r), c = r;
    l && (e[r + 1] = hp(e[r + 1])), Ry(e, u, r, !0), Ry(e, u, r, !1), yM(t, u, e, r, i), s = yc(a, c), i ? t.classBindings = s : t.styleBindings = s
}

function yM(e, t, n, r, o) {
    let i = o ? e.residualClasses : e.residualStyles;
    i != null && typeof t == "string" && To(i, t) >= 0 && (n[r + 1] = mp(n[r + 1]))
}

function Ry(e, t, n, r) {
    let o = e[n + 1],
        i = t === null,
        s = r ? qr(o) : jo(o),
        a = !1;
    for (; s !== 0 && (a === !1 || i);) {
        let c = e[s],
            l = e[s + 1];
        vM(c, t) && (a = !0, e[s + 1] = r ? mp(l) : hp(l)), s = r ? qr(l) : jo(l)
    }
    a && (e[n + 1] = r ? hp(o) : mp(o))
}

function vM(e, t) {
    return e === null || t == null || (Array.isArray(e) ? e[1] : e) === t ? !0 : Array.isArray(e) && typeof t == "string" ? To(e, t) >= 0 : !1
}
var xe = {
    textEnd: 0,
    key: 0,
    keyEnd: 0,
    value: 0,
    valueEnd: 0
};

function nD(e) {
    return e.substring(xe.key, xe.keyEnd)
}

function DM(e) {
    return e.substring(xe.value, xe.valueEnd)
}

function _M(e) {
    return iD(e), rD(e, Ho(e, 0, xe.textEnd))
}

function rD(e, t) {
    let n = xe.textEnd;
    return n === t ? -1 : (t = xe.keyEnd = CM(e, xe.key = t, n), Ho(e, t, n))
}

function xM(e) {
    return iD(e), oD(e, Ho(e, 0, xe.textEnd))
}

function oD(e, t) {
    let n = xe.textEnd,
        r = xe.key = Ho(e, t, n);
    return n === r ? -1 : (r = xe.keyEnd = IM(e, r, n), r = Oy(e, r, n, 58), r = xe.value = Ho(e, r, n), r = xe.valueEnd = TM(e, r, n), Oy(e, r, n, 59))
}

function iD(e) {
    xe.key = 0, xe.keyEnd = 0, xe.value = 0, xe.valueEnd = 0, xe.textEnd = e.length
}

function Ho(e, t, n) {
    for (; t < n && e.charCodeAt(t) <= 32;) t++;
    return t
}

function CM(e, t, n) {
    for (; t < n && e.charCodeAt(t) > 32;) t++;
    return t
}

function IM(e, t, n) {
    let r;
    for (; t < n && ((r = e.charCodeAt(t)) === 45 || r === 95 || (r & -33) >= 65 && (r & -33) <= 90 || r >= 48 && r <= 57);) t++;
    return t
}

function Oy(e, t, n, r) {
    return t = Ho(e, t, n), t < n && t++, t
}

function TM(e, t, n) {
    let r = -1,
        o = -1,
        i = -1,
        s = t,
        a = s;
    for (; s < n;) {
        let c = e.charCodeAt(s++);
        if (c === 59) return a;
        c === 34 || c === 39 ? a = s = Py(e, c, s, n) : t === s - 4 && i === 85 && o === 82 && r === 76 && c === 40 ? a = s = Py(e, 41, s, n) : c > 32 && (a = s), i = o, o = r, r = c & -33
    }
    return a
}

function Py(e, t, n, r) {
    let o = -1,
        i = n;
    for (; i < r;) {
        let s = e.charCodeAt(i++);
        if (s == t && o !== 92) return i;
        s == 92 && o === 92 ? o = 0 : o = s
    }
    throw new Error
}

function Tl(e, t, n) {
    return aD(e, t, n, !1), Tl
}

function sD(e, t) {
    return aD(e, t, null, !0), sD
}

function SM(e) {
    cD(dD, bM, e, !1)
}

function bM(e, t) {
    for (let n = xM(t); n >= 0; n = oD(t, n)) dD(e, nD(t), DM(t))
}

function wM(e) {
    cD(LM, AM, e, !0)
}

function AM(e, t) {
    for (let n = _M(t); n >= 0; n = rD(t, n)) Ui(e, nD(t), !0)
}

function aD(e, t, n, r) {
    let o = C(),
        i = Y(),
        s = Br(2);
    if (i.firstUpdatePass && uD(i, e, s, r), t !== ce && Le(o, s, t)) {
        let a = i.data[qe()];
        fD(i, a, o, o[W], e, o[s + 1] = FM(t, n), r, s)
    }
}

function cD(e, t, n, r) {
    let o = Y(),
        i = Br(2);
    o.firstUpdatePass && uD(o, null, i, r);
    let s = C();
    if (n !== ce && Le(s, i, n)) {
        let a = o.data[qe()];
        if (pD(a, r) && !lD(o, i)) {
            let c = r ? a.classesWithoutHost : a.stylesWithoutHost;
            c !== null && (n = Ja(c, n || "")), pp(o, a, s, n, r)
        } else kM(o, a, s, s[W], s[i + 1], s[i + 1] = PM(e, t, n), r, i)
    }
}

function lD(e, t) {
    return t >= e.expandoStartIndex
}

function uD(e, t, n, r) {
    let o = e.data;
    if (o[n + 1] === null) {
        let i = o[qe()],
            s = lD(e, n);
        pD(i, r) && t === null && !s && (t = !1), t = MM(o, i, t, r), EM(o, i, t, n, s, r)
    }
}

function MM(e, t, n, r) {
    let o = jE(e),
        i = r ? t.residualClasses : t.residualStyles;
    if (o === null)(r ? t.classBindings : t.styleBindings) === 0 && (n = Mf(null, e, t, n, r), n = is(n, t.attrs, r), i = null);
    else {
        let s = t.directiveStylingLast;
        if (s === -1 || e[s] !== o)
            if (n = Mf(o, e, t, n, r), i === null) {
                let c = NM(e, t, r);
                c !== void 0 && Array.isArray(c) && (c = Mf(null, e, t, c[1], r), c = is(c, t.attrs, r), RM(e, t, r, c))
            } else i = OM(e, t, r)
    }
    return i !== void 0 && (r ? t.residualClasses = i : t.residualStyles = i), n
}

function NM(e, t, n) {
    let r = n ? t.classBindings : t.styleBindings;
    if (jo(r) !== 0) return e[qr(r)]
}

function RM(e, t, n, r) {
    let o = n ? t.classBindings : t.styleBindings;
    e[qr(o)] = r
}

function OM(e, t, n) {
    let r, o = t.directiveEnd;
    for (let i = 1 + t.directiveStylingLast; i < o; i++) {
        let s = e[i].hostAttrs;
        r = is(r, s, n)
    }
    return is(r, t.attrs, n)
}

function Mf(e, t, n, r, o) {
    let i = null,
        s = n.directiveEnd,
        a = n.directiveStylingLast;
    for (a === -1 ? a = n.directiveStart : a++; a < s && (i = t[a], r = is(r, i.hostAttrs, o), i !== e);) a++;
    return e !== null && (n.directiveStylingLast = a), r
}

function is(e, t, n) {
    let r = n ? 1 : 2,
        o = -1;
    if (t !== null)
        for (let i = 0; i < t.length; i++) {
            let s = t[i];
            typeof s == "number" ? o = s : o === r && (Array.isArray(e) || (e = e === void 0 ? [] : ["", e]), Ui(e, s, n ? !0 : t[++i]))
        }
    return e === void 0 ? null : e
}

function PM(e, t, n) {
    if (n == null || n === "") return Oe;
    let r = [],
        o = Ve(n);
    if (Array.isArray(o))
        for (let i = 0; i < o.length; i++) e(r, o[i], !0);
    else if (o instanceof Set)
        for (let i of o) e(r, i, !0);
    else if (typeof o == "object")
        for (let i in o) o.hasOwnProperty(i) && e(r, i, o[i]);
    else typeof o == "string" && t(r, o);
    return r
}

function dD(e, t, n) {
    Ui(e, t, Ve(n))
}

function LM(e, t, n) {
    let r = String(t);
    r !== "" && !r.includes(" ") && Ui(e, r, n)
}

function kM(e, t, n, r, o, i, s, a) {
    o === ce && (o = Oe);
    let c = 0,
        l = 0,
        u = 0 < o.length ? o[0] : null,
        d = 0 < i.length ? i[0] : null;
    for (; u !== null || d !== null;) {
        let f = c < o.length ? o[c + 1] : void 0,
            p = l < i.length ? i[l + 1] : void 0,
            m = null,
            x;
        u === d ? (c += 2, l += 2, f !== p && (m = d, x = p)) : d === null || u !== null && u < d ? (c += 2, m = u) : (l += 2, m = d, x = p), m !== null && fD(e, t, n, r, m, x, s, a), u = c < o.length ? o[c] : null, d = l < i.length ? i[l] : null
    }
}

function fD(e, t, n, r, o, i, s, a) {
    if (!(t.type & 3)) return;
    let c = e.data,
        l = c[a + 1],
        u = gM(l) ? Ly(c, t, n, o, jo(l), s) : void 0;
    if (!qc(u)) {
        qc(i) || hM(l) && (i = Ly(c, null, n, o, a, s));
        let d = Zd(qe(), n);
        aw(r, s, d, o, i)
    }
}

function Ly(e, t, n, r, o, i) {
    let s = t === null,
        a;
    for (; o > 0;) {
        let c = e[o],
            l = Array.isArray(c),
            u = l ? c[1] : c,
            d = u === null,
            f = n[o + 1];
        f === ce && (f = d ? Oe : void 0);
        let p = d ? nc(f, r) : u === r ? f : void 0;
        if (l && !qc(p) && (p = nc(c, r)), qc(p) && (a = p, s)) return a;
        let m = e[o + 1];
        o = s ? qr(m) : jo(m)
    }
    if (t !== null) {
        let c = i ? t.residualClasses : t.residualStyles;
        c != null && (a = nc(c, r))
    }
    return a
}

function qc(e) {
    return e !== void 0
}

function FM(e, t) {
    return e == null || e === "" || (typeof t == "string" ? e = e + t : typeof e == "object" && (e = Li(Ve(e)))), e
}

function pD(e, t) {
    return (e.flags & (t ? 8 : 16)) !== 0
}

function UM(e, t = "") {
    let n = C(),
        r = Y(),
        o = e + z,
        i = r.firstCreatePass ? Kr(r, o, 1, t, null) : r.data[o],
        s = BM(r, n, i, t);
    n[o] = s, fc() && kp(r, n, s, i), Ur(i, !1)
}
var BM = (e, t, n, r) => (zi(!0), ab(t[W], r));

function hD(e, t, n, r = "") {
    return Le(e, xn(), n) ? t + pe(n) + r : ce
}

function mD(e, t, n, r, o, i = "") {
    let s = $i(),
        a = Wr(e, s, n, o);
    return Br(2), a ? t + pe(n) + r + pe(o) + i : ce
}

function jM(e, t, n, r, o, i, s, a = "") {
    let c = $i(),
        l = Ev(e, c, n, o, s);
    return Br(3), l ? t + pe(n) + r + pe(o) + i + pe(s) + a : ce
}

function HM(e, t, n, r, o, i, s, a, c, l = "") {
    let u = $i(),
        d = ys(e, u, n, o, s, c);
    return Br(4), d ? t + pe(n) + r + pe(o) + i + pe(s) + a + pe(c) + l : ce
}

function VM(e, t, n, r, o, i, s, a, c, l, u, d, f, p = "") {
    let m = $i(),
        x = ys(e, m, n, o, s, c);
    return x = Wr(e, m + 4, u, f) || x, Br(6), x ? t + pe(n) + r + pe(o) + i + pe(s) + a + pe(c) + l + pe(u) + d + pe(f) + p : ce
}

function gD(e) {
    return dh("", e), gD
}

function dh(e, t, n) {
    let r = C(),
        o = hD(r, e, t, n);
    return o !== ce && _s(r, qe(), o), dh
}

function ED(e, t, n, r, o) {
    let i = C(),
        s = mD(i, e, t, n, r, o);
    return s !== ce && _s(i, qe(), s), ED
}

function yD(e, t, n, r, o, i, s) {
    let a = C(),
        c = jM(a, e, t, n, r, o, i, s);
    return c !== ce && _s(a, qe(), c), yD
}

function vD(e, t, n, r, o, i, s, a, c) {
    let l = C(),
        u = HM(l, e, t, n, r, o, i, s, a, c);
    return u !== ce && _s(l, qe(), u), vD
}

function DD(e, t, n, r, o, i, s, a, c, l, u, d, f) {
    let p = C(),
        m = VM(p, e, t, n, r, o, i, s, a, c, l, u, d, f);
    return m !== ce && _s(p, qe(), m), DD
}

function _s(e, t, n) {
    let r = Zd(t, e);
    cb(e[W], r, n)
}

function _D(e, t, n) {
    Xp(t) && (t = t());
    let r = C(),
        o = xn();
    if (Le(r, o, t)) {
        let i = Y(),
            s = Wi();
        Y0(s, r, e, t, r[W], n)
    }
    return _D
}

function $M(e, t) {
    let n = Xp(e);
    return n && e.set(t), n
}

function xD(e, t) {
    let n = C(),
        r = Y(),
        o = he();
    return Xv(r, n, n[W], o, e, t), xD
}
var CD = {};

function ID(e) {
    Ye("NgLet");
    let t = Y(),
        n = C(),
        r = e + z,
        o = Kr(t, r, 128, null, null);
    return Ur(o, !1), Hi(t, n, r, CD), ID
}

function GM(e) {
    let t = Y(),
        n = C(),
        r = qe();
    return Hi(t, n, r, e), e
}

function WM(e) {
    let t = ff(),
        n = No(t, z + e);
    if (n === CD) throw new g(314, !1);
    return n
}

function zM(e) {
    return Le(C(), xn(), e) ? pe(e) : ce
}

function qM(e, t, n = "") {
    return hD(C(), e, t, n)
}

function KM(e, t, n, r, o = "") {
    return mD(C(), e, t, n, r, o)
}

function ky(e, t, n) {
    let r = Y();
    r.firstCreatePass && TD(t, r.data, r.blueprint, Xt(e), n)
}

function TD(e, t, n, r, o) {
    if (e = Se(e), Array.isArray(e))
        for (let i = 0; i < e.length; i++) TD(e[i], t, n, r, o);
    else {
        let i = Y(),
            s = C(),
            a = he(),
            c = wr(e) ? e : Se(e.provide),
            l = Wd(e),
            u = a.providerIndexes & 1048575,
            d = a.directiveStart,
            f = a.providerIndexes >> 20;
        if (wr(e) || !e.multi) {
            let p = new Vr(l, o, k, null),
                m = Rf(c, t, o ? u : u + f, d);
            m === -1 ? (Pf(Mc(a, s), i, c), Nf(i, e, t.length), t.push(c), a.directiveStart++, a.directiveEnd++, o && (a.providerIndexes += 1048576), n.push(p), s.push(p)) : (n[m] = p, s[m] = p)
        } else {
            let p = Rf(c, t, u + f, d),
                m = Rf(c, t, u, u + f),
                x = p >= 0 && n[p],
                D = m >= 0 && n[m];
            if (o && !D || !o && !x) {
                Pf(Mc(a, s), i, c);
                let I = QM(o ? JM : YM, n.length, o, r, l, e);
                !o && D && (n[m].providerFactory = I), Nf(i, e, t.length, 0), t.push(c), a.directiveStart++, a.directiveEnd++, o && (a.providerIndexes += 1048576), n.push(I), s.push(I)
            } else {
                let I = SD(n[o ? m : p], l, !o && r);
                Nf(i, e, p > -1 ? p : m, I)
            }!o && r && D && n[m].componentProviders++
        }
    }
}

function Nf(e, t, n, r) {
    let o = wr(t),
        i = CE(t);
    if (o || i) {
        let c = (i ? Se(t.useClass) : t).prototype.ngOnDestroy;
        if (c) {
            let l = e.destroyHooks || (e.destroyHooks = []);
            if (!o && t.multi) {
                let u = l.indexOf(n);
                u === -1 ? l.push(n, [r, c]) : l[u + 1].push(r, c)
            } else l.push(n, c)
        }
    }
}

function SD(e, t, n) {
    return n && e.componentProviders++, e.multi.push(t) - 1
}

function Rf(e, t, n, r) {
    for (let o = n; o < r; o++)
        if (t[o] === e) return o;
    return -1
}

function YM(e, t, n, r, o) {
    return gp(this.multi, [])
}

function JM(e, t, n, r, o) {
    let i = this.multi,
        s;
    if (this.providerFactory) {
        let a = this.providerFactory.componentProviders,
            c = Xi(r, r[b], this.providerFactory.index, o);
        s = c.slice(0, a), gp(i, s);
        for (let l = a; l < c.length; l++) s.push(c[l])
    } else s = [], gp(i, s);
    return s
}

function gp(e, t) {
    for (let n = 0; n < e.length; n++) {
        let r = e[n];
        t.push(r())
    }
    return t
}

function QM(e, t, n, r, o, i) {
    let s = new Vr(e, n, k, null);
    return s.multi = [], s.index = t, s.componentProviders = 0, SD(s, o, r && !n), s
}

function ZM(e, t) {
    return n => {
        n.providersResolver = (r, o) => ky(r, o ? o(e) : e, !1), t && (n.viewProvidersResolver = (r, o) => ky(r, o ? o(t) : t, !0))
    }
}

function XM(e, t, n) {
    let r = e.\u0275cmp;
    r.directiveDefs = $c(t, Pv), r.pipeDefs = $c(n, Fd)
}

function eN(e, t) {
    let n = yt() + e,
        r = C();
    return r[n] === ce ? or(r, n, t()) : zp(r, n)
}

function tN(e, t, n) {
    return bD(C(), yt(), e, t, n)
}

function nN(e, t, n, r) {
    return wD(C(), yt(), e, t, n, r)
}

function rN(e, t, n, r, o) {
    return AD(C(), yt(), e, t, n, r, o)
}

function oN(e, t, n, r, o, i, s) {
    return cN(C(), yt(), e, t, n, r, o, i)
}

function iN(e, t, n, r, o, i, s) {
    let a = yt() + e,
        c = C(),
        l = ys(c, a, n, r, o, i);
    return Le(c, a + 4, s) || l ? or(c, a + 5, t(n, r, o, i, s)) : zp(c, a + 5)
}

function sN(e, t, n, r, o, i, s, a) {
    let c = yt() + e,
        l = C(),
        u = ys(l, c, n, r, o, i);
    return Wr(l, c + 4, s, a) || u ? or(l, c + 6, t(n, r, o, i, s, a)) : zp(l, c + 6)
}

function aN(e, t, n) {
    return lN(C(), yt(), e, t, n)
}

function xs(e, t) {
    let n = e[t];
    return n === ce ? void 0 : n
}

function bD(e, t, n, r, o, i) {
    let s = t + n;
    return Le(e, s, o) ? or(e, s + 1, i ? r.call(i, o) : r(o)) : xs(e, s + 1)
}

function wD(e, t, n, r, o, i, s) {
    let a = t + n;
    return Wr(e, a, o, i) ? or(e, a + 2, s ? r.call(s, o, i) : r(o, i)) : xs(e, a + 2)
}

function AD(e, t, n, r, o, i, s, a) {
    let c = t + n;
    return Ev(e, c, o, i, s) ? or(e, c + 3, a ? r.call(a, o, i, s) : r(o, i, s)) : xs(e, c + 3)
}

function cN(e, t, n, r, o, i, s, a, c) {
    let l = t + n;
    return ys(e, l, o, i, s, a) ? or(e, l + 4, c ? r.call(c, o, i, s, a) : r(o, i, s, a)) : xs(e, l + 4)
}

function lN(e, t, n, r, o, i) {
    let s = t + n,
        a = !1;
    for (let c = 0; c < o.length; c++) Le(e, s++, o[c]) && (a = !0);
    return a ? or(e, s, r.apply(i, o)) : xs(e, s)
}

function uN(e, t) {
    let n = Y(),
        r, o = e + z;
    n.firstCreatePass ? (r = dN(t, n.pipeRegistry), n.data[o] = r, r.onDestroy && (n.destroyHooks ? ? = []).push(o, r.onDestroy)) : r = n.data[o];
    let i = r.factory || (r.factory = Kn(r.type, !0)),
        s, a = Be(k);
    try {
        let c = Ac(!1),
            l = i();
        return Ac(c), Hi(n, C(), o, l), l
    } finally {
        Be(a)
    }
}

function dN(e, t) {
    if (t)
        for (let n = t.length - 1; n >= 0; n--) {
            let r = t[n];
            if (e === r.name) return r
        }
}

function fN(e, t, n) {
    let r = e + z,
        o = C(),
        i = No(o, r);
    return fh(o, r) ? bD(o, yt(), t, i.transform, n, i) : i.transform(n)
}

function pN(e, t, n, r) {
    let o = e + z,
        i = C(),
        s = No(i, o);
    return fh(i, o) ? wD(i, yt(), t, s.transform, n, r, s) : s.transform(n, r)
}

function hN(e, t, n, r, o) {
    let i = e + z,
        s = C(),
        a = No(s, i);
    return fh(s, i) ? AD(s, yt(), t, a.transform, n, r, o, a) : a.transform(n, r, o)
}

function fh(e, t) {
    return e[b].data[t].pure
}

function mN(e, t) {
    return ul(e, t)
}
var vc = null;

function MD(e) {
    vc !== null && (e.defaultEncapsulation !== vc.defaultEncapsulation || e.preserveWhitespaces !== vc.preserveWhitespaces) || (vc = e)
}
var Kc = class {
        ngModuleFactory;
        componentFactories;
        constructor(t, n) {
            this.ngModuleFactory = t, this.componentFactories = n
        }
    },
    ph = (() => {
        class e {
            compileModuleSync(n) {
                return new rs(n)
            }
            compileModuleAsync(n) {
                return Promise.resolve(this.compileModuleSync(n))
            }
            compileModuleAndAllComponentsSync(n) {
                let r = this.compileModuleSync(n),
                    o = Ld(n),
                    i = b0(o.declarations).reduce((s, a) => {
                        let c = Qt(a);
                        return c && s.push(new rr(c)), s
                    }, []);
                return new Kc(r, i)
            }
            compileModuleAndAllComponentsAsync(n) {
                return Promise.resolve(this.compileModuleAndAllComponentsSync(n))
            }
            clearCache() {}
            clearCacheFor(n) {}
            getModuleId(n) {}
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    ND = new v("");
var RD = (() => {
    class e {
        applicationErrorHandler = h(Ke);
        appRef = h(Bt);
        taskService = h(en);
        ngZone = h(Q);
        zonelessEnabled = h(Ro);
        tracing = h(sn, {
            optional: !0
        });
        zoneIsDefined = typeof Zone < "u" && !!Zone.root.run;
        schedulerTickApplyArgs = [{
            data: {
                __scheduler_tick__: !0
            }
        }];
        subscriptions = new oe;
        angularZoneId = this.zoneIsDefined ? this.ngZone._inner ? .get(Oi) : null;
        scheduleInRootZone = !this.zonelessEnabled && this.zoneIsDefined && (h(pc, {
            optional: !0
        }) ? ? !1);
        cancelScheduledCallback = null;
        useMicrotaskScheduler = !1;
        runningTick = !1;
        pendingRenderTaskId = null;
        constructor() {
            this.subscriptions.add(this.appRef.afterTick.subscribe(() => {
                let n = this.taskService.add();
                if (!this.runningTick && (this.cleanup(), !this.zonelessEnabled || this.appRef.includeAllTestViews)) {
                    this.taskService.remove(n);
                    return
                }
                this.switchToMicrotaskScheduler(), this.taskService.remove(n)
            })), this.subscriptions.add(this.ngZone.onUnstable.subscribe(() => {
                this.runningTick || this.cleanup()
            }))
        }
        switchToMicrotaskScheduler() {
            this.ngZone.runOutsideAngular(() => {
                let n = this.taskService.add();
                this.useMicrotaskScheduler = !0, queueMicrotask(() => {
                    this.useMicrotaskScheduler = !1, this.taskService.remove(n)
                })
            })
        }
        notify(n) {
            if (!this.zonelessEnabled && n === 5) return;
            switch (n) {
                case 0:
                    {
                        this.appRef.dirtyFlags |= 2;
                        break
                    }
                case 3:
                case 2:
                case 4:
                case 5:
                case 1:
                    {
                        this.appRef.dirtyFlags |= 4;
                        break
                    }
                case 6:
                    {
                        this.appRef.dirtyFlags |= 2;
                        break
                    }
                case 12:
                    {
                        this.appRef.dirtyFlags |= 16;
                        break
                    }
                case 13:
                    {
                        this.appRef.dirtyFlags |= 2;
                        break
                    }
                case 11:
                    break;
                default:
                    this.appRef.dirtyFlags |= 8
            }
            if (this.appRef.tracingSnapshot = this.tracing ? .snapshot(this.appRef.tracingSnapshot) ? ? null, !this.shouldScheduleTick()) return;
            let r = this.useMicrotaskScheduler ? YE : vf;
            this.pendingRenderTaskId = this.taskService.add(), this.scheduleInRootZone ? this.cancelScheduledCallback = Zone.root.run(() => r(() => this.tick())) : this.cancelScheduledCallback = this.ngZone.runOutsideAngular(() => r(() => this.tick()))
        }
        shouldScheduleTick() {
            return !(this.appRef.destroyed || this.pendingRenderTaskId !== null || this.runningTick || this.appRef._runningTick || !this.zonelessEnabled && this.zoneIsDefined && Zone.current.get(Oi + this.angularZoneId))
        }
        tick() {
            if (this.runningTick || this.appRef.destroyed) return;
            if (this.appRef.dirtyFlags === 0) {
                this.cleanup();
                return
            }!this.zonelessEnabled && this.appRef.dirtyFlags & 7 && (this.appRef.dirtyFlags |= 1);
            let n = this.taskService.add();
            try {
                this.ngZone.run(() => {
                    this.runningTick = !0, this.appRef._tick()
                }, void 0, this.schedulerTickApplyArgs)
            } catch (r) {
                this.applicationErrorHandler(r)
            } finally {
                this.taskService.remove(n), this.cleanup()
            }
        }
        ngOnDestroy() {
            this.subscriptions.unsubscribe(), this.cleanup()
        }
        cleanup() {
            if (this.runningTick = !1, this.cancelScheduledCallback ? .(), this.cancelScheduledCallback = null, this.pendingRenderTaskId !== null) {
                let n = this.pendingRenderTaskId;
                this.pendingRenderTaskId = null, this.taskService.remove(n)
            }
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
        })
    }
    return e
})();

function OD() {
    return [{
        provide: Jt,
        useExisting: RD
    }, {
        provide: Q,
        useClass: Pi
    }, {
        provide: Ro,
        useValue: !0
    }]
}

function gN() {
    return typeof $localize < "u" && $localize.locale || Ds
}
var Wo = new v("", {
    factory: () => h(Wo, {
        optional: !0,
        skipSelf: !0
    }) || gN()
});
var Cs = class {
    destroyed = !1;
    listeners = null;
    errorHandler = h(ut, {
        optional: !0
    });
    destroyRef = h(He);
    constructor() {
        this.destroyRef.onDestroy(() => {
            this.destroyed = !0, this.listeners = null
        })
    }
    subscribe(t) {
        if (this.destroyed) throw new g(953, !1);
        return (this.listeners ? ? = []).push(t), {
            unsubscribe: () => {
                let n = this.listeners ? .indexOf(t);
                n !== void 0 && n !== -1 && this.listeners ? .splice(n, 1)
            }
        }
    }
    emit(t) {
        if (this.destroyed) {
            console.warn(dt(953, !1));
            return
        }
        if (this.listeners === null) return;
        let n = S(null);
        try {
            for (let r of this.listeners) try {
                r(t)
            } catch (o) {
                this.errorHandler ? .handleError(o)
            }
        } finally {
            S(n)
        }
    }
};

function te(e) {
    return aE(e)
}

function Is(e, t) {
    return Ci(e, t ? .equal)
}
var EN = e => e;

function hh(e, t) {
    if (typeof e == "function") {
        let n = md(e, EN, t ? .equal);
        return PD(n, t ? .debugName)
    } else {
        let n = md(e.source, e.computation, e.equal);
        return PD(n, e.debugName)
    }
}

function PD(e, t) {
    let n = e[ue],
        r = e;
    return r.set = o => iE(n, o), r.update = o => sE(n, o), r.asReadonly = qi.bind(e), r
}
var Al = Symbol("InputSignalNode#UNSET"),
    GD = B(E({}, ha), {
        transformFn: void 0,
        applyValueToInputSignal(e, t) {
            Gn(e, t)
        }
    });

function WD(e, t) {
    let n = Object.create(GD);
    n.value = e, n.transformFn = t ? .transform;

    function r() {
        if (Vn(n), n.value === Al) {
            let o = null;
            throw new g(-950, o)
        }
        return n.value
    }
    return r[ue] = n, r
}
var Sl = class {
    attributeName;
    constructor(t) {
        this.attributeName = t
    }
    __NG_ELEMENT_ID__ = () => cs(this.attributeName);
    toString() {
        return `HostAttributeToken ${this.attributeName}`
    }
};

function c5(e) {
    return new Cs
}

function LD(e, t) {
    return WD(e, t)
}

function TN(e) {
    return WD(Al, e)
}
var zD = (LD.required = TN, LD);

function kD(e, t) {
    return wv(t)
}

function SN(e, t) {
    return Av(t)
}
var l5 = (kD.required = SN, kD);

function u5(e, t) {
    return Mv(t)
}

function qD(e, t) {
    let n = Object.create(GD),
        r = new Cs;
    n.value = e;

    function o() {
        return Vn(n), FD(n.value), n.value
    }
    return o[ue] = n, o.asReadonly = qi.bind(o), o.set = i => {
        n.equal(n.value, i) || (Gn(n, i), r.emit(i))
    }, o.update = i => {
        FD(n.value), o.set(i(n.value))
    }, o.subscribe = r.subscribe.bind(r), o.destroyRef = r.destroyRef, o
}

function FD(e) {
    if (e === Al) throw new g(952, !1)
}

function UD(e, t) {
    return qD(e, t)
}

function bN(e) {
    return qD(Al, e)
}
var d5 = (UD.required = bN, UD);

function wN(e, t, n) {
    let r = new rs(n);
    return Promise.resolve(r)
}

function BD(e) {
    for (let t = e.length - 1; t >= 0; t--)
        if (e[t] !== void 0) return e[t]
}
var AN = (() => {
        class e {
            zone = h(Q);
            changeDetectionScheduler = h(Jt);
            applicationRef = h(Bt);
            applicationErrorHandler = h(Ke);
            _onMicrotaskEmptySubscription;
            initialize() {
                this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({
                    next: () => {
                        this.changeDetectionScheduler.runningTick || this.zone.run(() => {
                            try {
                                this.applicationRef.dirtyFlags |= 1, this.applicationRef._tick()
                            } catch (n) {
                                this.applicationErrorHandler(n)
                            }
                        })
                    }
                }))
            }
            ngOnDestroy() {
                this._onMicrotaskEmptySubscription ? .unsubscribe()
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    MN = new v("", {
        factory: () => !1
    });

function NN({
    ngZoneFactory: e,
    scheduleInRootZone: t
}) {
    return e ? ? = () => new Q(B(E({}, KD()), {
        scheduleInRootZone: t
    })), [{
        provide: Ro,
        useValue: !1
    }, {
        provide: Q,
        useFactory: e
    }, {
        provide: En,
        multi: !0,
        useFactory: () => {
            let n = h(AN, {
                optional: !0
            });
            return () => n.initialize()
        }
    }, {
        provide: En,
        multi: !0,
        useFactory: () => {
            let n = h(RN);
            return () => {
                n.initialize()
            }
        }
    }, {
        provide: pc,
        useValue: t ? ? yf
    }]
}

function f5(e) {
    let t = e ? .scheduleInRootZone,
        n = NN({
            ngZoneFactory: () => {
                let r = KD(e);
                return r.scheduleInRootZone = t, r.shouldCoalesceEventChangeDetection && Ye("NgZone_CoalesceEvent"), new Q(r)
            },
            scheduleInRootZone: t
        });
    return Zn([{
        provide: MN,
        useValue: !0
    }, n])
}

function KD(e) {
    return {
        enableLongStackTrace: !1,
        shouldCoalesceEventChangeDetection: e ? .eventCoalescing ? ? !1,
        shouldCoalesceRunChangeDetection: e ? .runCoalescing ? ? !1
    }
}
var RN = (() => {
    class e {
        subscription = new oe;
        initialized = !1;
        zone = h(Q);
        pendingTasks = h(en);
        initialize() {
            if (this.initialized) return;
            this.initialized = !0;
            let n = null;
            !this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => {
                this.subscription.add(this.zone.onStable.subscribe(() => {
                    Q.assertNotInAngularZone(), queueMicrotask(() => {
                        n !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null)
                    })
                }))
            }), this.subscription.add(this.zone.onUnstable.subscribe(() => {
                Q.assertInAngularZone(), n ? ? = this.pendingTasks.add()
            }))
        }
        ngOnDestroy() {
            this.subscription.unsubscribe()
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
        })
    }
    return e
})();
var bl = new v(""),
    ON = new v("");

function Ts(e) {
    return !e.moduleRef
}

function PN(e) {
    let t = Ts(e) ? e.r3Injector : e.moduleRef.injector,
        n = t.get(Q);
    return n.run(() => {
        Ts(e) ? e.r3Injector.resolveInjectorInitializers() : e.moduleRef.resolveInjectorInitializers();
        let r = t.get(Ke),
            o;
        if (n.runOutsideAngular(() => {
                o = n.onError.subscribe({
                    next: r
                })
            }), Ts(e)) {
            let i = () => t.destroy(),
                s = e.platformInjector.get(bl);
            s.add(i), t.onDestroy(() => {
                o.unsubscribe(), s.delete(i)
            })
        } else {
            let i = () => e.moduleRef.destroy(),
                s = e.platformInjector.get(bl);
            s.add(i), e.moduleRef.onDestroy(() => {
                Zi(e.allPlatformModules, e.moduleRef), o.unsubscribe(), s.delete(i)
            })
        }
        return kN(r, n, () => {
            let i = t.get(en),
                s = i.add(),
                a = t.get(nh);
            return a.runInitializers(), a.donePromise.then(() => {
                let c = t.get(Wo, Ds);
                if (Qv(c || Ds), !t.get(ON, !0)) return Ts(e) ? t.get(Bt) : (e.allPlatformModules.push(e.moduleRef), e.moduleRef);
                if (Ts(e)) {
                    let u = t.get(Bt);
                    return e.rootComponent !== void 0 && u.bootstrap(e.rootComponent), u
                } else return YD ? .(e.moduleRef, e.allPlatformModules), e.moduleRef
            }).finally(() => {
                i.remove(s)
            })
        })
    })
}
var YD;

function jD() {
    YD = LN
}

function LN(e, t) {
    let n = e.injector.get(Bt);
    if (e._bootstrapComponents.length > 0) e._bootstrapComponents.forEach(r => n.bootstrap(r));
    else if (e.instance.ngDoBootstrap) e.instance.ngDoBootstrap(n);
    else throw new g(-403, !1);
    t.push(e)
}

function kN(e, t, n) {
    try {
        let r = n();
        return Yr(r) ? r.catch(o => {
            throw t.runOutsideAngular(() => e(o)), o
        }) : r
    } catch (r) {
        throw t.runOutsideAngular(() => e(r)), r
    }
}
var JD = (() => {
        class e {
            _injector;
            _modules = [];
            _destroyListeners = [];
            _destroyed = !1;
            constructor(n) {
                this._injector = n
            }
            bootstrapModuleFactory(n, r) {
                let o = [OD(), ...r ? .applicationProviders ? ? [], QE],
                    i = Ov(n.moduleType, this.injector, o);
                return jD(), PN({
                    moduleRef: i,
                    allPlatformModules: this._modules,
                    platformInjector: this.injector
                })
            }
            bootstrapModule(n, r = []) {
                let o = rh({}, r);
                return jD(), wN(this.injector, o, n).then(i => this.bootstrapModuleFactory(i, o))
            }
            onDestroy(n) {
                this._destroyListeners.push(n)
            }
            get injector() {
                return this._injector
            }
            destroy() {
                if (this._destroyed) throw new g(404, !1);
                this._modules.slice().forEach(r => r.destroy()), this._destroyListeners.forEach(r => r());
                let n = this._injector.get(bl, null);
                n && (n.forEach(r => r()), n.clear()), this._destroyed = !0
            }
            get destroyed() {
                return this._destroyed
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(fe))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "platform"
            })
        }
        return e
    })(),
    xh = null;

function FN(e) {
    if (Ih()) throw new g(400, !1);
    Vv(), xh = e;
    let t = e.get(JD);
    return jN(e), t
}

function Ch(e, t, n = []) {
    let r = `Platform: ${t}`,
        o = new v(r);
    return (i = []) => {
        let s = Ih();
        if (!s) {
            let a = [...n, ...i, {
                provide: o,
                useValue: !0
            }];
            s = e ? .(a) ? ? FN(UN(a, r))
        }
        return BN(o)
    }
}

function UN(e = [], t) {
    return fe.create({
        name: t,
        providers: [{
            provide: Bi,
            useValue: "platform"
        }, {
            provide: bl,
            useValue: new Set([() => xh = null])
        }, ...e]
    })
}

function BN(e) {
    let t = Ih();
    if (!t) throw new g(-401, !1);
    return t
}

function Ih() {
    return xh ? .get(JD) ? ? null
}

function jN(e) {
    let t = e.get(Yc, null);
    _e(e, () => {
        t ? .forEach(n => n())
    })
}
var HN = 1e4;
var p5 = HN - 1e3;
var ir = (() => {
    class e {
        static __NG_ELEMENT_ID__ = VN
    }
    return e
})();

function VN(e) {
    return $N(he(), C(), (e & 16) === 16)
}

function $N(e, t, n) {
    if (_n(e) && !n) {
        let r = gt(e.index, t);
        return new nr(r, r)
    } else if (e.type & 175) {
        let r = t[Pe];
        return new nr(r, t)
    }
    return null
}
var mh = class {
        supports(t) {
            return Wp(t)
        }
        create(t) {
            return new gh(t)
        }
    },
    GN = (e, t) => t,
    gh = class {
        length = 0;
        collection;
        _linkedRecords = null;
        _unlinkedRecords = null;
        _previousItHead = null;
        _itHead = null;
        _itTail = null;
        _additionsHead = null;
        _additionsTail = null;
        _movesHead = null;
        _movesTail = null;
        _removalsHead = null;
        _removalsTail = null;
        _identityChangesHead = null;
        _identityChangesTail = null;
        _trackByFn;
        constructor(t) {
            this._trackByFn = t || GN
        }
        forEachItem(t) {
            let n;
            for (n = this._itHead; n !== null; n = n._next) t(n)
        }
        forEachOperation(t) {
            let n = this._itHead,
                r = this._removalsHead,
                o = 0,
                i = null;
            for (; n || r;) {
                let s = !r || n && n.currentIndex < HD(r, o, i) ? n : r,
                    a = HD(s, o, i),
                    c = s.currentIndex;
                if (s === r) o--, r = r._nextRemoved;
                else if (n = n._next, s.previousIndex == null) o++;
                else {
                    i || (i = []);
                    let l = a - o,
                        u = c - o;
                    if (l != u) {
                        for (let f = 0; f < l; f++) {
                            let p = f < i.length ? i[f] : i[f] = 0,
                                m = p + f;
                            u <= m && m < l && (i[f] = p + 1)
                        }
                        let d = s.previousIndex;
                        i[d] = u - l
                    }
                }
                a !== c && t(s, a, c)
            }
        }
        forEachPreviousItem(t) {
            let n;
            for (n = this._previousItHead; n !== null; n = n._nextPrevious) t(n)
        }
        forEachAddedItem(t) {
            let n;
            for (n = this._additionsHead; n !== null; n = n._nextAdded) t(n)
        }
        forEachMovedItem(t) {
            let n;
            for (n = this._movesHead; n !== null; n = n._nextMoved) t(n)
        }
        forEachRemovedItem(t) {
            let n;
            for (n = this._removalsHead; n !== null; n = n._nextRemoved) t(n)
        }
        forEachIdentityChange(t) {
            let n;
            for (n = this._identityChangesHead; n !== null; n = n._nextIdentityChange) t(n)
        }
        diff(t) {
            if (t == null && (t = []), !Wp(t)) throw new g(900, !1);
            return this.check(t) ? this : null
        }
        onDestroy() {}
        check(t) {
            this._reset();
            let n = this._itHead,
                r = !1,
                o, i, s;
            if (Array.isArray(t)) {
                this.length = t.length;
                for (let a = 0; a < this.length; a++) i = t[a], s = this._trackByFn(a, i), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, i, s, a), r = !0) : (r && (n = this._verifyReinsertion(n, i, s, a)), Object.is(n.item, i) || this._addIdentityChange(n, i)), n = n._next
            } else o = 0, gv(t, a => {
                s = this._trackByFn(o, a), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, a, s, o), r = !0) : (r && (n = this._verifyReinsertion(n, a, s, o)), Object.is(n.item, a) || this._addIdentityChange(n, a)), n = n._next, o++
            }), this.length = o;
            return this._truncate(n), this.collection = t, this.isDirty
        }
        get isDirty() {
            return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null
        }
        _reset() {
            if (this.isDirty) {
                let t;
                for (t = this._previousItHead = this._itHead; t !== null; t = t._next) t._nextPrevious = t._next;
                for (t = this._additionsHead; t !== null; t = t._nextAdded) t.previousIndex = t.currentIndex;
                for (this._additionsHead = this._additionsTail = null, t = this._movesHead; t !== null; t = t._nextMoved) t.previousIndex = t.currentIndex;
                this._movesHead = this._movesTail = null, this._removalsHead = this._removalsTail = null, this._identityChangesHead = this._identityChangesTail = null
            }
        }
        _mismatch(t, n, r, o) {
            let i;
            return t === null ? i = this._itTail : (i = t._prev, this._remove(t)), t = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(r, null), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._reinsertAfter(t, i, o)) : (t = this._linkedRecords === null ? null : this._linkedRecords.get(r, o), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._moveAfter(t, i, o)) : t = this._addAfter(new Eh(n, r), i, o)), t
        }
        _verifyReinsertion(t, n, r, o) {
            let i = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(r, null);
            return i !== null ? t = this._reinsertAfter(i, t._prev, o) : t.currentIndex != o && (t.currentIndex = o, this._addToMoves(t, o)), t
        }
        _truncate(t) {
            for (; t !== null;) {
                let n = t._next;
                this._addToRemovals(this._unlink(t)), t = n
            }
            this._unlinkedRecords !== null && this._unlinkedRecords.clear(), this._additionsTail !== null && (this._additionsTail._nextAdded = null), this._movesTail !== null && (this._movesTail._nextMoved = null), this._itTail !== null && (this._itTail._next = null), this._removalsTail !== null && (this._removalsTail._nextRemoved = null), this._identityChangesTail !== null && (this._identityChangesTail._nextIdentityChange = null)
        }
        _reinsertAfter(t, n, r) {
            this._unlinkedRecords !== null && this._unlinkedRecords.remove(t);
            let o = t._prevRemoved,
                i = t._nextRemoved;
            return o === null ? this._removalsHead = i : o._nextRemoved = i, i === null ? this._removalsTail = o : i._prevRemoved = o, this._insertAfter(t, n, r), this._addToMoves(t, r), t
        }
        _moveAfter(t, n, r) {
            return this._unlink(t), this._insertAfter(t, n, r), this._addToMoves(t, r), t
        }
        _addAfter(t, n, r) {
            return this._insertAfter(t, n, r), this._additionsTail === null ? this._additionsTail = this._additionsHead = t : this._additionsTail = this._additionsTail._nextAdded = t, t
        }
        _insertAfter(t, n, r) {
            let o = n === null ? this._itHead : n._next;
            return t._next = o, t._prev = n, o === null ? this._itTail = t : o._prev = t, n === null ? this._itHead = t : n._next = t, this._linkedRecords === null && (this._linkedRecords = new wl), this._linkedRecords.put(t), t.currentIndex = r, t
        }
        _remove(t) {
            return this._addToRemovals(this._unlink(t))
        }
        _unlink(t) {
            this._linkedRecords !== null && this._linkedRecords.remove(t);
            let n = t._prev,
                r = t._next;
            return n === null ? this._itHead = r : n._next = r, r === null ? this._itTail = n : r._prev = n, t
        }
        _addToMoves(t, n) {
            return t.previousIndex === n || (this._movesTail === null ? this._movesTail = this._movesHead = t : this._movesTail = this._movesTail._nextMoved = t), t
        }
        _addToRemovals(t) {
            return this._unlinkedRecords === null && (this._unlinkedRecords = new wl), this._unlinkedRecords.put(t), t.currentIndex = null, t._nextRemoved = null, this._removalsTail === null ? (this._removalsTail = this._removalsHead = t, t._prevRemoved = null) : (t._prevRemoved = this._removalsTail, this._removalsTail = this._removalsTail._nextRemoved = t), t
        }
        _addIdentityChange(t, n) {
            return t.item = n, this._identityChangesTail === null ? this._identityChangesTail = this._identityChangesHead = t : this._identityChangesTail = this._identityChangesTail._nextIdentityChange = t, t
        }
    },
    Eh = class {
        item;
        trackById;
        currentIndex = null;
        previousIndex = null;
        _nextPrevious = null;
        _prev = null;
        _next = null;
        _prevDup = null;
        _nextDup = null;
        _prevRemoved = null;
        _nextRemoved = null;
        _nextAdded = null;
        _nextMoved = null;
        _nextIdentityChange = null;
        constructor(t, n) {
            this.item = t, this.trackById = n
        }
    },
    yh = class {
        _head = null;
        _tail = null;
        add(t) {
            this._head === null ? (this._head = this._tail = t, t._nextDup = null, t._prevDup = null) : (this._tail._nextDup = t, t._prevDup = this._tail, t._nextDup = null, this._tail = t)
        }
        get(t, n) {
            let r;
            for (r = this._head; r !== null; r = r._nextDup)
                if ((n === null || n <= r.currentIndex) && Object.is(r.trackById, t)) return r;
            return null
        }
        remove(t) {
            let n = t._prevDup,
                r = t._nextDup;
            return n === null ? this._head = r : n._nextDup = r, r === null ? this._tail = n : r._prevDup = n, this._head === null
        }
    },
    wl = class {
        map = new Map;
        put(t) {
            let n = t.trackById,
                r = this.map.get(n);
            r || (r = new yh, this.map.set(n, r)), r.add(t)
        }
        get(t, n) {
            let r = t,
                o = this.map.get(r);
            return o ? o.get(t, n) : null
        }
        remove(t) {
            let n = t.trackById;
            return this.map.get(n).remove(t) && this.map.delete(n), t
        }
        get isEmpty() {
            return this.map.size === 0
        }
        clear() {
            this.map.clear()
        }
    };

function HD(e, t, n) {
    let r = e.previousIndex;
    if (r === null) return r;
    let o = 0;
    return n && r < n.length && (o = n[r]), r + t + o
}
var vh = class {
        supports(t) {
            return t instanceof Map || fl(t)
        }
        create() {
            return new Dh
        }
    },
    Dh = class {
        _records = new Map;
        _mapHead = null;
        _appendAfter = null;
        _previousMapHead = null;
        _changesHead = null;
        _changesTail = null;
        _additionsHead = null;
        _additionsTail = null;
        _removalsHead = null;
        get isDirty() {
            return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null
        }
        forEachItem(t) {
            let n;
            for (n = this._mapHead; n !== null; n = n._next) t(n)
        }
        forEachPreviousItem(t) {
            let n;
            for (n = this._previousMapHead; n !== null; n = n._nextPrevious) t(n)
        }
        forEachChangedItem(t) {
            let n;
            for (n = this._changesHead; n !== null; n = n._nextChanged) t(n)
        }
        forEachAddedItem(t) {
            let n;
            for (n = this._additionsHead; n !== null; n = n._nextAdded) t(n)
        }
        forEachRemovedItem(t) {
            let n;
            for (n = this._removalsHead; n !== null; n = n._nextRemoved) t(n)
        }
        diff(t) {
            if (!t) t = new Map;
            else if (!(t instanceof Map || fl(t))) throw new g(900, !1);
            return this.check(t) ? this : null
        }
        check(t) {
            this._reset();
            let n = this._mapHead;
            if (this._appendAfter = null, this._forEach(t, (r, o) => {
                    if (n && n.key === o) this._maybeAddToChanges(n, r), this._appendAfter = n, n = n._next;
                    else {
                        let i = this._getOrCreateRecordForKey(o, r);
                        n = this._insertBeforeOrAppend(n, i)
                    }
                }), n) {
                n._prev && (n._prev._next = null), this._removalsHead = n;
                for (let r = n; r !== null; r = r._nextRemoved) r === this._mapHead && (this._mapHead = null), this._records.delete(r.key), r._nextRemoved = r._next, r.previousValue = r.currentValue, r.currentValue = null, r._prev = null, r._next = null
            }
            return this._changesTail && (this._changesTail._nextChanged = null), this._additionsTail && (this._additionsTail._nextAdded = null), this.isDirty
        }
        _insertBeforeOrAppend(t, n) {
            if (t) {
                let r = t._prev;
                return n._next = t, n._prev = r, t._prev = n, r && (r._next = n), t === this._mapHead && (this._mapHead = n), this._appendAfter = t, t
            }
            return this._appendAfter ? (this._appendAfter._next = n, n._prev = this._appendAfter) : this._mapHead = n, this._appendAfter = n, null
        }
        _getOrCreateRecordForKey(t, n) {
            if (this._records.has(t)) {
                let o = this._records.get(t);
                this._maybeAddToChanges(o, n);
                let i = o._prev,
                    s = o._next;
                return i && (i._next = s), s && (s._prev = i), o._next = null, o._prev = null, o
            }
            let r = new _h(t);
            return this._records.set(t, r), r.currentValue = n, this._addToAdditions(r), r
        }
        _reset() {
            if (this.isDirty) {
                let t;
                for (this._previousMapHead = this._mapHead, t = this._previousMapHead; t !== null; t = t._next) t._nextPrevious = t._next;
                for (t = this._changesHead; t !== null; t = t._nextChanged) t.previousValue = t.currentValue;
                for (t = this._additionsHead; t != null; t = t._nextAdded) t.previousValue = t.currentValue;
                this._changesHead = this._changesTail = null, this._additionsHead = this._additionsTail = null, this._removalsHead = null
            }
        }
        _maybeAddToChanges(t, n) {
            Object.is(n, t.currentValue) || (t.previousValue = t.currentValue, t.currentValue = n, this._addToChanges(t))
        }
        _addToAdditions(t) {
            this._additionsHead === null ? this._additionsHead = this._additionsTail = t : (this._additionsTail._nextAdded = t, this._additionsTail = t)
        }
        _addToChanges(t) {
            this._changesHead === null ? this._changesHead = this._changesTail = t : (this._changesTail._nextChanged = t, this._changesTail = t)
        }
        _forEach(t, n) {
            t instanceof Map ? t.forEach(n) : Object.keys(t).forEach(r => n(t[r], r))
        }
    },
    _h = class {
        key;
        previousValue = null;
        currentValue = null;
        _nextPrevious = null;
        _next = null;
        _prev = null;
        _nextAdded = null;
        _nextRemoved = null;
        _nextChanged = null;
        constructor(t) {
            this.key = t
        }
    };

function VD() {
    return new Th([new mh])
}
var Th = (() => {
    class e {
        factories;
        static\ u0275prov = y({
            token: e,
            providedIn: "root",
            factory: VD
        });
        constructor(n) {
            this.factories = n
        }
        static create(n, r) {
            if (r != null) {
                let o = r.factories.slice();
                n = n.concat(o)
            }
            return new e(n)
        }
        static extend(n) {
            return {
                provide: e,
                useFactory: () => {
                    let r = h(e, {
                        optional: !0,
                        skipSelf: !0
                    });
                    return e.create(n, r || VD())
                }
            }
        }
        find(n) {
            let r = this.factories.find(o => o.supports(n));
            if (r != null) return r;
            throw new g(901, !1)
        }
    }
    return e
})();

function $D() {
    return new Ml([new vh])
}
var Ml = (() => {
    class e {
        static\ u0275prov = y({
            token: e,
            providedIn: "root",
            factory: $D
        });
        factories;
        constructor(n) {
            this.factories = n
        }
        static create(n, r) {
            if (r) {
                let o = r.factories.slice();
                n = n.concat(o)
            }
            return new e(n)
        }
        static extend(n) {
            return {
                provide: e,
                useFactory: () => {
                    let r = h(e, {
                        optional: !0,
                        skipSelf: !0
                    });
                    return e.create(n, r || $D())
                }
            }
        }
        find(n) {
            let r = this.factories.find(o => o.supports(n));
            if (r) return r;
            throw new g(901, !1)
        }
    }
    return e
})();
var QD = Ch(null, "core", []),
    ZD = (() => {
        class e {
            constructor(n) {}
            static\ u0275fac = function(r) {
                return new(r || e)(_(Bt))
            };
            static\ u0275mod = Ut({
                type: e
            });
            static\ u0275inj = ft({})
        }
        return e
    })();

function bn(e) {
    return typeof e == "boolean" ? e : e != null && e !== "false"
}

function Sh(e, t = NaN) {
    return !isNaN(parseFloat(e)) && !isNaN(Number(e)) ? Number(e) : t
}

function h5(e, t) {
    let n = Qt(e),
        r = t.elementInjector || So();
    return new rr(n).create(r, t.projectableNodes, t.hostElement, t.environmentInjector, t.directives, t.bindings)
}

function XD(e) {
    let t = Qt(e);
    if (!t) return null;
    let n = new rr(t);
    return {
        get selector() {
            return n.selector
        },
        get type() {
            return n.componentType
        },
        get inputs() {
            return n.inputs
        },
        get outputs() {
            return n.outputs
        },
        get ngContentSelectors() {
            return n.ngContentSelectors
        },
        get isStandalone() {
            return t.standalone
        },
        get isSignal() {
            return t.signals
        }
    }
}
var e_ = null;

function jt() {
    return e_
}

function bh(e) {
    e_ ? ? = e
}
var Ss = class {},
    wn = (() => {
        class e {
            historyGo(n) {
                throw new Error("")
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => h(t_),
                providedIn: "platform"
            })
        }
        return e
    })(),
    wh = new v(""),
    t_ = (() => {
        class e extends wn {
            _location;
            _history;
            _doc = h(Z);
            constructor() {
                super(), this._location = window.location, this._history = window.history
            }
            getBaseHrefFromDOM() {
                return jt().getBaseHref(this._doc)
            }
            onPopState(n) {
                let r = jt().getGlobalEventTarget(this._doc, "window");
                return r.addEventListener("popstate", n, !1), () => r.removeEventListener("popstate", n)
            }
            onHashChange(n) {
                let r = jt().getGlobalEventTarget(this._doc, "window");
                return r.addEventListener("hashchange", n, !1), () => r.removeEventListener("hashchange", n)
            }
            get href() {
                return this._location.href
            }
            get protocol() {
                return this._location.protocol
            }
            get hostname() {
                return this._location.hostname
            }
            get port() {
                return this._location.port
            }
            get pathname() {
                return this._location.pathname
            }
            get search() {
                return this._location.search
            }
            get hash() {
                return this._location.hash
            }
            set pathname(n) {
                this._location.pathname = n
            }
            pushState(n, r, o) {
                this._history.pushState(n, r, o)
            }
            replaceState(n, r, o) {
                this._history.replaceState(n, r, o)
            }
            forward() {
                this._history.forward()
            }
            back() {
                this._history.back()
            }
            historyGo(n = 0) {
                this._history.go(n)
            }
            getState() {
                return this._history.state
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => new e,
                providedIn: "platform"
            })
        }
        return e
    })();

function Nl(e, t) {
    return e ? t ? e.endsWith("/") ? t.startsWith("/") ? e + t.slice(1) : e + t : t.startsWith("/") ? e + t : `${e}/${t}` : e : t
}

function n_(e) {
    let t = e.search(/#|\?|$/);
    return e[t - 1] === "/" ? e.slice(0, t - 1) + e.slice(t) : e
}

function Ht(e) {
    return e && e[0] !== "?" ? `?${e}` : e
}
var Vt = (() => {
        class e {
            historyGo(n) {
                throw new Error("")
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => h(Ol),
                providedIn: "root"
            })
        }
        return e
    })(),
    Rl = new v(""),
    Ol = (() => {
        class e extends Vt {
            _platformLocation;
            _baseHref;
            _removeListenerFns = [];
            constructor(n, r) {
                super(), this._platformLocation = n, this._baseHref = r ? ? this._platformLocation.getBaseHrefFromDOM() ? ? h(Z).location ? .origin ? ? ""
            }
            ngOnDestroy() {
                for (; this._removeListenerFns.length;) this._removeListenerFns.pop()()
            }
            onPopState(n) {
                this._removeListenerFns.push(this._platformLocation.onPopState(n), this._platformLocation.onHashChange(n))
            }
            getBaseHref() {
                return this._baseHref
            }
            prepareExternalUrl(n) {
                return Nl(this._baseHref, n)
            }
            path(n = !1) {
                let r = this._platformLocation.pathname + Ht(this._platformLocation.search),
                    o = this._platformLocation.hash;
                return o && n ? `${r}${o}` : r
            }
            pushState(n, r, o, i) {
                let s = this.prepareExternalUrl(o + Ht(i));
                this._platformLocation.pushState(n, r, s)
            }
            replaceState(n, r, o, i) {
                let s = this.prepareExternalUrl(o + Ht(i));
                this._platformLocation.replaceState(n, r, s)
            }
            forward() {
                this._platformLocation.forward()
            }
            back() {
                this._platformLocation.back()
            }
            getState() {
                return this._platformLocation.getState()
            }
            historyGo(n = 0) {
                this._platformLocation.historyGo ? .(n)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(wn), _(Rl, 8))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })();
var sr = (() => {
    class e {
        _subject = new ne;
        _basePath;
        _locationStrategy;
        _urlChangeListeners = [];
        _urlChangeSubscription = null;
        constructor(n) {
            this._locationStrategy = n;
            let r = this._locationStrategy.getBaseHref();
            this._basePath = qN(n_(r_(r))), this._locationStrategy.onPopState(o => {
                this._subject.next({
                    url: this.path(!0),
                    pop: !0,
                    state: o.state,
                    type: o.type
                })
            })
        }
        ngOnDestroy() {
            this._urlChangeSubscription ? .unsubscribe(), this._urlChangeListeners = []
        }
        path(n = !1) {
            return this.normalize(this._locationStrategy.path(n))
        }
        getState() {
            return this._locationStrategy.getState()
        }
        isCurrentPathEqualTo(n, r = "") {
            return this.path() == this.normalize(n + Ht(r))
        }
        normalize(n) {
            return e.stripTrailingSlash(zN(this._basePath, r_(n)))
        }
        prepareExternalUrl(n) {
            return n && n[0] !== "/" && (n = "/" + n), this._locationStrategy.prepareExternalUrl(n)
        }
        go(n, r = "", o = null) {
            this._locationStrategy.pushState(o, "", n, r), this._notifyUrlChangeListeners(this.prepareExternalUrl(n + Ht(r)), o)
        }
        replaceState(n, r = "", o = null) {
            this._locationStrategy.replaceState(o, "", n, r), this._notifyUrlChangeListeners(this.prepareExternalUrl(n + Ht(r)), o)
        }
        forward() {
            this._locationStrategy.forward()
        }
        back() {
            this._locationStrategy.back()
        }
        historyGo(n = 0) {
            this._locationStrategy.historyGo ? .(n)
        }
        onUrlChange(n) {
            return this._urlChangeListeners.push(n), this._urlChangeSubscription ? ? = this.subscribe(r => {
                this._notifyUrlChangeListeners(r.url, r.state)
            }), () => {
                let r = this._urlChangeListeners.indexOf(n);
                this._urlChangeListeners.splice(r, 1), this._urlChangeListeners.length === 0 && (this._urlChangeSubscription ? .unsubscribe(), this._urlChangeSubscription = null)
            }
        }
        _notifyUrlChangeListeners(n = "", r) {
            this._urlChangeListeners.forEach(o => o(n, r))
        }
        subscribe(n, r, o) {
            return this._subject.subscribe({
                next: n,
                error: r ? ? void 0,
                complete: o ? ? void 0
            })
        }
        static normalizeQueryParams = Ht;
        static joinWithSlash = Nl;
        static stripTrailingSlash = n_;
        static\ u0275fac = function(r) {
            return new(r || e)(_(Vt))
        };
        static\ u0275prov = y({
            token: e,
            factory: () => WN(),
            providedIn: "root"
        })
    }
    return e
})();

function WN() {
    return new sr(_(Vt))
}

function zN(e, t) {
    if (!e || !t.startsWith(e)) return t;
    let n = t.substring(e.length);
    return n === "" || ["/", ";", "?", "#"].includes(n[0]) ? n : t
}

function r_(e) {
    return e.replace(/\/index.html$/, "")
}

function qN(e) {
    if (new RegExp("^(https?:)?//").test(e)) {
        let [, n] = e.split(/\/\/[^\/]+/);
        return n
    }
    return e
}
var Fh = (() => {
    class e extends Vt {
        _platformLocation;
        _baseHref = "";
        _removeListenerFns = [];
        constructor(n, r) {
            super(), this._platformLocation = n, r != null && (this._baseHref = r)
        }
        ngOnDestroy() {
            for (; this._removeListenerFns.length;) this._removeListenerFns.pop()()
        }
        onPopState(n) {
            this._removeListenerFns.push(this._platformLocation.onPopState(n), this._platformLocation.onHashChange(n))
        }
        getBaseHref() {
            return this._baseHref
        }
        path(n = !1) {
            let r = this._platformLocation.hash ? ? "#";
            return r.length > 0 ? r.substring(1) : r
        }
        prepareExternalUrl(n) {
            let r = Nl(this._baseHref, n);
            return r.length > 0 ? "#" + r : r
        }
        pushState(n, r, o, i) {
            let s = this.prepareExternalUrl(o + Ht(i)) || this._platformLocation.pathname;
            this._platformLocation.pushState(n, r, s)
        }
        replaceState(n, r, o, i) {
            let s = this.prepareExternalUrl(o + Ht(i)) || this._platformLocation.pathname;
            this._platformLocation.replaceState(n, r, s)
        }
        forward() {
            this._platformLocation.forward()
        }
        back() {
            this._platformLocation.back()
        }
        getState() {
            return this._platformLocation.getState()
        }
        historyGo(n = 0) {
            this._platformLocation.historyGo ? .(n)
        }
        static\ u0275fac = function(r) {
            return new(r || e)(_(wn), _(Rl, 8))
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac
        })
    }
    return e
})();
var Uh = (function(e) {
    return e[e.Decimal = 0] = "Decimal", e[e.Percent = 1] = "Percent", e[e.Currency = 2] = "Currency", e[e.Scientific = 3] = "Scientific", e
})(Uh || {});
var ke = (function(e) {
        return e[e.Format = 0] = "Format", e[e.Standalone = 1] = "Standalone", e
    })(ke || {}),
    K = (function(e) {
        return e[e.Narrow = 0] = "Narrow", e[e.Abbreviated = 1] = "Abbreviated", e[e.Wide = 2] = "Wide", e[e.Short = 3] = "Short", e
    })(K || {}),
    Qe = (function(e) {
        return e[e.Short = 0] = "Short", e[e.Medium = 1] = "Medium", e[e.Long = 2] = "Long", e[e.Full = 3] = "Full", e
    })(Qe || {}),
    Ze = {
        Decimal: 0,
        Group: 1,
        List: 2,
        PercentSign: 3,
        PlusSign: 4,
        MinusSign: 5,
        Exponential: 6,
        SuperscriptingExponent: 7,
        PerMille: 8,
        Infinity: 9,
        NaN: 10,
        TimeSeparator: 11,
        CurrencyDecimal: 12,
        CurrencyGroup: 13
    };

function u_(e) {
    return Je(e)[le.LocaleId]
}

function d_(e, t, n) {
    let r = Je(e),
        o = [r[le.DayPeriodsFormat], r[le.DayPeriodsStandalone]],
        i = _t(o, t);
    return _t(i, n)
}

function f_(e, t, n) {
    let r = Je(e),
        o = [r[le.DaysFormat], r[le.DaysStandalone]],
        i = _t(o, t);
    return _t(i, n)
}

function p_(e, t, n) {
    let r = Je(e),
        o = [r[le.MonthsFormat], r[le.MonthsStandalone]],
        i = _t(o, t);
    return _t(i, n)
}

function h_(e, t) {
    let r = Je(e)[le.Eras];
    return _t(r, t)
}

function bs(e, t) {
    let n = Je(e);
    return _t(n[le.DateFormat], t)
}

function ws(e, t) {
    let n = Je(e);
    return _t(n[le.TimeFormat], t)
}

function As(e, t) {
    let r = Je(e)[le.DateTimeFormat];
    return _t(r, t)
}

function an(e, t) {
    let n = Je(e),
        r = n[le.NumberSymbols][t];
    if (typeof r > "u") {
        if (t === Ze.CurrencyDecimal) return n[le.NumberSymbols][Ze.Decimal];
        if (t === Ze.CurrencyGroup) return n[le.NumberSymbols][Ze.Group]
    }
    return r
}

function m_(e, t) {
    return Je(e)[le.NumberFormats][t]
}

function g_(e) {
    if (!e[le.ExtraData]) throw new g(2303, !1)
}

function E_(e) {
    let t = Je(e);
    return g_(t), (t[le.ExtraData][2] || []).map(r => typeof r == "string" ? Ah(r) : [Ah(r[0]), Ah(r[1])])
}

function y_(e, t, n) {
    let r = Je(e);
    g_(r);
    let o = [r[le.ExtraData][0], r[le.ExtraData][1]],
        i = _t(o, t) || [];
    return _t(i, n) || []
}

function _t(e, t) {
    for (let n = t; n > -1; n--)
        if (typeof e[n] < "u") return e[n];
    throw new g(2304, !1)
}

function Ah(e) {
    let [t, n] = e.split(":");
    return {
        hours: +t,
        minutes: +n
    }
}
var KN = /^(\d{4,})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/,
    Pl = {},
    YN = /((?:[^BEGHLMOSWYZabcdhmswyz']+)|(?:'(?:[^']|'')*')|(?:G{1,5}|y{1,4}|Y{1,4}|M{1,5}|L{1,5}|w{1,2}|W{1}|d{1,2}|E{1,6}|c{1,6}|a{1,5}|b{1,5}|B{1,5}|h{1,2}|H{1,2}|m{1,2}|s{1,2}|S{1,3}|z{1,4}|Z{1,5}|O{1,4}))([\s\S]*)/;

function v_(e, t, n, r) {
    let o = oR(e);
    t = An(n, t) || t;
    let s = [],
        a;
    for (; t;)
        if (a = YN.exec(t), a) {
            s = s.concat(a.slice(1));
            let u = s.pop();
            if (!u) break;
            t = u
        } else {
            s.push(t);
            break
        }
    let c = o.getTimezoneOffset();
    r && (c = __(r, c), o = rR(o, r));
    let l = "";
    return s.forEach(u => {
        let d = tR(u);
        l += d ? d(o, n, c) : u === "''" ? "'" : u.replace(/(^'|'$)/g, "").replace(/''/g, "'")
    }), l
}

function Bl(e, t, n) {
    let r = new Date(0);
    return r.setFullYear(e, t, n), r.setHours(0, 0, 0), r
}

function An(e, t) {
    let n = u_(e);
    if (Pl[n] ? ? = {}, Pl[n][t]) return Pl[n][t];
    let r = "";
    switch (t) {
        case "shortDate":
            r = bs(e, Qe.Short);
            break;
        case "mediumDate":
            r = bs(e, Qe.Medium);
            break;
        case "longDate":
            r = bs(e, Qe.Long);
            break;
        case "fullDate":
            r = bs(e, Qe.Full);
            break;
        case "shortTime":
            r = ws(e, Qe.Short);
            break;
        case "mediumTime":
            r = ws(e, Qe.Medium);
            break;
        case "longTime":
            r = ws(e, Qe.Long);
            break;
        case "fullTime":
            r = ws(e, Qe.Full);
            break;
        case "short":
            let o = An(e, "shortTime"),
                i = An(e, "shortDate");
            r = Ll(As(e, Qe.Short), [o, i]);
            break;
        case "medium":
            let s = An(e, "mediumTime"),
                a = An(e, "mediumDate");
            r = Ll(As(e, Qe.Medium), [s, a]);
            break;
        case "long":
            let c = An(e, "longTime"),
                l = An(e, "longDate");
            r = Ll(As(e, Qe.Long), [c, l]);
            break;
        case "full":
            let u = An(e, "fullTime"),
                d = An(e, "fullDate");
            r = Ll(As(e, Qe.Full), [u, d]);
            break
    }
    return r && (Pl[n][t] = r), r
}

function Ll(e, t) {
    return t && (e = e.replace(/\{([^}]+)}/g, function(n, r) {
        return t != null && r in t ? t[r] : n
    })), e
}

function $t(e, t, n = "-", r, o) {
    let i = "";
    (e < 0 || o && e <= 0) && (o ? e = -e + 1 : (e = -e, i = n));
    let s = String(e);
    for (; s.length < t;) s = "0" + s;
    return r && (s = s.slice(s.length - t)), i + s
}

function JN(e, t) {
    return $t(e, 3).substring(0, t)
}

function Ee(e, t, n = 0, r = !1, o = !1) {
    return function(i, s) {
        let a = QN(e, i);
        if ((n > 0 || a > -n) && (a += n), e === 3) a === 0 && n === -12 && (a = 12);
        else if (e === 6) return JN(a, t);
        let c = an(s, Ze.MinusSign);
        return $t(a, t, c, r, o)
    }
}

function QN(e, t) {
    switch (e) {
        case 0:
            return t.getFullYear();
        case 1:
            return t.getMonth();
        case 2:
            return t.getDate();
        case 3:
            return t.getHours();
        case 4:
            return t.getMinutes();
        case 5:
            return t.getSeconds();
        case 6:
            return t.getMilliseconds();
        case 7:
            return t.getDay();
        default:
            throw new g(2301, !1)
    }
}

function X(e, t, n = ke.Format, r = !1) {
    return function(o, i) {
        return ZN(o, i, e, t, n, r)
    }
}

function ZN(e, t, n, r, o, i) {
    switch (n) {
        case 2:
            return p_(t, o, r)[e.getMonth()];
        case 1:
            return f_(t, o, r)[e.getDay()];
        case 0:
            let s = e.getHours(),
                a = e.getMinutes();
            if (i) {
                let l = E_(t),
                    u = y_(t, o, r),
                    d = l.findIndex(f => {
                        if (Array.isArray(f)) {
                            let [p, m] = f, x = s >= p.hours && a >= p.minutes, D = s < m.hours || s === m.hours && a < m.minutes;
                            if (p.hours < m.hours) {
                                if (x && D) return !0
                            } else if (x || D) return !0
                        } else if (f.hours === s && f.minutes === a) return !0;
                        return !1
                    });
                if (d !== -1) return u[d]
            }
            return d_(t, o, r)[s < 12 ? 0 : 1];
        case 3:
            return h_(t, r)[e.getFullYear() <= 0 ? 0 : 1];
        default:
            let c = n;
            throw new g(2302, !1)
    }
}

function kl(e) {
    return function(t, n, r) {
        let o = -1 * r,
            i = an(n, Ze.MinusSign),
            s = o > 0 ? Math.floor(o / 60) : Math.ceil(o / 60);
        switch (e) {
            case 0:
                return (o >= 0 ? "+" : "") + $t(s, 2, i) + $t(Math.abs(o % 60), 2, i);
            case 1:
                return "GMT" + (o >= 0 ? "+" : "") + $t(s, 1, i);
            case 2:
                return "GMT" + (o >= 0 ? "+" : "") + $t(s, 2, i) + ":" + $t(Math.abs(o % 60), 2, i);
            case 3:
                return r === 0 ? "Z" : (o >= 0 ? "+" : "") + $t(s, 2, i) + ":" + $t(Math.abs(o % 60), 2, i);
            default:
                throw new g(2310, !1)
        }
    }
}
var XN = 0,
    Ul = 4;

function eR(e) {
    let t = Bl(e, XN, 1).getDay();
    return Bl(e, 0, 1 + (t <= Ul ? Ul : Ul + 7) - t)
}

function D_(e) {
    let t = e.getDay(),
        n = t === 0 ? -3 : Ul - t;
    return Bl(e.getFullYear(), e.getMonth(), e.getDate() + n)
}

function Mh(e, t = !1) {
    return function(n, r) {
        let o;
        if (t) {
            let i = new Date(n.getFullYear(), n.getMonth(), 1).getDay() - 1,
                s = n.getDate();
            o = 1 + Math.floor((s + i) / 7)
        } else {
            let i = D_(n),
                s = eR(i.getFullYear()),
                a = i.getTime() - s.getTime();
            o = 1 + Math.round(a / 6048e5)
        }
        return $t(o, e, an(r, Ze.MinusSign))
    }
}

function Fl(e, t = !1) {
    return function(n, r) {
        let i = D_(n).getFullYear();
        return $t(i, e, an(r, Ze.MinusSign), t)
    }
}
var Nh = {};

function tR(e) {
    if (Nh[e]) return Nh[e];
    let t;
    switch (e) {
        case "G":
        case "GG":
        case "GGG":
            t = X(3, K.Abbreviated);
            break;
        case "GGGG":
            t = X(3, K.Wide);
            break;
        case "GGGGG":
            t = X(3, K.Narrow);
            break;
        case "y":
            t = Ee(0, 1, 0, !1, !0);
            break;
        case "yy":
            t = Ee(0, 2, 0, !0, !0);
            break;
        case "yyy":
            t = Ee(0, 3, 0, !1, !0);
            break;
        case "yyyy":
            t = Ee(0, 4, 0, !1, !0);
            break;
        case "Y":
            t = Fl(1);
            break;
        case "YY":
            t = Fl(2, !0);
            break;
        case "YYY":
            t = Fl(3);
            break;
        case "YYYY":
            t = Fl(4);
            break;
        case "M":
        case "L":
            t = Ee(1, 1, 1);
            break;
        case "MM":
        case "LL":
            t = Ee(1, 2, 1);
            break;
        case "MMM":
            t = X(2, K.Abbreviated);
            break;
        case "MMMM":
            t = X(2, K.Wide);
            break;
        case "MMMMM":
            t = X(2, K.Narrow);
            break;
        case "LLL":
            t = X(2, K.Abbreviated, ke.Standalone);
            break;
        case "LLLL":
            t = X(2, K.Wide, ke.Standalone);
            break;
        case "LLLLL":
            t = X(2, K.Narrow, ke.Standalone);
            break;
        case "w":
            t = Mh(1);
            break;
        case "ww":
            t = Mh(2);
            break;
        case "W":
            t = Mh(1, !0);
            break;
        case "d":
            t = Ee(2, 1);
            break;
        case "dd":
            t = Ee(2, 2);
            break;
        case "c":
        case "cc":
            t = Ee(7, 1);
            break;
        case "ccc":
            t = X(1, K.Abbreviated, ke.Standalone);
            break;
        case "cccc":
            t = X(1, K.Wide, ke.Standalone);
            break;
        case "ccccc":
            t = X(1, K.Narrow, ke.Standalone);
            break;
        case "cccccc":
            t = X(1, K.Short, ke.Standalone);
            break;
        case "E":
        case "EE":
        case "EEE":
            t = X(1, K.Abbreviated);
            break;
        case "EEEE":
            t = X(1, K.Wide);
            break;
        case "EEEEE":
            t = X(1, K.Narrow);
            break;
        case "EEEEEE":
            t = X(1, K.Short);
            break;
        case "a":
        case "aa":
        case "aaa":
            t = X(0, K.Abbreviated);
            break;
        case "aaaa":
            t = X(0, K.Wide);
            break;
        case "aaaaa":
            t = X(0, K.Narrow);
            break;
        case "b":
        case "bb":
        case "bbb":
            t = X(0, K.Abbreviated, ke.Standalone, !0);
            break;
        case "bbbb":
            t = X(0, K.Wide, ke.Standalone, !0);
            break;
        case "bbbbb":
            t = X(0, K.Narrow, ke.Standalone, !0);
            break;
        case "B":
        case "BB":
        case "BBB":
            t = X(0, K.Abbreviated, ke.Format, !0);
            break;
        case "BBBB":
            t = X(0, K.Wide, ke.Format, !0);
            break;
        case "BBBBB":
            t = X(0, K.Narrow, ke.Format, !0);
            break;
        case "h":
            t = Ee(3, 1, -12);
            break;
        case "hh":
            t = Ee(3, 2, -12);
            break;
        case "H":
            t = Ee(3, 1);
            break;
        case "HH":
            t = Ee(3, 2);
            break;
        case "m":
            t = Ee(4, 1);
            break;
        case "mm":
            t = Ee(4, 2);
            break;
        case "s":
            t = Ee(5, 1);
            break;
        case "ss":
            t = Ee(5, 2);
            break;
        case "S":
            t = Ee(6, 1);
            break;
        case "SS":
            t = Ee(6, 2);
            break;
        case "SSS":
            t = Ee(6, 3);
            break;
        case "Z":
        case "ZZ":
        case "ZZZ":
            t = kl(0);
            break;
        case "ZZZZZ":
            t = kl(3);
            break;
        case "O":
        case "OO":
        case "OOO":
        case "z":
        case "zz":
        case "zzz":
            t = kl(1);
            break;
        case "OOOO":
        case "ZZZZ":
        case "zzzz":
            t = kl(2);
            break;
        default:
            return null
    }
    return Nh[e] = t, t
}

function __(e, t) {
    e = e.replace(/:/g, "");
    let n = Date.parse("Jan 01, 1970 00:00:00 " + e) / 6e4;
    return isNaN(n) ? t : n
}

function nR(e, t) {
    return e = new Date(e.getTime()), e.setMinutes(e.getMinutes() + t), e
}

function rR(e, t, n) {
    let o = e.getTimezoneOffset(),
        i = __(t, o);
    return nR(e, -1 * (i - o))
}

function oR(e) {
    if (o_(e)) return e;
    if (typeof e == "number" && !isNaN(e)) return new Date(e);
    if (typeof e == "string") {
        if (e = e.trim(), /^(\d{4}(-\d{1,2}(-\d{1,2})?)?)$/.test(e)) {
            let [o, i = 1, s = 1] = e.split("-").map(a => +a);
            return Bl(o, i - 1, s)
        }
        let n = parseFloat(e);
        if (!isNaN(e - n)) return new Date(n);
        let r;
        if (r = e.match(KN)) return iR(r)
    }
    let t = new Date(e);
    if (!o_(t)) throw new g(2311, !1);
    return t
}

function iR(e) {
    let t = new Date(0),
        n = 0,
        r = 0,
        o = e[8] ? t.setUTCFullYear : t.setFullYear,
        i = e[8] ? t.setUTCHours : t.setHours;
    e[9] && (n = Number(e[9] + e[10]), r = Number(e[9] + e[11])), o.call(t, Number(e[1]), Number(e[2]) - 1, Number(e[3]));
    let s = Number(e[4] || 0) - n,
        a = Number(e[5] || 0) - r,
        c = Number(e[6] || 0),
        l = Math.floor(parseFloat("0." + (e[7] || 0)) * 1e3);
    return i.call(t, s, a, c, l), t
}

function o_(e) {
    return e instanceof Date && !isNaN(e.valueOf())
}
var sR = /^(\d+)?\.((\d+)(-(\d+))?)?$/,
    i_ = 22,
    jl = ".",
    Ms = "0",
    aR = ";",
    cR = ",",
    Rh = "#";

function lR(e, t, n, r, o, i, s = !1) {
    let a = "",
        c = !1;
    if (!isFinite(e)) a = an(n, Ze.Infinity);
    else {
        let l = fR(e);
        s && (l = dR(l));
        let u = t.minInt,
            d = t.minFrac,
            f = t.maxFrac;
        if (i) {
            let F = i.match(sR);
            if (F === null) throw new g(2306, !1);
            let me = F[1],
                ee = F[3],
                jn = F[5];
            me != null && (u = Oh(me)), ee != null && (d = Oh(ee)), jn != null ? f = Oh(jn) : ee != null && d > f && (f = d)
        }
        pR(l, d, f);
        let p = l.digits,
            m = l.integerLen,
            x = l.exponent,
            D = [];
        for (c = p.every(F => !F); m < u; m++) p.unshift(0);
        for (; m < 0; m++) p.unshift(0);
        m > 0 ? D = p.splice(m, p.length) : (D = p, p = [0]);
        let I = [];
        for (p.length >= t.lgSize && I.unshift(p.splice(-t.lgSize, p.length).join("")); p.length > t.gSize;) I.unshift(p.splice(-t.gSize, p.length).join(""));
        p.length && I.unshift(p.join("")), a = I.join(an(n, r)), D.length && (a += an(n, o) + D.join("")), x && (a += an(n, Ze.Exponential) + "+" + x)
    }
    return e < 0 && !c ? a = t.negPre + a + t.negSuf : a = t.posPre + a + t.posSuf, a
}

function x_(e, t, n) {
    let r = m_(t, Uh.Decimal),
        o = uR(r, an(t, Ze.MinusSign));
    return lR(e, o, t, Ze.Group, Ze.Decimal, n)
}

function uR(e, t = "-") {
    let n = {
            minInt: 1,
            minFrac: 0,
            maxFrac: 0,
            posPre: "",
            posSuf: "",
            negPre: "",
            negSuf: "",
            gSize: 0,
            lgSize: 0
        },
        r = e.split(aR),
        o = r[0],
        i = r[1],
        s = o.indexOf(jl) !== -1 ? o.split(jl) : [o.substring(0, o.lastIndexOf(Ms) + 1), o.substring(o.lastIndexOf(Ms) + 1)],
        a = s[0],
        c = s[1] || "";
    n.posPre = a.substring(0, a.indexOf(Rh));
    for (let u = 0; u < c.length; u++) {
        let d = c.charAt(u);
        d === Ms ? n.minFrac = n.maxFrac = u + 1 : d === Rh ? n.maxFrac = u + 1 : n.posSuf += d
    }
    let l = a.split(cR);
    if (n.gSize = l[1] ? l[1].length : 0, n.lgSize = l[2] || l[1] ? (l[2] || l[1]).length : 0, i) {
        let u = o.length - n.posPre.length - n.posSuf.length,
            d = i.indexOf(Rh);
        n.negPre = i.substring(0, d).replace(/'/g, ""), n.negSuf = i.slice(d + u).replace(/'/g, "")
    } else n.negPre = t + n.posPre, n.negSuf = n.posSuf;
    return n
}

function dR(e) {
    if (e.digits[0] === 0) return e;
    let t = e.digits.length - e.integerLen;
    return e.exponent ? e.exponent += 2 : (t === 0 ? e.digits.push(0, 0) : t === 1 && e.digits.push(0), e.integerLen += 2), e
}

function fR(e) {
    let t = Math.abs(e) + "",
        n = 0,
        r, o, i, s, a;
    for ((o = t.indexOf(jl)) > -1 && (t = t.replace(jl, "")), (i = t.search(/e/i)) > 0 ? (o < 0 && (o = i), o += +t.slice(i + 1), t = t.substring(0, i)) : o < 0 && (o = t.length), i = 0; t.charAt(i) === Ms; i++);
    if (i === (a = t.length)) r = [0], o = 1;
    else {
        for (a--; t.charAt(a) === Ms;) a--;
        for (o -= i, r = [], s = 0; i <= a; i++, s++) r[s] = Number(t.charAt(i))
    }
    return o > i_ && (r = r.splice(0, i_ - 1), n = o - 1, o = 1), {
        digits: r,
        exponent: n,
        integerLen: o
    }
}

function pR(e, t, n) {
    if (t > n) throw new g(2307, !1);
    let r = e.digits,
        o = r.length - e.integerLen,
        i = Math.min(Math.max(t, o), n),
        s = i + e.integerLen,
        a = r[s];
    if (s > 0) {
        r.splice(Math.max(e.integerLen, s));
        for (let d = s; d < r.length; d++) r[d] = 0
    } else {
        o = Math.max(0, o), e.integerLen = 1, r.length = Math.max(1, s = i + 1), r[0] = 0;
        for (let d = 1; d < s; d++) r[d] = 0
    }
    if (a >= 5)
        if (s - 1 < 0) {
            for (let d = 0; d > s; d--) r.unshift(0), e.integerLen++;
            r.unshift(1), e.integerLen++
        } else r[s - 1]++;
    for (; o < Math.max(0, i); o++) r.push(0);
    let c = i !== 0,
        l = t + e.integerLen,
        u = r.reduceRight(function(d, f, p, m) {
            return f = f + d, m[p] = f < 10 ? f : f - 10, c && (m[p] === 0 && p >= l ? m.pop() : c = !1), f >= 10 ? 1 : 0
        }, 0);
    u && (r.unshift(u), e.integerLen++)
}

function Oh(e) {
    let t = parseInt(e);
    if (isNaN(t)) throw new g(2305, !1);
    return t
}
var Ph = /\s+/,
    s_ = [],
    hR = (() => {
        class e {
            _ngEl;
            _renderer;
            initialClasses = s_;
            rawClass;
            stateMap = new Map;
            constructor(n, r) {
                this._ngEl = n, this._renderer = r
            }
            set klass(n) {
                this.initialClasses = n != null ? n.trim().split(Ph) : s_
            }
            set ngClass(n) {
                this.rawClass = typeof n == "string" ? n.trim().split(Ph) : n
            }
            ngDoCheck() {
                for (let r of this.initialClasses) this._updateState(r, !0);
                let n = this.rawClass;
                if (Array.isArray(n) || n instanceof Set)
                    for (let r of n) this._updateState(r, !0);
                else if (n != null)
                    for (let r of Object.keys(n)) this._updateState(r, !!n[r]);
                this._applyStateDiff()
            }
            _updateState(n, r) {
                let o = this.stateMap.get(n);
                o !== void 0 ? (o.enabled !== r && (o.changed = !0, o.enabled = r), o.touched = !0) : this.stateMap.set(n, {
                    enabled: r,
                    changed: !0,
                    touched: !0
                })
            }
            _applyStateDiff() {
                for (let n of this.stateMap) {
                    let r = n[0],
                        o = n[1];
                    o.changed ? (this._toggleClass(r, o.enabled), o.changed = !1) : o.touched || (o.enabled && this._toggleClass(r, !1), this.stateMap.delete(r)), o.touched = !1
                }
            }
            _toggleClass(n, r) {
                n = n.trim(), n.length > 0 && n.split(Ph).forEach(o => {
                    r ? this._renderer.addClass(this._ngEl.nativeElement, o) : this._renderer.removeClass(this._ngEl.nativeElement, o)
                })
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(it), k(Tn))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngClass", ""]
                ],
                inputs: {
                    klass: [0, "class", "klass"],
                    ngClass: "ngClass"
                }
            })
        }
        return e
    })();
var Hl = class {
        $implicit;
        ngForOf;
        index;
        count;
        constructor(t, n, r, o) {
            this.$implicit = t, this.ngForOf = n, this.index = r, this.count = o
        }
        get first() {
            return this.index === 0
        }
        get last() {
            return this.index === this.count - 1
        }
        get even() {
            return this.index % 2 === 0
        }
        get odd() {
            return !this.even
        }
    },
    C_ = (() => {
        class e {
            _viewContainer;
            _template;
            _differs;
            set ngForOf(n) {
                this._ngForOf = n, this._ngForOfDirty = !0
            }
            set ngForTrackBy(n) {
                this._trackByFn = n
            }
            get ngForTrackBy() {
                return this._trackByFn
            }
            _ngForOf = null;
            _ngForOfDirty = !0;
            _differ = null;
            _trackByFn;
            constructor(n, r, o) {
                this._viewContainer = n, this._template = r, this._differs = o
            }
            set ngForTemplate(n) {
                n && (this._template = n)
            }
            ngDoCheck() {
                if (this._ngForOfDirty) {
                    this._ngForOfDirty = !1;
                    let n = this._ngForOf;
                    !this._differ && n && (this._differ = this._differs.find(n).create(this.ngForTrackBy))
                }
                if (this._differ) {
                    let n = this._differ.diff(this._ngForOf);
                    n && this._applyChanges(n)
                }
            }
            _applyChanges(n) {
                let r = this._viewContainer;
                n.forEachOperation((o, i, s) => {
                    if (o.previousIndex == null) r.createEmbeddedView(this._template, new Hl(o.item, this._ngForOf, -1, -1), s === null ? void 0 : s);
                    else if (s == null) r.remove(i === null ? void 0 : i);
                    else if (i !== null) {
                        let a = r.get(i);
                        r.move(a, s), a_(a, o)
                    }
                });
                for (let o = 0, i = r.length; o < i; o++) {
                    let a = r.get(o).context;
                    a.index = o, a.count = i, a.ngForOf = this._ngForOf
                }
                n.forEachIdentityChange(o => {
                    let i = r.get(o.currentIndex);
                    a_(i, o)
                })
            }
            static ngTemplateContextGuard(n, r) {
                return !0
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Dt), k(nn), k(Th))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngFor", "", "ngForOf", ""]
                ],
                inputs: {
                    ngForOf: "ngForOf",
                    ngForTrackBy: "ngForTrackBy",
                    ngForTemplate: "ngForTemplate"
                }
            })
        }
        return e
    })();

function a_(e, t) {
    e.context.$implicit = t.item
}
var mR = (() => {
        class e {
            _viewContainer;
            _context = new Vl;
            _thenTemplateRef = null;
            _elseTemplateRef = null;
            _thenViewRef = null;
            _elseViewRef = null;
            constructor(n, r) {
                this._viewContainer = n, this._thenTemplateRef = r
            }
            set ngIf(n) {
                this._context.$implicit = this._context.ngIf = n, this._updateView()
            }
            set ngIfThen(n) {
                c_(n, !1), this._thenTemplateRef = n, this._thenViewRef = null, this._updateView()
            }
            set ngIfElse(n) {
                c_(n, !1), this._elseTemplateRef = n, this._elseViewRef = null, this._updateView()
            }
            _updateView() {
                this._context.$implicit ? this._thenViewRef || (this._viewContainer.clear(), this._elseViewRef = null, this._thenTemplateRef && (this._thenViewRef = this._viewContainer.createEmbeddedView(this._thenTemplateRef, this._context))) : this._elseViewRef || (this._viewContainer.clear(), this._thenViewRef = null, this._elseTemplateRef && (this._elseViewRef = this._viewContainer.createEmbeddedView(this._elseTemplateRef, this._context)))
            }
            static ngIfUseIfTypeGuard;
            static ngTemplateGuard_ngIf;
            static ngTemplateContextGuard(n, r) {
                return !0
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Dt), k(nn))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngIf", ""]
                ],
                inputs: {
                    ngIf: "ngIf",
                    ngIfThen: "ngIfThen",
                    ngIfElse: "ngIfElse"
                }
            })
        }
        return e
    })(),
    Vl = class {
        $implicit = null;
        ngIf = null
    };

function c_(e, t) {
    if (e && !e.createEmbeddedView) throw new g(2020, !1)
}
var $l = class {
        _viewContainerRef;
        _templateRef;
        _created = !1;
        constructor(t, n) {
            this._viewContainerRef = t, this._templateRef = n
        }
        create() {
            this._created = !0, this._viewContainerRef.createEmbeddedView(this._templateRef)
        }
        destroy() {
            this._created = !1, this._viewContainerRef.clear()
        }
        enforceState(t) {
            t && !this._created ? this.create() : !t && this._created && this.destroy()
        }
    },
    Bh = (() => {
        class e {
            _defaultViews = [];
            _defaultUsed = !1;
            _caseCount = 0;
            _lastCaseCheckIndex = 0;
            _lastCasesMatched = !1;
            _ngSwitch;
            set ngSwitch(n) {
                this._ngSwitch = n, this._caseCount === 0 && this._updateDefaultCases(!0)
            }
            _addCase() {
                return this._caseCount++
            }
            _addDefault(n) {
                this._defaultViews.push(n)
            }
            _matchCase(n) {
                let r = n === this._ngSwitch;
                return this._lastCasesMatched || = r, this._lastCaseCheckIndex++, this._lastCaseCheckIndex === this._caseCount && (this._updateDefaultCases(!this._lastCasesMatched), this._lastCaseCheckIndex = 0, this._lastCasesMatched = !1), r
            }
            _updateDefaultCases(n) {
                if (this._defaultViews.length > 0 && n !== this._defaultUsed) {
                    this._defaultUsed = n;
                    for (let r of this._defaultViews) r.enforceState(n)
                }
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngSwitch", ""]
                ],
                inputs: {
                    ngSwitch: "ngSwitch"
                }
            })
        }
        return e
    })(),
    gR = (() => {
        class e {
            ngSwitch;
            _view;
            ngSwitchCase;
            constructor(n, r, o) {
                this.ngSwitch = o, o._addCase(), this._view = new $l(n, r)
            }
            ngDoCheck() {
                this._view.enforceState(this.ngSwitch._matchCase(this.ngSwitchCase))
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Dt), k(nn), k(Bh, 9))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngSwitchCase", ""]
                ],
                inputs: {
                    ngSwitchCase: "ngSwitchCase"
                }
            })
        }
        return e
    })(),
    ER = (() => {
        class e {
            constructor(n, r, o) {
                o._addDefault(new $l(n, r))
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Dt), k(nn), k(Bh, 9))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngSwitchDefault", ""]
                ]
            })
        }
        return e
    })();
var yR = (() => {
        class e {
            _ngEl;
            _differs;
            _renderer;
            _ngStyle = null;
            _differ = null;
            constructor(n, r, o) {
                this._ngEl = n, this._differs = r, this._renderer = o
            }
            set ngStyle(n) {
                this._ngStyle = n, !this._differ && n && (this._differ = this._differs.find(n).create())
            }
            ngDoCheck() {
                if (this._differ) {
                    let n = this._differ.diff(this._ngStyle);
                    n && this._applyChanges(n)
                }
            }
            _setStyle(n, r) {
                let [o, i] = n.split("."), s = o.indexOf("-") === -1 ? void 0 : Ft.DashCase;
                r != null ? this._renderer.setStyle(this._ngEl.nativeElement, o, i ? `${r}${i}` : r, s) : this._renderer.removeStyle(this._ngEl.nativeElement, o, s)
            }
            _applyChanges(n) {
                n.forEachRemovedItem(r => this._setStyle(r.key, null)), n.forEachAddedItem(r => this._setStyle(r.key, r.currentValue)), n.forEachChangedItem(r => this._setStyle(r.key, r.currentValue))
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(it), k(Ml), k(Tn))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngStyle", ""]
                ],
                inputs: {
                    ngStyle: "ngStyle"
                }
            })
        }
        return e
    })(),
    vR = (() => {
        class e {
            _viewContainerRef;
            _viewRef = null;
            ngTemplateOutletContext = null;
            ngTemplateOutlet = null;
            ngTemplateOutletInjector = null;
            injector = h(fe);
            constructor(n) {
                this._viewContainerRef = n
            }
            ngOnChanges(n) {
                if (this._shouldRecreateView(n)) {
                    let r = this._viewContainerRef;
                    if (this._viewRef && r.remove(r.indexOf(this._viewRef)), !this.ngTemplateOutlet) {
                        this._viewRef = null;
                        return
                    }
                    let o = this._createContextForwardProxy();
                    this._viewRef = r.createEmbeddedView(this.ngTemplateOutlet, o, {
                        injector: this._getInjector()
                    })
                }
            }
            _getInjector() {
                return this.ngTemplateOutletInjector === "outlet" ? this.injector : this.ngTemplateOutletInjector ? ? void 0
            }
            _shouldRecreateView(n) {
                return !!n.ngTemplateOutlet || !!n.ngTemplateOutletInjector
            }
            _createContextForwardProxy() {
                return new Proxy({}, {
                    set: (n, r, o) => this.ngTemplateOutletContext ? Reflect.set(this.ngTemplateOutletContext, r, o) : !1,
                    get: (n, r, o) => {
                        if (this.ngTemplateOutletContext) return Reflect.get(this.ngTemplateOutletContext, r, o)
                    }
                })
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Dt))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "ngTemplateOutlet", ""]
                ],
                inputs: {
                    ngTemplateOutletContext: "ngTemplateOutletContext",
                    ngTemplateOutlet: "ngTemplateOutlet",
                    ngTemplateOutletInjector: "ngTemplateOutletInjector"
                },
                features: [rn]
            })
        }
        return e
    })();

function Ns(e, t) {
    return new g(2100, !1)
}
var Lh = class {
        createSubscription(t, n, r) {
            return te(() => t.subscribe({
                next: n,
                error: r
            }))
        }
        dispose(t) {
            te(() => t.unsubscribe())
        }
    },
    kh = class {
        createSubscription(t, n, r) {
            return t.then(o => n ? .(o), o => r ? .(o)), {
                unsubscribe: () => {
                    n = null, r = null
                }
            }
        }
        dispose(t) {
            t.unsubscribe()
        }
    },
    DR = new kh,
    _R = new Lh,
    xR = (() => {
        class e {
            _ref;
            _latestValue = null;
            markForCheckOnValueUpdate = !0;
            _subscription = null;
            _obj = null;
            _strategy = null;
            applicationErrorHandler = h(Ke);
            constructor(n) {
                this._ref = n
            }
            ngOnDestroy() {
                this._subscription && this._dispose(), this._ref = null
            }
            transform(n) {
                if (!this._obj) {
                    if (n) try {
                        this.markForCheckOnValueUpdate = !1, this._subscribe(n)
                    } finally {
                        this.markForCheckOnValueUpdate = !0
                    }
                    return this._latestValue
                }
                return n !== this._obj ? (this._dispose(), this.transform(n)) : this._latestValue
            }
            _subscribe(n) {
                this._obj = n, this._strategy = this._selectStrategy(n), this._subscription = this._strategy.createSubscription(n, r => this._updateLatestValue(n, r), r => this.applicationErrorHandler(r))
            }
            _selectStrategy(n) {
                if (Yr(n)) return DR;
                if (El(n)) return _R;
                throw Ns(e, n)
            }
            _dispose() {
                this._strategy.dispose(this._subscription), this._latestValue = null, this._subscription = null, this._obj = null
            }
            _updateLatestValue(n, r) {
                n === this._obj && (this._latestValue = r, this.markForCheckOnValueUpdate && this._ref ? .markForCheck())
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(ir, 16))
            };
            static\ u0275pipe = Sn({
                name: "async",
                type: e,
                pure: !1
            })
        }
        return e
    })();
var CR = /(?:[0-9A-Za-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD50-\uDD52\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E]|\uD838[\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF38\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A])\S*/g,
    IR = (() => {
        class e {
            transform(n) {
                return n == null ? null : (I_(e, n), n.replace(CR, r => r[0].toUpperCase() + r.slice(1).toLowerCase()))
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275pipe = Sn({
                name: "titlecase",
                type: e,
                pure: !0
            })
        }
        return e
    })(),
    TR = (() => {
        class e {
            transform(n) {
                return n == null ? null : (I_(e, n), n.toUpperCase())
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275pipe = Sn({
                name: "uppercase",
                type: e,
                pure: !0
            })
        }
        return e
    })();

function I_(e, t) {
    if (typeof t != "string") throw Ns(e, t)
}
var SR = "mediumDate",
    T_ = new v(""),
    S_ = new v(""),
    bR = (() => {
        class e {
            locale;
            defaultTimezone;
            defaultOptions;
            constructor(n, r, o) {
                this.locale = n, this.defaultTimezone = r, this.defaultOptions = o
            }
            transform(n, r, o, i) {
                if (n == null || n === "" || n !== n) return null;
                try {
                    let s = r ? ? this.defaultOptions ? .dateFormat ? ? SR,
                        a = o ? ? this.defaultOptions ? .timezone ? ? this.defaultTimezone ? ? void 0;
                    return v_(n, s, i || this.locale, a)
                } catch (s) {
                    throw Ns(e, s.message)
                }
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Wo, 16), k(T_, 24), k(S_, 24))
            };
            static\ u0275pipe = Sn({
                name: "date",
                type: e,
                pure: !0
            })
        }
        return e
    })();

function wR(e, t) {
    return {
        key: e,
        value: t
    }
}
var AR = (() => {
    class e {
        differs;
        constructor(n) {
            this.differs = n
        }
        differ;
        keyValues = [];
        compareFn = l_;
        transform(n, r = l_) {
            if (!n || !(n instanceof Map) && typeof n != "object") return null;
            this.differ ? ? = this.differs.find(n).create();
            let o = this.differ.diff(n),
                i = r !== this.compareFn;
            return o && (this.keyValues = [], o.forEachItem(s => {
                this.keyValues.push(wR(s.key, s.currentValue))
            })), (o || i) && (r && this.keyValues.sort(r), this.compareFn = r), this.keyValues
        }
        static\ u0275fac = function(r) {
            return new(r || e)(k(Ml, 16))
        };
        static\ u0275pipe = Sn({
            name: "keyvalue",
            type: e,
            pure: !1
        })
    }
    return e
})();

function l_(e, t) {
    let n = e.key,
        r = t.key;
    if (n === r) return 0;
    if (n == null) return 1;
    if (r == null) return -1;
    if (typeof n == "string" && typeof r == "string") return n < r ? -1 : 1;
    if (typeof n == "number" && typeof r == "number") return n - r;
    if (typeof n == "boolean" && typeof r == "boolean") return n < r ? -1 : 1;
    let o = String(n),
        i = String(r);
    return o == i ? 0 : o < i ? -1 : 1
}
var MR = (() => {
    class e {
        _locale;
        constructor(n) {
            this._locale = n
        }
        transform(n, r, o) {
            if (!NR(n)) return null;
            o || = this._locale;
            try {
                let i = RR(n);
                return x_(i, o, r)
            } catch (i) {
                throw Ns(e, i.message)
            }
        }
        static\ u0275fac = function(r) {
            return new(r || e)(k(Wo, 16))
        };
        static\ u0275pipe = Sn({
            name: "number",
            type: e,
            pure: !0
        })
    }
    return e
})();

function NR(e) {
    return !(e == null || e === "" || e !== e)
}

function RR(e) {
    if (typeof e == "string" && !isNaN(Number(e) - parseFloat(e))) return Number(e);
    if (typeof e != "number") throw new g(2309, !1);
    return e
}
var OR = (() => {
    class e {
        transform(n, r, o) {
            if (n == null) return null;
            if (!(typeof n == "string" || Array.isArray(n))) throw Ns(e, n);
            return n.slice(r, o)
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275pipe = Sn({
            name: "slice",
            type: e,
            pure: !1
        })
    }
    return e
})();
var jh = (() => {
    class e {
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275mod = Ut({
            type: e
        });
        static\ u0275inj = ft({})
    }
    return e
})();

function Rs(e, t) {
    t = encodeURIComponent(t);
    for (let n of e.split(";")) {
        let r = n.indexOf("="),
            [o, i] = r == -1 ? [n, ""] : [n.slice(0, r), n.slice(r + 1)];
        if (o.trim() === t) return decodeURIComponent(i)
    }
    return null
}
var Jr = class {};
var Vh = "browser",
    PR = "server";

function CK(e) {
    return e === Vh
}

function IK(e) {
    return e === PR
}
var $h = (() => {
        class e {
            static\ u0275prov = y({
                token: e,
                providedIn: "root",
                factory: () => new Hh(h(Z), window)
            })
        }
        return e
    })(),
    Hh = class {
        document;
        window;
        offset = () => [0, 0];
        constructor(t, n) {
            this.document = t, this.window = n
        }
        setOffset(t) {
            Array.isArray(t) ? this.offset = () => t : this.offset = t
        }
        getScrollPosition() {
            return [this.window.scrollX, this.window.scrollY]
        }
        scrollToPosition(t, n) {
            this.window.scrollTo(B(E({}, n), {
                left: t[0],
                top: t[1]
            }))
        }
        scrollToAnchor(t, n) {
            let r = LR(this.document, t);
            r && (this.scrollToElement(r, n), r.focus({
                preventScroll: !0
            }))
        }
        setHistoryScrollRestoration(t) {
            try {
                this.window.history.scrollRestoration = t
            } catch (n) {
                console.warn(dt(2400, !1))
            }
        }
        scrollToElement(t, n) {
            let r = t.getBoundingClientRect(),
                o = r.left + this.window.pageXOffset,
                i = r.top + this.window.pageYOffset,
                s = this.offset();
            this.window.scrollTo(B(E({}, n), {
                left: o - s[0],
                top: i - s[1]
            }))
        }
    };

function LR(e, t) {
    let n = e.getElementById(t) || e.getElementsByName(t)[0];
    if (n) return n;
    if (typeof e.createTreeWalker == "function" && e.body && typeof e.body.attachShadow == "function") {
        let r = e.createTreeWalker(e.body, NodeFilter.SHOW_ELEMENT),
            o = r.currentNode;
        for (; o;) {
            let i = o.shadowRoot;
            if (i) {
                let s = i.getElementById(t) || i.querySelector(`[name="${t}"]`);
                if (s) return s
            }
            o = r.nextNode()
        }
    }
    return null
}
var w_ = e => e.src,
    kR = new v("", {
        factory: () => w_
    });
var b_ = /^((\s*\d+w\s*(,|$)){1,})$/;
var FR = [1, 2],
    UR = 640;
var BR = 1920,
    jR = 1080;
var TK = (() => {
    class e {
        imageLoader = h(kR);
        config = HR(h(Qc));
        renderer = h(Tn);
        imgElement = h(it).nativeElement;
        injector = h(fe);
        destroyRef = h(He);
        lcpObserver;
        _renderedSrc = null;
        ngSrc;
        ngSrcset;
        sizes;
        width;
        height;
        decoding;
        loading;
        priority = !1;
        loaderParams;
        disableOptimizedSrcset = !1;
        fill = !1;
        placeholder;
        placeholderConfig;
        src;
        srcset;
        constructor() {
            this.destroyRef.onDestroy(() => {
                this.renderer.removeAttribute(this.imgElement, "loading")
            })
        }
        ngOnInit() {
            Ye("NgOptimizedImage"), this.placeholder && this.removePlaceholderOnLoad(this.imgElement), this.setHostAttributes()
        }
        setHostAttributes() {
            this.fill ? this.sizes || = "100vw" : (this.setHostAttribute("width", this.width.toString()), this.setHostAttribute("height", this.height.toString())), this.setHostAttribute("loading", this.getLoadingBehavior()), this.setHostAttribute("fetchpriority", this.getFetchPriority()), this.setHostAttribute("decoding", this.getDecoding()), this.setHostAttribute("ng-img", "true");
            let n = this.updateSrcAndSrcset();
            this.sizes ? this.getLoadingBehavior() === "lazy" ? this.setHostAttribute("sizes", "auto, " + this.sizes) : this.setHostAttribute("sizes", this.sizes) : this.ngSrcset && b_.test(this.ngSrcset) && this.getLoadingBehavior() === "lazy" && this.setHostAttribute("sizes", "auto, 100vw")
        }
        ngOnChanges(n) {
            if (n.ngSrc && !n.ngSrc.isFirstChange()) {
                let r = this._renderedSrc;
                this.updateSrcAndSrcset(!0)
            }
        }
        getAspectRatio() {
            return this.width && this.height && this.height !== 0 ? this.width / this.height : null
        }
        callImageLoader(n) {
            let r = n;
            this.loaderParams && (r.loaderParams = this.loaderParams);
            let o = this.getAspectRatio();
            return o !== null && r.width && (r.height = Math.round(r.width / o)), this.imageLoader(r)
        }
        getLoadingBehavior() {
            return !this.priority && this.loading !== void 0 ? this.loading : this.priority ? "eager" : "lazy"
        }
        getFetchPriority() {
            return this.priority ? "high" : "auto"
        }
        getDecoding() {
            return this.priority ? "sync" : this.decoding ? ? "auto"
        }
        getRewrittenSrc() {
            if (!this._renderedSrc) {
                let n = {
                    src: this.ngSrc
                };
                this._renderedSrc = this.callImageLoader(n)
            }
            return this._renderedSrc
        }
        getRewrittenSrcset() {
            let n = b_.test(this.ngSrcset);
            return this.ngSrcset.split(",").filter(o => o !== "").map(o => {
                o = o.trim();
                let i = n ? parseFloat(o) : parseFloat(o) * this.width;
                return `${this.callImageLoader({src:this.ngSrc,width:i})} ${o}`
            }).join(", ")
        }
        getAutomaticSrcset() {
            return this.sizes ? this.getResponsiveSrcset() : this.getFixedSrcset()
        }
        getResponsiveSrcset() {
            let {
                breakpoints: n
            } = this.config, r = n;
            return this.sizes ? .trim() === "100vw" && (r = n.filter(i => i >= UR)), r.map(i => `${this.callImageLoader({src:this.ngSrc,width:i})} ${i}w`).join(", ")
        }
        updateSrcAndSrcset(n = !1) {
            n && (this._renderedSrc = null);
            let r = this.getRewrittenSrc();
            this.setHostAttribute("src", r);
            let o;
            return this.ngSrcset ? o = this.getRewrittenSrcset() : this.shouldGenerateAutomaticSrcset() && (o = this.getAutomaticSrcset()), o && this.setHostAttribute("srcset", o), o
        }
        getFixedSrcset() {
            return FR.map(r => `${this.callImageLoader({src:this.ngSrc,width:this.width*r})} ${r}x`).join(", ")
        }
        shouldGenerateAutomaticSrcset() {
            let n = !1;
            return this.sizes || (n = this.width > BR || this.height > jR), !this.disableOptimizedSrcset && !this.srcset && this.imageLoader !== w_ && !n
        }
        generatePlaceholder(n) {
            let {
                placeholderResolution: r
            } = this.config;
            return n === !0 ? `url(${this.callImageLoader({src:this.ngSrc,width:r,isPlaceholder:!0})})` : typeof n == "string" ? `url(${n})` : null
        }
        shouldBlurPlaceholder(n) {
            return !n || !n.hasOwnProperty("blur") ? !0 : !!n.blur
        }
        removePlaceholderOnLoad(n) {
            let r = () => {
                    let s = this.injector.get(ir);
                    o(), i(), this.placeholder = !1, s.markForCheck()
                },
                o = this.renderer.listen(n, "load", r),
                i = this.renderer.listen(n, "error", r);
            this.destroyRef.onDestroy(() => {
                o(), i()
            }), VR(n, r)
        }
        setHostAttribute(n, r) {
            this.renderer.setAttribute(this.imgElement, n, r)
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275dir = be({
            type: e,
            selectors: [
                ["img", "ngSrc", ""]
            ],
            hostVars: 18,
            hostBindings: function(r, o) {
                r & 2 && Tl("position", o.fill ? "absolute" : null)("width", o.fill ? "100%" : null)("height", o.fill ? "100%" : null)("inset", o.fill ? "0" : null)("background-size", o.placeholder ? "cover" : null)("background-position", o.placeholder ? "50% 50%" : null)("background-repeat", o.placeholder ? "no-repeat" : null)("background-image", o.placeholder ? o.generatePlaceholder(o.placeholder) : null)("filter", o.placeholder && o.shouldBlurPlaceholder(o.placeholderConfig) ? "blur(15px)" : null)
            },
            inputs: {
                ngSrc: [2, "ngSrc", "ngSrc", $R],
                ngSrcset: "ngSrcset",
                sizes: "sizes",
                width: [2, "width", "width", Sh],
                height: [2, "height", "height", Sh],
                decoding: "decoding",
                loading: "loading",
                priority: [2, "priority", "priority", bn],
                loaderParams: "loaderParams",
                disableOptimizedSrcset: [2, "disableOptimizedSrcset", "disableOptimizedSrcset", bn],
                fill: [2, "fill", "fill", bn],
                placeholder: [2, "placeholder", "placeholder", GR],
                placeholderConfig: "placeholderConfig",
                src: "src",
                srcset: "srcset"
            },
            features: [rn]
        })
    }
    return e
})();

function HR(e) {
    let t = {};
    return e.breakpoints && (t.breakpoints = e.breakpoints.sort((n, r) => n - r)), Object.assign({}, Jc, e, t)
}

function VR(e, t) {
    e.complete && e.naturalWidth && t()
}

function $R(e) {
    return typeof e == "string" ? e : Ve(e)
}

function GR(e) {
    return typeof e == "string" && e !== "true" && e !== "false" && e !== "" ? e : bn(e)
}
var Os = class {
        _doc;
        constructor(t) {
            this._doc = t
        }
        manager
    },
    Gl = (() => {
        class e extends Os {
            constructor(n) {
                super(n)
            }
            supports(n) {
                return !0
            }
            addEventListener(n, r, o, i) {
                return n.addEventListener(r, o, i), () => this.removeEventListener(n, r, o, i)
            }
            removeEventListener(n, r, o, i) {
                return n.removeEventListener(r, o, i)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Z))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    ql = new v(""),
    qh = (() => {
        class e {
            _zone;
            _plugins;
            _eventNameToPlugin = new Map;
            constructor(n, r) {
                this._zone = r, n.forEach(s => {
                    s.manager = this
                });
                let o = n.filter(s => !(s instanceof Gl));
                this._plugins = o.slice().reverse();
                let i = n.find(s => s instanceof Gl);
                i && this._plugins.push(i)
            }
            addEventListener(n, r, o, i) {
                return this._findPluginFor(r).addEventListener(n, r, o, i)
            }
            getZone() {
                return this._zone
            }
            _findPluginFor(n) {
                let r = this._eventNameToPlugin.get(n);
                if (r) return r;
                if (r = this._plugins.find(i => i.supports(n)), !r) throw new g(5101, !1);
                return this._eventNameToPlugin.set(n, r), r
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(ql), _(Q))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    Gh = "ng-app-id";

function A_(e) {
    for (let t of e) t.remove()
}

function M_(e, t) {
    let n = t.createElement("style");
    return n.textContent = e, n
}

function zR(e, t, n, r) {
    let o = e.head ? .querySelectorAll(`style[${Gh}="${t}"],link[${Gh}="${t}"]`);
    if (o)
        for (let i of o) i.removeAttribute(Gh), i instanceof HTMLLinkElement ? r.set(i.href.slice(i.href.lastIndexOf("/") + 1), {
            usage: 0,
            elements: [i]
        }) : i.textContent && n.set(i.textContent, {
            usage: 0,
            elements: [i]
        })
}

function zh(e, t) {
    let n = t.createElement("link");
    return n.setAttribute("rel", "stylesheet"), n.setAttribute("href", e), n
}
var Kh = (() => {
        class e {
            doc;
            appId;
            nonce;
            inline = new Map;
            external = new Map;
            hosts = new Set;
            constructor(n, r, o, i = {}) {
                this.doc = n, this.appId = r, this.nonce = o, zR(n, r, this.inline, this.external), this.hosts.add(n.head)
            }
            addStyles(n, r) {
                for (let o of n) this.addUsage(o, this.inline, M_);
                r ? .forEach(o => this.addUsage(o, this.external, zh))
            }
            removeStyles(n, r) {
                for (let o of n) this.removeUsage(o, this.inline);
                r ? .forEach(o => this.removeUsage(o, this.external))
            }
            addUsage(n, r, o) {
                let i = r.get(n);
                i ? i.usage++ : r.set(n, {
                    usage: 1,
                    elements: [...this.hosts].map(s => this.addElement(s, o(n, this.doc)))
                })
            }
            removeUsage(n, r) {
                let o = r.get(n);
                o && (o.usage--, o.usage <= 0 && (A_(o.elements), r.delete(n)))
            }
            ngOnDestroy() {
                for (let [, {
                        elements: n
                    }] of [...this.inline, ...this.external]) A_(n);
                this.hosts.clear()
            }
            addHost(n) {
                this.hosts.add(n);
                for (let [r, {
                        elements: o
                    }] of this.inline) o.push(this.addElement(n, M_(r, this.doc)));
                for (let [r, {
                        elements: o
                    }] of this.external) o.push(this.addElement(n, zh(r, this.doc)))
            }
            removeHost(n) {
                this.hosts.delete(n)
            }
            addElement(n, r) {
                return this.nonce && r.setAttribute("nonce", this.nonce), n.appendChild(r)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Z), _(ls), _(ds, 8), _(us))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    Wh = {
        svg: "http://www.w3.org/2000/svg",
        xhtml: "http://www.w3.org/1999/xhtml",
        xlink: "http://www.w3.org/1999/xlink",
        xml: "http://www.w3.org/XML/1998/namespace",
        xmlns: "http://www.w3.org/2000/xmlns/",
        math: "http://www.w3.org/1998/Math/MathML"
    },
    Yh = /%COMP%/g;
var R_ = "%COMP%",
    qR = `_nghost-${R_}`,
    KR = `_ngcontent-${R_}`,
    YR = !0,
    JR = new v("", {
        factory: () => YR
    });

function QR(e) {
    return KR.replace(Yh, e)
}

function ZR(e) {
    return qR.replace(Yh, e)
}

function O_(e, t) {
    return t.map(n => n.replace(Yh, e))
}
var Jh = (() => {
        class e {
            eventManager;
            sharedStylesHost;
            appId;
            removeStylesOnCompDestroy;
            doc;
            ngZone;
            nonce;
            tracingService;
            rendererByCompId = new Map;
            defaultRenderer;
            constructor(n, r, o, i, s, a, c = null, l = null) {
                this.eventManager = n, this.sharedStylesHost = r, this.appId = o, this.removeStylesOnCompDestroy = i, this.doc = s, this.ngZone = a, this.nonce = c, this.tracingService = l, this.defaultRenderer = new Ps(n, s, a, this.tracingService)
            }
            createRenderer(n, r) {
                if (!n || !r) return this.defaultRenderer;
                let o = this.getOrCreateRenderer(n, r);
                return o instanceof zl ? o.applyToHost(n) : o instanceof Ls && o.applyStyles(), o
            }
            getOrCreateRenderer(n, r) {
                let o = this.rendererByCompId,
                    i = o.get(r.id);
                if (!i) {
                    let s = this.doc,
                        a = this.ngZone,
                        c = this.eventManager,
                        l = this.sharedStylesHost,
                        u = this.removeStylesOnCompDestroy,
                        d = this.tracingService;
                    switch (r.encapsulation) {
                        case kt.Emulated:
                            i = new zl(c, l, r, this.appId, u, s, a, d);
                            break;
                        case kt.ShadowDom:
                            return new Wl(c, n, r, s, a, this.nonce, d, l);
                        case kt.ExperimentalIsolatedShadowDom:
                            return new Wl(c, n, r, s, a, this.nonce, d);
                        default:
                            i = new Ls(c, l, r, u, s, a, d);
                            break
                    }
                    o.set(r.id, i)
                }
                return i
            }
            ngOnDestroy() {
                this.rendererByCompId.clear()
            }
            componentReplaced(n) {
                this.rendererByCompId.delete(n)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(qh), _(Kh), _(ls), _(JR), _(Z), _(Q), _(ds), _(sn, 8))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    Ps = class {
        eventManager;
        doc;
        ngZone;
        tracingService;
        data = Object.create(null);
        throwOnSyntheticProps = !0;
        constructor(t, n, r, o) {
            this.eventManager = t, this.doc = n, this.ngZone = r, this.tracingService = o
        }
        destroy() {}
        destroyNode = null;
        createElement(t, n) {
            return n ? this.doc.createElementNS(Wh[n] || n, t) : this.doc.createElement(t)
        }
        createComment(t) {
            return this.doc.createComment(t)
        }
        createText(t) {
            return this.doc.createTextNode(t)
        }
        appendChild(t, n) {
            (N_(t) ? t.content : t).appendChild(n)
        }
        insertBefore(t, n, r) {
            t && (N_(t) ? t.content : t).insertBefore(n, r)
        }
        removeChild(t, n) {
            n.remove()
        }
        selectRootElement(t, n) {
            let r = typeof t == "string" ? this.doc.querySelector(t) : t;
            if (!r) throw new g(-5104, !1);
            return n || (r.textContent = ""), r
        }
        parentNode(t) {
            return t.parentNode
        }
        nextSibling(t) {
            return t.nextSibling
        }
        setAttribute(t, n, r, o) {
            if (o) {
                n = o + ":" + n;
                let i = Wh[o];
                i ? t.setAttributeNS(i, n, r) : t.setAttribute(n, r)
            } else t.setAttribute(n, r)
        }
        removeAttribute(t, n, r) {
            if (r) {
                let o = Wh[r];
                o ? t.removeAttributeNS(o, n) : t.removeAttribute(`${r}:${n}`)
            } else t.removeAttribute(n)
        }
        addClass(t, n) {
            t.classList.add(n)
        }
        removeClass(t, n) {
            t.classList.remove(n)
        }
        setStyle(t, n, r, o) {
            o & (Ft.DashCase | Ft.Important) ? t.style.setProperty(n, r, o & Ft.Important ? "important" : "") : t.style[n] = r
        }
        removeStyle(t, n, r) {
            r & Ft.DashCase ? t.style.removeProperty(n) : t.style[n] = ""
        }
        setProperty(t, n, r) {
            t != null && (t[n] = r)
        }
        setValue(t, n) {
            t.nodeValue = n
        }
        listen(t, n, r, o) {
            if (typeof t == "string" && (t = jt().getGlobalEventTarget(this.doc, t), !t)) throw new g(5102, !1);
            let i = this.decoratePreventDefault(r);
            return this.tracingService ? .wrapEventListener && (i = this.tracingService.wrapEventListener(t, n, i)), this.eventManager.addEventListener(t, n, i, o)
        }
        decoratePreventDefault(t) {
            return n => {
                if (n === "__ngUnwrap__") return t;
                t(n) === !1 && n.preventDefault()
            }
        }
    };

function N_(e) {
    return e.tagName === "TEMPLATE" && e.content !== void 0
}
var Wl = class extends Ps {
        hostEl;
        sharedStylesHost;
        shadowRoot;
        constructor(t, n, r, o, i, s, a, c) {
            super(t, o, i, a), this.hostEl = n, this.sharedStylesHost = c, this.shadowRoot = n.attachShadow({
                mode: "open"
            }), this.sharedStylesHost && this.sharedStylesHost.addHost(this.shadowRoot);
            let l = r.styles;
            l = O_(r.id, l);
            for (let d of l) {
                let f = document.createElement("style");
                s && f.setAttribute("nonce", s), f.textContent = d, this.shadowRoot.appendChild(f)
            }
            let u = r.getExternalStyles ? .();
            if (u)
                for (let d of u) {
                    let f = zh(d, o);
                    s && f.setAttribute("nonce", s), this.shadowRoot.appendChild(f)
                }
        }
        nodeOrShadowRoot(t) {
            return t === this.hostEl ? this.shadowRoot : t
        }
        appendChild(t, n) {
            return super.appendChild(this.nodeOrShadowRoot(t), n)
        }
        insertBefore(t, n, r) {
            return super.insertBefore(this.nodeOrShadowRoot(t), n, r)
        }
        removeChild(t, n) {
            return super.removeChild(null, n)
        }
        parentNode(t) {
            return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(t)))
        }
        destroy() {
            this.sharedStylesHost && this.sharedStylesHost.removeHost(this.shadowRoot)
        }
    },
    Ls = class extends Ps {
        sharedStylesHost;
        removeStylesOnCompDestroy;
        styles;
        styleUrls;
        constructor(t, n, r, o, i, s, a, c) {
            super(t, i, s, a), this.sharedStylesHost = n, this.removeStylesOnCompDestroy = o;
            let l = r.styles;
            this.styles = c ? O_(c, l) : l, this.styleUrls = r.getExternalStyles ? .(c)
        }
        applyStyles() {
            this.sharedStylesHost.addStyles(this.styles, this.styleUrls)
        }
        destroy() {
            this.removeStylesOnCompDestroy && $r.size === 0 && this.sharedStylesHost.removeStyles(this.styles, this.styleUrls)
        }
    },
    zl = class extends Ls {
        contentAttr;
        hostAttr;
        constructor(t, n, r, o, i, s, a, c) {
            let l = o + "-" + r.id;
            super(t, n, r, i, s, a, c, l), this.contentAttr = QR(l), this.hostAttr = ZR(l)
        }
        applyToHost(t) {
            this.applyStyles(), this.setAttribute(t, this.hostAttr, "")
        }
        createElement(t, n) {
            let r = super.createElement(t, n);
            return super.setAttribute(r, this.contentAttr, ""), r
        }
    };
var Kl = class e extends Ss {
        supportsDOMEvents = !0;
        static makeCurrent() {
            bh(new e)
        }
        onAndCancel(t, n, r, o) {
            return t.addEventListener(n, r, o), () => {
                t.removeEventListener(n, r, o)
            }
        }
        dispatchEvent(t, n) {
            t.dispatchEvent(n)
        }
        remove(t) {
            t.remove()
        }
        createElement(t, n) {
            return n = n || this.getDefaultDocument(), n.createElement(t)
        }
        createHtmlDocument() {
            return document.implementation.createHTMLDocument("fakeTitle")
        }
        getDefaultDocument() {
            return document
        }
        isElementNode(t) {
            return t.nodeType === Node.ELEMENT_NODE
        }
        isShadowRoot(t) {
            return t instanceof DocumentFragment
        }
        getGlobalEventTarget(t, n) {
            return n === "window" ? window : n === "document" ? t : n === "body" ? t.body : null
        }
        getBaseHref(t) {
            let n = XR();
            return n == null ? null : eO(n)
        }
        resetBaseElement() {
            ks = null
        }
        getUserAgent() {
            return window.navigator.userAgent
        }
        getCookie(t) {
            return Rs(document.cookie, t)
        }
    },
    ks = null;

function XR() {
    return ks = ks || document.head.querySelector("base"), ks ? ks.getAttribute("href") : null
}

function eO(e) {
    return new URL(e, document.baseURI).pathname
}
var Yl = class {
        addToWindow(t) {
            ge.getAngularTestability = (r, o = !0) => {
                let i = t.findTestabilityInTree(r, o);
                if (i == null) throw new g(5103, !1);
                return i
            }, ge.getAllAngularTestabilities = () => t.getAllTestabilities(), ge.getAllAngularRootElements = () => t.getAllRootElements();
            let n = r => {
                let o = ge.getAllAngularTestabilities(),
                    i = o.length,
                    s = function() {
                        i--, i == 0 && r()
                    };
                o.forEach(a => {
                    a.whenStable(s)
                })
            };
            ge.frameworkStabilizers || (ge.frameworkStabilizers = []), ge.frameworkStabilizers.push(n)
        }
        findTestabilityInTree(t, n, r) {
            if (n == null) return null;
            let o = t.getTestability(n);
            return o ? ? (r ? jt().isShadowRoot(n) ? this.findTestabilityInTree(t, n.host, !0) : this.findTestabilityInTree(t, n.parentElement, !0) : null)
        }
    },
    tO = (() => {
        class e {
            build() {
                return new XMLHttpRequest
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    P_ = ["alt", "control", "meta", "shift"],
    nO = {
        "\b": "Backspace",
        "	": "Tab",
        "\x7F": "Delete",
        "\x1B": "Escape",
        Del: "Delete",
        Esc: "Escape",
        Left: "ArrowLeft",
        Right: "ArrowRight",
        Up: "ArrowUp",
        Down: "ArrowDown",
        Menu: "ContextMenu",
        Scroll: "ScrollLock",
        Win: "OS"
    },
    rO = {
        alt: e => e.altKey,
        control: e => e.ctrlKey,
        meta: e => e.metaKey,
        shift: e => e.shiftKey
    },
    L_ = (() => {
        class e extends Os {
            constructor(n) {
                super(n)
            }
            supports(n) {
                return e.parseEventName(n) != null
            }
            addEventListener(n, r, o, i) {
                let s = e.parseEventName(r),
                    a = e.eventCallback(s.fullKey, o, this.manager.getZone());
                return this.manager.getZone().runOutsideAngular(() => jt().onAndCancel(n, s.domEventName, a, i))
            }
            static parseEventName(n) {
                let r = n.toLowerCase().split("."),
                    o = r.shift();
                if (r.length === 0 || !(o === "keydown" || o === "keyup")) return null;
                let i = e._normalizeKey(r.pop()),
                    s = "",
                    a = r.indexOf("code");
                if (a > -1 && (r.splice(a, 1), s = "code."), P_.forEach(l => {
                        let u = r.indexOf(l);
                        u > -1 && (r.splice(u, 1), s += l + ".")
                    }), s += i, r.length != 0 || i.length === 0) return null;
                let c = {};
                return c.domEventName = o, c.fullKey = s, c
            }
            static matchEventFullKeyCode(n, r) {
                let o = nO[n.key] || n.key,
                    i = "";
                return r.indexOf("code.") > -1 && (o = n.code, i = "code."), o == null || !o ? !1 : (o = o.toLowerCase(), o === " " ? o = "space" : o === "." && (o = "dot"), P_.forEach(s => {
                    if (s !== o) {
                        let a = rO[s];
                        a(n) && (i += s + ".")
                    }
                }), i += o, i === r)
            }
            static eventCallback(n, r, o) {
                return i => {
                    e.matchEventFullKeyCode(i, n) && o.runGuarded(() => r(i))
                }
            }
            static _normalizeKey(n) {
                return n === "esc" ? "escape" : n
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Z))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })();

function oO() {
    Kl.makeCurrent()
}

function iO() {
    return new ut
}

function sO() {
    return vp(document), document
}
var aO = [{
        provide: us,
        useValue: Vh
    }, {
        provide: Yc,
        useValue: oO,
        multi: !0
    }, {
        provide: Z,
        useFactory: sO
    }],
    cO = Ch(QD, "browser", aO);
var lO = [{
        provide: gl,
        useClass: Yl
    }, {
        provide: ml,
        useClass: vs
    }, {
        provide: vs,
        useClass: vs
    }],
    uO = [{
            provide: Bi,
            useValue: "root"
        }, {
            provide: ut,
            useFactory: iO
        }, {
            provide: ql,
            useClass: Gl,
            multi: !0
        }, {
            provide: ql,
            useClass: L_,
            multi: !0
        }, Jh, Kh, qh, {
            provide: Gr,
            useExisting: Jh
        }, {
            provide: Jr,
            useClass: tO
        },
        []
    ],
    dO = (() => {
        class e {
            constructor() {}
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275mod = Ut({
                type: e
            });
            static\ u0275inj = ft({
                providers: [...uO, ...lO],
                imports: [jh, ZD]
            })
        }
        return e
    })();
var st = class e {
    headers;
    normalizedNames = new Map;
    lazyInit;
    lazyUpdate = null;
    constructor(t) {
        t ? typeof t == "string" ? this.lazyInit = () => {
            this.headers = new Map, t.split(`
`).forEach(n => {
                let r = n.indexOf(":");
                if (r > 0) {
                    let o = n.slice(0, r),
                        i = n.slice(r + 1).trim();
                    this.addHeaderEntry(o, i)
                }
            })
        } : typeof Headers < "u" && t instanceof Headers ? (this.headers = new Map, t.forEach((n, r) => {
            this.addHeaderEntry(r, n)
        })) : this.lazyInit = () => {
            this.headers = new Map, Object.entries(t).forEach(([n, r]) => {
                this.setHeaderEntries(n, r)
            })
        } : this.headers = new Map
    }
    has(t) {
        return this.init(), this.headers.has(t.toLowerCase())
    }
    get(t) {
        this.init();
        let n = this.headers.get(t.toLowerCase());
        return n && n.length > 0 ? n[0] : null
    }
    keys() {
        return this.init(), Array.from(this.normalizedNames.values())
    }
    getAll(t) {
        return this.init(), this.headers.get(t.toLowerCase()) || null
    }
    append(t, n) {
        return this.clone({
            name: t,
            value: n,
            op: "a"
        })
    }
    set(t, n) {
        return this.clone({
            name: t,
            value: n,
            op: "s"
        })
    }
    delete(t, n) {
        return this.clone({
            name: t,
            value: n,
            op: "d"
        })
    }
    maybeSetNormalizedName(t, n) {
        this.normalizedNames.has(n) || this.normalizedNames.set(n, t)
    }
    init() {
        this.lazyInit && (this.lazyInit instanceof e ? this.copyFrom(this.lazyInit) : this.lazyInit(), this.lazyInit = null, this.lazyUpdate && (this.lazyUpdate.forEach(t => this.applyUpdate(t)), this.lazyUpdate = null))
    }
    copyFrom(t) {
        t.init(), Array.from(t.headers.keys()).forEach(n => {
            this.headers.set(n, t.headers.get(n)), this.normalizedNames.set(n, t.normalizedNames.get(n))
        })
    }
    clone(t) {
        let n = new e;
        return n.lazyInit = this.lazyInit && this.lazyInit instanceof e ? this.lazyInit : this, n.lazyUpdate = (this.lazyUpdate || []).concat([t]), n
    }
    applyUpdate(t) {
        let n = t.name.toLowerCase();
        switch (t.op) {
            case "a":
            case "s":
                let r = t.value;
                if (typeof r == "string" && (r = [r]), r.length === 0) return;
                this.maybeSetNormalizedName(t.name, n);
                let o = (t.op === "a" ? this.headers.get(n) : void 0) || [];
                o.push(...r), this.headers.set(n, o);
                break;
            case "d":
                let i = t.value;
                if (!i) this.headers.delete(n), this.normalizedNames.delete(n);
                else {
                    let s = this.headers.get(n);
                    if (!s) return;
                    s = s.filter(a => i.indexOf(a) === -1), s.length === 0 ? (this.headers.delete(n), this.normalizedNames.delete(n)) : this.headers.set(n, s)
                }
                break
        }
    }
    addHeaderEntry(t, n) {
        let r = t.toLowerCase();
        this.maybeSetNormalizedName(t, r), this.headers.has(r) ? this.headers.get(r).push(n) : this.headers.set(r, [n])
    }
    setHeaderEntries(t, n) {
        let r = (Array.isArray(n) ? n : [n]).map(i => i.toString()),
            o = t.toLowerCase();
        this.headers.set(o, r), this.maybeSetNormalizedName(t, o)
    }
    forEach(t) {
        this.init(), Array.from(this.normalizedNames.keys()).forEach(n => t(this.normalizedNames.get(n), this.headers.get(n)))
    }
};
var Ql = class {
        map = new Map;
        set(t, n) {
            return this.map.set(t, n), this
        }
        get(t) {
            return this.map.has(t) || this.map.set(t, t.defaultValue()), this.map.get(t)
        }
        delete(t) {
            return this.map.delete(t), this
        }
        has(t) {
            return this.map.has(t)
        }
        keys() {
            return this.map.keys()
        }
    },
    Zl = class {
        encodeKey(t) {
            return k_(t)
        }
        encodeValue(t) {
            return k_(t)
        }
        decodeKey(t) {
            return decodeURIComponent(t)
        }
        decodeValue(t) {
            return decodeURIComponent(t)
        }
    };

function fO(e, t) {
    let n = new Map;
    return e.length > 0 && e.replace(/^\?/, "").split("&").forEach(o => {
        let i = o.indexOf("="),
            [s, a] = i == -1 ? [t.decodeKey(o), ""] : [t.decodeKey(o.slice(0, i)), t.decodeValue(o.slice(i + 1))],
            c = n.get(s) || [];
        c.push(a), n.set(s, c)
    }), n
}
var pO = /%(\d[a-f0-9])/gi,
    hO = {
        40: "@",
        "3A": ":",
        24: "$",
        "2C": ",",
        "3B": ";",
        "3D": "=",
        "3F": "?",
        "2F": "/"
    };

function k_(e) {
    return encodeURIComponent(e).replace(pO, (t, n) => hO[n] ? ? t)
}

function Jl(e) {
    return `${e}`
}
var Mn = class e {
    map;
    encoder;
    updates = null;
    cloneFrom = null;
    constructor(t = {}) {
        if (this.encoder = t.encoder || new Zl, t.fromString) {
            if (t.fromObject) throw new g(2805, !1);
            this.map = fO(t.fromString, this.encoder)
        } else t.fromObject ? (this.map = new Map, Object.keys(t.fromObject).forEach(n => {
            let r = t.fromObject[n],
                o = Array.isArray(r) ? r.map(Jl) : [Jl(r)];
            this.map.set(n, o)
        })) : this.map = null
    }
    has(t) {
        return this.init(), this.map.has(t)
    }
    get(t) {
        this.init();
        let n = this.map.get(t);
        return n ? n[0] : null
    }
    getAll(t) {
        return this.init(), this.map.get(t) || null
    }
    keys() {
        return this.init(), Array.from(this.map.keys())
    }
    append(t, n) {
        return this.clone({
            param: t,
            value: n,
            op: "a"
        })
    }
    appendAll(t) {
        let n = [];
        return Object.keys(t).forEach(r => {
            let o = t[r];
            Array.isArray(o) ? o.forEach(i => {
                n.push({
                    param: r,
                    value: i,
                    op: "a"
                })
            }) : n.push({
                param: r,
                value: o,
                op: "a"
            })
        }), this.clone(n)
    }
    set(t, n) {
        return this.clone({
            param: t,
            value: n,
            op: "s"
        })
    }
    delete(t, n) {
        return this.clone({
            param: t,
            value: n,
            op: "d"
        })
    }
    toString() {
        return this.init(), this.keys().map(t => {
            let n = this.encoder.encodeKey(t);
            return this.map.get(t).map(r => n + "=" + this.encoder.encodeValue(r)).join("&")
        }).filter(t => t !== "").join("&")
    }
    clone(t) {
        let n = new e({
            encoder: this.encoder
        });
        return n.cloneFrom = this.cloneFrom || this, n.updates = (this.updates || []).concat(t), n
    }
    init() {
        this.map === null && (this.map = new Map), this.cloneFrom !== null && (this.cloneFrom.init(), this.cloneFrom.keys().forEach(t => this.map.set(t, this.cloneFrom.map.get(t))), this.updates.forEach(t => {
            switch (t.op) {
                case "a":
                case "s":
                    let n = (t.op === "a" ? this.map.get(t.param) : void 0) || [];
                    n.push(Jl(t.value)), this.map.set(t.param, n);
                    break;
                case "d":
                    if (t.value !== void 0) {
                        let r = this.map.get(t.param) || [],
                            o = r.indexOf(Jl(t.value));
                        o !== -1 && r.splice(o, 1), r.length > 0 ? this.map.set(t.param, r) : this.map.delete(t.param)
                    } else {
                        this.map.delete(t.param);
                        break
                    }
            }
        }), this.cloneFrom = this.updates = null)
    }
};

function mO(e) {
    switch (e) {
        case "DELETE":
        case "GET":
        case "HEAD":
        case "OPTIONS":
        case "JSONP":
            return !1;
        default:
            return !0
    }
}

function F_(e) {
    return typeof ArrayBuffer < "u" && e instanceof ArrayBuffer
}

function U_(e) {
    return typeof Blob < "u" && e instanceof Blob
}

function B_(e) {
    return typeof FormData < "u" && e instanceof FormData
}

function gO(e) {
    return typeof URLSearchParams < "u" && e instanceof URLSearchParams
}
var j_ = "Content-Type",
    H_ = "Accept",
    $_ = "text/plain",
    G_ = "application/json",
    EO = `${G_}, ${$_}, */*`,
    zo = class e {
        url;
        body = null;
        headers;
        context;
        reportProgress = !1;
        withCredentials = !1;
        credentials;
        keepalive = !1;
        cache;
        priority;
        mode;
        redirect;
        referrer;
        integrity;
        referrerPolicy;
        responseType = "json";
        method;
        params;
        urlWithParams;
        transferCache;
        timeout;
        constructor(t, n, r, o) {
            this.url = n, this.method = t.toUpperCase();
            let i;
            if (mO(this.method) || o ? (this.body = r !== void 0 ? r : null, i = o) : i = r, i) {
                if (this.reportProgress = !!i.reportProgress, this.withCredentials = !!i.withCredentials, this.keepalive = !!i.keepalive, i.responseType && (this.responseType = i.responseType), i.headers && (this.headers = i.headers), i.context && (this.context = i.context), i.params && (this.params = i.params), i.priority && (this.priority = i.priority), i.cache && (this.cache = i.cache), i.credentials && (this.credentials = i.credentials), typeof i.timeout == "number") {
                    if (i.timeout < 1 || !Number.isInteger(i.timeout)) throw new g(2822, "");
                    this.timeout = i.timeout
                }
                i.mode && (this.mode = i.mode), i.redirect && (this.redirect = i.redirect), i.integrity && (this.integrity = i.integrity), i.referrer && (this.referrer = i.referrer), i.referrerPolicy && (this.referrerPolicy = i.referrerPolicy), this.transferCache = i.transferCache
            }
            if (this.headers ? ? = new st, this.context ? ? = new Ql, !this.params) this.params = new Mn, this.urlWithParams = n;
            else {
                let s = this.params.toString();
                if (s.length === 0) this.urlWithParams = n;
                else {
                    let a = n.indexOf("?"),
                        c = a === -1 ? "?" : a < n.length - 1 ? "&" : "";
                    this.urlWithParams = n + c + s
                }
            }
        }
        serializeBody() {
            return this.body === null ? null : typeof this.body == "string" || F_(this.body) || U_(this.body) || B_(this.body) || gO(this.body) ? this.body : this.body instanceof Mn ? this.body.toString() : typeof this.body == "object" || typeof this.body == "boolean" || Array.isArray(this.body) ? JSON.stringify(this.body) : this.body.toString()
        }
        detectContentTypeHeader() {
            return this.body === null || B_(this.body) ? null : U_(this.body) ? this.body.type || null : F_(this.body) ? null : typeof this.body == "string" ? $_ : this.body instanceof Mn ? "application/x-www-form-urlencoded;charset=UTF-8" : typeof this.body == "object" || typeof this.body == "number" || typeof this.body == "boolean" ? G_ : null
        }
        clone(t = {}) {
            let n = t.method || this.method,
                r = t.url || this.url,
                o = t.responseType || this.responseType,
                i = t.keepalive ? ? this.keepalive,
                s = t.priority || this.priority,
                a = t.cache || this.cache,
                c = t.mode || this.mode,
                l = t.redirect || this.redirect,
                u = t.credentials || this.credentials,
                d = t.referrer || this.referrer,
                f = t.integrity || this.integrity,
                p = t.referrerPolicy || this.referrerPolicy,
                m = t.transferCache ? ? this.transferCache,
                x = t.timeout ? ? this.timeout,
                D = t.body !== void 0 ? t.body : this.body,
                I = t.withCredentials ? ? this.withCredentials,
                F = t.reportProgress ? ? this.reportProgress,
                me = t.headers || this.headers,
                ee = t.params || this.params,
                jn = t.context ? ? this.context;
            return t.setHeaders !== void 0 && (me = Object.keys(t.setHeaders).reduce((vi, mr) => vi.set(mr, t.setHeaders[mr]), me)), t.setParams && (ee = Object.keys(t.setParams).reduce((vi, mr) => vi.set(mr, t.setParams[mr]), ee)), new e(n, r, D, {
                params: ee,
                headers: me,
                context: jn,
                reportProgress: F,
                responseType: o,
                withCredentials: I,
                transferCache: m,
                keepalive: i,
                cache: a,
                priority: s,
                timeout: x,
                mode: c,
                redirect: l,
                credentials: u,
                referrer: d,
                integrity: f,
                referrerPolicy: p
            })
        }
    },
    Qr = (function(e) {
        return e[e.Sent = 0] = "Sent", e[e.UploadProgress = 1] = "UploadProgress", e[e.ResponseHeader = 2] = "ResponseHeader", e[e.DownloadProgress = 3] = "DownloadProgress", e[e.Response = 4] = "Response", e[e.User = 5] = "User", e
    })(Qr || {}),
    Ko = class {
        headers;
        status;
        statusText;
        url;
        ok;
        type;
        redirected;
        responseType;
        constructor(t, n = 200, r = "OK") {
            this.headers = t.headers || new st, this.status = t.status !== void 0 ? t.status : n, this.statusText = t.statusText || r, this.url = t.url || null, this.redirected = t.redirected, this.responseType = t.responseType, this.ok = this.status >= 200 && this.status < 300
        }
    },
    Xl = class e extends Ko {
        constructor(t = {}) {
            super(t)
        }
        type = Qr.ResponseHeader;
        clone(t = {}) {
            return new e({
                headers: t.headers || this.headers,
                status: t.status !== void 0 ? t.status : this.status,
                statusText: t.statusText || this.statusText,
                url: t.url || this.url || void 0
            })
        }
    },
    Fs = class e extends Ko {
        body;
        constructor(t = {}) {
            super(t), this.body = t.body !== void 0 ? t.body : null
        }
        type = Qr.Response;
        clone(t = {}) {
            return new e({
                body: t.body !== void 0 ? t.body : this.body,
                headers: t.headers || this.headers,
                status: t.status !== void 0 ? t.status : this.status,
                statusText: t.statusText || this.statusText,
                url: t.url || this.url || void 0,
                redirected: t.redirected ? ? this.redirected,
                responseType: t.responseType ? ? this.responseType
            })
        }
    },
    qo = class extends Ko {
        name = "HttpErrorResponse";
        message;
        error;
        ok = !1;
        constructor(t) {
            super(t, 0, "Unknown Error"), this.status >= 200 && this.status < 300 ? this.message = `Http failure during parsing for ${t.url||"(unknown url)"}` : this.message = `Http failure response for ${t.url||"(unknown url)"}: ${t.status} ${t.statusText}`, this.error = t.error || null
        }
    },
    yO = 200,
    vO = 204;
var DO = new v("");
var _O = /^\)\]\}',?\n/;
var Zh = (() => {
    class e {
        xhrFactory;
        tracingService = h(sn, {
            optional: !0
        });
        constructor(n) {
            this.xhrFactory = n
        }
        maybePropagateTrace(n) {
            return this.tracingService ? .propagate ? this.tracingService.propagate(n) : n
        }
        handle(n) {
            if (n.method === "JSONP") throw new g(-2800, !1);
            let r = this.xhrFactory;
            return R(null).pipe(Ue(() => new P(i => {
                let s = r.build();
                if (s.open(n.method, n.urlWithParams), n.withCredentials && (s.withCredentials = !0), n.headers.forEach((D, I) => s.setRequestHeader(D, I.join(","))), n.headers.has(H_) || s.setRequestHeader(H_, EO), !n.headers.has(j_)) {
                    let D = n.detectContentTypeHeader();
                    D !== null && s.setRequestHeader(j_, D)
                }
                if (n.timeout && (s.timeout = n.timeout), n.responseType) {
                    let D = n.responseType.toLowerCase();
                    s.responseType = D !== "json" ? D : "text"
                }
                let a = n.serializeBody(),
                    c = null,
                    l = () => {
                        if (c !== null) return c;
                        let D = s.statusText || "OK",
                            I = new st(s.getAllResponseHeaders()),
                            F = s.responseURL || n.url;
                        return c = new Xl({
                            headers: I,
                            status: s.status,
                            statusText: D,
                            url: F
                        }), c
                    },
                    u = this.maybePropagateTrace(() => {
                        let {
                            headers: D,
                            status: I,
                            statusText: F,
                            url: me
                        } = l(), ee = null;
                        I !== vO && (ee = typeof s.response > "u" ? s.responseText : s.response), I === 0 && (I = ee ? yO : 0);
                        let jn = I >= 200 && I < 300;
                        if (n.responseType === "json" && typeof ee == "string") {
                            let vi = ee;
                            ee = ee.replace(_O, "");
                            try {
                                ee = ee !== "" ? JSON.parse(ee) : null
                            } catch (mr) {
                                ee = vi, jn && (jn = !1, ee = {
                                    error: mr,
                                    text: ee
                                })
                            }
                        }
                        jn ? (i.next(new Fs({
                            body: ee,
                            headers: D,
                            status: I,
                            statusText: F,
                            url: me || void 0
                        })), i.complete()) : i.error(new qo({
                            error: ee,
                            headers: D,
                            status: I,
                            statusText: F,
                            url: me || void 0
                        }))
                    }),
                    d = this.maybePropagateTrace(D => {
                        let {
                            url: I
                        } = l(), F = new qo({
                            error: D,
                            status: s.status || 0,
                            statusText: s.statusText || "Unknown Error",
                            url: I || void 0
                        });
                        i.error(F)
                    }),
                    f = d;
                n.timeout && (f = this.maybePropagateTrace(D => {
                    let {
                        url: I
                    } = l(), F = new qo({
                        error: new DOMException("Request timed out", "TimeoutError"),
                        status: s.status || 0,
                        statusText: s.statusText || "Request timeout",
                        url: I || void 0
                    });
                    i.error(F)
                }));
                let p = !1,
                    m = this.maybePropagateTrace(D => {
                        p || (i.next(l()), p = !0);
                        let I = {
                            type: Qr.DownloadProgress,
                            loaded: D.loaded
                        };
                        D.lengthComputable && (I.total = D.total), n.responseType === "text" && s.responseText && (I.partialText = s.responseText), i.next(I)
                    }),
                    x = this.maybePropagateTrace(D => {
                        let I = {
                            type: Qr.UploadProgress,
                            loaded: D.loaded
                        };
                        D.lengthComputable && (I.total = D.total), i.next(I)
                    });
                return s.addEventListener("load", u), s.addEventListener("error", d), s.addEventListener("timeout", f), s.addEventListener("abort", d), n.reportProgress && (s.addEventListener("progress", m), a !== null && s.upload && s.upload.addEventListener("progress", x)), s.send(a), i.next({
                    type: Qr.Sent
                }), () => {
                    s.removeEventListener("error", d), s.removeEventListener("abort", d), s.removeEventListener("load", u), s.removeEventListener("timeout", f), n.reportProgress && (s.removeEventListener("progress", m), a !== null && s.upload && s.upload.removeEventListener("progress", x)), s.readyState !== s.DONE && s.abort()
                }
            })))
        }
        static\ u0275fac = function(r) {
            return new(r || e)(_(Jr))
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
        })
    }
    return e
})();

function W_(e, t) {
    return t(e)
}

function xO(e, t) {
    return (n, r) => t.intercept(n, {
        handle: o => e(o, r)
    })
}

function CO(e, t, n) {
    return (r, o) => _e(n, () => t(r, i => e(i, o)))
}
var z_ = new v(""),
    Xh = new v("", {
        factory: () => []
    }),
    q_ = new v(""),
    em = new v("", {
        factory: () => !0
    });

function IO() {
    let e = null;
    return (t, n) => {
        e === null && (e = (h(z_, {
            optional: !0
        }) ? ? []).reduceRight(xO, W_));
        let r = h(Oo);
        if (h(em)) {
            let i = r.add();
            return e(t, n).pipe(Do(i))
        } else return e(t, n)
    }
}
var tm = (() => {
    class e {
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275prov = y({
            token: e,
            factory: function(r) {
                let o = null;
                return r ? o = new(r || e) : o = _(Zh), o
            },
            providedIn: "root"
        })
    }
    return e
})();
var eu = (() => {
        class e {
            backend;
            injector;
            chain = null;
            pendingTasks = h(Oo);
            contributeToStability = h(em);
            constructor(n, r) {
                this.backend = n, this.injector = r
            }
            handle(n) {
                if (this.chain === null) {
                    let r = Array.from(new Set([...this.injector.get(Xh), ...this.injector.get(q_, [])]));
                    this.chain = r.reduceRight((o, i) => CO(o, i, this.injector), W_)
                }
                if (this.contributeToStability) {
                    let r = this.pendingTasks.add();
                    return this.chain(n, o => this.backend.handle(o)).pipe(Do(r))
                } else return this.chain(n, r => this.backend.handle(r))
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(tm), _(re))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    nm = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: function(r) {
                    let o = null;
                    return r ? o = new(r || e) : o = _(eu), o
                },
                providedIn: "root"
            })
        }
        return e
    })();

function Qh(e, t) {
    return {
        body: t,
        headers: e.headers,
        context: e.context,
        observe: e.observe,
        params: e.params,
        reportProgress: e.reportProgress,
        responseType: e.responseType,
        withCredentials: e.withCredentials,
        credentials: e.credentials,
        transferCache: e.transferCache,
        timeout: e.timeout,
        keepalive: e.keepalive,
        priority: e.priority,
        cache: e.cache,
        mode: e.mode,
        redirect: e.redirect,
        integrity: e.integrity,
        referrer: e.referrer,
        referrerPolicy: e.referrerPolicy
    }
}
var tu = (() => {
    class e {
        handler;
        constructor(n) {
            this.handler = n
        }
        request(n, r, o = {}) {
            let i;
            if (n instanceof zo) i = n;
            else {
                let c;
                o.headers instanceof st ? c = o.headers : c = new st(o.headers);
                let l;
                o.params && (o.params instanceof Mn ? l = o.params : l = new Mn({
                    fromObject: o.params
                })), i = new zo(n, r, o.body !== void 0 ? o.body : null, {
                    headers: c,
                    context: o.context,
                    params: l,
                    reportProgress: o.reportProgress,
                    responseType: o.responseType || "json",
                    withCredentials: o.withCredentials,
                    transferCache: o.transferCache,
                    keepalive: o.keepalive,
                    priority: o.priority,
                    cache: o.cache,
                    mode: o.mode,
                    redirect: o.redirect,
                    credentials: o.credentials,
                    referrer: o.referrer,
                    referrerPolicy: o.referrerPolicy,
                    integrity: o.integrity,
                    timeout: o.timeout
                })
            }
            let s = R(i).pipe(qn(c => this.handler.handle(c)));
            if (n instanceof zo || o.observe === "events") return s;
            let a = s.pipe(Ne(c => c instanceof Fs));
            switch (o.observe || "body") {
                case "body":
                    switch (i.responseType) {
                        case "arraybuffer":
                            return a.pipe(j(c => {
                                if (c.body !== null && !(c.body instanceof ArrayBuffer)) throw new g(2806, !1);
                                return c.body
                            }));
                        case "blob":
                            return a.pipe(j(c => {
                                if (c.body !== null && !(c.body instanceof Blob)) throw new g(2807, !1);
                                return c.body
                            }));
                        case "text":
                            return a.pipe(j(c => {
                                if (c.body !== null && typeof c.body != "string") throw new g(2808, !1);
                                return c.body
                            }));
                        default:
                            return a.pipe(j(c => c.body))
                    }
                case "response":
                    return a;
                default:
                    throw new g(2809, !1)
            }
        }
        delete(n, r = {}) {
            return this.request("DELETE", n, r)
        }
        get(n, r = {}) {
            return this.request("GET", n, r)
        }
        head(n, r = {}) {
            return this.request("HEAD", n, r)
        }
        jsonp(n, r) {
            return this.request("JSONP", n, {
                params: new Mn().append(r, "JSONP_CALLBACK"),
                observe: "body",
                responseType: "json"
            })
        }
        options(n, r = {}) {
            return this.request("OPTIONS", n, r)
        }
        patch(n, r, o = {}) {
            return this.request("PATCH", n, Qh(o, r))
        }
        post(n, r, o = {}) {
            return this.request("POST", n, Qh(o, r))
        }
        put(n, r, o = {}) {
            return this.request("PUT", n, Qh(o, r))
        }
        static\ u0275fac = function(r) {
            return new(r || e)(_(nm))
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
        })
    }
    return e
})();
var TO = new v("", {
        factory: () => !0
    }),
    SO = "XSRF-TOKEN",
    bO = new v("", {
        factory: () => SO
    }),
    wO = "X-XSRF-TOKEN",
    AO = new v("", {
        factory: () => wO
    }),
    MO = (() => {
        class e {
            cookieName = h(bO);
            doc = h(Z);
            lastCookieString = "";
            lastToken = null;
            parseCount = 0;
            getToken() {
                let n = this.doc.cookie || "";
                return n !== this.lastCookieString && (this.parseCount++, this.lastToken = Rs(n, this.cookieName), this.lastCookieString = n), this.lastToken
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    K_ = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: function(r) {
                    let o = null;
                    return r ? o = new(r || e) : o = _(MO), o
                },
                providedIn: "root"
            })
        }
        return e
    })();

function NO(e, t) {
    if (!h(TO) || e.method === "GET" || e.method === "HEAD") return t(e);
    try {
        let o = h(wn).href,
            {
                origin: i
            } = new URL(o),
            {
                origin: s
            } = new URL(e.url, i);
        if (i !== s) return t(e)
    } catch (o) {
        return t(e)
    }
    let n = h(K_).getToken(),
        r = h(AO);
    return n != null && !e.headers.has(r) && (e = e.clone({
        headers: e.headers.set(r, n)
    })), t(e)
}
var rm = (function(e) {
    return e[e.Interceptors = 0] = "Interceptors", e[e.LegacyInterceptors = 1] = "LegacyInterceptors", e[e.CustomXsrfConfiguration = 2] = "CustomXsrfConfiguration", e[e.NoXsrfProtection = 3] = "NoXsrfProtection", e[e.JsonpSupport = 4] = "JsonpSupport", e[e.RequestsMadeViaParent = 5] = "RequestsMadeViaParent", e[e.Fetch = 6] = "Fetch", e
})(rm || {});

function RO(e, t) {
    return {\
        u0275kind: e,
        \u0275providers: t
    }
}

function Y_(...e) {
    let t = [tu, eu, {
        provide: nm,
        useExisting: eu
    }, {
        provide: tm,
        useFactory: () => h(DO, {
            optional: !0
        }) ? ? h(Zh)
    }, {
        provide: Xh,
        useValue: NO,
        multi: !0
    }];
    for (let n of e) t.push(...n.\u0275providers);
    return Zn(t)
}
var V_ = new v("");

function J_() {
    return RO(rm.LegacyInterceptors, [{
        provide: V_,
        useFactory: IO
    }, {
        provide: Xh,
        useExisting: V_,
        multi: !0
    }])
}
var OO = (() => {
    class e {
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275mod = Ut({
            type: e
        });
        static\ u0275inj = ft({
            providers: [Y_(J_())]
        })
    }
    return e
})();
var BY = (() => {
        class e {
            _doc;
            _dom;
            constructor(n) {
                this._doc = n, this._dom = jt()
            }
            addTag(n, r = !1) {
                return n ? this._getOrCreateElement(n, r) : null
            }
            addTags(n, r = !1) {
                return n ? n.reduce((o, i) => (i && o.push(this._getOrCreateElement(i, r)), o), []) : []
            }
            getTag(n) {
                return n && this._doc.querySelector(`meta[${n}]`) || null
            }
            getTags(n) {
                if (!n) return [];
                let r = this._doc.querySelectorAll(`meta[${n}]`);
                return r ? [].slice.call(r) : []
            }
            updateTag(n, r) {
                if (!n) return null;
                r = r || this._parseSelector(n);
                let o = this.getTag(r);
                return o ? this._setMetaElementAttributes(n, o) : this._getOrCreateElement(n, !0)
            }
            removeTag(n) {
                this.removeTagElement(this.getTag(n))
            }
            removeTagElement(n) {
                n && this._dom.remove(n)
            }
            _getOrCreateElement(n, r = !1) {
                if (!r) {
                    let s = this._parseSelector(n),
                        a = this.getTags(s).filter(c => this._containsAttributes(n, c))[0];
                    if (a !== void 0) return a
                }
                let o = this._dom.createElement("meta");
                return this._setMetaElementAttributes(n, o), this._doc.getElementsByTagName("head")[0].appendChild(o), o
            }
            _setMetaElementAttributes(n, r) {
                return Object.keys(n).forEach(o => r.setAttribute(this._getMetaKeyMap(o), n[o])), r
            }
            _parseSelector(n) {
                let r = n.name ? "name" : "property";
                return `${r}="${n[r]}"`
            }
            _containsAttributes(n, r) {
                return Object.keys(n).every(o => r.getAttribute(this._getMetaKeyMap(o)) === n[o])
            }
            _getMetaKeyMap(n) {
                return LO[n] || n
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Z))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    LO = {
        httpEquiv: "http-equiv"
    },
    Q_ = (() => {
        class e {
            _doc;
            constructor(n) {
                this._doc = n
            }
            getTitle() {
                return this._doc.title
            }
            setTitle(n) {
                this._doc.title = n || ""
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Z))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })();
var kO = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: function(r) {
                    let o = null;
                    return r ? o = new(r || e) : o = _(FO), o
                },
                providedIn: "root"
            })
        }
        return e
    })(),
    FO = (() => {
        class e extends kO {
            _doc;
            constructor(n) {
                super(), this._doc = n
            }
            sanitize(n, r) {
                if (r == null) return null;
                switch (n) {
                    case vt.NONE:
                        return r;
                    case vt.HTML:
                        return on(r, "HTML") ? Ve(r) : tl(this._doc, String(r)).toString();
                    case vt.STYLE:
                        return on(r, "Style") ? Ve(r) : r;
                    case vt.SCRIPT:
                        if (on(r, "Script")) return Ve(r);
                        throw new g(5200, !1);
                    case vt.URL:
                        return on(r, "URL") ? Ve(r) : fs(String(r));
                    case vt.RESOURCE_URL:
                        if (on(r, "ResourceURL")) return Ve(r);
                        throw new g(5201, !1);
                    default:
                        throw new g(5202, !1)
                }
            }
            bypassSecurityTrustHtml(n) {
                return xp(n)
            }
            bypassSecurityTrustStyle(n) {
                return Cp(n)
            }
            bypassSecurityTrustScript(n) {
                return Ip(n)
            }
            bypassSecurityTrustUrl(n) {
                return Tp(n)
            }
            bypassSecurityTrustResourceUrl(n) {
                return Sp(n)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Z))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })();
var O = "primary",
    Js = Symbol("RouteTitle"),
    cm = class {
        params;
        constructor(t) {
            this.params = t || {}
        }
        has(t) {
            return Object.prototype.hasOwnProperty.call(this.params, t)
        }
        get(t) {
            if (this.has(t)) {
                let n = this.params[t];
                return Array.isArray(n) ? n[0] : n
            }
            return null
        }
        getAll(t) {
            if (this.has(t)) {
                let n = this.params[t];
                return Array.isArray(n) ? n : [n]
            }
            return []
        }
        get keys() {
            return Object.keys(this.params)
        }
    };

function Xr(e) {
    return new cm(e)
}

function om(e, t, n) {
    for (let r = 0; r < e.length; r++) {
        let o = e[r],
            i = t[r];
        if (o[0] === ":") n[o.substring(1)] = i;
        else if (o !== i.path) return !1
    }
    return !0
}

function ox(e, t, n) {
    let r = n.path.split("/"),
        o = r.indexOf("**");
    if (o === -1) {
        if (r.length > e.length || n.pathMatch === "full" && (t.hasChildren() || r.length < e.length)) return null;
        let c = {},
            l = e.slice(0, r.length);
        return om(r, l, c) ? {
            consumed: l,
            posParams: c
        } : null
    }
    if (o !== r.lastIndexOf("**")) return null;
    let i = r.slice(0, o),
        s = r.slice(o + 1);
    if (i.length + s.length > e.length || n.pathMatch === "full" && t.hasChildren() && n.path !== "**") return null;
    let a = {};
    return !om(i, e.slice(0, i.length), a) || !om(s, e.slice(e.length - s.length), a) ? null : {
        consumed: e,
        posParams: a
    }
}

function au(e) {
    return new Promise((t, n) => {
        e.pipe(mn()).subscribe({
            next: r => t(r),
            error: r => n(r)
        })
    })
}

function BO(e, t) {
    if (e.length !== t.length) return !1;
    for (let n = 0; n < e.length; ++n)
        if (!cn(e[n], t[n])) return !1;
    return !0
}

function cn(e, t) {
    let n = e ? lm(e) : void 0,
        r = t ? lm(t) : void 0;
    if (!n || !r || n.length != r.length) return !1;
    let o;
    for (let i = 0; i < n.length; i++)
        if (o = n[i], !ix(e[o], t[o])) return !1;
    return !0
}

function lm(e) {
    return [...Object.keys(e), ...Object.getOwnPropertySymbols(e)]
}

function ix(e, t) {
    if (Array.isArray(e) && Array.isArray(t)) {
        if (e.length !== t.length) return !1;
        let n = [...e].sort(),
            r = [...t].sort();
        return n.every((o, i) => r[i] === o)
    } else return e === t
}

function jO(e) {
    return e.length > 0 ? e[e.length - 1] : null
}

function to(e) {
    return ka(e) ? e : Yr(e) ? J(Promise.resolve(e)) : R(e)
}

function sx(e) {
    return ka(e) ? au(e) : Promise.resolve(e)
}
var HO = {
        exact: cx,
        subset: lx
    },
    ax = {
        exact: VO,
        subset: $O,
        ignored: () => !0
    },
    Cm = {
        paths: "exact",
        fragment: "ignored",
        matrixParams: "ignored",
        queryParams: "exact"
    },
    Vs = {
        paths: "subset",
        fragment: "ignored",
        matrixParams: "ignored",
        queryParams: "subset"
    };

function Im(e, t, n) {
    let r = e instanceof Ge ? e : t.parseUrl(e);
    return Is(() => um(t.lastSuccessfulNavigation() ? .finalUrl ? ? new Ge, r, E(E({}, Vs), n)))
}

function um(e, t, n) {
    return HO[n.paths](e.root, t.root, n.matrixParams) && ax[n.queryParams](e.queryParams, t.queryParams) && !(n.fragment === "exact" && e.fragment !== t.fragment)
}

function VO(e, t) {
    return cn(e, t)
}

function cx(e, t, n) {
    if (!Zr(e.segments, t.segments) || !ou(e.segments, t.segments, n) || e.numberOfChildren !== t.numberOfChildren) return !1;
    for (let r in t.children)
        if (!e.children[r] || !cx(e.children[r], t.children[r], n)) return !1;
    return !0
}

function $O(e, t) {
    return Object.keys(t).length <= Object.keys(e).length && Object.keys(t).every(n => ix(e[n], t[n]))
}

function lx(e, t, n) {
    return ux(e, t, t.segments, n)
}

function ux(e, t, n, r) {
    if (e.segments.length > n.length) {
        let o = e.segments.slice(0, n.length);
        return !(!Zr(o, n) || t.hasChildren() || !ou(o, n, r))
    } else if (e.segments.length === n.length) {
        if (!Zr(e.segments, n) || !ou(e.segments, n, r)) return !1;
        for (let o in t.children)
            if (!e.children[o] || !lx(e.children[o], t.children[o], r)) return !1;
        return !0
    } else {
        let o = n.slice(0, e.segments.length),
            i = n.slice(e.segments.length);
        return !Zr(e.segments, o) || !ou(e.segments, o, r) || !e.children[O] ? !1 : ux(e.children[O], t, i, r)
    }
}

function ou(e, t, n) {
    return t.every((r, o) => ax[n](e[o].parameters, r.parameters))
}
var Ge = class {
        root;
        queryParams;
        fragment;
        _queryParamMap;
        constructor(t = new V([], {}), n = {}, r = null) {
            this.root = t, this.queryParams = n, this.fragment = r
        }
        get queryParamMap() {
            return this._queryParamMap ? ? = Xr(this.queryParams), this._queryParamMap
        }
        toString() {
            return zO.serialize(this)
        }
    },
    V = class {
        segments;
        children;
        parent = null;
        constructor(t, n) {
            this.segments = t, this.children = n, Object.values(n).forEach(r => r.parent = this)
        }
        hasChildren() {
            return this.numberOfChildren > 0
        }
        get numberOfChildren() {
            return Object.keys(this.children).length
        }
        toString() {
            return iu(this)
        }
    },
    ar = class {
        path;
        parameters;
        _parameterMap;
        constructor(t, n) {
            this.path = t, this.parameters = n
        }
        get parameterMap() {
            return this._parameterMap ? ? = Xr(this.parameters), this._parameterMap
        }
        toString() {
            return fx(this)
        }
    };

function GO(e, t) {
    return Zr(e, t) && e.every((n, r) => cn(n.parameters, t[r].parameters))
}

function Zr(e, t) {
    return e.length !== t.length ? !1 : e.every((n, r) => n.path === t[r].path)
}

function WO(e, t) {
    let n = [];
    return Object.entries(e.children).forEach(([r, o]) => {
        r === O && (n = n.concat(t(o, r)))
    }), Object.entries(e.children).forEach(([r, o]) => {
        r !== O && (n = n.concat(t(o, r)))
    }), n
}
var ur = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => new Rn,
                providedIn: "root"
            })
        }
        return e
    })(),
    Rn = class {
        parse(t) {
            let n = new fm(t);
            return new Ge(n.parseRootSegment(), n.parseQueryParams(), n.parseFragment())
        }
        serialize(t) {
            let n = `/${Us(t.root,!0)}`,
                r = YO(t.queryParams),
                o = typeof t.fragment == "string" ? `#${qO(t.fragment)}` : "";
            return `${n}${r}${o}`
        }
    },
    zO = new Rn;

function iu(e) {
    return e.segments.map(t => fx(t)).join("/")
}

function Us(e, t) {
    if (!e.hasChildren()) return iu(e);
    if (t) {
        let n = e.children[O] ? Us(e.children[O], !1) : "",
            r = [];
        return Object.entries(e.children).forEach(([o, i]) => {
            o !== O && r.push(`${o}:${Us(i,!1)}`)
        }), r.length > 0 ? `${n}(${r.join("//")})` : n
    } else {
        let n = WO(e, (r, o) => o === O ? [Us(e.children[O], !1)] : [`${o}:${Us(r,!1)}`]);
        return Object.keys(e.children).length === 1 && e.children[O] != null ? `${iu(e)}/${n[0]}` : `${iu(e)}/(${n.join("//")})`
    }
}

function dx(e) {
    return encodeURIComponent(e).replace(/%40/g, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",")
}

function nu(e) {
    return dx(e).replace(/%3B/gi, ";")
}

function qO(e) {
    return encodeURI(e)
}

function dm(e) {
    return dx(e).replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/%26/gi, "&")
}

function su(e) {
    return decodeURIComponent(e)
}

function Z_(e) {
    return su(e.replace(/\+/g, "%20"))
}

function fx(e) {
    return `${dm(e.path)}${KO(e.parameters)}`
}

function KO(e) {
    return Object.entries(e).map(([t, n]) => `;${dm(t)}=${dm(n)}`).join("")
}

function YO(e) {
    let t = Object.entries(e).map(([n, r]) => Array.isArray(r) ? r.map(o => `${nu(n)}=${nu(o)}`).join("&") : `${nu(n)}=${nu(r)}`).filter(n => n);
    return t.length ? `?${t.join("&")}` : ""
}
var JO = /^[^\/()?;#]+/;

function im(e) {
    let t = e.match(JO);
    return t ? t[0] : ""
}
var QO = /^[^\/()?;=#]+/;

function ZO(e) {
    let t = e.match(QO);
    return t ? t[0] : ""
}
var XO = /^[^=?&#]+/;

function eP(e) {
    let t = e.match(XO);
    return t ? t[0] : ""
}
var tP = /^[^&#]+/;

function nP(e) {
    let t = e.match(tP);
    return t ? t[0] : ""
}
var fm = class {
    url;
    remaining;
    constructor(t) {
        this.url = t, this.remaining = t
    }
    parseRootSegment() {
        for (; this.consumeOptional("/"););
        return this.remaining === "" || this.peekStartsWith("?") || this.peekStartsWith("#") ? new V([], {}) : new V([], this.parseChildren())
    }
    parseQueryParams() {
        let t = {};
        if (this.consumeOptional("?"))
            do this.parseQueryParam(t); while (this.consumeOptional("&"));
        return t
    }
    parseFragment() {
        return this.consumeOptional("#") ? decodeURIComponent(this.remaining) : null
    }
    parseChildren(t = 0) {
        if (t > 50) throw new g(4010, !1);
        if (this.remaining === "") return {};
        this.consumeOptional("/");
        let n = [];
        for (this.peekStartsWith("(") || n.push(this.parseSegment()); this.peekStartsWith("/") && !this.peekStartsWith("//") && !this.peekStartsWith("/(");) this.capture("/"), n.push(this.parseSegment());
        let r = {};
        this.peekStartsWith("/(") && (this.capture("/"), r = this.parseParens(!0, t));
        let o = {};
        return this.peekStartsWith("(") && (o = this.parseParens(!1, t)), (n.length > 0 || Object.keys(r).length > 0) && (o[O] = new V(n, r)), o
    }
    parseSegment() {
        let t = im(this.remaining);
        if (t === "" && this.peekStartsWith(";")) throw new g(4009, !1);
        return this.capture(t), new ar(su(t), this.parseMatrixParams())
    }
    parseMatrixParams() {
        let t = {};
        for (; this.consumeOptional(";");) this.parseParam(t);
        return t
    }
    parseParam(t) {
        let n = ZO(this.remaining);
        if (!n) return;
        this.capture(n);
        let r = "";
        if (this.consumeOptional("=")) {
            let o = im(this.remaining);
            o && (r = o, this.capture(r))
        }
        t[su(n)] = su(r)
    }
    parseQueryParam(t) {
        let n = eP(this.remaining);
        if (!n) return;
        this.capture(n);
        let r = "";
        if (this.consumeOptional("=")) {
            let s = nP(this.remaining);
            s && (r = s, this.capture(r))
        }
        let o = Z_(n),
            i = Z_(r);
        if (t.hasOwnProperty(o)) {
            let s = t[o];
            Array.isArray(s) || (s = [s], t[o] = s), s.push(i)
        } else t[o] = i
    }
    parseParens(t, n) {
        let r = {};
        for (this.capture("("); !this.consumeOptional(")") && this.remaining.length > 0;) {
            let o = im(this.remaining),
                i = this.remaining[o.length];
            if (i !== "/" && i !== ")" && i !== ";") throw new g(4010, !1);
            let s;
            o.indexOf(":") > -1 ? (s = o.slice(0, o.indexOf(":")), this.capture(s), this.capture(":")) : t && (s = O);
            let a = this.parseChildren(n + 1);
            r[s ? ? O] = Object.keys(a).length === 1 && a[O] ? a[O] : new V([], a), this.consumeOptional("//")
        }
        return r
    }
    peekStartsWith(t) {
        return this.remaining.startsWith(t)
    }
    consumeOptional(t) {
        return this.peekStartsWith(t) ? (this.remaining = this.remaining.substring(t.length), !0) : !1
    }
    capture(t) {
        if (!this.consumeOptional(t)) throw new g(4011, !1)
    }
};

function px(e) {
    return e.segments.length > 0 ? new V([], {
        [O]: e
    }) : e
}

function hx(e) {
    let t = {};
    for (let [r, o] of Object.entries(e.children)) {
        let i = hx(o);
        if (r === O && i.segments.length === 0 && i.hasChildren())
            for (let [s, a] of Object.entries(i.children)) t[s] = a;
        else(i.segments.length > 0 || i.hasChildren()) && (t[r] = i)
    }
    let n = new V(e.segments, t);
    return rP(n)
}

function rP(e) {
    if (e.numberOfChildren === 1 && e.children[O]) {
        let t = e.children[O];
        return new V(e.segments.concat(t.segments), t.children)
    }
    return e
}

function cr(e) {
    return e instanceof Ge
}

function mx(e, t, n = null, r = null, o = new Rn) {
    let i = gx(e);
    return Ex(i, t, n, r, o)
}

function gx(e) {
    let t;

    function n(i) {
        let s = {};
        for (let c of i.children) {
            let l = n(c);
            s[c.outlet] = l
        }
        let a = new V(i.url, s);
        return i === e && (t = a), a
    }
    let r = n(e.root),
        o = px(r);
    return t ? ? o
}

function Ex(e, t, n, r, o) {
    let i = e;
    for (; i.parent;) i = i.parent;
    if (t.length === 0) return sm(i, i, i, n, r, o);
    let s = oP(t);
    if (s.toRoot()) return sm(i, i, new V([], {}), n, r, o);
    let a = iP(s, i, e),
        c = a.processChildren ? js(a.segmentGroup, a.index, s.commands) : vx(a.segmentGroup, a.index, s.commands);
    return sm(i, a.segmentGroup, c, n, r, o)
}

function cu(e) {
    return typeof e == "object" && e != null && !e.outlets && !e.segmentPath
}

function $s(e) {
    return typeof e == "object" && e != null && e.outlets
}

function X_(e, t, n) {
    e || = "\u0275";
    let r = new Ge;
    return r.queryParams = {
        [e]: t
    }, n.parse(n.serialize(r)).queryParams[e]
}

function sm(e, t, n, r, o, i) {
    let s = {};
    for (let [l, u] of Object.entries(r ? ? {})) s[l] = Array.isArray(u) ? u.map(d => X_(l, d, i)) : X_(l, u, i);
    let a;
    e === t ? a = n : a = yx(e, t, n);
    let c = px(hx(a));
    return new Ge(c, s, o)
}

function yx(e, t, n) {
    let r = {};
    return Object.entries(e.children).forEach(([o, i]) => {
        i === t ? r[o] = n : r[o] = yx(i, t, n)
    }), new V(e.segments, r)
}
var lu = class {
    isAbsolute;
    numberOfDoubleDots;
    commands;
    constructor(t, n, r) {
        if (this.isAbsolute = t, this.numberOfDoubleDots = n, this.commands = r, t && r.length > 0 && cu(r[0])) throw new g(4003, !1);
        let o = r.find($s);
        if (o && o !== jO(r)) throw new g(4004, !1)
    }
    toRoot() {
        return this.isAbsolute && this.commands.length === 1 && this.commands[0] == "/"
    }
};

function oP(e) {
    if (typeof e[0] == "string" && e.length === 1 && e[0] === "/") return new lu(!0, 0, e);
    let t = 0,
        n = !1,
        r = e.reduce((o, i, s) => {
            if (typeof i == "object" && i != null) {
                if (i.outlets) {
                    let a = {};
                    return Object.entries(i.outlets).forEach(([c, l]) => {
                        a[c] = typeof l == "string" ? l.split("/") : l
                    }), [...o, {
                        outlets: a
                    }]
                }
                if (i.segmentPath) return [...o, i.segmentPath]
            }
            return typeof i != "string" ? [...o, i] : s === 0 ? (i.split("/").forEach((a, c) => {
                c == 0 && a === "." || (c == 0 && a === "" ? n = !0 : a === ".." ? t++ : a != "" && o.push(a))
            }), o) : [...o, i]
        }, []);
    return new lu(n, t, r)
}
var Jo = class {
    segmentGroup;
    processChildren;
    index;
    constructor(t, n, r) {
        this.segmentGroup = t, this.processChildren = n, this.index = r
    }
};

function iP(e, t, n) {
    if (e.isAbsolute) return new Jo(t, !0, 0);
    if (!n) return new Jo(t, !1, NaN);
    if (n.parent === null) return new Jo(n, !0, 0);
    let r = cu(e.commands[0]) ? 0 : 1,
        o = n.segments.length - 1 + r;
    return sP(n, o, e.numberOfDoubleDots)
}

function sP(e, t, n) {
    let r = e,
        o = t,
        i = n;
    for (; i > o;) {
        if (i -= o, r = r.parent, !r) throw new g(4005, !1);
        o = r.segments.length
    }
    return new Jo(r, !1, o - i)
}

function aP(e) {
    return $s(e[0]) ? e[0].outlets : {
        [O]: e
    }
}

function vx(e, t, n) {
    if (e ? ? = new V([], {}), e.segments.length === 0 && e.hasChildren()) return js(e, t, n);
    let r = cP(e, t, n),
        o = n.slice(r.commandIndex);
    if (r.match && r.pathIndex < e.segments.length) {
        let i = new V(e.segments.slice(0, r.pathIndex), {});
        return i.children[O] = new V(e.segments.slice(r.pathIndex), e.children), js(i, 0, o)
    } else return r.match && o.length === 0 ? new V(e.segments, {}) : r.match && !e.hasChildren() ? pm(e, t, n) : r.match ? js(e, 0, o) : pm(e, t, n)
}

function js(e, t, n) {
    if (n.length === 0) return new V(e.segments, {}); {
        let r = aP(n),
            o = {};
        if (Object.keys(r).some(i => i !== O) && e.children[O] && e.numberOfChildren === 1 && e.children[O].segments.length === 0) {
            let i = js(e.children[O], t, n);
            return new V(e.segments, i.children)
        }
        return Object.entries(r).forEach(([i, s]) => {
            typeof s == "string" && (s = [s]), s !== null && (o[i] = vx(e.children[i], t, s))
        }), Object.entries(e.children).forEach(([i, s]) => {
            r[i] === void 0 && (o[i] = s)
        }), new V(e.segments, o)
    }
}

function cP(e, t, n) {
    let r = 0,
        o = t,
        i = {
            match: !1,
            pathIndex: 0,
            commandIndex: 0
        };
    for (; o < e.segments.length;) {
        if (r >= n.length) return i;
        let s = e.segments[o],
            a = n[r];
        if ($s(a)) break;
        let c = `${a}`,
            l = r < n.length - 1 ? n[r + 1] : null;
        if (o > 0 && c === void 0) break;
        if (c && l && typeof l == "object" && l.outlets === void 0) {
            if (!tx(c, l, s)) return i;
            r += 2
        } else {
            if (!tx(c, {}, s)) return i;
            r++
        }
        o++
    }
    return {
        match: !0,
        pathIndex: o,
        commandIndex: r
    }
}

function pm(e, t, n) {
    let r = e.segments.slice(0, t),
        o = 0;
    for (; o < n.length;) {
        let i = n[o];
        if ($s(i)) {
            let c = lP(i.outlets);
            return new V(r, c)
        }
        if (o === 0 && cu(n[0])) {
            let c = e.segments[t];
            r.push(new ar(c.path, ex(n[0]))), o++;
            continue
        }
        let s = $s(i) ? i.outlets[O] : `${i}`,
            a = o < n.length - 1 ? n[o + 1] : null;
        s && a && cu(a) ? (r.push(new ar(s, ex(a))), o += 2) : (r.push(new ar(s, {})), o++)
    }
    return new V(r, {})
}

function lP(e) {
    let t = {};
    return Object.entries(e).forEach(([n, r]) => {
        typeof r == "string" && (r = [r]), r !== null && (t[n] = pm(new V([], {}), 0, r))
    }), t
}

function ex(e) {
    let t = {};
    return Object.entries(e).forEach(([n, r]) => t[n] = `${r}`), t
}

function tx(e, t, n) {
    return e == n.path && cn(t, n.parameters)
}
var Qo = "imperative",
    Ce = (function(e) {
        return e[e.NavigationStart = 0] = "NavigationStart", e[e.NavigationEnd = 1] = "NavigationEnd", e[e.NavigationCancel = 2] = "NavigationCancel", e[e.NavigationError = 3] = "NavigationError", e[e.RoutesRecognized = 4] = "RoutesRecognized", e[e.ResolveStart = 5] = "ResolveStart", e[e.ResolveEnd = 6] = "ResolveEnd", e[e.GuardsCheckStart = 7] = "GuardsCheckStart", e[e.GuardsCheckEnd = 8] = "GuardsCheckEnd", e[e.RouteConfigLoadStart = 9] = "RouteConfigLoadStart", e[e.RouteConfigLoadEnd = 10] = "RouteConfigLoadEnd", e[e.ChildActivationStart = 11] = "ChildActivationStart", e[e.ChildActivationEnd = 12] = "ChildActivationEnd", e[e.ActivationStart = 13] = "ActivationStart", e[e.ActivationEnd = 14] = "ActivationEnd", e[e.Scroll = 15] = "Scroll", e[e.NavigationSkipped = 16] = "NavigationSkipped", e
    })(Ce || {}),
    ct = class {
        id;
        url;
        constructor(t, n) {
            this.id = t, this.url = n
        }
    },
    lr = class extends ct {
        type = Ce.NavigationStart;
        navigationTrigger;
        restoredState;
        constructor(t, n, r = "imperative", o = null) {
            super(t, n), this.navigationTrigger = r, this.restoredState = o
        }
        toString() {
            return `NavigationStart(id: ${this.id}, url: '${this.url}')`
        }
    },
    lt = class extends ct {
        urlAfterRedirects;
        type = Ce.NavigationEnd;
        constructor(t, n, r) {
            super(t, n), this.urlAfterRedirects = r
        }
        toString() {
            return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`
        }
    },
    Fe = (function(e) {
        return e[e.Redirect = 0] = "Redirect", e[e.SupersededByNewNavigation = 1] = "SupersededByNewNavigation", e[e.NoDataFromResolver = 2] = "NoDataFromResolver", e[e.GuardRejected = 3] = "GuardRejected", e[e.Aborted = 4] = "Aborted", e
    })(Fe || {}),
    Xo = (function(e) {
        return e[e.IgnoredSameUrlNavigation = 0] = "IgnoredSameUrlNavigation", e[e.IgnoredByUrlHandlingStrategy = 1] = "IgnoredByUrlHandlingStrategy", e
    })(Xo || {}),
    xt = class extends ct {
        reason;
        code;
        type = Ce.NavigationCancel;
        constructor(t, n, r, o) {
            super(t, n), this.reason = r, this.code = o
        }
        toString() {
            return `NavigationCancel(id: ${this.id}, url: '${this.url}')`
        }
    };

function Dx(e) {
    return e instanceof xt && (e.code === Fe.Redirect || e.code === Fe.SupersededByNewNavigation)
}
var ln = class extends ct {
        reason;
        code;
        type = Ce.NavigationSkipped;
        constructor(t, n, r, o) {
            super(t, n), this.reason = r, this.code = o
        }
    },
    eo = class extends ct {
        error;
        target;
        type = Ce.NavigationError;
        constructor(t, n, r, o) {
            super(t, n), this.error = r, this.target = o
        }
        toString() {
            return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`
        }
    },
    Gs = class extends ct {
        urlAfterRedirects;
        state;
        type = Ce.RoutesRecognized;
        constructor(t, n, r, o) {
            super(t, n), this.urlAfterRedirects = r, this.state = o
        }
        toString() {
            return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
    },
    uu = class extends ct {
        urlAfterRedirects;
        state;
        type = Ce.GuardsCheckStart;
        constructor(t, n, r, o) {
            super(t, n), this.urlAfterRedirects = r, this.state = o
        }
        toString() {
            return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
    },
    du = class extends ct {
        urlAfterRedirects;
        state;
        shouldActivate;
        type = Ce.GuardsCheckEnd;
        constructor(t, n, r, o, i) {
            super(t, n), this.urlAfterRedirects = r, this.state = o, this.shouldActivate = i
        }
        toString() {
            return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`
        }
    },
    fu = class extends ct {
        urlAfterRedirects;
        state;
        type = Ce.ResolveStart;
        constructor(t, n, r, o) {
            super(t, n), this.urlAfterRedirects = r, this.state = o
        }
        toString() {
            return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
    },
    pu = class extends ct {
        urlAfterRedirects;
        state;
        type = Ce.ResolveEnd;
        constructor(t, n, r, o) {
            super(t, n), this.urlAfterRedirects = r, this.state = o
        }
        toString() {
            return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
    },
    hu = class {
        route;
        type = Ce.RouteConfigLoadStart;
        constructor(t) {
            this.route = t
        }
        toString() {
            return `RouteConfigLoadStart(path: ${this.route.path})`
        }
    },
    mu = class {
        route;
        type = Ce.RouteConfigLoadEnd;
        constructor(t) {
            this.route = t
        }
        toString() {
            return `RouteConfigLoadEnd(path: ${this.route.path})`
        }
    },
    gu = class {
        snapshot;
        type = Ce.ChildActivationStart;
        constructor(t) {
            this.snapshot = t
        }
        toString() {
            return `ChildActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
    },
    Eu = class {
        snapshot;
        type = Ce.ChildActivationEnd;
        constructor(t) {
            this.snapshot = t
        }
        toString() {
            return `ChildActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
    },
    yu = class {
        snapshot;
        type = Ce.ActivationStart;
        constructor(t) {
            this.snapshot = t
        }
        toString() {
            return `ActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
    },
    vu = class {
        snapshot;
        type = Ce.ActivationEnd;
        constructor(t) {
            this.snapshot = t
        }
        toString() {
            return `ActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
    },
    ei = class {
        routerEvent;
        position;
        anchor;
        scrollBehavior;
        type = Ce.Scroll;
        constructor(t, n, r, o) {
            this.routerEvent = t, this.position = n, this.anchor = r, this.scrollBehavior = o
        }
        toString() {
            let t = this.position ? `${this.position[0]}, ${this.position[1]}` : null;
            return `Scroll(anchor: '${this.anchor}', position: '${t}')`
        }
    },
    ti = class {},
    Ws = class {},
    ni = class {
        url;
        navigationBehaviorOptions;
        constructor(t, n) {
            this.url = t, this.navigationBehaviorOptions = n
        }
    };

function uP(e) {
    return !(e instanceof ti) && !(e instanceof ni) && !(e instanceof Ws)
}
var Du = class {
        rootInjector;
        outlet = null;
        route = null;
        children;
        attachRef = null;
        get injector() {
            return this.route ? .snapshot._environmentInjector ? ? this.rootInjector
        }
        constructor(t) {
            this.rootInjector = t, this.children = new no(this.rootInjector)
        }
    },
    no = (() => {
        class e {
            rootInjector;
            contexts = new Map;
            constructor(n) {
                this.rootInjector = n
            }
            onChildOutletCreated(n, r) {
                let o = this.getOrCreateContext(n);
                o.outlet = r, this.contexts.set(n, o)
            }
            onChildOutletDestroyed(n) {
                let r = this.getContext(n);
                r && (r.outlet = null, r.attachRef = null)
            }
            onOutletDeactivated() {
                let n = this.contexts;
                return this.contexts = new Map, n
            }
            onOutletReAttached(n) {
                this.contexts = n
            }
            getOrCreateContext(n) {
                let r = this.getContext(n);
                return r || (r = new Du(this.rootInjector), this.contexts.set(n, r)), r
            }
            getContext(n) {
                return this.contexts.get(n) || null
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(re))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    _u = class {
        _root;
        constructor(t) {
            this._root = t
        }
        get root() {
            return this._root.value
        }
        parent(t) {
            let n = this.pathFromRoot(t);
            return n.length > 1 ? n[n.length - 2] : null
        }
        children(t) {
            let n = hm(t, this._root);
            return n ? n.children.map(r => r.value) : []
        }
        firstChild(t) {
            let n = hm(t, this._root);
            return n && n.children.length > 0 ? n.children[0].value : null
        }
        siblings(t) {
            let n = mm(t, this._root);
            return n.length < 2 ? [] : n[n.length - 2].children.map(o => o.value).filter(o => o !== t)
        }
        pathFromRoot(t) {
            return mm(t, this._root).map(n => n.value)
        }
    };

function hm(e, t) {
    if (e === t.value) return t;
    for (let n of t.children) {
        let r = hm(e, n);
        if (r) return r
    }
    return null
}

function mm(e, t) {
    if (e === t.value) return [t];
    for (let n of t.children) {
        let r = mm(e, n);
        if (r.length) return r.unshift(t), r
    }
    return []
}
var at = class {
    value;
    children;
    constructor(t, n) {
        this.value = t, this.children = n
    }
    toString() {
        return `TreeNode(${this.value})`
    }
};

function Yo(e) {
    let t = {};
    return e && e.children.forEach(n => t[n.value.outlet] = n), t
}
var zs = class extends _u {
    snapshot;
    constructor(t, n) {
        super(t), this.snapshot = n, Sm(this, t)
    }
    toString() {
        return this.snapshot.toString()
    }
};

function _x(e, t) {
    let n = dP(e, t),
        r = new ye([new ar("", {})]),
        o = new ye({}),
        i = new ye({}),
        s = new ye({}),
        a = new ye(""),
        c = new On(r, o, s, a, i, O, e, n.root);
    return c.snapshot = n.root, new zs(new at(c, []), n)
}

function dP(e, t) {
    let n = {},
        r = {},
        o = {},
        s = new ri([], n, o, "", r, O, e, null, {}, t);
    return new qs("", new at(s, []))
}
var On = class {
    urlSubject;
    paramsSubject;
    queryParamsSubject;
    fragmentSubject;
    dataSubject;
    outlet;
    component;
    snapshot;
    _futureSnapshot;
    _routerState;
    _paramMap;
    _queryParamMap;
    title;
    url;
    params;
    queryParams;
    fragment;
    data;
    constructor(t, n, r, o, i, s, a, c) {
        this.urlSubject = t, this.paramsSubject = n, this.queryParamsSubject = r, this.fragmentSubject = o, this.dataSubject = i, this.outlet = s, this.component = a, this._futureSnapshot = c, this.title = this.dataSubject ? .pipe(j(l => l[Js])) ? ? R(void 0), this.url = t, this.params = n, this.queryParams = r, this.fragment = o, this.data = i
    }
    get routeConfig() {
        return this._futureSnapshot.routeConfig
    }
    get root() {
        return this._routerState.root
    }
    get parent() {
        return this._routerState.parent(this)
    }
    get firstChild() {
        return this._routerState.firstChild(this)
    }
    get children() {
        return this._routerState.children(this)
    }
    get pathFromRoot() {
        return this._routerState.pathFromRoot(this)
    }
    get paramMap() {
        return this._paramMap ? ? = this.params.pipe(j(t => Xr(t))), this._paramMap
    }
    get queryParamMap() {
        return this._queryParamMap ? ? = this.queryParams.pipe(j(t => Xr(t))), this._queryParamMap
    }
    toString() {
        return this.snapshot ? this.snapshot.toString() : `Future(${this._futureSnapshot})`
    }
};

function Tm(e, t, n = "emptyOnly") {
    let r, {
        routeConfig: o
    } = e;
    return t !== null && (n === "always" || o ? .path === "" || !t.component && !t.routeConfig ? .loadComponent) ? r = {
        params: E(E({}, t.params), e.params),
        data: E(E({}, t.data), e.data),
        resolve: E(E(E(E({}, e.data), t.data), o ? .data), e._resolvedData)
    } : r = {
        params: E({}, e.params),
        data: E({}, e.data),
        resolve: E(E({}, e.data), e._resolvedData ? ? {})
    }, o && Cx(o) && (r.resolve[Js] = o.title), r
}
var ri = class {
        url;
        params;
        queryParams;
        fragment;
        data;
        outlet;
        component;
        routeConfig;
        _resolve;
        _resolvedData;
        _routerState;
        _paramMap;
        _queryParamMap;
        _environmentInjector;
        get title() {
            return this.data ? .[Js]
        }
        constructor(t, n, r, o, i, s, a, c, l, u) {
            this.url = t, this.params = n, this.queryParams = r, this.fragment = o, this.data = i, this.outlet = s, this.component = a, this.routeConfig = c, this._resolve = l, this._environmentInjector = u
        }
        get root() {
            return this._routerState.root
        }
        get parent() {
            return this._routerState.parent(this)
        }
        get firstChild() {
            return this._routerState.firstChild(this)
        }
        get children() {
            return this._routerState.children(this)
        }
        get pathFromRoot() {
            return this._routerState.pathFromRoot(this)
        }
        get paramMap() {
            return this._paramMap ? ? = Xr(this.params), this._paramMap
        }
        get queryParamMap() {
            return this._queryParamMap ? ? = Xr(this.queryParams), this._queryParamMap
        }
        toString() {
            let t = this.url.map(r => r.toString()).join("/"),
                n = this.routeConfig ? this.routeConfig.path : "";
            return `Route(url:'${t}', path:'${n}')`
        }
    },
    qs = class extends _u {
        url;
        constructor(t, n) {
            super(n), this.url = t, Sm(this, n)
        }
        toString() {
            return xx(this._root)
        }
    };

function Sm(e, t) {
    t.value._routerState = e, t.children.forEach(n => Sm(e, n))
}

function xx(e) {
    let t = e.children.length > 0 ? ` { ${e.children.map(xx).join(", ")} } ` : "";
    return `${e.value}${t}`
}

function am(e) {
    if (e.snapshot) {
        let t = e.snapshot,
            n = e._futureSnapshot;
        e.snapshot = n, cn(t.queryParams, n.queryParams) || e.queryParamsSubject.next(n.queryParams), t.fragment !== n.fragment && e.fragmentSubject.next(n.fragment), cn(t.params, n.params) || e.paramsSubject.next(n.params), BO(t.url, n.url) || e.urlSubject.next(n.url), cn(t.data, n.data) || e.dataSubject.next(n.data)
    } else e.snapshot = e._futureSnapshot, e.dataSubject.next(e._futureSnapshot.data)
}

function gm(e, t) {
    let n = cn(e.params, t.params) && GO(e.url, t.url),
        r = !e.parent != !t.parent;
    return n && !r && (!e.parent || gm(e.parent, t.parent))
}

function Cx(e) {
    return typeof e.title == "string" || e.title === null
}
var Ix = new v(""),
    bm = (() => {
        class e {
            activated = null;
            get activatedComponentRef() {
                return this.activated
            }
            _activatedRoute = null;
            name = O;
            activateEvents = new Re;
            deactivateEvents = new Re;
            attachEvents = new Re;
            detachEvents = new Re;
            routerOutletData = zD();
            parentContexts = h(no);
            location = h(Dt);
            changeDetector = h(ir);
            inputBinder = h(Qs, {
                optional: !0
            });
            supportsBindingToComponentInputs = !0;
            ngOnChanges(n) {
                if (n.name) {
                    let {
                        firstChange: r,
                        previousValue: o
                    } = n.name;
                    if (r) return;
                    this.isTrackedInParentContexts(o) && (this.deactivate(), this.parentContexts.onChildOutletDestroyed(o)), this.initializeOutletWithName()
                }
            }
            ngOnDestroy() {
                this.isTrackedInParentContexts(this.name) && this.parentContexts.onChildOutletDestroyed(this.name), this.inputBinder ? .unsubscribeFromRouteData(this)
            }
            isTrackedInParentContexts(n) {
                return this.parentContexts.getContext(n) ? .outlet === this
            }
            ngOnInit() {
                this.initializeOutletWithName()
            }
            initializeOutletWithName() {
                if (this.parentContexts.onChildOutletCreated(this.name, this), this.activated) return;
                let n = this.parentContexts.getContext(this.name);
                n ? .route && (n.attachRef ? this.attach(n.attachRef, n.route) : this.activateWith(n.route, n.injector))
            }
            get isActivated() {
                return !!this.activated
            }
            get component() {
                if (!this.activated) throw new g(4012, !1);
                return this.activated.instance
            }
            get activatedRoute() {
                if (!this.activated) throw new g(4012, !1);
                return this._activatedRoute
            }
            get activatedRouteData() {
                return this._activatedRoute ? this._activatedRoute.snapshot.data : {}
            }
            detach() {
                if (!this.activated) throw new g(4012, !1);
                this.location.detach();
                let n = this.activated;
                return this.activated = null, this._activatedRoute = null, this.detachEvents.emit(n.instance), n
            }
            attach(n, r) {
                this.activated = n, this._activatedRoute = r, this.location.insert(n.hostView), this.inputBinder ? .bindActivatedRouteToOutletComponent(this), this.attachEvents.emit(n.instance)
            }
            deactivate() {
                if (this.activated) {
                    let n = this.component;
                    this.activated.destroy(), this.activated = null, this._activatedRoute = null, this.deactivateEvents.emit(n)
                }
            }
            activateWith(n, r) {
                if (this.isActivated) throw new g(4013, !1);
                this._activatedRoute = n;
                let o = this.location,
                    s = n.snapshot.component,
                    a = this.parentContexts.getOrCreateContext(this.name).children,
                    c = new Em(n, a, o.injector, this.routerOutletData);
                this.activated = o.createComponent(s, {
                    index: o.length,
                    injector: c,
                    environmentInjector: r
                }), this.changeDetector.markForCheck(), this.inputBinder ? .bindActivatedRouteToOutletComponent(this), this.activateEvents.emit(this.activated.instance)
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["router-outlet"]
                ],
                inputs: {
                    name: "name",
                    routerOutletData: [1, "routerOutletData"]
                },
                outputs: {
                    activateEvents: "activate",
                    deactivateEvents: "deactivate",
                    attachEvents: "attach",
                    detachEvents: "detach"
                },
                exportAs: ["outlet"],
                features: [rn]
            })
        }
        return e
    })(),
    Em = class {
        route;
        childContexts;
        parent;
        outletData;
        constructor(t, n, r, o) {
            this.route = t, this.childContexts = n, this.parent = r, this.outletData = o
        }
        get(t, n) {
            return t === On ? this.route : t === no ? this.childContexts : t === Ix ? this.outletData : this.parent.get(t, n)
        }
    },
    Qs = new v(""),
    wm = (() => {
        class e {
            outletDataSubscriptions = new Map;
            bindActivatedRouteToOutletComponent(n) {
                this.unsubscribeFromRouteData(n), this.subscribeToRouteData(n)
            }
            unsubscribeFromRouteData(n) {
                this.outletDataSubscriptions.get(n) ? .unsubscribe(), this.outletDataSubscriptions.delete(n)
            }
            subscribeToRouteData(n) {
                let {
                    activatedRoute: r
                } = n, o = ja([r.queryParams, r.params, r.data]).pipe(Ue(([i, s, a], c) => (a = E(E(E({}, i), s), a), c === 0 ? R(a) : Promise.resolve(a)))).subscribe(i => {
                    if (!n.isActivated || !n.activatedComponentRef || n.activatedRoute !== r || r.component === null) {
                        this.unsubscribeFromRouteData(n);
                        return
                    }
                    let s = XD(r.component);
                    if (!s) {
                        this.unsubscribeFromRouteData(n);
                        return
                    }
                    for (let {
                            templateName: a
                        } of s.inputs) n.activatedComponentRef.setInput(a, i[a])
                });
                this.outletDataSubscriptions.set(n, o)
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })(),
    Am = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275cmp = Qp({
                type: e,
                selectors: [
                    ["ng-component"]
                ],
                exportAs: ["emptyRouterOutlet"],
                decls: 1,
                vars: 0,
                template: function(r, o) {
                    r & 1 && _l(0, "router-outlet")
                },
                dependencies: [bm],
                encapsulation: 2
            })
        }
        return e
    })();

function Mm(e) {
    let t = e.children && e.children.map(Mm),
        n = t ? B(E({}, e), {
            children: t
        }) : E({}, e);
    return !n.component && !n.loadComponent && (t || n.loadChildren) && n.outlet && n.outlet !== O && (n.component = Am), n
}

function fP(e, t, n) {
    let r = Ks(e, t._root, n ? n._root : void 0);
    return new zs(r, t)
}

function Ks(e, t, n) {
    if (n && e.shouldReuseRoute(t.value, n.value.snapshot)) {
        let r = n.value;
        r._futureSnapshot = t.value;
        let o = pP(e, t, n);
        return new at(r, o)
    } else {
        if (e.shouldAttach(t.value)) {
            let i = e.retrieve(t.value);
            if (i !== null) {
                let s = i.route;
                return s.value._futureSnapshot = t.value, s.children = t.children.map(a => Ks(e, a)), s
            }
        }
        let r = hP(t.value),
            o = t.children.map(i => Ks(e, i));
        return new at(r, o)
    }
}

function pP(e, t, n) {
    return t.children.map(r => {
        for (let o of n.children)
            if (e.shouldReuseRoute(r.value, o.value.snapshot)) return Ks(e, r, o);
        return Ks(e, r)
    })
}

function hP(e) {
    return new On(new ye(e.url), new ye(e.params), new ye(e.queryParams), new ye(e.fragment), new ye(e.data), e.outlet, e.component, e)
}
var oi = class {
        redirectTo;
        navigationBehaviorOptions;
        constructor(t, n) {
            this.redirectTo = t, this.navigationBehaviorOptions = n
        }
    },
    Tx = "ngNavigationCancelingError";

function xu(e, t) {
    let {
        redirectTo: n,
        navigationBehaviorOptions: r
    } = cr(t) ? {
        redirectTo: t,
        navigationBehaviorOptions: void 0
    } : t, o = Sx(!1, Fe.Redirect);
    return o.url = n, o.navigationBehaviorOptions = r, o
}

function Sx(e, t) {
    let n = new Error(`NavigationCancelingError: ${e||""}`);
    return n[Tx] = !0, n.cancellationCode = t, n
}

function mP(e) {
    return bx(e) && cr(e.url)
}

function bx(e) {
    return !!e && e[Tx]
}
var ym = class {
        routeReuseStrategy;
        futureState;
        currState;
        forwardEvent;
        inputBindingEnabled;
        constructor(t, n, r, o, i) {
            this.routeReuseStrategy = t, this.futureState = n, this.currState = r, this.forwardEvent = o, this.inputBindingEnabled = i
        }
        activate(t) {
            let n = this.futureState._root,
                r = this.currState ? this.currState._root : null;
            this.deactivateChildRoutes(n, r, t), am(this.futureState.root), this.activateChildRoutes(n, r, t)
        }
        deactivateChildRoutes(t, n, r) {
            let o = Yo(n);
            t.children.forEach(i => {
                let s = i.value.outlet;
                this.deactivateRoutes(i, o[s], r), delete o[s]
            }), Object.values(o).forEach(i => {
                this.deactivateRouteAndItsChildren(i, r)
            })
        }
        deactivateRoutes(t, n, r) {
            let o = t.value,
                i = n ? n.value : null;
            if (o === i)
                if (o.component) {
                    let s = r.getContext(o.outlet);
                    s && this.deactivateChildRoutes(t, n, s.children)
                } else this.deactivateChildRoutes(t, n, r);
            else i && this.deactivateRouteAndItsChildren(n, r)
        }
        deactivateRouteAndItsChildren(t, n) {
            t.value.component && this.routeReuseStrategy.shouldDetach(t.value.snapshot) ? this.detachAndStoreRouteSubtree(t, n) : this.deactivateRouteAndOutlet(t, n)
        }
        detachAndStoreRouteSubtree(t, n) {
            let r = n.getContext(t.value.outlet),
                o = r && t.value.component ? r.children : n,
                i = Yo(t);
            for (let s of Object.values(i)) this.deactivateRouteAndItsChildren(s, o);
            if (r && r.outlet) {
                let s = r.outlet.detach(),
                    a = r.children.onOutletDeactivated();
                this.routeReuseStrategy.store(t.value.snapshot, {
                    componentRef: s,
                    route: t,
                    contexts: a
                })
            }
        }
        deactivateRouteAndOutlet(t, n) {
            let r = n.getContext(t.value.outlet),
                o = r && t.value.component ? r.children : n,
                i = Yo(t);
            for (let s of Object.values(i)) this.deactivateRouteAndItsChildren(s, o);
            r && (r.outlet && (r.outlet.deactivate(), r.children.onOutletDeactivated()), r.attachRef = null, r.route = null)
        }
        activateChildRoutes(t, n, r) {
            let o = Yo(n);
            t.children.forEach(i => {
                this.activateRoutes(i, o[i.value.outlet], r), this.forwardEvent(new vu(i.value.snapshot))
            }), t.children.length && this.forwardEvent(new Eu(t.value.snapshot))
        }
        activateRoutes(t, n, r) {
            let o = t.value,
                i = n ? n.value : null;
            if (am(o), o === i)
                if (o.component) {
                    let s = r.getOrCreateContext(o.outlet);
                    this.activateChildRoutes(t, n, s.children)
                } else this.activateChildRoutes(t, n, r);
            else if (o.component) {
                let s = r.getOrCreateContext(o.outlet);
                if (this.routeReuseStrategy.shouldAttach(o.snapshot)) {
                    let a = this.routeReuseStrategy.retrieve(o.snapshot);
                    this.routeReuseStrategy.store(o.snapshot, null), s.children.onOutletReAttached(a.contexts), s.attachRef = a.componentRef, s.route = a.route.value, s.outlet && s.outlet.attach(a.componentRef, a.route.value), am(a.route.value), this.activateChildRoutes(t, null, s.children)
                } else s.attachRef = null, s.route = o, s.outlet && s.outlet.activateWith(o, s.injector), this.activateChildRoutes(t, null, s.children)
            } else this.activateChildRoutes(t, null, r)
        }
    },
    Cu = class {
        path;
        route;
        constructor(t) {
            this.path = t, this.route = this.path[this.path.length - 1]
        }
    },
    Zo = class {
        component;
        route;
        constructor(t, n) {
            this.component = t, this.route = n
        }
    };

function gP(e, t, n) {
    let r = e._root,
        o = t ? t._root : null;
    return Bs(r, o, n, [r.value])
}

function EP(e) {
    let t = e.routeConfig ? e.routeConfig.canActivateChild : null;
    return !t || t.length === 0 ? null : {
        node: e,
        guards: t
    }
}

function si(e, t) {
    let n = Symbol(),
        r = t.get(e, n);
    return r === n ? typeof e == "function" && !Ad(e) ? e : t.get(e) : r
}

function Bs(e, t, n, r, o = {
    canDeactivateChecks: [],
    canActivateChecks: []
}) {
    let i = Yo(t);
    return e.children.forEach(s => {
        yP(s, i[s.value.outlet], n, r.concat([s.value]), o), delete i[s.value.outlet]
    }), Object.entries(i).forEach(([s, a]) => Hs(a, n.getContext(s), o)), o
}

function yP(e, t, n, r, o = {
    canDeactivateChecks: [],
    canActivateChecks: []
}) {
    let i = e.value,
        s = t ? t.value : null,
        a = n ? n.getContext(e.value.outlet) : null;
    if (s && i.routeConfig === s.routeConfig) {
        let c = vP(s, i, i.routeConfig.runGuardsAndResolvers);
        c ? o.canActivateChecks.push(new Cu(r)) : (i.data = s.data, i._resolvedData = s._resolvedData), i.component ? Bs(e, t, a ? a.children : null, r, o) : Bs(e, t, n, r, o), c && a && a.outlet && a.outlet.isActivated && o.canDeactivateChecks.push(new Zo(a.outlet.component, s))
    } else s && Hs(t, a, o), o.canActivateChecks.push(new Cu(r)), i.component ? Bs(e, null, a ? a.children : null, r, o) : Bs(e, null, n, r, o);
    return o
}

function vP(e, t, n) {
    if (typeof n == "function") return _e(t._environmentInjector, () => n(e, t));
    switch (n) {
        case "pathParamsChange":
            return !Zr(e.url, t.url);
        case "pathParamsOrQueryParamsChange":
            return !Zr(e.url, t.url) || !cn(e.queryParams, t.queryParams);
        case "always":
            return !0;
        case "paramsOrQueryParamsChange":
            return !gm(e, t) || !cn(e.queryParams, t.queryParams);
        default:
            return !gm(e, t)
    }
}

function Hs(e, t, n) {
    let r = Yo(e),
        o = e.value;
    Object.entries(r).forEach(([i, s]) => {
        o.component ? t ? Hs(s, t.children.getContext(i), n) : Hs(s, null, n) : Hs(s, t, n)
    }), o.component ? t && t.outlet && t.outlet.isActivated ? n.canDeactivateChecks.push(new Zo(t.outlet.component, o)) : n.canDeactivateChecks.push(new Zo(null, o)) : n.canDeactivateChecks.push(new Zo(null, o))
}

function Zs(e) {
    return typeof e == "function"
}

function DP(e) {
    return typeof e == "boolean"
}

function _P(e) {
    return e && Zs(e.canLoad)
}

function xP(e) {
    return e && Zs(e.canActivate)
}

function CP(e) {
    return e && Zs(e.canActivateChild)
}

function IP(e) {
    return e && Zs(e.canDeactivate)
}

function TP(e) {
    return e && Zs(e.canMatch)
}

function wx(e) {
    return e instanceof Nt || e ? .name === "EmptyError"
}
var ru = Symbol("INITIAL_VALUE");

function ii() {
    return Ue(e => ja(e.map(t => t.pipe(tt(1), pd(ru)))).pipe(j(t => {
        for (let n of t)
            if (n !== !0) {
                if (n === ru) return ru;
                if (n === !1 || SP(n)) return n
            }
        return !0
    }), Ne(t => t !== ru), tt(1)))
}

function SP(e) {
    return cr(e) || e instanceof oi
}

function Ax(e) {
    return e.aborted ? R(void 0).pipe(tt(1)) : new P(t => {
        let n = () => {
            t.next(), t.complete()
        };
        return e.addEventListener("abort", n), () => e.removeEventListener("abort", n)
    })
}

function Mx(e) {
    return _o(Ax(e))
}

function bP(e) {
    return de(t => {
        let {
            targetSnapshot: n,
            currentSnapshot: r,
            guards: {
                canActivateChecks: o,
                canDeactivateChecks: i
            }
        } = t;
        return i.length === 0 && o.length === 0 ? R(B(E({}, t), {
            guardsResult: !0
        })) : wP(i, n, r).pipe(de(s => s && DP(s) ? AP(n, o, e) : R(s)), j(s => B(E({}, t), {
            guardsResult: s
        })))
    })
}

function wP(e, t, n) {
    return J(e).pipe(de(r => PP(r.component, r.route, n, t)), mn(r => r !== !0, !0))
}

function AP(e, t, n) {
    return J(t).pipe(qn(r => zn(NP(r.route.parent, n), MP(r.route, n), OP(e, r.path), RP(e, r.route))), mn(r => r !== !0, !0))
}

function MP(e, t) {
    return e !== null && t && t(new yu(e)), R(!0)
}

function NP(e, t) {
    return e !== null && t && t(new gu(e)), R(!0)
}

function RP(e, t) {
    let n = t.routeConfig ? t.routeConfig.canActivate : null;
    if (!n || n.length === 0) return R(!0);
    let r = n.map(o => wi(() => {
        let i = t._environmentInjector,
            s = si(o, i),
            a = xP(s) ? s.canActivate(t, e) : _e(i, () => s(t, e));
        return to(a).pipe(mn())
    }));
    return R(r).pipe(ii())
}

function OP(e, t) {
    let n = t[t.length - 1],
        o = t.slice(0, t.length - 1).reverse().map(i => EP(i)).filter(i => i !== null).map(i => wi(() => {
            let s = i.guards.map(a => {
                let c = i.node._environmentInjector,
                    l = si(a, c),
                    u = CP(l) ? l.canActivateChild(n, e) : _e(c, () => l(n, e));
                return to(u).pipe(mn())
            });
            return R(s).pipe(ii())
        }));
    return R(o).pipe(ii())
}

function PP(e, t, n, r) {
    let o = t && t.routeConfig ? t.routeConfig.canDeactivate : null;
    if (!o || o.length === 0) return R(!0);
    let i = o.map(s => {
        let a = t._environmentInjector,
            c = si(s, a),
            l = IP(c) ? c.canDeactivate(e, t, n, r) : _e(a, () => c(e, t, n, r));
        return to(l).pipe(mn())
    });
    return R(i).pipe(ii())
}

function LP(e, t, n, r, o) {
    let i = t.canLoad;
    if (i === void 0 || i.length === 0) return R(!0);
    let s = i.map(a => {
        let c = si(a, e),
            l = _P(c) ? c.canLoad(t, n) : _e(e, () => c(t, n)),
            u = to(l);
        return o ? u.pipe(Mx(o)) : u
    });
    return R(s).pipe(ii(), Nx(r))
}

function Nx(e) {
    return rd(nt(t => {
        if (typeof t != "boolean") throw xu(e, t)
    }), j(t => t === !0))
}

function kP(e, t, n, r, o, i) {
    let s = t.canMatch;
    if (!s || s.length === 0) return R(!0);
    let a = s.map(c => {
        let l = si(c, e),
            u = TP(l) ? l.canMatch(t, n, o) : _e(e, () => l(t, n, o));
        return to(u).pipe(Mx(i))
    });
    return R(a).pipe(ii(), Nx(r))
}
var Nn = class e extends Error {
        segmentGroup;
        constructor(t) {
            super(), this.segmentGroup = t || null, Object.setPrototypeOf(this, e.prototype)
        }
    },
    Ys = class e extends Error {
        urlTree;
        constructor(t) {
            super(), this.urlTree = t, Object.setPrototypeOf(this, e.prototype)
        }
    };

function FP(e) {
    throw new g(4e3, !1)
}

function UP(e) {
    throw Sx(!1, Fe.GuardRejected)
}
var vm = class {
    urlSerializer;
    urlTree;
    constructor(t, n) {
        this.urlSerializer = t, this.urlTree = n
    }
    lineralizeSegments(t, n) {
        return G(this, null, function*() {
            let r = [],
                o = n.root;
            for (;;) {
                if (r = r.concat(o.segments), o.numberOfChildren === 0) return r;
                if (o.numberOfChildren > 1 || !o.children[O]) throw FP(`${t.redirectTo}`);
                o = o.children[O]
            }
        })
    }
    applyRedirectCommands(t, n, r, o, i) {
        return G(this, null, function*() {
            let s = yield BP(n, o, i);
            if (s instanceof Ge) throw new Ys(s);
            let a = this.applyRedirectCreateUrlTree(s, this.urlSerializer.parse(s), t, r);
            if (s[0] === "/") throw new Ys(a);
            return a
        })
    }
    applyRedirectCreateUrlTree(t, n, r, o) {
        let i = this.createSegmentGroup(t, n.root, r, o);
        return new Ge(i, this.createQueryParams(n.queryParams, this.urlTree.queryParams), n.fragment)
    }
    createQueryParams(t, n) {
        let r = {};
        return Object.entries(t).forEach(([o, i]) => {
            if (typeof i == "string" && i[0] === ":") {
                let a = i.substring(1);
                r[o] = n[a]
            } else r[o] = i
        }), r
    }
    createSegmentGroup(t, n, r, o) {
        let i = this.createSegments(t, n.segments, r, o),
            s = {};
        return Object.entries(n.children).forEach(([a, c]) => {
            s[a] = this.createSegmentGroup(t, c, r, o)
        }), new V(i, s)
    }
    createSegments(t, n, r, o) {
        return n.map(i => i.path[0] === ":" ? this.findPosParam(t, i, o) : this.findOrReturn(i, r))
    }
    findPosParam(t, n, r) {
        let o = r[n.path.substring(1)];
        if (!o) throw new g(4001, !1);
        return o
    }
    findOrReturn(t, n) {
        let r = 0;
        for (let o of n) {
            if (o.path === t.path) return n.splice(r), o;
            r++
        }
        return t
    }
};

function BP(e, t, n) {
    if (typeof e == "string") return Promise.resolve(e);
    let r = e;
    return au(to(_e(n, () => r(t))))
}

function jP(e, t) {
    return e.providers && !e._injector && (e._injector = Go(e.providers, t, `Route: ${e.path}`)), e._injector ? ? t
}

function Gt(e) {
    return e.outlet || O
}

function HP(e, t) {
    let n = e.filter(r => Gt(r) === t);
    return n.push(...e.filter(r => Gt(r) !== t)), n
}
var Dm = {
    matched: !1,
    consumedSegments: [],
    remainingSegments: [],
    parameters: {},
    positionalParamSegments: {}
};

function Rx(e) {
    return {
        routeConfig: e.routeConfig,
        url: e.url,
        params: e.params,
        queryParams: e.queryParams,
        fragment: e.fragment,
        data: e.data,
        outlet: e.outlet,
        title: e.title,
        paramMap: e.paramMap,
        queryParamMap: e.queryParamMap
    }
}

function VP(e, t, n, r, o, i, s) {
    let a = Ox(e, t, n);
    if (!a.matched) return R(a);
    let c = Rx(i(a));
    return r = jP(t, r), kP(r, t, n, o, c, s).pipe(j(l => l === !0 ? a : E({}, Dm)))
}

function Ox(e, t, n) {
    if (t.path === "") return t.pathMatch === "full" && (e.hasChildren() || n.length > 0) ? E({}, Dm) : {
        matched: !0,
        consumedSegments: [],
        remainingSegments: n,
        parameters: {},
        positionalParamSegments: {}
    };
    let o = (t.matcher || ox)(n, e, t);
    if (!o) return E({}, Dm);
    let i = {};
    Object.entries(o.posParams ? ? {}).forEach(([a, c]) => {
        i[a] = c.path
    });
    let s = o.consumed.length > 0 ? E(E({}, i), o.consumed[o.consumed.length - 1].parameters) : i;
    return {
        matched: !0,
        consumedSegments: o.consumed,
        remainingSegments: n.slice(o.consumed.length),
        parameters: s,
        positionalParamSegments: o.posParams ? ? {}
    }
}

function nx(e, t, n, r, o) {
    return n.length > 0 && WP(e, n, r, o) ? {
        segmentGroup: new V(t, GP(r, new V(n, e.children))),
        slicedSegments: []
    } : n.length === 0 && zP(e, n, r) ? {
        segmentGroup: new V(e.segments, $P(e, n, r, e.children)),
        slicedSegments: n
    } : {
        segmentGroup: new V(e.segments, e.children),
        slicedSegments: n
    }
}

function $P(e, t, n, r) {
    let o = {};
    for (let i of n)
        if (Tu(e, t, i) && !r[Gt(i)]) {
            let s = new V([], {});
            o[Gt(i)] = s
        }
    return E(E({}, r), o)
}

function GP(e, t) {
    let n = {};
    n[O] = t;
    for (let r of e)
        if (r.path === "" && Gt(r) !== O) {
            let o = new V([], {});
            n[Gt(r)] = o
        }
    return n
}

function WP(e, t, n, r) {
    return n.some(o => !Tu(e, t, o) || !(Gt(o) !== O) ? !1 : !(r !== void 0 && Gt(o) === r))
}

function zP(e, t, n) {
    return n.some(r => Tu(e, t, r))
}

function Tu(e, t, n) {
    return (e.hasChildren() || t.length > 0) && n.pathMatch === "full" ? !1 : n.path === ""
}

function qP(e, t, n) {
    return t.length === 0 && !e.children[n]
}
var _m = class {};

function KP(e, t, n, r, o, i, s = "emptyOnly", a) {
    return G(this, null, function*() {
        return new xm(e, t, n, r, o, s, i, a).recognize()
    })
}
var YP = 31,
    xm = class {
        injector;
        configLoader;
        rootComponentType;
        config;
        urlTree;
        paramsInheritanceStrategy;
        urlSerializer;
        abortSignal;
        applyRedirects;
        absoluteRedirectCount = 0;
        allowRedirects = !0;
        constructor(t, n, r, o, i, s, a, c) {
            this.injector = t, this.configLoader = n, this.rootComponentType = r, this.config = o, this.urlTree = i, this.paramsInheritanceStrategy = s, this.urlSerializer = a, this.abortSignal = c, this.applyRedirects = new vm(this.urlSerializer, this.urlTree)
        }
        noMatchError(t) {
            return new g(4002, `'${t.segmentGroup}'`)
        }
        recognize() {
            return G(this, null, function*() {
                let t = nx(this.urlTree.root, [], [], this.config).segmentGroup,
                    {
                        children: n,
                        rootSnapshot: r
                    } = yield this.match(t), o = new at(r, n), i = new qs("", o), s = mx(r, [], this.urlTree.queryParams, this.urlTree.fragment);
                return s.queryParams = this.urlTree.queryParams, i.url = this.urlSerializer.serialize(s), {
                    state: i,
                    tree: s
                }
            })
        }
        match(t) {
            return G(this, null, function*() {
                let n = new ri([], Object.freeze({}), Object.freeze(E({}, this.urlTree.queryParams)), this.urlTree.fragment, Object.freeze({}), O, this.rootComponentType, null, {}, this.injector);
                try {
                    return {
                        children: yield this.processSegmentGroup(this.injector, this.config, t, O, n), rootSnapshot: n
                    }
                } catch (r) {
                    if (r instanceof Ys) return this.urlTree = r.urlTree, this.match(r.urlTree.root);
                    throw r instanceof Nn ? this.noMatchError(r) : r
                }
            })
        }
        processSegmentGroup(t, n, r, o, i) {
            return G(this, null, function*() {
                if (r.segments.length === 0 && r.hasChildren()) return this.processChildren(t, n, r, i);
                let s = yield this.processSegment(t, n, r, r.segments, o, !0, i);
                return s instanceof at ? [s] : []
            })
        }
        processChildren(t, n, r, o) {
            return G(this, null, function*() {
                let i = [];
                for (let c of Object.keys(r.children)) c === "primary" ? i.unshift(c) : i.push(c);
                let s = [];
                for (let c of i) {
                    let l = r.children[c],
                        u = HP(n, c),
                        d = yield this.processSegmentGroup(t, u, l, c, o);
                    s.push(...d)
                }
                let a = Px(s);
                return JP(a), a
            })
        }
        processSegment(t, n, r, o, i, s, a) {
            return G(this, null, function*() {
                for (let c of n) try {
                    return yield this.processSegmentAgainstRoute(c._injector ? ? t, n, c, r, o, i, s, a)
                } catch (l) {
                    if (l instanceof Nn || wx(l)) continue;
                    throw l
                }
                if (qP(r, o, i)) return new _m;
                throw new Nn(r)
            })
        }
        processSegmentAgainstRoute(t, n, r, o, i, s, a, c) {
            return G(this, null, function*() {
                if (Gt(r) !== s && (s === O || !Tu(o, i, r))) throw new Nn(o);
                if (r.redirectTo === void 0) return this.matchSegmentAgainstRoute(t, o, r, i, s, c);
                if (this.allowRedirects && a) return this.expandSegmentAgainstRouteUsingRedirect(t, o, n, r, i, s, c);
                throw new Nn(o)
            })
        }
        expandSegmentAgainstRouteUsingRedirect(t, n, r, o, i, s, a) {
            return G(this, null, function*() {
                let {
                    matched: c,
                    parameters: l,
                    consumedSegments: u,
                    positionalParamSegments: d,
                    remainingSegments: f
                } = Ox(n, o, i);
                if (!c) throw new Nn(n);
                typeof o.redirectTo == "string" && o.redirectTo[0] === "/" && (this.absoluteRedirectCount++, this.absoluteRedirectCount > YP && (this.allowRedirects = !1));
                let p = this.createSnapshot(t, o, i, l, a);
                if (this.abortSignal.aborted) throw new Error(this.abortSignal.reason);
                let m = yield this.applyRedirects.applyRedirectCommands(u, o.redirectTo, d, Rx(p), t), x = yield this.applyRedirects.lineralizeSegments(o, m);
                return this.processSegment(t, r, n, x.concat(f), s, !1, a)
            })
        }
        createSnapshot(t, n, r, o, i) {
            let s = new ri(r, o, Object.freeze(E({}, this.urlTree.queryParams)), this.urlTree.fragment, ZP(n), Gt(n), n.component ? ? n._loadedComponent ? ? null, n, XP(n), t),
                a = Tm(s, i, this.paramsInheritanceStrategy);
            return s.params = Object.freeze(a.params), s.data = Object.freeze(a.data), s
        }
        matchSegmentAgainstRoute(t, n, r, o, i, s) {
            return G(this, null, function*() {
                if (this.abortSignal.aborted) throw new Error(this.abortSignal.reason);
                let a = me => this.createSnapshot(t, r, me.consumedSegments, me.parameters, s),
                    c = yield au(VP(n, r, o, t, this.urlSerializer, a, this.abortSignal));
                if (r.path === "**" && (n.children = {}), !c ? .matched) throw new Nn(n);
                t = r._injector ? ? t;
                let {
                    routes: l
                } = yield this.getChildConfig(t, r, o), u = r._loadedInjector ? ? t, {
                    parameters: d,
                    consumedSegments: f,
                    remainingSegments: p
                } = c, m = this.createSnapshot(t, r, f, d, s), {
                    segmentGroup: x,
                    slicedSegments: D
                } = nx(n, f, p, l, i);
                if (D.length === 0 && x.hasChildren()) {
                    let me = yield this.processChildren(u, l, x, m);
                    return new at(m, me)
                }
                if (l.length === 0 && D.length === 0) return new at(m, []);
                let I = Gt(r) === i,
                    F = yield this.processSegment(u, l, x, D, I ? O : i, !0, m);
                return new at(m, F instanceof at ? [F] : [])
            })
        }
        getChildConfig(t, n, r) {
            return G(this, null, function*() {
                if (n.children) return {
                    routes: n.children,
                    injector: t
                };
                if (n.loadChildren) {
                    if (n._loadedRoutes !== void 0) {
                        let i = n._loadedNgModuleFactory;
                        return i && !n._loadedInjector && (n._loadedInjector = i.create(t).injector), {
                            routes: n._loadedRoutes,
                            injector: n._loadedInjector
                        }
                    }
                    if (this.abortSignal.aborted) throw new Error(this.abortSignal.reason);
                    if (yield au(LP(t, n, r, this.urlSerializer, this.abortSignal))) {
                        let i = yield this.configLoader.loadChildren(t, n);
                        return n._loadedRoutes = i.routes, n._loadedInjector = i.injector, n._loadedNgModuleFactory = i.factory, i
                    }
                    throw UP(n)
                }
                return {
                    routes: [],
                    injector: t
                }
            })
        }
    };

function JP(e) {
    e.sort((t, n) => t.value.outlet === O ? -1 : n.value.outlet === O ? 1 : t.value.outlet.localeCompare(n.value.outlet))
}

function QP(e) {
    let t = e.value.routeConfig;
    return t && t.path === ""
}

function Px(e) {
    let t = [],
        n = new Set;
    for (let r of e) {
        if (!QP(r)) {
            t.push(r);
            continue
        }
        let o = t.find(i => r.value.routeConfig === i.value.routeConfig);
        o !== void 0 ? (o.children.push(...r.children), n.add(o)) : t.push(r)
    }
    for (let r of n) {
        let o = Px(r.children);
        t.push(new at(r.value, o))
    }
    return t.filter(r => !n.has(r))
}

function ZP(e) {
    return e.data || {}
}

function XP(e) {
    return e.resolve || {}
}

function eL(e, t, n, r, o, i, s) {
    return de(a => G(null, null, function*() {
        let {
            state: c,
            tree: l
        } = yield KP(e, t, n, r, a.extractedUrl, o, i, s);
        return B(E({}, a), {
            targetSnapshot: c,
            urlAfterRedirects: l
        })
    }))
}

function tL(e) {
    return de(t => {
        let {
            targetSnapshot: n,
            guards: {
                canActivateChecks: r
            }
        } = t;
        if (!r.length) return R(t);
        let o = new Set(r.map(a => a.route)),
            i = new Set;
        for (let a of o)
            if (!i.has(a))
                for (let c of Lx(a)) i.add(c);
        let s = 0;
        return J(i).pipe(qn(a => o.has(a) ? nL(a, n, e) : (a.data = Tm(a, a.parent, e).resolve, R(void 0))), nt(() => s++), Ha(1), de(a => s === i.size ? R(t) : ve))
    })
}

function Lx(e) {
    let t = e.children.map(n => Lx(n)).flat();
    return [e, ...t]
}

function nL(e, t, n) {
    let r = e.routeConfig,
        o = e._resolve;
    return r ? .title !== void 0 && !Cx(r) && (o[Js] = r.title), wi(() => (e.data = Tm(e, e.parent, n).resolve, rL(o, e, t).pipe(j(i => (e._resolvedData = i, e.data = E(E({}, e.data), i), null)))))
}

function rL(e, t, n) {
    let r = lm(e);
    if (r.length === 0) return R({});
    let o = {};
    return J(r).pipe(de(i => oL(e[i], t, n).pipe(mn(), nt(s => {
        if (s instanceof oi) throw xu(new Rn, s);
        o[i] = s
    }))), Ha(1), j(() => o), hn(i => wx(i) ? ve : bi(i)))
}

function oL(e, t, n) {
    let r = t._environmentInjector,
        o = si(e, r),
        i = o.resolve ? o.resolve(t, n) : _e(r, () => o(t, n));
    return to(i)
}

function rx(e) {
    return Ue(t => {
        let n = e(t);
        return n ? J(n).pipe(j(() => t)) : R(t)
    })
}
var Nm = (() => {
        class e {
            buildTitle(n) {
                let r, o = n.root;
                for (; o !== void 0;) r = this.getResolvedTitleForRoute(o) ? ? r, o = o.children.find(i => i.outlet === O);
                return r
            }
            getResolvedTitleForRoute(n) {
                return n.data[Js]
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => h(kx),
                providedIn: "root"
            })
        }
        return e
    })(),
    kx = (() => {
        class e extends Nm {
            title;
            constructor(n) {
                super(), this.title = n
            }
            updateTitle(n) {
                let r = this.buildTitle(n);
                r !== void 0 && this.title.setTitle(r)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Q_))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    dr = new v("", {
        factory: () => ({})
    }),
    ai = new v(""),
    Su = (() => {
        class e {
            componentLoaders = new WeakMap;
            childrenLoaders = new WeakMap;
            onLoadStartListener;
            onLoadEndListener;
            compiler = h(ph);
            loadComponent(n, r) {
                return G(this, null, function*() {
                    if (this.componentLoaders.get(r)) return this.componentLoaders.get(r);
                    if (r._loadedComponent) return Promise.resolve(r._loadedComponent);
                    this.onLoadStartListener && this.onLoadStartListener(r);
                    let o = G(this, null, function*() {
                        try {
                            let i = yield sx(_e(n, () => r.loadComponent())), s = yield Bx(Ux(i));
                            return this.onLoadEndListener && this.onLoadEndListener(r), r._loadedComponent = s, s
                        } finally {
                            this.componentLoaders.delete(r)
                        }
                    });
                    return this.componentLoaders.set(r, o), o
                })
            }
            loadChildren(n, r) {
                if (this.childrenLoaders.get(r)) return this.childrenLoaders.get(r);
                if (r._loadedRoutes) return Promise.resolve({
                    routes: r._loadedRoutes,
                    injector: r._loadedInjector
                });
                this.onLoadStartListener && this.onLoadStartListener(r);
                let o = G(this, null, function*() {
                    try {
                        let i = yield Fx(r, this.compiler, n, this.onLoadEndListener);
                        return r._loadedRoutes = i.routes, r._loadedInjector = i.injector, r._loadedNgModuleFactory = i.factory, i
                    } finally {
                        this.childrenLoaders.delete(r)
                    }
                });
                return this.childrenLoaders.set(r, o), o
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })();

function Fx(e, t, n, r) {
    return G(this, null, function*() {
        let o = yield sx(_e(n, () => e.loadChildren())), i = yield Bx(Ux(o)), s;
        i instanceof pl || Array.isArray(i) ? s = i : s = yield t.compileModuleAsync(i), r && r(e);
        let a, c, l = !1,
            u;
        return Array.isArray(s) ? (c = s, l = !0) : (a = s.create(n).injector, u = s, c = a.get(ai, [], {
            optional: !0,
            self: !0
        }).flat()), {
            routes: c.map(Mm),
            injector: a,
            factory: u
        }
    })
}

function iL(e) {
    return e && typeof e == "object" && "default" in e
}

function Ux(e) {
    return iL(e) ? e.default : e
}

function Bx(e) {
    return G(this, null, function*() {
        return e
    })
}
var bu = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => h(sL),
                providedIn: "root"
            })
        }
        return e
    })(),
    sL = (() => {
        class e {
            shouldProcessUrl(n) {
                return !0
            }
            extract(n) {
                return n
            }
            merge(n, r) {
                return n
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    Rm = new v(""),
    Om = new v("");

function jx(e, t, n) {
    let r = e.get(Om),
        o = e.get(Z);
    if (!o.startViewTransition || r.skipNextTransition) return r.skipNextTransition = !1, new Promise(l => setTimeout(l));
    let i, s = new Promise(l => {
            i = l
        }),
        a = o.startViewTransition(() => (i(), aL(e)));
    a.updateCallbackDone.catch(l => {}), a.ready.catch(l => {}), a.finished.catch(l => {});
    let {
        onViewTransitionCreated: c
    } = r;
    return c && _e(e, () => c({
        transition: a,
        from: t,
        to: n
    })), s
}

function aL(e) {
    return new Promise(t => {
        hs({
            read: () => setTimeout(t)
        }, {
            injector: e
        })
    })
}
var cL = () => {},
    Pm = new v(""),
    wu = (() => {
        class e {
            currentNavigation = ae(null, {
                equal: () => !1
            });
            currentTransition = null;
            lastSuccessfulNavigation = ae(null);
            events = new ne;
            transitionAbortWithErrorSubject = new ne;
            configLoader = h(Su);
            environmentInjector = h(re);
            destroyRef = h(He);
            urlSerializer = h(ur);
            rootContexts = h(no);
            location = h(sr);
            inputBindingEnabled = h(Qs, {
                optional: !0
            }) !== null;
            titleStrategy = h(Nm);
            options = h(dr, {
                optional: !0
            }) || {};
            paramsInheritanceStrategy = this.options.paramsInheritanceStrategy || "emptyOnly";
            urlHandlingStrategy = h(bu);
            createViewTransition = h(Rm, {
                optional: !0
            });
            navigationErrorHandler = h(Pm, {
                optional: !0
            });
            navigationId = 0;
            get hasRequestedNavigation() {
                return this.navigationId !== 0
            }
            transitions;
            afterPreactivation = () => R(void 0);
            rootComponentType = null;
            destroyed = !1;
            constructor() {
                let n = o => this.events.next(new hu(o)),
                    r = o => this.events.next(new mu(o));
                this.configLoader.onLoadEndListener = r, this.configLoader.onLoadStartListener = n, this.destroyRef.onDestroy(() => {
                    this.destroyed = !0
                })
            }
            complete() {
                this.transitions ? .complete()
            }
            handleNavigationRequest(n) {
                let r = ++this.navigationId;
                te(() => {
                    this.transitions ? .next(B(E({}, n), {
                        extractedUrl: this.urlHandlingStrategy.extract(n.rawUrl),
                        targetSnapshot: null,
                        targetRouterState: null,
                        guards: {
                            canActivateChecks: [],
                            canDeactivateChecks: []
                        },
                        guardsResult: null,
                        id: r,
                        routesRecognizeHandler: {},
                        beforeActivateHandler: {}
                    }))
                })
            }
            setupNavigations(n) {
                return this.transitions = new ye(null), this.transitions.pipe(Ne(r => r !== null), Ue(r => {
                    let o = !1,
                        i = new AbortController,
                        s = () => !o && this.currentTransition ? .id === r.id;
                    return R(r).pipe(Ue(a => {
                        if (this.navigationId > r.id) return this.cancelNavigationTransition(r, "", Fe.SupersededByNewNavigation), ve;
                        this.currentTransition = r;
                        let c = this.lastSuccessfulNavigation();
                        this.currentNavigation.set({
                            id: a.id,
                            initialUrl: a.rawUrl,
                            extractedUrl: a.extractedUrl,
                            targetBrowserUrl: typeof a.extras.browserUrl == "string" ? this.urlSerializer.parse(a.extras.browserUrl) : a.extras.browserUrl,
                            trigger: a.source,
                            extras: a.extras,
                            previousNavigation: c ? B(E({}, c), {
                                previousNavigation: null
                            }) : null,
                            abort: () => i.abort(),
                            routesRecognizeHandler: a.routesRecognizeHandler,
                            beforeActivateHandler: a.beforeActivateHandler
                        });
                        let l = !n.navigated || this.isUpdatingInternalState() || this.isUpdatedBrowserUrl(),
                            u = a.extras.onSameUrlNavigation ? ? n.onSameUrlNavigation;
                        if (!l && u !== "reload") return this.events.next(new ln(a.id, this.urlSerializer.serialize(a.rawUrl), "", Xo.IgnoredSameUrlNavigation)), a.resolve(!1), ve;
                        if (this.urlHandlingStrategy.shouldProcessUrl(a.rawUrl)) return R(a).pipe(Ue(d => (this.events.next(new lr(d.id, this.urlSerializer.serialize(d.extractedUrl), d.source, d.restoredState)), d.id !== this.navigationId ? ve : Promise.resolve(d))), eL(this.environmentInjector, this.configLoader, this.rootComponentType, n.config, this.urlSerializer, this.paramsInheritanceStrategy, i.signal), nt(d => {
                            r.targetSnapshot = d.targetSnapshot, r.urlAfterRedirects = d.urlAfterRedirects, this.currentNavigation.update(f => (f.finalUrl = d.urlAfterRedirects, f)), this.events.next(new Ws)
                        }), Ue(d => J(r.routesRecognizeHandler.deferredHandle ? ? R(void 0)).pipe(j(() => d))), nt(() => {
                            let d = new Gs(a.id, this.urlSerializer.serialize(a.extractedUrl), this.urlSerializer.serialize(a.urlAfterRedirects), a.targetSnapshot);
                            this.events.next(d)
                        }));
                        if (l && this.urlHandlingStrategy.shouldProcessUrl(a.currentRawUrl)) {
                            let {
                                id: d,
                                extractedUrl: f,
                                source: p,
                                restoredState: m,
                                extras: x
                            } = a, D = new lr(d, this.urlSerializer.serialize(f), p, m);
                            this.events.next(D);
                            let I = _x(this.rootComponentType, this.environmentInjector).snapshot;
                            return this.currentTransition = r = B(E({}, a), {
                                targetSnapshot: I,
                                urlAfterRedirects: f,
                                extras: B(E({}, x), {
                                    skipLocationChange: !1,
                                    replaceUrl: !1
                                })
                            }), this.currentNavigation.update(F => (F.finalUrl = f, F)), R(r)
                        } else return this.events.next(new ln(a.id, this.urlSerializer.serialize(a.extractedUrl), "", Xo.IgnoredByUrlHandlingStrategy)), a.resolve(!1), ve
                    }), j(a => {
                        let c = new uu(a.id, this.urlSerializer.serialize(a.extractedUrl), this.urlSerializer.serialize(a.urlAfterRedirects), a.targetSnapshot);
                        return this.events.next(c), this.currentTransition = r = B(E({}, a), {
                            guards: gP(a.targetSnapshot, a.currentSnapshot, this.rootContexts)
                        }), r
                    }), bP(a => this.events.next(a)), Ue(a => {
                        if (r.guardsResult = a.guardsResult, a.guardsResult && typeof a.guardsResult != "boolean") throw xu(this.urlSerializer, a.guardsResult);
                        let c = new du(a.id, this.urlSerializer.serialize(a.extractedUrl), this.urlSerializer.serialize(a.urlAfterRedirects), a.targetSnapshot, !!a.guardsResult);
                        if (this.events.next(c), !s()) return ve;
                        if (!a.guardsResult) return this.cancelNavigationTransition(a, "", Fe.GuardRejected), ve;
                        if (a.guards.canActivateChecks.length === 0) return R(a);
                        let l = new fu(a.id, this.urlSerializer.serialize(a.extractedUrl), this.urlSerializer.serialize(a.urlAfterRedirects), a.targetSnapshot);
                        if (this.events.next(l), !s()) return ve;
                        let u = !1;
                        return R(a).pipe(tL(this.paramsInheritanceStrategy), nt({
                            next: () => {
                                u = !0;
                                let d = new pu(a.id, this.urlSerializer.serialize(a.extractedUrl), this.urlSerializer.serialize(a.urlAfterRedirects), a.targetSnapshot);
                                this.events.next(d)
                            },
                            complete: () => {
                                u || this.cancelNavigationTransition(a, "", Fe.NoDataFromResolver)
                            }
                        }))
                    }), rx(a => {
                        let c = u => {
                                let d = [];
                                if (u.routeConfig ? ._loadedComponent) u.component = u.routeConfig ? ._loadedComponent;
                                else if (u.routeConfig ? .loadComponent) {
                                    let f = u._environmentInjector;
                                    d.push(this.configLoader.loadComponent(f, u.routeConfig).then(p => {
                                        u.component = p
                                    }))
                                }
                                for (let f of u.children) d.push(...c(f));
                                return d
                            },
                            l = c(a.targetSnapshot.root);
                        return l.length === 0 ? R(a) : J(Promise.all(l).then(() => a))
                    }), rx(() => this.afterPreactivation()), Ue(() => {
                        let {
                            currentSnapshot: a,
                            targetSnapshot: c
                        } = r, l = this.createViewTransition ? .(this.environmentInjector, a.root, c.root);
                        return l ? J(l).pipe(j(() => r)) : R(r)
                    }), tt(1), Ue(a => {
                        let c = fP(n.routeReuseStrategy, a.targetSnapshot, a.currentRouterState);
                        this.currentTransition = r = a = B(E({}, a), {
                            targetRouterState: c
                        }), this.currentNavigation.update(u => (u.targetRouterState = c, u)), this.events.next(new ti);
                        let l = r.beforeActivateHandler.deferredHandle;
                        return l ? J(l.then(() => a)) : R(a)
                    }), nt(a => {
                        new ym(n.routeReuseStrategy, r.targetRouterState, r.currentRouterState, c => this.events.next(c), this.inputBindingEnabled).activate(this.rootContexts), s() && (o = !0, this.currentNavigation.update(c => (c.abort = cL, c)), this.lastSuccessfulNavigation.set(te(this.currentNavigation)), this.events.next(new lt(a.id, this.urlSerializer.serialize(a.extractedUrl), this.urlSerializer.serialize(a.urlAfterRedirects))), this.titleStrategy ? .updateTitle(a.targetRouterState.snapshot), a.resolve(!0))
                    }), _o(Ax(i.signal).pipe(Ne(() => !o && !r.targetRouterState), nt(() => {
                        this.cancelNavigationTransition(r, i.signal.reason + "", Fe.Aborted)
                    }))), nt({
                        complete: () => {
                            o = !0
                        }
                    }), _o(this.transitionAbortWithErrorSubject.pipe(nt(a => {
                        throw a
                    }))), Do(() => {
                        i.abort(), o || this.cancelNavigationTransition(r, "", Fe.SupersededByNewNavigation), this.currentTransition ? .id === r.id && (this.currentNavigation.set(null), this.currentTransition = null)
                    }), hn(a => {
                        if (o = !0, this.destroyed) return r.resolve(!1), ve;
                        if (bx(a)) this.events.next(new xt(r.id, this.urlSerializer.serialize(r.extractedUrl), a.message, a.cancellationCode)), mP(a) ? this.events.next(new ni(a.url, a.navigationBehaviorOptions)) : r.resolve(!1);
                        else {
                            let c = new eo(r.id, this.urlSerializer.serialize(r.extractedUrl), a, r.targetSnapshot ? ? void 0);
                            try {
                                let l = _e(this.environmentInjector, () => this.navigationErrorHandler ? .(c));
                                if (l instanceof oi) {
                                    let {
                                        message: u,
                                        cancellationCode: d
                                    } = xu(this.urlSerializer, l);
                                    this.events.next(new xt(r.id, this.urlSerializer.serialize(r.extractedUrl), u, d)), this.events.next(new ni(l.redirectTo, l.navigationBehaviorOptions))
                                } else throw this.events.next(c), a
                            } catch (l) {
                                this.options.resolveNavigationPromiseOnError ? r.resolve(!1) : r.reject(l)
                            }
                        }
                        return ve
                    }))
                }))
            }
            cancelNavigationTransition(n, r, o) {
                let i = new xt(n.id, this.urlSerializer.serialize(n.extractedUrl), r, o);
                this.events.next(i), n.resolve(!1)
            }
            isUpdatingInternalState() {
                return this.currentTransition ? .extractedUrl.toString() !== this.currentTransition ? .currentUrlTree.toString()
            }
            isUpdatedBrowserUrl() {
                let n = this.urlHandlingStrategy.extract(this.urlSerializer.parse(this.location.path(!0))),
                    r = te(this.currentNavigation),
                    o = r ? .targetBrowserUrl ? ? r ? .extractedUrl;
                return n.toString() !== o ? .toString() && !r ? .extras.skipLocationChange
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })();

function lL(e) {
    return e !== Qo
}
var Hx = new v("");
var Vx = (() => {
        class e {
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => h(uL),
                providedIn: "root"
            })
        }
        return e
    })(),
    Iu = class {
        shouldDetach(t) {
            return !1
        }
        store(t, n) {}
        shouldAttach(t) {
            return !1
        }
        retrieve(t) {
            return null
        }
        shouldReuseRoute(t, n) {
            return t.routeConfig === n.routeConfig
        }
        shouldDestroyInjector(t) {
            return !0
        }
    },
    uL = (() => {
        class e extends Iu {
            static\ u0275fac = (() => {
                let n;
                return function(o) {
                    return (n || (n = as(e)))(o || e)
                }
            })();
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    Au = (() => {
        class e {
            urlSerializer = h(ur);
            options = h(dr, {
                optional: !0
            }) || {};
            canceledNavigationResolution = this.options.canceledNavigationResolution || "replace";
            location = h(sr);
            urlHandlingStrategy = h(bu);
            urlUpdateStrategy = this.options.urlUpdateStrategy || "deferred";
            currentUrlTree = new Ge;
            getCurrentUrlTree() {
                return this.currentUrlTree
            }
            rawUrlTree = this.currentUrlTree;
            getRawUrlTree() {
                return this.rawUrlTree
            }
            createBrowserPath({
                finalUrl: n,
                initialUrl: r,
                targetBrowserUrl: o
            }) {
                let i = n !== void 0 ? this.urlHandlingStrategy.merge(n, r) : r,
                    s = o ? ? i;
                return s instanceof Ge ? this.urlSerializer.serialize(s) : s
            }
            routerUrlState(n) {
                return n ? .targetBrowserUrl === void 0 || n ? .finalUrl === void 0 ? {} : {\
                    u0275routerUrl: this.urlSerializer.serialize(n.finalUrl)
                }
            }
            commitTransition({
                targetRouterState: n,
                finalUrl: r,
                initialUrl: o
            }) {
                r && n ? (this.currentUrlTree = r, this.rawUrlTree = this.urlHandlingStrategy.merge(r, o), this.routerState = n) : this.rawUrlTree = o
            }
            routerState = _x(null, h(re));
            getRouterState() {
                return this.routerState
            }
            _stateMemento = this.createStateMemento();
            get stateMemento() {
                return this._stateMemento
            }
            updateStateMemento() {
                this._stateMemento = this.createStateMemento()
            }
            createStateMemento() {
                return {
                    rawUrlTree: this.rawUrlTree,
                    currentUrlTree: this.currentUrlTree,
                    routerState: this.routerState
                }
            }
            restoredState() {
                return this.location.getState()
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: () => h(dL),
                providedIn: "root"
            })
        }
        return e
    })(),
    dL = (() => {
        class e extends Au {
            currentPageId = 0;
            lastSuccessfulId = -1;
            get browserPageId() {
                return this.canceledNavigationResolution !== "computed" ? this.currentPageId : this.restoredState() ? .\u0275routerPageId ? ? this.currentPageId
            }
            registerNonRouterCurrentEntryChangeListener(n) {
                return this.location.subscribe(r => {
                    r.type === "popstate" && setTimeout(() => {
                        n(r.url, r.state, "popstate", {
                            replaceUrl: !0
                        })
                    })
                })
            }
            handleRouterEvent(n, r) {
                n instanceof lr ? this.updateStateMemento() : n instanceof ln ? this.commitTransition(r) : n instanceof Gs ? this.urlUpdateStrategy === "eager" && (r.extras.skipLocationChange || this.setBrowserUrl(this.createBrowserPath(r), r)) : n instanceof ti ? (this.commitTransition(r), this.urlUpdateStrategy === "deferred" && !r.extras.skipLocationChange && this.setBrowserUrl(this.createBrowserPath(r), r)) : n instanceof xt && !Dx(n) ? this.restoreHistory(r) : n instanceof eo ? this.restoreHistory(r, !0) : n instanceof lt && (this.lastSuccessfulId = n.id, this.currentPageId = this.browserPageId)
            }
            setBrowserUrl(n, r) {
                let {
                    extras: o,
                    id: i
                } = r, {
                    replaceUrl: s,
                    state: a
                } = o;
                if (this.location.isCurrentPathEqualTo(n) || s) {
                    let c = this.browserPageId,
                        l = E(E({}, a), this.generateNgRouterState(i, c, r));
                    this.location.replaceState(n, "", l)
                } else {
                    let c = E(E({}, a), this.generateNgRouterState(i, this.browserPageId + 1, r));
                    this.location.go(n, "", c)
                }
            }
            restoreHistory(n, r = !1) {
                if (this.canceledNavigationResolution === "computed") {
                    let o = this.browserPageId,
                        i = this.currentPageId - o;
                    i !== 0 ? this.location.historyGo(i) : this.getCurrentUrlTree() === n.finalUrl && i === 0 && (this.resetInternalState(n), this.resetUrlToCurrentUrlTree())
                } else this.canceledNavigationResolution === "replace" && (r && this.resetInternalState(n), this.resetUrlToCurrentUrlTree())
            }
            resetInternalState({
                finalUrl: n
            }) {
                this.routerState = this.stateMemento.routerState, this.currentUrlTree = this.stateMemento.currentUrlTree, this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, n ? ? this.rawUrlTree)
            }
            resetUrlToCurrentUrlTree() {
                this.location.replaceState(this.urlSerializer.serialize(this.getRawUrlTree()), "", this.generateNgRouterState(this.lastSuccessfulId, this.currentPageId))
            }
            generateNgRouterState(n, r, o) {
                return this.canceledNavigationResolution === "computed" ? E({
                    navigationId: n,
                    \u0275routerPageId: r
                }, this.routerUrlState(o)) : E({
                    navigationId: n
                }, this.routerUrlState(o))
            }
            static\ u0275fac = (() => {
                let n;
                return function(o) {
                    return (n || (n = as(e)))(o || e)
                }
            })();
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })();

function Mu(e, t) {
    e.events.pipe(Ne(n => n instanceof lt || n instanceof xt || n instanceof eo || n instanceof ln), j(n => n instanceof lt || n instanceof ln ? 0 : (n instanceof xt ? n.code === Fe.Redirect || n.code === Fe.SupersededByNewNavigation : !1) ? 2 : 1), Ne(n => n !== 2), tt(1)).subscribe(() => {
        t()
    })
}
var Wt = (() => {
    class e {
        get currentUrlTree() {
            return this.stateManager.getCurrentUrlTree()
        }
        get rawUrlTree() {
            return this.stateManager.getRawUrlTree()
        }
        disposed = !1;
        nonRouterCurrentEntryChangeSubscription;
        console = h(hl);
        stateManager = h(Au);
        options = h(dr, {
            optional: !0
        }) || {};
        pendingTasks = h(en);
        urlUpdateStrategy = this.options.urlUpdateStrategy || "deferred";
        navigationTransitions = h(wu);
        urlSerializer = h(ur);
        location = h(sr);
        urlHandlingStrategy = h(bu);
        injector = h(re);
        _events = new ne;
        get events() {
            return this._events
        }
        get routerState() {
            return this.stateManager.getRouterState()
        }
        navigated = !1;
        routeReuseStrategy = h(Vx);
        injectorCleanup = h(Hx, {
            optional: !0
        });
        onSameUrlNavigation = this.options.onSameUrlNavigation || "ignore";
        config = h(ai, {
            optional: !0
        }) ? .flat() ? ? [];
        componentInputBindingEnabled = !!h(Qs, {
            optional: !0
        });
        currentNavigation = this.navigationTransitions.currentNavigation.asReadonly();
        constructor() {
            this.resetConfig(this.config), this.navigationTransitions.setupNavigations(this).subscribe({
                error: n => {}
            }), this.subscribeToNavigationEvents()
        }
        eventsSubscription = new oe;
        subscribeToNavigationEvents() {
            let n = this.navigationTransitions.events.subscribe(r => {
                try {
                    let o = this.navigationTransitions.currentTransition,
                        i = te(this.navigationTransitions.currentNavigation);
                    if (o !== null && i !== null) {
                        if (this.stateManager.handleRouterEvent(r, i), r instanceof xt && r.code !== Fe.Redirect && r.code !== Fe.SupersededByNewNavigation) this.navigated = !0;
                        else if (r instanceof lt) this.navigated = !0, this.injectorCleanup ? .(this.routeReuseStrategy, this.routerState, this.config);
                        else if (r instanceof ni) {
                            let s = r.navigationBehaviorOptions,
                                a = this.urlHandlingStrategy.merge(r.url, o.currentRawUrl),
                                c = E({
                                    scroll: o.extras.scroll,
                                    browserUrl: o.extras.browserUrl,
                                    info: o.extras.info,
                                    skipLocationChange: o.extras.skipLocationChange,
                                    replaceUrl: o.extras.replaceUrl || this.urlUpdateStrategy === "eager" || lL(o.source)
                                }, s);
                            this.scheduleNavigation(a, Qo, null, c, {
                                resolve: o.resolve,
                                reject: o.reject,
                                promise: o.promise
                            })
                        }
                    }
                    uP(r) && this._events.next(r)
                } catch (o) {
                    this.navigationTransitions.transitionAbortWithErrorSubject.next(o)
                }
            });
            this.eventsSubscription.add(n)
        }
        resetRootComponentType(n) {
            this.routerState.root.component = n, this.navigationTransitions.rootComponentType = n
        }
        initialNavigation() {
            this.setUpLocationChangeListener(), this.navigationTransitions.hasRequestedNavigation || this.navigateToSyncWithBrowser(this.location.path(!0), Qo, this.stateManager.restoredState(), {
                replaceUrl: !0
            })
        }
        setUpLocationChangeListener() {
            this.nonRouterCurrentEntryChangeSubscription ? ? = this.stateManager.registerNonRouterCurrentEntryChangeListener((n, r, o, i) => {
                this.navigateToSyncWithBrowser(n, o, r, i)
            })
        }
        navigateToSyncWithBrowser(n, r, o, i) {
            let s = o ? .navigationId ? o : null,
                a = o ? .\u0275routerUrl ? ? n;
            if (o ? .\u0275routerUrl && (i = B(E({}, i), {
                    browserUrl: n
                })), o) {
                let l = E({}, o);
                delete l.navigationId, delete l.\u0275routerPageId, delete l.\u0275routerUrl, Object.keys(l).length !== 0 && (i.state = l)
            }
            let c = this.parseUrl(a);
            this.scheduleNavigation(c, r, s, i).catch(l => {
                this.disposed || this.injector.get(Ke)(l)
            })
        }
        get url() {
            return this.serializeUrl(this.currentUrlTree)
        }
        getCurrentNavigation() {
            return te(this.navigationTransitions.currentNavigation)
        }
        get lastSuccessfulNavigation() {
            return this.navigationTransitions.lastSuccessfulNavigation
        }
        resetConfig(n) {
            this.config = n.map(Mm), this.navigated = !1
        }
        ngOnDestroy() {
            this.dispose()
        }
        dispose() {
            this._events.unsubscribe(), this.navigationTransitions.complete(), this.nonRouterCurrentEntryChangeSubscription ? .unsubscribe(), this.nonRouterCurrentEntryChangeSubscription = void 0, this.disposed = !0, this.eventsSubscription.unsubscribe()
        }
        createUrlTree(n, r = {}) {
            let {
                relativeTo: o,
                queryParams: i,
                fragment: s,
                queryParamsHandling: a,
                preserveFragment: c
            } = r, l = c ? this.currentUrlTree.fragment : s, u = null;
            switch (a ? ? this.options.defaultQueryParamsHandling) {
                case "merge":
                    u = E(E({}, this.currentUrlTree.queryParams), i);
                    break;
                case "preserve":
                    u = this.currentUrlTree.queryParams;
                    break;
                default:
                    u = i || null
            }
            u !== null && (u = this.removeEmptyProps(u));
            let d;
            try {
                let f = o ? o.snapshot : this.routerState.snapshot.root;
                d = gx(f)
            } catch (f) {
                (typeof n[0] != "string" || n[0][0] !== "/") && (n = []), d = this.currentUrlTree.root
            }
            return Ex(d, n, u, l ? ? null, this.urlSerializer)
        }
        navigateByUrl(n, r = {
            skipLocationChange: !1
        }) {
            let o = cr(n) ? n : this.parseUrl(n),
                i = this.urlHandlingStrategy.merge(o, this.rawUrlTree);
            return this.scheduleNavigation(i, Qo, null, r)
        }
        navigate(n, r = {
            skipLocationChange: !1
        }) {
            return fL(n), this.navigateByUrl(this.createUrlTree(n, r), r)
        }
        serializeUrl(n) {
            return this.urlSerializer.serialize(n)
        }
        parseUrl(n) {
            try {
                return this.urlSerializer.parse(n)
            } catch (r) {
                return this.console.warn(dt(4018, !1)), this.urlSerializer.parse("/")
            }
        }
        isActive(n, r) {
            let o;
            if (r === !0 ? o = E({}, Cm) : r === !1 ? o = E({}, Vs) : o = E(E({}, Vs), r), cr(n)) return um(this.currentUrlTree, n, o);
            let i = this.parseUrl(n);
            return um(this.currentUrlTree, i, o)
        }
        removeEmptyProps(n) {
            return Object.entries(n).reduce((r, [o, i]) => (i != null && (r[o] = i), r), {})
        }
        scheduleNavigation(n, r, o, i, s) {
            if (this.disposed) return Promise.resolve(!1);
            let a, c, l;
            s ? (a = s.resolve, c = s.reject, l = s.promise) : l = new Promise((d, f) => {
                a = d, c = f
            });
            let u = this.pendingTasks.add();
            return Mu(this, () => {
                queueMicrotask(() => this.pendingTasks.remove(u))
            }), this.navigationTransitions.handleNavigationRequest({
                source: r,
                restoredState: o,
                currentUrlTree: this.currentUrlTree,
                currentRawUrl: this.currentUrlTree,
                rawUrl: n,
                extras: i,
                resolve: a,
                reject: c,
                promise: l,
                currentSnapshot: this.routerState.snapshot,
                currentRouterState: this.routerState
            }), l.catch(Promise.reject.bind(Promise))
        }
        static\ u0275fac = function(r) {
            return new(r || e)
        };
        static\ u0275prov = y({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
        })
    }
    return e
})();

function fL(e) {
    for (let t = 0; t < e.length; t++)
        if (e[t] == null) throw new g(4008, !1)
}
var pL = (() => {
        class e {
            router = h(Wt);
            stateManager = h(Au);
            fragment = ae("");
            queryParams = ae({});
            path = ae("");
            serializer = h(ur);
            constructor() {
                this.updateState(), this.router.events ? .subscribe(n => {
                    n instanceof lt && this.updateState()
                })
            }
            updateState() {
                let {
                    fragment: n,
                    root: r,
                    queryParams: o
                } = this.stateManager.getCurrentUrlTree();
                this.fragment.set(n), this.queryParams.set(o), this.path.set(this.serializer.serialize(new Ge(r)))
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    Nu = (() => {
        class e {
            router;
            route;
            tabIndexAttribute;
            renderer;
            el;
            locationStrategy;
            hrefAttributeValue = h(new Sl("href"), {
                optional: !0
            });
            reactiveHref = hh(() => this.isAnchorElement ? this.computeHref(this._urlTree()) : this.hrefAttributeValue);
            get href() {
                return te(this.reactiveHref)
            }
            set href(n) {
                this.reactiveHref.set(n)
            }
            set target(n) {
                this._target.set(n)
            }
            get target() {
                return te(this._target)
            }
            _target = ae(void 0);
            set queryParams(n) {
                this._queryParams.set(n)
            }
            get queryParams() {
                return te(this._queryParams)
            }
            _queryParams = ae(void 0, {
                equal: () => !1
            });
            set fragment(n) {
                this._fragment.set(n)
            }
            get fragment() {
                return te(this._fragment)
            }
            _fragment = ae(void 0);
            set queryParamsHandling(n) {
                this._queryParamsHandling.set(n)
            }
            get queryParamsHandling() {
                return te(this._queryParamsHandling)
            }
            _queryParamsHandling = ae(void 0);
            set state(n) {
                this._state.set(n)
            }
            get state() {
                return te(this._state)
            }
            _state = ae(void 0, {
                equal: () => !1
            });
            set info(n) {
                this._info.set(n)
            }
            get info() {
                return te(this._info)
            }
            _info = ae(void 0, {
                equal: () => !1
            });
            set relativeTo(n) {
                this._relativeTo.set(n)
            }
            get relativeTo() {
                return te(this._relativeTo)
            }
            _relativeTo = ae(void 0);
            set preserveFragment(n) {
                this._preserveFragment.set(n)
            }
            get preserveFragment() {
                return te(this._preserveFragment)
            }
            _preserveFragment = ae(!1);
            set skipLocationChange(n) {
                this._skipLocationChange.set(n)
            }
            get skipLocationChange() {
                return te(this._skipLocationChange)
            }
            _skipLocationChange = ae(!1);
            set replaceUrl(n) {
                this._replaceUrl.set(n)
            }
            get replaceUrl() {
                return te(this._replaceUrl)
            }
            _replaceUrl = ae(!1);
            isAnchorElement;
            onChanges = new ne;
            applicationErrorHandler = h(Ke);
            options = h(dr, {
                optional: !0
            });
            reactiveRouterState = h(pL);
            constructor(n, r, o, i, s, a) {
                this.router = n, this.route = r, this.tabIndexAttribute = o, this.renderer = i, this.el = s, this.locationStrategy = a;
                let c = s.nativeElement.tagName ? .toLowerCase();
                this.isAnchorElement = c === "a" || c === "area" || !!(typeof customElements == "object" && customElements.get(c) ? .observedAttributes ? .includes ? .("href"))
            }
            setTabIndexIfNotOnNativeEl(n) {
                this.tabIndexAttribute != null || this.isAnchorElement || this.applyAttributeValue("tabindex", n)
            }
            ngOnChanges(n) {
                this.onChanges.next(this)
            }
            routerLinkInput = ae(null);
            set routerLink(n) {
                n == null ? (this.routerLinkInput.set(null), this.setTabIndexIfNotOnNativeEl(null)) : (cr(n) ? this.routerLinkInput.set(n) : this.routerLinkInput.set(Array.isArray(n) ? n : [n]), this.setTabIndexIfNotOnNativeEl("0"))
            }
            onClick(n, r, o, i, s) {
                let a = this._urlTree();
                if (a === null || this.isAnchorElement && (n !== 0 || r || o || i || s || typeof this.target == "string" && this.target != "_self")) return !0;
                let c = {
                    skipLocationChange: this.skipLocationChange,
                    replaceUrl: this.replaceUrl,
                    state: this.state,
                    info: this.info
                };
                return this.router.navigateByUrl(a, c) ? .catch(l => {
                    this.applicationErrorHandler(l)
                }), !this.isAnchorElement
            }
            ngOnDestroy() {}
            applyAttributeValue(n, r) {
                let o = this.renderer,
                    i = this.el.nativeElement;
                r !== null ? o.setAttribute(i, n, r) : o.removeAttribute(i, n)
            }
            _urlTree = Is(() => {
                this.reactiveRouterState.path(), this._preserveFragment() && this.reactiveRouterState.fragment();
                let n = o => o === "preserve" || o === "merge";
                (n(this._queryParamsHandling()) || n(this.options ? .defaultQueryParamsHandling)) && this.reactiveRouterState.queryParams();
                let r = this.routerLinkInput();
                return r === null || !this.router.createUrlTree ? null : cr(r) ? r : this.router.createUrlTree(r, {
                    relativeTo: this._relativeTo() !== void 0 ? this._relativeTo() : this.route,
                    queryParams: this._queryParams(),
                    fragment: this._fragment(),
                    queryParamsHandling: this._queryParamsHandling(),
                    preserveFragment: this._preserveFragment()
                })
            }, {
                equal: (n, r) => this.computeHref(n) === this.computeHref(r)
            });
            get urlTree() {
                return te(this._urlTree)
            }
            computeHref(n) {
                return n !== null && this.locationStrategy ? this.locationStrategy ? .prepareExternalUrl(this.router.serializeUrl(n)) ? ? "" : null
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Wt), k(On), cs("tabindex"), k(Tn), k(it), k(Vt))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "routerLink", ""]
                ],
                hostVars: 2,
                hostBindings: function(r, o) {
                    r & 1 && Cl("click", function(s) {
                        return o.onClick(s.button, s.ctrlKey, s.shiftKey, s.altKey, s.metaKey)
                    }), r & 2 && Dl("href", o.reactiveHref(), bp)("target", o._target())
                },
                inputs: {
                    target: "target",
                    queryParams: "queryParams",
                    fragment: "fragment",
                    queryParamsHandling: "queryParamsHandling",
                    state: "state",
                    info: "info",
                    relativeTo: "relativeTo",
                    preserveFragment: [2, "preserveFragment", "preserveFragment", bn],
                    skipLocationChange: [2, "skipLocationChange", "skipLocationChange", bn],
                    replaceUrl: [2, "replaceUrl", "replaceUrl", bn],
                    routerLink: "routerLink"
                },
                features: [rn]
            })
        }
        return e
    })(),
    hL = (() => {
        class e {
            router;
            element;
            renderer;
            cdr;
            links;
            classes = [];
            routerEventsSubscription;
            linkInputChangesSubscription;
            _isActive = !1;
            get isActive() {
                return this._isActive
            }
            routerLinkActiveOptions = {
                exact: !1
            };
            ariaCurrentWhenActive;
            isActiveChange = new Re;
            link = h(Nu, {
                optional: !0
            });
            constructor(n, r, o, i) {
                this.router = n, this.element = r, this.renderer = o, this.cdr = i, this.routerEventsSubscription = n.events.subscribe(s => {
                    s instanceof lt && this.update()
                })
            }
            ngAfterContentInit() {
                R(this.links.changes, R(null)).pipe(Kt()).subscribe(n => {
                    this.update(), this.subscribeToEachLinkOnChanges()
                })
            }
            subscribeToEachLinkOnChanges() {
                this.linkInputChangesSubscription ? .unsubscribe();
                let n = [...this.links.toArray(), this.link].filter(r => !!r).map(r => r.onChanges);
                this.linkInputChangesSubscription = J(n).pipe(Kt()).subscribe(r => {
                    this._isActive !== this.isLinkActive(this.router)(r) && this.update()
                })
            }
            set routerLinkActive(n) {
                let r = Array.isArray(n) ? n : n.split(" ");
                this.classes = r.filter(o => !!o)
            }
            ngOnChanges(n) {
                this.update()
            }
            ngOnDestroy() {
                this.routerEventsSubscription.unsubscribe(), this.linkInputChangesSubscription ? .unsubscribe()
            }
            update() {
                !this.links || !this.router.navigated || queueMicrotask(() => {
                    let n = this.hasActiveLinks();
                    this.classes.forEach(r => {
                        n ? this.renderer.addClass(this.element.nativeElement, r) : this.renderer.removeClass(this.element.nativeElement, r)
                    }), n && this.ariaCurrentWhenActive !== void 0 ? this.renderer.setAttribute(this.element.nativeElement, "aria-current", this.ariaCurrentWhenActive.toString()) : this.renderer.removeAttribute(this.element.nativeElement, "aria-current"), this._isActive !== n && (this._isActive = n, this.cdr.markForCheck(), this.isActiveChange.emit(n))
                })
            }
            isLinkActive(n) {
                let r = mL(this.routerLinkActiveOptions) ? this.routerLinkActiveOptions : this.routerLinkActiveOptions.exact ? ? !1 ? E({}, Cm) : E({}, Vs);
                return o => {
                    let i = o.urlTree;
                    return i ? te(Im(i, n, r)) : !1
                }
            }
            hasActiveLinks() {
                let n = this.isLinkActive(this.router);
                return this.link && n(this.link) || this.links.some(n)
            }
            static\ u0275fac = function(r) {
                return new(r || e)(k(Wt), k(it), k(Tn), k(ir))
            };
            static\ u0275dir = be({
                type: e,
                selectors: [
                    ["", "routerLinkActive", ""]
                ],
                contentQueries: function(r, o, i) {
                    if (r & 1 && Il(i, Nu, 5), r & 2) {
                        let s;
                        lh(s = uh()) && (o.links = s)
                    }
                },
                inputs: {
                    routerLinkActiveOptions: "routerLinkActiveOptions",
                    ariaCurrentWhenActive: "ariaCurrentWhenActive",
                    routerLinkActive: "routerLinkActive"
                },
                outputs: {
                    isActiveChange: "isActiveChange"
                },
                exportAs: ["routerLinkActive"],
                features: [rn]
            })
        }
        return e
    })();

function mL(e) {
    let t = e;
    return !!(t.paths || t.matrixParams || t.queryParams || t.fragment)
}
var Xs = class {};
var $x = (() => {
        class e {
            router;
            injector;
            preloadingStrategy;
            loader;
            subscription;
            constructor(n, r, o, i) {
                this.router = n, this.injector = r, this.preloadingStrategy = o, this.loader = i
            }
            setUpPreloading() {
                this.subscription = this.router.events.pipe(Ne(n => n instanceof lt), qn(() => this.preload())).subscribe(() => {})
            }
            preload() {
                return this.processRoutes(this.injector, this.router.config)
            }
            ngOnDestroy() {
                this.subscription ? .unsubscribe()
            }
            processRoutes(n, r) {
                let o = [];
                for (let i of r) {
                    i.providers && !i._injector && (i._injector = Go(i.providers, n, ""));
                    let s = i._injector ? ? n;
                    i._loadedNgModuleFactory && !i._loadedInjector && (i._loadedInjector = i._loadedNgModuleFactory.create(s).injector);
                    let a = i._loadedInjector ? ? s;
                    (i.loadChildren && !i._loadedRoutes && i.canLoad === void 0 || i.loadComponent && !i._loadedComponent) && o.push(this.preloadConfig(s, i)), (i.children || i._loadedRoutes) && o.push(this.processRoutes(a, i.children ? ? i._loadedRoutes))
                }
                return J(o).pipe(Kt())
            }
            preloadConfig(n, r) {
                return this.preloadingStrategy.preload(r, () => {
                    if (n.destroyed) return R(null);
                    let o;
                    r.loadChildren && r.canLoad === void 0 ? o = J(this.loader.loadChildren(n, r)) : o = R(null);
                    let i = o.pipe(de(s => s === null ? R(void 0) : (r._loadedRoutes = s.routes, r._loadedInjector = s.injector, r._loadedNgModuleFactory = s.factory, this.processRoutes(s.injector ? ? n, s.routes))));
                    if (r.loadComponent && !r._loadedComponent) {
                        let s = this.loader.loadComponent(n, r);
                        return J([i, s]).pipe(Kt())
                    } else return i
                })
            }
            static\ u0275fac = function(r) {
                return new(r || e)(_(Wt), _(re), _(Xs), _(Su))
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
        return e
    })(),
    Gx = new v(""),
    gL = (() => {
        class e {
            options;
            routerEventsSubscription;
            scrollEventsSubscription;
            lastId = 0;
            lastSource = Qo;
            restoredId = 0;
            store = {};
            isHydrating = h(Dp, {
                optional: !0
            }) ? ? !1;
            urlSerializer = h(ur);
            zone = h(Q);
            viewportScroller = h($h);
            transitions = h(wu);
            constructor(n) {
                this.options = n, this.options.scrollPositionRestoration || = "disabled", this.options.anchorScrolling || = "disabled", this.isHydrating && h(Bt).whenStable().then(() => {
                    this.isHydrating = !1
                })
            }
            init() {
                this.options.scrollPositionRestoration !== "disabled" && this.viewportScroller.setHistoryScrollRestoration("manual"), this.routerEventsSubscription = this.createScrollEvents(), this.scrollEventsSubscription = this.consumeScrollEvents()
            }
            createScrollEvents() {
                return this.transitions.events.subscribe(n => {
                    n instanceof lr ? (this.store[this.lastId] = this.viewportScroller.getScrollPosition(), this.lastSource = n.navigationTrigger, this.restoredId = n.restoredState ? n.restoredState.navigationId : 0) : n instanceof lt ? (this.lastId = n.id, this.scheduleScrollEvent(n, this.urlSerializer.parse(n.urlAfterRedirects).fragment)) : n instanceof ln && n.code === Xo.IgnoredSameUrlNavigation && (this.lastSource = void 0, this.restoredId = 0, this.scheduleScrollEvent(n, this.urlSerializer.parse(n.url).fragment))
                })
            }
            consumeScrollEvents() {
                return this.transitions.events.subscribe(n => {
                    if (!(n instanceof ei) || n.scrollBehavior === "manual") return;
                    let r = {
                        behavior: "instant"
                    };
                    n.position ? this.options.scrollPositionRestoration === "top" ? this.viewportScroller.scrollToPosition([0, 0], r) : this.options.scrollPositionRestoration === "enabled" && this.viewportScroller.scrollToPosition(n.position, r) : n.anchor && this.options.anchorScrolling === "enabled" ? this.viewportScroller.scrollToAnchor(n.anchor) : this.options.scrollPositionRestoration !== "disabled" && this.viewportScroller.scrollToPosition([0, 0])
                })
            }
            scheduleScrollEvent(n, r) {
                if (this.isHydrating) return;
                let o = te(this.transitions.currentNavigation) ? .extras.scroll;
                this.zone.runOutsideAngular(() => G(this, null, function*() {
                    yield new Promise(i => {
                        setTimeout(i), typeof requestAnimationFrame < "u" && requestAnimationFrame(i)
                    }), this.zone.run(() => {
                        this.transitions.events.next(new ei(n, this.lastSource === "popstate" ? this.store[this.restoredId] : null, r, o))
                    })
                }))
            }
            ngOnDestroy() {
                this.routerEventsSubscription ? .unsubscribe(), this.scrollEventsSubscription ? .unsubscribe()
            }
            static\ u0275fac = function(r) {
                Vp()
            };
            static\ u0275prov = y({
                token: e,
                factory: e.\u0275fac
            })
        }
        return e
    })();

function EL() {
    return h(Wt).routerState.root
}

function ea(e, t) {
    return {\
        u0275kind: e,
        \u0275providers: t
    }
}

function yL() {
    let e = h(fe);
    return t => {
        let n = e.get(Bt);
        if (t !== n.components[0]) return;
        let r = e.get(Wt),
            o = e.get(Wx);
        e.get(km) === 1 && r.initialNavigation(), e.get(Kx, null, {
            optional: !0
        }) ? .setUpPreloading(), e.get(Gx, null, {
            optional: !0
        }) ? .init(), r.resetRootComponentType(n.componentTypes[0]), o.closed || (o.next(), o.complete(), o.unsubscribe())
    }
}
var Wx = new v("", {
        factory: () => new ne
    }),
    km = new v("", {
        factory: () => 1
    });

function zx() {
    let e = [{
        provide: Zc,
        useValue: !0
    }, {
        provide: km,
        useValue: 0
    }, yl(() => {
        let t = h(fe);
        return t.get(wh, Promise.resolve()).then(() => new Promise(r => {
            let o = t.get(Wt),
                i = t.get(Wx);
            Mu(o, () => {
                r(!0)
            }), t.get(wu).afterPreactivation = () => (r(!0), i.closed ? R(void 0) : i), o.initialNavigation()
        }))
    })];
    return ea(2, e)
}

function qx() {
    let e = [yl(() => {
        h(Wt).setUpLocationChangeListener()
    }), {
        provide: km,
        useValue: 2
    }];
    return ea(3, e)
}
var Kx = new v("");

function Yx(e) {
    return ea(0, [{
        provide: Kx,
        useExisting: $x
    }, {
        provide: Xs,
        useExisting: e
    }])
}

function Jx() {
    return ea(8, [wm, {
        provide: Qs,
        useExisting: wm
    }])
}

function Qx(e) {
    Ye("NgRouterViewTransitions");
    let t = [{
        provide: Rm,
        useValue: jx
    }, {
        provide: Om,
        useValue: E({
            skipNextTransition: !!e ? .skipInitialTransition
        }, e)
    }];
    return ea(9, t)
}
var Zx = [sr, {
        provide: ur,
        useClass: Rn
    }, Wt, no, {
        provide: On,
        useFactory: EL
    }, Su, []],
    vL = (() => {
        class e {
            constructor() {}
            static forRoot(n, r) {
                return {
                    ngModule: e,
                    providers: [Zx, [], {
                            provide: ai,
                            multi: !0,
                            useValue: n
                        },
                        [], r ? .errorHandler ? {
                            provide: Pm,
                            useValue: r.errorHandler
                        } : [], {
                            provide: dr,
                            useValue: r || {}
                        },
                        r ? .useHash ? _L() : xL(), DL(), r ? .preloadingStrategy ? Yx(r.preloadingStrategy).\u0275providers : [], r ? .initialNavigation ? CL(r) : [], r ? .bindToComponentInputs ? Jx().\u0275providers : [], r ? .enableViewTransitions ? Qx().\u0275providers : [], IL()
                    ]
                }
            }
            static forChild(n) {
                return {
                    ngModule: e,
                    providers: [{
                        provide: ai,
                        multi: !0,
                        useValue: n
                    }]
                }
            }
            static\ u0275fac = function(r) {
                return new(r || e)
            };
            static\ u0275mod = Ut({
                type: e
            });
            static\ u0275inj = ft({})
        }
        return e
    })();

function DL() {
    return {
        provide: Gx,
        useFactory: () => {
            let e = h($h),
                t = h(dr);
            return t.scrollOffset && e.setOffset(t.scrollOffset), new gL(t)
        }
    }
}

function _L() {
    return {
        provide: Vt,
        useClass: Fh
    }
}

function xL() {
    return {
        provide: Vt,
        useClass: Ol
    }
}

function CL(e) {
    return [e.initialNavigation === "disabled" ? qx().\u0275providers : [], e.initialNavigation === "enabledBlocking" ? zx().\u0275providers : []]
}
var Lm = new v("");

function IL() {
    return [{
        provide: Lm,
        useFactory: yL
    }, {
        provide: vl,
        multi: !0,
        useExisting: Lm
    }]
}
var ro = {
    production: !0,
    currentEnvironment: "production",
    domainName: "bytephase.com",
    websiteUrl: "https://bytephase.com",
    baseUrl: "api.bytephase.com",
    frontendBaseUrl: "https://bytephase.com",
    appUrl: "https://app.bytephase.com",
    capacitorAppId: "com.bytephase.app.twa",
    capacitorAppName: "Bytephase",
    androidVersionCode: 25,
    androidVersionName: "25.0",
    firebase: {
        apiKey: "AIzaSyA0pt979S75KsHce58YjfVWuJI-QpFOMcc",
        authDomain: "bytephase-push-notificat-4d4b3.firebaseapp.com",
        projectId: "bytephase-push-notificat-4d4b3",
        storageBucket: "bytephase-push-notificat-4d4b3.appspot.com",
        messagingSenderId: "501948568283",
        appId: "1:501948568283:web:0cb0ac060e7739dff9f2fe",
        measurementId: "G-6KSH6KR3JW",
        vapidKey: "BKaAehMlElQt6_Cn4BLOZ50grxEulTRP-pT5jEE2_9SwwODAeYKLO3ZcSPFROqN6vfv_nQUzUs_lX7ztBlztZ4s"
    },
    siteKey: "6Lc8wyUjAAAAAPhrwENZYebOwfPj5O7s1cEqe13M",
    client_id: "501948568283-9g6i2qnupvji8mvvq6hpi2ui1aljs8iq.apps.googleusercontent.com",
    redirect_uri: "https://app.bytephase.com/auth/callback",
    pusherKey: "0c83d41e64dc55e9ee49",
    googleMapsApiKey: "AIzaSyAqCTmIK2KmOcHlO2ecRAfU4dxXZBKNn78",
    appVersion: "3.1.0",
    feedbackModuleAllowedUsersEmail: ["ganeshghalme31@gmail.com", "midhun.bytephase@gmail.com", "akshay.bytephase@gmail.com", "madhu.bytephase@gmail.com", "ashwini.bytephase@gmail.com", "siddhant.bytephase@gmail.com", "nikhil.bytephase@gmail.com", "vishwajit.bytephase@gmail.com"]
};
var Xx = {
    _formatNumberCore(e, t, n) {
        if (t === "currency") {
            n.precision = n.precision ? ? 0;
            let r = this.format(e, Object.assign({}, n, {
                    type: "fixedpoint"
                })),
                o = this.getCurrencySymbol().symbol.replace(/\$/g, "$$$$");
            return r = r.replace(/^(\D*)(\d.*)/, `$1${o}$2`), r
        }
        return this.callBase.apply(this, [e, t, n])
    },
    getCurrencySymbol: () => ({
        symbol: "$"
    }),
    getOpenXmlCurrencyFormat: () => "$#,##0{0}_);\\($#,##0{0}\\)"
};
var eC = {
    "en-150": "en-001",
    "en-AG": "en-001",
    "en-AI": "en-001",
    "en-AU": "en-001",
    "en-BB": "en-001",
    "en-BM": "en-001",
    "en-BS": "en-001",
    "en-BW": "en-001",
    "en-BZ": "en-001",
    "en-CC": "en-001",
    "en-CK": "en-001",
    "en-CM": "en-001",
    "en-CX": "en-001",
    "en-CY": "en-001",
    "en-DG": "en-001",
    "en-DM": "en-001",
    "en-ER": "en-001",
    "en-FJ": "en-001",
    "en-FK": "en-001",
    "en-FM": "en-001",
    "en-GB": "en-001",
    "en-GD": "en-001",
    "en-GG": "en-001",
    "en-GH": "en-001",
    "en-GI": "en-001",
    "en-GM": "en-001",
    "en-GY": "en-001",
    "en-HK": "en-001",
    "en-IE": "en-001",
    "en-IL": "en-001",
    "en-IM": "en-001",
    "en-IN": "en-001",
    "en-IO": "en-001",
    "en-JE": "en-001",
    "en-JM": "en-001",
    "en-KE": "en-001",
    "en-KI": "en-001",
    "en-KN": "en-001",
    "en-KY": "en-001",
    "en-LC": "en-001",
    "en-LR": "en-001",
    "en-LS": "en-001",
    "en-MG": "en-001",
    "en-MO": "en-001",
    "en-MS": "en-001",
    "en-MT": "en-001",
    "en-MU": "en-001",
    "en-MV": "en-001",
    "en-MW": "en-001",
    "en-MY": "en-001",
    "en-NA": "en-001",
    "en-NF": "en-001",
    "en-NG": "en-001",
    "en-NR": "en-001",
    "en-NU": "en-001",
    "en-NZ": "en-001",
    "en-PG": "en-001",
    "en-PK": "en-001",
    "en-PN": "en-001",
    "en-PW": "en-001",
    "en-RW": "en-001",
    "en-SB": "en-001",
    "en-SC": "en-001",
    "en-SD": "en-001",
    "en-SG": "en-001",
    "en-SH": "en-001",
    "en-SL": "en-001",
    "en-SS": "en-001",
    "en-SX": "en-001",
    "en-SZ": "en-001",
    "en-TC": "en-001",
    "en-TK": "en-001",
    "en-TO": "en-001",
    "en-TT": "en-001",
    "en-TV": "en-001",
    "en-TZ": "en-001",
    "en-UG": "en-001",
    "en-VC": "en-001",
    "en-VG": "en-001",
    "en-VU": "en-001",
    "en-WS": "en-001",
    "en-ZA": "en-001",
    "en-ZM": "en-001",
    "en-ZW": "en-001",
    "en-AT": "en-150",
    "en-BE": "en-150",
    "en-CH": "en-150",
    "en-DE": "en-150",
    "en-DK": "en-150",
    "en-FI": "en-150",
    "en-NL": "en-150",
    "en-SE": "en-150",
    "en-SI": "en-150",
    "hi-Latn": "en-IN",
    "es-AR": "es-419",
    "es-BO": "es-419",
    "es-BR": "es-419",
    "es-BZ": "es-419",
    "es-CL": "es-419",
    "es-CO": "es-419",
    "es-CR": "es-419",
    "es-CU": "es-419",
    "es-DO": "es-419",
    "es-EC": "es-419",
    "es-GT": "es-419",
    "es-HN": "es-419",
    "es-MX": "es-419",
    "es-NI": "es-419",
    "es-PA": "es-419",
    "es-PE": "es-419",
    "es-PR": "es-419",
    "es-PY": "es-419",
    "es-SV": "es-419",
    "es-US": "es-419",
    "es-UY": "es-419",
    "es-VE": "es-419",
    nb: "no",
    nn: "no",
    "pt-AO": "pt-PT",
    "pt-CH": "pt-PT",
    "pt-CV": "pt-PT",
    "pt-FR": "pt-PT",
    "pt-GQ": "pt-PT",
    "pt-GW": "pt-PT",
    "pt-LU": "pt-PT",
    "pt-MO": "pt-PT",
    "pt-MZ": "pt-PT",
    "pt-ST": "pt-PT",
    "pt-TL": "pt-PT",
    "az-Arab": "und",
    "az-Cyrl": "und",
    "bal-Latn": "und",
    "blt-Latn": "und",
    "bm-Nkoo": "und",
    "bs-Cyrl": "und",
    "byn-Latn": "und",
    "cu-Glag": "und",
    "dje-Arab": "und",
    "dyo-Arab": "und",
    "en-Dsrt": "und",
    "en-Shaw": "und",
    "ff-Adlm": "und",
    "ff-Arab": "und",
    "ha-Arab": "und",
    "iu-Latn": "und",
    "kk-Arab": "und",
    "ks-Deva": "und",
    "ku-Arab": "und",
    "ky-Arab": "und",
    "ky-Latn": "und",
    "ml-Arab": "und",
    "mn-Mong": "und",
    "mni-Mtei": "und",
    "ms-Arab": "und",
    "pa-Arab": "und",
    "sat-Deva": "und",
    "sd-Deva": "und",
    "sd-Khoj": "und",
    "sd-Sind": "und",
    "shi-Latn": "und",
    "so-Arab": "und",
    "sr-Latn": "und",
    "sw-Arab": "und",
    "tg-Arab": "und",
    "ug-Cyrl": "und",
    "uz-Arab": "und",
    "uz-Cyrl": "und",
    "vai-Latn": "und",
    "wo-Arab": "und",
    "yo-Arab": "und",
    "yue-Hans": "und",
    "zh-Hant": "und",
    "zh-Hant-MO": "zh-Hant-HK"
};
var tC = (e, t) => {
    let n = e[t];
    return n ? n !== "root" && n : t.substr(0, t.lastIndexOf("-"))
};
var TL = {
        "[object Array]": "array",
        "[object Date]": "date",
        "[object Object]": "object",
        "[object String]": "string"
    },
    fr = function(e) {
        if (e === null) return "null";
        let t = Object.prototype.toString.call(e);
        return typeof e == "object" ? TL[t] || "object" : typeof e
    },
    nC = function(e) {
        return typeof e == "boolean"
    },
    ta = function(e) {
        return ci(e) && e.toString().indexOf("e") !== -1
    },
    rC = function(e) {
        return fr(e) === "date"
    },
    un = function(e) {
        return e != null
    },
    we = function(e) {
        return typeof e == "function"
    },
    dn = function(e) {
        return typeof e == "string"
    },
    ci = function(e) {
        return typeof e == "number" && isFinite(e) || !isNaN(e - parseFloat(e))
    },
    Ct = function(e) {
        return fr(e) === "object"
    },
    oC = function(e) {
        let t;
        for (t in e) return !1;
        return !0
    },
    We = function(e) {
        if (!e || fr(e) !== "object") return !1;
        let t = Object.getPrototypeOf(e);
        if (!t) return !0;
        let n = Object.hasOwnProperty.call(t, "constructor") && t.constructor;
        return typeof n == "function" && Object.toString.call(n) === Object.toString.call(Object)
    },
    iC = function(e) {
        return !["object", "array", "function"].includes(fr(e))
    },
    Ru = function(e) {
        return e != null && e === e.window
    },
    sC = function(e) {
        return !!e && !!(e.jquery || e.dxRenderer)
    },
    na = function(e) {
        return !!e && we(e.then)
    },
    li = function(e) {
        return !!e && we(e.done) && we(e.fail)
    },
    aC = function(e) {
        return !!(e && e.preventDefault)
    };
var V6 = {
    isBoolean: nC,
    isDate: rC,
    isDeferred: li,
    isDefined: un,
    isEmptyObject: oC,
    isEvent: aC,
    isExponential: ta,
    isFunction: we,
    isNumeric: ci,
    isObject: Ct,
    isPlainObject: We,
    isPrimitive: iC,
    isPromise: na,
    isRenderer: sC,
    isString: dn,
    isWindow: Ru,
    type: fr
};
var SL = function(e, t, n) {
        e = e || {};
        for (let r in t)
            if (Object.prototype.hasOwnProperty.call(t, r)) {
                let o = t[r];
                (!(r in e) || n) && (e[r] = o)
            }
        return e
    },
    Te = function(e) {
        e = e || {};
        let t = 1,
            n = !1;
        for (typeof e == "boolean" && (n = e, e = arguments[1] || {}, t++); t < arguments.length; t++) {
            let r = arguments[t];
            if (r != null)
                for (let o in r) {
                    let i = e[o],
                        s = r[o],
                        a = !1,
                        c;
                    o === "__proto__" || o === "constructor" || e === s || (n && s && (We(s) || (a = Array.isArray(s))) ? (a ? c = i && Array.isArray(i) ? i : [] : c = i && We(i) ? i : {}, e[o] = Te(n, c, s)) : s !== void 0 && (e[o] = s))
                }
        }
        return e
    };
var bL = (function() {
        let e = [new RegExp("&", "g"), new RegExp('"', "g"), new RegExp("'", "g"), new RegExp("<", "g"), new RegExp(">", "g")];
        return function(t) {
            return String(t).replace(e[0], "&amp;").replace(e[1], "&quot;").replace(e[2], "&#39;").replace(e[3], "&lt;").replace(e[4], "&gt;")
        }
    })(),
    wL = function(e) {
        switch (typeof e) {
            case "string":
                return e.split(/\s+/, 4);
            case "object":
                return [e.x || e.h || e.left, e.y || e.v || e.top, e.x || e.h || e.right, e.y || e.v || e.bottom];
            case "number":
                return [e];
            default:
                return e
        }
    },
    AL = function(e) {
        let t = wL(e),
            n = parseInt(t && t[0], 10),
            r = parseInt(t && t[1], 10),
            o = parseInt(t && t[2], 10),
            i = parseInt(t && t[3], 10);
        return isFinite(n) || (n = 0), isFinite(r) || (r = n), isFinite(o) || (o = n), isFinite(i) || (i = r), {
            top: r,
            right: o,
            bottom: i,
            left: n
        }
    };

function ui(e) {
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
    return we(e) ? e(...n) : (n.forEach((o, i) => {
        dn(o) && (o = o.replace(/\$/g, "$$$$"));
        let s = new RegExp(`\\{${i}\\}`, "gm");
        e = e.replace(s, o)
    }), e)
}
var ML = (function() {
    let e = /\s/g;
    return function(t) {
        return !t || !t.replace(e, "")
    }
})();
var cC = "25.1.11",
    e9 = "25.1.11";
var NL = function() {},
    Ou = function(e) {
        return typeof console > "u" || !we(console[e]) ? NL : console[e].bind(console)
    },
    di = {
        log: Ou("log"),
        info: Ou("info"),
        warn: Ou("warn"),
        error: Ou("error")
    },
    lC = (function() {
        function e(t, n) {
            if (!t) throw new Error(n)
        }
        return {
            assert: e,
            assertParam: function(t, n) {
                e(t != null, n)
            }
        }
    })(),
    uC = {
        logger: di,
        debug: lC
    };
var RL = `https://js.devexpress.com/error/${cC.split(".").slice(0,2).join("_")}/`;

function dC(e, t) {
    let n = {
        ERROR_MESSAGES: Te(t, e),
        Error: function() {
            for (var s = arguments.length, a = new Array(s), c = 0; c < s; c++) a[c] = arguments[c];
            return (function(l) {
                let u = l[0];
                l = l.slice(1);
                let d = r(u, l),
                    f = i(u),
                    p = o(u, d);
                return Te(new Error(p), {
                    __id: u,
                    __details: d,
                    url: f
                })
            })(a)
        },
        log() {
            for (var s = arguments.length, a = new Array(s), c = 0; c < s; c++) a[c] = arguments[c];
            let l = a[0],
                u = "log";
            /^E\d+$/.test(l) ? u = "error" : /^W\d+$/.test(l) && (u = "warn"), uC.logger[u](u === "log" ? l : (function(d) {
                let f = d[0];
                return d = d.slice(1), o(f, r(f, d))
            })(a))
        }
    };

    function r(s, a) {
        return a = [n.ERROR_MESSAGES[s]].concat(a), ui.apply(this, a).replace(/\.*\s*?$/, "")
    }

    function o(s, a) {
        let c = s != null && s.startsWith("W") ? "warning" : "error";
        return ui.apply(this, [`{0} - {1}.

For additional information on this {2} message, see: {3}`, s, a, c, i(s)])
    }

    function i(s) {
        return RL + s
    }
    return n
}
var fC = dC;
var Pu = fC({
    E0001: "Method is not implemented",
    E0002: "Member name collision: {0}",
    E0003: "A class must be instantiated using the 'new' keyword",
    E0004: "The NAME property of the component is not specified",
    E0005: "Unknown device",
    E0006: "Unknown endpoint key is requested",
    E0007: "'Invalidate' method is called outside the update transaction",
    E0008: "Type of the option name is not appropriate to create an action",
    E0009: "Component '{0}' has not been initialized for an element",
    E0010: "Animation configuration with the '{0}' type requires '{1}' configuration as {2}",
    E0011: "Unknown animation type '{0}'",
    E0012: "jQuery version is too old. Please upgrade jQuery to 1.10.0 or later",
    E0013: "KnockoutJS version is too old. Please upgrade KnockoutJS to 2.3.0 or later",
    E0014: "The 'release' method shouldn't be called for an unlocked Lock object",
    E0015: "Queued task returned an unexpected result",
    E0017: "Event namespace is not defined",
    E0018: "DevExpress.ui.DevExpressPopup widget is required",
    E0020: "Template engine '{0}' is not supported",
    E0021: "Unknown theme is set: {0}",
    E0022: "LINK[rel=DevExpress-theme] tags must go before DevExpress included scripts",
    E0023: "Template name is not specified",
    E0024: "DevExtreme bundle already included",
    E0025: "Unexpected argument type",
    E0100: "Unknown validation type is detected",
    E0101: "Misconfigured range validation rule is detected",
    E0102: "Misconfigured comparison validation rule is detected",
    E0103: "validationCallback of an asynchronous rule should return a jQuery or a native promise",
    E0110: "Unknown validation group is detected",
    E0120: "Adapter for a DevExpressValidator component cannot be configured",
    E0121: "The 'customItem' parameter of the 'onCustomItemCreating' function is empty or contains invalid data. Assign a custom object or a Promise that is resolved after the item is created.",
    E0122: "AIIntegration: The sendRequest method is missing.",
    W0000: "'{0}' is deprecated in {1}. {2}",
    W0001: "{0} - '{1}' option is deprecated in {2}. {3}",
    W0002: "{0} - '{1}' method is deprecated in {2}. {3}",
    W0003: "{0} - '{1}' property is deprecated in {2}. {3}",
    W0004: "Timeout for theme loading is over: {0}",
    W0005: "'{0}' event is deprecated in {1}. {2}",
    W0006: "Invalid recurrence rule: '{0}'",
    W0007: "'{0}' Globalize culture is not defined",
    W0008: "Invalid view type: {0}",
    W0009: "Invalid time zone name: '{0}'",
    W0010: "{0} is deprecated in {1}. {2}",
    W0011: "Number parsing is invoked while the parser is not defined",
    W0012: "Date parsing is invoked while the parser is not defined",
    W0013: "'{0}' file is deprecated in {1}. {2}",
    W0014: "{0} - '{1}' type is deprecated in {2}. {3}",
    W0015: "Instead of returning a value from the '{0}' function, write it into the '{1}' field of the function's parameter.",
    W0016: 'The "{0}" option does not accept the "{1}" value since v{2}. {3}.',
    W0017: 'Setting the "{0}" property with a function is deprecated since v21.2',
    W0018: 'Setting the "position" property with a function is deprecated since v21.2',
    W0019: `DevExtreme: Unable to Locate a Valid License Key.

Detailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.

If you are using a 30-day trial version of DevExtreme, you must uninstall all copies of DevExtreme once your 30-day trial period expires. For terms and conditions that govern use of DevExtreme UI components/libraries, please refer to the DevExtreme End User License Agreement: https://js.devexpress.com/EULAs/DevExtremeComplete.

To use DevExtreme in a commercial project, you must purchase a license. For pricing/licensing options, please visit: https://js.devexpress.com/Buy.

If you have licensing-related questions or need help with a purchase, please email clientservices@devexpress.com.

`,
    W0020: `DevExtreme: License Key Has Expired.

Detailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.

A mismatch exists between the license key used and the DevExtreme version referenced in this project.

To proceed, you can:
\u2022 use a version of DevExtreme linked to your license key: https://www.devexpress.com/ClientCenter/DownloadManager
\u2022 renew your DevExpress Subscription: https://www.devexpress.com/buy/renew (once you renew your subscription, you will be entitled to product updates and support service as defined in the DevExtreme End User License Agreement)

If you have licensing-related questions or need help with a renewal, please email clientservices@devexpress.com.

`,
    W0021: `DevExtreme: License Key Verification Has Failed.

Detailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.

To verify your DevExtreme license, make certain to specify a correct key in the GlobalConfig. If you continue to encounter this error, please visit https://www.devexpress.com/ClientCenter/DownloadManager to obtain a valid license key.

If you have a valid license and this problem persists, please submit a support ticket via the DevExpress Support Center. We will be happy to follow-up: https://supportcenter.devexpress.com/ticket/create.

`,
    W0022: `DevExtreme: Pre-release software. Not suitable for commercial use.

Detailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.

Pre-release software may contain deficiencies and as such, should not be considered for use or integrated in any mission critical application.

`,
    W0023: `DevExtreme: the following 'devextreme' package version does not match versions of other DevExpress products used in this application:

{0}

Interoperability between different versions of the products listed herein cannot be guaranteed.

`,
    W0024: `DevExtreme: Use Your DevExtreme License Key - Not Your DevExpress .NET License Key

Invalid/incorrect license key. You used your DevExpress .NET license key instead of your DevExtreme (React, Angular, Vue, JS) license key. Please copy your DevExtreme license key and try again. 

Go to https://www.devexpress.com/ClientCenter/DownloadManager (navigate to the DevExtreme Subscription section) to obtain a valid DevExtreme license key. To validate your license, specify the correct key within GlobalConfig.

For detailed license/registration information, visit https://js.devexpress.com/Documentation/Licensing/.

If you have a valid license and the issue persists, submit a support ticket via the DevExpress Support Center. We will be happy to follow-up: https://supportcenter.devexpress.com/ticket/create.

`
});
var It = Pu;
var OL = function(e, t, n) {
        return function() {
            let r = this.callBase;
            this.callBase = e[t];
            try {
                return n.apply(this, arguments)
            } finally {
                this.callBase = r
            }
        }
    },
    PL = function(e) {
        let t = function() {};
        return t.prototype = e.prototype, new t
    },
    LL = function(e) {
        let t = this,
            n, r, o;
        if (!e) return t;
        for (r in e) o = e[r], n = typeof t.prototype[r] == "function" && typeof o == "function", t.prototype[r] = n ? OL(t.parent.prototype, r, o) : o;
        return t
    },
    kL = function() {
        let e = this,
            t, n, r, o = Object.prototype.hasOwnProperty.bind(e);
        !o("_includedCtors") && !o("_includedPostCtors") && (e._includedCtors = e._includedCtors.slice(0), e._includedPostCtors = e._includedPostCtors.slice(0));
        for (var s = arguments.length, a = new Array(s), c = 0; c < s; c++) a[c] = arguments[c];
        for (r = 0; r < a.length; r++) {
            t = a[r], t.ctor && e._includedCtors.push(t.ctor), t.postCtor && e._includedPostCtors.push(t.postCtor);
            for (n in t) n === "ctor" || n === "postCtor" || n === "default" || (e.prototype[n] = t[n])
        }
        return e
    },
    FL = function(e) {
        if (!Object.prototype.hasOwnProperty.bind(this)("parent") && this.parent) {
            let r = Object.getPrototypeOf(this);
            return r === e || r.subclassOf(e)
        }
        return this.parent === e ? !0 : !this.parent || !this.parent.subclassOf ? !1 : this.parent.subclassOf(e)
    },
    pC = function() {
        throw It.Error("E0001")
    },
    Fm = function() {};
Fm.inherit = function(e) {
    let t = function() {
        if (!this || Ru(this) || typeof this.constructor != "function") throw It.Error("E0003");
        let n = this,
            {
                ctor: r
            } = n,
            o = n.constructor._includedCtors,
            i = n.constructor._includedPostCtors,
            s;
        for (s = 0; s < o.length; s++) o[s].call(n);
        if (r) {
            for (var a = arguments.length, c = new Array(a), l = 0; l < a; l++) c[l] = arguments[l];
            r.apply(n, c)
        }
        for (s = 0; s < i.length; s++) i[s].call(n)
    };
    return t.prototype = PL(this), Object.setPrototypeOf(t, this), t.inherit = this.inherit, t.abstract = pC, t.redefine = LL, t.include = kL, t.subclassOf = FL, t.parent = this, t._includedCtors = this._includedCtors ? this._includedCtors.slice(0) : [], t._includedPostCtors = this._includedPostCtors ? this._includedPostCtors.slice(0) : [], t.prototype.constructor = t, t.redefine(e), t
};
Fm.abstract = pC;
var hC = Fm;
var fi = hC;
var oo = (e, t) => {
        if (Array.isArray(e)) return e.map(t);
        let n = [];
        for (let r in e) n.push(t(e[r], r));
        return n
    },
    ze = (e, t) => {
        if (e) {
            if ("length" in e)
                for (let n = 0; n < e.length && t.call(e[n], n, e[n]) !== !1; n++);
            else
                for (let n in e)
                    if (t.call(e[n], n, e[n]) === !1) break;
            return e
        }
    },
    UL = (e, t) => {
        if (!(!e || !("length" in e) || e.length === 0))
            for (let n = e.length - 1; n >= 0 && t.call(e[n], n, e[n]) !== !1; n--);
    };

function fn(e) {
    let t = fi.inherit(e),
        n = t,
        r = new n(e),
        o = {},
        i = function(s, a) {
            ze(s, function(c) {
                we(r[c]) ? (a || !e[c]) && (e[c] = function() {
                    return r[c].apply(e, arguments)
                }) : (a && (o[c] = e[c]), e[c] = r[c])
            })
        };
    return i(e, !0), e.inject = function(s) {
        n = n.inherit(s), r = new n, i(s)
    }, e.resetInjection = function() {
        Te(e, o), n = t, r = new t
    }, e
}
var Ie = fn({
    locale: (() => {
        let e = "en";
        return t => {
            if (!t) return e;
            e = t
        }
    })(),
    getValueByClosestLocale(e) {
        let t = this.locale(),
            n = e(t),
            r = !1;
        for (; !n && !r;) t = tC(eC, t), t ? n = e(t) : r = !0;
        return n === void 0 && t !== "en" ? e("en") : n
    }
});
var mC = {
    "af-NA": 1,
    agq: 1,
    ak: 1,
    ar: 6,
    "ar-EH": 1,
    "ar-ER": 1,
    "ar-KM": 1,
    "ar-LB": 1,
    "ar-MA": 1,
    "ar-MR": 1,
    "ar-PS": 1,
    "ar-SO": 1,
    "ar-SS": 1,
    "ar-TD": 1,
    "ar-TN": 1,
    asa: 1,
    ast: 1,
    az: 1,
    "az-Cyrl": 1,
    bas: 1,
    be: 1,
    bem: 1,
    bez: 1,
    bg: 1,
    bm: 1,
    br: 1,
    bs: 1,
    "bs-Cyrl": 1,
    ca: 1,
    ce: 1,
    cgg: 1,
    ckb: 6,
    cs: 1,
    cy: 1,
    da: 1,
    de: 1,
    dje: 1,
    dsb: 1,
    dua: 1,
    dyo: 1,
    ee: 1,
    el: 1,
    "en-001": 1,
    "en-AE": 6,
    "en-BI": 1,
    "en-MP": 1,
    "en-MV": 5,
    "en-SD": 6,
    eo: 1,
    es: 1,
    et: 1,
    eu: 1,
    ewo: 1,
    fa: 6,
    ff: 1,
    "ff-Adlm": 1,
    fi: 1,
    fo: 1,
    fr: 1,
    "fr-DJ": 6,
    "fr-DZ": 6,
    "fr-SY": 6,
    fur: 1,
    fy: 1,
    ga: 1,
    gd: 1,
    gl: 1,
    gsw: 1,
    gv: 1,
    ha: 1,
    hr: 1,
    hsb: 1,
    hu: 1,
    hy: 1,
    ia: 1,
    ig: 1,
    is: 1,
    it: 1,
    jgo: 1,
    jmc: 1,
    ka: 1,
    kab: 6,
    kde: 1,
    kea: 1,
    khq: 1,
    kk: 1,
    kkj: 1,
    kl: 1,
    "ko-KP": 1,
    ksb: 1,
    ksf: 1,
    ksh: 1,
    ku: 1,
    kw: 1,
    ky: 1,
    lag: 1,
    lb: 1,
    lg: 1,
    ln: 1,
    lrc: 6,
    lt: 1,
    lu: 1,
    lv: 1,
    "mas-TZ": 1,
    mfe: 1,
    mg: 1,
    mgo: 1,
    mi: 1,
    mk: 1,
    mn: 1,
    ms: 1,
    mua: 1,
    mzn: 6,
    naq: 1,
    nds: 1,
    nl: 1,
    nmg: 1,
    nnh: 1,
    no: 1,
    nus: 1,
    nyn: 1,
    os: 1,
    pcm: 1,
    pl: 1,
    ps: 6,
    "pt-AO": 1,
    "pt-CH": 1,
    "pt-CV": 1,
    "pt-GQ": 1,
    "pt-GW": 1,
    "pt-LU": 1,
    "pt-ST": 1,
    "pt-TL": 1,
    "qu-BO": 1,
    "qu-EC": 1,
    rm: 1,
    rn: 1,
    ro: 1,
    rof: 1,
    ru: 1,
    rw: 1,
    rwk: 1,
    sah: 1,
    sbp: 1,
    sc: 1,
    se: 1,
    ses: 1,
    sg: 1,
    shi: 1,
    "shi-Latn": 1,
    si: 1,
    sk: 1,
    sl: 1,
    smn: 1,
    so: 1,
    "so-DJ": 6,
    sq: 1,
    sr: 1,
    "sr-Latn": 1,
    sv: 1,
    sw: 1,
    "ta-LK": 1,
    "ta-MY": 1,
    teo: 1,
    tg: 1,
    "ti-ER": 1,
    tk: 1,
    to: 1,
    tr: 1,
    tt: 1,
    twq: 1,
    tzm: 1,
    uk: 1,
    uz: 1,
    "uz-Arab": 6,
    "uz-Cyrl": 1,
    vai: 1,
    "vai-Latn": 1,
    vi: 1,
    vun: 1,
    wae: 1,
    wo: 1,
    xog: 1,
    yav: 1,
    yi: 1,
    yo: 1,
    zgh: 1
};
var BL = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    jL = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    HL = ["AM", "PM"],
    VL = ["Q1", "Q2", "Q3", "Q4"],
    gC = (e, t) => {
        let n = {
            abbreviated: 3,
            short: 2,
            narrow: 1
        };
        return oo(e, r => r.substr(0, n[t]))
    },
    ra = {
        getMonthNames: e => gC(BL, e),
        getDayNames: e => gC(jL, e),
        getQuarterNames: e => VL,
        getPeriodNames: e => HL
    };
var $L = /[\u200E\u200F]/g,
    GL = /[\u202F]/g,
    Um = {},
    WL = e => {
        let t = `${Ie.locale()}/${JSON.stringify(e)}`;
        return Um[t] || (Um[t] = new Intl.DateTimeFormat(Ie.locale(), e).format), Um[t]
    };

function Bm(e, t) {
    return WL(t)(e).replace($L, "").replace(GL, " ")
}
var io = e => t => {
        if (!e.timeZoneName) {
            let n = t.getFullYear(),
                r = String(n).length < 3,
                i = r ? n + 400 : n,
                s = new Date(Date.UTC(i, t.getMonth(), t.getDate(), t.getHours(), t.getMinutes(), t.getSeconds(), t.getMilliseconds()));
            r && s.setFullYear(n);
            let a = Te({
                timeZone: "UTC"
            }, e);
            return Bm(s, a)
        }
        return Bm(t, e)
    },
    jm = e => new Intl.NumberFormat(Ie.locale()).format(e),
    zL = (() => {
        let e = {};
        return t => {
            if (!(t in e)) {
                if (jm(0) === "0") return e[t] = !1, !1;
                e[t] = {};
                for (let n = 0; n < 10; ++n) e[t][jm(n)] = n
            }
            return e[t]
        }
    })(),
    Lu = e => {
        let t = zL(Ie.locale());
        return t ? e.split("").map(n => n in t ? String(t[n]) : n).join("") : e
    },
    EC = e => e.replace(/(\D)0+(\d)/g, "$1$2"),
    qL = (e, t) => EC(e) === EC(t),
    Hm = e => e.replace("d\u2019", "de "),
    Vm = {
        day: {
            day: "numeric"
        },
        date: {
            year: "numeric",
            month: "long",
            day: "numeric"
        },
        dayofweek: {
            weekday: "long"
        },
        longdate: {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric"
        },
        longdatelongtime: {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "numeric",
            second: "numeric"
        },
        longtime: {
            hour: "numeric",
            minute: "numeric",
            second: "numeric"
        },
        month: {
            month: "long"
        },
        monthandday: {
            month: "long",
            day: "numeric"
        },
        monthandyear: {
            year: "numeric",
            month: "long"
        },
        shortdate: {},
        shorttime: {
            hour: "numeric",
            minute: "numeric"
        },
        shortyear: {
            year: "2-digit"
        },
        year: {
            year: "numeric"
        }
    };
Object.defineProperty(Vm, "shortdateshorttime", {
    get() {
        let e = Intl.DateTimeFormat(Ie.locale()).resolvedOptions();
        return {
            year: e.year,
            month: e.month,
            day: e.day,
            hour: "numeric",
            minute: "numeric"
        }
    }
});
var KL = e => typeof e == "string" && Vm[e.toLowerCase()],
    yC = {
        standalone(e, t) {
            let n = new Date(1999, e, 13, 1);
            return io({
                month: t
            })(n)
        },
        format(e, t) {
            let n = new Date(0, e, 13, 1),
                o = Hm(io({
                    day: "numeric",
                    month: t
                })(n)).split(" ").filter(i => !i.includes("13"));
            return o.length === 1 ? o[0] : o.length === 2 ? o[0].length > o[1].length ? o[0] : o[1] : yC.standalone(e, t)
        }
    },
    vC = {
        engine: () => "intl",
        getMonthNames(e, t) {
            let n = {
                wide: "long",
                abbreviated: "short",
                narrow: "narrow"
            }[e || "wide"];
            return t = t === "format" ? t : "standalone", Array.from({
                length: 12
            }, (r, o) => yC[t](o, n))
        },
        getDayNames: e => (t => Array.from({
            length: 7
        }, (n, r) => io({
            weekday: t
        })(new Date(0, 0, r))))({
            wide: "long",
            abbreviated: "short",
            short: "narrow",
            narrow: "narrow"
        }[e || "wide"]),
        getPeriodNames() {
            let e = io({
                hour: "numeric",
                hour12: !0
            });
            return [1, 13].map(t => {
                let n = jm(1),
                    r = e(new Date(0, 0, 1, t)).split(n);
                return r.length !== 2 ? "" : (r[0].length > r[1].length ? r[0] : r[1]).trim()
            })
        },
        format(e, t) {
            if (!e) return;
            if (!t) return e;
            typeof t != "function" && !t.formatter && (t = t.type ? ? t);
            let n = KL(t);
            if (n) return io(n)(e);
            let r = typeof t;
            return t.formatter || r === "function" || r === "string" ? this.callBase.apply(this, [e, t]) : io(t)(e)
        },
        parse(e, t) {
            let n;
            return t && !t.parser && typeof e == "string" && (e = Hm(e), n = r => Hm(this.format(r, t))), this.callBase(e, n ? ? t)
        },
        _parseDateBySimpleFormat(e, t) {
            e = Lu(e);
            let n = this.getFormatParts(t),
                r = e.split(/\D+/).filter(s => s.length > 0);
            if (n.length !== r.length) return;
            let o = this._generateDateArgs(n, r),
                i = s => {
                    let a = ((c, l) => {
                        let u = l ? 12 : 0;
                        return new Date(c.year, c.month, c.day, (c.hours + u) % 24, c.minutes, c.seconds)
                    })(o, s);
                    if (qL(Lu(this.format(a, t)), e)) return a
                };
            return i(!1) ? ? i(!0)
        },
        _generateDateArgs(e, t) {
            let n = new Date,
                r = {
                    year: n.getFullYear(),
                    month: n.getMonth(),
                    day: n.getDate(),
                    hours: 0,
                    minutes: 0,
                    seconds: 0
                };
            return e.forEach((o, i) => {
                let s = t[i],
                    a = parseInt(s, 10);
                o === "month" && (a -= 1), r[o] = a
            }), r
        },
        formatUsesMonthName(e) {
            return typeof e == "object" && !(e.type || e.format) ? e.month === "long" : this.callBase.apply(this, [e])
        },
        formatUsesDayName(e) {
            return typeof e == "object" && !(e.type || e.format) ? e.weekday === "long" : this.callBase.apply(this, [e])
        },
        getTimeSeparator: () => Lu(Bm(new Date(2001, 1, 1, 11, 11), {
            hour: "numeric",
            minute: "numeric",
            hour12: !1
        })).replace(/\d/g, ""),
        getFormatParts(e) {
            if (typeof e == "string") return this.callBase(e);
            let t = Te({}, Vm[e.toLowerCase()]),
                n = new Date(2001, 2, 4, 5, 6, 7),
                r = io(t)(n);
            return r = Lu(r), [{
                name: "year",
                value: 1
            }, {
                name: "month",
                value: 3
            }, {
                name: "day",
                value: 4
            }, {
                name: "hours",
                value: 5
            }, {
                name: "minutes",
                value: 6
            }, {
                name: "seconds",
                value: 7
            }].map(o => ({
                name: o.name,
                index: r.indexOf(`${o.value}`)
            })).filter(o => o.index > -1).sort((o, i) => o.index - i.index).map(o => o.name)
        }
    };
var DC = {
        rtlEnabled: !1,
        defaultCurrency: "USD",
        defaultUseCurrencyAccountingStyle: !0,
        oDataFilterToLower: !0,
        serverDecimalSeparator: ".",
        decimalSeparator: ".",
        thousandsSeparator: ",",
        forceIsoDateParsing: !0,
        wrapActionsBeforeExecute: !0,
        useLegacyStoreResult: !1,
        useJQuery: void 0,
        editorStylingMode: void 0,
        useLegacyVisibleIndex: !1,
        versionAssertions: [],
        copyStylesToShadowDom: !0,
        floatingActionButtonConfig: {
            icon: "add",
            closeIcon: "close",
            label: "",
            position: {
                at: "right bottom",
                my: "right bottom",
                offset: {
                    x: -16,
                    y: -16
                }
            },
            maxSpeedDialActionCount: 5,
            shading: !1,
            direction: "auto"
        },
        optionsParser: e => {
            e.trim().charAt(0) !== "{" && (e = `{${e}}`);
            try {
                return JSON.parse(e)
            } catch (t) {
                try {
                    return JSON.parse(YL(e))
                } catch (n) {
                    throw It.Error("E3018", t, e)
                }
            }
        }
    },
    YL = e => e.replace(/'/g, '"').replace(/,\s*([\]}])/g, "$1").replace(/([{,])\s*([^":\s]+)\s*:/g, '$1"$2":'),
    JL = ["decimalSeparator", "thousandsSeparator"],
    _C = function() {
        if (!arguments.length) return DC;
        let e = arguments.length <= 0 ? void 0 : arguments[0];
        JL.forEach(t => {
            if (e[t]) {
                let n = `Now, the ${t} is selected based on the specified locale.`;
                It.log("W0003", "config", t, "19.2", n)
            }
        }), Te(DC, e)
    };
typeof DevExpress < "u" && DevExpress.config && _C(DevExpress.config);
var xC = _C;
var $m = xC;
var CC = fi.inherit({
    ctor: function(e) {
        e && (e = String(e)), this._value = this._normalize(e || this._generate())
    },
    _normalize: function(e) {
        for (e = e.replace(/[^a-f0-9]/gi, "").toLowerCase(); e.length < 32;) e += "0";
        return [e.substr(0, 8), e.substr(8, 4), e.substr(12, 4), e.substr(16, 4), e.substr(20, 12)].join("-")
    },
    _generate: function() {
        let e = "";
        for (let t = 0; t < 32; t++) e += Math.round(15 * Math.random()).toString(16);
        return e
    },
    toString: function() {
        return this._value
    },
    valueOf: function() {
        return this._value
    },
    toJSON: function() {
        return this._value
    }
});
var Gm = CC;
var IC = {},
    ku;

function QL(e, t) {
    IC[e] = t
}

function Wm(e) {
    if (dn(e)) {
        if (ku = IC[e], !ku) throw It.Error("E0020", e)
    } else ku = e
}

function ZL() {
    return ku
}
var Tt = $m;
var TC = {
    af: "\xA4#,##0.00;(\xA4#,##0.00)",
    "af-NA": "\xA4#,##0.00;(\xA4#,##0.00)",
    agq: "#,##0.00\xA4",
    ak: "\xA4#,##0.00",
    am: "\xA4#,##0.00;(\xA4#,##0.00)",
    ar: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-AE": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-BH": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-DJ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-DZ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-EG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-EH": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-ER": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-IL": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-IQ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-JO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-KM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-KW": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-LB": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-LY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-MA": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-MR": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-OM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-PS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-QA": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-SA": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-SD": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-SO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-SS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-SY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-TD": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-TN": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ar-YE": "\xA4#,##0.00;(\xA4#,##0.00)",
    as: "\xA4\xA0#,##,##0.00",
    asa: "#,##0.00\xA0\xA4",
    ast: "#,##0.00\xA0\xA4",
    az: "#,##0.00\xA0\xA4",
    "az-Cyrl": "#,##0.00\xA0\xA4",
    "az-Latn": "#,##0.00\xA0\xA4",
    bas: "#,##0.00\xA0\xA4",
    be: "#,##0.00\xA0\xA4",
    "be-tarask": "#,##0.00\xA0\xA4",
    bem: "\xA4#,##0.00;(\xA4#,##0.00)",
    bez: "#,##0.00\xA4",
    bg: "0.00\xA0\xA4;(0.00\xA0\xA4)",
    bm: "\xA4#,##0.00;(\xA4#,##0.00)",
    bn: "#,##,##0.00\xA4;(#,##,##0.00\xA4)",
    "bn-IN": "#,##,##0.00\xA4;(#,##,##0.00\xA4)",
    bo: "\xA4\xA0#,##0.00",
    "bo-IN": "\xA4\xA0#,##0.00",
    br: "#,##0.00\xA0\xA4",
    brx: "\xA4\xA0#,##,##0.00",
    bs: "#,##0.00\xA0\xA4",
    "bs-Cyrl": "#,##0.00\xA0\xA4",
    "bs-Latn": "#,##0.00\xA0\xA4",
    ca: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "ca-AD": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "ca-ES-valencia": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "ca-FR": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "ca-IT": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    ccp: "#,##,##0.00\xA4;(#,##,##0.00\xA4)",
    "ccp-IN": "#,##,##0.00\xA4;(#,##,##0.00\xA4)",
    ce: "#,##0.00\xA0\xA4",
    ceb: "\xA4#,##0.00;(\xA4#,##0.00)",
    cgg: "\xA4#,##0.00",
    chr: "\xA4#,##0.00;(\xA4#,##0.00)",
    ckb: "\xA4\xA0#,##0.00",
    "ckb-IR": "\xA4\xA0#,##0.00",
    cs: "#,##0.00\xA0\xA4",
    cy: "\xA4#,##0.00;(\xA4#,##0.00)",
    da: "#,##0.00\xA0\xA4",
    "da-GL": "#,##0.00\xA0\xA4",
    dav: "\xA4#,##0.00;(\xA4#,##0.00)",
    de: "#,##0.00\xA0\xA4",
    "de-AT": "#,##0.00\xA0\xA4",
    "de-BE": "#,##0.00\xA0\xA4",
    "de-CH": "#,##0.00\xA0\xA4",
    "de-IT": "#,##0.00\xA0\xA4",
    "de-LI": "#,##0.00\xA0\xA4",
    "de-LU": "#,##0.00\xA0\xA4",
    dje: "#,##0.00\xA4",
    doi: "\xA4#,##0.00",
    dsb: "#,##0.00\xA0\xA4",
    dua: "#,##0.00\xA0\xA4",
    dyo: "#,##0.00\xA0\xA4",
    dz: "\xA4#,##,##0.00",
    ebu: "\xA4#,##0.00;(\xA4#,##0.00)",
    ee: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ee-TG": "\xA4#,##0.00;(\xA4#,##0.00)",
    el: "#,##0.00\xA0\xA4",
    "el-CY": "#,##0.00\xA0\xA4",
    en: "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-001": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-150": "#,##0.00\xA0\xA4",
    "en-AE": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-AG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-AI": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-AS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-AT": "\xA4\xA0#,##0.00",
    "en-AU": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-BB": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-BE": "#,##0.00\xA0\xA4",
    "en-BI": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-BM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-BS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-BW": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-BZ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-CA": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-CC": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-CH": "\xA4\xA0#,##0.00;\xA4-#,##0.00",
    "en-CK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-CM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-CX": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-CY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-DE": "#,##0.00\xA0\xA4",
    "en-DG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-DK": "#,##0.00\xA0\xA4",
    "en-DM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-ER": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-FI": "#,##0.00\xA0\xA4",
    "en-FJ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-FK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-FM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GB": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GD": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GH": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GI": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GU": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-GY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-HK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-IE": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-IL": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-IM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-IN": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-IO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-JE": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-JM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-KE": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-KI": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-KN": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-KY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-LC": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-LR": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-LS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MH": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MP": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MT": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MU": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MV": "\xA4\xA0#,##0.00",
    "en-MW": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-MY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-NA": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-NF": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-NG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-NL": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "en-NR": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-NU": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-NZ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-PG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-PH": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-PK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-PN": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-PR": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-PW": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-RW": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SB": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SC": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SD": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SE": "#,##0.00\xA0\xA4",
    "en-SG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SH": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SI": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "en-SL": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SX": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-SZ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-TC": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-TK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-TO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-TT": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-TV": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-TZ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-UG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-UM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-VC": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-VG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-VI": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-VU": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-WS": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-ZA": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-ZM": "\xA4#,##0.00;(\xA4#,##0.00)",
    "en-ZW": "\xA4#,##0.00;(\xA4#,##0.00)",
    eo: "\xA4\xA0#,##0.00",
    es: "#,##0.00\xA0\xA4",
    "es-419": "\xA4#,##0.00",
    "es-AR": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "es-BO": "\xA4#,##0.00",
    "es-BR": "\xA4#,##0.00",
    "es-BZ": "\xA4#,##0.00",
    "es-CL": "\xA4#,##0.00",
    "es-CO": "\xA4#,##0.00",
    "es-CR": "\xA4#,##0.00",
    "es-CU": "\xA4#,##0.00",
    "es-DO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "es-EA": "#,##0.00\xA0\xA4",
    "es-EC": "\xA4#,##0.00",
    "es-GQ": "#,##0.00\xA0\xA4",
    "es-GT": "\xA4#,##0.00",
    "es-HN": "\xA4#,##0.00",
    "es-IC": "#,##0.00\xA0\xA4",
    "es-MX": "\xA4#,##0.00",
    "es-NI": "\xA4#,##0.00",
    "es-PA": "\xA4#,##0.00",
    "es-PE": "\xA4#,##0.00",
    "es-PH": "#,##0.00\xA0\xA4",
    "es-PR": "\xA4#,##0.00",
    "es-PY": "\xA4#,##0.00",
    "es-SV": "\xA4#,##0.00",
    "es-US": "\xA4#,##0.00",
    "es-UY": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "es-VE": "\xA4#,##0.00",
    et: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    eu: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    ewo: "#,##0.00\xA0\xA4",
    fa: "\u200E\xA4\xA0#,##0.00;\u200E(\xA4\xA0#,##0.00)",
    "fa-AF": "\xA4\xA0#,##0.00;\u200E(\xA4\xA0#,##0.00)",
    ff: "#,##0.00\xA0\xA4",
    "ff-Adlm": "\xA4\xA0#,##0.00",
    "ff-Adlm-BF": "\xA4\xA0#,##0.00",
    "ff-Adlm-CM": "\xA4\xA0#,##0.00",
    "ff-Adlm-GH": "\xA4\xA0#,##0.00",
    "ff-Adlm-GM": "\xA4\xA0#,##0.00",
    "ff-Adlm-GW": "\xA4\xA0#,##0.00",
    "ff-Adlm-LR": "\xA4\xA0#,##0.00",
    "ff-Adlm-MR": "\xA4\xA0#,##0.00",
    "ff-Adlm-NE": "\xA4\xA0#,##0.00",
    "ff-Adlm-NG": "\xA4\xA0#,##0.00",
    "ff-Adlm-SL": "\xA4\xA0#,##0.00",
    "ff-Adlm-SN": "\xA4\xA0#,##0.00",
    "ff-Latn": "#,##0.00\xA0\xA4",
    "ff-Latn-BF": "#,##0.00\xA0\xA4",
    "ff-Latn-CM": "#,##0.00\xA0\xA4",
    "ff-Latn-GH": "#,##0.00\xA0\xA4",
    "ff-Latn-GM": "#,##0.00\xA0\xA4",
    "ff-Latn-GN": "#,##0.00\xA0\xA4",
    "ff-Latn-GW": "#,##0.00\xA0\xA4",
    "ff-Latn-LR": "#,##0.00\xA0\xA4",
    "ff-Latn-MR": "#,##0.00\xA0\xA4",
    "ff-Latn-NE": "#,##0.00\xA0\xA4",
    "ff-Latn-NG": "#,##0.00\xA0\xA4",
    "ff-Latn-SL": "#,##0.00\xA0\xA4",
    fi: "#,##0.00\xA0\xA4",
    fil: "\xA4#,##0.00;(\xA4#,##0.00)",
    fo: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fo-DK": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    fr: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-BE": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-BF": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-BI": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-BJ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-BL": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CA": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CD": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CF": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CG": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CH": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CI": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-CM": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-DJ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-DZ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-GA": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-GF": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-GN": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-GP": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-GQ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-HT": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-KM": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-LU": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MA": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MC": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MF": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MG": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-ML": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MQ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MR": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-MU": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-NC": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-NE": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-PF": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-PM": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-RE": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-RW": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-SC": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-SN": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-SY": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-TD": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-TG": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-TN": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-VU": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-WF": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "fr-YT": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    fur: "\xA4\xA0#,##0.00",
    fy: "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    ga: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ga-GB": "\xA4#,##0.00;(\xA4#,##0.00)",
    gd: "\xA4#,##0.00;(\xA4#,##0.00)",
    gl: "#,##0.00\xA0\xA4",
    gsw: "#,##0.00\xA0\xA4",
    "gsw-FR": "#,##0.00\xA0\xA4",
    "gsw-LI": "#,##0.00\xA0\xA4",
    gu: "\xA4#,##,##0.00;(\xA4#,##,##0.00)",
    guz: "\xA4#,##0.00;(\xA4#,##0.00)",
    gv: "\xA4#,##0.00",
    ha: "\xA4\xA0#,##0.00",
    "ha-GH": "\xA4\xA0#,##0.00",
    "ha-NE": "\xA4\xA0#,##0.00",
    haw: "\xA4#,##0.00;(\xA4#,##0.00)",
    he: "#,##0.00\xA0\xA4",
    hi: "\xA4#,##,##0.00",
    "hi-Latn": "\xA4#,##,##0.00",
    hr: "#,##0.00\xA0\xA4",
    "hr-BA": "#,##0.00\xA0\xA4",
    hsb: "#,##0.00\xA0\xA4",
    hu: "#,##0.00\xA0\xA4",
    hy: "#,##0.00\xA0\xA4",
    ia: "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    id: "\xA4#,##0.00",
    ig: "\xA4#,##0.00;(\xA4#,##0.00)",
    ii: "\xA4\xA0#,##0.00",
    is: "#,##0.00\xA0\xA4",
    it: "#,##0.00\xA0\xA4",
    "it-CH": "#,##0.00\xA0\xA4",
    "it-SM": "#,##0.00\xA0\xA4",
    "it-VA": "#,##0.00\xA0\xA4",
    ja: "\xA4#,##0.00;(\xA4#,##0.00)",
    jgo: "\xA4\xA0#,##0.00",
    jmc: "\xA4#,##0.00",
    jv: "\xA4\xA0#,##0.00",
    ka: "#,##0.00\xA0\xA4",
    kab: "#,##0.00\xA4",
    kam: "\xA4#,##0.00;(\xA4#,##0.00)",
    kde: "\xA4#,##0.00;(\xA4#,##0.00)",
    kea: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    kgp: "\xA4\xA0#,##0.00",
    khq: "#,##0.00\xA4",
    ki: "\xA4#,##0.00;(\xA4#,##0.00)",
    kk: "#,##0.00\xA0\xA4",
    kkj: "\xA4\xA0#,##0.00",
    kl: "\xA4#,##0.00;\xA4-#,##0.00",
    kln: "\xA4#,##0.00;(\xA4#,##0.00)",
    km: "#,##0.00\xA4;(#,##0.00\xA4)",
    kn: "\xA4#,##0.00;(\xA4#,##0.00)",
    ko: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ko-KP": "\xA4#,##0.00;(\xA4#,##0.00)",
    kok: "\xA4#,##0.00;(\xA4#,##0.00)",
    ks: "\xA4#,##0.00",
    "ks-Arab": "\xA4#,##0.00",
    "ks-Deva": "\xA4\xA0#,##0.00",
    ksb: "#,##0.00\xA4",
    ksf: "#,##0.00\xA0\xA4",
    ksh: "#,##0.00\xA0\xA4",
    ku: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    kw: "\xA4#,##0.00",
    ky: "#,##0.00\xA0\xA4",
    lag: "\xA4\xA0#,##0.00",
    lb: "#,##0.00\xA0\xA4",
    lg: "#,##0.00\xA4",
    lkt: "\xA4\xA0#,##0.00",
    ln: "#,##0.00\xA0\xA4",
    "ln-AO": "#,##0.00\xA0\xA4",
    "ln-CF": "#,##0.00\xA0\xA4",
    "ln-CG": "#,##0.00\xA0\xA4",
    lo: "\xA4#,##0.00;\xA4-#,##0.00",
    lrc: "\xA4\xA0#,##0.00",
    "lrc-IQ": "\xA4\xA0#,##0.00",
    lt: "#,##0.00\xA0\xA4",
    lu: "#,##0.00\xA4",
    luo: "#,##0.00\xA4",
    luy: "\xA4#,##0.00;\xA4-\xA0#,##0.00",
    lv: "#,##0.00\xA0\xA4",
    mai: "\xA4\xA0#,##0.00",
    mas: "\xA4#,##0.00;(\xA4#,##0.00)",
    "mas-TZ": "\xA4#,##0.00;(\xA4#,##0.00)",
    mer: "\xA4#,##0.00;(\xA4#,##0.00)",
    mfe: "\xA4\xA0#,##0.00",
    mg: "\xA4#,##0.00",
    mgh: "\xA4\xA0#,##0.00",
    mgo: "\xA4\xA0#,##0.00",
    mi: "\xA4\xA0#,##0.00",
    mk: "#,##0.00\xA0\xA4",
    ml: "\xA4#,##0.00;(\xA4#,##0.00)",
    mn: "\xA4\xA0#,##0.00",
    mni: "\xA4\xA0#,##0.00",
    "mni-Beng": "\xA4\xA0#,##0.00",
    mr: "\xA4#,##0.00;(\xA4#,##0.00)",
    ms: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ms-BN": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ms-ID": "\xA4#,##0.00",
    "ms-SG": "\xA4#,##0.00;(\xA4#,##0.00)",
    mt: "\xA4#,##0.00",
    mua: "\xA4#,##0.00;(\xA4#,##0.00)",
    my: "\xA4\xA0#,##0.00",
    mzn: "\xA4\xA0#,##0.00",
    naq: "\xA4#,##0.00",
    nb: "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nb-SJ": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    nd: "\xA4#,##0.00;(\xA4#,##0.00)",
    nds: "\xA4\xA0#,##0.00",
    "nds-NL": "\xA4\xA0#,##0.00",
    ne: "\xA4\xA0#,##,##0.00",
    "ne-IN": "\xA4\xA0#,##,##0.00",
    nl: "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nl-AW": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nl-BE": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nl-BQ": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nl-CW": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nl-SR": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    "nl-SX": "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    nmg: "#,##0.00\xA0\xA4",
    nn: "#,##0.00\xA0\xA4",
    nnh: "\xA4\xA0#,##0.00",
    no: "\xA4\xA0#,##0.00;(\xA4\xA0#,##0.00)",
    nus: "\xA4#,##0.00;(\xA4#,##0.00)",
    nyn: "\xA4#,##0.00",
    om: "\xA4#,##0.00",
    "om-KE": "\xA4#,##0.00",
    or: "\xA4#,##0.00;(\xA4#,##0.00)",
    os: "\xA4\xA0#,##0.00",
    "os-RU": "\xA4\xA0#,##0.00",
    pa: "\xA4\xA0#,##0.00",
    "pa-Arab": "\xA4\xA0#,##0.00",
    "pa-Guru": "\xA4\xA0#,##0.00",
    pcm: "\xA4#,##0.00",
    pl: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    ps: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ps-PK": "\xA4#,##0.00;(\xA4#,##0.00)",
    pt: "\xA4\xA0#,##0.00",
    "pt-AO": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-CH": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-CV": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-GQ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-GW": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-LU": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-MO": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-MZ": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-PT": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-ST": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "pt-TL": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    qu: "\xA4\xA0#,##0.00",
    "qu-BO": "\xA4\xA0#,##0.00",
    "qu-EC": "\xA4\xA0#,##0.00",
    rm: "#,##0.00\xA0\xA4",
    rn: "#,##0.00\xA4",
    ro: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "ro-MD": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    rof: "\xA4#,##0.00",
    ru: "#,##0.00\xA0\xA4",
    "ru-BY": "#,##0.00\xA0\xA4",
    "ru-KG": "#,##0.00\xA0\xA4",
    "ru-KZ": "#,##0.00\xA0\xA4",
    "ru-MD": "#,##0.00\xA0\xA4",
    "ru-UA": "#,##0.00\xA0\xA4",
    rw: "\xA4\xA0#,##0.00",
    rwk: "#,##0.00\xA4",
    sa: "\xA4\xA0#,##0.00",
    sah: "#,##0.00\xA0\xA4",
    saq: "\xA4#,##0.00;(\xA4#,##0.00)",
    sat: "\xA4\xA0#,##0.00",
    "sat-Olck": "\xA4\xA0#,##0.00",
    sbp: "#,##0.00\xA4",
    sc: "#,##0.00\xA0\xA4",
    sd: "\xA4\xA0#,##0.00",
    "sd-Arab": "\xA4\xA0#,##0.00",
    "sd-Deva": "\xA4\xA0#,##0.00",
    se: "#,##0.00\xA0\xA4",
    "se-FI": "#,##0.00\xA0\xA4",
    "se-SE": "#,##0.00\xA0\xA4",
    seh: "#,##0.00\xA4",
    ses: "#,##0.00\xA4",
    sg: "\xA4#,##0.00;\xA4-#,##0.00",
    shi: "#,##0.00\xA4",
    "shi-Latn": "#,##0.00\xA4",
    "shi-Tfng": "#,##0.00\xA4",
    si: "\xA4#,##0.00;(\xA4#,##0.00)",
    sk: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    sl: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    smn: "#,##0.00\xA0\xA4",
    sn: "\xA4#,##0.00;(\xA4#,##0.00)",
    so: "\xA4#,##0.00;(\xA4#,##0.00)",
    "so-DJ": "\xA4#,##0.00;(\xA4#,##0.00)",
    "so-ET": "\xA4#,##0.00;(\xA4#,##0.00)",
    "so-KE": "\xA4#,##0.00;(\xA4#,##0.00)",
    sq: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sq-MK": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sq-XK": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    sr: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Cyrl": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Cyrl-BA": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Cyrl-ME": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Cyrl-XK": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Latn": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Latn-BA": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Latn-ME": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    "sr-Latn-XK": "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    su: "\xA4#,##0.00",
    "su-Latn": "\xA4#,##0.00",
    sv: "#,##0.00\xA0\xA4",
    "sv-AX": "#,##0.00\xA0\xA4",
    "sv-FI": "#,##0.00\xA0\xA4",
    sw: "\xA4\xA0#,##0.00",
    "sw-CD": "\xA4\xA0#,##0.00",
    "sw-KE": "\xA4\xA0#,##0.00",
    "sw-UG": "\xA4\xA0#,##0.00",
    ta: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ta-LK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ta-MY": "\xA4#,##0.00;(\xA4#,##0.00)",
    "ta-SG": "\xA4#,##0.00;(\xA4#,##0.00)",
    te: "\xA4#,##0.00;(\xA4#,##0.00)",
    teo: "\xA4#,##0.00;(\xA4#,##0.00)",
    "teo-KE": "\xA4#,##0.00;(\xA4#,##0.00)",
    tg: "#,##0.00\xA0\xA4",
    th: "\xA4#,##0.00;(\xA4#,##0.00)",
    ti: "\xA4#,##0.00",
    "ti-ER": "\xA4#,##0.00",
    tk: "#,##0.00\xA0\xA4",
    to: "\xA4\xA0#,##0.00",
    tr: "\xA4#,##0.00;(\xA4#,##0.00)",
    "tr-CY": "\xA4#,##0.00;(\xA4#,##0.00)",
    tt: "#,##0.00\xA0\xA4",
    twq: "#,##0.00\xA4",
    tzm: "#,##0.00\xA0\xA4",
    ug: "\xA4#,##0.00;(\xA4#,##0.00)",
    uk: "#,##0.00\xA0\xA4",
    und: "\xA4\xA0#,##0.00",
    ur: "\xA4#,##0.00;(\xA4#,##0.00)",
    "ur-IN": "\xA4#,##0.00;(\xA4#,##0.00)",
    uz: "#,##0.00\xA0\xA4",
    "uz-Arab": "\xA4\xA0#,##0.00",
    "uz-Cyrl": "#,##0.00\xA0\xA4",
    "uz-Latn": "#,##0.00\xA0\xA4",
    vai: "\xA4#,##0.00;(\xA4#,##0.00)",
    "vai-Latn": "\xA4#,##0.00;(\xA4#,##0.00)",
    "vai-Vaii": "\xA4#,##0.00;(\xA4#,##0.00)",
    vi: "#,##0.00\xA0\xA4",
    vun: "\xA4#,##0.00",
    wae: "\xA4\xA0#,##0.00",
    wo: "\xA4\xA0#,##0.00",
    xh: "\xA4#,##0.00",
    xog: "#,##0.00\xA0\xA4",
    yav: "#,##0.00\xA0\xA4;(#,##0.00\xA0\xA4)",
    yi: "\xA4\xA0#,##0.00",
    yo: "\xA4#,##0.00;(\xA4#,##0.00)",
    "yo-BJ": "\xA4#,##0.00;(\xA4#,##0.00)",
    yrl: "\xA4\xA0#,##0.00",
    "yrl-CO": "\xA4\xA0#,##0.00",
    "yrl-VE": "\xA4\xA0#,##0.00",
    yue: "\xA4#,##0.00;(\xA4#,##0.00)",
    "yue-Hans": "\xA4#,##0.00;(\xA4#,##0.00)",
    "yue-Hant": "\xA4#,##0.00;(\xA4#,##0.00)",
    zgh: "#,##0.00\xA4",
    zh: "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hans": "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hans-HK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hans-MO": "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hans-SG": "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hant": "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hant-HK": "\xA4#,##0.00;(\xA4#,##0.00)",
    "zh-Hant-MO": "\xA4#,##0.00;(\xA4#,##0.00)",
    zu: "\xA4#,##0.00;(\xA4#,##0.00)"
};
var SC = (e, t) => {
    if (!t) return;
    let n = e;
    if (typeof e == "string") {
        n = "";
        for (let i = 0; i < e.length; i += 1) e[i] !== "$" && (n += "\\"), n += e[i]
    }
    let r = {
            ".00": "{0}",
            "'": "\\'",
            "\\(": "\\(",
            "\\)": "\\)",
            " ": "\\ ",
            '"': "&quot;",
            "\\\xA4": n
        },
        o = t.split(";");
    for (let i = 0; i < o.length; i += 1)
        for (let s in r) Object.prototype.hasOwnProperty.call(r, s) && (o[i] = o[i].replace(new RegExp(s, "g"), r[s]));
    return o.length === 2 ? `${o[0]}_);${o[1]}` : o[0]
};
var XL = ["standard", "accounting"];
var ek = /([^\s0]+)?(\s*)0*[.,]*0*(\s*)([^\s0]+)?/,
    zm = {},
    bC = e => {
        let t = `${Ie.locale()}/${JSON.stringify(e)}`;
        return zm[t] || (zm[t] = new Intl.NumberFormat(Ie.locale(), e).format), zm[t]
    },
    tk = e => new Intl.NumberFormat(Ie.locale(), {
        style: "currency",
        currency: e
    }),
    wC = {
        engine: () => "intl",
        _formatNumberCore(e, t, n) {
            return t === "exponential" ? this.callBase.apply(this, [e, t, n]) : bC(this._normalizeFormatConfig(t, n, e))(e)
        },
        _normalizeFormatConfig(e, t, n) {
            let r;
            if (e === "decimal") {
                let o = String(n).split(".")[1];
                r = {
                    minimumIntegerDigits: t.precision || void 0,
                    useGrouping: !1,
                    maximumFractionDigits: o ? .length,
                    round: n < 0 ? "ceil" : "floor"
                }
            } else r = this._getPrecisionConfig(t.precision);
            if (e === "percent") r.style = "percent";
            else if (e === "currency") {
                let o = t.useCurrencyAccountingStyle ? ? Tt().defaultUseCurrencyAccountingStyle;
                r.style = "currency", r.currency = t.currency || Tt().defaultCurrency, r.currencySign = XL[+o]
            }
            return r
        },
        _getPrecisionConfig(e) {
            let t;
            return e === null ? t = {
                minimumFractionDigits: 0,
                maximumFractionDigits: 20
            } : t = {
                minimumFractionDigits: e || 0,
                maximumFractionDigits: e || 0
            }, t
        },
        format(e, t) {
            return typeof e != "number" ? e : (t = this._normalizeFormat(t), t.currency === "default" && (t.currency = Tt().defaultCurrency), !t || typeof t != "function" && !t.type && !t.formatter ? bC(t)(e) : this.callBase.apply(this, [e, t]))
        },
        _getCurrencySymbolInfo(e) {
            let t = tk(e);
            return this._extractCurrencySymbolInfo(t.format(0))
        },
        _extractCurrencySymbolInfo(e) {
            let t = ek.exec(e) || [],
                n = t[1] ? "before" : "after",
                r = t[1] || t[4] || "",
                o = t[2] || t[3] || "";
            return {
                position: n,
                symbol: r,
                delimiter: o
            }
        },
        getCurrencySymbol(e) {
            return e || (e = Tt().defaultCurrency), {
                symbol: this._getCurrencySymbolInfo(e).symbol
            }
        },
        getOpenXmlCurrencyFormat(e) {
            let t = e || Tt().defaultCurrency,
                n = this._getCurrencySymbolInfo(t).symbol,
                r = Ie.getValueByClosestLocale(o => TC[o]);
            return SC(n, r)
        }
    };
var MC = function(e) {
        return e === 0 ? 0 : e / Math.abs(e)
    },
    NC = function(e, t, n) {
        let r = !t && t !== 0,
            o = !n && n !== 0;
        return r && (t = o ? e : Math.min(e, n)), o && (n = r ? e : Math.max(e, t)), Math.min(Math.max(e, t), n)
    },
    EJ = function(e, t, n) {
        return e >= t && e <= n
    };

function nk(e) {
    let [t, n] = e.toExponential().split("e");
    return Math.abs(parseInt(n, 10))
}

function rk(e) {
    let t = e.toExponential().split("e"),
        n = parseFloat(t[0]);
    return {
        exponent: parseInt(t[1], 10),
        mantissa: n
    }
}

function Fu(e, t) {
    let n = rk(e);
    return parseFloat(`${n.mantissa}e${n.exponent+t}`)
}

function yJ(e, t) {
    let n = Math.abs(e),
        r = n > 1 ? 10 : 0,
        i = ik(t ? ? 0) + 2 > 7 ? 15 : 7,
        [s, a] = e.toString().split("."),
        c = e;
    if (ta(e)) return ok(e, i);
    if (!a) return e;
    if (ta(t)) {
        let m = s.length + nk(t);
        return parseFloat(c.toPrecision(m))
    }
    let u = n - Math.floor(n),
        d = r + u,
        f = parseFloat(d.toPrecision(i)).toString().split(".");
    return f[0] === r.toString() ? parseFloat(`${s}.${f[1]}`) : parseFloat(c.toPrecision(i))
}

function ok(e, t) {
    let n = e.toExponential(),
        [r, o] = n.split("e");
    return r.includes(".") ? parseFloat(e.toPrecision(t)) : parseFloat(n)
}

function ik(e) {
    let t = e.toString();
    if (!t.includes(".")) return 0;
    let [n, r] = t.split("."), o = r.indexOf("e");
    return o >= 0 ? o : r.length
}

function AC(e, t) {
    if (e < 0 && t % 2 !== 1) return NaN;
    let n = Math.abs(e) ** (1 / t);
    return t % 2 === 1 && e < 0 ? -n : n
}

function vJ(e, t, n, r) {
    if (Math.abs(e) < 1e-8) {
        if (e = t, t = n, n = r, Math.abs(e) < 1e-8) return e = t, t = n, Math.abs(e) < 1e-8 ? [] : [-t / e];
        let c = t * t - 4 * e * n;
        return Math.abs(c) < 1e-8 ? [-t / (2 * e)] : c > 0 ? [(-t + Math.sqrt(c)) / (2 * e), (-t - Math.sqrt(c)) / (2 * e)] : []
    }
    let o = (3 * e * n - t * t) / (3 * e * e),
        i = (2 * t * t * t - 9 * e * t * n + 27 * e * e * r) / (27 * e * e * e),
        s, a;
    if (Math.abs(o) < 1e-8) s = [AC(-i, 3)];
    else if (Math.abs(i) < 1e-8) s = [0].concat(o < 0 ? [Math.sqrt(-o), -Math.sqrt(-o)] : []);
    else {
        let c = i * i / 4 + o * o * o / 27;
        if (Math.abs(c) < 1e-8) s = [-1.5 * i / o, 3 * i / o];
        else if (c > 0) a = AC(-i / 2 - Math.sqrt(c), 3), s = [a - o / (3 * a)];
        else {
            a = 2 * Math.sqrt(-o / 3);
            let l = Math.acos(3 * i / o / a) / 3,
                u = 2 * Math.PI / 3;
            s = [a * Math.cos(l), a * Math.cos(l - u), a * Math.cos(l - 2 * u)]
        }
    }
    for (let c = 0; c < s.length; c++) s[c] -= t / (3 * e);
    return s
}

function DJ(e) {
    return Math.trunc ? Math.trunc(e) : e > 0 ? Math.floor(e) : Math.ceil(e)
}

function _J(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
    return parseFloat(e.toFixed(t))
}

function sk(e) {
    return MC(e) * Math.round(Math.abs(e))
}

function ak(e, t) {
    let n = 10 ** t,
        r = Fu(e, t);
    return sk(r) / n
}

function Uu(e, t) {
    let n = t ? ? 0;
    return (n > 0 ? ak(e, n) : e).toFixed(n)
}
var ck = {
    thousandsSeparator: ",",
    decimalSeparator: "."
};

function lk(e) {
    return e.split(",").slice(1).map(t => {
        let n = 0;
        return t.split("").filter(r => {
            n += +(r === "'");
            let o = r === "#" || r === "0",
                i = n % 2;
            return o && !i
        }).length
    })
}

function uk(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ";",
        n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "'",
        r = [],
        o = "",
        i = "searchingSeparator";
    for (let s = 0; s < e.length; s += 1) {
        let a = e[s];
        i === "searchingSeparator" && a === n ? i = "skippingSeparationInsideEscaping" : i === "skippingSeparationInsideEscaping" && a === n ? i = "searchingSeparator" : i === "searchingSeparator" && a === t && (i = "separating", r.push(o), o = ""), i !== "separating" ? o += a : i = "searchingSeparator"
    }
    return r.push(o), r
}

function dk(e) {
    let t = uk(e);
    return t.length === 1 && t.push(`-${t[0]}`), t
}

function qm(e) {
    return e.toString().split("").reverse().join("")
}

function fk(e) {
    return e.includes("%") && !e.match(/'[^']*%[^']*'/g)
}

function UC(e) {
    return e.replace(/'[^']*'/g, "")
}

function RC(e) {
    if (!e) return 0;
    let t = UC(e);
    return t.length - t.replace(/[#]/g, "").length
}

function OC(e) {
    if (!e) return 0;
    let t = UC(e);
    return t.length - t.replace(/[0]/g, "").length
}

function PC(e, t, n) {
    if (!e) return "";
    for (e.length > n && (e = e.substr(0, n)); e.length > t && e.endsWith("0");) e = e.substr(0, e.length - 1);
    for (; e.length < t;) e += "0";
    return e
}

function pk(e, t, n) {
    if (!t.length) return e;
    let r = [],
        o = 0;
    for (; e;) {
        let i = t[o];
        if (!i) break;
        r.push(e.slice(0, i)), e = e.slice(i), o < t.length - 1 && (o += 1)
    }
    return r.join(n)
}

function LC(e, t) {
    return e.split("'").map((n, r) => {
        let o = r % 2;
        return !n && o ? "'" : o ? n : n.replace(/[,#0]+/, t)
    }).join("")
}

function hk(e) {
    let t = !1;
    for (let n = 0; n < e.length; n += 1)
        if (e[n] === "'" && (t = !t), e[n] === "." && !t) return n;
    return e.length
}

function BC(e, t) {
    return t = t || ck, n => {
        if (typeof n != "number" || isNaN(n)) return "";
        let r = dk(e),
            o = 1 / n === 1 / 0,
            i = n > 0 || o,
            s = r[i ? 0 : 1],
            a = hk(s),
            c = [s.substr(0, a), s.substr(a + 1)],
            l = OC(c[1]),
            u = l + RC(c[1]);
        fk(s) && (n = Fu(n, 2)), i || (n = -n);
        let d = OC(c[0]),
            f = RC(c[0]) || t.unlimitedIntegerDigits ? void 0 : d,
            p = Math.floor(n).toString().length,
            m = NC(u, 0, 15 - p),
            x = lk(c[0]).reverse(),
            D = Uu(n, m < 0 ? 0 : m).split("."),
            I = PC(qm(D[0]), d, f),
            F = PC(D[1], l, u);
        I = pk(I, x, t.thousandsSeparator);
        let me = qm(LC(qm(c[0]), I)),
            ee = u ? LC(c[1], F) : "";
        return me + (ee.match(/\d/) ? t.decimalSeparator : "") + ee
    }
}

function oa(e, t, n) {
    let r = (t ? .01 : 1) * parseFloat(e) || 0;
    return n ? -r : r
}

function kC(e, t, n, r) {
    let o = e,
        i = "",
        s = "",
        a = "";
    do a && (i = s.length === a.length ? "0" : "1", e = r ? i + e : e + i), s = a || t(oa(o, n)), o = r ? `1${o}` : `${o}1`, a = t(oa(o, n)); while (s !== a && (r ? s.length === a.length : s.length <= a.length));
    if (r && a.length > s.length) {
        let c = !t(12345).includes("12345");
        do e = `1${e}`; while (c && oa(e, n) < 1e5)
    }
    return e
}

function FC(e, t, n, r) {
    let o = t(oa(e, n, r)),
        i = e.split("."),
        s = `${i[0]}.3${i[1].slice(1)}`,
        a = oa(s, n, r),
        c = t(a).indexOf("3") - 1;
    return o = o.replace(/(\d)\D(\d)/g, "$1,$2"), c >= 0 && (o = `${o.slice(0,c)}.${o.slice(c+1)}`), o = o.replace(/1+/, "1").replace(/1/g, "#"), n || (o = o.replace(/%/g, "'%'")), o
}

function bJ(e) {
    let t = ".",
        n = e(1).includes("100");
    t = kC(t, e, n, !0), t = kC(t, e, n, !1);
    let r = FC(t, e, n, !1),
        o = FC(t, e, n, !0);
    return o === `-${r}` ? r : `${r};${o}`
}
var jC = Gm;
var HC = fn;
var VC = HC({
    isWrapped: function() {
        return !1
    },
    isWritableWrapped: function() {
        return !1
    },
    wrap: function(e) {
        return e
    },
    unwrap: function(e) {
        return e
    },
    assign: function() {
        di.error("Method 'assign' should not be used for not wrapped variables. Use 'isWrapped' method for ensuring.")
    }
});
var Pn = VC;
var mk = (function() {
        function e() {}
        return function(t) {
            return e.prototype = t, new e
        }
    })(),
    gk = function(e, t) {
        let n = [],
            r, o;
        for (r in e) Object.prototype.hasOwnProperty.call(e, r) && n.push(r);
        for (n.sort(function(i, s) {
                let a = ci(i),
                    c = ci(s);
                return a && c ? i - s : a && !c ? -1 : !a && c ? 1 : i < s ? -1 : i > s ? 1 : 0
            }), o = 0; o < n.length; o++) r = n[o], t(r, e[r])
    },
    $C = e => Ct(e) ? Array.isArray(e) ? [] : We(e) ? {} : Object.create(Object.getPrototypeOf(e)) : e,
    GC = function(e, t, n, r, o, i) {
        !o && Pn.isWrapped(e[t]) ? Pn.assign(e[t], n) : e[t] = n
    },
    Km = function(e, t, n, r, o, i) {
        let s = r ? Ct(e) : We(e);
        !o && Pn.isWrapped(e[t]) ? Pn.assign(e[t], n) : !o && Array.isArray(n) ? e[t] = n.map(a => pi($C(a), a, r, o, i)) : !o && s ? e[t] = pi($C(n), n, r, o, i, Km) : e[t] = n
    },
    pi = function(e, t, n, r, o, i) {
        let s, a, c = i ? Km : GC;
        for (let l in t) {
            if (s = e[l], a = t[l], l === "__proto__" || l === "constructor" || e === a) continue;
            if (We(a)) {
                let f = n ? Ct(s) : We(s);
                a = pi(f ? s : {}, a, n, r, o)
            }(Array.isArray(a) && !r || ((o || a !== void 0) && s !== a || o && s === void 0)) && c(e, l, a, n, r, o)
        }
        return e
    };
var Ek = Pn.unwrap,
    {
        isWrapped: qC
    } = Pn,
    {
        assign: yk
    } = Pn,
    vk = function(e) {
        return e.replace(/\[/g, ".").replace(/\]/g, "")
    },
    Ym = function(e) {
        return vk(e).split(".")
    },
    Dk = function(e, t, n) {
        return n = n || {}, ia(t === "this" ? e : e[t], n)
    },
    KC = function(e, t, n, r) {
        if (t === "this") throw new It.Error("E4016");
        let o = e[t];
        r.unwrapObservables && qC(o) ? yk(o, n) : e[t] = n
    },
    YC = function(e) {
        return e = e || {}, e.unwrapObservables = e.unwrapObservables !== void 0 ? e.unwrapObservables : !0, e
    };

function ia(e, t) {
    return t.unwrapObservables ? Ek(e) : e
}
var JC = function(e) {
    if (arguments.length > 1 && (e = [].slice.call(arguments)), !e || e === "this") return function(t) {
        return t
    };
    if (typeof e == "string") {
        let t = Ym(e);
        return function(n, r) {
            r = YC(r);
            let o = r.functionsAsIs,
                i = "defaultValue" in r,
                s = ia(n, r);
            for (let a = 0; a < t.length; a++) {
                if (!s) {
                    if (s == null && i) return r.defaultValue;
                    break
                }
                let c = t[a];
                if (i && Ct(s) && !(c in s)) return r.defaultValue;
                let l = ia(s[c], r);
                !o && we(l) && (l = l.call(s)), s = l
            }
            return s
        }
    }
    if (Array.isArray(e)) return _k(e);
    if (we(e)) return e
};

function _k(e) {
    let t = {};
    for (let n = 0, r = e.length; n < r; n++) {
        let o = e[n];
        t[o] = JC(o)
    }
    return function(n, r) {
        let o;
        return ze(t, function(i) {
            let s = this(n, r);
            if (s === void 0) return;
            let a = o || (o = {}),
                c = i.split("."),
                l = c.length - 1;
            for (let u = 0; u < l; u++) {
                let d = c[u];
                d in a || (a[d] = {}), a = a[d]
            }
            a[c[l]] = s
        }), o
    }
}

function WC(e, t) {
    return t != null && t.locale ? e.toLocaleLowerCase(t.locale) : e.toLowerCase()
}

function xk(e, t) {
    return t != null && t.locale ? e.toLocaleUpperCase(t.locale) : e.toUpperCase()
}
var zC = function(e, t, n, r) {
        if (un(n)) return n;
        let o = {};
        return KC(e, t, o, r), o
    },
    Ck = function(e) {
        e = Ym(e || "this");
        let t = e.length - 1;
        return function(n, r, o) {
            o = YC(o);
            let i = ia(n, o);
            e.forEach(function(s, a) {
                let c = Dk(i, s, o),
                    l = !o.functionsAsIs && we(c) && !qC(c);
                a === t ? o.merge && We(r) && (!un(c) || We(c)) ? (c = zC(i, s, c, o), pi(c, r, !1, !0)) : l ? i[s](r) : KC(i, s, r, o) : (c = zC(i, s, c, o), l && (c = c.call(i)), i = c)
            })
        }
    },
    Bu = function(e, t) {
        var n;
        let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
        if (e instanceof Date) return e.getTime();
        let o = r == null || (n = r.collatorOptions) === null || n === void 0 ? void 0 : n.sensitivity;
        if (e && e instanceof fi && e.valueOf) e = e.valueOf();
        else if (typeof e == "string" && (o === "base" || o === "case")) {
            let a = /[\u0300-\u036f]/g;
            o === "base" && (e = WC(e, r)), e = e.normalize("NFD").replace(a, "")
        }
        if (typeof e == "string" && !(t || o === "case" || o === "variant")) {
            var s;
            e = e.normalize("NFC");
            let a = r == null || (s = r.locale) === null || s === void 0 ? void 0 : s.toLowerCase();
            return (a && !!["hy", "el"].find(l => a === l || a.startsWith(`${l}-`)) ? xk : WC)(e, r)
        }
        return e
    };
var Ln = function(e) {
    this._options = e || {}, this._list = [], this._queue = [], this._firing = !1, this._fired = !1, this._firingIndexes = []
};
Ln.prototype._fireCore = function(e, t) {
    let n = this._firingIndexes,
        r = this._list,
        {
            stopOnFalse: o
        } = this._options,
        i = n.length;
    for (n[i] = 0; n[i] < r.length && !(r[n[i]].apply(e, t) === !1 && o); n[i]++);
    n.pop()
};
Ln.prototype.add = function(e) {
    return typeof e == "function" && (!this._options.unique || !this.has(e)) && this._list.push(e), this
};
Ln.prototype.remove = function(e) {
    let t = this._list,
        n = this._firingIndexes,
        r = t.indexOf(e);
    if (r > -1 && (t.splice(r, 1), this._firing && n.length))
        for (let o = 0; o < n.length; o++) r <= n[o] && n[o]--;
    return this
};
Ln.prototype.has = function(e) {
    let t = this._list;
    return e ? t.indexOf(e) > -1 : !!t.length
};
Ln.prototype.empty = function(e) {
    return this._list = [], this
};
Ln.prototype.fireWith = function(e, t) {
    let n = this._queue;
    if (t = t || [], t = t.slice ? t.slice() : t, this._options.syncStrategy) this._firing = !0, this._fireCore(e, t);
    else {
        if (n.push([e, t]), this._firing) return;
        for (this._firing = !0; n.length;) {
            let r = n.shift();
            this._fireCore(r[0], r[1])
        }
    }
    return this._firing = !1, this._fired = !0, this
};
Ln.prototype.fire = function() {
    this.fireWith(this, arguments)
};
Ln.prototype.fired = function() {
    return this._fired
};
var Jm = function(e) {
    return new Ln(e)
};
var eQ = Jm;
var QC = Jm;
var ZC = [{
        method: "resolve",
        handler: "done",
        state: "resolved"
    }, {
        method: "reject",
        handler: "fail",
        state: "rejected"
    }, {
        method: "notify",
        handler: "progress"
    }],
    hi = function() {
        let e = this;
        this._state = "pending", this._promise = {}, ZC.forEach(function(t) {
            let n = t.method;
            this[`${n}Callbacks`] = QC(), this[n] = function() {
                return this[`${n}With`](this._promise, arguments)
            }.bind(this), this._promise[t.handler] = function(r) {
                if (!r) return this;
                let o = e[`${n}Callbacks`];
                return o.fired() ? r.apply(e[`${n}Context`], e[`${n}Args`]) : o.add(function(i, s) {
                    r.apply(i, s)
                }), this
            }
        }.bind(this)), this._promise.always = function(t) {
            return this.done(t).fail(t)
        }, this._promise.catch = function(t) {
            return this.then(null, t)
        }, this._promise.then = function(t, n) {
            let r = new hi;
            return ["done", "fail"].forEach(function(o) {
                let i = o === "done" ? t : n;
                this[o](function() {
                    if (!i) {
                        r[o === "done" ? "resolve" : "reject"].apply(this, arguments);
                        return
                    }
                    let s = i && i.apply(this, arguments);
                    li(s) ? s.done(r.resolve).fail(r.reject) : na(s) ? s.then(r.resolve, r.reject) : r.resolve.apply(this, un(s) ? [s] : arguments)
                })
            }.bind(this)), r.promise()
        }, this._promise.state = function() {
            return e._state
        }, this._promise.promise = function(t) {
            return t ? Te(t, e._promise) : e._promise
        }, this._promise.promise(this)
    };
ZC.forEach(function(e) {
    let t = e.method,
        {
            state: n
        } = e;
    hi.prototype[`${t}With`] = function(r, o) {
        let i = this[`${t}Callbacks`];
        return this.state() === "pending" && (this[`${t}Args`] = o, this[`${t}Context`] = r, n && (this._state = n), i.fire(r, o), n !== "pending" && (this.resolveCallbacks.empty(), this.rejectCallbacks.empty())), this
    }
});

function XC(e, t) {
    if (li(e)) return e;
    if (na(e)) {
        let n = new hi;
        return e.then(function() {
            n.resolveWith.apply(n, [t].concat([
                [].slice.call(arguments)
            ]))
        }, function() {
            n.rejectWith.apply(n, [t].concat([
                [].slice.call(arguments)
            ]))
        }), n
    }
    return new hi().resolveWith(t, [e])
}
var Ik = function() {
    if (arguments.length === 1) return XC(arguments[0]);
    let e = [].slice.call(arguments),
        t = [],
        n = 0,
        r = new hi,
        o = function(i) {
            return function(s) {
                t[i] = this, e[i] = arguments.length > 1 ? [].slice.call(arguments) : s, n++, n === e.length && r.resolveWith(t, e)
            }
        };
    for (let i = 0; i < e.length; i++) li(e[i]) ? e[i].promise().done(o(i)).fail(r.reject) : n++;
    return n === e.length && r.resolveWith(t, e), r.promise()
};

function mi() {
    return new hi
}

function ju() {
    return Ik.apply(this, arguments)
}
var EQ = new mi,
    Tk = function(e, t) {
        return un(e) ? e : t
    },
    Sk = function(e, t) {
        let n = new mi,
            r = t || this,
            o = {
                promise: n.promise(),
                abort() {
                    clearTimeout(i), n.rejectWith(r)
                }
            },
            i = (arguments[2] || setTimeout)(function() {
                let s = e.call(r);
                s && s.done && we(s.done) ? s.done(function() {
                    n.resolveWith(r)
                }) : n.resolveWith(r)
            }, typeof t == "number" ? t : 0);
        return o
    },
    Qm = [],
    eI = [],
    sa = [],
    gi, Hu = function(e, t, n) {
        if (gi && gi !== e) return Qm.push(t), eI.push(e), n = n || new mi, sa.push(n), n;
        let r = gi,
            o = sa.length;
        gi = e;
        let i = t();
        return i || (sa.length > o ? i = ju.apply(this, sa.slice(o)) : n && n.resolve()), gi = r, n && i && i.done && i.done(n.resolve).fail(n.reject), !gi && Qm.length && (eI.shift() === "render" ? nI : rI)(Qm.shift(), sa.shift()), i || ju()
    },
    nI = function(e, t) {
        return Hu("render", e, t)
    },
    rI = function(e, t) {
        return Hu("update", e, t)
    },
    bk = function(e) {
        return function() {
            let t = this;
            return Hu("render", function() {
                return e.call(t)
            })
        }
    },
    wk = function(e) {
        return function() {
            let t = this;
            return Hu("update", function() {
                return e.call(t)
            })
        }
    },
    Ak = (e, t, n) => {
        let r = [],
            o = 0;
        return ze(t, (i, s) => {
            let a = 0,
                c = n ? n(s) : s;
            ze(e, (l, u) => {
                let d = c[l];
                if (d !== void 0) {
                    if (Mk(d, u)) {
                        a++;
                        return
                    }
                    return a = -1, !1
                }
            }), !(a < o) && (a > o && (r.length = 0, o = a), r.push(s))
        }), r
    },
    Mk = function(e, t) {
        if (Array.isArray(e) && Array.isArray(t)) {
            let n = !1;
            return ze(e, (r, o) => {
                if (o !== t[r]) return n = !0, !1
            }), !n
        }
        return e === t
    },
    oI = function(e) {
        switch (fr(e)) {
            case "string":
                return e.split(/\s+/, 2);
            case "object":
                return [e.x ? ? e.h, e.y ? ? e.v];
            case "number":
                return [e];
            case "array":
                return e;
            default:
                return null
        }
    },
    Nk = function(e) {
        let t = dn(e) ? e : e.toString(),
            n = t.match(/[^a-zA-Z0-9_]/g);
        return n && ze(n, (r, o) => {
            t = t.replace(o, `__${o.charCodeAt()}__`)
        }), t
    },
    Rk = function(e) {
        let t = e.match(/__\d+__/g);
        return t && t.forEach(n => {
            let r = parseInt(n.replace("__", ""));
            e = e.replace(n, String.fromCharCode(r))
        }), e
    },
    Ok = function(e, t) {
        let n = oI(e),
            r = t ? parseFloat(n && n[0]) : parseInt(n && n[0], 10),
            o = t ? parseFloat(n && n[1]) : parseInt(n && n[1], 10);
        return isFinite(r) || (r = 0), isFinite(o) || (o = r), {
            h: r,
            v: o
        }
    },
    Pk = function(e) {
        if (e instanceof jC) return e.toString();
        if (Ct(e) || Array.isArray(e)) try {
            let t = JSON.stringify(e);
            return t === "{}" ? e : t
        } catch (t) {
            return e
        }
        return e
    },
    so = function(e) {
        return e.replace(/[[\]{}\-()*+?.\\^$|\s]/g, "\\$&")
    },
    Lk = function(e) {
        let t = Tt().serverDecimalSeparator;
        return un(e) && (e = e.toString().replace(".", t)), e
    },
    kk = function() {},
    Fk = function() {
        return new mi().resolve().promise()
    },
    Uk = function(e, t, n) {
        let r = [],
            o, i = !n;
        for (let s = 0; s < e.length; s++) o = !!t(e[s], s), o === i && r.push(e[s]);
        return r
    },
    Bk = (e, t, n, r) => e.length !== t.length ? !1 : !e.some((o, i) => !Zm(o, t[i], n + 1, Object.assign({}, r, {
        strict: !0
    }))),
    jk = (e, t, n, r) => {
        let o = Object.keys(e),
            i = Object.keys(t);
        if (o.length !== i.length) return !1;
        let s = new Set(i);
        return !o.some(a => !s.has(a) || !Zm(e[a], t[a], n + 1, r))
    },
    tI = {
        maxDepth: 3,
        strict: !0
    },
    Zm = (e, t, n, r) => {
        let {
            strict: o,
            maxDepth: i
        } = r, s = Bu(e, !0), a = Bu(t, !0), c = o ? s === a : s == a;
        switch (!0) {
            case c:
            case n >= i:
                return !0;
            case (Ct(s) && Ct(a)):
                return jk(s, a, n, r);
            case (Array.isArray(s) && Array.isArray(a)):
                return Bk(s, a, n, r);
            default:
                return !1
        }
    },
    Hk = function(e, t) {
        let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : tI,
            r = Object.assign({}, tI, n);
        return Zm(e, t, 0, r)
    },
    yQ = {
        ensureDefined: Tk,
        executeAsync: Sk,
        deferRender: nI,
        deferUpdate: rI,
        deferRenderer: bk,
        deferUpdater: wk,
        findBestMatches: Ak,
        splitPair: oI,
        normalizeKey: Nk,
        denormalizeKey: Rk,
        pairToObject: Ok,
        getKeyHash: Pk,
        escapeRegExp: so,
        applyServerDecimalSeparator: Lk,
        noop: kk,
        asyncNoop: Fk,
        grep: Uk,
        equalByValue: Hk
    };
var Vk = typeof Intl < "u";
var iI = ["currency", "fixedpoint", "exponential", "percent", "decimal"],
    Xm = {
        1: "K",
        2: "M",
        3: "B",
        4: "T"
    },
    sI = {
        largenumber: "auto",
        thousands: 1,
        millions: 2,
        billions: 3,
        trillions: 4
    },
    eg = fn({
        engine: () => "base",
        numericFormats: iI,
        defaultLargeNumberFormatPostfixes: Xm,
        _parseNumberFormatString(e) {
            let t = {};
            if (!e || typeof e != "string") return;
            let n = e.toLowerCase().split(" ");
            if (ze(n, (o, i) => {
                    iI.includes(i) ? t.formatType = i : i in sI && (t.power = sI[i])
                }), t.power && !t.formatType && (t.formatType = "fixedpoint"), r = t, "formatType" in r && t.formatType) return t;
            var r
        },
        _calculateNumberPower(e, t, n, r) {
            let o = Math.abs(e),
                i = 0;
            if (o > 1)
                for (; o && o >= t && (r === void 0 || i < r);) i += 1, o /= t;
            else if (o > 0 && o < 1)
                for (; o < 1 && (n === void 0 || i > n);) i -= 1, o *= t;
            return i
        },
        _getNumberByPower(e, t, n) {
            let r = e;
            for (; t > 0;) r /= n, t -= 1;
            for (; t < 0;) r *= n, t += 1;
            return r
        },
        _formatNumber(e, t, n) {
            t.power === "auto" && (t.power = this._calculateNumberPower(e, 1e3, 0, 4)), t.power && (e = this._getNumberByPower(e, t.power, 1e3));
            let r = t.power && this.defaultLargeNumberFormatPostfixes[t.power] || "",
                o = this._formatNumberCore(e, t.formatType, n);
            return o = o.replace(/(\d|.$)(\D*)$/, `$1${r}$2`), o
        },
        _formatNumberExponential(e, t) {
            let n = this._calculateNumberPower(e, 10),
                r = this._getNumberByPower(e, n, 10);
            t.precision === void 0 && (t.precision = 1), r.toFixed(t.precision || 0) >= 10 && (n += 1, r /= 10);
            let o = (n >= 0 ? "+" : "") + n.toString();
            return `${this._formatNumberCore(r,"fixedpoint",t)}E${o}`
        },
        _addZeroes(e, t) {
            let n = 10 ** t,
                r = e < 0 ? "-" : "";
            e = (Math.abs(e) * n >>> 0) / n;
            let o = e.toString();
            for (; o.length < t;) o = `0${o}`;
            return r + o
        },
        _addGroupSeparators(e) {
            let t = e.toString().split(".");
            return t[0].replace(/\B(?=(\d{3})+(?!\d))/g, Tt().thousandsSeparator) + (t[1] ? Tt().decimalSeparator + t[1] : "")
        },
        _formatNumberCore(e, t, n) {
            if (t === "exponential") return this._formatNumberExponential(e, n);
            t !== "decimal" && n.precision !== null && (n.precision = n.precision || 0), t === "percent" && (e *= 100);
            let r = `${e}`;
            return n.precision !== void 0 && (t === "decimal" ? r = this._addZeroes(e, n.precision) : r = n.precision === null ? e.toPrecision() : Uu(e, n.precision)), t !== "decimal" ? r = this._addGroupSeparators(r) : r = r.toString().replace(".", Tt().decimalSeparator), t === "percent" && (r += "%"), r
        },
        _normalizeFormat(e) {
            return e ? (typeof e == "function" || We(e) || (e = {
                type: e
            }), e) : {}
        },
        _getSeparators() {
            return {
                decimalSeparator: this.getDecimalSeparator(),
                thousandsSeparator: this.getThousandsSeparator()
            }
        },
        getThousandsSeparator() {
            return this.format(1e4, "fixedPoint")[2]
        },
        getDecimalSeparator() {
            return this.format(1.2, {
                type: "fixedPoint",
                precision: 1
            })[1]
        },
        convertDigits(e, t) {
            let n = this.format(90, "decimal");
            if (typeof e != "string" || n[1] === "0") return e;
            let r = t ? n[1] : "0",
                o = t ? "0" : n[1],
                i = t ? n[0] : "9",
                s = new RegExp(`[${r}-${i}]`, "g");
            return e.replace(s, a => String.fromCharCode(a.charCodeAt(0) + (o.charCodeAt(0) - r.charCodeAt(0))))
        },
        getNegativeEtalonRegExp(e) {
            let t = this._getSeparators(),
                n = new RegExp(`[0-9${so(t.decimalSeparator+t.thousandsSeparator)}]+`, "g"),
                r = this.format(-1, e).replace(n, "1");
            return ["\\", "(", ")", "[", "]", "*", "+", "$", "^", "?", "|", "{", "}"].forEach(o => {
                r = r.replace(new RegExp(`\\${o}`, "g"), `\\${o}`)
            }), r = r.replace(/ /g, "\\s"), r = r.replace(/1/g, ".*"), new RegExp(r, "g")
        },
        getSign(e, t) {
            if (!t) return e.replace(/[^0-9-]/g, "").startsWith("-") ? -1 : 1;
            let n = this.getNegativeEtalonRegExp(t);
            return e.match(n) ? -1 : 1
        },
        format(e, t) {
            var n;
            if (typeof e != "number" || typeof t == "number") return e;
            if (t = ((n = t) === null || n === void 0 ? void 0 : n.formatter) || t, typeof t == "function") return t(e);
            t = this._normalizeFormat(t), t.type || (t.type = "decimal");
            let r = this._parseNumberFormatString(t.type);
            if (!r) {
                let o = this._getSeparators();
                o.unlimitedIntegerDigits = t.unlimitedIntegerDigits;
                let i = BC(t.type, o)(e);
                return this.convertDigits(i)
            }
            return this._formatNumber(e, r, t)
        },
        parse(e, t) {
            var n;
            if (!e) return;
            if (typeof t != "string" && (n = t) !== null && n !== void 0 && n.parser) return t.parser(e);
            e = this.convertDigits(e, !0), t && typeof t != "string" && It.log("W0011");
            let r = this.getDecimalSeparator(),
                o = new RegExp(`[^0-9${so(r)}]`, "g"),
                i = e.replace(o, "").replace(r, ".").replace(/\.$/g, "");
            if (i === "." || i === "") return null;
            if (this._calcSignificantDigits(i) > 15) return NaN;
            let s = +i * this.getSign(e, t);
            t = this._normalizeFormat(t);
            let a = this._parseNumberFormatString(t.type),
                c = a ? .power;
            if (c) {
                if (c === "auto") {
                    let l = /\d(K|M|B|T)/.exec(e);
                    l && (c = Object.keys(Xm).map(Number).find(u => Xm[u] === l[1]))
                }
                s *= 10 ** (3 * c)
            }
            return a ? .formatType === "percent" && (s /= 100), s
        },
        _calcSignificantDigits(e) {
            let [t, n] = e.split("."), r = i => {
                let s = -1;
                for (let a = 0; a < i.length; a += 1)
                    if (i[a] !== "0") {
                        s = a;
                        break
                    }
                return s > -1 ? i.length - s : 0
            }, o = 0;
            return t && (o += r(t.split(""))), n && (o += r(n.split("").reverse())), o
        }
    });
eg.inject(Xx);
Vk && eg.inject(wC);
var St = eg;
var cI = " .,:;/\\<>()-[]\u060C";
var pr = e => {
        let t = e && St.convertDigits(e, !1).charCodeAt(0),
            n = St.convertDigits("0", !1).charCodeAt(0);
        return n <= t && t < n + 10
    },
    $k = (e, t, n, r) => {
        let o = e[n],
            i = e[n + 1];
        if (!r && (o === "." || o === " " && e.slice(n - 1, n + 3) === ". m." || o === "-" && !pr(i))) return !0;
        let s = r && t.some(a => e[n] !== a[n]);
        return !cI.includes(o) && r === pr(o) && (!r || s)
    },
    Gk = (e, t) => {
        if (!pr(e[t]))
            for (; t > 0 && !pr(e[t - 1]) && (e[t - 1] === "." || !cI.includes(e[t - 1]));) t -= 1;
        return t
    },
    Wk = (e, t, n, r) => {
        let o = 0,
            i = [],
            s = a => e[o] !== a[o] && (r === void 0 || pr(e[o]) === r);
        for (Array.isArray(t) || (t = [t]), o = 0; o < e.length; o += 1)
            if (!n.includes(o) && t.filter(s).length) {
                o = Gk(e, o);
                do {
                    if (r = pr(e[o]), !i.length && !r && pr(t[0][o])) break;
                    i.push(o), n.unshift(o), o += 1
                } while (e[o] && $k(e, t, o, r));
                break
            }
        return i.length === 1 && (e[n[0] - 1] === "0" || e[n[0] - 1] === "\u0660") && n.unshift(n[0] - 1), i
    },
    zk = (e, t, n, r) => {
        let o = t[0],
            i = o < r.length ? r[o] : o;
        return t.forEach((s, a) => {
            e = e.substr(0, i + a) + (n.length > 1 ? n[a] : n) + e.substr(i + a + 1)
        }), t.length === 1 && (e = e.replace(`0${n}`, n + n), e = e.replace(`\u0660${n}`, n + n)), e
    },
    qk = (e, t, n, r) => {
        let o, i, s;
        if (!pr(e[t[0]] || "0")) {
            let a = Math.max(t.length <= 3 ? 3 : 4, n.length);
            for (; t.length > a;) {
                for (i = t.pop(), s = r[i], r[i] = -1, o = i + 1; o < r.length; o += 1) r[o] -= 1;
                e = e.substr(0, s) + e.substr(s + 1)
            }
            for (i = t[t.length - 1] + 1, s = i < r.length ? r[i] : i; t.length < a;) {
                for (t.push(t[t.length - 1] + 1), o = i; o < r.length; o += 1) r[o] += 1;
                e = `${e.substr(0,s)} ${e.substr(s)}`
            }
        }
        return e = zk(e, t, n, r), e
    },
    aI = (e, t) => Array.isArray(e) ? e.map(n => (t(n) || "").toString()) : (t(e) || "").toString(),
    Kk = /[a-zA-Z]/g,
    Yk = (e, t, n, r) => {
        let o = t.split("").map((i, s) => !n.includes(s) && (i.match(Kk) || i === "'") ? r[s] : -1);
        return e = e.split("").map((i, s) => {
            let a = i,
                c = o.includes(s),
                l = s > 0 && o.includes(s - 1),
                u = o.includes(s + 1);
            return c && (l || (a = `'${a}`), u || (a = `${a}'`)), a
        }).join(""), e
    },
    lI = e => {
        let t = [],
            n = aI(new Date(2009, 8, 8, 6, 5, 4), e),
            r = n.split("").map((a, c) => c),
            o = n,
            i = {},
            s = [{
                date: new Date(2009, 8, 8, 6, 5, 4, 111),
                pattern: "S"
            }, {
                date: new Date(2009, 8, 8, 6, 5, 2),
                pattern: "s"
            }, {
                date: new Date(2009, 8, 8, 6, 2, 4),
                pattern: "m"
            }, {
                date: new Date(2009, 8, 8, 18, 5, 4),
                pattern: "H",
                isDigit: !0
            }, {
                date: new Date(2009, 8, 8, 2, 5, 4),
                pattern: "h",
                isDigit: !0
            }, {
                date: new Date(2009, 8, 8, 18, 5, 4),
                pattern: "a",
                isDigit: !1
            }, {
                date: new Date(2009, 8, 1, 6, 5, 4),
                pattern: "d"
            }, {
                date: [new Date(2009, 8, 2, 6, 5, 4), new Date(2009, 8, 3, 6, 5, 4), new Date(2009, 8, 4, 6, 5, 4)],
                pattern: "E"
            }, {
                date: new Date(2009, 9, 6, 6, 5, 4),
                pattern: "M"
            }, {
                date: new Date(1998, 8, 8, 6, 5, 4),
                pattern: "y"
            }];
        if (o && (s.forEach(a => {
                let c = Wk(n, aI(a.date, e), t, a.isDigit),
                    l = a.pattern === "M" && !i.d ? "L" : a.pattern;
                o = qk(o, c, l, r), i[l] = c.length
            }), o = Yk(o, n, t, r), t.length)) return o
    };

function bt(e, t) {
    for (; e.length < t;) e = `0${e}`;
    return e
}
var aa = {
        3: "abbreviated",
        4: "wide",
        5: "narrow"
    },
    tg = {
        y(e, t, n) {
            let r = e[n ? "getUTCFullYear" : "getFullYear"]();
            return t === 2 && (r %= 100), bt(r.toString(), t)
        },
        M(e, t, n, r) {
            let o = e[n ? "getUTCMonth" : "getMonth"](),
                i = aa[t];
            return i ? r.getMonthNames(i, "format")[o] : bt((o + 1).toString(), Math.min(t, 2))
        },
        L(e, t, n, r) {
            let o = e[n ? "getUTCMonth" : "getMonth"](),
                i = aa[t];
            return i ? r.getMonthNames(i, "standalone")[o] : bt((o + 1).toString(), Math.min(t, 2))
        },
        Q(e, t, n, r) {
            let o = e[n ? "getUTCMonth" : "getMonth"](),
                i = Math.floor(o / 3),
                s = aa[t];
            return s ? r.getQuarterNames(s)[i] : bt((i + 1).toString(), Math.min(t, 2))
        },
        E(e, t, n, r) {
            let o = e[n ? "getUTCDay" : "getDay"](),
                i = aa[t < 3 ? 3 : t];
            return r.getDayNames(i)[o]
        },
        a(e, t, n, r) {
            let i = e[n ? "getUTCHours" : "getHours"]() < 12 ? 0 : 1,
                s = aa[t];
            return r.getPeriodNames(s)[i]
        },
        d: (e, t, n) => bt(e[n ? "getUTCDate" : "getDate"]().toString(), Math.min(t, 2)),
        H: (e, t, n) => bt(e[n ? "getUTCHours" : "getHours"]().toString(), Math.min(t, 2)),
        h(e, t, n) {
            let r = e[n ? "getUTCHours" : "getHours"]();
            return bt((r % 12 || 12).toString(), Math.min(t, 2))
        },
        m: (e, t, n) => bt(e[n ? "getUTCMinutes" : "getMinutes"]().toString(), Math.min(t, 2)),
        s: (e, t, n) => bt(e[n ? "getUTCSeconds" : "getSeconds"]().toString(), Math.min(t, 2)),
        S: (e, t, n) => bt(e[n ? "getUTCMilliseconds" : "getMilliseconds"]().toString(), 3).substr(0, t),
        x(e, t, n) {
            let r = n ? 0 : e.getTimezoneOffset(),
                o = r > 0 ? "-" : "+",
                i = Math.abs(r),
                s = Math.floor(i / 60),
                a = i % 60,
                c = bt(s.toString(), 2),
                l = bt(a.toString(), 2);
            return o + c + (t >= 3 ? ":" : "") + (t > 1 || a ? l : "")
        },
        X(e, t, n) {
            return n || !e.getTimezoneOffset() ? "Z" : tg.x(e, t, n)
        },
        Z: (e, t, n) => tg.X(e, t >= 5 ? 3 : 2, n)
    },
    uI = (e, t) => n => {
        let r, o, i, s = 0,
            a = !1,
            c, l = "";
        if (!n) return null;
        if (!e) return n;
        let u = e.endsWith("Z") || e.endsWith("'Z'");
        for (r = 0; r < e.length; r += 1) i = e[r], o = tg[i], c = i === e[r + 1], s += 1, c || (o && !a && (l += o(n, s, u, t)), s = 0), i === "'" && !c ? a = !a : (a || !o) && (l += i), i === "'" && c && (r += 1);
        return l
    };
var Fn = {
        3: "abbreviated",
        4: "wide",
        5: "narrow"
    },
    dI = (e, t) => e > 2 ? Object.keys(Fn).map(n => ["format", "standalone"].map(r => t.getMonthNames(Fn[n], r).join("|")).join("|")).join("|") : e === 2 ? "1[012]|0?[1-9]" : "0??[1-9]|1[012]",
    Jk = {
        ":": (e, t) => {
            var n;
            let r = e > 1 ? `{${e}}` : "",
                o = so((n = t.getTimeSeparator) === null || n === void 0 ? void 0 : n.call(t));
            return o !== ":" && (o = `${o}|:`), `${o}${r}`
        },
        y: e => e === 2 ? `[0-9]{${e}}` : "[0-9]+?",
        M: dI,
        L: dI,
        Q(e, t) {
            return e > 2 ? t.getQuarterNames(Fn[e], "format").join("|") : "0?[1-4]"
        },
        E: (e, t) => "\\D*",
        a: (e, t) => t.getPeriodNames(Fn[e < 3 ? 3 : e], "format").join("|"),
        d: e => e === 2 ? "3[01]|[12][0-9]|0?[1-9]" : "0??[1-9]|[12][0-9]|3[01]",
        H: e => e === 2 ? "2[0-3]|1[0-9]|0?[0-9]" : "0??[0-9]|1[0-9]|2[0-3]",
        h: e => e === 2 ? "1[012]|0?[1-9]" : "0??[1-9]|1[012]",
        m: e => e === 2 ? "[1-5][0-9]|0?[0-9]" : "0??[0-9]|[1-5][0-9]",
        s: e => e === 2 ? "[1-5][0-9]|0?[0-9]" : "0??[0-9]|[1-5][0-9]",
        S: e => `[0-9]{1,${e}}`,
        w: e => e === 2 ? "[1-5][0-9]|0?[0-9]" : "0??[0-9]|[1-5][0-9]",
        x: e => e === 3 ? "[+-](?:2[0-3]|[01][0-9]):(?:[0-5][0-9])|Z" : "[+-](?:2[0-3]|[01][0-9])(?:[0-5][0-9])|Z"
    },
    kn = Number,
    ng = (e, t) => e.map(n => n.toLowerCase()).indexOf(t.toLowerCase()),
    fI = (e, t, n) => t > 2 ? ["format", "standalone"].map(r => Object.keys(Fn).map(o => {
        let i = n.getMonthNames(Fn[o], r);
        return ng(i, e)
    })).reduce((r, o) => r.concat(o)).filter(r => r >= 0)[0] : kn(e) - 1,
    Qk = {
        y(e, t) {
            let n = kn(e);
            return t === 2 ? n < 30 ? 2e3 + n : 1900 + n : n
        },
        M: fI,
        L: fI,
        Q(e, t, n) {
            return t > 2 ? n.getQuarterNames(Fn[t], "format").indexOf(e) : kn(e) - 1
        },
        E(e, t, n) {
            let r = n.getDayNames(Fn[t < 3 ? 3 : t], "format");
            return ng(r, e)
        },
        a(e, t, n) {
            let r = n.getPeriodNames(Fn[t < 3 ? 3 : t], "format");
            return ng(r, e)
        },
        d: kn,
        H: kn,
        h: kn,
        m: kn,
        s: kn,
        S(e, t) {
            for (t = Math.max(t, 3), e = e.slice(0, 3); t < 3;) e = `${e}0`, t += 1;
            return kn(e)
        }
    },
    Vu = ["y", "M", "d", "h", "m", "s", "S"],
    rg = {
        y: "setFullYear",
        M: "setMonth",
        L: "setMonth",
        a(e, t, n) {
            let r = e.getHours(),
                o = n.h;
            o !== void 0 && o !== r && (r -= 1), !t && r === 12 ? r = 0 : t && r !== 12 && (r += 12), e.setHours(r)
        },
        d: "setDate",
        H: "setHours",
        h: "setHours",
        m: "setMinutes",
        s: "setSeconds",
        S: "setMilliseconds"
    },
    Zk = (e, t) => {
        let n = e[t];
        if (!n) return 0;
        let r = 0;
        do t += 1, r += 1; while (e[t] === n);
        return r
    },
    Xk = (e, t) => {
        let n = "";
        for (let r = 0; r < t; r += 1) n += e;
        return n
    },
    eF = ["d", "H", "h", "m", "s", "w", "M", "L", "Q"],
    tF = e => {
        let t = o => {
                if (!o) return !1;
                let i = o[0];
                return ["y", "S"].includes(i) || eF.includes(i) && o.length < 3
            },
            n = !0,
            r = 0;
        return e.every((o, i, s) => (t(o) && ((a => !a.startsWith("S") && a.length !== 2)(o) && (n = ++r < 2), t(s[i + 1]) || (r = 0)), n))
    },
    nF = (e, t) => {
        let n = "",
            r = "",
            o = !1,
            i = [],
            s = () => {
                r && (i.push(`'${r}'`), n += `${so(r)})`, r = "")
            };
        for (let a = 0; a < e.length; a += 1) {
            let c = e[a],
                l = c === "'",
                u = Jk[c];
            if (!(l && (o = !o, e[a - 1] !== "'")))
                if (u && !o) {
                    let d = Zk(e, a),
                        f = Xk(c, d);
                    s(), i.push(f), n += `(${u(d,t)})`, a += d - 1
                } else r || (n += "("), r += c
        }
        return s(), tF(i) || di.warn(`The following format may be parsed incorrectly: ${e}.`), {
            patterns: i,
            regexp: new RegExp(`^${n}$`, "i")
        }
    },
    kQ = () => rg,
    rF = (e, t, n, r, o) => {
        let i = t[0],
            s = rg[i],
            a = Qk[i];
        if (s && a) {
            let c = a(n, t.length, r);
            o[t] = c, e[s] ? e[s](c) : s(e, c, o)
        }
    },
    oF = (e, t, n) => {
        let r = rg[t],
            o = `g${r.substr(1)}`,
            i = n[o]();
        e[r](i)
    },
    iF = e => e.map(t => t.startsWith("'") ? "" : t.startsWith("H") ? "h" : t[0]),
    sF = e => {
        let t = e.map(n => Vu.indexOf(n));
        return Math.max(...t)
    },
    aF = e => {
        let t = e.filter(n => !Vu.includes(n));
        return Vu.concat(t)
    },
    pI = (e, t) => {
        let n = nF(e, t);
        return r => {
            let o = n.regexp.exec(r);
            if (o) {
                let i = new Date,
                    s = new Date(i.getFullYear(), 0, 1),
                    a = iF(n.patterns),
                    c = sF(a),
                    l = aF(a),
                    u = {};
                return l.forEach((d, f) => {
                    if (!d || f < Vu.length && f > c) return;
                    let p = a.indexOf(d);
                    if (p >= 0) {
                        let m = n.patterns[p],
                            x = o[p + 1];
                        rF(s, m, x, t, u)
                    } else oF(s, d, i)
                }), s
            }
            return null
        }
    };
var cF = typeof Intl < "u",
    og = {
        shortdate: "M/d/y",
        shorttime: "h:mm a",
        longdate: "EEEE, MMMM d, y",
        longtime: "h:mm:ss a",
        monthandday: "MMMM d",
        monthandyear: "MMMM y",
        quarterandyear: "QQQ y",
        day: "d",
        year: "y",
        shortdateshorttime: "M/d/y, h:mm a",
        longdatelongtime: "EEEE, MMMM d, y, h:mm:ss a",
        month: "LLLL",
        shortyear: "yy",
        dayofweek: "EEEE",
        quarter: "QQQ",
        hour: "HH",
        minute: "mm",
        second: "ss",
        millisecond: "SSS",
        "datetime-local": "yyyy-MM-ddTHH':'mm':'ss"
    },
    lF = {
        year: ["y", "yy", "yyyy"],
        day: ["d", "dd"],
        month: ["M", "MM", "MMM", "MMMM"],
        hours: ["H", "HH", "h", "hh", "ah"],
        minutes: ["m", "mm"],
        seconds: ["s", "ss"],
        milliseconds: ["S", "SS", "SSS"]
    },
    hI = fn({
        engine: () => "base",
        _getPatternByFormat: e => og[e.toLowerCase()],
        _expandPattern(e) {
            return this._getPatternByFormat(e) || e
        },
        formatUsesMonthName(e) {
            return this._expandPattern(e).indexOf("MMMM") !== -1
        },
        formatUsesDayName(e) {
            return this._expandPattern(e).indexOf("EEEE") !== -1
        },
        getFormatParts(e) {
            let t = this._getPatternByFormat(e) || e,
                n = [];
            return ze(t.split(/\W+/), (r, o) => {
                ze(lF, (i, s) => {
                    s.includes(o) && n.push(i)
                })
            }), n
        },
        getMonthNames: e => ra.getMonthNames(e),
        getDayNames: e => ra.getDayNames(e),
        getQuarterNames: e => ra.getQuarterNames(e),
        getPeriodNames: e => ra.getPeriodNames(e),
        getTimeSeparator: () => ":",
        is24HourFormat(e) {
            let t = new Date(2017, 0, 20, 11, 0, 0, 0),
                n = new Date(2017, 0, 20, 23, 0, 0, 0),
                r = this.format(t, e),
                o = this.format(n, e);
            for (let i = 0; i < r.length; i += 1)
                if (r[i] !== o[i]) return !isNaN(parseInt(r[i], 10))
        },
        format(e, t) {
            if (!e) return;
            if (!t) return e;
            let n;
            if (typeof t == "function") n = t;
            else if (t.formatter) n = t.formatter;
            else if (t = t.type ? ? t, dn(t)) return t = og[t.toLowerCase()] || t, St.convertDigits(uI(t, this)(e));
            if (n) return n(e)
        },
        parse(e, t) {
            let n = this,
                r, o;
            if (!e) return;
            if (!t) return this.parse(e, "shortdate");
            if (typeof t == "object" && t.parser) return t.parser(e);
            if (typeof t == "string" && !og[t.toLowerCase()]) r = t;
            else {
                o = s => {
                    let a = n.format(s, t);
                    return St.convertDigits(a, !0)
                };
                try {
                    r = lI(o)
                } catch (s) {}
            }
            if (r) return e = St.convertDigits(e, !0), pI(r, this)(e);
            Pu.log("W0012");
            let i = new Date(e);
            if (!(!i || isNaN(i.getTime()))) return i
        },
        firstDayOfWeekIndex() {
            return Ie.getValueByClosestLocale(t => mC[t]) ? ? 0
        }
    });
cF && hI.inject(vC);
var ca = hI;
var mI = {
    en: {
        Yes: "Yes",
        No: "No",
        Cancel: "Cancel",
        CheckState: "Check state",
        Close: "Close",
        Clear: "Clear",
        Done: "Done",
        Loading: "Loading...",
        Select: "Select...",
        Search: "Search",
        Back: "Back",
        OK: "OK",
        Today: "Today",
        Yesterday: "Yesterday",
        "dxCollectionWidget-noDataText": "No data to display",
        "dxDropDownEditor-selectLabel": "Select",
        "validation-required": "Required",
        "validation-required-formatted": "{0} is required",
        "validation-numeric": "Value must be a number",
        "validation-numeric-formatted": "{0} must be a number",
        "validation-range": "Value is out of range",
        "validation-range-formatted": "{0} is out of range",
        "validation-stringLength": "The length of the value is not correct",
        "validation-stringLength-formatted": "The length of {0} is not correct",
        "validation-custom": "Value is invalid",
        "validation-custom-formatted": "{0} is invalid",
        "validation-async": "Value is invalid",
        "validation-async-formatted": "{0} is invalid",
        "validation-compare": "Values do not match",
        "validation-compare-formatted": "{0} does not match",
        "validation-pattern": "Value does not match pattern",
        "validation-pattern-formatted": "{0} does not match pattern",
        "validation-email": "Email is invalid",
        "validation-email-formatted": "{0} is invalid",
        "validation-mask": "Value is invalid",
        "dxLookup-searchPlaceholder": "Minimum character number: {0}",
        "dxList-pullingDownText": "Pull down to refresh...",
        "dxList-pulledDownText": "Release to refresh...",
        "dxList-refreshingText": "Refreshing...",
        "dxList-pageLoadingText": "Loading...",
        "dxList-nextButtonText": "More",
        "dxList-selectAll": "Select All",
        "dxList-listAriaLabel": "Items",
        "dxList-listAriaLabel-deletable": "Deletable items",
        "dxListEditDecorator-delete": "Delete",
        "dxListEditDecorator-more": "More",
        "dxList-selectAll-indeterminate": "Half-checked",
        "dxList-selectAll-checked": "Checked",
        "dxList-selectAll-notChecked": "Not checked",
        "dxList-ariaRoleDescription": "List",
        "dxList-listAriaLabel-itemContent": "List item content",
        "dxScrollView-pullingDownText": "Pull down to refresh...",
        "dxScrollView-pulledDownText": "Release to refresh...",
        "dxScrollView-refreshingText": "Refreshing...",
        "dxScrollView-reachBottomText": "Loading...",
        "dxDateBox-simulatedDataPickerTitleTime": "Select time",
        "dxDateBox-simulatedDataPickerTitleDate": "Select date",
        "dxDateBox-simulatedDataPickerTitleDateTime": "Select date and time",
        "dxDateBox-validation-datetime": "Value must be a date or time",
        "dxDateRangeBox-invalidStartDateMessage": "Start value must be a date",
        "dxDateRangeBox-invalidEndDateMessage": "End value must be a date",
        "dxDateRangeBox-startDateOutOfRangeMessage": "Start date is out of range",
        "dxDateRangeBox-endDateOutOfRangeMessage": "End date is out of range",
        "dxDateRangeBox-startDateLabel": "Start Date",
        "dxDateRangeBox-endDateLabel": "End Date",
        "dxFileUploader-selectFile": "Select a file",
        "dxFileUploader-dropFile": "or Drop a file here",
        "dxFileUploader-bytes": "bytes",
        "dxFileUploader-kb": "KB",
        "dxFileUploader-Mb": "MB",
        "dxFileUploader-Gb": "GB",
        "dxFileUploader-upload": "Upload",
        "dxFileUploader-uploaded": "Uploaded",
        "dxFileUploader-readyToUpload": "Ready to upload",
        "dxFileUploader-uploadAbortedMessage": "Upload cancelled",
        "dxFileUploader-uploadFailedMessage": "Upload failed",
        "dxFileUploader-invalidFileExtension": "File type is not allowed",
        "dxFileUploader-invalidMaxFileSize": "File is too large",
        "dxFileUploader-invalidMinFileSize": "File is too small",
        "dxRangeSlider-ariaFrom": "From",
        "dxRangeSlider-ariaTill": "Till",
        "dxSwitch-switchedOnText": "ON",
        "dxSwitch-switchedOffText": "OFF",
        "dxForm-optionalMark": "optional",
        "dxForm-requiredMessage": "{0} is required",
        "dxNumberBox-invalidValueMessage": "Value must be a number",
        "dxNumberBox-noDataText": "No data",
        "dxDataGrid-emptyHeaderWithColumnChooserText": "Use {0} to display columns",
        "dxDataGrid-emptyHeaderWithGroupPanelText": "Drag a column from the group panel here",
        "dxDataGrid-emptyHeaderWithColumnChooserAndGroupPanelText": "Use {0} or drag a column from the group panel",
        "dxDataGrid-emptyHeaderColumnChooserText": "column chooser",
        "dxDataGrid-columnChooserTitle": "Column Chooser",
        "dxDataGrid-columnChooserEmptyText": "Drag a column here to hide it",
        "dxDataGrid-groupContinuesMessage": "Continues on the next page",
        "dxDataGrid-groupContinuedMessage": "Continued from the previous page",
        "dxDataGrid-groupHeaderText": "Group by This Column",
        "dxDataGrid-ungroupHeaderText": "Ungroup",
        "dxDataGrid-ungroupAllText": "Ungroup All",
        "dxDataGrid-editingEditRow": "Edit",
        "dxDataGrid-editingSaveRowChanges": "Save",
        "dxDataGrid-editingCancelRowChanges": "Cancel",
        "dxDataGrid-editingDeleteRow": "Delete",
        "dxDataGrid-editingUndeleteRow": "Undelete",
        "dxDataGrid-editingConfirmDeleteMessage": "Are you sure you want to delete this record?",
        "dxDataGrid-validationCancelChanges": "Cancel changes",
        "dxDataGrid-groupPanelEmptyText": "Drag a column header here to group by that column",
        "dxDataGrid-noDataText": "No data",
        "dxDataGrid-searchPanelPlaceholder": "Search...",
        "dxDataGrid-filterRowShowAllText": "(All)",
        "dxDataGrid-filterRowResetOperationText": "Reset",
        "dxDataGrid-filterRowOperationEquals": "Equals",
        "dxDataGrid-filterRowOperationNotEquals": "Does not equal",
        "dxDataGrid-filterRowOperationLess": "Less than",
        "dxDataGrid-filterRowOperationLessOrEquals": "Less than or equal to",
        "dxDataGrid-filterRowOperationGreater": "Greater than",
        "dxDataGrid-filterRowOperationGreaterOrEquals": "Greater than or equal to",
        "dxDataGrid-filterRowOperationStartsWith": "Starts with",
        "dxDataGrid-filterRowOperationContains": "Contains",
        "dxDataGrid-filterRowOperationNotContains": "Does not contain",
        "dxDataGrid-filterRowOperationEndsWith": "Ends with",
        "dxDataGrid-filterRowOperationBetween": "Between",
        "dxDataGrid-filterRowOperationBetweenStartText": "Start",
        "dxDataGrid-filterRowOperationBetweenEndText": "End",
        "dxDataGrid-ariaSearchBox": "Search box",
        "dxDataGrid-applyFilterText": "Apply filter",
        "dxDataGrid-trueText": "true",
        "dxDataGrid-falseText": "false",
        "dxDataGrid-sortingAscendingText": "Sort Ascending",
        "dxDataGrid-sortingDescendingText": "Sort Descending",
        "dxDataGrid-sortingClearText": "Clear Sorting",
        "dxDataGrid-ariaNotSortedColumn": "Not sorted column",
        "dxDataGrid-ariaSortedAscendingColumn": "Column sorted in ascending order",
        "dxDataGrid-ariaSortedDescendingColumn": "Column sorted in descending order",
        "dxDataGrid-ariaSortIndex": "Sort index {0}",
        "dxDataGrid-editingSaveAllChanges": "Save changes",
        "dxDataGrid-editingCancelAllChanges": "Discard changes",
        "dxDataGrid-editingAddRow": "Add a row",
        "dxDataGrid-summaryMin": "Min: {0}",
        "dxDataGrid-summaryMinOtherColumn": "Min of {1} is {0}",
        "dxDataGrid-summaryMax": "Max: {0}",
        "dxDataGrid-summaryMaxOtherColumn": "Max of {1} is {0}",
        "dxDataGrid-summaryAvg": "Avg: {0}",
        "dxDataGrid-summaryAvgOtherColumn": "Avg of {1} is {0}",
        "dxDataGrid-summarySum": "Sum: {0}",
        "dxDataGrid-summarySumOtherColumn": "Sum of {1} is {0}",
        "dxDataGrid-summaryCount": "Count: {0}",
        "dxDataGrid-columnFixingFix": "Set Fixed Position",
        "dxDataGrid-columnFixingUnfix": "Unfix",
        "dxDataGrid-columnFixingLeftPosition": "Left",
        "dxDataGrid-columnFixingRightPosition": "Right",
        "dxDataGrid-columnFixingStickyPosition": "Sticky",
        "dxDataGrid-exportTo": "Export",
        "dxDataGrid-exportToExcel": "Export to Excel file",
        "dxDataGrid-exporting": "Exporting...",
        "dxDataGrid-excelFormat": "Excel file",
        "dxDataGrid-selectedRows": "Selected rows",
        "dxDataGrid-exportSelectedRows": "Export selected rows to {0}",
        "dxDataGrid-exportAll": "Export all data to {0}",
        "dxDataGrid-headerFilterLabel": "Filter options",
        "dxDataGrid-headerFilterIndicatorLabel": "Show filter options for column '{0}'",
        "dxDataGrid-headerFilterEmptyValue": "(Blanks)",
        "dxDataGrid-headerFilterOK": "OK",
        "dxDataGrid-headerFilterCancel": "Cancel",
        "dxDataGrid-ariaAdaptiveCollapse": "Hide additional data",
        "dxDataGrid-ariaAdaptiveExpand": "Display additional data",
        "dxDataGrid-ariaColumn": "Column",
        "dxDataGrid-ariaColumnHeader": "Column header",
        "dxDataGrid-ariaValue": "Value",
        "dxDataGrid-ariaError": "Error",
        "dxDataGrid-ariaRevertButton": "Press Escape to discard the changes",
        "dxDataGrid-ariaFilterCell": "Filter cell",
        "dxDataGrid-ariaCollapse": "Collapse",
        "dxDataGrid-ariaModifiedCell": "Modified",
        "dxDataGrid-ariaDeletedCell": "Deleted",
        "dxDataGrid-ariaEditableCell": "Editable",
        "dxDataGrid-ariaExpand": "Expand",
        "dxDataGrid-ariaCollapsedRow": "Collapsed row",
        "dxDataGrid-ariaExpandedRow": "Expanded row",
        "dxDataGrid-ariaDataGrid": "Data grid with {0} rows and {1} columns",
        "dxDataGrid-ariaSearchInGrid": "Search in the data grid",
        "dxDataGrid-ariaSelectAll": "Select all",
        "dxDataGrid-ariaSelectRow": "Select row",
        "dxDataGrid-ariaToolbar": "Data grid toolbar",
        "dxDataGrid-ariaEditForm": "Edit form",
        "dxDataGrid-filterBuilderPopupTitle": "Filter Builder",
        "dxDataGrid-filterPanelCreateFilter": "Create Filter",
        "dxDataGrid-filterPanelClearFilter": "Clear",
        "dxDataGrid-filterPanelFilterEnabledHint": "Enable the filter",
        "dxDataGrid-masterDetail": "Cell with details",
        "dxDataGrid-moveColumnToTheRight": "Move to the right",
        "dxDataGrid-moveColumnToTheLeft": "Move to the left",
        "dxTreeList-ariaTreeList": "Tree list with {0} rows and {1} columns",
        "dxTreeList-ariaExpandableInstruction": "Press Ctrl + right arrow to expand the focused node and Ctrl + left arrow to collapse it",
        "dxTreeList-ariaSearchInGrid": "Search in the tree list",
        "dxTreeList-ariaToolbar": "Tree list toolbar",
        "dxTreeList-editingAddRowToNode": "Add",
        "dxPager-infoText": "Page {0} of {1} ({2} items)",
        "dxPager-pagesCountText": "of",
        "dxPager-pageSize": "Items per page: {0}",
        "dxPager-pageSizesAllText": "All",
        "dxPager-page": "Page {0}",
        "dxPager-prevPage": "Previous page",
        "dxPager-nextPage": "Next page",
        "dxPager-ariaLabel": "Page navigation",
        "dxPager-ariaPageSize": "Page size",
        "dxPager-ariaPageNumber": "Page number",
        "dxPagination-infoText": "Page {0} of {1} ({2} items)",
        "dxPagination-pagesCountText": "of",
        "dxPagination-pageSize": "Items per page: {0}",
        "dxPagination-pageSizesAllText": "All",
        "dxPagination-page": "Page {0}",
        "dxPagination-prevPage": "Previous page",
        "dxPagination-nextPage": "Next page",
        "dxPagination-ariaLabel": "Page navigation",
        "dxPagination-ariaPageSize": "Page size",
        "dxPagination-ariaPageNumber": "Page number",
        "dxPivotGrid-grandTotal": "Grand Total",
        "dxPivotGrid-total": "{0} Total",
        "dxPivotGrid-fieldChooserTitle": "Field Chooser",
        "dxPivotGrid-showFieldChooser": "Show Field Chooser",
        "dxPivotGrid-expandAll": "Expand All",
        "dxPivotGrid-collapseAll": "Collapse All",
        "dxPivotGrid-sortColumnBySummary": 'Sort "{0}" by This Column',
        "dxPivotGrid-sortRowBySummary": 'Sort "{0}" by This Row',
        "dxPivotGrid-removeAllSorting": "Remove All Sorting",
        "dxPivotGrid-dataNotAvailable": "N/A",
        "dxPivotGrid-rowFields": "Row Fields",
        "dxPivotGrid-columnFields": "Column Fields",
        "dxPivotGrid-dataFields": "Data Fields",
        "dxPivotGrid-filterFields": "Filter Fields",
        "dxPivotGrid-allFields": "All Fields",
        "dxPivotGrid-columnFieldArea": "Drop Column Fields Here",
        "dxPivotGrid-dataFieldArea": "Drop Data Fields Here",
        "dxPivotGrid-rowFieldArea": "Drop Row Fields Here",
        "dxPivotGrid-filterFieldArea": "Drop Filter Fields Here",
        "dxScheduler-dateRange": "from {0} to {1}",
        "dxScheduler-ariaLabel": "Scheduler. {0} view: {1} with {2} appointments",
        "dxScheduler-ariaLabel-currentIndicator-present": "The current time indicator is visible in the view",
        "dxScheduler-ariaLabel-currentIndicator-not-present": "The current time indicator is not visible on the screen",
        "dxScheduler-appointmentAriaLabel-group": "Group: {0}",
        "dxScheduler-appointmentAriaLabel-recurring": "Recurring appointment",
        "dxScheduler-appointmentListAriaLabel": "Appointment list",
        "dxScheduler-editorLabelTitle": "Subject",
        "dxScheduler-editorLabelStartDate": "Start Date",
        "dxScheduler-editorLabelEndDate": "End Date",
        "dxScheduler-editorLabelDescription": "Description",
        "dxScheduler-editorLabelRecurrence": "Repeat",
        "dxScheduler-navigationToday": "Today",
        "dxScheduler-navigationPrevious": "Previous page",
        "dxScheduler-navigationNext": "Next page",
        "dxScheduler-openAppointment": "Open appointment",
        "dxScheduler-recurrenceNever": "Never",
        "dxScheduler-recurrenceMinutely": "Every minute",
        "dxScheduler-recurrenceHourly": "Hourly",
        "dxScheduler-recurrenceDaily": "Daily",
        "dxScheduler-recurrenceWeekly": "Weekly",
        "dxScheduler-recurrenceMonthly": "Monthly",
        "dxScheduler-recurrenceYearly": "Yearly",
        "dxScheduler-recurrenceRepeatEvery": "Repeat Every",
        "dxScheduler-recurrenceRepeatOn": "Repeat On",
        "dxScheduler-recurrenceEnd": "End repeat",
        "dxScheduler-recurrenceAfter": "After",
        "dxScheduler-recurrenceOn": "On",
        "dxScheduler-recurrenceUntilDateLabel": "Date when repeat ends",
        "dxScheduler-recurrenceOccurrenceLabel": "Number of occurrences",
        "dxScheduler-recurrenceRepeatMinutely": "minute(s)",
        "dxScheduler-recurrenceRepeatHourly": "hour(s)",
        "dxScheduler-recurrenceRepeatDaily": "day(s)",
        "dxScheduler-recurrenceRepeatWeekly": "week(s)",
        "dxScheduler-recurrenceRepeatMonthly": "month(s)",
        "dxScheduler-recurrenceRepeatYearly": "year(s)",
        "dxScheduler-switcherDay": "Day",
        "dxScheduler-switcherWeek": "Week",
        "dxScheduler-switcherWorkWeek": "Work Week",
        "dxScheduler-switcherMonth": "Month",
        "dxScheduler-switcherAgenda": "Agenda",
        "dxScheduler-switcherTimelineDay": "Timeline Day",
        "dxScheduler-switcherTimelineWeek": "Timeline Week",
        "dxScheduler-switcherTimelineWorkWeek": "Timeline Work Week",
        "dxScheduler-switcherTimelineMonth": "Timeline Month",
        "dxScheduler-recurrenceRepeatOnDate": "on date",
        "dxScheduler-recurrenceRepeatCount": "occurrence(s)",
        "dxScheduler-allDay": "All day",
        "dxScheduler-ariaEditForm": "Edit form",
        "dxScheduler-confirmRecurrenceEditTitle": "Edit Recurring Appointment",
        "dxScheduler-confirmRecurrenceDeleteTitle": "Delete Recurring Appointment",
        "dxScheduler-confirmRecurrenceEditMessage": "Do you want to edit only this appointment or the whole series?",
        "dxScheduler-confirmRecurrenceDeleteMessage": "Do you want to delete only this appointment or the whole series?",
        "dxScheduler-confirmRecurrenceEditSeries": "Edit series",
        "dxScheduler-confirmRecurrenceDeleteSeries": "Delete series",
        "dxScheduler-confirmRecurrenceEditOccurrence": "Edit appointment",
        "dxScheduler-confirmRecurrenceDeleteOccurrence": "Delete appointment",
        "dxScheduler-noTimezoneTitle": "No timezone",
        "dxScheduler-moreAppointments": "{0} more",
        "dxCalendar-currentDay": "Today",
        "dxCalendar-currentMonth": "Current month",
        "dxCalendar-currentYear": "Current year",
        "dxCalendar-currentYearRange": "Current year range",
        "dxCalendar-todayButtonText": "Today",
        "dxCalendar-ariaWidgetName": "Calendar",
        "dxCalendar-previousMonthButtonLabel": "Previous month",
        "dxCalendar-previousYearButtonLabel": "Previous year",
        "dxCalendar-previousDecadeButtonLabel": "Previous decade",
        "dxCalendar-previousCenturyButtonLabel": "Previous century",
        "dxCalendar-nextMonthButtonLabel": "Next month",
        "dxCalendar-nextYearButtonLabel": "Next year",
        "dxCalendar-nextDecadeButtonLabel": "Next decade",
        "dxCalendar-nextCenturyButtonLabel": "Next century",
        "dxCalendar-captionMonthLabel": "Month selection",
        "dxCalendar-captionYearLabel": "Year selection",
        "dxCalendar-captionDecadeLabel": "Decade selection",
        "dxCalendar-captionCenturyLabel": "Century selection",
        "dxCalendar-selectedDate": "The selected date is {0}",
        "dxCalendar-selectedDates": "The selected dates",
        "dxCalendar-selectedDateRange": "The selected date range is from {0} to {1}",
        "dxCalendar-selectedMultipleDateRange": "from {0} to {1}",
        "dxCalendar-selectedDateRangeCount": "There are {0} selected date ranges",
        "dxCalendar-readOnlyLabel": "Read-only calendar",
        "dxCardView-ariaSearchInGrid": "Search in the card view",
        "dxCardView-ariaHeaderItemLabel": "Field name {0}",
        "dxCardView-ariaHeaderItemSortingAscendingLabel": "Sorted in ascending order",
        "dxCardView-ariaHeaderItemSortingDescendingLabel": "Sorted in descending order",
        "dxCardView-ariaHeaderItemSortingIndexLabel": "Sort index {0}",
        "dxCardView-ariaHeaderHasHeaderFilterLabel": "Header filter applied",
        "dxCardView-ariaSelectCard": "Select card",
        "dxCardView-ariaCardView": "Card view with {0} cards. Each card has {1} fields",
        "dxCardView-ariaCard": "Card",
        "dxCardView-ariaEditableCard": "Editable card",
        "dxCardView-ariaCardPosition": "Row {0}, column {1}",
        "dxCardView-ariaSelectedCardState": "Selected",
        "dxCardView-ariaNotSelectedCardState": "Not selected",
        "dxCardView-selectAll": "Select all",
        "dxCardView-clearSelection": "Clear selection",
        "dxCardView-cardNoImageAriaLabel": "No image",
        "dxCardView-headerItemDropZoneText": "Drop the header item here",
        "dxCardView-emptyHeaderPanelText": "Use {0} to display columns",
        "dxCardView-emptyHeaderPanelColumnChooserText": "column chooser",
        "dxAvatar-defaultImageAlt": "Avatar",
        "dxChat-elementAriaLabel": "Chat",
        "dxChat-textareaPlaceholder": "Type a message",
        "dxChat-sendButtonAriaLabel": "Send",
        "dxChat-cancelEditingButtonAriaLabel": "Cancel",
        "dxChat-editingMessageCaption": "Edit Message",
        "dxChat-defaultUserName": "Unknown User",
        "dxChat-messageListAriaLabel": "Message list",
        "dxChat-alertListAriaLabel": "Error list",
        "dxChat-emptyListMessage": "There are no messages in this chat",
        "dxChat-emptyListPrompt": "Write your first message",
        "dxChat-typingMessageSingleUser": "{0} is typing...",
        "dxChat-typingMessageTwoUsers": "{0} and {1} are typing...",
        "dxChat-typingMessageThreeUsers": "{0}, {1} and {2} are typing...",
        "dxChat-typingMessageMultipleUsers": "{0} and others are typing...",
        "dxChat-editedMessageText": "Edited",
        "dxChat-editingEditMessage": "Edit",
        "dxChat-editingDeleteMessage": "Delete",
        "dxChat-editingDeleteConfirmText": "Are you sure you want to delete this message?",
        "dxChat-deletedMessageText": "This message was deleted",
        "dxChat-defaultImageAlt": "Image shared in chat",
        "dxColorView-ariaRed": "Red",
        "dxColorView-ariaGreen": "Green",
        "dxColorView-ariaBlue": "Blue",
        "dxColorView-ariaAlpha": "Transparency",
        "dxColorView-ariaHex": "Color code",
        "dxTagBox-selected": "{0} selected",
        "dxTagBox-allSelected": "All selected ({0})",
        "dxTagBox-moreSelected": "{0} more",
        "dxTagBox-tagRoleDescription": "Tag. Press the delete button to remove this tag",
        "dxTagBox-ariaRoleDescription": "Tag box",
        "vizExport-printingButtonText": "Print",
        "vizExport-titleMenuText": "Exporting/Printing",
        "vizExport-exportButtonText": "{0} file",
        "dxFilterBuilder-and": "And",
        "dxFilterBuilder-or": "Or",
        "dxFilterBuilder-notAnd": "Not And",
        "dxFilterBuilder-notOr": "Not Or",
        "dxFilterBuilder-addCondition": "Add Condition",
        "dxFilterBuilder-addGroup": "Add Group",
        "dxFilterBuilder-enterValueText": "<enter a value>",
        "dxFilterBuilder-filterOperationEquals": "Equals",
        "dxFilterBuilder-filterOperationNotEquals": "Does not equal",
        "dxFilterBuilder-filterOperationLess": "Is less than",
        "dxFilterBuilder-filterOperationLessOrEquals": "Is less than or equal to",
        "dxFilterBuilder-filterOperationGreater": "Is greater than",
        "dxFilterBuilder-filterOperationGreaterOrEquals": "Is greater than or equal to",
        "dxFilterBuilder-filterOperationStartsWith": "Starts with",
        "dxFilterBuilder-filterOperationContains": "Contains",
        "dxFilterBuilder-filterOperationNotContains": "Does not contain",
        "dxFilterBuilder-filterOperationEndsWith": "Ends with",
        "dxFilterBuilder-filterOperationIsBlank": "Is blank",
        "dxFilterBuilder-filterOperationIsNotBlank": "Is not blank",
        "dxFilterBuilder-filterOperationBetween": "Is between",
        "dxFilterBuilder-filterOperationAnyOf": "Is any of",
        "dxFilterBuilder-filterOperationNoneOf": "Is none of",
        "dxFilterBuilder-filterAriaRootElement": "Filter builder",
        "dxFilterBuilder-filterAriaGroupLevel": "Level {0}",
        "dxFilterBuilder-filterAriaGroupItem": "Group item",
        "dxFilterBuilder-filterAriaOperationButton": "Operation",
        "dxFilterBuilder-filterAriaAddButton": "Add",
        "dxFilterBuilder-filterAriaRemoveButton": "Remove {0}",
        "dxFilterBuilder-filterAriaItemField": "Item field",
        "dxFilterBuilder-filterAriaItemOperation": "Item operation",
        "dxFilterBuilder-filterAriaItemValue": "Item value",
        "dxHtmlEditor-dialogColorCaption": "Change Font Color",
        "dxHtmlEditor-dialogBackgroundCaption": "Change Background Color",
        "dxHtmlEditor-dialogLinkCaption": "Add Link",
        "dxHtmlEditor-dialogLinkUrlField": "URL",
        "dxHtmlEditor-dialogLinkTextField": "Text",
        "dxHtmlEditor-dialogLinkTargetField": "Open link in new window",
        "dxHtmlEditor-dialogImageCaption": "Add Image",
        "dxHtmlEditor-dialogImageUrlField": "URL",
        "dxHtmlEditor-dialogImageAltField": "Alternate text",
        "dxHtmlEditor-dialogImageWidthField": "Width (px)",
        "dxHtmlEditor-dialogImageHeightField": "Height (px)",
        "dxHtmlEditor-dialogInsertTableRowsField": "Rows",
        "dxHtmlEditor-dialogInsertTableColumnsField": "Columns",
        "dxHtmlEditor-dialogInsertTableCaption": "Insert Table",
        "dxHtmlEditor-dialogUpdateImageCaption": "Update Image",
        "dxHtmlEditor-dialogImageUpdateButton": "Update",
        "dxHtmlEditor-dialogImageAddButton": "Add",
        "dxHtmlEditor-dialogImageSpecifyUrl": "From the Web",
        "dxHtmlEditor-dialogImageSelectFile": "From This Device",
        "dxHtmlEditor-dialogImageKeepAspectRatio": "Keep Aspect Ratio",
        "dxHtmlEditor-dialogImageEncodeToBase64": "Encode to Base64",
        "dxHtmlEditor-heading": "Heading",
        "dxHtmlEditor-normalText": "Normal text",
        "dxHtmlEditor-background": "Background Color",
        "dxHtmlEditor-bold": "Bold",
        "dxHtmlEditor-color": "Font Color",
        "dxHtmlEditor-font": "Font",
        "dxHtmlEditor-italic": "Italic",
        "dxHtmlEditor-link": "Add Link",
        "dxHtmlEditor-image": "Add Image",
        "dxHtmlEditor-size": "Size",
        "dxHtmlEditor-strike": "Strikethrough",
        "dxHtmlEditor-subscript": "Subscript",
        "dxHtmlEditor-superscript": "Superscript",
        "dxHtmlEditor-underline": "Underline",
        "dxHtmlEditor-blockquote": "Blockquote",
        "dxHtmlEditor-header": "Header",
        "dxHtmlEditor-increaseIndent": "Increase Indent",
        "dxHtmlEditor-decreaseIndent": "Decrease Indent",
        "dxHtmlEditor-orderedList": "Ordered List",
        "dxHtmlEditor-bulletList": "Bullet List",
        "dxHtmlEditor-alignLeft": "Align Left",
        "dxHtmlEditor-alignCenter": "Align Center",
        "dxHtmlEditor-alignRight": "Align Right",
        "dxHtmlEditor-alignJustify": "Align Justify",
        "dxHtmlEditor-codeBlock": "Code Block",
        "dxHtmlEditor-variable": "Add Variable",
        "dxHtmlEditor-undo": "Undo",
        "dxHtmlEditor-redo": "Redo",
        "dxHtmlEditor-clear": "Clear Formatting",
        "dxHtmlEditor-insertTable": "Insert Table",
        "dxHtmlEditor-insertHeaderRow": "Insert Header Row",
        "dxHtmlEditor-insertRowAbove": "Insert Row Above",
        "dxHtmlEditor-insertRowBelow": "Insert Row Below",
        "dxHtmlEditor-insertColumnLeft": "Insert Column Left",
        "dxHtmlEditor-insertColumnRight": "Insert Column Right",
        "dxHtmlEditor-deleteColumn": "Delete Column",
        "dxHtmlEditor-deleteRow": "Delete Row",
        "dxHtmlEditor-deleteTable": "Delete Table",
        "dxHtmlEditor-cellProperties": "Cell Properties",
        "dxHtmlEditor-tableProperties": "Table Properties",
        "dxHtmlEditor-insert": "Insert",
        "dxHtmlEditor-delete": "Delete",
        "dxHtmlEditor-border": "Border",
        "dxHtmlEditor-style": "Style",
        "dxHtmlEditor-width": "Width",
        "dxHtmlEditor-height": "Height",
        "dxHtmlEditor-borderColor": "Color",
        "dxHtmlEditor-borderWidth": "Border Width",
        "dxHtmlEditor-tableBackground": "Background",
        "dxHtmlEditor-dimensions": "Dimensions",
        "dxHtmlEditor-alignment": "Alignment",
        "dxHtmlEditor-horizontal": "Horizontal",
        "dxHtmlEditor-vertical": "Vertical",
        "dxHtmlEditor-paddingVertical": "Vertical Padding",
        "dxHtmlEditor-paddingHorizontal": "Horizontal Padding",
        "dxHtmlEditor-pixels": "Pixels",
        "dxHtmlEditor-list": "List",
        "dxHtmlEditor-ordered": "Ordered",
        "dxHtmlEditor-bullet": "Bullet",
        "dxHtmlEditor-align": "Align",
        "dxHtmlEditor-center": "Center",
        "dxHtmlEditor-left": "Left",
        "dxHtmlEditor-right": "Right",
        "dxHtmlEditor-indent": "Indent",
        "dxHtmlEditor-justify": "Justify",
        "dxHtmlEditor-borderStyleNone": "none",
        "dxHtmlEditor-borderStyleHidden": "hidden",
        "dxHtmlEditor-borderStyleDotted": "dotted",
        "dxHtmlEditor-borderStyleDashed": "dashed",
        "dxHtmlEditor-borderStyleSolid": "solid",
        "dxHtmlEditor-borderStyleDouble": "double",
        "dxHtmlEditor-borderStyleGroove": "groove",
        "dxHtmlEditor-borderStyleRidge": "ridge",
        "dxHtmlEditor-borderStyleInset": "inset",
        "dxHtmlEditor-borderStyleOutset": "outset",
        "dxHtmlEditor-aiDialogTitle": "AI Assistant",
        "dxHtmlEditor-aiDialogError": "Something went wrong. Please try again.",
        "dxHtmlEditor-aiDialogCanceled": "Generation canceled",
        "dxHtmlEditor-aiReplace": "Replace",
        "dxHtmlEditor-aiInsertAbove": "Insert above",
        "dxHtmlEditor-aiInsertBelow": "Insert below",
        "dxHtmlEditor-aiCopy": "Copy",
        "dxHtmlEditor-aiRegenerate": "Regenerate",
        "dxHtmlEditor-aiGenerate": "Generate",
        "dxHtmlEditor-aiCancel": "Cancel",
        "dxHtmlEditor-aiToolbarItemAriaLabel": "AI Assistant toolbar item",
        "dxHtmlEditor-aiResultTextAreaAriaLabel": "AI Assistant result",
        "dxHtmlEditor-aiAskPlaceholder": "Ask AI to modify text",
        "dxFileManager-newDirectoryName": "Untitled directory",
        "dxFileManager-rootDirectoryName": "Files",
        "dxFileManager-errorNoAccess": "Access Denied. Operation could not be completed.",
        "dxFileManager-errorDirectoryExistsFormat": "Directory '{0}' already exists.",
        "dxFileManager-errorFileExistsFormat": "File '{0}' already exists.",
        "dxFileManager-errorFileNotFoundFormat": "File '{0}' not found.",
        "dxFileManager-errorDirectoryNotFoundFormat": "Directory '{0}' not found.",
        "dxFileManager-errorWrongFileExtension": "File extension is not allowed.",
        "dxFileManager-errorMaxFileSizeExceeded": "File size exceeds the maximum allowed size.",
        "dxFileManager-errorInvalidSymbols": "This name contains invalid characters.",
        "dxFileManager-errorDefault": "Unspecified error.",
        "dxFileManager-errorDirectoryOpenFailed": "The directory cannot be opened",
        "dxFileManager-commandCreate": "New directory",
        "dxFileManager-commandRename": "Rename",
        "dxFileManager-commandMove": "Move to",
        "dxFileManager-commandCopy": "Copy to",
        "dxFileManager-commandDelete": "Delete",
        "dxFileManager-commandDownload": "Download",
        "dxFileManager-commandUpload": "Upload files",
        "dxFileManager-commandRefresh": "Refresh",
        "dxFileManager-commandThumbnails": "Thumbnails View",
        "dxFileManager-commandDetails": "Details View",
        "dxFileManager-commandClearSelection": "Clear selection",
        "dxFileManager-commandShowNavPane": "Toggle navigation pane",
        "dxFileManager-dialogDirectoryChooserMoveTitle": "Move to",
        "dxFileManager-dialogDirectoryChooserMoveButtonText": "Move",
        "dxFileManager-dialogDirectoryChooserCopyTitle": "Copy to",
        "dxFileManager-dialogDirectoryChooserCopyButtonText": "Copy",
        "dxFileManager-dialogRenameItemTitle": "Rename",
        "dxFileManager-dialogRenameItemButtonText": "Save",
        "dxFileManager-dialogCreateDirectoryTitle": "New directory",
        "dxFileManager-dialogCreateDirectoryButtonText": "Create",
        "dxFileManager-dialogDeleteItemTitle": "Delete",
        "dxFileManager-dialogDeleteItemButtonText": "Delete",
        "dxFileManager-dialogDeleteItemSingleItemConfirmation": "Are you sure you want to delete {0}?",
        "dxFileManager-dialogDeleteItemMultipleItemsConfirmation": "Are you sure you want to delete {0} items?",
        "dxFileManager-dialogButtonCancel": "Cancel",
        "dxFileManager-editingCreateSingleItemProcessingMessage": "Creating a directory inside {0}",
        "dxFileManager-editingCreateSingleItemSuccessMessage": "Created a directory inside {0}",
        "dxFileManager-editingCreateSingleItemErrorMessage": "Directory was not created",
        "dxFileManager-editingCreateCommonErrorMessage": "Directory was not created",
        "dxFileManager-editingRenameSingleItemProcessingMessage": "Renaming an item inside {0}",
        "dxFileManager-editingRenameSingleItemSuccessMessage": "Renamed an item inside {0}",
        "dxFileManager-editingRenameSingleItemErrorMessage": "Item was not renamed",
        "dxFileManager-editingRenameCommonErrorMessage": "Item was not renamed",
        "dxFileManager-editingDeleteSingleItemProcessingMessage": "Deleting an item from {0}",
        "dxFileManager-editingDeleteMultipleItemsProcessingMessage": "Deleting {0} items from {1}",
        "dxFileManager-editingDeleteSingleItemSuccessMessage": "Deleted an item from {0}",
        "dxFileManager-editingDeleteMultipleItemsSuccessMessage": "Deleted {0} items from {1}",
        "dxFileManager-editingDeleteSingleItemErrorMessage": "Item was not deleted",
        "dxFileManager-editingDeleteMultipleItemsErrorMessage": "{0} items were not deleted",
        "dxFileManager-editingDeleteCommonErrorMessage": "Some items were not deleted",
        "dxFileManager-editingMoveSingleItemProcessingMessage": "Moving an item to {0}",
        "dxFileManager-editingMoveMultipleItemsProcessingMessage": "Moving {0} items to {1}",
        "dxFileManager-editingMoveSingleItemSuccessMessage": "Moved an item to {0}",
        "dxFileManager-editingMoveMultipleItemsSuccessMessage": "Moved {0} items to {1}",
        "dxFileManager-editingMoveSingleItemErrorMessage": "Item was not moved",
        "dxFileManager-editingMoveMultipleItemsErrorMessage": "{0} items were not moved",
        "dxFileManager-editingMoveCommonErrorMessage": "Some items were not moved",
        "dxFileManager-editingCopySingleItemProcessingMessage": "Copying an item to {0}",
        "dxFileManager-editingCopyMultipleItemsProcessingMessage": "Copying {0} items to {1}",
        "dxFileManager-editingCopySingleItemSuccessMessage": "Copied an item to {0}",
        "dxFileManager-editingCopyMultipleItemsSuccessMessage": "Copied {0} items to {1}",
        "dxFileManager-editingCopySingleItemErrorMessage": "Item was not copied",
        "dxFileManager-editingCopyMultipleItemsErrorMessage": "{0} items were not copied",
        "dxFileManager-editingCopyCommonErrorMessage": "Some items were not copied",
        "dxFileManager-editingUploadSingleItemProcessingMessage": "Uploading an item to {0}",
        "dxFileManager-editingUploadMultipleItemsProcessingMessage": "Uploading {0} items to {1}",
        "dxFileManager-editingUploadSingleItemSuccessMessage": "Uploaded an item to {0}",
        "dxFileManager-editingUploadMultipleItemsSuccessMessage": "Uploaded {0} items to {1}",
        "dxFileManager-editingUploadSingleItemErrorMessage": "Item was not uploaded",
        "dxFileManager-editingUploadMultipleItemsErrorMessage": "{0} items were not uploaded",
        "dxFileManager-editingUploadCanceledMessage": "Canceled",
        "dxFileManager-editingDownloadSingleItemErrorMessage": "Item was not downloaded",
        "dxFileManager-editingDownloadMultipleItemsErrorMessage": "{0} items were not downloaded",
        "dxFileManager-listDetailsColumnCaptionName": "Name",
        "dxFileManager-listDetailsColumnCaptionDateModified": "Date Modified",
        "dxFileManager-listDetailsColumnCaptionFileSize": "File Size",
        "dxFileManager-listThumbnailsTooltipTextSize": "Size",
        "dxFileManager-listThumbnailsTooltipTextDateModified": "Date Modified",
        "dxFileManager-notificationProgressPanelTitle": "Progress",
        "dxFileManager-notificationProgressPanelEmptyListText": "No operations",
        "dxFileManager-notificationProgressPanelOperationCanceled": "Canceled",
        "dxDiagram-categoryGeneral": "General",
        "dxDiagram-categoryFlowchart": "Flowchart",
        "dxDiagram-categoryOrgChart": "Org Chart",
        "dxDiagram-categoryContainers": "Containers",
        "dxDiagram-categoryCustom": "Custom",
        "dxDiagram-commandExportToSvg": "Export to SVG",
        "dxDiagram-commandExportToPng": "Export to PNG",
        "dxDiagram-commandExportToJpg": "Export to JPEG",
        "dxDiagram-commandUndo": "Undo",
        "dxDiagram-commandRedo": "Redo",
        "dxDiagram-commandFontName": "Font Name",
        "dxDiagram-commandFontSize": "Font Size",
        "dxDiagram-commandBold": "Bold",
        "dxDiagram-commandItalic": "Italic",
        "dxDiagram-commandUnderline": "Underline",
        "dxDiagram-commandTextColor": "Font Color",
        "dxDiagram-commandLineColor": "Line Color",
        "dxDiagram-commandLineWidth": "Line Width",
        "dxDiagram-commandLineStyle": "Line Style",
        "dxDiagram-commandLineStyleSolid": "Solid",
        "dxDiagram-commandLineStyleDotted": "Dotted",
        "dxDiagram-commandLineStyleDashed": "Dashed",
        "dxDiagram-commandFillColor": "Fill Color",
        "dxDiagram-commandAlignLeft": "Align Left",
        "dxDiagram-commandAlignCenter": "Align Center",
        "dxDiagram-commandAlignRight": "Align Right",
        "dxDiagram-commandConnectorLineType": "Connector Line Type",
        "dxDiagram-commandConnectorLineStraight": "Straight",
        "dxDiagram-commandConnectorLineOrthogonal": "Orthogonal",
        "dxDiagram-commandConnectorLineStart": "Connector Line Start",
        "dxDiagram-commandConnectorLineEnd": "Connector Line End",
        "dxDiagram-commandConnectorLineNone": "None",
        "dxDiagram-commandConnectorLineArrow": "Arrow",
        "dxDiagram-commandFullscreen": "Full Screen",
        "dxDiagram-commandUnits": "Units",
        "dxDiagram-commandPageSize": "Page Size",
        "dxDiagram-commandPageOrientation": "Page Orientation",
        "dxDiagram-commandPageOrientationLandscape": "Landscape",
        "dxDiagram-commandPageOrientationPortrait": "Portrait",
        "dxDiagram-commandPageColor": "Page Color",
        "dxDiagram-commandShowGrid": "Show Grid",
        "dxDiagram-commandSnapToGrid": "Snap to Grid",
        "dxDiagram-commandGridSize": "Grid Size",
        "dxDiagram-commandZoomLevel": "Zoom Level",
        "dxDiagram-commandAutoZoom": "Auto Zoom",
        "dxDiagram-commandFitToContent": "Fit to Content",
        "dxDiagram-commandFitToWidth": "Fit to Width",
        "dxDiagram-commandAutoZoomByContent": "Auto Zoom by Content",
        "dxDiagram-commandAutoZoomByWidth": "Auto Zoom by Width",
        "dxDiagram-commandSimpleView": "Simple View",
        "dxDiagram-commandCut": "Cut",
        "dxDiagram-commandCopy": "Copy",
        "dxDiagram-commandPaste": "Paste",
        "dxDiagram-commandSelectAll": "Select All",
        "dxDiagram-commandDelete": "Delete",
        "dxDiagram-commandBringToFront": "Bring to Front",
        "dxDiagram-commandSendToBack": "Send to Back",
        "dxDiagram-commandLock": "Lock",
        "dxDiagram-commandUnlock": "Unlock",
        "dxDiagram-commandInsertShapeImage": "Insert Image...",
        "dxDiagram-commandEditShapeImage": "Change Image...",
        "dxDiagram-commandDeleteShapeImage": "Delete Image",
        "dxDiagram-commandLayoutLeftToRight": "Left-to-right",
        "dxDiagram-commandLayoutRightToLeft": "Right-to-left",
        "dxDiagram-commandLayoutTopToBottom": "Top-to-bottom",
        "dxDiagram-commandLayoutBottomToTop": "Bottom-to-top",
        "dxDiagram-unitIn": "in",
        "dxDiagram-unitCm": "cm",
        "dxDiagram-unitPx": "px",
        "dxDiagram-dialogButtonOK": "OK",
        "dxDiagram-dialogButtonCancel": "Cancel",
        "dxDiagram-dialogInsertShapeImageTitle": "Insert Image",
        "dxDiagram-dialogEditShapeImageTitle": "Change Image",
        "dxDiagram-dialogEditShapeImageSelectButton": "Select image",
        "dxDiagram-dialogEditShapeImageLabelText": "or drop a file here",
        "dxDiagram-uiExport": "Export",
        "dxDiagram-uiProperties": "Properties",
        "dxDiagram-uiSettings": "Settings",
        "dxDiagram-uiShowToolbox": "Show Toolbox",
        "dxDiagram-uiSearch": "Search",
        "dxDiagram-uiStyle": "Style",
        "dxDiagram-uiLayout": "Layout",
        "dxDiagram-uiLayoutTree": "Tree",
        "dxDiagram-uiLayoutLayered": "Layered",
        "dxDiagram-uiDiagram": "Diagram",
        "dxDiagram-uiText": "Text",
        "dxDiagram-uiObject": "Object",
        "dxDiagram-uiConnector": "Connector",
        "dxDiagram-uiPage": "Page",
        "dxDiagram-shapeText": "Text",
        "dxDiagram-shapeRectangle": "Rectangle",
        "dxDiagram-shapeEllipse": "Ellipse",
        "dxDiagram-shapeCross": "Cross",
        "dxDiagram-shapeTriangle": "Triangle",
        "dxDiagram-shapeDiamond": "Diamond",
        "dxDiagram-shapeHeart": "Heart",
        "dxDiagram-shapePentagon": "Pentagon",
        "dxDiagram-shapeHexagon": "Hexagon",
        "dxDiagram-shapeOctagon": "Octagon",
        "dxDiagram-shapeStar": "Star",
        "dxDiagram-shapeArrowLeft": "Left Arrow",
        "dxDiagram-shapeArrowUp": "Up Arrow",
        "dxDiagram-shapeArrowRight": "Right Arrow",
        "dxDiagram-shapeArrowDown": "Down Arrow",
        "dxDiagram-shapeArrowUpDown": "Up Down Arrow",
        "dxDiagram-shapeArrowLeftRight": "Left Right Arrow",
        "dxDiagram-shapeProcess": "Process",
        "dxDiagram-shapeDecision": "Decision",
        "dxDiagram-shapeTerminator": "Terminator",
        "dxDiagram-shapePredefinedProcess": "Predefined Process",
        "dxDiagram-shapeDocument": "Document",
        "dxDiagram-shapeMultipleDocuments": "Multiple Documents",
        "dxDiagram-shapeManualInput": "Manual Input",
        "dxDiagram-shapePreparation": "Preparation",
        "dxDiagram-shapeData": "Data",
        "dxDiagram-shapeDatabase": "Database",
        "dxDiagram-shapeHardDisk": "Hard Disk",
        "dxDiagram-shapeInternalStorage": "Internal Storage",
        "dxDiagram-shapePaperTape": "Paper Tape",
        "dxDiagram-shapeManualOperation": "Manual Operation",
        "dxDiagram-shapeDelay": "Delay",
        "dxDiagram-shapeStoredData": "Stored Data",
        "dxDiagram-shapeDisplay": "Display",
        "dxDiagram-shapeMerge": "Merge",
        "dxDiagram-shapeConnector": "Connector",
        "dxDiagram-shapeOr": "Or",
        "dxDiagram-shapeSummingJunction": "Summing Junction",
        "dxDiagram-shapeContainerDefaultText": "Container",
        "dxDiagram-shapeVerticalContainer": "Vertical Container",
        "dxDiagram-shapeHorizontalContainer": "Horizontal Container",
        "dxDiagram-shapeCardDefaultText": "Person's Name",
        "dxDiagram-shapeCardWithImageOnLeft": "Card with Image on the Left",
        "dxDiagram-shapeCardWithImageOnTop": "Card with Image on the Top",
        "dxDiagram-shapeCardWithImageOnRight": "Card with Image on the Right",
        "dxGantt-dialogTitle": "Title",
        "dxGantt-dialogStartTitle": "Start",
        "dxGantt-dialogEndTitle": "End",
        "dxGantt-dialogProgressTitle": "Progress",
        "dxGantt-dialogResourcesTitle": "Resources",
        "dxGantt-dialogResourceManagerTitle": "Resource Manager",
        "dxGantt-dialogTaskDetailsTitle": "Task Details",
        "dxGantt-dialogEditResourceListHint": "Edit Resource List",
        "dxGantt-dialogEditNoResources": "No resources",
        "dxGantt-dialogButtonAdd": "Add",
        "dxGantt-contextMenuNewTask": "New Task",
        "dxGantt-contextMenuNewSubtask": "New Subtask",
        "dxGantt-contextMenuDeleteTask": "Delete Task",
        "dxGantt-contextMenuDeleteDependency": "Delete Dependency",
        "dxGantt-dialogTaskDeleteConfirmation": "Deleting a task also deletes all its dependencies and subtasks. Are you sure you want to delete this task?",
        "dxGantt-dialogDependencyDeleteConfirmation": "Are you sure you want to delete the dependency from the task?",
        "dxGantt-dialogResourcesDeleteConfirmation": "Deleting a resource also deletes it from tasks to which this resource is assigned. Are you sure you want to delete these resources? Resources: {0}",
        "dxGantt-dialogConstraintCriticalViolationMessage": "The task you are attempting to move is linked to a second task by a dependency relation. This change would conflict with dependency rules. How would you like to proceed?",
        "dxGantt-dialogConstraintViolationMessage": "The task you are attempting to move is linked to a second task by a dependency relation. How would you like to proceed?",
        "dxGantt-dialogCancelOperationMessage": "Cancel the operation",
        "dxGantt-dialogDeleteDependencyMessage": "Delete the dependency",
        "dxGantt-dialogMoveTaskAndKeepDependencyMessage": "Move the task and keep the dependency",
        "dxGantt-dialogConstraintCriticalViolationSeveralTasksMessage": "The task you are attempting to move is linked to another tasks by dependency relations. This change would conflict with dependency rules. How would you like to proceed?",
        "dxGantt-dialogConstraintViolationSeveralTasksMessage": "The task you are attempting to move is linked to another tasks by dependency relations. How would you like to proceed?",
        "dxGantt-dialogDeleteDependenciesMessage": "Delete the dependency relations",
        "dxGantt-dialogMoveTaskAndKeepDependenciesMessage": "Move the task and keep the dependencies",
        "dxGantt-undo": "Undo",
        "dxGantt-redo": "Redo",
        "dxGantt-expandAll": "Expand All",
        "dxGantt-collapseAll": "Collapse All",
        "dxGantt-addNewTask": "Add New Task",
        "dxGantt-deleteSelectedTask": "Delete Selected Task",
        "dxGantt-zoomIn": "Zoom In",
        "dxGantt-zoomOut": "Zoom Out",
        "dxGantt-fullScreen": "Full Screen",
        "dxGantt-quarter": "Q{0}",
        "dxGantt-sortingAscendingText": "Sort Ascending",
        "dxGantt-sortingDescendingText": "Sort Descending",
        "dxGantt-sortingClearText": "Clear Sorting",
        "dxGantt-showResources": "Show Resources",
        "dxGantt-showDependencies": "Show Dependencies",
        "dxGantt-dialogStartDateValidation": "Start date must be after {0}",
        "dxGantt-dialogEndDateValidation": "End date must be after {0}",
        "dxGallery-itemName": "Gallery item",
        "dxMultiView-elementAriaRoleDescription": "MultiView",
        "dxMultiView-elementAriaLabel": "Use the arrow keys or swipe to navigate between views",
        "dxMultiView-itemAriaRoleDescription": "View",
        "dxMultiView-itemAriaLabel": "{0} of {1}",
        "dxSplitter-resizeHandleAriaLabel": "Split bar",
        "dxSplitter-resizeHandleAriaRoleDescription": "Separator",
        "dxStepper-optionalMark": "(Optional)"
    }
};
var gI = function(e) {
        return e == null ? "" : String(e)
    },
    ig = function(e) {
        return gI(e).charAt(0).toUpperCase() + e.substr(1)
    },
    sg = function(e) {
        return gI(e).replace(/([a-z\d])([A-Z])/g, "$1 $2").split(/[\s_-]+/)
    },
    ag = function(e) {
        return oo(sg(e), function(t) {
            return t.toLowerCase()
        }).join("-")
    },
    uF = function(e) {
        return ag(e).replace(/-/g, "_")
    },
    dF = function(e, t) {
        return oo(sg(e), function(n, r) {
            return n = n.toLowerCase(), (t || r > 0) && (n = ig(n)), n
        }).join("")
    },
    cg = function(e) {
        return ig(ag(e).replace(/-/g, " "))
    },
    fF = function(e) {
        return oo(sg(e), function(t) {
            return ig(t.toLowerCase())
        }).join(" ")
    },
    pF = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
    hF = function(e) {
        let t = [],
            n, r, o = !1,
            i = !1;
        for (n = 0; n < e.length; n++) r = e.charAt(n), i = r === r.toUpperCase() && r !== "-" && r !== ")" && r !== "/" || r in pF, r === "_" || r === "." ? (r = " ", i = !0) : n === 0 ? (r = r.toUpperCase(), i = !0) : !o && i && t.length > 0 && t.push(" "), t.push(r), o = i;
        return t.join("")
    },
    XQ = {
        dasherize: ag,
        underscore: uF,
        camelize: dF,
        humanize: cg,
        titleize: fF,
        captionize: hF
    };
var mF = Te(!0, {}, mI),
    gF = (e, t) => {
        var n;
        return e[t] || t ? .toLowerCase && ((n = Object.entries(e).find(r => {
            let [o] = r;
            return o.toLowerCase() === t.toLowerCase()
        })) === null || n === void 0 ? void 0 : n[1]) || {}
    },
    lg = {},
    EF = fn({
        engine: () => "base",
        _dictionary: mF,
        load(e) {
            Te(!0, this._dictionary, e)
        },
        _localizablePrefix: "@",
        setup(e) {
            this._localizablePrefix = e
        },
        localizeString(e) {
            let t = this,
                n = new RegExp(`(^|[^a-zA-Z_0-9${t._localizablePrefix}-]+)(${t._localizablePrefix}{1,2})([a-zA-Z_0-9-]+)`, "g"),
                r = t._localizablePrefix + t._localizablePrefix;
            return e.replace(n, (o, i, s, a) => {
                let c = t._localizablePrefix + a,
                    l;
                return s !== r && (l = t.format(a)), l || (lg[a] = cg(a)), i + (l || c)
            })
        },
        getMessagesByLocales() {
            return this._dictionary
        },
        getDictionary(e) {
            return e ? lg : Te({}, lg, this.getMessagesByLocales()[Ie.locale()])
        },
        getFormatter(e) {
            return this._getFormatterBase(e) || this._getFormatterBase(e, "en")
        },
        _getFormatterBase(e, t) {
            let n = Ie.getValueByClosestLocale(r => gF(this._dictionary, r)[e]);
            if (n) return function() {
                let r = arguments.length === 1 && Array.isArray(arguments[0]) ? arguments[0].slice(0) : Array.prototype.slice.call(arguments, 0);
                return r.unshift(n), ui.apply(this, r)
            }
        },
        format(e) {
            let t = this.getFormatter(e),
                n = Array.prototype.slice.call(arguments, 1);
            return t ? .apply(this, n) || ""
        }
    }),
    la = EF;
var yF = Ie.locale.bind(Ie),
    vF = la.load.bind(la),
    DF = la.format.bind(la),
    _F = St.format.bind(St),
    xF = St.parse.bind(St),
    CF = ca.format.bind(ca),
    IF = ca.parse.bind(ca);
var yZ = (() => {
    class e {
        constructor() {
            this.loaderSubject = new ye(!1), this.isLoading$ = this.loaderSubject.asObservable().pipe(dd())
        }
        show() {
            this.loaderSubject.value || this.loaderSubject.next(!0)
        }
        hide() {
            this.loaderSubject.value && this.loaderSubject.next(!1)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)
            }
        }
        static {
            this.\u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var Un = {
        PAYMENT: "payment",
        BULK_PAYMENT: "bulk_payment",
        SEND_REVIEW: "send_review",
        DELIVERY: "delivery",
        JOB_ASSIGNEE: "job_assignee",
        TASK: "task",
        JOB_COMMENT: "job_comment",
        JOB_INVOICE: "job_invoice",
        QUOTATION: "quotation"
    },
    Bn = {
        CUSTOMER: "customer",
        EMPLOYEE: "employee"
    },
    TF = {
        sms: {
            key: "sms",
            i18n: "common_sms",
            icon: "fa-thin fa-comment",
            iconClass: "text-muted",
            label: "SMS",
            color: "#f97316"
        },
        whatsapp: {
            key: "whatsapp",
            i18n: "common_whatsapp",
            icon: "fa-brands fa-whatsapp",
            iconClass: "text-success",
            label: "WhatsApp",
            color: "#25d366"
        },
        email: {
            key: "email",
            i18n: "common_email",
            icon: "fa-thin fa-envelope",
            iconClass: "text-muted",
            label: "Email",
            color: "#6366f1"
        },
        push: {
            key: "push",
            i18n: "common_push",
            icon: "fa-thin fa-mobile-screen-button",
            iconClass: "text-muted",
            label: "Push",
            color: "#8b5cf6"
        }
    },
    Xe = {
        QUOTATION_VIEWED: "push_quotation_viewed",
        SELF_CHECKIN_CREATED: "push_self_checkin_created",
        PAYMENT_RECEIVED: "push_payment_received",
        EXPENSE_ADDED: "push_expense_added",
        TASK_STATUS_CHANGED: "push_task_status_changed",
        QUOTATION_DECISION: "push_quotation_decision",
        CUSTOMER_COMMENT: "push_customer_comment",
        DAILY_REPORT: "push_daily_report",
        JOB_ASSIGNED: "push_job_assigned",
        TASK_ASSIGNED: "push_task_assigned",
        PICKUP_ASSIGNED: "push_pickup_assigned",
        DAILY_QUEUE: "push_daily_queue",
        LARGE_PAYMENT_MIN_AMOUNT: "large_payment_min_amount",
        DAILY_QUEUE_LOCAL_HOUR: "daily_queue_local_hour"
    },
    SF = "notification_default_";

function DZ(e, t) {
    return `${SF}${e}_${t}`
}
var _Z = Object.values(TF),
    xZ = [{
        key: Un.PAYMENT,
        recipient: Bn.CUSTOMER,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.BULK_PAYMENT,
        recipient: Bn.CUSTOMER,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.SEND_REVIEW,
        recipient: Bn.CUSTOMER,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.DELIVERY,
        recipient: Bn.CUSTOMER,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.JOB_ASSIGNEE,
        recipient: Bn.EMPLOYEE,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.TASK,
        recipient: Bn.EMPLOYEE,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.JOB_COMMENT,
        recipient: Bn.EMPLOYEE,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.JOB_INVOICE,
        recipient: Bn.CUSTOMER,
        channels: ["sms", "whatsapp", "email", "push"]
    }, {
        key: Un.QUOTATION,
        recipient: Bn.CUSTOMER,
        channels: ["sms", "whatsapp", "email", "push"]
    }],
    CZ = [{
        key: Xe.QUOTATION_VIEWED,
        tag: !0
    }, {
        key: Xe.SELF_CHECKIN_CREATED
    }],
    IZ = [{
        toggle: Xe.PAYMENT_RECEIVED,
        amount: Xe.LARGE_PAYMENT_MIN_AMOUNT
    }],
    TZ = [{
        key: Xe.EXPENSE_ADDED
    }, {
        key: Xe.TASK_STATUS_CHANGED
    }],
    SZ = [{
        key: Xe.QUOTATION_DECISION
    }, {
        key: Xe.CUSTOMER_COMMENT
    }],
    bZ = [{
        key: Xe.JOB_ASSIGNED
    }, {
        key: Xe.TASK_ASSIGNED
    }, {
        key: Xe.PICKUP_ASSIGNED
    }],
    wZ = Array.from({
        length: 24
    }, (e, t) => ({
        value: t,
        label: `${String(t).padStart(2,"0")}:00`
    })),
    ug = Object.values(Xe),
    AZ = ug.filter(e => e.startsWith("push_")),
    MZ = ug.filter(e => e.endsWith("_local_hour")),
    NZ = ug.filter(e => !e.startsWith("push_") && !e.endsWith("_local_hour")),
    RZ = {
        [Xe.LARGE_PAYMENT_MIN_AMOUNT]: 5e3,
        [Xe.DAILY_QUEUE_LOCAL_HOUR]: 9
    };
var $u = "/api/",
    Ei = window.location.origin,
    bF = window.location.hostname,
    fg = bF.endsWith(ro.domainName),
    ua = "";
fg && Ei.includes(".") && (ua = Ei.substring(Ei.indexOf("/") + 2, Ei.indexOf(".")), ua = ua !== "" ? ua + "." : "");
var yI = fg ? `${window.location.protocol}//${ua}${ro.baseUrl+$u}` : `${Ei}${$u}`,
    LZ = "https://accounts.google.com/o/oauth2/v2/auth",
    kZ = fg ? `${window.location.protocol}//${ro.baseUrl+$u}` : `${Ei}${$u}`,
    FZ = "yyyy-MM-ddTHH:mm:ss",
    UZ = "dd-MMM-yyyy hh:mm a",
    BZ = "register",
    jZ = "auth/",
    HZ = "jobs",
    pg = "customers",
    VZ = "forgetUser",
    $Z = "contacts",
    hg = "employees",
    GZ = "roles",
    mg = "leads",
    WZ = "leadSources",
    zZ = "leadStatuses",
    qZ = "deviceTypes",
    KZ = "jobTypes",
    YZ = "sales",
    JZ = "amcContracts",
    QZ = "amcTypes",
    ZZ = "userTokens",
    XZ = "amcServices",
    e7 = "amcComplaints",
    t7 = "deviceInformations",
    n7 = "softwares",
    r7 = "expenses",
    o7 = "ledger",
    i7 = "profilePictures",
    s7 = "imports",
    a7 = "business-readiness",
    c7 = {
        CUSTOMER: 2e3,
        EMPLOYEE: 20,
        LEAD: 2e4,
        PART: 2e3,
        DEVICE_TYPE: 20,
        DEVICE_BRAND: 100,
        DEVICE_MODEL: 2e3
    },
    l7 = "exports",
    u7 = "activities",
    d7 = "expenseCategories";
var f7 = "termAndConditionTypes",
    p7 = "termAndConditions";
var h7 = "deviceBrands",
    m7 = "prePostConditions",
    g7 = "quickReply",
    E7 = "partCategories",
    y7 = "partSubCategories",
    v7 = "permissions",
    D7 = "deviceModels",
    _7 = "deviceColors",
    x7 = "followUps",
    C7 = "followUpChannels";
var I7 = "banks",
    T7 = "repairServices",
    S7 = "workSchedule",
    b7 = "calendarEvents",
    w7 = "jobRepairServices",
    A7 = "feedbacks",
    M7 = "requestCallbacks";
var N7 = "backupDriveJobs",
    R7 = "backupDrives",
    O7 = "partPartSuppliers",
    P7 = "quotations",
    L7 = "jobInvoices",
    k7 = "signatures",
    F7 = "notificationTemplateSignatures",
    U7 = "accessories",
    B7 = "jobSources",
    j7 = "smsHistories",
    H7 = "message-logs",
    V7 = "tableSequenceNumbers",
    $7 = "parts",
    G7 = "partTransactions",
    W7 = "settings",
    z7 = "notificationPreferences",
    q7 = "generalSettings";
var K7 = "purchases",
    Y7 = "tasks",
    J7 = "globalSearch",
    Q7 = "storageLocations",
    Z7 = "accounts",
    X7 = "setups",
    eX = "admin/impersonate",
    tX = "accounts/getTenantDetails",
    nX = "businessTypes";
var rX = "pickupDrops";
var oX = "unitTypes",
    iX = "partSuppliers",
    sX = "outsourceVendors";
var aX = "jobStatuses",
    cX = "jobComments",
    lX = "reviews",
    uX = "notes",
    dX = "paymentTypes",
    fX = "deliveryTypes",
    pX = "jobDeliveries",
    hX = "shipments",
    mX = "integrations/shipping",
    gX = "lookups",
    EX = "amcLookups",
    yX = "taxes",
    vX = "tenantLogins",
    DX = "smsUrlMapping",
    _X = "upiLinks",
    xX = "deliveryProviders";
var CX = "payments",
    IX = "bulkPayments";
var TX = "attachments",
    SX = "notifications",
    bX = "reports",
    wX = "saleReports",
    AX = "purchaseReports",
    MX = "dashboardReports";
var NX = "jobReports",
    RX = "expenseReports",
    OX = "paymentReports",
    PX = "inventoryReports",
    LX = "employeeReports",
    kX = "countries",
    FX = "timezones",
    UX = "pricing/plans",
    BX = "pricing/detect-country",
    jX = "pricing/validate-coupon",
    HX = "subscription/checkout",
    VX = "subscription/prospect",
    $X = "subscription/invoices",
    GX = "contactUs",
    WX = "scanBarcode",
    zX = "prints",
    qX = "states",
    KX = "cities",
    YX = "jobParts",
    JX = "collectPayments",
    QX = "integrations",
    ZX = "quickbooks",
    XX = "mailchimps",
    eee = "chats",
    tee = "guests",
    nee = "employeeLocation",
    ree = "appInstalled",
    oee = "ride",
    iee = "post",
    see = "noticePanel",
    aee = "referredByList",
    cee = "outsourceTo",
    lee = "customFields",
    uee = "feedbackForms",
    dee = "attachmentBase64Data",
    fee = "modules",
    pee = 5242880;
var hee = 50,
    mee = 1e5,
    gee = 14400 * 1e3,
    Eee = "DD-MMM-YYYY",
    yee = 101,
    vee = 400,
    Dee = "DD-MMM-YYYY hh:mm A",
    _ee = "yyyy-MM-dd",
    xee = "dd-MMM-yyyy",
    Cee = "/dashboards",
    Iee = ["8pt", "10pt", "12pt", "14pt", "18pt", "24pt", "36pt"];
var Tee = ["GST", "Non-GST"],
    See = "#.##'%'",
    bee = "#0.##",
    wee = "/assets/images/bytephase-logo.gif",
    Aee = {
        THERMAL_PRINT: "thermal_print",
        SIMPLE_PRINT: "simple_print"
    },
    Mee = [{
        id: "US",
        countryName: "United States",
        format: "MM/DD/YYYY hh:mm A",
        example: "12/25/2024 05:30 PM",
        description: "12-hour format with AM/PM"
    }, {
        id: "UK",
        countryName: "United Kingdom",
        format: "DD/MM/YYYY HH:mm",
        example: "25/12/2024 17:30",
        description: "24-hour format"
    }, {
        id: "IN",
        countryName: "India",
        format: "DD-MM-YYYY hh:mm A",
        example: "25-12-2024 05:30 PM",
        description: "12-hour format with AM/PM"
    }, {
        id: "DE",
        countryName: "Germany",
        format: "DD.MM.YYYY HH:mm",
        example: "25.12.2024 17:30",
        description: "24-hour format"
    }, {
        id: "JP",
        countryName: "Japan",
        format: "YYYY/MM/DD HH:mm",
        example: "2024/12/25 17:30",
        description: "24-hour format"
    }, {
        id: "CN",
        countryName: "China",
        format: "YYYY-MM-DD HH:mm",
        example: "2024-12-25 17:30",
        description: "24-hour format"
    }, {
        id: "AU",
        countryName: "Australia",
        format: "DD/MM/YYYY hh:mm A",
        example: "25/12/2024 05:30 PM",
        description: "12-hour format with AM/PM"
    }, {
        id: "CA",
        countryName: "Canada",
        format: "YYYY-MM-DD hh:mm A",
        example: "2024-12-25 05:30 PM",
        description: "12-hour format with AM/PM"
    }, {
        id: "ZA",
        countryName: "South Africa",
        format: "YYYY/MM/DD hh:mm A",
        example: "2024/12/25 05:30 PM",
        description: "12-hour format with AM/PM"
    }, {
        id: "OTHER",
        countryName: "Other",
        format: "YYYY/MM/DD hh:mm A",
        example: "2024/12/25 05:30 PM",
        description: "12-hour format with AM/PM"
    }],
    wF = (function(e) {
        return e.MOBILE = "Mobile", e.EMAIL = "Email", e
    })(wF || {}),
    Nee = {
        IMAGES: {
            JOBSHEET_EXAMPLE: "assets/images/track-status-jobsheet-reference.png",
            JOBSHEET_EMAIL_EXAMPLE: "assets/images/track-status-email-reference.png"
        }
    },
    AF = (function(e) {
        return e.BOTH = "Both", e.REPAIR_SERVICE = "Repair Service", e.RECOVERY_SERVICE = "Recovery Service", e
    })(AF || {}),
    MF = (function(e) {
        return e.REPAIR_SERVICE = "Add Repair Job", e.RECOVERY_SERVICE = "Add Recovery Job", e.BULK_JOB = "Add Bulk Repair Job", e
    })(MF || {}),
    ao = (function(e) {
        return e.LITE = "Lite", e.BASIC = "Basic", e.STANDARD = "Standard", e.ENTERPRISE = "Enterprise", e
    })(ao || {}),
    Ree = [ao.LITE, ao.BASIC, ao.STANDARD, ao.ENTERPRISE],
    Oee = {
        OTP_DELIVERY: ao.ENTERPRISE,
        SEND_REVIEW_LINK: ao.STANDARD
    },
    Pee = ["Arial", "Courier New", "Georgia", "Impact", "Lucida Console", "Tahoma", "Times New Roman", "Verdana"],
    NF = (function(e) {
        return e.OPEN = "Open", e.COMPLETED = "Completed", e.Cancelled = "Cancelled", e
    })(NF || {}),
    Lee = ["Overdue", "Today", "Tomorrow", "Future"],
    RF = (function(e) {
        return e.OPEN = "Open", e.PENDING = "Pending", e.IN_PROGRESS = "In Progress", e.COMPLETED = "Completed", e.Cancelled = "Cancelled", e
    })(RF || {}),
    OF = (function(e) {
        return e.OPEN = "Open", e.CONTACTED = "Contacted", e.Cancelled = "Cancelled", e.PICKUP_BOOKED = "Pickup Booked", e.PICKUP_COMPLETED = "Pickup Completed", e.APPROVED = "Approved", e.CONVERTED = "Converted", e
    })(OF || {}),
    PF = (function(e) {
        return e.URGENT = "Urgent", e.MEDIUM = "Medium", e.LOW = "Low", e
    })(PF || {}),
    LF = (function(e) {
        return e.NOT_STARTED_YET = "Not Started Yet", e.IN_PROGRESS = "In Progress", e.COMPLETED = "Completed", e.CANCELLED = "Cancelled", e
    })(LF || {}),
    kF = (function(e) {
        return e.PAID = "Paid", e.PARTIALLY_PAID = "Partially Paid", e.UNPAID = "Unpaid", e.FREE = "Free", e.REFUND = "Refund", e.OVERDUE = "Over Due", e.OVER_PAID = "Over Paid", e.PARTIAL_PAID_OVER_DUE = "Partial Paid Over Due", e
    })(kF || {});
var FF = (function(e) {
        return e.CARD = "CARD", e.DQR = "DQR", e.UPI = "UPI", e
    })(FF || {}),
    UF = (function(e) {
        return e.INFO = "info", e.ERROR = "error", e.WARNING = "warning", e.SUCCESS = "success", e
    })(UF || {}),
    BF = (function(e) {
        return e.SYSTEM = "System", e.GOOGLE = "Google", e.MICROSOFT = "Microsoft", e
    })(BF || {}),
    jF = (function(e) {
        return e.GOOGLE_CALENDER = "Google Calendar", e.MICROSOFT_CALENDAR = "Microsoft Calendar", e
    })(jF || {}),
    HF = (function(e) {
        return e.CUSTOMER = "Customer", e.JOB = "Job", e.QUOTATION = "Quotation", e.EMPLOYEE = "Employee", e.SALE = "Sale", e.TASK = "Task", e.EXPENSE = "Expense", e.LEAD = "Lead", e.AMC_CONTRACT = "AMC Contract", e.AMC_COMPLAINT = "AMC Complaint", e.DEVICE_INFORMATION = "Device Information", e
    })(HF || {}),
    VF = (function(e) {
        return e.TEXT = "Text", e.NUMBER = "Number", e.DROPDOWN = "Dropdown", e
    })(VF || {}),
    $F = (function(e) {
        return e.MB = "MB", e.GB = "GB", e.TB = "TB", e.PB = "PB", e
    })($F || {}),
    GF = (function(e) {
        return e.HOURS = "HOURS", e.DAY = "DAY", e.WEEK = "WEEK", e
    })(GF || {}),
    WF = (function(e) {
        return e.ON_SITE = "On Site", e.CARRY_IN = "Carry In", e
    })(WF || {}),
    zF = (function(e) {
        return e.PENDING = "Pending", e.COMPLETED = "Completed", e
    })(zF || {}),
    qF = (function(e) {
        return e.MONTHLY = "Monthly", e.QUARTERLY = "Quarterly", e.ANNUAL = "Annual", e
    })(qF || {}),
    KF = (function(e) {
        return e.ACTIVE = "Active", e.EXPIRED = "Expired", e.RENEWAL_PENDING = "Renewal Pending", e.RENEWED = "Renewed", e.CANCELLED = "Cancelled", e.SUSPENDED = "Suspended", e.PENDING_APPROVAL = "Pending Approval", e.INACTIVE = "Inactive", e
    })(KF || {}),
    YF = (function(e) {
        return e.SUBSCRIBED = "subscribed", e.UNSUBSCRIBED = "unsubscribed", e.CLEANED = "cleaned", e.PENDING = "pending", e.TRANSACTIONAL = "transactional", e
    })(YF || {}),
    JF = (function(e) {
        return e.ACTIVE = "Active", e.INACTIVE = "Inactive", e
    })(JF || {}),
    QF = (function(e) {
        return e.MAILCHIMP = "Mailchimp", e.STRIPE = "Stripe", e.PHONE_PE = "Phone Pe", e.QUICK_BOOK = "Quick Book", e.GUPSHUP = "Gupshup", e.TWILIO = "Twilio", e.BULKGATE = "BulkGate", e.ZAPIER = "Zapier", e.META_LEAD_ADS = "Meta Lead Ads", e.SHIPROCKET = "Shiprocket", e
    })(QF || {}),
    ZF = (function(e) {
        return e.PAYMENT = "payment", e.SMS = "sms", e.FORM = "form", e.LEAD_GENERATION = "lead_generation", e.SHIPPING = "shipping", e
    })(ZF || {}),
    XF = (function(e) {
        return e.PAID = "Paid", e.PARTIALLY_PAID = "Partially Paid", e.UNPAID = "Unpaid", e.OVERDUE = "Overdue", e.PENDING = "Pending", e.CANCELLED = "Cancelled", e.PAYMENT_PLAN = "Payment Plan", e
    })(XF || {}),
    e1 = (function(e) {
        return e.PENDING = "Pending", e.IN_PROGRESS = "In Progress", e.RESOLVED = "Resolved", e.CLOSED = "Closed", e.CANCELLED = "Cancelled", e
    })(e1 || {}),
    t1 = (function(e) {
        return e.DASHBOARD_EXPENSE_CHART = "Expense", e.DASHBOARD_INCOME_CHART = "Payment Received", e.REPORTS_REVENUES_EXPENSE = "Expense", e.PAYMENT_TYPE_WISE_REVENUE_REPORT = "Payment Type Wise Revenue  Report", e.SERVICE_TYPE_WISE_REPORT = "Service Type Wise Report", e.STATUS_WISE_REPORT = "Status Wise Report", e.DEVICE_MODEL_WISE_JOB_REPORT = "Device Model Wise Job Report", e.JOB_TYPE_WISE_REPORT = "Job Type Wise Report", e.JOB_MODEL_WISE_REPORT = "Job Model Wise Report", e.JOB_SOURCE_WISE_REPORT = "Job Source Wise Report", e.SALES_EARNINGS_OVERVIEW = "Sales Earnings Overview", e.SALES_COUNT_REPORT = "Sales Count Report", e.SERVICE_WISE_REPORT = "Service Wise Report", e.PART_WISE_REPORT = "Part Wise Report", e.AMC_EARNINGS_OVERVIEW = "AMC Earnings Overview", e.AMC_CONTRACT_COUNT_WISE_REPORT = "AMC Contract Count Wise Report", e.EMPLOYEE_JOB_DISTRIBUTION = "Employee Job Distribution", e.EMPLOYEE_REVENUE_COMPARISON = "Employee Revenue Comparison", e.EMPLOYEE_JOB_COMPLETION_TREND = "Employee Job Completion Trend", e.EMPLOYEE_REVENUE_TREND = "Employee Revenue Trend", e.EMPLOYEE_TASK_BREAKDOWN = "Employee Task Breakdown", e
    })(t1 || {}),
    n1 = (function(e) {
        return e.JOB_ASSIGNEE_UPDATED = "JOB_ASSIGNEE_UPDATED", e.JOB_STATUS_UPDATED = "JOB_STATUS_UPDATED", e.JOB_ASSIGNEE_AND_STATUS = "JOB_ASSIGNEE_AND_STATUS_UPDATED", e.JOB_UPDATED = "JOB_UPDATED", e.JOB_CREATED = "JOB_CREATED", e.JOB_COMMENT_CREATED = "JOB_COMMENT_CREATED", e.BACKUP_DRIVE_JOB_CREATED = "BACKUP_DRIVE_JOB_CREATED", e.BACKUP_DRIVE_JOB_UPDATED = "BACKUP_DRIVE_JOB_UPDATED", e.QUOTATION_CREATED = "QUOTATION_CREATED", e.QUOTATION_UPDATED = "QUOTATION_UPDATED", e.JOB_INVOICE_CREATED = "JOB_INVOICE_CREATED", e.PAYMENT_CREATED = "PAYMENT_CREATED", e.PAYMENT_UPDATED = "PAYMENT_UPDATED", e.PAYMENT_DELETED = "PAYMENT_DELETED", e.JOB_DELIVERY_CREATED = "JOB_DELIVERY_CREATED", e.JOB_DELIVERY_UPDATED = "JOB_DELIVERY_UPDATED", e.PARTABLE_CREATED = "PARTABLE_CREATED", e.PARTABLE_UPDATED = "PARTABLE_UPDATED", e.REPAIRABLE_CREATED = "REPAIRABLE_CREATED", e.REPAIRABLE_UPDATED = "REPAIRABLE_UPDATED", e.REPAIRABLE_DELETED = "REPAIRABLE_DELETED", e.PARTABLE_DELETED = "PARTABLE_DELETED", e.ATTACHMENT_CREATED = "ATTACHMENT_CREATED", e.ATTACHMENT_DELETED = "ATTACHMENT_DELETED", e.OUTSOURCED_JOB_CREATED = "OUTSOURCED_JOB_CREATED", e.OUTSOURCED_JOB_UPDATED = "OUTSOURCED_JOB_UPDATED", e.OUTSOURCED_JOB_DELETED = "OUTSOURCED_JOB_DELETED", e.JOB_POST_CONDITION_UPDATED = "JOB_POST_CONDITION_UPDATED", e.DIRECTORY_SCAN_CREATED = "DIRECTORY_SCAN_CREATED", e.DIRECTORY_SCAN_UPDATED = "DIRECTORY_SCAN_UPDATED", e.JOB_DIAGNOSIS_CREATED = "JOB_DIAGNOSIS_CREATED", e.JOB_DIAGNOSIS_UPDATED = "JOB_DIAGNOSIS_UPDATED", e
    })(n1 || {}),
    r1 = (function(e) {
        return e.AMC_CONTRACT = "AMC_CONTRACT", e.AMC_SERVICE = "AMC_SERVICE", e.AMC_COMPLAINT = "AMC_COMPLAINT", e.DEVICE_INFORMATION = "DEVICE_INFORMATION", e.SOFTWARE = "SOFTWARE", e.AMC_CONTRACT_CREATED = "AMC_CONTRACT_CREATED", e.AMC_CONTRACT_UPDATED = "AMC_CONTRACT_UPDATED", e.AMC_SERVICE_CREATED = "AMC_SERVICE_CREATED", e.AMC_SERVICE_UPDATED = "AMC_CONTRACT_UPDATED", e.AMC_SERVICE_DELETED = "AMC_CONTRACT_DELETED", e.AMC_COMPLAINT_CREATED = "AMC_COMPLAINT_CREATED", e.AMC_COMPLAINT_UPDATED = "AMC_COMPLAINT_UPDATED", e.AMC_COMPLAINT_DELETED = "AMC_COMPLAINT_DELETED", e.DEVICE_INFORMATION_CREATED = "DEVICE_INFORMATION_CREATED", e.DEVICE_INFORMATION_UPDATED = "DEVICE_INFORMATION_UPDATED", e.DEVICE_INFORMATION_DELETED = "DEVICE_INFORMATION_DELETED", e.SOFTWARE_CREATED = "SOFTWARE_CREATED", e.SOFTWARE_UPDATED = "SOFTWARE_UPDATED", e.SOFTWARE_DELETED = "SOFTWARE_DELETED", e.AMC_CONTRACT_ASSIGNEE_UPDATED = "AMC_CONTRACT_ASSIGNEE_UPDATED", e.AMC_CONTRACT_STATUS_UPDATED = "AMC_CONTRACT_STATUS_UPDATED", e.AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED = "AMC_CONTRACT_ASSIGNEE_AND_STATUS_UPDATED", e
    })(r1 || {}),
    kee = {
        AMC_CONTRACT_PRINT_SETTINGS: {
            AMC_TYPE_ID: "amc_type_id",
            ASSIGNEE_ID: "assignee_id",
            CREATED_AT: "created_at",
            CUSTOM_FIELDS: "custom_fields",
            END_DATE: "end_date",
            IS_CONTRACT_AUTO_RENEW: "is_contract_auto_renew",
            NUMBER_OF_DEVICES_COVERED: "number_of_devices_covered",
            NUMBER_OF_SERVICES: "number_of_services",
            PAYMENT_FREQUENCY: "payment_frequency",
            PAYMENT_RECEIVED: "payment_received",
            PAYMENT_STATUS: "payment_status",
            REMARK: "remark",
            RESPONSE_TIME: "response_time",
            RESPONSE_TIME_UNIT: "response_time_unit",
            SERVICE_OPTIONS: "service_options",
            START_DATE: "start_date",
            TERM_AND_CONDITION: "term_and_condition",
            TOTAL_AMOUNT: "total_amount",
            USER_ID: "user_id"
        },
        GENERAL_SETTINGS: {
            AUTO_ROUND_OFF: "auto_round_off",
            ENABLE_PRE_POST_CONDITION: "enable_pre_post_condition",
            ENABLE_GDPR_COMPLIANCE: "enable_gdpr_compliance",
            ENABLE_AUTOMATIC_INVOICE_CREATION_ON_PAYMENT: "enable_automatic_invoice_creation_on_payment",
            UNIFIED_INVOICE_NUMBER_FOR_SALES_AND_JOBS: "unified_invoice_number_for_sales_and_jobs",
            DISABLE_MOBILE_NUMBER_VALIDATION: "disable_mobile_number_validation",
            DISABLE_LOGIN_WITH_GOOGLE: "disable_login_with_google",
            ENABLE_ADDRESS_VALIDATION_FOR_SELF_CHECKIN: "enable_address_validation_for_self_checkin",
            ENABLE_BUSINESS_HOURS: "enable_business_hours",
            ENABLE_SELF_CHECKIN_REPAIR_SERVICE_PRICE: "enable_self_checkin_repair_service_price",
            ENABLE_MODEL_WISE_SERVICE_PRICING: "enable_model_wise_service_pricing",
            ENABLE_DIAGNOSIS_REPORT: "enable_diagnosis_report",
            ENABLE_TWO_FACTOR_AUTHENTICATION: "enable_two_factor_authentication",
            RESTRICT_PARTS_AFTER_JOB_CLOSE: "restrict_parts_after_job_close",
            NOTIFICATION_TEMPLATE_EMAIL_SIGNATURE: "notification_template_email_signature",
            NOTIFICATION_TEMPLATE_SMS_SIGNATURE: "notification_template_sms_signature",
            NOTIFICATION_TEMPLATE_WHATSAPP_SIGNATURE: "notification_template_whatsapp_signature",
            ALLOW_ZERO_QUANTITY_PART: "is_allow_zero_quantity_part",
            ENABLE_ADVANCE_PAYMENT_ON_JOB_CREATION: "enable_advance_payment_on_job_creation",
            ENABLE_BULK_JOB: "enable_bulk_job"
        },
        JOB_SETTING: {
            ASSIGNED_USER_ID: "assigned_user_id",
            DEVICE_TYPE_ID: "device_type_id",
            PRIORITY_ID: "priority_id",
            SERVICE_TYPE_ID: "service_type_id",
            SOURCE_ID: "source_id",
            STATUS_ID: "status_id",
            STORAGE_LOCATION_ID: "storage_location_id",
            TYPE_ID: "type_id"
        },
        PRINT_SETTINGS: {
            ACCESSORIES: "accessories",
            ADDRESS: "address",
            ASSIGNEE_ON_PRINT: "assignee_on_print",
            QR_CODE: "qr_code",
            COMMENT: "comment",
            CREATED_AT: "created_at",
            CUSTOM_FIELDS: "custom_fields",
            DEVICE_BRAND_ID: "device_brand_id",
            DEVICE_COLOR_ID: "device_color_id",
            DEVICE_MODEL_ID: "device_model_id",
            DEVICE_TYPE_ID: "device_type_id",
            EMAIL: "email",
            GST_NUMBER: "gst_number",
            HARDWARE_CONFIGURATION: "hardware_configuration",
            INITIAL_QUOTATION: "initial_quotation",
            MOBILE_NUMBER: "mobile_number",
            NAME: "name",
            PAYMENT_QR: "payment_qr",
            PHONE_NUMBER: "phone_number",
            REPAIRABLES: "repairables",
            SERIAL_NUMBER_ID: "serial_number_id",
            SERVICE_TYPE_ID: "service_type_id",
            STATUS: "status",
            JOB_STATUS: "job_status",
            JOB_TYPE: "job_type",
            TAGS_ID: "tags_id",
            VENDOR_JOB_ID: "vendor_job_id"
        },
        REMINDER_SETTINGS: {
            AMC_ALERTS: "amc_alerts",
            JOB_DUE_ALERTS: "job_due_alerts",
            PAYMENT_DUE_ALERTS: "payment_due_alerts",
            PICKUP_DROP_ALERTS: "pickup_drop_alerts",
            TASK_DUE_ALERTS: "task_due_alerts"
        },
        TABLE_SETTINGS: {
            ROW_ALTERNATION_ENABLED: "row_alternation_enabled",
            SHOW_COLUMN_LINES: "show_column_lines",
            SHOW_ROW_LINES: "show_row_lines"
        },
        TECHNICIAN_COPY_SETTINGS: {
            QR_CODE: "qr_code",
            COMMENT: "comment",
            DEVICE_BRAND_ID: "device_brand_id",
            DEVICE_COLOR_ID: "device_color_id",
            DEVICE_MODEL_ID: "device_model_id",
            DEVICE_TYPE_ID: "device_type_id",
            REPAIRABLES: "repairables",
            SERIAL_NUMBER_ID: "serial_number_id",
            SERVICE_TYPE_ID: "service_type_id"
        },
        THEME_AND_LAYOUT_SETTINGS: {
            SCROLLING_MODE: "scrolling_mode"
        },
        WORKFLOW_SETTINGS: {
            ADDING_DELIVERY_NEXT_JOB_STATUS: "adding_delivery_next_job_status",
            CITY: "city",
            JOB_OUTSOURCED_NEXT_JOB_STATUS: "job_outsourced_next_job_status",
            OUTSOURCED_JOB_COMPLETE_NEXT_JOB_STATUS: "outsourced_job_complete_next_job_status",
            QUOTATION_APPROVAL_NEXT_JOB_STATUS: "quotation_approval_next_job_status",
            QUOTATION_CREATION_NEXT_JOB_STATUS: "quotation_creation_next_job_status",
            QUOTATION_REJECTED_NEXT_JOB_STATUS: "quotation_rejected_next_job_status",
            SALE_CREATE_NEXT_PAYMENT_STATUS: "sale_create_next_payment_status",
            DEFAULT_JOB_DUE_DAY: "default_job_due_day",
            DEFAULT_TASK_DUE_DAY: "default_task_due_day",
            DEFAULT_PURCHASE_DUE_DAY: "default_purchase_due_day",
            SERVICE_OPTION: "service_option",
            INVOICE_TYPE: "invoice_type",
            STATE: "state"
        },
        INVOICE_DUE_ALERT_SETTINGS: {
            FIRST_REMINDER: "first_reminder",
            SECOND_REMINDER: "second_reminder",
            THIRD_REMINDER: "third_reminder"
        },
        JOB_FORM_FIELD_CONFIG: {
            SOURCE_ID: "job_form_source_id",
            REFERRED_BY_ID: "job_form_referred_by_id",
            DEVICE_MODEL_ID: "job_form_device_model_id",
            SERIAL_NUMBER: "job_form_serial_number",
            ACCESSORIES: "job_form_accessories",
            STORAGE_LOCATION_ID: "job_form_storage_location_id",
            DEVICE_COLOR_ID: "job_form_device_color_id",
            DEVICE_PASSWORD: "job_form_device_password",
            TAGS: "job_form_tags",
            HARDWARE_CONFIGURATION: "job_form_hardware_configuration",
            COMMENT: "job_form_comment",
            INITIAL_QUOTATION: "job_form_initial_quotation",
            ESTIMATED_DELIVERY: "job_form_estimated_delivery",
            VENDOR_JOB_ID: "job_form_vendor_job_id",
            TERM_AND_CONDITION: "job_form_term_and_condition",
            PCB_NUMBER: "job_form_pcb_number"
        },
        SELF_CHECK_IN_SETTINGS: {
            ADDRESS_MANDATORY: "self_checkin_address_mandatory",
            CITY_OPTIONAL: "self_checkin_city_optional",
            STATE_OPTIONAL: "self_checkin_state_optional",
            POSTAL_CODE_OPTIONAL: "self_checkin_postal_code_optional",
            HIDE_CITY: "self_checkin_hide_city",
            HIDE_STATE: "self_checkin_hide_state",
            HIDE_POSTAL_CODE: "self_checkin_hide_postal_code",
            SHOW_ADDRESS_ON_BASIC_INFO: "self_checkin_show_address_on_basic_info",
            HIDE_DEVICE_PASSWORD: "self_checkin_hide_device_password",
            SERVICE_MANDATORY: "self_checkin_service_mandatory",
            PICKUP_MIN_LEAD_HOURS_ENABLED: "self_checkin_pickup_min_lead_hours_enabled",
            HIDE_PICKUP: "self_checkin_hide_pickup",
            SHOW_THANKYOU_NOTE: "self_checkin_show_thankyou_note"
        }
    },
    Fee = [{
        id: "standard",
        text: "Pagination"
    }, {
        id: "infinite",
        text: "Virtual Scrolling"
    }],
    Uee = [{
        text: "Pickup"
    }, {
        text: "Drop"
    }];
var o1 = (function(e) {
        return e.DASHBOARD_TREND = "dashboard_trend", e.ACTIONABLE_DASHBOARD = "actionable_dashboard", e.SALE_DAILY_SALES = "sale_daily_sales", e.SALE_SUMMARY_REPORT = "sale_summary_report", e.SALE_TREND = "sale_trend", e.SALE_TOTAL_AMOUNT_TREND = "sale_total_amount_trend", e.PURCHASE_DAILY_EXPENSE = "purchase_daily_expense", e.PURCHASE_TREND = "purchase_trend", e.PURCHASE_TOTAL_AMOUNT_TREND = "purchase_total_amount_trend", e.EXPENSE_TREND = "expense_trend", e.EXPENSE_TOTAL_AMOUNT_TREND = "expense_total_amount_trend", e.MOST_POPULAR_REPAIR = "most_popular_repair", e.LOW_STOCK_INVENTORY_LIST = "low_stock_inventory_list", e.STATUS_WISE_JOB_REPORT = "status_wise_job_report", e.MOST_POPULAR_PART_WISE_SALES_REPORT = "most_popular_part_wise_sales_report", e.MOST_POPULAR_PART_WISE_PURCHASE_REPORT = "most_popular_part_wise_purchase_report", e.MOST_POPULAR_SERVICE_WISE_JOBS_REPORT = "most_popular_service_wise_jobs_report", e.MOST_POPULAR_PART_WISE_JOBS_REPORT = "most_popular_part_wise_jobs_report", e.PAYMENT_TYPE_WISE_AMOUNT = "payment_type_wise_amount", e.JOB_COUNT_TREND = "job_count_trend", e.JOB_TOTAL_AMOUNT_TREND = "job_total_amount_trend", e.PAYMENT_RECEIVED_TREND = "payment_received_trend", e.JOB_PAYMENT_RECEIVED_TREND = "job_payment_received_trend", e.SALE_PAYMENT_RECEIVED_TREND = "sale_payment_received_trend", e.PURCHASE_PAYMENT_RECEIVED_TREND = "purchase_payment_received_trend", e.CATEGORY_WISE_EXPENSE_REPORT = "category_wise_expense_report", e.EMPLOYEE_JOBS_COMPLETED_TREND = "employee_jobs_completed_trend", e.EMPLOYEE_REVENUE_TREND = "employee_revenue_trend", e.EMPLOYEE_PERFORMANCE_SUMMARY = "employee_performance_summary", e.EMPLOYEE_JOB_DISTRIBUTION = "employee_job_distribution", e.EMPLOYEE_REVENUE_COMPARISON = "employee_revenue_comparison", e.EMPLOYEE_TASK_SUMMARY = "employee_task_summary", e.EMPLOYEE_MONTHLY_TREND = "employee_monthly_trend", e
    })(o1 || {}),
    i1 = (function(e) {
        return e.OPEN = "Open", e.NOT_STARTED_YET = "Not Started Yet", e.IN_PROGRESS = "In Progress", e.COMPLETED = "Completed", e.CANCELLED = "Cancelled", e
    })(i1 || {}),
    s1 = (function(e) {
        return e.NOT_STARTED_YET = "Not Started Yet", e.IN_PROGRESS = "In Progress", e.COMPLETED = "Completed", e
    })(s1 || {}),
    a1 = (function(e) {
        return e.OPEN = "Open", e.CLOSED = "Closed", e.REJECTED = "Rejected", e.RETURNED = "Returned", e
    })(a1 || {}),
    c1 = (function(e) {
        return e.ADMIN = "admin", e.CORPORATE = "corporate", e.DEALER = "dealer", e.DELIVERY = "delivery", e.END = "end", e.GUEST = "guest", e.RECEPTIONIST = "reception", e.CORPORATE_MARKETING = "corporate-marketing", e.MARKETING = "marketing", e
    })(c1 || {}),
    l1 = (function(e) {
        return e.MALE = "Male", e.FEMALE = "Female", e.OTHER = "Other", e
    })(l1 || {});
var u1 = (function(e) {
    return e.ACCOUNT = "account", e
})(u1 || {});
var d1 = (function(e) {
        return e.IMAGE = "image", e.VIDEO = "video", e
    })(d1 || {}),
    f1 = (function(e) {
        return e.PRE_CONDITION = "pre_condition", e.POST_CONDITION = "post_condition", e
    })(f1 || {}),
    Bee = {
        BUSINESS_SETTING_VIEW: "business_settings.view",
        BUSINESS_SETTING_WRITE: "business_settings.write",
        JOB_WRITE: "job.write",
        JOB_DELETE: "job.delete",
        JOB_EXPORT_EXL: "job.export-exl",
        JOB_LIST: "job.list",
        JOB_VIEW_PAYMENT_COLUMN_IN_JOB_LIST: "job.view_payment_column_in_job_list",
        JOB_VIEW_PAYMENT_TAB: "job.view_payment_tab",
        JOB_REPAIR_SERVICE_WRITE: "job_repair_service.write",
        JOB_REPAIR_SERVICE_LIST: "job_repair_service.list",
        JOB_REPAIR_SERVICE_DELETE: "job_repair_service.delete",
        JOB_PART_WRITE: "job_part.write",
        JOB_PART_LIST: "job_part.list",
        JOB_PART_DELETE: "job_part.delete",
        JOB_INVOICE_WRITE: "job_invoice.write",
        JOB_INVOICE_LIST: "job_invoice.list",
        JOB_INVOICE_DELETE: "job_invoice.delete",
        CUSTOMER_WRITE: "customer.write",
        CUSTOMER_LIST: "customer.list",
        CUSTOMER_DETAIL: "customer.detail",
        CUSTOMER_VIEW_PAYMENT_TAB: "customer.view_payment_tab",
        CUSTOMER_VIEW_CONTACT_INFORMATION: "customer.view_contact_information",
        CUSTOMER_VIEW_PAYMENT_INFORMATION: "customer.view_payment_information",
        SALE_WRITE: "sale.write",
        SALE_LIST: "sale.list",
        SALE_DELETE: "sale.delete",
        PART_WRITE: "part.write",
        PART_LIST: "part.list",
        PART_DELETE: "part.delete",
        PART_SUPPLIER_WRITE: "part_supplier.write",
        PART_SUPPLIER_LIST: "part_supplier.list",
        PART_SUPPLIER_DELETE: "part_supplier.delete",
        BACKUP_DRIVE_WRITE: "backup_drive.write",
        BACKUP_DRIVE_LIST: "backup_drive.list",
        BACKUP_DRIVE_DELETE: "backup_drive.delete",
        PURCHASE_WRITE: "purchase.write",
        PURCHASE_LIST: "purchase.list",
        PURCHASE_DELETE: "purchase.delete",
        REPORT_VIEW: "report.view",
        EMPLOYEE_WRITE: "employee.write",
        EMPLOYEE_LIST: "employee.list",
        IMPORT_LIST: "import.list",
        IMPORT_WRITE: "import.write",
        IMPORT_DELETE: "import.delete",
        IMPORT_CUSTOMER: "import.customer",
        IMPORT_LEAD: "import.lead",
        IMPORT_PART: "import.part",
        IMPORT_EMPLOYEE: "import.employee",
        IMPORT_DEVICE_TYPE: "import.device_type",
        IMPORT_DEVICE_BRAND: "import.device_brand",
        IMPORT_DEVICE_MODEL: "import.device_model",
        TASK_WRITE: "task.write",
        TASK_LIST: "task.list",
        TASK_DELETE: "task.delete",
        LEAD_WRITE: "lead.write",
        LEAD_LIST: "lead.list",
        LEAD_DELETE: "lead.delete",
        FOLLOW_UP_LIST: "follow_up.list",
        FOLLOW_UP_WRITE: "follow_up.write",
        DEVICE_TYPE_WRITE: "device_type.write",
        DEVICE_TYPE_LIST: "device_type.view",
        DEVICE_TYPE_DELETE: "device_type.delete",
        JOB_TYPE_WRITE: "job_type.write",
        JOB_TYPE_LIST: "job_type.view",
        JOB_TYPE_DELETE: "job_type.delete",
        PAYMENT_TYPE_WRITE: "payment_type.write",
        PAYMENT_TYPE_LIST: "payment_type.view",
        PAYMENT_TYPE_DELETE: "payment_type.delete",
        DEVICE_BRAND_WRITE: "device_brand.write",
        DEVICE_BRAND_LIST: "device_brand.view",
        DEVICE_BRAND_DELETE: "device_brand.delete",
        DEVICE_MODEL_WRITE: "device_model.write",
        DEVICE_MODEL_LIST: "device_model.view",
        DEVICE_MODEL_DELETE: "device_model.delete",
        PRE_POST_CONDITION_WRITE: "pre_post_condition.write",
        PRE_POST_CONDITION_LIST: "pre_post_condition.view",
        PRE_POST_CONDITION_DELETE: "pre_post_condition.delete",
        ACCESSORY_WRITE: "accessory.write",
        ACCESSORY_LIST: "accessory.list",
        ACCESSORY_DELETE: "accessory.delete",
        REPAIR_SERVICE_WRITE: "repair_service.write",
        REPAIR_SERVICE_LIST: "repair_service.list",
        REPAIR_SERVICE_DELETE: "repair_service.delete",
        JOB_STATUS_WRITE: "job_status.write",
        JOB_STATUS_LIST: "job_status.list",
        JOB_STATUS_DELETE: "job_status.delete",
        STORAGE_LOCATION_WRITE: "storage_location.write",
        STORAGE_LOCATION_LIST: "storage_location.list",
        STORAGE_LOCATION_DELETE: "storage_location.delete",
        DEVICE_COLOR_WRITE: "device_color.write",
        DEVICE_COLOR_LIST: "device_color.list",
        DEVICE_COLOR_DELETE: "device_color.delete",
        BILLING_LIST: "billing.list",
        PICKUP_DROP_WRITE: "pickup_drop.write",
        PICKUP_DROP_LIST: "pickup_drop.list",
        PICKUP_DROP_DELETE: "pickup_drop.delete",
        JOB_SOURCES_WRITE: "job_source.write",
        JOB_SOURCES_LIST: "job_source.list",
        JOB_SOURCES_DELETE: "job_source.delete",
        EXPENSES_WRITE: "expense.write",
        EXPENSES_LIST: "expense.list",
        EXPENSES_DELETE: "expense.delete",
        EXPENSE_CATEGORY_WRITE: "expense_category.write",
        EXPENSE_CATEGORY_LIST: "expense_category.list",
        EXPENSE_CATEGORY_DELETE: "expense_category.delete",
        QUOTATION_WRITE: "quotation.write",
        QUOTATION_LIST: "quotation.list",
        QUOTATION_APPROVE_OR_REJECT: "quotation.approve_or_reject",
        QUOTATION_DELETE: "quotation.delete",
        PAYMENT_WRITE: "payment.write",
        PAYMENT_DELETE: "payment.delete",
        QUICK_REPLY_WRITE: "quick_reply.write",
        QUICK_REPLY_LIST: "quick_reply.list",
        QUICK_REPLY_DELETE: "quick_reply.delete",
        CONTACT_US_WRITE: "contact_us.write",
        CONTACT_US_LIST: "contact_us.list",
        CONTACT_US_DELETE: "contact_us.delete",
        OUTSOURCED_JOB_WRITE: "outsourced_job.write",
        OUTSOURCED_JOB_LIST: "outsourced_job.list",
        OUTSOURCED_JOB_DELETE: "outsourced_job.delete",
        OUTSOURCE_VENDOR_WRITE: "outsource_vendor.write",
        OUTSOURCE_VENDOR_LIST: "outsource_vendor.list",
        OUTSOURCE_VENDOR_DELETE: "outsource_vendor.delete",
        AMC_CONTRACT_WRITE: "amc_contract.write",
        AMC_CONTRACT_LIST: "amc_contract.list",
        AMC_CONTRACT_DELETE: "amc_contract.delete",
        AMC_CONTRACT_SHOW_ONLY_ASSIGNED: "amc_contract.show_only_assigned",
        AMC_CONTRACT_VIEW_PAYMENT_COLUMN_IN_AMC_CONTRACT_LIST: "amc_contract.view_payment_column_in_amc_contract_list",
        AMC_CONTRACT_VIEW_PAYMENT_TAB: "amc_contract.view_payment_tab",
        AMC_SERVICE_WRITE: "amc_service.write",
        AMC_SERVICE_LIST: "amc_service.list",
        AMC_SERVICE_DELETE: "amc_service.delete",
        AMC_SERVICE_SHOW_ONLY_ASSIGNED: "amc_service.show_only_assigned",
        AMC_COMPLAINT_WRITE: "amc_complaint.write",
        AMC_COMPLAINT_LIST: "amc_complaint.list",
        AMC_COMPLAINT_DELETE: "amc_complaint.delete",
        AMC_COMPLAINT_SHOW_ONLY_ASSIGNED: "amc_complaint.show_only_assigned",
        DEVICE_INFORMATION_WRITE: "device_information.write",
        DEVICE_INFORMATION_LIST: "device_information.list",
        DEVICE_INFORMATION_DELETE: "device_information.delete",
        MAIL_MARKETING_WRITE: "mail_marketing.write",
        MAIL_MARKETING_LIST: "mail_marketing.list",
        MAIL_MARKETING_DELETE: "mail_marketing.delete",
        COMMISSION_VIEW_OWN: "commission.view_own",
        COMMISSION_VIEW_ALL: "commission.view_all",
        COMMISSION_MANAGE_SETTINGS: "commission.manage_settings",
        COMMISSION_MANAGE_PROFILES: "commission.manage_profiles",
        COMMISSION_APPROVE: "commission.approve",
        COMMISSION_VOID: "commission.void",
        COMMISSION_CREATE_ADJUSTMENT: "commission.create_adjustment",
        COMMISSION_MANAGE_PERIODS: "commission.manage_periods",
        COMMISSION_EXPORT: "commission.export",
        LEDGER_LIST: "ledger.list",
        LEDGER_WRITE: "ledger.write",
        LEDGER_DELETE: "ledger.delete"
    },
    jee = {
        ASSIGNED_TO: "Assign To",
        UPDATE_STATUS: "Update Status",
        ADD_INTERNAL_NOTES: "Add Internal Notes",
        ADD_COMMENT: "Add Comment",
        ADD_PAYMENT: "Add Payment",
        ADD_DELIVERY: "Add Delivery",
        ADD_BACKUP: "Add Backup",
        ADD_REVIEW: "Request Review",
        CLONE_JOB: "Clone Job",
        INVOICE: "Invoice",
        PRINT: "Print",
        JOB_SHEET: "Job Sheet",
        JOB_DIAGNOSIS: "Job Diagnosis",
        QUOTATION: "Quotation",
        SEND_WHATSAPP: "Send Whatsapp",
        SEND_UPI_LINK: "Send UPI Link",
        COLLECT_PAYMENT: "Collect Payment",
        TECHNICIAN_COPY: "Technician Copy",
        OUTSOURCE_TO: "Outsource To",
        PRE_POST_CONDITION: "Pre/Post Condition",
        DATA_VALIDATION: "Data Validation",
        DELETE_JOB: "Delete Job"
    },
    Hee = {
        SEND_WHATSAPP: "Send Whatsapp",
        ADD_PAYMENT: "Add Payment",
        REFUND: "Refund",
        SALE_INVOICE: "Sale Invoice",
        SEND_UPI_LINK: "Send UPI Link",
        PAYMENT_HISTORY: "Payment History",
        VIEW_SALE: "View Sale",
        COLLECT_PAYMENT: "Collect Payment",
        DELETE_SALE: "Delete Sale"
    },
    Vee = {
        FORGET_USER: "Forget User",
        SEND_ACTIVATION_LINK: "Send Activation Link",
        SEND_PAYMENT_OVERDUE_REMINDER: "Send Payment Reminder",
        DEACTIVATE_ACCOUNT: "Deactivate Account",
        ACTIVATE_ACCOUNT: "Activate Account",
        DELETE_CUSTOMER: "Delete Customer",
        DEACTIVATE_ACTIVATE_ACCOUNT: "Deactivate/Activate Account",
        TRACK: "Track"
    },
    $ee = {
        VIEW_RECEIPT: "View Receipt",
        EDIT: "Edit",
        DELETE: "Delete",
        TRACK: "Track"
    },
    Gee = {
        EDIT_OUTSOURCE: "Edit Outsource",
        VIEW_OUTSOURCE: "View Outsource",
        SCHEDULE_PICKUP_DROP: "Schedule Pickup Drop",
        DELETE_OUTSOURCE: "Delete Outsource"
    },
    Wee = {
        SEND_WHATSAPP: "Send Whatsapp",
        PURCHASE_INVOICE: "Purchase Invoice",
        VIEW_PURCHASE: "View Purchase",
        ADD_PAYMENT: "Add Payment",
        DELETE_PURCHASE: "Delete Purchase"
    },
    zee = {
        REFUND: "Refund",
        DOWNLOAD: "Download",
        DELETE_INVOICE: "Delete Invoice"
    },
    qee = {
        SEND_WHATSAPP: "Send Whatsapp",
        AMC_CONTRACT: "Amc Contract",
        ADD_PAYMENT: "Add Payment",
        UPDATE_STATUS: "Update Status",
        STICKER_PRINT: "Sticker Print"
    },
    Kee = {
        VIEW: "View Receipt",
        DOWNLOAD: "Download",
        EDIT: "Edit",
        DELETE: "Delete"
    },
    Yee = {
        PRINT_LABEL: "Print Label",
        EDIT_PART: "Edit Part",
        ADJUST_STOCK: "Adjust Stock",
        DELETE: "Delete Part",
        BARCODE: "Barcode"
    },
    Jee = {
        CHANGE_STATUS: "Change Status",
        VIEW: "View",
        APPROVE_AND_BOOK_PICKUP: "Approve And Book A Pickup",
        APPROVE_AND_CREATE_JOB: "Approve And Create Job",
        CONVERT_TO_CUSTOMER: "Convert To Customer"
    },
    Qee = {
        CHECK_STATUS: "Check Status"
    },
    Zee = {
        INVOICE: "Invoice",
        PRINT: "Print",
        JOB_SHEET: "Job Sheet",
        VIEW_JOB: "View Job",
        SEND: "Send Notification",
        DOWNLOAD: "Download"
    },
    Xee = {
        FOLLOW_UP: "Follow Up",
        CUSTOMER: "Convert To Customer",
        UPDATE_STATUS: "Update Status",
        SUBSCRIBE_TO_MAILCHIMP: "Subscribe To Mailchimp",
        DELETE: "Delete"
    },
    ete = {
        FORGET_PASSWORD: "forgot-password",
        ACTIVATION: "user-activation",
        JOB_DELIVERY_OTP: "job-delivery-otp",
        EMAIL_VERIFY_OTP: "email-verify-otp",
        MOBILE_VERIFY_OTP: "mobile-verify-otp"
    },
    tte = ["Adwords", "Calendly", "Facebook", "Google", "Instagram", "Personal Meeting", "Referral", "Website", "Whatsapp"],
    nte = {
        DEFAULT: "default",
        SMALL: "small",
        SMALL_1X: "small-1x",
        MEDIUM: "medium",
        SIDEBAR: "sidebar",
        HEADER: "header",
        LARGE: "large",
        EXTRA_LARGE: "extra-large",
        DROPDOWN_PROFILE_IMAGES: "dropdown-profile-image",
        MOBILE_PROFILE: "mobile-profile"
    },
    rte = {
        NEW: "new",
        UPDATE: "update",
        TRY: "try"
    },
    ote = {
        ROUNDED_CIRCLE: "roundedCircle",
        BADGE_SMALL: "badgeSmall",
        EXTRA_SMALL: "badge-extra-small",
        TITLE: "title"
    },
    ite = {
        TRANSACTION_NOT_FOUND: "TRANSACTION_NOT_FOUND",
        BAD_REQUEST: "BAD_REQUEST",
        AUTHORIZATION_FAILED: "AUTHORIZATION_FAILED",
        INTERNAL_SERVER_ERROR: "INTERNAL_SERVER_ERROR",
        PAYMENT_SUCCESS: "PAYMENT_SUCCESS",
        PAYMENT_ERROR: "PAYMENT_ERROR",
        PAYMENT_FAILED: "PAYMENT_FAILED",
        PAYMENT_PENDING: "PAYMENT_PENDING",
        PAYMENT_CANCELLED: "PAYMENT_CANCELLED",
        PAYMENT_DECLINED: "PAYMENT_DECLINED",
        REQUEST_DECLINE_BY_REQUESTEE: "REQUEST_DECLINE_BY_REQUESTEE",
        SUCCESS: "SUCCESS",
        PAYMENT_ALREADY_COMPLETED: "PAYMENT_ALREADY_COMPLETED",
        INVALID_TRANSACTION_ID: "INVALID_TRANSACTION_ID"
    },
    ste = {
        ALL: "All",
        TODAY: "Today",
        YESTERDAY: "Yesterday",
        THIS_WEEK: "This Week",
        LAST_WEEK: "Last Week",
        THIS_MONTH: "This Month",
        LAST_MONTH: "Last Month",
        LAST_THIRTY_DAYS: "Last 30 Days",
        CUSTOM: "Custom"
    },
    ate = {
        JOB: {
            group_name: "Jobs",
            groupTranslationKey: "jobs",
            items: [{
                title: "How to add a Job",
                translationKey: "how_to_add_a_job",
                url: "https://www.youtube.com/embed/dHFiVCw_8hE"
            }, {
                title: "Job Listing",
                translationKey: "job_listing",
                url: "https://www.youtube.com/embed/3H_0O3_DSgo"
            }, {
                title: "How to export data to excel",
                translationKey: "how_to_export_data_to_excel",
                url: "https://www.youtube.com/embed/iiIh3J1mdfY"
            }]
        },
        CUSTOMER: {
            group_name: "Customers",
            groupTranslationKey: "customer_group_name",
            items: [{
                title: "How to create Customer",
                translationKey: "how_to_create_customer",
                url: "https://www.youtube.com/embed/q0SWYrlETrA"
            }, {
                title: "How to view Customer Profile",
                translationKey: "how_to_view_customer_profile",
                url: "https://www.youtube.com/embed/I64wODCe-WM"
            }, {
                title: "How to set default State and City",
                translationKey: "how_to_set_default_state_and_city",
                url: "https://www.youtube.com/embed/lAvobJ7f7ps"
            }]
        },
        EMPLOYEE: {
            group_name: "Employees",
            groupTranslationKey: "employee_group_name",
            items: [{
                title: "How to create Employee",
                translationKey: "how_to_create_employee",
                url: "https://www.youtube.com/embed/2NNdZLJYCws"
            }, {
                title: "How to add Private Notes",
                translationKey: "how_to_add_private_notes",
                url: "https://www.youtube.com/embed/VaTWfCerHBw"
            }]
        },
        TASK: {
            SHORTCUT_KEYS: "https://www.youtube.com/embed/LBy27VR3ues",
            group_name: "Tasks & Lead",
            groupTranslationKey: "task_group_name",
            items: [{
                title: "How to create Task",
                translationKey: "how_to_create_task",
                url: "https://www.youtube.com/embed/nF3P7nrYOpo"
            }, {
                title: "How to create Lead",
                translationKey: "how_to_create_lead",
                url: "https://www.youtube.com/embed/dNKq4PWU3f8"
            }]
        },
        JOBSETTINGS: {
            group_name: "Job settings",
            groupTranslationKey: "job_settings_group_name",
            items: [{
                title: "How to add new Device Type",
                translationKey: "how_to_add_new_device_type",
                url: "https://www.youtube.com/embed/wTchctddc-U"
            }, {
                title: "How to add new Device Brand",
                translationKey: "how_to_add_new_device_brand",
                url: "https://www.youtube.com/embed/Mq9CWdbOwsQ"
            }, {
                title: "How to add new Job Status",
                translationKey: "how_to_add_new_job_status",
                url: "https://www.youtube.com/embed/e6tpeTEGqYI"
            }]
        },
        SALE: {
            group_name: "Sales",
            groupTranslationKey: "sale_group_name",
            items: [{
                title: "How to create Sale",
                translationKey: "how_to_create_sale",
                url: "https://www.youtube.com/embed/h6eb8CH-OCk"
            }]
        },
        INVENTORY: {
            group_name: "Inventory",
            groupTranslationKey: "inventory_group_name",
            items: [{
                title: "How to add Part",
                translationKey: "how_to_add_part",
                url: "https://www.youtube.com/embed/PLenhyW8_Ng"
            }, {
                title: "How to add Part Supplier",
                translationKey: "how_to_add_part_supplier",
                url: "https://www.youtube.com/embed/WUyY2ULpnoI"
            }]
        },
        BUSINESS_SETTINGS: {
            group_name: "Business Settings",
            groupTranslationKey: "business_settings_group_name",
            items: [{
                title: "How to add basic Business Info",
                translationKey: "how_to_add_basic_business_info",
                url: "https://www.youtube.com/embed/tVzsGBQGioA"
            }, {
                title: "How to add Bank Info",
                translationKey: "how_to_add_bank_info",
                url: "https://www.youtube.com/embed/O1IUTAMooOw"
            }, {
                title: "How to a logo",
                translationKey: "how_to_a_logo",
                url: "https://www.youtube.com/embed/fpScvfLqiVw"
            }]
        },
        SUBSCRIPTION: {
            group_name: "Support & Subscription",
            groupTranslationKey: "subscription_group_name",
            items: [{
                title: "How to buy SMS Pack",
                translationKey: "how_to_buy_sms_pack",
                url: "https://www.youtube.com/embed/gRHI2Ep3-6A",
                indiaOnly: !0
            }, {
                title: "How to send feedback/suggestions",
                translationKey: "how_to_send_feedback_suggestions",
                url: "https://www.youtube.com/embed/lsYlp9fiGLo"
            }]
        },
        EXPENSE: {
            group_name: "Expense",
            groupTranslationKey: "expense_group_name",
            items: [{
                title: "How to add an Expense",
                translationKey: "how_to_add_an_expense",
                url: "https://www.youtube.com/embed/OuUYq6Nzfhc"
            }]
        },
        PICKUPDROP: {
            group_name: "Pickup Drop",
            groupTranslationKey: "pickup_drop_group_name",
            items: [{
                title: "How to a pickup drop",
                translationKey: "how_to_a_pickup_drop",
                url: "https://www.youtube.com/embed/GarKgIcQrXU"
            }]
        },
        FEATURE: {
            group_name: "Feature",
            groupTranslationKey: "feature_group_name",
            items: [{
                title: "OTP verification for Delivery",
                translationKey: "otp_verification_for_delivery",
                url: "https://www.youtube.com/embed/SWq3EmgeNwc"
            }, {
                title: "How to use Column Chooser",
                translationKey: "how_to_use_column_chooser",
                url: "https://www.youtube.com/embed/WuWr_7d3ZbQ"
            }, {
                title: "Access create page by shortcut keys",
                translationKey: "access_create_page_by_shortcut_keys",
                url: "https://www.youtube.com/embed/LBy27VR3ues"
            }]
        },
        SETTINGS: {
            group_name: "Settings",
            groupTranslationKey: "settings_group_name",
            items: [{
                title: "How to set Sequence Setting",
                translationKey: "how_to_set_sequence_setting",
                url: "https://www.youtube.com/embed/GSY-dEv-VbY"
            }, {
                title: "How to set terms & conditions?",
                translationKey: "how_to_set_terms_and_conditions",
                url: "https://www.youtube.com/embed/iVW1Mr2jeg8"
            }, {
                title: "How to add new tax?",
                translationKey: "how_to_add_new_tax",
                url: "https://www.youtube.com/embed/M0RCuVg2guE"
            }]
        }
    },
    cte = {
        JOB_SHEET: {
            name: "job_sheet",
            displayName: "Job Sheet Number"
        },
        SERVICE_INVOICE: {
            name: "service_invoice",
            displayName: "Service Invoice Number"
        },
        QUOTATION: {
            name: "quotation",
            displayName: "Quotation Number"
        },
        SALE_NUMBER: {
            name: "sale_number",
            displayName: "Sale Number"
        },
        PURCHASE: {
            name: "purchase",
            displayName: "Purchase Number"
        },
        AMC_CONTRACT: {
            name: "amc_contract",
            displayName: "Contract Number"
        }
    },
    lte = [{
        column: "price",
        summaryType: "sum",
        alignment: "right"
    }, {
        column: "line_total",
        summaryType: "sum",
        alignment: "right"
    }, {
        column: "tax_amount",
        summaryType: "sum",
        alignment: "right"
    }, {
        column: "discount",
        summaryType: "sum",
        alignment: "right"
    }, {
        column: "sub_total",
        summaryType: "sum",
        alignment: "right"
    }],
    ute = {
        MODIFIED: "Modified",
        AWAITING_APPROVAL: "Awaiting Approval",
        APPROVED: "Approved",
        REJECTED: "Rejected"
    },
    dte = {
        ACTIVE: "ACTIVE",
        INACTIVE: "INACTIVE"
    },
    fte = {
        EMPLOYEE: 1,
        CUSTOMER: 2,
        PART_SUPPLIER: 3,
        OUTSOURCE_VENDOR: 4
    },
    pte = {
        JOB_SHEET: 1,
        QUOTATION: 2,
        JOB_INVOICE: 3,
        SALE: 4,
        PAYMENT: 5,
        JOB_DELIVERY: 6,
        PURCHASE: 7,
        AMC_CONTRACT: 8,
        GDPR_COMPLIANCE: 9,
        SELF_CHECKIN: 10,
        JOB_DIAGNOSIS: 11
    },
    p1 = (function(e) {
        return e.EMAIL = "email", e.SMS = "sms", e.PUSH = "push", e.WHATSAPP = "whatsapp", e
    })(p1 || {});
var T = {
        TENANT: {
            table: "tenants",
            name: "tenant"
        },
        JOB: {
            name: "job",
            table: "jobs",
            displayName: "Jobs",
            translationName: "jobs",
            searchPlaceholder: "JobSheet, Customer, Serial number etc",
            translationString: "job_placeholder",
            createNewLabel: "add_job_label",
            searchPanelWidth: 120,
            isVisibleSearchPanel: !0
        },
        DEVICE_TYPE: {
            name: "device_type",
            table: "device_types",
            displayName: "Device Types",
            searchPlaceholder: "Ex. Laptop",
            createNewLabel: "add_device_type_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        JOB_TYPE: {
            name: "job_type",
            table: "job_types",
            displayName: "Job Types",
            searchPlaceholder: "Ex. Repair, Installation",
            createNewLabel: "add_job_type_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        PAYMENT_TYPE: {
            name: "payment_type",
            table: "payment_types",
            displayName: "Payment Types",
            searchPlaceholder: "Ex. Cash, Card, Online",
            createNewLabel: "add_payment_type_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        DEVICE_BRAND: {
            name: "device_brand",
            table: "device_brands",
            displayName: "Brands",
            searchPlaceholder: "Ex. Dell",
            createNewLabel: "add_device_brand_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        DEVICE_MODEL: {
            name: "device_model",
            table: "device_models",
            displayName: "Models",
            searchPlaceholder: "Ex. Dell N5010",
            createNewLabel: "add_device_model_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        PRE_POST_CONDITIONS: {
            name: "pre_post_condition",
            table: "pre_post_conditions",
            displayName: "Pre Post Condition",
            searchPlaceholder: "Ex. Dead Battery, Display Crack",
            createNewLabel: "add_pre_post_conditions_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        BACKUP_DRIVE: {
            name: "backup_drive",
            table: "backup_drives",
            displayName: "Backup Drives",
            searchPlaceholder: "Ex. Samsung etc",
            createNewLabel: "add_backup_drive_label",
            searchPanelWidth: 120,
            isVisibleSearchPanel: !0
        },
        BACKUP_DRIVE_JOB: {
            name: "backup_drive_job",
            table: "backup_drive_job",
            displayName: "Backup Drive Jobs"
        },
        DEVICE_ACCESSORY: {
            name: "accessory",
            table: "accessories",
            displayName: "Accessories",
            searchPlaceholder: "Ex. Charger",
            createNewLabel: "add_device_accessory_label",
            searchPanelWidth: 120,
            isVisibleSearchPanel: !0
        },
        JOB_SOURCE: {
            name: "job_source",
            table: "job_sources",
            displayName: "Sources",
            searchPlaceholder: "Ex. Just Dial",
            createNewLabel: "add_job_source_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        REPAIR_SERVICE: {
            name: "repair_service",
            table: "repair_services",
            displayName: "Services",
            searchPlaceholder: "Ex. Noisy Fan",
            createNewLabel: "add_repair_service_label",
            searchPanelWidth: 95,
            isVisibleSearchPanel: !0
        },
        JOB_REPAIR_SERVICE: {
            name: "job_repair_service",
            table: "job_repair_services",
            displayName: "Services",
            createNewLabel: "add_job_repair_service_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !1
        },
        JOB_PART: {
            name: "job_part",
            table: "job_part",
            displayName: "Parts",
            createNewLabel: "add_job_part_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !1
        },
        PART_PART_SUPPLIERS: {
            name: "part_part_suppliers",
            displayName: "Part Suppliers"
        },
        PART_TRANSACTION: {
            name: "part_transactions",
            table: "part_transactions",
            displayName: "Part Transaction",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        JOB_STATUS: {
            name: "job_status",
            displayName: "Job Status",
            table: "job_status",
            searchPlaceholder: "Ex. Completed",
            createNewLabel: "add_job_status_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        CUSTOMER: {
            name: "customer",
            table: "users",
            displayName: "Customers",
            formatMessage: "lead_placeholder",
            createNewLabel: "add_customer_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        CONTACT: {
            name: "contact",
            table: "contact",
            displayName: "Contacts",
            searchPlaceholder: "Name, Mobile, Email etc",
            createNewLabel: "add_contact_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        EMPLOYEE: {
            name: "employee",
            table: "users",
            displayName: "Employees",
            searchPlaceholder: "Name, Mobile, Email etc",
            createNewLabel: "add_employee_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        EMPLOYEE_COMMISSION: {
            name: "employee_commission",
            table: "commission_profiles",
            displayName: "Employee Commission",
            searchPlaceholder: "Search employee",
            searchPanelWidth: 300,
            isVisibleSearchPanel: !0
        },
        LEAD: {
            name: "lead",
            table: "leads",
            displayName: "Leads",
            searchPlaceholder: "Name, Mobile, Email etc",
            formatMessage: "lead_placeholder",
            createNewLabel: "add_lead_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        PART: {
            name: "part",
            table: "parts",
            displayName: "Parts",
            searchPlaceholder: "Name, Variant etc",
            createNewLabel: "add_part_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        PART_SUPPLIER: {
            name: "part_supplier",
            table: "users",
            displayName: "Part Suppliers",
            searchPlaceholder: "Name, Phone, Email etc",
            createNewLabel: "add_part_supplier_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        PURCHASE: {
            name: "purchase",
            table: "purchases",
            displayName: "Purchase",
            searchPlaceholder: "Name, Number etc",
            createNewLabel: "add_purchase_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        FOLLOW_UP: {
            name: "follow_up",
            table: "follow_ups",
            displayName: "Follow Up",
            searchPlaceholder: "Channel, Comment etc",
            createNewLabel: "add_follow_up_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        PAYMENT: {
            name: "payment",
            table: "payments",
            displayName: "Payments",
            searchPanelWidth: 150,
            searchPlaceholder: "Search by jobsheet, sale, user",
            isVisibleSearchPanel: !0
        },
        SMS_HISTORY: {
            name: "sms_history",
            table: "sms_histories",
            displayName: "SMS History",
            createNewLabel: "add_sms_history_label",
            searchPlaceholder: "Mobile, Job Id, Message Id etc",
            isVisibleSearchPanel: !0,
            searchPanelWidth: 150
        },
        MESSAGE_LOG: {
            name: "message_log",
            table: "message_logs",
            displayName: "Message Center",
            searchPlaceholder: "Recipient, Subject etc",
            isVisibleSearchPanel: !0,
            searchPanelWidth: 200
        },
        REFERRAL_HISTORY: {
            name: "referral_history",
            table: "referral_histories",
            displayName: "Referral History",
            searchPlaceholder: "Name, Mobile",
            isVisibleSearchPanel: !0
        },
        PICKUP_DROP: {
            name: "pickup_drop",
            table: "pickup_drops",
            displayName: "Pickup Drops",
            searchPlaceholder: "Name, Mobile etc",
            createNewLabel: "add_pickup_drop_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        TASK: {
            name: "task",
            table: "tasks",
            displayName: "Tasks",
            searchPlaceholder: "Title, Description etc",
            createNewLabel: "add_task_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        BULK_PAYMENT: {
            name: "bulk_payment",
            table: "bulk_payments",
            displayName: "Bulk Payments",
            searchPlaceholder: "Title, Description etc",
            createNewLabel: "add_bulk_payment_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        REFERRED_BY_LIST: {
            name: "referred_by",
            table: "referred_by",
            displayName: "Referred By List",
            searchPlaceholder: "JobSheet, Customer, Serial number etc",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        STORAGE_LOCATION: {
            name: "storage_location",
            table: "storage_locations",
            displayName: "Storage Locations",
            searchPlaceholder: "Ex. Shelf1",
            createNewLabel: "add_storage_location_label",
            searchPanelWidth: 100,
            isVisibleSearchPanel: !0
        },
        DEVICE_COLOR: {
            name: "device_color",
            table: "device_colors",
            displayName: "Colors",
            searchPlaceholder: "Ex. Black",
            createNewLabel: "add_device_color_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        ASSIGNEE_HISTORY: {
            name: "assignee_history",
            table: "assigneeHistories",
            displayName: "Assignee History",
            isVisibleSearchPanel: !1
        },
        PAYMENT_LIST: {
            name: "paymentList",
            table: "paymentList",
            displayName: "Payments",
            isVisibleSearchPanel: !1
        },
        STATUS_CHANGE_HISTORY: {
            name: "status_change_history",
            table: "statusChangeHistories",
            displayName: "Status History",
            isVisibleSearchPanel: !1
        },
        JOB_DELIVERY: {
            name: "job_delivery",
            table: "jobDeliveries",
            displayName: "Delivery",
            isVisibleSearchPanel: !1
        },
        TAX: {
            name: "tax",
            table: "taxes",
            displayName: "Taxes",
            searchPanelWidth: 150,
            createNewLabel: "add_tax_label",
            searchPlaceholder: "Name",
            isVisibleSearchPanel: !0
        },
        UPI_LINK: {
            name: "upi_link",
            table: "upi_links",
            displayName: "UPI Links",
            searchPanelWidth: 150,
            createNewLabel: "add_upi_link_label",
            searchPlaceholder: "Name etc",
            isVisibleSearchPanel: !0
        },
        JOB_QUOTATION: {
            name: "job_quotation",
            table: "job_quotations",
            displayName: "Job Quotations",
            searchPanelWidth: 140,
            searchPlaceholder: "Quotation Number",
            isVisibleSearchPanel: !0
        },
        JOB_SHEET: {
            name: "job_sheet",
            table: "jobs",
            displayName: "JobSheet"
        },
        BULK_JOB: {
            name: "bulk_job",
            table: "jobs",
            displayName: "Bulk Job"
        },
        JOB_DIAGNOSIS: {
            name: "job_diagnosis",
            table: "job_diagnoses",
            displayName: "Job Diagnosis",
            searchPanelWidth: 140,
            searchPlaceholder: "Job Number, Issue etc",
            isVisibleSearchPanel: !0
        },
        DIRECTORY_SCAN: {
            name: "directory_scan",
            table: "directory_scans",
            displayName: "Data Validation"
        },
        JOB_INVOICE: {
            name: "job_invoice",
            table: "job_invoices",
            displayName: "Job Invoices",
            searchPanelWidth: 140,
            searchPlaceholder: "Invoice Number",
            isVisibleSearchPanel: !0
        },
        COLLECT_PAYMENT: {
            name: "collect_payment",
            table: "collect_payment",
            displayName: "Collect Payment",
            searchPanelWidth: 140,
            searchPlaceholder: "Transaction Id",
            isVisibleSearchPanel: !0
        },
        SALE: {
            name: "sale",
            table: "sales",
            displayName: "Sales",
            formatMessage: "sale_placeholder",
            createNewLabel: "add_sale_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        AMC_CONTRACT: {
            name: "amc_contract",
            table: "amc_contracts",
            displayName: "Contracts",
            searchPlaceholder: "Contract Number, User name etc",
            createNewLabel: "add_amc_contract_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        DEVICE_INFORMATION: {
            name: "device_information",
            table: "device_information",
            displayName: "Device Information",
            searchPlaceholder: "Device Information, name etc",
            createNewLabel: "add_device_information_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        AMC_SERVICE: {
            name: "amc_service",
            table: "amc_services",
            displayName: "AMC Service",
            searchPlaceholder: "Amc Services, User name etc",
            createNewLabel: "add_amc_service_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        AMC_COMPLAINT: {
            name: "amc_complaint",
            table: "amc_complaints",
            displayName: "Complaint",
            searchPlaceholder: "Amc Complaint, User name etc",
            createNewLabel: "add_amc_complaint_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        SOFTWARE: {
            name: "software",
            table: "softwares",
            displayName: "Software",
            searchPlaceholder: "Software, device name etc",
            createNewLabel: "add_software_label",
            searchPanelWidth: 140,
            isVisibleSearchPanel: !0
        },
        EXPENSE: {
            name: "expense",
            table: "expenses",
            displayName: "Expenses",
            searchPlaceholder: "Name, Description etc",
            createNewLabel: "add_expense_label",
            searchPanelWidth: 130,
            isVisibleSearchPanel: !0
        },
        FEEDBACKS_FORMS: {
            name: "feedback_forms",
            table: "feedbackForms",
            displayName: "Feedbacks",
            createNewLabel: "add_feedbacks_forms_label",
            isVisibleSearchPanel: !1
        },
        EXPENSE_CATEGORY: {
            name: "expense_category",
            table: "expense_categories",
            displayName: "Expense Category",
            searchPlaceholder: "Name",
            createNewLabel: "add_expense_category_label",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        PART_CATEGORY: {
            name: "part_category",
            table: "part_categories",
            displayName: "Part Category",
            searchPlaceholder: "Name",
            createNewLabel: "add_part_category_label",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        PART_SUB_CATEGORY: {
            name: "part_sub_category",
            table: "part_sub_categories",
            displayName: "Part Sub Category",
            searchPlaceholder: "Name",
            createNewLabel: "add_part_sub_category_label",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        IMPORT: {
            name: "import",
            table: "imports",
            displayName: "Imports",
            searchPlaceholder: "Search imports...",
            createNewLabel: "add_import_label",
            searchPanelWidth: 120
        },
        QUOTATION: {
            name: "quotation",
            table: "quotation",
            displayName: "Quotations",
            searchPlaceholder: "Name",
            createNewLabel: "add_quotation_label",
            searchPanelWidth: 120,
            isVisibleSearchPanel: !0
        },
        STANDALONE_QUOTATION: {
            name: "standalone_quotation",
            table: "quotation",
            displayName: "Quotations"
        },
        PERMISSION: {
            name: "permission",
            table: "permissions",
            displayName: "Permission"
        },
        QUICK_REPLY: {
            name: "quick_reply",
            table: "quick_replies",
            displayName: "Quick Reply",
            searchPlaceholder: "Name",
            createNewLabel: "add_quick_reply_label",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        CONTACT_US: {
            name: "contact_us",
            table: "contact_us",
            displayName: "Self Check-In",
            searchPlaceholder: "Name, Mobile etc...",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        OUTSOURCED_JOB: {
            name: "outsourced_job",
            table: "outsourced_job",
            displayName: "Outsourced Jobs",
            translationName: "job.outsource.outsourced_jobs",
            searchPlaceholder: "Name",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        OUTSOURCE_VENDOR: {
            name: "outsource_vendor",
            table: "users",
            displayName: "Outsource Vendors",
            createNewLabel: "add_outsource_vendor_label",
            searchPlaceholder: "Name",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !0
        },
        MAIL_MARKETING: {
            name: "mail_marketing",
            table: "mail_marketing",
            displayName: "Mail Marketing Campaigns",
            createNewLabel: "add_mail_marketing_label",
            searchPlaceholder: "Name",
            searchPanelWidth: 115,
            isVisibleSearchPanel: !1
        },
        REQUEST_CALLBACK: {
            name: "request_callback",
            displayName: "Request Callback"
        },
        USER: {
            name: "user",
            displayName: "Users"
        },
        JOB_COMMENT: {
            name: "job_comment",
            displayName: "Job Comment"
        },
        PRE_POST_CONDITION: {
            name: "pre_post_condition",
            displayName: "Pre Post Condition"
        },
        FEEDBACK: {
            name: "feedback",
            displayName: "Feedback"
        },
        REPORT: {
            name: "report",
            displayName: "Report"
        },
        MAILCHIMP: {
            name: "mailchimp",
            displayName: "Mailchimp"
        },
        GDPR_COMPLIANCE: {
            name: "gdpr_compliance",
            displayName: "GDPR Compliance"
        },
        RIDE: {
            name: "ride",
            displayName: "Ride"
        },
        MESSAGE_TEMPLATE: {
            name: "message_template",
            table: "message_templates",
            displayName: "Notification Templates",
            searchPlaceholder: "Search by event, subject...",
            createNewLabel: "add_message_template_label",
            searchPanelWidth: 150,
            isVisibleSearchPanel: !0
        },
        COMMISSION: {
            name: "commission",
            displayName: "Commission"
        },
        COMMISSION_ENTRY: {
            name: "commission_entry",
            table: "commission_entries",
            displayName: "Commission Entries",
            searchPlaceholder: "Search...",
            searchPanelWidth: 250,
            isVisibleSearchPanel: !1
        },
        COMMISSION_PERIOD: {
            name: "commission_period",
            table: "commission_periods",
            displayName: "Commission Periods",
            searchPlaceholder: "Search...",
            searchPanelWidth: 250,
            isVisibleSearchPanel: !1
        },
        COMMISSION_DASHBOARD: {
            name: "commission_dashboard",
            table: "commission_employees",
            displayName: "Commission Dashboard",
            searchPlaceholder: "Search...",
            searchPanelWidth: 250,
            isVisibleSearchPanel: !1
        },
        MY_COMMISSION: {
            name: "my_commission",
            table: "my_commission",
            displayName: "My Commission",
            searchPlaceholder: "Search...",
            searchPanelWidth: 250,
            isVisibleSearchPanel: !1
        },
        LEDGER: {
            name: "ledger",
            table: "ledger_entries",
            displayName: "Customer Ledger"
        }
    },
    hte = {
        GENERAL_SETTINGS: "general_settings",
        TABLE_SETTINGS: "table_settings",
        REMINDER_SETTINGS: "reminder_settings",
        PRINT_SETTINGS: "print_settings",
        TECHNICIAN_COPY_SETTINGS: "technician_copy_settings",
        AMC_CONTRACT_PRINT_SETTINGS: "amc_contract_print_settings",
        WORKFLOW_SETTINGS: "workflow_settings",
        THEME_AND_LAYOUT_SETTINGS: "theme_and_layout_settings",
        JOB_SETTING: "job_setting",
        JOB_FORM_FIELD_CONFIG: "job_form_field_config",
        SELF_CHECK_IN_SETTINGS: "self_check_in_settings"
    },
    mte = {
        ADVANCE_SETTINGS_FOR_AUTOMATIC_STATUS_CHANGE: "advance_settings_for_automatic_status_change",
        DEFAULT_JOB_CREATION_SETTINGS: "default_job_creation_settings",
        DEFAULT_TASK_CREATION_SETTINGS: "default_task_creation_settings",
        DEFAULT_PURCHASE_CREATION_SETTINGS: "default_purchase_creation_settings",
        BUSINESS_HOURS: "business_hours",
        CUSTOMER_ADDRESS: "customer_address",
        CUSTOMER: "customer",
        DEFAULT_DETAILS: "default_details",
        COVERAGE_DETAILS: "coverage_details",
        BILLING_AND_PAYMENT: "billing_and_payment",
        JOB_SERVICE_OPTION: "job_service_option",
        JOB_INVOICE_TYPE: "job_invoice_type",
        INVOICE_DUE_ALERT_SETTINGS: "invoice_alert_settings",
        CUSTOMIZE_PRINTS_TITLE: "customize_prints_title",
        OTHER: "other",
        SELF_CHECK_IN: "self_check_in",
        DEFAULT_NOTIFICATIONS: "default_notifications"
    },
    gte = {
        PAYMENT: T.PAYMENT.name,
        JOB_INVOICE: T.JOB_INVOICE.name,
        QUOTATION: T.QUOTATION.name,
        JOB_SHEET: T.JOB_SHEET.name
    },
    EI = [T.JOB.name, T.OUTSOURCED_JOB.name, T.LEAD.name, T.JOB_SHEET.name, T.AMC_CONTRACT.name, T.TASK.name, T.SALE.name, T.JOB_INVOICE.name, T.QUOTATION.name, T.PERMISSION.name, T.PICKUP_DROP.name, T.EXPENSE.name, T.PART.name, T.UPI_LINK.name, T.BACKUP_DRIVE.name, T.BACKUP_DRIVE_JOB.name, T.PURCHASE.name, T.PAYMENT.name, T.COLLECT_PAYMENT.name, T.CONTACT_US.name, T.AMC_COMPLAINT.name, T.DEVICE_INFORMATION.name, T.REPORT.name, T.SOFTWARE.name, T.MAIL_MARKETING.name, T.CUSTOMER.name, T.EMPLOYEE.name, T.IMPORT.name, T.COMMISSION.name, T.GDPR_COMPLIANCE.name],
    Ete = {
        LITE: [T.JOB.name, T.SALE.name, T.JOB_INVOICE.name, T.JOB_SHEET.name, T.QUOTATION.name, T.CUSTOMER.name, T.EMPLOYEE.name, T.REPORT.name, T.PAYMENT.name, T.PART.name, T.IMPORT.name, T.GDPR_COMPLIANCE.name],
        BASIC: [T.JOB.name, T.JOB_SHEET.name, T.SALE.name, T.JOB_INVOICE.name, T.QUOTATION.name, T.PAYMENT.name, T.CUSTOMER.name, T.REPORT.name, T.EMPLOYEE.name, T.PURCHASE.name, T.PICKUP_DROP.name, T.UPI_LINK.name, T.PART.name, T.IMPORT.name, T.GDPR_COMPLIANCE.name],
        STANDARD: EI,
        ENTERPRISE: EI
    },
    yte = {
        PRODUCTION: ro.currentEnvironment,
        STAGING: ro.currentEnvironment,
        LOCAL: ro.currentEnvironment
    },
    vte = {
        GOOGLE_PLAY_URL: "https://play.google.com/store/apps/details?id=com.bytephase.app.twa",
        VERSION: "1.0.1"
    },
    Dte = {
        APP_STORE_URL: "https://apps.apple.com/app/id0000000000",
        VERSION: "1.0.1"
    },
    _te = {
        SYSTEM_DISPLAY: "System Display"
    },
    xte = {
        YOUTUBE: "https://www.youtube.com/c/bytephase",
        INSTAGRAM: "https://www.instagram.com/bytephase/",
        FACEBOOK: "https://www.facebook.com/bytephase",
        TWITTER: "https://twitter.com/bytephase"
    },
    Cte = {
        pending: {
            label: "Pending",
            color: "#92400e",
            bgColor: "#fef3c7"
        },
        sent: {
            label: "Sent",
            color: "#166534",
            bgColor: "#dcfce7"
        },
        failed: {
            label: "Failed",
            color: "#991b1b",
            bgColor: "#fee2e2"
        },
        delivered: {
            label: "Delivered",
            color: "#1e40af",
            bgColor: "#dbeafe"
        }
    },
    dg = {
        THERMAL: "thermal",
        NORMAL: "normal",
        BARCODE: "barcode"
    },
    Ite = {
        [dg.THERMAL]: [{
            value: "58mm",
            label: "58mm",
            width: "58mm",
            description: "compact_pos_receipts",
            popular: !1
        }, {
            value: "80mm",
            label: "80mm",
            width: "80mm",
            description: "standard_pos_receipts",
            popular: !0
        }],
        [dg.NORMAL]: [{
            value: "A4",
            label: "A4",
            width: "210 \xD7 297 mm",
            description: "international_standard",
            popular: !0
        }, {
            value: "A5",
            label: "A5",
            width: "148 \xD7 210 mm",
            description: "half_of_a4",
            popular: !1
        }, {
            value: "LETTER",
            label: "Letter",
            width: "8.5 \xD7 11 in",
            description: "us_standard",
            popular: !1
        }],
        [dg.BARCODE]: [{
            value: "38x25mm",
            label: "38 \xD7 25 mm",
            width: "38 \xD7 25",
            description: "extra_small",
            popular: !1
        }, {
            value: "50x25mm",
            label: "50 \xD7 25 mm",
            width: "50 \xD7 25",
            description: "small_narrow",
            popular: !1
        }, {
            value: "50x30mm",
            label: "50 \xD7 30 mm",
            width: "50 \xD7 30",
            description: "standard_size",
            popular: !0
        }, {
            value: "100x50mm",
            label: "100 \xD7 50 mm",
            width: "100 \xD7 50",
            description: "medium_size",
            popular: !1
        }, {
            value: "100x75mm",
            label: "100 \xD7 75 mm",
            width: "100 \xD7 75",
            description: "large_size",
            popular: !1
        }]
    };
var hr = class {
    constructor(t, n) {
        this.api = t, this.base = n
    }
    getById(t) {
        return this.api.get(`${this.base}/${t}`)
    }
    getListByQuery(t = {}) {
        return this.api.getListByQuery(this.base, t)
    }
    create(t) {
        return this.api.post(this.base, t)
    }
    update(t) {
        return this.api.put(`${this.base}/${t.id}`, t)
    }
    patch(t) {
        return this.api.put(`${this.base}/${t.id}`, t)
    }
    delete(t) {
        return this.api.delete(`${this.base}/${t}`)
    }
    restore(t) {
        return this.api.post(`${this.base}/${t}/restore`)
    }
    permanentDelete(t) {
        return this.api.delete(`${this.base}/${t}/permanent`)
    }
};
var vI = (() => {
    class e extends hr {
        constructor(n) {
            super(n, pg), this.api = n, this.endpoint = pg
        }
        me() {
            return this.api.get(this.endpoint + "/me")
        }
        updateRole(n, r) {
            return this.api.patch(this.endpoint + `/updateRole/${n}`, r)
        }
        updateEmail(n, r) {
            return this.api.patch(this.endpoint + `/updateEmail/${n}`, r)
        }
        changePassword(n) {
            return this.api.post(this.endpoint + "/changePassword", n)
        }
        toggleActivation(n) {
            return this.api.patch(this.endpoint + `/toggleActivation/${n}`)
        }
        search(n) {
            return this.api.post(this.endpoint + "/search", n)
        }
        exportToFile(n, r) {
            return this.api.exportToFile(this.endpoint + "/" + n, r)
        }
        getPendingPayments(n) {
            return this.api.get(this.endpoint + `/getPendingPayments/${n}`)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)(_(yi))
            }
        }
        static {
            this.\u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var DI = (() => {
    class e extends hr {
        constructor(n) {
            super(n, hg), this.api = n, this.endpoint = hg
        }
        getEmployeeUserList() {
            return this.api.get(this.endpoint + "/getEmployeeList")
        }
        me() {
            return this.api.get(this.endpoint + "/me")
        }
        updateRole(n, r) {
            return this.api.patch(this.endpoint + `/updateRole/${n}`, r)
        }
        updateEmail(n, r) {
            return this.api.patch(this.endpoint + `/updateEmail/${n}`, r)
        }
        activities(n) {
            return this.api.get(this.endpoint + `/${n}/activities`)
        }
        getList() {
            return this.api.get(this.endpoint + "/getList")
        }
        toggleActivation(n) {
            return this.api.patch(this.endpoint + `/toggleActivation/${n}`)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)(_(yi))
            }
        }
        static {
            this.\u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var _I = (() => {
    class e extends hr {
        constructor(n) {
            super(n, mg), this.api = n, this.endpoint = mg
        }
        updateStatus(n, r) {
            return this.api.patch(this.endpoint + "/updateStatus/" + n, r)
        }
        getLeadListByQuery(n = {}) {
            return this.api.post(this.endpoint + "/getLeadListByQuery", n)
        }
        updateEmail(n, r) {
            return this.api.patch(this.endpoint + `/updateEmail/${n}`, r)
        }
        exportToFile(n, r) {
            return this.api.exportToFile(this.endpoint + "/" + n, r)
        }
        fetchReport(n) {
            return this.api.post(this.endpoint + "/reports", n)
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)(_(yi))
            }
        }
        static {
            this.\u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
var Hte = {
    [T.CUSTOMER.name]: vI,
    [T.EMPLOYEE.name]: DI,
    [T.LEAD.name]: _I
};
var $te = {
        JOB: {
            name: "ticket",
            light: "fa-thin fa-ticket",
            solid: "fa-solid fa-ticket"
        },
        CUSTOMER: {
            name: "users",
            light: "fa-thin fa-users",
            solid: "fa-solid fa-users"
        },
        EMPLOYEE: {
            name: "user-tie",
            light: "fa-thin fa-user-tie",
            solid: "fa-solid fa-user-tie"
        },
        LEAD: {
            name: "user-plus",
            light: "fa-thin fa-user-plus",
            solid: "fa-solid fa-user-plus"
        },
        SALE: {
            name: "store-alt",
            light: "fa-thin fa-store-alt",
            solid: "fa-solid fa-store-alt"
        },
        PURCHASE: {
            name: "shopping-cart",
            light: "fa-thin fa-shopping-cart",
            solid: "fa-solid fa-shopping-cart"
        },
        QUOTATION: {
            name: "file-alt",
            light: "fa-thin fa-file-alt",
            solid: "fa-solid fa-file-alt"
        },
        INVOICE: {
            name: "file-invoice-dollar",
            light: "fa-thin fa-file-invoice-dollar",
            solid: "fa-solid fa-file-invoice-dollar"
        },
        PAYMENT: {
            name: "money-check-alt",
            light: "fa-thin fa-money-check-alt",
            solid: "fa-solid fa-money-check-alt"
        },
        BILLING: {
            name: "wallet",
            light: "fa-thin fa-wallet",
            solid: "fa-solid fa-wallet"
        },
        TASK: {
            name: "tasks",
            light: "fa-thin fa-tasks",
            solid: "fa-solid fa-tasks"
        },
        EXPENSE: {
            name: "sack-dollar",
            light: "fa-thin fa-sack-dollar",
            solid: "fa-solid fa-sack-dollar"
        },
        INVENTORY: {
            name: "inventory",
            light: "fa-thin fa-inventory",
            solid: "fa-solid fa-inventory"
        },
        PART: {
            name: "inventory",
            light: "fa-thin fa-inventory",
            solid: "fa-solid fa-inventory"
        },
        PICKUP_DROP: {
            name: "truck-pickup",
            light: "fa-thin fa-truck-pickup",
            solid: "fa-solid fa-truck-pickup"
        },
        AMC_CONTRACT: {
            name: "file-contract",
            light: "fa-thin fa-file-contract",
            solid: "fa-solid fa-file-contract"
        },
        BACKUP_DRIVE: {
            name: "database",
            light: "fa-thin fa-database",
            solid: "fa-solid fa-database"
        },
        REPORT: {
            name: "chart-line",
            light: "fa-thin fa-chart-line",
            solid: "fa-solid fa-chart-line"
        },
        DASHBOARD: {
            name: "gauge-high",
            light: "fa-thin fa-gauge-high",
            solid: "fa-solid fa-gauge-high"
        },
        SETTINGS: {
            name: "cog",
            light: "fa-thin fa-cog",
            solid: "fa-solid fa-cog"
        },
        NOTIFICATION: {
            name: "bell",
            light: "fa-thin fa-bell",
            solid: "fa-solid fa-bell"
        },
        TEMPLATE: {
            name: "file-alt",
            light: "fa-thin fa-file-alt",
            solid: "fa-solid fa-file-alt"
        },
        MARKETING: {
            name: "envelope-open-text",
            light: "fa-thin fa-envelope-open-text",
            solid: "fa-solid fa-envelope-open-text"
        },
        SELF_CHECK_IN: {
            name: "ballot-check",
            light: "fa-thin fa-ballot-check",
            solid: "fa-solid fa-ballot-check"
        },
        SUPPORT: {
            name: "headset",
            light: "fa-thin fa-headset",
            solid: "fa-solid fa-headset"
        },
        HELP: {
            name: "question-circle",
            light: "fa-thin fa-question-circle",
            solid: "fa-solid fa-question-circle"
        },
        OUTSOURCE: {
            name: "external-link-alt",
            light: "fa-thin fa-external-link-alt",
            solid: "fa-solid fa-external-link-alt"
        },
        COMPLAINT: {
            name: "person-carry-box",
            light: "fa-thin fa-person-carry-box",
            solid: "fa-solid fa-person-carry-box"
        },
        REFERRAL: {
            name: "people-pulling",
            light: "fa-thin fa-people-pulling",
            solid: "fa-solid fa-people-pulling"
        },
        LEDGER: {
            name: "book",
            light: "fa-thin fa-book",
            solid: "fa-solid fa-book"
        }
    },
    Gte = {
        ADD: {
            name: "plus",
            light: "fa-thin fa-plus",
            solid: "fa-solid fa-plus"
        },
        EDIT: {
            name: "edit",
            light: "fa-thin fa-edit",
            solid: "fa-solid fa-edit"
        },
        DELETE: {
            name: "trash",
            light: "fa-thin fa-trash",
            solid: "fa-solid fa-trash"
        },
        SAVE: {
            name: "save",
            light: "fa-thin fa-save",
            solid: "fa-solid fa-save"
        },
        CANCEL: {
            name: "times",
            light: "fa-thin fa-times",
            solid: "fa-solid fa-times"
        },
        CLOSE: {
            name: "times",
            light: "fa-thin fa-times",
            solid: "fa-solid fa-times"
        },
        CONFIRM: {
            name: "check",
            light: "fa-thin fa-check",
            solid: "fa-solid fa-check"
        },
        RESTORE: {
            name: "trash-restore",
            light: "fa-thin fa-trash-restore",
            solid: "fa-solid fa-trash-restore"
        },
        VIEW: {
            name: "eye",
            light: "fa-thin fa-eye",
            solid: "fa-solid fa-eye"
        },
        HIDE: {
            name: "eye-slash",
            light: "fa-thin fa-eye-slash",
            solid: "fa-solid fa-eye-slash"
        },
        EXPAND: {
            name: "expand",
            light: "fa-thin fa-expand",
            solid: "fa-solid fa-expand"
        },
        COLLAPSE: {
            name: "compress",
            light: "fa-thin fa-compress",
            solid: "fa-solid fa-compress"
        },
        DOWNLOAD: {
            name: "download",
            light: "fa-thin fa-download",
            solid: "fa-solid fa-download"
        },
        UPLOAD: {
            name: "upload",
            light: "fa-thin fa-upload",
            solid: "fa-solid fa-upload"
        },
        IMPORT: {
            name: "file-import",
            light: "fa-thin fa-file-import",
            solid: "fa-solid fa-file-import"
        },
        EXPORT: {
            name: "file-export",
            light: "fa-thin fa-file-export",
            solid: "fa-solid fa-file-export"
        },
        PRINT: {
            name: "print",
            light: "fa-thin fa-print",
            solid: "fa-solid fa-print"
        },
        COPY: {
            name: "copy",
            light: "fa-thin fa-copy",
            solid: "fa-solid fa-copy"
        },
        SEARCH: {
            name: "search",
            light: "fa-thin fa-search",
            solid: "fa-solid fa-search"
        },
        FILTER: {
            name: "filter",
            light: "fa-thin fa-filter",
            solid: "fa-solid fa-filter"
        },
        SORT: {
            name: "sort",
            light: "fa-thin fa-sort",
            solid: "fa-solid fa-sort"
        },
        REFRESH: {
            name: "sync",
            light: "fa-thin fa-sync",
            solid: "fa-solid fa-sync"
        },
        BACK: {
            name: "arrow-left",
            light: "fa-thin fa-arrow-left",
            solid: "fa-solid fa-arrow-left"
        },
        FORWARD: {
            name: "arrow-right",
            light: "fa-thin fa-arrow-right",
            solid: "fa-solid fa-arrow-right"
        },
        HOME: {
            name: "home",
            light: "fa-thin fa-home",
            solid: "fa-solid fa-home"
        },
        SEND: {
            name: "paper-plane",
            light: "fa-thin fa-paper-plane",
            solid: "fa-solid fa-paper-plane"
        },
        EMAIL: {
            name: "envelope",
            light: "fa-thin fa-envelope",
            solid: "fa-solid fa-envelope"
        },
        CALL: {
            name: "phone",
            light: "fa-thin fa-phone",
            solid: "fa-solid fa-phone"
        },
        SMS: {
            name: "sms",
            light: "fa-thin fa-sms",
            solid: "fa-solid fa-sms"
        },
        COMMENT: {
            name: "comment",
            light: "fa-thin fa-comment",
            solid: "fa-solid fa-comment"
        },
        SHARE: {
            name: "share-alt",
            light: "fa-thin fa-share-alt",
            solid: "fa-solid fa-share-alt"
        },
        PENCIL: {
            name: "pencil",
            light: "fa-thin fa-pencil",
            solid: "fa-solid fa-pencil"
        },
        CLONE: {
            name: "clone",
            light: "fa-thin fa-clone",
            solid: "fa-solid fa-clone"
        },
        LOGOUT: {
            name: "sign-out-alt",
            light: "fa-thin fa-sign-out-alt",
            solid: "fa-solid fa-sign-out-alt"
        },
        CLEAR_CACHE: {
            name: "broom",
            light: "fa-thin fa-broom",
            solid: "fa-solid fa-broom"
        }
    },
    Wte = {
        SUCCESS: {
            name: "check-circle",
            light: "fa-thin fa-check-circle",
            solid: "fa-solid fa-check-circle"
        },
        ERROR: {
            name: "times-circle",
            light: "fa-thin fa-times-circle",
            solid: "fa-solid fa-times-circle"
        },
        WARNING: {
            name: "exclamation-triangle",
            light: "fa-thin fa-exclamation-triangle",
            solid: "fa-solid fa-exclamation-triangle"
        },
        INFO: {
            name: "info-circle",
            light: "fa-thin fa-info-circle",
            solid: "fa-solid fa-info-circle"
        },
        PENDING: {
            name: "clock",
            light: "fa-thin fa-clock",
            solid: "fa-solid fa-clock"
        },
        VERIFIED: {
            name: "check",
            light: "fa-thin fa-check",
            solid: "fa-solid fa-check"
        },
        LOADING: {
            name: "spinner",
            light: "fa-thin fa-spinner fa-spin",
            solid: "fa-solid fa-spinner fa-spin"
        }
    },
    zte = {
        MENU: {
            name: "bars",
            light: "fa-thin fa-bars",
            solid: "fa-solid fa-bars"
        },
        CHEVRON_RIGHT: {
            name: "chevron-right",
            light: "fa-thin fa-chevron-right",
            solid: "fa-solid fa-chevron-right"
        },
        CHEVRON_LEFT: {
            name: "chevron-left",
            light: "fa-thin fa-chevron-left",
            solid: "fa-solid fa-chevron-left"
        },
        CHEVRON_DOWN: {
            name: "chevron-down",
            light: "fa-thin fa-chevron-down",
            solid: "fa-solid fa-chevron-down"
        },
        CHEVRON_UP: {
            name: "chevron-up",
            light: "fa-thin fa-chevron-up",
            solid: "fa-solid fa-chevron-up"
        },
        ELLIPSIS_V: {
            name: "ellipsis-v",
            light: "fa-thin fa-ellipsis-v",
            solid: "fa-solid fa-ellipsis-v"
        },
        ELLIPSIS_H: {
            name: "ellipsis-h",
            light: "fa-thin fa-ellipsis-h",
            solid: "fa-solid fa-ellipsis-h"
        },
        THEME_DARK: {
            name: "moon",
            light: "fa-thin fa-moon",
            solid: "fa-solid fa-moon"
        },
        THEME_LIGHT: {
            name: "sun-bright",
            light: "fa-thin fa-sun-bright",
            solid: "fa-solid fa-sun-bright"
        },
        QR_CODE: {
            name: "qrcode",
            light: "fa-thin fa-qrcode",
            solid: "fa-solid fa-qrcode"
        },
        BARCODE: {
            name: "barcode",
            light: "fa-thin fa-barcode",
            solid: "fa-solid fa-barcode"
        },
        CALENDAR: {
            name: "calendar",
            light: "fa-thin fa-calendar",
            solid: "fa-solid fa-calendar"
        },
        CLOCK: {
            name: "clock",
            light: "fa-thin fa-clock",
            solid: "fa-solid fa-clock"
        },
        LINK: {
            name: "link",
            light: "fa-thin fa-link",
            solid: "fa-solid fa-link"
        },
        LOCK: {
            name: "lock",
            light: "fa-thin fa-lock",
            solid: "fa-solid fa-lock"
        },
        UNLOCK: {
            name: "unlock",
            light: "fa-thin fa-unlock",
            solid: "fa-solid fa-unlock"
        },
        KEY: {
            name: "key",
            light: "fa-thin fa-key",
            solid: "fa-solid fa-key"
        },
        USER: {
            name: "user",
            light: "fa-thin fa-user",
            solid: "fa-solid fa-user"
        },
        USER_CIRCLE: {
            name: "user-circle",
            light: "fa-thin fa-user-circle",
            solid: "fa-solid fa-user-circle"
        },
        MOBILE: {
            name: "mobile-screen-button",
            light: "fa-thin fa-mobile-screen-button",
            solid: "fa-solid fa-mobile-screen-button"
        },
        LAPTOP: {
            name: "laptop",
            light: "fa-thin fa-laptop",
            solid: "fa-solid fa-laptop"
        },
        GRID: {
            name: "th",
            light: "fa-thin fa-th",
            solid: "fa-solid fa-th"
        },
        LIST: {
            name: "list",
            light: "fa-thin fa-list",
            solid: "fa-solid fa-list"
        },
        TABLE: {
            name: "table",
            light: "fa-thin fa-table",
            solid: "fa-solid fa-table"
        },
        IMAGE: {
            name: "image",
            light: "fa-thin fa-image",
            solid: "fa-solid fa-image"
        },
        FILE: {
            name: "file",
            light: "fa-thin fa-file",
            solid: "fa-solid fa-file"
        },
        FOLDER: {
            name: "folder",
            light: "fa-thin fa-folder",
            solid: "fa-solid fa-folder"
        },
        ATTACHMENT: {
            name: "paperclip",
            light: "fa-thin fa-paperclip",
            solid: "fa-solid fa-paperclip"
        },
        SIGNATURE: {
            name: "signature",
            light: "fa-thin fa-signature",
            solid: "fa-solid fa-signature"
        },
        MAP: {
            name: "map-marker-alt",
            light: "fa-thin fa-map-marker-alt",
            solid: "fa-solid fa-map-marker-alt"
        },
        GRID_2: {
            name: "grid-2",
            light: "fa-thin fa-grid-2",
            solid: "fa-solid fa-grid-2"
        },
        COLUMNS_3: {
            name: "columns-3",
            light: "fa-thin fa-columns-3",
            solid: "fa-solid fa-columns-3"
        },
        TRUCK: {
            name: "truck",
            light: "fa-thin fa-truck",
            solid: "fa-solid fa-truck"
        },
        CHECK_SQUARE: {
            name: "check-square",
            light: "fa-thin fa-check-square",
            solid: "fa-solid fa-check-square"
        },
        USER_CHECK: {
            name: "user-check",
            light: "fa-thin fa-user-check",
            solid: "fa-solid fa-user-check"
        },
        SHIELD_CHECK: {
            name: "shield-check",
            light: "fa-thin fa-shield-check",
            solid: "fa-solid fa-shield-check"
        },
        FOLDER_SEARCH: {
            name: "folder-magnifying-glass",
            light: "fa-thin fa-folder-magnifying-glass",
            solid: "fa-solid fa-folder-magnifying-glass"
        },
        STICKY_NOTE: {
            name: "sticky-note",
            light: "fa-thin fa-sticky-note",
            solid: "fa-solid fa-sticky-note"
        },
        CIRCLE: {
            name: "circle",
            light: "fa-thin fa-circle",
            solid: "fa-solid fa-circle"
        },
        ID_CARD: {
            name: "id-card",
            light: "fa-thin fa-id-card",
            solid: "fa-solid fa-id-card"
        },
        ID_BADGE: {
            name: "id-badge",
            light: "fa-thin fa-id-badge",
            solid: "fa-solid fa-id-badge"
        },
        USER_TIMES: {
            name: "user-times",
            light: "fa-thin fa-user-times",
            solid: "fa-solid fa-user-times"
        },
        HISTORY: {
            name: "history",
            light: "fa-thin fa-history",
            solid: "fa-solid fa-history"
        },
        BARCODE_READ: {
            name: "barcode-read",
            light: "fa-thin fa-barcode-read",
            solid: "fa-solid fa-barcode-read"
        },
        DESKTOP: {
            name: "desktop",
            light: "fa-thin fa-desktop",
            solid: "fa-solid fa-desktop"
        },
        STAR: {
            name: "star",
            light: "fa-thin fa-star",
            solid: "fa-solid fa-star"
        },
        COMMENTS: {
            name: "comments",
            light: "fa-thin fa-comments",
            solid: "fa-solid fa-comments"
        },
        MESSAGES: {
            name: "messages",
            light: "fa-thin fa-messages",
            solid: "fa-solid fa-messages"
        },
        ADDRESS_BOOK: {
            name: "address-book",
            light: "fa-thin fa-address-book",
            solid: "fa-solid fa-address-book"
        },
        PERSON: {
            name: "person",
            light: "fa-thin fa-person",
            solid: "fa-solid fa-person"
        },
        CAMERA: {
            name: "camera",
            light: "fa-thin fa-camera",
            solid: "fa-solid fa-camera"
        },
        COMPUTER: {
            name: "computer",
            light: "fa-thin fa-computer",
            solid: "fa-solid fa-computer"
        },
        PALETTE: {
            name: "palette",
            light: "fa-thin fa-palette",
            solid: "fa-solid fa-palette"
        },
        CIRCLE_QUESTION: {
            name: "circle-question",
            light: "fa-thin fa-circle-question",
            solid: "fa-solid fa-circle-question"
        },
        CIRCLE_INFO: {
            name: "circle-info",
            light: "fa-thin fa-circle-info",
            solid: "fa-solid fa-circle-info"
        },
        RECEIPT: {
            name: "receipt",
            light: "fa-thin fa-receipt",
            solid: "fa-solid fa-receipt"
        },
        LOCATION: {
            name: "location",
            light: "fa-thin fa-location",
            solid: "fa-solid fa-location"
        },
        CASH_REGISTER: {
            name: "cash-register",
            light: "fa-thin fa-cash-register",
            solid: "fa-solid fa-cash-register"
        },
        DIAGRAM_PROJECT: {
            name: "diagram-project",
            light: "fa-thin fa-diagram-project",
            solid: "fa-solid fa-diagram-project"
        },
        MAGNIFYING_GLASS_CHART: {
            name: "magnifying-glass-chart",
            light: "fa-thin fa-magnifying-glass-chart",
            solid: "fa-solid fa-magnifying-glass-chart"
        },
        CIRCLE_CHECK: {
            name: "circle-check",
            light: "fa-thin fa-circle-check",
            solid: "fa-solid fa-circle-check"
        },
        FILE_LINES: {
            name: "file-lines",
            light: "fa-thin fa-file-lines",
            solid: "fa-solid fa-file-lines"
        },
        WAND_MAGIC: {
            name: "wand-magic-sparkles",
            light: "fa-thin fa-wand-magic-sparkles",
            solid: "fa-solid fa-wand-magic-sparkles"
        },
        ROAD: {
            name: "road",
            light: "fa-thin fa-road",
            solid: "fa-solid fa-road"
        },
        README: {
            name: "readme",
            light: "fa-thin fa-readme",
            solid: "fa-solid fa-readme"
        },
        GIFTS: {
            name: "gifts",
            light: "fa-thin fa-gifts",
            solid: "fa-solid fa-gifts"
        },
        COMMENT_SMS: {
            name: "comment-sms",
            light: "fa-thin fa-comment-sms",
            solid: "fa-solid fa-comment-sms"
        },
        ENVELOPES_BULK: {
            name: "envelopes-bulk",
            light: "fa-thin fa-envelopes-bulk",
            solid: "fa-solid fa-envelopes-bulk"
        },
        MESSAGE: {
            name: "message",
            light: "fa-thin fa-message",
            solid: "fa-solid fa-message"
        },
        MOBILE_SIMPLE: {
            name: "mobile",
            light: "fa-thin fa-mobile",
            solid: "fa-solid fa-mobile"
        },
        CALENDAR_CHECK: {
            name: "calendar-check",
            light: "fa-thin fa-calendar-check",
            solid: "fa-solid fa-calendar-check"
        },
        BOX: {
            name: "box",
            light: "fa-thin fa-box",
            solid: "fa-solid fa-box"
        },
        TRUCK_PICKUP: {
            name: "truck-pickup",
            light: "fa-thin fa-truck-pickup",
            solid: "fa-solid fa-truck-pickup"
        },
        USER_LOCK: {
            name: "user-lock",
            light: "fa-thin fa-user-lock",
            solid: "fa-solid fa-user-lock"
        },
        BUSINESS_TIME: {
            name: "business-time",
            light: "fa-thin fa-business-time",
            solid: "fa-solid fa-business-time"
        },
        CHART_NETWORK: {
            name: "chart-network",
            light: "fa-thin fa-chart-network",
            solid: "fa-solid fa-chart-network"
        },
        PEOPLE_CARRY_BOX: {
            name: "people-carry-box",
            light: "fa-thin fa-people-carry-box",
            solid: "fa-solid fa-people-carry-box"
        },
        PERSON_CARRY_BOX: {
            name: "person-carry-box",
            light: "fa-thin fa-person-carry-box",
            solid: "fa-solid fa-person-carry-box"
        },
        TAGS: {
            name: "tags",
            light: "fa-thin fa-tags",
            solid: "fa-solid fa-tags"
        },
        USER_SHIELD: {
            name: "user-shield",
            light: "fa-thin fa-user-shield",
            solid: "fa-solid fa-user-shield"
        },
        LAYER_GROUP: {
            name: "layer-group",
            light: "fa-thin fa-layer-group",
            solid: "fa-solid fa-layer-group"
        },
        SITEMAP: {
            name: "sitemap",
            light: "fa-thin fa-sitemap",
            solid: "fa-solid fa-sitemap"
        },
        WAREHOUSE: {
            name: "warehouse",
            light: "fa-thin fa-warehouse",
            solid: "fa-solid fa-warehouse"
        },
        PERCENT: {
            name: "percent",
            light: "fa-thin fa-percent",
            solid: "fa-solid fa-percent"
        },
        CALENDAR_PLUS: {
            name: "calendar-plus",
            light: "fa-thin fa-calendar-plus",
            solid: "fa-solid fa-calendar-plus"
        },
        ANGLE_UP: {
            name: "angle-up",
            light: "fa-thin fa-angle-up",
            solid: "fa-solid fa-angle-up"
        },
        ANGLES_UP: {
            name: "angles-up",
            light: "fa-thin fa-angles-up",
            solid: "fa-solid fa-angles-up"
        },
        EQUALS: {
            name: "equals",
            light: "fa-thin fa-equals",
            solid: "fa-solid fa-equals"
        },
        ROUTE: {
            name: "route",
            light: "fa-thin fa-route",
            solid: "fa-solid fa-route"
        },
        USER_PLUS: {
            name: "user-plus",
            light: "fa-thin fa-user-plus",
            solid: "fa-solid fa-user-plus"
        },
        TICKET: {
            name: "ticket",
            light: "fa-thin fa-ticket",
            solid: "fa-solid fa-ticket"
        }
    },
    qte = {
        BUSINESS_INFO: {
            name: "building",
            light: "fa-thin fa-building",
            solid: "fa-solid fa-building"
        },
        BANK: {
            name: "money-check-pen",
            light: "fa-thin fa-money-check-pen",
            solid: "fa-solid fa-money-check-pen"
        },
        LOGO: {
            name: "icons",
            light: "fa-thin fa-icons",
            solid: "fa-solid fa-icons"
        },
        SIGNATURE: {
            name: "signature",
            light: "fa-thin fa-signature",
            solid: "fa-solid fa-signature"
        },
        LINKS: {
            name: "link",
            light: "fa-thin fa-link",
            solid: "fa-solid fa-link"
        },
        BUSINESS_HOURS: {
            name: "calendar-clock",
            light: "fa-thin fa-calendar-clock",
            solid: "fa-solid fa-calendar-clock"
        },
        BUSINESS_TYPE: {
            name: "briefcase",
            light: "fa-thin fa-briefcase",
            solid: "fa-solid fa-briefcase"
        },
        COMMUNICATION: {
            name: "bell",
            light: "fa-thin fa-bell",
            solid: "fa-solid fa-bell"
        },
        EMAIL: {
            name: "envelope",
            light: "fa-thin fa-envelope",
            solid: "fa-solid fa-envelope"
        },
        SMS: {
            name: "sms",
            light: "fa-thin fa-sms",
            solid: "fa-solid fa-sms"
        },
        REMINDER: {
            name: "bell",
            light: "fa-thin fa-bell",
            solid: "fa-solid fa-bell"
        },
        SYSTEM_CONFIG: {
            name: "cog",
            light: "fa-thin fa-cog",
            solid: "fa-solid fa-cog"
        },
        CUSTOM_FIELDS: {
            name: "pen-field",
            light: "fa-thin fa-pen-field",
            solid: "fa-solid fa-pen-field"
        },
        GENERAL: {
            name: "sliders",
            light: "fa-thin fa-sliders",
            solid: "fa-solid fa-sliders"
        },
        MODULES: {
            name: "bars",
            light: "fa-thin fa-bars",
            solid: "fa-solid fa-bars"
        },
        TAX: {
            name: "percentage",
            light: "fa-thin fa-percentage",
            solid: "fa-solid fa-percentage"
        },
        TERMS: {
            name: "file",
            light: "fa-thin fa-file",
            solid: "fa-solid fa-file"
        },
        SEQUENCE: {
            name: "sliders-h",
            light: "fa-thin fa-sliders-h",
            solid: "fa-solid fa-sliders-h"
        },
        WORKFLOW: {
            name: "wrench",
            light: "fa-thin fa-wrench",
            solid: "fa-solid fa-wrench"
        },
        ADDRESS: {
            name: "map-location",
            light: "fa-thin fa-map-location",
            solid: "fa-solid fa-map-location"
        },
        DUE_DATE: {
            name: "calendar-days",
            light: "fa-thin fa-calendar-days",
            solid: "fa-solid fa-calendar-days"
        },
        PRINT: {
            name: "print",
            light: "fa-thin fa-print",
            solid: "fa-solid fa-print"
        },
        THEME: {
            name: "table-layout",
            light: "fa-thin fa-table-layout",
            solid: "fa-solid fa-table-layout"
        },
        EXPENSE_CATEGORY: {
            name: "dollar-sign",
            light: "fa-thin fa-dollar-sign",
            solid: "fa-solid fa-dollar-sign"
        },
        PAYMENT_TYPE: {
            name: "credit-card",
            light: "fa-thin fa-credit-card",
            solid: "fa-solid fa-credit-card"
        },
        INTEGRATIONS: {
            name: "link",
            light: "fa-thin fa-link",
            solid: "fa-solid fa-link"
        },
        SUBSCRIPTION: {
            name: "shopping-cart",
            light: "fa-thin fa-shopping-cart",
            solid: "fa-solid fa-shopping-cart"
        },
        PRINT_SLASH: {
            name: "print-slash",
            light: "fa-thin fa-print-slash",
            solid: "fa-solid fa-print-slash"
        },
        PRINT_MAGNIFYING_GLASS: {
            name: "print-magnifying-glass",
            light: "fa-thin fa-print-magnifying-glass",
            solid: "fa-solid fa-print-magnifying-glass"
        },
        MOUSE_ALT: {
            name: "mouse-alt",
            light: "fa-thin fa-mouse-alt",
            solid: "fa-solid fa-mouse-alt"
        },
        WHITE_LABEL: {
            name: "tag",
            light: "fa-thin fa-tag",
            solid: "fa-solid fa-tag"
        }
    },
    Kte = {
        REPAIR: {
            name: "wrench",
            light: "fa-thin fa-wrench",
            solid: "fa-solid fa-wrench"
        },
        RECOVERY: {
            name: "hdd",
            light: "fa-thin fa-hdd",
            solid: "fa-solid fa-hdd"
        },
        DEVICE: {
            name: "laptop",
            light: "fa-thin fa-laptop",
            solid: "fa-solid fa-laptop"
        },
        BRAND: {
            name: "tag",
            light: "fa-thin fa-tag",
            solid: "fa-solid fa-tag"
        },
        SERVICE: {
            name: "tools",
            light: "fa-thin fa-tools",
            solid: "fa-solid fa-tools"
        },
        ACCESSORY: {
            name: "plug",
            light: "fa-thin fa-plug",
            solid: "fa-solid fa-plug"
        },
        CONDITION: {
            name: "clipboard-check",
            light: "fa-thin fa-clipboard-check",
            solid: "fa-solid fa-clipboard-check"
        },
        DATA_VALIDATION: {
            name: "badge-check",
            light: "fa-thin fa-badge-check",
            solid: "fa-solid fa-badge-check"
        },
        STETHOSCOPE: {
            name: "stethoscope",
            light: "fa-thin fa-stethoscope",
            solid: "fa-solid fa-stethoscope"
        },
        DESKTOP: {
            name: "desktop",
            light: "fa-thin fa-desktop",
            solid: "fa-solid fa-desktop"
        },
        DICE: {
            name: "dice-d6",
            light: "fa-thin fa-dice-d6",
            solid: "fa-solid fa-dice-d6"
        },
        DESKTOP_ARROW_DOWN: {
            name: "desktop-arrow-down",
            light: "fa-thin fa-desktop-arrow-down",
            solid: "fa-solid fa-desktop-arrow-down"
        },
        CONTAINER_STORAGE: {
            name: "container-storage",
            light: "fa-thin fa-container-storage",
            solid: "fa-solid fa-container-storage"
        },
        TINT: {
            name: "tint",
            light: "fa-thin fa-tint",
            solid: "fa-solid fa-tint"
        },
        CIRCLE_NODES: {
            name: "circle-nodes",
            light: "fa-thin fa-circle-nodes",
            solid: "fa-solid fa-circle-nodes"
        },
        MESSAGES: {
            name: "messages",
            light: "fa-thin fa-messages",
            solid: "fa-solid fa-messages"
        }
    },
    Yte = {
        PDF: {
            name: "file-pdf",
            light: "fa-thin fa-file-pdf",
            solid: "fa-solid fa-file-pdf"
        },
        EXCEL: {
            name: "file-excel",
            light: "fa-thin fa-file-excel",
            solid: "fa-solid fa-file-excel"
        },
        WORD: {
            name: "file-word",
            light: "fa-thin fa-file-word",
            solid: "fa-solid fa-file-word"
        },
        CSV: {
            name: "file-csv",
            light: "fa-thin fa-file-csv",
            solid: "fa-solid fa-file-csv"
        },
        DOWNLOAD: {
            name: "file-arrow-down",
            light: "fa-thin fa-file-arrow-down",
            solid: "fa-solid fa-file-arrow-down"
        },
        INVOICE: {
            name: "file-invoice",
            light: "fa-thin fa-file-invoice",
            solid: "fa-solid fa-file-invoice"
        }
    };
var yi = (() => {
    class e {
        constructor(n) {
            this.http = n, this.baseUrl = yI
        }
        get(n) {
            return this.http.get(this.baseUrl + n)
        }
        getText(n) {
            return this.http.get(this.baseUrl + n, {
                responseType: "text"
            })
        }
        getWithParams(n, r) {
            return this.http.get(this.baseUrl + n, {
                params: r
            })
        }
        getListByQuery(n, r) {
            return this.http.get(this.baseUrl + n, {
                params: r
            })
        }
        post(n, r = {}) {
            return this.http.post(this.baseUrl + n, r)
        }
        postWithHeaders(n, r = {}, o = {}) {
            return this.http.post(this.baseUrl + n, r, {
                headers: new st(o)
            })
        }
        put(n, r = {}) {
            return this.http.put(this.baseUrl + n, r)
        }
        patch(n, r = {}) {
            return this.http.patch(this.baseUrl + n, r)
        }
        delete(n) {
            return this.http.delete(this.baseUrl + n)
        }
        restore(n) {
            return this.http.get(this.baseUrl + "/restore" + n)
        }
        upload(n, r) {
            let o = new FormData;
            o.append("file", r);
            let i = new st({
                enctype: "multipart/form-data"
            });
            return this.http.post(this.baseUrl + n, o, {
                headers: i
            })
        }
        uploadFormData(n, r) {
            let o = new st({
                enctype: "multipart/form-data"
            });
            return this.http.post(this.baseUrl + n, r, {
                headers: o
            })
        }
        exportUsingGet(n) {
            return this.http.get(this.baseUrl + n, {
                observe: "response",
                responseType: "blob"
            })
        }
        getPdfPrint(n, r) {
            let o = new st({
                "Content-Type": "application/json"
            });
            return this.http.post(this.baseUrl + n, r, {
                observe: "response",
                responseType: "blob",
                headers: o
            })
        }
        exportToFile(n, r) {
            return this.http.post(this.baseUrl + n, r, {
                observe: "response",
                responseType: "blob"
            }).pipe(hn(o => o.error instanceof Blob ? new P(i => {
                let s = new FileReader;
                s.onload = () => {
                    try {
                        let a = JSON.parse(s.result);
                        i.error(a)
                    } catch (a) {
                        i.error({
                            message: "Unknown error occurred",
                            details: s.result
                        })
                    }
                }, s.readAsText(o.error)
            }) : bi(o)))
        }
        getFiles(n, r) {
            return this.http.post(this.baseUrl + n, r, {
                observe: "response",
                responseType: "blob"
            })
        }
        static {
            this.\u0275fac = function(r) {
                return new(r || e)(_(tu))
            }
        }
        static {
            this.\u0275prov = y({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
export {
    oe as a, P as b, ne as c, ye as d, Ti as e, sd as f, LI as g, ve as h, ZU as i, Og as j, XU as k, eB as l, J as m, R as n, bi as o, ka as p, $I as q, GI as r, zI as s, j as t, ja as u, de as v, Kt as w, zn as x, wi as y, nT as z, ld as A, Tr as B, lT as C, uT as D, dT as E, Ne as F, fT as G, hn as H, qn as I, Jg as J, tt as K, pT as L, dd as M, gT as N, tE as O, Do as P, mn as Q, rE as R, ET as S, pd as T, Ue as U, _o as V, yT as W, nt as X, DT as Y, g as Z, dt as _, Qa as $, y as aa, ft as ba, v as ca, _ as da, h as ea, Zn as fa, re as ga, OE as ha, PE as ia, WE as ja, zE as ka, fe as la, Z as ma, He as na, Re as oa, Q as pa, ae as qa, ZE as ra, rn as sa, as as ta, cs as ua, it as va, us as wa, OS as xa, ds as ya, PS as za, vt as Aa, fb as Ba, T0 as Ca, S0 as Da, mb as Ea, Nb as Fa, hs as Ga, nn as Ha, Gr as Ia, Tn as Ja, k as Ka, Dt as La, Rv as Ma, Qp as Na, Ut as Oa, be as Pa, Sn as Qa, Fv as Ra, Bv as Sa, Yr as Ta, th as Ua, yl as Va, Bt as Wa, Dl as Xa, Tc as Ya, $A as Za, WA as _a, zA as $a, qA as ab, KA as bb, YA as cb, JA as db, Gv as eb, zc as fb, ih as gb, _l as hb, sh as ib, ah as jb, Wv as kb, ch as lb, xl as mb, qv as nb, Kv as ob, tM as pb, nM as qb, Jv as rb, Cl as sb, Zv as tb, aM as ub, lM as vb, uM as wb, Il as xb, eD as yb, lh as zb, uh as Ab, tD as Bb, fM as Cb, pM as Db, Tl as Eb, sD as Fb, SM as Gb, wM as Hb, UM as Ib, gD as Jb, dh as Kb, ED as Lb, yD as Mb, vD as Nb, DD as Ob, _D as Pb, $M as Qb, xD as Rb, ID as Sb, GM as Tb, WM as Ub, zM as Vb, qM as Wb, KM as Xb, ZM as Yb, XM as Zb, eN as _b, tN as $b, nN as ac, rN as bc, oN as cc, iN as dc, sN as ec, aN as fc, uN as gc, fN as hc, pN as ic, hN as jc, mN as kc, te as lc, Is as mc, hh as nc, c5 as oc, zD as pc, l5 as qc, u5 as rc, d5 as sc, f5 as tc, ir as uc, Th as vc, bn as wc, Sh as xc, h5 as yc, XD as zc, jt as Ac, Vt as Bc, Ol as Cc, sr as Dc, hR as Ec, C_ as Fc, mR as Gc, Bh as Hc, gR as Ic, ER as Jc, yR as Kc, vR as Lc, xR as Mc, IR as Nc, TR as Oc, bR as Pc, AR as Qc, MR as Rc, OR as Sc, jh as Tc, Jr as Uc, CK as Vc, IK as Wc, TK as Xc, Jh as Yc, cO as Zc, dO as _c, st as $c, qo as ad, z_ as bd, tm as cd, tu as dd, OO as ed, BY as fd, Q_ as gd, kO as hd, O as id, ur as jd, lr as kd, lt as ld, xt as md, eo as nd, no as od, On as pd, bm as qd, Nm as rd, Wt as sd, Nu as td, hL as ud, vL as vd, ro as wd, Un as xd, Bn as yd, Xe as zd, DZ as Ad, _Z as Bd, xZ as Cd, CZ as Dd, IZ as Ed, TZ as Fd, SZ as Gd, bZ as Hd, wZ as Id, AZ as Jd, MZ as Kd, NZ as Ld, RZ as Md, fg as Nd, yI as Od, LZ as Pd, kZ as Qd, FZ as Rd, UZ as Sd, BZ as Td, jZ as Ud, HZ as Vd, VZ as Wd, $Z as Xd, GZ as Yd, WZ as Zd, zZ as _d, qZ as $d, KZ as ae, YZ as be, JZ as ce, QZ as de, ZZ as ee, XZ as fe, e7 as ge, t7 as he, n7 as ie, r7 as je, o7 as ke, i7 as le, s7 as me, a7 as ne, c7 as oe, l7 as pe, u7 as qe, d7 as re, f7 as se, p7 as te, h7 as ue, m7 as ve, g7 as we, E7 as xe, y7 as ye, v7 as ze, D7 as Ae, _7 as Be, x7 as Ce, C7 as De, I7 as Ee, T7 as Fe, S7 as Ge, b7 as He, w7 as Ie, A7 as Je, M7 as Ke, N7 as Le, R7 as Me, O7 as Ne, P7 as Oe, L7 as Pe, k7 as Qe, F7 as Re, U7 as Se, B7 as Te, j7 as Ue, H7 as Ve, V7 as We, $7 as Xe, G7 as Ye, W7 as Ze, z7 as _e, q7 as $e, K7 as af, Y7 as bf, J7 as cf, Q7 as df, Z7 as ef, X7 as ff, eX as gf, tX as hf, nX as
    if, rX as jf, oX as kf, iX as lf, sX as mf, aX as nf, cX as of , lX as pf, uX as qf, dX as rf, fX as sf, pX as tf, hX as uf, mX as vf, gX as wf, EX as xf, yX as yf, vX as zf, DX as Af, _X as Bf, xX as Cf, CX as Df, IX as Ef, TX as Ff, SX as Gf, bX as Hf, wX as If, AX as Jf, MX as Kf, NX as Lf, RX as Mf, OX as Nf, PX as Of, LX as Pf, kX as Qf, FX as Rf, UX as Sf, BX as Tf, jX as Uf, HX as Vf, VX as Wf, $X as Xf, GX as Yf, WX as Zf, zX as _f, qX as $f, KX as ag, YX as bg, JX as cg, QX as dg, ZX as eg, XX as fg, eee as gg, tee as hg, nee as ig, ree as jg, oee as kg, iee as lg, see as mg, aee as ng, cee as og, lee as pg, uee as qg, dee as rg, fee as sg, pee as tg, hee as ug, mee as vg, gee as wg, Eee as xg, yee as yg, vee as zg, Dee as Ag, _ee as Bg, xee as Cg, Cee as Dg, Iee as Eg, Tee as Fg, See as Gg, bee as Hg, wee as Ig, Aee as Jg, Mee as Kg, wF as Lg, Nee as Mg, AF as Ng, MF as Og, ao as Pg, Ree as Qg, Oee as Rg, Pee as Sg, NF as Tg, Lee as Ug, RF as Vg, OF as Wg, PF as Xg, LF as Yg, kF as Zg, FF as _g, UF as $g, BF as ah, jF as bh, HF as ch, VF as dh, $F as eh, GF as fh, WF as gh, zF as hh, qF as ih, KF as jh, YF as kh, JF as lh, QF as mh, ZF as nh, XF as oh, e1 as ph, t1 as qh, n1 as rh, r1 as sh, kee as th, Fee as uh, Uee as vh, o1 as wh, i1 as xh, s1 as yh, a1 as zh, c1 as Ah, l1 as Bh, u1 as Ch, d1 as Dh, f1 as Eh, Bee as Fh, jee as Gh, Hee as Hh, Vee as Ih, $ee as Jh, Gee as Kh, Wee as Lh, zee as Mh, qee as Nh, Kee as Oh, Yee as Ph, Jee as Qh, Qee as Rh, Zee as Sh, Xee as Th, ete as Uh, tte as Vh, nte as Wh, rte as Xh, ote as Yh, ite as Zh, ste as _h, ate as $h, cte as ai, lte as bi, ute as ci, dte as di, fte as ei, pte as fi, p1 as gi, T as hi, hte as ii, mte as ji, gte as ki, Ete as li, vte as mi, Dte as ni, _te as oi, xte as pi, Cte as qi, dg as ri, Ite as si, hr as ti, yi as ui, vI as vi, DI as wi, _I as xi, Hte as yi, $te as zi, Gte as Ai, Wte as Bi, zte as Ci, qte as Di, Kte as Ei, Yte as Fi, fr as Gi, nC as Hi, ta as Ii, rC as Ji, un as Ki, we as Li, dn as Mi, ci as Ni, Ct as Oi, oC as Pi, We as Qi, iC as Ri, Ru as Si, sC as Ti, na as Ui, li as Vi, aC as Wi, V6 as Xi, SL as Yi, Te as Zi, bL as _i, AL as $i, ui as aj, ML as bj, cC as cj, e9 as dj, di as ej, fC as fj, It as gj, fi as hj, oo as ij, ze as jj, UL as kj, ra as lj, $m as mj, CC as nj, Gm as oj, QL as pj, Wm as qj, ZL as rj, Tt as sj, MC as tj, NC as uj, EJ as vj, nk as wj, yJ as xj, ik as yj, vJ as zj, DJ as Aj, _J as Bj, bJ as Cj, jC as Dj, HC as Ej, Pn as Fj, mk as Gj, gk as Hj, pi as Ij, Ym as Jj, JC as Kj, Ck as Lj, Bu as Mj, eQ as Nj, QC as Oj, XC as Pj, mi as Qj, ju as Rj, EQ as Sj, Tk as Tj, Sk as Uj, nI as Vj, rI as Wj, bk as Xj, wk as Yj, Ak as Zj, oI as _j, Nk as $j, Ok as ak, Pk as bk, so as ck, Lk as dk, kk as ek, Fk as fk, Uk as gk, Hk as hk, yQ as ik, St as jk, lI as kk, uI as lk, nF as mk, kQ as nk, ca as ok, ag as pk, dF as qk, fF as rk, hF as sk, XQ as tk, la as uk, yF as vk, vF as wk, DF as xk, _F as yk, CF as zk, yZ as Ak
};