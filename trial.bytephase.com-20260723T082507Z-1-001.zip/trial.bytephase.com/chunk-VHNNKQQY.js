import {
    d as D,
    i as j
} from "./chunk-FBFWB55K.js";
var rt = D({
    "./pwa-action-sheet.entry.js": () =>
        import ("./chunk-3HLUS2E5.js"),
    "./pwa-camera-modal-instance.entry.js": () =>
        import ("./chunk-DQNGODFY.js"),
    "./pwa-camera-modal.entry.js": () =>
        import ("./chunk-KIOHJHSO.js"),
    "./pwa-camera.entry.js": () =>
        import ("./chunk-GPTKZ5OH.js"),
    "./pwa-toast.entry.js": () =>
        import ("./chunk-5VOGFD3M.js")
});
var at = "ionicpwaelements",
    I, Q, u = !1,
    O = !1,
    h = (t, e = "") => () => {},
    ft = (t, e) => () => {},
    dt = "{visibility:hidden}.hydrated{visibility:inherit}",
    W = {},
    ut = "http://www.w3.org/2000/svg",
    pt = "http://www.w3.org/1999/xhtml",
    gt = t => t != null,
    _ = t => (t = typeof t, t === "object" || t === "function");

function X(t) {
    var e, n, s;
    return (s = (n = (e = t.head) === null || e === void 0 ? void 0 : e.querySelector('meta[name="csp-nonce"]')) === null || n === void 0 ? void 0 : n.getAttribute("content")) !== null && s !== void 0 ? s : void 0
}
var ht = (t, e, ...n) => {
        let s = null,
            l = !1,
            o = !1,
            c = [],
            $ = r => {
                for (let a = 0; a < r.length; a++) s = r[a], Array.isArray(s) ? $(s) : s != null && typeof s != "boolean" && ((l = typeof t != "function" && !_(s)) && (s = String(s)), l && o ? c[c.length - 1].$text$ += s : c.push(l ? q(null, s) : s), o = l)
            };
        if ($(n), e) {
            let r = e.className || e.class;
            r && (e.class = typeof r != "object" ? r : Object.keys(r).filter(a => r[a]).join(" "))
        }
        let i = q(t, null);
        return i.$attrs$ = e, c.length > 0 && (i.$children$ = c), i
    },
    q = (t, e) => {
        let n = {
            $flags$: 0,
            $tag$: t,
            $text$: e,
            $elm$: null,
            $children$: null
        };
        return n.$attrs$ = null, n
    },
    yt = {},
    St = t => t && t.$tag$ === yt,
    mt = (t, e) => t != null && !_(t) ? e & 4 ? t === "false" ? !1 : t === "" || !!t : e & 2 ? parseFloat(t) : e & 1 ? String(t) : t : t,
    vt = t => y(t).$hostElement$,
    Xt = (t, e, n) => {
        let s = vt(t);
        return {
            emit: l => Z(s, e, {
                bubbles: !!(n & 4),
                composed: !!(n & 2),
                cancelable: !!(n & 1),
                detail: l
            })
        }
    },
    Z = (t, e, n) => {
        let s = d.ce(e, n);
        return t.dispatchEvent(s), s
    },
    C = new WeakMap,
    Et = (t, e, n) => {
        let s = k.get(t);
        Gt && n ? (s = s || new CSSStyleSheet, typeof s == "string" ? s = e : s.replaceSync(e)) : s = e, k.set(t, s)
    },
    Lt = (t, e, n, s) => {
        var l;
        let o = R(e),
            c = k.get(o);
        if (t = t.nodeType === 11 ? t : g, c)
            if (typeof c == "string") {
                t = t.head || t;
                let $ = C.get(t),
                    i;
                if ($ || C.set(t, $ = new Set), !$.has(o)) {
                    {
                        i = g.createElement("style"), i.innerHTML = c;
                        let r = (l = d.$nonce$) !== null && l !== void 0 ? l : X(g);
                        r != null && i.setAttribute("nonce", r), t.insertBefore(i, t.querySelector("link"))
                    }
                    $ && $.add(o)
                }
            } else t.adoptedStyleSheets.includes(c) || (t.adoptedStyleSheets = [...t.adoptedStyleSheets, c]);
        return o
    },
    Pt = t => {
        let e = t.$cmpMeta$,
            n = t.$hostElement$,
            s = e.$flags$,
            l = h("attachStyles", e.$tagName$),
            o = Lt(n.shadowRoot ? n.shadowRoot : n.getRootNode(), e);
        s & 10 && (n["s-sc"] = o, n.classList.add(o + "-h")), l()
    },
    R = (t, e) => "sc-" + t.$tagName$,
    Y = (t, e, n, s, l, o) => {
        if (n !== s) {
            let c = J(t, e),
                $ = e.toLowerCase();
            if (e === "class") {
                let i = t.classList,
                    r = G(n),
                    a = G(s);
                i.remove(...r.filter(f => f && !a.includes(f))), i.add(...a.filter(f => f && !r.includes(f)))
            } else if (e === "style") {
                for (let i in n)(!s || s[i] == null) && (i.includes("-") ? t.style.removeProperty(i) : t.style[i] = "");
                for (let i in s)(!n || s[i] !== n[i]) && (i.includes("-") ? t.style.setProperty(i, s[i]) : t.style[i] = s[i])
            } else if (e === "ref") s && s(t);
            else if (!c && e[0] === "o" && e[1] === "n") e[2] === "-" ? e = e.slice(3) : J(T, $) ? e = $.slice(2) : e = $[2] + e.slice(3), n && d.rel(t, e, n, !1), s && d.ael(t, e, s, !1);
            else {
                let i = _(s);
                if ((c || i && s !== null) && !l) try {
                    if (t.tagName.includes("-")) t[e] = s;
                    else {
                        let r = s ? ? "";
                        e === "list" ? c = !1 : (n == null || t[e] != r) && (t[e] = r)
                    }
                } catch (r) {}
                s == null || s === !1 ? (s !== !1 || t.getAttribute(e) === "") && t.removeAttribute(e) : (!c || o & 4 || l) && !i && (s = s === !0 ? "" : s, t.setAttribute(e, s))
            }
        }
    },
    xt = /\s/,
    G = t => t ? t.split(xt) : [],
    N = (t, e, n, s) => {
        let l = e.$elm$.nodeType === 11 && e.$elm$.host ? e.$elm$.host : e.$elm$,
            o = t && t.$attrs$ || W,
            c = e.$attrs$ || W;
        for (s in o) s in c || Y(l, s, o[s], void 0, n, e.$flags$);
        for (s in c) Y(l, s, o[s], c[s], n, e.$flags$)
    },
    B = (t, e, n, s) => {
        let l = e.$children$[n],
            o = 0,
            c, $;
        if (l.$text$ !== null) c = l.$elm$ = g.createTextNode(l.$text$);
        else {
            if (u || (u = l.$tag$ === "svg"), c = l.$elm$ = g.createElementNS(u ? ut : pt, l.$tag$), u && l.$tag$ === "foreignObject" && (u = !1), N(null, l, u), gt(I) && c["s-si"] !== I && c.classList.add(c["s-si"] = I), l.$children$)
                for (o = 0; o < l.$children$.length; ++o) $ = B(t, l, o), $ && c.appendChild($);
            l.$tag$ === "svg" ? u = !1 : c.tagName === "foreignObject" && (u = !0)
        }
        return c
    },
    V = (t, e, n, s, l, o) => {
        let c = t,
            $;
        for (c.shadowRoot && c.tagName === Q && (c = c.shadowRoot); l <= o; ++l) s[l] && ($ = B(null, n, l), $ && (s[l].$elm$ = $, c.insertBefore($, e)))
    },
    tt = (t, e, n) => {
        for (let s = e; s <= n; ++s) {
            let l = t[s];
            if (l) {
                let o = l.$elm$;
                et(l), o && o.remove()
            }
        }
    },
    bt = (t, e, n, s) => {
        let l = 0,
            o = 0,
            c = e.length - 1,
            $ = e[0],
            i = e[c],
            r = s.length - 1,
            a = s[0],
            f = s[r],
            v;
        for (; l <= c && o <= r;) $ == null ? $ = e[++l] : i == null ? i = e[--c] : a == null ? a = s[++o] : f == null ? f = s[--r] : b($, a) ? (L($, a), $ = e[++l], a = s[++o]) : b(i, f) ? (L(i, f), i = e[--c], f = s[--r]) : b($, f) ? (L($, f), t.insertBefore($.$elm$, i.$elm$.nextSibling), $ = e[++l], f = s[--r]) : b(i, a) ? (L(i, a), t.insertBefore(i.$elm$, $.$elm$), i = e[--c], a = s[++o]) : (v = B(e && e[o], n, o), a = s[++o], v && $.$elm$.parentNode.insertBefore(v, $.$elm$));
        l > c ? V(t, s[r + 1] == null ? null : s[r + 1].$elm$, n, s, o, r) : o > r && tt(e, l, c)
    },
    b = (t, e) => t.$tag$ === e.$tag$,
    L = (t, e) => {
        let n = e.$elm$ = t.$elm$,
            s = t.$children$,
            l = e.$children$,
            o = e.$tag$,
            c = e.$text$;
        c === null ? (u = o === "svg" ? !0 : o === "foreignObject" ? !1 : u, N(t, e, u), s !== null && l !== null ? bt(n, s, e, l) : l !== null ? (t.$text$ !== null && (n.textContent = ""), V(n, null, e, l, 0, l.length - 1)) : s !== null && tt(s, 0, s.length - 1), u && o === "svg" && (u = !1)) : t.$text$ !== c && (n.data = c)
    },
    et = t => {
        t.$attrs$ && t.$attrs$.ref && t.$attrs$.ref(null), t.$children$ && t.$children$.map(et)
    },
    It = (t, e) => {
        let n = t.$hostElement$,
            s = t.$vnode$ || q(null, null),
            l = St(e) ? e : ht(null, null, e);
        Q = n.tagName, l.$tag$ = null, l.$flags$ |= 4, t.$vnode$ = l, l.$elm$ = s.$elm$ = n.shadowRoot || n, I = n["s-sc"], L(s, l)
    },
    st = (t, e) => {
        e && !t.$onRenderResolve$ && e["s-p"] && e["s-p"].push(new Promise(n => t.$onRenderResolve$ = n))
    },
    A = (t, e) => {
        if (t.$flags$ |= 16, t.$flags$ & 4) {
            t.$flags$ |= 512;
            return
        }
        return st(t, t.$ancestorComponent$), Ft(() => kt(t, e))
    },
    kt = (t, e) => {
        let n = h("scheduleUpdate", t.$cmpMeta$.$tagName$),
            s = t.$lazyInstance$,
            l;
        return e && (t.$flags$ |= 256, t.$queuedListeners$ && (t.$queuedListeners$.map(([o, c]) => M(s, o, c)), t.$queuedListeners$ = void 0)), n(), At(l, () => jt(t, s, e))
    },
    At = (t, e) => Tt(t) ? t.then(e) : e(),
    Tt = t => t instanceof Promise || t && t.then && typeof t.then == "function",
    jt = (t, e, n) => j(null, null, function*() {
        var s;
        let l = t.$hostElement$,
            o = h("update", t.$cmpMeta$.$tagName$),
            c = l["s-rc"];
        n && Pt(t);
        let $ = h("render", t.$cmpMeta$.$tagName$);
        Ht(t, e), c && (c.map(i => i()), l["s-rc"] = void 0), $(), o(); {
            let i = (s = l["s-p"]) !== null && s !== void 0 ? s : [],
                r = () => Ot(t);
            i.length === 0 ? r() : (Promise.all(i).then(r), t.$flags$ |= 4, i.length = 0)
        }
    }),
    Ht = (t, e, n) => {
        try {
            e = e.render(), t.$flags$ &= -17, t.$flags$ |= 2, It(t, e)
        } catch (s) {
            p(s, t.$hostElement$)
        }
        return null
    },
    Ot = t => {
        let e = t.$cmpMeta$.$tagName$,
            n = t.$hostElement$,
            s = h("postUpdate", e),
            l = t.$lazyInstance$,
            o = t.$ancestorComponent$;
        t.$flags$ & 64 ? s() : (t.$flags$ |= 64, lt(n), M(l, "componentDidLoad"), s(), t.$onReadyResolve$(n), o || nt()), t.$onInstanceResolve$(n), t.$onRenderResolve$ && (t.$onRenderResolve$(), t.$onRenderResolve$ = void 0), t.$flags$ & 512 && w(() => A(t, !1)), t.$flags$ &= -517
    },
    Zt = t => {
        {
            let e = y(t),
                n = e.$hostElement$.isConnected;
            return n && (e.$flags$ & 18) === 2 && A(e, !1), n
        }
    },
    nt = t => {
        lt(g.documentElement), w(() => Z(T, "appload", {
            detail: {
                namespace: at
            }
        }))
    },
    M = (t, e, n) => {
        if (t && t[e]) try {
            return t[e](n)
        } catch (s) {
            p(s)
        }
    },
    lt = t => t.classList.add("hydrated"),
    qt = (t, e) => y(t).$instanceValues$.get(e),
    Ut = (t, e, n, s) => {
        let l = y(t),
            o = l.$instanceValues$.get(e),
            c = l.$flags$,
            $ = l.$lazyInstance$;
        n = mt(n, s.$members$[e][0]);
        let i = Number.isNaN(o) && Number.isNaN(n),
            r = n !== o && !i;
        (!(c & 8) || o === void 0) && r && (l.$instanceValues$.set(e, n), $ && (c & 18) === 2 && A(l, !1))
    },
    ct = (t, e, n) => {
        if (e.$members$) {
            let s = Object.entries(e.$members$),
                l = t.prototype;
            if (s.map(([o, [c]]) => {
                    c & 31 || n & 2 && c & 32 ? Object.defineProperty(l, o, {
                        get() {
                            return qt(this, o)
                        },
                        set($) {
                            Ut(this, o, $, e)
                        },
                        configurable: !0,
                        enumerable: !0
                    }) : n & 1 && c & 64 && Object.defineProperty(l, o, {
                        value(...$) {
                            let i = y(this);
                            return i.$onInstancePromise$.then(() => i.$lazyInstance$[o](...$))
                        }
                    })
                }), n & 1) {
                let o = new Map;
                l.attributeChangedCallback = function(c, $, i) {
                    d.jmp(() => {
                        let r = o.get(c);
                        if (this.hasOwnProperty(r)) i = this[r], delete this[r];
                        else if (l.hasOwnProperty(r) && typeof this[r] == "number" && this[r] == i) return;
                        this[r] = i === null && typeof this[r] == "boolean" ? !1 : i
                    })
                }, t.observedAttributes = s.filter(([c, $]) => $[0] & 15).map(([c, $]) => {
                    let i = $[1] || c;
                    return o.set(i, c), i
                })
            }
        }
        return t
    },
    _t = (t, e, n, s, l) => j(null, null, function*() {
        if ((e.$flags$ & 32) === 0) {
            e.$flags$ |= 32; {
                if (l = Ct(n), l.then) {
                    let i = ft();
                    l = yield l, i()
                }
                l.isProxied || (ct(l, n, 2), l.isProxied = !0);
                let $ = h("createInstance", n.$tagName$);
                e.$flags$ |= 8;
                try {
                    new l(e)
                } catch (i) {
                    p(i)
                }
                e.$flags$ &= -9, $()
            }
            if (l.style) {
                let $ = l.style,
                    i = R(n);
                if (!k.has(i)) {
                    let r = h("registerStyles", n.$tagName$);
                    Et(i, $, !!(n.$flags$ & 1)), r()
                }
            }
        }
        let o = e.$ancestorComponent$,
            c = () => A(e, !0);
        o && o["s-rc"] ? o["s-rc"].push(c) : c()
    }),
    Bt = t => {
        if ((d.$flags$ & 1) === 0) {
            let e = y(t),
                n = e.$cmpMeta$,
                s = h("connectedCallback", n.$tagName$);
            if (e.$flags$ & 1) ot(t, e, n.$listeners$);
            else {
                e.$flags$ |= 1; {
                    let l = t;
                    for (; l = l.parentNode || l.host;)
                        if (l["s-p"]) {
                            st(e, e.$ancestorComponent$ = l);
                            break
                        }
                }
                n.$members$ && Object.entries(n.$members$).map(([l, [o]]) => {
                    if (o & 31 && t.hasOwnProperty(l)) {
                        let c = t[l];
                        delete t[l], t[l] = c
                    }
                }), _t(t, e, n)
            }
            s()
        }
    },
    Mt = t => {
        if ((d.$flags$ & 1) === 0) {
            let e = y(t),
                n = e.$lazyInstance$;
            e.$rmListeners$ && (e.$rmListeners$.map(s => s()), e.$rmListeners$ = void 0), M(n, "disconnectedCallback")
        }
    },
    Rt = (t, e = {}) => {
        var n;
        let s = h(),
            l = [],
            o = e.exclude || [],
            c = T.customElements,
            $ = g.head,
            i = $.querySelector("meta[charset]"),
            r = g.createElement("style"),
            a = [],
            f, v = !0;
        Object.assign(d, e), d.$resourcesUrl$ = new URL(e.resourcesUrl || "./", g.baseURI).href, t.map(S => {
            S[1].map(E => {
                let m = {
                    $flags$: E[0],
                    $tagName$: E[1],
                    $members$: E[2],
                    $listeners$: E[3]
                };
                m.$members$ = E[2], m.$listeners$ = E[3];
                let P = m.$tagName$,
                    $t = class extends HTMLElement {
                        constructor(x) {
                            super(x), x = this, Wt(x, m), m.$flags$ & 1 && x.attachShadow({
                                mode: "open"
                            })
                        }
                        connectedCallback() {
                            f && (clearTimeout(f), f = null), v ? a.push(this) : d.jmp(() => Bt(this))
                        }
                        disconnectedCallback() {
                            d.jmp(() => Mt(this))
                        }
                        componentOnReady() {
                            return y(this).$onReadyPromise$
                        }
                    };
                m.$lazyBundleId$ = S[0], !o.includes(P) && !c.get(P) && (l.push(P), c.define(P, ct($t, m, 1)))
            })
        }); {
            r.innerHTML = l + dt, r.setAttribute("data-styles", "");
            let S = (n = d.$nonce$) !== null && n !== void 0 ? n : X(g);
            S != null && r.setAttribute("nonce", S), $.insertBefore(r, i ? i.nextSibling : $.firstChild)
        }
        v = !1, a.length ? a.map(S => S.connectedCallback()) : d.jmp(() => f = setTimeout(nt, 30)), s()
    },
    ot = (t, e, n, s) => {
        n && n.map(([l, o, c]) => {
            let $ = wt(t, l),
                i = zt(e, c),
                r = Dt(l);
            d.ael($, o, i, r), (e.$rmListeners$ = e.$rmListeners$ || []).push(() => d.rel($, o, i, r))
        })
    },
    zt = (t, e) => n => {
        try {
            t.$flags$ & 256 ? t.$lazyInstance$[e](n) : (t.$queuedListeners$ = t.$queuedListeners$ || []).push([e, n])
        } catch (s) {
            p(s)
        }
    },
    wt = (t, e) => e & 16 ? g.body : t,
    Dt = t => (t & 2) !== 0;
var z = new WeakMap,
    y = t => z.get(t),
    Nt = (t, e) => z.set(e.$lazyInstance$ = t, e),
    Wt = (t, e) => {
        let n = {
            $flags$: 0,
            $hostElement$: t,
            $cmpMeta$: e,
            $instanceValues$: new Map
        };
        return n.$onInstancePromise$ = new Promise(s => n.$onInstanceResolve$ = s), n.$onReadyPromise$ = new Promise(s => n.$onReadyResolve$ = s), t["s-p"] = [], t["s-rc"] = [], ot(t, n, e.$listeners$), z.set(t, n)
    },
    J = (t, e) => e in t,
    p = (t, e) => (0, console.error)(t, e),
    H = new Map,
    Ct = (t, e, n) => {
        let s = t.$tagName$.replace(/-/g, "_"),
            l = t.$lazyBundleId$,
            o = H.get(l);
        if (o) return o[s];
        if (!n || !BUILD.hotModuleReplacement) {
            let c = $ => (H.set(l, $), $[s]);
            switch (l) {
                case "pwa-action-sheet":
                    return import ("./chunk-3HLUS2E5.js").then(c, p);
                case "pwa-camera-modal":
                    return import ("./chunk-KIOHJHSO.js").then(c, p);
                case "pwa-toast":
                    return import ("./chunk-5VOGFD3M.js").then(c, p);
                case "pwa-camera-modal-instance":
                    return import ("./chunk-DQNGODFY.js").then(c, p);
                case "pwa-camera":
                    return import ("./chunk-GPTKZ5OH.js").then(c, p)
            }
        }
        return rt(`./${l}.entry.js`).then(c => (H.set(l, c), c[s]), p)
    },
    k = new Map,
    T = typeof window < "u" ? window : {},
    g = T.document || {
        head: {}
    },
    d = {
        $flags$: 0,
        $resourcesUrl$: "",
        jmp: t => t(),
        raf: t => requestAnimationFrame(t),
        ael: (t, e, n, s) => t.addEventListener(e, n, s),
        rel: (t, e, n, s) => t.removeEventListener(e, n, s),
        ce: (t, e) => new CustomEvent(t, e)
    },
    Yt = t => Promise.resolve(t),
    Gt = (() => {
        try {
            return new CSSStyleSheet, typeof new CSSStyleSheet().replaceSync == "function"
        } catch (t) {}
        return !1
    })(),
    F = [],
    it = [],
    Jt = (t, e) => n => {
        t.push(n), O || (O = !0, e && d.$flags$ & 4 ? w(U) : d.raf(U))
    },
    K = t => {
        for (let e = 0; e < t.length; e++) try {
            t[e](performance.now())
        } catch (n) {
            p(n)
        }
        t.length = 0
    },
    U = () => {
        K(F), K(it), (O = F.length > 0) && d.raf(U)
    },
    w = t => Yt().then(t),
    Ft = Jt(it, !0);
export {
    ht as a, yt as b, vt as c, Xt as d, Zt as e, Rt as f, Nt as g, Yt as h
};