import {
    a as ze,
    b as G
} from "./chunk-2E5FSGQH.js";
import {
    a as Qe
} from "./chunk-2KS5UOZO.js";
import {
    a as fe
} from "./chunk-KJCCJCIN.js";
import {
    L as de,
    M as E,
    T as ce,
    Ta as Ce,
    Ud as Ne,
    Va as ge,
    W as ue,
    Zd as Be,
    _b as Ee,
    _d as N,
    ba as F,
    ca as ve,
    cb as be,
    cd as Le,
    e as w,
    fd as we,
    g as ie,
    gd as De,
    h as te,
    id as Pe,
    je as Ue,
    ka as he,
    ld as Ve,
    lf as Ye,
    mf as Ze,
    n as oe,
    ne as ke,
    ob as ye,
    pb as Me,
    ph as Je,
    q as ne,
    qb as xe,
    rd as Ae,
    re as q,
    rg as He,
    sb as Se,
    sd as Fe,
    t as ae,
    tb as O,
    td as Re,
    te as qe,
    u as re,
    ub as Te,
    ue as Ge,
    vd as Oe,
    we as je,
    y as le,
    yc as Ie,
    ze as We
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    $b as z,
    Ab as J,
    Ak as R,
    Db as U,
    Fa as a,
    Fh as b,
    Ka as S,
    Lc as K,
    Na as M,
    Oa as V,
    Rd as me,
    Sa as x,
    Sd as pe,
    Tc as X,
    Yb as Q,
    _a as p,
    ba as P,
    ch as _e,
    ea as m,
    eb as o,
    fb as l,
    fd as ee,
    gb as s,
    ha as u,
    hb as c,
    hi as I,
    ia as f,
    kc as $,
    n as W,
    nb as B,
    pd as T,
    qb as g,
    qd as se,
    sb as C,
    sd as A,
    ub as d,
    vd as k,
    xi as L,
    xk as v,
    yb as Z,
    z as Y,
    zb as H
} from "./chunk-GOPIAW4V.js";
var ti = t => ({
    lead_id: t
});

function oi(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-follow-up-popup", 2), C("followUpCancelClick", function() {
            u(i);
            let n = d();
            return f(n.isVisibleFollowUpPopup = !1)
        })("followUpSaveClick", function() {
            u(i);
            let n = d();
            return f(n.onSaveFollowUp())
        }), s()
    }
    if (t & 2) {
        let i = d();
        o("followUp", i.followUp)("isCreate", i.isCreate)("isVisiblePopup", i.isVisibleFollowUpPopup)("leadId", i.leadId)
    }
}
var $e = (() => {
    class t {
        constructor(i) {
            this.service = i, this.formatMessage = v, this.activatedRouter = m(T), this.isVisibleFollowUpPopup = !1, this.isCreate = !1, this.entity = I.FOLLOW_UP, this.leadId = null, this.columns = [{
                dataField: "follow_up_channel.name",
                caption: v("follow_up_method"),
                width: 120,
                allowSorting: !1
            }, {
                dataField: "next_follow_up",
                caption: v("lead_next_follow_up"),
                width: 140,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !1
            }, {
                dataField: "follow_up_by_user",
                caption: v("follow_up_by"),
                hidingPriority: 3,
                cellTemplate: "employeeTemplate",
                allowSorting: !1
            }, {
                dataField: "comment",
                caption: v("common_comment"),
                hidingPriority: 2,
                cellTemplate: "commentTemplate",
                allowSorting: !1
            }, {
                dataField: "created_at",
                caption: v("common_created_on"),
                hidingPriority: 1,
                cellTemplate: "dateTimeTemplate",
                allowSorting: !1
            }, {
                dataField: "",
                caption: "",
                width: 20,
                hidingPriority: 0,
                cellTemplate: "actionTemplate",
                allowSorting: !1
            }], this.leadId = +this.activatedRouter.parent.snapshot.paramMap.get("lead_id")
        }
        create() {
            this.isVisibleFollowUpPopup = !0, this.isCreate = !0
        }
        edit(i) {
            this.isCreate = !1, this.followUp = i, this.isVisibleFollowUpPopup = !0
        }
        onSaveFollowUp() {
            this.isCreate = !1, this.dataGrid.getData(), this.followUp = null, this.isVisibleFollowUpPopup = !1
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || t)(S(Ue))
            }
        }
        static {
            this.\u0275cmp = M({
                type: t,
                selectors: [
                    ["app-follow-up-list"]
                ],
                viewQuery: function(e, n) {
                    if (e & 1 && Z(N, 5), e & 2) {
                        let h;
                        H(h = J()) && (n.dataGrid = h.first)
                    }
                },
                standalone: !1,
                decls: 2,
                vars: 10,
                consts: [
                    [3, "dataGridAddNewClick", "dataGridEditClick", "additionalParams", "columns", "entity", "isVisibleAddAction", "isVisibleDeleteAction", "isVisibleEditAction", "service"],
                    [3, "followUp", "isCreate", "isVisiblePopup", "leadId"],
                    [3, "followUpCancelClick", "followUpSaveClick", "followUp", "isCreate", "isVisiblePopup", "leadId"]
                ],
                template: function(e, n) {
                    e & 1 && (l(0, "app-data-grid", 0), C("dataGridAddNewClick", function() {
                        return n.create()
                    })("dataGridEditClick", function(ii) {
                        return n.edit(ii)
                    }), s(), p(1, oi, 1, 4, "app-follow-up-popup", 1)), e & 2 && (o("additionalParams", z(8, ti, n.leadId))("columns", n.columns)("entity", n.entity)("isVisibleAddAction", !0)("isVisibleDeleteAction", !0)("isVisibleEditAction", !0)("service", n.service), a(), _(n.isVisibleFollowUpPopup ? 1 : -1))
                },
                dependencies: [N, ke],
                encapsulation: 2
            })
        }
    }
    return t
})();
var y = class {
    constructor(r) {
        return Object.assign(this, r)
    }
    static getForm(r) {
        return new le().group({
            id: [r.id || null],
            name: [r.name || null, [w.required]],
            contact_person_name: [r.contact_person_name || null],
            email: [r.email || null, w.email],
            address: q.getForm(new q(r.address)),
            mobile_number: [r.mobile_number || null, [O.phoneNumberValidator]],
            phone_number: [r.phone_number || null, [O.phoneNumberValidator]],
            lead_source_id: [r.lead_source_id || null],
            referred_by_user_id: [r.referred_by_user_id || null],
            next_follow_up: [r.next_follow_up || null],
            comment: [r.comment || null],
            status_id: [r.status_id || null],
            custom_fields: Te.getFormArray(r.custom_fields),
            role_id: [r.role_id || null],
            assigned_user_id: [r.assigned_user_id || null, w.required],
            assigned_user: [r.assigned_user || null],
            google_recaptcha: [""],
            device_type_id: [r.device_type_id || null],
            device_brand_id: [r.device_brand_id || null],
            device_model_id: [r.device_model_id || null],
            mobile_country_code: [r.mobile_country_code || null]
        }, {
            validator: O.atLeastOne(w.required, ["email", "mobile_number"])
        })
    }
};

function ni(t, r) {
    t & 1 && B(0)
}

function ai(t, r) {
    if (t & 1 && x(0, ni, 1, 0, "ng-container", 3), t & 2) {
        d();
        let i = U(3);
        o("ngTemplateOutlet", i)
    }
}

function ri(t, r) {
    t & 1 && B(0)
}

function li(t, r) {
    if (t & 1 && x(0, ri, 1, 0, "ng-container", 3), t & 2) {
        d();
        let i = U(3);
        o("ngTemplateOutlet", i)
    }
}

function si(t, r) {
    t & 1 && c(0, "app-skeleton-loader", 4), t & 2 && o("rows", 8)("columns", 3)
}

function di(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-save-cancel-footer", 46), C("cancelClick", function() {
            u(i);
            let n = d(4);
            return f(n.cancel())
        }), s()
    }
    if (t & 2) {
        let i = d(4);
        o("gaEvent", "create_save_lead_event")("isOnPopup", !1)("isSaving", i.isSaving)("isVisibleHr", !1)("saveText", i.leadId ? "common_save" : "common_create")("savingText", i.leadId ? "saving" : "common_creating")
    }
}

function ci(t, r) {
    if (t & 1 && x(0, di, 1, 6, "app-save-cancel-footer", 45), t & 2) {
        let i = d(3);
        o("ngxPermissionsOnly", i.PERMISSION_LIST.LEAD_WRITE)
    }
}

function mi(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-dx-outline-button", 49), C("onClickEvent", function() {
            u(i);
            let n = d(5);
            return f(n.setEditMode())
        }), s()
    }
}

function pi(t, r) {
    if (t & 1 && x(0, mi, 1, 0, "app-dx-outline-button", 48), t & 2) {
        let i = d(4);
        o("ngxPermissionsOnly", i.PERMISSION_LIST.LEAD_WRITE)
    }
}

function _i(t, r) {
    if (t & 1 && p(0, pi, 1, 1, "app-dx-outline-button", 47), t & 2) {
        let i = d(3);
        _(i.userPermissionList.includes(i.PERMISSION_LIST.LEAD_WRITE) ? 0 : -1)
    }
}

function ui(t, r) {
    if (t & 1 && c(0, "app-server-error", 10), t & 2) {
        let i = d(3);
        o("errorResponse", i.errorResponse)
    }
}

function fi(t, r) {
    if (t & 1 && (l(0, "app-control-container", 24), c(1, "app-email", 50), s()), t & 2) {
        let i = d(3);
        o("errorMsg", i.formatMessage("common_email_required"))("label", i.formatMessage("common_email_id")), a(), o("entityId", i.form.getRawValue().id)("entity", i.ENTITIES.LEAD)("formControl", i.form.controls.email)("isEditMode", i.isEditMode)("isUniqueValidation", !0)
    }
}

function vi(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-save-cancel-footer", 46), C("cancelClick", function() {
            u(i);
            let n = d(4);
            return f(n.cancel())
        }), s()
    }
    if (t & 2) {
        let i = d(4);
        o("gaEvent", "create_save_lead_event")("isOnPopup", !0)("isSaving", i.isSaving)("isVisibleHr", !1)("saveText", i.leadId ? "common_save" : "common_create")("savingText", i.leadId ? "saving" : "common_creating")
    }
}

function hi(t, r) {
    if (t & 1 && (l(0, "div", 44), x(1, vi, 1, 6, "app-save-cancel-footer", 45), s()), t & 2) {
        let i = d(3);
        a(), o("ngxPermissionsOnly", i.PERMISSION_LIST.LEAD_WRITE)
    }
}

function Ci(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "form", 6), C("ngSubmit", function() {
            u(i);
            let n = d(2);
            return f(n.save())
        }), l(1, "div", 7)(2, "div", 8), p(3, ci, 1, 1, "app-save-cancel-footer", 9), p(4, _i, 1, 1), s()(), p(5, ui, 1, 1, "app-server-error", 10), c(6, "app-section-title", 11), l(7, "div", 12)(8, "app-control-container", 13), c(9, "dx-select-box", 14), s(), l(10, "app-control-container", 15), c(11, "dx-text-box", 16), s(), l(12, "app-control-container", 17), c(13, "dx-select-box", 18), s(), l(14, "app-control-container", 19), c(15, "app-customer-dropdown", 20), s(), l(16, "app-control-container", 21), c(17, "app-mobile-number", 22)(18, "app-error", 23)(19, "app-error", 23), s(), p(20, fi, 2, 7, "app-control-container", 24), l(21, "app-control-container", 25), c(22, "app-phone-number", 26)(23, "app-error", 23), s(), l(24, "app-control-container", 27), c(25, "dx-text-box", 28), s(), l(26, "app-control-container", 29), c(27, "dx-date-box", 30), s(), l(28, "app-control-container", 31), c(29, "app-employee-dropdown", 32), s(), c(30, "app-section-title", 33), l(31, "div", 12)(32, "app-control-container", 34), c(33, "app-select-box-with-images", 35), s(), l(34, "app-control-container", 36), c(35, "app-select-box-with-images", 37), s(), l(36, "app-control-container", 38), c(37, "app-select-box-with-images", 39), s()(), c(38, "app-show-custom-fields", 40), l(39, "app-control-container", 41), c(40, "app-textarea", 26), s(), l(41, "div", 42), c(42, "app-address", 43), s(), p(43, hi, 2, 1, "div", 44), s()()
    }
    if (t & 2) {
        let i, e = d(2);
        o("formGroup", e.form), a(3), _(!e.isMobileDevice && e.isEditMode ? 3 : -1), a(), _(e.isEditMode ? -1 : 4), a(), _(e.errorResponse ? 5 : -1), a(), o("title", "lead_information"), a(2), o("errorMsg", e.formatMessage("lead_type_required"))("label", e.formatMessage("lead_type")), a(), o("items", e.leadTypes)("placeholder", e.formatMessage("select_lead_type"))("searchEnabled", !0), a(), o("errorMsg", e.formatMessage("lead_name_required"))("label", e.formatMessage("lead_name")), a(), o("placeholder", e.formatMessage("employee_name_placeholder")), a(), o("errorMsg", e.formatMessage("lead_source_required"))("label", e.formatMessage("lead_source")), a(), o("items", e.leadSources)("placeholder", e.formatMessage("select_lead_source_type"))("searchEnabled", !0), a(), o("errorMsg", e.formatMessage("lead_referred_required"))("label", e.formatMessage("lead_referred_by_customer")), a(), o("customerId", e.form.getRawValue().id ? (i = e.form.getRawValue()) == null ? null : i.referred_by_user_id : null)("formControl", e.form.controls.referred_by_user_id)("isEditMode", e.isEditMode)("isVisibleAddAction", !1), a(), o("errorMsg", e.formatMessage("common_mobile_required"))("label", e.formatMessage("common_mobile_number")), a(), o("entity", e.ENTITIES.LEAD)("entityId", e.leadId)("formControl", e.form.controls.mobile_number)("isEditMode", e.isEditMode)("form", e.form)("isUniqueValidation", !0), a(), o("displayError", e.form.get("mobile_number").invalid && e.form.get("mobile_number").touched && e.form.get("mobile_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile")), a(), o("displayError", e.form.touched && e.form.get("mobile_number").touched && e.form.errors && e.form.errors.atLeastOne)("errorMsg", e.formatMessage("common_mobile_or_email_required")), a(), _(e.form.getRawValue().id ? -1 : 20), a(), o("label", e.formatMessage("common_phone_number")), a(), o("formControl", e.form.controls.phone_number)("isEditMode", e.isEditMode), a(), o("displayError", e.form.get("phone_number").invalid && e.form.get("phone_number").touched && e.form.get("phone_number").errors.invalidPhoneNumber)("errorMsg", e.formatMessage("common_invalid_mobile")), a(), o("errorMsg", e.formatMessage("lead_contact_person_required"))("label", e.formatMessage("lead_contact_person")), a(), o("placeholder", e.formatMessage("lead_contact_person_placeholder")), a(), o("errorMsg", e.formatMessage("lead_next_follow_up_required"))("label", e.formatMessage("lead_next_follow_up")), a(), o("dateSerializationFormat", e.DATETIME_SERIALIZATION_FORMAT)("displayFormat", e.DISPLAY_DATETIME_SERIALIZATION_FORMAT)("min", e.today)("pickerType", e.isMobileDevice ? "rollers" : "calendar")("placeholder", e.formatMessage("lead_select_next_follow_up")), a(), o("errorMsg", e.formatMessage("common_assignee_required"))("label", e.formatMessage("common_assignee")), a(), o("entity", e.ENTITIES.LEAD)("isActiveOnly", !e.leadId)("isEditMode", e.isEditMode), a(), o("title", "lead_device_info"), a(2), o("errorMsg", e.formatMessage("device_type_required_warning"))("label", e.formatMessage("device_type_name")), a(), o("dataSource", e.allDeviceTypeList)("placeholder", "select_device_type"), a(), o("errorMsg", e.formatMessage("device_brand_required_warning"))("label", e.formatMessage("device_brand_name")), a(), o("dataSource", e.deviceBrandList)("isDxiButtonActive", e.isEditMode)("hasUserPermissions", e.PERMISSION_LIST.DEVICE_BRAND_LIST)("buttonOptions", e.addDeviceBrandOption)("buttonId", "job-basic-info-device-brand")("buttonName", "deviceBrand")("isReadOnly", !e.form.getRawValue().device_type_id)("placeholder", "device_brand_placeholder"), a(), o("errorMsg", e.formatMessage("device_model_required_error"))("label", e.formatMessage("device_model_name")), a(), o("dataSource", e.deviceModelList)("isDxiButtonActive", e.isEditMode)("hasUserPermissions", e.PERMISSION_LIST.DEVICE_MODEL_WRITE)("buttonOptions", e.addDeviceModelOption)("buttonId", "job-basic-info-model-btn")("buttonName", "deviceModel")("isReadOnly", !e.form.getRawValue().device_brand_id)("placeholder", "device_model_placeholder"), a(), o("formType", e.FORM_TYPE_LIST.LEAD)("form", e.form)("hasColumn", 4), a(), o("errorMsg", e.formatMessage("lead_comment_required"))("label", e.formatMessage("common_comment")), a(), o("formControl", e.form.controls.comment)("isEditMode", e.isEditMode), a(2), o("parentForm", e.form), a(), _(e.isMobileDevice && e.isEditMode ? 43 : -1)
    }
}

function gi(t, r) {
    if (t & 1 && (p(0, si, 1, 2, "app-skeleton-loader", 4), p(1, Ci, 44, 91, "form", 5)), t & 2) {
        let i = d();
        _(!i.form && i.leadId ? 0 : -1), a(), _(i.form ? 1 : -1)
    }
}

function bi(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-device-brand", 51), C("deviceBrandCancelClick", function() {
            u(i);
            let n = d();
            return f(n.isVisibleDeviceBrandPopup = !1)
        })("deviceBrandSaveClick", function(n) {
            u(i);
            let h = d();
            return f(h.onAddDeviceBrand(n))
        }), s()
    }
    if (t & 2) {
        let i = d();
        o("deviceBrand", i.deviceBrand)("isCreate", !0)("isVisiblePopup", i.isVisibleDeviceBrandPopup)
    }
}

function yi(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-device-model-popup", 52), C("deviceModelCancelClick", function() {
            u(i);
            let n = d();
            return f(n.isVisibleDeviceModelPopup = !1)
        })("deviceModelSaveClick", function(n) {
            u(i);
            let h = d();
            return f(h.onAddDeviceModel(n))
        }), s()
    }
    if (t & 2) {
        let i = d();
        o("deviceModel", i.deviceModel)("isAddingFromJob", !0)("isCreate", !0)("isVisiblePopup", i.isVisibleDeviceModelPopup)
    }
}
var j = (() => {
    class t {
        constructor() {
            this.formatMessage = v, this.formService = m(Me), this.userSessionService = m(F), this.userPermissionList = this.userSessionService.userPermissionList(), this.router = m(A), this.dataService = m(Pe), this.service = m(L), this.leadSourceService = m(ze), this.loaderService = m(R), this.roleService = m(ue), this.activatedRouter = m(T), this.isMobileDevice = m(ce).isMobileDevice(), this.toastNotificationService = m(ve), this.today = new Date, this.DATETIME_SERIALIZATION_FORMAT = me, this.DISPLAY_DATETIME_SERIALIZATION_FORMAT = pe, this.ENTITIES = I, this.lead = null, this.isEditMode = !1, this.errorResponse = null, this.leadTypes = [], this.leadSources = [], this.isSaving = !1, this.deviceBrandList = [], this.deviceModelList = [], this.allDeviceTypeList = [], this.allDeviceModelList = [], this.allDeviceBrandList = [], this.isVisibleDeviceBrandPopup = !1, this.isVisibleDeviceModelPopup = !1, this.PERMISSION_LIST = b, this.FORM_TYPE_LIST = _e, this.addDeviceBrandOption = {
                icon: "add",
                type: "default",
                hint: "Add New Device Brand",
                onClick: () => {
                    this.deviceBrand = new we({
                        device_type_id: this.form.getRawValue().device_type_id
                    }), this.isVisibleDeviceBrandPopup = !0
                }
            }, this.addDeviceModelOption = {
                icon: "add",
                type: "default",
                hint: "Add New Device Model",
                onClick: () => {
                    this.deviceModel = new De({
                        device_brand_id: this.form.getRawValue().device_brand_id,
                        device_type_id: this.form.getRawValue().device_type_id
                    }), this.isVisibleDeviceModelPopup = !0
                }
            }
        }
        ngOnInit() {
            this.leadId = +this.activatedRouter.parent.snapshot.paramMap.get("lead_id");
            let i = [this.roleService.getCustomerRoles(), this.leadSourceService.getListByQuery()];
            i.push(this.leadId ? this.service.getById(this.leadId) : W(new y({}))), this.loaderService.show(), Y(i).subscribe({
                next: ([e, n, h]) => {
                    this.leadTypes = e, this.leadSources = n, this.lead = new y(h), this.form = y.getForm(this.lead), this.leadId ? this.setFormReadOnly() : this.isEditMode = !0, this.initialize()
                },
                error: e => {
                    console.error(e)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        subscribeToValueChangesOnDeviceId() {
            this.form.controls.device_type_id.valueChanges.subscribe(i => {
                this.onChangeDeviceType(i)
            })
        }
        setFormReadOnly() {
            this.isEditMode = !1, this.form.disable({
                emitEvent: !1
            })
        }
        save() {
            if (this.errorResponse = null, this.form.valid) {
                this.isSaving = !0, this.loaderService.show();
                let i = this.form.value;
                this.leadId && (i.id = this.leadId), (this.leadId ? this.service.update(i) : this.service.create(i)).subscribe({
                    next: n => {
                        this.leadId ? (this.toastNotificationService.success("notification_lead_update_success"), this.lead = n, this.isEditMode = !1, this.form.disable({
                            emitEvent: !1
                        })) : (this.toastNotificationService.success("notification_lead_add_success"), this.router.navigateByUrl(`/leads/${n.id}/profiles`))
                    },
                    error: n => {
                        this.errorResponse = n
                    }
                }).add(() => {
                    this.isSaving = !1, this.loaderService.hide()
                })
            } else this.formService.validateFormFields(this.form)
        }
        cancel() {
            this.leadId ? (this.form = y.getForm(this.lead), this.isEditMode = !1, this.form.disable()) : this.router.navigateByUrl("/leads")
        }
        setEditMode() {
            this.isEditMode = !0, this.form.enable({
                emitEvent: !1
            })
        }
        initialize() {
            this.loaderService.show(), this.dataService.getLookups().subscribe({
                next: i => {
                    this.allDeviceBrandList = i.device_brands, this.allDeviceModelList = i.device_models, this.allDeviceTypeList = i.device_types;
                    let e = this.form.value.device_type_id,
                        n = this.form.value.device_brand_id;
                    e && this.updateDeviceBrandList(), e && n && this.updateDeviceModelList(), this.form.get("device_type_id").valueChanges.subscribe(() => {
                        this.updateDeviceBrandList(), this.updateDeviceModelList()
                    }), this.form.get("device_brand_id").valueChanges.subscribe(() => {
                        this.updateDeviceModelList()
                    }), this.subscribeToValueChangesOnDeviceId()
                },
                error: i => {
                    console.log(i)
                }
            }).add(() => {
                this.loaderService.hide()
            })
        }
        updateDeviceBrandList() {
            let i = this.form.controls.device_type_id.value;
            i ? this.deviceBrandList = this.allDeviceBrandList.filter(e => e.device_type_id === i) : this.deviceBrandList = []
        }
        updateDeviceModelList() {
            let i = this.form.controls.device_brand_id.value,
                e = this.form.controls.device_type_id.value;
            this.deviceModelList = this.allDeviceModelList.filter(n => n.device_brand_id === i && n.device_type_id === e)
        }
        onAddDeviceBrand(i) {
            this.isVisibleDeviceBrandPopup = !1, this.deviceBrandList.push(i), this.form.patchValue({
                device_brand_id: i.id
            })
        }
        onAddDeviceModel(i) {
            this.isVisibleDeviceModelPopup = !1, this.deviceModelList.push(i), this.form.patchValue({
                device_model_id: i.id
            })
        }
        onChangeDeviceBrand() {
            this.deviceModelList = this.allDeviceModelList.filter(i => i.device_brand_id === this.form.value.device_brand_id && i.device_type_id === this.form.value.device_type_id)
        }
        onChangeDeviceType(i) {
            this.form.patchValue({
                device_brand_id: null,
                accessories: [],
                repairables: [],
                device_model_id: null
            }), this.updateDeviceTypeChanges(i)
        }
        updateDeviceTypeChanges(i) {
            this.deviceBrandList = this.allDeviceBrandList.filter(e => e.device_type_id === i)
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || t)
            }
        }
        static {
            this.\u0275cmp = M({
                type: t,
                selectors: [
                    ["app-lead-detail"]
                ],
                standalone: !1,
                decls: 6,
                vars: 3,
                consts: [
                    ["formTemplate", ""],
                    [3, "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "deviceModel", "isAddingFromJob", "isCreate", "isVisiblePopup"],
                    [4, "ngTemplateOutlet"],
                    ["type", "form", 3, "rows", "columns"],
                    ["autocomplete", "off", 3, "formGroup"],
                    ["autocomplete", "off", 3, "ngSubmit", "formGroup"],
                    [1, "row", "mb-3"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [3, "gaEvent", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    [1, "mt-2", 3, "errorResponse"],
                    [3, "title"],
                    [1, "row"],
                    ["name", "role_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["displayExpr", "display_name", "formControlName", "role_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled"],
                    ["name", "name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["name", "lead_source_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["displayExpr", "name", "formControlName", "lead_source_id", "searchMode", "contains", "valueExpr", "id", 3, "items", "placeholder", "searchEnabled"],
                    ["name", "referred_by_user_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    [3, "customerId", "formControl", "isEditMode", "isVisibleAddAction"],
                    ["name", "mobile_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    [3, "entity", "entityId", "formControl", "isEditMode", "form", "isUniqueValidation"],
                    [3, "displayError", "errorMsg"],
                    ["name", "email", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["name", "phone_number", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "label"],
                    [3, "formControl", "isEditMode"],
                    ["name", "contact_person_name", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "contact_person_name", 3, "placeholder"],
                    ["name", "next_follow_up", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "next_follow_up", "type", "datetime", 3, "dateSerializationFormat", "displayFormat", "min", "pickerType", "placeholder"],
                    ["name", "assigned_user_id", 1, "col-sm-4", "col-md-4", "col-lg-4", 3, "errorMsg", "label"],
                    ["formControlName", "assigned_user_id", 3, "entity", "isActiveOnly", "isEditMode"],
                    [1, "my-2", 3, "title"],
                    ["name", "device_type_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_type_id", 3, "dataSource", "placeholder"],
                    ["name", "device_brand_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_brand_id", 3, "dataSource", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "isReadOnly", "placeholder"],
                    ["name", "device_model_id", 1, "col-sm-3", "col-md-3", "col-lg-3", 3, "errorMsg", "label"],
                    ["formControlName", "device_model_id", 3, "dataSource", "isDxiButtonActive", "hasUserPermissions", "buttonOptions", "buttonId", "buttonName", "isReadOnly", "placeholder"],
                    [1, "row", "d-flex", "flex-wrap", 3, "formType", "form", "hasColumn"],
                    ["name", "comment", 1, "col-sm-12", "col-md-12", "col-lg-12", 3, "errorMsg", "label"],
                    [1, "mt-5"],
                    [3, "parentForm"],
                    [1, "w-100", "mt-1", "mb-3", "pb-3"],
                    [3, "gaEvent", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText", "cancelClick", 4, "ngxPermissionsOnly"],
                    [3, "cancelClick", "gaEvent", "isOnPopup", "isSaving", "isVisibleHr", "saveText", "savingText"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1"],
                    ["buttonType", "default", "text", "common_edit", "class", "float-end ms-1", 3, "onClickEvent", 4, "ngxPermissionsOnly"],
                    ["buttonType", "default", "text", "common_edit", 1, "float-end", "ms-1", 3, "onClickEvent"],
                    [3, "entityId", "entity", "formControl", "isEditMode", "isUniqueValidation"],
                    [3, "deviceBrandCancelClick", "deviceBrandSaveClick", "deviceBrand", "isCreate", "isVisiblePopup"],
                    [3, "deviceModelCancelClick", "deviceModelSaveClick", "deviceModel", "isAddingFromJob", "isCreate", "isVisiblePopup"]
                ],
                template: function(e, n) {
                    e & 1 && (p(0, ai, 1, 1, "ng-container")(1, li, 1, 1, "ng-container"), x(2, gi, 2, 2, "ng-template", null, 0, $), p(4, bi, 1, 3, "app-device-brand", 1), p(5, yi, 1, 4, "app-device-model-popup", 2)), e & 2 && (_(n.leadId ? 0 : 1), a(4), _(n.isVisibleDeviceBrandPopup ? 4 : -1), a(), _(n.isVisibleDeviceModelPopup ? 5 : -1))
                },
                dependencies: [K, xe, Ae, Se, be, We, ye, Le, Fe, Re, Ne, Oe, Be, he, Ee, qe, Ge, je, Ve, Ie, Ce, ge, oe, ie, te, ne, re, ae, de],
                encapsulation: 2
            })
        }
    }
    return t
})();

function Mi(t, r) {
    if (t & 1 && c(0, "app-user-profile-info", 1), t & 2) {
        let i = d();
        o("entity", i.entity)("user", i.lead)
    }
}

function xi(t, r) {
    if (t & 1) {
        let i = g();
        l(0, "app-responsive-tabs", 4), C("tabChange", function(n) {
            u(i);
            let h = d();
            return f(h.selectTab(n))
        }), s()
    }
    if (t & 2) {
        let i = d();
        o("tabs", i.tabs)("selectedIndex", i.selectedTabIndex)("mobileMenuTitle", i.lead == null ? null : i.lead.name)
    }
}
var Ke = (() => {
    class t {
        constructor(i, e, n) {
            this.service = i, this.meta = e, this.loaderService = n, this.formatMessage = v, this.router = m(A), this.userSessionService = m(F), this.userPermissionList = this.userSessionService.userPermissionList(), this.activatedRouter = m(T), this.entity = I.LEAD, this.leadId = null, this.tabs = [], this.meta.addTags([{
                name: "description",
                content: "View Your Leads Profile"
            }, {
                name: "keywords",
                content: "Leads,Follow Up, Converted, manage lead by status,"
            }])
        }
        ngOnInit() {
            this.leadId = +this.activatedRouter.snapshot.paramMap.get("lead_id"), this.tabs = [{
                id: 0,
                text: v("profile"),
                path: `/leads/${this.leadId}/profiles`,
                icon: "fa-thin fa-id-card"
            }, {
                id: 1,
                text: v("follow_up_history"),
                path: `/leads/${this.leadId}/followUps`,
                visible: this.userPermissionList.includes(b.FOLLOW_UP_LIST),
                icon: "fa-thin fa-history"
            }], this.leadId && (this.loaderService.show(), this.selectedTabIndex = +this.activatedRouter.snapshot.paramMap.get("tab_index"), this.service.getById(this.leadId).subscribe({
                next: i => {
                    this.lead = new y(i)
                },
                error: i => {
                    console.error(i)
                }
            }).add(() => this.loaderService.hide()))
        }
        selectTab(i) {
            this.selectedTabIndex = i.itemIndex
        }
        static {
            this.\u0275fac = function(e) {
                return new(e || t)(S(L), S(ee), S(R))
            }
        }
        static {
            this.\u0275cmp = M({
                type: t,
                selectors: [
                    ["app-lead-profile"]
                ],
                standalone: !1,
                features: [Q([{
                    provide: Ye,
                    useExisting: L
                }])],
                decls: 4,
                vars: 2,
                consts: [
                    [1, "container-fluid"],
                    [3, "entity", "user"],
                    [1, "mt-1", "mb-1"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-bullseye", 3, "tabs", "selectedIndex", "mobileMenuTitle"],
                    ["mode", "route", "mobileMenuIcon", "fa-solid fa-bullseye", 3, "tabChange", "tabs", "selectedIndex", "mobileMenuTitle"]
                ],
                template: function(e, n) {
                    e & 1 && (l(0, "div", 0), p(1, Mi, 1, 2, "app-user-profile-info", 1), l(2, "div", 2), p(3, xi, 1, 3, "app-responsive-tabs", 3), s()()), e & 2 && (a(), _(n.lead ? 1 : -1), a(2), _(n.tabs ? 3 : -1))
                },
                dependencies: [Ze, He],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Xe = (() => {
    class t {
        static {
            this.\u0275fac = function(e) {
                return new(e || t)
            }
        }
        static {
            this.\u0275cmp = M({
                type: t,
                selectors: [
                    ["app-lead"]
                ],
                standalone: !1,
                decls: 2,
                vars: 0,
                consts: [
                    [1, "container-fluid"]
                ],
                template: function(e, n) {
                    e & 1 && (l(0, "div", 0), c(1, "router-outlet"), s())
                },
                dependencies: [se],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Si = [{
        path: "",
        component: Xe,
        children: [{
            path: "list",
            component: G,
            canActivate: [E],
            data: {
                permissions: {
                    only: [b.LEAD_LIST]
                }
            },
            pathMatch: "full",
            title: "BytePhase Lead Management"
        }, {
            path: "assigned",
            component: G,
            canActivate: [fe, E, Qe],
            data: {
                permissions: {
                    only: [b.LEAD_LIST]
                },
                assigned_only: !0
            },
            pathMatch: "full",
            title: "BytePhase Assigned Leads"
        }, {
            path: "add",
            component: j,
            canActivate: [E],
            data: {
                permissions: {
                    only: [b.LEAD_WRITE]
                }
            },
            title: "BytePhase Leads | Add Leads"
        }, {
            path: ":lead_id",
            component: Ke,
            canActivate: [E],
            data: {
                permissions: {
                    only: [b.LEAD_LIST]
                }
            },
            children: [{
                path: "profiles",
                component: j,
                data: {
                    tab_index: 0
                },
                title: "BytePhase Lead | Profile"
            }, {
                path: "followUps",
                component: $e,
                canActivate: [E],
                data: {
                    tab_index: 1,
                    permissions: {
                        only: [b.FOLLOW_UP_LIST]
                    }
                },
                title: "BytePhase Lead | Follow Ups"
            }, {
                path: "",
                redirectTo: "profile",
                pathMatch: "full"
            }]
        }, {
            path: "",
            redirectTo: "list",
            pathMatch: "full"
        }]
    }],
    ei = (() => {
        class t {
            static {
                this.\u0275fac = function(e) {
                    return new(e || t)
                }
            }
            static {
                this.\u0275mod = V({
                    type: t
                })
            }
            static {
                this.\u0275inj = P({
                    imports: [k.forChild(Si), k]
                })
            }
        }
        return t
    })();
var Lo = (() => {
    class t {
        static {
            this.\u0275fac = function(e) {
                return new(e || t)
            }
        }
        static {
            this.\u0275mod = V({
                type: t
            })
        }
        static {
            this.\u0275inj = P({
                imports: [X, ei, Je]
            })
        }
    }
    return t
})();
export {
    Lo as a
};