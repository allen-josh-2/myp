import {
    a as Ge
} from "./chunk-ZG5YLBXN.js";
import {
    b as qe
} from "./chunk-2E5FSGQH.js";
import {
    a as Je,
    b as Xe
} from "./chunk-FJFEFX5C.js";
import {
    c as $e,
    g as Ye
} from "./chunk-WDS5LHZR.js";
import "./chunk-36T2HUF3.js";
import "./chunk-OG4EABPU.js";
import "./chunk-HUDETQT5.js";
import "./chunk-PGAHHPJ5.js";
import "./chunk-MBAKXBI4.js";
import "./chunk-JWXBIPIQ.js";
import "./chunk-73S5G3JB.js";
import "./chunk-FAP35UT3.js";
import "./chunk-2KS5UOZO.js";
import "./chunk-KJCCJCIN.js";
import {
    $b as Be,
    Ba as Ae,
    Cb as Re,
    Sc as Le,
    T as I,
    Ug as ze,
    V as Te,
    Vc as Ve,
    Wc as je,
    Zd as V,
    ba as G,
    bf as Fe,
    ca as J,
    ha as ye,
    jg as He,
    lb as L,
    na as Ie,
    ph as Ke,
    rg as Ue,
    xc as Ne,
    ya as Se,
    yb as De,
    za as Ee
} from "./chunk-DCKGQUHB.js";
import {
    $a as g,
    $b as pe,
    Ai as te,
    Bi as ke,
    Ci as w,
    Di as oe,
    Eb as x,
    Ec as q,
    Fa as o,
    Fb as se,
    Fh as U,
    Fi as Oe,
    Hb as N,
    Ib as s,
    Jb as b,
    Ka as Q,
    Kb as E,
    Kf as ee,
    Lb as me,
    Mc as ge,
    Na as O,
    Oa as K,
    Pg as P,
    Sa as ce,
    Tc as be,
    Vg as he,
    Wg as fe,
    Xa as D,
    Za as $,
    _a as _,
    _h as ve,
    aa as re,
    ac as Y,
    ba as z,
    bb as W,
    bc as Z,
    cb as R,
    ci as xe,
    da as de,
    db as B,
    ea as u,
    eb as c,
    fb as i,
    fd as Ce,
    gb as r,
    gc as T,
    ha as h,
    hb as p,
    hc as y,
    hi as v,
    ia as f,
    li as Me,
    oc as _e,
    qa as le,
    qb as k,
    sb as M,
    sd as ue,
    ti as Pe,
    ub as m,
    ui as we,
    vd as F,
    wh as H,
    xk as l,
    zi as A
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as ie,
    b as ae
} from "./chunk-FBFWB55K.js";
var X = (() => {
    class t extends Pe {
        constructor(e) {
            super(e, ee), this.api = e, this.endpoint = ee
        }
        getReport(e) {
            return this.api.getListByQuery(this.endpoint, e)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(de(we))
            }
        }
        static {
            this.\u0275prov = re({
                token: t,
                factory: t.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return t
})();

function it(t, d) {
    if (t & 1 && (i(0, "small", 1), s(1), T(2, "dateFormat"), T(3, "dateFormat"), r()), t & 2) {
        let e = m();
        o(), me("", y(2, 2, e.dateDuration == null ? null : e.dateDuration.from_date), " \u2013 ", y(3, 4, e.dateDuration == null ? null : e.dateDuration.to_date))
    }
}

function at(t, d) {
    t & 1 && p(0, "span")
}

function rt(t, d) {
    t & 1 && p(0, "app-skeleton-loader", 3), t & 2 && c("rows", 5)("columns", 3)
}

function dt(t, d) {
    if (t & 1 && p(0, "app-trend-matrix-card", 6), t & 2) {
        let e = m();
        c("currentDateRangeValue", e.dashboardTrendReport == null || e.dashboardTrendReport.total_payment_received_amount == null ? null : e.dashboardTrendReport.total_payment_received_amount.current_period_total)("percentage", e.dashboardTrendReport == null || e.dashboardTrendReport.total_payment_received_amount == null ? null : e.dashboardTrendReport.total_payment_received_amount.percentage_change)("toolTip", "payment_received_description")
    }
}

function lt(t, d) {
    if (t & 1 && p(0, "app-trend-matrix-card", 7), t & 2) {
        let e = m();
        c("currentDateRangeValue", e.dashboardTrendReport == null || e.dashboardTrendReport.total_expense_amount == null ? null : e.dashboardTrendReport.total_expense_amount.current_period_total)("percentage", e.dashboardTrendReport == null || e.dashboardTrendReport.total_expense_amount == null ? null : e.dashboardTrendReport.total_expense_amount.percentage_change)("toolTip", "total_expense_description")
    }
}

function ct(t, d) {
    if (t & 1 && p(0, "app-trend-matrix-card", 8), t & 2) {
        let e = m();
        c("currentDateRangeValue", e.dashboardTrendReport == null || e.dashboardTrendReport.total_payable_amount == null ? null : e.dashboardTrendReport.total_payable_amount.current_period_total)("percentage", e.dashboardTrendReport == null || e.dashboardTrendReport.total_payable_amount == null ? null : e.dashboardTrendReport.total_payable_amount.percentage_change)("toolTip", "total_business_description")
    }
}

function st(t, d) {
    if (t & 1 && p(0, "app-trend-matrix-card", 9), t & 2) {
        let e = m();
        c("currentDateRangeValue", e.dashboardTrendReport == null || e.dashboardTrendReport.total_due_amount == null ? null : e.dashboardTrendReport.total_due_amount.current_period_total)("percentage", e.dashboardTrendReport == null || e.dashboardTrendReport.total_due_amount == null ? null : e.dashboardTrendReport.total_due_amount.percentage_change)("toolTip", "total_due_amount_description")
    }
}

function mt(t, d) {
    if (t & 1 && p(0, "app-trend-matrix-card", 10), t & 2) {
        let e = m();
        c("currentDateRangeValue", e.dashboardTrendReport == null || e.dashboardTrendReport.net_profit == null ? null : e.dashboardTrendReport.net_profit.current_period_total)("percentage", e.dashboardTrendReport == null || e.dashboardTrendReport.net_profit == null ? null : e.dashboardTrendReport.net_profit.percentage_change)("toolTip", "net_profit_description")
    }
}

function pt(t, d) {
    if (t & 1 && (i(0, "div", 5), p(1, "app-trend-matrix-card", 11), r()), t & 2) {
        let e = m();
        o(), c("currentDateRangeValue", e.dashboardTrendReport == null || e.dashboardTrendReport.total_commission == null ? null : e.dashboardTrendReport.total_commission.current_period_total)("percentage", e.dashboardTrendReport == null || e.dashboardTrendReport.total_commission == null ? null : e.dashboardTrendReport.total_commission.percentage_change)("toolTip", "total_commission_description")
    }
}
var We = (() => {
    class t {
        constructor() {
            this.formatMessage = l, this.isLoading = !1, this.fromDate = null, this.toDate = null, this.graphType = "bar", this.tenantService = u(L), this.isMobileDevice = u(I).isMobileDevice(), this.toastNotificationService = u(J), this.plan = this.tenantService.plan(), this.REPORT_TYPE = H, this.REPORT_DURATION_LIST = ve, this.TENANT_PLANS = P, this.service = u(X)
        }
        setGraphType(e) {
            this.graphType = e
        }
        setReportForDuration(e) {
            let n = {
                from_date: e.fromDate ? ? null,
                to_date: e.toDate ? ? null,
                type: ""
            };
            this.dateDuration = n, this.service.getReport(ae(ie({}, n), {
                type: H.DASHBOARD_TREND
            })).subscribe({
                next: a => {
                    this.dashboardTrendReport = a
                },
                error: a => {
                    console.error("Error Fetching Reports", a), this.toastNotificationService.error("notification_report_fetch_error")
                }
            }).add(() => {
                this.isLoading = !1
            })
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = O({
                type: t,
                selectors: [
                    ["app-admin-dashboard"]
                ],
                standalone: !1,
                decls: 17,
                vars: 10,
                consts: [
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-2"],
                    [1, "text-muted"],
                    [3, "durationDateChanges", "selectedDuration"],
                    ["type", "card-grid", 3, "rows", "columns"],
                    [1, "row", "flex-wrap", "justify-content-center", "my-2", "gap-1", 2, "display", "grid", "grid-template-rows", "1fr", "grid-template-columns", "repeat(auto-fit, minmax(270px, 1fr))", 3, "hidden"],
                    [1, "col", "px-1"],
                    ["icon", "fa-thin fa-money-bill-wave", "title", "payment_received", "tooltipId", "payment_received_description", 3, "currentDateRangeValue", "percentage", "toolTip"],
                    ["icon", "fa-thin fa-arrow-trend-down", "title", "total_expense_heading", "tooltipId", "total_expense_description", 3, "currentDateRangeValue", "percentage", "toolTip"],
                    ["icon", "fa-thin fa-store-alt", "title", "total_business_heading", "tooltipId", "total_business_description", 3, "currentDateRangeValue", "percentage", "toolTip"],
                    ["icon", "fa-thin fa-clock", "title", "total_due_amount_heading", "tooltipId", "total_due_amount_description", 3, "currentDateRangeValue", "percentage", "toolTip"],
                    ["icon", "fa-thin fa-chart-line", "title", "net_profit", "tooltipId", "net_profit_description", 3, "currentDateRangeValue", "percentage", "toolTip"],
                    ["icon", "fa-thin fa-percent", "title", "total_commission_heading", "tooltipId", "total_commission_description", 3, "currentDateRangeValue", "percentage", "toolTip"]
                ],
                template: function(n, a) {
                    n & 1 && (i(0, "div", 0), _(1, it, 4, 6, "small", 1)(2, at, 1, 0, "span"), i(3, "app-report-duration-dropdown", 2), M("durationDateChanges", function(S) {
                        return a.setReportForDuration(S)
                    }), r()(), _(4, rt, 1, 2, "app-skeleton-loader", 3), i(5, "div", 4)(6, "div", 5), _(7, dt, 1, 3, "app-trend-matrix-card", 6), r(), i(8, "div", 5), _(9, lt, 1, 3, "app-trend-matrix-card", 7), r(), i(10, "div", 5), _(11, ct, 1, 3, "app-trend-matrix-card", 8), r(), i(12, "div", 5), _(13, st, 1, 3, "app-trend-matrix-card", 9), r(), i(14, "div", 5), _(15, mt, 1, 3, "app-trend-matrix-card", 10), r(), _(16, pt, 2, 3, "div", 5), r()), n & 2 && (o(), g(a.dateDuration != null && a.dateDuration.from_date && (a.dateDuration != null && a.dateDuration.to_date) ? 1 : 2), o(2), c("selectedDuration", a.REPORT_DURATION_LIST.LAST_THIRTY_DAYS), o(), g(a.dashboardTrendReport ? -1 : 4), o(), c("hidden", !a.dashboardTrendReport), o(2), g(a.dashboardTrendReport != null && a.dashboardTrendReport.total_payment_received_amount ? 7 : -1), o(2), g(a.dashboardTrendReport != null && a.dashboardTrendReport.total_expense_amount ? 9 : -1), o(2), g(a.dashboardTrendReport != null && a.dashboardTrendReport.total_payable_amount ? 11 : -1), o(2), g(a.dashboardTrendReport != null && a.dashboardTrendReport.total_due_amount ? 13 : -1), o(2), g(a.dashboardTrendReport != null && a.dashboardTrendReport.net_profit ? 15 : -1), o(), g(a.dashboardTrendReport != null && a.dashboardTrendReport.total_commission ? 16 : -1))
                },
                dependencies: [je, ze, V, De],
                styles: ["#pie #device_type_pie #service_type_bar #earning_chart{height:440px}.border-left-theme[_ngcontent-%COMP%]{border-left:6px solid #3498db!important}.card-body-theme[_ngcontent-%COMP%]{border-top-right-radius:.25rem;border-bottom-right-radius:.25rem}.text-font[_ngcontent-%COMP%]{font-size:8px}.tilt-card[_ngcontent-%COMP%]{transition:transform .3s ease,box-shadow .3s ease,background-color .3s ease;transform-style:preserve-3d;perspective:1000px;cursor:pointer}.tilt-card[_ngcontent-%COMP%]:hover{transform:rotateX(-5deg) rotateY(5deg) translateY(-4px);box-shadow:8px 8px 20px #00000026,-2px -2px 10px #ffffff1a;background-color:#3498db0d}.dark-theme[_ngcontent-%COMP%]   .tilt-card[_ngcontent-%COMP%]:hover{box-shadow:8px 8px 20px #0006,-2px -2px 10px #ffffff0d;background-color:#3498db1a}.report-box.tilt-card[_ngcontent-%COMP%]:hover{transform:rotateX(-3deg) rotateY(4deg) translateY(-3px);border-left-color:#217dbb!important}"]
            })
        }
    }
    return t
})();
var Ze = (t, d, e) => ({
    "fa-2x": t,
    "fa-3x": d,
    "dx-state-disabled": e
});

function bt(t, d) {
    t & 1 && p(0, "app-skeleton-loader", 0), t & 2 && c("rows", 1)("columns", 4)
}

function Ct(t, d) {
    if (t & 1 && (i(0, "div", 1)(1, "div", 3)(2, "div", 4)(3, "div", 5)(4, "h3"), s(5), r(), i(6, "div", 6), p(7, "i", 7), i(8, "h6", 8), s(9), r()()()(), i(10, "div", 4)(11, "div", 5)(12, "h3"), s(13), r(), i(14, "div", 6), p(15, "i", 9), i(16, "h6", 10), s(17), r()()()(), i(18, "div", 4)(19, "div", 5)(20, "h3"), s(21), r(), i(22, "div", 6), p(23, "i", 11), i(24, "h6", 10), s(25), r()()()(), i(26, "div", 4)(27, "div", 5)(28, "h3"), s(29), r(), i(30, "div", 6), p(31, "i", 7), i(32, "h6", 8), s(33), r()()()()()()), t & 2) {
        let e = d,
            n = m();
        o(5), b(e.assigned_jobs), o(2), c("ngClass", n.isMobileDevice ? "fa-2x" : "fa-3x"), o(2), b(n.formatMessage("assigned_jobs")), o(4), b(e.assigned_leads), o(2), c("ngClass", Z(14, Ze, n.isMobileDevice, !n.isMobileDevice, !n.authorizationService.canAccess(n.ENTITIES.LEAD))), o(), c("ngClass", n.authorizationService.canAccess(n.ENTITIES.LEAD) ? "" : "text-secondary"), o(), b(n.formatMessage("assigned_leads")), o(4), b(e.assigned_tasks), o(2), c("ngClass", Z(18, Ze, n.isMobileDevice, !n.isMobileDevice, !n.authorizationService.canAccess(n.ENTITIES.TASK))), o(), c("ngClass", n.authorizationService.canAccess(n.ENTITIES.TASK) ? "" : "text-secondary"), o(), b(n.formatMessage("assigned_task")), o(4), b(e.delayed_jobs), o(2), c("ngClass", n.isMobileDevice ? "fa-2x" : "fa-3x"), o(2), b(n.formatMessage("assigned_delayed_jobs"))
    }
}

function ut(t, d) {
    t & 1 && p(0, "app-skeleton-loader", 0), t & 2 && c("rows", 1)("columns", 4)
}

function ht(t, d) {
    if (t & 1 && (i(0, "div", 2)(1, "div", 12)(2, "div", 13)(3, "div", 14)(4, "h3"), s(5), r(), i(6, "div", 6), p(7, "app-currency-symbol"), i(8, "h6", 8), s(9), r()()()()(), i(10, "div", 12)(11, "div", 15)(12, "div", 14)(13, "h3"), s(14), r(), i(15, "div", 6), p(16, "i", 16), i(17, "h6", 8), s(18), r()()()()(), i(19, "div", 12)(20, "div", 15)(21, "div", 14)(22, "h3"), s(23), r(), i(24, "div", 6), p(25, "i", 16), i(26, "h6", 8), s(27), r()()()()(), i(28, "div", 12)(29, "div", 15)(30, "div", 14)(31, "h3"), s(32), r(), i(33, "div", 6), p(34, "i", 16), i(35, "h6", 8), s(36), r()()()()()()), t & 2) {
        let e = d,
            n = m();
        o(5), b(e.open_jobs), o(4), b(n.formatMessage("job_open_jobs")), o(5), b(e.closed_jobs), o(4), b(n.formatMessage("closed_jobs")), o(5), b(e.delayed_jobs), o(4), b(n.formatMessage("delayed_jobs")), o(5), b(e.sales), o(4), b(n.formatMessage("sale"))
    }
}
var et = (() => {
    class t {
        constructor(e, n) {
            this.service = e, this.meta = n, this.formatMessage = l, this.ENTITIES = v, this.authorizationService = u(Re), this.userSessionService = u(G), this.isMobileDevice = u(I).isMobileDevice(), this.isEmployee = this.userSessionService.isEmployee(), this.meta.addTags([{
                name: "description",
                content: "All your Laptop repair Business Reports At one place on Dashboard"
            }, {
                name: "keywords",
                content: "Dashboard, cloud-based CRM, Laptop, repair, services, parts"
            }])
        }
        ngOnInit() {
            this.report$ = this.service.getReportForDashboard()
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)(Q(Ve), Q(Ce))
            }
        }
        static {
            this.\u0275cmp = O({
                type: t,
                selectors: [
                    ["app-dashboard-info"]
                ],
                standalone: !1,
                decls: 8,
                vars: 12,
                consts: [
                    ["type", "card-grid", 3, "rows", "columns"],
                    [1, "theme-secondary-bg", "p-2", "px-3"],
                    [1, "row"],
                    [1, "row", "row-cols-2", "row-cols-lg-5", "justify-content-between", "my-2"],
                    [1, "col", "card"],
                    [1, "p-3", "text-center"],
                    [1, "d-flex", "justify-content-center", "align-items-center"],
                    [1, "fa-thin", "fa-ticket", "me-2", 3, "ngClass"],
                    [1, "mb-0"],
                    [1, "fa-thin", "fa-user-plus", "me-2", 3, "ngClass"],
                    [3, "ngClass"],
                    [1, "fa-thin", "fa-tasks", "me-2", 3, "ngClass"],
                    [1, "col-sm-3", "col-md-3", "col-lg-3", "mb-1"],
                    [1, "card", "report-box", "border-left-theme"],
                    [1, "card-body", "card-body-theme", "text-center"],
                    [1, "card", "border-left-theme", "report-box"],
                    [1, "fa-thin", "fa-ticket", "me-2", "fa-3x"]
                ],
                template: function(n, a) {
                    if (n & 1 && (_(0, bt, 1, 2, "app-skeleton-loader", 0), T(1, "async"), _(2, Ct, 34, 22, "div", 1), T(3, "async"), _(4, ut, 1, 2, "app-skeleton-loader", 0), T(5, "async"), _(6, ht, 37, 8, "div", 2), T(7, "async")), n & 2) {
                        let C, S;
                        g(a.isEmployee && !y(1, 4, a.report$) ? 0 : -1), o(2), g((C = y(3, 6, a.isEmployee && a.report$)) ? 2 : -1, C), o(2), g(!a.isEmployee && !y(5, 8, a.report$) ? 4 : -1), o(2), g((S = y(7, 10, !a.isEmployee && a.report$)) ? 6 : -1, S)
                    }
                },
                dependencies: [q, V, Le, ge],
                styles: ["#pie #device_type_pie #service_type_bar #earning_chart{height:440px}.border-left-theme[_ngcontent-%COMP%]{border-left:6px solid #3498db!important}.card-body-theme[_ngcontent-%COMP%]{border-top-right-radius:.25rem;border-bottom-right-radius:.25rem}.text-font[_ngcontent-%COMP%]{font-size:8px}.tilt-card[_ngcontent-%COMP%]{transition:transform .3s ease,box-shadow .3s ease,background-color .3s ease;transform-style:preserve-3d;perspective:1000px;cursor:pointer}.tilt-card[_ngcontent-%COMP%]:hover{transform:rotateX(-5deg) rotateY(5deg) translateY(-4px);box-shadow:8px 8px 20px #00000026,-2px -2px 10px #ffffff1a;background-color:#3498db0d}.dark-theme[_ngcontent-%COMP%]   .tilt-card[_ngcontent-%COMP%]:hover{box-shadow:8px 8px 20px #0006,-2px -2px 10px #ffffff0d;background-color:#3498db1a}.report-box.tilt-card[_ngcontent-%COMP%]:hover{transform:rotateX(-3deg) rotateY(4deg) translateY(-3px);border-left-color:#217dbb!important}"]
            })
        }
    }
    return t
})();

function vt(t, d) {
    t & 1 && p(0, "app-skeleton-loader", 0), t & 2 && c("rows", 2)("columns", 3)
}

function xt(t, d) {
    if (t & 1 && (i(0, "p", 5), s(1), r()), t & 2) {
        let e = m(2);
        o(), b(e.formatMessage("actionable_items_subtitle"))
    }
}

function Mt(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "button", 12), M("click", function() {
            let a = h(e).$implicit,
                C = m(2);
            return f(C.setViewMode(a.mode))
        }), p(1, "i", 13), r()
    }
    if (t & 2) {
        let e = d.$implicit,
            n = m(2);
        se("active", n.currentViewMode === e.mode), c("ngClass", n.isMobileDevice ? "px-2 py-1" : ""), D("aria-label", e.tooltip)("title", e.tooltip), o(), N(e.icon), c("ngClass", n.isMobileDevice ? "small" : "")
    }
}

function Pt(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "div", 14)(1, "div", 15), M("click", function() {
            let a = h(e).$implicit,
                C = m(3);
            return f(C.navigateToItem(a))
        })("keydown.enter", function() {
            let a = h(e).$implicit,
                C = m(3);
            return f(C.navigateToItem(a))
        })("keydown.space", function(a) {
            let C = h(e).$implicit;
            return m(3).navigateToItem(C), f(a.preventDefault())
        }), i(2, "div", 16)(3, "div", 17)(4, "div", 18), p(5, "i"), r(), i(6, "div", 3)(7, "h6", 19), s(8), r(), i(9, "p", 20), s(10), r()(), i(11, "div", 21), s(12), r()()(), i(13, "div", 22)(14, "a", 23), s(15), p(16, "i", 24), r()()()()
    }
    if (t & 2) {
        let e = d.$implicit,
            n = m(3);
        o(), D("data-item-id", e.id)("aria-label", e.title + ": " + e.count + " items"), o(), x("--light-bg", e.cardBgColor)("--dark-bg", e.darkCardBgColor)("--light-bg-hover", e.cardBgHoverColor)("--dark-bg-hover", e.darkCardBgHoverColor), o(3), N(e.icon), x("color", e.iconColor), o(3), b(e.title), o(2), b(e.description), o(), x("--light-count-bg", e.countBgColor)("--dark-count-bg", e.darkCountBgColor)("--light-count-text", e.countTextColor)("--dark-count-text", e.darkCountTextColor), o(), E(" ", e.count, " "), o(3), E(" ", n.formatMessage(e.viewAllLinkKey), " ")
    }
}

function wt(t, d) {
    if (t & 1 && (i(0, "div", 8), R(1, Pt, 17, 26, "div", 14, $().trackByItemId, !0), r()), t & 2) {
        let e = m(2);
        o(), B(e.actionableItems)
    }
}

function kt(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "div", 28), M("click", function() {
            let a = h(e).$implicit,
                C = m(3);
            return f(C.navigateToItem(a))
        })("keydown.enter", function() {
            let a = h(e).$implicit,
                C = m(3);
            return f(C.navigateToItem(a))
        })("keydown.space", function(a) {
            let C = h(e).$implicit;
            return m(3).navigateToItem(C), f(a.preventDefault())
        }), i(1, "div", 29), p(2, "i"), r(), i(3, "div", 3)(4, "h6", 19), s(5), r(), i(6, "p", 30), s(7), r()(), i(8, "div", 31)(9, "span", 32), s(10), r(), i(11, "span", 33), s(12, "pending"), r()(), i(13, "div", 34), p(14, "i", 35), r()()
    }
    if (t & 2) {
        let e = d.$implicit;
        x("--item-border-color", e.borderColor)("--item-icon-color", e.iconColor), D("aria-label", e.title + ": " + e.count + " items"), o(2), N(e.icon), x("color", e.iconColor), o(3), b(e.title), o(2), b(e.description), o(2), x("color", e.iconColor), o(), b(e.count)
    }
}

function Ot(t, d) {
    if (t & 1 && (i(0, "div", 9)(1, "dx-scroll-view", 25)(2, "div", 26), R(3, kt, 15, 14, "div", 27, $().trackByItemId, !0), r()()()), t & 2) {
        let e = m(2);
        o(), c("height", 410)("showScrollbar", e.isMobileDevice ? "onScroll" : "never")("useNative", e.isMobileDevice), o(2), B(e.actionableItems)
    }
}

function Tt(t, d) {
    if (t & 1 && (i(0, "div", 50), p(1, "i"), i(2, "span"), s(3), r()()), t & 2) {
        let e = d.$implicit;
        o(), N(e.data.icon), x("color", e.data.iconColor), o(2), b(e.data.title)
    }
}

function yt(t, d) {
    if (t & 1 && (i(0, "div", 51), s(1), r()), t & 2) {
        let e = d.$implicit;
        o(), E(" ", e.data.description, " ")
    }
}

function It(t, d) {
    if (t & 1 && (i(0, "div", 52)(1, "span", 53), s(2), r()()), t & 2) {
        let e = d.$implicit;
        o(), x("background-color", e.data.countBgColor)("color", e.data.countTextColor), o(), E(" ", e.data.count, " ")
    }
}

function St(t, d) {
    if (t & 1 && (i(0, "div", 54)(1, "span", 55), s(2), r()()), t & 2) {
        let e = d.$implicit,
            n = m(3);
        o(), x("color", n.getPriorityColor(e.data.priority)), o(), E(" ", n.getPriorityLabel(e.data.priority), " ")
    }
}

function Et(t, d) {
    if (t & 1 && (i(0, "div", 56)(1, "button", 57), s(2), p(3, "i", 58), r()()), t & 2) {
        let e = m(3);
        o(2), E(" ", e.formatMessage("view") || "View", " ")
    }
}

function At(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "div", 10)(1, "dx-data-grid", 36), M("onRowClick", function(a) {
            h(e);
            let C = m(2);
            return f(C.navigateToItem(a.data))
        }), p(2, "dxo-paging", 37)(3, "dxo-scrolling", 38)(4, "dxo-selection", 39)(5, "dxi-column", 40)(6, "dxi-column", 41)(7, "dxi-column", 42)(8, "dxi-column", 43)(9, "dxi-column", 44), ce(10, Tt, 4, 5, "div", 45)(11, yt, 2, 1, "div", 46)(12, It, 3, 5, "div", 47)(13, St, 3, 3, "div", 48)(14, Et, 4, 1, "div", 49), r()()
    }
    if (t & 2) {
        let e = m(2);
        o(), c("dataSource", e.actionableItems)("showBorders", !1)("showRowLines", !0)("showColumnLines", !1)("hoverStateEnabled", !0)("rowAlternationEnabled", !1), o(), c("enabled", !1), o(3), c("caption", e.formatMessage("category") || "CATEGORY")("width", e.isMobileDevice ? void 0 : 240), o(), c("caption", e.formatMessage("description") || "DESCRIPTION")("visible", !e.isMobileDevice), o(), c("caption", e.formatMessage("count") || "COUNT")("width", e.isMobileDevice ? 80 : 100), o(), c("caption", e.formatMessage("priority") || "PRIORITY")("width", 120)("visible", !e.isMobileDevice), o(), c("caption", e.formatMessage("action") || "ACTION")("width", 120)("allowSorting", !1)("visible", !e.isMobileDevice), o(), c("dxTemplateOf", "categoryTemplate"), o(), c("dxTemplateOf", "descriptionTemplate"), o(), c("dxTemplateOf", "countTemplate"), o(), c("dxTemplateOf", "priorityTemplate"), o(), c("dxTemplateOf", "actionTemplate")
    }
}

function Dt(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "div", 66), M("click", function() {
            let a = h(e).$implicit,
                C = m(4);
            return f(C.navigateToItem(a))
        })("keydown.enter", function() {
            let a = h(e).$implicit,
                C = m(4);
            return f(C.navigateToItem(a))
        })("keydown.space", function(a) {
            let C = h(e).$implicit;
            return m(4).navigateToItem(C), f(a.preventDefault())
        }), i(1, "div", 67)(2, "div", 68), p(3, "i"), r(), i(4, "div", 3)(5, "h6", 69), s(6), r(), i(7, "p", 70), s(8), r(), i(9, "div", 71)(10, "span", 72), s(11), r(), i(12, "span", 73), s(13, "pending"), r()()()()()
    }
    if (t & 2) {
        let e = d.$implicit;
        x("--item-border-color", e.borderColor)("--item-icon-color", e.iconColor), D("aria-label", e.title + ": " + e.count + " items"), o(3), N(e.icon), x("color", e.iconColor), o(3), b(e.title), o(2), b(e.description), o(2), x("color", e.iconColor), o(), b(e.count)
    }
}

function Rt(t, d) {
    if (t & 1 && (i(0, "div", 60)(1, "div", 61)(2, "h6", 62), s(3), r(), i(4, "span", 63), s(5), r()(), i(6, "div", 64), R(7, Dt, 14, 14, "div", 65, $().trackByItemId, !0), r()()), t & 2) {
        let e = d.$implicit,
            n = m(3);
        D("data-priority", e.priority), o(3), b(e.title), o(2), b(n.getItemCountByPriority(e.priority)), o(2), B(n.getItemsByPriority(e.priority))
    }
}

function Bt(t, d) {
    if (t & 1 && (i(0, "div", 11)(1, "div", 59), R(2, Rt, 9, 3, "div", 60, W), r()()), t & 2) {
        let e = m(2);
        o(2), B(e.kanbanColumns)
    }
}

function Nt(t, d) {
    if (t & 1 && (i(0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "h6", 4), s(4), r(), _(5, xt, 2, 1, "p", 5), r(), i(6, "div", 6), R(7, Mt, 2, 8, "button", 7, W), r()(), _(9, wt, 3, 0, "div", 8), _(10, Ot, 5, 3, "div", 9), _(11, At, 15, 25, "div", 10), _(12, Bt, 4, 0, "div", 11), r()), t & 2) {
        let e = m();
        o(), c("ngClass", e.isMobileDevice ? "mb-2" : "mb-3"), o(3), b(e.formatMessage("actionable_items_title")), o(), g(e.isMobileDevice ? -1 : 5), o(2), B(e.viewModes), o(2), g(e.currentViewMode === "grid" ? 9 : -1), o(), g(e.currentViewMode === "list" ? 10 : -1), o(), g(e.currentViewMode === "table" ? 11 : -1), o(), g(e.currentViewMode === "kanban" ? 12 : -1)
    }
}
var tt = (() => {
    class t {
        constructor() {
            this.formatMessage = l, this.storageService = u(Te), this.service = u(X), this.toastNotificationService = u(J), this.router = u(ue), this.moduleDataService = u(He), this.tenantService = u(L), this.isMobileDevice = u(I).isMobileDevice(), this.showActionableItems = _e(), this.currentViewMode = this.getStoredViewMode() || "grid", this.viewModes = [{
                mode: "grid",
                icon: w.GRID_2.solid,
                tooltip: "Grid View"
            }, {
                mode: "list",
                icon: w.MENU.solid,
                tooltip: "List View"
            }, {
                mode: "table",
                icon: w.TABLE.solid,
                tooltip: "Table View"
            }, {
                mode: "kanban",
                icon: w.COLUMNS_3.solid,
                tooltip: "Kanban View"
            }], this.kanbanColumns = [{
                id: "critical",
                title: l("priority_critical") || "Critical",
                priority: "critical"
            }, {
                id: "high",
                title: l("priority_high") || "High",
                priority: "high"
            }, {
                id: "medium",
                title: l("priority_medium") || "Medium",
                priority: "medium"
            }, {
                id: "low",
                title: l("priority_low") || "Low",
                priority: "low"
            }]
        }
        ngOnInit() {
            this.currentPlan = this.tenantService.plan() ? .toUpperCase() || P.ENTERPRISE, this.service.getReport({
                type: H.ACTIONABLE_DASHBOARD
            }).subscribe({
                next: e => {
                    this.actionableItemsCounts = e, this.showActionableItems.emit(this.hasAnyActionableItems()), this.setActionableItems()
                },
                error: e => {}
            })
        }
        hasAnyActionableItems() {
            return this.actionableItemsCounts ? Object.values(this.actionableItemsCounts).some(n => n > 0) : !1
        }
        setViewMode(e) {
            this.currentViewMode = e, this.storeViewMode(e)
        }
        getItemsByPriority(e) {
            return this.actionableItems.filter(n => n.priority === e)
        }
        getItemCountByPriority(e) {
            return this.getItemsByPriority(e).reduce((n, a) => n + a.count, 0)
        }
        getStoredViewMode() {
            return localStorage.getItem("actionableItemsViewMode")
        }
        storeViewMode(e) {
            localStorage.setItem("actionableItemsViewMode", e)
        }
        getPriorityLabel(e) {
            return {
                critical: l("priority_critical") || "Critical",
                high: l("priority_high") || "High",
                medium: l("priority_medium") || "Medium",
                low: l("priority_low") || "Low"
            }[e] || e
        }
        getPriorityColor(e) {
            return {
                critical: "#dc2626",
                high: "#f97316",
                medium: "#eab308",
                low: "#16a34a"
            }[e] || "#6b7280"
        }
        navigateToItem(e) {
            this.router.navigate([e.route], {
                queryParams: e.queryParams
            })
        }
        trackByItemId(e, n) {
            return n.id
        }
        setActionableItems() {
            let e = Me[this.currentPlan] || [];
            this.actionableItems = [{
                id: "low-stock-alerts",
                title: l("actionable_low_stock_alerts"),
                description: l("actionable_low_stock_alerts_desc"),
                viewAllLinkKey: "actionable_view_all_low_stock_alerts",
                icon: ke.WARNING.light,
                iconColor: "#ef4444",
                count: this.actionableItemsCounts ? .low_stock_count,
                priority: "critical",
                cardBgColor: "#fef2f2",
                darkCardBgColor: "rgba(127, 29, 29, 0.2)",
                cardBgHoverColor: "#fee2e2",
                darkCardBgHoverColor: "rgba(127, 29, 29, 0.3)",
                countBgColor: "#fee2e2",
                countTextColor: "#dc2626",
                darkCountBgColor: "rgba(127, 29, 29, 0.4)",
                darkCountTextColor: "#fca5a5",
                borderColor: "#ef4444",
                route: "/parts/list",
                queryParams: {
                    stock_status: "low_stock"
                },
                visible: e.includes(v.PART.name) && this.actionableItemsCounts ? .low_stock_count !== 0
            }, {
                id: "pickup-deliveries",
                title: l("actionable_pickup_deliveries"),
                description: l("actionable_pickup_deliveries_desc"),
                viewAllLinkKey: "actionable_view_all_pickup_deliveries",
                icon: w.TRUCK.light,
                iconColor: "#3b82f6",
                count: this.actionableItemsCounts ? .pickup_drop_due_today,
                priority: "critical",
                cardBgColor: "#eff6ff",
                darkCardBgColor: "rgba(30, 58, 138, 0.2)",
                cardBgHoverColor: "#dbeafe",
                darkCardBgHoverColor: "rgba(30, 58, 138, 0.3)",
                countBgColor: "#dbeafe",
                countTextColor: "#1d4ed8",
                darkCountBgColor: "rgba(30, 58, 138, 0.4)",
                darkCountTextColor: "#93c5fd",
                borderColor: "#3b82f6",
                route: "/pickupDrops",
                queryParams: {
                    pickup_delivery_date: "today"
                },
                visible: e.includes(v.PICKUP_DROP.name) && this.actionableItemsCounts ? .pickup_drop_due_today !== 0
            }, {
                id: "tasks-due-today",
                title: l("actionable_tasks_due_today"),
                description: l("actionable_tasks_due_today_desc"),
                viewAllLinkKey: "actionable_view_all_tasks_due_today",
                icon: w.CHECK_SQUARE.light,
                iconColor: "#eab308",
                count: this.actionableItemsCounts ? .task_due_today,
                priority: "critical",
                cardBgColor: "#fefce8",
                darkCardBgColor: "rgba(133, 77, 14, 0.2)",
                cardBgHoverColor: "#fef9c3",
                darkCardBgHoverColor: "rgba(133, 77, 14, 0.3)",
                countBgColor: "#fef9c3",
                countTextColor: "#ca8a04",
                darkCountBgColor: "rgba(133, 77, 14, 0.4)",
                darkCountTextColor: "#fde047",
                borderColor: "#eab308",
                route: "/tasks/list",
                queryParams: {
                    due_date: "today"
                },
                visible: e.includes(v.TASK.name) && this.actionableItemsCounts ? .task_due_today !== 0
            }, {
                id: "jobs-due-today",
                title: l("actionable_jobs_due_today"),
                description: l("actionable_jobs_due_today_desc"),
                viewAllLinkKey: "actionable_view_all_jobs_due_today",
                icon: w.CALENDAR.light,
                iconColor: "#ef4444",
                count: this.actionableItemsCounts ? .job_due_today,
                priority: "high",
                cardBgColor: "#fef2f2",
                darkCardBgColor: "rgba(127, 29, 29, 0.2)",
                cardBgHoverColor: "#fee2e2",
                darkCardBgHoverColor: "rgba(127, 29, 29, 0.3)",
                countBgColor: "#fee2e2",
                countTextColor: "#b91c1c",
                darkCountBgColor: "rgba(127, 29, 29, 0.4)",
                darkCountTextColor: "#fca5a5",
                borderColor: "#ef4444",
                route: "/jobs/list",
                queryParams: {
                    due_date: "today"
                },
                visible: e.includes(v.JOB.name) && this.actionableItemsCounts ? .job_due_today !== 0
            }, {
                id: "lead-followups",
                title: l("actionable_lead_followups"),
                description: l("actionable_lead_followups_desc"),
                viewAllLinkKey: "actionable_view_all_lead_followups",
                icon: te.CALL.light,
                iconColor: "#ec4899",
                count: this.actionableItemsCounts ? .lead_follow_up_today,
                priority: "high",
                cardBgColor: "#fdf2f8",
                darkCardBgColor: "rgba(131, 24, 67, 0.2)",
                cardBgHoverColor: "#fce7f3",
                darkCardBgHoverColor: "rgba(131, 24, 67, 0.3)",
                countBgColor: "#fce7f3",
                countTextColor: "#db2777",
                darkCountBgColor: "rgba(131, 24, 67, 0.4)",
                darkCountTextColor: "#f9a8d4",
                borderColor: "#ec4899",
                route: "/leads/list",
                queryParams: {
                    followup_date: "today"
                },
                visible: e.includes(v.LEAD.name) && this.actionableItemsCounts ? .lead_follow_up_today !== 0
            }, {
                id: "unanswered-comments",
                title: l("actionable_unanswered_comments"),
                description: l("actionable_unanswered_comments_desc"),
                viewAllLinkKey: "actionable_view_all_unanswered_comments",
                icon: te.COMMENT.light,
                iconColor: "#f97316",
                count: this.actionableItemsCounts ? .unanswered_job_comments,
                priority: "high",
                cardBgColor: "#fff7ed",
                darkCardBgColor: "rgba(154, 52, 18, 0.2)",
                cardBgHoverColor: "#ffedd5",
                darkCardBgHoverColor: "rgba(154, 52, 18, 0.3)",
                countBgColor: "#ffedd5",
                countTextColor: "#ea580c",
                darkCountBgColor: "rgba(154, 52, 18, 0.4)",
                darkCountTextColor: "#fdba74",
                borderColor: "#f97316",
                route: "/jobs/comments",
                queryParams: {
                    has_unanswered_comments: !0
                },
                visible: e.includes(v.JOB.name) && this.actionableItemsCounts ? .unanswered_job_comments !== 0
            }, {
                id: "quotations-pending",
                title: l("actionable_quotations_pending"),
                description: l("actionable_quotations_pending_desc"),
                viewAllLinkKey: "actionable_view_all_quotations_pending",
                icon: Oe.INVOICE.light,
                iconColor: "#a855f7",
                count: this.actionableItemsCounts ? .quotation_pending_approval,
                priority: "medium",
                cardBgColor: "#faf5ff",
                darkCardBgColor: "rgba(88, 28, 135, 0.2)",
                cardBgHoverColor: "#f3e8ff",
                darkCardBgHoverColor: "rgba(88, 28, 135, 0.3)",
                countBgColor: "#f3e8ff",
                countTextColor: "#7c3aed",
                darkCountBgColor: "rgba(88, 28, 135, 0.4)",
                darkCountTextColor: "#c084fc",
                borderColor: "#a855f7",
                route: "/quotations/list",
                queryParams: {
                    status: xe.AWAITING_APPROVAL
                },
                visible: e.includes(v.QUOTATION.name) && this.actionableItemsCounts ? .quotation_pending_approval !== 0
            }, {
                id: "invoices-due-today",
                title: l("actionable_invoices_due_today"),
                description: l("actionable_invoices_due_today_desc"),
                viewAllLinkKey: "actionable_view_all_invoices_due_today",
                icon: oe.EXPENSE_CATEGORY.light,
                iconColor: "#22c55e",
                count: this.actionableItemsCounts ? .job_invoice_due_today,
                cardBgColor: "#f0fdf4",
                darkCardBgColor: "rgba(20, 83, 45, 0.2)",
                cardBgHoverColor: "#dcfce7",
                darkCardBgHoverColor: "rgba(20, 83, 45, 0.3)",
                countBgColor: "#dcfce7",
                countTextColor: "#16a34a",
                darkCountBgColor: "rgba(20, 83, 45, 0.4)",
                darkCountTextColor: "#86efac",
                borderColor: "#22c55e",
                priority: "medium",
                route: "/billings/invoices",
                queryParams: {
                    payment_due_date: "today"
                },
                visible: e.includes(v.JOB_INVOICE.name) && this.actionableItemsCounts ? .job_invoice_due_today !== 0
            }, {
                id: "supplier-payments",
                title: l("actionable_supplier_payments"),
                description: l("actionable_supplier_payments_desc"),
                viewAllLinkKey: "actionable_view_all_supplier_payments",
                icon: oe.PAYMENT_TYPE.light,
                iconColor: "#f97316",
                count: this.actionableItemsCounts ? .supplier_payment,
                priority: "medium",
                cardBgColor: "#fff7ed",
                darkCardBgColor: "rgba(154, 52, 18, 0.2)",
                cardBgHoverColor: "#ffedd5",
                darkCardBgHoverColor: "rgba(154, 52, 18, 0.3)",
                countBgColor: "#ffedd5",
                countTextColor: "#ea580c",
                darkCountBgColor: "rgba(154, 52, 18, 0.4)",
                darkCountTextColor: "#fdba74",
                borderColor: "#f97316",
                route: "/purchases/list",
                queryParams: {
                    due_date: "today"
                },
                visible: e.includes(v.PURCHASE.name) && this.actionableItemsCounts ? .supplier_payment !== 0
            }, {
                id: "self-checkin-approvals",
                title: l("actionable_self_checkin_approvals"),
                description: l("actionable_self_checkin_approvals_desc"),
                viewAllLinkKey: "actionable_view_all_self_checkin_approvals",
                icon: w.USER_CHECK.light,
                iconColor: "#14b8a6",
                count: this.actionableItemsCounts ? .open_contact_us,
                priority: "low",
                cardBgColor: "#f0fdfa",
                darkCardBgColor: "rgba(19, 78, 74, 0.2)",
                cardBgHoverColor: "#ccfbf1",
                darkCardBgHoverColor: "rgba(19, 78, 74, 0.3)",
                countBgColor: "#ccfbf1",
                countTextColor: "#0d9488",
                darkCountBgColor: "rgba(19, 78, 74, 0.4)",
                darkCountTextColor: "#5eead4",
                borderColor: "#14b8a6",
                route: "/jobs/selfCheckIn",
                queryParams: {
                    status: fe.OPEN
                },
                visible: e.includes(v.CONTACT_US.name) && this.actionableItemsCounts ? .open_contact_us !== 0
            }, {
                id: "amc-renewals",
                title: l("actionable_amc_renewals"),
                description: l("actionable_amc_renewals_desc"),
                viewAllLinkKey: "actionable_view_all_amc_renewals",
                icon: w.SHIELD_CHECK.light,
                iconColor: "#8b5cf6",
                count: this.actionableItemsCounts ? .amc_contract_expire_this_week,
                priority: "low",
                cardBgColor: "#f5f3ff",
                darkCardBgColor: "rgba(76, 29, 149, 0.2)",
                cardBgHoverColor: "#ede9fe",
                darkCardBgHoverColor: "rgba(76, 29, 149, 0.3)",
                countBgColor: "#ede9fe",
                countTextColor: "#7c3aed",
                darkCountBgColor: "rgba(76, 29, 149, 0.4)",
                darkCountTextColor: "#a78bfa",
                borderColor: "#8b5cf6",
                route: "/amcs/list",
                queryParams: {
                    contract_expiring: "week"
                },
                visible: e.includes(v.AMC_CONTRACT.name) && this.actionableItemsCounts ? .amc_contract_expire_this_week !== 0
            }, {
                id: "outsourcing",
                title: l("actionable_outsourcing"),
                description: l("actionable_outsourcing_desc"),
                viewAllLinkKey: "actionable_view_all_outsourcing",
                icon: A.CUSTOMER.light,
                iconColor: "#06b6d4",
                count: this.actionableItemsCounts ? .open_outsource_jobs,
                priority: "low",
                cardBgColor: "#ecfeff",
                darkCardBgColor: "rgba(22, 78, 99, 0.2)",
                cardBgHoverColor: "#cffafe",
                darkCardBgHoverColor: "rgba(22, 78, 99, 0.3)",
                countBgColor: "#cffafe",
                countTextColor: "#0891b2",
                darkCountBgColor: "rgba(22, 78, 99, 0.4)",
                darkCountTextColor: "#67e8f9",
                borderColor: "#06b6d4",
                route: "/jobs/outsourceTo/list",
                queryParams: {
                    status: he.OPEN
                },
                visible: e.includes(v.OUTSOURCED_JOB.name) && this.actionableItemsCounts ? .open_outsource_jobs !== 0
            }].filter(n => n.visible)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = O({
                type: t,
                selectors: [
                    ["app-actionable-items"]
                ],
                outputs: {
                    showActionableItems: "showActionableItems"
                },
                standalone: !1,
                decls: 2,
                vars: 2,
                consts: [
                    ["type", "card-grid", 3, "rows", "columns"],
                    [1, "mb-4", "position-relative"],
                    [1, "d-flex", "justify-content-between", "align-items-center", 3, "ngClass"],
                    [1, "flex-grow-1"],
                    [1, "fw-semibold", "actionable-items-title", "mb-0"],
                    [1, "actionable-items-subtitle", "mb-0", "text-muted", 2, "font-size", "0.75rem"],
                    [1, "view-mode-toggle", "flex-shrink-0"],
                    [1, "view-mode-btn", 3, "active", "ngClass"],
                    [1, "row", "g-3"],
                    [1, "d-flex", "flex-column", "gap-3"],
                    [1, "table-view"],
                    [1, "kanban-view"],
                    [1, "view-mode-btn", 3, "click", "ngClass"],
                    [3, "ngClass"],
                    [1, "col-lg-4", "col-md-6", "col-sm-12"],
                    ["role", "button", "tabindex", "0", 1, "card", "actionable-card", "h-100", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "card-header-section", "rounded-top"],
                    [1, "d-flex", "align-items-start", "mb-2"],
                    [1, "icon-wrapper", "me-3"],
                    [1, "fw-medium", "mb-1"],
                    [1, "text-muted", "mb-0"],
                    [1, "badge", "rounded-pill", "count-badge"],
                    [1, "card-footer-section", "rounded-bottom"],
                    [1, "view-link", "text-decoration-none", "d-inline-flex", "align-items-center"],
                    [1, "fa", "fa-chevron-right", "ms-1"],
                    [3, "height", "showScrollbar", "useNative"],
                    [1, "d-flex", "flex-column", "gap-2"],
                    ["role", "button", "tabindex", "0", 1, "list-item", "d-flex", "align-items-center", "gap-3", "p-3", "border", "rounded", 3, "--item-border-color", "--item-icon-color"],
                    ["role", "button", "tabindex", "0", 1, "list-item", "d-flex", "align-items-center", "gap-3", "p-3", "border", "rounded", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "list-item-icon"],
                    [1, "mb-0", "list-item-description"],
                    [1, "d-flex", "flex-column", "align-items-end", "gap-1"],
                    [1, "fw-bold", "list-item-count"],
                    [1, "list-item-pending-label", "text-lowercase"],
                    [1, "list-item-chevron"],
                    [1, "fa-solid", "fa-chevron-right"],
                    ["keyExpr", "id", 3, "onRowClick", "dataSource", "showBorders", "showRowLines", "showColumnLines", "hoverStateEnabled", "rowAlternationEnabled"],
                    [3, "enabled"],
                    ["mode", "standard"],
                    ["mode", "single"],
                    ["dataField", "title", "cellTemplate", "categoryTemplate", 3, "caption", "width"],
                    ["dataField", "description", "cellTemplate", "descriptionTemplate", 3, "caption", "visible"],
                    ["dataField", "count", "cellTemplate", "countTemplate", "alignment", "center", 3, "caption", "width"],
                    ["dataField", "priority", "cellTemplate", "priorityTemplate", "alignment", "center", 3, "caption", "width", "visible"],
                    ["cellTemplate", "actionTemplate", "alignment", "center", 3, "caption", "width", "allowSorting", "visible"],
                    ["class", "category-cell", 4, "dxTemplate", "dxTemplateOf"],
                    ["class", "description-cell", 4, "dxTemplate", "dxTemplateOf"],
                    ["class", "count-cell", 4, "dxTemplate", "dxTemplateOf"],
                    ["class", "priority-cell", 4, "dxTemplate", "dxTemplateOf"],
                    ["class", "action-cell", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "category-cell"],
                    [1, "description-cell"],
                    [1, "count-cell"],
                    [1, "table-count-badge"],
                    [1, "priority-cell"],
                    [1, "priority-badge"],
                    [1, "action-cell"],
                    [1, "border-0", "bg-transparent", "table-view-link"],
                    [1, "fa-solid", "fa-arrow-up-right-from-square", "ms-1"],
                    [1, "kanban-board"],
                    [1, "kanban-column"],
                    [1, "kanban-column-header"],
                    [1, "mb-0"],
                    [1, "kanban-column-count"],
                    [1, "kanban-column-content"],
                    ["role", "button", "tabindex", "0", 1, "kanban-card", "border", "rounded-3", "p-3", 3, "--item-border-color", "--item-icon-color"],
                    ["role", "button", "tabindex", "0", 1, "kanban-card", "border", "rounded-3", "p-3", 3, "click", "keydown.enter", "keydown.space"],
                    [1, "d-flex", "gap-2", "align-items-start"],
                    [1, "kanban-card-icon"],
                    [1, "mb-1"],
                    [1, "kanban-card-description", "mb-2"],
                    [1, "d-flex", "align-items-center", "justify-content-between"],
                    [1, "kanban-card-count"],
                    [1, "kanban-card-pending-label"]
                ],
                template: function(n, a) {
                    n & 1 && (_(0, vt, 1, 2, "app-skeleton-loader", 0), _(1, Nt, 13, 7, "div", 1)), n & 2 && (g(a.actionableItemsCounts ? -1 : 0), o(), g(a.actionableItemsCounts ? 1 : -1))
                },
                dependencies: [q, V, ye, Ne, Ae, Ie, Se, Ee, Be],
                styles: [".cursor-pointer[_ngcontent-%COMP%]{cursor:pointer}.actionable-items-title[_ngcontent-%COMP%]{color:var(--primary-text);font-size:.9rem}.actionable-items-subtitle[_ngcontent-%COMP%]{color:var(--primary-text);font-size:.9375rem;opacity:.7}.view-mode-toggle[_ngcontent-%COMP%]{display:flex;gap:.25rem;background:#f8f9fa;padding:.25rem;border-radius:.5rem}.view-mode-btn[_ngcontent-%COMP%]{background:transparent;border:none;padding:.5rem .75rem;border-radius:.375rem;cursor:pointer;color:#95a5a6;transition:all .2s ease}.view-mode-btn[_ngcontent-%COMP%]:hover{background:#ecf0f1;color:#2c3e50}.view-mode-btn.active[_ngcontent-%COMP%]{background:#fff;color:#3498db;box-shadow:0 1px 2px #0000000d}.actionable-card[_ngcontent-%COMP%]{transition:all .3s cubic-bezier(.4,0,.2,1)}.actionable-card[_ngcontent-%COMP%]:hover{transform:translateY(-6px) scale(1.02);box-shadow:0 20px 25px -5px #0000001a,0 10px 10px -5px #0000000a}.actionable-card[_ngcontent-%COMP%]   .card-header-section[_ngcontent-%COMP%]{padding:.75rem 1rem;flex:1;transition:background-color .2s ease;background-color:var(--light-bg)}.actionable-card[_ngcontent-%COMP%]:hover   .card-header-section[_ngcontent-%COMP%]{background-color:var(--light-bg-hover)}.actionable-card[_ngcontent-%COMP%]   .card-footer-section[_ngcontent-%COMP%]{padding:.75rem 1rem;text-align:center;background-color:#fff}.actionable-card[_ngcontent-%COMP%]   .icon-wrapper[_ngcontent-%COMP%]{width:2rem;height:2rem;border-radius:.5rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;background-color:#fff;box-shadow:0 1px 2px #0000000d}.actionable-card[_ngcontent-%COMP%]   .icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1rem}.actionable-card[_ngcontent-%COMP%]   .count-badge[_ngcontent-%COMP%]{background-color:var(--light-count-bg);color:var(--light-count-text);transition:background-color .2s ease,color .2s ease}.actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%]{color:#3498db}.actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%]:hover{text-decoration:none}.actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%]:hover   i[_ngcontent-%COMP%]{transform:translate(3px)}.list-item[_ngcontent-%COMP%]{background-color:#fff;border:1px solid #ecf0f1;border-top:3px solid var(--item-border-color)!important;transition:all .2s ease;cursor:pointer}.list-item[_ngcontent-%COMP%]:hover{transform:translateY(-2px);box-shadow:0 4px 12px #0000001a}.list-item-icon[_ngcontent-%COMP%]{width:3rem;height:3rem;border-radius:.5rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;background-color:#f8f9fa}.list-item-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.5rem}.list-item-title[_ngcontent-%COMP%]{font-size:1rem;color:#2c3e50}.list-item-description[_ngcontent-%COMP%]{font-size:.875rem;color:#95a5a6}.list-item-count[_ngcontent-%COMP%]{font-size:2rem;line-height:1}.list-item-pending-label[_ngcontent-%COMP%]{font-size:.75rem;color:#95a5a6}.list-item-chevron[_ngcontent-%COMP%]{color:#95a5a6;font-size:.875rem}.table-view[_ngcontent-%COMP%]{border-radius:.75rem;overflow:hidden}.table-view[_ngcontent-%COMP%]     .dx-datagrid{background:#fff;border:1px solid #ecf0f1;border-radius:.75rem;font-family:inherit}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers{background:#f8f9fa;border-bottom:1px solid #ecf0f1}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers .dx-header-row td{padding:.75rem 1rem;border-bottom:none;font-weight:600}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row{border-bottom:1px solid #f8f9fa}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row:last-child{border-bottom:none}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-row-lines>td{border-bottom:1px solid #f8f9fa}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row td{padding:.75rem 1rem;border-left:none;border-right:none}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-state-hover{background-color:#f8f9fa!important}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-state-hover td{background-color:transparent!important}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-content .dx-datagrid-table{border:none}.category-cell[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.5rem}.category-cell[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1rem}.category-cell[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-weight:500}.description-cell[_ngcontent-%COMP%]{color:#95a5a6;font-size:.875rem}.count-cell[_ngcontent-%COMP%]{display:flex;justify-content:center}.table-count-badge[_ngcontent-%COMP%]{padding:.25rem .75rem;border-radius:.375rem;font-weight:600;font-size:.875rem}.priority-cell[_ngcontent-%COMP%]{display:flex;justify-content:center}.priority-badge[_ngcontent-%COMP%]{font-weight:600;font-size:.75rem;text-transform:uppercase}.action-cell[_ngcontent-%COMP%]{display:flex;justify-content:center}.table-view-link[_ngcontent-%COMP%]{color:#3498db;text-decoration:none;font-weight:500;font-size:.875rem;display:inline-flex;align-items:center;gap:.25rem;transition:all .2s ease}.table-view-link[_ngcontent-%COMP%]:hover{color:#5faee3;text-decoration:underline}.table-view-link[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:.75rem}.kanban-board[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem}.kanban-column[_ngcontent-%COMP%]{background:#f8f9fa;border-radius:.75rem;padding:1rem;transition:all .2s ease}.kanban-column-header[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;padding-bottom:.75rem;border-bottom:1px solid #ecf0f1}.kanban-column-title[_ngcontent-%COMP%]{font-size:1rem;font-weight:600;color:#2c3e50}.kanban-column-count[_ngcontent-%COMP%]{background:#fff;padding:.25rem .625rem;border-radius:.5rem;font-size:.875rem;font-weight:700;color:#2c3e50;min-width:2rem;text-align:center}.kanban-column-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.75rem}.kanban-card[_ngcontent-%COMP%]{background-color:#fff;border:1px solid #ecf0f1;border-left:4px solid var(--item-border-color)!important;transition:all .2s ease;cursor:pointer}.kanban-card[_ngcontent-%COMP%]:hover{transform:translateY(-2px);box-shadow:0 10px 15px -3px #0000001a,0 4px 6px -2px #0000000d}.kanban-card-icon[_ngcontent-%COMP%]{width:2.5rem;height:2.5rem;border-radius:.5rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;background-color:#f8f9fa}.kanban-card-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem}.kanban-card-title[_ngcontent-%COMP%]{font-size:.9375rem;font-weight:600;color:#2c3e50}.kanban-card-description[_ngcontent-%COMP%]{font-size:.8125rem;color:#95a5a6;line-height:1.4}.kanban-card-count[_ngcontent-%COMP%]{font-size:1.5rem;font-weight:700;line-height:1}.kanban-card-pending-label[_ngcontent-%COMP%]{font-size:.75rem;color:#95a5a6;text-transform:lowercase}@media(max-width:1199.98px){.kanban-board[_ngcontent-%COMP%]{grid-template-columns:repeat(2,1fr)}}@media(max-width:767.98px){.view-mode-btn[_ngcontent-%COMP%]{padding:.375rem .625rem}.actionable-card[_ngcontent-%COMP%]   .card-header-section[_ngcontent-%COMP%], .actionable-card[_ngcontent-%COMP%]   .card-footer-section[_ngcontent-%COMP%]{padding:.625rem .875rem}.list-item-icon[_ngcontent-%COMP%]{width:2.5rem;height:2.5rem}.list-item-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:1.25rem}.kanban-board[_ngcontent-%COMP%]{grid-template-columns:1fr}.table-view[_ngcontent-%COMP%]{overflow-x:auto;border-radius:.5rem}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers .dx-header-row td{padding:.5rem .75rem}.table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row td{padding:.5rem .75rem}}.dark-theme[_nghost-%COMP%]   .actionable-items-title[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-items-title[_ngcontent-%COMP%], .dark-theme[_nghost-%COMP%]   .actionable-items-subtitle[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-items-subtitle[_ngcontent-%COMP%]{color:var(--primary-text)}.dark-theme[_nghost-%COMP%]   .view-mode-toggle[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .view-mode-toggle[_ngcontent-%COMP%]{background:#1e293b}.dark-theme[_nghost-%COMP%]   .view-mode-btn[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .view-mode-btn[_ngcontent-%COMP%]{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .view-mode-btn[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .view-mode-btn[_ngcontent-%COMP%]:hover{background:#334155;color:#fff}.dark-theme[_nghost-%COMP%]   .view-mode-btn.active[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .view-mode-btn.active[_ngcontent-%COMP%]{background:#10172a;color:#3498db}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]{border-color:#334155;background-color:#1e293b}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]:hover{box-shadow:0 20px 25px -5px #00000080,0 10px 10px -5px #0000004d;border-color:#334155}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .card-header-section[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .card-header-section[_ngcontent-%COMP%]{background-color:var(--dark-bg)}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]:hover   .card-header-section[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]:hover   .card-header-section[_ngcontent-%COMP%]{background-color:var(--dark-bg-hover)}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .card-footer-section[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .card-footer-section[_ngcontent-%COMP%]{background-color:#1e293b!important}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .icon-wrapper[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .icon-wrapper[_ngcontent-%COMP%]{background-color:#10172a}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .count-badge[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .count-badge[_ngcontent-%COMP%]{background-color:var(--dark-count-bg);color:var(--dark-count-text)}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%]{color:#3498db}.dark-theme[_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .actionable-card[_ngcontent-%COMP%]   .view-link[_ngcontent-%COMP%]:hover{color:#75b9e7}.dark-theme[_nghost-%COMP%]   .list-item[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .list-item[_ngcontent-%COMP%]{background:#1e293b!important;border-color:#334155!important;border-top:3px solid var(--item-border-color)!important}.dark-theme[_nghost-%COMP%]   .list-item[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .list-item[_ngcontent-%COMP%]:hover{background:#10172a!important;box-shadow:0 4px 12px #0000004d}.dark-theme[_nghost-%COMP%]   .list-item-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .list-item-icon[_ngcontent-%COMP%]{background-color:#10172a}.dark-theme[_nghost-%COMP%]   .list-item-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .list-item-description[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .list-item-pending-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .list-item-pending-label[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .list-item-chevron[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .list-item-chevron[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid{background:#1e293b;border-color:#334155}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers{background:#1e293b;border-bottom-color:#334155}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers .dx-header-row td, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-headers .dx-header-row td{color:#a0aec0}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row{border-bottom-color:#334155}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-row-lines>td, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-row-lines>td{border-bottom-color:#334155}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row td, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row td{color:#fff}.dark-theme[_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-state-hover, .dark-theme   [_nghost-%COMP%]   .table-view[_ngcontent-%COMP%]     .dx-datagrid .dx-datagrid-rowsview .dx-row.dx-state-hover{background-color:#1e293b!important}.dark-theme[_nghost-%COMP%]   .description-cell[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .description-cell[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .table-view-link[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .table-view-link[_ngcontent-%COMP%]{color:#3498db}.dark-theme[_nghost-%COMP%]   .table-view-link[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .table-view-link[_ngcontent-%COMP%]:hover{color:#75b9e7}.dark-theme[_nghost-%COMP%]   .kanban-column[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-column[_ngcontent-%COMP%]{background:#10172a}.dark-theme[_nghost-%COMP%]   .kanban-column-header[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-column-header[_ngcontent-%COMP%]{border-bottom-color:#334155}.dark-theme[_nghost-%COMP%]   .kanban-column-count[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-column-count[_ngcontent-%COMP%]{background:#1e293b;color:#fff}.dark-theme[_nghost-%COMP%]   .kanban-card[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-card[_ngcontent-%COMP%]{background-color:#1e293b!important;border-color:#334155!important;border-left:4px solid var(--item-border-color)!important}.dark-theme[_nghost-%COMP%]   .kanban-card[_ngcontent-%COMP%]:hover, .dark-theme   [_nghost-%COMP%]   .kanban-card[_ngcontent-%COMP%]:hover{background-color:#1e293b!important;box-shadow:0 10px 15px -3px #0000004d,0 4px 6px -2px #0003}.dark-theme[_nghost-%COMP%]   .kanban-card-icon[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-card-icon[_ngcontent-%COMP%]{background-color:#10172a}.dark-theme[_nghost-%COMP%]   .kanban-card-description[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-card-description[_ngcontent-%COMP%]{color:#a0aec0!important}.dark-theme[_nghost-%COMP%]   .kanban-card-pending-label[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .kanban-card-pending-label[_ngcontent-%COMP%]{color:#a0aec0!important}"]
            })
        }
    }
    return t
})();
var ne = (t, d) => [t, d],
    Vt = t => [t];

function jt(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "app-actionable-items", 4), M("showActionableItems", function(a) {
            h(e);
            let C = m(2);
            return f(C.manageActionableItems(a))
        }), r()
    }
}

function Ft(t, d) {
    if (t & 1 && _(0, jt, 1, 0, "app-actionable-items"), t & 2) {
        let e = m();
        g(e.displayActionableItems() ? 0 : -1)
    }
}

function Ht(t, d) {
    t & 1 && p(0, "app-admin-dashboard")
}

function Ut(t, d) {
    t & 1 && p(0, "app-dashboard-info")
}

function zt(t, d) {
    if (t & 1 && _(0, Ht, 1, 0, "app-admin-dashboard")(1, Ut, 1, 0, "app-dashboard-info"), t & 2) {
        let e = m();
        g(e.isAdmin ? 0 : 1)
    }
}

function Kt(t, d) {
    t & 1 && p(0, "app-task-list", 7), t & 2 && c("assignedOnly", !0)
}

function $t(t, d) {
    t & 1 && p(0, "app-lead-list", 7), t & 2 && c("assignedOnly", !0)
}

function Yt(t, d) {
    t & 1 && p(0, "app-pickup-drop-list", 7), t & 2 && c("assignedOnly", !0)
}

function qt(t, d) {
    if (t & 1) {
        let e = k();
        i(0, "div", 3)(1, "div", 2)(2, "app-responsive-tabs", 5), M("tabChange", function(a) {
            h(e);
            let C = m();
            return f(C.selectTab(a))
        }), i(3, "div", 6), p(4, "app-job-list", 7), r(), i(5, "div", 8), _(6, Kt, 1, 1, "app-task-list", 7), r(), i(7, "div", 9), _(8, $t, 1, 1, "app-lead-list", 7), r(), i(9, "div", 10), _(10, Yt, 1, 1, "app-pickup-drop-list", 7), r()()()()
    }
    if (t & 2) {
        let e = m();
        o(2), c("tabs", e.tabs)("selectedIndex", e.selectedTabIndex)("showNavButtons", !0)("scrollByContent", !0)("mobileMenuTitle", e.formatMessage("dashboard")), o(2), c("assignedOnly", !0), o(2), g(Y(9, ne, e.TENANT_PLANS.STANDARD, e.TENANT_PLANS.ENTERPRISE).includes(e.plan) ? 6 : -1), o(2), g(Y(12, ne, e.TENANT_PLANS.STANDARD, e.TENANT_PLANS.ENTERPRISE).includes(e.plan) ? 8 : -1), o(2), g(pe(15, Vt, e.TENANT_PLANS.LITE).includes(e.plan) ? -1 : 10)
    }
}
var ot = (() => {
    class t {
        constructor() {
            this.formatMessage = l, this.userSessionService = u(G), this.tenantService = u(L), this.isMobileDevice = u(I).isMobileDevice(), this.plan = this.tenantService.plan(), this.isAdmin = this.userSessionService.isAdmin(), this.isEmployee = this.userSessionService.isEmployee(), this.userPermissionList = this.userSessionService.userPermissionList(), this.tabs = [{
                id: 0,
                text: l("assigned_jobs"),
                icon: A.JOB.light,
                path: "",
                visible: !0
            }, {
                id: 1,
                text: l("assigned_task"),
                icon: A.TASK.light,
                path: "",
                disabled: [P.LITE, P.BASIC].includes(this.plan),
                visible: this.userPermissionList.includes(U.TASK_LIST)
            }, {
                id: 2,
                text: l("assigned_leads"),
                icon: A.LEAD.light,
                path: "",
                disabled: [P.LITE, P.BASIC].includes(this.plan),
                visible: this.userPermissionList.includes(U.LEAD_LIST)
            }, {
                id: 3,
                text: l("assigned_scheduled_pickups"),
                icon: A.PICKUP_DROP.light,
                path: "",
                disabled: [P.LITE].includes(this.plan),
                visible: this.userPermissionList.includes(U.PICKUP_DROP_LIST)
            }], this.selectedTabIndex = 0, this.displayActionableItems = le(!0), this.TENANT_PLANS = P, this.PERMISSION_LIST = U
        }
        selectTab(e) {
            this.selectedTabIndex = e.itemIndex
        }
        manageActionableItems(e) {
            this.displayActionableItems.set(e)
        }
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275cmp = O({
                type: t,
                selectors: [
                    ["app-dashboard"]
                ],
                standalone: !1,
                decls: 6,
                vars: 6,
                consts: [
                    [1, "container-fluid"],
                    [1, "row"],
                    [1, "col-sm-12", "col-md-12", "col-lg-12"],
                    [1, "row", "mt-3"],
                    [3, "showActionableItems"],
                    ["mode", "template", "mobileMenuIcon", "fa-solid fa-house", 3, "tabChange", "tabs", "selectedIndex", "showNavButtons", "scrollByContent", "mobileMenuTitle"],
                    ["content0", ""],
                    [3, "assignedOnly"],
                    ["content1", ""],
                    ["content2", ""],
                    ["content3", ""]
                ],
                template: function(n, a) {
                    n & 1 && (i(0, "div", 0)(1, "div", 1)(2, "div", 2), _(3, Ft, 1, 1), _(4, zt, 2, 1), _(5, qt, 11, 17, "div", 3), r()()()), n & 2 && (o(3), g(a.isEmployee && Y(3, ne, a.TENANT_PLANS.STANDARD, a.TENANT_PLANS.ENTERPRISE).includes(a.plan) && a.userPermissionList.includes(a.PERMISSION_LIST.REPORT_VIEW) ? 3 : -1), o(), g(a.userPermissionList.includes(a.PERMISSION_LIST.REPORT_VIEW) ? 4 : -1), o(), g(a.isMobileDevice ? -1 : 5))
                },
                dependencies: [Fe, Ue, $e, Je, qe, We, et, tt],
                encapsulation: 2
            })
        }
    }
    return t
})();
var Gt = [{
        path: "",
        component: ot,
        pathMatch: "full",
        title: "BytePhase Dashboard "
    }, {
        path: "**",
        redirectTo: "/errors/404"
    }],
    nt = (() => {
        class t {
            static {
                this.\u0275fac = function(n) {
                    return new(n || t)
                }
            }
            static {
                this.\u0275mod = K({
                    type: t
                })
            }
            static {
                this.\u0275inj = z({
                    imports: [F.forChild(Gt), F]
                })
            }
        }
        return t
    })();
var un = (() => {
    class t {
        static {
            this.\u0275fac = function(n) {
                return new(n || t)
            }
        }
        static {
            this.\u0275mod = K({
                type: t
            })
        }
        static {
            this.\u0275inj = z({
                imports: [be, F, nt, Ke, Ye, Xe, Ge]
            })
        }
    }
    return t
})();
export {
    un as DashboardModule
};