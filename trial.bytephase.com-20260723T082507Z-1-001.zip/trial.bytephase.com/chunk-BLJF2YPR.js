import {
    V as h,
    Z as f
} from "./chunk-DCKGQUHB.js";
import {
    Dg as u,
    aa as a,
    da as c,
    sd as s
} from "./chunk-GOPIAW4V.js";
var j = (() => {
    class e {
        constructor(i, t, r) {
            this.authService = i, this.storageService = t, this.router = r
        }
        canActivate(i, t) {
            let r = t.url;
            return this.checkLogin(r, i)
        }
        checkLogin(i, t) {
            return new Promise((r, m) => {
                this.authService.authStatus.subscribe({
                    next: o => {
                        let n = t.routeConfig.path === "login";
                        return o && n ? (this.router.navigate([u]), r(!1)) : !o && !n ? (this.authService.redirectUrl = i, this.router.navigate(["/auth/login"]), r(!1)) : r(!0)
                    },
                    error: o => {
                        console.error(o)
                    }
                }).add(() => {
                    m("Error processing")
                })
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || e)(c(f), c(h), c(s))
            }
        }
        static {
            this.\u0275prov = a({
                token: e,
                factory: e.\u0275fac
            })
        }
    }
    return e
})();
export {
    j as a
};