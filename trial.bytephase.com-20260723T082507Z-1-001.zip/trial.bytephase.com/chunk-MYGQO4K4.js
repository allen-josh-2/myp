import {
    Z as a,
    ba as m
} from "./chunk-DCKGQUHB.js";
import {
    Dg as u,
    K as s,
    aa as n,
    da as r,
    sd as c
} from "./chunk-GOPIAW4V.js";
var b = (() => {
    class e {
        constructor(o, i, t) {
            this.authService = o, this.router = i, this.userSessionService = t
        }
        canActivate(o, i) {
            return new Promise(t => {
                this.authService.authStatus.pipe(s(1)).subscribe({
                    next: f => {
                        if (f) {
                            let p = this.userSessionService.isEmployee(),
                                h = i.url.includes("/guest/lead");
                            return !p && h ? t(!0) : (this.router.navigate([u]), t(!1))
                        }
                        return t(!0)
                    },
                    error: () => t(!0)
                })
            })
        }
        static {
            this.\u0275fac = function(i) {
                return new(i || e)(r(a), r(c), r(m))
            }
        }
        static {
            this.\u0275prov = n({
                token: e,
                factory: e.\u0275fac,
                providedIn: "root"
            })
        }
    }
    return e
})();
export {
    b as a
};