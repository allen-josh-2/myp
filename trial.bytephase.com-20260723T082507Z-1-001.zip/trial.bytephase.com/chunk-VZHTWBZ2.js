import {
    a as A
} from "./chunk-PZDHMQ7I.js";
import "./chunk-RW3SLQZQ.js";
import {
    Bc as V,
    Nb as Se,
    T as he,
    Ta as J,
    V as q,
    Va as H,
    ca as W,
    e as N,
    g as pe,
    h as me,
    ha as ve,
    ia as F,
    lb as Q,
    n as ue,
    pb as Ce,
    ph as Me,
    q as ge,
    sb as ye,
    t as _e,
    u as fe,
    we as Pe,
    y as xe
} from "./chunk-DCKGQUHB.js";
import {
    $a as _,
    $b as le,
    C as ne,
    Ec as de,
    Fa as i,
    Fb as M,
    Hb as G,
    Ib as r,
    Jb as c,
    Kb as x,
    Lb as w,
    Mb as U,
    Na as B,
    Oa as $,
    Rc as Y,
    Sa as re,
    Tc as ce,
    U as ae,
    W as oe,
    Wb as se,
    _a as g,
    ba as R,
    bb as E,
    cb as I,
    db as O,
    ea as v,
    eb as b,
    fb as a,
    gb as o,
    gc as P,
    ha as C,
    hb as p,
    hc as Z,
    ia as y,
    ic as k,
    mc as T,
    pd as D,
    qa as f,
    qb as S,
    sb as h,
    sd as L,
    ub as d,
    vd as K,
    wd as be,
    xk as u
} from "./chunk-GOPIAW4V.js";
import "./chunk-JHTW4QMD.js";
import "./chunk-UIGZEDL5.js";
import "./chunk-WNQ4N7RJ.js";
import "./chunk-HNIQUNPL.js";
import "./chunk-LJZ7ZJF4.js";
import {
    a as te,
    b as ie
} from "./chunk-FBFWB55K.js";
var Le = n => [n];

function Ve(n, l) {
    if (n & 1 && (a(0, "div", 0)(1, "div", 3), p(2, "i", 4), a(3, "h4", 5), r(4), o(), a(5, "p", 6), r(6), o()()()), n & 2) {
        let e = d();
        i(4), c(e.formatMessage("manage_subscription_ios_title")), i(2), c(e.formatMessage("manage_subscription_ios_message"))
    }
}

function Ae(n, l) {
    if (n & 1 && (a(0, "span", 64)(1, "span", 68), r(2), o(), a(3, "span", 69), r(4), o()()), n & 2) {
        let e = d(3);
        i(2), c(e.formatMessage("promo_title")), i(2), x("\u2014 ", e.formatMessage("promo_subtitle"))
    }
}

function qe(n, l) {
    n & 1 && (a(0, "span", 64)(1, "span", 68), r(2, "Start Your Free 14-Day Trial"), o(), a(3, "span", 69), r(4, "\u2014 No credit card required"), o()())
}

function Fe(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 59)(1, "div", 60)(2, "a", 61), p(3, "img", 62), o(), a(4, "div", 63), g(5, Ae, 5, 2, "span", 64), g(6, qe, 5, 0, "span", 64), a(7, "a", 65), h("click", function() {
            C(e);
            let s = d(2);
            return y(s.onTryNow())
        }), p(8, "i", 66), r(9), o()()()(), p(10, "div", 67)
    }
    if (n & 2) {
        let e = d(2);
        i(5), _(e.isIndia() ? 5 : -1), i(), _(e.isIndia() ? -1 : 6), i(3), x(" ", e.isIndia() ? e.formatMessage("promo_cta") : "Start Free Trial", " ")
    }
}

function je(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "button", 101), h("click", function() {
            C(e);
            let s = d(2).$implicit,
                m = d(3);
            return y(m.buyAddOn(s))
        }), r(1), o()
    }
    if (n & 2) {
        let e = d(5);
        i(), x(" ", e.formatMessage("buy_now"), " ")
    }
}

function ze(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 84)(1, "button", 98), h("click", function() {
            C(e);
            let s = d().$implicit,
                m = d(3);
            return y(m.toggleAddOn(s.id))
        }), p(2, "i", 99), r(3), o(), g(4, je, 2, 1, "button", 100), o()
    }
    if (n & 2) {
        let e = d().$implicit,
            t = d(3);
        i(), M("btn-outline-primary", !t.isAddOnSelected(e.id))("btn-success", t.isAddOnSelected(e.id)), i(), M("fa-plus", !t.isAddOnSelected(e.id))("fa-check", t.isAddOnSelected(e.id)), i(), x(" ", t.isAddOnSelected(e.id) ? t.formatMessage("added") : t.formatMessage("pricing_add_to_plan"), " "), i(), _(t.isLoggedIn ? 4 : -1)
    }
}

function Re(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "button", 101), h("click", function() {
            C(e);
            let s = d(2).$implicit,
                m = d(3);
            return y(m.buyAddOn(s))
        }), r(1), o()
    }
    if (n & 2) {
        let e = d(5);
        i(), x(" ", e.formatMessage("buy_now"), " ")
    }
}

function $e(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 96)(1, "button", 102), h("click", function() {
            C(e);
            let s = d().$implicit,
                m = d(3);
            return y(m.toggleAddOn(s.id))
        }), p(2, "i", 99), r(3), o(), g(4, Re, 2, 1, "button", 100), o()
    }
    if (n & 2) {
        let e = d().$implicit,
            t = d(3);
        i(), M("btn-outline-primary", !t.isAddOnSelected(e.id))("btn-success", t.isAddOnSelected(e.id)), i(), M("fa-plus", !t.isAddOnSelected(e.id))("fa-check", t.isAddOnSelected(e.id)), i(), x(" ", t.isAddOnSelected(e.id) ? t.formatMessage("added") : t.formatMessage("pricing_add_to_plan"), " "), i(), _(t.isLoggedIn ? 4 : -1)
    }
}

function Ge(n, l) {
    if (n & 1 && (a(0, "div", 97)(1, "a", 103), r(2), o()()), n & 2) {
        let e = d(4);
        i(2), x(" ", e.formatMessage("contact_sales"), " ")
    }
}

function Ue(n, l) {
    if (n & 1 && (a(0, "div", 70)(1, "div", 71)(2, "div", 72)(3, "div", 73), p(4, "i", 74), o(), a(5, "div")(6, "span", 75), r(7), o(), a(8, "h6", 76), r(9), o()()(), a(10, "div", 77)(11, "div", 78), r(12), o(), a(13, "div", 79), r(14), P(15, "number"), o()()(), a(16, "p", 80), r(17), o(), a(18, "div", 81)(19, "span", 82), p(20, "i", 83), r(21), o(), a(22, "span", 82), p(23, "i", 83), r(24), o(), a(25, "span", 82), p(26, "i", 83), r(27), o()(), g(28, ze, 5, 10, "div", 84), a(29, "div", 85)(30, "div", 86)(31, "div", 87)(32, "div", 88), p(33, "i", 74), o(), a(34, "div")(35, "span", 89), r(36), o(), a(37, "h5", 90), r(38), o(), a(39, "p", 91), r(40), o(), a(41, "div", 92)(42, "span"), p(43, "i", 83), r(44), o(), a(45, "span"), p(46, "i", 83), r(47), o(), a(48, "span"), p(49, "i", 83), r(50), o()(), a(51, "a", 93), r(52), o()()()(), a(53, "div", 94)(54, "div", 78), r(55), o(), a(56, "div", 95), r(57), P(58, "number"), o(), g(59, $e, 5, 10, "div", 96), g(60, Ge, 3, 1, "div", 97), o()()()), n & 2) {
        let e = l.$implicit,
            t = d(3);
        i(7), c(t.formatMessage("pricing_works_with_any_plan")), i(2), c(t.formatMessage("pricing_white_label_title")), i(3), c(t.formatMessage("pricing_annual")), i(2), w("", t.currencyCode(), " ", k(15, 22, e.price, "1.0-0")), i(3), c(t.formatMessage("pricing_white_label_desc")), i(4), c(t.formatMessage("pricing_white_label_branding")), i(3), c(t.formatMessage("pricing_white_label_trust")), i(3), c(t.formatMessage("pricing_white_label_seo")), i(), _(t.currencyCode() === "INR" ? 28 : -1), i(8), c(t.formatMessage("pricing_works_with_any_plan")), i(2), c(t.formatMessage("pricing_white_label_title")), i(2), c(t.formatMessage("pricing_white_label_desc")), i(4), c(t.formatMessage("pricing_white_label_branding")), i(3), c(t.formatMessage("pricing_white_label_trust")), i(3), c(t.formatMessage("pricing_white_label_seo")), i(2), x(" ", t.formatMessage("pricing_see_how_white_label_works"), " "), i(3), c(t.formatMessage("pricing_annual")), i(2), w("", t.currencyCode(), " ", k(58, 25, e.price, "1.0-0")), i(2), _(t.currencyCode() === "INR" ? 59 : -1), i(), _(t.currencyCode() !== "INR" ? 60 : -1)
    }
}

function Ye(n, l) {
    if (n & 1 && (a(0, "div", 12), I(1, Ue, 61, 28, "div", 70, E), o()), n & 2) {
        let e = d(2);
        i(), O(e.addOns())
    }
}

function We(n, l) {
    if (n & 1 && (a(0, "span", 16), r(1), o()), n & 2) {
        let e = d(2);
        i(), c(e.formatMessage("save_20_percent"))
    }
}

function Je(n, l) {
    if (n & 1 && (a(0, "span", 107), p(1, "i", 19), r(2), o()), n & 2) {
        let e = d(3);
        i(2), x(" ", e.formatMessage("most_popular"), " ")
    }
}

function He(n, l) {
    if (n & 1 && (a(0, "div", 113), r(1), P(2, "number"), o()), n & 2) {
        let e = d().$implicit,
            t = d(2);
        i(), U(" \u2248 ", t.currencyCode(), " ", k(2, 3, t.getMonthlyPrice(e), "1.0-0"), " / ", t.formatMessage("per_month"), " ")
    }
}

function Qe(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "button", 121), h("click", function() {
            C(e);
            let s = d().$implicit,
                m = d(2);
            return y(m.onBuyNow(s))
        }), r(1), p(2, "i", 122), o()
    }
    if (n & 2) {
        let e = d().$implicit,
            t = d(2);
        M("primary", e.name === "Standard"), i(), x(" ", t.formatMessage("buy_now"), " ")
    }
}

function Ze(n, l) {
    if (n & 1 && (a(0, "a", 117), r(1), p(2, "i", 122), o()), n & 2) {
        let e = d(3);
        i(), x(" ", e.formatMessage("start_free_trial"), " ")
    }
}

function Ke(n, l) {
    if (n & 1 && (a(0, "div", 119)(1, "span", 123), p(2, "i", 124), o(), r(3), a(4, "b"), r(5), o(), r(6), o()), n & 2) {
        let e = d().$implicit,
            t = d(2);
        i(3), x(" ", t.formatMessage("everything_in"), " "), i(2), c(t.getPreviousPlan(e.name)), i(), x(", ", t.formatMessage("plus"), " ")
    }
}

function Xe(n, l) {
    if (n & 1 && r(0), n & 2) {
        let e = d().$implicit,
            t = d().$implicit;
        x(" ", e.plans[t.name], " ")
    }
}

function et(n, l) {
    if (n & 1 && (a(0, "li")(1, "span", 125), p(2, "i", 124), o(), g(3, Xe, 1, 1), r(4), o()), n & 2) {
        let e = l.$implicit,
            t = d().$implicit;
        i(3), _(e.plans[t.name] !== !0 ? 3 : -1), i(), x("", e.label, " ")
    }
}

function tt(n, l) {
    if (n & 1 && (a(0, "div", 22)(1, "div", 104)(2, "div", 105)(3, "span", 106), r(4), o(), g(5, Je, 3, 1, "span", 107), o(), a(6, "div", 108), r(7), o(), a(8, "div", 109)(9, "span", 110), r(10), o(), a(11, "span", 111), r(12), P(13, "number"), o(), a(14, "span", 112), r(15), o()(), g(16, He, 3, 6, "div", 113), a(17, "div", 114), p(18, "i", 115), a(19, "span")(20, "b"), r(21), o(), r(22), o()(), g(23, Qe, 3, 3, "button", 116), g(24, Ze, 3, 1, "a", 117), p(25, "hr", 118), g(26, Ke, 7, 3, "div", 119), a(27, "ul", 120), I(28, et, 5, 2, "li", null, E), o()()()), n & 2) {
        let e = l.$implicit,
            t = d(2);
        i(), M("featured", e.name === "Standard"), i(3), c(e.name), i(), _(e.name === "Standard" ? 5 : -1), i(2), c(t.planDescriptions[e.name]), i(3), c(t.currencyCode()), i(2), c(k(13, 14, t.getPrice(e), "1.0-0")), i(3), x("/ ", t.isAnnual() ? t.formatMessage("per_year") : t.isIndia() ? t.formatMessage("per_quarter") : t.formatMessage("per_month")), i(), _(t.isAnnual() || t.isIndia() ? 16 : -1), i(5), c(t.employeeLimits[e.name]), i(), x(" ", t.formatMessage("employees")), i(), _(t.currencyCode() === "INR" ? 23 : -1), i(), _(t.currencyCode() !== "INR" ? 24 : -1), i(2), _(e.name !== "Lite" ? 26 : -1), i(2), O(t.getNewFeatures(e.name))
    }
}

function it(n, l) {
    if (n & 1 && (a(0, "th", 126), r(1), o()), n & 2) {
        let e = l.$implicit;
        M("featured", e.name === "Standard"), i(), x(" ", e.name, " ")
    }
}

function nt(n, l) {
    if (n & 1 && (a(0, "td", 34), r(1), o()), n & 2) {
        let e = l.$implicit,
            t = d(2);
        i(), c(t.employeeLimits[e.name])
    }
}

function at(n, l) {
    n & 1 && p(0, "i", 127)
}

function ot(n, l) {
    n & 1 && p(0, "i", 128)
}

function rt(n, l) {
    if (n & 1 && r(0), n & 2) {
        let e = d().$implicit,
            t = d().$implicit;
        x(" ", t.plans[e.name], " ")
    }
}

function st(n, l) {
    if (n & 1 && (a(0, "td", 126), g(1, at, 1, 0, "i", 127), g(2, ot, 1, 0, "i", 128), g(3, rt, 1, 1), o()), n & 2) {
        let e = l.$implicit,
            t = d().$implicit;
        i(), _(t.plans[e.name] === !0 ? 1 : -1), i(), _(t.plans[e.name] === !1 ? 2 : -1), i(), _(t.plans[e.name] !== !0 && t.plans[e.name] !== !1 ? 3 : -1)
    }
}

function lt(n, l) {
    if (n & 1 && (a(0, "tr")(1, "td"), p(2, "i"), r(3), o(), I(4, st, 4, 3, "td", 126, E), o()), n & 2) {
        let e = l.$implicit,
            t = d(2);
        i(2), G(se("fa-solid ", e.icon, " text-muted me-2")), i(), c(e.label), i(), O(t.plans())
    }
}

function dt(n, l) {
    if (n & 1 && (a(0, "td", 129), r(1), P(2, "number"), o()), n & 2) {
        let e = l.$implicit,
            t = d(2);
        M("featured", e.name === "Standard"), i(), w(" ", t.currencyCode(), " ", k(2, 4, t.getPrice(e), "1.0-0"), " ")
    }
}

function ct(n, l) {
    n & 1 && (a(0, "span", 150), r(1, "Popular"), o())
}

function pt(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 135)(1, "div", 145)(2, "div")(3, "div", 146), p(4, "i", 147), o(), a(5, "div", 95), r(6), P(7, "number"), o(), a(8, "div", 148), r(9, "SMS Credits"), o(), a(10, "div", 149), r(11), o(), g(12, ct, 2, 0, "span", 150), a(13, "div", 151)(14, "span", 152), r(15), o(), a(16, "span", 153), r(17), P(18, "number"), o()(), a(19, "div", 152), r(20, "Unlimited Validity"), o()(), a(21, "button", 154), h("click", function() {
            let s = C(e).$implicit,
                m = d(3);
            return y(m.buySMSPack(s))
        }), r(22, " Buy Now "), p(23, "i", 155), o()()()
    }
    if (n & 2) {
        let e = l.$implicit,
            t = l.$index,
            s = d(3);
        i(), M("border-primary", t === 2), i(5), c(Z(7, 11, e.metadata == null ? null : e.metadata.credits)), i(5), c(e.name.replace(" SMS Pack", "")), i(), _(t === 2 ? 12 : -1), i(3), c(s.currencyCode()), i(2), x(" ", k(18, 13, e.price, "1.0-0")), i(4), M("btn-primary", t === 2)("btn-outline-primary", t !== 2)
    }
}

function mt(n, l) {
    n & 1 && (a(0, "span", 161), r(1, "Popular"), o())
}

function ut(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 156)(1, "div", 157)(2, "div", 158), p(3, "i", 147), o(), a(4, "div", 159)(5, "div", 160), r(6), g(7, mt, 2, 0, "span", 161), o(), a(8, "div", 162), r(9), P(10, "number"), o()()(), a(11, "div", 163)(12, "div", 164), r(13), P(14, "number"), o(), a(15, "button", 165), h("click", function() {
            let s = C(e).$implicit,
                m = d(3);
            return y(m.buySMSPack(s))
        }), r(16, "Buy Now"), o()()()
    }
    if (n & 2) {
        let e = l.$implicit,
            t = l.$index,
            s = d(3);
        M("border-primary", t === 2), i(2), b("ngClass", le(17, Le, "bp-sms-color-" + t)), i(4), x("", e.name.replace(" SMS Pack", ""), " "), i(), _(t === 2 ? 7 : -1), i(2), x("", Z(10, 12, e.metadata == null ? null : e.metadata.credits), " Credits \xB7 No Expiry"), i(4), w("", s.currencyCode(), " ", k(14, 14, e.price, "1.0-0")), i(2), M("btn-primary", t === 2)("btn-outline-dark", t !== 2)
    }
}

function gt(n, l) {
    if (n & 1 && (a(0, "div", 37)(1, "div", 130)(2, "span", 131), p(3, "i", 132), r(4, "SMS Credits "), o(), a(5, "h3", 133), r(6, "SMS Packs"), o(), a(7, "p", 6), r(8, "Top up SMS credits for your business notifications. No expiry."), o()(), a(9, "div", 134), I(10, pt, 24, 16, "div", 135, E), o(), a(12, "div", 136), I(13, ut, 17, 19, "div", 137, E), o(), a(15, "div", 138)(16, "div", 139), p(17, "i", 140), a(18, "div", 141), r(19, "No Expiry"), o(), a(20, "div", 142), r(21, "Credits never expire"), o()(), a(22, "div", 139), p(23, "i", 143), a(24, "div", 141), r(25, "Instant Delivery"), o(), a(26, "div", 142), r(27, "Credits added instantly"), o()(), a(28, "div", 139), p(29, "i", 144), a(30, "div", 141), r(31, "Secure & Reliable"), o(), a(32, "div", 142), r(33, "100% secure transactions"), o()()()()), n & 2) {
        let e = d(2);
        i(10), O(e.smsPacks()), i(3), O(e.smsPacks())
    }
}

function _t(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 166), h("click", function() {
            let s = C(e).$implicit;
            return y(s.open = !s.open)
        }), a(1, "div", 167)(2, "span"), r(3), o(), p(4, "i", 168), o(), a(5, "div", 169), r(6), o()()
    }
    if (n & 2) {
        let e = l.$implicit;
        M("open", e.open), i(3), c(e.q), i(3), c(e.a)
    }
}

function ft(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 1), g(1, Fe, 11, 3), a(2, "div", 7)(3, "div", 8), p(4, "span", 9), r(5), o(), a(6, "h1", 10), r(7), a(8, "em"), r(9), o()(), a(10, "p", 11), r(11), o(), g(12, Ye, 3, 0, "div", 12), a(13, "div", 13)(14, "div", 14)(15, "button", 15), h("click", function() {
            C(e);
            let s = d();
            return y(s.isAnnual.set(!1))
        }), r(16), o(), a(17, "button", 15), h("click", function() {
            C(e);
            let s = d();
            return y(s.isAnnual.set(!0))
        }), r(18), g(19, We, 2, 1, "span", 16), o()()(), a(20, "div", 17)(21, "span", 18), p(22, "i", 19)(23, "i", 19)(24, "i", 19)(25, "i", 19)(26, "i", 19), o(), r(27), o()(), a(28, "div", 20)(29, "div", 21), I(30, tt, 30, 17, "div", 22, E), o(), a(32, "div", 23)(33, "div"), p(34, "i", 24), r(35), o(), a(36, "div"), p(37, "i", 25), r(38), o(), a(39, "div"), p(40, "i", 26), r(41), o(), a(42, "div"), p(43, "i", 27), r(44), o()()(), a(45, "div", 28)(46, "h3", 29), r(47), o(), a(48, "div", 30)(49, "table")(50, "thead")(51, "tr")(52, "th", 31), r(53), o(), I(54, it, 2, 3, "th", 32, E), o()(), a(56, "tbody")(57, "tr")(58, "td"), p(59, "i", 33), r(60), o(), I(61, nt, 2, 1, "td", 34, E), o(), I(63, lt, 6, 4, "tr", null, E), a(65, "tr")(66, "td", 35), r(67), o(), I(68, dt, 3, 7, "td", 36, E), o()()()()(), g(70, gt, 34, 0, "div", 37), a(71, "div", 38)(72, "div", 39)(73, "h3", 29), r(74), o(), a(75, "div", 40)(76, "div", 41), I(77, _t, 7, 4, "div", 42, E), o()()()(), a(79, "div", 43)(80, "div", 40)(81, "div", 44)(82, "div", 45)(83, "h4", 46), r(84), o(), a(85, "p", 47), r(86), o(), a(87, "a", 48), p(88, "i", 49), r(89), o()()()()(), a(90, "div", 50)(91, "div", 39)(92, "div", 51)(93, "div", 52), p(94, "img", 53), o(), a(95, "div", 54)(96, "span"), r(97), o()(), a(98, "div", 55)(99, "a", 56), r(100), o(), a(101, "a", 57), r(102), o(), a(103, "a", 58), r(104), o()()()()()()
    }
    if (n & 2) {
        let e = d();
        i(), _(e.isLoggedIn ? -1 : 1), i(4), x(" ", e.isIndia() ? "Pricing \xB7 1 month trial at \u20B9299 \xB7 Full access" : e.formatMessage("eyebrow_text"), " "), i(2), x("", e.formatMessage("pricing_title_prefix"), " "), i(2), c(e.formatMessage("pricing_title_highlight")), i(2), c(e.formatMessage("pricing_subtitle")), i(), _(e.addOns().length ? 12 : -1), i(3), M("active", !e.isAnnual()), i(), x(" ", e.isIndia() ? e.formatMessage("quarterly") : e.formatMessage("monthly"), " "), i(), M("active", e.isAnnual()), i(), x(" ", e.formatMessage("annual"), " "), i(), _(e.isAnnual() ? 19 : -1), i(8), x(" ", e.formatMessage("rating_text"), " "), i(3), O(e.plans()), i(5), x(" ", e.formatMessage("guarantee_trial")), i(3), x(" ", e.formatMessage("guarantee_secure")), i(3), x(" ", e.formatMessage("guarantee_cancel")), i(3), x(" ", e.formatMessage("pricing_money_back_guarantee")), i(3), c(e.formatMessage("compare_all_features")), i(6), c(e.formatMessage("feature")), i(), O(e.plans()), i(6), c(e.formatMessage("employees")), i(), O(e.plans()), i(2), O(e.filteredFeatures()), i(4), c(e.formatMessage("price")), i(), O(e.plans()), i(2), _(e.smsPacks().length ? 70 : -1), i(4), c(e.formatMessage("faq_title")), i(3), O(e.faqs), i(7), c(e.formatMessage("still_have_questions")), i(2), c(e.formatMessage("team_replies_within")), i(3), x(" ", e.formatMessage("chat_with_us"), " "), i(8), x("\xA9 2026 BytePhase Software \xB7 ", e.formatMessage("prices_exclude_tax")), i(3), c(e.formatMessage("terms")), i(2), c(e.formatMessage("privacy")), i(2), c(e.formatMessage("security"))
    }
}

function xt(n, l) {
    n & 1 && (a(0, "div", 2), p(1, "dx-load-indicator", 170), o()), n & 2 && (i(), b("visible", !0))
}
var ke = (() => {
    class n {
        constructor() {
            this.formatMessage = u, this.subscriptionService = v(A), this.storageService = v(q), this.tenantService = v(Q), this.route = v(D), this.router = v(L), this.isIOSNative = v(he).isIOS, this.plans = f([]), this.addOns = f([]), this.smsPacks = f([]), this.trialPlan = f(null), this.selectedAddOnIds = f([]), this.country = f(null), this.isAnnual = f(!0), this.isLoading = f(!0), this.isLoggedIn = !!this.storageService.getToken(), this.currencyCode = T(() => this.country() ? .currency_code || "USD"), this.isIndia = T(() => this.currencyCode() === "INR"), this.filteredFeatures = T(() => this.features.filter(e => !e.indiaOnly || this.isIndia())), this.employeeLimits = {
                Lite: "2",
                Basic: "6",
                Standard: "12",
                Enterprise: u("unlimited")
            }, this.planDescriptions = {
                Lite: u("plan_lite_desc"),
                Basic: u("plan_basic_desc"),
                Standard: u("plan_standard_desc"),
                Enterprise: u("plan_enterprise_desc")
            }, this.features = [{
                key: "jobs",
                label: u("pricing_jobs_sales_records"),
                icon: "fa-briefcase",
                plans: {
                    Lite: "1000",
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "device_images",
                label: u("pricing_upload_device_images"),
                icon: "fa-camera",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "client_login",
                label: u("pricing_client_login"),
                icon: "fa-user-check",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "reports",
                label: u("pricing_advance_reports"),
                icon: "fa-chart-bar",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "dashboards",
                label: u("pricing_individual_dashboards"),
                icon: "fa-gauge-high",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "attachments",
                label: u("pricing_attachments"),
                icon: "fa-paperclip",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "inventory",
                label: u("pricing_inventory_module"),
                icon: "fa-box",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "whatsapp",
                label: u("pricing_whatsapp_integration"),
                icon: "fa-comment-dots",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "quotations",
                label: u("pricing_quotations_invoices"),
                icon: "fa-file-lines",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "support_48h",
                label: u("pricing_48h_support"),
                icon: "fa-headset",
                plans: {
                    Lite: !0,
                    Basic: !1,
                    Standard: !1,
                    Enterprise: !1
                }
            }, {
                key: "activity_log",
                label: u("pricing_activity_log"),
                icon: "fa-clock-rotate-left",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "mobile_app",
                label: u("pricing_mobile_app"),
                icon: "fa-mobile-screen",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "rbac",
                label: u("pricing_role_based_access"),
                icon: "fa-shield-halved",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "chat",
                label: u("pricing_private_public_chat"),
                icon: "fa-comments",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "purchase",
                label: u("pricing_purchase_management"),
                icon: "fa-cart-shopping",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "email_setup",
                label: u("pricing_own_email_setup"),
                icon: "fa-envelope-open-text",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "pickup",
                label: u("pricing_pickup_drop"),
                icon: "fa-truck",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "upi",
                label: u("pricing_upi_payments"),
                icon: "fa-money-bill-wave",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                },
                indiaOnly: !0
            }, {
                key: "bulk_payments",
                label: u("pricing_bulk_payments"),
                icon: "fa-money-check-dollar",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "client_ledger",
                label: u("pricing_client_ledger"),
                icon: "fa-book",
                plans: {
                    Lite: !0,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "live_support",
                label: u("pricing_live_support"),
                icon: "fa-headset",
                plans: {
                    Lite: !1,
                    Basic: !0,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "amc",
                label: u("pricing_amc_contracts"),
                icon: "fa-file-contract",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "outsource",
                label: u("pricing_outsource_management"),
                icon: "fa-arrow-right-arrow-left",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "leads",
                label: u("pricing_lead_management"),
                icon: "fa-bullseye",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "tasks",
                label: u("pricing_task_management"),
                icon: "fa-list-check",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "expenses",
                label: u("pricing_expense_management"),
                icon: "fa-wallet",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "permissions",
                label: u("pricing_configurable_permissions"),
                icon: "fa-user-lock",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "assigned_jobs",
                label: u("pricing_assigned_only_jobs"),
                icon: "fa-user-tag",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "signature",
                label: u("pricing_digital_signature"),
                icon: "fa-signature",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "otp_delivery",
                label: u("pricing_otp_verification"),
                icon: "fa-key",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "payment_gateway",
                label: u("pricing_payment_gateway"),
                icon: "fa-credit-card",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                },
                indiaOnly: !0
            }, {
                key: "self_checkin",
                label: u("pricing_self_check_in"),
                icon: "fa-qrcode",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "employee_commission",
                label: u("pricing_employee_commission"),
                icon: "fa-percent",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "data_recovery",
                label: u("pricing_data_recovery"),
                icon: "fa-rotate-left",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "own_branding",
                label: u("pricing_own_branding"),
                icon: "fa-palette",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !0,
                    Enterprise: !0
                }
            }, {
                key: "branches",
                label: u("pricing_branches"),
                icon: "fa-building",
                plans: {
                    Lite: !1,
                    Basic: !1,
                    Standard: !1,
                    Enterprise: "3"
                }
            }], this.planOrder = ["Lite", "Basic", "Standard", "Enterprise"], this.faqs = [{
                q: u("faq_trial_q"),
                a: u("faq_trial_a"),
                open: !1
            }, {
                q: u("faq_upgrade_q"),
                a: u("faq_upgrade_a"),
                open: !1
            }, {
                q: u("faq_payment_q"),
                a: u("faq_payment_a"),
                open: !1
            }, {
                q: u("faq_cancel_q"),
                a: u("faq_cancel_a"),
                open: !1
            }]
        }
        ngOnInit() {
            this.detectCountryAndLoadPlans()
        }
        detectCountryAndLoadPlans() {
            let e = Number(this.route.snapshot.queryParams.country_id);
            if (e) {
                this.loadPlans(e);
                return
            }
            let t = this.tenantService.config() ? .country_id;
            if (t) {
                this.loadPlans(t);
                return
            }
            this.subscriptionService.detectCountry().subscribe({
                next: s => this.loadPlans(s.country_id),
                error: () => this.loadPlans()
            })
        }
        loadPlans(e) {
            this.isLoading.set(!0), this.subscriptionService.getPlans(e).subscribe({
                next: t => {
                    this.country.set(t.country);
                    let s = t.plans || [];
                    this.plans.set(this.groupPlans(s)), this.addOns.set(t.add_ons || []), this.smsPacks.set(t.sms_packs || []), this.trialPlan.set(s.find(m => m.name === "Trial") || null), this.isLoading.set(!1), this.scrollToFragment()
                },
                error: () => this.isLoading.set(!1)
            })
        }
        groupPlans(e) {
            let t = {},
                s = ["Lite", "Basic", "Standard", "Enterprise"];
            return e.forEach(m => {
                t[m.name] || (t[m.name] = {
                    name: m.name,
                    limits: m.plan_limits || []
                }), m.duration_type === "annual" ? t[m.name].annual = m : m.duration_type === "monthly" ? t[m.name].monthly = m : t[m.name].quarterly = m
            }), s.filter(m => t[m]).map(m => t[m])
        }
        getActivePlan(e) {
            return this.isAnnual() ? e.annual : this.isIndia() ? e.quarterly : e.monthly
        }
        getPrice(e) {
            return this.getActivePlan(e) ? .price || 0
        }
        getMonthlyPrice(e) {
            let t = this.getActivePlan(e);
            return t ? Math.round(t.price / t.duration_months) : 0
        }
        isFeatureAvailable(e, t) {
            return !!e.plans[t]
        }
        getPreviousPlan(e) {
            let t = this.planOrder.indexOf(e);
            return t > 0 ? this.planOrder[t - 1] : ""
        }
        getNewFeatures(e) {
            let t = this.filteredFeatures(),
                s = this.getPreviousPlan(e);
            return s ? t.filter(m => m.plans[e] && !m.plans[s]) : t.filter(m => m.plans[e])
        }
        toggleAddOn(e) {
            let t = this.selectedAddOnIds();
            t.includes(e) ? this.selectedAddOnIds.set(t.filter(s => s !== e)) : this.selectedAddOnIds.set([...t, e])
        }
        isAddOnSelected(e) {
            return this.selectedAddOnIds().includes(e)
        }
        onBuyNow(e) {
            let t = this.getActivePlan(e);
            if (!t) return;
            let s = {
                plan_id: t.id,
                order_type: "new"
            };
            this.selectedAddOnIds().length && (s.add_on_plan_ids = this.selectedAddOnIds().join(",")), this.storageService.loggedIn() ? this.router.navigate(["/pricing/checkout", "new"], {
                queryParams: s
            }) : this.router.navigate(["/pricing/register"], {
                queryParams: ie(te({}, s), {
                    country_id: this.country() ? .id,
                    currency_code: this.currencyCode()
                })
            })
        }
        onTryNow() {
            let e = this.trialPlan();
            if (e && this.currencyCode() === "INR") {
                let t = {
                    plan_id: e.id,
                    country_id: this.country() ? .id,
                    currency_code: this.currencyCode()
                };
                this.selectedAddOnIds().length && (t.add_on_plan_ids = this.selectedAddOnIds().join(",")), this.router.navigate(["/pricing/register"], {
                    queryParams: t
                })
            } else window.location.href = "/auth/signUp"
        }
        buyAddOn(e) {
            this.storageService.loggedIn() ? this.router.navigate(["/pricing/checkout", "new"], {
                queryParams: {
                    plan_id: e.id,
                    order_type: "add_on",
                    is_add_on_only: !0
                }
            }) : this.router.navigate(["/pricing/register"], {
                queryParams: {
                    plan_id: e.id,
                    country_id: this.country() ? .id,
                    currency_code: this.currencyCode(),
                    is_add_on_only: !0
                }
            })
        }
        scrollToFragment() {
            let e = this.route.snapshot.fragment;
            e && setTimeout(() => {
                document.getElementById(e) ? .scrollIntoView({
                    behavior: "smooth"
                })
            }, 100)
        }
        buySMSPack(e) {
            this.storageService.loggedIn() ? this.router.navigate(["/pricing/checkout", "new"], {
                queryParams: {
                    plan_id: e.id,
                    order_type: "add_on",
                    is_add_on_only: !0
                }
            }) : this.router.navigate(["/pricing/register"], {
                queryParams: {
                    plan_id: e.id,
                    country_id: this.country() ? .id,
                    currency_code: this.currencyCode(),
                    is_add_on_only: !0
                }
            })
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = B({
                type: n,
                selectors: [
                    ["app-pricing-page"]
                ],
                standalone: !1,
                decls: 3,
                vars: 1,
                consts: [
                    [1, "d-flex", "justify-content-center", "align-items-center", "px-3", 2, "min-height", "70vh"],
                    [1, "pricing-page"],
                    [1, "d-flex", "justify-content-center", "align-items-center", 2, "min-height", "70vh"],
                    [1, "text-center", 2, "max-width", "480px"],
                    [1, "fa-light", "fa-circle-info", "text-primary", "mb-3", 2, "font-size", "56px"],
                    [1, "fw-bold", "mb-3"],
                    [1, "text-muted"],
                    [1, "text-center", "py-5"],
                    [1, "bp-eyebrow", "mx-auto", "mb-3"],
                    [1, "bp-dot"],
                    [1, "bp-h1", "mb-0"],
                    [1, "bp-sub"],
                    [1, "container", "mt-5", 2, "max-width", "900px"],
                    [1, "mt-4", "d-flex", "justify-content-center"],
                    [1, "bp-toggle"],
                    [1, "bp-toggle-btn", 3, "click"],
                    [1, "bp-save-badge"],
                    [1, "bp-proof", "mt-4"],
                    [1, "bp-stars"],
                    [1, "fa-solid", "fa-star"],
                    [1, "container", "pb-5"],
                    [1, "row", "justify-content-center", "g-4"],
                    [1, "col-xl-3", "col-lg-5", "col-md-6", "col-sm-12"],
                    [1, "bp-guarantees", "mt-5", "pt-3"],
                    [1, "fa-solid", "fa-shield-check", "me-1"],
                    [1, "fa-solid", "fa-lock", "me-1"],
                    [1, "fa-solid", "fa-arrow-rotate-left", "me-1"],
                    [1, "fa-solid", "fa-hand-holding-dollar", "me-1"],
                    [1, "container", "pb-5", "d-none", "d-lg-block"],
                    [1, "fw-bold", "text-center", "mb-4"],
                    [1, "bp-compare"],
                    [2, "width", "30%"],
                    [1, "center", 3, "featured"],
                    [1, "fa-solid", "fa-users", "text-muted", "me-2"],
                    [1, "center", "fw-semibold"],
                    [1, "fw-bold"],
                    [1, "center", "fw-bold", 3, "featured"],
                    ["id", "sms-packs", 1, "container", "py-5", 2, "max-width", "960px"],
                    [1, "py-5", 2, "background", "var(--bp-surface)"],
                    [1, "container"],
                    [1, "row", "justify-content-center"],
                    [1, "col-lg-7"],
                    [1, "bp-faq-item", 3, "open"],
                    [1, "container", "py-5"],
                    [1, "col-lg-8"],
                    [1, "bp-contact-card"],
                    [1, "fw-bold", "mb-2"],
                    [1, "mb-4"],
                    ["href", "https://wa.me/919970022111", "target", "_blank", 1, "bp-chat-btn"],
                    [1, "fa-solid", "fa-comment"],
                    [1, "bp-footer"],
                    [1, "row", "align-items-center", "gy-3"],
                    [1, "col-12", "col-md-auto", "d-flex", "align-items-center", "gap-2", "justify-content-center", "justify-content-md-start"],
                    ["src", "assets/images/bytephase.png", "alt", "BytePhase", 2, "height", "24px"],
                    [1, "col-12", "col-md", "text-center", "text-md-start"],
                    [1, "col-12", "col-md-auto", "d-flex", "gap-4", "justify-content-center", "justify-content-md-end"],
                    ["href", "https://bytephase.com/terms", "target", "_blank"],
                    ["href", "https://bytephase.com/privacy", "target", "_blank"],
                    ["href", "https://bytephase.com/security", "target", "_blank"],
                    [1, "bp-promo-bar"],
                    [1, "container", "position-relative"],
                    ["href", "https://bytephase.com", "target", "_blank", 1, "position-absolute", "start-0", "top-50", "translate-middle-y", "d-none", "d-lg-block", "ps-3"],
                    ["src", "assets/images/bytephase.png", "alt", "BytePhase", 2, "height", "26px"],
                    [1, "d-flex", "align-items-center", "justify-content-center", "gap-3", "flex-wrap"],
                    [1, "bp-promo-text"],
                    [1, "bp-promo-cta", 2, "cursor", "pointer", 3, "click"],
                    [1, "fa-solid", "fa-sparkles"],
                    [1, "bp-promo-spacer"],
                    [1, "bp-promo-highlight"],
                    [1, "d-none", "d-md-inline"],
                    [1, "bp-addon-card"],
                    [1, "d-flex", "align-items-start", "justify-content-between", "d-md-none", "mb-2"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "bp-addon-icon", "flex-shrink-0", 2, "width", "36px", "height", "36px", "font-size", "16px"],
                    [1, "fa-solid", "fa-globe"],
                    [1, "badge", "bg-primary-subtle", "text-primary", "small"],
                    [1, "fw-bold", "mb-0", "mt-1"],
                    [1, "text-end", "flex-shrink-0"],
                    [1, "text-muted", "small", "text-uppercase", "fw-semibold"],
                    [1, "fw-bold", "fs-5"],
                    [1, "text-muted", "small", "mb-2", "d-md-none"],
                    [1, "d-flex", "gap-2", "flex-wrap", "d-md-none", "mb-2"],
                    [1, "small"],
                    [1, "fa-solid", "fa-check", "text-success", "me-1"],
                    [1, "d-flex", "gap-2", "d-md-none"],
                    [1, "row", "align-items-center", "d-none", "d-md-flex"],
                    [1, "col-md-8"],
                    [1, "d-flex", "align-items-center", "gap-3"],
                    [1, "bp-addon-icon", "flex-shrink-0"],
                    [1, "badge", "bg-primary-subtle", "text-primary", "small", "mb-1"],
                    [1, "fw-bold", "mb-1"],
                    [1, "text-muted", "small", "mb-2"],
                    [1, "d-flex", "gap-3", "small", "flex-wrap"],
                    ["href", "https://bytephase.com/white-label-repair-shop-crm/", "target", "_blank", 1, "text-primary", "small", "mt-2", "d-inline-block"],
                    [1, "col-md-4", "text-end"],
                    [1, "fw-bold", "fs-3"],
                    [1, "d-flex", "gap-2", "mt-2", "justify-content-end"],
                    [1, "mt-2"],
                    [1, "btn", "btn-sm", "fw-semibold", "rounded-pill", "px-3", "flex-grow-1", 3, "click"],
                    [1, "fa-solid", "me-1"],
                    [1, "btn", "btn-warning", "btn-sm", "fw-semibold", "rounded-pill", "px-3", 2, "color", "#000!important"],
                    [1, "btn", "btn-warning", "btn-sm", "fw-semibold", "rounded-pill", "px-3", 2, "color", "#000!important", 3, "click"],
                    [1, "btn", "btn-sm", "fw-semibold", "rounded-pill", "px-3", 3, "click"],
                    ["href", "https://bytephase.com/purchase-parity/", "target", "_blank", 1, "btn", "btn-warning", "btn-sm", "fw-semibold", "rounded-pill", "px-3", 2, "color", "#000!important"],
                    [1, "bp-card"],
                    [1, "d-flex", "align-items-center"],
                    [1, "bp-tier-name"],
                    [1, "bp-tier-tag", "ms-auto"],
                    [1, "bp-tier-desc"],
                    [1, "bp-price-wrap"],
                    [1, "bp-currency-sym"],
                    [1, "bp-price"],
                    [1, "bp-period"],
                    [1, "bp-equiv"],
                    [1, "bp-employees"],
                    [1, "fa-solid", "fa-users"],
                    [1, "bp-cta", 3, "primary"],
                    ["href", "/auth/signUp", 1, "bp-cta"],
                    [1, "my-3", 2, "border-color", "var(--bp-line)"],
                    [1, "bp-everything"],
                    [1, "bp-feature-list", "flex-grow-1"],
                    [1, "bp-cta", 3, "click"],
                    [1, "fa-solid", "fa-arrow-right"],
                    [1, "bp-ev-icon"],
                    [1, "fa-solid", "fa-check"],
                    [1, "bp-check"],
                    [1, "center"],
                    [1, "fa-solid", "fa-check", "yes"],
                    [1, "fa-solid", "fa-minus", "no"],
                    [1, "center", "fw-bold"],
                    [1, "text-center", "mb-4"],
                    [1, "badge", "bg-primary-subtle", "text-primary", "rounded-pill", "px-3", "py-2", "mb-2"],
                    [1, "fa-solid", "fa-message", "me-1"],
                    [1, "fw-bold", "mt-2"],
                    [1, "row", "g-3", "justify-content-center", "d-none", "d-md-flex"],
                    [1, "col-md-3"],
                    [1, "d-md-none"],
                    [1, "bp-sms-mobile-card", "d-flex", "align-items-center", "justify-content-between", "p-3", "rounded-3", "border", "mb-2", 3, "border-primary"],
                    [1, "d-flex", "justify-content-center", "gap-4", "gap-md-5", "mt-4", "pt-3", "text-muted", "small"],
                    [1, "text-center"],
                    [1, "fa-solid", "fa-shield-check", "d-block", "mb-1", 2, "font-size", "20px"],
                    [1, "fw-semibold"],
                    [2, "font-size", "11px"],
                    [1, "fa-solid", "fa-bolt", "d-block", "mb-1", 2, "font-size", "20px"],
                    [1, "fa-solid", "fa-lock", "d-block", "mb-1", 2, "font-size", "20px"],
                    [1, "bp-sms-card", "text-center", "p-4", "rounded-3", "border", "h-100", "d-flex", "flex-column", "justify-content-between"],
                    [1, "bp-sms-icon", "mb-3"],
                    [1, "fa-solid", "fa-message"],
                    [1, "fw-semibold", "mb-1"],
                    [1, "text-muted", "small", "mb-1"],
                    [1, "badge", "bg-warning", "text-dark", 2, "font-size", "10px"],
                    [1, "mt-3", "mb-1"],
                    [1, "text-muted", "small"],
                    [1, "fw-bold", "fs-4"],
                    [1, "btn", "fw-semibold", "rounded-pill", "px-3", "mt-3", "w-100", 3, "click"],
                    [1, "fa-solid", "fa-arrow-right", "ms-1"],
                    [1, "bp-sms-mobile-card", "d-flex", "align-items-center", "justify-content-between", "p-3", "rounded-3", "border", "mb-2"],
                    [1, "d-flex", "align-items-center", "gap-3", "flex-grow-1", "overflow-hidden"],
                    [1, "bp-sms-icon-sm", 3, "ngClass"],
                    [1, "overflow-hidden"],
                    [1, "fw-bold", "text-truncate"],
                    [1, "badge", "bg-warning", "text-dark", "ms-1", 2, "font-size", "10px"],
                    [1, "text-muted", "small", "text-truncate"],
                    [1, "text-end", "flex-shrink-0", "ms-2"],
                    [1, "fw-bold", "fs-5", "text-nowrap"],
                    [1, "btn", "fw-semibold", "rounded-pill", "text-nowrap", "mt-1", 2, "font-size", "11px", "padding", "3px 12px", 3, "click"],
                    [1, "bp-faq-item", 3, "click"],
                    [1, "bp-faq-q"],
                    [1, "fa-solid", "fa-plus"],
                    [1, "bp-faq-a"],
                    ["height", "50", "width", "50", 3, "visible"]
                ],
                template: function(t, s) {
                    t & 1 && g(0, Ve, 7, 2, "div", 0)(1, ft, 105, 31, "div", 1)(2, xt, 2, 1, "div", 2), t & 2 && _(s.isIOSNative() ? 0 : s.isLoading() ? 2 : 1)
                },
                dependencies: [de, V, Y],
                styles: ["[_nghost-%COMP%]{display:block;--bp-bg: var(--primary-bg);--bp-surface: var(--background-color);--bp-ink: var(--font-color);--bp-ink-2: var(--theme-font-color);--bp-ink-3: var(--section-header-color);--bp-line: var(--theme-border-color);--bp-line-2: var(--bg-secondary);--bp-primary: #2563eb;--bp-primary-soft: var(--bg-secondary, #eff4ff);--bp-primary-ink: #1d4ed8;--bp-success: #22c55e;--bp-success-soft: var(--bg-secondary, #ecfdf3)}.pricing-page[_ngcontent-%COMP%]{min-height:100vh;background:var(--bp-bg);color:var(--bp-ink);-webkit-font-smoothing:antialiased}.bp-contact-card[_ngcontent-%COMP%]{background:var(--bp-surface);border:1px solid var(--bp-line);border-radius:18px;padding:40px;text-align:center}.bp-chat-btn[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:10px;background:var(--bp-primary);color:#fff;border:0;font-size:15px;font-weight:600;cursor:pointer;transition:background .18s ease;box-shadow:0 6px 14px -4px #2563eb73}.bp-chat-btn[_ngcontent-%COMP%]:hover{background:var(--bp-primary-ink)}.bp-footer[_ngcontent-%COMP%]{background:linear-gradient(135deg,#1e293b,#0f172a);padding:32px 0;color:#94a3b8;font-size:13px}.bp-footer[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]{color:#e2e8f0;text-decoration:none}.bp-footer[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover{color:#fff}.bp-logo-mark[_ngcontent-%COMP%]{width:24px;height:24px;border-radius:6px;background:linear-gradient(135deg,#2563eb,#1d4ed8);display:grid;place-items:center;color:#fff;font-weight:800;font-size:11px}.bp-promo-bar[_ngcontent-%COMP%]{background:linear-gradient(135deg,#1e293b,#0f172a);padding:16px 0;color:#fff;position:fixed;top:0;left:0;right:0;z-index:1000}.bp-promo-spacer[_ngcontent-%COMP%]{height:60px}.bp-promo-text[_ngcontent-%COMP%]{font-size:14px;font-weight:500}.bp-promo-highlight[_ngcontent-%COMP%]{font-weight:700;font-size:15px;background:linear-gradient(90deg,#fbbf24,#f59e0b);-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:_ngcontent-%COMP%_bp-shimmer 2.5s ease-in-out infinite}@keyframes _ngcontent-%COMP%_bp-shimmer{0%,to{opacity:1}50%{opacity:.7}}.bp-promo-cta[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;padding:7px 18px;border-radius:999px;border:1px solid rgba(255,255,255,.3);background:#ffffff1a;color:#fff;font-size:13px;font-weight:600;text-decoration:none;transition:all .2s ease;backdrop-filter:blur(4px)}.bp-promo-cta[_ngcontent-%COMP%]:hover{background:#fff3;border-color:#ffffff80;color:#fff;transform:translateY(-1px)}.bp-promo-cta[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:12px;color:#fbbf24}.bp-eyebrow[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:999px;background:var(--bp-surface);border:1px solid var(--bp-line);font-size:12px;font-weight:500;color:var(--bp-ink-2);box-shadow:0 1px 2px #0f172a0a}.bp-dot[_ngcontent-%COMP%]{width:6px;height:6px;border-radius:50%;background:#16a34a;box-shadow:0 0 0 3px #16a34a26}.bp-proof[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;gap:10px;color:var(--bp-ink-2);font-size:13px}.bp-stars[_ngcontent-%COMP%]{color:#f59e0b;font-size:12px;letter-spacing:1px}.bp-h1[_ngcontent-%COMP%]{font-size:clamp(36px,5vw,52px);line-height:1.08;letter-spacing:-.025em;font-weight:700}.bp-h1[_ngcontent-%COMP%]   em[_ngcontent-%COMP%]{font-style:normal;color:var(--bp-primary)}.bp-sub[_ngcontent-%COMP%]{font-size:17px;color:var(--bp-ink-2);max-width:620px;margin:14px auto 0;line-height:1.55}.bp-addon-card[_ngcontent-%COMP%]{background:var(--bp-surface);border:2px solid var(--bp-primary);border-radius:14px;padding:24px 28px;margin-bottom:12px}.bp-addon-icon[_ngcontent-%COMP%]{width:52px;height:52px;border-radius:12px;background:#dbeafe;color:#2563eb;display:flex;align-items:center;justify-content:center;font-size:22px}.bp-toggle[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:4px;background:var(--bp-surface);border:1px solid var(--bp-line);padding:4px;border-radius:999px;box-shadow:0 1px 2px #0f172a0a}.bp-toggle-btn[_ngcontent-%COMP%]{border:0;background:transparent;padding:9px 18px;border-radius:999px;font-size:14px;font-weight:500;color:var(--bp-ink-2);cursor:pointer;transition:all .18s ease}.bp-toggle-btn.active[_ngcontent-%COMP%]{background:#1e293b;color:#fff}.bp-save-badge[_ngcontent-%COMP%]{font-size:11px;font-weight:600;padding:2px 7px;border-radius:999px;background:var(--bp-success-soft);color:var(--bp-success);border:1px solid #abefc6}.bp-card[_ngcontent-%COMP%]{background:var(--bp-surface);border:1px solid var(--bp-line);border-radius:18px;padding:28px 26px;display:flex;flex-direction:column;height:100%;transition:transform .25s ease,box-shadow .25s ease,border-color .25s ease;position:relative;box-shadow:0 1px 2px #0f172a0a}.bp-card[_ngcontent-%COMP%]:hover{border-color:#d0d5dd;box-shadow:0 12px 32px -12px #0f172a1f;transform:translateY(-2px)}.bp-card.featured[_ngcontent-%COMP%]{border:1.5px solid var(--bp-primary);box-shadow:0 0 0 4px var(--bp-primary-soft),0 24px 48px -16px #2563eb47,0 8px 16px -8px #0f172a14;transform:translateY(-8px)}.bp-card.featured[_ngcontent-%COMP%]:hover{transform:translateY(-10px)}.bp-card.featured[_ngcontent-%COMP%]   .bp-tier-name[_ngcontent-%COMP%]{color:var(--bp-primary)}.bp-card.featured[_ngcontent-%COMP%]   .bp-employees[_ngcontent-%COMP%]{background:var(--bp-primary-soft);color:var(--bp-primary-ink)}.bp-card.featured[_ngcontent-%COMP%]   .bp-check[_ngcontent-%COMP%]{background:var(--bp-primary-soft);color:var(--bp-primary)}.bp-tier-name[_ngcontent-%COMP%]{font-size:14px;font-weight:600;letter-spacing:.02em;text-transform:uppercase;color:var(--bp-ink-2)}.bp-tier-tag[_ngcontent-%COMP%]{font-size:11px;font-weight:600;padding:4px 10px;border-radius:999px;background:var(--bp-primary);color:#fff;box-shadow:0 4px 10px #2563eb52}.bp-tier-desc[_ngcontent-%COMP%]{color:var(--bp-ink-2);font-size:14px;margin-top:10px;line-height:1.5;min-height:42px}.bp-price-wrap[_ngcontent-%COMP%]{display:flex;align-items:baseline;gap:6px;margin-top:18px}.bp-currency-sym[_ngcontent-%COMP%]{font-size:22px;font-weight:600;color:var(--bp-ink-2)}.bp-price[_ngcontent-%COMP%]{font-size:48px;font-weight:700;letter-spacing:-.03em;line-height:1;color:var(--bp-ink);font-variant-numeric:tabular-nums}.bp-period[_ngcontent-%COMP%]{font-size:14px;color:var(--bp-ink-3)}.bp-equiv[_ngcontent-%COMP%]{font-size:13px;color:var(--bp-ink-2);margin-top:8px;font-variant-numeric:tabular-nums}.bp-employees[_ngcontent-%COMP%]{margin-top:22px;padding:12px 14px;background:var(--bp-line-2);border-radius:10px;display:flex;align-items:center;gap:10px;font-size:13px;color:var(--bp-ink)}.bp-cta[_ngcontent-%COMP%]{margin-top:22px;width:100%;border-radius:10px;padding:12px 16px;font-size:14px;font-weight:600;border:1px solid var(--bp-line);background:var(--bp-surface);color:var(--bp-ink);cursor:pointer;transition:all .18s ease;display:inline-flex;align-items:center;justify-content:center;gap:8px}.bp-cta[_ngcontent-%COMP%]:hover{border-color:var(--bp-ink);transform:translateY(-1px)}.bp-cta.primary[_ngcontent-%COMP%]{background:var(--bp-primary);color:#fff;border-color:var(--bp-primary);box-shadow:0 6px 14px -4px #2563eb73}.bp-cta.primary[_ngcontent-%COMP%]:hover{background:var(--bp-primary-ink);border-color:var(--bp-primary-ink)}.bp-cta[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{transition:transform .2s ease;font-size:12px}.bp-cta[_ngcontent-%COMP%]:hover   i[_ngcontent-%COMP%]{transform:translate(3px)}.bp-guarantee[_ngcontent-%COMP%]{text-align:center;font-size:12px;color:var(--bp-ink-3);margin-top:10px}.bp-feature-list[_ngcontent-%COMP%]{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:10px}.bp-feature-list[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:10px;font-size:14px;color:var(--bp-ink);line-height:1.45}.bp-check[_ngcontent-%COMP%]{flex:0 0 18px;height:18px;width:18px;border-radius:50%;background:var(--bp-success-soft);color:var(--bp-success);display:grid;place-items:center;font-size:9px;margin-top:2px}.bp-dash[_ngcontent-%COMP%]{flex:0 0 18px;height:18px;width:18px;border-radius:50%;background:var(--bp-line-2);color:var(--bp-ink-3);display:grid;place-items:center;font-size:9px;margin-top:2px}.bp-everything[_ngcontent-%COMP%]{font-size:13px;font-weight:500;color:var(--bp-ink-2);padding:4px 0 12px;display:flex;align-items:center;gap:8px;margin-bottom:6px;border-bottom:1px dashed var(--bp-line)}.bp-everything[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{color:var(--bp-ink);font-weight:600}.bp-ev-icon[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;background:var(--bp-primary-soft);color:var(--bp-primary);display:grid;place-items:center;flex:0 0 18px;font-size:9px}.bp-feature-cat[_ngcontent-%COMP%]{font-size:11px;font-weight:600;color:var(--bp-ink-3);text-transform:uppercase;letter-spacing:.06em;margin-top:14px;margin-bottom:6px}.bp-feature-cat[_ngcontent-%COMP%]:first-child{margin-top:0}.bp-guarantees[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;justify-content:center;gap:28px;color:var(--bp-ink-2);font-size:13px}.bp-guarantees[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:var(--bp-success)}.bp-compare[_ngcontent-%COMP%]{background:var(--bp-surface);border:1px solid var(--bp-line);border-radius:14px;overflow:hidden}.bp-compare[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]{width:100%;border-collapse:collapse}.bp-compare[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .bp-compare[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:12px 16px;font-size:13px;text-align:left;border-bottom:1px solid var(--bp-line-2)}.bp-compare[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{background:var(--bp-line-2, #fafbfc);font-weight:600;color:var(--bp-ink-2);text-transform:uppercase;letter-spacing:.04em;font-size:11px}.bp-compare[_ngcontent-%COMP%]   .center[_ngcontent-%COMP%]{text-align:center}.bp-compare[_ngcontent-%COMP%]   th.featured[_ngcontent-%COMP%]{color:var(--bp-primary)}.bp-compare[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:last-child   td[_ngcontent-%COMP%]{border-bottom:0}.bp-compare[_ngcontent-%COMP%]   .yes[_ngcontent-%COMP%]{color:var(--bp-success)}.bp-compare[_ngcontent-%COMP%]   .no[_ngcontent-%COMP%]{color:var(--bp-ink-3)}.bp-faq-item[_ngcontent-%COMP%]{border-bottom:1px solid var(--bp-line);padding:18px 4px}.bp-faq-q[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;font-weight:500;font-size:15px;color:var(--bp-ink);cursor:pointer}.bp-faq-q[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{color:var(--bp-ink-3);transition:transform .2s}.bp-faq-a[_ngcontent-%COMP%]{color:var(--bp-ink-2);font-size:14px;line-height:1.6;max-height:0;overflow:hidden;transition:max-height .25s ease,padding .2s ease}.bp-faq-item.open[_ngcontent-%COMP%]   .bp-faq-q[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{transform:rotate(45deg)}.bp-faq-item.open[_ngcontent-%COMP%]   .bp-faq-a[_ngcontent-%COMP%]{max-height:200px;padding-top:12px}@media(max-width:991px){.bp-card.featured[_ngcontent-%COMP%]{transform:none}.bp-card.featured[_ngcontent-%COMP%]:hover{transform:translateY(-2px)}}.bp-sms-card[_ngcontent-%COMP%]{background:var(--bp-surface);transition:transform .2s,box-shadow .2s;overflow:hidden}.bp-sms-card[_ngcontent-%COMP%]:hover{transform:translateY(-4px);box-shadow:0 8px 24px #00000014}.bp-sms-icon[_ngcontent-%COMP%]{width:48px;height:48px;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:20px;background:var(--bp-line-2, #f1f5f9);color:var(--bp-primary, #2563eb)}.bp-sms-icon-sm[_ngcontent-%COMP%]{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}.bp-sms-color-0[_ngcontent-%COMP%]{color:#2563eb}.bp-sms-color-0[_ngcontent-%COMP%]   .fa-message[_ngcontent-%COMP%], .bp-sms-icon.bp-sms-color-0[_ngcontent-%COMP%], .bp-sms-icon-sm.bp-sms-color-0[_ngcontent-%COMP%]{background:#eff4ff;color:#2563eb}.bp-sms-color-1[_ngcontent-%COMP%]{color:#16a34a}.bp-sms-color-1[_ngcontent-%COMP%]   .fa-message[_ngcontent-%COMP%], .bp-sms-icon.bp-sms-color-1[_ngcontent-%COMP%], .bp-sms-icon-sm.bp-sms-color-1[_ngcontent-%COMP%]{background:#ecfdf3;color:#16a34a}.bp-sms-color-2[_ngcontent-%COMP%]{color:#ea580c}.bp-sms-color-2[_ngcontent-%COMP%]   .fa-message[_ngcontent-%COMP%], .bp-sms-icon.bp-sms-color-2[_ngcontent-%COMP%], .bp-sms-icon-sm.bp-sms-color-2[_ngcontent-%COMP%]{background:#fff4ed;color:#ea580c}.bp-sms-color-3[_ngcontent-%COMP%]{color:#7c3aed}.bp-sms-color-3[_ngcontent-%COMP%]   .fa-message[_ngcontent-%COMP%], .bp-sms-icon.bp-sms-color-3[_ngcontent-%COMP%], .bp-sms-icon-sm.bp-sms-color-3[_ngcontent-%COMP%]{background:#f3f0ff;color:#7c3aed}.bp-sms-mobile-card[_ngcontent-%COMP%]{background:var(--bp-surface)}.bp-sms-icon-sm[_ngcontent-%COMP%]{background:var(--bp-line-2, #f1f5f9);color:var(--bp-primary, #2563eb)}"]
            })
        }
    }
    return n
})();

function vt(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 45)(1, "label", 46), r(2, "State"), o(), a(3, "dx-select-box", 52), h("onValueChanged", function(s) {
            C(e);
            let m = d(3);
            return y(m.billingStateId.set(s.value))
        }), o(), a(4, "small", 6), r(5, "Required for GST calculation (CGST+SGST or IGST)"), o()()
    }
    if (n & 2) {
        let e = d(3);
        i(3), b("items", e.states())("value", e.billingStateId())("searchEnabled", !0)
    }
}

function Ct(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 45)(1, "label", 46), r(2), o(), a(3, "dx-text-box", 53), h("onValueChanged", function(s) {
            C(e);
            let m = d(3);
            return y(m.billingGstin.set(s.value))
        }), o(), a(4, "small", 6), r(5), o()()
    }
    if (n & 2) {
        let e = d(3);
        i(2), w("", e.formatMessage("gstin"), " (", e.formatMessage("optional"), ")"), i(), b("value", e.billingGstin())("placeholder", e.formatMessage("gstin_placeholder"))("maxLength", 15), i(2), c(e.formatMessage("gstin_hint"))
    }
}

function yt(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 12)(1, "div", 13)(2, "div", 14)(3, "div", 43), p(4, "i", 44), o(), a(5, "div")(6, "h5", 17), r(7), o(), a(8, "small", 6), r(9), o()()(), a(10, "div", 45)(11, "label", 46), r(12), o(), a(13, "dx-text-box", 47), h("onValueChanged", function(s) {
            C(e);
            let m = d(2);
            return y(m.billingName.set(s.value))
        }), o()(), a(14, "div", 45)(15, "label", 46), r(16), o(), a(17, "dx-text-box", 47), h("onValueChanged", function(s) {
            C(e);
            let m = d(2);
            return y(m.billingCompany.set(s.value))
        }), o()(), a(18, "div", 48)(19, "div", 49)(20, "label", 46), r(21), o(), a(22, "dx-text-box", 50), h("onValueChanged", function(s) {
            C(e);
            let m = d(2);
            return y(m.billingEmail.set(s.value))
        }), o()(), a(23, "div", 49)(24, "label", 46), r(25), o(), a(26, "dx-text-box", 47), h("onValueChanged", function(s) {
            C(e);
            let m = d(2);
            return y(m.billingPhone.set(s.value))
        }), o()()(), g(27, vt, 6, 3, "div", 45), g(28, Ct, 6, 6, "div", 45), p(29, "hr", 51), a(30, "small", 6), p(31, "i", 7), r(32), o()()()
    }
    if (n & 2) {
        let e = d(2);
        i(7), c(e.formatMessage("billing_details")), i(2), c(e.formatMessage("checkout_billing_subtitle")), i(3), c(e.formatMessage("full_name")), i(), b("value", e.billingName()), i(3), x("Company / Business Name (", e.formatMessage("optional"), ")"), i(), b("value", e.billingCompany()), i(4), c(e.formatMessage("email_address")), i(), b("value", e.billingEmail()), i(3), c(e.formatMessage("phone_number")), i(), b("value", e.billingPhone()), i(), _(e.isIndia() && e.states().length ? 27 : -1), i(), _(e.isIndia() ? 28 : -1), i(4), c(e.formatMessage("checkout_privacy_note"))
    }
}

function St(n, l) {
    if (n & 1 && (a(0, "div", 18)(1, "span"), r(2), o(), a(3, "span", 36), r(4), P(5, "number"), o()()), n & 2) {
        let e, t = d(2);
        i(2), U("", (e = t.plan()) == null ? null : e.name, " ", t.formatMessage("plan"), " \u2014 ", (e = t.plan()) == null ? null : e.duration_type), i(2), w("", t.currencyCode(), " ", k(5, 5, t.baseAmount(), "1.2-2"))
    }
}

function Pt(n, l) {
    if (n & 1 && (a(0, "div", 18)(1, "span"), r(2), o(), a(3, "span", 36), r(4), P(5, "number"), o()()), n & 2) {
        let e = l.$implicit,
            t = d(2);
        i(2), c(e.name), i(2), w("", t.currencyCode(), " ", k(5, 3, e.price, "1.2-2"))
    }
}

function Mt(n, l) {
    if (n & 1 && (a(0, "div", 19)(1, "span"), r(2), o(), a(3, "span"), r(4), P(5, "number"), o()()), n & 2) {
        let e = d(2);
        i(2), w("", e.formatMessage("coupon_discount"), " (", e.couponCode(), ")"), i(2), w("-", e.currencyCode(), " ", k(5, 4, e.discountAmount(), "1.2-2"))
    }
}

function kt(n, l) {
    if (n & 1 && (a(0, "div", 55)(1, "span"), r(2, "CGST (9%)"), o(), a(3, "span"), r(4), P(5, "number"), o()(), a(6, "div", 54)(7, "span"), r(8, "SGST (9%)"), o(), a(9, "span"), r(10), P(11, "number"), o()()), n & 2) {
        let e = d(3);
        i(4), w("", e.currencyCode(), " ", k(5, 4, e.taxAmount() / 2, "1.2-2")), i(6), w("", e.currencyCode(), " ", k(11, 7, e.taxAmount() / 2, "1.2-2"))
    }
}

function wt(n, l) {
    if (n & 1 && (a(0, "div", 54)(1, "span"), r(2), o(), a(3, "span"), r(4), P(5, "number"), o()()), n & 2) {
        let e = d(3);
        i(2), x("IGST (", e.gstRate, "%)"), i(2), w("", e.currencyCode(), " ", k(5, 3, e.taxAmount(), "1.2-2"))
    }
}

function Et(n, l) {
    if (n & 1 && (g(0, kt, 12, 10), g(1, wt, 6, 6, "div", 54)), n & 2) {
        let e = d(2);
        _(e.isSameState() ? 0 : -1), i(), _(e.isSameState() ? -1 : 1)
    }
}

function It(n, l) {
    if (n & 1 && (a(0, "div", 24), p(1, "i", 56), a(2, "span", 57), r(3), o()()), n & 2) {
        let e = d(2);
        i(3), c(e.formatMessage("have_coupon"))
    }
}

function Ot(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "dx-button", 58), h("onClick", function() {
            C(e);
            let s = d(2);
            return y(s.applyCoupon())
        }), o()
    }
    if (n & 2) {
        let e = d(2);
        b("text", e.formatMessage("apply"))("disabled", e.isValidatingCoupon() || !e.couponCode())
    }
}

function Tt(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "dx-button", 59), h("onClick", function() {
            C(e);
            let s = d(2);
            return y(s.removeCoupon())
        }), o()
    }
}

function Nt(n, l) {
    if (n & 1 && (a(0, "small", 29), r(1), o()), n & 2) {
        let e = d(2);
        i(), c(e.couponError())
    }
}

function Bt(n, l) {
    if (n & 1 && (a(0, "small", 30), p(1, "i", 60), r(2), o()), n & 2) {
        let e = d(2);
        i(2), c(e.formatMessage("coupon_applied_success"))
    }
}

function Dt(n, l) {
    n & 1 && p(0, "i", 62)
}

function Lt(n, l) {
    n & 1 && p(0, "i", 64)
}

function Vt(n, l) {
    if (n & 1 && (a(0, "div", 61), g(1, Dt, 1, 0, "i", 62), p(2, "dx-load-indicator", 63), a(3, "span"), r(4), o(), g(5, Lt, 1, 0, "i", 64), o()), n & 2) {
        let e = d(2);
        i(), _(e.isSubmitting() ? -1 : 1), i(), b("visible", e.isSubmitting()), i(2), c(e.isSubmitting() ? e.formatMessage("processing") : e.formatMessage("proceed_to_payment")), i(), _(e.isSubmitting() ? -1 : 5)
    }
}

function At(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 0)(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "div")(5, "h3", 5), r(6), o(), a(7, "small", 6), p(8, "i", 7), r(9), o()(), a(10, "span", 8), p(11, "i", 9), r(12, "256-bit SSL encrypted "), o()()()(), a(13, "div", 10)(14, "div", 11), g(15, yt, 33, 13, "div", 12), a(16, "div")(17, "div", 13)(18, "div", 14)(19, "div", 15), p(20, "i", 16), o(), a(21, "div")(22, "h5", 17), r(23), o(), a(24, "small", 6), r(25), o()()(), g(26, St, 6, 8, "div", 18), I(27, Pt, 6, 6, "div", 18, E), g(29, Mt, 6, 7, "div", 19), g(30, Et, 2, 2), p(31, "hr"), a(32, "div", 20)(33, "span", 21), r(34), o(), a(35, "span", 22), r(36), P(37, "number"), o()(), a(38, "div", 23), g(39, It, 4, 1, "div", 24), a(40, "div", 25)(41, "dx-text-box", 26), h("onValueChanged", function(s) {
            C(e);
            let m = d();
            return y(m.couponCode.set(s.value))
        }), o(), g(42, Ot, 1, 2, "dx-button", 27), g(43, Tt, 1, 0, "dx-button", 28), o(), g(44, Nt, 2, 1, "small", 29), g(45, Bt, 3, 1, "small", 30), o(), a(46, "dx-button", 31), h("onClick", function() {
            C(e);
            let s = d();
            return y(s.proceedToPayment())
        }), re(47, Vt, 6, 4, "div", 32), o(), a(48, "div", 33)(49, "div", 34), p(50, "i", 35), a(51, "div")(52, "div", 36), r(53), o(), a(54, "div", 37), r(55), o()()(), a(56, "div", 34), p(57, "i", 38), a(58, "div")(59, "div", 36), r(60), o(), a(61, "div", 37), r(62, "256-bit SSL"), o()()(), a(63, "div", 34), p(64, "i", 39), a(65, "div")(66, "div", 36), r(67), o(), a(68, "div", 37), r(69, "PCI DSS"), o()()()()()()(), a(70, "p", 40), r(71), a(72, "a", 41), r(73), o(), r(74), a(75, "a", 42), r(76), o()()()()
    }
    if (n & 2) {
        let e = d();
        i(6), c(e.formatMessage("checkout")), i(3), c(e.formatMessage("checkout_subtitle")), i(6), _(e.isProspect() ? -1 : 15), i(), G(e.isProspect() ? "col-md-8 mx-auto" : "col-md-5"), i(7), c(e.formatMessage("order_summary")), i(2), c(e.formatMessage("checkout_review_order")), i(), _(e.plan() ? 26 : -1), i(), O(e.addOnPlans()), i(2), _(e.couponApplied() ? 29 : -1), i(), _(e.taxAmount() > 0 ? 30 : -1), i(4), c(e.formatMessage("total")), i(2), w("", e.currencyCode(), " ", k(37, 31, e.totalAmount(), "1.2-2")), i(3), _(e.couponApplied() ? -1 : 39), i(2), b("value", e.couponCode())("placeholder", e.formatMessage("enter_coupon_code"))("disabled", e.couponApplied()), i(), _(e.couponApplied() ? -1 : 42), i(), _(e.couponApplied() ? 43 : -1), i(), _(e.couponError() ? 44 : -1), i(), _(e.couponApplied() ? 45 : -1), i(), b("disabled", e.isSubmitting()), i(), b("dxTemplateOf", "content"), i(6), c(e.formatMessage("guarantee_secure")), i(2), c(e.formatMessage("checkout_data_safe")), i(5), c(e.formatMessage("checkout_encrypted")), i(7), c(e.formatMessage("checkout_trusted")), i(4), x(" ", e.formatMessage("checkout_terms_prefix"), " "), i(2), c(e.formatMessage("terms_of_service")), i(), x(" ", e.formatMessage("and"), " "), i(2), c(e.formatMessage("privacy_policy"))
    }
}

function qt(n, l) {
    n & 1 && (a(0, "div", 1), p(1, "dx-load-indicator", 65), o()), n & 2 && (i(), b("visible", !0))
}
var ee = (() => {
    class n {
        constructor() {
            this.formatMessage = u, this.subscriptionService = v(A), this.storageService = v(q), this.route = v(D), this.router = v(L), this.tenantService = v(Q), this.toastService = v(W), this.isLoading = f(!0), this.isSubmitting = f(!1), this.isProspect = f(!1), this.prospectToken = f(""), this.plan = f(null), this.country = f(null), this.planId = f(0), this.orderType = f("new"), this.states = f([]), this.couponCode = f(""), this.couponApplied = f(!1), this.couponDiscount = f(0), this.couponError = f(""), this.isValidatingCoupon = f(!1), this.billingName = f(""), this.billingCompany = f(""), this.billingEmail = f(""), this.billingPhone = f(""), this.billingStateId = f(null), this.billingGstin = f(""), this.addOnPlanIds = f([]), this.addOnPlans = f([]), this.isAddOnOnly = f(!1), this.baseAmount = T(() => Number(this.plan() ? .price) || 0), this.addOnTotal = T(() => this.addOnPlans().reduce((e, t) => e + Number(t.price), 0)), this.currencyCode = T(() => this.country() ? .currency_code || "INR"), this.discountAmount = T(() => this.couponApplied() ? this.couponDiscount() : 0), this.subtotal = T(() => Math.max(this.baseAmount() + this.addOnTotal() - this.discountAmount(), 0)), this.isIndia = T(() => this.currencyCode() === "INR"), this.companyStateId = 22, this.gstRate = 18, this.isSameState = T(() => this.billingStateId() === this.companyStateId), this.taxAmount = T(() => this.isIndia() ? Math.round(this.subtotal() * this.gstRate / 100 * 100) / 100 : 0), this.totalAmount = T(() => this.subtotal() + this.taxAmount())
        }
        ngOnInit() {
            let e = this.route.snapshot.params.token,
                t = this.route.snapshot.queryParams.add_on_plan_ids;
            t && this.addOnPlanIds.set(t.split(",").map(Number));
            let s = Number(this.route.snapshot.queryParams.billing_state_id);
            if (s && this.billingStateId.set(s), e) {
                this.isProspect.set(!0), this.prospectToken.set(e), this.loadProspectDetails(e);
                return
            }
            if (this.planId.set(Number(this.route.snapshot.queryParams.plan_id)), this.orderType.set(this.route.snapshot.queryParams.order_type || "new"), this.isAddOnOnly.set(this.route.snapshot.queryParams.is_add_on_only === "true"), !this.planId()) {
                this.router.navigate(["/pricing"]);
                return
            }
            this.loadPlanDetails()
        }
        loadPlanDetails() {
            let e = this.tenantService.config() ? .country_id;
            if (e) {
                this.subscriptionService.getPlans(e).subscribe({
                    next: t => this.setPlanData(t),
                    error: () => this.isLoading.set(!1)
                });
                return
            }
            this.subscriptionService.detectCountry().subscribe({
                next: t => {
                    this.subscriptionService.getPlans(t.country_id).subscribe({
                        next: s => this.setPlanData(s),
                        error: () => this.isLoading.set(!1)
                    })
                },
                error: () => {
                    this.subscriptionService.getPlans().subscribe({
                        next: t => this.setPlanData(t),
                        error: () => this.isLoading.set(!1)
                    })
                }
            })
        }
        setPlanData(e) {
            this.country.set(e.country), this.states.set(e.states || []);
            let t = [...e.add_ons || [], ...e.sms_packs || []];
            if (this.isAddOnOnly()) {
                let s = t.find(m => m.id === this.planId());
                this.plan.set(null), this.addOnPlans.set(s ? [s] : [])
            } else {
                let s = e.plans || [];
                this.plan.set(s.find(m => m.id === this.planId())), this.addOnPlans.set(t.filter(m => this.addOnPlanIds().includes(m.id)))
            }
            this.prefillBilling(), this.isLoading.set(!1)
        }
        loadProspectDetails(e) {
            this.subscriptionService.checkProspectStatus(e).subscribe({
                next: t => {
                    let s = t.prospect || {};
                    this.plan.set(s.plan), this.planId.set(s.plan ? .id), this.country.set({
                        currency_code: s.currency_code
                    }), this.billingName.set(s.name || ""), this.billingCompany.set(s.company_name || ""), this.billingEmail.set(s.email || ""), this.addOnPlanIds().length ? this.subscriptionService.getPlans(s.plan ? .country_id).subscribe({
                        next: m => {
                            let Ne = m.add_ons || [];
                            this.addOnPlans.set(Ne.filter(Be => this.addOnPlanIds().includes(Be.id))), this.isLoading.set(!1)
                        },
                        error: () => this.isLoading.set(!1)
                    }) : this.isLoading.set(!1)
                },
                error: () => this.isLoading.set(!1)
            })
        }
        prefillBilling() {
            let e = this.storageService.getTenant();
            if (e) {
                this.billingName.set(e.name || ""), this.billingCompany.set(e.name || ""), this.billingEmail.set(e.support_email || ""), this.billingPhone.set(e.support_number || "");
                let t = e.address ? .state;
                if (t && this.states().length && !this.billingStateId()) {
                    let s = this.states().find(m => m.name === t);
                    s && this.billingStateId.set(s.id)
                }
            }
        }
        applyCoupon() {
            let e = this.couponCode().trim();
            if (!e) return;
            this.isValidatingCoupon.set(!0), this.couponError.set("");
            let t = Number(this.storageService.getTenantId()) || void 0;
            this.subscriptionService.validateCoupon(e, this.planId(), this.currencyCode(), t).subscribe({
                next: s => {
                    this.couponApplied.set(!0), this.couponDiscount.set(s.discount_amount), this.isValidatingCoupon.set(!1)
                },
                error: s => {
                    this.couponError.set(s ? .error ? .message || u("invalid_coupon")), this.couponApplied.set(!1), this.couponDiscount.set(0), this.isValidatingCoupon.set(!1)
                }
            })
        }
        removeCoupon() {
            this.couponCode.set(""), this.couponApplied.set(!1), this.couponDiscount.set(0), this.couponError.set("")
        }
        proceedToPayment() {
            this.isSubmitting.set(!0);
            let e = window.location.hostname.startsWith("app.") || void 0;
            this.isProspect() ? this.subscriptionService.prospectCheckout(this.prospectToken(), {
                coupon_code: this.couponApplied() ? this.couponCode() : void 0,
                billing_state_id: this.billingStateId() || void 0,
                billing_gstin: this.billingGstin() || void 0,
                add_on_plan_ids: this.addOnPlanIds().length ? this.addOnPlanIds() : void 0,
                redirect_to_app: e
            }).subscribe({
                next: t => this.handleCheckoutResponse(t),
                error: t => this.handleCheckoutError(t)
            }) : this.isAddOnOnly() ? this.subscriptionService.checkoutAddOn({
                add_on_plan_ids: this.addOnPlans().map(t => t.id),
                coupon_code: this.couponApplied() ? this.couponCode() : void 0,
                billing_name: this.billingName() || void 0,
                billing_company: this.billingCompany() || void 0,
                billing_email: this.billingEmail() || void 0,
                billing_phone: this.billingPhone() || void 0,
                billing_state_id: this.billingStateId() || void 0,
                billing_gstin: this.billingGstin() || void 0,
                redirect_to_app: e
            }).subscribe({
                next: t => this.handleCheckoutResponse(t),
                error: t => this.handleCheckoutError(t)
            }) : this.subscriptionService.checkout({
                plan_id: this.planId(),
                order_type: this.orderType(),
                coupon_code: this.couponApplied() ? this.couponCode() : void 0,
                billing_name: this.billingName() || void 0,
                billing_company: this.billingCompany() || void 0,
                billing_email: this.billingEmail() || void 0,
                billing_phone: this.billingPhone() || void 0,
                billing_state_id: this.billingStateId() || void 0,
                billing_gstin: this.billingGstin() || void 0,
                add_on_plan_ids: this.addOnPlanIds().length ? this.addOnPlanIds() : void 0,
                redirect_to_app: e
            }).subscribe({
                next: t => this.handleCheckoutResponse(t),
                error: t => this.handleCheckoutError(t)
            })
        }
        handleCheckoutResponse(e) {
            let t = e.payment || e;
            if (t.redirect_url) {
                let s = be.appUrl,
                    m = window.location.origin;
                s && !m.includes("app.") && !m.includes("localhost") ? window.location.href = s + "/pricing/pay?url=" + encodeURIComponent(t.redirect_url) : window.location.href = t.redirect_url;
                return
            }
            this.isSubmitting.set(!1), this.toastService.error(u("checkout_failed"))
        }
        handleCheckoutError(e) {
            this.isSubmitting.set(!1), this.toastService.error(e ? .error ? .message || u("checkout_failed"))
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = B({
                type: n,
                selectors: [
                    ["app-checkout"]
                ],
                standalone: !1,
                decls: 2,
                vars: 1,
                consts: [
                    [1, "dx-theme-background-color", 2, "min-height", "100vh"],
                    [1, "d-flex", "justify-content-center", "align-items-center", "dx-theme-background-color", 2, "min-height", "80vh"],
                    [1, "checkout-header"],
                    [1, "container", 2, "max-width", "960px"],
                    [1, "d-flex", "align-items-center", "justify-content-between"],
                    [1, "fw-bold", "mb-0"],
                    [1, "text-muted"],
                    [1, "fa-solid", "fa-lock", "me-1"],
                    [1, "badge", "border", "rounded-pill", "px-3", "py-2", "text-muted", "d-none", "d-md-inline-block"],
                    [1, "fa-solid", "fa-shield-check", "text-success", "me-1"],
                    [1, "container", "py-4", 2, "max-width", "960px"],
                    [1, "row", "g-4", "align-items-start"],
                    [1, "col-md-7"],
                    [1, "checkout-card"],
                    [1, "d-flex", "align-items-center", "gap-3", "mb-4"],
                    [1, "checkout-icon", "bg-success-subtle", "text-success"],
                    [1, "fa-solid", "fa-receipt"],
                    [1, "fw-semibold", "mb-0"],
                    [1, "d-flex", "justify-content-between", "mb-2"],
                    [1, "d-flex", "justify-content-between", "mb-2", "text-success"],
                    [1, "d-flex", "justify-content-between", "align-items-center", "mb-4"],
                    [1, "fw-bold"],
                    [1, "fw-bold", "fs-4"],
                    [1, "coupon-section", "mb-4"],
                    [1, "mb-2"],
                    [1, "d-flex", "gap-2"],
                    [1, "flex-grow-1", 3, "onValueChanged", "value", "placeholder", "disabled"],
                    ["type", "default", "stylingMode", "contained", 3, "text", "disabled"],
                    ["icon", "close", "type", "danger", "stylingMode", "text"],
                    [1, "text-danger", "d-block", "mt-1"],
                    [1, "text-success", "d-block", "mt-1"],
                    ["type", "default", "stylingMode", "contained", 1, "w-100", "checkout-pay-btn", 3, "onClick", "disabled"],
                    ["class", "d-flex align-items-center justify-content-center gap-2", 4, "dxTemplate", "dxTemplateOf"],
                    [1, "d-flex", "justify-content-between", "mt-3", "pt-3", "border-top", "small"],
                    [1, "d-flex", "align-items-center", "gap-2"],
                    [1, "fa-solid", "fa-shield-check", "text-success"],
                    [1, "fw-semibold"],
                    [1, "text-muted", 2, "font-size", "11px"],
                    [1, "fa-solid", "fa-lock", "text-primary"],
                    [1, "fa-solid", "fa-circle-check", "text-success"],
                    [1, "text-center", "text-muted", "small", "mt-4"],
                    ["href", "https://bytephase.com/terms-conditions", "target", "_blank", 1, "text-primary"],
                    ["href", "https://bytephase.com/privacy-policy", "target", "_blank", 1, "text-primary"],
                    [1, "checkout-icon", "bg-primary-subtle", "text-primary"],
                    [1, "fa-solid", "fa-user"],
                    [1, "mb-3"],
                    [1, "form-label", "fw-semibold", "small"],
                    [3, "onValueChanged", "value"],
                    [1, "row", "mb-3"],
                    [1, "col-6"],
                    ["mode", "email", 3, "onValueChanged", "value"],
                    [1, "my-3"],
                    ["displayExpr", "name", "valueExpr", "id", "placeholder", "Select your state", 3, "onValueChanged", "items", "value", "searchEnabled"],
                    [3, "onValueChanged", "value", "placeholder", "maxLength"],
                    [1, "d-flex", "justify-content-between", "mb-2", "text-muted", "small"],
                    [1, "d-flex", "justify-content-between", "mb-1", "text-muted", "small"],
                    [1, "fa-solid", "fa-tag", "text-primary", "me-1"],
                    [1, "text-primary", "fw-semibold", "small"],
                    ["type", "default", "stylingMode", "contained", 3, "onClick", "text", "disabled"],
                    ["icon", "close", "type", "danger", "stylingMode", "text", 3, "onClick"],
                    [1, "fa-solid", "fa-check", "me-1"],
                    [1, "d-flex", "align-items-center", "justify-content-center", "gap-2"],
                    [1, "fa-solid", "fa-lock"],
                    ["height", "18", "width", "18", 3, "visible"],
                    [1, "fa-solid", "fa-arrow-right"],
                    ["height", "50", "width", "50", 3, "visible"]
                ],
                template: function(t, s) {
                    t & 1 && g(0, At, 77, 34, "div", 0)(1, qt, 2, 1, "div", 1), t & 2 && _(s.isLoading() ? 1 : 0)
                },
                dependencies: [ve, F, V, J, H, Y],
                styles: [".checkout-header[_ngcontent-%COMP%]{padding:20px 0;border-bottom:1px solid var(--theme-border-color)}.checkout-card[_ngcontent-%COMP%]{background:var(--background-color);border:1px solid var(--theme-border-color);border-radius:12px;padding:28px}.checkout-icon[_ngcontent-%COMP%]{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px}.coupon-section[_ngcontent-%COMP%]{background:var(--bg-secondary);border:1px dashed var(--theme-border-color);border-radius:10px;padding:14px}.checkout-pay-btn[_ngcontent-%COMP%]     .dx-button-content{padding:12px 20px;font-size:15px;font-weight:600}.coupon-section[_ngcontent-%COMP%]     .dx-button.dx-state-disabled{opacity:.5}"]
            })
        }
    }
    return n
})();
var z = class {
    constructor(l) {
        return Object.assign(this, l)
    }
    static getForm(l) {
        return new xe().group({
            name: [l.name || null, [N.required, N.maxLength(255)]],
            email: [l.email || null, [N.required, N.email, N.maxLength(255)]],
            mobile_number: [l.mobile_number || null, [N.required]],
            company_name: [l.company_name || null, [N.required, N.maxLength(255)]],
            country_id: [l.country_id || null, [N.required]],
            currency_code: [l.currency_code || null, [N.required]],
            plan_id: [l.plan_id || null, [N.required]],
            billing_state_id: [l.billing_state_id || null],
            billing_gstin: [l.billing_gstin || null, [N.maxLength(15)]]
        })
    }
};

function Ft(n, l) {
    if (n & 1 && (a(0, "app-control-container", 14), p(1, "dx-select-box", 22), a(2, "small", 17), r(3, "Required for GST calculation on invoice"), o()()), n & 2) {
        let e = d();
        i(), b("items", e.states())("searchEnabled", !0)
    }
}

function jt(n, l) {
    if (n & 1 && (a(0, "div", 18), r(1), o()), n & 2) {
        let e = d();
        i(), x(" ", (e.errorResponse == null || e.errorResponse.error == null ? null : e.errorResponse.error.message) || e.formatMessage("something_went_wrong"), " ")
    }
}
var Ee = (() => {
    class n {
        constructor() {
            this.formatMessage = u, this.subscriptionService = v(A), this.route = v(D), this.router = v(L), this.toastService = v(W), this.formService = v(Ce), this.isSubmitting = f(!1), this.states = f([]), this.isIndia = f(!1), this.errorResponse = null, this.countryId = null, this.addOnPlanIds = ""
        }
        ngOnInit() {
            let e = Number(this.route.snapshot.queryParams.plan_id),
                t = Number(this.route.snapshot.queryParams.country_id),
                s = this.route.snapshot.queryParams.currency_code || "INR";
            this.addOnPlanIds = this.route.snapshot.queryParams.add_on_plan_ids || "", this.countryId = t || null, this.isIndia.set(s === "INR"), this.form = z.getForm(new z({
                plan_id: e || null,
                country_id: t || null,
                currency_code: s
            })), this.isIndia() && this.subscriptionService.getPlans(t || void 0).subscribe({
                next: m => this.states.set(m.states || [])
            })
        }
        onSubmit() {
            this.formService.validateFormFields(this.form), !this.form.invalid && (this.isSubmitting.set(!0), this.errorResponse = null, this.subscriptionService.createProspect(this.form.value).subscribe({
                next: e => {
                    this.isSubmitting.set(!1);
                    let t = {};
                    this.form.value.billing_state_id && (t.billing_state_id = this.form.value.billing_state_id), this.form.value.billing_gstin && (t.billing_gstin = this.form.value.billing_gstin), this.addOnPlanIds && (t.add_on_plan_ids = this.addOnPlanIds), this.router.navigate(["/pricing/prospect", e.token, "checkout"], {
                        queryParams: t
                    })
                },
                error: e => {
                    this.errorResponse = e, this.isSubmitting.set(!1)
                }
            }))
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = B({
                type: n,
                selectors: [
                    ["app-prospect-register"]
                ],
                standalone: !1,
                decls: 26,
                vars: 19,
                consts: [
                    [1, "d-flex", "justify-content-center", "align-items-center", "py-5", "dx-theme-background-color", 2, "min-height", "80vh"],
                    [1, "dx-card", "shadow", "rounded-4", 2, "max-width", "520px", "width", "100%"],
                    [1, "p-4", "p-md-5"],
                    [1, "fw-bold", "mb-1", "text-center"],
                    [1, "text-muted", "text-center", "small", "mb-4"],
                    [3, "ngSubmit", "formGroup"],
                    ["name", "name", 3, "label", "errorMsg"],
                    ["formControlName", "name", 3, "placeholder"],
                    ["label", "Business Email", "name", "email", 3, "errorMsg"],
                    ["formControlName", "email", "mode", "email", "placeholder", "Enter your business email"],
                    ["name", "mobile_number", 3, "label", "errorMsg"],
                    [3, "countryId", "formControl"],
                    ["label", "Company / Business Name", "name", "company_name", 3, "errorMsg"],
                    ["formControlName", "company_name", "placeholder", "Enter your company or business name"],
                    ["label", "State", "name", "billing_state_id"],
                    ["label", "GSTIN (Optional)", "name", "billing_gstin"],
                    ["formControlName", "billing_gstin", "placeholder", "e.g. 27AAJCB1677J1ZC", 3, "maxLength"],
                    [1, "text-muted"],
                    [1, "alert", "alert-danger", "small", "mt-2"],
                    ["type", "default", "stylingMode", "contained", 1, "w-100", "mt-3", 3, "text", "useSubmitBehavior", "disabled"],
                    [1, "text-center", "small", "mt-4", "mb-0"],
                    ["href", "/auth/tenantLogin", 1, "text-primary"],
                    ["formControlName", "billing_state_id", "displayExpr", "name", "valueExpr", "id", "placeholder", "Select your state", 3, "items", "searchEnabled"]
                ],
                template: function(t, s) {
                    t & 1 && (a(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "h3", 3), r(4), o(), a(5, "p", 4), r(6), o(), a(7, "form", 5), h("ngSubmit", function() {
                        return s.onSubmit()
                    }), a(8, "app-control-container", 6), p(9, "dx-text-box", 7), o(), a(10, "app-control-container", 8), p(11, "dx-text-box", 9), o(), a(12, "app-control-container", 10), p(13, "app-mobile-number", 11), o(), a(14, "app-control-container", 12), p(15, "dx-text-box", 13), o(), g(16, Ft, 4, 2, "app-control-container", 14), a(17, "app-control-container", 15), p(18, "dx-text-box", 16), a(19, "small", 17), r(20, "For GST invoice. You can add this later from billing settings."), o()(), g(21, jt, 2, 1, "div", 18), p(22, "dx-button", 19), o(), a(23, "p", 20)(24, "a", 21), r(25), o()()()()()), t & 2 && (i(4), c(s.formatMessage("create_account")), i(2), c(s.formatMessage("prospect_register_subtitle")), i(), b("formGroup", s.form), i(), b("label", s.formatMessage("name"))("errorMsg", s.formatMessage("required")), i(), b("placeholder", s.formatMessage("enter_name")), i(), b("errorMsg", s.formatMessage("required")), i(2), b("label", s.formatMessage("mobile_number"))("errorMsg", s.formatMessage("required")), i(), b("countryId", s.countryId)("formControl", s.form.controls.mobile_number), i(), b("errorMsg", s.formatMessage("required")), i(2), _(s.isIndia() && s.states().length ? 16 : -1), i(2), b("maxLength", 15), i(3), _(s.errorResponse ? 21 : -1), i(), b("text", s.formatMessage("proceed_to_payment"))("useSubmitBehavior", !0)("disabled", s.isSubmitting()), i(3), x("", s.formatMessage("already_have_account"), " Login"))
                },
                dependencies: [ye, Pe, F, J, H, ue, pe, me, ge, fe, _e],
                styles: ["[_nghost-%COMP%]{display:block;background:var(--primary-bg);color:var(--font-color)}"]
            })
        }
    }
    return n
})();

function zt(n, l) {
    n & 1 && (a(0, "div", 1), p(1, "dx-load-indicator", 3), o()), n & 2 && (i(), b("visible", !0))
}

function Rt(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "dx-button", 9), h("onClick", function() {
            C(e);
            let s = d(2);
            return y(s.goToWorkspace())
        }), o()
    }
    if (n & 2) {
        let e = d(2);
        b("text", e.formatMessage("go_to_workspace"))
    }
}

function $t(n, l) {
    if (n & 1 && (a(0, "div", 2)(1, "div", 4), p(2, "i", 5), o(), a(3, "h3", 6), r(4), o(), a(5, "p", 7), r(6), o(), g(7, Rt, 1, 1, "dx-button", 8), o()), n & 2) {
        let e = d();
        i(4), c(e.formatMessage("payment_success")), i(2), c(e.formatMessage("payment_success_desc")), i(), _(e.isLoggedIn() ? 7 : -1)
    }
}

function Gt(n, l) {
    if (n & 1) {
        let e = S();
        a(0, "div", 2)(1, "div", 4), p(2, "i", 10), o(), a(3, "h3", 6), r(4), o(), a(5, "p", 7), r(6), o(), a(7, "dx-button", 9), h("onClick", function() {
            C(e);
            let s = d();
            return y(s.goToPricing())
        }), o()()
    }
    if (n & 2) {
        let e = d();
        i(4), c(e.formatMessage("payment_failed")), i(2), c(e.formatMessage("payment_failed_desc")), i(), b("text", e.formatMessage("try_again"))
    }
}

function Ut(n, l) {
    if (n & 1 && (a(0, "div", 2)(1, "div", 4), p(2, "dx-load-indicator", 3), o(), a(3, "h3", 6), r(4), o(), a(5, "p", 7), r(6), o()()), n & 2) {
        let e = d();
        i(2), b("visible", !0), i(2), c(e.formatMessage("payment_pending")), i(2), c(e.formatMessage("payment_pending_desc"))
    }
}
var Ie = (() => {
    class n {
        constructor() {
            this.formatMessage = u, this.storageService = v(q), this.subscriptionService = v(A), this.route = v(D), this.router = v(L), this.isLoggedIn = f(this.storageService.loggedIn()), this.isLoading = f(!0), this.status = f("pending"), this.orderNumber = f(""), this.pollingSubscription = null
        }
        ngOnInit() {
            let e = this.route.snapshot.queryParams.order;
            if (!e || !this.isLoggedIn()) {
                this.status.set("paid"), this.isLoading.set(!1);
                return
            }
            this.orderNumber.set(e), this.checkStatus(e)
        }
        ngOnDestroy() {
            this.pollingSubscription ? .unsubscribe()
        }
        checkStatus(e) {
            this.subscriptionService.checkOrderStatus(e).subscribe({
                next: t => {
                    let s = t.status ? .value || t.status || "pending";
                    this.handleStatus(s, e)
                },
                error: () => {
                    this.status.set("failed"), this.isLoading.set(!1)
                }
            })
        }
        handleStatus(e, t) {
            e === "paid" ? (this.status.set("paid"), this.isLoading.set(!1)) : e === "failed" ? (this.status.set("failed"), this.isLoading.set(!1)) : (this.status.set("pending"), this.isLoading.set(!1), this.startPolling(t))
        }
        startPolling(e) {
            this.pollingSubscription = ne(3e3).pipe(ae(() => this.subscriptionService.checkOrderStatus(e)), oe(t => {
                let s = t.status ? .value || t.status || "pending";
                return s === "pending" || s === "payment_initiated"
            }, !0)).subscribe({
                next: t => {
                    let s = t.status ? .value || t.status || "pending";
                    s === "paid" ? (this.status.set("paid"), this.pollingSubscription ? .unsubscribe()) : s === "failed" && (this.status.set("failed"), this.pollingSubscription ? .unsubscribe())
                }
            })
        }
        goToWorkspace() {
            window.location.href = "/settings/subscription"
        }
        goToPricing() {
            this.router.navigate(["/pricing"])
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = B({
                type: n,
                selectors: [
                    ["app-payment-success"]
                ],
                standalone: !1,
                decls: 5,
                vars: 4,
                consts: [
                    [1, "d-flex", "justify-content-center", "align-items-center", "dx-theme-background-color", 2, "min-height", "80vh"],
                    [1, "text-center"],
                    [1, "dx-card", "shadow", "rounded-4", "p-5", "text-center", "mx-3", 2, "max-width", "460px", "width", "100%"],
                    ["height", "50", "width", "50", 3, "visible"],
                    [1, "mb-4"],
                    [1, "fa-solid", "fa-circle-check", "text-success", 2, "font-size", "64px"],
                    [1, "fw-bold", "mb-2"],
                    [1, "text-muted", "mb-4"],
                    ["type", "default", "stylingMode", "contained", 1, "w-100", 3, "text"],
                    ["type", "default", "stylingMode", "contained", 1, "w-100", 3, "onClick", "text"],
                    [1, "fa-solid", "fa-circle-xmark", "text-danger", 2, "font-size", "64px"]
                ],
                template: function(t, s) {
                    t & 1 && (a(0, "div", 0), g(1, zt, 2, 1, "div", 1), g(2, $t, 8, 3, "div", 2), g(3, Gt, 8, 3, "div", 2), g(4, Ut, 7, 3, "div", 2), o()), t & 2 && (i(), _(s.isLoading() ? 1 : -1), i(), _(!s.isLoading() && s.status() === "paid" ? 2 : -1), i(), _(!s.isLoading() && s.status() === "failed" ? 3 : -1), i(), _(!s.isLoading() && s.status() === "pending" ? 4 : -1))
                },
                dependencies: [F, V],
                styles: ["[_nghost-%COMP%]{display:block}"]
            })
        }
    }
    return n
})();
var Oe = (() => {
    class n {
        constructor() {
            this.route = v(D)
        }
        ngOnInit() {
            let e = this.route.snapshot.queryParams.url;
            e && (window.location.href = e)
        }
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275cmp = B({
                type: n,
                selectors: [
                    ["app-payment-redirect"]
                ],
                standalone: !1,
                decls: 2,
                vars: 1,
                consts: [
                    [1, "d-flex", "justify-content-center", "align-items-center", 2, "min-height", "100vh"],
                    ["height", "50", "width", "50", 3, "visible"]
                ],
                template: function(t, s) {
                    t & 1 && (a(0, "div", 0), p(1, "dx-load-indicator", 1), o()), t & 2 && (i(), b("visible", !0))
                },
                dependencies: [V],
                encapsulation: 2
            })
        }
    }
    return n
})();
var Yt = [{
        path: "",
        children: [{
            path: "pay",
            component: Oe,
            title: "Redirecting to Payment..."
        }, {
            path: "",
            component: ke,
            title: "BytePhase Pricing"
        }, {
            path: "checkout/:orderNumber",
            component: ee,
            title: "BytePhase Checkout"
        }, {
            path: "register",
            component: Ee,
            title: "BytePhase Register"
        }, {
            path: "prospect/:token/checkout",
            component: ee,
            title: "BytePhase Checkout"
        }, {
            path: "success",
            component: Ie,
            title: "BytePhase Payment Success"
        }]
    }],
    Te = (() => {
        class n {
            static {
                this.\u0275fac = function(t) {
                    return new(t || n)
                }
            }
            static {
                this.\u0275mod = $({
                    type: n
                })
            }
            static {
                this.\u0275inj = R({
                    imports: [K.forChild(Yt), K]
                })
            }
        }
        return n
    })();
var dn = (() => {
    class n {
        static {
            this.\u0275fac = function(t) {
                return new(t || n)
            }
        }
        static {
            this.\u0275mod = $({
                type: n
            })
        }
        static {
            this.\u0275inj = R({
                imports: [ce, Me, Te, Se]
            })
        }
    }
    return n
})();
export {
    dn as SubscriptionModule
};